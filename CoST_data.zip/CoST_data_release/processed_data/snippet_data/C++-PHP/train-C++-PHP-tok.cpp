#include <bits/stdc++.h> NEW_LINE using namespace std ; void towerOfHanoi ( int n , char from_rod , char to_rod , char aux_rod ) { if ( n == 1 ) { cout << " Move ▁ disk ▁ 1 ▁ from ▁ rod ▁ " << from_rod << " ▁ to ▁ rod ▁ " << to_rod << endl ; return ; } towerOfHanoi ( n - 1 , from_rod , aux_rod , to_rod ) ; cout << " Move ▁ disk ▁ " << n << " ▁ from ▁ rod ▁ " << from_rod << " ▁ to ▁ rod ▁ " << to_rod << endl ; towerOfHanoi ( n - 1 , aux_rod , to_rod , from_rod ) ; }
int n = 4 ;
towerOfHanoi ( n , ' A ' , ' C ' , ' B ' ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void printMaxOfMin ( int arr [ ] , int n ) {
for ( int k = 1 ; k <= n ; k ++ ) {
int maxOfMin = INT_MIN ;
for ( int i = 0 ; i <= n - k ; i ++ ) {
int min = arr [ i ] ; for ( int j = 1 ; j < k ; j ++ ) { if ( arr [ i + j ] < min ) min = arr [ i + j ] ; }
if ( min > maxOfMin ) maxOfMin = min ; }
cout << maxOfMin << " ▁ " ; } }
int main ( ) { int arr [ ] = { 10 , 20 , 30 , 50 , 10 , 70 , 30 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printMaxOfMin ( arr , n ) ; return 0 ; }
void PrintMinNumberForPattern ( string arr ) {
int curr_max = 0 ;
int last_entry = 0 ; int j ;
for ( int i = 0 ; i < arr . length ( ) ; i ++ ) {
int noOfNextD = 0 ; switch ( arr [ i ] ) { case ' I ' :
j = i + 1 ; while ( arr [ j ] == ' D ' && j < arr . length ( ) ) { noOfNextD ++ ; j ++ ; } if ( i == 0 ) { curr_max = noOfNextD + 2 ;
cout << " ▁ " << ++ last_entry ; cout << " ▁ " << curr_max ;
last_entry = curr_max ; } else {
curr_max = curr_max + noOfNextD + 1 ;
last_entry = curr_max ; cout << " ▁ " << last_entry ; }
for ( int k = 0 ; k < noOfNextD ; k ++ ) { cout << " ▁ " << -- last_entry ; i ++ ; } break ;
case ' D ' : if ( i == 0 ) {
j = i + 1 ; while ( arr [ j ] == ' D ' && j < arr . length ( ) ) { noOfNextD ++ ; j ++ ; }
curr_max = noOfNextD + 2 ;
cout << " ▁ " << curr_max << " ▁ " << curr_max - 1 ;
last_entry = curr_max - 1 ; } else {
cout << " ▁ " << last_entry - 1 ; last_entry -- ; } break ; } } cout << endl ; }
int main ( ) { PrintMinNumberForPattern ( " IDID " ) ; PrintMinNumberForPattern ( " I " ) ; PrintMinNumberForPattern ( " DD " ) ; PrintMinNumberForPattern ( " II " ) ; PrintMinNumberForPattern ( " DIDI " ) ; PrintMinNumberForPattern ( " IIDDD " ) ; PrintMinNumberForPattern ( " DDIDDIID " ) ; return 0 ; }
stack < int > st ;
void push_digits ( int number ) { while ( number != 0 ) { st . push ( number % 10 ) ; number = number / 10 ; } }
int reverse_number ( int number ) {
push_digits ( number ) ; int reverse = 0 ; int i = 1 ;
while ( ! st . empty ( ) ) { reverse = reverse + ( st . top ( ) * i ) ; st . pop ( ) ; i = i * 10 ; }
return reverse ; }
int main ( ) { int number = 39997 ;
cout << reverse_number ( number ) ; return 0 ; }
void heapify ( int arr [ ] , int n , int i ) {
int largest = i ;
int l = 2 * i + 1 ;
int r = 2 * i + 2 ;
if ( l < n && arr [ l ] > arr [ largest ] ) largest = l ;
if ( r < n && arr [ r ] > arr [ largest ] ) largest = r ;
if ( largest != i ) { swap ( arr [ i ] , arr [ largest ] ) ;
heapify ( arr , n , largest ) ; } }
void heapSort ( int arr [ ] , int n ) {
for ( int i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( int i = n - 1 ; i > 0 ; i -- ) {
swap ( arr [ 0 ] , arr [ i ] ) ;
heapify ( arr , i , 0 ) ; } }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; ++ i ) cout << arr [ i ] << " ▁ " ; cout << " STRNEWLINE " ; }
int main ( ) { int arr [ ] = { 12 , 11 , 13 , 5 , 6 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; heapSort ( arr , n ) ; cout << " Sorted ▁ array ▁ is ▁ STRNEWLINE " ; printArray ( arr , n ) ; }
bool isHeap ( int arr [ ] , int i , int n ) {
if ( i >= ( n - 2 ) / 2 ) return true ;
if ( arr [ i ] >= arr [ 2 * i + 1 ] && arr [ i ] >= arr [ 2 * i + 2 ] && isHeap ( arr , 2 * i + 1 , n ) && isHeap ( arr , 2 * i + 2 , n ) ) return true ; return false ; }
int main ( ) { int arr [ ] = { 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 } ; int n = sizeof ( arr ) / sizeof ( int ) - 1 ; isHeap ( arr , 0 , n ) ? printf ( " Yes " ) : printf ( " No " ) ; return 0 ; }
bool isHeap ( int arr [ ] , int n ) {
for ( int i = 0 ; i <= ( n - 2 ) / 2 ; i ++ ) {
if ( arr [ 2 * i + 1 ] > arr [ i ] ) return false ;
if ( 2 * i + 2 < n && arr [ 2 * i + 2 ] > arr [ i ] ) return false ; } return true ; }
int main ( ) { int arr [ ] = { 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 } ; int n = sizeof ( arr ) / sizeof ( int ) ; isHeap ( arr , n ) ? printf ( " Yes " ) : printf ( " No " ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE void generate_derangement ( int N ) {
int S [ N + 1 ] ; for ( int i = 1 ; i <= N ; i ++ ) S [ i ] = i ;
int D [ N + 1 ] ; for ( int i = 1 ; i <= N ; i += 2 ) { if ( i == N && i % N != 0 ) {
int temp = D [ N ] ; D [ N ] = D [ N - 1 ] ; D [ N - 1 ] = temp ; } else { D [ i ] = i + 1 ; D [ i + 1 ] = i ; } }
for ( int i = 1 ; i <= N ; i ++ ) printf ( " % d ▁ " , D [ i ] ) ; printf ( " STRNEWLINE " ) ; }
int main ( ) { generate_derangement ( 10 ) ; return 0 ; }
int sumBetweenTwoKth ( int arr [ ] , int n , int k1 , int k2 ) {
sort ( arr , arr + n ) ;
int result = 0 ; for ( int i = k1 ; i < k2 - 1 ; i ++ ) result += arr [ i ] ; return result ; }
int main ( ) { int arr [ ] = { 20 , 8 , 22 , 4 , 12 , 10 , 14 } ; int k1 = 3 , k2 = 6 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << sumBetweenTwoKth ( arr , n , k1 , k2 ) ; return 0 ; }
int minSum ( int a [ ] , int n ) {
sort ( a , a + n ) ; int num1 = 0 ; int num2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) num1 = num1 * 10 + a [ i ] ; else num2 = num2 * 10 + a [ i ] ; } return num2 + num1 ; }
int main ( ) { int arr [ ] = { 5 , 3 , 0 , 7 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " The ▁ required ▁ sum ▁ is ▁ " << minSum ( arr , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  3 NEW_LINE #define M  4 NEW_LINE using namespace std ;
void printDistance ( int mat [ N ] [ M ] ) { int ans [ N ] [ M ] ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) ans [ i ] [ j ] = INT_MAX ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) {
for ( int k = 0 ; k < N ; k ++ ) for ( int l = 0 ; l < M ; l ++ ) {
if ( mat [ k ] [ l ] == 1 ) ans [ i ] [ j ] = min ( ans [ i ] [ j ] , abs ( i - k ) + abs ( j - l ) ) ; } }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) cout << ans [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int mat [ N ] [ M ] = { 0 , 0 , 0 , 1 , 0 , 0 , 1 , 1 , 0 , 1 , 1 , 0 } ; printDistance ( mat ) ; return 0 ; }
bool isMinHeap ( int level [ ] , int n ) {
for ( int i = ( n / 2 - 1 ) ; i >= 0 ; i -- ) {
if ( level [ i ] > level [ 2 * i + 1 ] ) return false ; if ( 2 * i + 2 < n ) {
if ( level [ i ] > level [ 2 * i + 2 ] ) return false ; } } return true ; }
int main ( ) { int level [ ] = { 10 , 15 , 14 , 25 , 30 } ; int n = sizeof ( level ) / sizeof ( level [ 0 ] ) ; if ( isMinHeap ( level , n ) ) cout << " True " ; else cout << " False " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int mostFrequent ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int max_count = 1 , res = arr [ 0 ] , curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
int main ( ) { int arr [ ] = { 1 , 5 , 2 , 1 , 3 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << mostFrequent ( arr , n ) ; return 0 ; }
bool areDisjoint ( int set1 [ ] , int set2 [ ] , int m , int n ) {
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( set1 [ i ] == set2 [ j ] ) return false ;
return true ; }
int main ( ) { int set1 [ ] = { 12 , 34 , 11 , 9 , 3 } ; int set2 [ ] = { 7 , 2 , 1 , 5 } ; int m = sizeof ( set1 ) / sizeof ( set1 [ 0 ] ) ; int n = sizeof ( set2 ) / sizeof ( set2 [ 0 ] ) ; areDisjoint ( set1 , set2 , m , n ) ? cout << " Yes " : cout << " ▁ No " ; return 0 ; }
void findMissing ( int a [ ] , int b [ ] , int n , int m ) { for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < m ; j ++ ) if ( a [ i ] == b [ j ] ) break ; if ( j == m ) cout << a [ i ] << " ▁ " ; } }
int main ( ) { int a [ ] = { 1 , 2 , 6 , 3 , 4 , 5 } ; int b [ ] = { 2 , 4 , 3 , 1 , 0 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int m = sizeof ( b ) / sizeof ( b [ 1 ] ) ; findMissing ( a , b , n , m ) ; return 0 ; }
bool areEqual ( int arr1 [ ] , int arr2 [ ] , int n , int m ) {
if ( n != m ) return false ;
sort ( arr1 , arr1 + n ) ; sort ( arr2 , arr2 + m ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr1 [ i ] != arr2 [ i ] ) return false ;
return true ; }
int main ( ) { int arr1 [ ] = { 3 , 5 , 2 , 5 , 2 } ; int arr2 [ ] = { 2 , 3 , 5 , 5 , 2 } ; int n = sizeof ( arr1 ) / sizeof ( int ) ; int m = sizeof ( arr2 ) / sizeof ( int ) ; if ( areEqual ( arr1 , arr2 , n , m ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
bool isProduct ( int arr [ ] , int n , int x ) {
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; i < n ; i ++ ) if ( arr [ i ] * arr [ j ] == x ) return true ; return false ; }
int main ( ) { int arr [ ] = { 10 , 20 , 9 , 40 } ; int x = 400 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; isProduct ( arr , n , x ) ? cout << " Yesn " : cout << " Non " ; x = 190 ; isProduct ( arr , n , x ) ? cout << " Yesn " : cout << " Non " ; return 0 ; }
int findGreatest ( int arr [ ] , int n ) { int result = -1 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ j ] * arr [ k ] == arr [ i ] ) result = max ( result , arr [ i ] ) ; return result ; }
int main ( ) { int arr [ ] = { 30 , 10 , 9 , 3 , 35 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findGreatest ( arr , n ) ; return 0 ; }
int subset ( int ar [ ] , int n ) {
int res = 0 ;
sort ( ar , ar + n ) ;
for ( int i = 0 ; i < n ; i ++ ) { int count = 1 ;
for ( ; i < n - 1 ; i ++ ) { if ( ar [ i ] == ar [ i + 1 ] ) count ++ ; else break ; }
res = max ( res , count ) ; } return res ; }
int main ( ) { int arr [ ] = { 5 , 6 , 9 , 3 , 4 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << subset ( arr , n ) ; return 0 ; }
int getPairsCount ( int arr [ ] , int n , int sum ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] + arr [ j ] == sum ) count ++ ; return count ; }
int main ( ) { int arr [ ] = { 1 , 5 , 7 , -1 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int sum = 6 ; cout << " Count ▁ of ▁ pairs ▁ is ▁ " << getPairsCount ( arr , n , sum ) ; return 0 ; }
int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ )
if ( ( arr1 [ i ] + arr2 [ j ] ) == x ) count ++ ;
return count ; }
int main ( ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; int x = 10 ; cout << " Count ▁ = ▁ " << countPairs ( arr1 , arr2 , m , n , x ) ; return 0 ; }
bool isPresent ( int arr [ ] , int low , int high , int value ) { while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ; for ( int i = 0 ; i < m ; i ++ ) {
int value = x - arr1 [ i ] ;
if ( isPresent ( arr2 , 0 , n - 1 , value ) ) count ++ ; }
return count ; }
int main ( ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; int x = 10 ; cout << " Count ▁ = ▁ " << countPairs ( arr1 , arr2 , m , n , x ) ; return 0 ; }
int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ; int l = 0 , r = n - 1 ;
while ( l < m && r >= 0 ) {
if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) { l ++ ; r -- ; count ++ ; }
else if ( ( arr1 [ l ] + arr2 [ r ] ) < x ) l ++ ;
else r -- ; }
return count ; }
int main ( ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; int x = 10 ; cout << " Count ▁ = ▁ " << countPairs ( arr1 , arr2 , m , n , x ) ; return 0 ; }
bool isPresent ( int arr [ ] , int low , int high , int value ) { while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
int countQuadruples ( int arr1 [ ] , int arr2 [ ] , int arr3 [ ] , int arr4 [ ] , int n , int x ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) for ( int k = 0 ; k < n ; k ++ ) {
int T = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
if ( isPresent ( arr4 , 0 , n , x - T ) )
count ++ ; }
return count ; }
int arr1 [ ] = { 1 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 7 , 8 } ; int arr3 [ ] = { 1 , 4 , 6 , 10 } ; int arr4 [ ] = { 2 , 4 , 7 , 8 } ; int n = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int x = 30 ; cout << " Count ▁ = ▁ " << countQuadruples ( arr1 , arr2 , arr3 , arr4 , n , x ) ; return 0 ; }
int countPairs ( int arr [ ] , int n ) { int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int product = arr [ i ] * arr [ j ] ;
for ( int k = 0 ; k < n ; k ++ ) {
if ( arr [ k ] == product ) { result ++ ; break ; } } } }
return result ; }
int main ( ) { int arr [ ] = { 6 , 2 , 4 , 12 , 5 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countPairs ( arr , n ) ; return 0 ; }
void findPairs ( int arr1 [ ] , int arr2 [ ] , int n , int m , int x ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( arr1 [ i ] + arr2 [ j ] == x ) cout << arr1 [ i ] << " ▁ " << arr2 [ j ] << endl ; }
int main ( ) { int arr1 [ ] = { 1 , 2 , 3 , 7 , 5 , 4 } ; int arr2 [ ] = { 0 , 7 , 4 , 3 , 2 , 1 } ; int n = sizeof ( arr1 ) / sizeof ( int ) ; int m = sizeof ( arr2 ) / sizeof ( int ) ; int x = 8 ; findPairs ( arr1 , arr2 , n , m , x ) ; return 0 ; }
void findPair ( int arr [ ] , int n ) { bool found = false ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { for ( int k = 0 ; k < n ; k ++ ) { if ( arr [ i ] + arr [ j ] == arr [ k ] ) { cout << arr [ i ] << " ▁ " << arr [ j ] << endl ; found = true ; } } } } if ( found == false ) cout << " Not ▁ exist " << endl ; }
int main ( ) { int arr [ ] = { 10 , 4 , 8 , 13 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findPair ( arr , n ) ; return 0 ; }
bool printPairs ( int arr [ ] , int n , int k ) { bool isPairFound = true ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i != j && arr [ i ] % arr [ j ] == k ) { cout << " ( " << arr [ i ] << " , ▁ " << arr [ j ] << " ) " << " ▁ " ; isPairFound = true ; } } } return isPairFound ; }
int main ( ) { int arr [ ] = { 2 , 3 , 5 , 4 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; if ( printPairs ( arr , n , k ) == false ) cout << " No ▁ such ▁ pair ▁ exists " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define ASCII_SIZE  256 NEW_LINE using namespace std ; char getMaxOccuringChar ( char * str ) {
int count [ ASCII_SIZE ] = { 0 } ;
int len = strlen ( str ) ;
int max = 0 ;
for ( int i = 0 ; i < len ; i ++ ) { count [ str [ i ] ] ++ ; if ( max < count [ str [ i ] ] ) { max = count [ str [ i ] ] ; result = str [ i ] ; } } return result ; }
int main ( ) { char str [ ] = " sample ▁ string " ; cout << " Max ▁ occurring ▁ character ▁ is ▁ " << getMaxOccuringChar ( str ) ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int firstNonRepeating ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ i ] == arr [ j ] ) break ; if ( j == n ) return arr [ i ] ; } return -1 ; }
int main ( ) { int arr [ ] = { 9 , 4 , 9 , 6 , 7 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << firstNonRepeating ( arr , n ) ; return 0 ; }
int printKDistinct ( int arr [ ] , int n , int k ) { int dist_count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ j ] == arr [ i ] ) break ;
if ( j == n ) dist_count ++ ; if ( dist_count == k ) return arr [ i ] ; } return -1 ; }
int main ( ) { int ar [ ] = { 1 , 2 , 1 , 3 , 4 , 2 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; int k = 2 ; cout << printKDistinct ( ar , n , k ) ; return 0 ; }
void subarrayDivisibleByK ( int arr [ ] , int n , int k ) {
map < int , int > mp ;
int s = 0 , e = 0 , maxs = 0 , maxe = 0 ;
mp [ arr [ 0 ] % k ] ++ ; for ( int i = 1 ; i < n ; i ++ ) { int mod = arr [ i ] % k ;
while ( mp [ k - mod ] != 0 || ( mod == 0 && mp [ mod ] != 0 ) ) { mp [ arr [ s ] % k ] -- ; s ++ ; }
mp [ mod ] ++ ; e ++ ;
if ( ( e - s ) > ( maxe - maxs ) ) { maxe = e ; maxs = s ; } } cout << " The ▁ maximum ▁ size ▁ is ▁ " << maxe - maxs + 1 << " ▁ and ▁ " " the ▁ subarray ▁ is ▁ as ▁ follows STRNEWLINE " ; for ( int i = maxs ; i <= maxe ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int k = 3 ; int arr [ ] = { 5 , 10 , 15 , 20 , 25 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; subarrayDivisibleByK ( arr , n , k ) ; return 0 ; }
bool findTriplet ( int a1 [ ] , int a2 [ ] , int a3 [ ] , int n1 , int n2 , int n3 , int sum ) { for ( int i = 0 ; i < n1 ; i ++ ) for ( int j = 0 ; j < n2 ; j ++ ) for ( int k = 0 ; k < n3 ; k ++ ) if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) return true ; return false ; }
int main ( ) { int a1 [ ] = { 1 , 2 , 3 , 4 , 5 } ; int a2 [ ] = { 2 , 3 , 6 , 1 , 2 } ; int a3 [ ] = { 3 , 2 , 4 , 5 , 6 } ; int sum = 9 ; int n1 = sizeof ( a1 ) / sizeof ( a1 [ 0 ] ) ; int n2 = sizeof ( a2 ) / sizeof ( a2 [ 0 ] ) ; int n3 = sizeof ( a3 ) / sizeof ( a3 [ 0 ] ) ; findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) ? cout << " Yes " : cout << " No " ; return 0 ; }
int minInsertion ( string str ) {
int n = str . length ( ) ;
int res = 0 ;
int count [ 26 ] = { 0 } ;
for ( int i = 0 ; i < n ; i ++ ) count [ str [ i ] - ' a ' ] ++ ;
for ( int i = 0 ; i < 26 ; i ++ ) if ( count [ i ] % 2 == 1 ) res ++ ;
return ( res == 0 ) ? 0 : res - 1 ; }
int main ( ) { string str = " geeksforgeeks " ; cout << minInsertion ( str ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int findDiff ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ; int count = 0 , max_count = 0 , min_count = n ; for ( int i = 0 ; i < ( n - 1 ) ; i ++ ) {
if ( arr [ i ] == arr [ i + 1 ] ) { count += 1 ; continue ; } else { max_count = max ( max_count , count ) ; min_count = min ( min_count , count ) ; count = 0 ; } } return ( max_count - min_count ) ; }
int main ( ) { int arr [ ] = { 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findDiff ( arr , n ) << " STRNEWLINE " ; return 0 ; }
int maxDiff ( int arr [ ] , int n ) { int SubsetSum_1 = 0 , SubsetSum_2 = 0 ; for ( int i = 0 ; i <= n - 1 ; i ++ ) { bool isSingleOccurance = true ; for ( int j = i + 1 ; j <= n - 1 ; j ++ ) {
if ( arr [ i ] == arr [ j ] ) { isSingleOccurance = false ; arr [ i ] = arr [ j ] = 0 ; break ; } } if ( isSingleOccurance ) { if ( arr [ i ] > 0 ) SubsetSum_1 += arr [ i ] ; else SubsetSum_2 += arr [ i ] ; } } return abs ( SubsetSum_1 - SubsetSum_2 ) ; }
int main ( ) { int arr [ ] = { 4 , 2 , -3 , 3 , -2 , -2 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Maximum ▁ Difference ▁ = ▁ " << maxDiff ( arr , n ) ; return 0 ; }
int maxDiff ( int arr [ ] , int n ) { int result = 0 ;
sort ( arr , arr + n ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) result += abs ( arr [ i ] ) ; else i ++ ; }
if ( arr [ n - 2 ] != arr [ n - 1 ] ) result += abs ( arr [ n - 1 ] ) ;
return result ; }
int main ( ) { int arr [ ] = { 4 , 2 , -3 , 3 , -2 , -2 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Maximum ▁ Difference ▁ = ▁ " << maxDiff ( arr , n ) ; return 0 ; }
int calculate ( int a [ ] , int n ) {
sort ( a , a + n ) ; int count = 1 ; int answer = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == a [ i - 1 ] ) {
count += 1 ; } else {
answer = answer + ( count * ( count - 1 ) ) / 2 ; count = 1 ; } } answer = answer + ( count * ( count - 1 ) ) / 2 ; return answer ; }
int main ( ) { int a [ ] = { 1 , 2 , 1 , 2 , 4 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
cout << calculate ( a , n ) ; return 0 ; }
int calculate ( int a [ ] , int n ) {
int * maximum = max_element ( a , a + n ) ;
int frequency [ * maximum + 1 ] = { 0 } ;
for ( int i = 0 ; i < n ; i ++ ) {
frequency [ a [ i ] ] += 1 ; } int answer = 0 ;
for ( int i = 0 ; i < ( * maximum ) + 1 ; i ++ ) {
answer = answer + frequency [ i ] * ( frequency [ i ] - 1 ) ; } return answer / 2 ; }
int main ( ) { int a [ ] = { 1 , 2 , 1 , 2 , 4 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
cout << ( calculate ( a , n ) ) ; }
void printAllAPTriplets ( int arr [ ] , int n ) { unordered_set < int > s ; for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int diff = arr [ j ] - arr [ i ] ; if ( s . find ( arr [ i ] - diff ) != s . end ( ) ) cout << arr [ i ] - diff << " ▁ " << arr [ i ] << " ▁ " << arr [ j ] << endl ; } s . insert ( arr [ i ] ) ; } }
int main ( ) { int arr [ ] = { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printAllAPTriplets ( arr , n ) ; return 0 ; }
void printAllAPTriplets ( int arr [ ] , int n ) { for ( int i = 1 ; i < n - 1 ; i ++ ) {
for ( int j = i - 1 , k = i + 1 ; j >= 0 && k < n ; ) {
if ( arr [ j ] + arr [ k ] == 2 * arr [ i ] ) { cout << arr [ j ] << " ▁ " << arr [ i ] << " ▁ " << arr [ k ] << endl ;
k ++ ; j -- ; }
else if ( arr [ j ] + arr [ k ] < 2 * arr [ i ] ) k ++ ; else j -- ; } } }
int main ( ) { int arr [ ] = { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printAllAPTriplets ( arr , n ) ; return 0 ; }
int countTriplets ( int arr [ ] , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) for ( int j = i + 1 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] * arr [ j ] * arr [ k ] == m ) count ++ ; return count ; }
int main ( ) { int arr [ ] = { 1 , 4 , 6 , 2 , 3 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int m = 24 ; cout << countTriplets ( arr , n , m ) ; return 0 ; }
int countPairs ( int arr [ ] , int n ) { int ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ )
if ( arr [ i ] == arr [ j ] ) ans ++ ; return ans ; }
int main ( ) { int arr [ ] = { 1 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countPairs ( arr , n ) << endl ; return 0 ; }
int countNum ( int arr [ ] , int n ) { int count = 0 ;
sort ( arr , arr + n ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) count += arr [ i + 1 ] - arr [ i ] - 1 ; return count ; }
int main ( ) { int arr [ ] = { 3 , 5 , 8 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countNum ( arr , n ) << endl ; return 0 ; }
int countSubarrays ( int arr [ ] , int n ) {
int difference = 0 ; int ans = 0 ;
fill_n ( hash_positive , n + 1 , 0 ) ; fill_n ( hash_negative , n + 1 , 0 ) ;
hash_positive [ 0 ] = 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] & 1 == 1 ) difference ++ ; else difference -- ;
if ( difference < 0 ) { ans += hash_negative [ - difference ] ; hash_negative [ - difference ] ++ ; }
else { ans += hash_positive [ difference ] ; hash_positive [ difference ] ++ ; } }
return ans ; }
int main ( ) { int arr [ ] = { 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
cout << " Total ▁ Number ▁ of ▁ Even - Odd ▁ subarrays " " ▁ are ▁ " << countSubarrays ( arr , n ) ; return 0 ; }
int findLargestd ( int S [ ] , int n ) { bool found = false ;
sort ( S , S + n ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) continue ; for ( int k = j + 1 ; k < n ; k ++ ) { if ( i == k ) continue ; for ( int l = k + 1 ; l < n ; l ++ ) { if ( i == l ) continue ;
if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) { found = true ; return S [ i ] ; } } } } } if ( found == false ) return INT_MIN ; }
int main ( ) { int S [ ] = { 2 , 3 , 5 , 7 , 12 } ; int n = sizeof ( S ) / sizeof ( S [ 0 ] ) ; int ans = findLargestd ( S , n ) ; if ( ans == INT_MIN ) cout << " No ▁ Solution " << endl ; else cout << " Largest ▁ d ▁ such ▁ that ▁ a ▁ + ▁ b ▁ + ▁ " << " c ▁ = ▁ d ▁ is ▁ " << ans << endl ; return 0 ; }
int recaman ( int n ) {
arr [ 0 ] = 0 ; printf ( " % d , ▁ " , arr [ 0 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) { int curr = arr [ i - 1 ] - i ; int j ; for ( j = 0 ; j < i ; j ++ ) {
if ( ( arr [ j ] == curr ) curr < 0 ) { curr = arr [ i - 1 ] + i ; break ; } } arr [ i ] = curr ; printf ( " % d , ▁ " , arr [ i ] ) ; } }
int main ( ) { int n = 17 ; recaman ( n ) ; return 0 ; }
void recaman ( int n ) { if ( n <= 0 ) return ;
printf ( " % d , ▁ " , 0 ) ; unordered_set < int > s ; s . insert ( 0 ) ;
int prev = 0 ; for ( int i = 1 ; i < n ; i ++ ) { int curr = prev - i ;
if ( curr < 0 || s . find ( curr ) != s . end ( ) ) curr = prev + i ; s . insert ( curr ) ; printf ( " % d , ▁ " , curr ) ; prev = curr ; } }
int main ( ) { int n = 17 ; recaman ( n ) ; return 0 ; }
int findArea ( int arr [ ] , int n ) {
sort ( arr , arr + n , greater < int > ( ) ) ;
int dimension [ 2 ] = { 0 , 0 } ;
for ( int i = 0 , j = 0 ; i < n - 1 && j < 2 ; i ++ )
if ( arr [ i ] == arr [ i + 1 ] ) dimension [ j ++ ] = arr [ i ++ ] ;
return ( dimension [ 0 ] * dimension [ 1 ] ) ; }
int main ( ) { int arr [ ] = { 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findArea ( arr , n ) ; return 0 ; }
int search ( int arr [ ] , int l , int h , int key ) { if ( l > h ) return -1 ; int mid = ( l + h ) / 2 ; if ( arr [ mid ] == key ) return mid ;
if ( arr [ l ] <= arr [ mid ] ) {
if ( key >= arr [ l ] && key <= arr [ mid ] ) return search ( arr , l , mid - 1 , key ) ;
return search ( arr , mid + 1 , h , key ) ; }
if ( key >= arr [ mid ] && key <= arr [ h ] ) return search ( arr , mid + 1 , h , key ) ; return search ( arr , l , mid - 1 , key ) ; }
int main ( ) { int arr [ ] = { 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int key = 6 ; int i = search ( arr , 0 , n - 1 , key ) ; if ( i != -1 ) cout << " Index : ▁ " << i << endl ; else cout << " Key ▁ not ▁ found " ; }
bool pairInSortedRotated ( int arr [ ] , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) return true ;
if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return false ; }
int main ( ) { int arr [ ] = { 11 , 15 , 6 , 8 , 9 , 10 } ; int sum = 16 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( pairInSortedRotated ( arr , n , sum ) ) cout << " Array ▁ has ▁ two ▁ elements ▁ with ▁ sum ▁ 16" ; else cout << " Array ▁ doesn ' t ▁ have ▁ two ▁ elements ▁ with ▁ sum ▁ 16 ▁ " ; return 0 ; }
int pairsInSortedRotated ( int arr [ ] , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
int cnt = 0 ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) { cnt ++ ;
if ( l == ( r - 1 + n ) % n ) { return cnt ; } l = ( l + 1 ) % n ; r = ( r - 1 + n ) % n ; }
else if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return cnt ; }
int main ( ) { int arr [ ] = { 11 , 15 , 6 , 7 , 9 , 10 } ; int sum = 16 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << pairsInSortedRotated ( arr , n , sum ) ; return 0 ; }
int maxSum ( int arr [ ] , int n ) {
int arrSum = 0 ;
int currVal = 0 ; for ( int i = 0 ; i < n ; i ++ ) { arrSum = arrSum + arr [ i ] ; currVal = currVal + ( i * arr [ i ] ) ; }
int maxVal = currVal ;
for ( int j = 1 ; j < n ; j ++ ) { currVal = currVal + arrSum - n * arr [ n - j ] ; if ( currVal > maxVal ) maxVal = currVal ; }
return maxVal ; }
int main ( void ) { int arr [ ] = { 10 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Max sum is " return 0 ; }
int maxSum ( int arr [ ] , int n ) {
int res = INT_MIN ;
for ( int i = 0 ; i < n ; i ++ ) {
int curr_sum = 0 ;
for ( int j = 0 ; j < n ; j ++ ) { int index = ( i + j ) % n ; curr_sum += j * arr [ index ] ; }
res = max ( res , curr_sum ) ; } return res ; }
int main ( ) { int arr [ ] = { 8 , 3 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxSum ( arr , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int maxSum ( int arr [ ] , int n ) {
int cum_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) cum_sum += arr [ i ] ;
int curr_val = 0 ; for ( int i = 0 ; i < n ; i ++ ) curr_val += i * arr [ i ] ;
int res = curr_val ;
for ( int i = 1 ; i < n ; i ++ ) {
int next_val = curr_val - ( cum_sum - arr [ i - 1 ] ) + arr [ i - 1 ] * ( n - 1 ) ;
curr_val = next_val ;
res = max ( res , next_val ) ; } return res ; }
int main ( ) { int arr [ ] = { 8 , 3 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxSum ( arr , n ) << endl ; return 0 ; }
int countRotations ( int arr [ ] , int n ) {
int min = arr [ 0 ] , min_index ; for ( int i = 0 ; i < n ; i ++ ) { if ( min > arr [ i ] ) { min = arr [ i ] ; min_index = i ; } } return min_index ; }
int main ( ) { int arr [ ] = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countRotations ( arr , n ) ; return 0 ; }
int countRotations ( int arr [ ] , int low , int high ) {
if ( high < low ) return 0 ;
if ( high == low ) return low ;
int mid = low + ( high - low ) / 2 ;
if ( mid < high && arr [ mid + 1 ] < arr [ mid ] ) return ( mid + 1 ) ;
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) return mid ;
if ( arr [ high ] > arr [ mid ] ) return countRotations ( arr , low , mid - 1 ) ; return countRotations ( arr , mid + 1 , high ) ; }
int main ( ) { int arr [ ] = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countRotations ( arr , 0 , n - 1 ) ; return 0 ; }
void preprocess ( int arr [ ] , int n , int temp [ ] ) {
for ( int i = 0 ; i < n ; i ++ ) temp [ i ] = temp [ i + n ] = arr [ i ] ; }
void leftRotate ( int arr [ ] , int n , int k , int temp [ ] ) {
int start = k % n ;
for ( int i = start ; i < start + n ; i ++ ) cout << temp [ i ] << " ▁ " ; cout << endl ; }
int main ( ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int temp [ 2 * n ] ; preprocess ( arr , n , temp ) ; int k = 2 ; leftRotate ( arr , n , k , temp ) ; k = 3 ; leftRotate ( arr , n , k , temp ) ; k = 4 ; leftRotate ( arr , n , k , temp ) ; return 0 ; }
void leftRotate ( int arr [ ] , int n , int k ) {
for ( int i = k ; i < k + n ; i ++ ) cout << arr [ i % n ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 2 ; leftRotate ( arr , n , k ) ; cout << endl ; k = 3 ; leftRotate ( arr , n , k ) ; cout << endl ; k = 4 ; leftRotate ( arr , n , k ) ; cout << endl ; return 0 ; }
void reverseArray ( int arr [ ] , int start , int end ) { while ( start < end ) { std :: swap ( arr [ start ] , arr [ end ] ) ; start ++ ; end -- ; } }
void rightRotate ( int arr [ ] , int d , int n ) { reverseArray ( arr , 0 , n - 1 ) ; reverseArray ( arr , 0 , d - 1 ) ; reverseArray ( arr , d , n - 1 ) ; }
void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) std :: cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; rightRotate ( arr , k , n ) ; printArray ( arr , n ) ; return 0 ; }
int maxHamming ( int arr [ ] , int n ) {
int brr [ 2 * n + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ i ] = arr [ i ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ n + i ] = arr [ i ] ;
int maxHam = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { int currHam = 0 ; for ( int j = i , k = 0 ; j < ( i + n ) ; j ++ , k ++ ) if ( brr [ j ] != arr [ k ] ) currHam ++ ;
if ( currHam == n ) return n ; maxHam = max ( maxHam , currHam ) ; } return maxHam ; }
int main ( ) { int arr [ ] = { 2 , 4 , 6 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxHamming ( arr , n ) ; return 0 ; }
void leftRotate ( int arr [ ] , int n , int k ) {
int mod = k % n ;
for ( int i = 0 ; i < n ; i ++ ) cout << ( arr [ ( mod + i ) % n ] ) << " ▁ " ; cout << " STRNEWLINE " ; }
int main ( ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 2 ;
leftRotate ( arr , n , k ) ; k = 3 ;
leftRotate ( arr , n , k ) ; k = 4 ;
leftRotate ( arr , n , k ) ; return 0 ; }
int findElement ( int arr [ ] , int ranges [ ] [ 2 ] , int rotations , int index ) { for ( int i = rotations - 1 ; i >= 0 ; i -- ) {
int left = ranges [ i ] [ 0 ] ; int right = ranges [ i ] [ 1 ] ;
if ( left <= index && right >= index ) { if ( index == left ) index = right ; else index -- ; } }
return arr [ index ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ;
int rotations = 2 ;
int ranges [ rotations ] [ 2 ] = { { 0 , 2 } , { 0 , 3 } } ; int index = 1 ; cout << findElement ( arr , ranges , rotations , index ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void splitArr ( int arr [ ] , int n , int k ) { for ( int i = 0 ; i < k ; i ++ ) {
int x = arr [ 0 ] ; for ( int j = 0 ; j < n - 1 ; ++ j ) arr [ j ] = arr [ j + 1 ] ; arr [ n - 1 ] = x ; } }
int main ( ) { int arr [ ] = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int position = 2 ; splitArr ( arr , 6 , position ) ; for ( int i = 0 ; i < n ; ++ i ) printf ( " % d ▁ " , arr [ i ] ) ; return 0 ; }
void rearrangeArr ( int arr [ ] , int n ) {
int evenPos = n / 2 ;
int oddPos = n - evenPos ; int tempArr [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) tempArr [ i ] = arr [ i ] ;
sort ( tempArr , tempArr + n ) ; int j = oddPos - 1 ;
for ( int i = 0 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j -- ; } j = oddPos ;
for ( int i = 1 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j ++ ; }
for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; rearrangeArr ( arr , size ) ; return 0 ; }
void pushZerosToEnd ( int arr [ ] , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
int main ( ) { int arr [ ] = { 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; pushZerosToEnd ( arr , n ) ; cout << " Array ▁ after ▁ pushing ▁ all ▁ zeros ▁ to ▁ end ▁ of ▁ array ▁ : STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
int minSwap ( int * arr , int n , int k ) {
int count = 0 ; for ( int i = 0 ; i < n ; ++ i ) if ( arr [ i ] <= k ) ++ count ;
int bad = 0 ; for ( int i = 0 ; i < count ; ++ i ) if ( arr [ i ] > k ) ++ bad ;
int ans = bad ; for ( int i = 0 , j = count ; j < n ; ++ i , ++ j ) {
if ( arr [ i ] > k ) -- bad ;
if ( arr [ j ] > k ) ++ bad ;
ans = min ( ans , bad ) ; } return ans ; }
int main ( ) { int arr [ ] = { 2 , 1 , 5 , 6 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; cout << minSwap ( arr , n , k ) << " STRNEWLINE " ; int arr1 [ ] = { 2 , 7 , 9 , 5 , 8 , 7 , 4 } ; n = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; k = 5 ; cout << minSwap ( arr1 , n , k ) ; return 0 ; }
void reorder ( int arr [ ] , int index [ ] , int n ) { int temp [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) temp [ index [ i ] ] = arr [ i ] ;
for ( int i = 0 ; i < n ; i ++ ) { arr [ i ] = temp [ i ] ; index [ i ] = i ; } }
int main ( ) { int arr [ ] = { 50 , 40 , 70 , 60 , 90 } ; int index [ ] = { 3 , 0 , 4 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; reorder ( arr , index , n ) ; cout << " Reordered ▁ array ▁ is : ▁ STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << " Modified Index array is : " for ( int i = 0 ; i < n ; i ++ ) cout << index [ i ] << " ▁ " ; return 0 ; }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; printf ( " STRNEWLINE " ) ; }
void RearrangePosNeg ( int arr [ ] , int n ) { int key , j ; for ( int i = 1 ; i < n ; i ++ ) { key = arr [ i ] ;
if ( key > 0 ) continue ;
j = i - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { arr [ j + 1 ] = arr [ j ] ; j = j - 1 ; }
arr [ j + 1 ] = key ; } }
int main ( ) { int arr [ ] = { -12 , 11 , -13 , -5 , 6 , -7 , 5 , -3 , -6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; RearrangePosNeg ( arr , n ) ; printArray ( arr , n ) ; return 0 ; }
void rearrange ( int arr [ ] , int n ) {
int temp [ n ] ;
int small = 0 , large = n - 1 ;
int flag = true ;
for ( int i = 0 ; i < n ; i ++ ) { if ( flag ) temp [ i ] = arr [ large -- ] ; else temp [ i ] = arr [ small ++ ] ; flag = ! flag ; }
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Original ▁ Array STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; rearrange ( arr , n ) ; cout << " Modified Array " for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void rearrange ( int arr [ ] , int n ) {
int max_idx = n - 1 , min_idx = 0 ;
int max_elem = arr [ n - 1 ] + 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] += ( arr [ max_idx ] % max_elem ) * max_elem ; max_idx -- ; }
else { arr [ i ] += ( arr [ min_idx ] % max_elem ) * max_elem ; min_idx ++ ; } }
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = arr [ i ] / max_elem ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Original ▁ Arrayn " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; rearrange ( arr , n ) ; cout << " Modified Array " for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void rearrange ( int arr [ ] , int n ) { int j = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < 0 ) { if ( i != j ) swap ( arr [ i ] , arr [ j ] ) ; j ++ ; } } }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; }
int main ( ) { int arr [ ] = { -1 , 2 , -3 , 4 , 5 , 6 , -7 , 8 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; rearrange ( arr , n ) ; printArray ( arr , n ) ; return 0 ; }
void segregateElements ( int arr [ ] , int n ) {
int temp [ n ] ;
int j = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] >= 0 ) temp [ j ++ ] = arr [ i ] ;
if ( j == n j == 0 ) return ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < 0 ) temp [ j ++ ] = arr [ i ] ;
memcpy ( arr , temp , sizeof ( temp ) ) ; }
int main ( ) { int arr [ ] = { 1 , -1 , -3 , -2 , 7 , 5 , 11 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; segregateElements ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void rearrange ( int * arr , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( i % 2 == 0 && arr [ i ] > arr [ i + 1 ] ) swap ( arr [ i ] , arr [ i + 1 ] ) ; if ( i % 2 != 0 && arr [ i ] < arr [ i + 1 ] ) swap ( arr [ i ] , arr [ i + 1 ] ) ; } }
void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << endl ; }
int main ( ) { int arr [ ] = { 6 , 4 , 2 , 1 , 8 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Before ▁ rearranging : ▁ STRNEWLINE " ; printArray ( arr , n ) ; rearrange ( arr , n ) ; cout << " After ▁ rearranging : ▁ STRNEWLINE " ; printArray ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void rearrange ( int a [ ] , int size ) { int positive = 0 , negative = 1 ; while ( true ) {
while ( positive < size && a [ positive ] >= 0 ) positive += 2 ;
while ( negative < size && a [ negative ] <= 0 ) negative += 2 ;
if ( positive < size && negative < size ) swap ( a [ positive ] , a [ negative ] ) ;
else break ; } }
int main ( ) { int arr [ ] = { 1 , -3 , 5 , 6 , -3 , 6 , 7 , -4 , 9 , 10 } ; int n = ( sizeof ( arr ) / sizeof ( arr [ 0 ] ) ) ; rearrange ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void arrayEvenAndOdd ( int arr [ ] , int n ) { int i = -1 , j = 0 ; int t ; while ( j != n ) { if ( arr [ j ] % 2 == 0 ) { i ++ ;
swap ( arr [ i ] , arr [ j ] ) ; } j ++ ; }
for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 } ; int n = sizeof ( arr ) / sizeof ( int ) ; arrayEvenAndOdd ( arr , n ) ; return 0 ; }
int largest ( int arr [ ] , int n ) { int i ;
int max = arr [ 0 ] ;
for ( i = 1 ; i < n ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
int main ( ) { int arr [ ] = { 10 , 324 , 45 , 90 , 9808 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Largest ▁ in ▁ given ▁ array ▁ is ▁ " << largest ( arr , n ) ; return 0 ; }
int largest ( int arr [ ] , int n ) { return * max_element ( arr , arr + n ) ; }
int main ( ) { int arr [ ] = { 10 , 324 , 45 , 90 , 9808 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << largest ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void findElements ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) if ( arr [ j ] > arr [ i ] ) count ++ ; if ( count >= 2 ) cout << arr [ i ] << " ▁ " ; } }
int main ( ) { int arr [ ] = { 2 , -6 , 3 , 5 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findElements ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void findElements ( int arr [ ] , int n ) { sort ( arr , arr + n ) ; for ( int i = 0 ; i < n - 2 ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 2 , -6 , 3 , 5 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findElements ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void findElements ( int arr [ ] , int n ) { int first = INT_MIN , second = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) second = arr [ i ] ; } for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < second ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 2 , -6 , 3 , 5 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findElements ( arr , n ) ; return 0 ; }
double findMean ( int a [ ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += a [ i ] ; return ( double ) sum / ( double ) n ; }
double findMedian ( int a [ ] , int n ) {
sort ( a , a + n ) ;
if ( n % 2 != 0 ) return ( double ) a [ n / 2 ] ; return ( double ) ( a [ ( n - 1 ) / 2 ] + a [ n / 2 ] ) / 2.0 ; }
int main ( ) { int a [ ] = { 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
cout << " Mean ▁ = ▁ " << findMean ( a , n ) << endl ; cout << " Median ▁ = ▁ " << findMedian ( a , n ) << endl ; return 0 ; }
void printSmall ( int arr [ ] , int n , int k ) {
for ( int i = k ; i < n ; ++ i ) {
int max_var = arr [ k - 1 ] ; int pos = k - 1 ; for ( int j = k - 2 ; j >= 0 ; j -- ) { if ( arr [ j ] > max_var ) { max_var = arr [ j ] ; pos = j ; } }
if ( max_var > arr [ i ] ) { int j = pos ; while ( j < k - 1 ) { arr [ j ] = arr [ j + 1 ] ; j ++ ; }
arr [ k - 1 ] = arr [ i ] ; } }
for ( int i = 0 ; i < k ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 5 ; printSmall ( arr , n , k ) ; return 0 ; }
int sumNodes ( int l ) {
int leafNodeCount = pow ( 2 , l - 1 ) ; int sumLastLevel = 0 ;
sumLastLevel = ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ;
int sum = sumLastLevel * l ; return sum ; }
int main ( ) { int l = 3 ; cout << sumNodes ( l ) ; return 0 ; }
void add ( int arr [ ] , int N , int lo , int hi , int val ) { arr [ lo ] += val ; if ( hi != N - 1 ) arr [ hi + 1 ] -= val ; }
void updateArray ( int arr [ ] , int N ) {
for ( int i = 1 ; i < N ; i ++ ) arr [ i ] += arr [ i - 1 ] ; }
void printArr ( int arr [ ] , int N ) { updateArray ( arr , N ) ; for ( int i = 0 ; i < N ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << endl ; }
int main ( ) { int N = 6 ; int arr [ N ] = { 0 } ;
add ( arr , N , 0 , 2 , 100 ) ; add ( arr , N , 1 , 5 , 100 ) ; add ( arr , N , 2 , 3 , 100 ) ; printArr ( arr , N ) ; return 0 ; }
void FillPrefixSuffix ( int prefix [ ] , int arr [ ] , int suffix [ ] , int n ) {
prefix [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) prefix [ i ] = __gcd ( prefix [ i - 1 ] , arr [ i ] ) ;
suffix [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) suffix [ i ] = __gcd ( suffix [ i + 1 ] , arr [ i ] ) ; }
int GCDoutsideRange ( int l , int r , int prefix [ ] , int suffix [ ] , int n ) {
if ( l == 0 ) return suffix [ r + 1 ] ;
if ( r == n - 1 ) return prefix [ l - 1 ] ; return __gcd ( prefix [ l - 1 ] , suffix [ r + 1 ] ) ; }
int main ( ) { int arr [ ] = { 2 , 6 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int prefix [ n ] , suffix [ n ] ; FillPrefixSuffix ( prefix , arr , suffix , n ) ; int l = 0 , r = 0 ; cout << GCDoutsideRange ( l , r , prefix , suffix , n ) << endl ; l = 1 ; r = 1 ; cout << GCDoutsideRange ( l , r , prefix , suffix , n ) << endl ; l = 1 ; r = 2 ; cout << GCDoutsideRange ( l , r , prefix , suffix , n ) << endl ; return 0 ; }
int countInRange ( int arr [ ] , int n , int x , int y ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] >= x && arr [ i ] <= y ) count ++ ; } return count ; }
int main ( ) { int arr [ ] = { 1 , 3 , 4 , 9 , 10 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
int i = 1 , j = 4 ; cout << countInRange ( arr , n , i , j ) << endl ; i = 9 , j = 12 ; cout << countInRange ( arr , n , i , j ) << endl ; return 0 ; }
int lowerIndex ( int arr [ ] , int n , int x ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] >= x ) h = mid - 1 ; else l = mid + 1 ; } return l ; }
int upperIndex ( int arr [ ] , int n , int y ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] <= y ) l = mid + 1 ; else h = mid - 1 ; } return h ; }
int countInRange ( int arr [ ] , int n , int x , int y ) {
int count = 0 ; count = upperIndex ( arr , n , y ) - lowerIndex ( arr , n , x ) + 1 ; return count ; }
int main ( ) { int arr [ ] = { 1 , 4 , 4 , 9 , 10 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
sort ( arr , arr + n ) ;
int i = 1 , j = 4 ; cout << countInRange ( arr , n , i , j ) << endl ; i = 9 , j = 12 ; cout << countInRange ( arr , n , i , j ) << endl ; return 0 ; }
void precompute ( int arr [ ] , int n , int pre [ ] ) { memset ( pre , 0 , n * sizeof ( int ) ) ; pre [ n - 1 ] = arr [ n - 1 ] * pow ( 2 , 0 ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) pre [ i ] = pre [ i + 1 ] + arr [ i ] * ( 1 << ( n - 1 - i ) ) ; }
int decimalOfSubarr ( int arr [ ] , int l , int r , int n , int pre [ ] ) {
if ( r != n - 1 ) return ( pre [ l ] - pre [ r + 1 ] ) / ( 1 << ( n - 1 - r ) ) ; return pre [ l ] / ( 1 << ( n - 1 - r ) ) ; }
int main ( ) { int arr [ ] = { 1 , 0 , 1 , 0 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int pre [ n ] ; precompute ( arr , n , pre ) ; cout << decimalOfSubarr ( arr , 2 , 4 , n , pre ) << endl ; cout << decimalOfSubarr ( arr , 4 , 5 , n , pre ) << endl ; return 0 ; }
int answerQuery ( int a [ ] , int n , int l , int r ) {
int count = 0 ;
l = l - 1 ;
for ( int i = l ; i < r ; i ++ ) { int element = a [ i ] ; int divisors = 0 ;
for ( int j = l ; j < r ; j ++ ) {
if ( a [ j ] % a [ i ] == 0 ) divisors ++ ; else break ; }
if ( divisors == ( r - l ) ) count ++ ; }
return count ; }
int main ( ) { int a [ ] = { 1 , 2 , 3 , 5 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int l = 1 , r = 4 ; cout << answerQuery ( a , n , l , r ) << endl ; l = 2 , r = 4 ; cout << answerQuery ( a , n , l , r ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  2147483647 NEW_LINE int one [ 100001 ] [ 32 ] ;
void make_prefix ( int A [ ] , int n ) { for ( int j = 0 ; j < 32 ; j ++ ) one [ 0 ] [ j ] = 0 ;
for ( int i = 1 ; i <= n ; i ++ ) { int a = A [ i - 1 ] ; for ( int j = 0 ; j < 32 ; j ++ ) { int x = pow ( 2 , j ) ;
if ( a & x ) one [ i ] [ j ] = 1 + one [ i - 1 ] [ j ] ; else one [ i ] [ j ] = one [ i - 1 ] [ j ] ; } } }
int Solve ( int L , int R ) { int l = L , r = R ; int tot_bits = r - l + 1 ;
int X = MAX ;
for ( int i = 0 ; i < 31 ; i ++ ) {
int x = one [ r ] [ i ] - one [ l - 1 ] [ i ] ;
if ( x >= tot_bits - x ) { int ith_bit = pow ( 2 , i ) ;
X = X ^ ith_bit ; } } return X ; }
int main ( ) { int n = 5 , q = 3 ; int A [ ] = { 210 , 11 , 48 , 22 , 133 } ; int L [ ] = { 1 , 4 , 2 } , R [ ] = { 3 , 14 , 4 } ; make_prefix ( A , n ) ; for ( int j = 0 ; j < q ; j ++ ) cout << Solve ( L [ j ] , R [ j ] ) << endl ; return 0 ; }
int answer_query ( int a [ ] , int n , int l , int r ) {
int count = 0 ; for ( int i = l ; i < r ; i ++ ) if ( a [ i ] == a [ i + 1 ] ) count += 1 ; return count ; }
int main ( ) { int a [ ] = { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
int L , R ; L = 1 ; R = 8 ; cout << answer_query ( a , n , L , R ) << endl ;
L = 0 ; R = 4 ; cout << answer_query ( a , n , L , R ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int N = 1000 ;
int prefixans [ N ] ;
int countIndex ( int a [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] == a [ i + 1 ] ) prefixans [ i ] = 1 ; if ( i != 0 ) prefixans [ i ] += prefixans [ i - 1 ] ; } }
int answer_query ( int l , int r ) { if ( l == 0 ) return prefixans [ r - 1 ] ; else return prefixans [ r - 1 ] - prefixans [ l - 1 ] ; }
int main ( ) { int a [ ] = { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
countIndex ( a , n ) ; int L , R ;
L = 1 ; R = 8 ; cout << answer_query ( L , R ) << endl ;
L = 0 ; R = 4 ; cout << answer_query ( L , R ) << endl ; return 0 ; }
int repeated_digit ( int n ) { unordered_set < int > s ;
while ( n != 0 ) { int d = n % 10 ;
if ( s . find ( d ) != s . end ( ) ) {
return 0 ; } s . insert ( d ) ; n = n / 10 ; }
return 1 ; }
int calculate ( int L , int R ) { int answer = 0 ;
for ( int i = L ; i < R + 1 ; ++ i ) {
answer = answer + repeated_digit ( i ) ; } return answer ; }
int main ( ) { int L = 1 , R = 100 ;
cout << calculate ( L , R ) ; return 0 ; }
#include <iostream> NEW_LINE #include <climits> NEW_LINE using namespace std ; int maxSubArraySum ( int a [ ] , int size ) { int max_so_far = INT_MIN , max_ending_here = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here = max_ending_here + a [ i ] ; if ( max_so_far < max_ending_here ) max_so_far = max_ending_here ; if ( max_ending_here < 0 ) max_ending_here = 0 ; } return max_so_far ; }
int main ( ) { int a [ ] = { -2 , -3 , 4 , -1 , -2 , 1 , 5 , -3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int max_sum = maxSubArraySum ( a , n ) ; cout << " Maximum ▁ contiguous ▁ sum ▁ is ▁ " << max_sum ; return 0 ; }
#include <climits> NEW_LINE int maxSubarraySum ( int arr [ ] , int size ) { int max_ending_here = 0 , max_so_far = INT_MIN ; for ( int i = 0 ; i < size ; i ++ ) { if ( arr [ i ] <= max_ending_here + arr [ i ] ) { max_ending_here += arr [ i ] ; }
else { max_ending_here = arr [ i ] ; } if ( max_ending_here > max_so_far ) max_so_far = max_ending_here ; } return max_so_far ; }
#include <iostream> NEW_LINE using namespace std ; int maxSubArraySum ( int a [ ] , int size ) { int max_so_far = a [ 0 ] ; int curr_max = a [ 0 ] ; for ( int i = 1 ; i < size ; i ++ ) { curr_max = max ( a [ i ] , curr_max + a [ i ] ) ; max_so_far = max ( max_so_far , curr_max ) ; } return max_so_far ; }
int main ( ) { int a [ ] = { -2 , -3 , 4 , -1 , -2 , 1 , 5 , -3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int max_sum = maxSubArraySum ( a , n ) ; cout << " Maximum ▁ contiguous ▁ sum ▁ is ▁ " << max_sum ; return 0 ; }
#include <iostream> NEW_LINE #include <climits> NEW_LINE using namespace std ; int maxSubArraySum ( int a [ ] , int size ) { int max_so_far = INT_MIN , max_ending_here = 0 , start = 0 , end = 0 , s = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here += a [ i ] ; if ( max_so_far < max_ending_here ) { max_so_far = max_ending_here ; start = s ; end = i ; } if ( max_ending_here < 0 ) { max_ending_here = 0 ; s = i + 1 ; } } cout << " Maximum ▁ contiguous ▁ sum ▁ is ▁ " << max_so_far << endl ; cout << " Starting ▁ index ▁ " << start << endl << " Ending ▁ index ▁ " << end << endl ; }
int main ( ) { int a [ ] = { -2 , -3 , 4 , -1 , -2 , 1 , 5 , -3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int max_sum = maxSubArraySum ( a , n ) ; return 0 ; }
void findMinAvgSubarray ( int arr [ ] , int n , int k ) {
if ( n < k ) return ;
int res_index = 0 ;
int curr_sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) curr_sum += arr [ i ] ;
int min_sum = curr_sum ;
for ( int i = k ; i < n ; i ++ ) {
curr_sum += arr [ i ] - arr [ i - k ] ;
if ( curr_sum < min_sum ) { min_sum = curr_sum ; res_index = ( i - k + 1 ) ; } } cout << " Subarray ▁ between ▁ [ " << res_index << " , ▁ " << res_index + k - 1 << " ] ▁ has ▁ minimum ▁ average " ; }
int main ( ) { int arr [ ] = { 3 , 7 , 90 , 20 , 10 , 50 , 40 } ;
int k = 3 ; int n = sizeof arr / sizeof arr [ 0 ] ; findMinAvgSubarray ( arr , n , k ) ; return 0 ; }
int minJumps ( int arr [ ] , int n ) {
int * jumps = new int [ n ] ; int min ;
jumps [ n - 1 ] = 0 ;
for ( int i = n - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] == 0 ) jumps [ i ] = INT_MAX ;
else if ( arr [ i ] >= n - i - 1 ) jumps [ i ] = 1 ;
else {
min = INT_MAX ;
for ( int j = i + 1 ; j < n && j <= arr [ i ] + i ; j ++ ) { if ( min > jumps [ j ] ) min = jumps [ j ] ; }
if ( min != INT_MAX ) jumps [ i ] = min + 1 ; else
jumps [ i ] = min ; } } return jumps [ 0 ] ; }
int main ( ) { int arr [ ] = { 1 , 3 , 6 , 1 , 0 , 9 } ; int size = sizeof ( arr ) / sizeof ( int ) ; cout << " Minimum ▁ number ▁ of ▁ jumps ▁ to ▁ reach " << " ▁ end ▁ is ▁ " << minJumps ( arr , size ) ; return 0 ; }
int smallestSubWithSum ( int arr [ ] , int n , int x ) {
int curr_sum = 0 , min_len = n + 1 ;
int start = 0 , end = 0 ; while ( end < n ) {
while ( curr_sum <= x && end < n ) curr_sum += arr [ end ++ ] ;
while ( curr_sum > x && start < n ) {
if ( end - start < min_len ) min_len = end - start ;
curr_sum -= arr [ start ++ ] ; } } return min_len ; }
int main ( ) { int arr1 [ ] = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; ( res1 == n1 + 1 ) ? cout << " Not ▁ possible STRNEWLINE " : cout << res1 << endl ; int arr2 [ ] = { 1 , 10 , 5 , 2 , 7 } ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; ( res2 == n2 + 1 ) ? cout << " Not ▁ possible STRNEWLINE " : cout << res2 << endl ; int arr3 [ ] = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = sizeof ( arr3 ) / sizeof ( arr3 [ 0 ] ) ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; ( res3 == n3 + 1 ) ? cout << " Not ▁ possible STRNEWLINE " : cout << res3 << endl ; return 0 ; }
int findMaxAverage ( int arr [ ] , int n , int k ) {
if ( k > n ) return -1 ;
int * csum = new int [ n ] ; csum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) csum [ i ] = csum [ i - 1 ] + arr [ i ] ;
int max_sum = csum [ k - 1 ] , max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { int curr_sum = csum [ i ] - csum [ i - k ] ; if ( curr_sum > max_sum ) { max_sum = curr_sum ; max_end = i ; } }
return max_end - k + 1 ; }
int main ( ) { int arr [ ] = { 1 , 12 , -5 , -6 , 50 , 3 } ; int k = 4 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ " " length ▁ " << k << " ▁ begins ▁ at ▁ index ▁ " << findMaxAverage ( arr , n , k ) ; return 0 ; }
int findMaxAverage ( int arr [ ] , int n , int k ) {
if ( k > n ) return -1 ;
int sum = arr [ 0 ] ; for ( int i = 1 ; i < k ; i ++ ) sum += arr [ i ] ; int max_sum = sum , max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { int sum = sum + arr [ i ] - arr [ i - k ] ; if ( sum > max_sum ) { max_sum = sum ; max_end = i ; } }
return max_end - k + 1 ; }
int main ( ) { int arr [ ] = { 1 , 12 , -5 , -6 , 50 , 3 } ; int k = 4 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ " " length ▁ " << k << " ▁ begins ▁ at ▁ index ▁ " << findMaxAverage ( arr , n , k ) ; return 0 ; }
int countMinOperations ( unsigned int target [ ] , int n ) {
int result = 0 ;
while ( 1 ) {
int zero_count = 0 ;
int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( target [ i ] & 1 ) break ;
else if ( target [ i ] == 0 ) zero_count ++ ; }
if ( zero_count == n ) return result ;
if ( i == n ) {
for ( int j = 0 ; j < n ; j ++ ) target [ j ] = target [ j ] / 2 ; result ++ ; }
for ( int j = i ; j < n ; j ++ ) { if ( target [ j ] & 1 ) { target [ j ] -- ; result ++ ; } } } }
int main ( ) { unsigned int arr [ ] = { 16 , 16 , 16 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ number ▁ of ▁ steps ▁ required ▁ to ▁ " " get ▁ the ▁ given ▁ target ▁ array ▁ is ▁ " << countMinOperations ( arr , n ) ; return 0 ; }
int findMinOps ( int arr [ ] , int n ) {
int ans = 0 ;
for ( int i = 0 , j = n - 1 ; i <= j ; ) {
if ( arr [ i ] == arr [ j ] ) { i ++ ; j -- ; }
else if ( arr [ i ] > arr [ j ] ) {
j -- ; arr [ j ] += arr [ j + 1 ] ; ans ++ ; }
else { i ++ ; arr [ i ] += arr [ i - 1 ] ; ans ++ ; } } return ans ; }
int main ( ) { int arr [ ] = { 1 , 4 , 5 , 9 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ minimum ▁ operations ▁ is ▁ " << findMinOps ( arr , n ) << endl ; return 0 ; }
int findSmallest ( int arr [ ] , int n ) {
int res = 1 ;
for ( int i = 0 ; i < n && arr [ i ] <= res ; i ++ ) res = res + arr [ i ] ; return res ; }
int main ( ) { int arr1 [ ] = { 1 , 3 , 4 , 5 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << findSmallest ( arr1 , n1 ) << endl ; int arr2 [ ] = { 1 , 2 , 6 , 10 , 11 , 15 } ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; cout << findSmallest ( arr2 , n2 ) << endl ; int arr3 [ ] = { 1 , 1 , 1 , 1 } ; int n3 = sizeof ( arr3 ) / sizeof ( arr3 [ 0 ] ) ; cout << findSmallest ( arr3 , n3 ) << endl ; int arr4 [ ] = { 1 , 1 , 3 , 4 } ; int n4 = sizeof ( arr4 ) / sizeof ( arr4 [ 0 ] ) ; cout << findSmallest ( arr4 , n4 ) << endl ; return 0 ; }
int findMinDiff ( int arr [ ] , int n ) {
int diff = INT_MAX ;
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( abs ( arr [ i ] - arr [ j ] ) < diff ) diff = abs ( arr [ i ] - arr [ j ] ) ;
return diff ; }
int main ( ) { int arr [ ] = { 1 , 5 , 3 , 19 , 18 , 25 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ difference ▁ is ▁ " << findMinDiff ( arr , n ) ; return 0 ; }
int findMinDiff ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int diff = INT_MAX ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i + 1 ] - arr [ i ] < diff ) diff = arr [ i + 1 ] - arr [ i ] ;
return diff ; }
int main ( ) { int arr [ ] = { 1 , 5 , 3 , 19 , 18 , 25 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ difference ▁ is ▁ " << findMinDiff ( arr , n ) ; return 0 ; }
int main ( ) { int a = 2 , b = 10 ; int size = abs ( b - a ) + 1 ; int * array = new int [ size ] ;
for ( int i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) array [ i - a ] = 1 ; cout << " MULTIPLES ▁ of ▁ 2 ▁ and ▁ 5 : STRNEWLINE " ; for ( int i = a ; i <= b ; i ++ ) if ( array [ i - a ] == 1 ) cout << i << " ▁ " ; return 0 ; }
int longestCommonSum ( bool arr1 [ ] , bool arr2 [ ] , int n ) {
int maxLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int sum1 = 0 , sum2 = 0 ;
for ( int j = i ; j < n ; j ++ ) {
sum1 += arr1 [ j ] ; sum2 += arr2 [ j ] ;
if ( sum1 == sum2 ) { int len = j - i + 1 ; if ( len > maxLen ) maxLen = len ; } } } return maxLen ; }
int main ( ) { bool arr1 [ ] = { 0 , 1 , 0 , 1 , 1 , 1 , 1 } ; bool arr2 [ ] = { 1 , 1 , 1 , 1 , 1 , 0 , 1 } ; int n = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << " Length ▁ of ▁ the ▁ longest ▁ common ▁ span ▁ with ▁ same ▁ " " sum ▁ is ▁ " << longestCommonSum ( arr1 , arr2 , n ) ; return 0 ; }
bool sortedAfterSwap ( int A [ ] , bool B [ ] , int n ) { int i , j ;
for ( i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] ) { j = i ; while ( B [ j ] ) j ++ ;
sort ( A + i , A + 1 + j ) ; i = j ; } }
for ( i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) return false ; } return true ; }
int main ( ) { int A [ ] = { 1 , 2 , 5 , 3 , 4 , 6 } ; bool B [ ] = { 0 , 1 , 1 , 1 , 0 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; if ( sortedAfterSwap ( A , B , n ) ) cout << " A ▁ can ▁ be ▁ sorted STRNEWLINE " ; else cout << " A ▁ can ▁ not ▁ be ▁ sorted STRNEWLINE " ; return 0 ; }
bool sortedAfterSwap ( int A [ ] , bool B [ ] , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] ) { if ( A [ i ] != i + 1 ) swap ( A [ i ] , A [ i + 1 ] ) ; } }
for ( int i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) return false ; } return true ; }
int main ( ) { int A [ ] = { 1 , 2 , 5 , 3 , 4 , 6 } ; bool B [ ] = { 0 , 1 , 1 , 1 , 0 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; if ( sortedAfterSwap ( A , B , n ) ) cout << " A ▁ can ▁ be ▁ sorted STRNEWLINE " ; else cout << " A ▁ can ▁ not ▁ be ▁ sorted STRNEWLINE " ; return 0 ; }
void segregate0and1 ( int arr [ ] , int n ) { int type0 = 0 ; int type1 = n - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { swap ( arr [ type0 ] , arr [ type1 ] ) ; type1 -- ; } else { type0 ++ ; } } }
int main ( ) { int arr [ ] = { 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; segregate0and1 ( arr , n ) ; for ( int a : arr ) cout << a << " ▁ " ; }
bool increasing ( int a [ ] , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( a [ i ] >= a [ i + 1 ] ) return false ; return true ; }
bool decreasing ( int a [ ] , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( a [ i ] < a [ i + 1 ] ) return false ; return true ; } int shortestUnsorted ( int a [ ] , int n ) {
if ( increasing ( a , n ) == true || decreasing ( a , n ) == true ) return 0 ; else return 3 ; }
int main ( ) { int ar [ ] = { 7 , 9 , 10 , 8 , 11 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; cout << shortestUnsorted ( ar , n ) ; return 0 ; }
void printUnion ( int arr1 [ ] , int arr2 [ ] , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) cout << arr1 [ i ++ ] << " ▁ " ; else if ( arr2 [ j ] < arr1 [ i ] ) cout << arr2 [ j ++ ] << " ▁ " ; else { cout << arr2 [ j ++ ] << " ▁ " ; i ++ ; } }
while ( i < m ) cout << arr1 [ i ++ ] << " ▁ " ; while ( j < n ) cout << arr2 [ j ++ ] << " ▁ " ; }
int main ( ) { int arr1 [ ] = { 1 , 2 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 5 , 7 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; printUnion ( arr1 , arr2 , m , n ) ; return 0 ; }
void printIntersection ( int arr1 [ ] , int arr2 [ ] , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) i ++ ; else if ( arr2 [ j ] < arr1 [ i ] ) j ++ ; else { cout << arr2 [ j ] << " ▁ " ; i ++ ; j ++ ; } } }
int main ( ) { int arr1 [ ] = { 1 , 2 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 5 , 7 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ;
printIntersection ( arr1 , arr2 , m , n ) ; return 0 ; }
void printUnion ( int arr1 [ ] , int arr2 [ ] , int m , int n ) {
if ( m > n ) { int * tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
sort ( arr1 , arr1 + m ) ; for ( int i = 0 ; i < m ; i ++ ) cout << arr1 [ i ] << " ▁ " ;
for ( int i = 0 ; i < n ; i ++ ) if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) == -1 ) cout << arr2 [ i ] << " ▁ " ; }
void printIntersection ( int arr1 [ ] , int arr2 [ ] , int m , int n ) {
if ( m > n ) { int * tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
sort ( arr1 , arr1 + m ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) != -1 ) cout << arr2 [ i ] << " ▁ " ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return -1 ; }
int main ( ) { int arr1 [ ] = { 7 , 1 , 5 , 2 , 3 , 6 } ; int arr2 [ ] = { 3 , 8 , 6 , 20 , 7 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ;
cout << " Union ▁ of ▁ two ▁ arrays ▁ is ▁ n " ; printUnion ( arr1 , arr2 , m , n ) ; cout << " nIntersection ▁ of ▁ two ▁ arrays ▁ is ▁ n " ; printIntersection ( arr1 , arr2 , m , n ) ; return 0 ; }
void intersection ( int a [ ] , int b [ ] , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) { if ( a [ i ] > b [ j ] ) { j ++ ; } else if ( b [ j ] > a [ i ] ) { i ++ ; } else {
cout << a [ i ] << " ▁ " ; i ++ ; j ++ ; } } }
int main ( ) { int a [ ] = { 1 , 3 , 2 , 3 , 3 , 4 , 5 , 5 , 6 } ; int b [ ] = { 3 , 3 , 5 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int m = sizeof ( b ) / sizeof ( b [ 0 ] ) ;
sort ( a , a + n ) ; sort ( b , b + m ) ;
intersection ( a , b , n , m ) ; }
#include <iostream> NEW_LINE using namespace std ; int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] - arr [ j ] == k arr [ j ] - arr [ i ] == k ) count ++ ; } return count ; }
int main ( ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; cout << " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " << countPairsWithDiffK ( arr , n , k ) ; return 0 ; }
int binarySearch ( int arr [ ] , int low , int high , int x ) { if ( high >= low ) { int mid = low + ( high - low ) / 2 ; if ( x == arr [ mid ] ) return mid ; if ( x > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return -1 ; }
int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 , i ;
sort ( arr , arr + n ) ;
for ( i = 0 ; i < n - 1 ; i ++ ) if ( binarySearch ( arr , i + 1 , n - 1 , arr [ i ] + k ) != -1 ) count ++ ; return count ; }
int main ( ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; cout << " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " << countPairsWithDiffK ( arr , n , k ) ; return 0 ; }
int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 ;
sort ( arr , arr + n ) ; int l = 0 ; int r = 0 ; while ( r < n ) { if ( arr [ r ] - arr [ l ] == k ) { count ++ ; l ++ ; r ++ ; } else if ( arr [ r ] - arr [ l ] > k ) l ++ ;
else r ++ ; } return count ; }
int main ( ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; cout << " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " << countPairsWithDiffK ( arr , n , k ) ; return 0 ; }
void constructArr ( int arr [ ] , int pair [ ] , int n ) { arr [ 0 ] = ( pair [ 0 ] + pair [ 1 ] - pair [ n - 1 ] ) / 2 ; for ( int i = 1 ; i < n ; i ++ ) arr [ i ] = pair [ i - 1 ] - arr [ 0 ] ; }
int main ( ) { int pair [ ] = { 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 } ; int n = 5 ; int arr [ n ] ; constructArr ( arr , pair , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void merge ( int ar1 [ ] , int ar2 [ ] , int m , int n ) {
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int j , last = ar1 [ m - 1 ] ; for ( j = m - 2 ; j >= 0 && ar1 [ j ] > ar2 [ i ] ; j -- ) ar1 [ j + 1 ] = ar1 [ j ] ;
if ( j != m - 2 last > ar2 [ i ] ) { ar1 [ j + 1 ] = ar2 [ i ] ; ar2 [ i ] = last ; } } }
int main ( ) { int ar1 [ ] = { 1 , 5 , 9 , 10 , 15 , 20 } ; int ar2 [ ] = { 2 , 3 , 8 , 13 } ; int m = sizeof ( ar1 ) / sizeof ( ar1 [ 0 ] ) ; int n = sizeof ( ar2 ) / sizeof ( ar2 [ 0 ] ) ; merge ( ar1 , ar2 , m , n ) ; cout << " After ▁ Merging ▁ nFirst ▁ Array : ▁ " ; for ( int i = 0 ; i < m ; i ++ ) cout << ar1 [ i ] << " ▁ " ; cout << " nSecond ▁ Array : ▁ " ; for ( int i = 0 ; i < n ; i ++ ) cout << ar2 [ i ] << " ▁ " ; return 0 ; }
int minMaxProduct ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) {
sort ( arr1 , arr1 + n1 ) ; sort ( arr2 , arr2 + n2 ) ;
return arr1 [ n1 - 1 ] * arr2 [ 0 ] ; }
int main ( ) { int arr1 [ ] = { 10 , 2 , 3 , 6 , 4 , 1 } ; int arr2 [ ] = { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n2 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << minMaxProduct ( arr1 , arr2 , n1 , n2 ) ; return 0 ; }
int minMaxProduct ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) {
int max = arr1 [ 0 ] ;
int min = arr2 [ 0 ] ; int i ; for ( i = 1 ; i < n1 && i < n2 ; ++ i ) {
if ( arr1 [ i ] > max ) max = arr1 [ i ] ;
if ( arr2 [ i ] < min ) min = arr2 [ i ] ; }
while ( i < n1 ) { if ( arr1 [ i ] > max ) max = arr1 [ i ] ; i ++ ; } while ( i < n2 ) { if ( arr2 [ i ] < min ) min = arr2 [ i ] ; i ++ ; } return max * min ; }
int main ( ) { int arr1 [ ] = { 10 , 2 , 3 , 6 , 4 , 1 } ; int arr2 [ ] = { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n2 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << minMaxProduct ( arr1 , arr2 , n1 , n2 ) << endl ; return 0 ; }
int insertSorted ( int arr [ ] , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; arr [ n ] = key ; return ( n + 1 ) ; }
int main ( ) { int arr [ 20 ] = { 12 , 16 , 20 , 40 , 50 , 70 } ; int capacity = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int n = 6 ; int i , key = 26 ; cout << " Before Insertion : " for ( i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ;
n = insertSorted ( arr , n , key , capacity ) ; cout << " After Insertion : " for ( i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
int findElement ( int arr [ ] , int n , int key ) { int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
int deleteElement ( int arr [ ] , int n , int key ) {
int pos = findElement ( arr , n , key ) ; if ( pos == - 1 ) { cout << " Element ▁ not ▁ found " ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
int main ( ) { int i ; int arr [ ] = { 10 , 50 , 30 , 40 , 20 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int key = 30 ; cout << " Array ▁ before ▁ deletion STRNEWLINE " ; for ( i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; n = deleteElement ( arr , n , key ) ; cout << " Array after deletion " ; for ( i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void findCommon ( int ar1 [ ] , int ar2 [ ] , int ar3 [ ] , int n1 , int n2 , int n3 ) {
int i = 0 , j = 0 , k = 0 ;
while ( i < n1 && j < n2 && k < n3 ) {
if ( ar1 [ i ] == ar2 [ j ] && ar2 [ j ] == ar3 [ k ] ) { cout << ar1 [ i ] << " ▁ " ; i ++ ; j ++ ; k ++ ; }
else if ( ar1 [ i ] < ar2 [ j ] ) i ++ ;
else if ( ar2 [ j ] < ar3 [ k ] ) j ++ ;
else k ++ ; } }
int main ( ) { int ar1 [ ] = { 1 , 5 , 10 , 20 , 40 , 80 } ; int ar2 [ ] = { 6 , 7 , 20 , 80 , 100 } ; int ar3 [ ] = { 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 } ; int n1 = sizeof ( ar1 ) / sizeof ( ar1 [ 0 ] ) ; int n2 = sizeof ( ar2 ) / sizeof ( ar2 [ 0 ] ) ; int n3 = sizeof ( ar3 ) / sizeof ( ar3 [ 0 ] ) ; cout << " Common ▁ Elements ▁ are ▁ " ; findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) ; return 0 ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ; if ( arr [ mid ] == x ) return mid ; if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ; return binarySearch ( arr , mid + 1 , r , x ) ; } return -1 ; }
int findPos ( int arr [ ] , int key ) { int l = 0 , h = 1 ; int val = arr [ 0 ] ;
while ( val < key ) {
l = h ;
h = 2 * h ;
val = arr [ h ] ; }
return binarySearch ( arr , l , h , key ) ; }
int main ( ) { int arr [ ] = { 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 } ; int ans = findPos ( arr , 10 ) ; if ( ans == -1 ) cout << " Element ▁ not ▁ found " ; else cout << " Element ▁ found ▁ at ▁ index ▁ " << ans ; return 0 ; }
int findSingle ( int ar [ ] , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
int main ( ) { int ar [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; cout << " Element ▁ occurring ▁ once ▁ is ▁ " << findSingle ( ar , n ) ; return 0 ; }
bool isPresent ( int B [ ] , int m , int x ) { for ( int i = 0 ; i < m ; i ++ ) if ( B [ i ] == x ) return true ; return false ; }
int findMaxSubarraySumUtil ( int A [ ] , int B [ ] , int n , int m ) {
int max_so_far = INT_MIN , curr_max = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( isPresent ( B , m , A [ i ] ) ) { curr_max = 0 ; continue ; }
curr_max = max ( A [ i ] , curr_max + A [ i ] ) ; max_so_far = max ( max_so_far , curr_max ) ; } return max_so_far ; }
void findMaxSubarraySum ( int A [ ] , int B [ ] , int n , int m ) { int maxSubarraySum = findMaxSubarraySumUtil ( A , B , n , m ) ;
if ( maxSubarraySum == INT_MIN ) { cout << " Maximum ▁ Subarray ▁ Sum ▁ cant ▁ be ▁ found " << endl ; } else { cout << " The ▁ Maximum ▁ Subarray ▁ Sum ▁ = ▁ " << maxSubarraySum << endl ; } }
int main ( ) { int A [ ] = { 3 , 4 , 5 , -4 , 6 } ; int B [ ] = { 1 , 8 , 5 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; int m = sizeof ( B ) / sizeof ( B [ 0 ] ) ;
findMaxSubarraySum ( A , B , n , m ) ; return 0 ; }
int findMaxSum ( int arr [ ] , int n ) { int res = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) { int prefix_sum = arr [ i ] ; for ( int j = 0 ; j < i ; j ++ ) prefix_sum += arr [ j ] ; int suffix_sum = arr [ i ] ; for ( int j = n - 1 ; j > i ; j -- ) suffix_sum += arr [ j ] ; if ( prefix_sum == suffix_sum ) res = max ( res , prefix_sum ) ; } return res ; }
int main ( ) { int arr [ ] = { -2 , 5 , 3 , 1 , 2 , 6 , -4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findMaxSum ( arr , n ) ; return 0 ; }
int findMaxSum ( int arr [ ] , int n ) {
int preSum [ n ] ;
int suffSum [ n ] ;
int ans = INT_MIN ;
preSum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) preSum [ i ] = preSum [ i - 1 ] + arr [ i ] ;
suffSum [ n - 1 ] = arr [ n - 1 ] ; if ( preSum [ n - 1 ] == suffSum [ n - 1 ] ) ans = max ( ans , preSum [ n - 1 ] ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) { suffSum [ i ] = suffSum [ i + 1 ] + arr [ i ] ; if ( suffSum [ i ] == preSum [ i ] ) ans = max ( ans , preSum [ i ] ) ; } return ans ; }
int main ( ) { int arr [ ] = { -2 , 5 , 3 , 1 , 2 , 6 , -4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findMaxSum ( arr , n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; void printLeaders ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) { int j ; for ( j = i + 1 ; j < size ; j ++ ) { if ( arr [ i ] <= arr [ j ] ) break ; }
if ( j == size ) cout << arr [ i ] << " ▁ " ; } }
int main ( ) { int arr [ ] = { 16 , 17 , 4 , 3 , 5 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printLeaders ( arr , n ) ; return 0 ; }
void printLeaders ( int arr [ ] , int size ) { int max_from_right = arr [ size - 1 ] ;
cout << max_from_right << " ▁ " ; for ( int i = size - 2 ; i >= 0 ; i -- ) { if ( max_from_right < arr [ i ] ) { max_from_right = arr [ i ] ; cout << max_from_right << " ▁ " ; } } }
int main ( ) { int arr [ ] = { 16 , 17 , 4 , 3 , 5 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printLeaders ( arr , n ) ; return 0 ; }
void findMajority ( int arr [ ] , int n ) { int maxCount = 0 ;
int index = -1 ; for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; }
if ( count > maxCount ) { maxCount = count ; index = i ; } }
if ( maxCount > n / 2 ) cout << arr [ index ] << endl ; else cout << " No ▁ Majority ▁ Element " << endl ; }
int main ( ) { int arr [ ] = { 1 , 1 , 2 , 1 , 3 , 5 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
findMajority ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int maxTripletSum ( int arr [ ] , int n ) {
int sum = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( sum < arr [ i ] + arr [ j ] + arr [ k ] ) sum = arr [ i ] + arr [ j ] + arr [ k ] ; return sum ; }
int main ( ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxTripletSum ( arr , n ) ; return 0 ; }
int maxTripletSum ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
return arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ; }
int main ( ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxTripletSum ( arr , n ) ; return 0 ; }
int maxTripletSum ( int arr [ ] , int n ) {
int maxA = INT_MIN , maxB = INT_MIN , maxC = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > maxA ) { maxC = maxB ; maxB = maxA ; maxA = arr [ i ] ; }
else if ( arr [ i ] > maxB ) { maxC = maxB ; maxB = arr [ i ] ; }
else if ( arr [ i ] > maxC ) maxC = arr [ i ] ; } return ( maxA + maxB + maxC ) ; }
int main ( ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxTripletSum ( arr , n ) ; return 0 ; }
int maximum ( int a , int b , int c ) { return max ( max ( a , b ) , c ) ; }
int minimum ( int a , int b , int c ) { return min ( min ( a , b ) , c ) ; }
void smallestDifferenceTriplet ( int arr1 [ ] , int arr2 [ ] , int arr3 [ ] , int n ) {
sort ( arr1 , arr1 + n ) ; sort ( arr2 , arr2 + n ) ; sort ( arr3 , arr3 + n ) ;
int res_min , res_max , res_mid ;
int i = 0 , j = 0 , k = 0 ;
int diff = INT_MAX ; while ( i < n && j < n && k < n ) { int sum = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
int max = maximum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ;
int min = minimum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ; if ( min == arr1 [ i ] ) i ++ ; else if ( min == arr2 [ j ] ) j ++ ; else k ++ ;
if ( diff > ( max - min ) ) { diff = max - min ; res_max = max ; res_mid = sum - ( max + min ) ; res_min = min ; } }
cout << res_max << " , ▁ " << res_mid << " , ▁ " << res_min ; }
int main ( ) { int arr1 [ ] = { 5 , 2 , 8 } ; int arr2 [ ] = { 10 , 7 , 12 } ; int arr3 [ ] = { 9 , 14 , 6 } ; int n = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) ; return 0 ; }
bool find3Numbers ( int A [ ] , int arr_size , int sum ) { int l , r ;
sort ( A , A + arr_size ) ;
for ( int i = 0 ; i < arr_size - 2 ; i ++ ) {
l = i + 1 ;
r = arr_size - 1 ; while ( l < r ) { if ( A [ i ] + A [ l ] + A [ r ] == sum ) { printf ( " Triplet ▁ is ▁ % d , ▁ % d , ▁ % d " , A [ i ] , A [ l ] , A [ r ] ) ; return true ; } else if ( A [ i ] + A [ l ] + A [ r ] < sum ) l ++ ;
else r -- ; } }
return false ; }
int main ( ) { int A [ ] = { 1 , 4 , 45 , 6 , 10 , 8 } ; int sum = 22 ; int arr_size = sizeof ( A ) / sizeof ( A [ 0 ] ) ; find3Numbers ( A , arr_size , sum ) ; return 0 ; }
void subArray ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i ; j < n ; j ++ ) {
for ( int k = i ; k <= j ; k ++ ) cout << arr [ k ] << " ▁ " ; cout << endl ; } } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " All ▁ Non - empty ▁ Subarrays STRNEWLINE " ; subArray ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void printSubsequences ( int arr [ ] , int n ) {
unsigned int opsize = pow ( 2 , n ) ;
for ( int counter = 1 ; counter < opsize ; counter ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( counter & ( 1 << j ) ) cout << arr [ j ] << " ▁ " ; } cout << endl ; } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " All ▁ Non - empty ▁ Subsequences STRNEWLINE " ; printSubsequences ( arr , n ) ; return 0 ; }
void productArray ( int arr [ ] , int n ) {
if ( n == 1 ) { cout << 0 ; return ; } int i , temp = 1 ;
int * prod = new int [ ( sizeof ( int ) * n ) ] ;
memset ( prod , 1 , n ) ;
for ( i = 0 ; i < n ; i ++ ) { prod [ i ] = temp ; temp *= arr [ i ] ; }
temp = 1 ;
for ( i = n - 1 ; i >= 0 ; i -- ) { prod [ i ] *= temp ; temp *= arr [ i ] ; }
for ( i = 0 ; i < n ; i ++ ) cout << prod [ i ] << " ▁ " ; return ; }
int main ( ) { int arr [ ] = { 10 , 3 , 5 , 6 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " The ▁ product ▁ array ▁ is : ▁ STRNEWLINE " ; productArray ( arr , n ) ; }
bool areConsecutive ( int arr [ ] , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) {
bool * visited = ( bool * ) calloc ( n , sizeof ( bool ) ) ; int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( visited [ arr [ i ] - min ] != false ) return false ;
visited [ arr [ i ] - min ] = true ; }
return true ; }
return false ; }
int getMin ( int arr [ ] , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] < min ) min = arr [ i ] ; return min ; } int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
int main ( ) { int arr [ ] = { 5 , 4 , 2 , 3 , 1 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( areConsecutive ( arr , n ) == true ) printf ( " ▁ Array ▁ elements ▁ are ▁ consecutive ▁ " ) ; else printf ( " ▁ Array ▁ elements ▁ are ▁ not ▁ consecutive ▁ " ) ; getchar ( ) ; return 0 ; }
bool areConsecutive ( int arr [ ] , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { int j ; if ( arr [ i ] < 0 ) j = - arr [ i ] - min ; else j = arr [ i ] - min ;
if ( arr [ j ] > 0 ) arr [ j ] = - arr [ j ] ; else return false ; }
return true ; }
return false ; }
int getMin ( int arr [ ] , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] < min ) min = arr [ i ] ; return min ; } int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
int main ( ) { int arr [ ] = { 1 , 4 , 5 , 3 , 2 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( areConsecutive ( arr , n ) == true ) printf ( " ▁ Array ▁ elements ▁ are ▁ consecutive ▁ " ) ; else printf ( " ▁ Array ▁ elements ▁ are ▁ not ▁ consecutive ▁ " ) ; getchar ( ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; void relativeComplement ( int arr1 [ ] , int arr2 [ ] , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) {
if ( arr1 [ i ] < arr2 [ j ] ) { cout << arr1 [ i ] << " ▁ " ; i ++ ;
} else if ( arr1 [ i ] > arr2 [ j ] ) { j ++ ;
} else if ( arr1 [ i ] == arr2 [ j ] ) { i ++ ; j ++ ; } }
while ( i < n ) cout << arr1 [ i ] << " ▁ " ; }
int main ( ) { int arr1 [ ] = { 3 , 6 , 10 , 12 , 15 } ; int arr2 [ ] = { 1 , 3 , 5 , 10 , 16 } ; int n = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int m = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; relativeComplement ( arr1 , arr2 , n , m ) ; return 0 ; }
int minOps ( int arr [ ] , int n , int k ) {
int max = * max_element ( arr , arr + n ) ; int res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ( max - arr [ i ] ) % k != 0 ) return -1 ;
else res += ( max - arr [ i ] ) / k ; }
return res ; }
int main ( ) { int arr [ ] = { 21 , 33 , 9 , 45 , 63 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 6 ; cout << minOps ( arr , n , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int solve ( int A [ ] , int B [ ] , int C [ ] , int i , int j , int k ) { int min_diff , current_diff , max_term ;
min_diff = Integer . MAX_VALUE ; while ( i != -1 && j != -1 && k != -1 ) { current_diff = abs ( max ( A [ i ] , max ( B [ j ] , C [ k ] ) ) - min ( A [ i ] , min ( B [ j ] , C [ k ] ) ) ) ;
if ( current_diff < min_diff ) min_diff = current_diff ;
max_term = max ( A [ i ] , max ( B [ j ] , C [ k ] ) ) ;
if ( A [ i ] == max_term ) i -= 1 ; else if ( B [ j ] == max_term ) j -= 1 ; else k -= 1 ; } return min_diff ; }
int main ( ) { int D [ ] = { 5 , 8 , 10 , 15 } ; int E [ ] = { 6 , 9 , 15 , 78 , 89 } ; int F [ ] = { 2 , 3 , 6 , 6 , 8 , 8 , 10 } ; int nD = sizeof ( D ) / sizeof ( D [ 0 ] ) ; int nE = sizeof ( E ) / sizeof ( E [ 0 ] ) ; int nF = sizeof ( F ) / sizeof ( F [ 0 ] ) ; cout << solve ( D , E , F , nD - 1 , nE - 1 , nF - 1 ) ; return 0 ; }
int search ( int arr [ ] , int n , int x ) { int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == x ) return i ; } return -1 ; }
int main ( ) { int arr [ ] = { 1 , 10 , 30 , 15 } ; int x = 30 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << x << " ▁ is ▁ present ▁ at ▁ index ▁ " << search ( arr , n , x ) ; getchar ( ) ; return 0 ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { while ( l <= r ) { int m = l + ( r - l ) / 2 ;
if ( arr [ m ] == x ) return m ;
if ( arr [ m ] < x ) l = m + 1 ;
else r = m - 1 ; }
return -1 ; }
int main ( void ) { int arr [ ] = { 2 , 3 , 4 , 10 , 40 } ; int x = 10 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int result = binarySearch ( arr , 0 , n - 1 , x ) ; ( result == -1 ) ? cout << " Element ▁ is ▁ not ▁ present ▁ in ▁ array " : cout << " Element ▁ is ▁ present ▁ at ▁ index ▁ " << result ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int jumpSearch ( int arr [ ] , int x , int n ) {
int step = sqrt ( n ) ;
int prev = 0 ; while ( arr [ min ( step , n ) - 1 ] < x ) { prev = step ; step += sqrt ( n ) ; if ( prev >= n ) return -1 ; }
while ( arr [ prev ] < x ) { prev ++ ;
if ( prev == min ( step , n ) ) return -1 ; }
if ( arr [ prev ] == x ) return prev ; return -1 ; }
int main ( ) { int arr [ ] = { 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 } ; int x = 55 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
int index = jumpSearch ( arr , x , n ) ;
cout << " Number " ▁ < < ▁ x ▁ < < ▁ " is at index " return 0 ; }
int exponentialSearch ( int arr [ ] , int n , int x ) {
if ( arr [ 0 ] == x ) return 0 ;
int i = 1 ; while ( i < n && arr [ i ] <= x ) i = i * 2 ;
return binarySearch ( arr , i / 2 , min ( i , n - 1 ) , x ) ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return -1 ; }
int main ( void ) { int arr [ ] = { 2 , 3 , 4 , 10 , 40 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 10 ; int result = exponentialSearch ( arr , n , x ) ; ( result == -1 ) ? printf ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) : printf ( " Element ▁ is ▁ present ▁ at ▁ index ▁ % d " , result ) ; return 0 ; }
void selectionSort ( int arr [ ] , int n ) { int i , j , min_idx ;
for ( i = 0 ; i < n - 1 ; i ++ ) {
min_idx = i ; for ( j = i + 1 ; j < n ; j ++ ) if ( arr [ j ] < arr [ min_idx ] ) min_idx = j ;
swap ( & arr [ min_idx ] , & arr [ i ] ) ; } }
int main ( ) { int arr [ ] = { 64 , 25 , 12 , 22 , 11 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; selectionSort ( arr , n ) ; cout << " Sorted ▁ array : ▁ STRNEWLINE " ; printArray ( arr , n ) ; return 0 ; }
void bubbleSort ( int arr [ ] , int n ) { int i , j ; bool swapped ; for ( i = 0 ; i < n - 1 ; i ++ ) { swapped = false ; for ( j = 0 ; j < n - i - 1 ; j ++ ) { if ( arr [ j ] > arr [ j + 1 ] ) {
swap ( & arr [ j ] , & arr [ j + 1 ] ) ; swapped = true ; } }
if ( swapped == false ) break ; } }
int main ( ) { int arr [ ] = { 64 , 34 , 25 , 12 , 22 , 11 , 90 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; bubbleSort ( arr , n ) ; printf ( " Sorted ▁ array : ▁ STRNEWLINE " ) ; printArray ( arr , n ) ; return 0 ; }
void countSort ( int arr [ ] , int n , int exp ) {
int output [ n ] ; int i , count [ 10 ] = { 0 } ;
for ( i = 0 ; i < n ; i ++ ) count [ ( arr [ i ] / exp ) % 10 ] ++ ;
for ( i = 1 ; i < 10 ; i ++ ) count [ i ] += count [ i - 1 ] ;
for ( i = n - 1 ; i >= 0 ; i -- ) { output [ count [ ( arr [ i ] / exp ) % 10 ] - 1 ] = arr [ i ] ; count [ ( arr [ i ] / exp ) % 10 ] -- ; }
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = output [ i ] ; }
void radixsort ( int arr [ ] , int n ) {
int m = getMax ( arr , n ) ;
for ( int exp = 1 ; m / exp > 0 ; exp *= 10 ) countSort ( arr , n , exp ) ; }
void print ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 170 , 45 , 75 , 90 , 802 , 24 , 2 , 66 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
radixsort ( arr , n ) ; print ( arr , n ) ; return 0 ; }
void swap ( int * a , int * b ) { int temp = * a ; * a = * b ; * b = temp ; }
int partition ( int arr [ ] , int l , int h ) { int x = arr [ h ] ; int i = ( l - 1 ) ; for ( int j = l ; j <= h - 1 ; j ++ ) { if ( arr [ j ] <= x ) { i ++ ; swap ( & arr [ i ] , & arr [ j ] ) ; } } swap ( & arr [ i + 1 ] , & arr [ h ] ) ; return ( i + 1 ) ; }
void quickSort ( int A [ ] , int l , int h ) { if ( l < h ) {
int p = partition ( A , l , h ) ; quickSort ( A , l , p - 1 ) ; quickSort ( A , p + 1 , h ) ; } }
int main ( ) { int n = 5 ; int arr [ n ] = { 4 , 2 , 6 , 9 , 2 } ; quickSort ( arr , 0 , n - 1 ) ; for ( int i = 0 ; i < n ; i ++ ) { cout << arr [ i ] << " ▁ " ; } return 0 ; }
void swap ( int * a , int * b ) { int t = * a ; * a = * b ; * b = t ; }
int partition ( int arr [ ] , int l , int h ) { int x = arr [ h ] ; int i = ( l - 1 ) ; for ( int j = l ; j <= h - 1 ; j ++ ) { if ( arr [ j ] <= x ) { i ++ ; swap ( & arr [ i ] , & arr [ j ] ) ; } } swap ( & arr [ i + 1 ] , & arr [ h ] ) ; return ( i + 1 ) ; }
void quickSortIterative ( int arr [ ] , int l , int h ) {
int stack [ h - l + 1 ] ;
int top = -1 ;
stack [ ++ top ] = l ; stack [ ++ top ] = h ;
while ( top >= 0 ) {
h = stack [ top -- ] ; l = stack [ top -- ] ;
int p = partition ( arr , l , h ) ;
if ( p - 1 > l ) { stack [ ++ top ] = l ; stack [ ++ top ] = p - 1 ; }
if ( p + 1 < h ) { stack [ ++ top ] = p + 1 ; stack [ ++ top ] = h ; } } }
void printArr ( int arr [ ] , int n ) { int i ; for ( i = 0 ; i < n ; ++ i ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 4 , 3 , 5 , 2 , 1 , 3 , 2 , 3 } ; int n = sizeof ( arr ) / sizeof ( * arr ) ;
quickSortIterative ( arr , 0 , n - 1 ) ; printArr ( arr , n ) ; return 0 ; }
int findCrossOver ( int arr [ ] , int low , int high , int x ) {
if ( arr [ high ] <= x ) return high ;
if ( arr [ low ] > x ) return low ;
int mid = ( low + high ) / 2 ;
if ( arr [ mid ] <= x && arr [ mid + 1 ] > x ) return mid ;
if ( arr [ mid ] < x ) return findCrossOver ( arr , mid + 1 , high , x ) ; return findCrossOver ( arr , low , mid - 1 , x ) ; }
void printKclosest ( int arr [ ] , int x , int k , int n ) {
int l = findCrossOver ( arr , 0 , n - 1 , x ) ;
int r = l + 1 ;
int count = 0 ;
if ( arr [ l ] == x ) l -- ;
while ( l >= 0 && r < n && count < k ) { if ( x - arr [ l ] < arr [ r ] - x ) printf ( " % d ▁ " , arr [ l -- ] ) ; else printf ( " % d ▁ " , arr [ r ++ ] ) ; count ++ ; }
while ( count < k && l >= 0 ) printf ( " % d ▁ " , arr [ l -- ] ) , count ++ ;
while ( count < k && r < n ) printf ( " % d ▁ " , arr [ r ++ ] ) , count ++ ; }
int main ( ) { int arr [ ] = { 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 35 , k = 4 ; printKclosest ( arr , x , 4 , n ) ; return 0 ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ; if ( mid > l && arr [ mid - 1 ] == x ) return ( mid - 1 ) ; if ( mid < r && arr [ mid + 1 ] == x ) return ( mid + 1 ) ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 2 , x ) ;
return binarySearch ( arr , mid + 2 , r , x ) ; }
return -1 ; }
int main ( void ) { int arr [ ] = { 3 , 2 , 10 , 4 , 40 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 4 ; int result = binarySearch ( arr , 0 , n - 1 , x ) ; ( result == -1 ) ? printf ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) : printf ( " Element ▁ is ▁ present ▁ at ▁ index ▁ % d " , result ) ; return 0 ; }
void printClosest ( int ar1 [ ] , int ar2 [ ] , int m , int n , int x ) {
int diff = INT_MAX ;
int res_l , res_r ;
int l = 0 , r = n - 1 ; while ( l < m && r >= 0 ) {
if ( abs ( ar1 [ l ] + ar2 [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = abs ( ar1 [ l ] + ar2 [ r ] - x ) ; }
if ( ar1 [ l ] + ar2 [ r ] > x ) r -- ;
else l ++ ; }
cout << " The ▁ closest ▁ pair ▁ is ▁ [ " << ar1 [ res_l ] << " , ▁ " << ar2 [ res_r ] << " ] ▁ STRNEWLINE " ; }
int main ( ) { int ar1 [ ] = { 1 , 4 , 5 , 7 } ; int ar2 [ ] = { 10 , 20 , 30 , 40 } ; int m = sizeof ( ar1 ) / sizeof ( ar1 [ 0 ] ) ; int n = sizeof ( ar2 ) / sizeof ( ar2 [ 0 ] ) ; int x = 38 ; printClosest ( ar1 , ar2 , m , n , x ) ; return 0 ; }
void printClosest ( int arr [ ] , int n , int x ) {
int res_l , res_r ;
int l = 0 , r = n - 1 , diff = INT_MAX ;
while ( r > l ) {
if ( abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } cout << " ▁ The ▁ closest ▁ pair ▁ is ▁ " << arr [ res_l ] << " ▁ and ▁ " << arr [ res_r ] ; }
int main ( ) { int arr [ ] = { 10 , 22 , 28 , 29 , 30 , 40 } , x = 54 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printClosest ( arr , n , x ) ; return 0 ; }
int countOnes ( bool arr [ ] , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
int main ( ) { bool arr [ ] = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " << countOnes ( arr , 0 , n - 1 ) ; return 0 ; }
void solve ( int a [ ] , int n ) { int maxx = -1 , minn = a [ 0 ] , l = 0 , r = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] > maxx ) { maxx = a [ i ] ; l = i ; }
if ( a [ i ] <= minn ) { minn = a [ i ] ; r = i ; } } if ( r < l ) cout << l + ( n - r - 2 ) ; else cout << l + ( n - r - 1 ) ; }
int main ( ) { int a [ ] = { 5 , 6 , 1 , 3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; solve ( a , n ) ; return 0 ; }
int lcs ( char * X , char * Y , int m , int n ) { if ( m == 0 n == 0 ) return 0 ; if ( X [ m - 1 ] == Y [ n - 1 ] ) return 1 + lcs ( X , Y , m - 1 , n - 1 ) ; else return max ( lcs ( X , Y , m , n - 1 ) , lcs ( X , Y , m - 1 , n ) ) ; }
int main ( ) { char X [ ] = " AGGTAB " ; char Y [ ] = " GXTXAYB " ; int m = strlen ( X ) ; int n = strlen ( Y ) ; cout << " Length ▁ of ▁ LCS ▁ is ▁ " << lcs ( X , Y , m , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int max ( int a , int b ) ;
int lcs ( char * X , char * Y , int m , int n ) { int L [ m + 1 ] [ n + 1 ] ; int i , j ;
for ( i = 0 ; i <= m ; i ++ ) { for ( j = 0 ; j <= n ; j ++ ) { if ( i == 0 j == 0 ) L [ i ] [ j ] = 0 ; else if ( X [ i - 1 ] == Y [ j - 1 ] ) L [ i ] [ j ] = L [ i - 1 ] [ j - 1 ] + 1 ; else L [ i ] [ j ] = max ( L [ i - 1 ] [ j ] , L [ i ] [ j - 1 ] ) ; } }
return L [ m ] [ n ] ; }
int main ( ) { char X [ ] = " AGGTAB " ; char Y [ ] = " GXTXAYB " ; int m = strlen ( X ) ; int n = strlen ( Y ) ; cout << " Length ▁ of ▁ LCS ▁ is ▁ " << lcs ( X , Y , m , n ) ; return 0 ; }
int count ( int S [ ] , int m , int n ) {
if ( n == 0 ) return 1 ;
if ( n < 0 ) return 0 ;
if ( m <= 0 && n >= 1 ) return 0 ;
return count ( S , m - 1 , n ) + count ( S , m , n - S [ m - 1 ] ) ; }
int main ( ) { int i , j ; int arr [ ] = { 1 , 2 , 3 } ; int m = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " % d ▁ " , count ( arr , m , 4 ) ) ; getchar ( ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE int count ( int S [ ] , int m , int n ) {
int table [ n + 1 ] ; memset ( table , 0 , sizeof ( table ) ) ;
table [ 0 ] = 1 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = S [ i ] ; j <= n ; j ++ ) table [ j ] += table [ j - S [ i ] ] ; return table [ n ] ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int binomialCoeff ( int n , int k ) { int C [ k + 1 ] ; memset ( C , 0 , sizeof ( C ) ) ;
C [ 0 ] = 1 ; for ( int i = 1 ; i <= n ; i ++ ) {
for ( int j = min ( i , k ) ; j > 0 ; j -- ) C [ j ] = C [ j ] + C [ j - 1 ] ; } return C [ k ] ; }
int main ( ) { int n = 5 , k = 2 ; printf ( " Value ▁ of ▁ C ( % d , ▁ % d ) ▁ is ▁ % d ▁ " , n , k , binomialCoeff ( n , k ) ) ; return 0 ; }
int eggDrop ( int n , int k ) {
int eggFloor [ n + 1 ] [ k + 1 ] ; int res ; int i , j , x ;
for ( i = 1 ; i <= n ; i ++ ) { eggFloor [ i ] [ 1 ] = 1 ; eggFloor [ i ] [ 0 ] = 0 ; }
for ( j = 1 ; j <= k ; j ++ ) eggFloor [ 1 ] [ j ] = j ;
for ( i = 2 ; i <= n ; i ++ ) { for ( j = 2 ; j <= k ; j ++ ) { eggFloor [ i ] [ j ] = INT_MAX ; for ( x = 1 ; x <= j ; x ++ ) { res = 1 + max ( eggFloor [ i - 1 ] [ x - 1 ] , eggFloor [ i ] [ j - x ] ) ; if ( res < eggFloor [ i ] [ j ] ) eggFloor [ i ] [ j ] = res ; } } }
return eggFloor [ n ] [ k ] ; }
int main ( ) { int n = 2 , k = 36 ; printf ( " Minimum number of trials " STRNEWLINE " in worst case with % d eggs and " STRNEWLINE " % d floors is % d " , n , k , eggDrop ( n , k ) ) ; return 0 ; }
int max ( int x , int y ) { return ( x > y ) ? x : y ; }
int lps ( char * str ) { int n = strlen ( str ) ; int i , j , cl ;
int L [ n ] [ n ] ;
for ( i = 0 ; i < n ; i ++ ) L [ i ] [ i ] = 1 ;
for ( cl = 2 ; cl <= n ; cl ++ ) { for ( i = 0 ; i < n - cl + 1 ; i ++ ) { j = i + cl - 1 ; if ( str [ i ] == str [ j ] && cl == 2 ) L [ i ] [ j ] = 2 ; else if ( str [ i ] == str [ j ] ) L [ i ] [ j ] = L [ i + 1 ] [ j - 1 ] + 2 ; else L [ i ] [ j ] = max ( L [ i ] [ j - 1 ] , L [ i + 1 ] [ j ] ) ; } } return L [ 0 ] [ n - 1 ] ; }
int main ( ) { char seq [ ] = " GEEKS ▁ FOR ▁ GEEKS " ; int n = strlen ( seq ) ; printf ( " The ▁ length ▁ of ▁ the ▁ LPS ▁ is ▁ % d " , lps ( seq ) ) ; getchar ( ) ; return 0 ; }
int cutRod ( int price [ ] , int n ) { if ( n <= 0 ) return 0 ; int max_val = INT_MIN ;
for ( int i = 0 ; i < n ; i ++ ) max_val = max ( max_val , price [ i ] + cutRod ( price , n - i - 1 ) ) ; return max_val ; }
int main ( ) { int arr [ ] = { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ % dn " , cutRod ( arr , size ) ) ; getchar ( ) ; return 0 ; }
int cutRod ( int price [ ] , int n ) { int val [ n + 1 ] ; val [ 0 ] = 0 ; int i , j ;
for ( i = 1 ; i <= n ; i ++ ) { int max_val = INT_MIN ; for ( j = 0 ; j < i ; j ++ ) max_val = max ( max_val , price [ j ] + val [ i - j - 1 ] ) ; val [ i ] = max_val ; } return val [ n ] ; }
int main ( ) { int arr [ ] = { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ % dn " , cutRod ( arr , size ) ) ; getchar ( ) ; return 0 ; }
int lbs ( int arr [ ] , int n ) { int i , j ;
int * lis = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
int * lds = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lds [ i ] = 1 ;
for ( i = n - 2 ; i >= 0 ; i -- ) for ( j = n - 1 ; j > i ; j -- ) if ( arr [ i ] > arr [ j ] && lds [ i ] < lds [ j ] + 1 ) lds [ i ] = lds [ j ] + 1 ;
int max = lis [ 0 ] + lds [ 0 ] - 1 ; for ( i = 1 ; i < n ; i ++ ) if ( lis [ i ] + lds [ i ] - 1 > max ) max = lis [ i ] + lds [ i ] - 1 ; return max ; }
int main ( ) { int arr [ ] = { 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Length ▁ of ▁ LBS ▁ is ▁ % d STRNEWLINE " , lbs ( arr , n ) ) ; return 0 ; }
int maxDivide ( int a , int b ) { while ( a % b == 0 ) a = a / b ; return a ; }
int isUgly ( int no ) { no = maxDivide ( no , 2 ) ; no = maxDivide ( no , 3 ) ; no = maxDivide ( no , 5 ) ; return ( no == 1 ) ? 1 : 0 ; }
int getNthUglyNo ( int n ) { int i = 1 ;
int count = 1 ;
while ( n > count ) { i ++ ; if ( isUgly ( i ) ) count ++ ; } return i ; }
int main ( ) { unsigned no = getNthUglyNo ( 150 ) ; printf ( "150th ▁ ugly ▁ no . ▁ is ▁ % d ▁ " , no ) ; getchar ( ) ; return 0 ; }
bool isSubsetSum ( int set [ ] , int n , int sum ) {
if ( sum == 0 ) return true ; if ( n == 0 ) return false ;
if ( set [ n - 1 ] > sum ) return isSubsetSum ( set , n - 1 , sum ) ;
return isSubsetSum ( set , n - 1 , sum ) || isSubsetSum ( set , n - 1 , sum - set [ n - 1 ] ) ; }
int main ( ) { int set [ ] = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = sizeof ( set ) / sizeof ( set [ 0 ] ) ; if ( isSubsetSum ( set , n , sum ) == true ) printf ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) ; else printf ( " No ▁ subset ▁ with ▁ given ▁ sum " ) ; return 0 ; }
bool isSubsetSum ( int set [ ] , int n , int sum ) {
bool subset [ n + 1 ] [ sum + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) subset [ i ] [ 0 ] = true ;
for ( int i = 1 ; i <= sum ; i ++ ) subset [ 0 ] [ i ] = false ;
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = 1 ; j <= sum ; j ++ ) { if ( j < set [ i - 1 ] ) subset [ i ] [ j ] = subset [ i - 1 ] [ j ] ; if ( j >= set [ i - 1 ] ) subset [ i ] [ j ] = subset [ i - 1 ] [ j ] || subset [ i - 1 ] [ j - set [ i - 1 ] ] ; } }
for ( int i = 0 ; i <= n ; i ++ ) { for ( int j = 0 ; j <= sum ; j ++ ) printf ( " % 4d " , subset [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } return subset [ n ] [ sum ] ; }
int main ( ) { int set [ ] = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = sizeof ( set ) / sizeof ( set [ 0 ] ) ; if ( isSubsetSum ( set , n , sum ) == true ) printf ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) ; else printf ( " No ▁ subset ▁ with ▁ given ▁ sum " ) ; return 0 ; }
unsigned long long int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ; if ( sum == 0 ) return 1 ;
unsigned long long int ans = 0 ;
for ( int i = 0 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
unsigned long long int finalCount ( int n , int sum ) {
unsigned long long int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
int main ( ) { int n = 2 , sum = 5 ; cout << finalCount ( n , sum ) ; return 0 ; }
unsigned long long int lookup [ 101 ] [ 501 ] ;
unsigned long long int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ;
if ( lookup [ n ] [ sum ] != -1 ) return lookup [ n ] [ sum ] ;
unsigned long long int ans = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return lookup [ n ] [ sum ] = ans ; }
unsigned long long int finalCount ( int n , int sum ) {
unsigned long long int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
int main ( ) { int n = 3 , sum = 5 ; cout << finalCount ( n , sum ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #include <iostream> NEW_LINE using namespace std ; void findCount ( int n , int sum ) {
int start = pow ( 10 , n - 1 ) ; int end = pow ( 10 , n ) - 1 ; int count = 0 ; int i = start ; while ( i <= end ) { int cur = 0 ; int temp = i ; while ( temp != 0 ) { cur += temp % 10 ; temp = temp / 10 ; } if ( cur == sum ) { count ++ ; i += 9 ; } else i ++ ; } cout << count ; }
int main ( ) { int n = 3 ; int sum = 5 ; findCount ( n , sum ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; long long int countNonDecreasing ( int n ) {
long long int dp [ 10 ] [ n + 1 ] ; memset ( dp , 0 , sizeof dp ) ;
for ( int i = 0 ; i < 10 ; i ++ ) dp [ i ] [ 1 ] = 1 ;
for ( int digit = 0 ; digit <= 9 ; digit ++ ) {
for ( int len = 2 ; len <= n ; len ++ ) {
for ( int x = 0 ; x <= digit ; x ++ ) dp [ digit ] [ len ] += dp [ x ] [ len - 1 ] ; } } long long int count = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) count += dp [ i ] [ n ] ; return count ; }
int main ( ) { int n = 3 ; cout << countNonDecreasing ( n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; long long int countNonDecreasing ( int n ) { int N = 10 ;
long long count = 1 ; for ( int i = 1 ; i <= n ; i ++ ) { count *= ( N + i - 1 ) ; count /= i ; } return count ; }
int main ( ) { int n = 3 ; cout << countNonDecreasing ( n ) ; return 0 ; }
int getMinSquares ( unsigned int n ) {
if ( sqrt ( n ) - floor ( sqrt ( n ) ) == 0 ) return 1 ; if ( n <= 3 ) return n ;
int res = n ;
for ( int x = 1 ; x <= n ; x ++ ) { int temp = x * x ; if ( temp > n ) break ; else res = min ( res , 1 + getMinSquares ( n - temp ) ) ; } return res ; }
int main ( ) { cout << getMinSquares ( 6 ) ; return 0 ; }
int getMinSquares ( int n ) {
int * dp = new int [ n + 1 ] ;
dp [ 0 ] = 0 ; dp [ 1 ] = 1 ; dp [ 2 ] = 2 ; dp [ 3 ] = 3 ;
for ( int i = 4 ; i <= n ; i ++ ) {
dp [ i ] = i ;
for ( int x = 1 ; x <= ceil ( sqrt ( i ) ) ; x ++ ) { int temp = x * x ; if ( temp > i ) break ; else dp [ i ] = min ( dp [ i ] , 1 + dp [ i - temp ] ) ; } }
int res = dp [ n ] ; delete [ ] dp ; return res ; }
int main ( ) { cout << getMinSquares ( 6 ) ; return 0 ; }
int minCoins ( int coins [ ] , int m , int V ) {
if ( V == 0 ) return 0 ;
int res = INT_MAX ;
for ( int i = 0 ; i < m ; i ++ ) { if ( coins [ i ] <= V ) { int sub_res = minCoins ( coins , m , V - coins [ i ] ) ;
if ( sub_res != INT_MAX && sub_res + 1 < res ) res = sub_res + 1 ; } } return res ; }
int main ( ) { int coins [ ] = { 9 , 6 , 5 , 1 } ; int m = sizeof ( coins ) / sizeof ( coins [ 0 ] ) ; int V = 11 ; cout << " Minimum ▁ coins ▁ required ▁ is ▁ " << minCoins ( coins , m , V ) ; return 0 ; }
int minCoins ( int coins [ ] , int m , int V ) {
int table [ V + 1 ] ;
table [ 0 ] = 0 ;
for ( int i = 1 ; i <= V ; i ++ ) table [ i ] = INT_MAX ;
for ( int i = 1 ; i <= V ; i ++ ) {
for ( int j = 0 ; j < m ; j ++ ) if ( coins [ j ] <= i ) { int sub_res = table [ i - coins [ j ] ] ; if ( sub_res != INT_MAX && sub_res + 1 < table [ i ] ) table [ i ] = sub_res + 1 ; } } if ( table [ V ] == INT_MAX ) return -1 ; return table [ V ] ; }
int main ( ) { int coins [ ] = { 9 , 6 , 5 , 1 } ; int m = sizeof ( coins ) / sizeof ( coins [ 0 ] ) ; int V = 11 ; cout << " Minimum ▁ coins ▁ required ▁ is ▁ " << minCoins ( coins , m , V ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int superSeq ( char * X , char * Y , int m , int n ) { if ( ! m ) return n ; if ( ! n ) return m ; if ( X [ m - 1 ] == Y [ n - 1 ] ) return 1 + superSeq ( X , Y , m - 1 , n - 1 ) ; return 1 + min ( superSeq ( X , Y , m - 1 , n ) , superSeq ( X , Y , m , n - 1 ) ) ; }
int main ( ) { char X [ ] = " AGGTAB " ; char Y [ ] = " GXTXAYB " ; cout << " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ " << superSeq ( X , Y , strlen ( X ) , strlen ( Y ) ) ; return 0 ; }
int superSeq ( char * X , char * Y , int m , int n ) { int dp [ m + 1 ] [ n + 1 ] ;
for ( int i = 0 ; i <= m ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) {
if ( ! i ) dp [ i ] [ j ] = j ; else if ( ! j ) dp [ i ] [ j ] = i ; else if ( X [ i - 1 ] == Y [ j - 1 ] ) dp [ i ] [ j ] = 1 + dp [ i - 1 ] [ j - 1 ] ; else dp [ i ] [ j ] = 1 + min ( dp [ i - 1 ] [ j ] , dp [ i ] [ j - 1 ] ) ; } } return dp [ m ] [ n ] ; }
int main ( ) { char X [ ] = " AGGTAB " ; char Y [ ] = " GXTXAYB " ; cout << " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ " << superSeq ( X , Y , strlen ( X ) , strlen ( Y ) ) ; return 0 ; }
int sumOfDigitsFrom1ToN ( int n ) {
int result = 0 ;
for ( int x = 1 ; x <= n ; x ++ ) result += sumOfDigits ( x ) ; return result ; }
int sumOfDigits ( int x ) { int sum = 0 ; while ( x != 0 ) { sum += x % 10 ; x = x / 10 ; } return sum ; }
int main ( ) { int n = 328 ; cout << " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from ▁ 1 ▁ to ▁ " << n << " ▁ is ▁ " << sumOfDigitsFrom1ToN ( n ) ; return 0 ; }
int sumOfDigitsFrom1ToN ( int n ) {
if ( n < 10 ) return n * ( n + 1 ) / 2 ;
int d = log10 ( n ) ;
int * a = new int [ d + 1 ] ; a [ 0 ] = 0 , a [ 1 ] = 45 ; for ( int i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * ceil ( pow ( 10 , i - 1 ) ) ;
int p = ceil ( pow ( 10 , d ) ) ;
int msd = n / p ;
return msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToN ( n % p ) ; }
int main ( ) { int n = 328 ; cout << " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from ▁ 1 ▁ to ▁ " << n << " ▁ is ▁ " << sumOfDigitsFrom1ToN ( n ) ; return 0 ; }
int countWays ( int N ) {
if ( N == 1 )
return 4 ;
int countB = 1 , countS = 1 , prev_countB , prev_countS ;
for ( int i = 2 ; i <= N ; i ++ ) { prev_countB = countB ; prev_countS = countS ; countS = prev_countB + prev_countS ; countB = prev_countS ; }
int result = countS + countB ;
return ( result * result ) ; }
int main ( ) { int N = 3 ; cout << " Count ▁ of ▁ ways ▁ for ▁ " << N << " ▁ sections ▁ is ▁ " << countWays ( N ) ; return 0 ; }
void printPatternUtil ( const char str [ ] , char buff [ ] , int i , int j , int n ) { if ( i == n ) { buff [ j ] = ' \0' ; cout << buff << endl ; return ; }
buff [ j ] = str [ i ] ; printPatternUtil ( str , buff , i + 1 , j + 1 , n ) ;
buff [ j ] = ' ▁ ' ; buff [ j + 1 ] = str [ i ] ; printPatternUtil ( str , buff , i + 1 , j + 2 , n ) ; }
void printPattern ( const char * str ) { int n = strlen ( str ) ;
char buf [ 2 * n ] ;
buf [ 0 ] = str [ 0 ] ; printPatternUtil ( str , buf , 1 , 1 , n ) ; }
int main ( ) { const char * str = " ABCD " ; printPattern ( str ) ; return 0 ; }
float area ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 ) { return abs ( ( x1 * ( y2 - y3 ) + x2 * ( y3 - y1 ) + x3 * ( y1 - y2 ) ) / 2.0 ) ; }
bool isInside ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 , int x , int y ) {
float A = area ( x1 , y1 , x2 , y2 , x3 , y3 ) ;
float A1 = area ( x , y , x2 , y2 , x3 , y3 ) ;
float A2 = area ( x1 , y1 , x , y , x3 , y3 ) ;
float A3 = area ( x1 , y1 , x2 , y2 , x , y ) ;
return ( A == A1 + A2 + A3 ) ; }
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) printf ( " Inside " ) ; else printf ( " Not ▁ Inside " ) ; return 0 ; }
float getAvg ( float prev_avg , int x , int n ) { return ( prev_avg * n + x ) / ( n + 1 ) ; }
void streamAvg ( float arr [ ] , int n ) { float avg = 0 ; for ( int i = 0 ; i < n ; i ++ ) { avg = getAvg ( avg , arr [ i ] , i ) ; printf ( " Average ▁ of ▁ % d ▁ numbers ▁ is ▁ % f ▁ STRNEWLINE " , i + 1 , avg ) ; } return ; }
int main ( ) { float arr [ ] = { 10 , 20 , 30 , 40 , 50 , 60 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; streamAvg ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void SieveOfEratosthenes ( int n ) {
bool prime [ n + 1 ] ; memset ( prime , true , sizeof ( prime ) ) ; for ( int p = 2 ; p * p <= n ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * p ; i <= n ; i += p ) prime [ i ] = false ; } }
for ( int p = 2 ; p <= n ; p ++ ) if ( prime [ p ] ) cout << p << " ▁ " ; }
int main ( ) { int n = 30 ; cout << " Following ▁ are ▁ the ▁ prime ▁ numbers ▁ smaller ▁ " << " ▁ than ▁ or ▁ equal ▁ to ▁ " << n << endl ; SieveOfEratosthenes ( n ) ; return 0 ; }
int maximumNumberDistinctPrimeRange ( int m , int n ) {
long long factorCount [ n + 1 ] ;
bool prime [ n + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) { factorCount [ i ] = 0 ;
prime [ i ] = true ; } for ( int i = 2 ; i <= n ; i ++ ) {
if ( prime [ i ] == true ) {
factorCount [ i ] = 1 ;
for ( int j = i * 2 ; j <= n ; j += i ) {
factorCount [ j ] ++ ;
prime [ j ] = false ; } } }
int max = factorCount [ m ] ; int num = m ;
for ( int i = m ; i <= n ; i ++ ) {
if ( factorCount [ i ] > max ) { max = factorCount [ i ] ; num = i ; } } return num ; }
int main ( ) { int m = 4 , n = 6 ;
cout << maximumNumberDistinctPrimeRange ( m , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX_CHAR  256
int count [ MAX_CHAR ] = { 0 } ;
int fact ( int n ) { return ( n <= 1 ) ? 1 : n * fact ( n - 1 ) ; }
void populateAndIncreaseCount ( int * count , char * str ) { int i ; for ( i = 0 ; str [ i ] ; ++ i ) ++ count [ str [ i ] ] ; for ( i = 1 ; i < MAX_CHAR ; ++ i ) count [ i ] += count [ i - 1 ] ; }
void updatecount ( int * count , char ch ) { int i ; for ( i = ch ; i < MAX_CHAR ; ++ i ) -- count [ i ] ; }
int findRank ( char * str ) { int len = strlen ( str ) ; int mul = fact ( len ) ; int rank = 1 , i ;
populateAndIncreaseCount ( count , str ) ; for ( i = 0 ; i < len ; ++ i ) { mul /= len - i ;
rank += count [ str [ i ] - 1 ] * mul ;
updatecount ( count , str [ i ] ) ; } return rank ; }
int main ( ) { char str [ ] = " string " ; cout << findRank ( str ) ; return 0 ; }
int binomialCoeff ( int n , int k ) ; int binomialCoeff ( int n , int k ) { int res = 1 ; if ( k > n - k ) k = n - k ; for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
void printPascal ( int n ) {
for ( int line = 0 ; line < n ; line ++ ) {
for ( int i = 0 ; i <= line ; i ++ ) printf ( " % d ▁ " , binomialCoeff ( line , i ) ) ; printf ( " STRNEWLINE " ) ; } }
int main ( ) { int n = 7 ; printPascal ( n ) ; return 0 ; }
bool isPerfectSquare ( int x ) { int s = sqrt ( x ) ; return ( s * s == x ) ; }
bool isFibonacci ( int n ) {
return isPerfectSquare ( 5 * n * n + 4 ) || isPerfectSquare ( 5 * n * n - 4 ) ; }
int main ( ) { for ( int i = 1 ; i <= 10 ; i ++ ) isFibonacci ( i ) ? cout << i << " ▁ is ▁ a ▁ Fibonacci ▁ Number ▁ STRNEWLINE " : cout << i << " ▁ is ▁ a ▁ not ▁ Fibonacci ▁ Number ▁ STRNEWLINE " ; return 0 ; }
int findTrailingZeros ( int n ) {
int count = 0 ;
for ( int i = 5 ; n / i >= 1 ; i *= 5 ) count += n / i ; return count ; }
int main ( ) { int n = 100 ; cout << " Count ▁ of ▁ trailing ▁ 0s ▁ in ▁ " << 100 << " ! ▁ is ▁ " << findTrailingZeros ( n ) ; return 0 ; }
unsigned long int catalan ( unsigned int n ) {
if ( n <= 1 ) return 1 ;
unsigned long int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) res += catalan ( i ) * catalan ( n - i - 1 ) ; return res ; }
int main ( ) { for ( int i = 0 ; i < 10 ; i ++ ) cout << catalan ( i ) << " ▁ " ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; unsigned long int catalanDP ( unsigned int n ) {
unsigned long int catalan [ n + 1 ] ;
catalan [ 0 ] = catalan [ 1 ] = 1 ;
for ( int i = 2 ; i <= n ; i ++ ) { catalan [ i ] = 0 ; for ( int j = 0 ; j < i ; j ++ ) catalan [ i ] += catalan [ j ] * catalan [ i - j - 1 ] ; }
return catalan [ n ] ; }
int main ( ) { for ( int i = 0 ; i < 10 ; i ++ ) cout << catalanDP ( i ) << " ▁ " ; return 0 ; }
unsigned long int binomialCoeff ( unsigned int n , unsigned int k ) { unsigned long int res = 1 ;
if ( k > n - k ) k = n - k ;
for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
unsigned long int catalan ( unsigned int n ) {
unsigned long int c = binomialCoeff ( 2 * n , n ) ;
return c / ( n + 1 ) ; }
int main ( ) { for ( int i = 0 ; i < 10 ; i ++ ) cout << catalan ( i ) << " ▁ " ; return 0 ; }
int getInvCount ( int arr [ ] ) { int inv_count = 0 ; for ( int i = 0 ; i < 9 - 1 ; i ++ ) for ( int j = i + 1 ; j < 9 ; j ++ )
if ( arr [ j ] && arr [ i ] && arr [ i ] > arr [ j ] ) inv_count ++ ; return inv_count ; }
bool isSolvable ( int puzzle [ 3 ] [ 3 ] ) {
int invCount = getInvCount ( ( int * ) puzzle ) ;
return ( invCount % 2 == 0 ) ; }
int main ( int argv , char * * args ) { int puzzle [ 3 ] [ 3 ] = { { 1 , 8 , 2 } , { 0 , 4 , 3 } , { 7 , 6 , 5 } } ; isSolvable ( puzzle ) ? cout << " Solvable " : cout << " Not ▁ Solvable " ; return 0 ; }
int find ( double p ) { return ceil ( sqrt ( 2 * 365 * log ( 1 / ( 1 - p ) ) ) ) ; }
int main ( ) { cout << find ( 0.70 ) ; }
int countSolutions ( int n ) { int res = 0 ; for ( int x = 0 ; x * x < n ; x ++ ) for ( int y = 0 ; x * x + y * y < n ; y ++ ) res ++ ; return res ; }
int main ( ) { cout << " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " << countSolutions ( 6 ) << endl ; return 0 ; }
int countSolutions ( int n ) { int x = 0 , yCount , res = 0 ;
for ( yCount = 0 ; yCount * yCount < n ; yCount ++ ) ;
while ( yCount != 0 ) {
res += yCount ;
x ++ ;
while ( yCount != 0 && ( x * x + ( yCount - 1 ) * ( yCount - 1 ) >= n ) ) yCount -- ; } return res ; }
int main ( ) { cout << " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " << countSolutions ( 6 ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define EPSILON  0.001 NEW_LINE using namespace std ;
double func ( double x ) { return x * x * x - x * x + 2 ; }
double derivFunc ( double x ) { return 3 * x * x - 2 * x ; }
void newtonRaphson ( double x ) { double h = func ( x ) / derivFunc ( x ) ; while ( abs ( h ) >= EPSILON ) { h = func ( x ) / derivFunc ( x ) ;
x = x - h ; } cout << " The ▁ value ▁ of ▁ the ▁ root ▁ is ▁ : ▁ " << x ; }
double x0 = -20 ; newtonRaphson ( x0 ) ; return 0 ; }
bool oppositeSigns ( int x , int y ) { return ( ( x ^ y ) < 0 ) ; }
int main ( ) { int x = 100 , y = -100 ; if ( oppositeSigns ( x , y ) == true ) printf ( " Signs ▁ are ▁ opposite " ) ; else printf ( " Signs ▁ are ▁ not ▁ opposite " ) ; return 0 ; }
void update ( int arr [ ] , int l , int r , int val ) { arr [ l ] += val ; arr [ r + 1 ] -= val ; }
int getElement ( int arr [ ] , int i ) {
int res = 0 ; for ( int j = 0 ; j <= i ; j ++ ) res += arr [ j ] ; return res ; }
int main ( ) { int arr [ ] = { 0 , 0 , 0 , 0 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int l = 2 , r = 4 , val = 2 ; update ( arr , l , r , val ) ;
int index = 4 ; cout << " Element ▁ at ▁ index ▁ " << index << " ▁ is ▁ " << getElement ( arr , index ) << endl ; l = 0 , r = 3 , val = 4 ; update ( arr , l , r , val ) ;
index = 3 ; cout << " Element ▁ at ▁ index ▁ " << index << " ▁ is ▁ " << getElement ( arr , index ) << endl ; return 0 ; }
unsigned int countSetBits ( unsigned int n ) {
int bitCount = 0 ; for ( int i = 1 ; i <= n ; i ++ ) bitCount += countSetBitsUtil ( i ) ; return bitCount ; }
unsigned int countSetBitsUtil ( unsigned int x ) { if ( x <= 0 ) return 0 ; return ( x % 2 == 0 ? 0 : 1 ) + countSetBitsUtil ( x / 2 ) ; }
int main ( ) { int n = 4 ; printf ( " Total ▁ set ▁ bit ▁ count ▁ is ▁ % d " , countSetBits ( n ) ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countSetBits ( int n ) { int i = 0 ;
int ans = 0 ;
while ( ( 1 << i ) <= n ) {
bool k = 0 ;
int change = 1 << i ;
for ( int j = 0 ; j <= n ; j ++ ) { ans += k ; if ( change == 1 ) {
k = ! k ;
change = 1 << i ; } else { change -- ; } }
i ++ ; } return ans ; }
int main ( ) { int n = 17 ; cout << countSetBits ( n ) << endl ; return 0 ; }
uint_t snoob ( uint_t x ) { uint_t rightOne ; uint_t nextHigherOneBit ; uint_t rightOnesPattern ; uint_t next = 0 ; if ( x ) {
rightOne = x & - ( signed ) x ;
nextHigherOneBit = x + rightOne ;
rightOnesPattern = x ^ nextHigherOneBit ;
rightOnesPattern = ( rightOnesPattern ) / rightOne ;
rightOnesPattern >>= 2 ;
next = nextHigherOneBit | rightOnesPattern ; } return next ; }
int main ( ) { int x = 156 ; cout << " Next ▁ higher ▁ number ▁ with ▁ same ▁ number ▁ of ▁ set ▁ bits ▁ is ▁ " << snoob ( x ) ; getchar ( ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE int multiplyWith3Point5 ( int x ) { return ( x << 1 ) + x + ( x >> 1 ) ; }
int main ( ) { int x = 4 ; printf ( " % d " , multiplyWith3Point5 ( x ) ) ; getchar ( ) ; return 0 ; }
unsigned int getModulo ( unsigned int n , unsigned int d ) { return ( n & ( d - 1 ) ) ; }
int main ( ) { unsigned int n = 6 ;
unsigned int d = 4 ; printf ( " % u ▁ moduo ▁ % u ▁ is ▁ % u " , n , d , getModulo ( n , d ) ) ; getchar ( ) ; return 0 ; }
int getOddOccurrence ( int arr [ ] , int arr_size ) { for ( int i = 0 ; i < arr_size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < arr_size ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; } if ( count % 2 != 0 ) return arr [ i ] ; } return -1 ; }
int main ( ) { int arr [ ] = { 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
cout << getOddOccurrence ( arr , n ) ; return 0 ; }
int fastPow ( int N , int K ) { if ( K == 0 ) return 1 ; int temp = fastPow ( N , K / 2 ) ; if ( K % 2 == 0 ) return temp * temp ; else return N * temp * temp ; } int countWays ( int N , int K ) { return K * fastPow ( K - 1 , N - 1 ) ; }
int main ( ) { int N = 3 , K = 3 ; cout << countWays ( N , K ) ; return 0 ; }
int countSetBits ( int n ) {
if ( n == 0 ) return 0 ; else return 1 + countSetBits ( n & ( n - 1 ) ) ; }
int n = 9 ;
cout << countSetBits ( n ) ; return 0 ; }
using namespace std ; int main ( ) { cout << __builtin_popcount ( 4 ) << endl ; cout << __builtin_popcount ( 15 ) ; return 0 ; }
int countSetBits ( int n ) { int count = 0 ; while ( n > 0 ) { count ++ ; n &= ( n - 1 ) ; } return count ; }
int FlippedCount ( int a , int b ) {
return countSetBits ( a ^ b ) ; }
int main ( ) { int a = 10 ; int b = 20 ; cout << FlippedCount ( a , b ) << endl ; return 0 ; }
int PositionRightmostSetbit ( int n ) {
int position = 1 ; int m = 1 ; while ( ! ( n & m ) ) {
m = m << 1 ; position ++ ; } return position ; }
int main ( ) { int n = 16 ;
cout << PositionRightmostSetbit ( n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; #define INT_SIZE  32 NEW_LINE int Right_most_setbit ( int num ) {
for ( int i = 0 ; i < INT_SIZE ; i ++ ) { if ( ! ( num & ( 1 << i ) ) ) pos ++ ; else break ; } return pos ; } }
int main ( ) { int num = 0 ; int pos = Right_most_setbit ( num ) ; cout << pos << endl ; return 0 ; }
void bin ( unsigned n ) { if ( n > 1 ) bin ( n >> 1 ) ; printf ( " % d " , n & 1 ) ; }
int main ( void ) { bin ( 131 ) ; printf ( " STRNEWLINE " ) ; bin ( 3 ) ; return 0 ; }
int maxOnesIndex ( bool arr [ ] , int n ) {
int max_count = 0 ;
int max_index ;
int prev_zero = -1 ;
int prev_prev_zero = -1 ;
for ( int curr = 0 ; curr < n ; ++ curr ) {
if ( arr [ curr ] == 0 ) {
if ( curr - prev_prev_zero > max_count ) { max_count = curr - prev_prev_zero ; max_index = prev_zero ; }
prev_prev_zero = prev_zero ; prev_zero = curr ; } }
if ( n - prev_prev_zero > max_count ) max_index = prev_zero ; return max_index ; }
int main ( ) { bool arr [ ] = { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Index ▁ of ▁ 0 ▁ to ▁ be ▁ replaced ▁ is ▁ " << maxOnesIndex ( arr , n ) ; return 0 ; }
int min ( int x , int y ) { return ( x < y ) ? x : y ; } int max ( int x , int y ) { return ( x > y ) ? x : y ; }
int findLength ( int arr [ ] , int n ) {
int max_len = 1 ; for ( int i = 0 ; i < n - 1 ; i ++ ) {
int mn = arr [ i ] , mx = arr [ i ] ;
for ( int j = i + 1 ; j < n ; j ++ ) {
mn = min ( mn , arr [ j ] ) ; mx = max ( mx , arr [ j ] ) ;
if ( ( mx - mn ) == j - i ) max_len = max ( max_len , mx - mn + 1 ) ; } }
return max_len ; }
int main ( ) { int arr [ ] = { 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Length ▁ of ▁ the ▁ longest ▁ contiguous ▁ subarray ▁ is ▁ " << findLength ( arr , n ) ; return 0 ; }
void printArr ( int arr [ ] , int k ) { for ( int i = 0 ; i < k ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << endl ; }
void printSeqUtil ( int n , int k , int & len , int arr [ ] ) {
if ( len == k ) { printArr ( arr , k ) ; return ; }
int i = ( len == 0 ) ? 1 : arr [ len - 1 ] + 1 ;
len ++ ;
while ( i <= n ) { arr [ len - 1 ] = i ; printSeqUtil ( n , k , len , arr ) ; i ++ ; }
len -- ; }
void printSeq ( int n , int k ) {
int arr [ k ] ;
int len = 0 ; printSeqUtil ( n , k , len , arr ) ; }
int main ( ) { int k = 3 , n = 7 ; printSeq ( n , k ) ; return 0 ; }
bool isSubSequence ( char str1 [ ] , char str2 [ ] , int m , int n ) {
if ( m == 0 ) return true ; if ( n == 0 ) return false ;
if ( str1 [ m - 1 ] == str2 [ n - 1 ] ) return isSubSequence ( str1 , str2 , m - 1 , n - 1 ) ;
return isSubSequence ( str1 , str2 , m , n - 1 ) ; }
int main ( ) { char str1 [ ] = " gksrek " ; char str2 [ ] = " geeksforgeeks " ; int m = strlen ( str1 ) ; int n = strlen ( str2 ) ; isSubSequence ( str1 , str2 , m , n ) ? cout << " Yes ▁ " : cout << " No " ; return 0 ; }
void segregate0and1 ( int arr [ ] , int n ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 0 ) count ++ ; }
for ( int i = 0 ; i < count ; i ++ ) arr [ i ] = 0 ;
for ( int i = count ; i < n ; i ++ ) arr [ i ] = 1 ; }
void print ( int arr [ ] , int n ) { cout << " Array ▁ after ▁ segregation ▁ is ▁ " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 1 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; segregate0and1 ( arr , n ) ; print ( arr , n ) ; return 0 ; }
void segregate0and1 ( int arr [ ] , int size ) { int type0 = 0 ; int type1 = size - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { swap ( arr [ type0 ] , arr [ type1 ] ) ; type1 -- ; } else type0 ++ ; } }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 1 , 1 , 1 } ; int i , arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; segregate0and1 ( arr , arr_size ) ; cout << " Array ▁ after ▁ segregation ▁ is ▁ " ; for ( i = 0 ; i < arr_size ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
int GetCeilIndex ( int arr [ ] , vector < int > & T , int l , int r , int key ) { while ( r - l > 1 ) { int m = l + ( r - l ) / 2 ; if ( arr [ T [ m ] ] >= key ) r = m ; else l = m ; } return r ; } int LongestIncreasingSubsequence ( int arr [ ] , int n ) {
vector < int > tailIndices ( n , 0 ) ;
vector < int > prevIndices ( n , -1 ) ;
int len = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ tailIndices [ 0 ] ] ) {
tailIndices [ 0 ] = i ; } else if ( arr [ i ] > arr [ tailIndices [ len - 1 ] ] ) {
prevIndices [ i ] = tailIndices [ len - 1 ] ; tailIndices [ len ++ ] = i ; } else {
int pos = GetCeilIndex ( arr , tailIndices , -1 , len - 1 , arr [ i ] ) ; prevIndices [ i ] = tailIndices [ pos - 1 ] ; tailIndices [ pos ] = i ; } } cout << " LIS ▁ of ▁ given ▁ input " << endl ; for ( int i = tailIndices [ len - 1 ] ; i >= 0 ; i = prevIndices [ i ] ) cout << arr [ i ] << " ▁ " ; cout << endl ; return len ; }
int main ( ) { int arr [ ] = { 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " LIS ▁ size ▁ % d STRNEWLINE " , LongestIncreasingSubsequence ( arr , n ) ) ; return 0 ; }
void generateUtil ( int A [ ] , int B [ ] , int C [ ] , int i , int j , int m , int n , int len , bool flag ) {
if ( flag ) {
if ( len ) printArr ( C , len + 1 ) ;
for ( int k = i ; k < m ; k ++ ) { if ( ! len ) {
C [ len ] = A [ k ] ;
generateUtil ( A , B , C , k + 1 , j , m , n , len , ! flag ) ; } else
{ if ( A [ k ] > C [ len ] ) { C [ len + 1 ] = A [ k ] ; generateUtil ( A , B , C , k + 1 , j , m , n , len + 1 , ! flag ) ; } } } } else
{ for ( int l = j ; l < n ; l ++ ) { if ( B [ l ] > C [ len ] ) { C [ len + 1 ] = B [ l ] ; generateUtil ( A , B , C , i , l + 1 , m , n , len + 1 , ! flag ) ; } } } }
void generate ( int A [ ] , int B [ ] , int m , int n ) { int C [ m + n ] ;
generateUtil ( A , B , C , 0 , 0 , m , n , 0 , true ) ; }
void printArr ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << endl ; }
int main ( ) { int A [ ] = { 10 , 15 , 25 } ; int B [ ] = { 5 , 20 , 30 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; int m = sizeof ( B ) / sizeof ( B [ 0 ] ) ; generate ( A , B , n , m ) ; return 0 ; }
void replace_elements ( int arr [ ] , int n ) {
int pos = 0 ; for ( int i = 0 ; i < n ; i ++ ) { arr [ pos ++ ] = arr [ i ] ; while ( pos > 1 && arr [ pos - 2 ] == arr [ pos - 1 ] ) { pos -- ; arr [ pos - 1 ] ++ ; } }
for ( int i = 0 ; i < pos ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 6 , 4 , 3 , 4 , 3 , 3 , 5 } ; int n = sizeof ( arr ) / sizeof ( int ) ; replace_elements ( arr , n ) ; return 0 ; }
void arrangeString ( string str , int x , int y ) { int count_0 = 0 ; int count_1 = 0 ; int len = str . length ( ) ;
for ( int i = 0 ; i < len ; i ++ ) { if ( str [ i ] == '0' ) count_0 ++ ; else count_1 ++ ; }
while ( count_0 > 0 count_1 > 0 ) { for ( int j = 0 ; j < x && count_0 > 0 ; j ++ ) { if ( count_0 > 0 ) { cout << "0" ; count_0 -- ; } } for ( int j = 0 ; j < y && count_1 > 0 ; j ++ ) { if ( count_1 > 0 ) { cout << "1" ; count_1 -- ; } } } }
int main ( ) { string str = "01101101101101101000000" ; int x = 1 ; int y = 2 ; arrangeString ( str , x , y ) ; return 0 ; }
void rearrange ( int arr [ ] , int n ) {
if ( arr == NULL n % 2 == 1 ) return ;
int currIdx = ( n - 1 ) / 2 ;
while ( currIdx > 0 ) { int count = currIdx , swapIdx = currIdx ; while ( count -- > 0 ) { int temp = arr [ swapIdx + 1 ] ; arr [ swapIdx + 1 ] = arr [ swapIdx ] ; arr [ swapIdx ] = temp ; swapIdx ++ ; } currIdx -- ; } }
int main ( ) { int arr [ ] = { 1 , 3 , 5 , 2 , 4 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; rearrange ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << " ▁ " << arr [ i ] ; }
int maxDiff ( int arr [ ] , int n ) {
int maxDiff = -1 ;
int maxRight = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) { if ( arr [ i ] > maxRight ) maxRight = arr [ i ] ; else { int diff = maxRight - arr [ i ] ; if ( diff > maxDiff ) { maxDiff = diff ; } } } return maxDiff ; }
int main ( ) { int arr [ ] = { 1 , 2 , 90 , 10 , 110 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
cout << " Maximum ▁ difference ▁ is ▁ " << maxDiff ( arr , n ) ; return 0 ; }
int maxDiff ( int arr [ ] , int n ) {
int diff = arr [ 1 ] - arr [ 0 ] ; int curr_sum = diff ; int max_sum = curr_sum ; for ( int i = 1 ; i < n - 1 ; i ++ ) {
diff = arr [ i + 1 ] - arr [ i ] ;
if ( curr_sum > 0 ) curr_sum += diff ; else curr_sum = diff ;
if ( curr_sum > max_sum ) max_sum = curr_sum ; } return max_sum ; }
int main ( ) { int arr [ ] = { 80 , 2 , 6 , 3 , 100 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
cout << " Maximum ▁ difference ▁ is ▁ " << maxDiff ( arr , n ) ; return 0 ; }
int maxRepeating ( int * arr , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) arr [ arr [ i ] % k ] += k ;
int max = arr [ 0 ] , result = 0 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; result = i ; } }
return result ; }
int main ( ) { int arr [ ] = { 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 8 ; cout << " The ▁ maximum ▁ repeating ▁ number ▁ is ▁ " << maxRepeating ( arr , n , k ) << endl ; return 0 ; }
int maxPathSum ( int ar1 [ ] , int ar2 [ ] , int m , int n ) {
int i = 0 , j = 0 ;
int result = 0 , sum1 = 0 , sum2 = 0 ;
while ( i < m && j < n ) {
if ( ar1 [ i ] < ar2 [ j ] ) sum1 += ar1 [ i ++ ] ;
else if ( ar1 [ i ] > ar2 [ j ] ) sum2 += ar2 [ j ++ ] ;
else {
result += max ( sum1 , sum2 ) + ar1 [ i ] ;
sum1 = 0 ; sum2 = 0 ;
i ++ ; j ++ ; } }
while ( i < m ) sum1 += ar1 [ i ++ ] ;
while ( j < n ) sum2 += ar2 [ j ++ ] ;
result += max ( sum1 , sum2 ) ; return result ; }
int main ( ) { int ar1 [ ] = { 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 } ; int ar2 [ ] = { 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 } ; int m = sizeof ( ar1 ) / sizeof ( ar1 [ 0 ] ) ; int n = sizeof ( ar2 ) / sizeof ( ar2 [ 0 ] ) ;
cout << " Maximum ▁ sum ▁ path ▁ is ▁ " << maxPathSum ( ar1 , ar2 , m , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void smallestGreater ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) {
int diff = INT_MAX , closest = -1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] < arr [ j ] && arr [ j ] - arr [ i ] < diff ) { diff = arr [ j ] - arr [ i ] ; closest = j ; } }
( closest == -1 ) ? cout << " _ ▁ " : cout << arr [ closest ] << " ▁ " ; } }
int main ( ) { int ar [ ] = { 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; smallestGreater ( ar , n ) ; return 0 ; }
void findZeroes ( int arr [ ] , int n , int m ) {
int wL = 0 , wR = 0 ;
int bestL = 0 , bestWindow = 0 ;
int zeroCount = 0 ;
while ( wR < n ) {
if ( zeroCount <= m ) { if ( arr [ wR ] == 0 ) zeroCount ++ ; wR ++ ; }
if ( zeroCount > m ) { if ( arr [ wL ] == 0 ) zeroCount -- ; wL ++ ; }
if ( ( wR - wL > bestWindow ) && ( zeroCount <= m ) ) { bestWindow = wR - wL ; bestL = wL ; } }
for ( int i = 0 ; i < bestWindow ; i ++ ) { if ( arr [ bestL + i ] == 0 ) cout << bestL + i << " ▁ " ; } }
int main ( ) { int arr [ ] = { 1 , 0 , 0 , 1 , 1 , 0 , 1 , 0 , 1 , 1 } ; int m = 2 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Indexes ▁ of ▁ zeroes ▁ to ▁ be ▁ flipped ▁ are ▁ " ; findZeroes ( arr , n , m ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countIncreasing ( int arr [ ] , int n ) {
int cnt = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] > arr [ j - 1 ] ) cnt ++ ;
else break ; } } return cnt ; }
int main ( ) { int arr [ ] = { 1 , 2 , 2 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is ▁ " << countIncreasing ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countIncreasing ( int arr [ ] , int n ) {
int cnt = 0 ;
int len = 1 ;
for ( int i = 0 ; i < n - 1 ; ++ i ) {
if ( arr [ i + 1 ] > arr [ i ] ) len ++ ;
else { cnt += ( ( ( len - 1 ) * len ) / 2 ) ; len = 1 ; } }
if ( len > 1 ) cnt += ( ( ( len - 1 ) * len ) / 2 ) ; return cnt ; }
int main ( ) { int arr [ ] = { 1 , 2 , 2 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is ▁ " << countIncreasing ( arr , n ) ; return 0 ; }
long long int arraySum ( int arr [ ] , int n ) { long long int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + arr [ i ] ; return sum ; }
long long int maxDiff ( int arr [ ] , int n , int k ) {
sort ( arr , arr + n ) ;
long long int arraysum = arraySum ( arr , n ) ;
long long int diff1 = abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
reverse ( arr , arr + n ) ;
long long int diff2 = abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
return ( max ( diff1 , diff2 ) ) ; }
int main ( ) { int arr [ ] = { 1 , 7 , 4 , 8 , -1 , 5 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; cout << " Maximum ▁ Difference ▁ = ▁ " << maxDiff ( arr , n , k ) ; return 0 ; }
int minNumber ( int a [ ] , int n , int x ) {
sort ( a , a + n ) ; int k ; for ( k = 0 ; a [ ( n - 1 ) / 2 ] != x ; k ++ ) { a [ n ++ ] = x ; sort ( a , a + n ) ; } return k ; }
int main ( ) { int x = 10 ; int a [ 6 ] = { 10 , 20 , 30 } ; int n = 3 ; cout << minNumber ( a , n , x ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int minNumber ( int a [ ] , int n , int x ) { int l = 0 , h = 0 , e = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == x ) e ++ ;
else if ( a [ i ] > x ) h ++ ;
else if ( a [ i ] < x ) l ++ ; } int ans = 0 ; if ( l > h ) ans = l - h ; else if ( l < h ) ans = h - l - 1 ;
return ans + 1 - e ; }
int main ( ) { int x = 10 ; int a [ ] = { 10 , 20 , 30 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << minNumber ( a , n , x ) << endl ; return 0 ; }
int fun ( int x ) { int y = ( x / 4 ) * 4 ;
int ans = 0 ; for ( int i = y ; i <= x ; i ++ ) ans ^= i ; return ans ; }
int query ( int x ) {
if ( x == 0 ) return 0 ; int k = ( x + 1 ) / 2 ;
return ( x %= 2 ) ? 2 * fun ( k ) : ( ( fun ( k - 1 ) * 2 ) ^ ( k & 1 ) ) ; } void allQueries ( int q , int l [ ] , int r [ ] ) { for ( int i = 0 ; i < q ; i ++ ) cout << ( query ( r [ i ] ) ^ query ( l [ i ] - 1 ) ) << endl ; }
int main ( ) { int q = 3 ; int l [ ] = { 2 , 2 , 5 } ; int r [ ] = { 4 , 8 , 9 } ; allQueries ( q , l , r ) ; return 0 ; }
void checkEVENodd ( int arr [ ] , int n , int l , int r ) {
if ( arr [ r ] == 1 ) cout << " odd " << endl ;
else cout < < " even " << endl ; }
int main ( ) { int arr [ ] = { 1 , 1 , 0 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; checkEVENodd ( arr , n , 1 , 3 ) ; return 0 ; }
int findMean ( int arr [ ] , int l , int r ) {
int sum = 0 , count = 0 ;
for ( int i = l ; i <= r ; i ++ ) { sum += arr [ i ] ; count ++ ; }
int mean = floor ( sum / count ) ;
return mean ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; cout << findMean ( arr , 0 , 2 ) << endl ; cout << findMean ( arr , 1 , 3 ) << endl ; cout << findMean ( arr , 0 , 4 ) << endl ; return 0 ; }
int calculateProduct ( int A [ ] , int L , int R , int P ) {
L = L - 1 ; R = R - 1 ; int ans = 1 ; for ( int i = L ; i <= R ; i ++ ) { ans = ans * A [ i ] ; ans = ans % P ; } return ans ; }
int main ( ) { int A [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ; int P = 229 ; int L = 2 , R = 5 ; cout << calculateProduct ( A , L , R , P ) << endl ; L = 1 , R = 3 ; cout << calculateProduct ( A , L , R , P ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 10000 ;
int prefix [ MAX + 1 ] ; void buildPrefix ( ) {
bool prime [ MAX + 1 ] ; memset ( prime , true , sizeof ( prime ) ) ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * 2 ; i <= MAX ; i += p ) prime [ i ] = false ; } }
prefix [ 0 ] = prefix [ 1 ] = 0 ; for ( int p = 2 ; p <= MAX ; p ++ ) { prefix [ p ] = prefix [ p - 1 ] ; if ( prime [ p ] ) prefix [ p ] ++ ; } }
int query ( int L , int R ) { return prefix [ R ] - prefix [ L - 1 ] ; }
int main ( ) { buildPrefix ( ) ; int L = 5 , R = 10 ; cout << query ( L , R ) << endl ; L = 1 , R = 10 ; cout << query ( L , R ) << endl ; return 0 ; }
void command ( bool arr [ ] , int a , int b ) { arr [ a ] ^= 1 ; arr [ b + 1 ] ^= 1 ; }
void process ( bool arr [ ] , int n ) { for ( int k = 1 ; k <= n ; k ++ ) arr [ k ] ^= arr [ k - 1 ] ; }
void result ( bool arr [ ] , int n ) { for ( int k = 1 ; k <= n ; k ++ ) cout << arr [ k ] << " ▁ " ; }
int main ( ) { int n = 5 , m = 3 ; bool arr [ n + 2 ] = { 0 } ;
command ( arr , 1 , 5 ) ; command ( arr , 2 , 5 ) ; command ( arr , 3 , 5 ) ;
process ( arr , n ) ;
result ( arr , n ) ; return 0 ; }
double probability ( int a [ ] , int b [ ] , int size1 , int size2 ) {
int max1 = INT_MIN , count1 = 0 ; for ( int i = 0 ; i < size1 ; i ++ ) { if ( a [ i ] > max1 ) { max1 = a [ i ] ; count1 = 1 ; } else if ( a [ i ] == max1 ) { count1 ++ ; } }
int max2 = INT_MIN , count2 = 0 ; for ( int i = 0 ; i < size2 ; i ++ ) { if ( b [ i ] > max2 ) { max2 = b [ i ] ; count2 = 1 ; } else if ( b [ i ] == max2 ) { count2 ++ ; } }
return ( double ) ( count1 * count2 ) / ( size1 * size2 ) ; }
int main ( ) { int a [ ] = { 1 , 2 , 3 } ; int b [ ] = { 1 , 3 , 3 } ; int size1 = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int size2 = sizeof ( b ) / sizeof ( b [ 0 ] ) ; cout << probability ( a , b , size1 , size2 ) ; return 0 ; }
int countDe ( int arr [ ] , int n ) {
vector < int > v ( arr , arr + n ) ;
sort ( arr , arr + n ) ;
int count1 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count1 ++ ;
reverse ( arr , arr + n ) ;
int count2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count2 ++ ;
return ( min ( count1 , count2 ) ) ; }
int main ( ) { int arr [ ] = { 5 , 9 , 21 , 17 , 13 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ Dearrangement ▁ = ▁ " << countDe ( arr , n ) ; return 0 ; }
int maxOfSegmentMins ( int a [ ] , int n , int k ) {
if ( k == 1 ) return * min_element ( a , a + n ) ; if ( k == 2 ) return max ( a [ 0 ] , a [ n - 1 ] ) ;
return * max_element ( a , a + n ) ; }
int main ( ) { int a [ ] = { -10 , -9 , -8 , 2 , 7 , -6 , -5 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int k = 2 ; cout << maxOfSegmentMins ( a , n , k ) ; }
int printMinimumProduct ( int arr [ ] , int n ) {
int first_min = min ( arr [ 0 ] , arr [ 1 ] ) ; int second_min = max ( arr [ 0 ] , arr [ 1 ] ) ;
for ( int i = 2 ; i < n ; i ++ ) { if ( arr [ i ] < first_min ) { second_min = first_min ; first_min = arr [ i ] ; } else if ( arr [ i ] < second_min ) second_min = arr [ i ] ; } return first_min * second_min ; }
int main ( ) { int a [ ] = { 11 , 8 , 5 , 7 , 5 , 100 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << printMinimumProduct ( a , n ) ; return 0 ; }
long long noOfTriples ( long long arr [ ] , int n ) {
sort ( arr , arr + n ) ;
long long count = 0 ; for ( long long i = 0 ; i < n ; i ++ ) if ( arr [ i ] == arr [ 2 ] ) count ++ ;
if ( arr [ 0 ] == arr [ 2 ] ) return ( count - 2 ) * ( count - 1 ) * ( count ) / 6 ;
else if ( arr [ 1 ] == arr [ 2 ] ) return ( count - 1 ) * ( count ) / 2 ;
return count ; }
int main ( ) { long long arr [ ] = { 1 , 3 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << noOfTriples ( arr , n ) ; return 0 ; }
bool checkReverse ( int arr [ ] , int n ) {
int temp [ n ] ; for ( int i = 0 ; i < n ; i ++ ) temp [ i ] = arr [ i ] ;
sort ( temp , temp + n ) ;
int front ; for ( front = 0 ; front < n ; front ++ ) if ( temp [ front ] != arr [ front ] ) break ;
int back ; for ( back = n - 1 ; back >= 0 ; back -- ) if ( temp [ back ] != arr [ back ] ) break ;
if ( front >= back ) return true ;
do { front ++ ; if ( arr [ front - 1 ] < arr [ front ] ) return false ; } while ( front != back ) ; return true ; }
int main ( ) { int arr [ ] = { 1 , 2 , 5 , 4 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; checkReverse ( arr , n ) ? ( cout << " Yes " << endl ) : ( cout << " No " << endl ) ; return 0 ; }
bool checkReverse ( int arr [ ] , int n ) { if ( n == 1 ) return true ;
int i ; for ( i = 1 ; i < n && arr [ i - 1 ] < arr [ i ] ; i ++ ) ; if ( i == n ) return true ;
int j = i ; while ( j < n && arr [ j ] < arr [ j - 1 ] ) { if ( i > 1 && arr [ j ] < arr [ i - 2 ] ) return false ; j ++ ; } if ( j == n ) return true ;
int k = j ;
if ( arr [ k ] < arr [ i - 1 ] ) return false ; while ( k > 1 && k < n ) { if ( arr [ k ] < arr [ k - 1 ] ) return false ; k ++ ; } return true ; }
int main ( ) { int arr [ ] = { 1 , 3 , 4 , 10 , 9 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; checkReverse ( arr , n ) ? cout << " Yes " : cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int MinOperation ( int a [ ] , int b [ ] , int n ) {
sort ( a , a + n ) ; sort ( b , b + n ) ;
int result = 0 ;
for ( int i = 0 ; i < n ; ++ i ) { result = result + abs ( a [ i ] - b [ i ] ) ; } return result ; }
int main ( ) { int a [ ] = { 3 , 1 , 1 } ; int b [ ] = { 1 , 2 , 2 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << MinOperation ( a , b , n ) ; return 0 ; }
void sortExceptUandL ( int a [ ] , int l , int u , int n ) {
int b [ n - ( u - l + 1 ) ] ; for ( int i = 0 ; i < l ; i ++ ) b [ i ] = a [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) b [ l + ( i - ( u + 1 ) ) ] = a [ i ] ;
sort ( b , b + n - ( u - l + 1 ) ) ;
for ( int i = 0 ; i < l ; i ++ ) a [ i ] = b [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) a [ i ] = b [ l + ( i - ( u + 1 ) ) ] ; }
int main ( ) { int a [ ] = { 5 , 4 , 3 , 12 , 14 , 9 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int l = 2 , u = 4 ; sortExceptUandL ( a , l , u , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << a [ i ] << " ▁ " ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int sortExceptK ( int arr [ ] , int k , int n ) {
swap ( arr [ k ] , arr [ n - 1 ] ) ;
sort ( arr , arr + n - 1 ) ;
int last = arr [ n - 1 ] ;
for ( int i = n - 1 ; i > k ; i -- ) arr [ i ] = arr [ i - 1 ] ;
arr [ k ] = last ; }
int main ( ) { int a [ ] = { 10 , 4 , 11 , 7 , 6 , 20 } ; int k = 2 ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; sortExceptK ( a , k , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << a [ i ] << " ▁ " ; }
int findMinSwaps ( int arr [ ] , int n ) {
int noOfZeroes [ n ] ; memset ( noOfZeroes , 0 , sizeof ( noOfZeroes ) ) ; int i , count = 0 ;
noOfZeroes [ n - 1 ] = 1 - arr [ n - 1 ] ; for ( i = n - 2 ; i >= 0 ; i -- ) { noOfZeroes [ i ] = noOfZeroes [ i + 1 ] ; if ( arr [ i ] == 0 ) noOfZeroes [ i ] ++ ; }
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 1 ) count += noOfZeroes [ i ] ; } return count ; }
int main ( ) { int arr [ ] = { 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findMinSwaps ( arr , n ) ; return 0 ; }
int maxPartitions ( int arr [ ] , int n ) { int ans = 0 , max_so_far = 0 ; for ( int i = 0 ; i < n ; ++ i ) {
max_so_far = max ( max_so_far , arr [ i ] ) ;
if ( max_so_far == i ) ans ++ ; } return ans ; }
int main ( ) { int arr [ ] = { 1 , 0 , 2 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxPartitions ( arr , n ) ; return 0 ; }
void cuttringRopes ( int Ropes [ ] , int n ) {
sort ( Ropes , Ropes + n ) ; int singleOperation = 0 ;
int cuttingLenght = Ropes [ 0 ] ;
for ( int i = 1 ; i < n ; i ++ ) {
if ( Ropes [ i ] - cuttingLenght > 0 ) { cout << ( n - i ) << " ▁ " ;
cuttingLenght = Ropes [ i ] ; singleOperation ++ ; } }
if ( singleOperation == 0 ) cout << "0 ▁ " ; }
int main ( ) { int Ropes [ ] = { 5 , 1 , 1 , 2 , 3 , 5 } ; int n = sizeof ( Ropes ) / sizeof ( Ropes [ 0 ] ) ; cuttringRopes ( Ropes , n ) ; return 0 ; }
void rankify ( int * A , int n ) {
float R [ n ] = { 0 } ;
for ( int i = 0 ; i < n ; i ++ ) { int r = 1 , s = 1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( j != i && A [ j ] < A [ i ] ) r += 1 ; if ( j != i && A [ j ] == A [ i ] ) s += 1 ; }
R [ i ] = r + ( float ) ( s - 1 ) / ( float ) 2 ; } for ( int i = 0 ; i < n ; i ++ ) cout << R [ i ] << ' ▁ ' ; }
int main ( ) { int A [ ] = { 1 , 2 , 5 , 2 , 1 , 25 , 2 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; for ( int i = 0 ; i < n ; i ++ ) cout << A [ i ] << ' ▁ ' ; cout << ' ' ; rankify ( A , n ) ; return 0 ; }
int min_noOf_operation ( int arr [ ] , int n , int k ) { int noOfSubtraction ; int res = 0 ; for ( int i = 1 ; i < n ; i ++ ) { noOfSubtraction = 0 ; if ( arr [ i ] > arr [ i - 1 ] ) {
noOfSubtraction = ( arr [ i ] - arr [ i - 1 ] ) / k ;
if ( ( arr [ i ] - arr [ i - 1 ] ) % k != 0 ) noOfSubtraction ++ ;
arr [ i ] = arr [ i ] - k * noOfSubtraction ; }
res = res + noOfSubtraction ; } return res ; }
int main ( ) { int arr [ ] = { 1 , 1 , 2 , 3 } ; int N = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 5 ; cout << min_noOf_operation ( arr , N , k ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int maxSum ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += ( arr [ i ] * i ) ; return sum ; }
int main ( ) { int arr [ ] = { 3 , 5 , 6 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxSum ( arr , n ) << endl ; return 0 ; }
int countPairs ( int a [ ] , int n , int k ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( abs ( a [ j ] - a [ i ] ) < k ) res ++ ; return res ; }
int main ( ) { int a [ ] = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << countPairs ( a , n , k ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countPairs ( int a [ ] , int n , int k ) {
sort ( a , a + n ) ; int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j = i + 1 ; while ( j < n && a [ j ] - a [ i ] < k ) { res ++ ; j ++ ; } } return res ; }
int main ( ) { int a [ ] = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << countPairs ( a , n , k ) << endl ; return 0 ; }
int sumOfMinAbsDifferences ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int sum = 0 ;
sum += abs ( arr [ 0 ] - arr [ 1 ] ) ;
sum += abs ( arr [ n - 1 ] - arr [ n - 2 ] ) ;
for ( int i = 1 ; i < n - 1 ; i ++ ) sum += min ( abs ( arr [ i ] - arr [ i - 1 ] ) , abs ( arr [ i ] - arr [ i + 1 ] ) ) ;
return sum ; }
int main ( ) { int arr [ ] = { 5 , 10 , 1 , 4 , 8 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Sum ▁ = ▁ " << sumOfMinAbsDifferences ( arr , n ) ; }
int findSmallestDifference ( int A [ ] , int B [ ] , int m , int n ) {
sort ( A , A + m ) ; sort ( B , B + n ) ; int a = 0 , b = 0 ;
int result = INT_MAX ;
while ( a < m && b < n ) { if ( abs ( A [ a ] - B [ b ] ) < result ) result = abs ( A [ a ] - B [ b ] ) ;
if ( A [ a ] < B [ b ] ) a ++ ; else b ++ ; }
return result ; }
int main ( ) {
int A [ ] = { 1 , 2 , 11 , 5 } ;
int B [ ] = { 4 , 12 , 19 , 23 , 127 , 235 } ;
int m = sizeof ( A ) / sizeof ( A [ 0 ] ) ; int n = sizeof ( B ) / sizeof ( B [ 0 ] ) ;
cout << findSmallestDifference ( A , B , m , n ) ; return 0 ; }
void findLarger ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
for ( int i = n - 1 ; i >= n / 2 ; i -- ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 3 , 6 , 1 , 0 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findLarger ( arr , n ) ; return 0 ; }
int findSingle ( int ar [ ] , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
int main ( ) { int ar [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; cout << " Element ▁ occurring ▁ once ▁ is ▁ " << findSingle ( ar , n ) ; return 0 ; }
int countOccurrences ( int arr [ ] , int n , int x ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( x == arr [ i ] ) res ++ ; return res ; }
int main ( ) { int arr [ ] = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 2 ; cout << countOccurrences ( arr , n , x ) ; return 0 ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r < l ) return -1 ; int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
int countOccurrences ( int arr [ ] , int n , int x ) { int ind = binarySearch ( arr , 0 , n - 1 , x ) ;
if ( ind == -1 ) return 0 ;
int count = 1 ; int left = ind - 1 ; while ( left >= 0 && arr [ left ] == x ) count ++ , left -- ;
int right = ind + 1 ; while ( right < n && arr [ right ] == x ) count ++ , right ++ ; return count ; }
int main ( ) { int arr [ ] = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 2 ; cout << countOccurrences ( arr , n , x ) ; return 0 ; }
void printClosest ( int arr [ ] , int n , int x ) {
int res_l , res_r ;
int l = 0 , r = n - 1 , diff = INT_MAX ;
while ( r > l ) {
if ( abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } cout << " ▁ The ▁ closest ▁ pair ▁ is ▁ " << arr [ res_l ] << " ▁ and ▁ " << arr [ res_r ] ; }
int main ( ) { int arr [ ] = { 10 , 22 , 28 , 29 , 30 , 40 } , x = 54 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printClosest ( arr , n , x ) ; return 0 ; }
int countOnes ( bool arr [ ] , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
int main ( ) { bool arr [ ] = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " << countOnes ( arr , 0 , n - 1 ) ; return 0 ; }
int findMissingUtil ( int arr1 [ ] , int arr2 [ ] , int N ) {
if ( N == 1 ) return arr1 [ 0 ] ;
if ( arr1 [ 0 ] != arr2 [ 0 ] ) return arr1 [ 0 ] ;
int lo = 0 , hi = N - 1 ;
while ( lo < hi ) { int mid = ( lo + hi ) / 2 ;
if ( arr1 [ mid ] == arr2 [ mid ] ) lo = mid ; else hi = mid ;
if ( lo == hi - 1 ) break ; }
return arr1 [ hi ] ; }
void findMissing ( int arr1 [ ] , int arr2 [ ] , int M , int N ) { if ( N == M - 1 ) cout << " Missing ▁ Element ▁ is ▁ " << findMissingUtil ( arr1 , arr2 , M ) << endl ; else if ( M == N - 1 ) cout << " Missing ▁ Element ▁ is ▁ " << findMissingUtil ( arr2 , arr1 , N ) << endl ; else cout << " Invalid ▁ Input " ; }
int main ( ) { int arr1 [ ] = { 1 , 4 , 5 , 7 , 9 } ; int arr2 [ ] = { 4 , 5 , 7 , 9 } ; int M = sizeof ( arr1 ) / sizeof ( int ) ; int N = sizeof ( arr2 ) / sizeof ( int ) ; findMissing ( arr1 , arr2 , M , N ) ; return 0 ; }
void findMissing ( int arr1 [ ] , int arr2 [ ] , int M , int N ) { if ( M != N - 1 && N != M - 1 ) { cout << " Invalid ▁ Input " ; return ; }
int res = 0 ; for ( int i = 0 ; i < M ; i ++ ) res = res ^ arr1 [ i ] ; for ( int i = 0 ; i < N ; i ++ ) res = res ^ arr2 [ i ] ; cout << " Missing ▁ element ▁ is ▁ " << res ; }
int main ( ) { int arr1 [ ] = { 4 , 1 , 5 , 9 , 7 } ; int arr2 [ ] = { 7 , 5 , 9 , 4 } ; int M = sizeof ( arr1 ) / sizeof ( int ) ; int N = sizeof ( arr2 ) / sizeof ( int ) ; findMissing ( arr1 , arr2 , M , N ) ; return 0 ; }
void getTwoElements ( int arr [ ] , int n , int * x , int * y ) {
int xor1 ;
int set_bit_no ; int i ; * x = 0 ; * y = 0 ; xor1 = arr [ 0 ] ;
for ( i = 1 ; i < n ; i ++ ) xor1 = xor1 ^ arr [ i ] ;
for ( i = 1 ; i <= n ; i ++ ) xor1 = xor1 ^ i ;
set_bit_no = xor1 & ~ ( xor1 - 1 ) ;
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] & set_bit_no )
* x = * x ^ arr [ i ] ; else
* y = * y ^ arr [ i ] ; } for ( i = 1 ; i <= n ; i ++ ) { if ( i & set_bit_no )
* x = * x ^ i ; else
* y = * y ^ i ; }
}
int main ( ) { int arr [ ] = { 1 , 3 , 4 , 5 , 5 , 6 , 2 } ; int * x = ( int * ) malloc ( sizeof ( int ) ) ; int * y = ( int * ) malloc ( sizeof ( int ) ) ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; getTwoElements ( arr , n , x , y ) ; cout << " ▁ The ▁ missing ▁ element ▁ is ▁ " << * x << " ▁ and ▁ the ▁ repeating " << " ▁ number ▁ is ▁ " << * y ; getchar ( ) ; }
int search ( int arr [ ] , int n , int x ) {
int i = 0 ; while ( i < n ) {
if ( arr [ i ] == x ) return i ;
i = i + abs ( arr [ i ] - x ) ; } cout << " number ▁ is ▁ not ▁ present ! " ; return -1 ; }
int main ( ) { int arr [ ] = { 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 3 ; cout << " Element ▁ " << x << " ▁ is ▁ present ▁ at ▁ index ▁ " << search ( arr , n , 3 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE void thirdLargest ( int arr [ ] , int arr_size ) {
if ( arr_size < 3 ) { printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] ; for ( int i = 1 ; i < arr_size ; i ++ ) if ( arr [ i ] > first ) first = arr [ i ] ;
int second = INT_MIN ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > second && arr [ i ] < first ) second = arr [ i ] ;
int third = INT_MIN ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > third && arr [ i ] < second ) third = arr [ i ] ; printf ( " The ▁ third ▁ Largest ▁ element ▁ is ▁ % d STRNEWLINE " , third ) ; }
int main ( ) { int arr [ ] = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; thirdLargest ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE void thirdLargest ( int arr [ ] , int arr_size ) {
if ( arr_size < 3 ) { printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] , second = INT_MIN , third = INT_MIN ;
for ( int i = 1 ; i < arr_size ; i ++ ) {
if ( arr [ i ] > first ) { third = second ; second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) { third = second ; second = arr [ i ] ; }
else if ( arr [ i ] > third ) third = arr [ i ] ; } printf ( " The ▁ third ▁ Largest ▁ element ▁ is ▁ % d STRNEWLINE " , third ) ; }
int main ( ) { int arr [ ] = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; thirdLargest ( arr , n ) ; return 0 ; }
bool checkPair ( int arr [ ] , int n ) {
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += arr [ i ] ;
if ( sum % 2 != 0 ) return false ; sum = sum / 2 ;
unordered_set < int > s ; for ( int i = 0 ; i < n ; i ++ ) { int val = sum - arr [ i ] ;
if ( s . find ( val ) != s . end ( ) ) { printf ( " Pair ▁ elements ▁ are ▁ % d ▁ and ▁ % d STRNEWLINE " , arr [ i ] , val ) ; return true ; } s . insert ( arr [ i ] ) ; } return false ; }
int main ( ) { int arr [ ] = { 2 , 11 , 5 , 1 , 4 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( checkPair ( arr , n ) == false ) printf ( " No ▁ pair ▁ found " ) ; return 0 ; }
string search ( int arr [ ] , int n , int x ) {
if ( arr [ n - 1 ] == x ) return " Found " ; int backup = arr [ n - 1 ] ; arr [ n - 1 ] = x ;
for ( int i = 0 ; ; i ++ ) {
if ( arr [ i ] == x ) {
arr [ n - 1 ] = backup ;
if ( i < n - 1 ) return " Found " ;
return " Not ▁ Found " ; } } }
int main ( ) { int arr [ ] = { 4 , 6 , 1 , 5 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 1 ; cout << search ( arr , n , x ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; int findMajority ( int arr [ ] , int n ) { return arr [ n / 2 ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 2 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findMajority ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void minAdjDifference ( int arr [ ] , int n ) { if ( n < 2 ) return ;
int res = abs ( arr [ 1 ] - arr [ 0 ] ) ; for ( int i = 2 ; i < n ; i ++ ) res = min ( res , abs ( arr [ i ] - arr [ i - 1 ] ) ) ;
res = min ( res , abs ( arr [ n - 1 ] - arr [ 0 ] ) ) ; cout << " Min ▁ Difference ▁ = ▁ " << res ; }
int main ( ) { int a [ ] = { 10 , 12 , 13 , 15 , 10 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; minAdjDifference ( a , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  100000 NEW_LINE using namespace std ; int Print3Smallest ( int array [ ] , int n ) { int firstmin = MAX , secmin = MAX , thirdmin = MAX ; for ( int i = 0 ; i < n ; i ++ ) {
if ( array [ i ] < firstmin ) { thirdmin = secmin ; secmin = firstmin ; firstmin = array [ i ] ; }
else if ( array [ i ] < secmin ) { thirdmin = secmin ; secmin = array [ i ] ; }
else if ( array [ i ] < thirdmin ) thirdmin = array [ i ] ; } cout << " First ▁ min ▁ = ▁ " << firstmin << " STRNEWLINE " ; cout << " Second ▁ min ▁ = ▁ " << secmin << " STRNEWLINE " ; cout << " Third ▁ min ▁ = ▁ " << thirdmin << " STRNEWLINE " ; }
int main ( ) { int array [ ] = { 4 , 9 , 1 , 32 , 12 } ; int n = sizeof ( array ) / sizeof ( array [ 0 ] ) ; Print3Smallest ( array , n ) ; return 0 ; }
int getMin ( int arr [ ] , int n ) { return * min_element ( arr , arr + n ) ; } int getMax ( int arr [ ] , int n ) { return * max_element ( arr , arr + n ) ; }
int main ( ) { int arr [ ] = { 12 , 1234 , 45 , 67 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ element ▁ of ▁ array : ▁ " << getMin ( arr , n ) << " STRNEWLINE " ; cout << " Maximum ▁ element ▁ of ▁ array : ▁ " << getMax ( arr , n ) ; return 0 ; }
void printfrequency ( int arr [ ] , int n ) {
for ( int j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] - 1 ;
for ( int i = 0 ; i < n ; i ++ ) arr [ arr [ i ] % n ] = arr [ arr [ i ] % n ] + n ;
for ( int i = 0 ; i < n ; i ++ ) cout << i + 1 << " ▁ - > ▁ " << arr [ i ] / n << endl ; }
int main ( ) { int arr [ ] = { 2 , 3 , 3 , 2 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printfrequency ( arr , n ) ; return 0 ; }
int getInvCount ( int arr [ ] , int n ) {
int invcount = 0 ; for ( int i = 1 ; i < n - 1 ; i ++ ) {
int small = 0 ; for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) small ++ ;
int great = 0 ; for ( int j = i - 1 ; j >= 0 ; j -- ) if ( arr [ i ] < arr [ j ] ) great ++ ;
invcount += great * small ; } return invcount ; }
int main ( ) { int arr [ ] = { 8 , 4 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Inversion ▁ Count ▁ : ▁ " << getInvCount ( arr , n ) ; return 0 ; }
int findWater ( int arr [ ] , int n ) {
int water = 0 ;
left [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) left [ i ] = max ( left [ i - 1 ] , arr [ i ] ) ;
right [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) right [ i ] = max ( right [ i + 1 ] , arr [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) water += min ( left [ i ] , right [ i ] ) - arr [ i ] ; return water ; }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " << findWater ( arr , n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; int findWater ( int arr [ ] , int n ) {
int result = 0 ;
int left_max = 0 , right_max = 0 ;
int lo = 0 , hi = n - 1 ; while ( lo <= hi ) { if ( arr [ lo ] < arr [ hi ] ) { if ( arr [ lo ] > left_max )
left_max = arr [ lo ] ; else
result += left_max - arr [ lo ] ; lo ++ ; } else { if ( arr [ hi ] > right_max )
right_max = arr [ hi ] ; else result += right_max - arr [ hi ] ; hi -- ; } } return result ; }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " << findWater ( arr , n ) ; }
int missingK ( int a [ ] , int k , int n ) { int difference = 0 , ans = 0 , count = k ; bool flag = 0 ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { difference = 0 ;
if ( ( a [ i ] + 1 ) != a [ i + 1 ] ) {
difference += ( a [ i + 1 ] - a [ i ] ) - 1 ;
if ( difference >= count ) { ans = a [ i ] + count ; flag = 1 ; break ; } else count -= difference ; } }
if ( flag ) return ans ; else return -1 ; }
int a [ ] = { 1 , 5 , 11 , 19 } ;
int k = 11 ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
int missing = missingK ( a , k , n ) ; cout << missing << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void printUncommon ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) { int i = 0 , j = 0 , k = 0 ; while ( i < n1 && j < n2 ) {
if ( arr1 [ i ] < arr2 [ j ] ) { cout << arr1 [ i ] << " ▁ " ; i ++ ; k ++ ; } else if ( arr2 [ j ] < arr1 [ i ] ) { cout << arr2 [ j ] << " ▁ " ; k ++ ; j ++ ; }
else { i ++ ; j ++ ; } }
while ( i < n1 ) { cout << arr1 [ i ] << " ▁ " ; i ++ ; k ++ ; } while ( j < n2 ) { cout << arr2 [ j ] << " ▁ " ; j ++ ; k ++ ; } }
int main ( ) { int arr1 [ ] = { 10 , 20 , 30 } ; int arr2 [ ] = { 20 , 25 , 30 , 40 , 50 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; printUncommon ( arr1 , arr2 , n1 , n2 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int leastFrequent ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int min_count = n + 1 , res = -1 , curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
int main ( ) { int arr [ ] = { 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << leastFrequent ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define M  4 NEW_LINE using namespace std ;
int maximumSum ( int a [ ] [ M ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) sort ( a [ i ] , a [ i ] + M ) ;
int sum = a [ n - 1 ] [ M - 1 ] ; int prev = a [ n - 1 ] [ M - 1 ] ; int i , j ;
for ( i = n - 2 ; i >= 0 ; i -- ) { for ( j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i ] [ j ] < prev ) { prev = a [ i ] [ j ] ; sum += prev ; break ; } }
if ( j == -1 ) return 0 ; } return sum ; }
int main ( ) { int arr [ ] [ M ] = { { 1 , 7 , 3 , 4 } , { 4 , 2 , 5 , 1 } , { 9 , 5 , 1 , 8 } } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maximumSum ( arr , n ) ; return 0 ; }
int countPairs ( int A [ ] , int n , int k ) { int ans = 0 ;
sort ( A , A + n ) ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int x = 0 ;
while ( ( A [ i ] * pow ( k , x ) ) <= A [ j ] ) { if ( ( A [ i ] * pow ( k , x ) ) == A [ j ] ) { ans ++ ; break ; } x ++ ; } } } return ans ; }
int main ( ) { int A [ ] = { 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; int k = 3 ; cout << countPairs ( A , n , k ) ; return 0 ; }
int findValue ( int a [ ] , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] == k ) k *= 2 ; } return k ; }
int main ( ) { int arr [ ] = { 2 , 3 , 4 , 10 , 8 , 1 } , k = 2 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findValue ( arr , n , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE void dupLastIndex ( int arr [ ] , int n ) {
if ( arr == NULL n <= 0 ) return ;
for ( int i = n - 1 ; i > 0 ; i -- ) { if ( arr [ i ] == arr [ i - 1 ] ) { printf ( " Last ▁ index : ▁ % d STRNEWLINE Last ▁ " " duplicate ▁ item : ▁ % d STRNEWLINE " , i , arr [ i ] ) ; return ; } }
printf ( " no ▁ duplicate ▁ found " ) ; }
int main ( ) { int arr [ ] = { 1 , 5 , 5 , 6 , 6 , 7 , 9 } ; int n = sizeof ( arr ) / sizeof ( int ) ; dupLastIndex ( arr , n ) ; return 0 ; }
int findSmallest ( int a [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < n ; j ++ ) if ( a [ j ] % a [ i ] ) break ;
if ( j == n ) return a [ i ] ; } return -1 ; }
int main ( ) { int a [ ] = { 25 , 20 , 5 , 10 , 100 } ; int n = sizeof ( a ) / sizeof ( int ) ; cout << findSmallest ( a , n ) ; return 0 ; }
int findSmallest ( int a [ ] , int n ) {
int smallest = * min_element ( a , a + n ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( a [ i ] % smallest ) return -1 ; return smallest ; }
int main ( ) { int a [ ] = { 25 , 20 , 5 , 10 , 100 } ; int n = sizeof ( a ) / sizeof ( int ) ; cout << findSmallest ( a , n ) ; return 0 ; }
int findIndex ( int arr [ ] , int len ) {
int maxIndex = 0 ; for ( int i = 0 ; i < len ; ++ i ) if ( arr [ i ] > arr [ maxIndex ] ) maxIndex = i ;
for ( int i = 0 ; i < len ; ++ i ) if ( maxIndex != i && arr [ maxIndex ] < 2 * arr [ i ] ) return -1 ; return maxIndex ; }
int main ( ) { int arr [ ] = { 3 , 6 , 1 , 0 } ; int len = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << ( findIndex ( arr , len ) ) ; }
int find_consecutive_steps ( int arr [ ] , int len ) { int count = 0 ; int maximum = 0 ; for ( int index = 1 ; index < len ; index ++ ) {
if ( arr [ index ] > arr [ index - 1 ] ) count ++ ; else { maximum = max ( maximum , count ) ; count = 0 ; } } return max ( maximum , count ) ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int len = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << find_consecutive_steps ( arr , len ) ; }
#include <bits/stdc++.h> NEW_LINE #define ll  long long int NEW_LINE using namespace std ; ll CalculateMax ( ll arr [ ] , int n ) {
sort ( arr , arr + n ) ; int min_sum = arr [ 0 ] + arr [ 1 ] ; int max_sum = arr [ n - 1 ] + arr [ n - 2 ] ; return abs ( max_sum - min_sum ) ; }
int main ( ) { ll arr [ ] = { 6 , 7 , 1 , 11 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << CalculateMax ( arr , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define ll  long long int NEW_LINE using namespace std ; ll calculate ( ll a [ ] , ll n ) {
sort ( a , a + n ) ;
vector < ll > s ; for ( int i = 0 , j = n - 1 ; i < j ; i ++ , j -- ) s . push_back ( a [ i ] + a [ j ] ) ; ll mini = * min_element ( s . begin ( ) , s . end ( ) ) ; ll maxi = * max_element ( s . begin ( ) , s . end ( ) ) ; return abs ( maxi - mini ) ; }
int main ( ) { ll a [ ] = { 2 , 6 , 4 , 3 } ; int n = sizeof ( a ) / ( sizeof ( a [ 0 ] ) ) ; cout << calculate ( a , n ) << endl ; return 0 ; }
void printMinDiffPairs ( int arr [ ] , int n ) { if ( n <= 1 ) return ;
sort ( arr , arr + n ) ;
int minDiff = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) minDiff = min ( minDiff , arr [ i ] - arr [ i - 1 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( ( arr [ i ] - arr [ i - 1 ] ) == minDiff ) cout << " ( " << arr [ i - 1 ] << " , ▁ " << arr [ i ] << " ) , ▁ " ; }
int main ( ) { int arr [ ] = { 5 , 3 , 2 , 4 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printMinDiffPairs ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int calculateDiff ( int i , int j , int arr [ ] ) {
return abs ( arr [ i ] - arr [ j ] ) + abs ( i - j ) ; }
int maxDistance ( int arr [ ] , int n ) {
int result = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i ; j < n ; j ++ ) {
if ( calculateDiff ( i , j , arr ) > result ) result = calculateDiff ( i , j , arr ) ; } } return result ; }
int main ( ) { int arr [ ] = { -70 , -64 , -6 , -56 , 64 , 61 , -57 , 16 , 48 , -98 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxDistance ( arr , n ) << endl ; return 0 ; }
int maxDistance ( int arr [ ] , int n ) {
int max1 = INT_MIN , min1 = INT_MAX ; int max2 = INT_MIN , min2 = INT_MAX ; for ( int i = 0 ; i < n ; i ++ ) {
max1 = max ( max1 , arr [ i ] + i ) ; min1 = min ( min1 , arr [ i ] + i ) ; max2 = max ( max2 , arr [ i ] - i ) ; min2 = min ( min2 , arr [ i ] - i ) ; }
return max ( max1 - min1 , max2 - min2 ) ; }
int main ( ) { int arr [ ] = { -70 , -64 , -6 , -56 , 64 , 61 , -57 , 16 , 48 , -98 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxDistance ( arr , n ) << endl ; return 0 ; }
int extrema ( int a [ ] , int n ) { int count = 0 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
count += ( a [ i ] > a [ i - 1 ] && a [ i ] > a [ i + 1 ] ) ;
count += ( a [ i ] < a [ i - 1 ] && a [ i ] < a [ i + 1 ] ) ; } return count ; }
int main ( ) { int a [ ] = { 1 , 0 , 2 , 1 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << extrema ( a , n ) ; return 0 ; }
int findClosest ( int arr [ ] , int n , int target ) {
if ( target <= arr [ 0 ] ) return arr [ 0 ] ; if ( target >= arr [ n - 1 ] ) return arr [ n - 1 ] ;
int i = 0 , j = n , mid = 0 ; while ( i < j ) { mid = ( i + j ) / 2 ; if ( arr [ mid ] == target ) return arr [ mid ] ;
if ( target < arr [ mid ] ) {
if ( mid > 0 && target > arr [ mid - 1 ] ) return getClosest ( arr [ mid - 1 ] , arr [ mid ] , target ) ;
j = mid ; }
else { if ( mid < n - 1 && target < arr [ mid + 1 ] ) return getClosest ( arr [ mid ] , arr [ mid + 1 ] , target ) ;
i = mid + 1 ; } }
return arr [ mid ] ; }
int getClosest ( int val1 , int val2 , int target ) { if ( target - val1 >= val2 - target ) return val2 ; else return val1 ; }
int main ( ) { int arr [ ] = { 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int target = 11 ; cout << ( findClosest ( arr , n , target ) ) ; }
int sum ( int a [ ] , int n ) {
int maxSum = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) maxSum = max ( maxSum , a [ i ] + a [ j ] ) ;
int c = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( a [ i ] + a [ j ] == maxSum ) c ++ ; return c ; }
int main ( ) { int array [ ] = { 1 , 1 , 1 , 2 , 2 , 2 } ; int n = sizeof ( array ) / sizeof ( array [ 0 ] ) ; cout << sum ( array , n ) ; return 0 ; }
int sum ( int a [ ] , int n ) {
int maxVal = a [ 0 ] , maxCount = 1 ; int secondMax = INT_MIN , secondMaxCount ; for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == maxVal ) maxCount ++ ; else if ( a [ i ] > maxVal ) { secondMax = maxVal ; secondMaxCount = maxCount ; maxVal = a [ i ] ; maxCount = 1 ; } else if ( a [ i ] == secondMax ) { secondMax = a [ i ] ; secondMaxCount ++ ; } else if ( a [ i ] > secondMax ) { secondMax = a [ i ] ; secondMaxCount = 1 ; } }
if ( maxCount > 1 ) return maxCount * ( maxCount - 1 ) / 2 ;
return secondMaxCount ; }
int main ( ) { int array [ ] = { 1 , 1 , 1 , 2 , 2 , 2 , 3 } ; int n = sizeof ( array ) / sizeof ( array [ 0 ] ) ; cout << sum ( array , n ) ; return 0 ; }
void printKMissing ( int arr [ ] , int n , int k ) { sort ( arr , arr + n ) ;
int i = 0 ; while ( i < n && arr [ i ] <= 0 ) i ++ ;
int count = 0 , curr = 1 ; while ( count < k && i < n ) { if ( arr [ i ] != curr ) { cout << curr << " ▁ " ; count ++ ; } else i ++ ; curr ++ ; }
while ( count < k ) { cout << curr << " ▁ " ; curr ++ ; count ++ ; } }
int main ( ) { int arr [ ] = { 2 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; printKMissing ( arr , n , k ) ; return 0 ; }
int nobleInteger ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( arr [ i ] < arr [ j ] ) count ++ ;
if ( count == arr [ i ] ) return arr [ i ] ; } return -1 ; }
int main ( ) { int arr [ ] = { 10 , 3 , 20 , 40 , 2 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int res = nobleInteger ( arr , size ) ; if ( res != -1 ) cout << " The ▁ noble ▁ integer ▁ is ▁ " << res ; else cout << " No ▁ Noble ▁ Integer ▁ Found " ; }
int nobleInteger ( int arr [ ] , int n ) { sort ( arr , arr + n ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] == arr [ i + 1 ] ) continue ;
if ( arr [ i ] == n - i - 1 ) return arr [ i ] ; } if ( arr [ n - 1 ] == 0 ) return arr [ n - 1 ] ; return -1 ; }
int main ( ) { int arr [ ] = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr , 5 ) ; if ( res != -1 ) cout << " The ▁ noble ▁ integer ▁ is ▁ " << res ; else cout << " No ▁ Noble ▁ Integer ▁ Found " ; return 0 ; }
long long int findMinSum ( long long int a [ ] , long long int b [ ] , int n ) {
sort ( a , a + n ) ; sort ( b , b + n ) ;
long long int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + abs ( a [ i ] - b [ i ] ) ; return sum ; }
long long int a [ ] = { 4 , 1 , 8 , 7 } ; long long int b [ ] = { 2 , 3 , 6 , 5 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; printf ( " % lld STRNEWLINE " , findMinSum ( a , b , n ) ) ; return 0 ; }
bool checkIsAP ( int arr [ ] , int n ) { if ( n == 1 ) return true ;
sort ( arr , arr + n ) ;
int d = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] != d ) return false ; return true ; }
int main ( ) { int arr [ ] = { 20 , 15 , 5 , 0 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; ( checkIsAP ( arr , n ) ) ? ( cout << " Yes " << endl ) : ( cout << " No " << endl ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int minProductSubset ( int a [ ] , int n ) { if ( n == 1 ) return a [ 0 ] ;
int max_neg = INT_MIN ; int min_pos = INT_MAX ; int count_neg = 0 , count_zero = 0 ; int prod = 1 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == 0 ) { count_zero ++ ; continue ; }
if ( a [ i ] < 0 ) { count_neg ++ ; max_neg = max ( max_neg , a [ i ] ) ; }
if ( a [ i ] > 0 ) min_pos = min ( min_pos , a [ i ] ) ; prod = prod * a [ i ] ; }
if ( count_zero == n || ( count_neg == 0 && count_zero > 0 ) ) return 0 ;
if ( count_neg == 0 ) return min_pos ;
if ( ! ( count_neg & 1 ) && count_neg != 0 ) {
prod = prod / max_neg ; } return prod ; }
int main ( ) { int a [ ] = { -1 , -1 , -2 , 4 , 3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << minProductSubset ( a , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countPairs ( int a [ ] , int n ) {
int mn = INT_MAX ; int mx = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) { mn = min ( mn , a [ i ] ) ; mx = max ( mx , a [ i ] ) ; }
int c1 = 0 ;
int c2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] == mn ) c1 ++ ; if ( a [ i ] == mx ) c2 ++ ; }
if ( mn == mx ) return n * ( n - 1 ) / 2 ; else return c1 * c2 ; }
int main ( ) { int a [ ] = { 3 , 2 , 1 , 1 , 3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << countPairs ( a , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int findElement ( int a [ ] , int n , int b ) {
sort ( a , a + n ) ;
int max = a [ n - 1 ] ; while ( b < max ) {
if ( binary_search ( a , a + n , b ) ) b *= 2 ; else return b ; } return b ; }
int main ( ) { int a [ ] = { 1 , 2 , 3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int b = 1 ; cout << findElement ( a , n , b ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define Mod  1000000007 NEW_LINE using namespace std ;
long long int findSum ( int arr [ ] , int n ) { long long int sum = 0 ;
sort ( arr , arr + n ) ;
int i = 0 ; while ( i < n && arr [ i ] < 0 ) { if ( i != n - 1 && arr [ i + 1 ] <= 0 ) { sum = ( sum + ( arr [ i ] * arr [ i + 1 ] ) % Mod ) % Mod ; i += 2 ; } else break ; }
int j = n - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { if ( j != 0 && arr [ j - 1 ] > 0 ) { sum = ( sum + ( arr [ j ] * arr [ j - 1 ] ) % Mod ) % Mod ; j -= 2 ; } else break ; }
if ( j > i ) sum = ( sum + ( arr [ i ] * arr [ j ] ) % Mod ) % Mod ;
else if ( i == j ) sum = ( sum + arr [ i ] ) % Mod ; return sum ; }
int main ( ) { int arr [ ] = { -1 , 9 , 4 , 5 , -4 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findSum ( arr , n ) ; return 0 ; }
void countOddRotations ( int n ) { int odd_count = 0 , even_count = 0 ; do { int digit = n % 10 ; if ( digit % 2 == 1 ) odd_count ++ ; else even_count ++ ; n = n / 10 ; } while ( n != 0 ) ; cout << " Odd ▁ = ▁ " << odd_count << endl ; cout << " Even ▁ = ▁ " << even_count << endl ; }
int main ( ) { int n = 1234 ; countOddRotations ( n ) ; }
int numberOfDigits ( int n ) { int cnt = 0 ; while ( n > 0 ) { cnt ++ ; n /= 10 ; } return cnt ; }
void cal ( int num ) { int digits = numberOfDigits ( num ) ; int powTen = pow ( 10 , digits - 1 ) ; for ( int i = 0 ; i < digits - 1 ; i ++ ) { int firstDigit = num / powTen ;
int left = ( ( num * 10 ) + firstDigit ) - ( firstDigit * powTen * 10 ) ; cout << left << " ▁ " ;
num = left ; } }
int main ( ) { int num = 1445 ; cal ( num ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void CheckKCycles ( int n , string s ) { bool ff = true ; int x = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
x = ( s . substr ( i ) + s . substr ( 0 , i ) ) . length ( ) ;
if ( x >= s . length ( ) ) { continue ; } ff = false ; break ; } if ( ff ) { cout << ( " Yes " ) ; } else { cout << ( " No " ) ; } }
int main ( ) { int n = 3 ; string s = "123" ; CheckKCycles ( n , s ) ; return 0 ; }
bool rightRotationDivisor ( int N ) { int lastDigit = N % 10 ; int rightRotation = ( lastDigit * pow ( 10 , int ( log10 ( N ) ) ) ) + floor ( N / 10 ) ; return ( rightRotation % N == 0 ) ; }
void generateNumbers ( int m ) { for ( int i = pow ( 10 , ( m - 1 ) ) ; i < pow ( 10 , m ) ; i ++ ) if ( rightRotationDivisor ( i ) ) cout << i << endl ; }
int main ( ) { int m = 3 ; generateNumbers ( m ) ; }
void checkIfSortRotated ( int arr [ ] , int n ) { int minEle = INT_MAX ; int maxEle = INT_MIN ; int minIndex = -1 ;
for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < minEle ) { minEle = arr [ i ] ; minIndex = i ; } } int flag1 = 1 ;
for ( int i = 1 ; i < minIndex ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag1 = 0 ; break ; } } int flag2 = 1 ;
for ( int i = minIndex + 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag2 = 0 ; break ; } }
if ( flag1 && flag2 && ( arr [ n - 1 ] < arr [ 0 ] ) ) cout << " YES " ; else cout << " NO " ; }
int main ( ) { int arr [ ] = { 3 , 4 , 5 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
checkIfSortRotated ( arr , n ) ; return 0 ; }
void occurredOnce ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
if ( arr [ 0 ] != arr [ 1 ] ) cout << arr [ 0 ] << " ▁ " ;
for ( int i = 1 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i - 1 ] ) cout << arr [ i ] << " ▁ " ;
if ( arr [ n - 2 ] != arr [ n - 1 ] ) cout << arr [ n - 1 ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; occurredOnce ( arr , n ) ; return 0 ; }
void occurredOnce ( int arr [ ] , int n ) { int i = 1 , len = n ;
if ( arr [ 0 ] == arr [ len - 1 ] ) { i = 2 ; len -- ; }
for ( ; i < n ; i ++ )
if ( arr [ i ] == arr [ i - 1 ] ) i ++ ;
else cout < < arr [ i - 1 ] << " ▁ " ;
if ( arr [ n - 1 ] != arr [ 0 ] && arr [ n - 1 ] != arr [ n - 2 ] ) cout << arr [ n - 1 ] ; }
int main ( ) { int arr [ ] = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; occurredOnce ( arr , n ) ; return 0 ; }
void rvereseArray ( int arr [ ] , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) cout << arr [ i ] << " ▁ " ; }
void splitArr ( int arr [ ] , int k , int n ) { rvereseArray ( arr , 0 , n - 1 ) ; rvereseArray ( arr , 0 , n - k - 1 ) ; rvereseArray ( arr , n - k , n - 1 ) ; }
int main ( ) { int arr [ ] = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 2 ;
splitArr ( arr , k , n ) ; printArray ( arr , n ) ; return 0 ; }
int countRotationsDivBy8 ( string n ) { int len = n . length ( ) ; int count = 0 ;
if ( len == 1 ) { int oneDigit = n [ 0 ] - '0' ; if ( oneDigit % 8 == 0 ) return 1 ; return 0 ; }
if ( len == 2 ) {
int first = ( n [ 0 ] - '0' ) * 10 + ( n [ 1 ] - '0' ) ;
int second = ( n [ 1 ] - '0' ) * 10 + ( n [ 0 ] - '0' ) ; if ( first % 8 == 0 ) count ++ ; if ( second % 8 == 0 ) count ++ ; return count ; }
int threeDigit ; for ( int i = 0 ; i < ( len - 2 ) ; i ++ ) { threeDigit = ( n [ i ] - '0' ) * 100 + ( n [ i + 1 ] - '0' ) * 10 + ( n [ i + 2 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ; }
threeDigit = ( n [ len - 1 ] - '0' ) * 100 + ( n [ 0 ] - '0' ) * 10 + ( n [ 1 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
threeDigit = ( n [ len - 2 ] - '0' ) * 100 + ( n [ len - 1 ] - '0' ) * 10 + ( n [ 0 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
return count ; }
int main ( ) { string n = "43262488612" ; cout << " Rotations : ▁ " << countRotationsDivBy8 ( n ) ; return 0 ; }
int findRotations ( string str ) {
string tmp = str + str ; int n = str . length ( ) ; for ( int i = 1 ; i <= n ; i ++ ) {
string substring = tmp . substr ( i , str . size ( ) ) ;
if ( str == substring ) return i ; } return n ; }
int main ( ) { string str = " abc " ; cout << findRotations ( str ) << endl ; return 0 ; }
bool isRotation ( unsigned int x , unsigned int y ) {
unsigned long long int x64 = x | ( ( unsigned long long int ) x << 32 ) ; while ( x64 >= y ) {
if ( unsigned ( x64 ) == y ) return true ;
x64 >>= 1 ; } return false ; }
int main ( ) { unsigned int x = 122 ; unsigned int y = 2147483678 ; if ( isRotation ( x , y ) ) cout << " yes " << endl ; else cout << " no " << endl ; return 0 ; }
int countRotations ( string n ) { int len = n . length ( ) ;
if ( len == 1 ) { int oneDigit = n . at ( 0 ) - '0' ; if ( oneDigit % 4 == 0 ) return 1 ; return 0 ; }
int twoDigit , count = 0 ; for ( int i = 0 ; i < ( len - 1 ) ; i ++ ) { twoDigit = ( n . at ( i ) - '0' ) * 10 + ( n . at ( i + 1 ) - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; }
twoDigit = ( n . at ( len - 1 ) - '0' ) * 10 + ( n . at ( 0 ) - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; return count ; }
int main ( ) { string n = "4834" ; cout << " Rotations : ▁ " << countRotations ( n ) << endl ; return 0 ; }
int solve ( int A [ ] , int n ) { int i , cnt = 0 , j ;
int parent [ n + 1 ] ;
int vis [ n + 1 ] ;
memset ( parent , -1 , sizeof ( parent ) ) ; memset ( vis , 0 , sizeof ( vis ) ) ; for ( i = 0 ; i < n ; i ++ ) { j = i ;
if ( parent [ j ] == -1 ) {
while ( parent [ j ] == -1 ) { parent [ j ] = i ; j = ( j + A [ j ] + 1 ) % n ; }
if ( parent [ j ] == i ) {
while ( ! vis [ j ] ) { vis [ j ] = 1 ; cnt ++ ; j = ( j + A [ j ] + 1 ) % n ; } } } } return cnt ; }
int main ( ) { int A [ ] = { 0 , 0 , 0 , 2 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; cout << solve ( A , n ) ; return 0 ; }
void TOWUtil ( int * arr , int n , bool * curr_elements , int no_of_selected_elements , bool * soln , int * min_diff , int sum , int curr_sum , int curr_position ) {
if ( curr_position == n ) return ;
if ( ( n / 2 - no_of_selected_elements ) > ( n - curr_position ) ) return ;
TOWUtil ( arr , n , curr_elements , no_of_selected_elements , soln , min_diff , sum , curr_sum , curr_position + 1 ) ;
no_of_selected_elements ++ ; curr_sum = curr_sum + arr [ curr_position ] ; curr_elements [ curr_position ] = true ;
if ( no_of_selected_elements == n / 2 ) {
if ( abs ( sum / 2 - curr_sum ) < * min_diff ) { * min_diff = abs ( sum / 2 - curr_sum ) ; for ( int i = 0 ; i < n ; i ++ ) soln [ i ] = curr_elements [ i ] ; } } else {
TOWUtil ( arr , n , curr_elements , no_of_selected_elements , soln , min_diff , sum , curr_sum , curr_position + 1 ) ; }
curr_elements [ curr_position ] = false ; }
void tugOfWar ( int * arr , int n ) {
bool * curr_elements = new bool [ n ] ;
bool * soln = new bool [ n ] ; int min_diff = INT_MAX ; int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum += arr [ i ] ; curr_elements [ i ] = soln [ i ] = false ; }
TOWUtil ( arr , n , curr_elements , 0 , soln , & min_diff , sum , 0 , 0 ) ;
cout << " The ▁ first ▁ subset ▁ is : ▁ " ; for ( int i = 0 ; i < n ; i ++ ) { if ( soln [ i ] == true ) cout << arr [ i ] << " ▁ " ; } cout << " The second subset is : " for ( int i = 0 ; i < n ; i ++ ) { if ( soln [ i ] == false ) cout << arr [ i ] << " ▁ " ; } }
int main ( ) { int arr [ ] = { 23 , 45 , -34 , 12 , 0 , 98 , -99 , 4 , 189 , -1 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; tugOfWar ( arr , n ) ; return 0 ; }
#include <iostream> NEW_LINE #include <climits> NEW_LINE using namespace std ; #define INF  INT_MAX NEW_LINE #define N  4
int minCost ( int cost [ ] [ N ] ) {
int dist [ N ] ; for ( int i = 0 ; i < N ; i ++ ) dist [ i ] = INF ; dist [ 0 ] = 0 ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( dist [ j ] > dist [ i ] + cost [ i ] [ j ] ) dist [ j ] = dist [ i ] + cost [ i ] [ j ] ; return dist [ N - 1 ] ; }
int main ( ) { int cost [ N ] [ N ] = { { 0 , 15 , 80 , 90 } , { INF , 0 , 40 , 50 } , { INF , INF , 0 , 70 } , { INF , INF , INF , 0 } } ; cout << " The ▁ Minimum ▁ cost ▁ to ▁ reach ▁ station ▁ " << N << " ▁ is ▁ " << minCost ( cost ) ; return 0 ; }
int numOfways ( int n , int k ) { int p = 1 ; if ( k % 2 ) p = -1 ; return ( pow ( n - 1 , k ) + p * ( n - 1 ) ) / n ; }
int main ( ) { int n = 4 , k = 2 ; cout << numOfways ( n , k ) << endl ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ;
int power ( int n ) { if ( n == 1 ) return 2 ; return 2 * power ( n - 1 ) ; }
int main ( ) { int n = 4 ; cout << power ( n ) ; return 0 ; }
#define size  4
bool checkStar ( int mat [ ] [ size ] ) {
int vertexD1 = 0 , vertexDn_1 = 0 ;
if ( size == 1 ) return ( mat [ 0 ] [ 0 ] == 0 ) ;
if ( size == 2 ) return ( mat [ 0 ] [ 0 ] == 0 && mat [ 0 ] [ 1 ] == 1 && mat [ 1 ] [ 0 ] == 1 && mat [ 1 ] [ 1 ] == 0 ) ;
for ( int i = 0 ; i < size ; i ++ ) { int degreeI = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( mat [ i ] [ j ] ) degreeI ++ ; if ( degreeI == 1 ) vertexD1 ++ ; else if ( degreeI == size - 1 ) vertexDn_1 ++ ; } return ( vertexD1 == ( size - 1 ) && vertexDn_1 == 1 ) ; }
int main ( ) { int mat [ size ] [ size ] = { { 0 , 1 , 1 , 1 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } } ; checkStar ( mat ) ? cout << " Star ▁ Graph " : cout << " Not ▁ a ▁ Star ▁ Graph " ; return 0 ; }
int fib ( int n ) { if ( n <= 1 ) return n ; return fib ( n - 1 ) + fib ( n - 2 ) ; }
int findVertices ( int n ) {
return fib ( n + 2 ) ; }
int main ( ) { int n = 3 ; cout << findVertices ( n ) ; return 0 ; }
bool check ( int degree [ ] , int n ) {
int deg_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) deg_sum += degree [ i ] ;
return ( 2 * ( n - 1 ) == deg_sum ) ; }
int main ( ) { int n = 5 ; int degree [ ] = { 2 , 3 , 1 , 1 , 1 } ; if ( check ( degree , n ) ) cout << " Tree " ; else cout << " Graph " ; return 0 ; }
bool isInorder ( int arr [ ] , int n ) {
if ( n == 0 n == 1 ) return true ; for ( int i = 1 ; i < n ; i ++ )
if ( arr [ i - 1 ] > arr [ i ] ) return false ;
return true ; }
int main ( ) { int arr [ ] = { 19 , 23 , 25 , 30 , 45 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( isInorder ( arr , n ) ) cout << " Yesn " ; else cout << " Non " ; return 0 ; }
bool isLeaf ( int pre [ ] , int & i , int n , int min , int max ) { if ( i >= n ) return false ; if ( pre [ i ] > min && pre [ i ] < max ) { i ++ ; bool left = isLeaf ( pre , i , n , min , pre [ i - 1 ] ) ; bool right = isLeaf ( pre , i , n , pre [ i - 1 ] , max ) ; if ( ! left && ! right ) cout << pre [ i - 1 ] << " ▁ " ; return true ; } return false ; } void printLeaves ( int preorder [ ] , int n ) { int i = 0 ; isLeaf ( preorder , i , n , INT_MIN , INT_MAX ) ; }
int main ( ) { int preorder [ ] = { 890 , 325 , 290 , 530 , 965 } ; int n = sizeof ( preorder ) / sizeof ( preorder [ 0 ] ) ; printLeaves ( preorder , n ) ; return 0 ; }
void pairs ( int arr [ ] , int n , int k ) {
int smallest = INT_MAX ; int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
if ( abs ( arr [ i ] + arr [ j ] - k ) < smallest ) { smallest = abs ( arr [ i ] + arr [ j ] - k ) ; count = 1 ; }
else if ( abs ( arr [ i ] + arr [ j ] - k ) == smallest ) count ++ ; }
cout << " Minimal ▁ Value ▁ = ▁ " << smallest << " STRNEWLINE " ; cout << " Total ▁ Pairs ▁ = ▁ " << count << " STRNEWLINE " ; }
int main ( ) { int arr [ ] = { 3 , 5 , 7 , 5 , 1 , 9 , 9 } ; int k = 12 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; pairs ( arr , n , k ) ; return 0 ; }
int main ( ) { int a [ ] = { 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 } ; int key = 20 ; int arraySize = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int count = 0 ; for ( int i = 0 ; i < arraySize ; i ++ ) { if ( a [ i ] <= key ) { count += 1 ; } } cout << " Rank ▁ of ▁ " << key << " ▁ in ▁ stream ▁ is : ▁ " << count - 1 << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX_SIZE  10
void sortByRow ( int mat [ ] [ MAX_SIZE ] , int n , bool ascending ) { for ( int i = 0 ; i < n ; i ++ ) { if ( ascending ) sort ( mat [ i ] , mat [ i ] + n ) ; else sort ( mat [ i ] , mat [ i ] + n , greater < int > ( ) ) ; } }
void transpose ( int mat [ ] [ MAX_SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ )
swap ( mat [ i ] [ j ] , mat [ j ] [ i ] ) ; }
void sortMatRowAndColWise ( int mat [ ] [ MAX_SIZE ] , int n ) {
sortByRow ( mat , n , true ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n , false ) ;
transpose ( mat , n ) ; }
void printMat ( int mat [ ] [ MAX_SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << mat [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int n = 3 ; int mat [ n ] [ MAX_SIZE ] = { { 3 , 2 , 1 } , { 9 , 8 , 7 } , { 6 , 5 , 4 } } ; cout << " Original ▁ Matrix : STRNEWLINE " ; printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; cout << " Matrix After Sorting : " ; printMat ( mat , n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 100 ; void middlesum ( int mat [ ] [ MAX ] , int n ) { int row_sum = 0 , col_sum = 0 ;
for ( int i = 0 ; i < n ; i ++ ) row_sum += mat [ n / 2 ] [ i ] ; cout << " Sum ▁ of ▁ middle ▁ row ▁ = ▁ " << row_sum << endl ;
for ( int i = 0 ; i < n ; i ++ ) col_sum += mat [ i ] [ n / 2 ] ; cout << " Sum ▁ of ▁ middle ▁ column ▁ = ▁ " << col_sum ; }
int main ( ) { int mat [ ] [ MAX ] = { { 2 , 5 , 7 } , { 3 , 7 , 2 } , { 5 , 6 , 9 } } ; middlesum ( mat , 3 ) ; return 0 ; }
#define M  3 NEW_LINE #define N  3 NEW_LINE using namespace std ;
void rotateMatrix ( int matrix [ ] [ M ] , int k ) {
int temp [ M ] ;
k = k % M ; for ( int i = 0 ; i < N ; i ++ ) {
for ( int t = 0 ; t < M - k ; t ++ ) temp [ t ] = matrix [ i ] [ t ] ;
for ( int j = M - k ; j < M ; j ++ ) matrix [ i ] [ j - M + k ] = matrix [ i ] [ j ] ;
for ( int j = k ; j < M ; j ++ ) matrix [ i ] [ j ] = temp [ j - k ] ; } }
void displayMatrix ( int matrix [ ] [ M ] ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) cout << matrix [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int matrix [ N ] [ M ] = { { 12 , 23 , 34 } , { 45 , 56 , 67 } , { 78 , 89 , 91 } } ; int k = 2 ;
rotateMatrix ( matrix , k ) ;
displayMatrix ( matrix ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  3 NEW_LINE using namespace std ;
void multiply ( int mat [ ] [ N ] , int res [ ] [ N ] ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) { res [ i ] [ j ] = 0 ; for ( int k = 0 ; k < N ; k ++ ) res [ i ] [ j ] += mat [ i ] [ k ] * mat [ k ] [ j ] ; } } }
bool InvolutoryMatrix ( int mat [ N ] [ N ] ) { int res [ N ] [ N ] ;
multiply ( mat , res ) ; for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) { if ( i == j && res [ i ] [ j ] != 1 ) return false ; if ( i != j && res [ i ] [ j ] != 0 ) return false ; } } return true ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 0 , 0 } , { 0 , -1 , 0 } , { 0 , 0 , -1 } } ;
if ( InvolutoryMatrix ( mat ) ) cout << " Involutory ▁ Matrix " ; else cout << " Not ▁ Involutory ▁ Matrix " ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; #define n  4 NEW_LINE void interchangeFirstLast ( int m [ ] [ n ] ) { int rows = n ;
for ( int i = 0 ; i < n ; i ++ ) { int t = m [ 0 ] [ i ] ; m [ 0 ] [ i ] = m [ rows - 1 ] [ i ] ; m [ rows - 1 ] [ i ] = t ; } }
int m [ n ] [ n ] = { { 8 , 9 , 7 , 6 } , { 4 , 7 , 6 , 5 } , { 3 , 2 , 1 , 8 } , { 9 , 9 , 7 , 7 } } ; interchangeFirstLast ( m ) ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << m [ i ] [ j ] << " ▁ " ; cout << endl ; } }
#include <iostream> NEW_LINE using namespace std ; #define n  3 NEW_LINE bool checkMarkov ( double m [ ] [ n ] ) {
for ( int i = 0 ; i < n ; i ++ ) {
double sum = 0 ; for ( int j = 0 ; j < n ; j ++ ) sum = sum + m [ i ] [ j ] ; if ( sum != 1 ) return false ; } return true ; }
double m [ 3 ] [ 3 ] = { { 0 , 0 , 1 } , { 0.5 , 0 , 0.5 } , { 1 , 0 , 0 } } ;
if ( checkMarkov ( m ) ) cout << " ▁ yes ▁ " ; else cout << " ▁ no ▁ " ; }
#include <bits/stdc++.h> NEW_LINE #define N  4 NEW_LINE using namespace std ;
bool isDiagonalMatrix ( int mat [ N ] [ N ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ )
if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ; return true ; }
int main ( ) { int mat [ N ] [ N ] = { { 4 , 0 , 0 , 0 } , { 0 , 7 , 0 , 0 } , { 0 , 0 , 5 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isDiagonalMatrix ( mat ) ) cout << " Yes " << endl ; else cout << " No " << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  4 NEW_LINE using namespace std ;
bool isScalarMatrix ( int mat [ N ] [ N ] ) {
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ;
for ( int i = 0 ; i < N - 1 ; i ++ ) if ( mat [ i ] [ i ] != mat [ i + 1 ] [ i + 1 ] ) return false ; return true ; }
int main ( ) { int mat [ N ] [ N ] = { { 2 , 0 , 0 , 0 } , { 0 , 2 , 0 , 0 } , { 0 , 0 , 2 , 0 } , { 0 , 0 , 0 , 2 } } ;
if ( isScalarMatrix ( mat ) ) cout << " Yes " << endl ; else cout << " No " << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX_SIZE  10
void sortByRow ( int mat [ MAX_SIZE ] [ MAX_SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ )
sort ( mat [ i ] , mat [ i ] + n ) ; }
void transpose ( int mat [ MAX_SIZE ] [ MAX_SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ )
swap ( mat [ i ] [ j ] , mat [ j ] [ i ] ) ; }
void sortMatRowAndColWise ( int mat [ MAX_SIZE ] [ MAX_SIZE ] , int n ) {
sortByRow ( mat , n ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n ) ;
transpose ( mat , n ) ; }
void printMat ( int mat [ MAX_SIZE ] [ MAX_SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << mat [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int mat [ MAX_SIZE ] [ MAX_SIZE ] = { { 4 , 1 , 3 } , { 9 , 6 , 8 } , { 5 , 2 , 7 } } ; int n = 3 ; cout << " Original ▁ Matrix : STRNEWLINE " ; printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; cout << " Matrix After Sorting : " ; printMat ( mat , n ) ; return 0 ; }
void doublyEven ( int n ) { int arr [ n ] [ n ] , i , j ;
for ( i = 0 ; i < n ; i ++ ) for ( j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * i ) + j + 1 ;
for ( i = 0 ; i < n / 4 ; i ++ ) for ( j = 0 ; j < n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < n / 4 ; i ++ ) for ( j = 3 * ( n / 4 ) ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * n / 4 ; i < n ; i ++ ) for ( j = 0 ; j < n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * n / 4 ; i < n ; i ++ ) for ( j = 3 * n / 4 ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = n / 4 ; i < 3 * n / 4 ; i ++ ) for ( j = n / 4 ; j < 3 * n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) cout << arr [ i ] [ j ] << " ▁ " ; cout << " STRNEWLINE " ; } }
int main ( ) { int n = 8 ;
doublyEven ( n ) ; return 0 ; }
bool isMagicSquare ( int mat [ ] [ N ] ) {
int sum = 0 , sum2 = 0 ; for ( int i = 0 ; i < N ; i ++ ) sum = sum + mat [ i ] [ i ] ;
for ( int i = 0 ; i < N ; i ++ ) sum2 = sum2 + mat [ i ] [ N - 1 - i ] ; if ( sum != sum2 ) return false ;
for ( int i = 0 ; i < N ; i ++ ) { int rowSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) rowSum += mat [ i ] [ j ] ;
if ( rowSum != sum ) return false ; }
for ( int i = 0 ; i < N ; i ++ ) { int colSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) colSum += mat [ j ] [ i ] ;
if ( sum != colSum ) return false ; } return true ; }
int main ( ) { int mat [ ] [ N ] = { { 2 , 7 , 6 } , { 9 , 5 , 1 } , { 4 , 3 , 8 } } ; if ( isMagicSquare ( mat ) ) cout << " Magic ▁ Square " ; else cout << " Not ▁ a ▁ magic ▁ Square " ; return 0 ; }
int subCount ( int arr [ ] , int n , int k ) {
int mod [ k ] ; memset ( mod , 0 , sizeof ( mod ) ) ;
int cumSum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { cumSum += arr [ i ] ;
mod [ ( ( cumSum % k ) + k ) % k ] ++ ; }
int result = 0 ;
for ( int i = 0 ; i < k ; i ++ )
if ( mod [ i ] > 1 ) result += ( mod [ i ] * ( mod [ i ] - 1 ) ) / 2 ;
result += mod [ 0 ] ; return result ; }
int countSubmatrix ( int mat [ SIZE ] [ SIZE ] , int n , int k ) {
int tot_count = 0 ; int left , right , i ; int temp [ n ] ;
for ( left = 0 ; left < n ; left ++ ) {
memset ( temp , 0 , sizeof ( temp ) ) ;
for ( right = left ; right < n ; right ++ ) {
for ( i = 0 ; i < n ; ++ i ) temp [ i ] += mat [ i ] [ right ] ;
tot_count += subCount ( temp , n , k ) ; } }
return tot_count ; }
int main ( ) { int mat [ ] [ SIZE ] = { { 5 , -1 , 6 } , { -2 , 3 , 8 } , { 7 , 4 , -9 } } ; int n = 3 , k = 4 ; cout << " Count ▁ = ▁ " << countSubmatrix ( mat , n , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int find ( int n , int k ) { if ( n + 1 >= k ) return ( k - 1 ) ; else return ( 2 * n + 1 - k ) ; }
int main ( ) { int n = 4 , k = 7 ; int freq = find ( n , k ) ; if ( freq < 0 ) cout << " ▁ element ▁ not ▁ exist ▁ STRNEWLINE ▁ " ; else cout << " ▁ Frequency ▁ of ▁ " << k << " ▁ is ▁ " << freq << " STRNEWLINE " ; return 0 ; }
void ZigZag ( int rows , int columns , int numbers [ ] ) { int k = 0 ;
int arr [ rows ] [ columns ] ; for ( int i = 0 ; i < rows ; i ++ ) {
if ( i % 2 == 0 ) {
for ( int j = 0 ; j < columns and numbers [ k ] > 0 ; j ++ ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } }
else {
for ( int j = columns - 1 ; j >= 0 and numbers [ k ] > 0 ; j -- ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } } }
for ( int i = 0 ; i < rows ; i ++ ) { for ( int j = 0 ; j < columns ; j ++ ) cout << arr [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int rows = 4 ; int columns = 5 ; int Numbers [ ] = { 3 , 4 , 2 , 2 , 3 , 1 , 5 } ; ZigZag ( rows , columns , Numbers ) ; return 0 ; }
int numberofPosition ( int n , int k , int x , int y , int obstPosx [ ] , int obstPosy [ ] ) {
int d11 , d12 , d21 , d22 , r1 , r2 , c1 , c2 ;
d11 = min ( x - 1 , y - 1 ) ; d12 = min ( n - x , n - y ) ; d21 = min ( n - x , y - 1 ) ; d22 = min ( x - 1 , n - y ) ; r1 = y - 1 ; r2 = n - y ; c1 = x - 1 ; c2 = n - x ;
for ( int i = 0 ; i < k ; i ++ ) { if ( x > obstPosx [ i ] && y > obstPosy [ i ] && x - obstPosx [ i ] == y - obstPosy [ i ] ) d11 = min ( d11 , x - obstPosx [ i ] - 1 ) ; if ( obstPosx [ i ] > x && obstPosy [ i ] > y && obstPosx [ i ] - x == obstPosy [ i ] - y ) d12 = min ( d12 , obstPosx [ i ] - x - 1 ) ; if ( obstPosx [ i ] > x && y > obstPosy [ i ] && obstPosx [ i ] - x == y - obstPosy [ i ] ) d21 = min ( d21 , obstPosx [ i ] - x - 1 ) ; if ( x > obstPosx [ i ] && obstPosy [ i ] > y && x - obstPosx [ i ] == obstPosy [ i ] - y ) d22 = min ( d22 , x - obstPosx [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] < y ) r1 = min ( r1 , y - obstPosy [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] > y ) r2 = min ( r2 , obstPosy [ i ] - y - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] < x ) c1 = min ( c1 , x - obstPosx [ i ] - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] > x ) c2 = min ( c2 , obstPosx [ i ] - x - 1 ) ; } return d11 + d12 + d21 + d22 + r1 + r2 + c1 + c2 ; }
int n = 8 ;
int k = 1 ;
int Qposx = 4 ;
int Qposy = 4 ;
int obstPosx [ ] = { 3 } ;
int obstPosy [ ] = { 5 } ; cout << numberofPosition ( n , k , Qposx , Qposy , obstPosx , obstPosy ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int n = 5 ;
int FindMaxProduct ( int arr [ ] [ n ] , int n ) { int max = 0 , result ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = 0 ; j < n ; j ++ ) {
if ( ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i ] [ j - 1 ] * arr [ i ] [ j - 2 ] * arr [ i ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j ] * arr [ i - 2 ] [ j ] * arr [ i - 3 ] [ j ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j - 1 ] * arr [ i - 2 ] [ j - 2 ] * arr [ i - 3 ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 1 ) <= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j + 1 ] * arr [ i - 2 ] [ j + 2 ] * arr [ i - 3 ] [ j + 3 ] ; if ( max < result ) max = result ; } } } return max ; }
int main ( ) { int arr [ ] [ 5 ] = { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 1 } , { 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 1 , 0 } , { 9 , 6 , 4 , 2 , 3 } } ; cout << FindMaxProduct ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  3 NEW_LINE using namespace std ;
int minimumflip ( int mat [ ] [ N ] , int n ) { int transpose [ n ] [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) transpose [ i ] [ j ] = mat [ j ] [ i ] ;
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( transpose [ i ] [ j ] != mat [ i ] [ j ] ) flip ++ ; return flip / 2 ; }
int main ( ) { int n = 3 ; int mat [ N ] [ N ] = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; cout << minimumflip ( mat , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  3 NEW_LINE using namespace std ;
int minimumflip ( int mat [ ] [ N ] , int n ) {
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) flip ++ ; return flip ; }
int main ( ) { int n = 3 ; int mat [ N ] [ N ] = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; cout << minimumflip ( mat , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  4 NEW_LINE using namespace std ;
bool isLowerTriangularMatrix ( int mat [ N ] [ N ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 0 , 0 , 0 } , { 1 , 4 , 0 , 0 } , { 4 , 6 , 2 , 0 } , { 0 , 4 , 7 , 6 } } ;
if ( isLowerTriangularMatrix ( mat ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  4 NEW_LINE using namespace std ;
bool isUpperTriangularMatrix ( int mat [ N ] [ N ] ) { for ( int i = 1 ; i < N ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 3 , 5 , 3 } , { 0 , 4 , 6 , 2 } , { 0 , 0 , 2 , 5 } , { 0 , 0 , 0 , 6 } } ; if ( isUpperTriangularMatrix ( mat ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  100
void freq ( int ar [ ] [ MAX ] , int m , int n ) { int even = 0 , odd = 0 ; for ( int i = 0 ; i < m ; ++ i ) { for ( int j = 0 ; j < n ; ++ j ) {
if ( ( ar [ i ] [ j ] % 2 ) == 0 ) ++ even ; else ++ odd ; } }
printf ( " ▁ Frequency ▁ of ▁ odd ▁ number ▁ = ▁ % d ▁ STRNEWLINE " , odd ) ; printf ( " ▁ Frequency ▁ of ▁ even ▁ number ▁ = ▁ % d ▁ STRNEWLINE " , even ) ; }
int main ( ) { int m = 3 , n = 3 ; int array [ ] [ MAX ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; freq ( array , m , n ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ;
bool HalfDiagonalSums ( int mat [ ] [ MAX ] , int n ) {
int diag1_left = 0 , diag1_right = 0 ; int diag2_left = 0 , diag2_right = 0 ; for ( int i = 0 , j = n - 1 ; i < n ; i ++ , j -- ) { if ( i < n / 2 ) { diag1_left += mat [ i ] [ i ] ; diag2_left += mat [ j ] [ i ] ; } else if ( i > n / 2 ) { diag1_right += mat [ i ] [ i ] ; diag2_right += mat [ j ] [ i ] ; } } return ( diag1_left == diag2_right && diag2_right == diag2_left && diag1_right == diag2_left && diag2_right == mat [ n / 2 ] [ n / 2 ] ) ; }
int main ( ) { int a [ ] [ MAX ] = { { 2 , 9 , 1 , 4 , -2 } , { 6 , 7 , 2 , 11 , 4 } , { 4 , 2 , 9 , 2 , 4 } , { 1 , 9 , 2 , 4 , 4 } , { 0 , 2 , 4 , 2 , 5 } } ; cout << ( HalfDiagonalSums ( a , 5 ) ? " Yes " : " No " ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 100 ; bool isIdentity ( int mat [ ] [ MAX ] , int N ) { for ( int row = 0 ; row < N ; row ++ ) { for ( int col = 0 ; col < N ; col ++ ) { if ( row == col && mat [ row ] [ col ] != 1 ) return false ; else if ( row != col && mat [ row ] [ col ] != 0 ) return false ; } } return true ; }
int main ( ) { int N = 4 ; int mat [ ] [ MAX ] = { { 1 , 0 , 0 , 0 } , { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isIdentity ( mat , N ) ) cout << " Yes ▁ " ; else cout << " No ▁ " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define mod  100000007
long long modPower ( long long a , long long t ) { long long now = a , ret = 1 ;
while ( t ) { if ( t & 1 ) ret = now * ( ret % mod ) ; now = now * ( now % mod ) ; t >>= 1 ; } return ret ; }
long countWays ( int n , int m , int k ) {
if ( k == -1 && ( n + m ) % 2 == 1 ) return 0 ;
if ( n == 1 m == 1 ) return 1 ;
return ( modPower ( modPower ( ( long long ) 2 , n - 1 ) , m - 1 ) % mod ) ; }
int main ( ) { int n = 2 , m = 7 , k = 1 ; cout << countWays ( n , m , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; void imageSwap ( int mat [ ] [ MAX ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j <= i ; j ++ ) mat [ i ] [ j ] = mat [ i ] [ j ] + mat [ j ] [ i ] - ( mat [ j ] [ i ] = mat [ i ] [ j ] ) ; }
void printMatrix ( int mat [ ] [ MAX ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << mat [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; int n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ; return 0 ; }
const int m = 3 ;
const int n = 2 ;
long long countSets ( int a [ n ] [ m ] ) {
long long res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < m ; j ++ ) a [ i ] [ j ] ? u ++ : v ++ ; res += pow ( 2 , u ) - 1 + pow ( 2 , v ) - 1 ; }
for ( int i = 0 ; i < m ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < n ; j ++ ) a [ j ] [ i ] ? u ++ : v ++ ; res += pow ( 2 , u ) - 1 + pow ( 2 , v ) - 1 ; }
return res - ( n * m ) ; }
int main ( ) { int a [ ] [ 3 ] = { ( 1 , 0 , 1 ) , ( 0 , 1 , 0 ) } ; cout << countSets ( a ) ; return 0 ; }
int calculateEnergy ( int mat [ SIZE ] [ SIZE ] , int n ) { int i_des , j_des , q ; int tot_energy = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
q = mat [ i ] [ j ] / n ;
i_des = q ; j_des = mat [ i ] [ j ] - ( n * q ) ;
tot_energy += abs ( i_des - i ) + abs ( j_des - j ) ; } }
return tot_energy ; }
int main ( ) { int mat [ SIZE ] [ SIZE ] = { { 4 , 7 , 0 , 3 } , { 8 , 5 , 6 , 1 } , { 9 , 11 , 10 , 2 } , { 15 , 13 , 14 , 12 } } ; int n = 4 ; cout << " Total ▁ energy ▁ required ▁ = ▁ " << calculateEnergy ( mat , n ) << " ▁ units " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ;
bool isUnique ( int mat [ ] [ MAX ] , int i , int j , int n , int m ) {
int sumrow = 0 ; for ( int k = 0 ; k < m ; k ++ ) { sumrow += mat [ i ] [ k ] ; if ( sumrow > 1 ) return false ; }
int sumcol = 0 ; for ( int k = 0 ; k < n ; k ++ ) { sumcol += mat [ k ] [ j ] ; if ( sumcol > 1 ) return false ; } return true ; } int countUnique ( int mat [ ] [ MAX ] , int n , int m ) { int uniquecount = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] && isUnique ( mat , i , j , n , m ) ) uniquecount ++ ; return uniquecount ; }
int main ( ) { int mat [ ] [ MAX ] = { { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 1 , 0 , 0 , 1 } } ; cout << countUnique ( mat , 3 , 4 ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 100 ; bool isSparse ( int array [ ] [ MAX ] , int m , int n ) { int counter = 0 ;
for ( int i = 0 ; i < m ; ++ i ) for ( int j = 0 ; j < n ; ++ j ) if ( array [ i ] [ j ] == 0 ) ++ counter ; return ( counter > ( ( m * n ) / 2 ) ) ; }
int main ( ) { int array [ ] [ MAX ] = { { 1 , 0 , 3 } , { 0 , 0 , 4 } , { 6 , 0 , 0 } } ; int m = 3 , n = 3 ; if ( isSparse ( array , m , n ) ) cout << " Yes " ; else cout << " No " ; }
#include <iostream> NEW_LINE #define MAX  100 NEW_LINE using namespace std ;
int countCommon ( int mat [ ] [ MAX ] , int n ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( mat [ i ] [ i ] == mat [ i ] [ n - i - 1 ] ) res ++ ; return res ; }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; cout << countCommon ( mat , 3 ) ; return 0 ; }
bool areSumSame ( int a [ ] [ MAX ] , int n , int m ) { int sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum1 = 0 , sum2 = 0 ; for ( int j = 0 ; j < m ; j ++ ) { sum1 += a [ i ] [ j ] ; sum2 += a [ j ] [ i ] ; } if ( sum1 == sum2 ) return true ; } return false ; }
int n = 4 ;
int m = 4 ; int M [ n ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 9 , 5 , 3 , 1 } , { 0 , 3 , 5 , 6 } , { 0 , 4 , 5 , 6 } } ; cout << areSumSame ( M , n , m ) << " STRNEWLINE " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  4 NEW_LINE using namespace std ;
void findMax ( int arr [ ] [ N ] ) { int row = 0 , i , j ; for ( i = 0 , j = N - 1 ; i < N ; i ++ ) {
while ( arr [ i ] [ j ] == 1 && j >= 0 ) { row = i ; j -- ; } } cout << " Row ▁ number ▁ = ▁ " << row + 1 ; cout << " , ▁ MaxCount ▁ = ▁ " << N - 1 - j ; }
int main ( ) { int arr [ N ] [ N ] = { 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 0 , 1 , 1 , 1 } ; findMax ( arr ) ; return 0 ; }
void transpose ( int mat [ ] [ MAX ] , int tr [ ] [ MAX ] , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) tr [ i ] [ j ] = mat [ j ] [ i ] ; }
bool isSymmetric ( int mat [ ] [ MAX ] , int N ) { int tr [ N ] [ MAX ] ; transpose ( mat , tr , N ) ; for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != tr [ i ] [ j ] ) return false ; return true ; }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 100 ;
bool isSymmetric ( int mat [ ] [ MAX ] , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) return false ; return true ; }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define n  4 NEW_LINE #define m  4 NEW_LINE using namespace std ;
int findPossibleMoves ( int mat [ n ] [ m ] , int p , int q ) {
int X [ 8 ] = { 2 , 1 , -1 , -2 , -2 , -1 , 1 , 2 } ; int Y [ 8 ] = { 1 , 2 , 2 , 1 , -1 , -2 , -2 , -1 } ; int count = 0 ;
for ( int i = 0 ; i < 8 ; i ++ ) {
int x = p + X [ i ] ; int y = q + Y [ i ] ;
if ( x >= 0 && y >= 0 && x < n && y < m && mat [ x ] [ y ] == 0 ) count ++ ; }
return count ; }
int main ( ) { int mat [ n ] [ m ] = { { 1 , 0 , 1 , 0 } , { 0 , 1 , 1 , 1 } , { 1 , 1 , 0 , 1 } , { 0 , 1 , 1 , 1 } } ; int p = 2 , q = 2 ; cout << findPossibleMoves ( mat , p , q ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; void printDiagonalSums ( int mat [ ] [ MAX ] , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) principal += mat [ i ] [ j ] ;
if ( ( i + j ) == ( n - 1 ) ) secondary += mat [ i ] [ j ] ; } } cout << " Principal ▁ Diagonal : " << principal << endl ; cout << " Secondary ▁ Diagonal : " << secondary << endl ; }
int main ( ) { int a [ ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; void printDiagonalSums ( int mat [ ] [ MAX ] , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { principal += mat [ i ] [ i ] ; secondary += mat [ i ] [ n - i - 1 ] ; } cout << " Principal ▁ Diagonal : " << principal << endl ; cout << " Secondary ▁ Diagonal : " << secondary << endl ; }
int main ( ) { int a [ ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; void printBoundary ( int a [ ] [ MAX ] , int m , int n ) { for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( i == 0 j == 0 i == n - 1 j == n - 1 ) cout << a [ i ] [ j ] << " ▁ " ; else cout << " ▁ " << " ▁ " ; } cout << " STRNEWLINE " ; } }
int main ( ) { int a [ 4 ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printBoundary ( a , 4 , 4 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; int getBoundarySum ( int a [ ] [ MAX ] , int m , int n ) { long long int sum = 0 ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( i == 0 ) sum += a [ i ] [ j ] ; else if ( i == m - 1 ) sum += a [ i ] [ j ] ; else if ( j == 0 ) sum += a [ i ] [ j ] ; else if ( j == n - 1 ) sum += a [ i ] [ j ] ; } } return sum ; }
int main ( ) { int a [ ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; long long int sum = getBoundarySum ( a , 4 , 4 ) ; cout << " Sum ▁ of ▁ boundary ▁ elements ▁ is ▁ " << sum ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 100 ; void printSpiral ( int mat [ ] [ MAX ] , int r , int c ) { int i , a = 0 , b = 2 ; int low_row = ( 0 > a ) ? 0 : a ; int low_column = ( 0 > b ) ? 0 : b - 1 ; int high_row = ( ( a + 1 ) >= r ) ? r - 1 : a + 1 ; int high_column = ( ( b + 1 ) >= c ) ? c - 1 : b + 1 ; while ( ( low_row > 0 - r && low_column > 0 - c ) ) { for ( i = low_column + 1 ; i <= high_column && i < c && low_row >= 0 ; ++ i ) cout << mat [ low_row ] [ i ] << " ▁ " ; low_row -= 1 ; for ( i = low_row + 2 ; i <= high_row && i < r && high_column < c ; ++ i ) cout << mat [ i ] [ high_column ] << " ▁ " ; high_column += 1 ; for ( i = high_column - 2 ; i >= low_column && i >= 0 && high_row < r ; -- i ) cout << mat [ high_row ] [ i ] << " ▁ " ; high_row += 1 ; for ( i = high_row - 2 ; i > low_row && i >= 0 && low_column >= 0 ; -- i ) cout << mat [ i ] [ low_column ] << " ▁ " ; low_column -= 1 ; } cout << endl ; }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int r = 3 , c = 3 ;
printSpiral ( mat , r , c ) ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  100 NEW_LINE using namespace std ; int difference ( int arr [ ] [ MAX ] , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) d1 += arr [ i ] [ j ] ;
if ( i == n - j - 1 ) d2 += arr [ i ] [ j ] ; } }
return abs ( d1 - d2 ) ; }
int main ( ) { int n = 3 ; int arr [ ] [ MAX ] = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , -12 } } ; cout << difference ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  100 NEW_LINE using namespace std ; int difference ( int arr [ ] [ MAX ] , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { d1 += arr [ i ] [ i ] ; d2 += arr [ i ] [ n - i - 1 ] ; }
return abs ( d1 - d2 ) ; }
int main ( ) { int n = 3 ; int arr [ ] [ MAX ] = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , -12 } } ; cout << difference ( arr , n ) ; return 0 ; }
void spiralFill ( int m , int n , int a [ ] [ MAX ] ) {
int val = 1 ;
int k = 0 , l = 0 ; while ( k < m && l < n ) {
for ( int i = l ; i < n ; ++ i ) a [ k ] [ i ] = val ++ ; k ++ ;
for ( int i = k ; i < m ; ++ i ) a [ i ] [ n - 1 ] = val ++ ; n -- ;
if ( k < m ) { for ( int i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = val ++ ; m -- ; }
if ( l < n ) { for ( int i = m - 1 ; i >= k ; -- i ) a [ i ] [ l ] = val ++ ; l ++ ; } } }
int main ( ) { int m = 4 , n = 4 ; int a [ MAX ] [ MAX ] ; spiralFill ( m , n , a ) ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << a [ i ] [ j ] << " ▁ " ; cout << endl ; } return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  100
void maxMin ( int arr [ ] [ MAX ] , int n ) { int min = INT_MAX ; int max = INT_MIN ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j <= n / 2 ; j ++ ) {
if ( arr [ i ] [ j ] > arr [ i ] [ n - j - 1 ] ) { if ( min > arr [ i ] [ n - j - 1 ] ) min = arr [ i ] [ n - j - 1 ] ; if ( max < arr [ i ] [ j ] ) max = arr [ i ] [ j ] ; } else { if ( min > arr [ i ] [ j ] ) min = arr [ i ] [ j ] ; if ( max < arr [ i ] [ n - j - 1 ] ) max = arr [ i ] [ n - j - 1 ] ; } } } cout << " Maximum ▁ = ▁ " << max << " , ▁ Minimum ▁ = ▁ " << min ; }
int main ( ) { int arr [ MAX ] [ MAX ] = { 5 , 9 , 11 , 25 , 0 , 14 , 21 , 6 , 4 } ; maxMin ( arr , 3 ) ; return 0 ; }
const int MAX = 100 ;
int findNormal ( int mat [ ] [ MAX ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] * mat [ i ] [ j ] ; return sqrt ( sum ) ; }
int findTrace ( int mat [ ] [ MAX ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += mat [ i ] [ i ] ; return sum ; }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; cout << " Trace ▁ of ▁ Matrix ▁ = ▁ " << findTrace ( mat , 5 ) << endl ; cout << " Normal ▁ of ▁ Matrix ▁ = ▁ " << findNormal ( mat , 5 ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  5 NEW_LINE #define M  5 NEW_LINE using namespace std ;
int minOperation ( bool arr [ N ] [ M ] ) { int ans = 0 ; for ( int i = N - 1 ; i >= 0 ; i -- ) { for ( int j = M - 1 ; j >= 0 ; j -- ) {
if ( arr [ i ] [ j ] == 0 ) {
ans ++ ;
for ( int k = 0 ; k <= i ; k ++ ) { for ( int h = 0 ; h <= j ; h ++ ) {
if ( arr [ k ] [ h ] == 1 ) arr [ k ] [ h ] = 0 ; else arr [ k ] [ h ] = 1 ; } } } } } return ans ; }
int main ( ) { bool mat [ N ] [ M ] = { 0 , 0 , 1 , 1 , 1 , 0 , 0 , 0 , 1 , 1 , 0 , 0 , 0 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; cout << minOperation ( mat ) << endl ; return 0 ; }
int findSum ( int n ) { int ans = 0 , temp = 0 , num ;
for ( int i = 1 ; i <= n && temp < n ; i ++ ) {
temp = i - 1 ;
num = 1 ; while ( temp < n ) { if ( temp + i <= n ) ans += ( i * num ) ; else ans += ( ( n - temp ) * num ) ; temp += i ; num ++ ; } } return ans ; }
int main ( ) { int N = 2 ; cout << findSum ( N ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 1000 ; int countOps ( int A [ ] [ MAX ] , int B [ ] [ MAX ] , int m , int n ) {
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) A [ i ] [ j ] -= B [ i ] [ j ] ;
for ( int i = 1 ; i < n ; i ++ ) for ( int j = 1 ; j < m ; j ++ ) if ( A [ i ] [ j ] - A [ i ] [ 0 ] - A [ 0 ] [ j ] + A [ 0 ] [ 0 ] != 0 ) return -1 ;
int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) result += abs ( A [ i ] [ 0 ] ) ; for ( int j = 0 ; j < m ; j ++ ) result += abs ( A [ 0 ] [ j ] - A [ 0 ] [ 0 ] ) ; return ( result ) ; }
int main ( ) { int A [ MAX ] [ MAX ] = { { 1 , 1 , 1 } , { 1 , 1 , 1 } , { 1 , 1 , 1 } } ; int B [ MAX ] [ MAX ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; cout << countOps ( A , B , 3 , 3 ) ; return 0 ; }
void printCoils ( int n ) {
int m = 8 * n * n ;
int coil1 [ m ] ;
coil1 [ 0 ] = 8 * n * n + 2 * n ; int curr = coil1 [ 0 ] ; int nflg = 1 , step = 2 ;
int index = 1 ; while ( index < m ) {
for ( int i = 0 ; i < step ; i ++ ) {
curr = coil1 [ index ++ ] = ( curr - 4 * n * nflg ) ; if ( index >= m ) break ; } if ( index >= m ) break ;
for ( int i = 0 ; i < step ; i ++ ) { curr = coil1 [ index ++ ] = curr + nflg ; if ( index >= m ) break ; } nflg = nflg * ( -1 ) ; step += 2 ; }
int coil2 [ m ] ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) coil2 [ i ] = 16 * n * n + 1 - coil1 [ i ] ;
cout << " Coil ▁ 1 ▁ : ▁ " ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) cout << coil1 [ i ] << " ▁ " ; cout << " Coil 2 : " for ( int i = 0 ; i < 8 * n * n ; i ++ ) cout << coil2 [ i ] << " ▁ " ; }
int main ( ) { int n = 1 ; printCoils ( n ) ; return 0 ; }
int findSum ( int n ) {
int arr [ n ] [ n ] ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = abs ( i - j ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += arr [ i ] [ j ] ; return sum ; }
int main ( ) { int n = 3 ; cout << findSum ( n ) << endl ; return 0 ; }
int findSum ( int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += i * ( n - i ) ; return 2 * sum ; }
int main ( ) { int n = 3 ; cout << findSum ( n ) << endl ; return 0 ; }
int findSum ( int n ) { n -- ; int sum = 0 ; sum += ( n * ( n + 1 ) ) / 2 ; sum += ( n * ( n + 1 ) * ( 2 * n + 1 ) ) / 6 ; return sum ; }
int main ( ) { int n = 3 ; cout << findSum ( n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  1000 NEW_LINE using namespace std ; void checkHV ( int arr [ ] [ MAX ] , int N , int M ) {
bool horizontal = true , vertical = true ;
for ( int i = 0 , k = N - 1 ; i < N / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < M ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { horizontal = false ; break ; } } }
for ( int i = 0 , k = M - 1 ; i < M / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < N ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { vertical = false ; break ; } } } if ( ! horizontal && ! vertical ) cout << " NO STRNEWLINE " ; else if ( horizontal && ! vertical ) cout << " HORIZONTAL STRNEWLINE " ; else if ( vertical && ! horizontal ) cout << " VERTICAL STRNEWLINE " ; else cout << " BOTH STRNEWLINE " ; }
int main ( ) { int mat [ MAX ] [ MAX ] = { { 1 , 0 , 1 } , { 0 , 0 , 0 } , { 1 , 0 , 1 } } ; checkHV ( mat , 3 , 3 ) ; return 0 ; }
int maxDet ( int n ) { return ( 2 * n * n * n ) ; }
void resMatrix ( int n ) { for ( int i = 0 ; i < 3 ; i ++ ) { for ( int j = 0 ; j < 3 ; j ++ ) {
if ( i == 0 && j == 2 ) cout << "0 ▁ " ; else if ( i == 1 && j == 0 ) cout << "0 ▁ " ; else if ( i == 2 && j == 1 ) cout << "0 ▁ " ;
else cout < < n << " ▁ " ; } cout << " STRNEWLINE " ; } }
int main ( ) { int n = 15 ; cout << " Maximum ▁ Determinant ▁ = ▁ " << maxDet ( n ) ; cout << " Resultant Matrix : " resMatrix ( n ) ; return 0 ; }
int spiralDiaSum ( int n ) { if ( n == 1 ) return 1 ;
return ( 4 * n * n - 6 * n + 6 + spiralDiaSum ( n - 2 ) ) ; }
int main ( ) { int n = 7 ; cout << spiralDiaSum ( n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  3 NEW_LINE #define C  5
int numofneighbour ( int mat [ ] [ C ] , int i , int j ) { int count = 0 ;
if ( i > 0 && mat [ i - 1 ] [ j ] ) count ++ ;
if ( j > 0 && mat [ i ] [ j - 1 ] ) count ++ ;
if ( i < R - 1 && mat [ i + 1 ] [ j ] ) count ++ ;
if ( j < C - 1 && mat [ i ] [ j + 1 ] ) count ++ ; return count ; }
int findperimeter ( int mat [ R ] [ C ] ) { int perimeter = 0 ;
for ( int i = 0 ; i < R ; i ++ ) for ( int j = 0 ; j < C ; j ++ ) if ( mat [ i ] [ j ] ) perimeter += ( 4 - numofneighbour ( mat , i , j ) ) ; return perimeter ; }
int main ( ) { int mat [ R ] [ C ] = { 0 , 1 , 0 , 0 , 0 , 1 , 1 , 1 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , } ; cout << findperimeter ( mat ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; void printMatrixDiagonal ( int mat [ MAX ] [ MAX ] , int n ) {
int i = 0 , j = 0 ;
bool isUp = true ;
for ( int k = 0 ; k < n * n ; ) {
if ( isUp ) { for ( ; i >= 0 && j < n ; j ++ , i -- ) { cout << mat [ i ] [ j ] << " ▁ " ; k ++ ; }
if ( i < 0 && j <= n - 1 ) i = 0 ; if ( j == n ) i = i + 2 , j -- ; }
else { for ( ; j >= 0 && i < n ; i ++ , j -- ) { cout << mat [ i ] [ j ] << " ▁ " ; k ++ ; }
if ( j < 0 && i <= n - 1 ) j = 0 ; if ( i == n ) j = j + 2 , i -- ; }
isUp = ! isUp ; } }
int main ( ) { int mat [ MAX ] [ MAX ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int n = 3 ; printMatrixDiagonal ( mat , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  100 NEW_LINE using namespace std ;
int maxRowDiff ( int mat [ ] [ MAX ] , int m , int n ) {
int rowSum [ m ] ;
for ( int i = 0 ; i < m ; i ++ ) { int sum = 0 ; for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] ; rowSum [ i ] = sum ; }
int max_diff = rowSum [ 1 ] - rowSum [ 0 ] ; int min_element = rowSum [ 0 ] ; for ( int i = 1 ; i < m ; i ++ ) {
if ( rowSum [ i ] - min_element > max_diff ) max_diff = rowSum [ i ] - min_element ;
if ( rowSum [ i ] < min_element ) min_element = rowSum [ i ] ; } return max_diff ; }
int main ( ) { int m = 5 , n = 4 ; int mat [ ] [ MAX ] = { { -1 , 2 , 3 , 4 } , { 5 , 3 , -2 , 1 } , { 6 , 7 , 2 , -3 } , { 2 , 9 , 1 , 4 } , { 2 , 1 , -2 , 0 } } ; cout << maxRowDiff ( mat , m , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  100 NEW_LINE using namespace std ;
int sortedCount ( int mat [ ] [ MAX ] , int r , int c ) {
int result = 0 ;
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = 0 ; j < c - 1 ; j ++ ) if ( mat [ i ] [ j + 1 ] <= mat [ i ] [ j ] ) break ;
if ( j == c - 1 ) result ++ ; }
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = c - 1 ; j > 0 ; j -- ) if ( mat [ i ] [ j - 1 ] <= mat [ i ] [ j ] ) break ;
if ( c > 1 && j == 0 ) result ++ ; } return result ; }
int main ( ) { int m = 4 , n = 5 ; int mat [ ] [ MAX ] = { { 1 , 2 , 3 , 4 , 5 } , { 4 , 3 , 1 , 2 , 6 } , { 8 , 7 , 6 , 5 , 4 } , { 5 , 7 , 8 , 9 , 10 } } ; cout << sortedCount ( mat , m , n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 1000 ;
int maxXOR ( int mat [ ] [ MAX ] , int N ) {
int r_xor , c_xor ; int max_xor = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { r_xor = 0 , c_xor = 0 ; for ( int j = 0 ; j < N ; j ++ ) {
r_xor = r_xor ^ mat [ i ] [ j ] ;
c_xor = c_xor ^ mat [ j ] [ i ] ; }
if ( max_xor < max ( r_xor , c_xor ) ) max_xor = max ( r_xor , c_xor ) ; }
return max_xor ; }
int main ( ) { int N = 3 ; int mat [ ] [ MAX ] = { { 1 , 5 , 4 } , { 3 , 7 , 2 } , { 5 , 9 , 10 } } ; cout << " maximum ▁ XOR ▁ value ▁ : ▁ " << maxXOR ( mat , N ) ; return 0 ; }
void direction ( ll R , ll C ) { if ( R != C && R % 2 == 0 && C % 2 != 0 && R < C ) { cout << " Left " << endl ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R > C ) { cout << " Up " << endl ; return ; } if ( R == C && R % 2 != 0 && C % 2 != 0 ) { cout << " Right " << endl ; return ; } if ( R == C && R % 2 == 0 && C % 2 == 0 ) { cout << " Left " << endl ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R < C ) { cout << " Right " << endl ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R > C ) { cout << " Down " << endl ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R < C ) { cout << " Left " << endl ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R > C ) { cout << " Up " << endl ; return ; } if ( R != C && R % 2 == 0 && C % 2 != 0 && R > C ) { cout << " Down " << endl ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R < C ) { cout << " Right " << endl ; return ; } }
int main ( ) { ll R = 3 , C = 1 ; direction ( R , C ) ; return 0 ; }
bool checkDiagonal ( int mat [ N ] [ M ] , int i , int j ) { int res = mat [ i ] [ j ] ; while ( ++ i < N && ++ j < M ) {
if ( mat [ i ] [ j ] != res ) return false ; }
return true ; }
bool isToepliz ( int mat [ N ] [ M ] ) {
for ( int i = 0 ; i < M ; i ++ ) {
if ( ! checkDiagonal ( mat , 0 , i ) ) return false ; }
for ( int i = 1 ; i < N ; i ++ ) {
if ( ! checkDiagonal ( mat , i , 0 ) ) return false ; }
return true ; }
int main ( ) { int mat [ N ] [ M ] = { { 6 , 7 , 8 , 9 } , { 4 , 6 , 7 , 8 } , { 1 , 4 , 6 , 7 } , { 0 , 1 , 4 , 6 } , { 2 , 0 , 1 , 4 } } ;
if ( isToepliz ( mat ) ) cout << " Matrix ▁ is ▁ a ▁ Toepliz ▁ " ; else cout << " Matrix ▁ is ▁ not ▁ a ▁ Toepliz ▁ " ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; #define N  5
int countZeroes ( int mat [ N ] [ N ] ) {
int row = N - 1 , col = 0 ;
int count = 0 ; while ( col < N ) {
while ( mat [ row ] [ col ] )
if ( -- row < 0 ) return count ;
count += ( row + 1 ) ;
col ++ ; } return count ; }
int main ( ) { int mat [ N ] [ N ] = { { 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 1 , 1 } , { 0 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } } ; cout << countZeroes ( mat ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countNegative ( int M [ ] [ 4 ] , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < m ; j ++ ) { if ( M [ i ] [ j ] < 0 ) count += 1 ;
else break ; } } return count ; }
int main ( ) { int M [ 3 ] [ 4 ] = { { -3 , -2 , -1 , 1 } , { -2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; cout << countNegative ( M , 3 , 4 ) ; return 0 ; }
int countNegative ( int M [ ] [ 4 ] , int n , int m ) {
int count = 0 ;
int i = 0 ; int j = m - 1 ;
while ( j >= 0 && i < n ) { if ( M [ i ] [ j ] < 0 ) {
count += j + 1 ;
i += 1 ; }
else j -= 1 ; } return count ; }
int main ( ) { int M [ 3 ] [ 4 ] = { { -3 , -2 , -1 , 1 } , { -2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; cout << countNegative ( M , 3 , 4 ) ; return 0 ; }
#define N  10
int findLargestPlus ( int mat [ N ] [ N ] ) {
int left [ N ] [ N ] , right [ N ] [ N ] , top [ N ] [ N ] , bottom [ N ] [ N ] ;
for ( int i = 0 ; i < N ; i ++ ) {
top [ 0 ] [ i ] = mat [ 0 ] [ i ] ;
bottom [ N - 1 ] [ i ] = mat [ N - 1 ] [ i ] ;
left [ i ] [ 0 ] = mat [ i ] [ 0 ] ;
right [ i ] [ N - 1 ] = mat [ i ] [ N - 1 ] ; }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 1 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] == 1 ) left [ i ] [ j ] = left [ i ] [ j - 1 ] + 1 ; else left [ i ] [ j ] = 0 ;
if ( mat [ j ] [ i ] == 1 ) top [ j ] [ i ] = top [ j - 1 ] [ i ] + 1 ; else top [ j ] [ i ] = 0 ;
j = N - 1 - j ;
if ( mat [ j ] [ i ] == 1 ) bottom [ j ] [ i ] = bottom [ j + 1 ] [ i ] + 1 ; else bottom [ j ] [ i ] = 0 ;
if ( mat [ i ] [ j ] == 1 ) right [ i ] [ j ] = right [ i ] [ j + 1 ] + 1 ; else right [ i ] [ j ] = 0 ;
j = N - 1 - j ; } }
int n = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
int len = min ( min ( top [ i ] [ j ] , bottom [ i ] [ j ] ) , min ( left [ i ] [ j ] , right [ i ] [ j ] ) ) ;
if ( len > n ) n = len ; } }
if ( n ) return 4 * ( n - 1 ) + 1 ;
return 0 ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } , { 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 } , { 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 } , { 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 } , { 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 } , { 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 } , { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 } } ; cout << findLargestPlus ( mat ) ; return 0 ; }
string findLeft ( string str ) { int n = str . length ( ) ;
while ( n -- ) {
if ( str [ n ] == ' d ' ) { str [ n ] = ' c ' ; break ; } if ( str [ n ] == ' b ' ) { str [ n ] = ' a ' ; break ; }
if ( str [ n ] == ' a ' ) str [ n ] = ' b ' ; else if ( str [ n ] == ' c ' ) str [ n ] = ' d ' ; } return str ; }
int main ( ) { string str = " aacbddc " ; cout << " Left ▁ of ▁ " << str << " ▁ is ▁ " << findLeft ( str ) ; return 0 ; }
void printSpiral ( int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
int x ;
x = min ( min ( i , j ) , min ( n - 1 - i , n - 1 - j ) ) ;
if ( i <= j ) printf ( " % d TABSYMBOL ▁ " , ( n - 2 * x ) * ( n - 2 * x ) - ( i - x ) - ( j - x ) ) ;
else printf ( " % d TABSYMBOL ▁ " , ( n - 2 * x - 2 ) * ( n - 2 * x - 2 ) + ( i - x ) + ( j - x ) ) ; } printf ( " STRNEWLINE " ) ; } }
int main ( ) { int n = 5 ;
printSpiral ( n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  5
int findMaxValue ( int mat [ ] [ N ] ) {
int maxValue = INT_MIN ;
for ( int a = 0 ; a < N - 1 ; a ++ ) for ( int b = 0 ; b < N - 1 ; b ++ ) for ( int d = a + 1 ; d < N ; d ++ ) for ( int e = b + 1 ; e < N ; e ++ ) if ( maxValue < ( mat [ d ] [ e ] - mat [ a ] [ b ] ) ) maxValue = mat [ d ] [ e ] - mat [ a ] [ b ] ; return maxValue ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 2 , -1 , -4 , -20 } , { -8 , -3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { -4 , -1 , 1 , 7 , -6 } , { 0 , -4 , 10 , -5 , 1 } } ; cout << " Maximum ▁ Value ▁ is ▁ " << findMaxValue ( mat ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  5
int findMaxValue ( int mat [ ] [ N ] ) {
int maxValue = INT_MIN ;
int maxArr [ N ] [ N ] ;
maxArr [ N - 1 ] [ N - 1 ] = mat [ N - 1 ] [ N - 1 ] ;
int maxv = mat [ N - 1 ] [ N - 1 ] ; for ( int j = N - 2 ; j >= 0 ; j -- ) { if ( mat [ N - 1 ] [ j ] > maxv ) maxv = mat [ N - 1 ] [ j ] ; maxArr [ N - 1 ] [ j ] = maxv ; }
maxv = mat [ N - 1 ] [ N - 1 ] ; for ( int i = N - 2 ; i >= 0 ; i -- ) { if ( mat [ i ] [ N - 1 ] > maxv ) maxv = mat [ i ] [ N - 1 ] ; maxArr [ i ] [ N - 1 ] = maxv ; }
for ( int i = N - 2 ; i >= 0 ; i -- ) { for ( int j = N - 2 ; j >= 0 ; j -- ) {
if ( maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] > maxValue ) maxValue = maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] ;
maxArr [ i ] [ j ] = max ( mat [ i ] [ j ] , max ( maxArr [ i ] [ j + 1 ] , maxArr [ i + 1 ] [ j ] ) ) ; } } return maxValue ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 2 , -1 , -4 , -20 } , { -8 , -3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { -4 , -1 , 1 , 7 , -6 } , { 0 , -4 , 10 , -5 , 1 } } ; cout << " Maximum ▁ Value ▁ is ▁ " << findMaxValue ( mat ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  3 NEW_LINE #define C  4 NEW_LINE void modifyMatrix ( bool mat [ R ] [ C ] ) { bool row [ R ] ; bool col [ C ] ; int i , j ;
for ( i = 0 ; i < R ; i ++ ) { row [ i ] = 0 ; }
for ( i = 0 ; i < C ; i ++ ) { col [ i ] = 0 ; }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( mat [ i ] [ j ] == 1 ) { row [ i ] = 1 ; col [ j ] = 1 ; } } }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( row [ i ] == 1 col [ j ] == 1 ) { mat [ i ] [ j ] = 1 ; } } } }
void printMatrix ( bool mat [ R ] [ C ] ) { int i , j ; for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { cout << mat [ i ] [ j ] ; } cout << endl ; } }
int main ( ) { bool mat [ R ] [ C ] = { { 1 , 0 , 0 , 1 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 } } ; cout << " Input ▁ Matrix ▁ STRNEWLINE " ; printMatrix ( mat ) ; modifyMatrix ( mat ) ; printf ( " Matrix ▁ after ▁ modification ▁ STRNEWLINE " ) ; printMatrix ( mat ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  3 NEW_LINE #define C  4 NEW_LINE void modifyMatrix ( int mat [ R ] [ C ] ) {
bool row_flag = false ; bool col_flag = false ;
for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) { if ( i == 0 && mat [ i ] [ j ] == 1 ) row_flag = true ; if ( j == 0 && mat [ i ] [ j ] == 1 ) col_flag = true ; if ( mat [ i ] [ j ] == 1 ) { mat [ 0 ] [ j ] = 1 ; mat [ i ] [ 0 ] = 1 ; } } }
for ( int i = 1 ; i < R ; i ++ ) { for ( int j = 1 ; j < C ; j ++ ) { if ( mat [ 0 ] [ j ] == 1 mat [ i ] [ 0 ] == 1 ) { mat [ i ] [ j ] = 1 ; } } }
if ( row_flag == true ) { for ( int i = 0 ; i < C ; i ++ ) { mat [ 0 ] [ i ] = 1 ; } }
if ( col_flag == true ) { for ( int i = 0 ; i < R ; i ++ ) { mat [ i ] [ 0 ] = 1 ; } } }
void printMatrix ( int mat [ R ] [ C ] ) { for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) { cout << mat [ i ] [ j ] ; } cout << " STRNEWLINE " ; } }
int main ( ) { int mat [ R ] [ C ] = { { 1 , 0 , 0 , 1 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 } } ; cout << " Input ▁ Matrix ▁ : STRNEWLINE " ; printMatrix ( mat ) ; modifyMatrix ( mat ) ; cout << " Matrix ▁ After ▁ Modification ▁ : STRNEWLINE " ; printMatrix ( mat ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; #define n  5 NEW_LINE int find ( bool arr [ n ] [ n ] ) {
int i = 0 , j = n - 1 ;
int res = -1 ;
while ( i < n && j >= 0 ) {
if ( arr [ i ] [ j ] == 0 ) {
while ( j >= 0 && ( arr [ i ] [ j ] == 0 i == j ) ) j -- ;
if ( j == -1 ) { res = i ; break ; }
else i ++ ; }
else {
while ( i < n && ( arr [ i ] [ j ] == 1 i == j ) ) i ++ ;
if ( i == n ) { res = j ; break ; }
else j -- ; } }
if ( res == -1 ) return res ;
for ( int i = 0 ; i < n ; i ++ ) if ( res != i && arr [ i ] [ res ] != 1 ) return -1 ; for ( int j = 0 ; j < n ; j ++ ) if ( res != j && arr [ res ] [ j ] != 0 ) return -1 ; return res ; }
int main ( ) { bool mat [ n ] [ n ] = { { 0 , 0 , 1 , 1 , 0 } , { 0 , 0 , 0 , 1 , 0 } , { 1 , 1 , 1 , 1 , 0 } , { 0 , 0 , 0 , 0 , 0 } , { 1 , 1 , 1 , 1 , 1 } } ; cout << find ( mat ) ; return 0 ; }
int preProcess ( int mat [ M ] [ N ] , int aux [ M ] [ N ] ) {
for ( int i = 0 ; i < N ; i ++ ) aux [ 0 ] [ i ] = mat [ 0 ] [ i ] ;
for ( int i = 1 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) aux [ i ] [ j ] = mat [ i ] [ j ] + aux [ i - 1 ] [ j ] ;
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 1 ; j < N ; j ++ ) aux [ i ] [ j ] += aux [ i ] [ j - 1 ] ; }
int sumQuery ( int aux [ M ] [ N ] , int tli , int tlj , int rbi , int rbj ) {
int res = aux [ rbi ] [ rbj ] ;
if ( tli > 0 ) res = res - aux [ tli - 1 ] [ rbj ] ;
if ( tlj > 0 ) res = res - aux [ rbi ] [ tlj - 1 ] ;
if ( tli > 0 && tlj > 0 ) res = res + aux [ tli - 1 ] [ tlj - 1 ] ; return res ; }
int main ( ) { int mat [ M ] [ N ] = { { 1 , 2 , 3 , 4 , 6 } , { 5 , 3 , 8 , 1 , 2 } , { 4 , 6 , 7 , 5 , 5 } , { 2 , 4 , 8 , 9 , 4 } } ; int aux [ M ] [ N ] ; preProcess ( mat , aux ) ; int tli = 2 , tlj = 2 , rbi = 3 , rbj = 4 ; cout << " Query1 : " tli = 0 , tlj = 0 , rbi = 1 , rbj = 1 ; cout << " Query2 : " tli = 1 , tlj = 2 , rbi = 3 , rbj = 3 ; cout << " Query3 : " return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  3 NEW_LINE #define C  3
void swap ( int mat [ R ] [ C ] , int row1 , int row2 , int col ) { for ( int i = 0 ; i < col ; i ++ ) { int temp = mat [ row1 ] [ i ] ; mat [ row1 ] [ i ] = mat [ row2 ] [ i ] ; mat [ row2 ] [ i ] = temp ; } }
int rankOfMatrix ( int mat [ R ] [ C ] ) { int rank = C ; for ( int row = 0 ; row < rank ; row ++ ) {
if ( mat [ row ] [ row ] ) { for ( int col = 0 ; col < R ; col ++ ) { if ( col != row ) {
double mult = ( double ) mat [ col ] [ row ] / mat [ row ] [ row ] ; for ( int i = 0 ; i < rank ; i ++ ) mat [ col ] [ i ] -= mult * mat [ row ] [ i ] ; } } }
else { bool reduce = true ;
for ( int i = row + 1 ; i < R ; i ++ ) {
if ( mat [ i ] [ row ] ) { swap ( mat , row , i , rank ) ; reduce = false ; break ; } }
if ( reduce ) {
rank -- ;
for ( int i = 0 ; i < R ; i ++ ) mat [ i ] [ row ] = mat [ i ] [ rank ] ; }
row -- ; }
} return rank ; }
void display ( int mat [ R ] [ C ] , int row , int col ) { for ( int i = 0 ; i < row ; i ++ ) { for ( int j = 0 ; j < col ; j ++ ) printf ( " ▁ % d " , mat [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } }
int main ( ) { int mat [ ] [ 3 ] = { { 10 , 20 , 10 } , { -20 , -30 , 10 } , { 30 , 50 , 0 } } ; printf ( " Rank ▁ of ▁ the ▁ matrix ▁ is ▁ : ▁ % d " , rankOfMatrix ( mat ) ) ; return 0 ; }
int countIslands ( int mat [ ] [ N ] ) {
int count = 0 ;
for ( int i = 0 ; i < M ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] == ' X ' ) { if ( ( i == 0 mat [ i - 1 ] [ j ] == ' O ' ) && ( j == 0 mat [ i ] [ j - 1 ] == ' O ' ) ) count ++ ; } } } return count ; }
int main ( ) { int mat [ M ] [ N ] = { { ' O ' , ' O ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' } , { ' O ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' O ' } } ; cout << " Number ▁ of ▁ rectangular ▁ islands ▁ is ▁ " << countIslands ( mat ) ; return 0 ; }
#define M  6 NEW_LINE #define N  6
void floodFillUtil ( char mat [ ] [ N ] , int x , int y , char prevV , char newV ) {
if ( x < 0 x > = M y < 0 y > = N ) return ; if ( mat [ x ] [ y ] != prevV ) return ;
mat [ x ] [ y ] = newV ;
floodFillUtil ( mat , x + 1 , y , prevV , newV ) ; floodFillUtil ( mat , x - 1 , y , prevV , newV ) ; floodFillUtil ( mat , x , y + 1 , prevV , newV ) ; floodFillUtil ( mat , x , y - 1 , prevV , newV ) ; }
int replaceSurrounded ( char mat [ ] [ N ] ) {
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' O ' ) mat [ i ] [ j ] = ' - ' ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ 0 ] == ' - ' ) floodFillUtil ( mat , i , 0 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ N - 1 ] == ' - ' ) floodFillUtil ( mat , i , N - 1 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ 0 ] [ i ] == ' - ' ) floodFillUtil ( mat , 0 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ M - 1 ] [ i ] == ' - ' ) floodFillUtil ( mat , M - 1 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' - ' ) mat [ i ] [ j ] = ' X ' ; }
int main ( ) { char mat [ ] [ N ] = { { ' X ' , ' O ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' X ' , ' O ' , ' X ' , ' X ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' O ' , ' X ' , ' X ' , ' X ' , ' X ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' , ' O ' , ' O ' , ' O ' } , } ; replaceSurrounded ( mat ) ; for ( int i = 0 ; i < M ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) cout << mat [ i ] [ j ] << " ▁ " ; cout << endl ; } return 0 ; }
#define n  5
void printSumSimple ( int mat [ ] [ n ] , int k ) {
if ( k > n ) return ;
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
for ( int j = 0 ; j < n - k + 1 ; j ++ ) {
int sum = 0 ; for ( int p = i ; p < k + i ; p ++ ) for ( int q = j ; q < k + j ; q ++ ) sum += mat [ p ] [ q ] ; cout << sum << " ▁ " ; }
cout << endl ; } }
int main ( ) { int mat [ n ] [ n ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; int k = 3 ; printSumSimple ( mat , k ) ; return 0 ; }
#define n  5
void printSumTricky ( int mat [ ] [ n ] , int k ) {
if ( k > n ) return ;
int stripSum [ n ] [ n ] ;
for ( int j = 0 ; j < n ; j ++ ) {
int sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) sum += mat [ i ] [ j ] ; stripSum [ 0 ] [ j ] = sum ;
for ( int i = 1 ; i < n - k + 1 ; i ++ ) { sum += ( mat [ i + k - 1 ] [ j ] - mat [ i - 1 ] [ j ] ) ; stripSum [ i ] [ j ] = sum ; } }
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
int sum = 0 ; for ( int j = 0 ; j < k ; j ++ ) sum += stripSum [ i ] [ j ] ; cout << sum << " ▁ " ;
for ( int j = 1 ; j < n - k + 1 ; j ++ ) { sum += ( stripSum [ i ] [ j + k - 1 ] - stripSum [ i ] [ j - 1 ] ) ; cout << sum << " ▁ " ; } cout << endl ; } }
int main ( ) { int mat [ n ] [ n ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; int k = 3 ; printSumTricky ( mat , k ) ; return 0 ; }
#include <stdio.h> NEW_LINE #define M  3 NEW_LINE #define N  4
void transpose ( int A [ ] [ N ] , int B [ ] [ M ] ) { int i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < M ; j ++ ) B [ i ] [ j ] = A [ j ] [ i ] ; }
int main ( ) { int A [ M ] [ N ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } } ; int B [ N ] [ M ] , i , j ; transpose ( A , B ) ; printf ( " Result ▁ matrix ▁ is ▁ STRNEWLINE " ) ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < M ; j ++ ) printf ( " % d ▁ " , B [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  4
void transpose ( int A [ ] [ N ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) swap ( A [ i ] [ j ] , A [ j ] [ i ] ) ; }
int main ( ) { int A [ N ] [ N ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; transpose ( A ) ; printf ( " Modified ▁ matrix ▁ is ▁ STRNEWLINE " ) ; for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) printf ( " % d ▁ " , A [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define R  3 NEW_LINE #define C  3 NEW_LINE using namespace std ;
int pathCountRec ( int mat [ ] [ C ] , int m , int n , int k ) {
if ( m < 0 n < 0 ) return 0 ; if ( m == 0 && n == 0 ) return ( k == mat [ m ] [ n ] ) ;
return pathCountRec ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountRec ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; }
int pathCount ( int mat [ ] [ C ] , int k ) { return pathCountRec ( mat , R - 1 , C - 1 , k ) ; }
int main ( ) { int k = 12 ; int mat [ R ] [ C ] = { { 1 , 2 , 3 } , { 4 , 6 , 5 } , { 3 , 2 , 1 } } ; cout << pathCount ( mat , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define R  3 NEW_LINE #define C  3 NEW_LINE using namespace std ;
int x [ ] = { 0 , 1 , 1 , -1 , 1 , 0 , -1 , -1 } ; int y [ ] = { 1 , 0 , 1 , 1 , -1 , -1 , 0 , -1 } ;
int dp [ R ] [ C ] ;
bool isvalid ( int i , int j ) { if ( i < 0 j < 0 i > = R j > = C ) return false ; return true ; }
bool isadjacent ( char prev , char curr ) { return ( ( curr - prev ) == 1 ) ; }
int getLenUtil ( char mat [ R ] [ C ] , int i , int j , char prev ) {
if ( ! isvalid ( i , j ) || ! isadjacent ( prev , mat [ i ] [ j ] ) ) return 0 ;
if ( dp [ i ] [ j ] != -1 ) return dp [ i ] [ j ] ;
int ans = 0 ;
for ( int k = 0 ; k < 8 ; k ++ ) ans = max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , mat [ i ] [ j ] ) ) ;
return dp [ i ] [ j ] = ans ; }
int getLen ( char mat [ R ] [ C ] , char s ) { memset ( dp , -1 , sizeof dp ) ; int ans = 0 ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) {
if ( mat [ i ] [ j ] == s ) {
for ( int k = 0 ; k < 8 ; k ++ ) ans = max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , s ) ) ; } } } return ans ; }
int main ( ) { char mat [ R ] [ C ] = { { ' a ' , ' c ' , ' d ' } , { ' h ' , ' b ' , ' a ' } , { ' i ' , ' g ' , ' f ' } } ; cout << getLen ( mat , ' a ' ) << endl ; cout << getLen ( mat , ' e ' ) << endl ; cout << getLen ( mat , ' b ' ) << endl ; cout << getLen ( mat , ' f ' ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define R  3 NEW_LINE #define C  3 NEW_LINE using namespace std ; int minInitialPoints ( int points [ ] [ C ] ) {
int dp [ R ] [ C ] ; int m = R , n = C ;
dp [ m - 1 ] [ n - 1 ] = points [ m - 1 ] [ n - 1 ] > 0 ? 1 : abs ( points [ m - 1 ] [ n - 1 ] ) + 1 ;
for ( int i = m - 2 ; i >= 0 ; i -- ) dp [ i ] [ n - 1 ] = max ( dp [ i + 1 ] [ n - 1 ] - points [ i ] [ n - 1 ] , 1 ) ; for ( int j = n - 2 ; j >= 0 ; j -- ) dp [ m - 1 ] [ j ] = max ( dp [ m - 1 ] [ j + 1 ] - points [ m - 1 ] [ j ] , 1 ) ;
for ( int i = m - 2 ; i >= 0 ; i -- ) { for ( int j = n - 2 ; j >= 0 ; j -- ) { int min_points_on_exit = min ( dp [ i + 1 ] [ j ] , dp [ i ] [ j + 1 ] ) ; dp [ i ] [ j ] = max ( min_points_on_exit - points [ i ] [ j ] , 1 ) ; } } return dp [ 0 ] [ 0 ] ; }
int main ( ) { int points [ R ] [ C ] = { { -2 , -3 , 3 } , { -5 , -10 , 1 } , { 10 , 30 , -5 } } ; cout << " Minimum ▁ Initial ▁ Points ▁ Required : ▁ " << minInitialPoints ( points ) ; return 0 ; }
