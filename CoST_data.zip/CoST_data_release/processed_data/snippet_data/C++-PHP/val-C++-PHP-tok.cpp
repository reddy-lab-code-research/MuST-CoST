void calculateSpan ( int price [ ] , int n , int S [ ] ) {
S [ 0 ] = 1 ;
for ( int i = 1 ; i < n ; i ++ ) {
S [ i ] = 1 ;
for ( int j = i - 1 ; ( j >= 0 ) && ( price [ i ] >= price [ j ] ) ; j -- ) S [ i ] ++ ; } }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int price [ ] = { 10 , 4 , 5 , 90 , 120 , 80 } ; int n = sizeof ( price ) / sizeof ( price [ 0 ] ) ; int S [ n ] ;
calculateSpan ( price , n , S ) ;
int findSubArray ( int arr [ ] , int n ) { int sum = 0 ; int maxsize = -1 , startindex ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { sum = ( arr [ i ] == 0 ) ? -1 : 1 ;
for ( int j = i + 1 ; j < n ; j ++ ) { ( arr [ j ] == 0 ) ? ( sum += -1 ) : ( sum += 1 ) ;
if ( sum == 0 && maxsize < j - i + 1 ) { maxsize = j - i + 1 ; startindex = i ; } } } if ( maxsize == -1 ) cout << " No ▁ such ▁ subarray " ; else cout << startindex << " ▁ to ▁ " << startindex + maxsize - 1 ; return maxsize ; }
int main ( ) { int arr [ ] = { 1 , 0 , 0 , 1 , 0 , 1 , 1 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findSubArray ( arr , size ) ; return 0 ; }
void leftRotatebyOne ( int arr [ ] , int n ) { int temp = arr [ 0 ] , i ; for ( i = 0 ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; arr [ n - 1 ] = temp ; }
void leftRotate ( int arr [ ] , int d , int n ) { for ( int i = 0 ; i < d ; i ++ ) leftRotatebyOne ( arr , n ) ; }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; leftRotate ( arr , 2 , n ) ; printArray ( arr , n ) ; return 0 ; }
void print2Smallest ( int arr [ ] , int arr_size ) { int i , first , second ;
if ( arr_size < 2 ) { cout << " ▁ Invalid ▁ Input ▁ " ; return ; } first = second = INT_MAX ; for ( i = 0 ; i < arr_size ; i ++ ) {
if ( arr [ i ] < first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] < second && arr [ i ] != first ) second = arr [ i ] ; } if ( second == INT_MAX ) cout << " There ▁ is ▁ no ▁ second ▁ smallest ▁ element STRNEWLINE " ; else cout << " The ▁ smallest ▁ element ▁ is ▁ " << first << " ▁ and ▁ second ▁ " " Smallest ▁ element ▁ is ▁ " << second << endl ; }
int main ( ) { int arr [ ] = { 12 , 13 , 1 , 10 , 34 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; print2Smallest ( arr , n ) ; return 0 ; }
int findFirstMissing ( int array [ ] , int start , int end ) { if ( start > end ) return end + 1 ; if ( start != array [ start ] ) return start ; int mid = ( start + end ) / 2 ;
if ( array [ mid ] == mid ) return findFirstMissing ( array , mid + 1 , end ) ; return findFirstMissing ( array , start , mid ) ; }
int main ( ) { int arr [ ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Smallest ▁ missing ▁ element ▁ is ▁ " << findFirstMissing ( arr , 0 , n - 1 ) << endl ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int getInvCount ( int arr [ ] , int n ) { int inv_count = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) inv_count ++ ; return inv_count ; }
int main ( ) { int arr [ ] = { 1 , 20 , 6 , 4 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " ▁ Number ▁ of ▁ inversions ▁ are ▁ " << getInvCount ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void printUnsorted ( int arr [ ] , int n ) { int s = 0 , e = n - 1 , i , max , min ;
for ( s = 0 ; s < n - 1 ; s ++ ) { if ( arr [ s ] > arr [ s + 1 ] ) break ; } if ( s == n - 1 ) { cout << " The ▁ complete ▁ array ▁ is ▁ sorted " ; return ; }
for ( e = n - 1 ; e > 0 ; e -- ) { if ( arr [ e ] < arr [ e - 1 ] ) break ; }
max = arr [ s ] ; min = arr [ s ] ; for ( i = s + 1 ; i <= e ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; if ( arr [ i ] < min ) min = arr [ i ] ; }
for ( i = 0 ; i < s ; i ++ ) { if ( arr [ i ] > min ) { s = i ; break ; } }
for ( i = n - 1 ; i >= e + 1 ; i -- ) { if ( arr [ i ] < max ) { e = i ; break ; } }
cout << " The ▁ unsorted ▁ subarray ▁ which " << " ▁ makes ▁ the ▁ given ▁ array " << endl << " sorted ▁ lies ▁ between ▁ the ▁ indees ▁ " << s << " ▁ and ▁ " << e ; return ; } int main ( ) { int arr [ ] = { 10 , 12 , 20 , 30 , 25 , 40 , 32 , 31 , 35 , 50 , 60 } ; int arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printUnsorted ( arr , arr_size ) ; getchar ( ) ; return 0 ; }
int findElement ( int arr [ ] , int n , int key ) { int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return -1 ; }
int main ( ) { int arr [ ] = { 12 , 34 , 10 , 6 , 40 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
int key = 40 ; int position = findElement ( arr , n , key ) ; if ( position == - 1 ) cout << " Element ▁ not ▁ found " ; else cout << " Element ▁ Found ▁ at ▁ Position : ▁ " << position + 1 ; return 0 ; }
int equilibrium ( int arr [ ] , int n ) {
int sum = 0 ;
int leftsum = 0 ;
for ( int i = 0 ; i < n ; ++ i ) sum += arr [ i ] ; for ( int i = 0 ; i < n ; ++ i ) {
sum -= arr [ i ] ; if ( leftsum == sum ) return i ; leftsum += arr [ i ] ; }
return -1 ; }
int main ( ) { int arr [ ] = { -7 , 1 , 5 , 2 , -4 , 3 , 0 } ; int arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " First ▁ equilibrium ▁ index ▁ is ▁ " << equilibrium ( arr , arr_size ) ; return 0 ; }
int ceilSearch ( int arr [ ] , int low , int high , int x ) { int i ;
if ( x <= arr [ low ] ) return low ;
for ( i = low ; i < high ; i ++ ) { if ( arr [ i ] == x ) return i ;
if ( arr [ i ] < x && arr [ i + 1 ] >= x ) return i + 1 ; }
return -1 ; }
int main ( ) { int arr [ ] = { 1 , 2 , 8 , 10 , 10 , 12 , 19 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 3 ; int index = ceilSearch ( arr , 0 , n - 1 , x ) ; if ( index == -1 ) cout << " Ceiling ▁ of ▁ " << x << " ▁ doesn ' t ▁ exist ▁ in ▁ array ▁ " ; else cout << " ceiling ▁ of ▁ " << x << " ▁ is ▁ " << arr [ index ] ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; bool isMajority ( int arr [ ] , int n , int x ) { int i ;
int last_index = n % 2 ? ( n / 2 + 1 ) : ( n / 2 ) ;
for ( i = 0 ; i < last_index ; i ++ ) {
if ( arr [ i ] == x && arr [ i + n / 2 ] == x ) return 1 ; } return 0 ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 4 , 4 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 4 ; if ( isMajority ( arr , n , x ) ) cout << x << " ▁ appears ▁ more ▁ than ▁ " << n / 2 << " ▁ times ▁ in ▁ arr [ ] " << endl ; else cout << x << " ▁ does ▁ not ▁ appear ▁ more ▁ than " << n / 2 << " ▁ times ▁ in ▁ arr [ ] " << endl ; return 0 ; }
int findPeakUtil ( int arr [ ] , int low , int high , int n ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == 0 arr [ mid - 1 ] <= arr [ mid ] ) && ( mid == n - 1 arr [ mid + 1 ] <= arr [ mid ] ) ) return mid ;
else if ( mid > 0 && arr [ mid - 1 ] > arr [ mid ] ) return findPeakUtil ( arr , low , ( mid - 1 ) , n ) ;
else return findPeakUtil ( arr , ( mid + 1 ) , high , n ) ; }
int findPeak ( int arr [ ] , int n ) { return findPeakUtil ( arr , 0 , n - 1 , n ) ; }
int main ( ) { int arr [ ] = { 1 , 3 , 20 , 4 , 1 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Index ▁ of ▁ a ▁ peak ▁ point ▁ is ▁ " << findPeak ( arr , n ) ; return 0 ; }
void printRepeating ( int arr [ ] , int size ) { int * count = new int [ sizeof ( int ) * ( size - 2 ) ] ; int i ; cout << " ▁ Repeating ▁ elements ▁ are ▁ " ; for ( i = 0 ; i < size ; i ++ ) { if ( count [ arr [ i ] ] == 1 ) cout << arr [ i ] << " ▁ " ; else count [ arr [ i ] ] ++ ; } }
int main ( ) { int arr [ ] = { 4 , 2 , 4 , 5 , 2 , 3 , 1 } ; int arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printRepeating ( arr , arr_size ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int linearSearch ( int arr [ ] , int n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == i ) return i ; }
return -1 ; }
int main ( ) { int arr [ ] = { -10 , -1 , 0 , 3 , 10 , 11 , 30 , 50 , 100 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Fixed ▁ Point ▁ is ▁ " << linearSearch ( arr , n ) ; return 0 ; }
int subArraySum ( int arr [ ] , int n , int sum ) { int curr_sum , i , j ;
for ( i = 0 ; i < n ; i ++ ) { curr_sum = arr [ i ] ;
for ( j = i + 1 ; j <= n ; j ++ ) { if ( curr_sum == sum ) { cout << " Sum ▁ found ▁ between ▁ indexes ▁ " << i << " ▁ and ▁ " << j - 1 ; return 1 ; } if ( curr_sum > sum j == n ) break ; curr_sum = curr_sum + arr [ j ] ; } } cout << " No ▁ subarray ▁ found " ; return 0 ; }
int main ( ) { int arr [ ] = { 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int sum = 23 ; subArraySum ( arr , n , sum ) ; return 0 ; }
int subArraySum ( int arr [ ] , int n , int sum ) {
int curr_sum = arr [ 0 ] , start = 0 , i ;
for ( i = 1 ; i <= n ; i ++ ) {
while ( curr_sum > sum && start < i - 1 ) { curr_sum = curr_sum - arr [ start ] ; start ++ ; }
if ( curr_sum == sum ) { cout << " Sum ▁ found ▁ between ▁ indexes ▁ " << start << " ▁ and ▁ " << i - 1 ; return 1 ; }
if ( i < n ) curr_sum = curr_sum + arr [ i ] ; }
cout << " No ▁ subarray ▁ found " ; return 0 ; }
int main ( ) { int arr [ ] = { 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int sum = 23 ; subArraySum ( arr , n , sum ) ; return 0 ; }
int MatrixChainOrder ( int p [ ] , int i , int j ) { if ( i == j ) return 0 ; int k ; int min = INT_MAX ; int count ;
for ( k = i ; k < j ; k ++ ) { count = MatrixChainOrder ( p , i , k ) + MatrixChainOrder ( p , k + 1 , j ) + p [ i - 1 ] * p [ k ] * p [ j ] ; if ( count < min ) min = count ; }
return min ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " << MatrixChainOrder ( arr , 1 , n - 1 ) ; }
int MatrixChainOrder ( int p [ ] , int n ) {
int m [ n ] [ n ] ; int i , j , k , L , q ;
for ( i = 1 ; i < n ; i ++ ) m [ i ] [ i ] = 0 ;
for ( L = 2 ; L < n ; L ++ ) { for ( i = 1 ; i < n - L + 1 ; i ++ ) { j = i + L - 1 ; m [ i ] [ j ] = INT_MAX ; for ( k = i ; k <= j - 1 ; k ++ ) {
q = m [ i ] [ k ] + m [ k + 1 ] [ j ] + p [ i - 1 ] * p [ k ] * p [ j ] ; if ( q < m [ i ] [ j ] ) m [ i ] [ j ] = q ; } } } return m [ 1 ] [ n - 1 ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " << MatrixChainOrder ( arr , size ) ; getchar ( ) ; return 0 ; }
int knapSack ( int W , int wt [ ] , int val [ ] , int n ) {
if ( n == 0 W == 0 ) return 0 ;
if ( wt [ n - 1 ] > W ) return knapSack ( W , wt , val , n - 1 ) ;
else return max ( val [ n - 1 ] + knapSack ( W - wt [ n - 1 ] , wt , val , n - 1 ) , knapSack ( W , wt , val , n - 1 ) ) ; }
int main ( ) { int val [ ] = { 60 , 100 , 120 } ; int wt [ ] = { 10 , 20 , 30 } ; int W = 50 ; int n = sizeof ( val ) / sizeof ( val [ 0 ] ) ; cout << knapSack ( W , wt , val , n ) ; return 0 ; }
int count ( int n ) {
int table [ n + 1 ] , i ;
table [ 0 ] = 1 ;
for ( i = 3 ; i <= n ; i ++ ) table [ i ] += table [ i - 3 ] ; for ( i = 5 ; i <= n ; i ++ ) table [ i ] += table [ i - 5 ] ; for ( i = 10 ; i <= n ; i ++ ) table [ i ] += table [ i - 10 ] ; return table [ n ] ; }
int main ( void ) { int n = 20 ; cout << " Count ▁ for ▁ " << n << " ▁ is ▁ " << count ( n ) << endl ; n = 13 ; cout << " Count ▁ for ▁ " << n << " ▁ is ▁ " << count ( n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void search ( char * pat , char * txt ) { int M = strlen ( pat ) ; int N = strlen ( txt ) ;
for ( int i = 0 ; i <= N - M ; i ++ ) { int j ;
for ( j = 0 ; j < M ; j ++ ) if ( txt [ i + j ] != pat [ j ] ) break ;
if ( j == M ) cout << " Pattern ▁ found ▁ at ▁ index ▁ " << i << endl ; } }
int main ( ) { char txt [ ] = " AABAACAADAABAAABAA " ; char pat [ ] = " AABA " ; search ( pat , txt ) ; return 0 ; }
#define d  256
void search ( char pat [ ] , char txt [ ] , int q ) { int M = strlen ( pat ) ; int N = strlen ( txt ) ; int i , j ;
int p = 0 ;
int t = 0 ; int h = 1 ;
for ( i = 0 ; i < M - 1 ; i ++ ) h = ( h * d ) % q ;
for ( i = 0 ; i < M ; i ++ ) { p = ( d * p + pat [ i ] ) % q ; t = ( d * t + txt [ i ] ) % q ; }
for ( i = 0 ; i <= N - M ; i ++ ) {
if ( p == t ) {
for ( j = 0 ; j < M ; j ++ ) { if ( txt [ i + j ] != pat [ j ] ) break ; }
if ( j == M ) cout << " Pattern ▁ found ▁ at ▁ index ▁ " << i << endl ; }
if ( i < N - M ) { t = ( d * ( t - txt [ i ] * h ) + txt [ i + M ] ) % q ;
if ( t < 0 ) t = ( t + q ) ; } } }
int main ( ) { char txt [ ] = " GEEKS ▁ FOR ▁ GEEKS " ; char pat [ ] = " GEEK " ;
int q = 101 ;
search ( pat , txt , q ) ; return 0 ; }
public : int power ( int x , unsigned int y ) { if ( y == 0 ) return 1 ; else if ( y % 2 == 0 ) return power ( x , y / 2 ) * power ( x , y / 2 ) ; else return x * power ( x , y / 2 ) * power ( x , y / 2 ) ; } } ;
int main ( ) { gfg g ; int x = 2 ; unsigned int y = 3 ; cout << g . power ( x , y ) ; return 0 ; }
bool isLucky ( int n ) { static int counter = 2 ;
int next_position = n ; if ( counter > n ) return 1 ; if ( n % counter == 0 ) return 0 ;
next_position -= next_position / counter ; counter ++ ; return isLucky ( next_position ) ; }
int main ( ) { int x = 5 ; if ( isLucky ( x ) ) cout << x << " ▁ is ▁ a ▁ lucky ▁ no . " ; else cout << x << " ▁ is ▁ not ▁ a ▁ lucky ▁ no . " ; }
public : float squareRoot ( float n ) {
float x = n ; float y = 1 ; float e = 0.000001 ;
while ( x - y > e ) { x = ( x + y ) / 2 ; y = n / x ; } return x ; } } ;
int main ( ) { gfg g ; int n = 50 ; cout << " Square ▁ root ▁ of ▁ " << n << " ▁ is ▁ " << g . squareRoot ( n ) ; getchar ( ) ; }
int multiply ( int x , int y ) { if ( y ) return ( x + multiply ( x , y - 1 ) ) ; else return 0 ; }
int pow ( int a , int b ) { if ( b ) return multiply ( a , pow ( a , b - 1 ) ) ; else return 1 ; }
int main ( ) { cout << pow ( 5 , 3 ) ; getchar ( ) ; return 0 ; }
float getAvg ( int x ) { static int sum , n ; sum += x ; return ( ( ( float ) sum ) / ++ n ) ; }
void streamAvg ( float arr [ ] , int n ) { float avg = 0 ; for ( int i = 0 ; i < n ; i ++ ) { avg = getAvg ( arr [ i ] ) ; cout << " Average ▁ of ▁ " << i + 1 << " ▁ numbers ▁ is ▁ " << fixed << setprecision ( 1 ) << avg << endl ; } return ; }
int main ( ) { float arr [ ] = { 10 , 20 , 30 , 40 , 50 , 60 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; streamAvg ( arr , n ) ; return 0 ; }
int count ( int n ) {
if ( n < 3 ) return n ; if ( n >= 3 && n < 10 ) return n - 1 ;
int po = 1 ; while ( n / po > 9 ) po = po * 10 ;
int msd = n / po ; if ( msd != 3 )
return count ( msd ) * count ( po - 1 ) + count ( msd ) + count ( n % po ) ; else
return count ( msd * po - 1 ) ; }
int main ( ) { cout << count ( 578 ) << " ▁ " ; return 0 ; }
void printPascal ( int n ) {
int arr [ n ] [ n ] ;
for ( int line = 0 ; line < n ; line ++ ) {
for ( int i = 0 ; i <= line ; i ++ ) {
if ( line == i i == 0 ) arr [ line ] [ i ] = 1 ;
else arr [ line ] [ i ] = arr [ line - 1 ] [ i - 1 ] + arr [ line - 1 ] [ i ] ; cout << arr [ line ] [ i ] << " ▁ " ; } cout << " STRNEWLINE " ; } }
int main ( ) { int n = 5 ; printPascal ( n ) ; return 0 ; }
void primeFactors ( int n ) {
while ( n % 2 == 0 ) { cout << 2 << " ▁ " ; n = n / 2 ; }
for ( int i = 3 ; i <= sqrt ( n ) ; i = i + 2 ) {
while ( n % i == 0 ) { cout << i << " ▁ " ; n = n / i ; } }
if ( n > 2 ) cout << n << " ▁ " ; }
int main ( ) { int n = 315 ; primeFactors ( n ) ; return 0 ; }
void printCombination ( int arr [ ] , int n , int r ) {
int data [ r ] ;
combinationUtil ( arr , data , 0 , n - 1 , 0 , r ) ; }
void combinationUtil ( int arr [ ] , int data [ ] , int start , int end , int index , int r ) {
if ( index == r ) { for ( int j = 0 ; j < r ; j ++ ) cout << data [ j ] << " ▁ " ; cout << endl ; return ; }
for ( int i = start ; i <= end && end - i + 1 >= r - index ; i ++ ) { data [ index ] = arr [ i ] ; combinationUtil ( arr , data , i + 1 , end , index + 1 , r ) ; } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int r = 3 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printCombination ( arr , n , r ) ; }
int findgroups ( int arr [ ] , int n ) {
int c [ 3 ] = { 0 } , i ;
int res = 0 ;
for ( i = 0 ; i < n ; i ++ ) c [ arr [ i ] % 3 ] ++ ;
res += ( ( c [ 0 ] * ( c [ 0 ] - 1 ) ) >> 1 ) ;
res += c [ 1 ] * c [ 2 ] ;
res += ( c [ 0 ] * ( c [ 0 ] - 1 ) * ( c [ 0 ] - 2 ) ) / 6 ;
res += ( c [ 1 ] * ( c [ 1 ] - 1 ) * ( c [ 1 ] - 2 ) ) / 6 ;
res += ( ( c [ 2 ] * ( c [ 2 ] - 1 ) * ( c [ 2 ] - 2 ) ) / 6 ) ;
res += c [ 0 ] * c [ 1 ] * c [ 2 ] ;
return res ; }
int main ( ) { int arr [ ] = { 3 , 6 , 7 , 2 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Required ▁ number ▁ of ▁ groups ▁ are ▁ " << findgroups ( arr , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int swapBits ( unsigned int x , unsigned int p1 , unsigned int p2 , unsigned int n ) {
unsigned int set1 = ( x >> p1 ) & ( ( 1U << n ) - 1 ) ;
unsigned int set2 = ( x >> p2 ) & ( ( 1U << n ) - 1 ) ;
unsigned int Xor = ( set1 ^ set2 ) ;
Xor = ( Xor << p1 ) | ( Xor << p2 ) ;
unsigned int result = x ^ Xor ; return result ; }
int main ( ) { int res = swapBits ( 28 , 0 , 3 , 2 ) ; cout << " Result ▁ = ▁ " << res ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int Add ( int x , int y ) {
while ( y != 0 ) {
int carry = x & y ;
x = x ^ y ;
y = carry << 1 ; } return x ; }
int main ( ) { cout << Add ( 15 , 32 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int addOne ( int x ) { int m = 1 ;
while ( x & m ) { x = x ^ m ; m <<= 1 ; }
x = x ^ m ; return x ; }
int main ( ) { cout << addOne ( 13 ) ; return 0 ; }
int fun ( unsigned int n ) { return n & ( n - 1 ) ; }
int main ( ) { int n = 7 ; cout << " The ▁ number ▁ after ▁ unsetting ▁ the " ; cout << " ▁ rightmost ▁ set ▁ bit ▁ " << fun ( n ) ; return 0 ; }
public : bool isPowerOfFour ( int n ) { if ( n == 0 ) return 0 ; while ( n != 1 ) { if ( n % 4 != 0 ) return 0 ; n = n / 4 ; } return 1 ; } } ;
int main ( ) { GFG g ; int test_no = 64 ; if ( g . isPowerOfFour ( test_no ) ) cout << test_no << " ▁ is ▁ a ▁ power ▁ of ▁ 4" ; else cout << test_no << " is ▁ not ▁ a ▁ power ▁ of ▁ 4" ; getchar ( ) ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; unsigned int nextPowerOf2 ( unsigned int n ) { unsigned count = 0 ;
if ( n && ! ( n & ( n - 1 ) ) ) return n ; while ( n != 0 ) { n >>= 1 ; count += 1 ; } return 1 << count ; }
int main ( ) { unsigned int n = 0 ; cout << nextPowerOf2 ( n ) ; return 0 ; }
bool isPowerOfTwo ( int n ) { if ( n == 0 ) return 0 ; while ( n != 1 ) { if ( n % 2 != 0 ) return 0 ; n = n / 2 ; } return 1 ; }
int main ( ) { isPowerOfTwo ( 31 ) ? cout << " Yes STRNEWLINE " : cout << " No STRNEWLINE " ; isPowerOfTwo ( 64 ) ? cout << " Yes STRNEWLINE " : cout << " No STRNEWLINE " ; return 0 ; }
#include <iostream> NEW_LINE #include <math.h> NEW_LINE using namespace std ; class gfg { public : unsigned int getFirstSetBitPos ( int n ) { return log2 ( n & - n ) + 1 ; } } ;
int main ( ) { gfg g ; int n = 12 ; cout << g . getFirstSetBitPos ( n ) ; return 0 ; }
int isPowerOfTwo ( unsigned n ) { return n && ( ! ( n & ( n - 1 ) ) ) ; }
int findPosition ( unsigned n ) { if ( ! isPowerOfTwo ( n ) ) return -1 ; unsigned count = 0 ;
while ( n ) { n = n >> 1 ;
++ count ; } return count ; }
int main ( void ) { int n = 0 ; int pos = findPosition ( n ) ; ( pos == -1 ) ? cout << " n ▁ = ▁ " << n << " , ▁ Invalid ▁ number STRNEWLINE " : cout << " n ▁ = ▁ " << n << " , ▁ Position ▁ " << pos << endl ; n = 12 ; pos = findPosition ( n ) ; ( pos == -1 ) ? cout << " n ▁ = ▁ " << n << " , ▁ Invalid ▁ number STRNEWLINE " : cout << " n ▁ = ▁ " << n << " , ▁ Position ▁ " << pos << endl ; n = 128 ; pos = findPosition ( n ) ; ( pos == -1 ) ? cout << " n ▁ = ▁ " << n << " , ▁ Invalid ▁ number STRNEWLINE " : cout << " n ▁ = ▁ " << n << " , ▁ Position ▁ " << pos << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int main ( ) { int x = 10 , y = 5 ;
x = x * y ;
y = x / y ;
x = x / y ; cout << " After ▁ Swapping : ▁ x ▁ = " << x << " , ▁ y = " << y ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int main ( ) { int x = 10 , y = 5 ;
x = x ^ y ;
y = x ^ y ;
x = x ^ y ; cout << " After ▁ Swapping : ▁ x ▁ = " << x << " , ▁ y = " << y ; return 0 ; }
void swap ( int * xp , int * yp ) { * xp = * xp ^ * yp ; * yp = * xp ^ * yp ; * xp = * xp ^ * yp ; }
int main ( ) { int x = 10 ; swap ( & x , & x ) ; cout << " After ▁ swap ( & x , ▁ & x ) : ▁ x ▁ = ▁ " << x ; return 0 ; }
int maxIndexDiff ( int arr [ ] , int n ) { int maxDiff = -1 ; int i , j ; for ( i = 0 ; i < n ; ++ i ) { for ( j = n - 1 ; j > i ; -- j ) { if ( arr [ j ] > arr [ i ] && maxDiff < ( j - i ) ) maxDiff = j - i ; } } return maxDiff ; }
int main ( ) { int arr [ ] = { 9 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 18 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int maxDiff = maxIndexDiff ( arr , n ) ; cout << " STRNEWLINE " << maxDiff ; return 0 ; }
int findMaximum ( int arr [ ] , int low , int high ) { int max = arr [ low ] ; int i ; for ( i = low + 1 ; i <= high ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; else break ; } return max ; }
int main ( ) { int arr [ ] = { 1 , 30 , 40 , 50 , 60 , 70 , 23 , 20 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " The ▁ maximum ▁ element ▁ is ▁ " << findMaximum ( arr , 0 , n - 1 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void printSorted ( int arr [ ] , int start , int end ) { if ( start > end ) return ;
printSorted ( arr , start * 2 + 1 , end ) ;
cout << arr [ start ] << " ▁ " ;
printSorted ( arr , start * 2 + 2 , end ) ; }
int main ( ) { int arr [ ] = { 4 , 2 , 5 , 1 , 3 } ; int arr_size = sizeof ( arr ) / sizeof ( int ) ; printSorted ( arr , 0 , arr_size - 1 ) ; getchar ( ) ; return 0 ; }
int search ( int mat [ 4 ] [ 4 ] , int n , int x ) { if ( n == 0 ) return -1 ; int smallest = mat [ 0 ] [ 0 ] , largest = mat [ n - 1 ] [ n - 1 ] ; if ( x < smallest x > largest ) return -1 ;
int i = 0 , j = n - 1 ; while ( i < n && j >= 0 ) { if ( mat [ i ] [ j ] == x ) { cout << " n ▁ Found ▁ at ▁ " << i << " , ▁ " << j ; return 1 ; } if ( mat [ i ] [ j ] > x ) j -- ;
else i ++ ; } cout << " n ▁ Element ▁ not ▁ found " ;
return 0 ; }
int main ( ) { int mat [ 4 ] [ 4 ] = { { 10 , 20 , 30 , 40 } , { 15 , 25 , 35 , 45 } , { 27 , 29 , 37 , 48 } , { 32 , 33 , 39 , 50 } } ; search ( mat , 4 , 29 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  4
void add ( int A [ ] [ N ] , int B [ ] [ N ] , int C [ ] [ N ] ) { int i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < N ; j ++ ) C [ i ] [ j ] = A [ i ] [ j ] + B [ i ] [ j ] ; }
int main ( ) { int A [ N ] [ N ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; int B [ N ] [ N ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; int C [ N ] [ N ] ; int i , j ; add ( A , B , C ) ; cout << " Result ▁ matrix ▁ is ▁ " << endl ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < N ; j ++ ) cout << C [ i ] [ j ] << " ▁ " ; cout << endl ; } return 0 ; }
