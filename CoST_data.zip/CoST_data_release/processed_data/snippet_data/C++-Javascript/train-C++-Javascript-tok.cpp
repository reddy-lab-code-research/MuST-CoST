struct node { int data ; struct node * left ; struct node * right ; } ;
#include <bits/stdc++.h> NEW_LINE using namespace std ; vector < int > no_NGN ( int arr [ ] , int n ) { vector < int > nxt ;
stack < int > s ; nxt . push_back ( 0 ) ;
s . push ( n - 1 ) ;
for ( int i = n - 2 ; i >= 0 ; i -- ) { while ( ! s . empty ( ) && arr [ i ] >= arr [ s . top ( ) ] ) s . pop ( ) ;
if ( s . empty ( ) ) nxt . push_back ( 0 ) ; else
nxt . push_back ( nxt [ n - s . top ( ) - 1 ] + 1 ) ; s . push ( i ) ; }
reverse ( nxt . begin ( ) , nxt . end ( ) ) ;
return nxt ; }
int main ( ) { int n = 8 ; int arr [ ] = { 3 , 4 , 2 , 7 , 5 , 8 , 10 , 6 } ; vector < int > nxt = no_NGN ( arr , n ) ;
cout << nxt [ 3 ] << endl ;
cout << nxt [ 6 ] << endl ;
cout << nxt [ 1 ] << endl ; return 0 ; }
stack < int > sortStack ( stack < int > input ) { stack < int > tmpStack ; while ( ! input . empty ( ) ) {
int tmp = input . top ( ) ; input . pop ( ) ;
while ( ! tmpStack . empty ( ) && tmpStack . top ( ) < tmp ) {
input . push ( tmpStack . top ( ) ) ; tmpStack . pop ( ) ; }
tmpStack . push ( tmp ) ; } return tmpStack ; } void sortArrayUsingStacks ( int arr [ ] , int n ) {
stack < int > input ; for ( int i = 0 ; i < n ; i ++ ) input . push ( arr [ i ] ) ;
stack < int > tmpStack = sortStack ( input ) ;
for ( int i = 0 ; i < n ; i ++ ) { arr [ i ] = tmpStack . top ( ) ; tmpStack . pop ( ) ; } }
int main ( ) { int arr [ ] = { 10 , 5 , 15 , 45 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; sortArrayUsingStacks ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void towerOfHanoi ( int n , char from_rod , char to_rod , char aux_rod ) { if ( n == 1 ) { cout << " Move ▁ disk ▁ 1 ▁ from ▁ rod ▁ " << from_rod << " ▁ to ▁ rod ▁ " << to_rod << endl ; return ; } towerOfHanoi ( n - 1 , from_rod , aux_rod , to_rod ) ; cout << " Move ▁ disk ▁ " << n << " ▁ from ▁ rod ▁ " << from_rod << " ▁ to ▁ rod ▁ " << to_rod << endl ; towerOfHanoi ( n - 1 , aux_rod , to_rod , from_rod ) ; }
int n = 4 ;
towerOfHanoi ( n , ' A ' , ' C ' , ' B ' ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void printMaxOfMin ( int arr [ ] , int n ) {
for ( int k = 1 ; k <= n ; k ++ ) {
int maxOfMin = INT_MIN ;
for ( int i = 0 ; i <= n - k ; i ++ ) {
int min = arr [ i ] ; for ( int j = 1 ; j < k ; j ++ ) { if ( arr [ i + j ] < min ) min = arr [ i + j ] ; }
if ( min > maxOfMin ) maxOfMin = min ; }
cout << maxOfMin << " ▁ " ; } }
int main ( ) { int arr [ ] = { 10 , 20 , 30 , 50 , 10 , 70 , 30 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printMaxOfMin ( arr , n ) ; return 0 ; }
#include <iostream> NEW_LINE #include <stack> NEW_LINE using namespace std ; void printMaxOfMin ( int arr [ ] , int n ) {
stack < int > s ;
int left [ n + 1 ] ; int right [ n + 1 ] ;
for ( int i = 0 ; i < n ; i ++ ) { left [ i ] = -1 ; right [ i ] = n ; }
for ( int i = 0 ; i < n ; i ++ ) { while ( ! s . empty ( ) && arr [ s . top ( ) ] >= arr [ i ] ) s . pop ( ) ; if ( ! s . empty ( ) ) left [ i ] = s . top ( ) ; s . push ( i ) ; }
while ( ! s . empty ( ) ) s . pop ( ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) { while ( ! s . empty ( ) && arr [ s . top ( ) ] >= arr [ i ] ) s . pop ( ) ; if ( ! s . empty ( ) ) right [ i ] = s . top ( ) ; s . push ( i ) ; }
int ans [ n + 1 ] ; for ( int i = 0 ; i <= n ; i ++ ) ans [ i ] = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int len = right [ i ] - left [ i ] - 1 ;
ans [ len ] = max ( ans [ len ] , arr [ i ] ) ; }
for ( int i = n - 1 ; i >= 1 ; i -- ) ans [ i ] = max ( ans [ i ] , ans [ i + 1 ] ) ;
for ( int i = 1 ; i <= n ; i ++ ) cout << ans [ i ] << " ▁ " ; }
int solve ( string s , int n ) {
int left = 0 , right = 0 , maxlength = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( s [ i ] == ' ( ' ) left ++ ; else right ++ ;
if ( left == right ) maxlength = max ( maxlength , 2 * right ) ;
else if ( right > left ) left = right = 0 ; } left = right = 0 ;
for ( int i = n - 1 ; i >= 0 ; i -- ) {
if ( s [ i ] == ' ( ' ) left ++ ; else right ++ ;
if ( left == right ) maxlength = max ( maxlength , 2 * left ) ;
else if ( left > right ) left = right = 0 ; } return maxlength ; }
cout << solve ( " ( ( ( ) ( ) ( ) ( ) ( ( ( ( ) ) " , 16 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void printLeast ( string arr ) {
int min_avail = 1 , pos_of_I = 0 ;
vector < int > v ;
if ( arr [ 0 ] == ' I ' ) { v . push_back ( 1 ) ; v . push_back ( 2 ) ; min_avail = 3 ; pos_of_I = 1 ; } else { v . push_back ( 2 ) ; v . push_back ( 1 ) ; min_avail = 3 ; pos_of_I = 0 ; }
for ( int i = 1 ; i < arr . length ( ) ; i ++ ) { if ( arr [ i ] == ' I ' ) { v . push_back ( min_avail ) ; min_avail ++ ; pos_of_I = i + 1 ; } else { v . push_back ( v [ i ] ) ; for ( int j = pos_of_I ; j <= i ; j ++ ) v [ j ] ++ ; min_avail ++ ; } }
for ( int i = 0 ; i < v . size ( ) ; i ++ ) cout << v [ i ] << " ▁ " ; cout << endl ; }
int main ( ) { printLeast ( " IDID " ) ; printLeast ( " I " ) ; printLeast ( " DD " ) ; printLeast ( " II " ) ; printLeast ( " DIDI " ) ; printLeast ( " IIDDD " ) ; printLeast ( " DDIDDIID " ) ; return 0 ; }
void PrintMinNumberForPattern ( string seq ) {
string result ;
stack < int > stk ;
for ( int i = 0 ; i <= seq . length ( ) ; i ++ ) {
stk . push ( i + 1 ) ;
if ( i == seq . length ( ) seq [ i ] == ' I ' ) {
while ( ! stk . empty ( ) ) {
result += to_string ( stk . top ( ) ) ; result += " ▁ " ; stk . pop ( ) ; } } } cout << result << endl ; }
int main ( ) { PrintMinNumberForPattern ( " IDID " ) ; PrintMinNumberForPattern ( " I " ) ; PrintMinNumberForPattern ( " DD " ) ; PrintMinNumberForPattern ( " II " ) ; PrintMinNumberForPattern ( " DIDI " ) ; PrintMinNumberForPattern ( " IIDDD " ) ; PrintMinNumberForPattern ( " DDIDDIID " ) ; return 0 ; }
string getMinNumberForPattern ( string seq ) { int n = seq . length ( ) ; if ( n >= 9 ) return " - 1" ; string result ( n + 1 , ' ▁ ' ) ; int count = 1 ;
for ( int i = 0 ; i <= n ; i ++ ) { if ( i == n seq [ i ] == ' I ' ) { for ( int j = i - 1 ; j >= -1 ; j -- ) { result [ j + 1 ] = '0' + count ++ ; if ( j >= 0 && seq [ j ] == ' I ' ) break ; } } } return result ; }
int main ( ) { string inputs [ ] = { " IDID " , " I " , " DD " , " II " , " DIDI " , " IIDDD " , " DDIDDIID " } ; for ( string input : inputs ) { cout << getMinNumberForPattern ( input ) << " STRNEWLINE " ; } return 0 ; }
void nextGreater ( int arr [ ] , int n , int next [ ] , char order ) {
stack < int > S ;
for ( int i = n - 1 ; i >= 0 ; i -- ) {
while ( ! S . empty ( ) && ( ( order == ' G ' ) ? arr [ S . top ( ) ] <= arr [ i ] : arr [ S . top ( ) ] >= arr [ i ] ) ) S . pop ( ) ;
if ( ! S . empty ( ) ) next [ i ] = S . top ( ) ;
else next [ i ] = -1 ;
S . push ( i ) ; } }
void nextSmallerOfNextGreater ( int arr [ ] , int n ) {
int NG [ n ] ;
int RS [ n ] ;
nextGreater ( arr , n , NG , ' G ' ) ;
nextGreater ( arr , n , RS , ' S ' ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( NG [ i ] != -1 && RS [ NG [ i ] ] != -1 ) cout << arr [ RS [ NG [ i ] ] ] << " ▁ " ; else cout << " - 1" << " ▁ " ; } }
int main ( ) { int arr [ ] = { 5 , 1 , 9 , 2 , 5 , 1 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; nextSmallerOfNextGreater ( arr , n ) ; return 0 ; }
struct Node { int data ; Node * left , * right ; } ;
Node * flipBinaryTree ( Node * root ) { if ( root == NULL ) return root ; if ( root -> left == NULL && root -> right == NULL ) return root ;
Node * flippedRoot = flipBinaryTree ( root -> left ) ;
root -> left -> left = root -> right ; root -> left -> right = root ; root -> left = root -> right = NULL ; return flippedRoot ; }
void printLevelOrder ( Node * root ) {
if ( root == NULL ) return ;
queue < Node * > q ;
q . push ( root ) ; while ( 1 ) {
int nodeCount = q . size ( ) ; if ( nodeCount == 0 ) break ;
while ( nodeCount > 0 ) { Node * node = q . front ( ) ; cout << node -> data << " ▁ " ; q . pop ( ) ; if ( node -> left != NULL ) q . push ( node -> left ) ; if ( node -> right != NULL ) q . push ( node -> right ) ; nodeCount -- ; } cout << endl ; } }
int main ( ) { Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> right -> left = newNode ( 4 ) ; root -> right -> right = newNode ( 5 ) ; cout << " Level ▁ order ▁ traversal ▁ of ▁ given ▁ tree STRNEWLINE " ; printLevelOrder ( root ) ; root = flipBinaryTree ( root ) ; cout << " Level order traversal of the flipped " STRNEWLINE " tree " printLevelOrder ( root ) ; return 0 ; }
void heapify ( int arr [ ] , int n , int i ) {
int largest = i ;
int l = 2 * i + 1 ;
int r = 2 * i + 2 ;
if ( l < n && arr [ l ] > arr [ largest ] ) largest = l ;
if ( r < n && arr [ r ] > arr [ largest ] ) largest = r ;
if ( largest != i ) { swap ( arr [ i ] , arr [ largest ] ) ;
heapify ( arr , n , largest ) ; } }
void heapSort ( int arr [ ] , int n ) {
for ( int i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( int i = n - 1 ; i > 0 ; i -- ) {
swap ( arr [ 0 ] , arr [ i ] ) ;
heapify ( arr , i , 0 ) ; } }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; ++ i ) cout << arr [ i ] << " ▁ " ; cout << " STRNEWLINE " ; }
int main ( ) { int arr [ ] = { 12 , 11 , 13 , 5 , 6 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; heapSort ( arr , n ) ; cout << " Sorted ▁ array ▁ is ▁ STRNEWLINE " ; printArray ( arr , n ) ; }
bool isHeap ( int arr [ ] , int n ) {
for ( int i = 0 ; i <= ( n - 2 ) / 2 ; i ++ ) {
if ( arr [ 2 * i + 1 ] > arr [ i ] ) return false ;
if ( 2 * i + 2 < n && arr [ 2 * i + 2 ] > arr [ i ] ) return false ; } return true ; }
int main ( ) { int arr [ ] = { 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 } ; int n = sizeof ( arr ) / sizeof ( int ) ; isHeap ( arr , n ) ? printf ( " Yes " ) : printf ( " No " ) ; return 0 ; }
void mergeKArrays ( int arr [ ] [ n ] , int a , int output [ ] ) { int c = 0 ;
for ( int i = 0 ; i < a ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) output [ c ++ ] = arr [ i ] [ j ] ; }
sort ( output , output + n * a ) ; }
void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] [ n ] = { { 2 , 6 , 12 , 34 } , { 1 , 9 , 20 , 1000 } , { 23 , 34 , 90 , 2000 } } ; int k = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int output [ n * k ] ; mergeKArrays ( arr , 3 , output ) ; cout << " Merged ▁ array ▁ is ▁ " << endl ; printArray ( output , n * k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define n  4
void mergeArrays ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 , int arr3 [ ] ) { int i = 0 , j = 0 , k = 0 ;
while ( i < n1 && j < n2 ) {
if ( arr1 [ i ] < arr2 [ j ] ) arr3 [ k ++ ] = arr1 [ i ++ ] ; else arr3 [ k ++ ] = arr2 [ j ++ ] ; }
while ( i < n1 ) arr3 [ k ++ ] = arr1 [ i ++ ] ;
while ( j < n2 ) arr3 [ k ++ ] = arr2 [ j ++ ] ; }
void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) cout << arr [ i ] << " ▁ " ; }
void mergeKArrays ( int arr [ ] [ n ] , int i , int j , int output [ ] ) {
if ( i == j ) { for ( int p = 0 ; p < n ; p ++ ) output [ p ] = arr [ i ] [ p ] ; return ; }
if ( j - i == 1 ) { mergeArrays ( arr [ i ] , arr [ j ] , n , n , output ) ; return ; }
int out1 [ n * ( ( ( i + j ) / 2 ) - i + 1 ) ] , out2 [ n * ( j - ( ( i + j ) / 2 ) ) ] ;
mergeKArrays ( arr , i , ( i + j ) / 2 , out1 ) ; mergeKArrays ( arr , ( i + j ) / 2 + 1 , j , out2 ) ;
mergeArrays ( out1 , out2 , n * ( ( ( i + j ) / 2 ) - i + 1 ) , n * ( j - ( ( i + j ) / 2 ) ) , output ) ; }
int main ( ) {
#include <bits/stdc++.h> NEW_LINE void generate_derangement ( int N ) {
int S [ N + 1 ] ; for ( int i = 1 ; i <= N ; i ++ ) S [ i ] = i ;
int D [ N + 1 ] ; for ( int i = 1 ; i <= N ; i += 2 ) { if ( i == N && i % N != 0 ) {
int temp = D [ N ] ; D [ N ] = D [ N - 1 ] ; D [ N - 1 ] = temp ; } else { D [ i ] = i + 1 ; D [ i + 1 ] = i ; } }
for ( int i = 1 ; i <= N ; i ++ ) printf ( " % d ▁ " , D [ i ] ) ; printf ( " STRNEWLINE " ) ; }
int main ( ) { generate_derangement ( 10 ) ; return 0 ; }
void heapify ( int arr [ ] , int n , int i ) {
int smallest = i ;
int l = 2 * i + 1 ;
int r = 2 * i + 2 ;
if ( l < n && arr [ l ] < arr [ smallest ] ) smallest = l ;
if ( r < n && arr [ r ] < arr [ smallest ] ) smallest = r ;
if ( smallest != i ) { swap ( arr [ i ] , arr [ smallest ] ) ;
heapify ( arr , n , smallest ) ; } }
void heapSort ( int arr [ ] , int n ) {
for ( int i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) {
swap ( arr [ 0 ] , arr [ i ] ) ;
heapify ( arr , i , 0 ) ; } }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; ++ i ) cout << arr [ i ] << " ▁ " ; cout << " STRNEWLINE " ; }
int main ( ) { int arr [ ] = { 4 , 6 , 3 , 2 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; heapSort ( arr , n ) ; cout << " Sorted ▁ array ▁ is ▁ STRNEWLINE " ; printArray ( arr , n ) ; }
int sumBetweenTwoKth ( int arr [ ] , int n , int k1 , int k2 ) {
sort ( arr , arr + n ) ;
int result = 0 ; for ( int i = k1 ; i < k2 - 1 ; i ++ ) result += arr [ i ] ; return result ; }
int main ( ) { int arr [ ] = { 20 , 8 , 22 , 4 , 12 , 10 , 14 } ; int k1 = 3 , k2 = 6 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << sumBetweenTwoKth ( arr , n , k1 , k2 ) ; return 0 ; }
int minSum ( int a [ ] , int n ) {
sort ( a , a + n ) ; int num1 = 0 ; int num2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) num1 = num1 * 10 + a [ i ] ; else num2 = num2 * 10 + a [ i ] ; } return num2 + num1 ; }
int main ( ) { int arr [ ] = { 5 , 3 , 0 , 7 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " The ▁ required ▁ sum ▁ is ▁ " << minSum ( arr , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { int data ; struct Node * left , * right ; } ;
int count ( Node * root ) { if ( root == NULL ) return 0 ; return count ( root -> left ) + count ( root -> right ) + 1 ; }
bool checkRec ( Node * root , int n ) {
if ( root == NULL ) return false ;
if ( count ( root ) == n - count ( root ) ) return true ;
return checkRec ( root -> left , n ) || checkRec ( root -> right , n ) ; }
bool check ( Node * root ) {
int n = count ( root ) ;
return checkRec ( root , n ) ; }
int main ( ) { struct Node * root = newNode ( 5 ) ; root -> left = newNode ( 1 ) ; root -> right = newNode ( 6 ) ; root -> left -> left = newNode ( 3 ) ; root -> right -> left = newNode ( 7 ) ; root -> right -> right = newNode ( 4 ) ; check ( root ) ? printf ( " YES " ) : printf ( " NO " ) ; return 0 ; }
stack < int > stack_push ( stack < int > stack ) { for ( int i = 0 ; i < 5 ; i ++ ) { stack . push ( i ) ; } return stack ; }
stack < int > stack_pop ( stack < int > stack ) { cout << " Pop ▁ : " ; for ( int i = 0 ; i < 5 ; i ++ ) { int y = ( int ) stack . top ( ) ; stack . pop ( ) ; cout << ( y ) << endl ; } return stack ; }
void stack_peek ( stack < int > stack ) { int element = ( int ) stack . top ( ) ; cout << " Element ▁ on ▁ stack ▁ top ▁ : ▁ " << element << endl ; }
void stack_search ( stack < int > stack , int element ) { int pos = -1 , co = 0 ; while ( stack . size ( ) > 0 ) { co ++ ; if ( stack . top ( ) == element ) { pos = co ; break ; } stack . pop ( ) ; } if ( pos == -1 ) cout << " Element ▁ not ▁ found " << endl ; else cout << " Element ▁ is ▁ found ▁ at ▁ position ▁ " << pos << endl ; }
int main ( ) { stack < int > stack ; stack = stack_push ( stack ) ; stack = stack_pop ( stack ) ; stack = stack_push ( stack ) ; stack_peek ( stack ) ; stack_search ( stack , 2 ) ; stack_search ( stack , 6 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { int data ; struct Node * left , * right ; } ;
int count ( Node * root ) { if ( root == NULL ) return 0 ; return count ( root -> left ) + count ( root -> right ) + 1 ; }
int checkRec ( Node * root , int n , bool & res ) {
if ( root == NULL ) return 0 ;
int c = checkRec ( root -> left , n , res ) + 1 + checkRec ( root -> right , n , res ) ;
if ( c == n - c ) res = true ;
return c ; }
bool check ( Node * root ) {
int n = count ( root ) ;
bool res = false ; checkRec ( root , n , res ) ; return res ; }
int main ( ) { struct Node * root = newNode ( 5 ) ; root -> left = newNode ( 1 ) ; root -> right = newNode ( 6 ) ; root -> left -> left = newNode ( 3 ) ; root -> right -> left = newNode ( 7 ) ; root -> right -> right = newNode ( 4 ) ; check ( root ) ? printf ( " YES " ) : printf ( " NO " ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
struct Node { int data ; struct Node * left , * right ; } ;
Node * newNode ( int data ) { Node * temp = new Node ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
int search ( int arr [ ] , int strt , int end , int value ) { for ( int i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) return i ; } }
Node * buildTree ( int in [ ] , int pre [ ] , int inStrt , int inEnd ) { static int preIndex = 0 ; if ( inStrt > inEnd ) return NULL ;
Node * tNode = newNode ( pre [ preIndex ++ ] ) ;
if ( inStrt == inEnd ) return tNode ;
int inIndex = search ( in , inStrt , inEnd , tNode -> data ) ;
tNode -> left = buildTree ( in , pre , inStrt , inIndex - 1 ) ; tNode -> right = buildTree ( in , pre , inIndex + 1 , inEnd ) ; return tNode ; }
int checkPostorder ( Node * node , int postOrder [ ] , int index ) { if ( node == NULL ) return index ;
index = checkPostorder ( node -> left , postOrder , index ) ;
index = checkPostorder ( node -> right , postOrder , index ) ;
if ( node -> data == postOrder [ index ] ) index ++ ; else return -1 ; return index ; }
int main ( ) { int inOrder [ ] = { 4 , 2 , 5 , 1 , 3 } ; int preOrder [ ] = { 1 , 2 , 4 , 5 , 3 } ; int postOrder [ ] = { 4 , 5 , 2 , 3 , 1 } ; int len = sizeof ( inOrder ) / sizeof ( inOrder [ 0 ] ) ;
Node * root = buildTree ( inOrder , preOrder , 0 , len - 1 ) ;
int index = checkPostorder ( root , postOrder , 0 ) ;
if ( index == len ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  3 NEW_LINE #define M  4 NEW_LINE using namespace std ;
void printDistance ( int mat [ N ] [ M ] ) { int ans [ N ] [ M ] ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) ans [ i ] [ j ] = INT_MAX ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) {
for ( int k = 0 ; k < N ; k ++ ) for ( int l = 0 ; l < M ; l ++ ) {
if ( mat [ k ] [ l ] == 1 ) ans [ i ] [ j ] = min ( ans [ i ] [ j ] , abs ( i - k ) + abs ( j - l ) ) ; } }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) cout << ans [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int mat [ N ] [ M ] = { 0 , 0 , 0 , 1 , 0 , 0 , 1 , 1 , 0 , 1 , 1 , 0 } ; printDistance ( mat ) ; return 0 ; }
int isChangeable ( int notes [ ] , int n ) {
int fiveCount = 0 ; int tenCount = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( notes [ i ] == 5 ) fiveCount ++ ; else if ( notes [ i ] == 10 ) {
if ( fiveCount > 0 ) { fiveCount -- ; tenCount ++ ; } else return 0 ; } else {
if ( fiveCount > 0 && tenCount > 0 ) { fiveCount -- ; tenCount -- ; }
else if ( fiveCount >= 3 ) { fiveCount -= 3 ; } else return 0 ; } } return 1 ; }
int a [ ] = { 5 , 5 , 5 , 10 , 20 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
if ( isChangeable ( a , n ) ) cout << " YES " ; else cout << " NO " ; return 0 ; }
int maxDistance ( int arr [ ] , int n ) {
unordered_map < int , int > mp ;
int max_dist = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( mp . find ( arr [ i ] ) == mp . end ( ) ) mp [ arr [ i ] ] = i ;
else max_dist = max ( max_dist , i - mp [ arr [ i ] ] ) ; } return max_dist ; }
int main ( ) { int arr [ ] = { 3 , 2 , 1 , 2 , 1 , 4 , 5 , 8 , 6 , 7 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxDistance ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; bool checkDuplicatesWithinK ( int arr [ ] , int n , int k ) {
unordered_set < int > myset ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( myset . find ( arr [ i ] ) != myset . end ( ) ) return true ;
myset . insert ( arr [ i ] ) ;
if ( i >= k ) myset . erase ( arr [ i - k ] ) ; } return false ; }
int main ( ) { int arr [ ] = { 10 , 5 , 3 , 4 , 3 , 5 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( checkDuplicatesWithinK ( arr , n , 3 ) ) cout << " Yes " ; else cout << " No " ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int mostFrequent ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int max_count = 1 , res = arr [ 0 ] , curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
int main ( ) { int arr [ ] = { 1 , 5 , 2 , 1 , 3 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << mostFrequent ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int mostFrequent ( int arr [ ] , int n ) {
unordered_map < int , int > hash ; for ( int i = 0 ; i < n ; i ++ ) hash [ arr [ i ] ] ++ ;
int max_count = 0 , res = -1 ; for ( auto i : hash ) { if ( max_count < i . second ) { res = i . first ; max_count = i . second ; } } return res ; }
int main ( ) { int arr [ ] = { 1 , 5 , 2 , 1 , 3 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << mostFrequent ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void smallestSubsegment ( int a [ ] , int n ) {
unordered_map < int , int > left ;
unordered_map < int , int > count ;
int mx = 0 ;
int mn , strindex ; for ( int i = 0 ; i < n ; i ++ ) { int x = a [ i ] ;
if ( count [ x ] == 0 ) { left [ x ] = i ; count [ x ] = 1 ; }
else count [ x ] ++ ;
if ( count [ x ] > mx ) { mx = count [ x ] ;
mn = i - left [ x ] + 1 ; strindex = left [ x ] ; }
else if ( count [ x ] == mx && i - left [ x ] + 1 < mn ) { mn = i - left [ x ] + 1 ; strindex = left [ x ] ; } }
for ( int i = strindex ; i < strindex + mn ; i ++ ) cout << a [ i ] << " ▁ " ; }
int main ( ) { int A [ ] = { 1 , 2 , 2 , 2 , 1 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; smallestSubsegment ( A , n ) ; return 0 ; }
void findSymPairs ( int arr [ ] [ 2 ] , int row ) {
unordered_map < int , int > hM ;
for ( int i = 0 ; i < row ; i ++ ) {
int first = arr [ i ] [ 0 ] ; int sec = arr [ i ] [ 1 ] ;
if ( hM . find ( sec ) != hM . end ( ) && hM [ sec ] == first ) cout << " ( " << sec << " , ▁ " << first << " ) " << endl ;
else hM [ first ] = sec ; } }
int main ( ) { int arr [ 5 ] [ 2 ] ; arr [ 0 ] [ 0 ] = 11 ; arr [ 0 ] [ 1 ] = 20 ; arr [ 1 ] [ 0 ] = 30 ; arr [ 1 ] [ 1 ] = 40 ; arr [ 2 ] [ 0 ] = 5 ; arr [ 2 ] [ 1 ] = 10 ; arr [ 3 ] [ 0 ] = 40 ; arr [ 3 ] [ 1 ] = 30 ; arr [ 4 ] [ 0 ] = 10 ; arr [ 4 ] [ 1 ] = 5 ; findSymPairs ( arr , 5 ) ; }
void groupElements ( int arr [ ] , int n ) {
bool * visited = new bool [ n ] ; for ( int i = 0 ; i < n ; i ++ ) visited [ i ] = false ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ! visited [ i ] ) {
cout << arr [ i ] << " ▁ " ; for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) { cout << arr [ i ] << " ▁ " ; visited [ j ] = true ; } } } } delete [ ] visited ; }
int main ( ) { int arr [ ] = { 4 , 6 , 9 , 2 , 3 , 4 , 9 , 6 , 10 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; groupElements ( arr , n ) ; return 0 ; }
bool areDisjoint ( int set1 [ ] , int set2 [ ] , int m , int n ) {
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( set1 [ i ] == set2 [ j ] ) return false ;
return true ; }
int main ( ) { int set1 [ ] = { 12 , 34 , 11 , 9 , 3 } ; int set2 [ ] = { 7 , 2 , 1 , 5 } ; int m = sizeof ( set1 ) / sizeof ( set1 [ 0 ] ) ; int n = sizeof ( set2 ) / sizeof ( set2 [ 0 ] ) ; areDisjoint ( set1 , set2 , m , n ) ? cout << " Yes " : cout << " ▁ No " ; return 0 ; }
bool areDisjoint ( int set1 [ ] , int set2 [ ] , int m , int n ) {
sort ( set1 , set1 + m ) ; sort ( set2 , set2 + n ) ;
int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( set1 [ i ] < set2 [ j ] ) i ++ ; else if ( set2 [ j ] < set1 [ i ] ) j ++ ;
else return false ; } return true ; }
int main ( ) { int set1 [ ] = { 12 , 34 , 11 , 9 , 3 } ; int set2 [ ] = { 7 , 2 , 1 , 5 } ; int m = sizeof ( set1 ) / sizeof ( set1 [ 0 ] ) ; int n = sizeof ( set2 ) / sizeof ( set2 [ 0 ] ) ; areDisjoint ( set1 , set2 , m , n ) ? cout << " Yes " : cout << " ▁ No " ; return 0 ; }
void findMissing ( int a [ ] , int b [ ] , int n , int m ) { for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < m ; j ++ ) if ( a [ i ] == b [ j ] ) break ; if ( j == m ) cout << a [ i ] << " ▁ " ; } }
int main ( ) { int a [ ] = { 1 , 2 , 6 , 3 , 4 , 5 } ; int b [ ] = { 2 , 4 , 3 , 1 , 0 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int m = sizeof ( b ) / sizeof ( b [ 1 ] ) ; findMissing ( a , b , n , m ) ; return 0 ; }
void findMissing ( int a [ ] , int b [ ] , int n , int m ) {
unordered_set < int > s ; for ( int i = 0 ; i < m ; i ++ ) s . insert ( b [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( s . find ( a [ i ] ) == s . end ( ) ) cout << a [ i ] << " ▁ " ; }
int main ( ) { int a [ ] = { 1 , 2 , 6 , 3 , 4 , 5 } ; int b [ ] = { 2 , 4 , 3 , 1 , 0 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int m = sizeof ( b ) / sizeof ( b [ 1 ] ) ; findMissing ( a , b , n , m ) ; return 0 ; }
bool areEqual ( int arr1 [ ] , int arr2 [ ] , int n , int m ) {
if ( n != m ) return false ;
sort ( arr1 , arr1 + n ) ; sort ( arr2 , arr2 + m ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr1 [ i ] != arr2 [ i ] ) return false ;
return true ; }
int main ( ) { int arr1 [ ] = { 3 , 5 , 2 , 5 , 2 } ; int arr2 [ ] = { 2 , 3 , 5 , 5 , 2 } ; int n = sizeof ( arr1 ) / sizeof ( int ) ; int m = sizeof ( arr2 ) / sizeof ( int ) ; if ( areEqual ( arr1 , arr2 , n , m ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
int find_maximum ( int a [ ] , int n , int k ) {
unordered_map < int , int > b ; for ( int i = 0 ; i < n ; i ++ ) { int x = a [ i ] ;
int d = min ( 1 + i , n - i ) ; if ( b . find ( x ) == b . end ( ) ) b [ x ] = d ; else
b [ x ] = min ( d , b [ x ] ) ; } int ans = INT_MAX ; for ( int i = 0 ; i < n ; i ++ ) { int x = a [ i ] ;
if ( x != k - x && b . find ( k - x ) != b . end ( ) ) ans = min ( max ( b [ x ] , b [ k - x ] ) , ans ) ; } return ans ; }
int main ( ) { int a [ ] = { 3 , 5 , 8 , 6 , 7 } ; int K = 11 ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << find_maximum ( a , n , K ) << endl ; return 0 ; }
bool isProduct ( int arr [ ] , int n , int x ) {
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; i < n ; i ++ ) if ( arr [ i ] * arr [ j ] == x ) return true ; return false ; }
int main ( ) { int arr [ ] = { 10 , 20 , 9 , 40 } ; int x = 400 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; isProduct ( arr , n , x ) ? cout << " Yesn " : cout << " Non " ; x = 190 ; isProduct ( arr , n , x ) ? cout << " Yesn " : cout << " Non " ; return 0 ; }
bool isProduct ( int arr [ ] , int n , int x ) { if ( n < 2 ) return false ;
unordered_set < int > s ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] == 0 ) { if ( x == 0 ) return true ; else continue ; }
if ( x % arr [ i ] == 0 ) { if ( s . find ( x / arr [ i ] ) != s . end ( ) ) return true ;
s . insert ( arr [ i ] ) ; } } return false ; }
int main ( ) { int arr [ ] = { 10 , 20 , 9 , 40 } ; int x = 400 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; isProduct ( arr , n , x ) ? cout << " Yes STRNEWLINE " : cout << " Non " ; x = 190 ; isProduct ( arr , n , x ) ? cout << " Yes STRNEWLINE " : cout << " Non " ; return 0 ; }
void printMissing ( int arr [ ] , int n , int low , int high ) {
bool points_of_range [ high - low + 1 ] = { false } ; for ( int i = 0 ; i < n ; i ++ ) {
if ( low <= arr [ i ] && arr [ i ] <= high ) points_of_range [ arr [ i ] - low ] = true ; }
for ( int x = 0 ; x <= high - low ; x ++ ) { if ( points_of_range [ x ] == false ) cout << low + x << " ▁ " ; } }
int main ( ) { int arr [ ] = { 1 , 3 , 5 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int low = 1 , high = 10 ; printMissing ( arr , n , low , high ) ; return 0 ; }
int find ( int a [ ] , int b [ ] , int k , int n1 , int n2 ) {
unordered_set < int > s ; for ( int i = 0 ; i < n2 ; i ++ ) s . insert ( b [ i ] ) ;
int missing = 0 ; for ( int i = 0 ; i < n1 ; i ++ ) { if ( s . find ( a [ i ] ) == s . end ( ) ) missing ++ ; if ( missing == k ) return a [ i ] ; } return -1 ; }
int main ( ) { int a [ ] = { 0 , 2 , 4 , 6 , 8 , 10 , 12 , 14 , 15 } ; int b [ ] = { 4 , 10 , 6 , 8 , 12 } ; int n1 = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int n2 = sizeof ( b ) / sizeof ( b [ 0 ] ) ; int k = 3 ; cout << find ( a , b , k , n1 , n2 ) ; return 0 ; }
struct Node { int key ; struct Node * left , * right ; } ;
bool isFullTree ( struct Node * root ) {
if ( root == NULL ) return true ;
if ( root -> left == NULL && root -> right == NULL ) return true ;
if ( ( root -> left ) && ( root -> right ) ) return ( isFullTree ( root -> left ) && isFullTree ( root -> right ) ) ;
return false ; }
int main ( ) { struct Node * root = NULL ; root = newNode ( 10 ) ; root -> left = newNode ( 20 ) ; root -> right = newNode ( 30 ) ; root -> left -> right = newNode ( 40 ) ; root -> left -> left = newNode ( 50 ) ; root -> right -> left = newNode ( 60 ) ; root -> right -> right = newNode ( 70 ) ; root -> left -> left -> left = newNode ( 80 ) ; root -> left -> left -> right = newNode ( 90 ) ; root -> left -> right -> left = newNode ( 80 ) ; root -> left -> right -> right = newNode ( 90 ) ; root -> right -> left -> left = newNode ( 80 ) ; root -> right -> left -> right = newNode ( 90 ) ; root -> right -> right -> left = newNode ( 80 ) ; root -> right -> right -> right = newNode ( 90 ) ; if ( isFullTree ( root ) ) cout << " The ▁ Binary ▁ Tree ▁ is ▁ full STRNEWLINE " ; else cout << " The ▁ Binary ▁ Tree ▁ is ▁ not ▁ full STRNEWLINE " ; return ( 0 ) ; }
int findGreatest ( int arr [ ] , int n ) { int result = -1 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ j ] * arr [ k ] == arr [ i ] ) result = max ( result , arr [ i ] ) ; return result ; }
int main ( ) { int arr [ ] = { 30 , 10 , 9 , 3 , 35 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findGreatest ( arr , n ) ; return 0 ; }
int findGreatest ( int arr [ ] , int n ) {
unordered_map < int , int > m ; for ( int i = 0 ; i < n ; i ++ ) m [ arr [ i ] ] ++ ;
sort ( arr , arr + n ) ; for ( int i = n - 1 ; i > 1 ; i -- ) {
for ( int j = 0 ; j < i && arr [ j ] <= sqrt ( arr [ i ] ) ; j ++ ) { if ( arr [ i ] % arr [ j ] == 0 ) { int result = arr [ i ] / arr [ j ] ;
if ( result != arr [ j ] && m [ result ] > 0 ) return arr [ i ] ;
else if ( result == arr [ j ] && m [ result ] > 1 ) return arr [ i ] ; } } } return -1 ; }
int main ( ) { int arr [ ] = { 17 , 2 , 1 , 15 , 30 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findGreatest ( arr , n ) ; return 0 ; }
int subset ( int ar [ ] , int n ) {
int res = 0 ;
sort ( ar , ar + n ) ;
for ( int i = 0 ; i < n ; i ++ ) { int count = 1 ;
for ( ; i < n - 1 ; i ++ ) { if ( ar [ i ] == ar [ i + 1 ] ) count ++ ; else break ; }
res = max ( res , count ) ; } return res ; }
int main ( ) { int arr [ ] = { 5 , 6 , 9 , 3 , 4 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << subset ( arr , n ) ; return 0 ; }
int minRemove ( int a [ ] , int b [ ] , int n , int m ) {
unordered_map < int , int > countA , countB ;
for ( int i = 0 ; i < n ; i ++ ) countA [ a [ i ] ] ++ ;
for ( int i = 0 ; i < m ; i ++ ) countB [ b [ i ] ] ++ ;
int res = 0 ; for ( auto x : countA ) if ( countB . find ( x . first ) != countB . end ( ) ) res += min ( x . second , countB [ x . first ] ) ;
return res ; }
int main ( ) { int a [ ] = { 1 , 2 , 3 , 4 } ; int b [ ] = { 2 , 3 , 4 , 5 , 8 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int m = sizeof ( b ) / sizeof ( b [ 0 ] ) ; cout << minRemove ( a , b , n , m ) ; return 0 ; }
int countItems ( item list1 [ ] , int m , item list2 [ ] , int n ) { int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( ( list1 [ i ] . name . compare ( list2 [ j ] . name ) == 0 ) && ( list1 [ i ] . price != list2 [ j ] . price ) ) count ++ ;
return count ; }
int main ( ) { item list1 [ ] = { { " apple " , 60 } , { " bread " , 20 } , { " wheat " , 50 } , { " oil " , 30 } } ; item list2 [ ] = { { " milk " , 20 } , { " bread " , 15 } , { " wheat " , 40 } , { " apple " , 60 } } ; int m = sizeof ( list1 ) / sizeof ( list1 [ 0 ] ) ; int n = sizeof ( list2 ) / sizeof ( list2 [ 0 ] ) ; cout << " Count ▁ = ▁ " << countItems ( list1 , m , list2 , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void makePermutation ( int a [ ] , int n ) {
unordered_map < int , int > count ; for ( int i = 0 ; i < n ; i ++ ) count [ a [ i ] ] ++ ; int next_missing = 1 ; for ( int i = 0 ; i < n ; i ++ ) { if ( count [ a [ i ] ] != 1 a [ i ] > n a [ i ] < 1 ) { count [ a [ i ] ] -- ;
while ( count . find ( next_missing ) != count . end ( ) ) next_missing ++ ;
a [ i ] = next_missing ; count [ next_missing ] = 1 ; } } }
int main ( ) { int A [ ] = { 2 , 2 , 3 , 3 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; makePermutation ( A , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << A [ i ] << " ▁ " ; return 0 ; }
int getPairsCount ( int arr [ ] , int n , int sum ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] + arr [ j ] == sum ) count ++ ; return count ; }
int main ( ) { int arr [ ] = { 1 , 5 , 7 , -1 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int sum = 6 ; cout << " Count ▁ of ▁ pairs ▁ is ▁ " << getPairsCount ( arr , n , sum ) ; return 0 ; }
int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ )
if ( ( arr1 [ i ] + arr2 [ j ] ) == x ) count ++ ;
return count ; }
int main ( ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; int x = 10 ; cout << " Count ▁ = ▁ " << countPairs ( arr1 , arr2 , m , n , x ) ; return 0 ; }
bool isPresent ( int arr [ ] , int low , int high , int value ) { while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ; for ( int i = 0 ; i < m ; i ++ ) {
int value = x - arr1 [ i ] ;
if ( isPresent ( arr2 , 0 , n - 1 , value ) ) count ++ ; }
return count ; }
int main ( ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; int x = 10 ; cout << " Count ▁ = ▁ " << countPairs ( arr1 , arr2 , m , n , x ) ; return 0 ; }
int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ; unordered_set < int > us ;
for ( int i = 0 ; i < m ; i ++ ) us . insert ( arr1 [ i ] ) ;
for ( int j = 0 ; j < n ; j ++ )
if ( us . find ( x - arr2 [ j ] ) != us . end ( ) ) count ++ ;
return count ; }
int main ( ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; int x = 10 ; cout << " Count ▁ = ▁ " << countPairs ( arr1 , arr2 , m , n , x ) ; return 0 ; }
int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ; int l = 0 , r = n - 1 ;
while ( l < m && r >= 0 ) {
if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) { l ++ ; r -- ; count ++ ; }
else if ( ( arr1 [ l ] + arr2 [ r ] ) < x ) l ++ ;
else r -- ; }
return count ; }
int main ( ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; int x = 10 ; cout << " Count ▁ = ▁ " << countPairs ( arr1 , arr2 , m , n , x ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int main ( ) { int arr [ ] = { 10 , 2 , -2 , -20 , 10 } ; int k = -10 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { int sum = 0 ; for ( int j = i ; j < n ; j ++ ) {
sum += arr [ j ] ;
if ( sum == k ) res ++ ; } } cout << ( res ) << endl ; }
int findSubarraySum ( int arr [ ] , int n , int sum ) {
unordered_map < int , int > prevSum ; int res = 0 ;
int currsum = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
currsum += arr [ i ] ;
if ( currsum == sum ) res ++ ;
if ( prevSum . find ( currsum - sum ) != prevSum . end ( ) ) res += ( prevSum [ currsum - sum ] ) ;
prevSum [ currsum ] ++ ; } return res ; }
int main ( ) { int arr [ ] = { 10 , 2 , -2 , -20 , 10 } ; int sum = -10 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findSubarraySum ( arr , n , sum ) ; return 0 ; }
int countPairs ( int arr [ ] , int n ) { int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int product = arr [ i ] * arr [ j ] ;
for ( int k = 0 ; k < n ; k ++ ) {
if ( arr [ k ] == product ) { result ++ ; break ; } } } }
return result ; }
int main ( ) { int arr [ ] = { 6 , 2 , 4 , 12 , 5 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countPairs ( arr , n ) ; return 0 ; }
int countPairs ( int arr [ ] , int n ) { int result = 0 ;
set < int > Hash ;
for ( int i = 0 ; i < n ; i ++ ) Hash . insert ( arr [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int product = arr [ i ] * arr [ j ] ;
if ( Hash . find ( product ) != Hash . end ( ) ) result ++ ; } }
return result ; }
int main ( ) { int arr [ ] = { 6 , 2 , 4 , 12 , 5 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countPairs ( arr , n ) ; return 0 ; }
void findPairs ( int arr1 [ ] , int arr2 [ ] , int n , int m , int x ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( arr1 [ i ] + arr2 [ j ] == x ) cout << arr1 [ i ] << " ▁ " << arr2 [ j ] << endl ; }
int main ( ) { int arr1 [ ] = { 1 , 2 , 3 , 7 , 5 , 4 } ; int arr2 [ ] = { 0 , 7 , 4 , 3 , 2 , 1 } ; int n = sizeof ( arr1 ) / sizeof ( int ) ; int m = sizeof ( arr2 ) / sizeof ( int ) ; int x = 8 ; findPairs ( arr1 , arr2 , n , m , x ) ; return 0 ; }
void findPairs ( int arr1 [ ] , int arr2 [ ] , int n , int m , int x ) {
unordered_set < int > s ; for ( int i = 0 ; i < n ; i ++ ) s . insert ( arr1 [ i ] ) ;
for ( int j = 0 ; j < m ; j ++ ) if ( s . find ( x - arr2 [ j ] ) != s . end ( ) ) cout << x - arr2 [ j ] << " ▁ " << arr2 [ j ] << endl ; }
int main ( ) { int arr1 [ ] = { 1 , 0 , -4 , 7 , 6 , 4 } ; int arr2 [ ] = { 0 , 2 , 4 , -3 , 2 , 1 } ; int x = 8 ; int n = sizeof ( arr1 ) / sizeof ( int ) ; int m = sizeof ( arr2 ) / sizeof ( int ) ; findPairs ( arr1 , arr2 , n , m , x ) ; return 0 ; }
void countFreq ( int a [ ] , int n ) {
unordered_map < int , int > hm ; for ( int i = 0 ; i < n ; i ++ ) hm [ a [ i ] ] ++ ; int cumul = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
cumul += hm [ a [ i ] ] ;
if ( hm [ a [ i ] ] ) { cout << a [ i ] << " - > " << cumul << endl ; }
hm [ a [ i ] ] = 0 ; } }
int main ( ) { int a [ ] = { 1 , 3 , 2 , 4 , 2 , 1 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; countFreq ( a , n ) ; return 0 ; }
void findPair ( int arr [ ] , int n ) { bool found = false ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { for ( int k = 0 ; k < n ; k ++ ) { if ( arr [ i ] + arr [ j ] == arr [ k ] ) { cout << arr [ i ] << " ▁ " << arr [ j ] << endl ; found = true ; } } } } if ( found == false ) cout << " Not ▁ exist " << endl ; }
int main ( ) { int arr [ ] = { 10 , 4 , 8 , 13 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findPair ( arr , n ) ; return 0 ; }
bool printPairs ( int arr [ ] , int n , int k ) { bool isPairFound = true ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i != j && arr [ i ] % arr [ j ] == k ) { cout << " ( " << arr [ i ] << " , ▁ " << arr [ j ] << " ) " << " ▁ " ; isPairFound = true ; } } } return isPairFound ; }
int main ( ) { int arr [ ] = { 2 , 3 , 5 , 4 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; if ( printPairs ( arr , n , k ) == false ) cout << " No ▁ such ▁ pair ▁ exists " ; return 0 ; }
vector < int > findDivisors ( int n ) { vector < int > v ;
for ( int i = 1 ; i <= sqrt ( n ) ; i ++ ) { if ( n % i == 0 ) {
if ( n / i == i ) v . push_back ( i ) ; else { v . push_back ( i ) ; v . push_back ( n / i ) ; } } } return v ; }
bool printPairs ( int arr [ ] , int n , int k ) {
unordered_map < int , bool > occ ; for ( int i = 0 ; i < n ; i ++ ) occ [ arr [ i ] ] = true ; bool isPairFound = false ; for ( int i = 0 ; i < n ; i ++ ) {
if ( occ [ k ] && k < arr [ i ] ) { cout << " ( " << k << " , ▁ " << arr [ i ] << " ) ▁ " ; isPairFound = true ; }
if ( arr [ i ] >= k ) {
vector < int > v = findDivisors ( arr [ i ] - k ) ;
for ( int j = 0 ; j < v . size ( ) ; j ++ ) { if ( arr [ i ] % v [ j ] == k && arr [ i ] != v [ j ] && occ [ v [ j ] ] ) { cout << " ( " << arr [ i ] << " , ▁ " << v [ j ] << " ) ▁ " ; isPairFound = true ; } }
v . clear ( ) ; } } return isPairFound ; }
int main ( ) { int arr [ ] = { 3 , 1 , 2 , 5 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 2 ; if ( printPairs ( arr , n , k ) == false ) cout << " No ▁ such ▁ pair ▁ exists " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void convert ( int arr [ ] , int n ) {
int temp [ n ] ; memcpy ( temp , arr , n * sizeof ( int ) ) ;
sort ( temp , temp + n ) ;
unordered_map < int , int > umap ;
int val = 0 ; for ( int i = 0 ; i < n ; i ++ ) umap [ temp [ i ] ] = val ++ ;
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = umap [ arr [ i ] ] ; } void printArr ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 10 , 20 , 15 , 12 , 11 , 50 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Given ▁ Array ▁ is ▁ STRNEWLINE " ; printArr ( arr , n ) ; convert ( arr , n ) ; cout << " Converted Array is " ; printArr ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define ASCII_SIZE  256 NEW_LINE using namespace std ; char getMaxOccuringChar ( char * str ) {
int count [ ASCII_SIZE ] = { 0 } ;
int len = strlen ( str ) ;
int max = 0 ;
char result ;
for ( int i = 0 ; i < len ; i ++ ) { count [ str [ i ] ] ++ ; if ( max < count [ str [ i ] ] ) { max = count [ str [ i ] ] ; result = str [ i ] ; } } return result ; }
int main ( ) { char str [ ] = " sample ▁ string " ; cout << " Max ▁ occurring ▁ character ▁ is ▁ " << getMaxOccuringChar ( str ) ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const char MARKER = ' $ ' ;
struct Node { char key ; Node * left , * right ; } ;
string dupSubUtil ( Node * root ) { string s = " " ;
if ( root == NULL ) return s + MARKER ;
string lStr = dupSubUtil ( root -> left ) ; if ( lStr . compare ( s ) == 0 ) return s ;
string rStr = dupSubUtil ( root -> right ) ; if ( rStr . compare ( s ) == 0 ) return s ;
s = s + root -> key + lStr + rStr ;
if ( s . length ( ) > 3 && subtrees . find ( s ) != subtrees . end ( ) ) return " " ; subtrees . insert ( s ) ; return s ; }
int main ( ) { Node * root = newNode ( ' A ' ) ; root -> left = newNode ( ' B ' ) ; root -> right = newNode ( ' C ' ) ; root -> left -> left = newNode ( ' D ' ) ; root -> left -> right = newNode ( ' E ' ) ; root -> right -> right = newNode ( ' B ' ) ; root -> right -> right -> right = newNode ( ' E ' ) ; root -> right -> right -> left = newNode ( ' D ' ) ; string str = dupSubUtil ( root ) ; ( str . compare ( " " ) == 0 ) ? cout << " ▁ Yes ▁ " : cout << " ▁ No ▁ " ; return 0 ; }
void printFirstRepeating ( int arr [ ] , int n ) {
int min = -1 ;
set < int > myset ;
for ( int i = n - 1 ; i >= 0 ; i -- ) {
if ( myset . find ( arr [ i ] ) != myset . end ( ) ) min = i ;
else myset . insert ( arr [ i ] ) ; }
if ( min != -1 ) cout << " The ▁ first ▁ repeating ▁ element ▁ is ▁ " << arr [ min ] ; else cout << " There ▁ are ▁ no ▁ repeating ▁ elements " ; }
int main ( ) { int arr [ ] = { 10 , 5 , 3 , 4 , 3 , 5 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printFirstRepeating ( arr , n ) ; }
void printFirstRepeating ( int arr [ ] , int n ) {
int k = 0 ;
int max = n ; for ( int i = 0 ; i < n ; i ++ ) if ( max < arr [ i ] ) max = arr [ i ] ;
int a [ max + 1 ] = { } ;
int b [ max + 1 ] = { } ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ arr [ i ] ] ) { b [ arr [ i ] ] = 1 ; k = 1 ; continue ; } else
a [ arr [ i ] ] = i ; } if ( k == 0 ) cout << " No ▁ repeating ▁ element ▁ found " << endl ; else { int min = max + 1 ;
for ( int i = 0 ; i < max + 1 ; i ++ ) if ( a [ i ] && min > a [ i ] && b [ i ] ) min = a [ i ] ; cout << arr [ min ] ; } cout << endl ; }
int main ( ) { int arr [ ] = { 10 , 5 , 3 , 4 , 3 , 5 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printFirstRepeating ( arr , n ) ; }
int findSum ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ; int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) sum = sum + arr [ i ] ; } return sum ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 1 , 1 , 4 , 5 , 6 } ; int n = sizeof ( arr ) / sizeof ( int ) ; cout << findSum ( arr , n ) ; return 0 ; }
int findSum ( int arr [ ] , int n ) { int sum = 0 ;
unordered_set < int > s ; for ( int i = 0 ; i < n ; i ++ ) { if ( s . find ( arr [ i ] ) == s . end ( ) ) { sum += arr [ i ] ; s . insert ( arr [ i ] ) ; } } return sum ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 1 , 1 , 4 , 5 , 6 } ; int n = sizeof ( arr ) / sizeof ( int ) ; cout << findSum ( arr , n ) ; return 0 ; }
int printKDistinct ( int arr [ ] , int n , int k ) { int dist_count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ j ] == arr [ i ] ) break ;
if ( j == n ) dist_count ++ ; if ( dist_count == k ) return arr [ i ] ; } return -1 ; }
int main ( ) { int ar [ ] = { 1 , 2 , 1 , 3 , 4 , 2 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; int k = 2 ; cout << printKDistinct ( ar , n , k ) ; return 0 ; }
struct Node { int data ; Node * left , * right ; } ;
int areMirror ( Node * a , Node * b ) {
if ( a == NULL && b == NULL ) return true ;
if ( a == NULL b == NULL ) return false ;
return a -> data == b -> data && areMirror ( a -> left , b -> right ) && areMirror ( a -> right , b -> left ) ; }
int main ( ) { Node * a = newNode ( 1 ) ; Node * b = newNode ( 1 ) ; a -> left = newNode ( 2 ) ; a -> right = newNode ( 3 ) ; a -> left -> left = newNode ( 4 ) ; a -> left -> right = newNode ( 5 ) ; b -> left = newNode ( 3 ) ; b -> right = newNode ( 2 ) ; b -> right -> left = newNode ( 5 ) ; b -> right -> right = newNode ( 4 ) ; areMirror ( a , b ) ? cout << " Yes " : cout << " No " ; return 0 ; }
void printPairs ( int arr [ ] , int n ) { vector < int > v ;
for ( int i = 0 ; i < n ; i ++ )
for ( int j = i + 1 ; j < n ; j ++ )
if ( abs ( arr [ i ] ) == abs ( arr [ j ] ) ) v . push_back ( abs ( arr [ i ] ) ) ;
if ( v . size ( ) == 0 ) return ;
sort ( v . begin ( ) , v . end ( ) ) ;
for ( int i = 0 ; i < v . size ( ) ; i ++ ) cout << - v [ i ] << " ▁ " << v [ i ] ; }
int main ( ) { int arr [ ] = { 4 , 8 , 9 , -4 , 1 , -1 , -8 , -9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printPairs ( arr , n ) ; return 0 ; }
bool canPairs ( int arr [ ] , int n , int k ) {
if ( n & 1 ) return false ;
unordered_map < int , int > freq ;
for ( int i = 0 ; i < n ; i ++ ) freq [ ( ( arr [ i ] % k ) + k ) % k ] ++ ;
for ( int i = 0 ; i < n ; i ++ ) {
int rem = ( ( arr [ i ] % k ) + k ) % k ;
if ( 2 * rem == k ) {
if ( freq [ rem ] % 2 != 0 ) return false ; }
else if ( rem == 0 ) {
if ( freq [ rem ] & 1 ) return false ; }
else if ( freq [ rem ] != freq [ k - rem ] ) return false ; } return true ; }
int main ( ) { int arr [ ] = { 92 , 75 , 65 , 48 , 45 , 35 } ; int k = 10 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
canPairs ( arr , n , k ) ? cout << " True " : cout << " False " ; return 0 ; }
bool findTriplet ( int a1 [ ] , int a2 [ ] , int a3 [ ] , int n1 , int n2 , int n3 , int sum ) { for ( int i = 0 ; i < n1 ; i ++ ) for ( int j = 0 ; j < n2 ; j ++ ) for ( int k = 0 ; k < n3 ; k ++ ) if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) return true ; return false ; }
int main ( ) { int a1 [ ] = { 1 , 2 , 3 , 4 , 5 } ; int a2 [ ] = { 2 , 3 , 6 , 1 , 2 } ; int a3 [ ] = { 3 , 2 , 4 , 5 , 6 } ; int sum = 9 ; int n1 = sizeof ( a1 ) / sizeof ( a1 [ 0 ] ) ; int n2 = sizeof ( a2 ) / sizeof ( a2 [ 0 ] ) ; int n3 = sizeof ( a3 ) / sizeof ( a3 [ 0 ] ) ; findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) ? cout << " Yes " : cout << " No " ; return 0 ; }
int maxLen ( int arr [ ] , int n ) {
unordered_map < int , int > presum ;
int sum = 0 ;
int max_len = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
sum += arr [ i ] ; if ( arr [ i ] == 0 && max_len == 0 ) max_len = 1 ; if ( sum == 0 ) max_len = i + 1 ;
if ( presum . find ( sum ) != presum . end ( ) ) { max_len = max ( max_len , i - presum [ sum ] ) ; }
else { presum [ sum ] = i ; } } return max_len ; }
int main ( ) { int arr [ ] = { 15 , -2 , 2 , -8 , 1 , 7 , 10 , 23 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Length ▁ of ▁ the ▁ longest ▁ 0 ▁ sum ▁ subarray ▁ is ▁ " << maxLen ( arr , n ) ; return 0 ; }
int longestSubsequence ( int a [ ] , int n ) {
unordered_map < int , int > mp ;
int dp [ n ] ; memset ( dp , 0 , sizeof ( dp ) ) ; int maximum = INT_MIN ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( mp . find ( a [ i ] - 1 ) != mp . end ( ) ) {
int lastIndex = mp [ a [ i ] - 1 ] - 1 ; dp [ i ] = 1 + dp [ lastIndex ] ; } else dp [ i ] = 1 ; mp [ a [ i ] ] = i + 1 ; maximum = max ( maximum , dp [ i ] ) ; } return maximum ; }
int main ( ) { int a [ ] = { 3 , 10 , 3 , 11 , 4 , 5 , 6 , 7 , 8 , 12 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << longestSubsequence ( a , n ) ; return 0 ; }
int longLenSub ( int arr [ ] , int n ) {
unordered_map < int , int > um ;
int longLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int len = 0 ;
if ( um . find ( arr [ i ] - 1 ) != um . end ( ) && len < um [ arr [ i ] - 1 ] ) len = um [ arr [ i ] - 1 ] ;
if ( um . find ( arr [ i ] + 1 ) != um . end ( ) && len < um [ arr [ i ] + 1 ] ) len = um [ arr [ i ] + 1 ] ;
um [ arr [ i ] ] = len + 1 ;
if ( longLen < um [ arr [ i ] ] ) longLen = um [ arr [ i ] ] ; }
return longLen ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 3 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Longest ▁ length ▁ subsequence ▁ = ▁ " << longLenSub ( arr , n ) ; return 0 ; }
int countWindowDistinct ( int win [ ] , int k ) { int dist_count = 0 ;
for ( int i = 0 ; i < k ; i ++ ) {
int j ; for ( j = 0 ; j < i ; j ++ ) if ( win [ i ] == win [ j ] ) break ; if ( j == i ) dist_count ++ ; } return dist_count ; }
void countDistinct ( int arr [ ] , int n , int k ) {
for ( int i = 0 ; i <= n - k ; i ++ ) cout << countWindowDistinct ( arr + i , k ) << endl ; }
int main ( ) { int arr [ ] = { 1 , 2 , 1 , 3 , 4 , 2 , 3 } , k = 4 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; countDistinct ( arr , n , k ) ; return 0 ; }
bool areElementsContiguous ( int arr [ ] , int n ) {
int max = * max_element ( arr , arr + n ) ; int min = * min_element ( arr , arr + n ) ; int m = max - min + 1 ;
if ( m > n ) return false ;
bool visited [ m ] ; memset ( visited , false , sizeof ( visited ) ) ;
for ( int i = 0 ; i < n ; i ++ ) visited [ arr [ i ] - min ] = true ;
for ( int i = 0 ; i < m ; i ++ ) if ( visited [ i ] == false ) return false ; return true ; }
int main ( ) { int arr [ ] = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( areElementsContiguous ( arr , n ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
bool areElementsContiguous ( int arr [ ] , int n ) {
unordered_set < int > us ; for ( int i = 0 ; i < n ; i ++ ) us . insert ( arr [ i ] ) ;
int count = 1 ;
int curr_ele = arr [ 0 ] - 1 ;
while ( us . find ( curr_ele ) != us . end ( ) ) {
count ++ ;
curr_ele -- ; }
curr_ele = arr [ 0 ] + 1 ;
while ( us . find ( curr_ele ) != us . end ( ) ) {
count ++ ;
curr_ele ++ ; }
return ( count == ( int ) ( us . size ( ) ) ) ; }
int main ( ) { int arr [ ] = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( areElementsContiguous ( arr , n ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
void subArraySum ( int arr [ ] , int n , int sum ) {
unordered_map < int , int > map ; int curr_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { curr_sum = curr_sum + arr [ i ] ;
if ( curr_sum == sum ) { cout << " Sum ▁ found ▁ between ▁ indexes ▁ " << 0 << " ▁ to ▁ " << i << endl ; return ; }
if ( map . find ( curr_sum - sum ) != map . end ( ) ) { cout << " Sum ▁ found ▁ between ▁ indexes ▁ " << map [ curr_sum - sum ] + 1 << " ▁ to ▁ " << i << endl ; return ; }
map [ curr_sum ] = i ; }
cout << " No ▁ subarray ▁ with ▁ given ▁ sum ▁ exists " ; }
int main ( ) { int arr [ ] = { 10 , 2 , -2 , -20 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int sum = -10 ; subArraySum ( arr , n , sum ) ; return 0 ; }
int minInsertion ( string str ) {
int n = str . length ( ) ;
int res = 0 ;
int count [ 26 ] = { 0 } ;
for ( int i = 0 ; i < n ; i ++ ) count [ str [ i ] - ' a ' ] ++ ;
for ( int i = 0 ; i < 26 ; i ++ ) if ( count [ i ] % 2 == 1 ) res ++ ;
return ( res == 0 ) ? 0 : res - 1 ; }
int main ( ) { string str = " geeksforgeeks " ; cout << minInsertion ( str ) ; return 0 ; }
int maxdiff ( int arr [ ] , int n ) { unordered_map < int , int > freq ;
for ( int i = 0 ; i < n ; i ++ ) freq [ arr [ i ] ] ++ ; int ans = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( freq [ arr [ i ] ] > freq [ arr [ j ] ] && arr [ i ] > arr [ j ] ) ans = max ( ans , freq [ arr [ i ] ] - freq [ arr [ j ] ] ) ; else if ( freq [ arr [ i ] ] < freq [ arr [ j ] ] && arr [ i ] < arr [ j ] ) ans = max ( ans , freq [ arr [ j ] ] - freq [ arr [ i ] ] ) ; } } return ans ; }
int main ( ) { int arr [ ] = { 3 , 1 , 3 , 2 , 3 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxdiff ( arr , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int findDiff ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ; int count = 0 , max_count = 0 , min_count = n ; for ( int i = 0 ; i < ( n - 1 ) ; i ++ ) {
if ( arr [ i ] == arr [ i + 1 ] ) { count += 1 ; continue ; } else { max_count = max ( max_count , count ) ; min_count = min ( min_count , count ) ; count = 0 ; } } return ( max_count - min_count ) ; }
int main ( ) { int arr [ ] = { 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findDiff ( arr , n ) << " STRNEWLINE " ; return 0 ; }
int maxDiff ( int arr [ ] , int n ) { int SubsetSum_1 = 0 , SubsetSum_2 = 0 ; for ( int i = 0 ; i <= n - 1 ; i ++ ) { bool isSingleOccurance = true ; for ( int j = i + 1 ; j <= n - 1 ; j ++ ) {
if ( arr [ i ] == arr [ j ] ) { isSingleOccurance = false ; arr [ i ] = arr [ j ] = 0 ; break ; } } if ( isSingleOccurance ) { if ( arr [ i ] > 0 ) SubsetSum_1 += arr [ i ] ; else SubsetSum_2 += arr [ i ] ; } } return abs ( SubsetSum_1 - SubsetSum_2 ) ; }
int main ( ) { int arr [ ] = { 4 , 2 , -3 , 3 , -2 , -2 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Maximum ▁ Difference ▁ = ▁ " << maxDiff ( arr , n ) ; return 0 ; }
int maxDiff ( int arr [ ] , int n ) { int result = 0 ;
sort ( arr , arr + n ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) result += abs ( arr [ i ] ) ; else i ++ ; }
if ( arr [ n - 2 ] != arr [ n - 1 ] ) result += abs ( arr [ n - 1 ] ) ;
return result ; }
int main ( ) { int arr [ ] = { 4 , 2 , -3 , 3 , -2 , -2 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Maximum ▁ Difference ▁ = ▁ " << maxDiff ( arr , n ) ; return 0 ; }
int maxDiff ( int arr [ ] , int n ) { unordered_map < int , int > hashPositive ; unordered_map < int , int > hashNegative ; int SubsetSum_1 = 0 , SubsetSum_2 = 0 ;
for ( int i = 0 ; i <= n - 1 ; i ++ ) if ( arr [ i ] > 0 ) hashPositive [ arr [ i ] ] ++ ;
for ( int i = 0 ; i <= n - 1 ; i ++ ) if ( arr [ i ] > 0 && hashPositive [ arr [ i ] ] == 1 ) SubsetSum_1 += arr [ i ] ;
for ( int i = 0 ; i <= n - 1 ; i ++ ) if ( arr [ i ] < 0 ) hashNegative [ abs ( arr [ i ] ) ] ++ ;
for ( int i = 0 ; i <= n - 1 ; i ++ ) if ( arr [ i ] < 0 && hashNegative [ abs ( arr [ i ] ) ] == 1 ) SubsetSum_2 += arr [ i ] ; return abs ( SubsetSum_1 - SubsetSum_2 ) ; }
int main ( ) { int arr [ ] = { 4 , 2 , -3 , 3 , -2 , -2 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Maximum ▁ Difference ▁ = ▁ " << maxDiff ( arr , n ) ; return 0 ; }
void minRange ( int arr [ ] , int n , int k ) { int l = 0 , r = n ;
for ( int i = 0 ; i < n ; i ++ ) {
unordered_set < int > s ; int j ; for ( j = i ; j < n ; j ++ ) { s . insert ( arr [ j ] ) ; if ( s . size ( ) == k ) { if ( ( j - i ) < ( r - l ) ) { r = j ; l = i ; } break ; } }
if ( j == n ) break ; }
if ( l == 0 && r == n ) cout << " Invalid ▁ k " ; else cout << l << " ▁ " << r ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; minRange ( arr , n , k ) ; return 0 ; }
void minRange ( int arr [ ] , int n , int k ) {
int l = 0 , r = n ;
int j = -1 ; map < int , int > hm ; for ( int i = 0 ; i < n ; i ++ ) { while ( j < n ) {
j ++ ;
if ( hm . size ( ) < k ) hm [ arr [ j ] ] ++ ;
if ( hm . size ( ) == k && ( ( r - l ) >= ( j - i ) ) ) { l = i ; r = j ; break ; } }
if ( hm . size ( ) < k ) break ;
while ( hm . size ( ) == k ) { if ( hm [ arr [ i ] ] == 1 ) hm . erase ( arr [ i ] ) ; else hm [ arr [ i ] ] -- ;
i ++ ;
if ( hm . size ( ) == k && ( r - l ) >= ( j - i ) ) { l = i ; r = j ; } } if ( hm [ arr [ i ] ] == 1 ) hm . erase ( arr [ i ] ) ; else hm [ arr [ i ] ] -- ; } if ( l == 0 && r == n ) cout << " Invalid ▁ k " << endl ; else cout << l << " ▁ " << r << endl ; }
int main ( ) { int arr [ ] = { 1 , 1 , 2 , 2 , 3 , 3 , 4 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; minRange ( arr , n , k ) ; return 0 ; }
void longest ( int a [ ] , int n , int k ) { unordered_map < int , int > freq ; int start = 0 , end = 0 , now = 0 , l = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
freq [ a [ i ] ] ++ ;
if ( freq [ a [ i ] ] == 1 ) now ++ ;
while ( now > k ) {
freq [ a [ l ] ] -- ;
if ( freq [ a [ l ] ] == 0 ) now -- ;
l ++ ; }
if ( i - l + 1 >= end - start + 1 ) end = i , start = l ; }
for ( int i = start ; i <= end ; i ++ ) cout << a [ i ] << " ▁ " ; }
int main ( ) { int a [ ] = { 6 , 5 , 1 , 2 , 3 , 2 , 1 , 4 , 5 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int k = 3 ; longest ( a , n , k ) ; return 0 ; }
int sum ( int a [ ] , int n ) {
unordered_map < int , int > cnt ;
int ans = 0 , pre_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { ans += ( i * a [ i ] ) - pre_sum ; pre_sum += a [ i ] ;
if ( cnt [ a [ i ] - 1 ] ) ans -= cnt [ a [ i ] - 1 ] ;
if ( cnt [ a [ i ] + 1 ] ) ans += cnt [ a [ i ] + 1 ] ;
cnt [ a [ i ] ] ++ ; } return ans ; }
int main ( ) { int a [ ] = { 1 , 2 , 3 , 1 , 3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << sum ( a , n ) ; return 0 ; }
int calculate ( int a [ ] , int n ) {
sort ( a , a + n ) ; int count = 1 ; int answer = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == a [ i - 1 ] ) {
count += 1 ; } else {
answer = answer + ( count * ( count - 1 ) ) / 2 ; count = 1 ; } } answer = answer + ( count * ( count - 1 ) ) / 2 ; return answer ; }
int main ( ) { int a [ ] = { 1 , 2 , 1 , 2 , 4 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
cout << calculate ( a , n ) ; return 0 ; }
int calculate ( int a [ ] , int n ) {
int * maximum = max_element ( a , a + n ) ;
int frequency [ * maximum + 1 ] = { 0 } ;
for ( int i = 0 ; i < n ; i ++ ) {
frequency [ a [ i ] ] += 1 ; } int answer = 0 ;
for ( int i = 0 ; i < ( * maximum ) + 1 ; i ++ ) {
answer = answer + frequency [ i ] * ( frequency [ i ] - 1 ) ; } return answer / 2 ; }
int main ( ) { int a [ ] = { 1 , 2 , 1 , 2 , 4 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
cout << ( calculate ( a , n ) ) ; }
int countSubarrWithEqualZeroAndOne ( int arr [ ] , int n ) {
unordered_map < int , int > um ; int curr_sum = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { curr_sum += ( arr [ i ] == 0 ) ? -1 : arr [ i ] ; um [ curr_sum ] ++ ; } int count = 0 ;
for ( auto itr = um . begin ( ) ; itr != um . end ( ) ; itr ++ ) {
if ( itr -> second > 1 ) count += ( ( itr -> second * ( itr -> second - 1 ) ) / 2 ) ; }
if ( um . find ( 0 ) != um . end ( ) ) count += um [ 0 ] ;
return count ; }
int main ( ) { int arr [ ] = { 1 , 0 , 0 , 1 , 0 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ = ▁ " << countSubarrWithEqualZeroAndOne ( arr , n ) ; return 0 ; }
int lenOfLongSubarr ( int arr [ ] , int n ) {
unordered_map < int , int > um ; int sum = 0 , maxLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
sum += arr [ i ] == 0 ? -1 : 1 ;
if ( sum == 1 ) maxLen = i + 1 ;
else if ( um . find ( sum ) == um . end ( ) ) um [ sum ] = i ;
if ( um . find ( sum - 1 ) != um . end ( ) ) {
if ( maxLen < ( i - um [ sum - 1 ] ) ) maxLen = i - um [ sum - 1 ] ; } }
return maxLen ; }
int main ( ) { int arr [ ] = { 0 , 1 , 1 , 0 , 0 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Length ▁ = ▁ " << lenOfLongSubarr ( arr , n ) ; return 0 ; }
void printAllAPTriplets ( int arr [ ] , int n ) { unordered_set < int > s ; for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int diff = arr [ j ] - arr [ i ] ; if ( s . find ( arr [ i ] - diff ) != s . end ( ) ) cout << arr [ i ] - diff << " ▁ " << arr [ i ] << " ▁ " << arr [ j ] << endl ; } s . insert ( arr [ i ] ) ; } }
int main ( ) { int arr [ ] = { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printAllAPTriplets ( arr , n ) ; return 0 ; }
void printAllAPTriplets ( int arr [ ] , int n ) { for ( int i = 1 ; i < n - 1 ; i ++ ) {
for ( int j = i - 1 , k = i + 1 ; j >= 0 && k < n ; ) {
if ( arr [ j ] + arr [ k ] == 2 * arr [ i ] ) { cout << arr [ j ] << " ▁ " << arr [ i ] << " ▁ " << arr [ k ] << endl ;
k ++ ; j -- ; }
else if ( arr [ j ] + arr [ k ] < 2 * arr [ i ] ) k ++ ; else j -- ; } } }
int main ( ) { int arr [ ] = { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printAllAPTriplets ( arr , n ) ; return 0 ; }
void findTriplets ( int a [ ] , int n , int sum ) { int i ;
sort ( a , a + n ) ;
bool flag = false ;
for ( i = 0 ; i < n - 2 ; i ++ ) { if ( i == 0 a [ i ] > a [ i - 1 ] ) {
int start = i + 1 ;
int end = n - 1 ;
int target = sum - a [ i ] ; while ( start < end ) {
if ( start > i + 1 && a [ start ] == a [ start - 1 ] ) { start ++ ; continue ; }
if ( end < n - 1 && a [ end ] == a [ end + 1 ] ) { end -- ; continue ; }
if ( target == a [ start ] + a [ end ] ) { cout << " [ " << a [ i ] << " , " << a [ start ] << " , " << a [ end ] << " ] ▁ " ; flag = true ; start ++ ; end -- ; }
else if ( target > ( a [ start ] + a [ end ] ) ) { start ++ ; }
else { end -- ; } } } }
if ( flag == false ) { cout << " No ▁ Such ▁ Triplets ▁ Exist " << " STRNEWLINE " ; } }
int main ( ) { int a [ ] = { 12 , 3 , 6 , 1 , 6 , 9 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int sum = 24 ;
findTriplets ( a , n , sum ) ; return 0 ; }
int countTriplets ( int arr [ ] , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) for ( int j = i + 1 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] * arr [ j ] * arr [ k ] == m ) count ++ ; return count ; }
int main ( ) { int arr [ ] = { 1 , 4 , 6 , 2 , 3 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int m = 24 ; cout << countTriplets ( arr , n , m ) ; return 0 ; }
int countPairs ( int arr [ ] , int n ) { int ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ )
if ( arr [ i ] == arr [ j ] ) ans ++ ; return ans ; }
int main ( ) { int arr [ ] = { 1 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countPairs ( arr , n ) << endl ; return 0 ; }
int countPairs ( int arr [ ] , int n ) { unordered_map < int , int > mp ;
for ( int i = 0 ; i < n ; i ++ ) mp [ arr [ i ] ] ++ ;
int ans = 0 ; for ( auto it = mp . begin ( ) ; it != mp . end ( ) ; it ++ ) { int count = it -> second ; ans += ( count * ( count - 1 ) ) / 2 ; } return ans ; }
int main ( ) { int arr [ ] = { 1 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countPairs ( arr , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  5
int ptr [ 501 ] ;
void findSmallestRange ( int arr [ ] [ N ] , int n , int k ) { int i , minval , maxval , minrange , minel , maxel , flag , minind ;
for ( i = 0 ; i <= k ; i ++ ) ptr [ i ] = 0 ; minrange = INT_MAX ; while ( 1 ) {
minind = -1 ; minval = INT_MAX ; maxval = INT_MIN ; flag = 0 ;
for ( i = 0 ; i < k ; i ++ ) {
if ( ptr [ i ] == n ) { flag = 1 ; break ; }
if ( ptr [ i ] < n && arr [ i ] [ ptr [ i ] ] < minval ) {
minind = i ; minval = arr [ i ] [ ptr [ i ] ] ; }
if ( ptr [ i ] < n && arr [ i ] [ ptr [ i ] ] > maxval ) { maxval = arr [ i ] [ ptr [ i ] ] ; } }
if ( flag ) break ; ptr [ minind ] ++ ;
if ( ( maxval - minval ) < minrange ) { minel = minval ; maxel = maxval ; minrange = maxel - minel ; } } printf ( " The ▁ smallest ▁ range ▁ is ▁ [ % d , ▁ % d ] STRNEWLINE " , minel , maxel ) ; }
int main ( ) { int arr [ ] [ N ] = { { 4 , 7 , 9 , 12 , 15 } , { 0 , 8 , 10 , 14 , 20 } , { 6 , 12 , 16 , 30 , 50 } } ; int k = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findSmallestRange ( arr , N , k ) ; return 0 ; }
int countNum ( int arr [ ] , int n ) { int count = 0 ;
sort ( arr , arr + n ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) count += arr [ i + 1 ] - arr [ i ] - 1 ; return count ; }
int main ( ) { int arr [ ] = { 3 , 5 , 8 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countNum ( arr , n ) << endl ; return 0 ; }
int countNum ( int arr [ ] , int n ) { unordered_set < int > s ; int count = 0 , maxm = INT_MIN , minm = INT_MAX ;
for ( int i = 0 ; i < n ; i ++ ) { s . insert ( arr [ i ] ) ; if ( arr [ i ] < minm ) minm = arr [ i ] ; if ( arr [ i ] > maxm ) maxm = arr [ i ] ; }
for ( int i = minm ; i <= maxm ; i ++ ) if ( s . find ( arr [ i ] ) == s . end ( ) ) count ++ ; return count ; }
int main ( ) { int arr [ ] = { 3 , 5 , 8 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countNum ( arr , n ) << endl ; return 0 ; }
#define MAXN  11
#define ver  2
int hashtable [ ver ] [ MAXN ] ;
int pos [ ver ] ;
void initTable ( ) { for ( int j = 0 ; j < MAXN ; j ++ ) for ( int i = 0 ; i < ver ; i ++ ) hashtable [ i ] [ j ] = INT_MIN ; }
int hash ( int function , int key ) { switch ( function ) { case 1 : return key % MAXN ; case 2 : return ( key / MAXN ) % MAXN ; } }
void place ( int key , int tableID , int cnt , int n ) {
if ( cnt == n ) { printf ( " % d ▁ unpositioned STRNEWLINE " , key ) ; printf ( " Cycle ▁ present . ▁ REHASH . STRNEWLINE " ) ; return ; }
for ( int i = 0 ; i < ver ; i ++ ) { pos [ i ] = hash ( i + 1 , key ) ; if ( hashtable [ i ] [ pos [ i ] ] == key ) return ; }
if ( hashtable [ tableID ] [ pos [ tableID ] ] != INT_MIN ) { int dis = hashtable [ tableID ] [ pos [ tableID ] ] ; hashtable [ tableID ] [ pos [ tableID ] ] = key ; place ( dis , ( tableID + 1 ) % ver , cnt + 1 , n ) ; }
else hashtable [ tableID ] [ pos [ tableID ] ] = key ; }
void printTable ( ) { printf ( " Final ▁ hash ▁ tables : STRNEWLINE " ) ; for ( int i = 0 ; i < ver ; i ++ , printf ( " STRNEWLINE " ) ) for ( int j = 0 ; j < MAXN ; j ++ ) ( hashtable [ i ] [ j ] == INT_MIN ) ? printf ( " - ▁ " ) : printf ( " % d ▁ " , hashtable [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; }
void cuckoo ( int keys [ ] , int n ) {
initTable ( ) ;
for ( int i = 0 , cnt = 0 ; i < n ; i ++ , cnt = 0 ) place ( keys [ i ] , 0 , cnt , n ) ;
printTable ( ) ; }
int keys_1 [ ] = { 20 , 50 , 53 , 75 , 100 , 67 , 105 , 3 , 36 , 39 } ; int n = sizeof ( keys_1 ) / sizeof ( int ) ; cuckoo ( keys_1 , n ) ;
int keys_2 [ ] = { 20 , 50 , 53 , 75 , 100 , 67 , 105 , 3 , 36 , 39 , 6 } ; int m = sizeof ( keys_2 ) / sizeof ( int ) ; cuckoo ( keys_2 , m ) ; return 0 ; }
int sumoflength ( int arr [ ] , int n ) {
unordered_set < int > s ;
int j = 0 , ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { while ( j < n && s . find ( arr [ j ] ) == s . end ( ) ) { s . insert ( arr [ j ] ) ; j ++ ; }
ans += ( ( j - i ) * ( j - i + 1 ) ) / 2 ;
s . erase ( arr [ i ] ) ; } return ans ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << sumoflength ( arr , n ) << endl ; return 0 ; }
int countDistictSubarray ( int arr [ ] , int n ) {
unordered_map < int , int > vis ; for ( int i = 0 ; i < n ; ++ i ) vis [ arr [ i ] ] = 1 ; int k = vis . size ( ) ;
vis . clear ( ) ;
int ans = 0 , right = 0 , window = 0 ; for ( int left = 0 ; left < n ; ++ left ) { while ( right < n && window < k ) { ++ vis [ arr [ right ] ] ; if ( vis [ arr [ right ] ] == 1 ) ++ window ; ++ right ; }
if ( window == k ) ans += ( n - right + 1 ) ;
-- vis [ arr [ left ] ] ;
if ( vis [ arr [ left ] ] == 0 ) -- window ; } return ans ; }
int main ( ) { int arr [ ] = { 2 , 1 , 3 , 2 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countDistictSubarray ( arr , n ) << " n " ; return 0 ; }
int countSubarrays ( int arr [ ] , int n ) {
int difference = 0 ; int ans = 0 ;
int hash_positive [ n + 1 ] , hash_negative [ n + 1 ] ;
fill_n ( hash_positive , n + 1 , 0 ) ; fill_n ( hash_negative , n + 1 , 0 ) ;
hash_positive [ 0 ] = 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] & 1 == 1 ) difference ++ ; else difference -- ;
if ( difference < 0 ) { ans += hash_negative [ - difference ] ; hash_negative [ - difference ] ++ ; }
else { ans += hash_positive [ difference ] ; hash_positive [ difference ] ++ ; } }
return ans ; }
int main ( ) { int arr [ ] = { 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
cout << " Total ▁ Number ▁ of ▁ Even - Odd ▁ subarrays " " ▁ are ▁ " << countSubarrays ( arr , n ) ; return 0 ; }
struct Node { int data ; Node * left , * right ; } ; struct Node * newNode ( int data ) { struct Node * node = new Node ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
int height ( Node * root , int & ans , Node * ( & k ) , int & lh , int & rh , int & f ) { if ( root == NULL ) return 0 ; int left_height = height ( root -> left , ans , k , lh , rh , f ) ; int right_height = height ( root -> right , ans , k , lh , rh , f ) ;
if ( ans < 1 + left_height + right_height ) { ans = 1 + left_height + right_height ;
k = root ;
lh = left_height ; rh = right_height ; } return 1 + max ( left_height , right_height ) ; }
void printArray ( int ints [ ] , int len , int f ) { int i ;
if ( f == 0 ) { for ( i = len - 1 ; i >= 0 ; i -- ) { printf ( " % d ▁ " , ints [ i ] ) ; } } else if ( f == 1 ) { for ( i = 0 ; i < len ; i ++ ) { printf ( " % d ▁ " , ints [ i ] ) ; } } }
void printPathsRecur ( Node * node , int path [ ] , int pathLen , int max , int & f ) { if ( node == NULL ) return ;
path [ pathLen ] = node -> data ; pathLen ++ ;
if ( node -> left == NULL && node -> right == NULL ) {
if ( pathLen == max && ( f == 0 f == 1 ) ) { printArray ( path , pathLen , f ) ; f = 2 ; } } else {
printPathsRecur ( node -> left , path , pathLen , max , f ) ; printPathsRecur ( node -> right , path , pathLen , max , f ) ; } }
void diameter ( Node * root ) { if ( root == NULL ) return ;
int ans = INT_MIN , lh = 0 , rh = 0 ;
int f = 0 ; Node * k ; int height_of_tree = height ( root , ans , k , lh , rh , f ) ; int lPath [ 100 ] , pathlen = 0 ;
printPathsRecur ( k -> left , lPath , pathlen , lh , f ) ; printf ( " % d ▁ " , k -> data ) ; int rPath [ 100 ] ; f = 1 ;
printPathsRecur ( k -> right , rPath , pathlen , rh , f ) ; }
struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> left -> right -> left = newNode ( 6 ) ; root -> left -> right -> right = newNode ( 7 ) ; root -> left -> left -> right = newNode ( 8 ) ; root -> left -> left -> right -> left = newNode ( 9 ) ; diameter ( root ) ; return 0 ; }
int findLargestd ( int S [ ] , int n ) { bool found = false ;
sort ( S , S + n ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) continue ; for ( int k = j + 1 ; k < n ; k ++ ) { if ( i == k ) continue ; for ( int l = k + 1 ; l < n ; l ++ ) { if ( i == l ) continue ;
if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) { found = true ; return S [ i ] ; } } } } } if ( found == false ) return INT_MIN ; }
int main ( ) { int S [ ] = { 2 , 3 , 5 , 7 , 12 } ; int n = sizeof ( S ) / sizeof ( S [ 0 ] ) ; int ans = findLargestd ( S , n ) ; if ( ans == INT_MIN ) cout << " No ▁ Solution " << endl ; else cout << " Largest ▁ d ▁ such ▁ that ▁ a ▁ + ▁ b ▁ + ▁ " << " c ▁ = ▁ d ▁ is ▁ " << ans << endl ; return 0 ; }
int findFourElements ( int arr [ ] , int n ) { unordered_map < int , pair < int , int > > mp ;
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) mp [ arr [ i ] + arr [ j ] ] = { i , j } ;
int d = INT_MIN ; for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int abs_diff = abs ( arr [ i ] - arr [ j ] ) ;
if ( mp . find ( abs_diff ) != mp . end ( ) ) {
pair < int , int > p = mp [ abs_diff ] ; if ( p . first != i && p . first != j && p . second != i && p . second != j ) d = max ( d , max ( arr [ i ] , arr [ j ] ) ) ; } } } return d ; }
int main ( ) { int arr [ ] = { 2 , 3 , 5 , 7 , 12 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int res = findFourElements ( arr , n ) ; if ( res == INT_MIN ) cout << " No ▁ Solution . " ; else cout << res ; return 0 ; }
int recaman ( int n ) {
int arr [ n ] ;
arr [ 0 ] = 0 ; printf ( " % d , ▁ " , arr [ 0 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) { int curr = arr [ i - 1 ] - i ; int j ; for ( j = 0 ; j < i ; j ++ ) {
if ( ( arr [ j ] == curr ) curr < 0 ) { curr = arr [ i - 1 ] + i ; break ; } } arr [ i ] = curr ; printf ( " % d , ▁ " , arr [ i ] ) ; } }
int main ( ) { int n = 17 ; recaman ( n ) ; return 0 ; }
void recaman ( int n ) { if ( n <= 0 ) return ;
printf ( " % d , ▁ " , 0 ) ; unordered_set < int > s ; s . insert ( 0 ) ;
int prev = 0 ; for ( int i = 1 ; i < n ; i ++ ) { int curr = prev - i ;
if ( curr < 0 || s . find ( curr ) != s . end ( ) ) curr = prev + i ; s . insert ( curr ) ; printf ( " % d , ▁ " , curr ) ; prev = curr ; } }
int main ( ) { int n = 17 ; recaman ( n ) ; return 0 ; }
int sumOfDiv ( int x ) {
int sum = 1 ; for ( int i = 2 ; i <= sqrt ( x ) ; i ++ ) { if ( x % i == 0 ) { sum += i ;
if ( x / i != i ) sum += x / i ; } } return sum ; }
bool isAmicable ( int a , int b ) { return ( sumOfDiv ( a ) == b && sumOfDiv ( b ) == a ) ; }
int countPairs ( int arr [ ] , int n ) {
unordered_set < int > s ; int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) s . insert ( arr [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( s . find ( sumOfDiv ( arr [ i ] ) ) != s . end ( ) ) {
int sum = sumOfDiv ( arr [ i ] ) ; if ( isAmicable ( arr [ i ] , sum ) ) count ++ ; } }
return count / 2 ; }
int main ( ) { int arr1 [ ] = { 220 , 284 , 1184 , 1210 , 2 , 5 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << countPairs ( arr1 , n1 ) << endl ; int arr2 [ ] = { 2620 , 2924 , 5020 , 5564 , 6232 , 6368 } ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; cout << countPairs ( arr2 , n2 ) << endl ; return 0 ; }
int findArea ( int arr [ ] , int n ) {
sort ( arr , arr + n , greater < int > ( ) ) ;
int dimension [ 2 ] = { 0 , 0 } ;
for ( int i = 0 , j = 0 ; i < n - 1 && j < 2 ; i ++ )
if ( arr [ i ] == arr [ i + 1 ] ) dimension [ j ++ ] = arr [ i ++ ] ;
return ( dimension [ 0 ] * dimension [ 1 ] ) ; }
int main ( ) { int arr [ ] = { 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findArea ( arr , n ) ; return 0 ; }
int findArea ( int arr [ ] , int n ) { unordered_set < int > s ;
int first = 0 , second = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( s . find ( arr [ i ] ) == s . end ( ) ) { s . insert ( arr [ i ] ) ; continue ; }
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; } else if ( arr [ i ] > second ) second = arr [ i ] ; }
return ( first * second ) ; }
int main ( ) { int arr [ ] = { 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findArea ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX_PATH_SIZE  1000
struct Node { char data ; Node * left , * right ; } ;
Node * newNode ( char data ) { struct Node * temp = new Node ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
struct PATH { int Hd ; char key ; } ;
void printPath ( vector < PATH > path , int size ) {
int minimum_Hd = INT_MAX ; PATH p ;
for ( int it = 0 ; it < size ; it ++ ) { p = path [ it ] ; minimum_Hd = min ( minimum_Hd , p . Hd ) ; }
for ( int it = 0 ; it < size ; it ++ ) {
p = path [ it ] ; int noOfUnderScores = abs ( p . Hd - minimum_Hd ) ;
for ( int i = 0 ; i < noOfUnderScores ; i ++ ) cout << " _ ▁ " ;
cout << p . key << endl ; } cout << " = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " << endl ; }
void printAllPathsUtil ( Node * root , vector < PATH > & AllPath , int HD , int order ) {
if ( root == NULL ) return ;
if ( root -> left == NULL && root -> right == NULL ) {
AllPath [ order ] = ( PATH { HD , root -> data } ) ; printPath ( AllPath , order + 1 ) ; return ; }
AllPath [ order ] = ( PATH { HD , root -> data } ) ;
printAllPathsUtil ( root -> left , AllPath , HD - 1 , order + 1 ) ;
printAllPathsUtil ( root -> right , AllPath , HD + 1 , order + 1 ) ; } void printAllPaths ( Node * root ) {
if ( root == NULL ) return ; vector < PATH > Allpaths ( MAX_PATH_SIZE ) ; printAllPathsUtil ( root , Allpaths , 0 , 0 ) ; }
int main ( ) { Node * root = newNode ( ' A ' ) ; root -> left = newNode ( ' B ' ) ; root -> right = newNode ( ' C ' ) ; root -> left -> left = newNode ( ' D ' ) ; root -> left -> right = newNode ( ' E ' ) ; root -> right -> left = newNode ( ' F ' ) ; root -> right -> right = newNode ( ' G ' ) ; printAllPaths ( root ) ; return 0 ; }
int longLenStrictBitonicSub ( int arr [ ] , int n ) {
unordered_map < int , int > inc , dcr ;
int len_inc [ n ] , len_dcr [ n ] ;
int longLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int len = 0 ;
if ( inc . find ( arr [ i ] - 1 ) != inc . end ( ) ) len = inc [ arr [ i ] - 1 ] ;
inc [ arr [ i ] ] = len_inc [ i ] = len + 1 ; }
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int len = 0 ;
if ( dcr . find ( arr [ i ] - 1 ) != dcr . end ( ) ) len = dcr [ arr [ i ] - 1 ] ;
dcr [ arr [ i ] ] = len_dcr [ i ] = len + 1 ; }
for ( int i = 0 ; i < n ; i ++ ) if ( longLen < ( len_inc [ i ] + len_dcr [ i ] - 1 ) ) longLen = len_inc [ i ] + len_dcr [ i ] - 1 ;
return longLen ; }
int main ( ) { int arr [ ] = { 1 , 5 , 2 , 3 , 4 , 5 , 3 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Longest ▁ length ▁ strict ▁ bitonic ▁ subsequence ▁ = ▁ " << longLenStrictBitonicSub ( arr , n ) ; return 0 ; }
void printArray ( int arr [ ] , int size ) ; void swap ( int arr [ ] , int fi , int si , int d ) ; void leftRotate ( int arr [ ] , int d , int n ) {
if ( d == 0 d == n ) return ;
if ( n - d == d ) { swap ( arr , 0 , n - d , d ) ; return ; }
if ( d < n - d ) { swap ( arr , 0 , n - d , d ) ; leftRotate ( arr , d , n - d ) ; }
else { swap ( arr , 0 , d , n - d ) ; leftRotate ( arr + n - d , 2 * d - n , d ) ; } }
void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << endl ; }
void swap ( int arr [ ] , int fi , int si , int d ) { int i , temp ; for ( i = 0 ; i < d ; i ++ ) { temp = arr [ fi + i ] ; arr [ fi + i ] = arr [ si + i ] ; arr [ si + i ] = temp ; } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; leftRotate ( arr , 2 , 7 ) ; printArray ( arr , 7 ) ; return 0 ; }
void leftRotate ( int arr [ ] , int d , int n ) { int i , j ; if ( d == 0 d == n ) return ; i = d ; j = n - d ; while ( i != j ) {
if ( i < j ) { swap ( arr , d - i , d + j - i , i ) ; j -= i ; }
else { swap ( arr , d - i , d , j ) ; i -= j ; } }
swap ( arr , d - i , d , i ) ; }
int search ( int arr [ ] , int l , int h , int key ) { if ( l > h ) return -1 ; int mid = ( l + h ) / 2 ; if ( arr [ mid ] == key ) return mid ;
if ( arr [ l ] <= arr [ mid ] ) {
if ( key >= arr [ l ] && key <= arr [ mid ] ) return search ( arr , l , mid - 1 , key ) ;
return search ( arr , mid + 1 , h , key ) ; }
if ( key >= arr [ mid ] && key <= arr [ h ] ) return search ( arr , mid + 1 , h , key ) ; return search ( arr , l , mid - 1 , key ) ; }
int main ( ) { int arr [ ] = { 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int key = 6 ; int i = search ( arr , 0 , n - 1 , key ) ; if ( i != -1 ) cout << " Index : ▁ " << i << endl ; else cout << " Key ▁ not ▁ found " ; }
bool pairInSortedRotated ( int arr [ ] , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) return true ;
if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return false ; }
int main ( ) { int arr [ ] = { 11 , 15 , 6 , 8 , 9 , 10 } ; int sum = 16 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( pairInSortedRotated ( arr , n , sum ) ) cout << " Array ▁ has ▁ two ▁ elements ▁ with ▁ sum ▁ 16" ; else cout << " Array ▁ doesn ' t ▁ have ▁ two ▁ elements ▁ with ▁ sum ▁ 16 ▁ " ; return 0 ; }
int pairsInSortedRotated ( int arr [ ] , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
int cnt = 0 ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) { cnt ++ ;
if ( l == ( r - 1 + n ) % n ) { return cnt ; } l = ( l + 1 ) % n ; r = ( r - 1 + n ) % n ; }
else if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return cnt ; }
int main ( ) { int arr [ ] = { 11 , 15 , 6 , 7 , 9 , 10 } ; int sum = 16 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << pairsInSortedRotated ( arr , n , sum ) ; return 0 ; }
int maxSum ( int arr [ ] , int n ) {
int arrSum = 0 ;
int currVal = 0 ; for ( int i = 0 ; i < n ; i ++ ) { arrSum = arrSum + arr [ i ] ; currVal = currVal + ( i * arr [ i ] ) ; }
int maxVal = currVal ;
for ( int j = 1 ; j < n ; j ++ ) { currVal = currVal + arrSum - n * arr [ n - j ] ; if ( currVal > maxVal ) maxVal = currVal ; }
return maxVal ; }
int main ( void ) { int arr [ ] = { 10 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Max sum is " return 0 ; }
int maxSum ( int arr [ ] , int n ) {
int res = INT_MIN ;
for ( int i = 0 ; i < n ; i ++ ) {
int curr_sum = 0 ;
for ( int j = 0 ; j < n ; j ++ ) { int index = ( i + j ) % n ; curr_sum += j * arr [ index ] ; }
res = max ( res , curr_sum ) ; } return res ; }
int main ( ) { int arr [ ] = { 8 , 3 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxSum ( arr , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int maxSum ( int arr [ ] , int n ) {
int cum_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) cum_sum += arr [ i ] ;
int curr_val = 0 ; for ( int i = 0 ; i < n ; i ++ ) curr_val += i * arr [ i ] ;
int res = curr_val ;
for ( int i = 1 ; i < n ; i ++ ) {
int next_val = curr_val - ( cum_sum - arr [ i - 1 ] ) + arr [ i - 1 ] * ( n - 1 ) ;
curr_val = next_val ;
res = max ( res , next_val ) ; } return res ; }
int main ( ) { int arr [ ] = { 8 , 3 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxSum ( arr , n ) << endl ; return 0 ; }
int countRotations ( int arr [ ] , int n ) {
int min = arr [ 0 ] , min_index ; for ( int i = 0 ; i < n ; i ++ ) { if ( min > arr [ i ] ) { min = arr [ i ] ; min_index = i ; } } return min_index ; }
int main ( ) { int arr [ ] = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countRotations ( arr , n ) ; return 0 ; }
int countRotations ( int arr [ ] , int low , int high ) {
if ( high < low ) return 0 ;
if ( high == low ) return low ;
int mid = low + ( high - low ) / 2 ;
if ( mid < high && arr [ mid + 1 ] < arr [ mid ] ) return ( mid + 1 ) ;
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) return mid ;
if ( arr [ high ] > arr [ mid ] ) return countRotations ( arr , low , mid - 1 ) ; return countRotations ( arr , mid + 1 , high ) ; }
int main ( ) { int arr [ ] = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << countRotations ( arr , 0 , n - 1 ) ; return 0 ; }
void preprocess ( int arr [ ] , int n , int temp [ ] ) {
for ( int i = 0 ; i < n ; i ++ ) temp [ i ] = temp [ i + n ] = arr [ i ] ; }
void leftRotate ( int arr [ ] , int n , int k , int temp [ ] ) {
int start = k % n ;
for ( int i = start ; i < start + n ; i ++ ) cout << temp [ i ] << " ▁ " ; cout << endl ; }
int main ( ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int temp [ 2 * n ] ; preprocess ( arr , n , temp ) ; int k = 2 ; leftRotate ( arr , n , k , temp ) ; k = 3 ; leftRotate ( arr , n , k , temp ) ; k = 4 ; leftRotate ( arr , n , k , temp ) ; return 0 ; }
void leftRotate ( int arr [ ] , int n , int k ) {
for ( int i = k ; i < k + n ; i ++ ) cout << arr [ i % n ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 2 ; leftRotate ( arr , n , k ) ; cout << endl ; k = 3 ; leftRotate ( arr , n , k ) ; cout << endl ; k = 4 ; leftRotate ( arr , n , k ) ; cout << endl ; return 0 ; }
int findMin ( int arr [ ] , int low , int high ) { while ( low < high ) { int mid = low + ( high - low ) / 2 ; if ( arr [ mid ] == arr [ high ] ) high -- ; else if ( arr [ mid ] > arr [ high ] ) low = mid + 1 ; else high = mid ; } return arr [ high ] ; }
int main ( ) { int arr1 [ ] = { 5 , 6 , 1 , 2 , 3 , 4 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << " The ▁ minimum ▁ element ▁ is ▁ " << findMin ( arr1 , 0 , n1 - 1 ) << endl ; int arr2 [ ] = { 1 , 2 , 3 , 4 } ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; cout << " The ▁ minimum ▁ element ▁ is ▁ " << findMin ( arr2 , 0 , n2 - 1 ) << endl ; int arr3 [ ] = { 1 } ; int n3 = sizeof ( arr3 ) / sizeof ( arr3 [ 0 ] ) ; cout << " The ▁ minimum ▁ element ▁ is ▁ " << findMin ( arr3 , 0 , n3 - 1 ) << endl ; int arr4 [ ] = { 1 , 2 } ; int n4 = sizeof ( arr4 ) / sizeof ( arr4 [ 0 ] ) ; cout << " The ▁ minimum ▁ element ▁ is ▁ " << findMin ( arr4 , 0 , n4 - 1 ) << endl ; int arr5 [ ] = { 2 , 1 } ; int n5 = sizeof ( arr5 ) / sizeof ( arr5 [ 0 ] ) ; cout << " The ▁ minimum ▁ element ▁ is ▁ " << findMin ( arr5 , 0 , n5 - 1 ) << endl ; int arr6 [ ] = { 5 , 6 , 7 , 1 , 2 , 3 , 4 } ; int n6 = sizeof ( arr6 ) / sizeof ( arr6 [ 0 ] ) ; cout << " The ▁ minimum ▁ element ▁ is ▁ " << findMin ( arr6 , 0 , n6 - 1 ) << endl ; int arr7 [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int n7 = sizeof ( arr7 ) / sizeof ( arr7 [ 0 ] ) ; cout << " The ▁ minimum ▁ element ▁ is ▁ " << findMin ( arr7 , 0 , n7 - 1 ) << endl ; int arr8 [ ] = { 2 , 3 , 4 , 5 , 6 , 7 , 8 , 1 } ; int n8 = sizeof ( arr8 ) / sizeof ( arr8 [ 0 ] ) ; cout << " The ▁ minimum ▁ element ▁ is ▁ " << findMin ( arr8 , 0 , n8 - 1 ) << endl ; int arr9 [ ] = { 3 , 4 , 5 , 1 , 2 } ; int n9 = sizeof ( arr9 ) / sizeof ( arr9 [ 0 ] ) ; cout << " The ▁ minimum ▁ element ▁ is ▁ " << findMin ( arr9 , 0 , n9 - 1 ) << endl ; return 0 ; }
void reverseArray ( int arr [ ] , int start , int end ) { while ( start < end ) { std :: swap ( arr [ start ] , arr [ end ] ) ; start ++ ; end -- ; } }
void rightRotate ( int arr [ ] , int d , int n ) { reverseArray ( arr , 0 , n - 1 ) ; reverseArray ( arr , 0 , d - 1 ) ; reverseArray ( arr , d , n - 1 ) ; }
void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) std :: cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; rightRotate ( arr , k , n ) ; printArray ( arr , n ) ; return 0 ; }
int maxHamming ( int arr [ ] , int n ) {
int brr [ 2 * n + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ i ] = arr [ i ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ n + i ] = arr [ i ] ;
int maxHam = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { int currHam = 0 ; for ( int j = i , k = 0 ; j < ( i + n ) ; j ++ , k ++ ) if ( brr [ j ] != arr [ k ] ) currHam ++ ;
if ( currHam == n ) return n ; maxHam = max ( maxHam , currHam ) ; } return maxHam ; }
int main ( ) { int arr [ ] = { 2 , 4 , 6 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxHamming ( arr , n ) ; return 0 ; }
void leftRotate ( int arr [ ] , int n , int k ) {
int mod = k % n ;
for ( int i = 0 ; i < n ; i ++ ) cout << ( arr [ ( mod + i ) % n ] ) << " ▁ " ; cout << " STRNEWLINE " ; }
int main ( ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 2 ;
leftRotate ( arr , n , k ) ; k = 3 ;
leftRotate ( arr , n , k ) ; k = 4 ;
leftRotate ( arr , n , k ) ; return 0 ; }
int findElement ( int arr [ ] , int ranges [ ] [ 2 ] , int rotations , int index ) { for ( int i = rotations - 1 ; i >= 0 ; i -- ) {
int left = ranges [ i ] [ 0 ] ; int right = ranges [ i ] [ 1 ] ;
if ( left <= index && right >= index ) { if ( index == left ) index = right ; else index -- ; } }
return arr [ index ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ;
int rotations = 2 ;
int ranges [ rotations ] [ 2 ] = { { 0 , 2 } , { 0 , 3 } } ; int index = 1 ; cout << findElement ( arr , ranges , rotations , index ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void splitArr ( int arr [ ] , int n , int k ) { for ( int i = 0 ; i < k ; i ++ ) {
int x = arr [ 0 ] ; for ( int j = 0 ; j < n - 1 ; ++ j ) arr [ j ] = arr [ j + 1 ] ; arr [ n - 1 ] = x ; } }
int main ( ) { int arr [ ] = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int position = 2 ; splitArr ( arr , 6 , position ) ; for ( int i = 0 ; i < n ; ++ i ) printf ( " % d ▁ " , arr [ i ] ) ; return 0 ; }
void splitArr ( int arr [ ] , int length , int rotation ) {
int tmp [ length * 2 ] = { 0 } ;
for ( int i = 0 ; i < length ; i ++ ) { tmp [ i ] = arr [ i ] ; tmp [ i + length ] = arr [ i ] ; } for ( int i = rotation ; i < rotation + length ; i ++ ) { arr [ i - rotation ] = tmp [ i ] ; } }
int main ( ) { int arr [ ] = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int position = 2 ; splitArr ( arr , n , position ) ; for ( int i = 0 ; i < n ; ++ i ) printf ( " % d ▁ " , arr [ i ] ) ; return 0 ; }
void fixArray ( int ar [ ] , int n ) { int i , j , temp ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) {
if ( ar [ j ] == i ) { temp = ar [ j ] ; ar [ j ] = ar [ i ] ; ar [ i ] = temp ; break ; } } }
for ( i = 0 ; i < n ; i ++ ) {
if ( ar [ i ] != i ) { ar [ i ] = -1 ; } }
cout << " Array ▁ after ▁ Rearranging " << endl ; for ( i = 0 ; i < n ; i ++ ) { cout << ar [ i ] << " ▁ " ; } }
int main ( ) { int n , ar [ ] = { -1 , -1 , 6 , 1 , 9 , 3 , 2 , -1 , 4 , -1 } ; n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ;
fixArray ( ar , n ) ; }
void rearrangeArr ( int arr [ ] , int n ) {
int evenPos = n / 2 ;
int oddPos = n - evenPos ; int tempArr [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) tempArr [ i ] = arr [ i ] ;
sort ( tempArr , tempArr + n ) ; int j = oddPos - 1 ;
for ( int i = 0 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j -- ; } j = oddPos ;
for ( int i = 1 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j ++ ; }
for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; rearrangeArr ( arr , size ) ; return 0 ; }
void pushZerosToEnd ( int arr [ ] , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
int main ( ) { int arr [ ] = { 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; pushZerosToEnd ( arr , n ) ; cout << " Array ▁ after ▁ pushing ▁ all ▁ zeros ▁ to ▁ end ▁ of ▁ array ▁ : STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void moveZerosToEnd ( int arr [ ] , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 ) swap ( arr [ count ++ ] , arr [ i ] ) ; }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 0 , 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Original ▁ array : ▁ " ; printArray ( arr , n ) ; moveZerosToEnd ( arr , n ) ; cout << " Modified array : " printArray ( arr , n ) ; return 0 ; }
#include <iostream> NEW_LINE void printArray ( int array [ ] , int length ) { std :: cout << " [ " ; for ( int i = 0 ; i < length ; i ++ ) { std :: cout << array [ i ] ; if ( i < ( length - 1 ) ) std :: cout << " , ▁ " ; else std :: cout << " ] " << std :: endl ; } } void reverse ( int array [ ] , int start , int end ) { while ( start < end ) { int temp = array [ start ] ; array [ start ] = array [ end ] ; array [ end ] = temp ; start ++ ; end -- ; } }
void rearrange ( int array [ ] , int start , int end ) {
if ( start == end ) return ;
rearrange ( array , ( start + 1 ) , end ) ;
if ( array [ start ] >= 0 ) { reverse ( array , ( start + 1 ) , end ) ; reverse ( array , start , end ) ; } }
int main ( ) { int array [ ] = { -12 , -11 , -13 , -5 , -6 , 7 , 5 , 3 , 6 } ; int length = ( sizeof ( array ) / sizeof ( array [ 0 ] ) ) ; int countNegative = 0 ; for ( int i = 0 ; i < length ; i ++ ) { if ( array [ i ] < 0 ) countNegative ++ ; } std :: cout << " array : ▁ " ; printArray ( array , length ) ; rearrange ( array , 0 , ( length - 1 ) ) ; reverse ( array , countNegative , ( length - 1 ) ) ; std :: cout << " rearranged ▁ array : ▁ " ; printArray ( array , length ) ; return 0 ; }
void pushZerosToEnd ( int arr [ ] , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
void modifyAndRearrangeArr ( int arr [ ] , int n ) {
if ( n == 1 ) return ;
for ( int i = 0 ; i < n - 1 ; i ++ ) {
if ( ( arr [ i ] != 0 ) && ( arr [ i ] == arr [ i + 1 ] ) ) {
arr [ i ] = 2 * arr [ i ] ;
arr [ i + 1 ] = 0 ;
i ++ ; } }
pushZerosToEnd ( arr , n ) ; }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 0 , 2 , 2 , 2 , 0 , 6 , 6 , 0 , 0 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Original ▁ array : ▁ " ; printArray ( arr , n ) ; modifyAndRearrangeArr ( arr , n ) ; cout << " Modified array : " printArray ( arr , n ) ; return 0 ; }
void swap ( int & a , int & b ) { a = b + a - ( b = a ) ; }
void shiftAllZeroToLeft ( int array [ ] , int n ) {
int lastSeenNonZero = 0 ; for ( index = 0 ; index < n ; index ++ ) {
if ( array [ index ] != 0 ) {
swap ( array [ index ] , array [ lastSeenNonZero ] ) ;
lastSeenNonZero ++ ; } } }
void reorder ( int arr [ ] , int index [ ] , int n ) { int temp [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) temp [ index [ i ] ] = arr [ i ] ;
for ( int i = 0 ; i < n ; i ++ ) { arr [ i ] = temp [ i ] ; index [ i ] = i ; } }
int main ( ) { int arr [ ] = { 50 , 40 , 70 , 60 , 90 } ; int index [ ] = { 3 , 0 , 4 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; reorder ( arr , index , n ) ; cout << " Reordered ▁ array ▁ is : ▁ STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << " Modified Index array is : " for ( int i = 0 ; i < n ; i ++ ) cout << index [ i ] << " ▁ " ; return 0 ; }
void reorder ( int arr [ ] , int index [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) {
while ( index [ i ] != i ) {
int oldTargetI = index [ index [ i ] ] ; char oldTargetE = arr [ index [ i ] ] ;
arr [ index [ i ] ] = arr [ i ] ; index [ index [ i ] ] = index [ i ] ;
index [ i ] = oldTargetI ; arr [ i ] = oldTargetE ; } } }
int main ( ) { int arr [ ] = { 50 , 40 , 70 , 60 , 90 } ; int index [ ] = { 3 , 0 , 4 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; reorder ( arr , index , n ) ; cout << " Reordered ▁ array ▁ is : ▁ STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << " Modified Index array is : " for ( int i = 0 ; i < n ; i ++ ) cout << index [ i ] << " ▁ " ; return 0 ; }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; printf ( " STRNEWLINE " ) ; }
void RearrangePosNeg ( int arr [ ] , int n ) { int key , j ; for ( int i = 1 ; i < n ; i ++ ) { key = arr [ i ] ;
if ( key > 0 ) continue ;
j = i - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { arr [ j + 1 ] = arr [ j ] ; j = j - 1 ; }
arr [ j + 1 ] = key ; } }
int main ( ) { int arr [ ] = { -12 , 11 , -13 , -5 , 6 , -7 , 5 , -3 , -6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; RearrangePosNeg ( arr , n ) ; printArray ( arr , n ) ; return 0 ; }
struct Node { int key ; struct Node * left , * right ; } ;
bool isLeaf ( Node * node ) { if ( node == NULL ) return false ; if ( node -> left == NULL && node -> right == NULL ) return true ; return false ; }
int leftLeavesSum ( Node * root ) {
int res = 0 ;
if ( root != NULL ) {
if ( isLeaf ( root -> left ) ) res += root -> left -> key ;
else res += leftLeavesSum ( root -> left ) ;
res += leftLeavesSum ( root -> right ) ; }
return res ; }
int main ( ) { struct Node * root = newNode ( 20 ) ; root -> left = newNode ( 9 ) ; root -> right = newNode ( 49 ) ; root -> right -> left = newNode ( 23 ) ; root -> right -> right = newNode ( 52 ) ; root -> right -> right -> left = newNode ( 50 ) ; root -> left -> left = newNode ( 5 ) ; root -> left -> right = newNode ( 12 ) ; root -> left -> right -> right = newNode ( 12 ) ; cout << " Sum ▁ of ▁ left ▁ leaves ▁ is ▁ " << leftLeavesSum ( root ) ; return 0 ; }
void printArray ( int A [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) cout << A [ i ] << " ▁ " ; cout << endl ; }
void reverse ( int arr [ ] , int l , int r ) { if ( l < r ) { swap ( arr [ l ] , arr [ r ] ) ; reverse ( arr , ++ l , -- r ) ; } }
void merge ( int arr [ ] , int l , int m , int r ) {
int i = l ;
int j = m + 1 ; while ( i <= m && arr [ i ] < 0 ) i ++ ;
while ( j <= r && arr [ j ] < 0 ) j ++ ;
reverse ( arr , i , m ) ;
reverse ( arr , m + 1 , j - 1 ) ;
reverse ( arr , i , j - 1 ) ; }
void RearrangePosNeg ( int arr [ ] , int l , int r ) { if ( l < r ) {
int m = l + ( r - l ) / 2 ;
RearrangePosNeg ( arr , l , m ) ; RearrangePosNeg ( arr , m + 1 , r ) ; merge ( arr , l , m , r ) ; } }
int main ( ) { int arr [ ] = { -12 , 11 , -13 , -5 , 6 , -7 , 5 , -3 , -6 } ; int arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; RearrangePosNeg ( arr , 0 , arr_size - 1 ) ; printArray ( arr , arr_size ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; void RearrangePosNeg ( int arr [ ] , int n ) { int i = 0 ; int j = n - 1 ; while ( true ) {
while ( arr [ i ] < 0 && i < n ) i ++ ;
while ( arr [ j ] > 0 && j >= 0 ) j -- ;
if ( i < j ) { int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } else break ; } }
int main ( ) { int arr [ ] = { -12 , 11 , -13 , -5 , 6 , -7 , 5 , -3 , -6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; RearrangePosNeg ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void rearrangeNaive ( int arr [ ] , int n ) {
int temp [ n ] , i ;
for ( i = 0 ; i < n ; i ++ ) temp [ arr [ i ] ] = i ;
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
void printArray ( int arr [ ] , int n ) { int i ; for ( i = 0 ; i < n ; i ++ ) cout << ( " % d ▁ " , arr [ i ] ) ; cout << ( " STRNEWLINE " ) ; }
int main ( ) { int arr [ ] = { 1 , 3 , 0 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << ( " Given ▁ array ▁ is ▁ STRNEWLINE " ) ; printArray ( arr , n ) ; rearrangeNaive ( arr , n ) ; cout << ( " Modified ▁ array ▁ is ▁ STRNEWLINE " ) ; printArray ( arr , n ) ; return 0 ; }
void rearrange ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) {
arr [ arr [ i ] % n ] += i * n ; } for ( int i = 0 ; i < n ; i ++ ) {
arr [ i ] /= n ; } }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << endl ; }
int main ( ) { int arr [ ] = { 2 , 0 , 1 , 4 , 5 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Given ▁ array ▁ is ▁ : ▁ " << endl ; printArray ( arr , n ) ; rearrange ( arr , n ) ; cout << " Modified ▁ array ▁ is ▁ : " << endl ; printArray ( arr , n ) ; return 0 ; }
void rearrange ( int arr [ ] , int n ) {
int temp [ n ] ;
int small = 0 , large = n - 1 ;
int flag = true ;
for ( int i = 0 ; i < n ; i ++ ) { if ( flag ) temp [ i ] = arr [ large -- ] ; else temp [ i ] = arr [ small ++ ] ; flag = ! flag ; }
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Original ▁ Array STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; rearrange ( arr , n ) ; cout << " Modified Array " for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void rearrange ( int arr [ ] , int n ) {
int max_idx = n - 1 , min_idx = 0 ;
int max_elem = arr [ n - 1 ] + 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] += ( arr [ max_idx ] % max_elem ) * max_elem ; max_idx -- ; }
else { arr [ i ] += ( arr [ min_idx ] % max_elem ) * max_elem ; min_idx ++ ; } }
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = arr [ i ] / max_elem ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Original ▁ Arrayn " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; rearrange ( arr , n ) ; cout << " Modified Array " for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void rearrange ( int arr [ ] , int n ) {
int max_ele = arr [ n - 1 ] ; int min_ele = arr [ 0 ] ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] = max_ele ; max_ele -= 1 ; }
else { arr [ i ] = min_ele ; min_ele += 1 ; } } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Original ▁ Array STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; rearrange ( arr , n ) ; cout << " Modified Array " for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
struct Node { int key ; struct Node * left , * right ; } ;
void leftLeavesSumRec ( Node * root , bool isleft , int * sum ) { if ( ! root ) return ;
if ( ! root -> left && ! root -> right && isleft ) * sum += root -> key ;
leftLeavesSumRec ( root -> left , 1 , sum ) ; leftLeavesSumRec ( root -> right , 0 , sum ) ; }
int leftLeavesSum ( Node * root ) { int sum = 0 ;
leftLeavesSumRec ( root , 0 , & sum ) ; return sum ; }
int sum = 0 ; struct Node * root = newNode ( 20 ) ; root -> left = newNode ( 9 ) ; root -> right = newNode ( 49 ) ; root -> right -> left = newNode ( 23 ) ; root -> right -> right = newNode ( 52 ) ; root -> right -> right -> left = newNode ( 50 ) ; root -> left -> left = newNode ( 5 ) ; root -> left -> right = newNode ( 12 ) ; root -> left -> right -> right = newNode ( 12 ) ; cout << " Sum ▁ of ▁ left ▁ leaves ▁ is ▁ " << leftLeavesSum ( root ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void rearrange ( int arr [ ] , int n ) { int j = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < 0 ) { if ( i != j ) swap ( arr [ i ] , arr [ j ] ) ; j ++ ; } } }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; }
int main ( ) { int arr [ ] = { -1 , 2 , -3 , 4 , 5 , 6 , -7 , 8 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; rearrange ( arr , n ) ; printArray ( arr , n ) ; return 0 ; }
void segregateElements ( int arr [ ] , int n ) {
int temp [ n ] ;
int j = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] >= 0 ) temp [ j ++ ] = arr [ i ] ;
if ( j == n j == 0 ) return ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < 0 ) temp [ j ++ ] = arr [ i ] ;
memcpy ( arr , temp , sizeof ( temp ) ) ; }
int main ( ) { int arr [ ] = { 1 , -1 , -3 , -2 , 7 , 5 , 11 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; segregateElements ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void rearrange ( int * arr , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( i % 2 == 0 && arr [ i ] > arr [ i + 1 ] ) swap ( arr [ i ] , arr [ i + 1 ] ) ; if ( i % 2 != 0 && arr [ i ] < arr [ i + 1 ] ) swap ( arr [ i ] , arr [ i + 1 ] ) ; } }
void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << endl ; }
int main ( ) { int arr [ ] = { 6 , 4 , 2 , 1 , 8 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Before ▁ rearranging : ▁ STRNEWLINE " ; printArray ( arr , n ) ; rearrange ( arr , n ) ; cout << " After ▁ rearranging : ▁ STRNEWLINE " ; printArray ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void rearrange ( int a [ ] , int size ) { int positive = 0 , negative = 1 ; while ( true ) {
while ( positive < size && a [ positive ] >= 0 ) positive += 2 ;
while ( negative < size && a [ negative ] <= 0 ) negative += 2 ;
if ( positive < size && negative < size ) swap ( a [ positive ] , a [ negative ] ) ;
else break ; } }
int main ( ) { int arr [ ] = { 1 , -3 , 5 , 6 , -3 , 6 , 7 , -4 , 9 , 10 } ; int n = ( sizeof ( arr ) / sizeof ( arr [ 0 ] ) ) ; rearrange ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void swap ( int * a , int i , int j ) { int temp = a [ i ] ; a [ i ] = a [ j ] ; a [ j ] = temp ; return ; }
void printArray ( int * a , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << a [ i ] << " ▁ " ; cout << endl ; return ; }
int main ( ) { int arr [ ] = { 1 , -3 , 5 , 6 , -3 , 6 , 7 , -4 , 9 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
printArray ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] >= 0 && i % 2 == 1 ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < 0 && j % 2 == 0 ) {
swap ( arr , i , j ) ; break ; } } } else if ( arr [ i ] < 0 && i % 2 == 0 ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] >= 0 && j % 2 == 1 ) {
swap ( arr , i , j ) ; break ; } } } }
printArray ( arr , n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; void arrayEvenAndOdd ( int arr [ ] , int n ) { int a [ n ] , ind = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] % 2 == 0 ) { a [ ind ] = arr [ i ] ; ind ++ ; } } for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] % 2 != 0 ) { a [ ind ] = arr [ i ] ; ind ++ ; } } for ( int i = 0 ; i < n ; i ++ ) { cout << a [ i ] << " ▁ " ; } cout << endl ; }
int main ( ) { int arr [ ] = { 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 } ; int n = sizeof ( arr ) / sizeof ( int ) ;
arrayEvenAndOdd ( arr , n ) ; return 0 ; }
void arrayEvenAndOdd ( int arr [ ] , int n ) { int i = -1 , j = 0 ; int t ; while ( j != n ) { if ( arr [ j ] % 2 == 0 ) { i ++ ;
swap ( arr [ i ] , arr [ j ] ) ; } j ++ ; }
for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 } ; int n = sizeof ( arr ) / sizeof ( int ) ; arrayEvenAndOdd ( arr , n ) ; return 0 ; }
struct Node { int data ; struct Node * left , * right ; Node ( int data ) { this -> data = data ; left = right = NULL ; } } ;
void printPostorder ( struct Node * node ) { if ( node == NULL ) return ;
printPostorder ( node -> left ) ;
printPostorder ( node -> right ) ;
cout << node -> data << " ▁ " ; }
void printInorder ( struct Node * node ) { if ( node == NULL ) return ;
printInorder ( node -> left ) ;
cout << node -> data << " ▁ " ;
printInorder ( node -> right ) ; }
void printPreorder ( struct Node * node ) { if ( node == NULL ) return ;
cout << node -> data << " ▁ " ;
printPreorder ( node -> left ) ;
printPreorder ( node -> right ) ; }
int main ( ) { struct Node * root = new Node ( 1 ) ; root -> left = new Node ( 2 ) ; root -> right = new Node ( 3 ) ; root -> left -> left = new Node ( 4 ) ; root -> left -> right = new Node ( 5 ) ; cout << " Preorder traversal of binary tree is " ; printPreorder ( root ) ; cout << " Inorder traversal of binary tree is " ; printInorder ( root ) ; cout << " Postorder traversal of binary tree is " ; printPostorder ( root ) ; return 0 ; }
int largest ( int arr [ ] , int n ) { int i ;
int max = arr [ 0 ] ;
for ( i = 1 ; i < n ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
int main ( ) { int arr [ ] = { 10 , 324 , 45 , 90 , 9808 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Largest ▁ in ▁ given ▁ array ▁ is ▁ " << largest ( arr , n ) ; return 0 ; }
int largest ( int arr [ ] , int n ) { return * max_element ( arr , arr + n ) ; }
int main ( ) { int arr [ ] = { 10 , 324 , 45 , 90 , 9808 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << largest ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void find3largest ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int check = 0 , count = 1 ; for ( int i = 1 ; i <= n ; i ++ ) { if ( count < 4 ) { if ( check != arr [ n - i ] ) {
cout << arr [ n - i ] << " ▁ " ; check = arr [ n - i ] ; count ++ ; } } else break ; } }
int main ( ) { int arr [ ] = { 12 , 45 , 1 , -1 , 45 , 54 , 23 , 5 , 0 , -10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; find3largest ( arr , n ) ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void findElements ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) if ( arr [ j ] > arr [ i ] ) count ++ ; if ( count >= 2 ) cout << arr [ i ] << " ▁ " ; } }
int main ( ) { int arr [ ] = { 2 , -6 , 3 , 5 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findElements ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void findElements ( int arr [ ] , int n ) { sort ( arr , arr + n ) ; for ( int i = 0 ; i < n - 2 ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 2 , -6 , 3 , 5 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findElements ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void findElements ( int arr [ ] , int n ) { int first = INT_MIN , second = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) second = arr [ i ] ; } for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < second ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 2 , -6 , 3 , 5 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findElements ( arr , n ) ; return 0 ; }
double findMean ( int a [ ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += a [ i ] ; return ( double ) sum / ( double ) n ; }
double findMedian ( int a [ ] , int n ) {
sort ( a , a + n ) ;
if ( n % 2 != 0 ) return ( double ) a [ n / 2 ] ; return ( double ) ( a [ ( n - 1 ) / 2 ] + a [ n / 2 ] ) / 2.0 ; }
int main ( ) { int a [ ] = { 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
cout << " Mean ▁ = ▁ " << findMean ( a , n ) << endl ; cout << " Median ▁ = ▁ " << findMedian ( a , n ) << endl ; return 0 ; }
void printSmall ( int arr [ ] , int n , int k ) {
for ( int i = k ; i < n ; ++ i ) {
int max_var = arr [ k - 1 ] ; int pos = k - 1 ; for ( int j = k - 2 ; j >= 0 ; j -- ) { if ( arr [ j ] > max_var ) { max_var = arr [ j ] ; pos = j ; } }
if ( max_var > arr [ i ] ) { int j = pos ; while ( j < k - 1 ) { arr [ j ] = arr [ j + 1 ] ; j ++ ; }
arr [ k - 1 ] = arr [ i ] ; } }
for ( int i = 0 ; i < k ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 5 ; printSmall ( arr , n , k ) ; return 0 ; }
void kSmallestPair ( int arr1 [ ] , int n1 , int arr2 [ ] , int n2 , int k ) { if ( k > n1 * n2 ) { cout << " k ▁ pairs ▁ don ' t ▁ exist " ; return ; }
int index2 [ n1 ] ; memset ( index2 , 0 , sizeof ( index2 ) ) ; while ( k > 0 ) {
int min_sum = INT_MAX ; int min_index = 0 ;
for ( int i1 = 0 ; i1 < n1 ; i1 ++ ) {
if ( index2 [ i1 ] < n2 && arr1 [ i1 ] + arr2 [ index2 [ i1 ] ] < min_sum ) {
min_index = i1 ;
min_sum = arr1 [ i1 ] + arr2 [ index2 [ i1 ] ] ; } } cout << " ( " << arr1 [ min_index ] << " , ▁ " << arr2 [ index2 [ min_index ] ] << " ) ▁ " ; index2 [ min_index ] ++ ; k -- ; } }
int main ( ) { int arr1 [ ] = { 1 , 3 , 11 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int arr2 [ ] = { 2 , 4 , 8 } ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; int k = 4 ; kSmallestPair ( arr1 , n1 , arr2 , n2 , k ) ; return 0 ; }
void print2largest ( int arr [ ] , int arr_size ) { int i , first , second ;
if ( arr_size < 2 ) { printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
sort ( arr , arr + arr_size ) ;
for ( i = arr_size - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] != arr [ arr_size - 1 ] ) { printf ( " The ▁ second ▁ largest ▁ element ▁ is ▁ % d STRNEWLINE " , arr [ i ] ) ; return ; } } printf ( " There ▁ is ▁ no ▁ second ▁ largest ▁ element STRNEWLINE " ) ; }
int main ( ) { int arr [ ] = { 12 , 35 , 1 , 10 , 34 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; print2largest ( arr , n ) ; return 0 ; }
int sumNodes ( int l ) {
int leafNodeCount = pow ( 2 , l - 1 ) ;
vector < int > vec [ l ] ;
for ( int i = 1 ; i <= leafNodeCount ; i ++ ) vec [ l - 1 ] . push_back ( i ) ;
for ( int i = l - 2 ; i >= 0 ; i -- ) { int k = 0 ;
while ( k < vec [ i + 1 ] . size ( ) - 1 ) {
vec [ i ] . push_back ( vec [ i + 1 ] [ k ] + vec [ i + 1 ] [ k + 1 ] ) ; k += 2 ; } } int sum = 0 ;
for ( int i = 0 ; i < l ; i ++ ) { for ( int j = 0 ; j < vec [ i ] . size ( ) ; j ++ ) sum += vec [ i ] [ j ] ; } return sum ; }
int main ( ) { int l = 3 ; cout << sumNodes ( l ) ; return 0 ; }
void print2largest ( int arr [ ] , int arr_size ) { int i , first , second ;
if ( arr_size < 2 ) { printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; } int largest = second = INT_MIN ;
for ( int i = 0 ; i < arr_size ; i ++ ) { largest = max ( largest , arr [ i ] ) ; }
for ( int i = 0 ; i < arr_size ; i ++ ) { if ( arr [ i ] != largest ) second = max ( second , arr [ i ] ) ; } if ( second == INT_MIN ) printf ( " There ▁ is ▁ no ▁ second ▁ largest ▁ element STRNEWLINE " ) ; else printf ( " The ▁ second ▁ largest ▁ element ▁ is ▁ % d STRNEWLINE " , second ) ; }
int main ( ) { int arr [ ] = { 12 , 35 , 1 , 10 , 34 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; print2largest ( arr , n ) ; return 0 ; }
int findSmallestMissinginSortedArray ( vector < int > arr ) {
if ( arr [ 0 ] != 0 ) return 0 ;
if ( arr [ arr . size ( ) - 1 ] == arr . size ( ) - 1 ) return arr . size ( ) ; int first = arr [ 0 ] ; return findFirstMissing ( arr , 0 , arr . size ( ) - 1 , first ) ; }
int findFirstMissing ( vector < int > arr , int start , int end , int first ) { if ( start < end ) { int mid = ( start + end ) / 2 ;
if ( arr [ mid ] != mid + first ) return findFirstMissing ( arr , start , mid , first ) ; else return findFirstMissing ( arr , mid + 1 , end , first ) ; } return start + first ; }
int main ( ) { vector < int > arr = { 0 , 1 , 2 , 3 , 4 , 5 , 7 } ; int n = arr . size ( ) ;
cout << " First ▁ Missing ▁ element ▁ is ▁ : ▁ " << findSmallestMissinginSortedArray ( arr ) ; }
int sumNodes ( int l ) {
int leafNodeCount = pow ( 2 , l - 1 ) ; int sumLastLevel = 0 ;
sumLastLevel = ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ;
int sum = sumLastLevel * l ; return sum ; }
int main ( ) { int l = 3 ; cout << sumNodes ( l ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  500
int lookup [ MAX ] [ MAX ] ;
void buildSparseTable ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) lookup [ i ] [ 0 ] = arr [ i ] ;
for ( int j = 1 ; ( 1 << j ) <= n ; j ++ ) {
for ( int i = 0 ; ( i + ( 1 << j ) - 1 ) < n ; i ++ ) {
if ( lookup [ i ] [ j - 1 ] < lookup [ i + ( 1 << ( j - 1 ) ) ] [ j - 1 ] ) lookup [ i ] [ j ] = lookup [ i ] [ j - 1 ] ; else lookup [ i ] [ j ] = lookup [ i + ( 1 << ( j - 1 ) ) ] [ j - 1 ] ; } } }
int query ( int L , int R ) {
int j = ( int ) log2 ( R - L + 1 ) ;
if ( lookup [ L ] [ j ] <= lookup [ R - ( 1 << j ) + 1 ] [ j ] ) return lookup [ L ] [ j ] ; else return lookup [ R - ( 1 << j ) + 1 ] [ j ] ; }
int main ( ) { int a [ ] = { 7 , 2 , 3 , 0 , 5 , 10 , 3 , 12 , 18 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; buildSparseTable ( a , n ) ; cout << query ( 0 , 4 ) << endl ; cout << query ( 4 , 7 ) << endl ; cout << query ( 7 , 8 ) << endl ; return 0 ; }
void add ( int arr [ ] , int N , int lo , int hi , int val ) { arr [ lo ] += val ; if ( hi != N - 1 ) arr [ hi + 1 ] -= val ; }
void updateArray ( int arr [ ] , int N ) {
for ( int i = 1 ; i < N ; i ++ ) arr [ i ] += arr [ i - 1 ] ; }
void printArr ( int arr [ ] , int N ) { updateArray ( arr , N ) ; for ( int i = 0 ; i < N ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << endl ; }
int main ( ) { int N = 6 ; int arr [ N ] = { 0 } ;
add ( arr , N , 0 , 2 , 100 ) ; add ( arr , N , 1 , 5 , 100 ) ; add ( arr , N , 2 , 3 , 100 ) ; printArr ( arr , N ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  1000
int tree [ 4 * MAX ] ;
int arr [ MAX ] ;
int gcd ( int a , int b ) { if ( a == 0 ) return b ; return gcd ( b % a , a ) ; }
int lcm ( int a , int b ) { return a * b / gcd ( a , b ) ; }
void build ( int node , int start , int end ) {
if ( start == end ) { tree [ node ] = arr [ start ] ; return ; } int mid = ( start + end ) / 2 ;
build ( 2 * node , start , mid ) ; build ( 2 * node + 1 , mid + 1 , end ) ;
int left_lcm = tree [ 2 * node ] ; int right_lcm = tree [ 2 * node + 1 ] ; tree [ node ] = lcm ( left_lcm , right_lcm ) ; }
int query ( int node , int start , int end , int l , int r ) {
if ( end < l start > r ) return 1 ;
if ( l <= start && r >= end ) return tree [ node ] ;
int mid = ( start + end ) / 2 ; int left_lcm = query ( 2 * node , start , mid , l , r ) ; int right_lcm = query ( 2 * node + 1 , mid + 1 , end , l , r ) ; return lcm ( left_lcm , right_lcm ) ; }
arr [ 0 ] = 5 ; arr [ 1 ] = 7 ; arr [ 2 ] = 5 ; arr [ 3 ] = 2 ; arr [ 4 ] = 10 ; arr [ 5 ] = 12 ; arr [ 6 ] = 11 ; arr [ 7 ] = 17 ; arr [ 8 ] = 14 ; arr [ 9 ] = 1 ; arr [ 10 ] = 44 ;
build ( 1 , 0 , 10 ) ;
cout << query ( 1 , 0 , 10 , 2 , 5 ) << endl ;
cout << query ( 1 , 0 , 10 , 5 , 10 ) << endl ;
cout << query ( 1 , 0 , 10 , 0 , 10 ) << endl ; return 0 ; }
void FillPrefixSuffix ( int prefix [ ] , int arr [ ] , int suffix [ ] , int n ) {
prefix [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) prefix [ i ] = __gcd ( prefix [ i - 1 ] , arr [ i ] ) ;
suffix [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) suffix [ i ] = __gcd ( suffix [ i + 1 ] , arr [ i ] ) ; }
int GCDoutsideRange ( int l , int r , int prefix [ ] , int suffix [ ] , int n ) {
if ( l == 0 ) return suffix [ r + 1 ] ;
if ( r == n - 1 ) return prefix [ l - 1 ] ; return __gcd ( prefix [ l - 1 ] , suffix [ r + 1 ] ) ; }
int main ( ) { int arr [ ] = { 2 , 6 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int prefix [ n ] , suffix [ n ] ; FillPrefixSuffix ( prefix , arr , suffix , n ) ; int l = 0 , r = 0 ; cout << GCDoutsideRange ( l , r , prefix , suffix , n ) << endl ; l = 1 ; r = 1 ; cout << GCDoutsideRange ( l , r , prefix , suffix , n ) << endl ; l = 1 ; r = 2 ; cout << GCDoutsideRange ( l , r , prefix , suffix , n ) << endl ; return 0 ; }
int countInRange ( int arr [ ] , int n , int x , int y ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] >= x && arr [ i ] <= y ) count ++ ; } return count ; }
int main ( ) { int arr [ ] = { 1 , 3 , 4 , 9 , 10 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
int i = 1 , j = 4 ; cout << countInRange ( arr , n , i , j ) << endl ; i = 9 , j = 12 ; cout << countInRange ( arr , n , i , j ) << endl ; return 0 ; }
int lowerIndex ( int arr [ ] , int n , int x ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] >= x ) h = mid - 1 ; else l = mid + 1 ; } return l ; }
int upperIndex ( int arr [ ] , int n , int y ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] <= y ) l = mid + 1 ; else h = mid - 1 ; } return h ; }
int countInRange ( int arr [ ] , int n , int x , int y ) {
int count = 0 ; count = upperIndex ( arr , n , y ) - lowerIndex ( arr , n , x ) + 1 ; return count ; }
int main ( ) { int arr [ ] = { 1 , 4 , 4 , 9 , 10 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
sort ( arr , arr + n ) ;
int i = 1 , j = 4 ; cout << countInRange ( arr , n , i , j ) << endl ; i = 9 , j = 12 ; cout << countInRange ( arr , n , i , j ) << endl ; return 0 ; }
void precompute ( int arr [ ] , int n , int pre [ ] ) { memset ( pre , 0 , n * sizeof ( int ) ) ; pre [ n - 1 ] = arr [ n - 1 ] * pow ( 2 , 0 ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) pre [ i ] = pre [ i + 1 ] + arr [ i ] * ( 1 << ( n - 1 - i ) ) ; }
int decimalOfSubarr ( int arr [ ] , int l , int r , int n , int pre [ ] ) {
if ( r != n - 1 ) return ( pre [ l ] - pre [ r + 1 ] ) / ( 1 << ( n - 1 - r ) ) ; return pre [ l ] / ( 1 << ( n - 1 - r ) ) ; }
int main ( ) { int arr [ ] = { 1 , 0 , 1 , 0 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int pre [ n ] ; precompute ( arr , n , pre ) ; cout << decimalOfSubarr ( arr , 2 , 4 , n , pre ) << endl ; cout << decimalOfSubarr ( arr , 4 , 5 , n , pre ) << endl ; return 0 ; }
int answerQuery ( int a [ ] , int n , int l , int r ) {
int count = 0 ;
l = l - 1 ;
for ( int i = l ; i < r ; i ++ ) { int element = a [ i ] ; int divisors = 0 ;
for ( int j = l ; j < r ; j ++ ) {
if ( a [ j ] % a [ i ] == 0 ) divisors ++ ; else break ; }
if ( divisors == ( r - l ) ) count ++ ; }
return count ; }
int main ( ) { int a [ ] = { 1 , 2 , 3 , 5 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int l = 1 , r = 4 ; cout << answerQuery ( a , n , l , r ) << endl ; l = 2 , r = 4 ; cout << answerQuery ( a , n , l , r ) << endl ; return 0 ; }
struct Node { int data ; Node * left , * right ; } ;
map < int , int > grid ;
void addConsideringGrid ( Node * root , int level , int index ) {
if ( root == NULL ) return ;
grid [ level - index ] += ( root -> data ) ;
addConsideringGrid ( root -> left , level + 1 , index - 1 ) ;
addConsideringGrid ( root -> right , level + 1 , index + 1 ) ; } vector < int > diagonalSum ( Node * root ) { grid . clear ( ) ;
addConsideringGrid ( root , 0 , 0 ) ; vector < int > ans ;
for ( auto x : grid ) { ans . push_back ( x . second ) ; } return ans ; }
struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 9 ) ; root -> left -> right = newNode ( 6 ) ; root -> right -> left = newNode ( 4 ) ; root -> right -> right = newNode ( 5 ) ; root -> right -> left -> right = newNode ( 7 ) ; root -> right -> left -> left = newNode ( 12 ) ; root -> left -> right -> left = newNode ( 11 ) ; root -> left -> left -> right = newNode ( 10 ) ;
vector < int > v = diagonalSum ( root ) ;
for ( int i = 0 ; i < v . size ( ) ; i ++ ) cout << v [ i ] << " ▁ " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  2147483647 NEW_LINE int one [ 100001 ] [ 32 ] ;
void make_prefix ( int A [ ] , int n ) { for ( int j = 0 ; j < 32 ; j ++ ) one [ 0 ] [ j ] = 0 ;
for ( int i = 1 ; i <= n ; i ++ ) { int a = A [ i - 1 ] ; for ( int j = 0 ; j < 32 ; j ++ ) { int x = pow ( 2 , j ) ;
if ( a & x ) one [ i ] [ j ] = 1 + one [ i - 1 ] [ j ] ; else one [ i ] [ j ] = one [ i - 1 ] [ j ] ; } } }
int Solve ( int L , int R ) { int l = L , r = R ; int tot_bits = r - l + 1 ;
int X = MAX ;
for ( int i = 0 ; i < 31 ; i ++ ) {
int x = one [ r ] [ i ] - one [ l - 1 ] [ i ] ;
if ( x >= tot_bits - x ) { int ith_bit = pow ( 2 , i ) ;
X = X ^ ith_bit ; } } return X ; }
int main ( ) { int n = 5 , q = 3 ; int A [ ] = { 210 , 11 , 48 , 22 , 133 } ; int L [ ] = { 1 , 4 , 2 } , R [ ] = { 3 , 14 , 4 } ; make_prefix ( A , n ) ; for ( int j = 0 ; j < q ; j ++ ) cout << Solve ( L [ j ] , R [ j ] ) << endl ; return 0 ; }
void type1 ( int arr [ ] , int start , int limit ) {
for ( int i = start ; i <= limit ; i ++ ) arr [ i ] ++ ; }
void type2 ( int arr [ ] , int query [ ] [ 3 ] , int start , int limit ) { for ( int i = start ; i <= limit ; i ++ ) {
if ( query [ i ] [ 0 ] == 1 ) type1 ( arr , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ;
else if ( query [ i ] [ 0 ] == 2 ) type2 ( arr , query , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ; } }
int n = 5 , m = 5 ; int arr [ n + 1 ] ; for ( int i = 1 ; i <= n ; i ++ ) arr [ i ] = 0 ;
int temp [ 15 ] = { 1 , 1 , 2 , 1 , 4 , 5 , 2 , 1 , 2 , 2 , 1 , 3 , 2 , 3 , 4 } ; int query [ 5 ] [ 3 ] ; int j = 0 ; for ( int i = 1 ; i <= m ; i ++ ) { query [ i ] [ 0 ] = temp [ j ++ ] ; query [ i ] [ 1 ] = temp [ j ++ ] ; query [ i ] [ 2 ] = temp [ j ++ ] ; }
for ( int i = 1 ; i <= m ; i ++ ) if ( query [ i ] [ 0 ] == 1 ) type1 ( arr , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ; else if ( query [ i ] [ 0 ] == 2 ) type2 ( arr , query , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ;
for ( int i = 1 ; i <= n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void record_sum ( int record [ ] , int l , int r , int n , int adder ) { for ( int i = l ; i <= r ; i ++ ) record [ i ] += adder ; }
int main ( ) { int n = 5 , m = 5 ; int arr [ n ] ;
memset ( arr , 0 , sizeof arr ) ; int query [ 5 ] [ 3 ] = { { 1 , 1 , 2 } , { 1 , 4 , 5 } , { 2 , 1 , 2 } , { 2 , 1 , 3 } , { 2 , 3 , 4 } } ; int record [ m ] ; memset ( record , 0 , sizeof record ) ; for ( int i = m - 1 ; i >= 0 ; i -- ) {
if ( query [ i ] [ 0 ] == 2 ) record_sum ( record , query [ i ] [ 1 ] - 1 , query [ i ] [ 2 ] - 1 , m , record [ i ] + 1 ) ;
else record_sum ( record , i , i , m , 1 ) ; }
for ( int i = 0 ; i < m ; i ++ ) { if ( query [ i ] [ 0 ] == 1 ) record_sum ( arr , query [ i ] [ 1 ] - 1 , query [ i ] [ 2 ] - 1 , n , record [ i ] ) ; }
for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << ' ▁ ' ; return 0 ; }
int solveQuery ( int start , int end , int arr [ ] ) {
unordered_map < int , int > frequency ;
for ( int i = start ; i <= end ; i ++ ) frequency [ arr [ i ] ] ++ ;
int count = 0 ; for ( auto x : frequency ) if ( x . first == x . second ) count ++ ; return count ; }
int main ( ) { int A [ ] = { 1 , 2 , 2 , 3 , 3 , 3 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ;
int queries [ ] [ 3 ] = { { 0 , 1 } , { 1 , 1 } , { 0 , 2 } , { 1 , 3 } , { 3 , 5 } , { 0 , 5 } } ;
int q = sizeof ( queries ) / sizeof ( queries [ 0 ] ) ; for ( int i = 0 ; i < q ; i ++ ) { int start = queries [ i ] [ 0 ] ; int end = queries [ i ] [ 1 ] ; cout << " Answer ▁ for ▁ Query ▁ " << ( i + 1 ) << " ▁ = ▁ " << solveQuery ( start , end , A ) << endl ; } return 0 ; }
int answer_query ( int a [ ] , int n , int l , int r ) {
int count = 0 ; for ( int i = l ; i < r ; i ++ ) if ( a [ i ] == a [ i + 1 ] ) count += 1 ; return count ; }
int main ( ) { int a [ ] = { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
int L , R ; L = 1 ; R = 8 ; cout << answer_query ( a , n , L , R ) << endl ;
L = 0 ; R = 4 ; cout << answer_query ( a , n , L , R ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int N = 1000 ;
int prefixans [ N ] ;
int countIndex ( int a [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] == a [ i + 1 ] ) prefixans [ i ] = 1 ; if ( i != 0 ) prefixans [ i ] += prefixans [ i - 1 ] ; } }
int answer_query ( int l , int r ) { if ( l == 0 ) return prefixans [ r - 1 ] ; else return prefixans [ r - 1 ] - prefixans [ l - 1 ] ; }
int main ( ) { int a [ ] = { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
countIndex ( a , n ) ; int L , R ;
L = 1 ; R = 8 ; cout << answer_query ( L , R ) << endl ;
L = 0 ; R = 4 ; cout << answer_query ( L , R ) << endl ; return 0 ; }
vector < int > initializeDiffArray ( vector < int > & A ) { int n = A . size ( ) ;
vector < int > D ( n + 1 ) ; D [ 0 ] = A [ 0 ] , D [ n ] = 0 ; for ( int i = 1 ; i < n ; i ++ ) D [ i ] = A [ i ] - A [ i - 1 ] ; return D ; }
void update ( vector < int > & D , int l , int r , int x ) { D [ l ] += x ; D [ r + 1 ] -= x ; }
int printArray ( vector < int > & A , vector < int > & D ) { for ( int i = 0 ; i < A . size ( ) ; i ++ ) { if ( i == 0 ) A [ i ] = D [ i ] ;
else A [ i ] = D [ i ] + A [ i - 1 ] ; cout << A [ i ] << " ▁ " ; } cout << endl ; }
vector < int > A { 10 , 5 , 20 , 40 } ;
vector < int > D = initializeDiffArray ( A ) ;
update ( D , 0 , 1 , 10 ) ; printArray ( A , D ) ;
update ( D , 1 , 3 , 20 ) ; update ( D , 2 , 2 , 30 ) ; printArray ( A , D ) ; return 0 ; }
#include <iostream> NEW_LINE #include <climits> NEW_LINE using namespace std ; int maxSubArraySum ( int a [ ] , int size ) { int max_so_far = INT_MIN , max_ending_here = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here = max_ending_here + a [ i ] ; if ( max_so_far < max_ending_here ) max_so_far = max_ending_here ; if ( max_ending_here < 0 ) max_ending_here = 0 ; } return max_so_far ; }
int main ( ) { int a [ ] = { -2 , -3 , 4 , -1 , -2 , 1 , 5 , -3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int max_sum = maxSubArraySum ( a , n ) ; cout << " Maximum ▁ contiguous ▁ sum ▁ is ▁ " << max_sum ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; int maxSubArraySum ( int a [ ] , int size ) { int max_so_far = a [ 0 ] ; int curr_max = a [ 0 ] ; for ( int i = 1 ; i < size ; i ++ ) { curr_max = max ( a [ i ] , curr_max + a [ i ] ) ; max_so_far = max ( max_so_far , curr_max ) ; } return max_so_far ; }
int main ( ) { int a [ ] = { -2 , -3 , 4 , -1 , -2 , 1 , 5 , -3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int max_sum = maxSubArraySum ( a , n ) ; cout << " Maximum ▁ contiguous ▁ sum ▁ is ▁ " << max_sum ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; int main ( ) { int price [ ] = { 2 , 30 , 15 , 10 , 8 , 25 , 80 } ; int n = 7 ;
int profit = 0 ;
for ( int i = 1 ; i < n ; i ++ ) {
int sub = price [ i ] - price [ i - 1 ] ; if ( sub > 0 ) profit += sub ; } cout << " Maximum ▁ Profit = " << profit ; return 0 ; }
void findMinAvgSubarray ( int arr [ ] , int n , int k ) {
if ( n < k ) return ;
int res_index = 0 ;
int curr_sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) curr_sum += arr [ i ] ;
int min_sum = curr_sum ;
for ( int i = k ; i < n ; i ++ ) {
curr_sum += arr [ i ] - arr [ i - k ] ;
if ( curr_sum < min_sum ) { min_sum = curr_sum ; res_index = ( i - k + 1 ) ; } } cout << " Subarray ▁ between ▁ [ " << res_index << " , ▁ " << res_index + k - 1 << " ] ▁ has ▁ minimum ▁ average " ; }
int main ( ) { int arr [ ] = { 3 , 7 , 90 , 20 , 10 , 50 , 40 } ;
int k = 3 ; int n = sizeof arr / sizeof arr [ 0 ] ; findMinAvgSubarray ( arr , n , k ) ; return 0 ; }
int minJumps ( int arr [ ] , int n ) {
int * jumps = new int [ n ] ; int min ;
jumps [ n - 1 ] = 0 ;
for ( int i = n - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] == 0 ) jumps [ i ] = INT_MAX ;
else if ( arr [ i ] >= n - i - 1 ) jumps [ i ] = 1 ;
else {
min = INT_MAX ;
for ( int j = i + 1 ; j < n && j <= arr [ i ] + i ; j ++ ) { if ( min > jumps [ j ] ) min = jumps [ j ] ; }
if ( min != INT_MAX ) jumps [ i ] = min + 1 ; else
jumps [ i ] = min ; } } return jumps [ 0 ] ; }
int main ( ) { int arr [ ] = { 1 , 3 , 6 , 1 , 0 , 9 } ; int size = sizeof ( arr ) / sizeof ( int ) ; cout << " Minimum ▁ number ▁ of ▁ jumps ▁ to ▁ reach " << " ▁ end ▁ is ▁ " << minJumps ( arr , size ) ; return 0 ; }
int smallestSubWithSum ( int arr [ ] , int n , int x ) {
int curr_sum = 0 , min_len = n + 1 ;
int start = 0 , end = 0 ; while ( end < n ) {
while ( curr_sum <= x && end < n ) curr_sum += arr [ end ++ ] ;
while ( curr_sum > x && start < n ) {
if ( end - start < min_len ) min_len = end - start ;
curr_sum -= arr [ start ++ ] ; } } return min_len ; }
int main ( ) { int arr1 [ ] = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; ( res1 == n1 + 1 ) ? cout << " Not ▁ possible STRNEWLINE " : cout << res1 << endl ; int arr2 [ ] = { 1 , 10 , 5 , 2 , 7 } ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; ( res2 == n2 + 1 ) ? cout << " Not ▁ possible STRNEWLINE " : cout << res2 << endl ; int arr3 [ ] = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = sizeof ( arr3 ) / sizeof ( arr3 [ 0 ] ) ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; ( res3 == n3 + 1 ) ? cout << " Not ▁ possible STRNEWLINE " : cout << res3 << endl ; return 0 ; }
int findMaxAverage ( int arr [ ] , int n , int k ) {
if ( k > n ) return -1 ;
int * csum = new int [ n ] ; csum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) csum [ i ] = csum [ i - 1 ] + arr [ i ] ;
int max_sum = csum [ k - 1 ] , max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { int curr_sum = csum [ i ] - csum [ i - k ] ; if ( curr_sum > max_sum ) { max_sum = curr_sum ; max_end = i ; } }
return max_end - k + 1 ; }
int main ( ) { int arr [ ] = { 1 , 12 , -5 , -6 , 50 , 3 } ; int k = 4 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ " " length ▁ " << k << " ▁ begins ▁ at ▁ index ▁ " << findMaxAverage ( arr , n , k ) ; return 0 ; }
int findMaxAverage ( int arr [ ] , int n , int k ) {
if ( k > n ) return -1 ;
int sum = arr [ 0 ] ; for ( int i = 1 ; i < k ; i ++ ) sum += arr [ i ] ; int max_sum = sum , max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { int sum = sum + arr [ i ] - arr [ i - k ] ; if ( sum > max_sum ) { max_sum = sum ; max_end = i ; } }
return max_end - k + 1 ; }
int main ( ) { int arr [ ] = { 1 , 12 , -5 , -6 , 50 , 3 } ; int k = 4 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ " " length ▁ " << k << " ▁ begins ▁ at ▁ index ▁ " << findMaxAverage ( arr , n , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
int countMinOperations ( unsigned int target [ ] , int n ) {
int result = 0 ;
while ( 1 ) {
int zero_count = 0 ;
int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( target [ i ] & 1 ) break ;
else if ( target [ i ] == 0 ) zero_count ++ ; }
if ( zero_count == n ) return result ;
if ( i == n ) {
for ( int j = 0 ; j < n ; j ++ ) target [ j ] = target [ j ] / 2 ; result ++ ; }
for ( int j = i ; j < n ; j ++ ) { if ( target [ j ] & 1 ) { target [ j ] -- ; result ++ ; } } } }
int main ( ) { unsigned int arr [ ] = { 16 , 16 , 16 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ number ▁ of ▁ steps ▁ required ▁ to ▁ " " get ▁ the ▁ given ▁ target ▁ array ▁ is ▁ " << countMinOperations ( arr , n ) ; return 0 ; }
int findMinOps ( int arr [ ] , int n ) {
int ans = 0 ;
for ( int i = 0 , j = n - 1 ; i <= j ; ) {
if ( arr [ i ] == arr [ j ] ) { i ++ ; j -- ; }
else if ( arr [ i ] > arr [ j ] ) {
j -- ; arr [ j ] += arr [ j + 1 ] ; ans ++ ; }
else { i ++ ; arr [ i ] += arr [ i - 1 ] ; ans ++ ; } } return ans ; }
int main ( ) { int arr [ ] = { 1 , 4 , 5 , 9 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ minimum ▁ operations ▁ is ▁ " << findMinOps ( arr , n ) << endl ; return 0 ; }
int findSmallest ( int arr [ ] , int n ) {
int res = 1 ;
for ( int i = 0 ; i < n && arr [ i ] <= res ; i ++ ) res = res + arr [ i ] ; return res ; }
int main ( ) { int arr1 [ ] = { 1 , 3 , 4 , 5 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << findSmallest ( arr1 , n1 ) << endl ; int arr2 [ ] = { 1 , 2 , 6 , 10 , 11 , 15 } ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; cout << findSmallest ( arr2 , n2 ) << endl ; int arr3 [ ] = { 1 , 1 , 1 , 1 } ; int n3 = sizeof ( arr3 ) / sizeof ( arr3 [ 0 ] ) ; cout << findSmallest ( arr3 , n3 ) << endl ; int arr4 [ ] = { 1 , 1 , 3 , 4 } ; int n4 = sizeof ( arr4 ) / sizeof ( arr4 [ 0 ] ) ; cout << findSmallest ( arr4 , n4 ) << endl ; return 0 ; }
int maxSubArraySum ( int a [ ] , int size ) { int max_so_far = INT_MIN , max_ending_here = 0 , start = 0 , end = 0 , s = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here += a [ i ] ; if ( max_so_far < max_ending_here ) { max_so_far = max_ending_here ; start = s ; end = i ; } if ( max_ending_here < 0 ) { max_ending_here = 0 ; s = i + 1 ; } } return ( end - start + 1 ) ; }
int main ( ) { int a [ ] = { -2 , -3 , 4 , -1 , -2 , 1 , 5 , -3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << maxSubArraySum ( a , n ) ; return 0 ; }
int findMinDiff ( int arr [ ] , int n ) {
int diff = INT_MAX ;
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( abs ( arr [ i ] - arr [ j ] ) < diff ) diff = abs ( arr [ i ] - arr [ j ] ) ;
return diff ; }
int main ( ) { int arr [ ] = { 1 , 5 , 3 , 19 , 18 , 25 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ difference ▁ is ▁ " << findMinDiff ( arr , n ) ; return 0 ; }
int findMinDiff ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int diff = INT_MAX ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i + 1 ] - arr [ i ] < diff ) diff = arr [ i + 1 ] - arr [ i ] ;
return diff ; }
int main ( ) { int arr [ ] = { 1 , 5 , 3 , 19 , 18 , 25 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ difference ▁ is ▁ " << findMinDiff ( arr , n ) ; return 0 ; }
int main ( ) { int a = 2 , b = 10 ; int size = abs ( b - a ) + 1 ; int * array = new int [ size ] ;
for ( int i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) array [ i - a ] = 1 ; cout << " MULTIPLES ▁ of ▁ 2 ▁ and ▁ 5 : STRNEWLINE " ; for ( int i = a ; i <= b ; i ++ ) if ( array [ i - a ] == 1 ) cout << i << " ▁ " ; return 0 ; }
bool checkbit ( int array [ ] , int index ) { return array [ index >> 5 ] & ( 1 << ( index & 31 ) ) ; }
void setbit ( int array [ ] , int index ) { array [ index >> 5 ] |= ( 1 << ( index & 31 ) ) ; }
int main ( ) { int a = 2 , b = 10 ; int size = abs ( b - a ) ;
size = ceil ( size / 32 ) ;
int * array = new int [ size ] ;
for ( int i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) setbit ( array , i - a ) ; cout << " MULTIPLES ▁ of ▁ 2 ▁ and ▁ 5 : STRNEWLINE " ; for ( int i = a ; i <= b ; i ++ ) if ( checkbit ( array , i - a ) ) cout << i << " ▁ " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
int longestCommonSum ( bool arr1 [ ] , bool arr2 [ ] , int n ) {
int maxLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int sum1 = 0 , sum2 = 0 ;
for ( int j = i ; j < n ; j ++ ) {
sum1 += arr1 [ j ] ; sum2 += arr2 [ j ] ;
if ( sum1 == sum2 ) { int len = j - i + 1 ; if ( len > maxLen ) maxLen = len ; } } } return maxLen ; }
int main ( ) { bool arr1 [ ] = { 0 , 1 , 0 , 1 , 1 , 1 , 1 } ; bool arr2 [ ] = { 1 , 1 , 1 , 1 , 1 , 0 , 1 } ; int n = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << " Length ▁ of ▁ the ▁ longest ▁ common ▁ span ▁ with ▁ same ▁ " " sum ▁ is ▁ " << longestCommonSum ( arr1 , arr2 , n ) ; return 0 ; }
void swap ( int * x , int * y ) { int temp = * x ; * x = * y ; * y = temp ; }
void sortInWave ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
for ( int i = 0 ; i < n - 1 ; i += 2 ) swap ( & arr [ i ] , & arr [ i + 1 ] ) ; }
int main ( ) { int arr [ ] = { 10 , 90 , 49 , 2 , 1 , 5 , 23 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; sortInWave ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void swap ( int * x , int * y ) { int temp = * x ; * x = * y ; * y = temp ; }
void sortInWave ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i += 2 ) {
if ( i > 0 && arr [ i - 1 ] > arr [ i ] ) swap ( & arr [ i ] , & arr [ i - 1 ] ) ;
if ( i < n - 1 && arr [ i ] < arr [ i + 1 ] ) swap ( & arr [ i ] , & arr [ i + 1 ] ) ; } }
int main ( ) { int arr [ ] = { 10 , 90 , 49 , 2 , 1 , 5 , 23 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; sortInWave ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
bool sortedAfterSwap ( int A [ ] , bool B [ ] , int n ) { int i , j ;
for ( i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] ) { j = i ; while ( B [ j ] ) j ++ ;
sort ( A + i , A + 1 + j ) ; i = j ; } }
for ( i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) return false ; } return true ; }
int main ( ) { int A [ ] = { 1 , 2 , 5 , 3 , 4 , 6 } ; bool B [ ] = { 0 , 1 , 1 , 1 , 0 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; if ( sortedAfterSwap ( A , B , n ) ) cout << " A ▁ can ▁ be ▁ sorted STRNEWLINE " ; else cout << " A ▁ can ▁ not ▁ be ▁ sorted STRNEWLINE " ; return 0 ; }
bool sortedAfterSwap ( int A [ ] , bool B [ ] , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] ) { if ( A [ i ] != i + 1 ) swap ( A [ i ] , A [ i + 1 ] ) ; } }
for ( int i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) return false ; } return true ; }
int main ( ) { int A [ ] = { 1 , 2 , 5 , 3 , 4 , 6 } ; bool B [ ] = { 0 , 1 , 1 , 1 , 0 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; if ( sortedAfterSwap ( A , B , n ) ) cout << " A ▁ can ▁ be ▁ sorted STRNEWLINE " ; else cout << " A ▁ can ▁ not ▁ be ▁ sorted STRNEWLINE " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
void segregate0and1 ( int arr [ ] , int n ) { int type0 = 0 ; int type1 = n - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { swap ( arr [ type0 ] , arr [ type1 ] ) ; type1 -- ; } else { type0 ++ ; } } }
int main ( ) { int arr [ ] = { 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; segregate0and1 ( arr , n ) ; for ( int a : arr ) cout << a << " ▁ " ; }
void findMinSum ( int arr [ ] , int n ) { sort ( arr , arr + n , compare ) ; int min = INT_MAX , x , y ; for ( int i = 1 ; i < n ; i ++ ) {
if ( abs ( arr [ i - 1 ] + arr [ i ] ) <= min ) {
min = abs ( arr [ i - 1 ] + arr [ i ] ) ; x = i - 1 ; y = i ; } } cout << " The ▁ two ▁ elements ▁ whose ▁ sum ▁ is ▁ minimum ▁ are ▁ " << arr [ x ] << " ▁ and ▁ " << arr [ y ] ; }
int main ( ) { int arr [ ] = { 1 , 60 , -10 , 70 , -80 , 85 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findMinSum ( arr , n ) ; return 0 ; }
bool increasing ( int a [ ] , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( a [ i ] >= a [ i + 1 ] ) return false ; return true ; }
bool decreasing ( int a [ ] , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( a [ i ] < a [ i + 1 ] ) return false ; return true ; } int shortestUnsorted ( int a [ ] , int n ) {
if ( increasing ( a , n ) == true || decreasing ( a , n ) == true ) return 0 ; else return 3 ; }
int main ( ) { int ar [ ] = { 7 , 9 , 10 , 8 , 11 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; cout << shortestUnsorted ( ar , n ) ; return 0 ; }
void swap ( vector < int > & arr , int i , int j ) { int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; }
int indexOf ( vector < int > & arr , int ele ) { for ( int i = 0 ; i < arr . size ( ) ; i ++ ) { if ( arr [ i ] == ele ) { return i ; } } return -1 ; }
int minSwaps ( vector < int > arr , int N ) { int ans = 0 ; vector < int > temp ( arr . begin ( ) , arr . end ( ) ) ; sort ( temp . begin ( ) , temp . end ( ) ) ; for ( int i = 0 ; i < N ; i ++ ) {
if ( arr [ i ] != temp [ i ] ) { ans ++ ;
swap ( arr , i , indexOf ( arr , temp [ i ] ) ) ; } } return ans ; }
int main ( ) { vector < int > a = { 101 , 758 , 315 , 730 , 472 , 619 , 460 , 479 } ; int n = a . size ( ) ;
cout << minSwaps ( a , n ) ; }
void printUnion ( int arr1 [ ] , int arr2 [ ] , int m , int n ) {
if ( m > n ) { int * tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
sort ( arr1 , arr1 + m ) ; for ( int i = 0 ; i < m ; i ++ ) cout << arr1 [ i ] << " ▁ " ;
for ( int i = 0 ; i < n ; i ++ ) if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) == -1 ) cout << arr2 [ i ] << " ▁ " ; }
void printIntersection ( int arr1 [ ] , int arr2 [ ] , int m , int n ) {
if ( m > n ) { int * tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
sort ( arr1 , arr1 + m ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) != -1 ) cout << arr2 [ i ] << " ▁ " ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return -1 ; }
int main ( ) { int arr1 [ ] = { 7 , 1 , 5 , 2 , 3 , 6 } ; int arr2 [ ] = { 3 , 8 , 6 , 20 , 7 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ;
cout << " Union ▁ of ▁ two ▁ arrays ▁ is ▁ n " ; printUnion ( arr1 , arr2 , m , n ) ; cout << " nIntersection ▁ of ▁ two ▁ arrays ▁ is ▁ n " ; printIntersection ( arr1 , arr2 , m , n ) ; return 0 ; }
void intersection ( int a [ ] , int b [ ] , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) { if ( a [ i ] > b [ j ] ) { j ++ ; } else if ( b [ j ] > a [ i ] ) { i ++ ; } else {
cout << a [ i ] << " ▁ " ; i ++ ; j ++ ; } } }
int main ( ) { int a [ ] = { 1 , 3 , 2 , 3 , 3 , 4 , 5 , 5 , 6 } ; int b [ ] = { 3 , 3 , 5 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int m = sizeof ( b ) / sizeof ( b [ 0 ] ) ;
sort ( a , a + n ) ; sort ( b , b + m ) ;
intersection ( a , b , n , m ) ; }
void printArr ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
void sortArr ( int arr [ ] , int n ) { int i , cnt0 = 0 , cnt1 = 0 , cnt2 = 0 ;
for ( i = 0 ; i < n ; i ++ ) { switch ( arr [ i ] ) { case 0 : cnt0 ++ ; break ; case 1 : cnt1 ++ ; break ; case 2 : cnt2 ++ ; break ; } }
i = 0 ;
while ( cnt0 > 0 ) { arr [ i ++ ] = 0 ; cnt0 -- ; }
while ( cnt1 > 0 ) { arr [ i ++ ] = 1 ; cnt1 -- ; }
while ( cnt2 > 0 ) { arr [ i ++ ] = 2 ; cnt2 -- ; }
printArr ( arr , n ) ; }
int main ( ) { int arr [ ] = { 0 , 1 , 1 , 0 , 1 , 2 , 1 , 2 , 0 , 0 , 0 , 1 } ; int n = sizeof ( arr ) / sizeof ( int ) ; sortArr ( arr , n ) ; return 0 ; }
int findNumberOfTriangles ( int arr [ ] , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
for ( int k = j + 1 ; k < n ; k ++ )
if ( arr [ i ] + arr [ j ] > arr [ k ] && arr [ i ] + arr [ k ] > arr [ j ] && arr [ k ] + arr [ j ] > arr [ i ] ) count ++ ; } } return count ; }
int main ( ) { int arr [ ] = { 10 , 21 , 22 , 100 , 101 , 200 , 300 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Total ▁ number ▁ of ▁ triangles ▁ possible ▁ is ▁ " << findNumberOfTriangles ( arr , size ) ; return 0 ; }
void CountTriangles ( vector < int > A ) { int n = A . size ( ) ; sort ( A . begin ( ) , A . end ( ) ) ; int count = 0 ; for ( int i = n - 1 ; i >= 1 ; i -- ) { int l = 0 , r = i - 1 ; while ( l < r ) { if ( A [ l ] + A [ r ] > A [ i ] ) {
count += r - l ;
r -- ; }
else l ++ ; } } cout << " No ▁ of ▁ possible ▁ solutions : ▁ " << count ; }
int main ( ) { vector < int > A = { 4 , 3 , 5 , 7 , 6 } ; CountTriangles ( A ) ; }
#include <bits/stdc++.h> NEW_LINE long long countPairsBruteForce ( long long X [ ] , long long Y [ ] , long long m , long long n ) { long long ans = 0 ; for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( pow ( X [ i ] , Y [ j ] ) > pow ( Y [ j ] , X [ i ] ) ) ans ++ ; return ans ; }
#include <iostream> NEW_LINE using namespace std ; int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] - arr [ j ] == k arr [ j ] - arr [ i ] == k ) count ++ ; } return count ; }
int main ( ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; cout << " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " << countPairsWithDiffK ( arr , n , k ) ; return 0 ; }
int binarySearch ( int arr [ ] , int low , int high , int x ) { if ( high >= low ) { int mid = low + ( high - low ) / 2 ; if ( x == arr [ mid ] ) return mid ; if ( x > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return -1 ; }
int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 , i ;
sort ( arr , arr + n ) ;
for ( i = 0 ; i < n - 1 ; i ++ ) if ( binarySearch ( arr , i + 1 , n - 1 , arr [ i ] + k ) != -1 ) count ++ ; return count ; }
int main ( ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; cout << " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " << countPairsWithDiffK ( arr , n , k ) ; return 0 ; }
int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 ;
sort ( arr , arr + n ) ; int l = 0 ; int r = 0 ; while ( r < n ) { if ( arr [ r ] - arr [ l ] == k ) { count ++ ; l ++ ; r ++ ; } else if ( arr [ r ] - arr [ l ] > k ) l ++ ;
else r ++ ; } return count ; }
int main ( ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; cout << " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " << countPairsWithDiffK ( arr , n , k ) ; return 0 ; }
struct Node { int data ; Node * left , * right ; Node ( int item ) { data = item ; } } ; int getSum ( Node * root ) ;
int getSumAlternate ( Node * root ) { if ( root == NULL ) return 0 ; int sum = root -> data ; if ( root -> left != NULL ) { sum += getSum ( root -> left -> left ) ; sum += getSum ( root -> left -> right ) ; } if ( root -> right != NULL ) { sum += getSum ( root -> right -> left ) ; sum += getSum ( root -> right -> right ) ; } return sum ; }
int getSum ( Node * root ) { if ( root == NULL ) return 0 ;
return max ( getSumAlternate ( root ) , ( getSumAlternate ( root -> left ) + getSumAlternate ( root -> right ) ) ) ; }
int main ( ) { Node * root = new Node ( 1 ) ; root -> left = new Node ( 2 ) ; root -> right = new Node ( 3 ) ; root -> right -> left = new Node ( 4 ) ; root -> right -> left -> right = new Node ( 5 ) ; root -> right -> left -> right -> left = new Node ( 6 ) ; cout << ( getSum ( root ) ) ; return 0 ; }
void constructArr ( int arr [ ] , int pair [ ] , int n ) { arr [ 0 ] = ( pair [ 0 ] + pair [ 1 ] - pair [ n - 1 ] ) / 2 ; for ( int i = 1 ; i < n ; i ++ ) arr [ i ] = pair [ i - 1 ] - arr [ 0 ] ; }
int main ( ) { int pair [ ] = { 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 } ; int n = 5 ; int arr [ n ] ; constructArr ( arr , pair , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void merge ( int ar1 [ ] , int ar2 [ ] , int m , int n ) {
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int j , last = ar1 [ m - 1 ] ; for ( j = m - 2 ; j >= 0 && ar1 [ j ] > ar2 [ i ] ; j -- ) ar1 [ j + 1 ] = ar1 [ j ] ;
if ( j != m - 2 last > ar2 [ i ] ) { ar1 [ j + 1 ] = ar2 [ i ] ; ar2 [ i ] = last ; } } }
int main ( ) { int ar1 [ ] = { 1 , 5 , 9 , 10 , 15 , 20 } ; int ar2 [ ] = { 2 , 3 , 8 , 13 } ; int m = sizeof ( ar1 ) / sizeof ( ar1 [ 0 ] ) ; int n = sizeof ( ar2 ) / sizeof ( ar2 [ 0 ] ) ; merge ( ar1 , ar2 , m , n ) ; cout << " After ▁ Merging ▁ nFirst ▁ Array : ▁ " ; for ( int i = 0 ; i < m ; i ++ ) cout << ar1 [ i ] << " ▁ " ; cout << " nSecond ▁ Array : ▁ " ; for ( int i = 0 ; i < n ; i ++ ) cout << ar2 [ i ] << " ▁ " ; return 0 ; }
int minMaxProduct ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) {
sort ( arr1 , arr1 + n1 ) ; sort ( arr2 , arr2 + n2 ) ;
return arr1 [ n1 - 1 ] * arr2 [ 0 ] ; }
int main ( ) { int arr1 [ ] = { 10 , 2 , 3 , 6 , 4 , 1 } ; int arr2 [ ] = { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n2 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << minMaxProduct ( arr1 , arr2 , n1 , n2 ) ; return 0 ; }
int minMaxProduct ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) {
int max = arr1 [ 0 ] ;
int min = arr2 [ 0 ] ; int i ; for ( i = 1 ; i < n1 && i < n2 ; ++ i ) {
if ( arr1 [ i ] > max ) max = arr1 [ i ] ;
if ( arr2 [ i ] < min ) min = arr2 [ i ] ; }
while ( i < n1 ) { if ( arr1 [ i ] > max ) max = arr1 [ i ] ; i ++ ; } while ( i < n2 ) { if ( arr2 [ i ] < min ) min = arr2 [ i ] ; i ++ ; } return max * min ; }
int main ( ) { int arr1 [ ] = { 10 , 2 , 3 , 6 , 4 , 1 } ; int arr2 [ ] = { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n2 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << minMaxProduct ( arr1 , arr2 , n1 , n2 ) << endl ; return 0 ; }
int insertSorted ( int arr [ ] , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; arr [ n ] = key ; return ( n + 1 ) ; }
int main ( ) { int arr [ 20 ] = { 12 , 16 , 20 , 40 , 50 , 70 } ; int capacity = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int n = 6 ; int i , key = 26 ; cout << " Before Insertion : " for ( i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ;
n = insertSorted ( arr , n , key , capacity ) ; cout << " After Insertion : " for ( i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
int findElement ( int arr [ ] , int n , int key ) { int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
int deleteElement ( int arr [ ] , int n , int key ) {
int pos = findElement ( arr , n , key ) ; if ( pos == - 1 ) { cout << " Element ▁ not ▁ found " ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
int main ( ) { int i ; int arr [ ] = { 10 , 50 , 30 , 40 , 20 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int key = 30 ; cout << " Array ▁ before ▁ deletion STRNEWLINE " ; for ( i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; n = deleteElement ( arr , n , key ) ; cout << " Array after deletion " ; for ( i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void findCommon ( int ar1 [ ] , int ar2 [ ] , int ar3 [ ] , int n1 , int n2 , int n3 ) {
int i = 0 , j = 0 , k = 0 ;
while ( i < n1 && j < n2 && k < n3 ) {
if ( ar1 [ i ] == ar2 [ j ] && ar2 [ j ] == ar3 [ k ] ) { cout << ar1 [ i ] << " ▁ " ; i ++ ; j ++ ; k ++ ; }
else if ( ar1 [ i ] < ar2 [ j ] ) i ++ ;
else if ( ar2 [ j ] < ar3 [ k ] ) j ++ ;
else k ++ ; } }
int main ( ) { int ar1 [ ] = { 1 , 5 , 10 , 20 , 40 , 80 } ; int ar2 [ ] = { 6 , 7 , 20 , 80 , 100 } ; int ar3 [ ] = { 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 } ; int n1 = sizeof ( ar1 ) / sizeof ( ar1 [ 0 ] ) ; int n2 = sizeof ( ar2 ) / sizeof ( ar2 [ 0 ] ) ; int n3 = sizeof ( ar3 ) / sizeof ( ar3 [ 0 ] ) ; cout << " Common ▁ Elements ▁ are ▁ " ; findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) ; return 0 ; }
void findCommon ( int ar1 [ ] , int ar2 [ ] , int ar3 [ ] , int n1 , int n2 , int n3 ) {
int i = 0 , j = 0 , k = 0 ;
int prev1 , prev2 , prev3 ;
prev1 = prev2 = prev3 = INT_MIN ;
while ( i < n1 && j < n2 && k < n3 ) {
while ( ar1 [ i ] == prev1 && i < n1 ) i ++ ;
while ( ar2 [ j ] == prev2 && j < n2 ) j ++ ;
while ( ar3 [ k ] == prev3 && k < n3 ) k ++ ;
if ( ar1 [ i ] == ar2 [ j ] && ar2 [ j ] == ar3 [ k ] ) { cout << ar1 [ i ] << " ▁ " ; prev1 = ar1 [ i ] ; prev2 = ar2 [ j ] ; prev3 = ar3 [ k ] ; i ++ ; j ++ ; k ++ ; }
else if ( ar1 [ i ] < ar2 [ j ] ) { prev1 = ar1 [ i ] ; i ++ ; }
else if ( ar2 [ j ] < ar3 [ k ] ) { prev2 = ar2 [ j ] ; j ++ ; }
else { prev3 = ar3 [ k ] ; k ++ ; } } }
int main ( ) { int ar1 [ ] = { 1 , 5 , 10 , 20 , 40 , 80 , 80 } ; int ar2 [ ] = { 6 , 7 , 20 , 80 , 80 , 100 } ; int ar3 [ ] = { 3 , 4 , 15 , 20 , 30 , 70 , 80 , 80 , 120 } ; int n1 = sizeof ( ar1 ) / sizeof ( ar1 [ 0 ] ) ; int n2 = sizeof ( ar2 ) / sizeof ( ar2 [ 0 ] ) ; int n3 = sizeof ( ar3 ) / sizeof ( ar3 [ 0 ] ) ; cout << " Common ▁ Elements ▁ are ▁ " ; findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) ; return 0 ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ; if ( arr [ mid ] == x ) return mid ; if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ; return binarySearch ( arr , mid + 1 , r , x ) ; } return -1 ; }
int findPos ( int arr [ ] , int key ) { int l = 0 , h = 1 ; int val = arr [ 0 ] ;
while ( val < key ) {
l = h ;
h = 2 * h ;
val = arr [ h ] ; }
return binarySearch ( arr , l , h , key ) ; }
int main ( ) { int arr [ ] = { 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 } ; int ans = findPos ( arr , 10 ) ; if ( ans == -1 ) cout << " Element ▁ not ▁ found " ; else cout << " Element ▁ found ▁ at ▁ index ▁ " << ans ; return 0 ; }
int findSingle ( int ar [ ] , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
int main ( ) { int ar [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; cout << " Element ▁ occurring ▁ once ▁ is ▁ " << findSingle ( ar , n ) ; return 0 ; }
int singleNumber ( int nums [ ] , int n ) { map < int , int > m ; long sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( m [ nums [ i ] ] == 0 ) { sum1 += nums [ i ] ; m [ nums [ i ] ] ++ ; } sum2 += nums [ i ] ; }
return 2 * ( sum1 ) - sum2 ; }
int main ( ) { int a [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = 7 ; cout << singleNumber ( a , n ) << " STRNEWLINE " ; int b [ ] = { 15 , 18 , 16 , 18 , 16 , 15 , 89 } ; cout << singleNumber ( b , n ) ; return 0 ; }
bool isPresent ( int B [ ] , int m , int x ) { for ( int i = 0 ; i < m ; i ++ ) if ( B [ i ] == x ) return true ; return false ; }
int findMaxSubarraySumUtil ( int A [ ] , int B [ ] , int n , int m ) {
int max_so_far = INT_MIN , curr_max = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( isPresent ( B , m , A [ i ] ) ) { curr_max = 0 ; continue ; }
curr_max = max ( A [ i ] , curr_max + A [ i ] ) ; max_so_far = max ( max_so_far , curr_max ) ; } return max_so_far ; }
void findMaxSubarraySum ( int A [ ] , int B [ ] , int n , int m ) { int maxSubarraySum = findMaxSubarraySumUtil ( A , B , n , m ) ;
if ( maxSubarraySum == INT_MIN ) { cout << " Maximum ▁ Subarray ▁ Sum ▁ cant ▁ be ▁ found " << endl ; } else { cout << " The ▁ Maximum ▁ Subarray ▁ Sum ▁ = ▁ " << maxSubarraySum << endl ; } }
int main ( ) { int A [ ] = { 3 , 4 , 5 , -4 , 6 } ; int B [ ] = { 1 , 8 , 5 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; int m = sizeof ( B ) / sizeof ( B [ 0 ] ) ;
findMaxSubarraySum ( A , B , n , m ) ; return 0 ; }
int findMaxSum ( int arr [ ] , int n ) { int res = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) { int prefix_sum = arr [ i ] ; for ( int j = 0 ; j < i ; j ++ ) prefix_sum += arr [ j ] ; int suffix_sum = arr [ i ] ; for ( int j = n - 1 ; j > i ; j -- ) suffix_sum += arr [ j ] ; if ( prefix_sum == suffix_sum ) res = max ( res , prefix_sum ) ; } return res ; }
int main ( ) { int arr [ ] = { -2 , 5 , 3 , 1 , 2 , 6 , -4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findMaxSum ( arr , n ) ; return 0 ; }
struct Node { int data ; struct Node * left ; struct Node * right ; } ;
int getHeight ( struct Node * Node ) { if ( Node == NULL ) return 0 ; else {
int lHeight = getHeight ( Node -> left ) ; int rHeight = getHeight ( Node -> right ) ;
if ( lHeight > rHeight ) return ( lHeight + 1 ) ; else return ( rHeight + 1 ) ; } }
int getTotalHeight ( struct Node * root ) { if ( root == NULL ) return 0 ; return getTotalHeight ( root -> left ) + getHeight ( root ) + getTotalHeight ( root -> right ) ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; printf ( " Sum ▁ of ▁ heights ▁ of ▁ all ▁ Nodes ▁ = ▁ % d " , getTotalHeight ( root ) ) ; return 0 ; }
int findMaxSum ( int arr [ ] , int n ) {
int preSum [ n ] ;
int suffSum [ n ] ;
int ans = INT_MIN ;
preSum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) preSum [ i ] = preSum [ i - 1 ] + arr [ i ] ;
suffSum [ n - 1 ] = arr [ n - 1 ] ; if ( preSum [ n - 1 ] == suffSum [ n - 1 ] ) ans = max ( ans , preSum [ n - 1 ] ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) { suffSum [ i ] = suffSum [ i + 1 ] + arr [ i ] ; if ( suffSum [ i ] == preSum [ i ] ) ans = max ( ans , preSum [ i ] ) ; } return ans ; }
int main ( ) { int arr [ ] = { -2 , 5 , 3 , 1 , 2 , 6 , -4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findMaxSum ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int equilibrium ( int a [ ] , int n ) { if ( n == 1 ) return ( 0 ) ; int forward [ n ] = { 0 } ; int rev [ n ] = { 0 } ;
for ( int i = 0 ; i < n ; i ++ ) { if ( i ) { forward [ i ] = forward [ i - 1 ] + a [ i ] ; } else { forward [ i ] = a [ i ] ; } }
for ( int i = n - 1 ; i > 0 ; i -- ) { if ( i <= n - 2 ) { rev [ i ] = rev [ i + 1 ] + a [ i ] ; } else { rev [ i ] = a [ i ] ; } }
for ( int i = 0 ; i < n ; i ++ ) { if ( forward [ i ] == rev [ i ] ) { return i ; } } return -1 ;
}
int main ( ) { int arr [ ] = { -7 , 1 , 5 , 2 , -4 , 3 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " First ▁ Point ▁ of ▁ equilibrium ▁ is ▁ at ▁ index ▁ " << equilibrium ( arr , n ) << " STRNEWLINE " ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; void printLeaders ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) { int j ; for ( j = i + 1 ; j < size ; j ++ ) { if ( arr [ i ] <= arr [ j ] ) break ; }
if ( j == size ) cout << arr [ i ] << " ▁ " ; } }
int main ( ) { int arr [ ] = { 16 , 17 , 4 , 3 , 5 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printLeaders ( arr , n ) ; return 0 ; }
void findMajority ( int arr [ ] , int n ) { int maxCount = 0 ;
int index = -1 ; for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; }
if ( count > maxCount ) { maxCount = count ; index = i ; } }
if ( maxCount > n / 2 ) cout << arr [ index ] << endl ; else cout << " No ▁ Majority ▁ Element " << endl ; }
int main ( ) { int arr [ ] = { 1 , 1 , 2 , 1 , 3 , 5 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
findMajority ( arr , n ) ; return 0 ; }
struct Node { int data ; struct Node * left ; struct Node * right ; } ;
int getTotalHeightUtil ( struct Node * root , int & sum ) { if ( root == NULL ) return 0 ; int lh = getTotalHeightUtil ( root -> left , sum ) ; int rh = getTotalHeightUtil ( root -> right , sum ) ; int h = max ( lh , rh ) + 1 ; sum = sum + h ; return h ; } int getTotalHeight ( Node * root ) { int sum = 0 ; getTotalHeightUtil ( root , sum ) ; return sum ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; printf ( " Sum ▁ of ▁ heights ▁ of ▁ all ▁ Nodes ▁ = ▁ % d " , getTotalHeight ( root ) ) ; return 0 ; }
int majorityElement ( int * arr , int n ) {
sort ( arr , arr + n ) ; int count = 1 , max_ele = -1 , temp = arr [ 0 ] , ele , f = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( temp == arr [ i ] ) { count ++ ; } else { count = 1 ; temp = arr [ i ] ; }
if ( max_ele < count ) { max_ele = count ; ele = arr [ i ] ; if ( max_ele > ( n / 2 ) ) { f = 1 ; break ; } } }
return ( f == 1 ? ele : -1 ) ; }
int main ( ) { int arr [ ] = { 1 , 1 , 2 , 1 , 3 , 5 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
cout << majorityElement ( arr , n ) ; return 0 ; }
int _binarySearch ( int arr [ ] , int low , int high , int x ) { if ( high >= low ) { int mid = ( low + high ) / 2 ;
if ( ( mid == 0 x > arr [ mid - 1 ] ) && ( arr [ mid ] == x ) ) return mid ; else if ( x > arr [ mid ] ) return _binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return _binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return -1 ; }
bool isMajority ( int arr [ ] , int n , int x ) {
int i = _binarySearch ( arr , 0 , n - 1 , x ) ;
if ( i == -1 ) return false ;
if ( ( ( i + n / 2 ) <= ( n - 1 ) ) && arr [ i + n / 2 ] == x ) return true ; else return false ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 3 ; if ( isMajority ( arr , n , x ) ) cout << x << " ▁ appears ▁ more ▁ than ▁ " << n / 2 << " ▁ times ▁ in ▁ arr [ ] " << endl ; else cout << x << " ▁ does ▁ not ▁ appear ▁ more ▁ than " << n / 2 << " ▁ times ▁ in ▁ arr [ ] " << endl ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; bool isMajorityElement ( int arr [ ] , int n , int key ) { if ( arr [ n / 2 ] == key ) return true ; else return false ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 3 ; if ( isMajorityElement ( arr , n , x ) ) cout << x << " ▁ appears ▁ more ▁ than ▁ " << n / 2 << " ▁ times ▁ in ▁ arr [ ] " << endl ; else cout << x << " ▁ does ▁ not ▁ appear ▁ more ▁ than " << n / 2 << " ▁ times ▁ in ▁ arr [ ] " << endl ; return 0 ; }
int isPairSum ( int A [ ] , int N , int X ) {
int i = 0 ;
int j = N - 1 ; while ( i < j ) {
if ( A [ i ] + A [ j ] == X ) return 1 ;
else if ( A [ i ] + A [ j ] < X ) i ++ ;
else j -- ; } return 0 ; }
int arr [ ] = { 3 , 5 , 9 , 2 , 8 , 10 , 11 } ;
int val = 17 ;
int arrSize = * ( & arr + 1 ) - arr ;
cout << ( bool ) isPairSum ( arr , arrSize , val ) ; return 0 ; }
int findPeak ( int arr [ ] , int n ) {
if ( n == 1 ) return 0 ; if ( arr [ 0 ] >= arr [ 1 ] ) return 0 ; if ( arr [ n - 1 ] >= arr [ n - 2 ] ) return n - 1 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
if ( arr [ i ] >= arr [ i - 1 ] && arr [ i ] >= arr [ i + 1 ] ) return i ; } }
int main ( ) { int arr [ ] = { 1 , 3 , 20 , 4 , 1 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Index ▁ of ▁ a ▁ peak ▁ point ▁ is ▁ " << findPeak ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int maxTripletSum ( int arr [ ] , int n ) {
int sum = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( sum < arr [ i ] + arr [ j ] + arr [ k ] ) sum = arr [ i ] + arr [ j ] + arr [ k ] ; return sum ; }
int main ( ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxTripletSum ( arr , n ) ; return 0 ; }
int maxTripletSum ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
return arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ; }
int main ( ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxTripletSum ( arr , n ) ; return 0 ; }
int maxTripletSum ( int arr [ ] , int n ) {
int maxA = INT_MIN , maxB = INT_MIN , maxC = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > maxA ) { maxC = maxB ; maxB = maxA ; maxA = arr [ i ] ; }
else if ( arr [ i ] > maxB ) { maxC = maxB ; maxB = arr [ i ] ; }
else if ( arr [ i ] > maxC ) maxC = arr [ i ] ; } return ( maxA + maxB + maxC ) ; }
int main ( ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxTripletSum ( arr , n ) ; return 0 ; }
int maximum ( int a , int b , int c ) { return max ( max ( a , b ) , c ) ; }
int minimum ( int a , int b , int c ) { return min ( min ( a , b ) , c ) ; }
void smallestDifferenceTriplet ( int arr1 [ ] , int arr2 [ ] , int arr3 [ ] , int n ) {
sort ( arr1 , arr1 + n ) ; sort ( arr2 , arr2 + n ) ; sort ( arr3 , arr3 + n ) ;
int res_min , res_max , res_mid ;
int i = 0 , j = 0 , k = 0 ;
int diff = INT_MAX ; while ( i < n && j < n && k < n ) { int sum = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
int max = maximum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ;
int min = minimum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ; if ( min == arr1 [ i ] ) i ++ ; else if ( min == arr2 [ j ] ) j ++ ; else k ++ ;
if ( diff > ( max - min ) ) { diff = max - min ; res_max = max ; res_mid = sum - ( max + min ) ; res_min = min ; } }
cout << res_max << " , ▁ " << res_mid << " , ▁ " << res_min ; }
int main ( ) { int arr1 [ ] = { 5 , 2 , 8 } ; int arr2 [ ] = { 10 , 7 , 12 } ; int arr3 [ ] = { 9 , 14 , 6 } ; int n = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) ; return 0 ; }
bool find3Numbers ( int A [ ] , int arr_size , int sum ) { int l , r ;
sort ( A , A + arr_size ) ;
for ( int i = 0 ; i < arr_size - 2 ; i ++ ) {
l = i + 1 ;
r = arr_size - 1 ; while ( l < r ) { if ( A [ i ] + A [ l ] + A [ r ] == sum ) { printf ( " Triplet ▁ is ▁ % d , ▁ % d , ▁ % d " , A [ i ] , A [ l ] , A [ r ] ) ; return true ; } else if ( A [ i ] + A [ l ] + A [ r ] < sum ) l ++ ;
else r -- ; } }
return false ; }
int main ( ) { int A [ ] = { 1 , 4 , 45 , 6 , 10 , 8 } ; int sum = 22 ; int arr_size = sizeof ( A ) / sizeof ( A [ 0 ] ) ; find3Numbers ( A , arr_size , sum ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define SIZE  10
void sortMat ( int mat [ SIZE ] [ SIZE ] , int n ) {
int temp [ n * n ] ; int k = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) temp [ k ++ ] = mat [ i ] [ j ] ;
sort ( temp , temp + k ) ;
k = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) mat [ i ] [ j ] = temp [ k ++ ] ; }
void printMat ( int mat [ SIZE ] [ SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << mat [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int mat [ SIZE ] [ SIZE ] = { { 5 , 4 , 7 } , { 1 , 3 , 8 } , { 2 , 9 , 6 } } ; int n = 3 ; cout << " Original ▁ Matrix : STRNEWLINE " ; printMat ( mat , n ) ; sortMat ( mat , n ) ; cout << " Matrix After Sorting : " ; printMat ( mat , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
void subArray ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i ; j < n ; j ++ ) {
for ( int k = i ; k <= j ; k ++ ) cout << arr [ k ] << " ▁ " ; cout << endl ; } } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " All ▁ Non - empty ▁ Subarrays STRNEWLINE " ; subArray ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void printSubsequences ( int arr [ ] , int n ) {
unsigned int opsize = pow ( 2 , n ) ;
for ( int counter = 1 ; counter < opsize ; counter ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( counter & ( 1 << j ) ) cout << arr [ j ] << " ▁ " ; } cout << endl ; } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " All ▁ Non - empty ▁ Subsequences STRNEWLINE " ; printSubsequences ( arr , n ) ; return 0 ; }
void productArray ( int arr [ ] , int n ) {
if ( n == 1 ) { cout << 0 ; return ; } int i , temp = 1 ;
int * prod = new int [ ( sizeof ( int ) * n ) ] ;
memset ( prod , 1 , n ) ;
for ( i = 0 ; i < n ; i ++ ) { prod [ i ] = temp ; temp *= arr [ i ] ; }
temp = 1 ;
for ( i = n - 1 ; i >= 0 ; i -- ) { prod [ i ] *= temp ; temp *= arr [ i ] ; }
for ( i = 0 ; i < n ; i ++ ) cout << prod [ i ] << " ▁ " ; return ; }
int main ( ) { int arr [ ] = { 10 , 3 , 5 , 6 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " The ▁ product ▁ array ▁ is : ▁ STRNEWLINE " ; productArray ( arr , n ) ; }
#include <iostream> NEW_LINE using namespace std ; long * productExceptSelf ( int a [ ] , int n ) { long prod = 1 ; long flag = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == 0 ) flag ++ ; else prod *= a [ i ] ; }
long * arr = new long [ n ] ; for ( int i = 0 ; i < n ; i ++ ) {
if ( flag > 1 ) { arr [ i ] = 0 ; }
else if ( flag == 0 ) arr [ i ] = ( prod / a [ i ] ) ;
else if ( flag == 1 && a [ i ] != 0 ) { arr [ i ] = 0 ; }
else arr [ i ] = prod ; } return arr ; }
int main ( ) { int n = 5 ; int array [ ] = { 10 , 3 , 5 , 6 , 2 } ; long * ans ; ans = productExceptSelf ( array , n ) ; for ( int i = 0 ; i < n ; i ++ ) { cout << ans [ i ] << " ▁ " ; } return 0 ; }
bool areConsecutive ( int arr [ ] , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) {
bool * visited = ( bool * ) calloc ( n , sizeof ( bool ) ) ; int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( visited [ arr [ i ] - min ] != false ) return false ;
visited [ arr [ i ] - min ] = true ; }
return true ; }
return false ; }
int getMin ( int arr [ ] , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] < min ) min = arr [ i ] ; return min ; } int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
int main ( ) { int arr [ ] = { 5 , 4 , 2 , 3 , 1 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( areConsecutive ( arr , n ) == true ) printf ( " ▁ Array ▁ elements ▁ are ▁ consecutive ▁ " ) ; else printf ( " ▁ Array ▁ elements ▁ are ▁ not ▁ consecutive ▁ " ) ; getchar ( ) ; return 0 ; }
bool areConsecutive ( int arr [ ] , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { int j ; if ( arr [ i ] < 0 ) j = - arr [ i ] - min ; else j = arr [ i ] - min ;
if ( arr [ j ] > 0 ) arr [ j ] = - arr [ j ] ; else return false ; }
return true ; }
return false ; }
int getMin ( int arr [ ] , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] < min ) min = arr [ i ] ; return min ; } int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
int main ( ) { int arr [ ] = { 1 , 4 , 5 , 3 , 2 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( areConsecutive ( arr , n ) == true ) printf ( " ▁ Array ▁ elements ▁ are ▁ consecutive ▁ " ) ; else printf ( " ▁ Array ▁ elements ▁ are ▁ not ▁ consecutive ▁ " ) ; getchar ( ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; void relativeComplement ( int arr1 [ ] , int arr2 [ ] , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) {
if ( arr1 [ i ] < arr2 [ j ] ) { cout << arr1 [ i ] << " ▁ " ; i ++ ;
} else if ( arr1 [ i ] > arr2 [ j ] ) { j ++ ;
} else if ( arr1 [ i ] == arr2 [ j ] ) { i ++ ; j ++ ; } }
while ( i < n ) cout << arr1 [ i ] << " ▁ " ; }
int main ( ) { int arr1 [ ] = { 3 , 6 , 10 , 12 , 15 } ; int arr2 [ ] = { 1 , 3 , 5 , 10 , 16 } ; int n = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int m = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; relativeComplement ( arr1 , arr2 , n , m ) ; return 0 ; }
int minOps ( int arr [ ] , int n , int k ) {
int max = * max_element ( arr , arr + n ) ; int res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ( max - arr [ i ] ) % k != 0 ) return -1 ;
else res += ( max - arr [ i ] ) / k ; }
return res ; }
int main ( ) { int arr [ ] = { 21 , 33 , 9 , 45 , 63 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 6 ; cout << minOps ( arr , n , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int solve ( int A [ ] , int B [ ] , int C [ ] , int i , int j , int k ) { int min_diff , current_diff , max_term ;
min_diff = Integer . MAX_VALUE ; while ( i != -1 && j != -1 && k != -1 ) { current_diff = abs ( max ( A [ i ] , max ( B [ j ] , C [ k ] ) ) - min ( A [ i ] , min ( B [ j ] , C [ k ] ) ) ) ;
if ( current_diff < min_diff ) min_diff = current_diff ;
max_term = max ( A [ i ] , max ( B [ j ] , C [ k ] ) ) ;
if ( A [ i ] == max_term ) i -= 1 ; else if ( B [ j ] == max_term ) j -= 1 ; else k -= 1 ; } return min_diff ; }
int main ( ) { int D [ ] = { 5 , 8 , 10 , 15 } ; int E [ ] = { 6 , 9 , 15 , 78 , 89 } ; int F [ ] = { 2 , 3 , 6 , 6 , 8 , 8 , 10 } ; int nD = sizeof ( D ) / sizeof ( D [ 0 ] ) ; int nE = sizeof ( E ) / sizeof ( E [ 0 ] ) ; int nF = sizeof ( F ) / sizeof ( F [ 0 ] ) ; cout << solve ( D , E , F , nD - 1 , nE - 1 , nF - 1 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void search ( vector < int > arr , int search_Element ) { int left = 0 ; int length = arr . size ( ) ; int position = -1 ; int right = length - 1 ;
for ( left = 0 ; left <= right ; ) {
if ( arr [ left ] == search_Element ) { position = left ; cout << " Element ▁ found ▁ in ▁ Array ▁ at ▁ " << position + 1 << " ▁ Position ▁ with ▁ " << left + 1 << " ▁ Attempt " ; break ; }
if ( arr [ right ] == search_Element ) { position = right ; cout << " Element ▁ found ▁ in ▁ Array ▁ at ▁ " << position + 1 << " ▁ Position ▁ with ▁ " << length - right << " ▁ Attempt " ; break ; } left ++ ; right -- ; }
if ( position == -1 ) cout << " Not ▁ found ▁ in ▁ Array ▁ with ▁ " << left << " ▁ Attempt " ; }
int main ( ) { vector < int > arr { 1 , 2 , 3 , 4 , 5 } ; int search_element = 5 ;
search ( arr , search_element ) ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int jumpSearch ( int arr [ ] , int x , int n ) {
int step = sqrt ( n ) ;
int prev = 0 ; while ( arr [ min ( step , n ) - 1 ] < x ) { prev = step ; step += sqrt ( n ) ; if ( prev >= n ) return -1 ; }
while ( arr [ prev ] < x ) { prev ++ ;
if ( prev == min ( step , n ) ) return -1 ; }
if ( arr [ prev ] == x ) return prev ; return -1 ; }
int main ( ) { int arr [ ] = { 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 } ; int x = 55 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
int index = jumpSearch ( arr , x , n ) ;
cout << " Number " ▁ < < ▁ x ▁ < < ▁ " is at index " return 0 ; }
int interpolationSearch ( int arr [ ] , int lo , int hi , int x ) { int pos ;
if ( lo <= hi && x >= arr [ lo ] && x <= arr [ hi ] ) {
pos = lo + ( ( ( double ) ( hi - lo ) / ( arr [ hi ] - arr [ lo ] ) ) * ( x - arr [ lo ] ) ) ;
if ( arr [ pos ] == x ) return pos ;
if ( arr [ pos ] < x ) return interpolationSearch ( arr , pos + 1 , hi , x ) ;
if ( arr [ pos ] > x ) return interpolationSearch ( arr , lo , pos - 1 , x ) ; } return -1 ; }
int arr [ ] = { 10 , 12 , 13 , 16 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 33 , 35 , 42 , 47 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
int x = 18 ; int index = interpolationSearch ( arr , 0 , n - 1 , x ) ;
if ( index != -1 ) cout << " Element ▁ found ▁ at ▁ index ▁ " << index ; else cout << " Element ▁ not ▁ found . " ; return 0 ; }
int exponentialSearch ( int arr [ ] , int n , int x ) {
if ( arr [ 0 ] == x ) return 0 ;
int i = 1 ; while ( i < n && arr [ i ] <= x ) i = i * 2 ;
return binarySearch ( arr , i / 2 , min ( i , n - 1 ) , x ) ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return -1 ; }
int main ( void ) { int arr [ ] = { 2 , 3 , 4 , 10 , 40 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 10 ; int result = exponentialSearch ( arr , n , x ) ; ( result == -1 ) ? printf ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) : printf ( " Element ▁ is ▁ present ▁ at ▁ index ▁ % d " , result ) ; return 0 ; }
void merge ( int arr [ ] , int l , int m , int r ) {
int n1 = m - l + 1 ; int n2 = r - m ;
int L [ n1 ] , R [ n2 ] ;
for ( int i = 0 ; i < n1 ; i ++ ) L [ i ] = arr [ l + i ] ; for ( int j = 0 ; j < n2 ; j ++ ) R [ j ] = arr [ m + 1 + j ] ;
int i = 0 ; int j = 0 ;
int k = l ; while ( i < n1 && j < n2 ) { if ( L [ i ] <= R [ j ] ) { arr [ k ] = L [ i ] ; i ++ ; } else { arr [ k ] = R [ j ] ; j ++ ; } k ++ ; }
while ( i < n1 ) { arr [ k ] = L [ i ] ; i ++ ; k ++ ; }
while ( j < n2 ) { arr [ k ] = R [ j ] ; j ++ ; k ++ ; } }
void mergeSort ( int arr [ ] , int l , int r ) { if ( l >= r ) { return ; }
int m = l + ( r - l ) / 2 ;
mergeSort ( arr , l , m ) ; mergeSort ( arr , m + 1 , r ) ;
merge ( arr , l , m , r ) ; }
void printArray ( int A [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) cout << A [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 12 , 11 , 13 , 5 , 6 , 7 } ; int arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Given ▁ array ▁ is ▁ STRNEWLINE " ; printArray ( arr , arr_size ) ; mergeSort ( arr , 0 , arr_size - 1 ) ; cout << " Sorted array is " ; printArray ( arr , arr_size ) ; return 0 ; }
void countSort ( vector < int > & arr ) { int max = * max_element ( arr . begin ( ) , arr . end ( ) ) ; int min = * min_element ( arr . begin ( ) , arr . end ( ) ) ; int range = max - min + 1 ; vector < int > count ( range ) , output ( arr . size ( ) ) ; for ( int i = 0 ; i < arr . size ( ) ; i ++ ) count [ arr [ i ] - min ] ++ ; for ( int i = 1 ; i < count . size ( ) ; i ++ ) count [ i ] += count [ i - 1 ] ; for ( int i = arr . size ( ) - 1 ; i >= 0 ; i -- ) { output [ count [ arr [ i ] - min ] - 1 ] = arr [ i ] ; count [ arr [ i ] - min ] -- ; } for ( int i = 0 ; i < arr . size ( ) ; i ++ ) arr [ i ] = output [ i ] ; }
void printArray ( vector < int > & arr ) { for ( int i = 0 ; i < arr . size ( ) ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << " STRNEWLINE " ; }
int main ( ) { vector < int > arr = { -5 , -10 , 0 , -3 , 8 , 5 , -1 , 10 } ; countSort ( arr ) ; printArray ( arr ) ; return 0 ; }
int getNextGap ( int gap ) {
gap = ( gap * 10 ) / 13 ; if ( gap < 1 ) return 1 ; return gap ; }
void combSort ( int a [ ] , int n ) {
int gap = n ;
bool swapped = true ;
while ( gap != 1 swapped == true ) {
gap = getNextGap ( gap ) ;
swapped = false ;
for ( int i = 0 ; i < n - gap ; i ++ ) { if ( a [ i ] > a [ i + gap ] ) {
swap ( a [ i ] , a [ i + gap ] ) ;
swapped = true ; } } } }
int main ( ) { int a [ ] = { 8 , 4 , 1 , 56 , 3 , -44 , 23 , -6 , 28 , 0 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; combSort ( a , n ) ; printf ( " Sorted ▁ array : ▁ STRNEWLINE " ) ; for ( int i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , a [ i ] ) ; return 0 ; }
void cycleSort ( int arr [ ] , int n ) {
int writes = 0 ;
for ( int cycle_start = 0 ; cycle_start <= n - 2 ; cycle_start ++ ) {
int item = arr [ cycle_start ] ;
int pos = cycle_start ; for ( int i = cycle_start + 1 ; i < n ; i ++ ) if ( arr [ i ] < item ) pos ++ ;
if ( pos == cycle_start ) continue ;
while ( item == arr [ pos ] ) pos += 1 ;
if ( pos != cycle_start ) { swap ( item , arr [ pos ] ) ; writes ++ ; }
while ( pos != cycle_start ) { pos = cycle_start ;
for ( int i = cycle_start + 1 ; i < n ; i ++ ) if ( arr [ i ] < item ) pos += 1 ;
while ( item == arr [ pos ] ) pos += 1 ;
if ( item != arr [ pos ] ) { swap ( item , arr [ pos ] ) ; writes ++ ; } } } }
int main ( ) { int arr [ ] = { 1 , 8 , 3 , 9 , 10 , 10 , 2 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cycleSort ( arr , n ) ; cout << " After ▁ sort ▁ : ▁ " << endl ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
int findCrossOver ( int arr [ ] , int low , int high , int x ) {
if ( arr [ high ] <= x ) return high ;
if ( arr [ low ] > x ) return low ;
int mid = ( low + high ) / 2 ;
if ( arr [ mid ] <= x && arr [ mid + 1 ] > x ) return mid ;
if ( arr [ mid ] < x ) return findCrossOver ( arr , mid + 1 , high , x ) ; return findCrossOver ( arr , low , mid - 1 , x ) ; }
void printKclosest ( int arr [ ] , int x , int k , int n ) {
int l = findCrossOver ( arr , 0 , n - 1 , x ) ;
int r = l + 1 ;
int count = 0 ;
if ( arr [ l ] == x ) l -- ;
while ( l >= 0 && r < n && count < k ) { if ( x - arr [ l ] < arr [ r ] - x ) printf ( " % d ▁ " , arr [ l -- ] ) ; else printf ( " % d ▁ " , arr [ r ++ ] ) ; count ++ ; }
while ( count < k && l >= 0 ) printf ( " % d ▁ " , arr [ l -- ] ) , count ++ ;
while ( count < k && r < n ) printf ( " % d ▁ " , arr [ r ++ ] ) , count ++ ; }
int main ( ) { int arr [ ] = { 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 35 , k = 4 ; printKclosest ( arr , x , 4 , n ) ; return 0 ; }
int countSort ( int arr [ ] , int n , int exp ) {
int output [ n ] ; int i , count [ n ] ; for ( int i = 0 ; i < n ; i ++ ) count [ i ] = 0 ;
for ( i = 0 ; i < n ; i ++ ) count [ ( arr [ i ] / exp ) % n ] ++ ;
for ( i = 1 ; i < n ; i ++ ) count [ i ] += count [ i - 1 ] ;
for ( i = n - 1 ; i >= 0 ; i -- ) { output [ count [ ( arr [ i ] / exp ) % n ] - 1 ] = arr [ i ] ; count [ ( arr [ i ] / exp ) % n ] -- ; }
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = output [ i ] ; }
void sort ( int arr [ ] , int n ) {
countSort ( arr , n , 1 ) ;
countSort ( arr , n , n ) ; }
void printArr ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int arr [ ] = { 40 , 12 , 45 , 32 , 33 , 1 , 22 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Given ▁ array ▁ is ▁ n " ; printArr ( arr , n ) ; sort ( arr , n ) ; cout << " nSorted ▁ array ▁ is ▁ n " ; printArr ( arr , n ) ; return 0 ; }
void printClosest ( int ar1 [ ] , int ar2 [ ] , int m , int n , int x ) {
int diff = INT_MAX ;
int res_l , res_r ;
int l = 0 , r = n - 1 ; while ( l < m && r >= 0 ) {
if ( abs ( ar1 [ l ] + ar2 [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = abs ( ar1 [ l ] + ar2 [ r ] - x ) ; }
if ( ar1 [ l ] + ar2 [ r ] > x ) r -- ;
else l ++ ; }
cout << " The ▁ closest ▁ pair ▁ is ▁ [ " << ar1 [ res_l ] << " , ▁ " << ar2 [ res_r ] << " ] ▁ STRNEWLINE " ; }
int main ( ) { int ar1 [ ] = { 1 , 4 , 5 , 7 } ; int ar2 [ ] = { 10 , 20 , 30 , 40 } ; int m = sizeof ( ar1 ) / sizeof ( ar1 [ 0 ] ) ; int n = sizeof ( ar2 ) / sizeof ( ar2 [ 0 ] ) ; int x = 38 ; printClosest ( ar1 , ar2 , m , n , x ) ; return 0 ; }
void printClosest ( int arr [ ] , int n , int x ) {
int res_l , res_r ;
int l = 0 , r = n - 1 , diff = INT_MAX ;
while ( r > l ) {
if ( abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } cout << " ▁ The ▁ closest ▁ pair ▁ is ▁ " << arr [ res_l ] << " ▁ and ▁ " << arr [ res_r ] ; }
int main ( ) { int arr [ ] = { 10 , 22 , 28 , 29 , 30 , 40 } , x = 54 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printClosest ( arr , n , x ) ; return 0 ; }
int countOnes ( bool arr [ ] , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
int main ( ) { bool arr [ ] = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " << countOnes ( arr , 0 , n - 1 ) ; return 0 ; }
void solve ( int a [ ] , int n ) { int maxx = -1 , minn = a [ 0 ] , l = 0 , r = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] > maxx ) { maxx = a [ i ] ; l = i ; }
if ( a [ i ] <= minn ) { minn = a [ i ] ; r = i ; } } if ( r < l ) cout << l + ( n - r - 2 ) ; else cout << l + ( n - r - 1 ) ; }
int main ( ) { int a [ ] = { 5 , 6 , 1 , 3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; solve ( a , n ) ; return 0 ; }
void printMaxActivities ( Activitiy arr [ ] , int n ) {
sort ( arr , arr + n , activityCompare ) ; cout << " Following ▁ activities ▁ are ▁ selected ▁ n " ;
int i = 0 ; cout << " ( " << arr [ i ] . start << " , ▁ " << arr [ i ] . finish << " ) , ▁ " ;
for ( int j = 1 ; j < n ; j ++ ) {
if ( arr [ j ] . start >= arr [ i ] . finish ) { cout << " ( " << arr [ j ] . start << " , ▁ " << arr [ j ] . finish << " ) , ▁ " ; i = j ; } } }
int main ( ) { Activitiy arr [ ] = { { 5 , 9 } , { 1 , 2 } , { 3 , 4 } , { 0 , 6 } , { 5 , 7 } , { 8 , 9 } } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printMaxActivities ( arr , n ) ; return 0 ; }
int _lis ( int arr [ ] , int n , int * max_ref ) {
if ( n == 1 ) return 1 ;
int res , max_ending_here = 1 ;
for ( int i = 1 ; i < n ; i ++ ) { res = _lis ( arr , i , max_ref ) ; if ( arr [ i - 1 ] < arr [ n - 1 ] && res + 1 > max_ending_here ) max_ending_here = res + 1 ; }
if ( * max_ref < max_ending_here ) * max_ref = max_ending_here ;
return max_ending_here ; }
int lis ( int arr [ ] , int n ) {
int max = 1 ;
_lis ( arr , n , & max ) ;
return max ; }
int main ( ) { int arr [ ] = { 10 , 22 , 9 , 33 , 21 , 50 , 41 , 60 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Length ▁ of ▁ lis ▁ is ▁ % d " , lis ( arr , n ) ) ; return 0 ; }
int lis ( int arr [ ] , int n ) { int lis [ n ] ; lis [ 0 ] = 1 ;
for ( int i = 1 ; i < n ; i ++ ) { lis [ i ] = 1 ; for ( int j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ; }
return * max_element ( lis , lis + n ) ; }
int main ( ) { int arr [ ] = { 10 , 22 , 9 , 33 , 21 , 50 , 41 , 60 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Length ▁ of ▁ lis ▁ is ▁ % d STRNEWLINE " , lis ( arr , n ) ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define endl  " NEW_LINE " using namespace std ; const int row = 3 ; const int col = 3 ; int minCost ( int cost [ row ] [ col ] ) {
for ( int i = 1 ; i < row ; i ++ ) { cost [ i ] [ 0 ] += cost [ i - 1 ] [ 0 ] ; }
for ( int j = 1 ; j < col ; j ++ ) { cost [ 0 ] [ j ] += cost [ 0 ] [ j - 1 ] ; }
for ( int i = 1 ; i < row ; i ++ ) { for ( int j = 1 ; j < col ; j ++ ) { cost [ i ] [ j ] += min ( cost [ i - 1 ] [ j - 1 ] , min ( cost [ i - 1 ] [ j ] , cost [ i ] [ j - 1 ] ) ) ; } }
return cost [ row - 1 ] [ col - 1 ] ; }
int main ( int argc , char const * argv [ ] ) { int cost [ row ] [ col ] = { { 1 , 2 , 3 } , { 4 , 8 , 2 } , { 1 , 5 , 3 } } ; cout << minCost ( cost ) << endl ; return 0 ; }
int count ( int S [ ] , int m , int n ) {
if ( n == 0 ) return 1 ;
if ( n < 0 ) return 0 ;
if ( m <= 0 && n >= 1 ) return 0 ;
return count ( S , m - 1 , n ) + count ( S , m , n - S [ m - 1 ] ) ; }
int main ( ) { int i , j ; int arr [ ] = { 1 , 2 , 3 } ; int m = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " % d ▁ " , count ( arr , m , 4 ) ) ; getchar ( ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE int count ( int S [ ] , int m , int n ) {
int table [ n + 1 ] ; memset ( table , 0 , sizeof ( table ) ) ;
table [ 0 ] = 1 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = S [ i ] ; j <= n ; j ++ ) table [ j ] += table [ j - S [ i ] ] ; return table [ n ] ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int dp [ 100 ] [ 100 ] ;
int matrixChainMemoised ( int * p , int i , int j ) { if ( i == j ) { return 0 ; } if ( dp [ i ] [ j ] != -1 ) { return dp [ i ] [ j ] ; } dp [ i ] [ j ] = INT_MAX ; for ( int k = i ; k < j ; k ++ ) { dp [ i ] [ j ] = min ( dp [ i ] [ j ] , matrixChainMemoised ( p , i , k ) + matrixChainMemoised ( p , k + 1 , j ) + p [ i - 1 ] * p [ k ] * p [ j ] ) ; } return dp [ i ] [ j ] ; } int MatrixChainOrder ( int * p , int n ) { int i = 1 , j = n - 1 ; return matrixChainMemoised ( p , i , j ) ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; memset ( dp , -1 , sizeof dp ) ; cout << " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " << MatrixChainOrder ( arr , n ) ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int binomialCoeff ( int n , int k ) { int C [ k + 1 ] ; memset ( C , 0 , sizeof ( C ) ) ;
C [ 0 ] = 1 ; for ( int i = 1 ; i <= n ; i ++ ) {
for ( int j = min ( i , k ) ; j > 0 ; j -- ) C [ j ] = C [ j ] + C [ j - 1 ] ; } return C [ k ] ; }
int main ( ) { int n = 5 , k = 2 ; printf ( " Value ▁ of ▁ C ( % d , ▁ % d ) ▁ is ▁ % d ▁ " , n , k , binomialCoeff ( n , k ) ) ; return 0 ; }
int eggDrop ( int n , int k ) {
if ( k == 1 k == 0 ) return k ;
if ( n == 1 ) return k ; int min = INT_MAX , x , res ;
for ( x = 1 ; x <= k ; x ++ ) { res = max ( eggDrop ( n - 1 , x - 1 ) , eggDrop ( n , k - x ) ) ; if ( res < min ) min = res ; } return min + 1 ; }
int main ( ) { int n = 2 , k = 10 ; cout << " Minimum ▁ number ▁ of ▁ trials ▁ " " in ▁ worst ▁ case ▁ with ▁ " << n << " ▁ eggs ▁ and ▁ " << k << " ▁ floors ▁ is ▁ " << eggDrop ( n , k ) << endl ; return 0 ; }
int cutRod ( int price [ ] , int n ) { if ( n <= 0 ) return 0 ; int max_val = INT_MIN ;
for ( int i = 0 ; i < n ; i ++ ) max_val = max ( max_val , price [ i ] + cutRod ( price , n - i - 1 ) ) ; return max_val ; }
int main ( ) { int arr [ ] = { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ % dn " , cutRod ( arr , size ) ) ; getchar ( ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int findRoot ( pair < int , int > arr [ ] , int n ) {
int root = 0 ; for ( int i = 0 ; i < n ; i ++ ) root += ( arr [ i ] . first - arr [ i ] . second ) ; return root ; }
int main ( ) { pair < int , int > arr [ ] = { { 1 , 5 } , { 2 , 0 } , { 3 , 0 } , { 4 , 0 } , { 5 , 5 } , { 6 , 5 } } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " % d STRNEWLINE " , findRoot ( arr , n ) ) ; return 0 ; }
int cutRod ( int price [ ] , int n ) { int val [ n + 1 ] ; val [ 0 ] = 0 ; int i , j ;
for ( i = 1 ; i <= n ; i ++ ) { int max_val = INT_MIN ; for ( j = 0 ; j < i ; j ++ ) max_val = max ( max_val , price [ j ] + val [ i - j - 1 ] ) ; val [ i ] = max_val ; } return val [ n ] ; }
int main ( ) { int arr [ ] = { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ % dn " , cutRod ( arr , size ) ) ; getchar ( ) ; return 0 ; }
int t [ 9 ] [ 9 ] ;
int un_kp ( int price [ ] , int length [ ] , int Max_len , int n ) {
if ( n == 0 Max_len == 0 ) { return 0 ; }
if ( length [ n - 1 ] <= Max_len ) { t [ n ] [ Max_len ] = max ( price [ n - 1 ] + un_kp ( price , length , Max_len - length [ n - 1 ] , n ) , un_kp ( price , length , Max_len , n - 1 ) ) ; }
else { t [ n ] [ Max_len ] = un_kp ( price , length , Max_len , n - 1 ) ; }
return t [ n ] [ Max_len ] ; }
int main ( ) { int price [ ] = { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int n = sizeof ( price ) / sizeof ( price [ 0 ] ) ; int length [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { length [ i ] = i + 1 ; } int Max_len = n ;
cout << " Maximum ▁ obtained ▁ value ▁ is ▁ " << un_kp ( price , length , n , Max_len ) << endl ; }
int lbs ( int arr [ ] , int n ) { int i , j ;
int * lis = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
int * lds = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lds [ i ] = 1 ;
for ( i = n - 2 ; i >= 0 ; i -- ) for ( j = n - 1 ; j > i ; j -- ) if ( arr [ i ] > arr [ j ] && lds [ i ] < lds [ j ] + 1 ) lds [ i ] = lds [ j ] + 1 ;
int max = lis [ 0 ] + lds [ 0 ] - 1 ; for ( i = 1 ; i < n ; i ++ ) if ( lis [ i ] + lds [ i ] - 1 > max ) max = lis [ i ] + lds [ i ] - 1 ; return max ; }
int main ( ) { int arr [ ] = { 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Length ▁ of ▁ LBS ▁ is ▁ % d STRNEWLINE " , lbs ( arr , n ) ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; bool isPalindrome ( string String , int i , int j ) { while ( i < j ) { if ( String [ i ] != String [ j ] ) return false ; i ++ ; j -- ; } return true ; } int minPalPartion ( string String , int i , int j ) { if ( i >= j || isPalindrome ( String , i , j ) ) return 0 ; int ans = INT_MAX , count ; for ( int k = i ; k < j ; k ++ ) { count = minPalPartion ( String , i , k ) + minPalPartion ( String , k + 1 , j ) + 1 ; ans = min ( ans , count ) ; } return ans ; }
int main ( ) { string str = " ababbbabbababa " ; cout << " Min ▁ cuts ▁ needed ▁ for ▁ " << " Palindrome ▁ Partitioning ▁ is ▁ " << minPalPartion ( str , 0 , str . length ( ) - 1 ) << endl ; return 0 ; }
bool findPartiion ( int arr [ ] , int n ) { int sum = 0 ; int i , j ;
for ( i = 0 ; i < n ; i ++ ) sum += arr [ i ] ; if ( sum % 2 != 0 ) return false ; bool part [ sum / 2 + 1 ] ;
for ( i = 0 ; i <= sum / 2 ; i ++ ) { part [ i ] = 0 ; }
for ( i = 0 ; i < n ; i ++ ) {
for ( j = sum / 2 ; j >= arr [ i ] ; j -- ) {
if ( part [ j - arr [ i ] ] == 1 j == arr [ i ] ) part [ j ] = 1 ; } } return part [ sum / 2 ] ; }
int main ( ) { int arr [ ] = { 1 , 3 , 3 , 2 , 3 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
if ( findPartiion ( arr , n ) == true ) cout << " Can ▁ be ▁ divided ▁ into ▁ two ▁ subsets ▁ of ▁ equal ▁ " " sum " ; else cout << " Can ▁ not ▁ be ▁ divided ▁ into " << " ▁ two ▁ subsets ▁ of ▁ equal ▁ sum " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define INF  INT_MAX
int printSolution ( int p [ ] , int n ) ; int printSolution ( int p [ ] , int n ) { int k ; if ( p [ n ] == 1 ) k = 1 ; else k = printSolution ( p , p [ n ] - 1 ) + 1 ; cout << " Line ▁ number ▁ " << k << " : ▁ From ▁ word ▁ no . ▁ " << p [ n ] << " ▁ to ▁ " << n << endl ; return k ; }
void solveWordWrap ( int l [ ] , int n , int M ) {
int extras [ n + 1 ] [ n + 1 ] ;
int lc [ n + 1 ] [ n + 1 ] ;
int c [ n + 1 ] ;
int p [ n + 1 ] ; int i , j ;
for ( i = 1 ; i <= n ; i ++ ) { extras [ i ] [ i ] = M - l [ i - 1 ] ; for ( j = i + 1 ; j <= n ; j ++ ) extras [ i ] [ j ] = extras [ i ] [ j - 1 ] - l [ j - 1 ] - 1 ; }
for ( i = 1 ; i <= n ; i ++ ) { for ( j = i ; j <= n ; j ++ ) { if ( extras [ i ] [ j ] < 0 ) lc [ i ] [ j ] = INF ; else if ( j == n && extras [ i ] [ j ] >= 0 ) lc [ i ] [ j ] = 0 ; else lc [ i ] [ j ] = extras [ i ] [ j ] * extras [ i ] [ j ] ; } }
c [ 0 ] = 0 ; for ( j = 1 ; j <= n ; j ++ ) { c [ j ] = INF ; for ( i = 1 ; i <= j ; i ++ ) { if ( c [ i - 1 ] != INF && lc [ i ] [ j ] != INF && ( c [ i - 1 ] + lc [ i ] [ j ] < c [ j ] ) ) { c [ j ] = c [ i - 1 ] + lc [ i ] [ j ] ; p [ j ] = i ; } } } printSolution ( p , n ) ; }
int main ( ) { int l [ ] = { 3 , 2 , 2 , 5 } ; int n = sizeof ( l ) / sizeof ( l [ 0 ] ) ; int M = 6 ; solveWordWrap ( l , n , M ) ; return 0 ; }
int maxDivide ( int a , int b ) { while ( a % b == 0 ) a = a / b ; return a ; }
int isUgly ( int no ) { no = maxDivide ( no , 2 ) ; no = maxDivide ( no , 3 ) ; no = maxDivide ( no , 5 ) ; return ( no == 1 ) ? 1 : 0 ; }
int getNthUglyNo ( int n ) { int i = 1 ;
int count = 1 ;
while ( n > count ) { i ++ ; if ( isUgly ( i ) ) count ++ ; } return i ; }
int main ( ) { unsigned no = getNthUglyNo ( 150 ) ; printf ( "150th ▁ ugly ▁ no . ▁ is ▁ % d ▁ " , no ) ; getchar ( ) ; return 0 ; }
int sum ( int freq [ ] , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
int optCost ( int freq [ ] , int i , int j ) {
if ( j < i ) return 0 ;
if ( j == i ) return freq [ i ] ;
int fsum = sum ( freq , i , j ) ;
int min = INT_MAX ;
for ( int r = i ; r <= j ; ++ r ) { int cost = optCost ( freq , i , r - 1 ) + optCost ( freq , r + 1 , j ) ; if ( cost < min ) min = cost ; }
return min + fsum ; }
int optimalSearchTree ( int keys [ ] , int freq [ ] , int n ) {
return optCost ( freq , 0 , n - 1 ) ; }
int main ( ) { int keys [ ] = { 10 , 12 , 20 } ; int freq [ ] = { 34 , 8 , 50 } ; int n = sizeof ( keys ) / sizeof ( keys [ 0 ] ) ; cout << " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ " << optimalSearchTree ( keys , freq , n ) ; return 0 ; }
int sum ( int freq [ ] , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
int optimalSearchTree ( int keys [ ] , int freq [ ] , int n ) {
int cost [ n ] [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) cost [ i ] [ i ] = freq [ i ] ;
for ( int L = 2 ; L <= n ; L ++ ) {
for ( int i = 0 ; i <= n - L + 1 ; i ++ ) {
int j = i + L - 1 ; cost [ i ] [ j ] = INT_MAX ;
for ( int r = i ; r <= j ; r ++ ) {
int c = ( ( r > i ) ? cost [ i ] [ r - 1 ] : 0 ) + ( ( r < j ) ? cost [ r + 1 ] [ j ] : 0 ) + sum ( freq , i , j ) ; if ( c < cost [ i ] [ j ] ) cost [ i ] [ j ] = c ; } } } return cost [ 0 ] [ n - 1 ] ; }
int main ( ) { int keys [ ] = { 10 , 12 , 20 } ; int freq [ ] = { 34 , 8 , 50 } ; int n = sizeof ( keys ) / sizeof ( keys [ 0 ] ) ; cout << " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ " << optimalSearchTree ( keys , freq , n ) ; return 0 ; }
bool isSubsetSum ( int set [ ] , int n , int sum ) {
if ( sum == 0 ) return true ; if ( n == 0 ) return false ;
if ( set [ n - 1 ] > sum ) return isSubsetSum ( set , n - 1 , sum ) ;
return isSubsetSum ( set , n - 1 , sum ) || isSubsetSum ( set , n - 1 , sum - set [ n - 1 ] ) ; }
int main ( ) { int set [ ] = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = sizeof ( set ) / sizeof ( set [ 0 ] ) ; if ( isSubsetSum ( set , n , sum ) == true ) printf ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) ; else printf ( " No ▁ subset ▁ with ▁ given ▁ sum " ) ; return 0 ; }
bool isSubsetSum ( int set [ ] , int n , int sum ) {
bool subset [ n + 1 ] [ sum + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) subset [ i ] [ 0 ] = true ;
for ( int i = 1 ; i <= sum ; i ++ ) subset [ 0 ] [ i ] = false ;
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = 1 ; j <= sum ; j ++ ) { if ( j < set [ i - 1 ] ) subset [ i ] [ j ] = subset [ i - 1 ] [ j ] ; if ( j >= set [ i - 1 ] ) subset [ i ] [ j ] = subset [ i - 1 ] [ j ] || subset [ i - 1 ] [ j - set [ i - 1 ] ] ; } }
for ( int i = 0 ; i <= n ; i ++ ) { for ( int j = 0 ; j <= sum ; j ++ ) printf ( " % 4d " , subset [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } return subset [ n ] [ sum ] ; }
int main ( ) { int set [ ] = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = sizeof ( set ) / sizeof ( set [ 0 ] ) ; if ( isSubsetSum ( set , n , sum ) == true ) printf ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) ; else printf ( " No ▁ subset ▁ with ▁ given ▁ sum " ) ; return 0 ; }
int countParenth ( char symb [ ] , char oper [ ] , int n ) { int F [ n ] [ n ] , T [ n ] [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) { F [ i ] [ i ] = ( symb [ i ] == ' F ' ) ? 1 : 0 ; T [ i ] [ i ] = ( symb [ i ] == ' T ' ) ? 1 : 0 ; }
for ( int gap = 1 ; gap < n ; ++ gap ) { for ( int i = 0 , j = gap ; j < n ; ++ i , ++ j ) { T [ i ] [ j ] = F [ i ] [ j ] = 0 ; for ( int g = 0 ; g < gap ; g ++ ) {
int k = i + g ;
int tik = T [ i ] [ k ] + F [ i ] [ k ] ; int tkj = T [ k + 1 ] [ j ] + F [ k + 1 ] [ j ] ;
if ( oper [ k ] == ' & ' ) { T [ i ] [ j ] += T [ i ] [ k ] * T [ k + 1 ] [ j ] ; F [ i ] [ j ] += ( tik * tkj - T [ i ] [ k ] * T [ k + 1 ] [ j ] ) ; } if ( oper [ k ] == ' ▁ ' ) { F [ i ] [ j ] += F [ i ] [ k ] * F [ k + 1 ] [ j ] ; T [ i ] [ j ] += ( tik * tkj - F [ i ] [ k ] * F [ k + 1 ] [ j ] ) ; } if ( oper [ k ] == ' ^ ' ) { T [ i ] [ j ] += F [ i ] [ k ] * T [ k + 1 ] [ j ] + T [ i ] [ k ] * F [ k + 1 ] [ j ] ; F [ i ] [ j ] += T [ i ] [ k ] * T [ k + 1 ] [ j ] + F [ i ] [ k ] * F [ k + 1 ] [ j ] ; } } } } return T [ 0 ] [ n - 1 ] ; }
int main ( ) { char symbols [ ] = " TTFT " ; char operators [ ] = " | & ^ " ; int n = strlen ( symbols ) ;
cout << countParenth ( symbols , operators , n ) ; return 0 ; }
int getCount ( char keypad [ ] [ 3 ] , int n ) { if ( keypad == NULL n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
int row [ ] = { 0 , 0 , -1 , 0 , 1 } ; int col [ ] = { 0 , -1 , 0 , 1 , 0 } ;
int count [ 10 ] [ n + 1 ] ; int i = 0 , j = 0 , k = 0 , move = 0 , ro = 0 , co = 0 , num = 0 ; int nextNum = 0 , totalCount = 0 ;
for ( i = 0 ; i <= 9 ; i ++ ) { count [ i ] [ 0 ] = 0 ; count [ i ] [ 1 ] = 1 ; }
for ( k = 2 ; k <= n ; k ++ ) {
for ( i = 0 ; i < 4 ; i ++ ) {
for ( j = 0 ; j < 3 ; j ++ ) {
if ( keypad [ i ] [ j ] != ' * ' && keypad [ i ] [ j ] != ' # ' ) {
num = keypad [ i ] [ j ] - '0' ; count [ num ] [ k ] = 0 ;
for ( move = 0 ; move < 5 ; move ++ ) { ro = i + row [ move ] ; co = j + col [ move ] ; if ( ro >= 0 && ro <= 3 && co >= 0 && co <= 2 && keypad [ ro ] [ co ] != ' * ' && keypad [ ro ] [ co ] != ' # ' ) { nextNum = keypad [ ro ] [ co ] - '0' ; count [ num ] [ k ] += count [ nextNum ] [ k - 1 ] ; } } } } } }
totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ ) totalCount += count [ i ] [ n ] ; return totalCount ; }
int main ( int argc , char * argv [ ] ) { char keypad [ 4 ] [ 3 ] = { { '1' , '2' , '3' } , { '4' , '5' , '6' } , { '7' , '8' , '9' } , { ' * ' , '0' , ' # ' } } ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 1 , getCount ( keypad , 1 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 2 , getCount ( keypad , 2 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 3 , getCount ( keypad , 3 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 4 , getCount ( keypad , 4 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 5 , getCount ( keypad , 5 ) ) ; return 0 ; }
int getCount ( char keypad [ ] [ 3 ] , int n ) { if ( keypad == NULL n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
int odd [ 10 ] , even [ 10 ] ; int i = 0 , j = 0 , useOdd = 0 , totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ )
odd [ i ] = 1 ;
for ( j = 2 ; j <= n ; j ++ ) { useOdd = 1 - useOdd ;
if ( useOdd == 1 ) { even [ 0 ] = odd [ 0 ] + odd [ 8 ] ; even [ 1 ] = odd [ 1 ] + odd [ 2 ] + odd [ 4 ] ; even [ 2 ] = odd [ 2 ] + odd [ 1 ] + odd [ 3 ] + odd [ 5 ] ; even [ 3 ] = odd [ 3 ] + odd [ 2 ] + odd [ 6 ] ; even [ 4 ] = odd [ 4 ] + odd [ 1 ] + odd [ 5 ] + odd [ 7 ] ; even [ 5 ] = odd [ 5 ] + odd [ 2 ] + odd [ 4 ] + odd [ 8 ] + odd [ 6 ] ; even [ 6 ] = odd [ 6 ] + odd [ 3 ] + odd [ 5 ] + odd [ 9 ] ; even [ 7 ] = odd [ 7 ] + odd [ 4 ] + odd [ 8 ] ; even [ 8 ] = odd [ 8 ] + odd [ 0 ] + odd [ 5 ] + odd [ 7 ] + odd [ 9 ] ; even [ 9 ] = odd [ 9 ] + odd [ 6 ] + odd [ 8 ] ; } else { odd [ 0 ] = even [ 0 ] + even [ 8 ] ; odd [ 1 ] = even [ 1 ] + even [ 2 ] + even [ 4 ] ; odd [ 2 ] = even [ 2 ] + even [ 1 ] + even [ 3 ] + even [ 5 ] ; odd [ 3 ] = even [ 3 ] + even [ 2 ] + even [ 6 ] ; odd [ 4 ] = even [ 4 ] + even [ 1 ] + even [ 5 ] + even [ 7 ] ; odd [ 5 ] = even [ 5 ] + even [ 2 ] + even [ 4 ] + even [ 8 ] + even [ 6 ] ; odd [ 6 ] = even [ 6 ] + even [ 3 ] + even [ 5 ] + even [ 9 ] ; odd [ 7 ] = even [ 7 ] + even [ 4 ] + even [ 8 ] ; odd [ 8 ] = even [ 8 ] + even [ 0 ] + even [ 5 ] + even [ 7 ] + even [ 9 ] ; odd [ 9 ] = even [ 9 ] + even [ 6 ] + even [ 8 ] ; } }
totalCount = 0 ; if ( useOdd == 1 ) { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += even [ i ] ; } else { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += odd [ i ] ; } return totalCount ; }
int main ( ) { char keypad [ 4 ] [ 3 ] = { { '1' , '2' , '3' } , { '4' , '5' , '6' } , { '7' , '8' , '9' } , { ' * ' , '0' , ' # ' } } ; cout << " Count ▁ for ▁ numbers ▁ of ▁ length ▁ 1 : ▁ " << getCount ( keypad , 1 ) << endl ; cout << " Count ▁ for ▁ numbers ▁ of ▁ length ▁ 2 : ▁ " << getCount ( keypad , 2 ) << endl ; cout << " Count ▁ for ▁ numbers ▁ of ▁ length ▁ 3 : ▁ " << getCount ( keypad , 3 ) << endl ; cout << " Count ▁ for ▁ numbers ▁ of ▁ length ▁ 4 : ▁ " << getCount ( keypad , 4 ) << endl ; cout << " Count ▁ for ▁ numbers ▁ of ▁ length ▁ 5 : ▁ " << getCount ( keypad , 5 ) << endl ; return 0 ; }
unsigned long long int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ; if ( sum == 0 ) return 1 ;
unsigned long long int ans = 0 ;
for ( int i = 0 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
unsigned long long int finalCount ( int n , int sum ) {
unsigned long long int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
int main ( ) { int n = 2 , sum = 5 ; cout << finalCount ( n , sum ) ; return 0 ; }
unsigned long long int lookup [ 101 ] [ 501 ] ;
unsigned long long int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ;
if ( lookup [ n ] [ sum ] != -1 ) return lookup [ n ] [ sum ] ;
unsigned long long int ans = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return lookup [ n ] [ sum ] = ans ; }
unsigned long long int finalCount ( int n , int sum ) {
memset ( lookup , -1 , sizeof lookup ) ;
unsigned long long int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
int main ( ) { int n = 3 , sum = 5 ; cout << finalCount ( n , sum ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #include <iostream> NEW_LINE using namespace std ; void findCount ( int n , int sum ) {
int start = pow ( 10 , n - 1 ) ; int end = pow ( 10 , n ) - 1 ; int count = 0 ; int i = start ; while ( i <= end ) { int cur = 0 ; int temp = i ; while ( temp != 0 ) { cur += temp % 10 ; temp = temp / 10 ; } if ( cur == sum ) { count ++ ; i += 9 ; } else i ++ ; } cout << count ; }
int main ( ) { int n = 3 ; int sum = 5 ; findCount ( n , sum ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; long long int countNonDecreasing ( int n ) {
long long int dp [ 10 ] [ n + 1 ] ; memset ( dp , 0 , sizeof dp ) ;
for ( int i = 0 ; i < 10 ; i ++ ) dp [ i ] [ 1 ] = 1 ;
for ( int digit = 0 ; digit <= 9 ; digit ++ ) {
for ( int len = 2 ; len <= n ; len ++ ) {
for ( int x = 0 ; x <= digit ; x ++ ) dp [ digit ] [ len ] += dp [ x ] [ len - 1 ] ; } } long long int count = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) count += dp [ i ] [ n ] ; return count ; }
int main ( ) { int n = 3 ; cout << countNonDecreasing ( n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; long long int countNonDecreasing ( int n ) { int N = 10 ;
long long count = 1 ; for ( int i = 1 ; i <= n ; i ++ ) { count *= ( N + i - 1 ) ; count /= i ; } return count ; }
int main ( ) { int n = 3 ; cout << countNonDecreasing ( n ) ; return 0 ; }
int getMinSquares ( unsigned int n ) {
if ( sqrt ( n ) - floor ( sqrt ( n ) ) == 0 ) return 1 ; if ( n <= 3 ) return n ;
int res = n ;
for ( int x = 1 ; x <= n ; x ++ ) { int temp = x * x ; if ( temp > n ) break ; else res = min ( res , 1 + getMinSquares ( n - temp ) ) ; } return res ; }
int main ( ) { cout << getMinSquares ( 6 ) ; return 0 ; }
int getMinSquares ( int n ) {
if ( n <= 3 ) return n ;
int * dp = new int [ n + 1 ] ;
dp [ 0 ] = 0 ; dp [ 1 ] = 1 ; dp [ 2 ] = 2 ; dp [ 3 ] = 3 ;
for ( int i = 4 ; i <= n ; i ++ ) {
dp [ i ] = i ;
for ( int x = 1 ; x <= ceil ( sqrt ( i ) ) ; x ++ ) { int temp = x * x ; if ( temp > i ) break ; else dp [ i ] = min ( dp [ i ] , 1 + dp [ i - temp ] ) ; } }
int res = dp [ n ] ; delete [ ] dp ; return res ; }
int main ( ) { cout << getMinSquares ( 6 ) ; return 0 ; }
int minCoins ( int coins [ ] , int m , int V ) {
if ( V == 0 ) return 0 ;
int res = INT_MAX ;
for ( int i = 0 ; i < m ; i ++ ) { if ( coins [ i ] <= V ) { int sub_res = minCoins ( coins , m , V - coins [ i ] ) ;
if ( sub_res != INT_MAX && sub_res + 1 < res ) res = sub_res + 1 ; } } return res ; }
int main ( ) { int coins [ ] = { 9 , 6 , 5 , 1 } ; int m = sizeof ( coins ) / sizeof ( coins [ 0 ] ) ; int V = 11 ; cout << " Minimum ▁ coins ▁ required ▁ is ▁ " << minCoins ( coins , m , V ) ; return 0 ; }
int minCoins ( int coins [ ] , int m , int V ) {
int table [ V + 1 ] ;
table [ 0 ] = 0 ;
for ( int i = 1 ; i <= V ; i ++ ) table [ i ] = INT_MAX ;
for ( int i = 1 ; i <= V ; i ++ ) {
for ( int j = 0 ; j < m ; j ++ ) if ( coins [ j ] <= i ) { int sub_res = table [ i - coins [ j ] ] ; if ( sub_res != INT_MAX && sub_res + 1 < table [ i ] ) table [ i ] = sub_res + 1 ; } } if ( table [ V ] == INT_MAX ) return -1 ; return table [ V ] ; }
int main ( ) { int coins [ ] = { 9 , 6 , 5 , 1 } ; int m = sizeof ( coins ) / sizeof ( coins [ 0 ] ) ; int V = 11 ; cout << " Minimum ▁ coins ▁ required ▁ is ▁ " << minCoins ( coins , m , V ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int superSeq ( char * X , char * Y , int m , int n ) { if ( ! m ) return n ; if ( ! n ) return m ; if ( X [ m - 1 ] == Y [ n - 1 ] ) return 1 + superSeq ( X , Y , m - 1 , n - 1 ) ; return 1 + min ( superSeq ( X , Y , m - 1 , n ) , superSeq ( X , Y , m , n - 1 ) ) ; }
int main ( ) { char X [ ] = " AGGTAB " ; char Y [ ] = " GXTXAYB " ; cout << " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ " << superSeq ( X , Y , strlen ( X ) , strlen ( Y ) ) ; return 0 ; }
int superSeq ( char * X , char * Y , int m , int n ) { int dp [ m + 1 ] [ n + 1 ] ;
for ( int i = 0 ; i <= m ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) {
if ( ! i ) dp [ i ] [ j ] = j ; else if ( ! j ) dp [ i ] [ j ] = i ; else if ( X [ i - 1 ] == Y [ j - 1 ] ) dp [ i ] [ j ] = 1 + dp [ i - 1 ] [ j - 1 ] ; else dp [ i ] [ j ] = 1 + min ( dp [ i - 1 ] [ j ] , dp [ i ] [ j - 1 ] ) ; } } return dp [ m ] [ n ] ; }
int main ( ) { char X [ ] = " AGGTAB " ; char Y [ ] = " GXTXAYB " ; cout << " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ " << superSeq ( X , Y , strlen ( X ) , strlen ( Y ) ) ; return 0 ; }
int sumOfDigitsFrom1ToN ( int n ) {
int result = 0 ;
for ( int x = 1 ; x <= n ; x ++ ) result += sumOfDigits ( x ) ; return result ; }
int sumOfDigits ( int x ) { int sum = 0 ; while ( x != 0 ) { sum += x % 10 ; x = x / 10 ; } return sum ; }
int main ( ) { int n = 328 ; cout << " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from ▁ 1 ▁ to ▁ " << n << " ▁ is ▁ " << sumOfDigitsFrom1ToN ( n ) ; return 0 ; }
int sumOfDigitsFrom1ToN ( int n ) {
if ( n < 10 ) return n * ( n + 1 ) / 2 ;
int d = log10 ( n ) ;
int * a = new int [ d + 1 ] ; a [ 0 ] = 0 , a [ 1 ] = 45 ; for ( int i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * ceil ( pow ( 10 , i - 1 ) ) ;
int p = ceil ( pow ( 10 , d ) ) ;
int msd = n / p ;
return msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToN ( n % p ) ; }
int main ( ) { int n = 328 ; cout << " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from ▁ 1 ▁ to ▁ " << n << " ▁ is ▁ " << sumOfDigitsFrom1ToN ( n ) ; return 0 ; }
int sumOfDigitsFrom1ToNUtil ( int n , int a [ ] ) { if ( n < 10 ) return ( n * ( n + 1 ) / 2 ) ; int d = ( int ) ( log10 ( n ) ) ; int p = ( int ) ( ceil ( pow ( 10 , d ) ) ) ; int msd = n / p ; return ( msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToNUtil ( n % p , a ) ) ; } int sumOfDigitsFrom1ToN ( int n ) { int d = ( int ) ( log10 ( n ) ) ; int a [ d + 1 ] ; a [ 0 ] = 0 ; a [ 1 ] = 45 ; for ( int i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * ( int ) ( ceil ( pow ( 10 , i - 1 ) ) ) ; return sumOfDigitsFrom1ToNUtil ( n , a ) ; }
int main ( ) { int n = 328 ; cout << " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from ▁ 1 ▁ to ▁ " << n << " ▁ is ▁ " << sumOfDigitsFrom1ToN ( n ) ; }
int countWays ( int N ) {
if ( N == 1 )
return 4 ;
int countB = 1 , countS = 1 , prev_countB , prev_countS ;
for ( int i = 2 ; i <= N ; i ++ ) { prev_countB = countB ; prev_countS = countS ; countS = prev_countB + prev_countS ; countB = prev_countS ; }
int result = countS + countB ;
return ( result * result ) ; }
int main ( ) { int N = 3 ; cout << " Count ▁ of ▁ ways ▁ for ▁ " << N << " ▁ sections ▁ is ▁ " << countWays ( N ) ; return 0 ; }
int findoptimal ( int N ) {
if ( N <= 6 ) return N ;
int screen [ N ] ;
int b ;
int n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = 0 ;
for ( b = n - 3 ; b >= 1 ; b -- ) {
int curr = ( n - b - 1 ) * screen [ b - 1 ] ; if ( curr > screen [ n - 1 ] ) screen [ n - 1 ] = curr ; } } return screen [ N - 1 ] ; }
int main ( ) { int N ;
for ( N = 1 ; N <= 20 ; N ++ ) cout << " Maximum ▁ Number ▁ of ▁ A ' s ▁ with ▁ " << N << " ▁ keystrokes ▁ is ▁ " << findoptimal ( N ) << endl ; }
int findoptimal ( int N ) {
if ( N <= 6 ) return N ;
int screen [ N ] ;
int b ;
int n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = max ( 2 * screen [ n - 4 ] , max ( 3 * screen [ n - 5 ] , 4 * screen [ n - 6 ] ) ) ; } return screen [ N - 1 ] ; }
int main ( ) { int N ;
for ( N = 1 ; N <= 20 ; N ++ ) printf ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with ▁ % d ▁ keystrokes ▁ is ▁ % d STRNEWLINE " , N , findoptimal ( N ) ) ; }
int power ( int x , unsigned int y ) { int temp ; if ( y == 0 ) return 1 ; temp = power ( x , y / 2 ) ; if ( y % 2 == 0 ) return temp * temp ; else return x * temp * temp ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int power ( int x , int y ) {
if ( y == 0 ) return 1 ;
if ( x == 0 ) return 0 ;
return x * power ( x , y - 1 ) ; }
int main ( ) { int x = 2 ; int y = 3 ; cout << ( power ( x , y ) ) ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int power ( int x , int y ) {
return ( int ) pow ( x , y ) ; }
int main ( ) { int x = 2 ; int y = 3 ; cout << ( power ( x , y ) ) ; }
float area ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 ) { return abs ( ( x1 * ( y2 - y3 ) + x2 * ( y3 - y1 ) + x3 * ( y1 - y2 ) ) / 2.0 ) ; }
bool isInside ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 , int x , int y ) {
float A = area ( x1 , y1 , x2 , y2 , x3 , y3 ) ;
float A1 = area ( x , y , x2 , y2 , x3 , y3 ) ;
float A2 = area ( x1 , y1 , x , y , x3 , y3 ) ;
float A3 = area ( x1 , y1 , x2 , y2 , x , y ) ;
return ( A == A1 + A2 + A3 ) ; }
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) printf ( " Inside " ) ; else printf ( " Not ▁ Inside " ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int preIndex = 0 ; void printPost ( int in [ ] , int pre [ ] , int inStrt , int inEnd , map < int , int > hm ) { if ( inStrt > inEnd ) return ;
int inIndex = hm [ pre [ preIndex ++ ] ] ;
printPost ( in , pre , inStrt , inIndex - 1 , hm ) ;
printPost ( in , pre , inIndex + 1 , inEnd , hm ) ;
cout << in [ inIndex ] << " ▁ " ; } void printPostMain ( int in [ ] , int pre [ ] , int n ) { map < int , int > hm ; for ( int i = 0 ; i < n ; i ++ ) hm [ in [ i ] ] = i ; printPost ( in , pre , 0 , n - 1 , hm ) ; }
int main ( ) { int in [ ] = { 4 , 2 , 5 , 1 , 3 , 6 } ; int pre [ ] = { 1 , 2 , 4 , 5 , 3 , 6 } ; int n = sizeof ( pre ) / sizeof ( pre [ 0 ] ) ; printPostMain ( in , pre , n ) ; return 0 ; }
struct Node { int key ; struct Node * left , * right ; } ;
struct Node * newNode ( int key ) { Node * temp = new Node ; temp -> key = key ; temp -> left = temp -> right = NULL ; return ( temp ) ; }
int maxDiffUtil ( Node * t , int * res ) {
if ( t == NULL ) return INT_MAX ;
if ( t -> left == NULL && t -> right == NULL ) return t -> key ;
int val = min ( maxDiffUtil ( t -> left , res ) , maxDiffUtil ( t -> right , res ) ) ;
* res = max ( * res , t -> key - val ) ;
return min ( val , t -> key ) ; }
int maxDiff ( Node * root ) {
int res = INT_MIN ; maxDiffUtil ( root , & res ) ; return res ; }
void inorder ( Node * root ) { if ( root ) { inorder ( root -> left ) ; printf ( " % d ▁ " , root -> key ) ; inorder ( root -> right ) ; } }
Node * root ; root = newNode ( 8 ) ; root -> left = newNode ( 3 ) ; root -> left -> left = newNode ( 1 ) ; root -> left -> right = newNode ( 6 ) ; root -> left -> right -> left = newNode ( 4 ) ; root -> left -> right -> right = newNode ( 7 ) ; root -> right = newNode ( 10 ) ; root -> right -> right = newNode ( 14 ) ; root -> right -> right -> left = newNode ( 13 ) ; printf ( " Maximum ▁ difference ▁ between ▁ a ▁ node ▁ and " " ▁ its ▁ ancestor ▁ is ▁ : ▁ % d STRNEWLINE " , maxDiff ( root ) ) ; }
float getAvg ( float prev_avg , int x , int n ) { return ( prev_avg * n + x ) / ( n + 1 ) ; }
void streamAvg ( float arr [ ] , int n ) { float avg = 0 ; for ( int i = 0 ; i < n ; i ++ ) { avg = getAvg ( avg , arr [ i ] , i ) ; printf ( " Average ▁ of ▁ % d ▁ numbers ▁ is ▁ % f ▁ STRNEWLINE " , i + 1 , avg ) ; } return ; }
int main ( ) { float arr [ ] = { 10 , 20 , 30 , 40 , 50 , 60 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; streamAvg ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void SieveOfEratosthenes ( int n ) {
bool prime [ n + 1 ] ; memset ( prime , true , sizeof ( prime ) ) ; for ( int p = 2 ; p * p <= n ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * p ; i <= n ; i += p ) prime [ i ] = false ; } }
for ( int p = 2 ; p <= n ; p ++ ) if ( prime [ p ] ) cout << p << " ▁ " ; }
int main ( ) { int n = 30 ; cout << " Following ▁ are ▁ the ▁ prime ▁ numbers ▁ smaller ▁ " << " ▁ than ▁ or ▁ equal ▁ to ▁ " << n << endl ; SieveOfEratosthenes ( n ) ; return 0 ; }
int maximumNumberDistinctPrimeRange ( int m , int n ) {
long long factorCount [ n + 1 ] ;
bool prime [ n + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) { factorCount [ i ] = 0 ;
prime [ i ] = true ; } for ( int i = 2 ; i <= n ; i ++ ) {
if ( prime [ i ] == true ) {
factorCount [ i ] = 1 ;
for ( int j = i * 2 ; j <= n ; j += i ) {
factorCount [ j ] ++ ;
prime [ j ] = false ; } } }
int max = factorCount [ m ] ; int num = m ;
for ( int i = m ; i <= n ; i ++ ) {
if ( factorCount [ i ] > max ) { max = factorCount [ i ] ; num = i ; } } return num ; }
int main ( ) { int m = 4 , n = 6 ;
cout << maximumNumberDistinctPrimeRange ( m , n ) ; return 0 ; }
int binomialCoeff ( int n , int k ) ; int binomialCoeff ( int n , int k ) { int res = 1 ; if ( k > n - k ) k = n - k ; for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
void printPascal ( int n ) {
for ( int line = 0 ; line < n ; line ++ ) {
for ( int i = 0 ; i <= line ; i ++ ) printf ( " % d ▁ " , binomialCoeff ( line , i ) ) ; printf ( " STRNEWLINE " ) ; } }
int main ( ) { int n = 7 ; printPascal ( n ) ; return 0 ; }
int findCeil ( int arr [ ] , int r , int l , int h ) { int mid ; while ( l < h ) {
mid = l + ( ( h - l ) >> 1 ) ; ( r > arr [ mid ] ) ? ( l = mid + 1 ) : ( h = mid ) ; } return ( arr [ l ] >= r ) ? l : -1 ; }
int myRand ( int arr [ ] , int freq [ ] , int n ) {
int prefix [ n ] , i ; prefix [ 0 ] = freq [ 0 ] ; for ( i = 1 ; i < n ; ++ i ) prefix [ i ] = prefix [ i - 1 ] + freq [ i ] ;
int r = ( rand ( ) % prefix [ n - 1 ] ) + 1 ;
int indexc = findCeil ( prefix , r , 0 , n - 1 ) ; return arr [ indexc ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int freq [ ] = { 10 , 5 , 20 , 100 } ; int i , n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
for ( i = 0 ; i < 5 ; i ++ ) cout << myRand ( arr , freq , n ) << endl ; return 0 ; }
bool isPerfectSquare ( int x ) { int s = sqrt ( x ) ; return ( s * s == x ) ; }
bool isFibonacci ( int n ) {
return isPerfectSquare ( 5 * n * n + 4 ) || isPerfectSquare ( 5 * n * n - 4 ) ; }
int main ( ) { for ( int i = 1 ; i <= 10 ; i ++ ) isFibonacci ( i ) ? cout << i << " ▁ is ▁ a ▁ Fibonacci ▁ Number ▁ STRNEWLINE " : cout << i << " ▁ is ▁ a ▁ not ▁ Fibonacci ▁ Number ▁ STRNEWLINE " ; return 0 ; }
int findTrailingZeros ( int n ) {
int count = 0 ;
for ( int i = 5 ; n / i >= 1 ; i *= 5 ) count += n / i ; return count ; }
int main ( ) { int n = 100 ; cout << " Count ▁ of ▁ trailing ▁ 0s ▁ in ▁ " << 100 << " ! ▁ is ▁ " << findTrailingZeros ( n ) ; return 0 ; }
unsigned long int catalan ( unsigned int n ) {
if ( n <= 1 ) return 1 ;
unsigned long int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) res += catalan ( i ) * catalan ( n - i - 1 ) ; return res ; }
int main ( ) { for ( int i = 0 ; i < 10 ; i ++ ) cout << catalan ( i ) << " ▁ " ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; unsigned long int catalanDP ( unsigned int n ) {
unsigned long int catalan [ n + 1 ] ;
catalan [ 0 ] = catalan [ 1 ] = 1 ;
for ( int i = 2 ; i <= n ; i ++ ) { catalan [ i ] = 0 ; for ( int j = 0 ; j < i ; j ++ ) catalan [ i ] += catalan [ j ] * catalan [ i - j - 1 ] ; }
return catalan [ n ] ; }
int main ( ) { for ( int i = 0 ; i < 10 ; i ++ ) cout << catalanDP ( i ) << " ▁ " ; return 0 ; }
unsigned long int binomialCoeff ( unsigned int n , unsigned int k ) { unsigned long int res = 1 ;
if ( k > n - k ) k = n - k ;
for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
unsigned long int catalan ( unsigned int n ) {
unsigned long int c = binomialCoeff ( 2 * n , n ) ;
return c / ( n + 1 ) ; }
int main ( ) { for ( int i = 0 ; i < 10 ; i ++ ) cout << catalan ( i ) << " ▁ " ; return 0 ; }
void catalan ( int n ) { cpp_int cat_ = 1 ;
cout << cat_ << " ▁ " ;
for ( cpp_int i = 1 ; i < n ; i ++ ) {
cat_ *= ( 4 * i - 2 ) ; cat_ /= ( i + 1 ) ; cout << cat_ << " ▁ " ; } }
int main ( ) { int n = 5 ;
catalan ( n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; void printString ( int n ) { int arr [ 10000 ] ; int i = 0 ;
while ( n ) { arr [ i ] = n % 26 ; n = n / 26 ; i ++ ; }
for ( int j = 0 ; j < i - 1 ; j ++ ) { if ( arr [ j ] <= 0 ) { arr [ j ] += 26 ; arr [ j + 1 ] = arr [ j + 1 ] - 1 ; } } for ( int j = i ; j >= 0 ; j -- ) { if ( arr [ j ] > 0 ) cout << char ( ' A ' + arr [ j ] - 1 ) ; } cout << endl ; }
int main ( ) { printString ( 26 ) ; printString ( 51 ) ; printString ( 52 ) ; printString ( 80 ) ; printString ( 676 ) ; printString ( 702 ) ; printString ( 705 ) ; return 0 ; }
int getInvCount ( int arr [ ] ) { int inv_count = 0 ; for ( int i = 0 ; i < 9 - 1 ; i ++ ) for ( int j = i + 1 ; j < 9 ; j ++ )
if ( arr [ j ] && arr [ i ] && arr [ i ] > arr [ j ] ) inv_count ++ ; return inv_count ; }
bool isSolvable ( int puzzle [ 3 ] [ 3 ] ) {
int invCount = getInvCount ( ( int * ) puzzle ) ;
return ( invCount % 2 == 0 ) ; }
int main ( int argv , char * * args ) { int puzzle [ 3 ] [ 3 ] = { { 1 , 8 , 2 } , { 0 , 4 , 3 } , { 7 , 6 , 5 } } ; isSolvable ( puzzle ) ? cout << " Solvable " : cout << " Not ▁ Solvable " ; return 0 ; }
int find ( double p ) { return ceil ( sqrt ( 2 * 365 * log ( 1 / ( 1 - p ) ) ) ) ; }
int main ( ) { cout << find ( 0.70 ) ; }
int countSolutions ( int n ) { int res = 0 ; for ( int x = 0 ; x * x < n ; x ++ ) for ( int y = 0 ; x * x + y * y < n ; y ++ ) res ++ ; return res ; }
int main ( ) { cout << " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " << countSolutions ( 6 ) << endl ; return 0 ; }
int countSolutions ( int n ) { int x = 0 , yCount , res = 0 ;
for ( yCount = 0 ; yCount * yCount < n ; yCount ++ ) ;
while ( yCount != 0 ) {
res += yCount ;
x ++ ;
while ( yCount != 0 && ( x * x + ( yCount - 1 ) * ( yCount - 1 ) >= n ) ) yCount -- ; } return res ; }
int main ( ) { cout << " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " << countSolutions ( 6 ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX_ITER  1000000
double func ( double x ) { return x * x * x - x * x + 2 ; }
void regulaFalsi ( double a , double b ) { if ( func ( a ) * func ( b ) >= 0 ) { cout << " You ▁ have ▁ not ▁ assumed ▁ right ▁ a ▁ and ▁ b STRNEWLINE " ; return ; }
double c = a ; for ( int i = 0 ; i < MAX_ITER ; i ++ ) {
c = ( a * func ( b ) - b * func ( a ) ) / ( func ( b ) - func ( a ) ) ;
if ( func ( c ) == 0 ) break ;
else if ( func ( c ) * func ( a ) < 0 ) b = c ; else a = c ; } cout << " The ▁ value ▁ of ▁ root ▁ is ▁ : ▁ " << c ; }
double a = -200 , b = 300 ; regulaFalsi ( a , b ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define EPSILON  0.001 NEW_LINE using namespace std ;
double func ( double x ) { return x * x * x - x * x + 2 ; }
double derivFunc ( double x ) { return 3 * x * x - 2 * x ; }
void newtonRaphson ( double x ) { double h = func ( x ) / derivFunc ( x ) ; while ( abs ( h ) >= EPSILON ) { h = func ( x ) / derivFunc ( x ) ;
x = x - h ; } cout << " The ▁ value ▁ of ▁ the ▁ root ▁ is ▁ : ▁ " << x ; }
double x0 = -20 ; newtonRaphson ( x0 ) ; return 0 ; }
bool oppositeSigns ( int x , int y ) { return ( ( x ^ y ) < 0 ) ; }
int main ( ) { int x = 100 , y = -100 ; if ( oppositeSigns ( x , y ) == true ) printf ( " Signs ▁ are ▁ opposite " ) ; else printf ( " Signs ▁ are ▁ not ▁ opposite " ) ; return 0 ; }
unsigned int countSetBits ( unsigned int n ) {
int bitCount = 0 ; for ( int i = 1 ; i <= n ; i ++ ) bitCount += countSetBitsUtil ( i ) ; return bitCount ; }
unsigned int countSetBitsUtil ( unsigned int x ) { if ( x <= 0 ) return 0 ; return ( x % 2 == 0 ? 0 : 1 ) + countSetBitsUtil ( x / 2 ) ; }
int main ( ) { int n = 4 ; printf ( " Total ▁ set ▁ bit ▁ count ▁ is ▁ % d " , countSetBits ( n ) ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countSetBits ( int n ) { int i = 0 ;
int ans = 0 ;
while ( ( 1 << i ) <= n ) {
bool k = 0 ;
int change = 1 << i ;
for ( int j = 0 ; j <= n ; j ++ ) { ans += k ; if ( change == 1 ) {
k = ! k ;
change = 1 << i ; } else { change -- ; } }
i ++ ; } return ans ; }
int main ( ) { int n = 17 ; cout << countSetBits ( n ) << endl ; return 0 ; }
int getSetBitsFromOneToN ( int N ) { int two = 2 , ans = 0 ; int n = N ; while ( n ) { ans += ( N / two ) * ( two >> 1 ) ; if ( ( N & ( two - 1 ) ) > ( two >> 1 ) - 1 ) ans += ( N & ( two - 1 ) ) - ( two >> 1 ) + 1 ; two <<= 1 ; n >>= 1 ; } return ans ; }
#include <iostream> NEW_LINE using namespace std ; int swapBits ( unsigned int num , unsigned int p1 , unsigned int p2 , unsigned int n ) { int shift1 , shift2 , value1 , value2 ; while ( n -- ) {
shift1 = 1 << p1 ;
shift2 = 1 << p2 ;
value1 = ( ( num & shift1 ) ) ; value2 = ( ( num & shift2 ) ) ;
if ( ( ! value1 && value2 ) || ( ! value2 && value1 ) ) {
if ( value1 ) {
num = num & ( ~ shift1 ) ;
num = num | shift2 ; }
else {
num = num & ( ~ shift2 ) ;
num = num | shift1 ; } } p1 ++ ; p2 ++ ; }
return num ; }
int main ( ) { int res = swapBits ( 28 , 0 , 3 , 2 ) ; cout << " Result ▁ = ▁ " << res ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define CHAR_BIT  8
int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHAR_BIT - 1 ) ) ) ; }
int smallest ( int x , int y , int z ) { return min ( x , min ( y , z ) ) ; }
int main ( ) { int x = 12 , y = 15 , z = 5 ; cout << " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ " << smallest ( x , y , z ) ; return 0 ; }
int smallest ( int x , int y , int z ) {
if ( ! ( y / x ) ) return ( ! ( y / z ) ) ? y : z ; return ( ! ( x / z ) ) ? x : z ; }
int main ( ) { int x = 78 , y = 88 , z = 68 ; cout << " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ " << smallest ( x , y , z ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void changeToZero ( int a [ 2 ] ) { a [ a [ 1 ] ] = a [ ! a [ 1 ] ] ; }
int main ( ) { int a [ ] = { 1 , 0 } ; changeToZero ( a ) ; cout << " arr [ 0 ] ▁ = ▁ " << a [ 0 ] << endl ; cout << " ▁ arr [ 1 ] ▁ = ▁ " << a [ 1 ] ; return 0 ; }
uint_t snoob ( uint_t x ) { uint_t rightOne ; uint_t nextHigherOneBit ; uint_t rightOnesPattern ; uint_t next = 0 ; if ( x ) {
rightOne = x & - ( signed ) x ;
nextHigherOneBit = x + rightOne ;
rightOnesPattern = x ^ nextHigherOneBit ;
rightOnesPattern = ( rightOnesPattern ) / rightOne ;
rightOnesPattern >>= 2 ;
next = nextHigherOneBit | rightOnesPattern ; } return next ; }
int main ( ) { int x = 156 ; cout << " Next ▁ higher ▁ number ▁ with ▁ same ▁ number ▁ of ▁ set ▁ bits ▁ is ▁ " << snoob ( x ) ; getchar ( ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE int multiplyWith3Point5 ( int x ) { return ( x << 1 ) + x + ( x >> 1 ) ; }
int main ( ) { int x = 4 ; printf ( " % d " , multiplyWith3Point5 ( x ) ) ; getchar ( ) ; return 0 ; }
int multiplyWith3Point5 ( int x ) { int r = 0 ;
int x1Shift = x << 1 ; int x2Shifts = x << 2 ; r = ( x ^ x1Shift ) ^ x2Shifts ; int c = ( x & x1Shift ) | ( x & x2Shifts ) | ( x1Shift & x2Shifts ) ; while ( c > 0 ) { c <<= 1 ; int t = r ; r ^= c ; c &= t ; }
r = r >> 1 ; return r ; }
int main ( ) { cout << ( multiplyWith3Point5 ( 5 ) ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; bool isPowerOfFour ( unsigned int n ) { return n != 0 && ( ( n & ( n - 1 ) ) == 0 ) && ! ( n & 0xAAAAAAAA ) ; }
int main ( ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) ) cout << test_no << " ▁ is ▁ a ▁ power ▁ of ▁ 4" ; else cout << test_no << " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; float logn ( int n , int r ) { return log ( n ) / log ( r ) ; } bool isPowerOfFour ( int n ) {
if ( n == 0 ) return false ; return floor ( logn ( n , 4 ) ) == ceil ( logn ( n , 4 ) ) ; }
int main ( ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) ) cout << test_no << " ▁ is ▁ a ▁ power ▁ of ▁ 4" ; else cout << test_no << " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
void findPostOrderUtil ( int pre [ ] , int n , int minval , int maxval , int & preIndex ) {
if ( preIndex == n ) return ;
if ( pre [ preIndex ] < minval pre [ preIndex ] > maxval ) { return ; }
int val = pre [ preIndex ] ; preIndex ++ ;
findPostOrderUtil ( pre , n , minval , val , preIndex ) ;
findPostOrderUtil ( pre , n , val , maxval , preIndex ) ; cout << val << " ▁ " ; }
void findPostOrder ( int pre [ ] , int n ) {
int preIndex = 0 ; findPostOrderUtil ( pre , n , INT_MIN , INT_MAX , preIndex ) ; }
int main ( ) { int pre [ ] = { 40 , 30 , 35 , 80 , 100 } ; int n = sizeof ( pre ) / sizeof ( pre [ 0 ] ) ;
findPostOrder ( pre , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int isPowerOfFour ( int n ) { return ( n > 0 and pow ( 4 , int ( log2 ( n ) / log2 ( 4 ) ) == n ) ) ; }
int main ( ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) ) cout << test_no << " ▁ is ▁ a ▁ power ▁ of ▁ 4" ; else cout << test_no << " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ; return 0 ; }
unsigned int getModulo ( unsigned int n , unsigned int d ) { return ( n & ( d - 1 ) ) ; }
int main ( ) { unsigned int n = 6 ;
unsigned int d = 4 ; printf ( " % u ▁ moduo ▁ % u ▁ is ▁ % u " , n , d , getModulo ( n , d ) ) ; getchar ( ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define CHARBIT  8
int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHARBIT - 1 ) ) ) ; }
int max ( int x , int y ) { return x - ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHARBIT - 1 ) ) ) ; }
int main ( ) { int x = 15 ; int y = 6 ; cout << " Minimum ▁ of ▁ " << x << " ▁ and ▁ " << y << " ▁ is ▁ " ; cout << min ( x , y ) ; cout << " Maximum of " < < x < < " and " < < y < < " is " cout << max ( x , y ) ; }
int absbit32 ( int x , int y ) { int sub = x - y ; int mask = ( sub >> 31 ) ; return ( sub ^ mask ) - mask ; }
int max ( int x , int y ) { int abs = absbit32 ( x , y ) ; return ( x + y + abs ) / 2 ; }
int min ( int x , int y ) { int abs = absbit32 ( x , y ) ; return ( x + y - abs ) / 2 ; }
int main ( ) { cout << max ( 2 , 3 ) << endl ; cout << max ( 2 , -3 ) << endl ; cout << max ( -2 , -3 ) << endl ; cout << min ( 2 , 3 ) << endl ; cout << min ( 2 , -3 ) << endl ; cout << min ( -2 , -3 ) << endl ; return 0 ; }
int getOddOccurrence ( int arr [ ] , int arr_size ) { for ( int i = 0 ; i < arr_size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < arr_size ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; } if ( count % 2 != 0 ) return arr [ i ] ; } return -1 ; }
int main ( ) { int arr [ ] = { 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
cout << getOddOccurrence ( arr , n ) ; return 0 ; }
int getOddOccurrence ( int arr [ ] , int size ) { unordered_map < int , int > hash ;
for ( int i = 0 ; i < size ; i ++ ) { hash [ arr [ i ] ] ++ ; }
for ( auto i : hash ) { if ( i . second % 2 != 0 ) { return i . first ; } } return -1 ; }
int main ( ) { int arr [ ] = { 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << getOddOccurrence ( arr , n ) ; return 0 ; }
int fastPow ( int N , int K ) { if ( K == 0 ) return 1 ; int temp = fastPow ( N , K / 2 ) ; if ( K % 2 == 0 ) return temp * temp ; else return N * temp * temp ; } int countWays ( int N , int K ) { return K * fastPow ( K - 1 , N - 1 ) ; }
int main ( ) { int N = 3 , K = 3 ; cout << countWays ( N , K ) ; return 0 ; }
int countSetBits ( int n ) {
if ( n == 0 ) return 0 ; else return 1 + countSetBits ( n & ( n - 1 ) ) ; }
int n = 9 ;
cout << countSetBits ( n ) ; return 0 ; }
int BitsSetTable256 [ 256 ] ;
void initialize ( ) {
BitsSetTable256 [ 0 ] = 0 ; for ( int i = 0 ; i < 256 ; i ++ ) { BitsSetTable256 [ i ] = ( i & 1 ) + BitsSetTable256 [ i / 2 ] ; } }
int countSetBits ( int n ) { return ( BitsSetTable256 [ n & 0xff ] + BitsSetTable256 [ ( n >> 8 ) & 0xff ] + BitsSetTable256 [ ( n >> 16 ) & 0xff ] + BitsSetTable256 [ n >> 24 ] ) ; }
initialize ( ) ; int n = 9 ; cout << countSetBits ( n ) ; }
using namespace std ; int main ( ) { cout << __builtin_popcount ( 4 ) << endl ; cout << __builtin_popcount ( 15 ) ; return 0 ; }
int countSetBits ( int N ) { int count = 0 ;
for ( int i = 0 ; i < sizeof ( int ) * 8 ; i ++ ) { if ( N & ( 1 << i ) ) count ++ ; } return count ; }
int main ( ) { int N = 15 ; cout << countSetBits ( N ) << endl ; return 0 ; }
int countSetBits ( int n ) { int count = 0 ; while ( n > 0 ) { count ++ ; n &= ( n - 1 ) ; } return count ; }
int FlippedCount ( int a , int b ) {
return countSetBits ( a ^ b ) ; }
int main ( ) { int a = 10 ; int b = 20 ; cout << FlippedCount ( a , b ) << endl ; return 0 ; }
bool powerOf2 ( int n ) {
if ( n == 1 ) return true ;
else if ( n % 2 != 0 n == 0 ) return false ;
return powerOf2 ( n / 2 ) ; }
int n = 64 ;
int m = 12 ; if ( powerOf2 ( n ) == 1 ) cout << " True " << endl ; else cout << " False " << endl ; if ( powerOf2 ( m ) == 1 ) cout << " True " << endl ; else cout << " False " << endl ; }
int PositionRightmostSetbit ( int n ) {
int position = 1 ; int m = 1 ; while ( ! ( n & m ) ) {
m = m << 1 ; position ++ ; } return position ; }
int main ( ) { int n = 16 ;
cout << PositionRightmostSetbit ( n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; #define INT_SIZE  32 NEW_LINE int Right_most_setbit ( int num ) {
for ( int i = 0 ; i < INT_SIZE ; i ++ ) { if ( ! ( num & ( 1 << i ) ) ) pos ++ ; else break ; } return pos ; } }
int main ( ) { int num = 0 ; int pos = Right_most_setbit ( num ) ; cout << pos << endl ; return 0 ; }
int PositionRightmostSetbit ( int n ) { int p = 1 ;
while ( n > 0 ) {
if ( n & 1 ) { return p ; }
p ++ ; n = n >> 1 ; }
return -1 ; }
int main ( ) { int n = 18 ;
int pos = PositionRightmostSetbit ( n ) ; if ( pos != -1 ) cout << pos ; else cout << 0 ; return 0 ; }
void bin ( long n ) { long i ; cout << "0" ; for ( i = 1 << 30 ; i > 0 ; i = i / 2 ) { if ( ( n & i ) != 0 ) { cout << "1" ; } else { cout << "0" ; } } }
int main ( void ) { bin ( 7 ) ; cout << endl ; bin ( 4 ) ; }
void bin ( unsigned n ) { if ( n > 1 ) bin ( n >> 1 ) ; printf ( " % d " , n & 1 ) ; }
int main ( void ) { bin ( 131 ) ; printf ( " STRNEWLINE " ) ; bin ( 3 ) ; return 0 ; }
void swap ( int & a , int & b ) {
a = ( a & b ) + ( a b ) ;
b = a + ( ~ b ) + 1 ;
a = a + ( ~ b ) + 1 ; cout << " After ▁ swapping : ▁ a ▁ = ▁ " << a << " , ▁ b ▁ = ▁ " << b ; }
int main ( ) { int a = 5 , b = 10 ;
swap ( a , b ) ; return 0 ; }
bool checkSentence ( char str [ ] ) {
int len = strlen ( str ) ;
if ( str [ 0 ] < ' A ' str [ 0 ] > ' Z ' ) return false ;
if ( str [ len - 1 ] != ' . ' ) return false ;
int prev_state = 0 , curr_state = 0 ;
int index = 1 ;
while ( str [ index ] ) {
if ( str [ index ] >= ' A ' && str [ index ] <= ' Z ' ) curr_state = 0 ;
else if ( str [ index ] == ' ▁ ' ) curr_state = 1 ;
else if ( str [ index ] >= ' a ' && str [ index ] <= ' z ' ) curr_state = 2 ;
else if ( str [ index ] == ' . ' ) curr_state = 3 ;
if ( prev_state == curr_state && curr_state != 2 ) return false ; if ( prev_state == 2 && curr_state == 0 ) return false ;
if ( curr_state == 3 && prev_state != 1 ) return ( str [ index + 1 ] == ' \0' ) ; index ++ ;
prev_state = curr_state ; } return false ; }
int main ( ) { char * str [ ] = { " I ▁ love ▁ cinema . " , " The ▁ vertex ▁ is ▁ S . " , " I ▁ am ▁ single . " , " My ▁ name ▁ is ▁ KG . " , " I ▁ lovE ▁ cinema . " , " GeeksQuiz . ▁ is ▁ a ▁ quiz ▁ site . " , " I ▁ love ▁ Geeksquiz ▁ and ▁ Geeksforgeeks . " , " ▁ You ▁ are ▁ my ▁ friend . " , " I ▁ love ▁ cinema " } ; int str_size = sizeof ( str ) / sizeof ( str [ 0 ] ) ; int i = 0 ; for ( i = 0 ; i < str_size ; i ++ ) checkSentence ( str [ i ] ) ? printf ( " \" % s \" ▁ is ▁ correct ▁ STRNEWLINE " , str [ i ] ) : printf ( " \" % s \" ▁ is ▁ incorrect ▁ STRNEWLINE " , str [ i ] ) ; return 0 ; }
int maxOnesIndex ( bool arr [ ] , int n ) {
int max_count = 0 ;
int max_index ;
int prev_zero = -1 ;
int prev_prev_zero = -1 ;
for ( int curr = 0 ; curr < n ; ++ curr ) {
if ( arr [ curr ] == 0 ) {
if ( curr - prev_prev_zero > max_count ) { max_count = curr - prev_prev_zero ; max_index = prev_zero ; }
prev_prev_zero = prev_zero ; prev_zero = curr ; } }
if ( n - prev_prev_zero > max_count ) max_index = prev_zero ; return max_index ; }
int main ( ) { bool arr [ ] = { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Index ▁ of ▁ 0 ▁ to ▁ be ▁ replaced ▁ is ▁ " << maxOnesIndex ( arr , n ) ; return 0 ; }
int min ( int x , int y ) { return ( x < y ) ? x : y ; } int max ( int x , int y ) { return ( x > y ) ? x : y ; }
int findLength ( int arr [ ] , int n ) {
int max_len = 1 ; for ( int i = 0 ; i < n - 1 ; i ++ ) {
int mn = arr [ i ] , mx = arr [ i ] ;
for ( int j = i + 1 ; j < n ; j ++ ) {
mn = min ( mn , arr [ j ] ) ; mx = max ( mx , arr [ j ] ) ;
if ( ( mx - mn ) == j - i ) max_len = max ( max_len , mx - mn + 1 ) ; } }
return max_len ; }
int main ( ) { int arr [ ] = { 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Length ▁ of ▁ the ▁ longest ▁ contiguous ▁ subarray ▁ is ▁ " << findLength ( arr , n ) ; return 0 ; }
void printArr ( int arr [ ] , int k ) { for ( int i = 0 ; i < k ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << endl ; }
void printSeqUtil ( int n , int k , int & len , int arr [ ] ) {
if ( len == k ) { printArr ( arr , k ) ; return ; }
int i = ( len == 0 ) ? 1 : arr [ len - 1 ] + 1 ;
len ++ ;
while ( i <= n ) { arr [ len - 1 ] = i ; printSeqUtil ( n , k , len , arr ) ; i ++ ; }
len -- ; }
void printSeq ( int n , int k ) {
int arr [ k ] ;
int len = 0 ; printSeqUtil ( n , k , len , arr ) ; }
int main ( ) { int k = 3 , n = 7 ; printSeq ( n , k ) ; return 0 ; }
bool isSubSequence ( char str1 [ ] , char str2 [ ] , int m , int n ) {
if ( m == 0 ) return true ; if ( n == 0 ) return false ;
if ( str1 [ m - 1 ] == str2 [ n - 1 ] ) return isSubSequence ( str1 , str2 , m - 1 , n - 1 ) ;
return isSubSequence ( str1 , str2 , m , n - 1 ) ; }
int main ( ) { char str1 [ ] = " gksrek " ; char str2 [ ] = " geeksforgeeks " ; int m = strlen ( str1 ) ; int n = strlen ( str2 ) ; isSubSequence ( str1 , str2 , m , n ) ? cout << " Yes ▁ " : cout << " No " ; return 0 ; }
void segregate0and1 ( int arr [ ] , int n ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 0 ) count ++ ; }
for ( int i = 0 ; i < count ; i ++ ) arr [ i ] = 0 ;
for ( int i = count ; i < n ; i ++ ) arr [ i ] = 1 ; }
void print ( int arr [ ] , int n ) { cout << " Array ▁ after ▁ segregation ▁ is ▁ " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 1 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; segregate0and1 ( arr , n ) ; print ( arr , n ) ; return 0 ; }
void segregate0and1 ( int arr [ ] , int size ) { int type0 = 0 ; int type1 = size - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { swap ( arr [ type0 ] , arr [ type1 ] ) ; type1 -- ; } else type0 ++ ; } }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 1 , 1 , 1 } ; int i , arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; segregate0and1 ( arr , arr_size ) ; cout << " Array ▁ after ▁ segregation ▁ is ▁ " ; for ( i = 0 ; i < arr_size ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
void find3Numbers ( vector < int > & nums ) {
if ( nums . size ( ) < 3 ) { cout << " No ▁ such ▁ triplet ▁ found " ; return ; }
int seq = 1 ;
int min_num = nums [ 0 ] ;
int max_seq = INT_MIN ;
int store_min = min_num ;
for ( int i = 1 ; i < nums . size ( ) ; i ++ ) { if ( nums [ i ] == min_num ) continue ; else if ( nums [ i ] < min_num ) { min_num = nums [ i ] ; continue ; }
else if ( nums [ i ] < max_seq ) {
max_seq = nums [ i ] ;
store_min = min_num ; }
else if ( nums [ i ] > max_seq ) { seq ++ ;
if ( seq == 3 ) { cout << " Triplet : ▁ " << store_min << " , ▁ " << max_seq << " , ▁ " << nums [ i ] << endl ; return ; } max_seq = nums [ i ] ; } }
cout << " No ▁ such ▁ triplet ▁ found " ; }
int main ( ) { vector < int > nums { 1 , 2 , -1 , 7 , 5 } ;
find3Numbers ( nums ) ; }
int maxSubarrayProduct ( int arr [ ] , int n ) {
int result = arr [ 0 ] ; for ( int i = 0 ; i < n ; i ++ ) { int mul = arr [ i ] ;
for ( int j = i + 1 ; j < n ; j ++ ) {
result = max ( result , mul ) ; mul *= arr [ j ] ; }
result = max ( result , mul ) ; } return result ; }
int main ( ) { int arr [ ] = { 1 , -2 , -3 , 0 , 7 , -8 , -2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Maximum ▁ Sub ▁ array ▁ product ▁ is ▁ " << maxSubarrayProduct ( arr , n ) ; return 0 ; }
int maxCircularSum ( int a [ ] , int n ) {
if ( n == 1 ) return a [ 0 ] ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum += a [ i ] ; }
int curr_max = a [ 0 ] , max_so_far = a [ 0 ] , curr_min = a [ 0 ] , min_so_far = a [ 0 ] ;
for ( int i = 1 ; i < n ; i ++ ) {
curr_max = max ( curr_max + a [ i ] , a [ i ] ) ; max_so_far = max ( max_so_far , curr_max ) ;
curr_min = min ( curr_min + a [ i ] , a [ i ] ) ; min_so_far = min ( min_so_far , curr_min ) ; } if ( min_so_far == sum ) return max_so_far ;
return max ( max_so_far , sum - min_so_far ) ; }
int main ( ) { int a [ ] = { 11 , 10 , -20 , 5 , -3 , -5 , 8 , -13 , 10 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << " Maximum ▁ circular ▁ sum ▁ is ▁ " << maxCircularSum ( a , n ) << endl ; return 0 ; }
int GetCeilIndex ( int arr [ ] , vector < int > & T , int l , int r , int key ) { while ( r - l > 1 ) { int m = l + ( r - l ) / 2 ; if ( arr [ T [ m ] ] >= key ) r = m ; else l = m ; } return r ; } int LongestIncreasingSubsequence ( int arr [ ] , int n ) {
vector < int > tailIndices ( n , 0 ) ;
vector < int > prevIndices ( n , -1 ) ;
int len = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ tailIndices [ 0 ] ] ) {
tailIndices [ 0 ] = i ; } else if ( arr [ i ] > arr [ tailIndices [ len - 1 ] ] ) {
prevIndices [ i ] = tailIndices [ len - 1 ] ; tailIndices [ len ++ ] = i ; } else {
int pos = GetCeilIndex ( arr , tailIndices , -1 , len - 1 , arr [ i ] ) ; prevIndices [ i ] = tailIndices [ pos - 1 ] ; tailIndices [ pos ] = i ; } } cout << " LIS ▁ of ▁ given ▁ input " << endl ; for ( int i = tailIndices [ len - 1 ] ; i >= 0 ; i = prevIndices [ i ] ) cout << arr [ i ] << " ▁ " ; cout << endl ; return len ; }
int main ( ) { int arr [ ] = { 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " LIS ▁ size ▁ % d STRNEWLINE " , LongestIncreasingSubsequence ( arr , n ) ) ; return 0 ; }
int maxSum ( int arr [ ] , int n ) { int sum = 0 ;
sort ( arr , arr + n ) ;
for ( int i = 0 ; i < n / 2 ; i ++ ) { sum -= ( 2 * arr [ i ] ) ; sum += ( 2 * arr [ n - i - 1 ] ) ; } return sum ; }
int main ( ) { int arr [ ] = { 4 , 2 , 1 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxSum ( arr , n ) << endl ; return 0 ; }
void threeWayPartition ( int arr [ ] , int n , int lowVal , int highVal ) {
int start = 0 , end = n - 1 ;
for ( int i = 0 ; i <= end ; ) {
if ( arr [ i ] < lowVal ) swap ( arr [ i ++ ] , arr [ start ++ ] ) ;
else if ( arr [ i ] > highVal ) swap ( arr [ i ] , arr [ end -- ] ) ; else i ++ ; } }
int main ( ) { int arr [ ] = { 1 , 14 , 5 , 20 , 4 , 2 , 54 , 20 , 87 , 98 , 3 , 1 , 32 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; threeWayPartition ( arr , n , 10 , 20 ) ; cout << " Modified ▁ array ▁ STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
void generateUtil ( int A [ ] , int B [ ] , int C [ ] , int i , int j , int m , int n , int len , bool flag ) {
if ( flag ) {
if ( len ) printArr ( C , len + 1 ) ;
for ( int k = i ; k < m ; k ++ ) { if ( ! len ) {
C [ len ] = A [ k ] ;
generateUtil ( A , B , C , k + 1 , j , m , n , len , ! flag ) ; } else
{ if ( A [ k ] > C [ len ] ) { C [ len + 1 ] = A [ k ] ; generateUtil ( A , B , C , k + 1 , j , m , n , len + 1 , ! flag ) ; } } } } else
{ for ( int l = j ; l < n ; l ++ ) { if ( B [ l ] > C [ len ] ) { C [ len + 1 ] = B [ l ] ; generateUtil ( A , B , C , i , l + 1 , m , n , len + 1 , ! flag ) ; } } } }
void generate ( int A [ ] , int B [ ] , int m , int n ) { int C [ m + n ] ;
generateUtil ( A , B , C , 0 , 0 , m , n , 0 , true ) ; }
void printArr ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << endl ; }
int main ( ) { int A [ ] = { 10 , 15 , 25 } ; int B [ ] = { 5 , 20 , 30 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; int m = sizeof ( B ) / sizeof ( B [ 0 ] ) ; generate ( A , B , n , m ) ; return 0 ; }
void updateindex ( int index [ ] , int a , int ai , int b , int bi ) { index [ a ] = ai ; index [ b ] = bi ; }
int minSwapsUtil ( int arr [ ] , int pairs [ ] , int index [ ] , int i , int n ) {
if ( i > n ) return 0 ;
if ( pairs [ arr [ i ] ] == arr [ i + 1 ] ) return minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
int one = arr [ i + 1 ] ; int indextwo = i + 1 ; int indexone = index [ pairs [ arr [ i ] ] ] ; int two = arr [ index [ pairs [ arr [ i ] ] ] ] ; swap ( arr [ i + 1 ] , arr [ indexone ] ) ; updateindex ( index , one , indexone , two , indextwo ) ; int a = minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
swap ( arr [ i + 1 ] , arr [ indexone ] ) ; updateindex ( index , one , indextwo , two , indexone ) ; one = arr [ i ] , indexone = index [ pairs [ arr [ i + 1 ] ] ] ;
two = arr [ index [ pairs [ arr [ i + 1 ] ] ] ] , indextwo = i ; swap ( arr [ i ] , arr [ indexone ] ) ; updateindex ( index , one , indexone , two , indextwo ) ; int b = minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
swap ( arr [ i ] , arr [ indexone ] ) ; updateindex ( index , one , indextwo , two , indexone ) ;
return 1 + min ( a , b ) ; }
int minSwaps ( int n , int pairs [ ] , int arr [ ] ) {
int index [ 2 * n + 1 ] ;
for ( int i = 1 ; i <= 2 * n ; i ++ ) index [ arr [ i ] ] = i ;
return minSwapsUtil ( arr , pairs , index , 1 , 2 * n ) ; }
int arr [ ] = { 0 , 3 , 5 , 6 , 4 , 1 , 2 } ;
int pairs [ ] = { 0 , 3 , 6 , 1 , 5 , 4 , 2 } ; int m = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
int n = m / 2 ;
cout << " Min ▁ swaps ▁ required ▁ is ▁ " << minSwaps ( n , pairs , arr ) ; return 0 ; }
void replace_elements ( int arr [ ] , int n ) {
int pos = 0 ; for ( int i = 0 ; i < n ; i ++ ) { arr [ pos ++ ] = arr [ i ] ; while ( pos > 1 && arr [ pos - 2 ] == arr [ pos - 1 ] ) { pos -- ; arr [ pos - 1 ] ++ ; } }
for ( int i = 0 ; i < pos ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 6 , 4 , 3 , 4 , 3 , 3 , 5 } ; int n = sizeof ( arr ) / sizeof ( int ) ; replace_elements ( arr , n ) ; return 0 ; }
void arrangeString ( string str , int x , int y ) { int count_0 = 0 ; int count_1 = 0 ; int len = str . length ( ) ;
for ( int i = 0 ; i < len ; i ++ ) { if ( str [ i ] == '0' ) count_0 ++ ; else count_1 ++ ; }
while ( count_0 > 0 count_1 > 0 ) { for ( int j = 0 ; j < x && count_0 > 0 ; j ++ ) { if ( count_0 > 0 ) { cout << "0" ; count_0 -- ; } } for ( int j = 0 ; j < y && count_1 > 0 ; j ++ ) { if ( count_1 > 0 ) { cout << "1" ; count_1 -- ; } } } }
int main ( ) { string str = "01101101101101101000000" ; int x = 1 ; int y = 2 ; arrangeString ( str , x , y ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void distinctAdjacentElement ( int a [ ] , int n ) {
map < int , int > m ;
for ( int i = 0 ; i < n ; ++ i ) m [ a [ i ] ] ++ ;
int mx = 0 ;
for ( int i = 0 ; i < n ; ++ i ) if ( mx < m [ a [ i ] ] ) mx = m [ a [ i ] ] ;
if ( mx > ( n + 1 ) / 2 ) cout << " NO " << endl ; else cout << " YES " << endl ; }
int main ( ) { int a [ ] = { 7 , 7 , 7 , 7 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; distinctAdjacentElement ( a , n ) ; return 0 ; }
void rearrange ( int arr [ ] , int n ) {
if ( arr == NULL n % 2 == 1 ) return ;
int currIdx = ( n - 1 ) / 2 ;
while ( currIdx > 0 ) { int count = currIdx , swapIdx = currIdx ; while ( count -- > 0 ) { int temp = arr [ swapIdx + 1 ] ; arr [ swapIdx + 1 ] = arr [ swapIdx ] ; arr [ swapIdx ] = temp ; swapIdx ++ ; } currIdx -- ; } }
int main ( ) { int arr [ ] = { 1 , 3 , 5 , 2 , 4 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; rearrange ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << " ▁ " << arr [ i ] ; }
int maxDiff ( int arr [ ] , int n ) {
int maxDiff = -1 ;
int maxRight = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) { if ( arr [ i ] > maxRight ) maxRight = arr [ i ] ; else { int diff = maxRight - arr [ i ] ; if ( diff > maxDiff ) { maxDiff = diff ; } } } return maxDiff ; }
int main ( ) { int arr [ ] = { 1 , 2 , 90 , 10 , 110 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
cout << " Maximum ▁ difference ▁ is ▁ " << maxDiff ( arr , n ) ; return 0 ; }
int maxDiff ( int arr [ ] , int n ) {
int diff = arr [ 1 ] - arr [ 0 ] ; int curr_sum = diff ; int max_sum = curr_sum ; for ( int i = 1 ; i < n - 1 ; i ++ ) {
diff = arr [ i + 1 ] - arr [ i ] ;
if ( curr_sum > 0 ) curr_sum += diff ; else curr_sum = diff ;
if ( curr_sum > max_sum ) max_sum = curr_sum ; } return max_sum ; }
int main ( ) { int arr [ ] = { 80 , 2 , 6 , 3 , 100 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
cout << " Maximum ▁ difference ▁ is ▁ " << maxDiff ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int main ( ) { vector < long long int > v { 34 , 8 , 10 , 3 , 2 , 80 , 30 , 33 , 1 } ; int n = v . size ( ) ; vector < long long int > maxFromEnd ( n + 1 , INT_MIN ) ;
for ( int i = v . size ( ) - 1 ; i >= 0 ; i -- ) { maxFromEnd [ i ] = max ( maxFromEnd [ i + 1 ] , v [ i ] ) ; } int result = 0 ; for ( int i = 0 ; i < v . size ( ) ; i ++ ) { int low = i + 1 , high = v . size ( ) - 1 , ans = i ; while ( low <= high ) { int mid = ( low + high ) / 2 ; if ( v [ i ] <= maxFromEnd [ mid ] ) {
ans = max ( ans , mid ) ; low = mid + 1 ; } else { high = mid - 1 ; } }
result = max ( result , ans - i ) ; } cout << result << endl ; }
#include <iostream> NEW_LINE using namespace std ; void getPostOrderBST ( int pre [ ] , int N ) { int pivotPoint = 0 ;
for ( int i = 1 ; i < N ; i ++ ) { if ( pre [ 0 ] <= pre [ i ] ) { pivotPoint = i ; break ; } }
for ( int i = pivotPoint - 1 ; i > 0 ; i -- ) { cout << pre [ i ] << " ▁ " ; }
for ( int i = N - 1 ; i >= pivotPoint ; i -- ) { cout << pre [ i ] << " ▁ " ; } cout << pre [ 0 ] ; }
#include <iostream> NEW_LINE using namespace std ; void constructLowerArray ( int arr [ ] , int * countSmaller , int n ) { int i , j ;
for ( i = 0 ; i < n ; i ++ ) countSmaller [ i ] = 0 ; for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < arr [ i ] ) countSmaller [ i ] ++ ; } } }
void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) cout << arr [ i ] << " ▁ " ; cout << " STRNEWLINE " ; }
int main ( ) { int arr [ ] = { 12 , 10 , 5 , 4 , 2 , 20 , 6 , 1 , 0 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int * low = ( int * ) malloc ( sizeof ( int ) * n ) ; constructLowerArray ( arr , low , n ) ; printArray ( low , n ) ; return 0 ; }
int segregate ( int arr [ ] , int size ) { int j = 0 , i ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] <= 0 ) { swap ( & arr [ i ] , & arr [ j ] ) ;
j ++ ; } } return j ; }
int findMissingPositive ( int arr [ ] , int size ) { int i ;
for ( i = 0 ; i < size ; i ++ ) { if ( abs ( arr [ i ] ) - 1 < size && arr [ abs ( arr [ i ] ) - 1 ] > 0 ) arr [ abs ( arr [ i ] ) - 1 ] = - arr [ abs ( arr [ i ] ) - 1 ] ; }
for ( i = 0 ; i < size ; i ++ ) if ( arr [ i ] > 0 )
return i + 1 ; return size + 1 ; }
int findMissing ( int arr [ ] , int size ) {
int shift = segregate ( arr , size ) ;
return findMissingPositive ( arr + shift , size - shift ) ; }
int main ( ) { int arr [ ] = { 0 , 10 , 2 , -10 , -20 } ; int arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int missing = findMissing ( arr , arr_size ) ; cout << " The ▁ smallest ▁ positive ▁ missing ▁ number ▁ is ▁ " << missing ; return 0 ; }
int firstMissingPositive ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) {
while ( arr [ i ] >= 1 && arr [ i ] <= n && arr [ i ] != arr [ arr [ i ] - 1 ] ) { swap ( arr [ i ] , arr [ arr [ i ] - 1 ] ) ; } }
for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] != i + 1 ) { return i + 1 ; } }
return n + 1 ; }
int main ( ) { int arr [ ] = { 2 , 3 , -7 , 6 , 8 , 1 , -10 , 15 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int ans = firstMissingPositive ( arr , n ) ; cout << ans ; return 0 ; }
void fillDepth ( int parent [ ] , int i , int depth [ ] ) {
if ( depth [ i ] ) return ;
if ( parent [ i ] == -1 ) { depth [ i ] = 1 ; return ; }
if ( depth [ parent [ i ] ] == 0 ) fillDepth ( parent , parent [ i ] , depth ) ;
depth [ i ] = depth [ parent [ i ] ] + 1 ; }
int findHeight ( int parent [ ] , int n ) {
int depth [ n ] ; for ( int i = 0 ; i < n ; i ++ ) depth [ i ] = 0 ;
for ( int i = 0 ; i < n ; i ++ ) fillDepth ( parent , i , depth ) ;
int ht = depth [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) if ( ht < depth [ i ] ) ht = depth [ i ] ; return ht ; }
int parent [ ] = { -1 , 0 , 0 , 1 , 1 , 3 , 5 } ; int n = sizeof ( parent ) / sizeof ( parent [ 0 ] ) ; cout << " Height ▁ is ▁ " << findHeight ( parent , n ) ; return 0 ; }
int maxRepeating ( int * arr , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) arr [ arr [ i ] % k ] += k ;
int max = arr [ 0 ] , result = 0 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; result = i ; } }
return result ; }
int main ( ) { int arr [ ] = { 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 8 ; cout << " The ▁ maximum ▁ repeating ▁ number ▁ is ▁ " << maxRepeating ( arr , n , k ) << endl ; return 0 ; }
int max ( int x , int y ) { return ( x > y ) ? x : y ; }
int maxPathSum ( int ar1 [ ] , int ar2 [ ] , int m , int n ) {
int i = 0 , j = 0 ;
int result = 0 , sum1 = 0 , sum2 = 0 ;
while ( i < m && j < n ) {
if ( ar1 [ i ] < ar2 [ j ] ) sum1 += ar1 [ i ++ ] ;
else if ( ar1 [ i ] > ar2 [ j ] ) sum2 += ar2 [ j ++ ] ;
else {
result += max ( sum1 , sum2 ) + ar1 [ i ] ;
sum1 = 0 ; sum2 = 0 ;
i ++ ; j ++ ; } }
while ( i < m ) sum1 += ar1 [ i ++ ] ;
while ( j < n ) sum2 += ar2 [ j ++ ] ;
result += max ( sum1 , sum2 ) ; return result ; }
int main ( ) { int ar1 [ ] = { 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 } ; int ar2 [ ] = { 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 } ; int m = sizeof ( ar1 ) / sizeof ( ar1 [ 0 ] ) ; int n = sizeof ( ar2 ) / sizeof ( ar2 [ 0 ] ) ;
cout << " Maximum ▁ sum ▁ path ▁ is ▁ " << maxPathSum ( ar1 , ar2 , m , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void smallestGreater ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) {
int diff = INT_MAX , closest = -1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] < arr [ j ] && arr [ j ] - arr [ i ] < diff ) { diff = arr [ j ] - arr [ i ] ; closest = j ; } }
( closest == -1 ) ? cout << " _ ▁ " : cout << arr [ closest ] << " ▁ " ; } }
int main ( ) { int ar [ ] = { 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; smallestGreater ( ar , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void smallestGreater ( int arr [ ] , int n ) { set < int > s ; for ( int i = 0 ; i < n ; i ++ ) s . insert ( arr [ i ] ) ; for ( int i = 0 ; i < n ; i ++ ) { auto it = s . find ( arr [ i ] ) ; it ++ ; if ( it != s . end ( ) ) cout << * it << " ▁ " ; else cout << " _ ▁ " ; } }
int main ( ) { int ar [ ] = { 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; smallestGreater ( ar , n ) ; return 0 ; }
void findZeroes ( int arr [ ] , int n , int m ) {
int wL = 0 , wR = 0 ;
int bestL = 0 , bestWindow = 0 ;
int zeroCount = 0 ;
while ( wR < n ) {
if ( zeroCount <= m ) { if ( arr [ wR ] == 0 ) zeroCount ++ ; wR ++ ; }
if ( zeroCount > m ) { if ( arr [ wL ] == 0 ) zeroCount -- ; wL ++ ; }
if ( ( wR - wL > bestWindow ) && ( zeroCount <= m ) ) { bestWindow = wR - wL ; bestL = wL ; } }
for ( int i = 0 ; i < bestWindow ; i ++ ) { if ( arr [ bestL + i ] == 0 ) cout << bestL + i << " ▁ " ; } }
int main ( ) { int arr [ ] = { 1 , 0 , 0 , 1 , 1 , 0 , 1 , 0 , 1 , 1 } ; int m = 2 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Indexes ▁ of ▁ zeroes ▁ to ▁ be ▁ flipped ▁ are ▁ " ; findZeroes ( arr , n , m ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countIncreasing ( int arr [ ] , int n ) {
int cnt = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] > arr [ j - 1 ] ) cnt ++ ;
else break ; } } return cnt ; }
int main ( ) { int arr [ ] = { 1 , 2 , 2 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is ▁ " << countIncreasing ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countIncreasing ( int arr [ ] , int n ) {
int cnt = 0 ;
int len = 1 ;
for ( int i = 0 ; i < n - 1 ; ++ i ) {
if ( arr [ i + 1 ] > arr [ i ] ) len ++ ;
else { cnt += ( ( ( len - 1 ) * len ) / 2 ) ; len = 1 ; } }
if ( len > 1 ) cnt += ( ( ( len - 1 ) * len ) / 2 ) ; return cnt ; }
int main ( ) { int arr [ ] = { 1 , 2 , 2 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is ▁ " << countIncreasing ( arr , n ) ; return 0 ; }
long long int arraySum ( int arr [ ] , int n ) { long long int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + arr [ i ] ; return sum ; }
long long int maxDiff ( int arr [ ] , int n , int k ) {
sort ( arr , arr + n ) ;
long long int arraysum = arraySum ( arr , n ) ;
long long int diff1 = abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
reverse ( arr , arr + n ) ;
long long int diff2 = abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
return ( max ( diff1 , diff2 ) ) ; }
int main ( ) { int arr [ ] = { 1 , 7 , 4 , 8 , -1 , 5 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; cout << " Maximum ▁ Difference ▁ = ▁ " << maxDiff ( arr , n , k ) ; return 0 ; }
int minNumber ( int a [ ] , int n , int x ) {
sort ( a , a + n ) ; int k ; for ( k = 0 ; a [ ( n - 1 ) / 2 ] != x ; k ++ ) { a [ n ++ ] = x ; sort ( a , a + n ) ; } return k ; }
int main ( ) { int x = 10 ; int a [ 6 ] = { 10 , 20 , 30 } ; int n = 3 ; cout << minNumber ( a , n , x ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int minNumber ( int a [ ] , int n , int x ) { int l = 0 , h = 0 , e = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == x ) e ++ ;
else if ( a [ i ] > x ) h ++ ;
else if ( a [ i ] < x ) l ++ ; } int ans = 0 ; if ( l > h ) ans = l - h ; else if ( l < h ) ans = h - l - 1 ;
return ans + 1 - e ; }
int main ( ) { int x = 10 ; int a [ ] = { 10 , 20 , 30 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << minNumber ( a , n , x ) << endl ; return 0 ; }
int fun ( int x ) { int y = ( x / 4 ) * 4 ;
int ans = 0 ; for ( int i = y ; i <= x ; i ++ ) ans ^= i ; return ans ; }
int query ( int x ) {
if ( x == 0 ) return 0 ; int k = ( x + 1 ) / 2 ;
return ( x %= 2 ) ? 2 * fun ( k ) : ( ( fun ( k - 1 ) * 2 ) ^ ( k & 1 ) ) ; } void allQueries ( int q , int l [ ] , int r [ ] ) { for ( int i = 0 ; i < q ; i ++ ) cout << ( query ( r [ i ] ) ^ query ( l [ i ] - 1 ) ) << endl ; }
int main ( ) { int q = 3 ; int l [ ] = { 2 , 2 , 5 } ; int r [ ] = { 4 , 8 , 9 } ; allQueries ( q , l , r ) ; return 0 ; }
int preprocess ( int arr [ ] , int N , int left [ ] , int right [ ] ) {
left [ 0 ] = 0 ; int lastIncr = 0 ; for ( int i = 1 ; i < N ; i ++ ) {
if ( arr [ i ] > arr [ i - 1 ] ) lastIncr = i ; left [ i ] = lastIncr ; }
right [ N - 1 ] = N - 1 ; int firstDecr = N - 1 ; for ( int i = N - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] > arr [ i + 1 ] ) firstDecr = i ; right [ i ] = firstDecr ; } }
bool isSubarrayMountainForm ( int arr [ ] , int left [ ] , int right [ ] , int L , int R ) {
return ( right [ L ] >= left [ R ] ) ; }
int main ( ) { int arr [ ] = { 2 , 3 , 2 , 4 , 4 , 6 , 3 , 2 } ; int N = sizeof ( arr ) / sizeof ( int ) ; int left [ N ] , right [ N ] ; preprocess ( arr , N , left , right ) ; int L = 0 ; int R = 2 ; if ( isSubarrayMountainForm ( arr , left , right , L , R ) ) cout << " Subarray ▁ is ▁ in ▁ mountain ▁ form STRNEWLINE " ; else cout << " Subarray ▁ is ▁ not ▁ in ▁ mountain ▁ form STRNEWLINE " ; L = 1 ; R = 3 ; if ( isSubarrayMountainForm ( arr , left , right , L , R ) ) cout << " Subarray ▁ is ▁ in ▁ mountain ▁ form STRNEWLINE " ; else cout << " Subarray ▁ is ▁ not ▁ in ▁ mountain ▁ form STRNEWLINE " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void preCompute ( int arr [ ] , int n , int pre [ ] ) { pre [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) pre [ i ] = arr [ i ] + pre [ i - 1 ] ; }
int rangeSum ( int i , int j , int pre [ ] ) { if ( i == 0 ) return pre [ j ] ; return pre [ j ] - pre [ i - 1 ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int pre [ n ] ;
preCompute ( arr , n , pre ) ; cout << rangeSum ( 1 , 3 , pre ) << endl ; cout << rangeSum ( 2 , 4 , pre ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  1000 NEW_LINE void sieveOfEratosthenes ( bool isPrime [ ] ) { isPrime [ 1 ] = false ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( isPrime [ p ] == true ) {
for ( int i = p * 2 ; i <= MAX ; i += p ) isPrime [ i ] = false ; } } }
int getMid ( int s , int e ) { return s + ( e - s ) / 2 ; }
int queryPrimesUtil ( int * st , int ss , int se , int qs , int qe , int index ) {
if ( qs <= ss && qe >= se ) return st [ index ] ;
if ( se < qs ss > qe ) return 0 ;
int mid = getMid ( ss , se ) ; return queryPrimesUtil ( st , ss , mid , qs , qe , 2 * index + 1 ) + queryPrimesUtil ( st , mid + 1 , se , qs , qe , 2 * index + 2 ) ; }
void updateValueUtil ( int * st , int ss , int se , int i , int diff , int si ) {
if ( i < ss i > se ) return ;
st [ si ] = st [ si ] + diff ; if ( se != ss ) { int mid = getMid ( ss , se ) ; updateValueUtil ( st , ss , mid , i , diff , 2 * si + 1 ) ; updateValueUtil ( st , mid + 1 , se , i , diff , 2 * si + 2 ) ; } }
void updateValue ( int arr [ ] , int * st , int n , int i , int new_val , bool isPrime [ ] ) {
if ( i < 0 i > n - 1 ) { printf ( " Invalid ▁ Input " ) ; return ; } int diff , oldValue ; oldValue = arr [ i ] ;
arr [ i ] = new_val ;
if ( isPrime [ oldValue ] && isPrime [ new_val ] ) return ;
if ( ( ! isPrime [ oldValue ] ) && ( ! isPrime [ new_val ] ) ) return ;
if ( isPrime [ oldValue ] && ! isPrime [ new_val ] ) { diff = -1 ; }
if ( ! isPrime [ oldValue ] && isPrime [ new_val ] ) { diff = 1 ; }
updateValueUtil ( st , 0 , n - 1 , i , diff , 0 ) ; }
void queryPrimes ( int * st , int n , int qs , int qe ) { int primesInRange = queryPrimesUtil ( st , 0 , n - 1 , qs , qe , 0 ) ; cout << " Number ▁ of ▁ Primes ▁ in ▁ subarray ▁ from ▁ " << qs << " ▁ to ▁ " << qe << " ▁ = ▁ " << primesInRange << " STRNEWLINE " ; }
int constructSTUtil ( int arr [ ] , int ss , int se , int * st , int si , bool isPrime [ ] ) {
if ( ss == se ) {
if ( isPrime [ arr [ ss ] ] ) st [ si ] = 1 ; else st [ si ] = 0 ; return st [ si ] ; }
int mid = getMid ( ss , se ) ; st [ si ] = constructSTUtil ( arr , ss , mid , st , si * 2 + 1 , isPrime ) + constructSTUtil ( arr , mid + 1 , se , st , si * 2 + 2 , isPrime ) ; return st [ si ] ; }
int * constructST ( int arr [ ] , int n , bool isPrime [ ] ) {
int x = ( int ) ( ceil ( log2 ( n ) ) ) ;
int max_size = 2 * ( int ) pow ( 2 , x ) - 1 ; int * st = new int [ max_size ] ;
constructSTUtil ( arr , 0 , n - 1 , st , 0 , isPrime ) ;
return st ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 5 , 7 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
bool isPrime [ MAX + 1 ] ; memset ( isPrime , true , sizeof isPrime ) ; sieveOfEratosthenes ( isPrime ) ;
int * st = constructST ( arr , n , isPrime ) ;
int start = 0 ; int end = 4 ; queryPrimes ( st , n , start , end ) ;
int i = 3 ; int x = 6 ; updateValue ( arr , st , n , i , x , isPrime ) ;
start = 0 ; end = 4 ; queryPrimes ( st , n , start , end ) ; return 0 ; }
void checkEVENodd ( int arr [ ] , int n , int l , int r ) {
if ( arr [ r ] == 1 ) cout << " odd " << endl ;
else cout < < " even " << endl ; }
int main ( ) { int arr [ ] = { 1 , 1 , 0 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; checkEVENodd ( arr , n , 1 , 3 ) ; return 0 ; }
int findMean ( int arr [ ] , int l , int r ) {
int sum = 0 , count = 0 ;
for ( int i = l ; i <= r ; i ++ ) { sum += arr [ i ] ; count ++ ; }
int mean = floor ( sum / count ) ;
return mean ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; cout << findMean ( arr , 0 , 2 ) << endl ; cout << findMean ( arr , 1 , 3 ) << endl ; cout << findMean ( arr , 0 , 4 ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  1000005 NEW_LINE using namespace std ; int prefixSum [ MAX ] ;
void calculatePrefixSum ( int arr [ ] , int n ) {
prefixSum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) prefixSum [ i ] = prefixSum [ i - 1 ] + arr [ i ] ; }
int findMean ( int l , int r ) { if ( l == 0 ) return floor ( prefixSum [ r ] / ( r + 1 ) ) ;
return floor ( ( prefixSum [ r ] - prefixSum [ l - 1 ] ) / ( r - l + 1 ) ) ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; calculatePrefixSum ( arr , n ) ; cout << findMean ( 0 , 2 ) << endl ; cout << findMean ( 1 , 3 ) << endl ; cout << findMean ( 0 , 4 ) << endl ; return 0 ; }
void updateQuery ( int arr [ ] , int n , int q , int l , int r , int k ) {
if ( q == 0 ) { arr [ l - 1 ] += k ; arr [ r ] += - k ; }
else { arr [ l - 1 ] += - k ; arr [ r ] += k ; } return ; }
void generateArray ( int arr [ ] , int n ) {
for ( int i = 1 ; i < n ; ++ i ) arr [ i ] += arr [ i - 1 ] ; return ; }
int main ( ) { int n = 5 ; int arr [ n + 1 ] ; memset ( arr , 0 , sizeof ( arr ) ) ; int q = 0 , l = 1 , r = 3 , k = 2 ; updateQuery ( arr , n , q , l , r , k ) ; q = 1 , l = 3 , r = 5 , k = 3 ; updateQuery ( arr , n , q , l , r , k ) ; q = 0 , l = 2 , r = 5 , k = 1 ; updateQuery ( arr , n , q , l , r , k ) ;
generateArray ( arr , n ) ;
for ( int i = 0 ; i < n ; ++ i ) cout << arr [ i ] << " ▁ " ; return 0 ; }
int calculateProduct ( int A [ ] , int L , int R , int P ) {
L = L - 1 ; R = R - 1 ; int ans = 1 ; for ( int i = L ; i <= R ; i ++ ) { ans = ans * A [ i ] ; ans = ans % P ; } return ans ; }
int main ( ) { int A [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ; int P = 229 ; int L = 2 , R = 5 ; cout << calculateProduct ( A , L , R , P ) << endl ; L = 1 , R = 3 ; cout << calculateProduct ( A , L , R , P ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  100 NEW_LINE int pre_product [ MAX ] ; int inverse_product [ MAX ] ;
int modInverse ( int a , int m ) { int m0 = m , t , q ; int x0 = 0 , x1 = 1 ; if ( m == 1 ) return 0 ; while ( a > 1 ) {
q = a / m ; t = m ;
m = a % m , a = t ; t = x0 ; x0 = x1 - q * x0 ; x1 = t ; }
if ( x1 < 0 ) x1 += m0 ; return x1 ; }
void calculate_Pre_Product ( int A [ ] , int N , int P ) { pre_product [ 0 ] = A [ 0 ] ; for ( int i = 1 ; i < N ; i ++ ) { pre_product [ i ] = pre_product [ i - 1 ] * A [ i ] ; pre_product [ i ] = pre_product [ i ] % P ; } }
void calculate_inverse_product ( int A [ ] , int N , int P ) { inverse_product [ 0 ] = modInverse ( pre_product [ 0 ] , P ) ; for ( int i = 1 ; i < N ; i ++ ) inverse_product [ i ] = modInverse ( pre_product [ i ] , P ) ; }
int calculateProduct ( int A [ ] , int L , int R , int P ) {
L = L - 1 ; R = R - 1 ; int ans ; if ( L == 0 ) ans = pre_product [ R ] ; else ans = pre_product [ R ] * inverse_product [ L - 1 ] ; return ans ; }
int A [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ; int N = sizeof ( A ) / sizeof ( A [ 0 ] ) ;
int P = 113 ;
calculate_Pre_Product ( A , N , P ) ; calculate_inverse_product ( A , N , P ) ;
int L = 2 , R = 5 ; cout << calculateProduct ( A , L , R , P ) << endl ; L = 1 , R = 3 ; cout << calculateProduct ( A , L , R , P ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 10000 ;
int prefix [ MAX + 1 ] ; void buildPrefix ( ) {
bool prime [ MAX + 1 ] ; memset ( prime , true , sizeof ( prime ) ) ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * 2 ; i <= MAX ; i += p ) prime [ i ] = false ; } }
prefix [ 0 ] = prefix [ 1 ] = 0 ; for ( int p = 2 ; p <= MAX ; p ++ ) { prefix [ p ] = prefix [ p - 1 ] ; if ( prime [ p ] ) prefix [ p ] ++ ; } }
int query ( int L , int R ) { return prefix [ R ] - prefix [ L - 1 ] ; }
int main ( ) { buildPrefix ( ) ; int L = 5 , R = 10 ; cout << query ( L , R ) << endl ; L = 1 , R = 10 ; cout << query ( L , R ) << endl ; return 0 ; }
void command ( bool arr [ ] , int a , int b ) { arr [ a ] ^= 1 ; arr [ b + 1 ] ^= 1 ; }
void process ( bool arr [ ] , int n ) { for ( int k = 1 ; k <= n ; k ++ ) arr [ k ] ^= arr [ k - 1 ] ; }
void result ( bool arr [ ] , int n ) { for ( int k = 1 ; k <= n ; k ++ ) cout << arr [ k ] << " ▁ " ; }
int main ( ) { int n = 5 , m = 3 ; bool arr [ n + 2 ] = { 0 } ;
command ( arr , 1 , 5 ) ; command ( arr , 2 , 5 ) ; command ( arr , 3 , 5 ) ;
process ( arr , n ) ;
result ( arr , n ) ; return 0 ; }
struct Interval { int start ; int end ; } ;
bool isIntersect ( Interval arr [ ] , int n ) {
sort ( arr , arr + n , compareInterval ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i - 1 ] . end > arr [ i ] . start ) return true ;
return false ; }
int main ( ) { Interval arr1 [ ] = { { 1 , 3 } , { 7 , 9 } , { 4 , 6 } , { 10 , 13 } } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; isIntersect ( arr1 , n1 ) ? cout << " Yes STRNEWLINE " : cout << " No STRNEWLINE " ; Interval arr2 [ ] = { { 6 , 8 } , { 1 , 3 } , { 2 , 4 } , { 4 , 7 } } ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; isIntersect ( arr2 , n2 ) ? cout << " Yes STRNEWLINE " : cout << " No STRNEWLINE " ; return 0 ; }
struct Interval { int start ; int end ; } ;
bool isIntersect ( Interval arr [ ] , int n ) { int max_ele = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { if ( max_ele < arr [ i ] . end ) max_ele = arr [ i ] . end ; }
int aux [ max_ele + 1 ] = { 0 } ; for ( int i = 0 ; i < n ; i ++ ) {
int x = arr [ i ] . start ;
int y = arr [ i ] . end ; aux [ x ] ++ , aux [ y + 1 ] -- ; } for ( int i = 1 ; i <= max_ele ; i ++ ) {
aux [ i ] += aux [ i - 1 ] ;
if ( aux [ i ] > 1 ) return true ; }
return false ; }
int main ( ) { Interval arr1 [ ] = { { 1 , 3 } , { 7 , 9 } , { 4 , 6 } , { 10 , 13 } } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; isIntersect ( arr1 , n1 ) ? cout << " Yes STRNEWLINE " : cout << " No STRNEWLINE " ; Interval arr2 [ ] = { { 6 , 8 } , { 1 , 3 } , { 2 , 4 } , { 4 , 7 } } ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; isIntersect ( arr2 , n2 ) ? cout << " Yes STRNEWLINE " : cout << " No STRNEWLINE " ; return 0 ; }
struct query { int start , end ; } ;
void incrementByD ( int arr [ ] , struct query q_arr [ ] , int n , int m , int d ) { int sum [ n ] ; memset ( sum , 0 , sizeof ( sum ) ) ;
for ( int i = 0 ; i < m ; i ++ ) {
sum [ q_arr [ i ] . start ] += d ;
if ( ( q_arr [ i ] . end + 1 ) < n ) sum [ q_arr [ i ] . end + 1 ] -= d ; }
arr [ 0 ] += sum [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { sum [ i ] += sum [ i - 1 ] ; arr [ i ] += sum [ i ] ; } }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 3 , 5 , 4 , 8 , 6 , 1 } ; struct query q_arr [ ] = { { 0 , 3 } , { 4 , 5 } , { 1 , 4 } , { 0 , 1 } , { 2 , 5 } } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int m = sizeof ( q_arr ) / sizeof ( q_arr [ 0 ] ) ; int d = 2 ; cout << " Original ▁ Array : STRNEWLINE " ; printArray ( arr , n ) ;
incrementByD ( arr , q_arr , n , m , d ) ; cout << " Modified Array : " printArray ( arr , n ) ; return 0 ; }
void prefixXOR ( int arr [ ] , int preXOR [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { while ( arr [ i ] % 2 != 1 ) arr [ i ] /= 2 ; preXOR [ i ] = arr [ i ] ; }
for ( int i = 1 ; i < n ; i ++ ) preXOR [ i ] = preXOR [ i - 1 ] ^ preXOR [ i ] ; }
int query ( int preXOR [ ] , int l , int r ) { if ( l == 0 ) return preXOR [ r ] ; else return preXOR [ r ] ^ preXOR [ l - 1 ] ; }
int main ( ) { int arr [ ] = { 3 , 4 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int preXOR [ n ] ; prefixXOR ( arr , preXOR , n ) ; cout << query ( preXOR , 0 , 2 ) << endl ; cout << query ( preXOR , 1 , 2 ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100000 ;
int tree [ MAX ] = { 0 } ;
bool lazy [ MAX ] = { false } ;
void toggle ( int node , int st , int en , int us , int ue ) {
if ( lazy [ node ] ) {
lazy [ node ] = false ; tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ 1 + ( node << 1 ) ] = ! lazy [ 1 + ( node << 1 ) ] ; } }
if ( st > en us > en ue < st ) return ;
if ( us <= st && en <= ue ) {
tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ 1 + ( node << 1 ) ] = ! lazy [ 1 + ( node << 1 ) ] ; } return ; }
int mid = ( st + en ) / 2 ; toggle ( ( node << 1 ) , st , mid , us , ue ) ; toggle ( ( node << 1 ) + 1 , mid + 1 , en , us , ue ) ;
if ( st < en ) tree [ node ] = tree [ node << 1 ] + tree [ ( node << 1 ) + 1 ] ; }
int countQuery ( int node , int st , int en , int qs , int qe ) {
if ( st > en qs > en qe < st ) return 0 ;
if ( lazy [ node ] ) {
lazy [ node ] = false ; tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ ( node << 1 ) + 1 ] = ! lazy [ ( node << 1 ) + 1 ] ; } }
if ( qs <= st && en <= qe ) return tree [ node ] ;
int mid = ( st + en ) / 2 ; return countQuery ( ( node << 1 ) , st , mid , qs , qe ) + countQuery ( ( node << 1 ) + 1 , mid + 1 , en , qs , qe ) ; }
int main ( ) { int n = 5 ;
toggle ( 1 , 0 , n - 1 , 1 , 2 ) ;
toggle ( 1 , 0 , n - 1 , 2 , 4 ) ;
cout << countQuery ( 1 , 0 , n - 1 , 2 , 3 ) << endl ;
toggle ( 1 , 0 , n - 1 , 2 , 4 ) ;
cout << countQuery ( 1 , 0 , n - 1 , 1 , 4 ) << endl ; return 0 ; }
double probability ( int a [ ] , int b [ ] , int size1 , int size2 ) {
int max1 = INT_MIN , count1 = 0 ; for ( int i = 0 ; i < size1 ; i ++ ) { if ( a [ i ] > max1 ) { max1 = a [ i ] ; count1 = 1 ; } else if ( a [ i ] == max1 ) { count1 ++ ; } }
int max2 = INT_MIN , count2 = 0 ; for ( int i = 0 ; i < size2 ; i ++ ) { if ( b [ i ] > max2 ) { max2 = b [ i ] ; count2 = 1 ; } else if ( b [ i ] == max2 ) { count2 ++ ; } }
return ( double ) ( count1 * count2 ) / ( size1 * size2 ) ; }
int main ( ) { int a [ ] = { 1 , 2 , 3 } ; int b [ ] = { 1 , 3 , 3 } ; int size1 = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int size2 = sizeof ( b ) / sizeof ( b [ 0 ] ) ; cout << probability ( a , b , size1 , size2 ) ; return 0 ; }
int countDe ( int arr [ ] , int n ) {
vector < int > v ( arr , arr + n ) ;
sort ( arr , arr + n ) ;
int count1 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count1 ++ ;
reverse ( arr , arr + n ) ;
int count2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count2 ++ ;
return ( min ( count1 , count2 ) ) ; }
int main ( ) { int arr [ ] = { 5 , 9 , 21 , 17 , 13 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ Dearrangement ▁ = ▁ " << countDe ( arr , n ) ; return 0 ; }
int maxOfSegmentMins ( int a [ ] , int n , int k ) {
if ( k == 1 ) return * min_element ( a , a + n ) ; if ( k == 2 ) return max ( a [ 0 ] , a [ n - 1 ] ) ;
return * max_element ( a , a + n ) ; }
int main ( ) { int a [ ] = { -10 , -9 , -8 , 2 , 7 , -6 , -5 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int k = 2 ; cout << maxOfSegmentMins ( a , n , k ) ; }
int printMinimumProduct ( int arr [ ] , int n ) {
int first_min = min ( arr [ 0 ] , arr [ 1 ] ) ; int second_min = max ( arr [ 0 ] , arr [ 1 ] ) ;
for ( int i = 2 ; i < n ; i ++ ) { if ( arr [ i ] < first_min ) { second_min = first_min ; first_min = arr [ i ] ; } else if ( arr [ i ] < second_min ) second_min = arr [ i ] ; } return first_min * second_min ; }
int main ( ) { int a [ ] = { 11 , 8 , 5 , 7 , 5 , 100 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << printMinimumProduct ( a , n ) ; return 0 ; }
long long noOfTriples ( long long arr [ ] , int n ) {
sort ( arr , arr + n ) ;
long long count = 0 ; for ( long long i = 0 ; i < n ; i ++ ) if ( arr [ i ] == arr [ 2 ] ) count ++ ;
if ( arr [ 0 ] == arr [ 2 ] ) return ( count - 2 ) * ( count - 1 ) * ( count ) / 6 ;
else if ( arr [ 1 ] == arr [ 2 ] ) return ( count - 1 ) * ( count ) / 2 ;
return count ; }
int main ( ) { long long arr [ ] = { 1 , 3 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << noOfTriples ( arr , n ) ; return 0 ; }
bool checkReverse ( int arr [ ] , int n ) {
int temp [ n ] ; for ( int i = 0 ; i < n ; i ++ ) temp [ i ] = arr [ i ] ;
sort ( temp , temp + n ) ;
int front ; for ( front = 0 ; front < n ; front ++ ) if ( temp [ front ] != arr [ front ] ) break ;
int back ; for ( back = n - 1 ; back >= 0 ; back -- ) if ( temp [ back ] != arr [ back ] ) break ;
if ( front >= back ) return true ;
do { front ++ ; if ( arr [ front - 1 ] < arr [ front ] ) return false ; } while ( front != back ) ; return true ; }
int main ( ) { int arr [ ] = { 1 , 2 , 5 , 4 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; checkReverse ( arr , n ) ? ( cout << " Yes " << endl ) : ( cout << " No " << endl ) ; return 0 ; }
bool checkReverse ( int arr [ ] , int n ) { if ( n == 1 ) return true ;
int i ; for ( i = 1 ; i < n && arr [ i - 1 ] < arr [ i ] ; i ++ ) ; if ( i == n ) return true ;
int j = i ; while ( j < n && arr [ j ] < arr [ j - 1 ] ) { if ( i > 1 && arr [ j ] < arr [ i - 2 ] ) return false ; j ++ ; } if ( j == n ) return true ;
int k = j ;
if ( arr [ k ] < arr [ i - 1 ] ) return false ; while ( k > 1 && k < n ) { if ( arr [ k ] < arr [ k - 1 ] ) return false ; k ++ ; } return true ; }
int main ( ) { int arr [ ] = { 1 , 3 , 4 , 10 , 9 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; checkReverse ( arr , n ) ? cout << " Yes " : cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int MinOperation ( int a [ ] , int b [ ] , int n ) {
sort ( a , a + n ) ; sort ( b , b + n ) ;
int result = 0 ;
for ( int i = 0 ; i < n ; ++ i ) { result = result + abs ( a [ i ] - b [ i ] ) ; } return result ; }
int main ( ) { int a [ ] = { 3 , 1 , 1 } ; int b [ ] = { 1 , 2 , 2 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << MinOperation ( a , b , n ) ; return 0 ; }
void sortExceptUandL ( int a [ ] , int l , int u , int n ) {
int b [ n - ( u - l + 1 ) ] ; for ( int i = 0 ; i < l ; i ++ ) b [ i ] = a [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) b [ l + ( i - ( u + 1 ) ) ] = a [ i ] ;
sort ( b , b + n - ( u - l + 1 ) ) ;
for ( int i = 0 ; i < l ; i ++ ) a [ i ] = b [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) a [ i ] = b [ l + ( i - ( u + 1 ) ) ] ; }
int main ( ) { int a [ ] = { 5 , 4 , 3 , 12 , 14 , 9 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int l = 2 , u = 4 ; sortExceptUandL ( a , l , u , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << a [ i ] << " ▁ " ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int sortExceptK ( int arr [ ] , int k , int n ) {
swap ( arr [ k ] , arr [ n - 1 ] ) ;
sort ( arr , arr + n - 1 ) ;
int last = arr [ n - 1 ] ;
for ( int i = n - 1 ; i > k ; i -- ) arr [ i ] = arr [ i - 1 ] ;
arr [ k ] = last ; }
int main ( ) { int a [ ] = { 10 , 4 , 11 , 7 , 6 , 20 } ; int k = 2 ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; sortExceptK ( a , k , n ) ; for ( int i = 0 ; i < n ; i ++ ) cout << a [ i ] << " ▁ " ; }
int findMinSwaps ( int arr [ ] , int n ) {
int noOfZeroes [ n ] ; memset ( noOfZeroes , 0 , sizeof ( noOfZeroes ) ) ; int i , count = 0 ;
noOfZeroes [ n - 1 ] = 1 - arr [ n - 1 ] ; for ( i = n - 2 ; i >= 0 ; i -- ) { noOfZeroes [ i ] = noOfZeroes [ i + 1 ] ; if ( arr [ i ] == 0 ) noOfZeroes [ i ] ++ ; }
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 1 ) count += noOfZeroes [ i ] ; } return count ; }
int main ( ) { int arr [ ] = { 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findMinSwaps ( arr , n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; int minswaps ( int arr [ ] , int n ) { int count = 0 ; int num_unplaced_zeros = 0 ; for ( int index = n - 1 ; index >= 0 ; index -- ) { if ( arr [ index ] == 0 ) num_unplaced_zeros += 1 ; else count += num_unplaced_zeros ; } return count ; }
int main ( ) { int arr [ ] = { 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 } ; cout << minswaps ( arr , 9 ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int new_data ) { struct Node * new_node = new Node ; new_node -> data = new_data ; new_node -> next = * head_ref ; * head_ref = new_node ; }
void printList ( struct Node * head ) { while ( head != NULL ) { cout << head -> data << " ▁ - > ▁ " ; head = head -> next ; } }
void sortlist ( int arr [ ] , int N , struct Node * head ) {
unordered_map < int , int > hash ; struct Node * temp = head ; while ( temp ) { hash [ temp -> data ] ++ ; temp = temp -> next ; } temp = head ;
for ( int i = 0 ; i < N ; i ++ ) {
int frequency = hash [ arr [ i ] ] ; while ( frequency -- ) {
temp -> data = arr [ i ] ; temp = temp -> next ; } } }
int main ( ) { struct Node * head = NULL ; int arr [ ] = { 5 , 1 , 3 , 2 , 8 } ; int N = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
push ( & head , 3 ) ; push ( & head , 2 ) ; push ( & head , 5 ) ; push ( & head , 8 ) ; push ( & head , 5 ) ; push ( & head , 2 ) ; push ( & head , 1 ) ;
sortlist ( arr , N , head ) ;
cout << " Sorted ▁ List : " << endl ; printList ( head ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void printRepeating ( int arr [ ] , int size ) {
set < int > s ( arr , arr + size ) ;
for ( auto x : s ) cout << x << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 3 , 2 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printRepeating ( arr , n ) ; return 0 ; }
int maxPartitions ( int arr [ ] , int n ) { int ans = 0 , max_so_far = 0 ; for ( int i = 0 ; i < n ; ++ i ) {
max_so_far = max ( max_so_far , arr [ i ] ) ;
if ( max_so_far == i ) ans ++ ; } return ans ; }
int main ( ) { int arr [ ] = { 1 , 0 , 2 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxPartitions ( arr , n ) ; return 0 ; }
void cuttringRopes ( int Ropes [ ] , int n ) {
sort ( Ropes , Ropes + n ) ; int singleOperation = 0 ;
int cuttingLenght = Ropes [ 0 ] ;
for ( int i = 1 ; i < n ; i ++ ) {
if ( Ropes [ i ] - cuttingLenght > 0 ) { cout << ( n - i ) << " ▁ " ;
cuttingLenght = Ropes [ i ] ; singleOperation ++ ; } }
if ( singleOperation == 0 ) cout << "0 ▁ " ; }
int main ( ) { int Ropes [ ] = { 5 , 1 , 1 , 2 , 3 , 5 } ; int n = sizeof ( Ropes ) / sizeof ( Ropes [ 0 ] ) ; cuttringRopes ( Ropes , n ) ; return 0 ; }
void rankify ( int * A , int n ) {
float R [ n ] = { 0 } ;
for ( int i = 0 ; i < n ; i ++ ) { int r = 1 , s = 1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( j != i && A [ j ] < A [ i ] ) r += 1 ; if ( j != i && A [ j ] == A [ i ] ) s += 1 ; }
R [ i ] = r + ( float ) ( s - 1 ) / ( float ) 2 ; } for ( int i = 0 ; i < n ; i ++ ) cout << R [ i ] << ' ▁ ' ; }
int main ( ) { int A [ ] = { 1 , 2 , 5 , 2 , 1 , 25 , 2 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; for ( int i = 0 ; i < n ; i ++ ) cout << A [ i ] << ' ▁ ' ; cout << ' ' ; rankify ( A , n ) ; return 0 ; }
int min_noOf_operation ( int arr [ ] , int n , int k ) { int noOfSubtraction ; int res = 0 ; for ( int i = 1 ; i < n ; i ++ ) { noOfSubtraction = 0 ; if ( arr [ i ] > arr [ i - 1 ] ) {
noOfSubtraction = ( arr [ i ] - arr [ i - 1 ] ) / k ;
if ( ( arr [ i ] - arr [ i - 1 ] ) % k != 0 ) noOfSubtraction ++ ;
arr [ i ] = arr [ i ] - k * noOfSubtraction ; }
res = res + noOfSubtraction ; } return res ; }
int main ( ) { int arr [ ] = { 1 , 1 , 2 , 3 } ; int N = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 5 ; cout << min_noOf_operation ( arr , N , k ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int maxSum ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += ( arr [ i ] * i ) ; return sum ; }
int main ( ) { int arr [ ] = { 3 , 5 , 6 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxSum ( arr , n ) << endl ; return 0 ; }
int countPairs ( int a [ ] , int n , int k ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( abs ( a [ j ] - a [ i ] ) < k ) res ++ ; return res ; }
int main ( ) { int a [ ] = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << countPairs ( a , n , k ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countPairs ( int a [ ] , int n , int k ) {
sort ( a , a + n ) ; int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j = i + 1 ; while ( j < n && a [ j ] - a [ i ] < k ) { res ++ ; j ++ ; } } return res ; }
int main ( ) { int a [ ] = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << countPairs ( a , n , k ) << endl ; return 0 ; }
void sortedMerge ( int a [ ] , int b [ ] , int res [ ] , int n , int m ) {
sort ( a , a + n ) ; sort ( b , b + m ) ;
int i = 0 , j = 0 , k = 0 ; while ( i < n && j < m ) { if ( a [ i ] <= b [ j ] ) { res [ k ] = a [ i ] ; i += 1 ; k += 1 ; } else { res [ k ] = b [ j ] ; j += 1 ; k += 1 ; } }
while ( i < n ) { res [ k ] = a [ i ] ; i += 1 ; k += 1 ; }
while ( j < m ) { res [ k ] = b [ j ] ; j += 1 ; k += 1 ; } }
int main ( ) { int a [ ] = { 10 , 5 , 15 } ; int b [ ] = { 20 , 3 , 2 , 12 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int m = sizeof ( b ) / sizeof ( b [ 0 ] ) ;
int res [ n + m ] ; sortedMerge ( a , b , res , n , m ) ; cout << " Sorted ▁ merge ▁ list ▁ : " ; for ( int i = 0 ; i < n + m ; i ++ ) cout << " ▁ " << res [ i ] ; cout << " n " ; return 0 ; }
ll findMaxPairs ( ll a [ ] , ll b [ ] , ll n , ll k ) {
sort ( a , a + n ) ;
sort ( b , b + n ) ;
bool flag [ n ] ; memset ( flag , false , sizeof ( flag ) ) ;
int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( abs ( a [ i ] - b [ j ] ) <= k && flag [ j ] == false ) {
result ++ ;
flag [ j ] = true ;
break ; } } } return result ; }
int main ( ) { ll a [ ] = { 10 , 15 , 20 } , b [ ] = { 17 , 12 , 24 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int k = 3 ; cout << findMaxPairs ( a , b , n , k ) ; return 0 ; }
ll findMaxPairs ( ll a [ ] , ll b [ ] , ll n , ll k ) {
sort ( a , a + n ) ;
sort ( b , b + n ) ; int result = 0 ; for ( int i = 0 , j = 0 ; i < n && j < n ; ) { if ( abs ( a [ i ] - b [ j ] ) <= k ) { result ++ ;
i ++ ; j ++ ; }
else if ( a [ i ] > b [ j ] ) j ++ ;
else i ++ ; } return result ; }
int main ( ) { ll a [ ] = { 10 , 15 , 20 } ; ll b [ ] = { 17 , 12 , 24 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int k = 3 ; cout << findMaxPairs ( a , b , n , k ) ; return 0 ; }
int sumOfMinAbsDifferences ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int sum = 0 ;
sum += abs ( arr [ 0 ] - arr [ 1 ] ) ;
sum += abs ( arr [ n - 1 ] - arr [ n - 2 ] ) ;
for ( int i = 1 ; i < n - 1 ; i ++ ) sum += min ( abs ( arr [ i ] - arr [ i - 1 ] ) , abs ( arr [ i ] - arr [ i + 1 ] ) ) ;
return sum ; }
int main ( ) { int arr [ ] = { 5 , 10 , 1 , 4 , 8 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Sum ▁ = ▁ " << sumOfMinAbsDifferences ( arr , n ) ; }
int findSmallestDifference ( int A [ ] , int B [ ] , int m , int n ) {
sort ( A , A + m ) ; sort ( B , B + n ) ; int a = 0 , b = 0 ;
int result = INT_MAX ;
while ( a < m && b < n ) { if ( abs ( A [ a ] - B [ b ] ) < result ) result = abs ( A [ a ] - B [ b ] ) ;
if ( A [ a ] < B [ b ] ) a ++ ; else b ++ ; }
return result ; }
int A [ ] = { 1 , 2 , 11 , 5 } ;
int B [ ] = { 4 , 12 , 19 , 23 , 127 , 235 } ;
int m = sizeof ( A ) / sizeof ( A [ 0 ] ) ; int n = sizeof ( B ) / sizeof ( B [ 0 ] ) ;
cout << findSmallestDifference ( A , B , m , n ) ; return 0 ; }
int arraySortedOrNot ( int arr [ ] , int n ) {
if ( n == 1 n == 0 ) return 1 ;
if ( arr [ n - 1 ] < arr [ n - 2 ] ) return 0 ;
return arraySortedOrNot ( arr , n - 1 ) ; }
int main ( ) { int arr [ ] = { 20 , 23 , 23 , 45 , 78 , 88 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( arraySortedOrNot ( arr , n ) ) cout << " Yes STRNEWLINE " ; else cout << " No STRNEWLINE " ; }
bool arraySortedOrNot ( int a [ ] , int n ) {
if ( n == 1 n == 0 ) { return true ; }
return a [ n - 1 ] >= a [ n - 2 ] && arraySortedOrNot ( a , n - 1 ) ; }
int main ( ) { int arr [ ] = { 20 , 23 , 23 , 45 , 78 , 88 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
if ( arraySortedOrNot ( arr , n ) ) { cout << " Yes " << endl ; } else { cout << " No " << endl ; } return 0 ; }
bool arraySortedOrNot ( int arr [ ] , int n ) {
if ( n == 0 n == 1 ) return true ; for ( int i = 1 ; i < n ; i ++ )
if ( arr [ i - 1 ] > arr [ i ] ) return false ;
return true ; }
int main ( ) { int arr [ ] = { 20 , 23 , 23 , 45 , 78 , 88 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( arraySortedOrNot ( arr , n ) ) cout << " Yes STRNEWLINE " ; else cout << " No STRNEWLINE " ; }
void findLarger ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
for ( int i = n - 1 ; i >= n / 2 ; i -- ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 3 , 6 , 1 , 0 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; findLarger ( arr , n ) ; return 0 ; }
int minSwapsToSort ( int arr [ ] , int n ) {
pair < int , int > arrPos [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { arrPos [ i ] . first = arr [ i ] ; arrPos [ i ] . second = i ; }
sort ( arrPos , arrPos + n ) ;
vector < bool > vis ( n , false ) ;
int ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( vis [ i ] arrPos [ i ] . second == i ) continue ;
int cycle_size = 0 ; int j = i ; while ( ! vis [ j ] ) { vis [ j ] = 1 ;
j = arrPos [ j ] . second ; cycle_size ++ ; }
ans += ( cycle_size - 1 ) ; }
return ans ; }
int minSwapToMakeArraySame ( int a [ ] , int b [ ] , int n ) {
map < int , int > mp ; for ( int i = 0 ; i < n ; i ++ ) mp [ b [ i ] ] = i ;
for ( int i = 0 ; i < n ; i ++ ) b [ i ] = mp [ a [ i ] ] ;
return minSwapsToSort ( b , n ) ; }
int main ( ) { int a [ ] = { 3 , 6 , 4 , 8 } ; int b [ ] = { 4 , 6 , 8 , 3 } ; int n = sizeof ( a ) / sizeof ( int ) ; cout << minSwapToMakeArraySame ( a , b , n ) ; return 0 ; }
int findSingle ( int ar [ ] , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
int main ( ) { int ar [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = sizeof ( ar ) / sizeof ( ar [ 0 ] ) ; cout << " Element ▁ occurring ▁ once ▁ is ▁ " << findSingle ( ar , n ) ; return 0 ; }
int singleNumber ( int nums [ ] , int n ) { map < int , int > m ; long sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( m [ nums [ i ] ] == 0 ) { sum1 += nums [ i ] ; m [ nums [ i ] ] ++ ; } sum2 += nums [ i ] ; }
return 2 * ( sum1 ) - sum2 ; }
int main ( ) { int a [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = 7 ; cout << singleNumber ( a , n ) << " STRNEWLINE " ; int b [ ] = { 15 , 18 , 16 , 18 , 16 , 15 , 89 } ; cout << singleNumber ( b , n ) ; return 0 ; }
int singleelement ( int arr [ ] , int n ) { int low = 0 , high = n - 2 ; int mid ; while ( low <= high ) { mid = ( low + high ) / 2 ; if ( arr [ mid ] == arr [ mid ^ 1 ] ) { low = mid + 1 ; } else { high = mid - 1 ; } } return arr [ low ] ; }
int main ( ) { int arr [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; sort ( arr , arr + size ) ; cout << singleelement ( arr , size ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countTriplets ( int arr [ ] , int n , int sum ) {
int ans = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) {
for ( int j = i + 1 ; j < n - 1 ; j ++ ) {
for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] + arr [ j ] + arr [ k ] < sum ) ans ++ ; } } return ans ; }
int main ( ) { int arr [ ] = { 5 , 1 , 3 , 4 , 7 } ; int n = sizeof arr / sizeof arr [ 0 ] ; int sum = 12 ; cout << countTriplets ( arr , n , sum ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countTriplets ( int arr [ ] , int n , int sum ) {
sort ( arr , arr + n ) ;
int ans = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) {
int j = i + 1 , k = n - 1 ;
while ( j < k ) {
if ( arr [ i ] + arr [ j ] + arr [ k ] >= sum ) k -- ;
else {
ans += ( k - j ) ; j ++ ; } } } return ans ; }
int main ( ) { int arr [ ] = { 5 , 1 , 3 , 4 , 7 } ; int n = sizeof arr / sizeof arr [ 0 ] ; int sum = 12 ; cout << countTriplets ( arr , n , sum ) << endl ; return 0 ; }
int countTriplets ( int a [ ] , int n ) {
unordered_set < int > s ; for ( int i = 0 ; i < n ; i ++ ) s . insert ( a [ i ] ) ;
int count = 0 ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int xr = a [ i ] ^ a [ j ] ;
if ( s . find ( xr ) != s . end ( ) && xr != a [ i ] && xr != a [ j ] ) count ++ ; } }
return count / 3 ; }
int main ( ) { int a [ ] = { 1 , 3 , 5 , 10 , 14 , 15 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << countTriplets ( a , n ) ; return 0 ; }
int getMissingNo ( int a [ ] , int n ) { int i , total = 1 ; for ( i = 2 ; i <= ( n + 1 ) ; i ++ ) { total += i ; total -= a [ i - 2 ] ; } return total ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 5 } ; cout << getMissingNo ( arr , sizeof ( arr ) / sizeof ( arr [ 0 ] ) ) ; return 0 ; }
int getMissingNo ( int a [ ] , int n ) { int n_elements_sum = n * ( n + 1 ) / 2 ; int sum = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) sum += a [ i ] ; return n_elements_sum - sum ; }
int main ( ) { int a [ ] = { 1 , 2 , 4 , 5 , 6 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) + 1 ; int miss = getMissingNo ( a , n ) ; cout << ( miss ) ; return 0 ; }
int countOccurrences ( int arr [ ] , int n , int x ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( x == arr [ i ] ) res ++ ; return res ; }
int main ( ) { int arr [ ] = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 2 ; cout << countOccurrences ( arr , n , x ) ; return 0 ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r < l ) return -1 ; int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
int countOccurrences ( int arr [ ] , int n , int x ) { int ind = binarySearch ( arr , 0 , n - 1 , x ) ;
if ( ind == -1 ) return 0 ;
int count = 1 ; int left = ind - 1 ; while ( left >= 0 && arr [ left ] == x ) count ++ , left -- ;
int right = ind + 1 ; while ( right < n && arr [ right ] == x ) count ++ , right ++ ; return count ; }
int main ( ) { int arr [ ] = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 2 ; cout << countOccurrences ( arr , n , x ) ; return 0 ; }
void printClosest ( int arr [ ] , int n , int x ) {
int res_l , res_r ;
int l = 0 , r = n - 1 , diff = INT_MAX ;
while ( r > l ) {
if ( abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } cout << " ▁ The ▁ closest ▁ pair ▁ is ▁ " << arr [ res_l ] << " ▁ and ▁ " << arr [ res_r ] ; }
int main ( ) { int arr [ ] = { 10 , 22 , 28 , 29 , 30 , 40 } , x = 54 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printClosest ( arr , n , x ) ; return 0 ; }
void constructTree ( int n , int d , int h ) { if ( d == 1 ) {
if ( n == 2 && h == 1 ) { cout << "1 ▁ 2" << endl ; return ; }
cout << " - 1" << endl ; return ; } if ( d > 2 * h ) { cout << " - 1" << endl ; return ; }
for ( int i = 1 ; i <= h ; i ++ ) cout << i << " ▁ " << i + 1 << endl ; if ( d > h ) {
cout << "1" << " ▁ " << h + 2 << endl ; for ( int i = h + 2 ; i <= d ; i ++ ) { cout << i << " ▁ " << i + 1 << endl ; } }
for ( int i = d + 1 ; i < n ; i ++ ) { int k = 1 ; if ( d == h ) k = 2 ; cout << k << " ▁ " << i + 1 << endl ; } }
int main ( ) { int n = 5 , d = 3 , h = 2 ; constructTree ( n , d , h ) ; return 0 ; }
int countOnes ( bool arr [ ] , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
int main ( ) { bool arr [ ] = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " << countOnes ( arr , 0 , n - 1 ) ; return 0 ; }
int countOnes ( bool arr [ ] , int n ) { int ans ; int low = 0 , high = n - 1 ;
while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] < 1 ) high = mid - 1 ;
else if ( arr [ mid ] > 1 ) low = mid + 1 ; else
{ if ( mid == n - 1 arr [ mid + 1 ] != 1 ) return mid + 1 ; else low = mid + 1 ; } } }
int main ( ) { bool arr [ ] = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " << countOnes ( arr , n ) ; return 0 ; }
int findMissingUtil ( int arr1 [ ] , int arr2 [ ] , int N ) {
if ( N == 1 ) return arr1 [ 0 ] ;
if ( arr1 [ 0 ] != arr2 [ 0 ] ) return arr1 [ 0 ] ;
int lo = 0 , hi = N - 1 ;
while ( lo < hi ) { int mid = ( lo + hi ) / 2 ;
if ( arr1 [ mid ] == arr2 [ mid ] ) lo = mid ; else hi = mid ;
if ( lo == hi - 1 ) break ; }
return arr1 [ hi ] ; }
void findMissing ( int arr1 [ ] , int arr2 [ ] , int M , int N ) { if ( N == M - 1 ) cout << " Missing ▁ Element ▁ is ▁ " << findMissingUtil ( arr1 , arr2 , M ) << endl ; else if ( M == N - 1 ) cout << " Missing ▁ Element ▁ is ▁ " << findMissingUtil ( arr2 , arr1 , N ) << endl ; else cout << " Invalid ▁ Input " ; }
int main ( ) { int arr1 [ ] = { 1 , 4 , 5 , 7 , 9 } ; int arr2 [ ] = { 4 , 5 , 7 , 9 } ; int M = sizeof ( arr1 ) / sizeof ( int ) ; int N = sizeof ( arr2 ) / sizeof ( int ) ; findMissing ( arr1 , arr2 , M , N ) ; return 0 ; }
void findMissing ( int arr1 [ ] , int arr2 [ ] , int M , int N ) { if ( M != N - 1 && N != M - 1 ) { cout << " Invalid ▁ Input " ; return ; }
int res = 0 ; for ( int i = 0 ; i < M ; i ++ ) res = res ^ arr1 [ i ] ; for ( int i = 0 ; i < N ; i ++ ) res = res ^ arr2 [ i ] ; cout << " Missing ▁ element ▁ is ▁ " << res ; }
int main ( ) { int arr1 [ ] = { 4 , 1 , 5 , 9 , 7 } ; int arr2 [ ] = { 7 , 5 , 9 , 4 } ; int M = sizeof ( arr1 ) / sizeof ( int ) ; int N = sizeof ( arr2 ) / sizeof ( int ) ; findMissing ( arr1 , arr2 , M , N ) ; return 0 ; }
void printTwoOdd ( int arr [ ] , int size ) {
map < int , int > m ; for ( int i = 0 ; i < size ; i ++ ) { m [ arr [ i ] ] ++ ; }
cout << " The ▁ two ▁ ODD ▁ elements ▁ are ▁ " ; for ( auto & x : m ) { if ( x . second % 2 != 0 ) cout << x . first << " , ▁ " ; } }
int main ( ) { int arr [ ] = { 4 , 2 , 4 , 5 , 2 , 3 , 3 , 1 } ; int arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printTwoOdd ( arr , arr_size ) ; return 0 ; }
void findFourElements ( int arr [ ] , int n , int X ) {
unordered_map < int , pair < int , int > > mp ; for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) mp [ arr [ i ] + arr [ j ] ] = { i , j } ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int sum = arr [ i ] + arr [ j ] ;
if ( mp . find ( X - sum ) != mp . end ( ) ) {
pair < int , int > p = mp [ X - sum ] ; if ( p . first != i && p . first != j && p . second != i && p . second != j ) { cout << arr [ i ] << " , ▁ " << arr [ j ] << " , ▁ " << arr [ p . first ] << " , ▁ " << arr [ p . second ] ; return ; } } } } }
int main ( ) { int arr [ ] = { 10 , 20 , 30 , 40 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int X = 91 ;
findFourElements ( arr , n , X ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
void fourSum ( int X , int arr [ ] , map < int , pair < int , int > > Map , int N ) { int temp [ N ] ;
for ( int i = 0 ; i < N ; i ++ ) temp [ i ] = 0 ;
for ( int i = 0 ; i < N - 1 ; i ++ ) {
for ( int j = i + 1 ; j < N ; j ++ ) {
int curr_sum = arr [ i ] + arr [ j ] ;
if ( Map . find ( X - curr_sum ) != Map . end ( ) ) {
pair < int , int > p = Map [ X - curr_sum ] ; if ( p . first != i && p . second != i && p . first != j && p . second != j && temp [ p . first ] == 0 && temp [ p . second ] == 0 && temp [ i ] == 0 && temp [ j ] == 0 ) {
cout << arr [ i ] << " , " << arr [ j ] << " , " << arr [ p . first ] << " , " << arr [ p . second ] ; temp [ p . second ] = 1 ; temp [ i ] = 1 ; temp [ j ] = 1 ; break ; } } } } }
map < int , pair < int , int > > twoSum ( int nums [ ] , int N ) { map < int , pair < int , int > > Map ; for ( int i = 0 ; i < N - 1 ; i ++ ) { for ( int j = i + 1 ; j < N ; j ++ ) { Map [ nums [ i ] + nums [ j ] ] . first = i ; Map [ nums [ i ] + nums [ j ] ] . second = j ; } } return Map ; }
int main ( ) { int arr [ ] = { 10 , 20 , 30 , 40 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int X = 91 ; map < int , pair < int , int > > Map = twoSum ( arr , n ) ;
fourSum ( X , arr , Map , n ) ; return 0 ; }
int search ( int arr [ ] , int n , int x ) {
int i = 0 ; while ( i < n ) {
if ( arr [ i ] == x ) return i ;
i = i + abs ( arr [ i ] - x ) ; } cout << " number ▁ is ▁ not ▁ present ! " ; return -1 ; }
int main ( ) { int arr [ ] = { 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 3 ; cout << " Element ▁ " << x << " ▁ is ▁ present ▁ at ▁ index ▁ " << search ( arr , n , 3 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE void thirdLargest ( int arr [ ] , int arr_size ) {
if ( arr_size < 3 ) { printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] ; for ( int i = 1 ; i < arr_size ; i ++ ) if ( arr [ i ] > first ) first = arr [ i ] ;
int second = INT_MIN ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > second && arr [ i ] < first ) second = arr [ i ] ;
int third = INT_MIN ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > third && arr [ i ] < second ) third = arr [ i ] ; printf ( " The ▁ third ▁ Largest ▁ element ▁ is ▁ % d STRNEWLINE " , third ) ; }
int main ( ) { int arr [ ] = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; thirdLargest ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE void thirdLargest ( int arr [ ] , int arr_size ) {
if ( arr_size < 3 ) { printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] , second = INT_MIN , third = INT_MIN ;
for ( int i = 1 ; i < arr_size ; i ++ ) {
if ( arr [ i ] > first ) { third = second ; second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) { third = second ; second = arr [ i ] ; }
else if ( arr [ i ] > third ) third = arr [ i ] ; } printf ( " The ▁ third ▁ Largest ▁ element ▁ is ▁ % d STRNEWLINE " , third ) ; }
int main ( ) { int arr [ ] = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; thirdLargest ( arr , n ) ; return 0 ; }
bool checkPair ( int arr [ ] , int n ) {
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += arr [ i ] ;
if ( sum % 2 != 0 ) return false ; sum = sum / 2 ;
unordered_set < int > s ; for ( int i = 0 ; i < n ; i ++ ) { int val = sum - arr [ i ] ;
if ( s . find ( val ) != s . end ( ) ) { printf ( " Pair ▁ elements ▁ are ▁ % d ▁ and ▁ % d STRNEWLINE " , arr [ i ] , val ) ; return true ; } s . insert ( arr [ i ] ) ; } return false ; }
int main ( ) { int arr [ ] = { 2 , 11 , 5 , 1 , 4 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( checkPair ( arr , n ) == false ) printf ( " No ▁ pair ▁ found " ) ; return 0 ; }
string search ( int arr [ ] , int n , int x ) {
if ( arr [ n - 1 ] == x ) return " Found " ; int backup = arr [ n - 1 ] ; arr [ n - 1 ] = x ;
for ( int i = 0 ; ; i ++ ) {
if ( arr [ i ] == x ) {
arr [ n - 1 ] = backup ;
if ( i < n - 1 ) return " Found " ;
return " Not ▁ Found " ; } } }
int main ( ) { int arr [ ] = { 4 , 6 , 1 , 5 , 8 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 1 ; cout << search ( arr , n , x ) ; return 0 ; }
pair < int , int > sequence ( const vector < int > & a ) { if ( a . size ( ) == 0 ) return { 0 , 0 } ; int s = 0 ; int e = a . size ( ) - 1 ; while ( s < e ) { int m = ( s + e ) / 2 ;
if ( a [ m ] >= m + a [ 0 ] ) s = m + 1 ;
else e = m ; } return { a [ s ] , a . size ( ) - ( a [ a . size ( ) - 1 ] - a [ 0 ] ) } ; }
int main ( ) { pair < int , int > p = sequence ( { 1 , 2 , 3 , 4 , 4 , 4 , 5 , 6 } ) ; cout << " Repeated ▁ element ▁ is ▁ " << p . first << " , ▁ it ▁ appears ▁ " << p . second << " ▁ times " ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; int findMajority ( int arr [ ] , int n ) { return arr [ n / 2 ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 2 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findMajority ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void minAdjDifference ( int arr [ ] , int n ) { if ( n < 2 ) return ;
int res = abs ( arr [ 1 ] - arr [ 0 ] ) ; for ( int i = 2 ; i < n ; i ++ ) res = min ( res , abs ( arr [ i ] - arr [ i - 1 ] ) ) ;
res = min ( res , abs ( arr [ n - 1 ] - arr [ 0 ] ) ) ; cout << " Min ▁ Difference ▁ = ▁ " << res ; }
int main ( ) { int a [ ] = { 10 , 12 , 13 , 15 , 10 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; minAdjDifference ( a , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  100000 NEW_LINE using namespace std ; int Print3Smallest ( int array [ ] , int n ) { int firstmin = MAX , secmin = MAX , thirdmin = MAX ; for ( int i = 0 ; i < n ; i ++ ) {
if ( array [ i ] < firstmin ) { thirdmin = secmin ; secmin = firstmin ; firstmin = array [ i ] ; }
else if ( array [ i ] < secmin ) { thirdmin = secmin ; secmin = array [ i ] ; }
else if ( array [ i ] < thirdmin ) thirdmin = array [ i ] ; } cout << " First ▁ min ▁ = ▁ " << firstmin << " STRNEWLINE " ; cout << " Second ▁ min ▁ = ▁ " << secmin << " STRNEWLINE " ; cout << " Third ▁ min ▁ = ▁ " << thirdmin << " STRNEWLINE " ; }
int main ( ) { int array [ ] = { 4 , 9 , 1 , 32 , 12 } ; int n = sizeof ( array ) / sizeof ( array [ 0 ] ) ; Print3Smallest ( array , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int getMin ( int arr [ ] , int n ) {
return ( n == 1 ) ? arr [ 0 ] : min ( arr [ 0 ] , getMin ( arr + 1 , n - 1 ) ) ; } int getMax ( int arr [ ] , int n ) {
return ( n == 1 ) ? arr [ 0 ] : max ( arr [ 0 ] , getMax ( arr + 1 , n - 1 ) ) ; }
int main ( ) { int arr [ ] = { 12 , 1234 , 45 , 67 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ element ▁ of ▁ array : ▁ " << getMin ( arr , n ) << " STRNEWLINE " ; cout << " Maximum ▁ element ▁ of ▁ array : ▁ " << getMax ( arr , n ) ; return 0 ; }
int getMin ( int arr [ ] , int n ) { return * min_element ( arr , arr + n ) ; } int getMax ( int arr [ ] , int n ) { return * max_element ( arr , arr + n ) ; }
int main ( ) { int arr [ ] = { 12 , 1234 , 45 , 67 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ element ▁ of ▁ array : ▁ " << getMin ( arr , n ) << " STRNEWLINE " ; cout << " Maximum ▁ element ▁ of ▁ array : ▁ " << getMax ( arr , n ) ; return 0 ; }
void findCounts ( int * arr , int n ) {
int hash [ n ] = { 0 } ;
int i = 0 ; while ( i < n ) {
hash [ arr [ i ] - 1 ] ++ ;
i ++ ; } printf ( " Below are counts of all elements " for ( int i = 0 ; i < n ; i ++ ) printf ( " % d ▁ - > ▁ % d STRNEWLINE " , i + 1 , hash [ i ] ) ; }
int main ( ) { int arr [ ] = { 2 , 3 , 3 , 2 , 5 } ; findCounts ( arr , sizeof ( arr ) / sizeof ( arr [ 0 ] ) ) ; int arr1 [ ] = { 1 } ; findCounts ( arr1 , sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ) ; int arr3 [ ] = { 4 , 4 , 4 , 4 } ; findCounts ( arr3 , sizeof ( arr3 ) / sizeof ( arr3 [ 0 ] ) ) ; int arr2 [ ] = { 1 , 3 , 5 , 7 , 9 , 1 , 3 , 5 , 7 , 9 , 1 } ; findCounts ( arr2 , sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ) ; int arr4 [ ] = { 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 } ; findCounts ( arr4 , sizeof ( arr4 ) / sizeof ( arr4 [ 0 ] ) ) ; int arr5 [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 } ; findCounts ( arr5 , sizeof ( arr5 ) / sizeof ( arr5 [ 0 ] ) ) ; int arr6 [ ] = { 11 , 10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 } ; findCounts ( arr6 , sizeof ( arr6 ) / sizeof ( arr6 [ 0 ] ) ) ; return 0 ; }
void findCounts ( int * arr , int n ) {
int i = 0 ; while ( i < n ) {
if ( arr [ i ] <= 0 ) { i ++ ; continue ; }
int elementIndex = arr [ i ] - 1 ;
if ( arr [ elementIndex ] > 0 ) { arr [ i ] = arr [ elementIndex ] ;
arr [ elementIndex ] = -1 ; } else {
arr [ elementIndex ] -- ;
arr [ i ] = 0 ; i ++ ; } } printf ( " Below are counts of all elements " for ( int i = 0 ; i < n ; i ++ ) printf ( " % d ▁ - > ▁ % d STRNEWLINE " , i + 1 , abs ( arr [ i ] ) ) ; }
int main ( ) { int arr [ ] = { 2 , 3 , 3 , 2 , 5 } ; findCounts ( arr , sizeof ( arr ) / sizeof ( arr [ 0 ] ) ) ; int arr1 [ ] = { 1 } ; findCounts ( arr1 , sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ) ; int arr3 [ ] = { 4 , 4 , 4 , 4 } ; findCounts ( arr3 , sizeof ( arr3 ) / sizeof ( arr3 [ 0 ] ) ) ; int arr2 [ ] = { 1 , 3 , 5 , 7 , 9 , 1 , 3 , 5 , 7 , 9 , 1 } ; findCounts ( arr2 , sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ) ; int arr4 [ ] = { 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 } ; findCounts ( arr4 , sizeof ( arr4 ) / sizeof ( arr4 [ 0 ] ) ) ; int arr5 [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 } ; findCounts ( arr5 , sizeof ( arr5 ) / sizeof ( arr5 [ 0 ] ) ) ; int arr6 [ ] = { 11 , 10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 } ; findCounts ( arr6 , sizeof ( arr6 ) / sizeof ( arr6 [ 0 ] ) ) ; return 0 ; }
void printfrequency ( int arr [ ] , int n ) {
for ( int j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] - 1 ;
for ( int i = 0 ; i < n ; i ++ ) arr [ arr [ i ] % n ] = arr [ arr [ i ] % n ] + n ;
for ( int i = 0 ; i < n ; i ++ ) cout << i + 1 << " ▁ - > ▁ " << arr [ i ] / n << endl ; }
int main ( ) { int arr [ ] = { 2 , 3 , 3 , 2 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printfrequency ( arr , n ) ; return 0 ; }
int deleteElement ( int arr [ ] , int n , int x ) {
int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == x ) break ;
if ( i < n ) {
n = n - 1 ; for ( int j = i ; j < n ; j ++ ) arr [ j ] = arr [ j + 1 ] ; } return n ; }
int main ( ) { int arr [ ] = { 11 , 15 , 6 , 8 , 9 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 6 ;
n = deleteElement ( arr , n , x ) ; cout << " Modified ▁ array ▁ is ▁ STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
int deleteElement ( int arr [ ] , int n , int x ) {
if ( arr [ n - 1 ] == x ) return ( n - 1 ) ;
int prev = arr [ n - 1 ] , i ; for ( i = n - 2 ; i >= 0 && arr [ i ] != x ; i -- ) { int curr = arr [ i ] ; arr [ i ] = prev ; prev = curr ; }
if ( i < 0 ) return 0 ;
arr [ i ] = prev ; return ( n - 1 ) ; }
int main ( ) { int arr [ ] = { 11 , 15 , 6 , 8 , 9 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 6 ;
n = deleteElement ( arr , n , x ) ; cout << " Modified ▁ array ▁ is ▁ STRNEWLINE " ; for ( int i = 0 ; i < n ; i ++ ) cout << arr [ i ] << " ▁ " ; return 0 ; }
int getInvCount ( int arr [ ] , int n ) {
int invcount = 0 ; for ( int i = 1 ; i < n - 1 ; i ++ ) {
int small = 0 ; for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) small ++ ;
int great = 0 ; for ( int j = i - 1 ; j >= 0 ; j -- ) if ( arr [ i ] < arr [ j ] ) great ++ ;
invcount += great * small ; } return invcount ; }
int main ( ) { int arr [ ] = { 8 , 4 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Inversion ▁ Count ▁ : ▁ " << getInvCount ( arr , n ) ; return 0 ; }
int maxWater ( int arr [ ] , int n ) {
int res = 0 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
int left = arr [ i ] ; for ( int j = 0 ; j < i ; j ++ ) left = max ( left , arr [ j ] ) ;
int right = arr [ i ] ; for ( int j = i + 1 ; j < n ; j ++ ) right = max ( right , arr [ j ] ) ;
res = res + ( min ( left , right ) - arr [ i ] ) ; } return res ; }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxWater ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
int findWater ( int arr [ ] , int n ) {
int left [ n ] ;
int right [ n ] ;
int water = 0 ;
left [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) left [ i ] = max ( left [ i - 1 ] , arr [ i ] ) ;
right [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) right [ i ] = max ( right [ i + 1 ] , arr [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) water += min ( left [ i ] , right [ i ] ) - arr [ i ] ; return water ; }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " << findWater ( arr , n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; int findWater ( int arr [ ] , int n ) {
int result = 0 ;
int left_max = 0 , right_max = 0 ;
int lo = 0 , hi = n - 1 ; while ( lo <= hi ) { if ( arr [ lo ] < arr [ hi ] ) { if ( arr [ lo ] > left_max )
left_max = arr [ lo ] ; else
result += left_max - arr [ lo ] ; lo ++ ; } else { if ( arr [ hi ] > right_max )
right_max = arr [ hi ] ; else result += right_max - arr [ hi ] ; hi -- ; } } return result ; }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " << findWater ( arr , n ) ; }
int maxWater ( int arr [ ] , int n ) { int size = n - 1 ;
int prev = arr [ 0 ] ;
int prev_index = 0 ; int water = 0 ;
int temp = 0 ; for ( int i = 1 ; i <= size ; i ++ ) {
if ( arr [ i ] >= prev ) { prev = arr [ i ] ; prev_index = i ;
temp = 0 ; } else {
water += prev - arr [ i ] ;
temp += prev - arr [ i ] ; } }
if ( prev_index < size ) {
water -= temp ;
prev = arr [ size ] ;
for ( int i = size ; i >= prev_index ; i -- ) {
if ( arr [ i ] >= prev ) { prev = arr [ i ] ; } else { water += prev - arr [ i ] ; } } }
return water ; }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxWater ( arr , n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; int maxWater ( int arr [ ] , int n ) {
int left = 0 ; int right = n - 1 ;
int l_max = 0 ; int r_max = 0 ;
int result = 0 ; while ( left <= right ) {
if ( r_max <= l_max ) {
result += max ( 0 , r_max - arr [ right ] ) ;
r_max = max ( r_max , arr [ right ] ) ;
right -= 1 ; } else {
result += max ( 0 , l_max - arr [ left ] ) ;
l_max = max ( l_max , arr [ left ] ) ;
left += 1 ; } } return result ; }
int main ( ) { int arr [ ] = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxWater ( arr , n ) << endl ; return 0 ; }
int missingK ( int a [ ] , int k , int n ) { int difference = 0 , ans = 0 , count = k ; bool flag = 0 ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { difference = 0 ;
if ( ( a [ i ] + 1 ) != a [ i + 1 ] ) {
difference += ( a [ i + 1 ] - a [ i ] ) - 1 ;
if ( difference >= count ) { ans = a [ i ] + count ; flag = 1 ; break ; } else count -= difference ; } }
if ( flag ) return ans ; else return -1 ; }
int a [ ] = { 1 , 5 , 11 , 19 } ;
int k = 11 ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
int missing = missingK ( a , k , n ) ; cout << missing << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void printUncommon ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) { int i = 0 , j = 0 , k = 0 ; while ( i < n1 && j < n2 ) {
if ( arr1 [ i ] < arr2 [ j ] ) { cout << arr1 [ i ] << " ▁ " ; i ++ ; k ++ ; } else if ( arr2 [ j ] < arr1 [ i ] ) { cout << arr2 [ j ] << " ▁ " ; k ++ ; j ++ ; }
else { i ++ ; j ++ ; } }
while ( i < n1 ) { cout << arr1 [ i ] << " ▁ " ; i ++ ; k ++ ; } while ( j < n2 ) { cout << arr2 [ j ] << " ▁ " ; j ++ ; k ++ ; } }
int main ( ) { int arr1 [ ] = { 10 , 20 , 30 } ; int arr2 [ ] = { 20 , 25 , 30 , 40 , 50 } ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; printUncommon ( arr1 , arr2 , n1 , n2 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int leastFrequent ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
int min_count = n + 1 , res = -1 , curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
int main ( ) { int arr [ ] = { 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << leastFrequent ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int leastFrequent ( int arr [ ] , int n ) {
unordered_map < int , int > hash ; for ( int i = 0 ; i < n ; i ++ ) hash [ arr [ i ] ] ++ ;
int min_count = n + 1 , res = -1 ; for ( auto i : hash ) { if ( min_count >= i . second ) { res = i . first ; min_count = i . second ; } } return res ; }
int main ( ) { int arr [ ] = { 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << leastFrequent ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define M  4 NEW_LINE using namespace std ;
int maximumSum ( int a [ ] [ M ] , int n ) {
int sum = a [ n - 1 ] [ M - 1 ] ; int prev = a [ n - 1 ] [ M - 1 ] ; int i , j ;
for ( i = n - 2 ; i >= 0 ; i -- ) { for ( j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i ] [ j ] < prev ) { prev = a [ i ] [ j ] ; sum += prev ; break ; } }
if ( j == -1 ) return 0 ; } return sum ; }
int main ( ) { int arr [ ] [ M ] = { { 1 , 7 , 3 , 4 } , { 4 , 2 , 5 , 1 } , { 9 , 5 , 1 , 8 } } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maximumSum ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define M  4 NEW_LINE using namespace std ;
int maximumSum ( int a [ ] [ M ] , int n ) {
int prev = * max_element ( & a [ n - 1 ] [ 0 ] , & a [ n - 1 ] [ M - 1 ] + 1 ) ;
int sum = prev ; for ( int i = n - 2 ; i >= 0 ; i -- ) { int max_smaller = INT_MIN ; for ( int j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i ] [ j ] < prev && a [ i ] [ j ] > max_smaller ) max_smaller = a [ i ] [ j ] ; }
if ( max_smaller == INT_MIN ) return 0 ; prev = max_smaller ; sum += max_smaller ; } return sum ; }
int main ( ) { int arr [ ] [ M ] = { { 1 , 7 , 3 , 4 } , { 4 , 2 , 5 , 1 } , { 9 , 5 , 1 , 8 } } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maximumSum ( arr , n ) ; return 0 ; }
int countPairs ( int A [ ] , int n , int k ) { int ans = 0 ;
sort ( A , A + n ) ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int x = 0 ;
while ( ( A [ i ] * pow ( k , x ) ) <= A [ j ] ) { if ( ( A [ i ] * pow ( k , x ) ) == A [ j ] ) { ans ++ ; break ; } x ++ ; } } } return ans ; }
int main ( ) { int A [ ] = { 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 } ; int n = sizeof ( A ) / sizeof ( A [ 0 ] ) ; int k = 3 ; cout << countPairs ( A , n , k ) ; return 0 ; }
int findValue ( int a [ ] , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] == k ) k *= 2 ; } return k ; }
int main ( ) { int arr [ ] = { 2 , 3 , 4 , 10 , 8 , 1 } , k = 2 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findValue ( arr , n , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE void dupLastIndex ( int arr [ ] , int n ) {
if ( arr == NULL n <= 0 ) return ;
for ( int i = n - 1 ; i > 0 ; i -- ) { if ( arr [ i ] == arr [ i - 1 ] ) { printf ( " Last ▁ index : ▁ % d STRNEWLINE Last ▁ " " duplicate ▁ item : ▁ % d STRNEWLINE " , i , arr [ i ] ) ; return ; } }
printf ( " no ▁ duplicate ▁ found " ) ; }
int main ( ) { int arr [ ] = { 1 , 5 , 5 , 6 , 6 , 7 , 9 } ; int n = sizeof ( arr ) / sizeof ( int ) ; dupLastIndex ( arr , n ) ; return 0 ; }
int findSmallest ( int a [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < n ; j ++ ) if ( a [ j ] % a [ i ] ) break ;
if ( j == n ) return a [ i ] ; } return -1 ; }
int main ( ) { int a [ ] = { 25 , 20 , 5 , 10 , 100 } ; int n = sizeof ( a ) / sizeof ( int ) ; cout << findSmallest ( a , n ) ; return 0 ; }
int findSmallest ( int a [ ] , int n ) {
int smallest = * min_element ( a , a + n ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( a [ i ] % smallest ) return -1 ; return smallest ; }
int main ( ) { int a [ ] = { 25 , 20 , 5 , 10 , 100 } ; int n = sizeof ( a ) / sizeof ( int ) ; cout << findSmallest ( a , n ) ; return 0 ; }
void printMax ( int arr [ ] , int k , int n ) {
vector < int > brr ( arr , arr + n ) ;
sort ( brr . begin ( ) , brr . end ( ) , greater < int > ( ) ) ;
for ( int i = 0 ; i < n ; ++ i ) if ( binary_search ( brr . begin ( ) , brr . begin ( ) + k , arr [ i ] , greater < int > ( ) ) ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 50 , 8 , 45 , 12 , 25 , 40 , 84 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; printMax ( arr , k , n ) ; return 0 ; }
int findIndex ( int arr [ ] , int len ) {
int maxIndex = 0 ; for ( int i = 0 ; i < len ; ++ i ) if ( arr [ i ] > arr [ maxIndex ] ) maxIndex = i ;
for ( int i = 0 ; i < len ; ++ i ) if ( maxIndex != i && arr [ maxIndex ] < 2 * arr [ i ] ) return -1 ; return maxIndex ; }
int main ( ) { int arr [ ] = { 3 , 6 , 1 , 0 } ; int len = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << ( findIndex ( arr , len ) ) ; }
int find_consecutive_steps ( int arr [ ] , int len ) { int count = 0 ; int maximum = 0 ; for ( int index = 1 ; index < len ; index ++ ) {
if ( arr [ index ] > arr [ index - 1 ] ) count ++ ; else { maximum = max ( maximum , count ) ; count = 0 ; } } return max ( maximum , count ) ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int len = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << find_consecutive_steps ( arr , len ) ; }
#include <bits/stdc++.h> NEW_LINE #define ll  long long int NEW_LINE using namespace std ; ll CalculateMax ( ll arr [ ] , int n ) {
sort ( arr , arr + n ) ; int min_sum = arr [ 0 ] + arr [ 1 ] ; int max_sum = arr [ n - 1 ] + arr [ n - 2 ] ; return abs ( max_sum - min_sum ) ; }
int main ( ) { ll arr [ ] = { 6 , 7 , 1 , 11 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << CalculateMax ( arr , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define ll  long long int NEW_LINE using namespace std ; ll calculate ( ll a [ ] , ll n ) {
sort ( a , a + n ) ;
vector < ll > s ; for ( int i = 0 , j = n - 1 ; i < j ; i ++ , j -- ) s . push_back ( a [ i ] + a [ j ] ) ; ll mini = * min_element ( s . begin ( ) , s . end ( ) ) ; ll maxi = * max_element ( s . begin ( ) , s . end ( ) ) ; return abs ( maxi - mini ) ; }
int main ( ) { ll a [ ] = { 2 , 6 , 4 , 3 } ; int n = sizeof ( a ) / ( sizeof ( a [ 0 ] ) ) ; cout << calculate ( a , n ) << endl ; return 0 ; }
void printMinDiffPairs ( int arr [ ] , int n ) { if ( n <= 1 ) return ;
sort ( arr , arr + n ) ;
int minDiff = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) minDiff = min ( minDiff , arr [ i ] - arr [ i - 1 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( ( arr [ i ] - arr [ i - 1 ] ) == minDiff ) cout << " ( " << arr [ i - 1 ] << " , ▁ " << arr [ i ] << " ) , ▁ " ; }
int main ( ) { int arr [ ] = { 5 , 3 , 2 , 4 , 1 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printMinDiffPairs ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int calculateDiff ( int i , int j , int arr [ ] ) {
return abs ( arr [ i ] - arr [ j ] ) + abs ( i - j ) ; }
int maxDistance ( int arr [ ] , int n ) {
int result = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i ; j < n ; j ++ ) {
if ( calculateDiff ( i , j , arr ) > result ) result = calculateDiff ( i , j , arr ) ; } } return result ; }
int main ( ) { int arr [ ] = { -70 , -64 , -6 , -56 , 64 , 61 , -57 , 16 , 48 , -98 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxDistance ( arr , n ) << endl ; return 0 ; }
int maxDistance ( int arr [ ] , int n ) {
int max1 = INT_MIN , min1 = INT_MAX ; int max2 = INT_MIN , min2 = INT_MAX ; for ( int i = 0 ; i < n ; i ++ ) {
max1 = max ( max1 , arr [ i ] + i ) ; min1 = min ( min1 , arr [ i ] + i ) ; max2 = max ( max2 , arr [ i ] - i ) ; min2 = min ( min2 , arr [ i ] - i ) ; }
return max ( max1 - min1 , max2 - min2 ) ; }
int main ( ) { int arr [ ] = { -70 , -64 , -6 , -56 , 64 , 61 , -57 , 16 , 48 , -98 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << maxDistance ( arr , n ) << endl ; return 0 ; }
int extrema ( int a [ ] , int n ) { int count = 0 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
count += ( a [ i ] > a [ i - 1 ] && a [ i ] > a [ i + 1 ] ) ;
count += ( a [ i ] < a [ i - 1 ] && a [ i ] < a [ i + 1 ] ) ; } return count ; }
int main ( ) { int a [ ] = { 1 , 0 , 2 , 1 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << extrema ( a , n ) ; return 0 ; }
int findClosest ( int arr [ ] , int n , int target ) {
if ( target <= arr [ 0 ] ) return arr [ 0 ] ; if ( target >= arr [ n - 1 ] ) return arr [ n - 1 ] ;
int i = 0 , j = n , mid = 0 ; while ( i < j ) { mid = ( i + j ) / 2 ; if ( arr [ mid ] == target ) return arr [ mid ] ;
if ( target < arr [ mid ] ) {
if ( mid > 0 && target > arr [ mid - 1 ] ) return getClosest ( arr [ mid - 1 ] , arr [ mid ] , target ) ;
j = mid ; }
else { if ( mid < n - 1 && target < arr [ mid + 1 ] ) return getClosest ( arr [ mid ] , arr [ mid + 1 ] , target ) ;
i = mid + 1 ; } }
return arr [ mid ] ; }
int getClosest ( int val1 , int val2 , int target ) { if ( target - val1 >= val2 - target ) return val2 ; else return val1 ; }
int main ( ) { int arr [ ] = { 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int target = 11 ; cout << ( findClosest ( arr , n , target ) ) ; }
int sum ( int a [ ] , int n ) {
int maxSum = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) maxSum = max ( maxSum , a [ i ] + a [ j ] ) ;
int c = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( a [ i ] + a [ j ] == maxSum ) c ++ ; return c ; }
int main ( ) { int array [ ] = { 1 , 1 , 1 , 2 , 2 , 2 } ; int n = sizeof ( array ) / sizeof ( array [ 0 ] ) ; cout << sum ( array , n ) ; return 0 ; }
int sum ( int a [ ] , int n ) {
int maxVal = a [ 0 ] , maxCount = 1 ; int secondMax = INT_MIN , secondMaxCount ; for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == maxVal ) maxCount ++ ; else if ( a [ i ] > maxVal ) { secondMax = maxVal ; secondMaxCount = maxCount ; maxVal = a [ i ] ; maxCount = 1 ; } else if ( a [ i ] == secondMax ) { secondMax = a [ i ] ; secondMaxCount ++ ; } else if ( a [ i ] > secondMax ) { secondMax = a [ i ] ; secondMaxCount = 1 ; } }
if ( maxCount > 1 ) return maxCount * ( maxCount - 1 ) / 2 ;
return secondMaxCount ; }
int main ( ) { int array [ ] = { 1 , 1 , 1 , 2 , 2 , 2 , 3 } ; int n = sizeof ( array ) / sizeof ( array [ 0 ] ) ; cout << sum ( array , n ) ; return 0 ; }
void printSmall ( int arr [ ] , int asize , int n ) {
vector < int > copy_arr ( arr , arr + asize ) ;
sort ( copy_arr . begin ( ) , copy_arr . begin ( ) + asize ) ;
for ( int i = 0 ; i < asize ; ++ i ) if ( binary_search ( copy_arr . begin ( ) , copy_arr . begin ( ) + n , arr [ i ] ) ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 } ; int asize = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int n = 5 ; printSmall ( arr , asize , n ) ; return 0 ; }
void printKMissing ( int arr [ ] , int n , int k ) { sort ( arr , arr + n ) ;
int i = 0 ; while ( i < n && arr [ i ] <= 0 ) i ++ ;
int count = 0 , curr = 1 ; while ( count < k && i < n ) { if ( arr [ i ] != curr ) { cout << curr << " ▁ " ; count ++ ; } else i ++ ; curr ++ ; }
while ( count < k ) { cout << curr << " ▁ " ; curr ++ ; count ++ ; } }
int main ( ) { int arr [ ] = { 2 , 3 , 4 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; printKMissing ( arr , n , k ) ; return 0 ; }
void printmissingk ( int arr [ ] , int n , int k ) {
map < int , int > d ;
for ( int i = 0 ; i < n ; i ++ ) d [ arr [ i ] ] = arr [ i ] ; int cnt = 1 ; int fl = 0 ;
for ( int i = 0 ; i < ( n + k ) ; i ++ ) { if ( d . find ( cnt ) == d . end ( ) ) { fl += 1 ; cout << cnt << " ▁ " ; if ( fl == k ) break ; } cnt += 1 ; } }
int main ( ) { int arr [ ] = { 1 , 4 , 3 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 3 ; ; printmissingk ( arr , n , k ) ; }
int nobleInteger ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( arr [ i ] < arr [ j ] ) count ++ ;
if ( count == arr [ i ] ) return arr [ i ] ; } return -1 ; }
int main ( ) { int arr [ ] = { 10 , 3 , 20 , 40 , 2 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int res = nobleInteger ( arr , size ) ; if ( res != -1 ) cout << " The ▁ noble ▁ integer ▁ is ▁ " << res ; else cout << " No ▁ Noble ▁ Integer ▁ Found " ; }
int nobleInteger ( int arr [ ] , int n ) { sort ( arr , arr + n ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] == arr [ i + 1 ] ) continue ;
if ( arr [ i ] == n - i - 1 ) return arr [ i ] ; } if ( arr [ n - 1 ] == 0 ) return arr [ n - 1 ] ; return -1 ; }
int main ( ) { int arr [ ] = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr , 5 ) ; if ( res != -1 ) cout << " The ▁ noble ▁ integer ▁ is ▁ " << res ; else cout << " No ▁ Noble ▁ Integer ▁ Found " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int nobleInteger ( int arr [ ] , int n ) {
int countArr [ n + 1 ] = { 0 } ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] < 0 ) { continue ; }
else if ( arr [ i ] >= n ) { countArr [ n ] ++ ; }
else { countArr [ arr [ i ] ] ++ ; } }
int totalGreater = countArr [ n ] ;
for ( int i = n - 1 ; i >= 0 ; i -- ) {
if ( totalGreater == i && countArr [ i ] > 0 ) { return i ; }
else if ( totalGreater > i ) { return -1 ; }
totalGreater += countArr [ i ] ; } return -1 ; }
int main ( ) { int arr [ ] = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr , 5 ) ; if ( res != -1 ) cout << " The ▁ noble ▁ integer ▁ is ▁ " << res ; else cout << " No ▁ Noble ▁ Integer ▁ Found " ; return 0 ; }
long long int findMinSum ( long long int a [ ] , long long int b [ ] , int n ) {
sort ( a , a + n ) ; sort ( b , b + n ) ;
long long int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + abs ( a [ i ] - b [ i ] ) ; return sum ; }
long long int a [ ] = { 4 , 1 , 8 , 7 } ; long long int b [ ] = { 2 , 3 , 6 , 5 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; printf ( " % lld STRNEWLINE " , findMinSum ( a , b , n ) ) ; return 0 ; }
bool checkIsAP ( int arr [ ] , int n ) { if ( n == 1 ) return true ;
sort ( arr , arr + n ) ;
int d = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] != d ) return false ; return true ; }
int main ( ) { int arr [ ] = { 20 , 15 , 5 , 0 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; ( checkIsAP ( arr , n ) ) ? ( cout << " Yes " << endl ) : ( cout << " No " << endl ) ; return 0 ; }
bool checkIsAP ( int arr [ ] , int n ) { unordered_map < int , int > hm ; int smallest = INT_MAX , second_smallest = INT_MAX ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] < smallest ) { second_smallest = smallest ; smallest = arr [ i ] ; }
else if ( arr [ i ] != smallest && arr [ i ] < second_smallest ) second_smallest = arr [ i ] ;
if ( hm . find ( arr [ i ] ) == hm . end ( ) ) hm [ arr [ i ] ] ++ ;
else return false ; }
int diff = second_smallest - smallest ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( hm . find ( second_smallest ) == hm . end ( ) ) return false ; second_smallest += diff ; } return true ; }
int main ( ) { int arr [ ] = { 20 , 15 , 5 , 0 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; ( checkIsAP ( arr , n ) ) ? ( cout << " Yes " << endl ) : ( cout << " No " << endl ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int minProductSubset ( int a [ ] , int n ) { if ( n == 1 ) return a [ 0 ] ;
int max_neg = INT_MIN ; int min_pos = INT_MAX ; int count_neg = 0 , count_zero = 0 ; int prod = 1 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == 0 ) { count_zero ++ ; continue ; }
if ( a [ i ] < 0 ) { count_neg ++ ; max_neg = max ( max_neg , a [ i ] ) ; }
if ( a [ i ] > 0 ) min_pos = min ( min_pos , a [ i ] ) ; prod = prod * a [ i ] ; }
if ( count_zero == n || ( count_neg == 0 && count_zero > 0 ) ) return 0 ;
if ( count_neg == 0 ) return min_pos ;
if ( ! ( count_neg & 1 ) && count_neg != 0 ) {
prod = prod / max_neg ; } return prod ; }
int main ( ) { int a [ ] = { -1 , -1 , -2 , 4 , 3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << minProductSubset ( a , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countPairs ( int a [ ] , int n ) {
int mn = INT_MAX ; int mx = INT_MIN ; for ( int i = 0 ; i < n ; i ++ ) { mn = min ( mn , a [ i ] ) ; mx = max ( mx , a [ i ] ) ; }
int c1 = 0 ;
int c2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] == mn ) c1 ++ ; if ( a [ i ] == mx ) c2 ++ ; }
if ( mn == mx ) return n * ( n - 1 ) / 2 ; else return c1 * c2 ; }
int main ( ) { int a [ ] = { 3 , 2 , 1 , 1 , 3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; cout << countPairs ( a , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int findElement ( int a [ ] , int n , int b ) {
sort ( a , a + n ) ;
int max = a [ n - 1 ] ; while ( b < max ) {
if ( binary_search ( a , a + n , b ) ) b *= 2 ; else return b ; } return b ; }
int main ( ) { int a [ ] = { 1 , 2 , 3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int b = 1 ; cout << findElement ( a , n , b ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define Mod  1000000007 NEW_LINE using namespace std ;
long long int findSum ( int arr [ ] , int n ) { long long int sum = 0 ;
sort ( arr , arr + n ) ;
int i = 0 ; while ( i < n && arr [ i ] < 0 ) { if ( i != n - 1 && arr [ i + 1 ] <= 0 ) { sum = ( sum + ( arr [ i ] * arr [ i + 1 ] ) % Mod ) % Mod ; i += 2 ; } else break ; }
int j = n - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { if ( j != 0 && arr [ j - 1 ] > 0 ) { sum = ( sum + ( arr [ j ] * arr [ j - 1 ] ) % Mod ) % Mod ; j -= 2 ; } else break ; }
if ( j > i ) sum = ( sum + ( arr [ i ] * arr [ j ] ) % Mod ) % Mod ;
else if ( i == j ) sum = ( sum + arr [ i ] ) % Mod ; return sum ; }
int main ( ) { int arr [ ] = { -1 , 9 , 4 , 5 , -4 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << findSum ( arr , n ) ; return 0 ; }
void push ( Node * * head_ref , int new_data ) {
Node * new_node = new Node ( ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void insertAfter ( Node * prev_node , int new_data ) {
if ( prev_node == NULL ) { cout << " the ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL " ; return ; }
Node * new_node = new Node ( ) ; new_node -> data = new_data ;
new_node -> next = prev_node -> next ;
prev_node -> next = new_node ; }
struct Node { int key ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int new_key ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> key = new_key ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
bool search ( struct Node * head , int x ) {
if ( head == NULL ) return false ;
if ( head -> key == x ) return true ;
return search ( head -> next , x ) ; }
push ( & head , 10 ) ; push ( & head , 30 ) ; push ( & head , 11 ) ; push ( & head , 21 ) ; push ( & head , 14 ) ; search ( head , 21 ) ? cout << " Yes " : cout << " No " ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void reverse ( struct Node * * head_ref ) { struct Node * prev = NULL ; struct Node * current = * head_ref ;
while ( current != NULL ) {
current = ( struct Node * ) ( ( ut ) prev ^ ( ut ) current ^ ( ut ) ( current -> next ) ^ ( ut ) ( current -> next = prev ) ^ ( ut ) ( prev = current ) ) ; } * head_ref = prev ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( struct Node * head ) { struct Node * temp = head ; while ( temp != NULL ) { printf ( " % d ▁ " , temp -> data ) ; temp = temp -> next ; } }
int main ( ) {
struct Node { int data ; struct Node * next ; } ;
void printList ( struct Node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> next ; } cout << endl ; }
Node * newNode ( int key ) { Node * temp = new Node ; temp -> data = key ; temp -> next = NULL ; return temp ; }
Node * insertBeg ( Node * head , int val ) { Node * temp = newNode ( val ) ; temp -> next = head ; head = temp ; return head ; }
void rearrangeOddEven ( Node * head ) { stack < Node * > odd ; stack < Node * > even ; int i = 1 ; while ( head != nullptr ) { if ( head -> data % 2 != 0 && i % 2 == 0 ) {
odd . push ( head ) ; } else if ( head -> data % 2 == 0 && i % 2 != 0 ) {
even . push ( head ) ; } head = head -> next ; i ++ ; } while ( ! odd . empty ( ) && ! even . empty ( ) ) {
swap ( odd . top ( ) -> data , even . top ( ) -> data ) ; odd . pop ( ) ; even . pop ( ) ; } }
int main ( ) { Node * head = newNode ( 8 ) ; head = insertBeg ( head , 7 ) ; head = insertBeg ( head , 6 ) ; head = insertBeg ( head , 5 ) ; head = insertBeg ( head , 3 ) ; head = insertBeg ( head , 2 ) ; head = insertBeg ( head , 1 ) ; cout << " Linked ▁ List : " << endl ; printList ( head ) ; rearrangeOddEven ( head ) ; cout << " Linked ▁ List ▁ after ▁ " << " Rearranging : " << endl ; printList ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void printList ( struct Node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> next ; } cout << endl ; }
Node * newNode ( int key ) { Node * temp = new Node ; temp -> data = key ; temp -> next = NULL ; return temp ; }
Node * insertBeg ( Node * head , int val ) { Node * temp = newNode ( val ) ; temp -> next = head ; head = temp ; return head ; }
void rearrange ( Node * * head ) {
Node * even ; Node * temp , * prev_temp ; Node * i , * j , * k , * l , * ptr ;
temp = ( * head ) -> next ; prev_temp = * head ; while ( temp != nullptr ) {
Node * x = temp -> next ;
if ( temp -> data % 2 != 0 ) { prev_temp -> next = x ; temp -> next = ( * head ) ; ( * head ) = temp ; } else { prev_temp = temp ; }
temp = x ; }
temp = ( * head ) -> next ; prev_temp = ( * head ) ; while ( temp != nullptr && temp -> data % 2 != 0 ) { prev_temp = temp ; temp = temp -> next ; } even = temp ;
prev_temp -> next = nullptr ;
i = * head ; j = even ; while ( j != nullptr && i != nullptr ) {
k = i -> next ; l = j -> next ; i -> next = j ; j -> next = k ;
ptr = j ;
i = k ; j = l ; } if ( i == nullptr ) {
ptr -> next = j ; }
}
int main ( ) { Node * head = newNode ( 8 ) ; head = insertBeg ( head , 7 ) ; head = insertBeg ( head , 6 ) ; head = insertBeg ( head , 3 ) ; head = insertBeg ( head , 5 ) ; head = insertBeg ( head , 1 ) ; head = insertBeg ( head , 2 ) ; head = insertBeg ( head , 10 ) ; cout << " Linked ▁ List : " << endl ; printList ( head ) ; cout << " Rearranged ▁ List " << endl ; rearrange ( & head ) ; printList ( head ) ; }
struct Node { int data ; struct Node * left , * right ; } ;
int minDepth ( Node * root ) {
if ( root == NULL ) return 0 ;
if ( root -> left == NULL && root -> right == NULL ) return 1 ; int l = INT_MAX , r = INT_MAX ;
if ( root -> left ) l = minDepth ( root -> left ) ;
if ( root -> right ) r = minDepth ( root -> right ) ; return min ( l , r ) + 1 ; }
Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; cout << " The ▁ minimum ▁ depth ▁ of ▁ binary ▁ tree ▁ is ▁ : ▁ " << minDepth ( root ) ; return 0 ; }
void deleteAlt ( Node * head ) { if ( head == NULL ) return ; Node * node = head -> next ; if ( node == NULL ) return ;
head -> next = node -> next ;
deleteAlt ( head -> next ) ; }
void AlternatingSplit ( Node * source , Node * * aRef , Node * * bRef ) { Node aDummy ;
Node * aTail = & aDummy ; Node bDummy ;
Node * bTail = & bDummy ; Node * current = source ; aDummy . next = NULL ; bDummy . next = NULL ; while ( current != NULL ) { MoveNode ( & ( aTail -> next ) , t ) ;
aTail = aTail -> next ;
if ( current != NULL ) { MoveNode ( & ( bTail -> next ) , t ) ; bTail = bTail -> next ; } } * aRef = aDummy . next ; * bRef = bDummy . next ; }
bool areIdentical ( Node * a , Node * b ) {
if ( a == NULL && b == NULL ) return true ;
if ( a != NULL && b != NULL ) return ( a -> data == b -> data ) && areIdentical ( a -> next , b -> next ) ;
return false ; }
class Node { public : int data ; Node * next ; } ;
void rotate ( Node * * head_ref , int k ) { if ( k == 0 ) return ;
Node * current = * head_ref ;
while ( current -> next != NULL ) current = current -> next ; current -> next = * head_ref ; current = * head_ref ;
for ( int i = 0 ; i < k - 1 ; i ++ ) current = current -> next ;
* head_ref = current -> next ; current -> next = NULL ; }
void push ( Node * * head_ref , int new_data ) {
Node * new_node = new Node ( ) ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( Node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> next ; } }
for ( int i = 60 ; i > 0 ; i -= 10 ) push ( & head , i ) ; cout << " Given ▁ linked ▁ list ▁ STRNEWLINE " ; printList ( head ) ; rotate ( & head , 4 ) ; cout << " Rotated Linked list " ; printList ( head ) ; return ( 0 ) ; }
class Node { public : int data ; Node * next ; } ;
int count [ 3 ] = { 0 , 0 , 0 } ; Node * ptr = head ;
while ( ptr != NULL ) { count [ ptr -> data ] += 1 ; ptr = ptr -> next ; } int i = 0 ; ptr = head ;
while ( ptr != NULL ) { if ( count [ i ] == 0 ) ++ i ; else { ptr -> data = i ; -- count [ i ] ; ptr = ptr -> next ; } } }
void push ( Node * * head_ref , int new_data ) {
Node * new_node = new Node ( ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( Node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> next ; } cout << endl ; }
Node * head = NULL ; push ( & head , 0 ) ; push ( & head , 1 ) ; push ( & head , 0 ) ; push ( & head , 2 ) ; push ( & head , 1 ) ; push ( & head , 1 ) ; push ( & head , 2 ) ; push ( & head , 1 ) ; push ( & head , 2 ) ; cout << " Linked ▁ List ▁ Before ▁ Sorting STRNEWLINE " ; printList ( head ) ; sortList ( head ) ; cout << " Linked ▁ List ▁ After ▁ Sorting STRNEWLINE " ; printList ( head ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct node { int data ; struct node * next ; } ; typedef struct node Node ;
void rearrange ( Node * head ) {
if ( head == NULL ) return ;
Node * prev = head , * curr = head -> next ; while ( curr ) {
if ( prev -> data > curr -> data ) swap ( prev -> data , curr -> data ) ;
if ( curr -> next && curr -> next -> data > curr -> data ) swap ( curr -> next -> data , curr -> data ) ; prev = curr -> next ; if ( ! curr -> next ) break ; curr = curr -> next -> next ; } }
void push ( Node * * head , int k ) { Node * tem = ( Node * ) malloc ( sizeof ( Node ) ) ; tem -> data = k ; tem -> next = * head ; * head = tem ; }
void display ( Node * head ) { Node * curr = head ; while ( curr != NULL ) { printf ( " % d ▁ " , curr -> data ) ; curr = curr -> next ; } }
push ( & head , 7 ) ; push ( & head , 3 ) ; push ( & head , 8 ) ; push ( & head , 6 ) ; push ( & head , 9 ) ; rearrange ( head ) ; display ( head ) ; return 0 ; }
class Node { public : int data ; Node * next ; } ;
Node * newNode ( int key ) { Node * temp = new Node ; temp -> data = key ; temp -> next = NULL ; return temp ; }
Node * rearrangeEvenOdd ( Node * head ) {
if ( head == NULL ) return NULL ;
Node * odd = head ; Node * even = head -> next ;
Node * evenFirst = even ; while ( 1 ) {
if ( ! odd || ! even || ! ( even -> next ) ) { odd -> next = evenFirst ; break ; }
odd -> next = even -> next ; odd = even -> next ;
if ( odd -> next == NULL ) { even -> next = NULL ; odd -> next = evenFirst ; break ; }
even -> next = odd -> next ; even = odd -> next ; } return head ; }
void printlist ( Node * node ) { while ( node != NULL ) { cout << node -> data << " - > " ; node = node -> next ; } cout << " NULL " << endl ; }
int main ( void ) { Node * head = newNode ( 1 ) ; head -> next = newNode ( 2 ) ; head -> next -> next = newNode ( 3 ) ; head -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next = newNode ( 5 ) ; cout << " Given ▁ Linked ▁ List STRNEWLINE " ; printlist ( head ) ; head = rearrangeEvenOdd ( head ) ; cout << " Modified ▁ Linked ▁ List STRNEWLINE " ; printlist ( head ) ; return 0 ; }
struct Node { int data ; Node * next ; } ;
Node * newNode ( int data ) { Node * new_node = new Node ; new_node -> data = data ; new_node -> next = NULL ; return new_node ; }
int addWithCarry ( Node * head ) {
if ( head == NULL ) return 1 ;
int res = head -> data + addWithCarry ( head -> next ) ;
head -> data = ( res ) % 10 ; return ( res ) / 10 ; }
Node * addOne ( Node * head ) {
int carry = addWithCarry ( head ) ;
if ( carry ) { Node * newNode = new Node ; newNode -> data = carry ; newNode -> next = head ;
return newNode ; } return head ; }
void printList ( Node * node ) { while ( node != NULL ) { printf ( " % d " , node -> data ) ; node = node -> next ; } printf ( " STRNEWLINE " ) ; }
int main ( void ) { Node * head = newNode ( 1 ) ; head -> next = newNode ( 9 ) ; head -> next -> next = newNode ( 9 ) ; head -> next -> next -> next = newNode ( 9 ) ; printf ( " List ▁ is ▁ " ) ; printList ( head ) ; head = addOne ( head ) ; printf ( " Resultant list is " printList ( head ) ; return 0 ; }
struct Node { int data ; Node * next , * arbit ; } ;
Node * reverse ( Node * head ) { Node * prev = NULL , * current = head , * next ; while ( current != NULL ) { next = current -> next ; current -> next = prev ; prev = current ; current = next ; } return prev ; }
Node * populateArbit ( Node * head ) {
head = reverse ( head ) ;
Node * max = head ;
Node * temp = head -> next ; while ( temp != NULL ) {
temp -> arbit = max ;
if ( max -> data < temp -> data ) max = temp ;
temp = temp -> next ; }
return reverse ( head ) ; }
void printNextArbitPointers ( Node * node ) { printf ( " Node TABSYMBOL Next ▁ Pointer TABSYMBOL Arbit ▁ Pointer STRNEWLINE " ) ; while ( node != NULL ) { cout << node -> data << " TABSYMBOL TABSYMBOL " ; if ( node -> next ) cout << node -> next -> data << " TABSYMBOL TABSYMBOL " ; else cout << " NULL " << " TABSYMBOL TABSYMBOL " ; if ( node -> arbit ) cout << node -> arbit -> data ; else cout << " NULL " ; cout << endl ; node = node -> next ; } }
Node * newNode ( int data ) { Node * new_node = new Node ; new_node -> data = data ; new_node -> next = NULL ; return new_node ; }
int main ( ) { Node * head = newNode ( 5 ) ; head -> next = newNode ( 10 ) ; head -> next -> next = newNode ( 2 ) ; head -> next -> next -> next = newNode ( 3 ) ; head = populateArbit ( head ) ; printf ( " Resultant ▁ Linked ▁ List ▁ is : ▁ STRNEWLINE " ) ; printNextArbitPointers ( head ) ; return 0 ; }
struct Node { int data ; Node * next , * arbit ; } ;
void populateArbit ( Node * head ) {
if ( head == NULL ) return ;
if ( head -> next == NULL ) { maxNode = head ; return ; }
populateArbit ( head -> next ) ;
head -> arbit = maxNode ;
if ( head -> data > maxNode -> data ) maxNode = head ; return ; }
void printNextArbitPointers ( Node * node ) { printf ( " Node TABSYMBOL Next ▁ Pointer TABSYMBOL Arbit ▁ Pointer STRNEWLINE " ) ; while ( node != NULL ) { cout << node -> data << " TABSYMBOL TABSYMBOL " ; if ( node -> next ) cout << node -> next -> data << " TABSYMBOL TABSYMBOL " ; else cout << " NULL " << " TABSYMBOL TABSYMBOL " ; if ( node -> arbit ) cout << node -> arbit -> data ; else cout << " NULL " ; cout << endl ; node = node -> next ; } }
Node * newNode ( int data ) { Node * new_node = new Node ; new_node -> data = data ; new_node -> next = NULL ; return new_node ; }
int main ( ) { Node * head = newNode ( 5 ) ; head -> next = newNode ( 10 ) ; head -> next -> next = newNode ( 2 ) ; head -> next -> next -> next = newNode ( 3 ) ; populateArbit ( head ) ; printf ( " Resultant ▁ Linked ▁ List ▁ is : ▁ STRNEWLINE " ) ; printNextArbitPointers ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void deleteLast ( struct Node * head , int x ) { struct Node * temp = head , * ptr = NULL ; while ( temp ) {
if ( temp -> data == x ) ptr = temp ; temp = temp -> next ; }
if ( ptr != NULL && ptr -> next == NULL ) { temp = head ; while ( temp -> next != ptr ) temp = temp -> next ; temp -> next = NULL ; }
if ( ptr != NULL && ptr -> next != NULL ) { ptr -> data = ptr -> next -> data ; temp = ptr -> next ; ptr -> next = ptr -> next -> next ; free ( temp ) ; } }
struct Node * newNode ( int x ) { Node * node = new Node ; node -> data = x ; node -> next = NULL ; return node ; }
void display ( struct Node * head ) { struct Node * temp = head ; if ( head == NULL ) { cout << " NULL STRNEWLINE " ; return ; } while ( temp != NULL ) { cout << " ▁ - - > ▁ " << temp -> data ; temp = temp -> next ; } cout << " NULL STRNEWLINE " ; }
int main ( ) { struct Node * head = newNode ( 1 ) ; head -> next = newNode ( 2 ) ; head -> next -> next = newNode ( 3 ) ; head -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next = newNode ( 5 ) ; head -> next -> next -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next -> next -> next = newNode ( 4 ) ; cout << " Created ▁ Linked ▁ list : ▁ " ; display ( head ) ; deleteLast ( head , 4 ) ; cout << " List ▁ after ▁ deletion ▁ of ▁ 4 : ▁ " ; display ( head ) ; return 0 ; }
Node * flattenList2 ( Node * head ) { Node * headcop = head ; stack < Node * > save ; save . push ( head ) ; Node * prev = NULL ; while ( ! save . empty ( ) ) { Node * temp = save . top ( ) ; save . pop ( ) ; if ( temp -> next ) save . push ( temp -> next ) ; if ( temp -> down ) save . push ( temp -> down ) ; if ( prev != NULL ) prev -> next = temp ; prev = temp ; } return headcop ; }
struct Node { int data ; struct Node * next ; } ; Node * newNode ( int data ) { Node * temp = new Node ; temp -> data = data ; temp -> next = NULL ; return temp ; }
int getLength ( Node * Node ) { int size = 0 ; while ( Node != NULL ) { Node = Node -> next ; size ++ ; } return size ; }
Node * paddZeros ( Node * sNode , int diff ) { if ( sNode == NULL ) return NULL ; Node * zHead = newNode ( 0 ) ; diff -- ; Node * temp = zHead ; while ( diff -- ) { temp -> next = newNode ( 0 ) ; temp = temp -> next ; } temp -> next = sNode ; return zHead ; }
Node * subtractLinkedListHelper ( Node * l1 , Node * l2 , bool & borrow ) { if ( l1 == NULL && l2 == NULL && borrow == 0 ) return NULL ; Node * previous = subtractLinkedListHelper ( l1 ? l1 -> next : NULL , l2 ? l2 -> next : NULL , borrow ) ; int d1 = l1 -> data ; int d2 = l2 -> data ; int sub = 0 ;
if ( borrow ) { d1 -- ; borrow = false ; }
if ( d1 < d2 ) { borrow = true ; d1 = d1 + 10 ; }
sub = d1 - d2 ;
Node * current = newNode ( sub ) ;
current -> next = previous ; return current ; }
Node * subtractLinkedList ( Node * l1 , Node * l2 ) {
if ( l1 == NULL && l2 == NULL ) return NULL ;
int len1 = getLength ( l1 ) ; int len2 = getLength ( l2 ) ; Node * lNode = NULL , * sNode = NULL ; Node * temp1 = l1 ; Node * temp2 = l2 ;
if ( len1 != len2 ) { lNode = len1 > len2 ? l1 : l2 ; sNode = len1 > len2 ? l2 : l1 ; sNode = paddZeros ( sNode , abs ( len1 - len2 ) ) ; } else {
while ( l1 && l2 ) { if ( l1 -> data != l2 -> data ) { lNode = l1 -> data > l2 -> data ? temp1 : temp2 ; sNode = l1 -> data > l2 -> data ? temp2 : temp1 ; break ; } l1 = l1 -> next ; l2 = l2 -> next ; } }
bool borrow = false ; return subtractLinkedListHelper ( lNode , sNode , borrow ) ; }
void printList ( struct Node * Node ) { while ( Node != NULL ) { printf ( " % d ▁ " , Node -> data ) ; Node = Node -> next ; } printf ( " STRNEWLINE " ) ; }
int main ( ) { Node * head1 = newNode ( 1 ) ; head1 -> next = newNode ( 0 ) ; head1 -> next -> next = newNode ( 0 ) ; Node * head2 = newNode ( 1 ) ; Node * result = subtractLinkedList ( head1 , head2 ) ; printList ( result ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
Node * newNode ( int data ) { struct Node * new_node = new Node ; new_node -> data = data ; new_node -> next = NULL ; return new_node ; }
struct Node * partition ( struct Node * head , int x ) {
struct Node * smallerHead = NULL , * smallerLast = NULL ; struct Node * greaterLast = NULL , * greaterHead = NULL ; struct Node * equalHead = NULL , * equalLast = NULL ;
while ( head != NULL ) {
if ( head -> data == x ) { if ( equalHead == NULL ) equalHead = equalLast = head ; else { equalLast -> next = head ; equalLast = equalLast -> next ; } }
else if ( head -> data < x ) { if ( smallerHead == NULL ) smallerLast = smallerHead = head ; else { smallerLast -> next = head ; smallerLast = head ; } }
else { if ( greaterHead == NULL ) greaterLast = greaterHead = head ; else { greaterLast -> next = head ; greaterLast = head ; } } head = head -> next ; }
if ( greaterLast != NULL ) greaterLast -> next = NULL ;
if ( smallerHead == NULL ) { if ( equalHead == NULL ) return greaterHead ; equalLast -> next = greaterHead ; return equalHead ; }
if ( equalHead == NULL ) { smallerLast -> next = greaterHead ; return smallerHead ; }
smallerLast -> next = equalHead ; equalLast -> next = greaterHead ; return smallerHead ; }
void printList ( struct Node * head ) { struct Node * temp = head ; while ( temp != NULL ) { printf ( " % d ▁ " , temp -> data ) ; temp = temp -> next ; } }
struct Node * head = newNode ( 10 ) ; head -> next = newNode ( 4 ) ; head -> next -> next = newNode ( 5 ) ; head -> next -> next -> next = newNode ( 30 ) ; head -> next -> next -> next -> next = newNode ( 2 ) ; head -> next -> next -> next -> next -> next = newNode ( 50 ) ; int x = 3 ; head = partition ( head , x ) ; printList ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
Node * getLoopstart ( Node * loop_node , Node * head ) { Node * ptr1 = loop_node ; Node * ptr2 = loop_node ;
unsigned int k = 1 , i ; while ( ptr1 -> next != ptr2 ) { ptr1 = ptr1 -> next ; k ++ ; }
ptr1 = head ;
ptr2 = head ; for ( i = 0 ; i < k ; i ++ ) ptr2 = ptr2 -> next ;
while ( ptr2 != ptr1 ) { ptr1 = ptr1 -> next ; ptr2 = ptr2 -> next ; } return ptr1 ; }
Node * detectAndgetLoopstarting ( Node * head ) { Node * slow_p = head , * fast_p = head , * loop_start ;
while ( slow_p && fast_p && fast_p -> next ) { slow_p = slow_p -> next ; fast_p = fast_p -> next -> next ;
if ( slow_p == fast_p ) { loop_start = getLoopstart ( slow_p , head ) ; break ; } }
return loop_start ; }
bool isPalindromeUtil ( Node * head , Node * loop_start ) { Node * ptr = head ; stack < int > s ;
int count = 0 ; while ( ptr != loop_start count != 1 ) { s . push ( ptr -> data ) ; if ( ptr == loop_start ) count = 1 ; ptr = ptr -> next ; } ptr = head ; count = 0 ;
while ( ptr != loop_start count != 1 ) {
if ( ptr -> data == s . top ( ) ) s . pop ( ) ;
else return false ; if ( ptr == loop_start ) count = 1 ; ptr = ptr -> next ; }
return true ; }
bool isPalindrome ( Node * head ) {
Node * loop_start = detectAndgetLoopstarting ( head ) ;
return isPalindromeUtil ( head , loop_start ) ; } Node * newNode ( int key ) { Node * temp = new Node ; temp -> data = key ; temp -> next = NULL ; return temp ; }
int main ( ) { Node * head = newNode ( 50 ) ; head -> next = newNode ( 20 ) ; head -> next -> next = newNode ( 15 ) ; head -> next -> next -> next = newNode ( 20 ) ; head -> next -> next -> next -> next = newNode ( 50 ) ;
head -> next -> next -> next -> next -> next = head -> next -> next ; isPalindrome ( head ) ? cout << " Palindrome " : cout << " Not Palindrome " return 0 ; }
struct Node { int data ; struct Node * next ; } ;
int countCommon ( Node * a , Node * b ) { int count = 0 ;
for ( ; a && b ; a = a -> next , b = b -> next )
if ( a -> data == b -> data ) ++ count ; else break ; return count ; }
int maxPalindrome ( Node * head ) { int result = 0 ; Node * prev = NULL , * curr = head ;
while ( curr ) {
Node * next = curr -> next ; curr -> next = prev ;
result = max ( result , 2 * countCommon ( prev , next ) + 1 ) ;
result = max ( result , 2 * countCommon ( curr , next ) ) ;
prev = curr ; curr = next ; } return result ; }
Node * newNode ( int key ) { Node * temp = new Node ; temp -> data = key ; temp -> next = NULL ; return temp ; }
Node * head = newNode ( 2 ) ; head -> next = newNode ( 4 ) ; head -> next -> next = newNode ( 3 ) ; head -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next = newNode ( 2 ) ; head -> next -> next -> next -> next -> next = newNode ( 15 ) ; cout << maxPalindrome ( head ) << endl ; return 0 ; }
vector < int > list ;
list . push_back ( 1 ) ; list . push_back ( 2 ) ; list . push_back ( 3 ) ;
for ( vector < int > :: iterator it = list . begin ( ) ; it != list . end ( ) ; ++ it ) cout << * it << " ▁ " ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
struct Node * newNode ( int x ) { Node * temp = new Node ; temp -> data = x ; temp -> next = NULL ; }
void printList ( Node * head ) { struct Node * temp = head ; while ( temp != NULL ) { printf ( " % d ▁ " , temp -> data ) ; temp = temp -> next ; } printf ( " STRNEWLINE " ) ; }
void moveToEnd ( Node * head , int key ) {
struct Node * pKey = head ;
struct Node * pCrawl = head ; while ( pCrawl != NULL ) {
if ( pCrawl != pKey && pCrawl -> data != key ) { pKey -> data = pCrawl -> data ; pCrawl -> data = key ; pKey = pKey -> next ; }
if ( pKey -> data != key ) pKey = pKey -> next ;
pCrawl = pCrawl -> next ; } }
int main ( ) { Node * head = newNode ( 10 ) ; head -> next = newNode ( 20 ) ; head -> next -> next = newNode ( 10 ) ; head -> next -> next -> next = newNode ( 30 ) ; head -> next -> next -> next -> next = newNode ( 40 ) ; head -> next -> next -> next -> next -> next = newNode ( 10 ) ; head -> next -> next -> next -> next -> next -> next = newNode ( 60 ) ; printf ( " Before ▁ moveToEnd ( ) , ▁ the ▁ Linked ▁ list ▁ is STRNEWLINE " ) ; printList ( head ) ; int key = 10 ; moveToEnd ( head , key ) ; printf ( " After moveToEnd ( ) , the Linked list is " printList ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ; struct Node * newNode ( int x ) { Node * temp = new Node ; temp -> data = x ; temp -> next = NULL ; }
Node * keyToEnd ( Node * head , int key ) {
Node * tail = head ; if ( head == NULL ) { return NULL ; } while ( tail -> next != NULL ) { tail = tail -> next ; }
Node * last = tail ; Node * current = head ; Node * prev = NULL ;
Node * prev2 = NULL ;
while ( current != tail ) { if ( current -> data == key && prev2 == NULL ) { prev = current ; current = current -> next ; head = current ; last -> next = prev ; last = last -> next ; last -> next = NULL ; prev = NULL ; } else { if ( current -> data == key && prev2 != NULL ) { prev = current ; current = current -> next ; prev2 -> next = current ; last -> next = prev ; last = last -> next ; last -> next = NULL ; } else if ( current != tail ) { prev2 = current ; current = current -> next ; } } } return head ; }
void printList ( Node * head ) { struct Node * temp = head ; while ( temp != NULL ) { printf ( " % d ▁ " , temp -> data ) ; temp = temp -> next ; } printf ( " STRNEWLINE " ) ; }
int main ( ) { Node * root = newNode ( 5 ) ; root -> next = newNode ( 2 ) ; root -> next -> next = newNode ( 2 ) ; root -> next -> next -> next = newNode ( 7 ) ; root -> next -> next -> next -> next = newNode ( 2 ) ; root -> next -> next -> next -> next -> next = newNode ( 2 ) ; root -> next -> next -> next -> next -> next -> next = newNode ( 2 ) ; int key = 2 ; cout << " Linked ▁ List ▁ before ▁ operations ▁ : " ; printList ( root ) ; cout << " Linked List after operations : " root = keyToEnd ( root , key ) ; printList ( root ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void freeList ( Node * node ) { while ( node != NULL ) { Node * next = node -> next ; delete ( node ) ; node = next ; } }
Node * deleteKthNode ( struct Node * head , int k ) {
if ( head == NULL ) return NULL ; if ( k == 1 ) { freeList ( head ) ; return NULL ; }
struct Node * ptr = head , * prev = NULL ;
int count = 0 ; while ( ptr != NULL ) {
count ++ ;
if ( k == count ) {
delete ( prev -> next ) ; prev -> next = ptr -> next ;
count = 0 ; }
if ( count != 0 ) prev = ptr ; ptr = prev -> next ; } return head ; }
void displayList ( struct Node * head ) { struct Node * temp = head ; while ( temp != NULL ) { cout << temp -> data << " ▁ " ; temp = temp -> next ; } }
struct Node * newNode ( int x ) { Node * temp = new Node ; temp -> data = x ; temp -> next = NULL ; return temp ; }
struct Node * head = newNode ( 1 ) ; head -> next = newNode ( 2 ) ; head -> next -> next = newNode ( 3 ) ; head -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next = newNode ( 5 ) ; head -> next -> next -> next -> next -> next = newNode ( 6 ) ; head -> next -> next -> next -> next -> next -> next = newNode ( 7 ) ; head -> next -> next -> next -> next -> next -> next -> next = newNode ( 8 ) ; int k = 3 ; head = deleteKthNode ( head , k ) ; displayList ( head ) ; return 0 ; }
class Node { public : int data ; Node * next ; } ;
int LinkedListLength ( Node * head ) { while ( head && head -> next ) { head = head -> next -> next ; } if ( ! head ) return 0 ; return 1 ; }
void push ( Node * * head , int info ) {
Node * node = new Node ( ) ;
node -> data = info ;
node -> next = ( * head ) ;
( * head ) = node ; }
int main ( void ) { Node * head = NULL ;
push ( & head , 4 ) ; push ( & head , 5 ) ; push ( & head , 7 ) ; push ( & head , 2 ) ; push ( & head , 9 ) ; push ( & head , 6 ) ; push ( & head , 1 ) ; push ( & head , 2 ) ; push ( & head , 0 ) ; push ( & head , 5 ) ; push ( & head , 5 ) ; int check = LinkedListLength ( head ) ;
if ( check == 0 ) { cout << " Even STRNEWLINE " ; } else { cout << " Odd STRNEWLINE " ; } return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = new Node ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void sumOfLastN_Nodes ( struct Node * head , int * n , int * sum ) {
if ( ! head ) return ;
sumOfLastN_Nodes ( head -> next , n , sum ) ;
if ( * n > 0 ) {
* sum = * sum + head -> data ;
-- * n ; } }
int sumOfLastN_NodesUtil ( struct Node * head , int n ) {
if ( n <= 0 ) return 0 ; int sum = 0 ;
sumOfLastN_Nodes ( head , & n , & sum ) ;
return sum ; }
int main ( ) { struct Node * head = NULL ;
push ( & head , 12 ) ; push ( & head , 4 ) ; push ( & head , 8 ) ; push ( & head , 6 ) ; push ( & head , 10 ) ; int n = 2 ; cout << " Sum ▁ of ▁ last ▁ " << n << " ▁ nodes ▁ = ▁ " << sumOfLastN_NodesUtil ( head , n ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = new Node ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
int sumOfLastN_NodesUtil ( struct Node * head , int n ) {
if ( n <= 0 ) return 0 ; stack < int > st ; int sum = 0 ;
while ( head != NULL ) {
st . push ( head -> data ) ;
head = head -> next ; }
while ( n -- ) { sum += st . top ( ) ; st . pop ( ) ; }
return sum ; }
int main ( ) { struct Node * head = NULL ;
push ( & head , 12 ) ; push ( & head , 4 ) ; push ( & head , 8 ) ; push ( & head , 6 ) ; push ( & head , 10 ) ; int n = 2 ; cout << " Sum ▁ of ▁ last ▁ " << n << " ▁ nodes ▁ = ▁ " << sumOfLastN_NodesUtil ( head , n ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = new Node ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; } void reverseList ( struct Node * * head_ref ) { struct Node * current , * prev , * next ; current = * head_ref ; prev = NULL ; while ( current != NULL ) { next = current -> next ; current -> next = prev ; prev = current ; current = next ; } * head_ref = prev ; }
int sumOfLastN_NodesUtil ( struct Node * head , int n ) {
if ( n <= 0 ) return 0 ;
reverseList ( & head ) ; int sum = 0 ; struct Node * current = head ;
while ( current != NULL && n -- ) {
sum += current -> data ;
current = current -> next ; }
reverseList ( & head ) ;
return sum ; }
push ( & head , 12 ) ; push ( & head , 4 ) ; push ( & head , 8 ) ; push ( & head , 6 ) ; push ( & head , 10 ) ; int n = 2 ; cout << " Sum ▁ of ▁ last ▁ " << n << " ▁ nodes ▁ = ▁ " << sumOfLastN_NodesUtil ( head , n ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = new Node ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
int sumOfLastN_NodesUtil ( struct Node * head , int n ) {
if ( n <= 0 ) return 0 ; int sum = 0 , len = 0 ; struct Node * temp = head ;
while ( temp != NULL ) { len ++ ; temp = temp -> next ; }
int c = len - n ; temp = head ;
while ( temp != NULL && c -- )
temp = temp -> next ;
while ( temp != NULL ) {
sum += temp -> data ;
temp = temp -> next ; }
return sum ; }
push ( & head , 12 ) ; push ( & head , 4 ) ; push ( & head , 8 ) ; push ( & head , 6 ) ; push ( & head , 10 ) ; int n = 2 ; cout << " Sum ▁ of ▁ last ▁ " << n << " ▁ nodes ▁ = ▁ " << sumOfLastN_NodesUtil ( head , n ) ; return 0 ; }
Node * SortedMerge ( Node * a , Node * b ) { Node * result = NULL ;
Node * * lastPtrRef = & result ; while ( 1 ) { if ( a == NULL ) { * lastPtrRef = b ; break ; } else if ( b == NULL ) { * lastPtrRef = a ; break ; } if ( a -> data <= b -> data ) { MoveNode ( lastPtrRef , & a ) ; } else { MoveNode ( lastPtrRef , & b ) ; }
lastPtrRef = & ( ( * lastPtrRef ) -> next ) ; } return ( result ) ; }
struct Node { int data ; Node * next ; } ;
void printList ( Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
Node * mergeKLists ( Node * arr [ ] , int last ) {
for ( int i = 1 ; i <= last ; i ++ ) { while ( true ) {
Node * head_0 = arr [ 0 ] , * head_i = arr [ i ] ;
if ( head_i == NULL ) break ;
if ( head_0 -> data >= head_i -> data ) { arr [ i ] = head_i -> next ; head_i -> next = head_0 ; arr [ 0 ] = head_i ; } else
while ( head_0 -> next != NULL ) {
if ( head_0 -> next -> data >= head_i -> data ) { arr [ i ] = head_i -> next ; head_i -> next = head_0 -> next ; head_0 -> next = head_i ; break ; }
head_0 = head_0 -> next ;
if ( head_0 -> next == NULL ) { arr [ i ] = head_i -> next ; head_i -> next = NULL ; head_0 -> next = head_i ; head_0 -> next -> next = NULL ; break ; } } } } return arr [ 0 ] ; }
int k = 3 ;
int n = 4 ;
Node * arr [ k ] ; arr [ 0 ] = newNode ( 1 ) ; arr [ 0 ] -> next = newNode ( 3 ) ; arr [ 0 ] -> next -> next = newNode ( 5 ) ; arr [ 0 ] -> next -> next -> next = newNode ( 7 ) ; arr [ 1 ] = newNode ( 2 ) ; arr [ 1 ] -> next = newNode ( 4 ) ; arr [ 1 ] -> next -> next = newNode ( 6 ) ; arr [ 1 ] -> next -> next -> next = newNode ( 8 ) ; arr [ 2 ] = newNode ( 0 ) ; arr [ 2 ] -> next = newNode ( 9 ) ; arr [ 2 ] -> next -> next = newNode ( 10 ) ; arr [ 2 ] -> next -> next -> next = newNode ( 11 ) ;
Node * head = mergeKLists ( arr , k - 1 ) ; printList ( head ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { int data ; struct Node * next ; } ;
Node * newNode ( int key ) { struct Node * temp = new Node ; temp -> data = key ; temp -> next = NULL ; return temp ; }
void printList ( Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
Node * merge ( Node * h1 , Node * h2 ) { if ( ! h1 ) return h2 ; if ( ! h2 ) return h1 ;
if ( h1 -> data < h2 -> data ) { h1 -> next = merge ( h1 -> next , h2 ) ; return h1 ; } else { h2 -> next = merge ( h1 , h2 -> next ) ; return h2 ; } }
int main ( ) { Node * head1 = newNode ( 1 ) ; head1 -> next = newNode ( 3 ) ; head1 -> next -> next = newNode ( 5 ) ;
Node * head2 = newNode ( 0 ) ; head2 -> next = newNode ( 2 ) ; head2 -> next -> next = newNode ( 4 ) ;
Node * mergedhead = merge ( head1 , head2 ) ; printList ( mergedhead ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
struct Node * newNode ( int key ) { struct Node * temp = new Node ; temp -> data = key ; temp -> next = NULL ; return temp ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
struct Node * mergeUtil ( struct Node * h1 , struct Node * h2 ) {
if ( ! h1 -> next ) { h1 -> next = h2 ; return h1 ; }
struct Node * curr1 = h1 , * next1 = h1 -> next ; struct Node * curr2 = h2 , * next2 = h2 -> next ; while ( next1 && curr2 ) {
if ( ( curr2 -> data ) >= ( curr1 -> data ) && ( curr2 -> data ) <= ( next1 -> data ) ) { next2 = curr2 -> next ; curr1 -> next = curr2 ; curr2 -> next = next1 ;
curr1 = curr2 ; curr2 = next2 ; } else {
if ( next1 -> next ) { next1 = next1 -> next ; curr1 = curr1 -> next ; }
else { next1 -> next = curr2 ; return h1 ; } } } return h1 ; }
struct Node * merge ( struct Node * h1 , struct Node * h2 ) { if ( ! h1 ) return h2 ; if ( ! h2 ) return h1 ;
if ( h1 -> data < h2 -> data ) return mergeUtil ( h1 , h2 ) ; else return mergeUtil ( h2 , h1 ) ; }
int main ( ) { struct Node * head1 = newNode ( 1 ) ; head1 -> next = newNode ( 3 ) ; head1 -> next -> next = newNode ( 5 ) ;
struct Node * head2 = newNode ( 0 ) ; head2 -> next = newNode ( 2 ) ; head2 -> next -> next = newNode ( 4 ) ;
struct Node * mergedhead = merge ( head1 , head2 ) ; printList ( mergedhead ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void swapNodes ( struct Node * * head_ref , struct Node * currX , struct Node * currY , struct Node * prevY ) {
* head_ref = currY ;
prevY -> next = currX ;
struct Node * temp = currY -> next ; currY -> next = currX -> next ; currX -> next = temp ; }
struct Node * recurSelectionSort ( struct Node * head ) {
if ( head -> next == NULL ) return head ;
struct Node * min = head ;
struct Node * beforeMin = NULL ; struct Node * ptr ;
for ( ptr = head ; ptr -> next != NULL ; ptr = ptr -> next ) {
if ( ptr -> next -> data < min -> data ) { min = ptr -> next ; beforeMin = ptr ; } }
if ( min != head ) swapNodes ( & head , head , min , beforeMin ) ;
head -> next = recurSelectionSort ( head -> next ) ; return head ; }
void sort ( struct Node * * head_ref ) {
if ( ( * head_ref ) == NULL ) return ;
* head_ref = recurSelectionSort ( * head_ref ) ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( struct Node * head ) { while ( head != NULL ) { cout << head -> data << " ▁ " ; head = head -> next ; } }
int main ( ) { struct Node * head = NULL ;
push ( & head , 6 ) ; push ( & head , 4 ) ; push ( & head , 8 ) ; push ( & head , 12 ) ; push ( & head , 10 ) ; cout << " Linked ▁ list ▁ before ▁ sorting : n " ; printList ( head ) ;
sort ( & head ) ; cout << " Linked list after sorting : n " ; printList ( head ) ; return 0 ; }
struct Node { int data ; Node * next ; } ;
Node * getNode ( int data ) { Node * newNode = ( Node * ) malloc ( sizeof ( Node ) ) ; newNode -> data = data ; newNode -> next = NULL ; return newNode ; }
void insertAtMid ( Node * * head_ref , int x ) {
if ( * head_ref == NULL ) * head_ref = getNode ( x ) ; else {
Node * newNode = getNode ( x ) ; Node * ptr = * head_ref ; int len = 0 ;
while ( ptr != NULL ) { len ++ ; ptr = ptr -> next ; }
int count = ( ( len % 2 ) == 0 ) ? ( len / 2 ) : ( len + 1 ) / 2 ; ptr = * head_ref ;
while ( count -- > 1 ) ptr = ptr -> next ;
newNode -> next = ptr -> next ; ptr -> next = newNode ; } }
void display ( Node * head ) { while ( head != NULL ) { cout << head -> data << " ▁ " ; head = head -> next ; } }
Node * head = NULL ; head = getNode ( 1 ) ; head -> next = getNode ( 2 ) ; head -> next -> next = getNode ( 4 ) ; head -> next -> next -> next = getNode ( 5 ) ; cout << " Linked ▁ list ▁ before ▁ insertion : ▁ " ; display ( head ) ; int x = 3 ; insertAtMid ( & head , x ) ; cout << " Linked list after insertion : " display ( head ) ; return 0 ; }
struct Node { int data ; Node * next ; } ; Node * getNode ( int data ) { Node * newNode = ( Node * ) malloc ( sizeof ( Node ) ) ; newNode -> data = data ; newNode -> next = NULL ; return newNode ; }
void insertAtMid ( Node * * head_ref , int x ) {
if ( * head_ref == NULL ) * head_ref = getNode ( x ) ; else {
Node * newNode = getNode ( x ) ;
Node * slow = * head_ref ; Node * fast = ( * head_ref ) -> next ; while ( fast && fast -> next ) {
slow = slow -> next ;
fast = fast -> next -> next ; }
newNode -> next = slow -> next ; slow -> next = newNode ; } }
void display ( Node * head ) { while ( head != NULL ) { cout << head -> data << " ▁ " ; head = head -> next ; } }
Node * head = NULL ; head = getNode ( 1 ) ; head -> next = getNode ( 2 ) ; head -> next -> next = getNode ( 4 ) ; head -> next -> next -> next = getNode ( 5 ) ; cout << " Linked ▁ list ▁ before ▁ insertion : ▁ " ; display ( head ) ; int x = 3 ; insertAtMid ( & head , x ) ; cout << " Linked list after insertion : " display ( head ) ; return 0 ; }
struct Node { int data ; Node * next ; } ;
Node * getNode ( int data ) {
Node * newNode = ( Node * ) malloc ( sizeof ( Node ) ) ;
newNode -> data = data ; newNode -> next = NULL ; return newNode ; }
void insertAfterNthNode ( Node * head , int n , int x ) {
if ( head == NULL ) return ;
Node * newNode = getNode ( x ) ; Node * ptr = head ; int len = 0 , i ;
while ( ptr != NULL ) { len ++ ; ptr = ptr -> next ; }
ptr = head ; for ( i = 1 ; i <= ( len - n ) ; i ++ ) ptr = ptr -> next ;
newNode -> next = ptr -> next ; ptr -> next = newNode ; }
void printList ( Node * head ) { while ( head != NULL ) { cout << head -> data << " ▁ " ; head = head -> next ; } }
Node * head = getNode ( 1 ) ; head -> next = getNode ( 3 ) ; head -> next -> next = getNode ( 4 ) ; head -> next -> next -> next = getNode ( 5 ) ; int n = 4 , x = 2 ; cout << " Original ▁ Linked ▁ List : ▁ " ; printList ( head ) ; insertAfterNthNode ( head , n , x ) ; cout << " Linked List After Insertion : " printList ( head ) ; return 0 ; }
struct Node { int data ; Node * next ; } ;
Node * getNode ( int data ) {
Node * newNode = ( Node * ) malloc ( sizeof ( Node ) ) ;
newNode -> data = data ; newNode -> next = NULL ; return newNode ; }
void insertAfterNthNode ( Node * head , int n , int x ) {
if ( head == NULL ) return ;
Node * newNode = getNode ( x ) ;
Node * slow_ptr = head ; Node * fast_ptr = head ;
for ( int i = 1 ; i <= n - 1 ; i ++ ) fast_ptr = fast_ptr -> next ;
while ( fast_ptr -> next != NULL ) {
slow_ptr = slow_ptr -> next ; fast_ptr = fast_ptr -> next ; }
newNode -> next = slow_ptr -> next ; slow_ptr -> next = newNode ; }
void printList ( Node * head ) { while ( head != NULL ) { cout << head -> data << " ▁ " ; head = head -> next ; } }
Node * head = getNode ( 1 ) ; head -> next = getNode ( 3 ) ; head -> next -> next = getNode ( 4 ) ; head -> next -> next -> next = getNode ( 5 ) ; int n = 4 , x = 2 ; cout << " Original ▁ Linked ▁ List : ▁ " ; printList ( head ) ; insertAfterNthNode ( head , n , x ) ; cout << " Linked List After Insertion : " printList ( head ) ; return 0 ; }
class Node { public : int data ; Node * next ; } ;
Node * rotateHelper ( Node * blockHead , Node * blockTail , int d , Node * * tail , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { Node * temp = blockHead ; for ( int i = 1 ; temp -> next -> next && i < k - 1 ; i ++ ) temp = temp -> next ; blockTail -> next = blockHead ; * tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , tail , k ) ; }
if ( d < 0 ) { blockTail -> next = blockHead ; * tail = blockHead ; return rotateHelper ( blockHead -> next , blockHead , d + 1 , tail , k ) ; } }
Node * rotateByBlocks ( Node * head , int k , int d ) {
if ( ! head ! head -> next ) return head ;
if ( d == 0 ) return head ; Node * temp = head , * tail = NULL ;
int i ; for ( i = 1 ; temp -> next && i < k ; i ++ ) temp = temp -> next ;
Node * nextBlock = temp -> next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , & tail , i ) ; else head = rotateHelper ( head , temp , d % k , & tail , k ) ;
tail -> next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
void push ( Node * * head_ref , int new_data ) { Node * new_node = new Node ; new_node -> data = new_data ; new_node -> next = ( * head_ref ) ; ( * head_ref ) = new_node ; }
void printList ( Node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> next ; } }
Node * head = NULL ;
for ( int i = 9 ; i > 0 ; i -= 1 ) push ( & head , i ) ; cout << " Given ▁ linked ▁ list ▁ STRNEWLINE " ; printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; cout << " Rotated by blocks Linked list " ; printList ( head ) ; return ( 0 ) ; }
struct Node { int data ; struct Node * next ; } ;
int countRotation ( struct Node * head ) {
int count = 0 ;
int min = head -> data ;
while ( head != NULL ) {
if ( min > head -> data ) break ; count ++ ;
head = head -> next ; } return count ; }
void push ( struct Node * * head , int data ) {
struct Node * newNode = new Node ;
newNode -> data = data ;
newNode -> next = ( * head ) ;
( * head ) = newNode ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
struct Node * head = NULL ;
push ( & head , 12 ) ; push ( & head , 11 ) ; push ( & head , 8 ) ; push ( & head , 5 ) ; push ( & head , 18 ) ; push ( & head , 15 ) ; printList ( head ) ; cout << endl ; cout << " Linked ▁ list ▁ rotated ▁ elements : ▁ " ;
cout << countRotation ( head ) << endl ; return 0 ; }
class Node { public : int data ; Node * next ; } ;
void setMiddleHead ( Node * * head ) { if ( * head == NULL ) return ;
Node * one_node = ( * head ) ;
Node * two_node = ( * head ) ;
Node * prev = NULL ; while ( two_node != NULL && two_node -> next != NULL ) {
prev = one_node ;
two_node = two_node -> next -> next ;
one_node = one_node -> next ; }
prev -> next = prev -> next -> next ; one_node -> next = ( * head ) ; ( * head ) = one_node ; }
void push ( Node * * head_ref , int new_data ) {
Node * new_node = new Node ( ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( Node * ptr ) { while ( ptr != NULL ) { cout << ptr -> data << " ▁ " ; ptr = ptr -> next ; } cout << endl ; }
Node * head = NULL ; int i ; for ( i = 5 ; i > 0 ; i -- ) push ( & head , i ) ; cout << " ▁ list ▁ before : ▁ " ; printList ( head ) ; setMiddleHead ( & head ) ; cout << " ▁ list ▁ After : ▁ " ; printList ( head ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { int data ; Node * next , * prev ; } ;
void insert ( Node * * head_ref , int data ) {
Node * new_node = new Node ;
new_node -> data = data ;
if ( * head_ref == NULL ) { new_node -> next = new_node ; new_node -> prev = new_node ; } else {
Node * last = ( * head_ref ) -> prev ;
new_node -> next = * head_ref ; new_node -> prev = last ;
last -> next = ( * head_ref ) -> prev = new_node ; }
* head_ref = new_node ; }
Node * merge ( Node * first , Node * second ) {
if ( ! first ) return second ;
if ( ! second ) return first ;
if ( first -> data < second -> data ) { first -> next = merge ( first -> next , second ) ; first -> next -> prev = first ; first -> prev = NULL ; return first ; } else { second -> next = merge ( first , second -> next ) ; second -> next -> prev = second ; second -> prev = NULL ; return second ; } }
Node * mergeUtil ( Node * head1 , Node * head2 ) {
if ( ! head1 ) return head2 ;
if ( ! head2 ) return head1 ;
Node * last_node ; if ( head1 -> prev -> data < head2 -> prev -> data ) last_node = head2 -> prev ; else last_node = head1 -> prev ;
head1 -> prev -> next = head2 -> prev -> next = NULL ;
Node * finalHead = merge ( head1 , head2 ) ;
finalHead -> prev = last_node ; last_node -> next = finalHead ; return finalHead ; }
void printList ( Node * head ) { Node * temp = head ; while ( temp -> next != head ) { cout << temp -> data << " ▁ " ; temp = temp -> next ; } cout << temp -> data << " ▁ " ; }
int main ( ) { Node * head1 = NULL , * head2 = NULL ;
insert ( & head1 , 8 ) ; insert ( & head1 , 5 ) ; insert ( & head1 , 3 ) ; insert ( & head1 , 1 ) ;
insert ( & head2 , 11 ) ; insert ( & head2 , 9 ) ; insert ( & head2 , 7 ) ; insert ( & head2 , 2 ) ; Node * newHead = mergeUtil ( head1 , head2 ) ; cout << " Final ▁ Sorted ▁ List : ▁ " ; printList ( newHead ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { int data ; struct Node * prev , * next ; } ; Node * newNode ( int val ) { Node * temp = new Node ; temp -> data = val ; temp -> prev = temp -> next = nullptr ; return temp ; } void printList ( Node * head ) { while ( head -> next != nullptr ) { cout << head -> data << " ▁ < - - > ▁ " ; head = head -> next ; } cout << head -> data << endl ; }
void insert ( Node * * head , int val ) { Node * temp = newNode ( val ) ; temp -> next = * head ; ( * head ) -> prev = temp ; ( * head ) = temp ; }
void reverseList ( Node * * head ) { Node * left = * head , * right = * head ;
while ( right -> next != nullptr ) right = right -> next ;
while ( left != right && left -> prev != right ) {
swap ( left -> data , right -> data ) ;
left = left -> next ;
right = right -> prev ; } }
int main ( ) { Node * head = newNode ( 5 ) ; insert ( & head , 4 ) ; insert ( & head , 3 ) ; insert ( & head , 2 ) ; insert ( & head , 1 ) ; printList ( head ) ; cout << " List ▁ After ▁ Reversing " << endl ; reverseList ( & head ) ; printList ( head ) ; return 0 ; }
struct Node { int data ; struct Node * prev , * next ; } ;
struct Node * getNode ( int data ) {
struct Node * newNode = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
newNode -> data = data ; newNode -> prev = newNode -> next = NULL ; return newNode ; }
void sortedInsert ( struct Node * * head_ref , struct Node * newNode ) { struct Node * current ;
if ( * head_ref == NULL ) * head_ref = newNode ;
else if ( ( * head_ref ) -> data >= newNode -> data ) { newNode -> next = * head_ref ; newNode -> next -> prev = newNode ; * head_ref = newNode ; } else { current = * head_ref ;
while ( current -> next != NULL && current -> next -> data < newNode -> data ) current = current -> next ;
newNode -> next = current -> next ;
if ( current -> next != NULL ) newNode -> next -> prev = newNode ; current -> next = newNode ; newNode -> prev = current ; } }
void insertionSort ( struct Node * * head_ref ) {
struct Node * sorted = NULL ;
struct Node * current = * head_ref ; while ( current != NULL ) {
struct Node * next = current -> next ;
current -> prev = current -> next = NULL ;
sortedInsert ( & sorted , current ) ;
current = next ; }
* head_ref = sorted ; }
void printList ( struct Node * head ) { while ( head != NULL ) { cout << head -> data << " ▁ " ; head = head -> next ; } }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ; new_node -> prev = NULL ;
if ( ( * head_ref ) != NULL ) ( * head_ref ) -> prev = new_node ;
( * head_ref ) = new_node ; }
struct Node * head = NULL ;
push ( & head , 9 ) ; push ( & head , 3 ) ; push ( & head , 5 ) ; push ( & head , 10 ) ; push ( & head , 12 ) ; push ( & head , 8 ) ; cout << " Doubly ▁ Linked ▁ List ▁ Before ▁ Sortingn " ; printList ( head ) ; insertionSort ( & head ) ; cout << " nDoubly ▁ Linked ▁ List ▁ After ▁ Sortingn " ; printList ( head ) ; return 0 ; }
struct Node { char data ; struct Node * next ; struct Node * prev ; } ;
void push ( struct Node * * head_ref , char new_data ) { struct Node * new_node = new Node ; new_node -> data = new_data ; new_node -> next = ( * head_ref ) ; new_node -> prev = NULL ; if ( ( * head_ref ) != NULL ) ( * head_ref ) -> prev = new_node ; ( * head_ref ) = new_node ; }
bool isPalindrome ( struct Node * left ) { if ( left == NULL ) return true ;
struct Node * right = left ; while ( right -> next != NULL ) right = right -> next ; while ( left != right ) { if ( left -> data != right -> data ) return false ; left = left -> next ; right = right -> prev ; } return true ; }
int main ( ) { struct Node * head = NULL ; push ( & head , ' l ' ) ; push ( & head , ' e ' ) ; push ( & head , ' v ' ) ; push ( & head , ' e ' ) ; push ( & head , ' l ' ) ; if ( isPalindrome ( head ) ) printf ( " It ▁ is ▁ Palindrome " ) ; else printf ( " Not ▁ Palindrome " ) ; return 0 ; }
struct Node { int key ; struct Node * left , * right ; } ;
void printLevels ( Node * root , int low , int high ) { queue < Node * > Q ;
Node * marker = new Node ;
int level = 1 ;
Q . push ( root ) ; Q . push ( marker ) ;
while ( Q . empty ( ) == false ) {
Node * n = Q . front ( ) ; Q . pop ( ) ;
if ( n == marker ) {
cout << endl ; level ++ ;
if ( Q . empty ( ) == true level > high ) break ;
Q . push ( marker ) ;
continue ; }
if ( level >= low ) cout << n -> key << " ▁ " ;
if ( n -> left != NULL ) Q . push ( n -> left ) ; if ( n -> right != NULL ) Q . push ( n -> right ) ; } }
int main ( ) { struct Node * root = newNode ( 20 ) ; root -> left = newNode ( 8 ) ; root -> right = newNode ( 22 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 12 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 14 ) ; cout << " Level ▁ Order ▁ traversal ▁ between ▁ given ▁ two ▁ levels ▁ is " ; printLevels ( root , 2 , 3 ) ; return 0 ; }
class node { public : int data ; node * left ; node * right ; node ( int data ) { this -> data = data ; this -> left = NULL ; this -> right = NULL ; } } ; void printKDistant ( node * root , int k ) { if ( root == NULL k < 0 ) return ; if ( k == 0 ) { cout << root -> data << " ▁ " ; return ; } printKDistant ( root -> left , k - 1 ) ; printKDistant ( root -> right , k - 1 ) ; }
node * root = new node ( 1 ) ; root -> left = new node ( 2 ) ; root -> right = new node ( 3 ) ; root -> left -> left = new node ( 4 ) ; root -> left -> right = new node ( 5 ) ; root -> right -> left = new node ( 8 ) ; printKDistant ( root , 2 ) ; return 0 ; }
struct Node { int data ; Node * left , * right ; } ;
Node * newNode ( int data ) { Node * newnode = new Node ( ) ; newnode -> data = data ; newnode -> left = newnode -> right = NULL ; }
bool printKDistant ( Node * root , int klevel ) { queue < Node * > q ; int level = 1 ; bool flag = false ; q . push ( root ) ;
q . push ( NULL ) ; while ( ! q . empty ( ) ) { Node * temp = q . front ( ) ;
if ( level == klevel && temp != NULL ) { flag = true ; cout << temp -> data << " ▁ " ; } q . pop ( ) ; if ( temp == NULL ) { if ( q . front ( ) ) q . push ( NULL ) ; level += 1 ;
if ( level > klevel ) break ; } else { if ( temp -> left ) q . push ( temp -> left ) ; if ( temp -> right ) q . push ( temp -> right ) ; } } cout << endl ; return flag ; }
Node * root = newNode ( 20 ) ; root -> left = newNode ( 10 ) ; root -> right = newNode ( 30 ) ; root -> left -> left = newNode ( 5 ) ; root -> left -> right = newNode ( 15 ) ; root -> left -> right -> left = newNode ( 12 ) ; root -> right -> left = newNode ( 25 ) ; root -> right -> right = newNode ( 40 ) ; cout << " data ▁ at ▁ level ▁ 1 ▁ : ▁ " ; int ret = printKDistant ( root , 1 ) ; if ( ret == false ) cout << " Number ▁ exceeds ▁ total ▁ number ▁ of ▁ levels STRNEWLINE " ; cout << " data ▁ at ▁ level ▁ 2 ▁ : ▁ " ; ret = printKDistant ( root , 2 ) ; if ( ret == false ) cout << " Number ▁ exceeds ▁ total ▁ number ▁ of ▁ levels STRNEWLINE " ; cout << " data ▁ at ▁ level ▁ 3 ▁ : ▁ " ; ret = printKDistant ( root , 3 ) ; if ( ret == false ) cout << " Number ▁ exceeds ▁ total ▁ number ▁ of ▁ levels STRNEWLINE " ; cout << " data ▁ at ▁ level ▁ 6 ▁ : ▁ " ; ret = printKDistant ( root , 6 ) ; if ( ret == false ) cout << " Number ▁ exceeds ▁ total ▁ number ▁ of ▁ levels STRNEWLINE " ; return 0 ; }
struct Node { int data ; struct Node * left , * right ; } ;
void printLeafNodes ( Node * root ) {
if ( ! root ) return ;
if ( ! root -> left && ! root -> right ) { cout << root -> data << " ▁ " ; return ; }
if ( root -> left ) printLeafNodes ( root -> left ) ;
if ( root -> right ) printLeafNodes ( root -> right ) ; }
Node * newNode ( int data ) { Node * temp = new Node ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> right -> left = newNode ( 5 ) ; root -> right -> right = newNode ( 8 ) ; root -> right -> left -> left = newNode ( 6 ) ; root -> right -> left -> right = newNode ( 7 ) ; root -> right -> right -> left = newNode ( 9 ) ; root -> right -> right -> right = newNode ( 10 ) ;
printLeafNodes ( root ) ; return 0 ; }
struct node { int data ; struct node * left , * right ; } ;
void printkdistanceNodeDown ( node * root , int k ) {
if ( root == NULL k < 0 ) return ;
if ( k == 0 ) { cout << root -> data << endl ; return ; }
printkdistanceNodeDown ( root -> left , k - 1 ) ; printkdistanceNodeDown ( root -> right , k - 1 ) ; }
int printkdistanceNode ( node * root , node * target , int k ) {
if ( root == NULL ) return -1 ;
if ( root == target ) { printkdistanceNodeDown ( root , k ) ; return 0 ; }
int dl = printkdistanceNode ( root -> left , target , k ) ;
if ( dl != -1 ) {
if ( dl + 1 == k ) cout << root -> data << endl ;
else printkdistanceNodeDown ( root -> right , k - dl - 2 ) ;
return 1 + dl ; }
int dr = printkdistanceNode ( root -> right , target , k ) ; if ( dr != -1 ) { if ( dr + 1 == k ) cout << root -> data << endl ; else printkdistanceNodeDown ( root -> left , k - dr - 2 ) ; return 1 + dr ; }
return -1 ; }
node * root = newnode ( 20 ) ; root -> left = newnode ( 8 ) ; root -> right = newnode ( 22 ) ; root -> left -> left = newnode ( 4 ) ; root -> left -> right = newnode ( 12 ) ; root -> left -> right -> left = newnode ( 10 ) ; root -> left -> right -> right = newnode ( 14 ) ; node * target = root -> left -> right ; printkdistanceNode ( root , target , 2 ) ; return 0 ; }
struct node { struct node * left , * right ; int key ; } ; node * newNode ( int key ) { node * temp = new node ; temp -> key = key ; temp -> left = temp -> right = NULL ; return temp ; }
void printSingles ( struct node * root ) {
if ( root == NULL ) return ;
if ( root -> left != NULL && root -> right != NULL ) { printSingles ( root -> left ) ; printSingles ( root -> right ) ; }
else if ( root -> right != NULL ) { cout << root -> right -> key << " ▁ " ; printSingles ( root -> right ) ; }
else if ( root -> left != NULL ) { cout << root -> left -> key << " ▁ " ; printSingles ( root -> left ) ; } }
int main ( ) {
node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> right = newNode ( 4 ) ; root -> right -> left = newNode ( 5 ) ; root -> right -> left -> left = newNode ( 6 ) ; printSingles ( root ) ; return 0 ; }
struct Node { int key ; Node * left , * right ; } ; Node * newNode ( int key ) { Node * node = new Node ; node -> key = key ; node -> left = node -> right = NULL ; return ( node ) ; }
void kDistantFromLeafUtil ( Node * node , int path [ ] , bool visited [ ] , int pathLen , int k ) {
if ( node == NULL ) return ;
path [ pathLen ] = node -> key ; visited [ pathLen ] = false ; pathLen ++ ;
if ( node -> left == NULL && node -> right == NULL && pathLen - k - 1 >= 0 && visited [ pathLen - k - 1 ] == false ) { cout << path [ pathLen - k - 1 ] << " ▁ " ; visited [ pathLen - k - 1 ] = true ; return ; }
kDistantFromLeafUtil ( node -> left , path , visited , pathLen , k ) ; kDistantFromLeafUtil ( node -> right , path , visited , pathLen , k ) ; }
void printKDistantfromLeaf ( Node * node , int k ) { int path [ MAX_HEIGHT ] ; bool visited [ MAX_HEIGHT ] = { false } ; kDistantFromLeafUtil ( node , path , visited , 0 , k ) ; }
Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> right -> left -> right = newNode ( 8 ) ; cout << " Nodes ▁ at ▁ distance ▁ 2 ▁ are : ▁ " ; printKDistantfromLeaf ( root , 2 ) ; return 0 ; }
struct Node { int data ; Node * left , * right ; } ; Node * newNode ( int key ) { Node * temp = new Node ; temp -> data = key ; temp -> left = temp -> right = NULL ; return temp ; }
int printKDistantfromLeaf ( struct Node * node , int k ) { if ( node == NULL ) return -1 ; int lk = printKDistantfromLeaf ( node -> left , k ) ; int rk = printKDistantfromLeaf ( node -> right , k ) ; bool isLeaf = lk == -1 && lk == rk ; if ( lk == 0 || rk == 0 || ( isLeaf && k == 0 ) ) cout << ( " ▁ " ) << ( node -> data ) ; if ( isLeaf && k > 0 )
return k - 1 ; if ( lk > 0 && lk < k )
return lk - 1 ; if ( rk > 0 && rk < k )
return rk - 1 ; return -2 ; }
int main ( ) { Node * root = NULL ;
root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> right -> left -> right = newNode ( 8 ) ; cout << ( " ▁ Nodes ▁ at ▁ distance ▁ 2 ▁ are ▁ : " ) << endl ; printKDistantfromLeaf ( root , 2 ) ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define COUNT  10
class Node { public : int data ; Node * left , * right ;
Node ( int data ) { this -> data = data ; this -> left = NULL ; this -> right = NULL ; } } ;
void print2DUtil ( Node * root , int space ) {
if ( root == NULL ) return ;
space += COUNT ;
print2DUtil ( root -> right , space ) ;
cout << endl ; for ( int i = COUNT ; i < space ; i ++ ) cout << " ▁ " ; cout << root -> data << " STRNEWLINE " ;
print2DUtil ( root -> left , space ) ; }
void print2D ( Node * root ) {
print2DUtil ( root , 0 ) ; }
int main ( ) { Node * root = new Node ( 1 ) ; root -> left = new Node ( 2 ) ; root -> right = new Node ( 3 ) ; root -> left -> left = new Node ( 4 ) ; root -> left -> right = new Node ( 5 ) ; root -> right -> left = new Node ( 6 ) ; root -> right -> right = new Node ( 7 ) ; root -> left -> left -> left = new Node ( 8 ) ; root -> left -> left -> right = new Node ( 9 ) ; root -> left -> right -> left = new Node ( 10 ) ; root -> left -> right -> right = new Node ( 11 ) ; root -> right -> left -> left = new Node ( 12 ) ; root -> right -> left -> right = new Node ( 13 ) ; root -> right -> right -> left = new Node ( 14 ) ; root -> right -> right -> right = new Node ( 15 ) ; print2D ( root ) ; return 0 ; }
struct Node { int data ; struct Node * left , * right ; } ; struct Node * newNode ( int item ) { struct Node * temp = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; temp -> data = item ; temp -> left = temp -> right = NULL ; return temp ; }
void leftViewUtil ( struct Node * root , int level , int * max_level ) {
if ( root == NULL ) return ;
if ( * max_level < level ) { cout << root -> data << " ▁ " ; * max_level = level ; }
leftViewUtil ( root -> left , level + 1 , max_level ) ; leftViewUtil ( root -> right , level + 1 , max_level ) ; }
void leftView ( struct Node * root ) { int max_level = 0 ; leftViewUtil ( root , 1 , & max_level ) ; }
int main ( ) { Node * root = newNode ( 10 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 7 ) ; root -> left -> right = newNode ( 8 ) ; root -> right -> right = newNode ( 15 ) ; root -> right -> left = newNode ( 12 ) ; root -> right -> right -> left = newNode ( 14 ) ; leftView ( root ) ; return 0 ; }
int rotate ( int arr [ ] , int N , int X ) {
long long int nextPower = 1 ;
while ( nextPower <= N ) nextPower *= 2 ;
if ( X == 1 ) return nextPower - N ;
long long int prevPower = nextPower / 2 ;
return 2 * ( N - prevPower ) + 1 ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int X = 1 ; int N = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << rotate ( arr , N , X ) ; return 0 ; }
string findRotation ( vector < vector < int > > & mat , vector < vector < int > > & T ) {
if ( T . size ( ) != mat . size ( ) || T [ 0 ] . size ( ) != mat [ 0 ] . size ( ) ) {
return " No " ; }
map < vector < int > , int > m ;
for ( int i = 0 ; i < mat . size ( ) ; i ++ ) {
m [ mat [ i ] ] += 1 ;
reverse ( mat [ i ] . begin ( ) , mat [ i ] . end ( ) ) ;
m [ mat [ i ] ] += 1 ; }
for ( int i = 0 ; i < mat [ 0 ] . size ( ) ; i ++ ) {
vector < int > r = { } ;
for ( int j = 0 ; j < mat . size ( ) ; j ++ ) { r . push_back ( mat [ j ] [ i ] ) ; }
m [ r ] += 1 ;
reverse ( r . begin ( ) , r . end ( ) ) ;
m [ r ] += 1 ; }
for ( int i = 0 ; i < T . size ( ) ; i ++ ) {
if ( m [ T [ i ] ] <= 0 ) { return " No " ; }
m [ T [ i ] ] -= 1 ; }
for ( int i = 0 ; i < T [ 0 ] . size ( ) ; i ++ ) {
vector < int > r = { } ;
for ( int j = 0 ; j < T . size ( ) ; j ++ ) { r . push_back ( T [ j ] [ i ] ) ; }
if ( m [ r ] <= 0 ) { return " No " ; }
m [ r ] -= 1 ; }
return " Yes " ; }
vector < vector < int > > mat = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; vector < vector < int > > T = { { 3 , 6 , 9 } , { 2 , 5 , 8 } , { 1 , 4 , 7 } } ;
cout << findRotation ( mat , T ) ; return 0 ; }
void print ( vector < vector < int > > & mat ) {
for ( int i = 0 ; i < mat . size ( ) ; i ++ ) {
for ( int j = 0 ; j < mat [ 0 ] . size ( ) ; j ++ )
cout << setw ( 3 ) << mat [ i ] [ j ] ; cout << " STRNEWLINE " ; } }
void performSwap ( vector < vector < int > > & mat , int i , int j ) { int N = mat . size ( ) ;
int ei = N - 1 - i ;
int ej = N - 1 - j ;
int temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ ej ] [ i ] ; mat [ ej ] [ i ] = mat [ ei ] [ ej ] ; mat [ ei ] [ ej ] = mat [ j ] [ ei ] ; mat [ j ] [ ei ] = temp ; }
void rotate ( vector < vector < int > > & mat , int N , int K ) {
K = K % 4 ;
while ( K -- ) {
for ( int i = 0 ; i < N / 2 ; i ++ ) {
for ( int j = i ; j < N - i - 1 ; j ++ ) {
if ( i != j && ( i + j ) != N - 1 ) {
performSwap ( mat , i , j ) ; } } } }
print ( mat ) ; }
int main ( ) { int K = 5 ; vector < vector < int > > mat = { { 1 , 2 , 3 , 4 } , { 6 , 7 , 8 , 9 } , { 11 , 12 , 13 , 14 } , { 16 , 17 , 18 , 19 } , } ; int N = mat . size ( ) ; rotate ( mat , N , K ) ; return 0 ; }
void findMaximumZeros ( string str , int n ) {
int c0 = 0 ;
for ( int i = 0 ; i < n ; ++ i ) { if ( str [ i ] == '0' ) c0 ++ ; }
if ( c0 == n ) {
cout << n ; return ; }
string s = str + str ;
int mx = 0 ;
for ( int i = 0 ; i < n ; ++ i ) {
int cs = 0 ; int ce = 0 ;
for ( int j = i ; j < i + n ; ++ j ) { if ( s [ j ] == '0' ) cs ++ ; else break ; }
for ( int j = i + n - 1 ; j >= i ; -- j ) { if ( s [ j ] == '0' ) ce ++ ; else break ; }
int val = cs + ce ;
mx = max ( val , mx ) ; }
cout << mx ; }
string s = "1001" ;
int n = s . size ( ) ; findMaximumZeros ( s , n ) ; return 0 ; }
void findMaximumZeros ( string str , int n ) {
int c0 = 0 ; for ( int i = 0 ; i < n ; ++ i ) { if ( str [ i ] == '0' ) c0 ++ ; }
if ( c0 == n ) {
cout << n ; return ; }
int mx = 0 ;
int cnt = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( str [ i ] == '0' ) cnt ++ ; else { mx = max ( mx , cnt ) ; cnt = 0 ; } }
mx = max ( mx , cnt ) ;
int start = 0 , end = n - 1 ; cnt = 0 ;
while ( str [ start ] != '1' && start < n ) { cnt ++ ; start ++ ; }
while ( str [ end ] != '1' && end >= 0 ) { cnt ++ ; end -- ; }
mx = max ( mx , cnt ) ;
cout << mx ; }
string s = "1001" ;
int n = s . size ( ) ; findMaximumZeros ( s , n ) ; return 0 ; }
void rotateMatrix ( vector < vector < int > > & mat ) { int i = 0 ;
for ( auto & it : mat ) {
reverse ( it . begin ( ) , it . end ( ) ) ;
reverse ( it . begin ( ) , it . begin ( ) + i ) ;
reverse ( it . begin ( ) + i , it . end ( ) ) ;
i ++ ; }
for ( auto rows : mat ) { for ( auto cols : rows ) { cout << cols << " ▁ " ; } cout << " STRNEWLINE " ; } }
int main ( ) { vector < vector < int > > mat = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; rotateMatrix ( mat ) ; return 0 ; }
struct Node { int data ; struct Node * left , * right ; } ;
unsigned int getLeafCount ( struct Node * node ) {
if ( ! node ) return 0 ;
queue < Node * > q ;
int count = 0 ; q . push ( node ) ; while ( ! q . empty ( ) ) { struct Node * temp = q . front ( ) ; q . pop ( ) ; if ( temp -> left != NULL ) q . push ( temp -> left ) ; if ( temp -> right != NULL ) q . push ( temp -> right ) ; if ( temp -> left == NULL && temp -> right == NULL ) count ++ ; } return count ; }
struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ;
cout << getLeafCount ( root ) ; return 0 ; }
void stringShift ( string s , vector < vector < int > > & shift ) { int val = 0 ; for ( int i = 0 ; i < shift . size ( ) ; ++ i )
val += shift [ i ] [ 0 ] == 0 ? - shift [ i ] [ 1 ] : shift [ i ] [ 1 ] ;
int len = s . length ( ) ;
val = val % len ;
string result = " " ;
if ( val > 0 ) result = s . substr ( len - val , val ) + s . substr ( 0 , len - val ) ;
else result = s . substr ( - val , len + val ) + s . substr ( 0 , - val ) ; cout << result ; }
int main ( ) { string s = " abc " ; vector < vector < int > > shift = { { 0 , 1 } , { 1 , 2 } } ; stringShift ( s , shift ) ; return 0 ; }
void rotateArray ( vector < int > & arr , int N ) {
vector < int > v = arr ;
sort ( v . begin ( ) , v . end ( ) ) ;
for ( int i = 1 ; i <= N ; ++ i ) {
rotate ( arr . begin ( ) , arr . begin ( ) + 1 , arr . end ( ) ) ;
if ( arr == v ) { cout << " YES " << endl ; return ; } }
cout << " NO " << endl ; }
vector < int > arr = { 3 , 4 , 5 , 1 , 2 } ;
int N = arr . size ( ) ;
rotateArray ( arr , N ) ; }
void findLargestRotation ( int num ) {
int ans = num ;
int len = floor ( log10 ( num ) + 1 ) ; int x = pow ( 10 , len - 1 ) ;
for ( int i = 1 ; i < len ; i ++ ) {
int lastDigit = num % 10 ;
num = num / 10 ;
num += ( lastDigit * x ) ;
if ( num > ans ) { ans = num ; } }
cout << ans ; }
int main ( ) { int N = 657 ; findLargestRotation ( N ) ; return 0 ; }
int numberOfDigit ( int N ) {
int digit = 0 ;
while ( N > 0 ) {
digit ++ ;
N /= 10 ; } return digit ; }
void rotateNumberByK ( int N , int K ) {
int X = numberOfDigit ( N ) ;
K = ( ( K % X ) + X ) % X ;
int left_no = N / ( int ) ( pow ( 10 , X - K ) ) ;
N = N % ( int ) ( pow ( 10 , X - K ) ) ;
int left_digit = numberOfDigit ( left_no ) ;
N = ( N * ( int ) ( pow ( 10 , left_digit ) ) ) + left_no ; cout << N ; }
int main ( ) { int N = 12345 , K = 7 ;
rotateNumberByK ( N , K ) ; return 0 ; }
void minMovesToSort ( int arr [ ] , int N ) {
int count = 0 ;
int index ;
for ( int i = 0 ; i < N - 1 ; i ++ ) {
if ( arr [ i ] < arr [ i + 1 ] ) {
count ++ ;
index = i ; } }
if ( count == 0 ) { cout << "0" ; } else if ( count == N - 1 ) { cout << N - 1 ; } else if ( count == 1 && arr [ 0 ] <= arr [ N - 1 ] ) { cout << index + 1 ; }
else { cout << " - 1" ; } }
int arr [ ] = { 2 , 1 , 5 , 4 , 2 } ; int N = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
minMovesToSort ( arr , N ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  3
int findMaximumDiagonalSumOMatrixf ( int A [ ] [ N ] ) {
int maxDiagonalSum = INT_MIN ;
for ( int i = 0 ; i < N ; i ++ ) {
int curr = 0 ;
for ( int j = 0 ; j < N ; j ++ ) {
curr += A [ j ] [ ( i + j ) % N ] ; }
maxDiagonalSum = max ( maxDiagonalSum , curr ) ; }
for ( int i = 0 ; i < N ; i ++ ) {
int curr = 0 ;
for ( int j = 0 ; j < N ; j ++ ) {
curr += A [ ( i + j ) % N ] [ j ] ; }
maxDiagonalSum = max ( maxDiagonalSum , curr ) ; } return maxDiagonalSum ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 1 , 2 } , { 2 , 1 , 2 } , { 1 , 2 , 2 } } ; cout << findMaximumDiagonalSumOMatrixf ( mat ) ; return 0 ; }
void diagonalSumPerfectSquare ( int arr [ ] , int N ) {
for ( int i = 0 ; i < N ; i ++ ) {
for ( int j = 0 ; j < N ; j ++ ) { cout << ( arr [ ( j + i ) % 7 ] ) << " ▁ " ; } cout << endl ; } }
int N = 7 ; int arr [ N ] ;
for ( int i = 0 ; i < N ; i ++ ) { arr [ i ] = i + 1 ; }
diagonalSumPerfectSquare ( arr , N ) ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
int countLeaves ( struct node * node ) {
if ( node == NULL ) { return 0 ; }
if ( node -> left == NULL && node -> right == NULL ) { return 1 ; }
return countLeaves ( node -> left ) + countLeaves ( node -> right ) ; }
int main ( ) { struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ;
cout << countLeaves ( root ) << endl ; }
int MaxSum ( vector < int > arr , int n , int k ) { int i , max_sum = 0 , sum = 0 ;
for ( i = 0 ; i < k ; i ++ ) { sum += arr [ i ] ; } max_sum = sum ;
while ( i < n ) {
sum = sum - arr [ i - k ] + arr [ i ] ; if ( max_sum < sum ) { max_sum = sum ; } i ++ ; }
return max_sum ; }
int gcd ( int n1 , int n2 ) {
if ( n2 == 0 ) { return n1 ; }
else { return gcd ( n2 , n1 % n2 ) ; } }
vector < int > RotateArr ( vector < int > arr , int n , int d ) {
int i = 0 , j = 0 ; d = d % n ;
int no_of_sets = gcd ( d , n ) ; for ( i = 0 ; i < no_of_sets ; i ++ ) { int temp = arr [ i ] ; j = i ;
while ( true ) { int k = j + d ; if ( k >= n ) k = k - n ; if ( k == i ) break ; arr [ j ] = arr [ k ] ; j = k ; }
arr [ j ] = temp ; }
return arr ; }
void performQuery ( vector < int > & arr , int Q [ ] [ 2 ] , int q ) { int N = ( int ) arr . size ( ) ;
for ( int i = 0 ; i < q ; i ++ ) {
if ( Q [ i ] [ 0 ] == 1 ) { arr = RotateArr ( arr , N , Q [ i ] [ 1 ] ) ;
for ( auto t : arr ) { cout << t << " ▁ " ; } cout << " STRNEWLINE " ; }
else { cout << MaxSum ( arr , N , Q [ i ] [ 1 ] ) << " STRNEWLINE " ; } } }
vector < int > arr = { 1 , 2 , 3 , 4 , 5 } ; int q = 5 ;
int Q [ ] [ 2 ] = { { 1 , 2 } , { 2 , 3 } , { 1 , 3 } , { 1 , 1 } , { 2 , 4 } } ;
performQuery ( arr , Q , q ) ; return 0 ; }
int getMinimumRemoval ( string str ) { int n = str . length ( ) ;
int ans = n ;
if ( n % 2 == 0 ) {
vector < int > freqEven ( 128 ) ; vector < int > freqOdd ( 128 ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) { freqEven [ str [ i ] ] ++ ; } else { freqOdd [ str [ i ] ] ++ ; } }
int evenMax = 0 , oddMax = 0 ; for ( char chr = ' a ' ; chr <= ' z ' ; chr ++ ) { evenMax = max ( evenMax , freqEven [ chr ] ) ; oddMax = max ( oddMax , freqOdd [ chr ] ) ; }
ans = ans - evenMax - oddMax ; }
else {
vector < int > freq ( 128 ) ; for ( int i = 0 ; i < n ; i ++ ) { freq [ str [ i ] ] ++ ; }
int strMax = 0 ; for ( char chr = ' a ' ; chr <= ' z ' ; chr ++ ) { strMax = max ( strMax , freq [ chr ] ) ; }
ans = ans - strMax ; } return ans ; }
int main ( ) { string str = " geeksgeeks " ; cout << getMinimumRemoval ( str ) ; }
int findAltSubSeq ( string s ) {
int n = s . size ( ) , ans = INT_MIN ;
for ( int i = 0 ; i < 10 ; i ++ ) { for ( int j = 0 ; j < 10 ; j ++ ) { int cur = 0 , f = 0 ;
for ( int k = 0 ; k < n ; k ++ ) { if ( f == 0 and s [ k ] - '0' == i ) { f = 1 ;
cur ++ ; } else if ( f == 1 and s [ k ] - '0' == j ) { f = 0 ;
cur ++ ; } }
if ( i != j and cur % 2 == 1 )
cur -- ;
ans = max ( cur , ans ) ; } }
return ans ; }
int main ( ) { string s = "100210601" ; cout << findAltSubSeq ( s ) ; return 0 ; }
int getFirstElement ( int a [ ] , int N , int K , int M ) {
K %= N ; int index ;
if ( K >= M )
index = ( N - K ) + ( M - 1 ) ;
else
index = ( M - K - 1 ) ; int result = a [ index ] ;
return result ; }
int main ( ) { int a [ ] = { 1 , 2 , 3 , 4 , 5 } ; int N = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int K = 3 , M = 2 ; cout << getFirstElement ( a , N , K , M ) ; return 0 ; }
int getFirstElement ( int a [ ] , int N , int K , int M ) {
K %= N ;
int index = ( K + M - 1 ) % N ; int result = a [ index ] ;
return result ; }
int a [ ] = { 3 , 4 , 5 , 23 } ;
int N = sizeof ( a ) / sizeof ( a [ 0 ] ) ;
int K = 2 , M = 1 ;
cout << getFirstElement ( a , N , K , M ) ; return 0 ; }
void left_rotate ( int arr [ ] ) { int last = arr [ 1 ] ; for ( int i = 3 ; i < 6 ; i = i + 2 ) { arr [ i - 2 ] = arr [ i ] ; } arr [ 6 - 1 ] = last ; }
void right_rotate ( int arr [ ] ) { int start = arr [ 6 - 2 ] ; for ( int i = 6 - 4 ; i >= 0 ; i = i - 2 ) { arr [ i + 2 ] = arr [ i ] ; } arr [ 0 ] = start ; }
void rotate ( int arr [ ] ) { left_rotate ( arr ) ; right_rotate ( arr ) ; for ( int i = 0 ; i < 6 ; i ++ ) { cout << ( arr [ i ] ) << " ▁ " ; } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ; rotate ( arr ) ; }
int maximumMatchingPairs ( int perm1 [ ] , int perm2 [ ] , int n ) {
int left [ n ] , right [ n ] ;
map < int , int > mp1 , mp2 ; for ( int i = 0 ; i < n ; i ++ ) { mp1 [ perm1 [ i ] ] = i ; } for ( int j = 0 ; j < n ; j ++ ) { mp2 [ perm2 [ j ] ] = j ; } for ( int i = 0 ; i < n ; i ++ ) {
int idx2 = mp2 [ perm1 [ i ] ] ; int idx1 = i ; if ( idx1 == idx2 ) {
left [ i ] = 0 ; right [ i ] = 0 ; } else if ( idx1 < idx2 ) {
left [ i ] = ( n - ( idx2 - idx1 ) ) ; right [ i ] = ( idx2 - idx1 ) ; } else {
left [ i ] = ( idx1 - idx2 ) ; right [ i ] = ( n - ( idx1 - idx2 ) ) ; } }
map < int , int > freq1 , freq2 ; for ( int i = 0 ; i < n ; i ++ ) { freq1 [ left [ i ] ] ++ ; freq2 [ right [ i ] ] ++ ; } int ans = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
ans = max ( ans , max ( freq1 [ left [ i ] ] , freq2 [ right [ i ] ] ) ) ; }
return ans ; }
int P1 [ ] = { 5 , 4 , 3 , 2 , 1 } ; int P2 [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = sizeof ( P1 ) / sizeof ( P1 [ 0 ] ) ;
cout << maximumMatchingPairs ( P1 , P2 , n ) ; return 0 ; }
int arr [ 10000 ] ;
void reverse ( int arr [ ] , int s , int e ) { while ( s < e ) { int tem = arr [ s ] ; arr [ s ] = arr [ e ] ; arr [ e ] = tem ; s = s + 1 ; e = e - 1 ; } }
void fun ( int arr [ ] , int k ) { int n = 4 - 1 ; int v = n - k ; if ( v >= 0 ) { reverse ( arr , 0 , v ) ; reverse ( arr , v + 1 , n ) ; reverse ( arr , 0 , n ) ; } }
int main ( ) { arr [ 0 ] = 1 ; arr [ 1 ] = 2 ; arr [ 2 ] = 3 ; arr [ 3 ] = 4 ; for ( int i = 0 ; i < 4 ; i ++ ) { fun ( arr , i ) ; cout << ( " [ " ) ; for ( int j = 0 ; j < 4 ; j ++ ) { cout << ( arr [ j ] ) << " , ▁ " ; } cout << ( " ] " ) ; } }
int countRotation ( int arr [ ] , int n ) { for ( int i = 1 ; i < n ; i ++ ) {
if ( arr [ i ] < arr [ i - 1 ] ) {
return i ; } }
return 0 ; }
int main ( ) { int arr1 [ ] = { 4 , 5 , 1 , 2 , 3 } ; int n = sizeof ( arr1 ) / sizeof ( int ) ; cout << countRotation ( arr1 , n ) ; }
int countRotation ( int arr [ ] , int low , int high ) {
if ( low > high ) { return 0 ; } int mid = low + ( high - low ) / 2 ;
if ( mid < high && arr [ mid ] > arr [ mid + 1 ] ) {
return mid + 1 ; }
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) {
return mid ; }
if ( arr [ mid ] > arr [ low ] ) {
return countRotation ( arr , mid + 1 , high ) ; } if ( arr [ mid ] < arr [ high ] ) {
return countRotation ( arr , low , mid - 1 ) ; } else {
int rightIndex = countRotation ( arr , mid + 1 , high ) ; int leftIndex = countRotation ( arr , low , mid - 1 ) ; if ( rightIndex == 0 ) { return leftIndex ; } return rightIndex ; } }
int main ( ) { int arr1 [ ] = { 4 , 5 , 1 , 2 , 3 } ; int N = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; cout << countRotation ( arr1 , 0 , N - 1 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE const int MAX = 100005 ; using namespace std ;
int seg [ 4 * MAX ] ;
void build ( int node , int l , int r , int a [ ] ) { if ( l == r ) seg [ node ] = a [ l ] ; else { int mid = ( l + r ) / 2 ; build ( 2 * node , l , mid , a ) ; build ( 2 * node + 1 , mid + 1 , r , a ) ; seg [ node ] = ( seg [ 2 * node ] seg [ 2 * node + 1 ] ) ; } }
int query ( int node , int l , int r , int start , int end , int a [ ] ) {
if ( l > end or r < start ) return 0 ; if ( start <= l and r <= end ) return seg [ node ] ;
int mid = ( l + r ) / 2 ;
return ( ( query ( 2 * node , l , mid , start , end , a ) ) | ( query ( 2 * node + 1 , mid + 1 , r , start , end , a ) ) ) ; }
void orsum ( int a [ ] , int n , int q , int k [ ] ) {
build ( 1 , 0 , n - 1 , a ) ;
for ( int j = 0 ; j < q ; j ++ ) {
int i = k [ j ] % ( n / 2 ) ;
int sec = query ( 1 , 0 , n - 1 , n / 2 - i , n - i - 1 , a ) ;
int first = ( query ( 1 , 0 , n - 1 , 0 , n / 2 - 1 - i , a ) | query ( 1 , 0 , n - 1 , n - i , n - 1 , a ) ) ; int temp = sec + first ;
cout << temp << endl ; } }
int main ( ) { int a [ ] = { 7 , 44 , 19 , 86 , 65 , 39 , 75 , 101 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int q = 2 ; int k [ q ] = { 4 , 2 } ; orsum ( a , n , q , k ) ; return 0 ; }
void maximumEqual ( int a [ ] , int b [ ] , int n ) {
vector < int > store ( 1e5 ) ;
for ( int i = 0 ; i < n ; i ++ ) { store [ b [ i ] ] = i + 1 ; }
vector < int > ans ( 1e5 ) ;
for ( int i = 0 ; i < n ; i ++ ) {
int d = abs ( store [ a [ i ] ] - ( i + 1 ) ) ;
if ( store [ a [ i ] ] < i + 1 ) { d = n - d ; }
ans [ d ] ++ ; } int finalans = 0 ;
for ( int i = 0 ; i < 1e5 ; i ++ ) finalans = max ( finalans , ans [ i ] ) ;
cout << finalans << " STRNEWLINE " ; }
int A [ ] = { 6 , 7 , 3 , 9 , 5 } ; int B [ ] = { 7 , 3 , 9 , 5 , 6 } ; int size = sizeof ( A ) / sizeof ( A [ 0 ] ) ;
maximumEqual ( A , B , size ) ; return 0 ; }
void rotatedSumQuery ( int arr [ ] , int n , vector < vector < int > > & query , int Q ) {
int prefix [ 2 * n ] ;
for ( int i = 0 ; i < n ; i ++ ) { prefix [ i ] = arr [ i ] ; prefix [ i + n ] = arr [ i ] ; }
for ( int i = 1 ; i < 2 * n ; i ++ ) prefix [ i ] += prefix [ i - 1 ] ;
int start = 0 ; for ( int q = 0 ; q < Q ; q ++ ) {
if ( query [ q ] [ 0 ] == 1 ) { int k = query [ q ] [ 1 ] ; start = ( start + k ) % n ; }
else if ( query [ q ] [ 0 ] == 2 ) { int L , R ; L = query [ q ] [ 1 ] ; R = query [ q ] [ 2 ] ;
if ( start + L == 0 )
cout << prefix [ start + R ] << endl ; else
cout << prefix [ start + R ] - prefix [ start + L - 1 ] << endl ; } } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ;
int Q = 5 ;
vector < vector < int > > query = { { 2 , 1 , 3 } , { 1 , 3 } , { 2 , 0 , 3 } , { 1 , 4 } , { 2 , 3 , 5 } } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; rotatedSumQuery ( arr , n , query , Q ) ; return 0 ; }
void isConversionPossible ( string s1 , string s2 , int x ) { int diff , n ; n = s1 . length ( ) ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( s1 [ i ] == s2 [ i ] ) continue ;
diff = ( int ( s2 [ i ] - s1 [ i ] ) + 26 ) % 26 ;
if ( diff > x ) { cout << " NO " << endl ; return ; } } cout << " YES " << endl ; }
int main ( ) { string s1 = " you " ; string s2 = " ara " ; int x = 6 ;
isConversionPossible ( s1 , s2 , x ) ; return 0 ; }
void RightRotate ( int a [ ] , int n , int k ) {
k = k % n ; for ( int i = 0 ; i < n ; i ++ ) { if ( i < k ) {
cout << a [ n + i - k ] << " ▁ " ; } else {
cout << ( a [ i - k ] ) << " ▁ " ; } } cout << " STRNEWLINE " ; }
int main ( ) { int Array [ ] = { 1 , 2 , 3 , 4 , 5 } ; int N = sizeof ( Array ) / sizeof ( Array [ 0 ] ) ; int K = 2 ; RightRotate ( Array , N , K ) ; }
int countRotation ( int n ) { int count = 0 ;
do { int digit = n % 10 ;
if ( digit == 0 ) count ++ ; n = n / 10 ; } while ( n != 0 ) ; return count ; }
int main ( ) { int n = 10203 ; cout << countRotation ( n ) ; }
class Node { public : int data ; Node * next ; } ;
void push ( Node * * head_ref , int new_data ) {
Node * new_node = new Node ( ) ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( Node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ - > ▁ " ; node = node -> next ; } cout << " NULL " ; }
Node * rightRotate ( Node * head , int k ) {
if ( ! head ) return head ;
Node * tmp = head ; int len = 1 ; while ( tmp -> next != NULL ) { tmp = tmp -> next ; len ++ ; }
if ( k > len ) k = k % len ;
k = len - k ;
if ( k == 0 k == len ) return head ;
Node * current = head ; int cnt = 1 ; while ( cnt < k && current != NULL ) { current = current -> next ; cnt ++ ; }
if ( current == NULL ) return head ;
Node * kthnode = current ;
tmp -> next = head ;
head = kthnode -> next ;
kthnode -> next = NULL ;
return head ; }
Node * head = NULL ; push ( & head , 5 ) ; push ( & head , 4 ) ; push ( & head , 3 ) ; push ( & head , 2 ) ; push ( & head , 1 ) ; int k = 2 ;
Node * updated_head = rightRotate ( head , k ) ;
printList ( updated_head ) ; return 0 ; }
bool isPossible ( int a [ ] , int n ) {
if ( n <= 2 ) return true ; int flag = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) { if ( ! ( a [ i ] > a [ i + 1 ] and a [ i + 1 ] > a [ i + 2 ] ) ) { flag = 1 ; break ; } }
if ( flag == 0 ) return true ; flag = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) { if ( ! ( a [ i ] < a [ i + 1 ] and a [ i + 1 ] < a [ i + 2 ] ) ) { flag = 1 ; break ; } }
if ( flag == 0 ) return true ;
int val1 = INT_MAX , mini = -1 , val2 = INT_MIN , maxi ; for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] < val1 ) { mini = i ; val1 = a [ i ] ; } if ( a [ i ] > val2 ) { maxi = i ; val2 = a [ i ] ; } } flag = 1 ;
for ( int i = 0 ; i < maxi ; i ++ ) { if ( a [ i ] > a [ i + 1 ] ) { flag = 0 ; break ; } }
if ( flag == 1 and maxi + 1 == mini ) { flag = 1 ;
for ( int i = mini ; i < n - 1 ; i ++ ) { if ( a [ i ] > a [ i + 1 ] ) { flag = 0 ; break ; } } if ( flag == 1 ) return true ; } flag = 1 ;
for ( int i = 0 ; i < mini ; i ++ ) { if ( a [ i ] < a [ i + 1 ] ) { flag = 0 ; break ; } }
if ( flag == 1 and maxi - 1 == mini ) { flag = 1 ;
for ( int i = maxi ; i < n - 1 ; i ++ ) { if ( a [ i ] < a [ i + 1 ] ) { flag = 0 ; break ; } } if ( flag == 1 ) return true ; }
return false ; }
int main ( ) { int a [ ] = { 4 , 5 , 6 , 2 , 3 } ; int n = sizeof ( a ) / sizeof ( a [ 0 ] ) ; if ( isPossible ( a , n ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
int cntRotations ( string s , int n ) {
string str = s + s ;
int pre [ 2 * n ] = { 0 } ;
for ( int i = 0 ; i < 2 * n ; i ++ ) { if ( i != 0 ) pre [ i ] += pre [ i - 1 ] ; if ( str [ i ] == ' a ' str [ i ] == ' e ' str [ i ] == ' i ' str [ i ] == ' o ' str [ i ] == ' u ' ) { pre [ i ] ++ ; } }
int ans = 0 ;
for ( int i = n - 1 ; i < 2 * n - 1 ; i ++ ) {
int r = i , l = i - n ;
int x1 = pre [ r ] ; if ( l >= 0 ) x1 -= pre [ l ] ; r = i - n / 2 ;
int left = pre [ r ] ; if ( l >= 0 ) left -= pre [ l ] ;
int right = x1 - left ;
if ( left > right ) { ans ++ ; } }
return ans ; }
int main ( ) { string s = " abecidft " ; int n = s . length ( ) ; cout << cntRotations ( s , n ) ; return 0 ; }
int cntRotations ( char s [ ] , int n ) { int lh = 0 , rh = 0 , i , ans = 0 ;
for ( i = 0 ; i < n / 2 ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { lh ++ ; }
for ( i = n / 2 ; i < n ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { rh ++ ; }
if ( lh > rh ) ans ++ ;
for ( i = 1 ; i < n ; ++ i ) { if ( s [ i - 1 ] == ' a ' s [ i - 1 ] == ' e ' s [ i - 1 ] == ' i ' s [ i - 1 ] == ' o ' s [ i - 1 ] == ' u ' ) { rh ++ ; lh -- ; } if ( s [ ( i - 1 + n / 2 ) % n ] == ' a ' || s [ ( i - 1 + n / 2 ) % n ] == ' e ' || s [ ( i - 1 + n / 2 ) % n ] == ' i ' || s [ ( i - 1 + n / 2 ) % n ] == ' o ' || s [ ( i - 1 + n / 2 ) % n ] == ' u ' ) { rh -- ; lh ++ ; } if ( lh > rh ) ans ++ ; }
return ans ; }
int main ( ) { char s [ ] = " abecidft " ; int n = strlen ( s ) ;
cout << " ▁ " << cntRotations ( s , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define size  2
void performQueries ( string str , int n , int queries [ ] [ size ] , int q ) {
int ptr = 0 ;
for ( int i = 0 ; i < q ; i ++ ) {
if ( queries [ i ] [ 0 ] == 1 ) {
ptr = ( ptr + queries [ i ] [ 1 ] ) % n ; } else { int k = queries [ i ] [ 1 ] ;
int index = ( ptr + k - 1 ) % n ;
cout << str [ index ] << " STRNEWLINE " ; } } }
int main ( ) { string str = " abcdefgh " ; int n = str . length ( ) ; int queries [ ] [ size ] = { { 1 , 2 } , { 2 , 2 } , { 1 , 4 } , { 2 , 7 } } ; int q = sizeof ( queries ) / sizeof ( queries [ 0 ] ) ; performQueries ( str , n , queries , q ) ; return 0 ; }
void ReverseArray ( string & arr , int left , int right ) { char temp ; while ( left < right ) { temp = arr [ left ] ; arr [ left ] = arr [ right ] ; arr [ right ] = temp ; left ++ ; right -- ; } }
bool RotateAndCheck ( string & str1 , string & str2 , int d ) { if ( str1 . length ( ) != str2 . length ( ) ) return false ;
string left_rot_str1 , right_rot_str1 ; bool left_flag = true , right_flag = true ; int str1_size = str1 . size ( ) ;
for ( int i = 0 ; i < str1_size ; i ++ ) { left_rot_str1 . push_back ( str1 [ i ] ) ; right_rot_str1 . push_back ( str1 [ i ] ) ; }
ReverseArray ( left_rot_str1 , 0 , d - 1 ) ; ReverseArray ( left_rot_str1 , d , str1_size - 1 ) ; ReverseArray ( left_rot_str1 , 0 , str1_size - 1 ) ;
ReverseArray ( right_rot_str1 , 0 , str1_size - d - 1 ) ; ReverseArray ( right_rot_str1 , str1_size - d , str1_size - 1 ) ; ReverseArray ( right_rot_str1 , 0 , str1_size - 1 ) ;
for ( int i = 0 ; i < str1_size ; i ++ ) {
if ( left_rot_str1 [ i ] != str2 [ i ] ) { left_flag = false ; }
if ( right_rot_str1 [ i ] != str2 [ i ] ) { right_flag = false ; } }
if ( left_flag right_flag ) return true ; return false ; }
int main ( ) { string str1 = " abcdefg " ; string str2 = " cdefgab " ;
int d = 2 ;
d = d % str1 . size ( ) ; if ( RotateAndCheck ( str1 , str2 , d ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
void countOddRotations ( int n ) { int odd_count = 0 , even_count = 0 ; do { int digit = n % 10 ; if ( digit % 2 == 1 ) odd_count ++ ; else even_count ++ ; n = n / 10 ; } while ( n != 0 ) ; cout << " Odd ▁ = ▁ " << odd_count << endl ; cout << " Even ▁ = ▁ " << even_count << endl ; }
int main ( ) { int n = 1234 ; countOddRotations ( n ) ; }
int numberOfDigits ( int n ) { int cnt = 0 ; while ( n > 0 ) { cnt ++ ; n /= 10 ; } return cnt ; }
void cal ( int num ) { int digits = numberOfDigits ( num ) ; int powTen = pow ( 10 , digits - 1 ) ; for ( int i = 0 ; i < digits - 1 ; i ++ ) { int firstDigit = num / powTen ;
int left = ( ( num * 10 ) + firstDigit ) - ( firstDigit * powTen * 10 ) ; cout << left << " ▁ " ;
num = left ; } }
int main ( ) { int num = 1445 ; cal ( num ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void CheckKCycles ( int n , string s ) { bool ff = true ; int x = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
x = ( s . substr ( i ) + s . substr ( 0 , i ) ) . length ( ) ;
if ( x >= s . length ( ) ) { continue ; } ff = false ; break ; } if ( ff ) { cout << ( " Yes " ) ; } else { cout << ( " No " ) ; } }
int main ( ) { int n = 3 ; string s = "123" ; CheckKCycles ( n , s ) ; return 0 ; }
struct ListNode { int data ; struct ListNode * next ; } ;
void rotateSubList ( ListNode * A , int m , int n , int k ) { int size = n - m + 1 ;
if ( k > size ) { k = k % size ; }
if ( k == 0 k == size ) { ListNode * head = A ; while ( head != NULL ) { cout << head -> data ; head = head -> next ; } return ; }
ListNode * link = NULL ; if ( m == 1 ) { link = A ; }
ListNode * c = A ;
int count = 0 ; ListNode * end = NULL ;
ListNode * pre = NULL ; while ( c != NULL ) { count ++ ;
if ( count == m - 1 ) { pre = c ; link = c -> next ; } if ( count == n - k ) { if ( m == 1 ) { end = c ; A = c -> next ; } else { end = c ;
pre -> next = c -> next ; } }
if ( count == n ) { ListNode * d = c -> next ; c -> next = link ; end -> next = d ; ListNode * head = A ; while ( head != NULL ) { cout << head -> data << " ▁ " ; head = head -> next ; } return ; } c = c -> next ; } }
void push ( struct ListNode * * head , int val ) { struct ListNode * new_node = new ListNode ; new_node -> data = val ; new_node -> next = ( * head ) ; ( * head ) = new_node ; }
int main ( ) { struct ListNode * head = NULL ; push ( & head , 70 ) ; push ( & head , 60 ) ; push ( & head , 50 ) ; push ( & head , 40 ) ; push ( & head , 30 ) ; push ( & head , 20 ) ; push ( & head , 10 ) ; ListNode * tmp = head ; cout << " Given ▁ List : ▁ " ; while ( tmp != NULL ) { cout << tmp -> data << " ▁ " ; tmp = tmp -> next ; } cout << endl ; int m = 3 , n = 6 , k = 2 ; cout << " After ▁ rotation ▁ of ▁ sublist : ▁ " ; rotateSubList ( head , m , n , k ) ; return 0 ; }
bool rightRotationDivisor ( int N ) { int lastDigit = N % 10 ; int rightRotation = ( lastDigit * pow ( 10 , int ( log10 ( N ) ) ) ) + floor ( N / 10 ) ; return ( rightRotation % N == 0 ) ; }
void generateNumbers ( int m ) { for ( int i = pow ( 10 , ( m - 1 ) ) ; i < pow ( 10 , m ) ; i ++ ) if ( rightRotationDivisor ( i ) ) cout << i << endl ; }
int main ( ) { int m = 3 ; generateNumbers ( m ) ; }
class node { public : int data ; node * left ; node * right ; node * next ; } ;
void populateNext ( node * p ) {
static node * next = NULL ; if ( p ) {
populateNext ( p -> right ) ;
p -> next = next ;
next = p ;
populateNext ( p -> left ) ; } }
int main ( ) { node * root = newnode ( 10 ) ; root -> left = newnode ( 8 ) ; root -> right = newnode ( 12 ) ; root -> left -> left = newnode ( 3 ) ;
populateNext ( root ) ;
node * ptr = root -> left -> left ; while ( ptr ) {
cout << " Next ▁ of ▁ " << ptr -> data << " ▁ is ▁ " << ( ptr -> next ? ptr -> next -> data : -1 ) << endl ; ptr = ptr -> next ; } return 0 ; }
void generateNumbers ( int m ) { vector < int > numbers ; int k_max , x ; for ( int y = 0 ; y < 10 ; y ++ ) { k_max = ( int ) ( pow ( 10 , m - 2 ) * ( 10 * y + 1 ) ) / ( int ) ( pow ( 10 , m - 1 ) + y ) ; for ( int k = 1 ; k <= k_max ; k ++ ) { x = ( int ) ( y * ( pow ( 10 , m - 1 ) - k ) ) / ( 10 * k - 1 ) ; if ( ( int ) ( y * ( pow ( 10 , m - 1 ) - k ) ) % ( 10 * k - 1 ) == 0 ) numbers . push_back ( 10 * x + y ) ; } } sort ( numbers . begin ( ) , numbers . end ( ) ) ; for ( int i = 0 ; i < numbers . size ( ) ; i ++ ) cout << ( numbers [ i ] ) << endl ; }
int main ( ) { int m = 3 ; generateNumbers ( m ) ; }
void checkIfSortRotated ( int arr [ ] , int n ) { int minEle = INT_MAX ; int maxEle = INT_MIN ; int minIndex = -1 ;
for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < minEle ) { minEle = arr [ i ] ; minIndex = i ; } } int flag1 = 1 ;
for ( int i = 1 ; i < minIndex ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag1 = 0 ; break ; } } int flag2 = 1 ;
for ( int i = minIndex + 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag2 = 0 ; break ; } }
if ( flag1 && flag2 && ( arr [ n - 1 ] < arr [ 0 ] ) ) cout << " YES " ; else cout << " NO " ; }
int main ( ) { int arr [ ] = { 3 , 4 , 5 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
checkIfSortRotated ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  4
void rotate90Clockwise ( int arr [ N ] [ N ] ) {
for ( int j = 0 ; j < N ; j ++ ) { for ( int i = N - 1 ; i >= 0 ; i -- ) cout << arr [ i ] [ j ] << " ▁ " ; cout << ' ' ; } }
int main ( ) { int arr [ N ] [ N ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; rotate90Clockwise ( arr ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  4
void rotate ( int arr [ N ] [ N ] ) {
for ( int i = 0 ; i < N ; ++ i ) { for ( int j = 0 ; j < i ; ++ j ) { int temp = arr [ i ] [ j ] ; arr [ i ] [ j ] = arr [ j ] [ i ] ; arr [ j ] [ i ] = temp ; } }
for ( int i = 0 ; i < N ; ++ i ) { for ( int j = 0 ; j < N / 2 ; ++ j ) { int temp = arr [ i ] [ j ] ; arr [ i ] [ j ] = arr [ i ] [ N - j - 1 ] ; arr [ i ] [ N - j - 1 ] = temp ; } } }
void print ( int arr [ N ] [ N ] ) { for ( int i = 0 ; i < N ; ++ i ) { for ( int j = 0 ; j < N ; ++ j ) cout << arr [ i ] [ j ] << " ▁ " ; cout << ' ' ; } }
int main ( ) { int arr [ N ] [ N ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; rotate ( arr ) ; print ( arr ) ; return 0 ; }
void occurredOnce ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
if ( arr [ 0 ] != arr [ 1 ] ) cout << arr [ 0 ] << " ▁ " ;
for ( int i = 1 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i - 1 ] ) cout << arr [ i ] << " ▁ " ;
if ( arr [ n - 2 ] != arr [ n - 1 ] ) cout << arr [ n - 1 ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; occurredOnce ( arr , n ) ; return 0 ; }
void occurredOnce ( int arr [ ] , int n ) { unordered_map < int , int > mp ;
for ( int i = 0 ; i < n ; i ++ ) mp [ arr [ i ] ] ++ ;
for ( auto it = mp . begin ( ) ; it != mp . end ( ) ; it ++ ) if ( it -> second == 1 ) cout << it -> first << " ▁ " ; }
int main ( ) { int arr [ ] = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; occurredOnce ( arr , n ) ; return 0 ; }
void occurredOnce ( int arr [ ] , int n ) { int i = 1 , len = n ;
if ( arr [ 0 ] == arr [ len - 1 ] ) { i = 2 ; len -- ; }
for ( ; i < n ; i ++ )
if ( arr [ i ] == arr [ i - 1 ] ) i ++ ;
else cout < < arr [ i - 1 ] << " ▁ " ;
if ( arr [ n - 1 ] != arr [ 0 ] && arr [ n - 1 ] != arr [ n - 2 ] ) cout << arr [ n - 1 ] ; }
int main ( ) { int arr [ ] = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; occurredOnce ( arr , n ) ; return 0 ; }
void rvereseArray ( int arr [ ] , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) cout << arr [ i ] << " ▁ " ; }
void splitArr ( int arr [ ] , int k , int n ) { rvereseArray ( arr , 0 , n - 1 ) ; rvereseArray ( arr , 0 , n - k - 1 ) ; rvereseArray ( arr , n - k , n - 1 ) ; }
int main ( ) { int arr [ ] = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int k = 2 ;
splitArr ( arr , k , n ) ; printArray ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; bool isRotation ( string a , string b ) { int n = a . length ( ) ; int m = b . length ( ) ; if ( n != m ) return false ;
int lps [ n ] ;
int len = 0 ; int i = 1 ;
lps [ 0 ] = 0 ;
while ( i < n ) { if ( a [ i ] == b [ len ] ) { lps [ i ] = ++ len ; ++ i ; } else { if ( len == 0 ) { lps [ i ] = 0 ; ++ i ; } else { len = lps [ len - 1 ] ; } } } i = 0 ;
for ( int k = lps [ n - 1 ] ; k < m ; ++ k ) { if ( b [ k ] != a [ i ++ ] ) return false ; } return true ; }
int main ( ) { string s1 = " ABACD " ; string s2 = " CDABA " ; cout << ( isRotation ( s1 , s2 ) ? "1" : "0" ) ; }
int countRotationsDivBy8 ( string n ) { int len = n . length ( ) ; int count = 0 ;
if ( len == 1 ) { int oneDigit = n [ 0 ] - '0' ; if ( oneDigit % 8 == 0 ) return 1 ; return 0 ; }
if ( len == 2 ) {
int first = ( n [ 0 ] - '0' ) * 10 + ( n [ 1 ] - '0' ) ;
int second = ( n [ 1 ] - '0' ) * 10 + ( n [ 0 ] - '0' ) ; if ( first % 8 == 0 ) count ++ ; if ( second % 8 == 0 ) count ++ ; return count ; }
int threeDigit ; for ( int i = 0 ; i < ( len - 2 ) ; i ++ ) { threeDigit = ( n [ i ] - '0' ) * 100 + ( n [ i + 1 ] - '0' ) * 10 + ( n [ i + 2 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ; }
threeDigit = ( n [ len - 1 ] - '0' ) * 100 + ( n [ 0 ] - '0' ) * 10 + ( n [ 1 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
threeDigit = ( n [ len - 2 ] - '0' ) * 100 + ( n [ len - 1 ] - '0' ) * 10 + ( n [ 0 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
return count ; }
int main ( ) { string n = "43262488612" ; cout << " Rotations : ▁ " << countRotationsDivBy8 ( n ) ; return 0 ; }
int minimunMoves ( string arr [ ] , int n ) { int ans = INT_MAX ; for ( int i = 0 ; i < n ; i ++ ) { int curr_count = 0 ;
for ( int j = 0 ; j < n ; j ++ ) { string tmp = arr [ j ] + arr [ j ] ;
int index = tmp . find ( arr [ i ] ) ;
if ( index == string :: npos ) return -1 ; curr_count += index ; } ans = min ( curr_count , ans ) ; } return ans ; }
int main ( ) { string arr [ ] = { " xzzwo " , " zwoxz " , " zzwox " , " xzzwo " } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << minimunMoves ( arr , n ) ; return 0 ; }
void restoreSortedArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] > arr [ i + 1 ] ) {
reverse ( arr , arr + i + 1 ) ; reverse ( arr + i + 1 , arr + n ) ; reverse ( arr , arr + n ) ; } } }
void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 3 , 4 , 5 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; restoreSortedArray ( arr , n ) ; printArray ( arr , n ) ; return 0 ; }
int findStartIndexOfArray ( int arr [ ] , int low , int high ) { if ( low > high ) { return -1 ; } if ( low == high ) { return low ; } int mid = low + ( high - low ) / 2 ; if ( arr [ mid ] > arr [ mid + 1 ] ) return mid + 1 ; if ( arr [ mid - 1 ] > arr [ mid ] ) return mid ; if ( arr [ low ] > arr [ mid ] ) return findStartIndexOfArray ( arr , low , mid - 1 ) ; else return findStartIndexOfArray ( arr , mid + 1 , high ) ; }
void restoreSortedArray ( int arr [ ] , int n ) {
if ( arr [ 0 ] < arr [ n - 1 ] ) return ; int start = findStartIndexOfArray ( arr , 0 , n - 1 ) ;
reverse ( arr , arr + start ) ; reverse ( arr + start , arr + n ) ; reverse ( arr , arr + n ) ; }
void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) cout << arr [ i ] << " ▁ " ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; restoreSortedArray ( arr , n ) ; printArray ( arr , n ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
int countRotation ( struct Node * head ) {
int count = 0 ;
int min = head -> data ;
while ( head != NULL ) {
if ( min > head -> data ) break ; count ++ ;
head = head -> next ; } return count ; }
void push ( struct Node * * head , int data ) {
struct Node * newNode = new Node ;
newNode -> data = data ;
newNode -> next = ( * head ) ;
( * head ) = newNode ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
struct Node * head = NULL ;
push ( & head , 12 ) ; push ( & head , 11 ) ; push ( & head , 8 ) ; push ( & head , 5 ) ; push ( & head , 18 ) ; push ( & head , 15 ) ; printList ( head ) ; cout << endl ; cout << " Linked ▁ list ▁ rotated ▁ elements : ▁ " ;
cout << countRotation ( head ) << endl ; return 0 ; }
class Node { public : int data ; Node * next ; } ;
Node * rotateHelper ( Node * blockHead , Node * blockTail , int d , Node * * tail , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { Node * temp = blockHead ; for ( int i = 1 ; temp -> next -> next && i < k - 1 ; i ++ ) temp = temp -> next ; blockTail -> next = blockHead ; * tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , tail , k ) ; }
if ( d < 0 ) { blockTail -> next = blockHead ; * tail = blockHead ; return rotateHelper ( blockHead -> next , blockHead , d + 1 , tail , k ) ; } }
Node * rotateByBlocks ( Node * head , int k , int d ) {
if ( ! head ! head -> next ) return head ;
if ( d == 0 ) return head ; Node * temp = head , * tail = NULL ;
int i ; for ( i = 1 ; temp -> next && i < k ; i ++ ) temp = temp -> next ;
Node * nextBlock = temp -> next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , & tail , i ) ; else head = rotateHelper ( head , temp , d % k , & tail , k ) ;
tail -> next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
void push ( Node * * head_ref , int new_data ) { Node * new_node = new Node ; new_node -> data = new_data ; new_node -> next = ( * head_ref ) ; ( * head_ref ) = new_node ; }
void printList ( Node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> next ; } }
Node * head = NULL ;
for ( int i = 9 ; i > 0 ; i -= 1 ) push ( & head , i ) ; cout << " Given ▁ linked ▁ list ▁ STRNEWLINE " ; printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; cout << " Rotated by blocks Linked list " ; printList ( head ) ; return ( 0 ) ; }
bool isRotation ( unsigned int x , unsigned int y ) {
unsigned long long int x64 = x | ( ( unsigned long long int ) x << 32 ) ; while ( x64 >= y ) {
if ( unsigned ( x64 ) == y ) return true ;
x64 >>= 1 ; } return false ; }
int main ( ) { unsigned int x = 122 ; unsigned int y = 2147483678 ; if ( isRotation ( x , y ) ) cout << " yes " << endl ; else cout << " no " << endl ; return 0 ; }
void leftrotate ( string & s , int d ) { reverse ( s . begin ( ) , s . begin ( ) + d ) ; reverse ( s . begin ( ) + d , s . end ( ) ) ; reverse ( s . begin ( ) , s . end ( ) ) ; }
void rightrotate ( string & s , int d ) { leftrotate ( s , s . length ( ) - d ) ; }
int main ( ) { string str1 = " GeeksforGeeks " ; leftrotate ( str1 , 2 ) ; cout << str1 << endl ; string str2 = " GeeksforGeeks " ; rightrotate ( str2 , 2 ) ; cout << str2 << endl ; return 0 ; }
int countRotations ( string n ) { int len = n . length ( ) ;
if ( len == 1 ) { int oneDigit = n . at ( 0 ) - '0' ; if ( oneDigit % 4 == 0 ) return 1 ; return 0 ; }
int twoDigit , count = 0 ; for ( int i = 0 ; i < ( len - 1 ) ; i ++ ) { twoDigit = ( n . at ( i ) - '0' ) * 10 + ( n . at ( i + 1 ) - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; }
twoDigit = ( n . at ( len - 1 ) - '0' ) * 10 + ( n . at ( 0 ) - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; return count ; }
int main ( ) { string n = "4834" ; cout << " Rotations : ▁ " << countRotations ( n ) << endl ; return 0 ; }
bool isRotated ( string str1 , string str2 ) { if ( str1 . length ( ) != str2 . length ( ) ) return false ; if ( str1 . length ( ) < 2 ) { return str1 . compare ( str2 ) == 0 ; } string clock_rot = " " ; string anticlock_rot = " " ; int len = str2 . length ( ) ;
anticlock_rot = anticlock_rot + str2 . substr ( len - 2 , 2 ) + str2 . substr ( 0 , len - 2 ) ;
clock_rot = clock_rot + str2 . substr ( 2 ) + str2 . substr ( 0 , 2 ) ;
return ( str1 . compare ( clock_rot ) == 0 || str1 . compare ( anticlock_rot ) == 0 ) ; }
int main ( ) { string str1 = " geeks " ; string str2 = " eksge " ; isRotated ( str1 , str2 ) ? cout << " Yes " : cout << " No " ; return 0 ; }
string minLexRotation ( string str ) {
int n = str . length ( ) ;
string arr [ n ] ;
string concat = str + str ;
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = concat . substr ( i , n ) ;
sort ( arr , arr + n ) ;
return arr [ 0 ] ; }
int main ( ) { cout << minLexRotation ( " GEEKSFORGEEKS " ) << endl ; cout << minLexRotation ( " GEEKSQUIZ " ) << endl ; cout << minLexRotation ( " BCABDADAB " ) << endl ; }
class Node { public : int data ; Node * next ; } ;
void rotate ( Node * * head_ref , int k ) { if ( k == 0 ) return ;
Node * current = * head_ref ;
while ( current -> next != NULL ) current = current -> next ; current -> next = * head_ref ; current = * head_ref ;
for ( int i = 0 ; i < k - 1 ; i ++ ) current = current -> next ;
* head_ref = current -> next ; current -> next = NULL ; }
void push ( Node * * head_ref , int new_data ) {
Node * new_node = new Node ( ) ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( Node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> next ; } }
for ( int i = 60 ; i > 0 ; i -= 10 ) push ( & head , i ) ; cout << " Given ▁ linked ▁ list ▁ STRNEWLINE " ; printList ( head ) ; rotate ( & head , 4 ) ; cout << " Rotated Linked list " ; printList ( head ) ; return ( 0 ) ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
struct Node { int data ; Node * next ;
Node ( int d ) { data = d ; next = NULL ; } } ;
void print ( Node * head ) { Node * temp = head ;
while ( temp != NULL ) {
cout << temp -> data << " ▁ " ; temp = temp -> next ; } }
void NextGreaterElement ( Node * head ) {
Node * H = head ;
Node * res = NULL ;
Node * tempList = NULL ;
do {
Node * curr = head ;
int Val = -1 ;
do {
if ( head -> data < curr -> data ) {
Val = curr -> data ; break ; }
curr = curr -> next ; } while ( curr != head ) ;
if ( res == NULL ) {
res = new Node ( Val ) ;
tempList = res ; } else {
tempList -> next = new Node ( Val ) ;
tempList = tempList -> next ; }
head = head -> next ; } while ( head != H ) ;
print ( res ) ; }
int main ( ) { Node * head = new Node ( 1 ) ; head -> next = new Node ( 5 ) ; head -> next -> next = new Node ( 12 ) ; head -> next -> next -> next = new Node ( 10 ) ; head -> next -> next -> next -> next = new Node ( 0 ) ; head -> next -> next -> next -> next -> next = head ; NextGreaterElement ( head ) ; return 0 ; }
class Node { public : int data ; Node * next ; } ;
class Node { public : int data ; Node * next ; } ;
void printList ( Node * n ) {
while ( n != NULL ) {
cout << n -> data << " ▁ " ; n = n -> next ; } }
int main ( ) { Node * head = NULL ; Node * second = NULL ; Node * third = NULL ;
head = new Node ( ) ; second = new Node ( ) ; third = new Node ( ) ;
head -> data = 1 ;
head -> next = second ;
second -> data = 2 ; second -> next = third ;
third -> data = 3 ; third -> next = NULL ; printList ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int data ) {
struct Node * ptr1 = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; struct Node * temp = * head_ref ; ptr1 -> data = data ; ptr1 -> next = * head_ref ;
if ( * head_ref != NULL ) {
while ( temp -> next != * head_ref ) temp = temp -> next ; temp -> next = ptr1 ; } else
ptr1 -> next = ptr1 ; * head_ref = ptr1 ; }
void deleteNode ( Node * & head_ref , Node * del ) {
if ( head_ref == del ) head_ref = del -> next ; struct Node * temp = head_ref ;
while ( temp -> next != del ) { temp = temp -> next ; }
temp -> next = del -> next ;
free ( del ) ; return ; }
bool isEvenParity ( int x ) {
int parity = 0 ; while ( x != 0 ) { if ( x & 1 ) parity ++ ; x = x >> 1 ; } if ( parity % 2 == 0 ) return true ; else return false ; }
void deleteEvenParityNodes ( Node * & head ) { if ( head == NULL ) return ; if ( head == head -> next ) { if ( isEvenParity ( head -> data ) ) head = NULL ; return ; } struct Node * ptr = head ; struct Node * next ;
do { next = ptr -> next ;
if ( isEvenParity ( ptr -> data ) ) deleteNode ( head , ptr ) ;
ptr = next ; } while ( ptr != head ) ; if ( head == head -> next ) { if ( isEvenParity ( head -> data ) ) head = NULL ; return ; } }
void printList ( struct Node * head ) { if ( head == NULL ) { cout << " Empty ▁ List STRNEWLINE " ; return ; } struct Node * temp = head ; if ( head != NULL ) { do { printf ( " % d ▁ " , temp -> data ) ; temp = temp -> next ; } while ( temp != head ) ; } }
struct Node * head = NULL ;
push ( & head , 21 ) ; push ( & head , 13 ) ; push ( & head , 6 ) ; push ( & head , 34 ) ; push ( & head , 9 ) ; push ( & head , 11 ) ; deleteEvenParityNodes ( head ) ; printList ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int data ) {
struct Node * ptr1 = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; struct Node * temp = * head_ref ; ptr1 -> data = data ; ptr1 -> next = * head_ref ;
if ( * head_ref != NULL ) {
while ( temp -> next != * head_ref ) temp = temp -> next ; temp -> next = ptr1 ; } else
ptr1 -> next = ptr1 ; * head_ref = ptr1 ; }
void deleteNode ( Node * head_ref , Node * del ) { struct Node * temp = head_ref ;
if ( head_ref == del ) head_ref = del -> next ;
while ( temp -> next != del ) { temp = temp -> next ; }
temp -> next = del -> next ;
free ( del ) ; return ; }
int digitSum ( int num ) { int sum = 0 ; while ( num ) { sum += ( num % 10 ) ; num /= 10 ; } return sum ; }
void deleteEvenDigitSumNodes ( Node * head ) { struct Node * ptr = head ; struct Node * next ;
do {
if ( ! ( digitSum ( ptr -> data ) & 1 ) ) deleteNode ( head , ptr ) ;
next = ptr -> next ; ptr = next ; } while ( ptr != head ) ; }
void printList ( struct Node * head ) { struct Node * temp = head ; if ( head != NULL ) { do { printf ( " % d ▁ " , temp -> data ) ; temp = temp -> next ; } while ( temp != head ) ; } }
struct Node * head = NULL ;
push ( & head , 21 ) ; push ( & head , 13 ) ; push ( & head , 6 ) ; push ( & head , 34 ) ; push ( & head , 11 ) ; push ( & head , 9 ) ; deleteEvenDigitSumNodes ( head ) ; printList ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int data ) {
struct Node * ptr1 = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; struct Node * temp = * head_ref ; ptr1 -> data = data ; ptr1 -> next = * head_ref ;
if ( * head_ref != NULL ) {
while ( temp -> next != * head_ref ) temp = temp -> next ; temp -> next = ptr1 ; } else
ptr1 -> next = ptr1 ; * head_ref = ptr1 ; }
void deleteNode ( Node * head_ref , Node * del ) { struct Node * temp = head_ref ;
if ( head_ref == del ) head_ref = del -> next ;
while ( temp -> next != del ) { temp = temp -> next ; }
temp -> next = del -> next ;
free ( del ) ; return ; }
int largestElement ( struct Node * head_ref ) {
struct Node * current ;
current = head_ref ;
int maxEle = INT_MIN ;
do {
if ( current -> data > maxEle ) { maxEle = current -> data ; } current = current -> next ; } while ( current != head_ref ) ; return maxEle ; }
void createHash ( set < int > & hash , int maxElement ) { int prev = 0 , curr = 1 ;
hash . insert ( prev ) ; hash . insert ( curr ) ;
while ( curr <= maxElement ) { int temp = curr + prev ; hash . insert ( temp ) ; prev = curr ; curr = temp ; } }
void deleteFibonacciNodes ( Node * head ) {
int maxEle = largestElement ( head ) ;
set < int > hash ; createHash ( hash , maxEle ) ; struct Node * ptr = head ; struct Node * next ;
do {
if ( hash . find ( ptr -> data ) != hash . end ( ) ) deleteNode ( head , ptr ) ;
next = ptr -> next ; ptr = next ; } while ( ptr != head ) ; }
void printList ( struct Node * head ) { struct Node * temp = head ; if ( head != NULL ) { do { printf ( " % d ▁ " , temp -> data ) ; temp = temp -> next ; } while ( temp != head ) ; } }
struct Node * head = NULL ;
push ( & head , 20 ) ; push ( & head , 13 ) ; push ( & head , 6 ) ; push ( & head , 34 ) ; push ( & head , 11 ) ; push ( & head , 9 ) ; deleteFibonacciNodes ( head ) ; printList ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int data ) { struct Node * ptr1 = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; struct Node * temp = * head_ref ; ptr1 -> data = data ; ptr1 -> next = * head_ref ;
if ( * head_ref != NULL ) { while ( temp -> next != * head_ref ) temp = temp -> next ; temp -> next = ptr1 ; } else
ptr1 -> next = ptr1 ; * head_ref = ptr1 ; }
void deleteNode ( Node * head_ref , Node * del ) { struct Node * temp = head_ref ;
if ( head_ref == del ) head_ref = del -> next ;
while ( temp -> next != del ) { temp = temp -> next ; }
temp -> next = del -> next ;
void deleteoddNodes ( Node * head ) { struct Node * ptr = head ; struct Node * next ;
do {
if ( ( ptr -> data % 2 ) == 1 ) deleteNode ( head , ptr ) ;
next = ptr -> next ; ptr = next ; } while ( ptr != head ) ; }
void printList ( struct Node * head ) { struct Node * temp = head ; if ( head != NULL ) { do { printf ( " % d ▁ " , temp -> data ) ; temp = temp -> next ; } while ( temp != head ) ; } }
struct Node * head = NULL ;
push ( & head , 2 ) ; push ( & head , 12 ) ; push ( & head , 11 ) ; push ( & head , 57 ) ; push ( & head , 61 ) ; push ( & head , 56 ) ; cout << " List after deletion : " ; deleteoddNodes ( head ) ; printList ( head ) ; return 0 ; }
struct Node { Node * next ; int data ; } ;
Node * create ( ) { Node * new_node = ( Node * ) malloc ( sizeof ( Node ) ) ; new_node -> next = NULL ; return new_node ; }
Node * find_head ( Node * random ) {
if ( random == NULL ) return NULL ; Node * head , * var = random ;
while ( ! ( var -> data > var -> next -> data var -> next == random ) ) { var = var -> next ; }
return var -> next ; }
Node * sortedInsert ( Node * head_ref , Node * new_node ) { Node * current = head_ref ;
if ( current == NULL ) { new_node -> next = new_node ; head_ref = new_node ; }
else if ( current -> data >= new_node -> data ) {
while ( current -> next != head_ref ) current = current -> next ; current -> next = new_node ; new_node -> next = head_ref ; head_ref = new_node ; } else {
while ( current -> next != head_ref && current -> next -> data < new_node -> data ) { current = current -> next ; } new_node -> next = current -> next ; current -> next = new_node ; }
return head_ref ; }
void printList ( Node * start ) { Node * temp ; if ( start != NULL ) { temp = start ; do { cout << temp -> data << " ▁ " ; temp = temp -> next ; } while ( temp != start ) ; } }
int main ( ) { int arr [ ] = { 12 , 56 , 2 , 11 , 1 , 90 } ; int list_size , i ;
Node * start = NULL ; Node * temp ;
for ( i = 0 ; i < 6 ; i ++ ) {
if ( start != NULL ) for ( int j = 0 ; j < ( rand ( ) % 10 ) ; j ++ ) start = start -> next ; temp = create ( ) ; temp -> data = arr [ i ] ; start = sortedInsert ( find_head ( start ) , temp ) ; }
printList ( find_head ( start ) ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; class CircularLinkedList { public : struct Node { int data ; Node * next ; } ; Node * last ;
Node * addToEmpty ( int data ) {
if ( last != NULL ) return last ;
Node * temp = new Node ( ) ;
temp -> data = data ; last = temp ;
last -> next = last ; return last ; }
Node * addBegin ( int data ) {
if ( last == NULL ) return addToEmpty ( data ) ;
Node * temp = new Node ( ) ;
temp -> data = data ; temp -> next = last -> next ; last -> next = temp ; return last ; }
void traverse ( ) { Node * p ;
if ( last == NULL ) { cout << ( " List ▁ is ▁ empty . " ) ; return ; }
p = last -> next ;
do { cout << p -> data << " ▁ " ; p = p -> next ; } while ( p != last -> next ) ; cout << endl ; }
int length ( ) {
int x = 0 ;
if ( last == NULL ) return x ;
Node * itr = last -> next ; while ( itr -> next != last -> next ) { x ++ ; itr = itr -> next ; }
return ( x + 1 ) ; }
Node * split ( int k ) {
Node * pass = new Node ( ) ;
if ( last == NULL ) return last ;
Node * newLast , * itr = last ; for ( int i = 0 ; i < k ; i ++ ) { itr = itr -> next ; }
newLast = itr ; pass -> next = itr -> next ; newLast -> next = last -> next ; last -> next = pass -> next ;
return newLast ; } } ;
int main ( ) { CircularLinkedList * clist = new CircularLinkedList ( ) ; clist -> last = NULL ; clist -> addToEmpty ( 12 ) ; clist -> addBegin ( 10 ) ; clist -> addBegin ( 8 ) ; clist -> addBegin ( 6 ) ; clist -> addBegin ( 4 ) ; clist -> addBegin ( 2 ) ; cout << ( " Original ▁ list : " ) ; clist -> traverse ( ) ; int k = 4 ;
clist2 -> last = clist -> split ( k ) ;
cout << ( " The ▁ new ▁ lists ▁ are : " ) ; clist2 -> traverse ( ) ; clist -> traverse ( ) ; }
struct Node { int data ; struct Node * left ; struct Node * right ; Node ( int x ) { data = x ; left = right = NULL ; } } ;
void inorder ( Node * root , vector < int > & v ) { if ( ! root ) return ;
inorder ( root -> left , v ) ;
v . push_back ( root -> data ) ;
inorder ( root -> right , v ) ; }
Node * bTreeToCList ( Node * root ) {
if ( root == NULL ) return NULL ;
vector < int > v ;
inorder ( root , v ) ;
Node * head_ref = new Node ( v [ 0 ] ) ;
Node * curr = head_ref ;
for ( int i = 1 ; i < v . size ( ) ; i ++ ) {
Node * temp = curr ;
curr -> right = new Node ( v [ i ] ) ;
curr = curr -> right ;
curr -> left = temp ; }
curr -> right = head_ref ;
head_ref -> left = curr ;
return head_ref ; }
void displayCList ( Node * head ) { cout << " Circular ▁ Doubly ▁ Linked ▁ List ▁ is ▁ : STRNEWLINE " ; Node * itr = head ; do { cout << itr -> data << " ▁ " ; itr = itr -> right ; } while ( head != itr ) ; cout << " STRNEWLINE " ; }
int main ( ) { Node * root = new Node ( 10 ) ; root -> left = new Node ( 12 ) ; root -> right = new Node ( 15 ) ; root -> left -> left = new Node ( 25 ) ; root -> left -> right = new Node ( 30 ) ; root -> right -> left = new Node ( 36 ) ; Node * head = bTreeToCList ( root ) ; displayCList ( head ) ; return 0 ; }
void DeleteAllOddNode ( struct Node * * head ) { int len = Length ( * head ) ; int count = 0 ; struct Node * previous = * head , * next = * head ;
if ( * head == NULL ) { printf ( " Delete Last List is empty " return ; }
if ( len == 1 ) { DeleteFirst ( head ) ; return ; }
while ( len > 0 ) {
if ( count == 0 ) {
DeleteFirst ( head ) ; }
if ( count % 2 == 0 && count != 0 ) { deleteNode ( * head , previous ) ; } previous = previous -> next ; next = previous -> next ; len -- ; count ++ ; } return ; }
void DeleteAllEvenNode ( struct Node * * head ) {
int len = Length ( * head ) ; int count = 1 ; struct Node * previous = * head , * next = * head ;
if ( * head == NULL ) { printf ( " List is empty " return ; }
if ( len < 2 ) { return ; }
previous = * head ;
next = previous -> next ; while ( len > 0 ) {
if ( count % 2 == 0 ) { previous -> next = next -> next ; free ( next ) ; previous = next -> next ; next = previous -> next ; } len -- ; count ++ ; } return ; }
struct Node { int data ; struct Node * next ; } ;
int Length ( struct Node * head ) { struct Node * current = head ; int count = 0 ;
if ( head == NULL ) { return 0 ; }
else { do { current = current -> next ; count ++ ; } while ( current != head ) ; } return count ; }
void Display ( struct Node * head ) { struct Node * current = head ;
if ( head == NULL ) { printf ( " Display List is empty " return ; }
else { do { printf ( " % d ▁ " , current -> data ) ; current = current -> next ; } while ( current != head ) ; } }
void Insert ( struct Node * * head , int data ) { struct Node * current = * head ;
struct Node * newNode = new Node ;
if ( ! newNode ) { printf ( " Memory Error " return ; }
newNode -> data = data ;
if ( * head == NULL ) { newNode -> next = newNode ; * head = newNode ; return ;
} else {
while ( current -> next != * head ) { current = current -> next ; }
newNode -> next = * head ;
current -> next = newNode ; } }
void deleteNode ( struct Node * head_ref , struct Node * del ) { struct Node * temp = head_ref ;
if ( head_ref == del ) { head_ref = del -> next ; }
while ( temp -> next != del ) { temp = temp -> next ; }
temp -> next = del -> next ;
void DeleteFirst ( struct Node * * head ) { struct Node * previous = * head , * next = * head ;
if ( * head == NULL ) { printf ( " List is empty " return ; }
if ( previous -> next == previous ) { * head = NULL ; return ; }
while ( previous -> next != * head ) { previous = previous -> next ; next = previous -> next ; }
previous -> next = next -> next ;
* head = previous -> next ; free ( next ) ; return ; }
void DeleteAllOddNode ( struct Node * * head ) { int len = Length ( * head ) ; int count = 0 ; struct Node * previous = * head , * next = * head ;
if ( * head == NULL ) { printf ( " Delete Last List is empty " return ; }
if ( len == 1 ) { DeleteFirst ( head ) ; return ; }
while ( len > 0 ) {
if ( count == 0 ) {
DeleteFirst ( head ) ; }
if ( count % 2 == 0 && count != 0 ) { deleteNode ( * head , previous ) ; } previous = previous -> next ; next = previous -> next ; len -- ; count ++ ; } return ; }
void DeleteAllEvenNode ( struct Node * * head ) {
int len = Length ( * head ) ; int count = 1 ; struct Node * previous = * head , * next = * head ;
if ( * head == NULL ) { printf ( " List is empty " return ; }
if ( len < 2 ) { return ; }
previous = * head ;
next = previous -> next ; while ( len > 0 ) {
if ( count % 2 == 0 ) { previous -> next = next -> next ; free ( next ) ; previous = next -> next ; next = previous -> next ; } len -- ; count ++ ; } return ; }
int main ( ) { struct Node * head = NULL ; Insert ( & head , 99 ) ; Insert ( & head , 11 ) ; Insert ( & head , 22 ) ; Insert ( & head , 33 ) ; Insert ( & head , 44 ) ; Insert ( & head , 55 ) ; Insert ( & head , 66 ) ;
printf ( " Initial ▁ List : ▁ " ) ; Display ( head ) ; printf ( " After deleting Odd position nodes : " DeleteAllOddNode ( & head ) ; Display ( head ) ;
printf ( " Initial List : " Display ( head ) ; printf ( " After deleting even position nodes : " DeleteAllEvenNode ( & head ) ; Display ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void printMinMax ( struct Node * * head ) {
if ( * head == NULL ) { return ; }
struct Node * current ;
current = * head ;
int min = INT_MAX , max = INT_MIN ;
do {
if ( current -> data < min ) { min = current -> data ; }
if ( current -> data > max ) { max = current -> data ; } current = current -> next ; } while ( current != head ) ; cout << " Minimum = " ▁ < < ▁ min ▁ < < ▁ " , Maximum = " }
void insertNode ( struct Node * * head , int data ) { struct Node * current = * head ;
struct Node * newNode = new Node ;
if ( ! newNode ) { printf ( " Memory Error " return ; }
newNode -> data = data ;
if ( * head == NULL ) { newNode -> next = newNode ; * head = newNode ; return ; }
else {
while ( current -> next != * head ) { current = current -> next ; }
newNode -> next = * head ;
current -> next = newNode ; } }
void displayList ( struct Node * head ) { struct Node * current = head ;
if ( head == NULL ) { printf ( " Display List is empty " return ; }
else { do { printf ( " % d ▁ " , current -> data ) ; current = current -> next ; } while ( current != head ) ; } }
int main ( ) { struct Node * Head = NULL ; insertNode ( & Head , 99 ) ; insertNode ( & Head , 11 ) ; insertNode ( & Head , 22 ) ; insertNode ( & Head , 33 ) ; insertNode ( & Head , 44 ) ; insertNode ( & Head , 55 ) ; insertNode ( & Head , 66 ) ; cout << " Initial ▁ List : ▁ " ; displayList ( Head ) ; printMinMax ( & Head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int data ) { struct Node * ptr1 = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; struct Node * temp = * head_ref ; ptr1 -> data = data ; ptr1 -> next = * head_ref ;
if ( * head_ref != NULL ) { while ( temp -> next != * head_ref ) temp = temp -> next ; temp -> next = ptr1 ; } else
ptr1 -> next = ptr1 ; * head_ref = ptr1 ; }
void deleteNode ( Node * head_ref , Node * del ) { struct Node * temp = head_ref ;
if ( head_ref == del ) head_ref = del -> next ;
while ( temp -> next != del ) { temp = temp -> next ; }
temp -> next = del -> next ;
void deleteEvenNodes ( Node * head ) { struct Node * ptr = head ; struct Node * next ;
do {
if ( ptr -> data % 2 == 0 ) deleteNode ( head , ptr ) ;
next = ptr -> next ; ptr = next ; } while ( ptr != head ) ; }
void printList ( struct Node * head ) { struct Node * temp = head ; if ( head != NULL ) { do { printf ( " % d ▁ " , temp -> data ) ; temp = temp -> next ; } while ( temp != head ) ; } }
struct Node * head = NULL ;
push ( & head , 61 ) ; push ( & head , 12 ) ; push ( & head , 56 ) ; push ( & head , 2 ) ; push ( & head , 11 ) ; push ( & head , 57 ) ; cout << " List after deletion : " ; deleteEvenNodes ( head ) ; printList ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int data ) { struct Node * ptr1 = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; struct Node * temp = * head_ref ; ptr1 -> data = data ; ptr1 -> next = * head_ref ;
if ( * head_ref != NULL ) { while ( temp -> next != * head_ref ) temp = temp -> next ; temp -> next = ptr1 ; } else
ptr1 -> next = ptr1 ; * head_ref = ptr1 ; }
int sumOfList ( struct Node * head ) { struct Node * temp = head ; int sum = 0 ; if ( head != NULL ) { do { temp = temp -> next ; sum += temp -> data ; } while ( temp != head ) ; } return sum ; }
struct Node * head = NULL ;
push ( & head , 12 ) ; push ( & head , 56 ) ; push ( & head , 2 ) ; push ( & head , 11 ) ; cout << " Sum ▁ of ▁ Circular ▁ linked ▁ list ▁ is ▁ = ▁ " << sumOfList ( head ) ; return 0 ; }
struct Node { int data ; Node * next ; Node ( int x ) { data = x ; next = NULL ; } } ;
void printList ( Node * head ) { if ( head == NULL ) return ; Node * temp = head ; do { cout << temp -> data << " - > " ; temp = temp -> next ; } while ( temp != head ) ; cout << head -> data << endl ; }
void deleteK ( Node * * head_ref , int k ) { Node * head = * head_ref ;
if ( head == NULL ) return ;
Node * curr = head , * prev ; while ( true ) {
if ( curr -> next == head && curr == head ) break ;
printList ( head ) ;
for ( int i = 0 ; i < k ; i ++ ) { prev = curr ; curr = curr -> next ; }
if ( curr == head ) { prev = head ; while ( prev -> next != head ) prev = prev -> next ; head = curr -> next ; prev -> next = head ; * head_ref = head ; free ( curr ) ; }
else if ( curr -> next == head ) { prev -> next = head ; free ( curr ) ; } else { prev -> next = curr -> next ; free ( curr ) ; } } }
void insertNode ( Node * * head_ref , int x ) {
Node * head = * head_ref ; Node * temp = new Node ( x ) ;
if ( head == NULL ) { temp -> next = temp ; * head_ref = temp ; }
else { Node * temp1 = head ; while ( temp1 -> next != head ) temp1 = temp1 -> next ; temp1 -> next = temp ; temp -> next = head ; } }
struct Node * head = NULL ; insertNode ( & head , 1 ) ; insertNode ( & head , 2 ) ; insertNode ( & head , 3 ) ; insertNode ( & head , 4 ) ; insertNode ( & head , 5 ) ; insertNode ( & head , 6 ) ; insertNode ( & head , 7 ) ; insertNode ( & head , 8 ) ; insertNode ( & head , 9 ) ; int k = 4 ;
deleteK ( & head , k ) ; return 0 ; }
struct Node { int data ; struct Node * next ; struct Node * prev ; } ;
void insertNode ( struct Node * * start , int value ) {
if ( * start == NULL ) { struct Node * new_node = new Node ; new_node -> data = value ; new_node -> next = new_node -> prev = new_node ; * start = new_node ; return ; }
Node * last = ( * start ) -> prev ;
struct Node * new_node = new Node ; new_node -> data = value ;
new_node -> next = * start ;
( * start ) -> prev = new_node ;
new_node -> prev = last ;
last -> next = new_node ; }
void displayList ( struct Node * start ) { struct Node * temp = start ; while ( temp -> next != start ) { printf ( " % d ▁ " , temp -> data ) ; temp = temp -> next ; } printf ( " % d ▁ " , temp -> data ) ; }
int searchList ( struct Node * start , int search ) {
struct Node * temp = start ;
int count = 0 , flag = 0 , value ;
if ( temp == NULL ) return -1 ; else {
while ( temp -> next != start ) {
count ++ ;
if ( temp -> data == search ) { flag = 1 ; count -- ; break ; }
temp = temp -> next ; }
if ( temp -> data == search ) { count ++ ; flag = 1 ; }
if ( flag == 1 ) cout << " STRNEWLINE " << search << " ▁ found ▁ at ▁ location ▁ " << count << endl ; else cout << " STRNEWLINE " << search << " ▁ not ▁ found " << endl ; } }
struct Node * start = NULL ;
insertNode ( & start , 4 ) ;
insertNode ( & start , 5 ) ;
insertNode ( & start , 7 ) ;
insertNode ( & start , 8 ) ;
insertNode ( & start , 6 ) ; printf ( " Created ▁ circular ▁ doubly ▁ linked ▁ list ▁ is : ▁ " ) ; displayList ( start ) ; searchList ( start , 5 ) ; return 0 ; }
struct node { int data ; struct node * next ; struct node * prev ; } ;
struct node * getNode ( ) { return ( ( struct node * ) malloc ( sizeof ( struct node ) ) ) ; }
int displayList ( struct node * temp ) { struct node * t = temp ; if ( temp == NULL ) return 0 ; else { cout << " The ▁ list ▁ is : ▁ " ; while ( temp -> next != t ) { cout << temp -> data << " ▁ " ; temp = temp -> next ; } cout << temp -> data << endl ; return 1 ; } }
int countList ( struct node * start ) {
struct node * temp = start ;
int count = 0 ;
while ( temp -> next != start ) { temp = temp -> next ; count ++ ; }
count ++ ; return count ; }
bool insertAtLocation ( struct node * start , int data , int loc ) {
struct node * temp , * newNode ; int i , count ;
newNode = getNode ( ) ;
temp = start ;
count = countList ( start ) ;
if ( temp == NULL count < loc ) return false ; else {
newNode -> data = data ;
for ( i = 1 ; i < loc - 1 ; i ++ ) { temp = temp -> next ; }
newNode -> next = temp -> next ;
( temp -> next ) -> prev = newNode ;
temp -> next = newNode ;
newNode -> prev = temp ; return true ; } return false ; }
void createList ( int arr [ ] , int n , struct node * * start ) {
struct node * newNode , * temp ; int i ;
for ( i = 0 ; i < n ; i ++ ) {
newNode = getNode ( ) ;
newNode -> data = arr [ i ] ;
if ( i == 0 ) { * start = newNode ; newNode -> prev = * start ; newNode -> next = * start ; } else {
temp = ( * start ) -> prev ;
temp -> next = newNode ; newNode -> next = * start ; newNode -> prev = temp ; temp = * start ; temp -> prev = newNode ; } } }
int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
struct node * start = NULL ;
createList ( arr , n , & start ) ;
displayList ( start ) ;
insertAtLocation ( start , 8 , 3 ) ;
displayList ( start ) ; return 0 ; }
struct Node { int data ; Node * next , * prev ; } ;
Node * getNode ( int data ) { Node * newNode = ( Node * ) malloc ( sizeof ( Node ) ) ; newNode -> data = data ; return newNode ; }
void insertEnd ( Node * * head , Node * new_node ) {
if ( * head == NULL ) { new_node -> next = new_node -> prev = new_node ; * head = new_node ; return ; }
Node * last = ( * head ) -> prev ;
new_node -> next = * head ;
( * head ) -> prev = new_node ;
new_node -> prev = last ;
last -> next = new_node ; }
Node * reverse ( Node * head ) { if ( ! head ) return NULL ;
Node * new_head = NULL ;
Node * last = head -> prev ;
Node * curr = last , * prev ;
while ( curr -> prev != last ) { prev = curr -> prev ;
insertEnd ( & new_head , curr ) ; curr = prev ; } insertEnd ( & new_head , curr ) ;
return new_head ; }
void display ( Node * head ) { if ( ! head ) return ; Node * temp = head ; cout << " Forward ▁ direction : ▁ " ; while ( temp -> next != head ) { cout << temp -> data << " ▁ " ; temp = temp -> next ; } cout << temp -> data ; Node * last = head -> prev ; temp = last ; cout << " Backward direction : " while ( temp -> prev != last ) { cout << temp -> data << " ▁ " ; temp = temp -> prev ; } cout << temp -> data ; }
int main ( ) { Node * head = NULL ; insertEnd ( & head , getNode ( 1 ) ) ; insertEnd ( & head , getNode ( 2 ) ) ; insertEnd ( & head , getNode ( 3 ) ) ; insertEnd ( & head , getNode ( 4 ) ) ; insertEnd ( & head , getNode ( 5 ) ) ; cout << " Current ▁ list : STRNEWLINE " ; display ( head ) ; head = reverse ( head ) ; cout << " Reversed list : " display ( head ) ; return 0 ; }
struct node { int data ; struct node * next ; struct node * prev ; } ;
struct node * getNode ( ) { return ( ( struct node * ) malloc ( sizeof ( struct node ) ) ) ; }
int displayList ( struct node * temp ) { struct node * t = temp ; if ( temp == NULL ) return 0 ; else { cout << " The ▁ list ▁ is : ▁ " ; while ( temp -> next != t ) { cout << temp -> data << " ▁ " ; temp = temp -> next ; } cout << temp -> data ; return 1 ; } }
void createList ( int arr [ ] , int n , struct node * * start ) {
struct node * newNode , * temp ; int i ;
for ( i = 0 ; i < n ; i ++ ) {
newNode = getNode ( ) ;
newNode -> data = arr [ i ] ;
if ( i == 0 ) { * start = newNode ; newNode -> prev = * start ; newNode -> next = * start ; } else {
temp = ( * start ) -> prev ;
temp -> next = newNode ; newNode -> next = * start ; newNode -> prev = temp ; temp = * start ; temp -> prev = newNode ; } } }
int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
struct node * start = NULL ;
createList ( arr , n , & start ) ;
displayList ( start ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ; Node * newNode ( int data ) { Node * node = new Node ; node -> data = data ; node -> next = NULL ; return node ; }
int alivesol ( int Num ) { if ( Num == 1 ) return 1 ;
Node * last = newNode ( 1 ) ; last -> next = last ; for ( int i = 2 ; i <= Num ; i ++ ) { Node * temp = newNode ( i ) ; temp -> next = last -> next ; last -> next = temp ; last = temp ; }
Node * curr = last -> next ;
Node * temp ; while ( curr -> next != curr ) { temp = curr ; curr = curr -> next ; temp -> next = curr -> next ;
delete curr ; temp = temp -> next ; curr = temp ; }
int res = temp -> data ; delete temp ; return res ; }
int main ( ) { int N = 100 ; cout << alivesol ( N ) << endl ; return 0 ; }
struct Node { struct Node * left ; struct Node * right ; int data ; } ;
int finddepth ( Node * root ) {
if ( ! root ) return 0 ;
int left = finddepth ( root -> left ) ;
int right = finddepth ( root -> right ) ;
return 1 + max ( left , right ) ; }
Node * dfs ( Node * root , int curr , int depth ) {
if ( ! root ) return NULL ;
if ( curr == depth ) return root ;
Node * left = dfs ( root -> left , curr + 1 , depth ) ;
Node * right = dfs ( root -> right , curr + 1 , depth ) ;
if ( left != NULL && right != NULL ) return root ;
return left ? left : right ; }
Node * lcaOfDeepestLeaves ( Node * root ) {
if ( ! root ) return NULL ;
int depth = finddepth ( root ) - 1 ;
return dfs ( root , 0 , depth ) ; }
Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> right -> left -> left = newNode ( 8 ) ; root -> right -> left -> right = newNode ( 9 ) ; cout << lcaOfDeepestLeaves ( root ) -> data ; return 0 ; }
int filter ( int x , int y , int z ) { if ( x != -1 && y != -1 ) { return z ; } return x == -1 ? y : x ; }
int samePathUtil ( int mtrx [ ] [ 7 ] , int vrtx , int v1 , int v2 , int i ) { int ans = -1 ;
if ( i == v1 i == v2 ) return i ; for ( int j = 0 ; j < vrtx ; j ++ ) {
if ( mtrx [ i ] [ j ] == 1 ) {
ans = filter ( ans , samePathUtil ( mtrx , vrtx , v1 , v2 , j ) , i ) ; } }
return ans ; }
bool isVertexAtSamePath ( int mtrx [ ] [ 7 ] , int vrtx , int v1 , int v2 , int i ) { int lca = samePathUtil ( mtrx , vrtx , v1 - 1 , v2 - 1 , i ) ; if ( lca == v1 - 1 lca == v2 - 1 ) return true ; return false ; }
int main ( ) { int vrtx = 7 , edge = 6 ; int mtrx [ 7 ] [ 7 ] = { { 0 , 1 , 1 , 1 , 0 , 0 , 0 } , { 0 , 0 , 0 , 0 , 1 , 0 , 0 } , { 0 , 0 , 0 , 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 } } ; int v1 = 1 , v2 = 5 ; if ( isVertexAtSamePath ( mtrx , vrtx , v1 , v2 , 0 ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  1000
#define log  10 
int level [ MAX ] ; int lca [ MAX ] [ log ] ; int dist [ MAX ] [ log ] ;
vector < pair < int , int > > graph [ MAX ] ; void addEdge ( int u , int v , int cost ) { graph [ u ] . push_back ( { v , cost } ) ; graph [ v ] . push_back ( { u , cost } ) ; }
void dfs ( int node , int parent , int h , int cost ) {
lca [ node ] [ 0 ] = parent ;
level [ node ] = h ; if ( parent != -1 ) { dist [ node ] [ 0 ] = cost ; } for ( int i = 1 ; i < log ; i ++ ) { if ( lca [ node ] [ i - 1 ] != -1 ) {
lca [ node ] [ i ] = lca [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ; dist [ node ] [ i ] = dist [ node ] [ i - 1 ] + dist [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ; } } for ( auto i : graph [ node ] ) { if ( i . first == parent ) continue ; dfs ( i . first , node , h + 1 , i . second ) ; } }
void findDistance ( int u , int v ) { int ans = 0 ;
if ( level [ u ] > level [ v ] ) swap ( u , v ) ;
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v ] [ i ] != -1 && level [ lca [ v ] [ i ] ] >= level [ u ] ) {
ans += dist [ v ] [ i ] ; v = lca [ v ] [ i ] ; } }
if ( v == u ) { cout << ans << endl ; } else {
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v ] [ i ] != lca [ u ] [ i ] ) {
ans += dist [ u ] [ i ] + dist [ v ] [ i ] ; v = lca [ v ] [ i ] ; u = lca [ u ] [ i ] ; } }
ans += dist [ u ] [ 0 ] + dist [ v ] [ 0 ] ; cout << ans << endl ; } }
int n = 5 ;
addEdge ( 1 , 2 , 2 ) ; addEdge ( 1 , 3 , 3 ) ; addEdge ( 2 , 4 , 5 ) ; addEdge ( 2 , 5 , 7 ) ;
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = 0 ; j < log ; j ++ ) { lca [ i ] [ j ] = -1 ; dist [ i ] [ j ] = 0 ; } }
dfs ( 1 , -1 , 0 , 0 ) ;
findDistance ( 1 , 3 ) ;
findDistance ( 2 , 3 ) ;
findDistance ( 3 , 5 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  1000 NEW_LINE int weight [ MAX ] ; int level [ MAX ] ; int par [ MAX ] ; bool prime [ MAX + 1 ] ; vector < int > graph [ MAX ] ;
void SieveOfEratosthenes ( ) {
memset ( prime , true , sizeof ( prime ) ) ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * p ; i <= MAX ; i += p ) prime [ i ] = false ; } } }
void dfs ( int node , int parent , int h ) {
par [ node ] = parent ;
level [ node ] = h ; for ( int child : graph [ node ] ) { if ( child == parent ) continue ; dfs ( child , node , h + 1 ) ; } }
int findPrimeOnPath ( int u , int v ) { int count = 0 ;
if ( level [ u ] > level [ v ] ) swap ( u , v ) ; int d = level [ v ] - level [ u ] ;
while ( d -- ) {
if ( prime [ weight [ v ] ] ) count ++ ; v = par [ v ] ; }
if ( v == u ) { if ( prime [ weight [ v ] ] ) count ++ ; return count ; }
while ( v != u ) { if ( prime [ weight [ v ] ] ) count ++ ; if ( prime [ weight [ u ] ] ) count ++ ; u = par [ u ] ; v = par [ v ] ; }
if ( prime [ weight [ v ] ] ) count ++ ; return count ; }
SieveOfEratosthenes ( ) ;
weight [ 1 ] = 5 ; weight [ 2 ] = 10 ; weight [ 3 ] = 11 ; weight [ 4 ] = 8 ; weight [ 5 ] = 6 ;
graph [ 1 ] . push_back ( 2 ) ; graph [ 2 ] . push_back ( 3 ) ; graph [ 2 ] . push_back ( 4 ) ; graph [ 1 ] . push_back ( 5 ) ; dfs ( 1 , -1 , 0 ) ; int u = 3 , v = 5 ; cout << findPrimeOnPath ( u , v ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  1000
#define log  10 
int level [ MAX ] ; int lca [ MAX ] [ log ] ; int minWeight [ MAX ] [ log ] ; int maxWeight [ MAX ] [ log ] ;
vector < int > graph [ MAX ] ;
int weight [ MAX ] ; void addEdge ( int u , int v ) { graph [ u ] . push_back ( v ) ; graph [ v ] . push_back ( u ) ; }
void dfs ( int node , int parent , int h ) {
lca [ node ] [ 0 ] = parent ;
level [ node ] = h ; if ( parent != -1 ) { minWeight [ node ] [ 0 ] = min ( weight [ node ] , weight [ parent ] ) ; maxWeight [ node ] [ 0 ] = max ( weight [ node ] , weight [ parent ] ) ; } for ( int i = 1 ; i < log ; i ++ ) { if ( lca [ node ] [ i - 1 ] != -1 ) {
lca [ node ] [ i ] = lca [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ; minWeight [ node ] [ i ] = min ( minWeight [ node ] [ i - 1 ] , minWeight [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ) ; maxWeight [ node ] [ i ] = max ( maxWeight [ node ] [ i - 1 ] , maxWeight [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ) ; } } for ( int i : graph [ node ] ) { if ( i == parent ) continue ; dfs ( i , node , h + 1 ) ; } }
void findMinMaxWeight ( int u , int v ) { int minWei = INT_MAX ; int maxWei = INT_MIN ;
if ( level [ u ] > level [ v ] ) swap ( u , v ) ;
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v ] [ i ] != -1 && level [ lca [ v ] [ i ] ] >= level [ u ] ) {
minWei = min ( minWei , minWeight [ v ] [ i ] ) ; maxWei = max ( maxWei , maxWeight [ v ] [ i ] ) ; v = lca [ v ] [ i ] ; } }
if ( v == u ) { cout << minWei << " ▁ " << maxWei << endl ; } else {
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v ] [ i ] != lca [ u ] [ i ] ) {
minWei = min ( minWei , min ( minWeight [ v ] [ i ] , minWeight [ u ] [ i ] ) ) ;
maxWei = max ( maxWei , max ( maxWeight [ v ] [ i ] , maxWeight [ u ] [ i ] ) ) ; v = lca [ v ] [ i ] ; u = lca [ u ] [ i ] ; } }
minWei = min ( minWei , min ( minWeight [ v ] [ 0 ] , minWeight [ u ] [ 0 ] ) ) ;
maxWei = max ( maxWei , max ( maxWeight [ v ] [ 0 ] , maxWeight [ u ] [ 0 ] ) ) ; cout << minWei << " ▁ " << maxWei << endl ; } }
int n = 5 ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 5 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 3 ) ; weight [ 1 ] = -1 ; weight [ 2 ] = 5 ; weight [ 3 ] = -1 ; weight [ 4 ] = 3 ; weight [ 5 ] = -2 ;
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = 0 ; j < log ; j ++ ) { lca [ i ] [ j ] = -1 ; minWeight [ i ] [ j ] = INT_MAX ; maxWeight [ i ] [ j ] = INT_MIN ; } }
dfs ( 1 , -1 , 0 ) ;
findMinMaxWeight ( 1 , 3 ) ;
findMinMaxWeight ( 2 , 4 ) ;
findMinMaxWeight ( 3 , 5 ) ; return 0 ; }
int T = 1 ; void dfs ( int node , int parent , vector < int > g [ ] , int level [ ] , int t_in [ ] , int t_out [ ] ) {
if ( parent == -1 ) { level [ node ] = 1 ; } else { level [ node ] = level [ parent ] + 1 ; }
t_in [ node ] = T ; for ( auto i : g [ node ] ) { if ( i != parent ) { T ++ ; dfs ( i , node , g , level , t_in , t_out ) ; } } T ++ ;
t_out [ node ] = T ; } int findLCA ( int n , vector < int > g [ ] , vector < int > v ) {
int level [ n + 1 ] ;
int t_in [ n + 1 ] ;
int t_out [ n + 1 ] ;
dfs ( 1 , -1 , g , level , t_in , t_out ) ; int mint = INT_MAX , maxt = INT_MIN ; int minv = -1 , maxv = -1 ; for ( auto i = v . begin ( ) ; i != v . end ( ) ; i ++ ) {
if ( t_in [ * i ] < mint ) { mint = t_in [ * i ] ; minv = * i ; }
if ( t_out [ * i ] > maxt ) { maxt = t_out [ * i ] ; maxv = * i ; } }
if ( minv == maxv ) { return minv ; }
int lev = min ( level [ minv ] , level [ maxv ] ) ; int node , l = INT_MIN ; for ( int i = 1 ; i <= n ; i ++ ) {
if ( level [ i ] > lev ) continue ;
if ( t_in [ i ] <= mint && t_out [ i ] >= maxt && level [ i ] > l ) { node = i ; l = level [ i ] ; } } return node ; }
int main ( ) { int n = 10 ; vector < int > g [ n + 1 ] ; g [ 1 ] . push_back ( 2 ) ; g [ 2 ] . push_back ( 1 ) ; g [ 1 ] . push_back ( 3 ) ; g [ 3 ] . push_back ( 1 ) ; g [ 1 ] . push_back ( 4 ) ; g [ 4 ] . push_back ( 1 ) ; g [ 2 ] . push_back ( 5 ) ; g [ 5 ] . push_back ( 2 ) ; g [ 2 ] . push_back ( 6 ) ; g [ 6 ] . push_back ( 2 ) ; g [ 3 ] . push_back ( 7 ) ; g [ 7 ] . push_back ( 3 ) ; g [ 4 ] . push_back ( 10 ) ; g [ 10 ] . push_back ( 4 ) ; g [ 8 ] . push_back ( 7 ) ; g [ 7 ] . push_back ( 8 ) ; g [ 9 ] . push_back ( 7 ) ; g [ 7 ] . push_back ( 9 ) ; vector < int > v = { 7 , 3 , 8 } ; cout << findLCA ( n , g , v ) << endl ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX_SIZE = 100005 , MAX_CHAR = 26 ; int nodeCharactersCount [ MAX_SIZE ] [ MAX_CHAR ] ; vector < int > tree [ MAX_SIZE ] ;
bool canFormPalindrome ( int * charArray ) {
int oddCount = 0 ; for ( int i = 0 ; i < MAX_CHAR ; i ++ ) { if ( charArray [ i ] % 2 == 1 ) oddCount ++ ; }
if ( oddCount >= 2 ) return false ; else return true ; }
int LCA ( int currentNode , int x , int y ) {
if ( currentNode == x ) return x ;
if ( currentNode == y ) return y ; int xLca , yLca ;
xLca = yLca = -1 ;
int gotLca = -1 ;
for ( int l = 0 ; l < tree [ currentNode ] . size ( ) ; l ++ ) {
int nextNode = tree [ currentNode ] [ l ] ;
int out_ = LCA ( nextNode , x , y ) ; if ( out_ == x ) xLca = out_ ; if ( out_ == y ) yLca = out_ ;
if ( xLca != -1 and yLca != -1 ) return currentNode ;
if ( out_ != -1 ) gotLca = out_ ; } return gotLca ; }
void buildTree ( int i ) { for ( int l = 0 ; l < tree [ i ] . size ( ) ; l ++ ) { int nextNode = tree [ i ] [ l ] ; for ( int j = 0 ; j < MAX_CHAR ; j ++ ) {
nodeCharactersCount [ nextNode ] [ j ] += nodeCharactersCount [ i ] [ j ] ; }
buildTree ( nextNode ) ; } }
bool canFormPalindromicPath ( int x , int y ) { int lcaNode ;
if ( x == y ) lcaNode = x ;
else lcaNode = LCA ( 1 , x , y ) ; int charactersCountFromXtoY [ MAX_CHAR ] = { 0 } ;
for ( int i = 0 ; i < MAX_CHAR ; i ++ ) { charactersCountFromXtoY [ i ] = nodeCharactersCount [ x ] [ i ] + nodeCharactersCount [ y ] [ i ] - 2 * nodeCharactersCount [ lcaNode ] [ i ] ; }
if ( canFormPalindrome ( charactersCountFromXtoY ) ) return true ; return false ; }
void updateNodeCharactersCount ( string str , int v ) {
for ( int i = 0 ; i < str . length ( ) ; i ++ ) nodeCharactersCount [ v ] [ str [ i ] - ' a ' ] ++ ; }
void performQueries ( vector < vector < int > > queries , int q ) { int i = 0 ; while ( i < q ) { int x = queries [ i ] [ 0 ] ; int y = queries [ i ] [ 1 ] ;
if ( canFormPalindromicPath ( x , y ) ) cout << " Yes STRNEWLINE " ; else cout << " No STRNEWLINE " ; i ++ ; } }
memset ( nodeCharactersCount , 0 , sizeof ( nodeCharactersCount ) ) ;
tree [ 1 ] . push_back ( 2 ) ; updateNodeCharactersCount ( " bbc " , 2 ) ;
tree [ 1 ] . push_back ( 3 ) ; updateNodeCharactersCount ( " ac " , 3 ) ;
buildTree ( 1 ) ; vector < vector < int > > queries { { 1 , 2 } , { 2 , 3 } , { 3 , 1 } , { 3 , 3 } } ; int q = queries . size ( ) ;
performQueries ( queries , q ) ; return 0 ; }
struct Node { Node * left ; Node * right ; int data ; } ;
Node * newNode ( int key ) { Node * node = new Node ( ) ; node -> left = node -> right = NULL ; node -> data = key ; return node ; }
bool FindPath ( Node * root , vector < int > & path , int key ) { if ( root == NULL ) return false ; path . push_back ( root -> data ) ; if ( root -> data == key ) return true ; if ( FindPath ( root -> left , path , key ) || FindPath ( root -> right , path , key ) ) return true ; path . pop_back ( ) ; return false ; }
int minMaxNodeInPath ( Node * root , int a , int b ) {
vector < int > Path1 ;
vector < int > Path2 ;
int min1 = INT_MAX ; int max1 = INT_MIN ;
int min2 = INT_MAX ; int max2 = INT_MIN ; int i = 0 ; int j = 0 ;
if ( FindPath ( root , Path1 , a ) && FindPath ( root , Path2 , b ) ) {
for ( i = 0 ; i < Path1 . size ( ) && Path2 . size ( ) ; i ++ ) if ( Path1 [ i ] != Path2 [ i ] ) break ; i -- ; j = i ;
for ( ; i < Path1 . size ( ) ; i ++ ) { if ( min1 > Path1 [ i ] ) min1 = Path1 [ i ] ; if ( max1 < Path1 [ i ] ) max1 = Path1 [ i ] ; }
for ( ; j < Path2 . size ( ) ; j ++ ) { if ( min2 > Path2 [ j ] ) min2 = Path2 [ j ] ; if ( max2 < Path2 [ j ] ) max2 = Path2 [ j ] ; }
cout << " Min ▁ = ▁ " << min ( min1 , min2 ) << endl ;
cout << " Max ▁ = ▁ " << max ( max1 , max2 ) ; }
else cout < < " Max = -1 " }
int main ( ) { Node * root = newNode ( 20 ) ; root -> left = newNode ( 8 ) ; root -> right = newNode ( 22 ) ; root -> left -> left = newNode ( 5 ) ; root -> left -> right = newNode ( 3 ) ; root -> right -> left = newNode ( 4 ) ; root -> right -> right = newNode ( 25 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 14 ) ; int a = 5 ; int b = 1454 ; minMaxNodeInPath ( root , a , b ) ; return 0 ; }
struct Node { int data ; struct Node * left ; struct Node * right ; } ;
struct Node * newNode ( int data ) { struct Node * node = new Node ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return node ; }
bool getPath ( Node * root , vector < int > & arr , int x ) {
if ( ! root ) return false ;
arr . push_back ( root -> data ) ;
if ( root -> data == x ) return true ;
if ( getPath ( root -> left , arr , x ) || getPath ( root -> right , arr , x ) ) return true ;
arr . pop_back ( ) ; return false ; }
int sumOddNodes ( Node * root , int n1 , int n2 ) {
vector < int > path1 ;
vector < int > path2 ; getPath ( root , path1 , n1 ) ; getPath ( root , path2 , n2 ) ; int intersection = -1 ;
int i = 0 , j = 0 ; while ( i != path1 . size ( ) || j != path2 . size ( ) ) {
if ( i == j && path1 [ i ] == path2 [ j ] ) { i ++ ; j ++ ; } else { intersection = j - 1 ; break ; } } int sum = 0 ;
for ( int i = path1 . size ( ) - 1 ; i > intersection ; i -- ) if ( path1 [ i ] % 2 ) sum += path1 [ i ] ; for ( int i = intersection ; i < path2 . size ( ) ; i ++ ) if ( path2 [ i ] % 2 ) sum += path2 [ i ] ; return sum ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; int node1 = 5 ; int node2 = 6 ; cout << sumOddNodes ( root , node1 , node2 ) ; return 0 ; }
const int MAX = 1000 ;
int findLCA ( int n1 , int n2 , int parent [ ] ) {
vector < bool > visited ( MAX , false ) ; visited [ n1 ] = true ;
while ( parent [ n1 ] != -1 ) { visited [ n1 ] = true ;
n1 = parent [ n1 ] ; } visited [ n1 ] = true ;
while ( ! visited [ n2 ] ) n2 = parent [ n2 ] ; return n2 ; }
void insertAdj ( int parent [ ] , int i , int j ) { parent [ i ] = j ; }
int parent [ MAX ] ;
parent [ 20 ] = -1 ; insertAdj ( parent , 8 , 20 ) ; insertAdj ( parent , 22 , 20 ) ; insertAdj ( parent , 4 , 8 ) ; insertAdj ( parent , 12 , 8 ) ; insertAdj ( parent , 10 , 12 ) ; insertAdj ( parent , 14 , 12 ) ; cout << findLCA ( 10 , 14 , parent ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { struct Node * left , * right ; int key ; } ; struct Node * newNode ( int key ) { struct Node * ptr = new Node ; ptr -> key = key ; ptr -> left = ptr -> right = NULL ; return ptr ; }
struct Node * insert ( struct Node * root , int key ) { if ( ! root ) root = newNode ( key ) ; else if ( root -> key > key ) root -> left = insert ( root -> left , key ) ; else if ( root -> key < key ) root -> right = insert ( root -> right , key ) ; return root ; }
int distanceFromRoot ( struct Node * root , int x ) { if ( root -> key == x ) return 0 ; else if ( root -> key > x ) return 1 + distanceFromRoot ( root -> left , x ) ; return 1 + distanceFromRoot ( root -> right , x ) ; }
int distanceBetween2 ( struct Node * root , int a , int b ) { if ( ! root ) return 0 ;
if ( root -> key > a && root -> key > b ) return distanceBetween2 ( root -> left , a , b ) ;
if ( root -> key < a && root -> key < b ) return distanceBetween2 ( root -> right , a , b ) ;
if ( root -> key >= a && root -> key <= b ) return distanceFromRoot ( root , a ) + distanceFromRoot ( root , b ) ; }
int findDistWrapper ( Node * root , int a , int b ) { if ( a > b ) swap ( a , b ) ; return distanceBetween2 ( root , a , b ) ; }
int main ( ) { struct Node * root = NULL ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; int a = 5 , b = 55 ; cout << findDistWrapper ( root , 5 , 35 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAXN  1001
int depth [ MAXN ] ;
int parent [ MAXN ] ; vector < int > adj [ MAXN ] ; void addEdge ( int u , int v ) { adj [ u ] . push_back ( v ) ; adj [ v ] . push_back ( u ) ; } void dfs ( int cur , int prev ) {
parent [ cur ] = prev ;
depth [ cur ] = depth [ prev ] + 1 ;
for ( int i = 0 ; i < adj [ cur ] . size ( ) ; i ++ ) if ( adj [ cur ] [ i ] != prev ) dfs ( adj [ cur ] [ i ] , cur ) ; } void preprocess ( ) {
depth [ 0 ] = -1 ;
dfs ( 1 , 0 ) ; }
int LCANaive ( int u , int v ) { if ( u == v ) return u ; if ( depth [ u ] > depth [ v ] ) swap ( u , v ) ; v = parent [ v ] ; return LCANaive ( u , v ) ; }
int main ( int argc , char const * argv [ ] ) {
addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 1 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 4 , 8 ) ; addEdge ( 4 , 9 ) ; addEdge ( 9 , 10 ) ; addEdge ( 9 , 11 ) ; addEdge ( 7 , 12 ) ; addEdge ( 7 , 13 ) ; preprocess ( ) ; cout << " LCA ( 11,8 ) ▁ : ▁ " << LCANaive ( 11 , 8 ) << endl ; cout << " LCA ( 3,13 ) ▁ : ▁ " << LCANaive ( 3 , 13 ) << endl ; return 0 ; }
#include " iostream " NEW_LINE #include " vector " NEW_LINE #include " math . h " NEW_LINE using namespace std ; #define MAXN  1001
int block_sz ;
int depth [ MAXN ] ;
int parent [ MAXN ] ;
int jump_parent [ MAXN ] ; vector < int > adj [ MAXN ] ; void addEdge ( int u , int v ) { adj [ u ] . push_back ( v ) ; adj [ v ] . push_back ( u ) ; } int LCANaive ( int u , int v ) { if ( u == v ) return u ; if ( depth [ u ] > depth [ v ] ) swap ( u , v ) ; v = parent [ v ] ; return LCANaive ( u , v ) ; }
void dfs ( int cur , int prev ) {
depth [ cur ] = depth [ prev ] + 1 ;
parent [ cur ] = prev ;
if ( depth [ cur ] % block_sz == 0 )
jump_parent [ cur ] = parent [ cur ] ; else
jump_parent [ cur ] = jump_parent [ prev ] ;
for ( int i = 0 ; i < adj [ cur ] . size ( ) ; ++ i ) if ( adj [ cur ] [ i ] != prev ) dfs ( adj [ cur ] [ i ] , cur ) ; }
int LCASQRT ( int u , int v ) { while ( jump_parent [ u ] != jump_parent [ v ] ) { if ( depth [ u ] > depth [ v ] )
swap ( u , v ) ;
v = jump_parent [ v ] ; }
return LCANaive ( u , v ) ; } void preprocess ( int height ) { block_sz = sqrt ( height ) ; depth [ 0 ] = -1 ;
dfs ( 1 , 0 ) ; }
int main ( int argc , char const * argv [ ] ) {
addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 1 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 4 , 8 ) ; addEdge ( 4 , 9 ) ; addEdge ( 9 , 10 ) ; addEdge ( 9 , 11 ) ; addEdge ( 7 , 12 ) ; addEdge ( 7 , 13 ) ;
int height = 4 ; preprocess ( height ) ; cout << " LCA ( 11,8 ) ▁ : ▁ " << LCASQRT ( 11 , 8 ) << endl ; cout << " LCA ( 3,13 ) ▁ : ▁ " << LCASQRT ( 3 , 13 ) << endl ; return 0 ; }
#define MAXN  100001 NEW_LINE vector < int > tree [ MAXN ] ;
void dfs ( int cur , int prev , int pathNumber , int ptr , int node , bool & flag ) { for ( int i = 0 ; i < tree [ cur ] . size ( ) ; i ++ ) { if ( tree [ cur ] [ i ] != prev and ! flag ) {
path [ pathNumber ] [ ptr ] = tree [ cur ] [ i ] ; if ( tree [ cur ] [ i ] == node ) {
flag = true ;
path [ pathNumber ] [ ptr + 1 ] = -1 ; return ; } dfs ( tree [ cur ] [ i ] , cur , pathNumber , ptr + 1 , node , flag ) ; } } }
int LCA ( int a , int b ) {
if ( a == b ) return a ;
path [ 1 ] [ 0 ] = path [ 2 ] [ 0 ] = 1 ;
bool flag = false ; dfs ( 1 , 0 , 1 , 1 , a , flag ) ;
flag = false ; dfs ( 1 , 0 , 2 , 1 , b , flag ) ;
int i = 0 ; while ( path [ 1 ] [ i ] == path [ 2 ] [ i ] ) i ++ ;
return path [ 1 ] [ i - 1 ] ; } void addEdge ( int a , int b ) { tree [ a ] . push_back ( b ) ; tree [ b ] . push_back ( a ) ; }
int main ( ) {
int n = 8 ; addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 3 , 8 ) ; cout << " LCA ( 4 , ▁ 7 ) ▁ = ▁ " << LCA ( 4 , 7 ) << endl ; cout << " LCA ( 4 , ▁ 6 ) ▁ = ▁ " << LCA ( 4 , 6 ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAXN  100000 NEW_LINE #define level  18 NEW_LINE vector < int > tree [ MAXN ] ; int depth [ MAXN ] ; int parent [ MAXN ] [ level ] ;
void dfs ( int cur , int prev ) { depth [ cur ] = depth [ prev ] + 1 ; parent [ cur ] [ 0 ] = prev ; for ( int i = 0 ; i < tree [ cur ] . size ( ) ; i ++ ) { if ( tree [ cur ] [ i ] != prev ) dfs ( tree [ cur ] [ i ] , cur ) ; } }
void precomputeSparseMatrix ( int n ) { for ( int i = 1 ; i < level ; i ++ ) { for ( int node = 1 ; node <= n ; node ++ ) { if ( parent [ node ] [ i - 1 ] != -1 ) parent [ node ] [ i ] = parent [ parent [ node ] [ i - 1 ] ] [ i - 1 ] ; } } }
int lca ( int u , int v ) { if ( depth [ v ] < depth [ u ] ) swap ( u , v ) ; int diff = depth [ v ] - depth [ u ] ;
for ( int i = 0 ; i < level ; i ++ ) if ( ( diff >> i ) & 1 ) v = parent [ v ] [ i ] ;
if ( u == v ) return u ;
for ( int i = level - 1 ; i >= 0 ; i -- ) if ( parent [ u ] [ i ] != parent [ v ] [ i ] ) { u = parent [ u ] [ i ] ; v = parent [ v ] [ i ] ; } return parent [ u ] [ 0 ] ; } void addEdge ( int u , int v ) { tree [ u ] . push_back ( v ) ; tree [ v ] . push_back ( u ) ; }
int main ( ) { memset ( parent , -1 , sizeof ( parent ) ) ; int n = 8 ; addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 3 , 8 ) ; depth [ 0 ] = 0 ;
dfs ( 1 , 0 ) ;
precomputeSparseMatrix ( n ) ;
cout << " LCA ( 4 , ▁ 7 ) ▁ = ▁ " << lca ( 4 , 7 ) << endl ; cout << " LCA ( 4 , ▁ 6 ) ▁ = ▁ " << lca ( 4 , 6 ) << endl ; return 0 ; }
struct Query { int L , R ; } ;
int LCE ( string str , int n , int L , int R ) { int length = 0 ; while ( str [ L + length ] == str [ R + length ] && R + length < n ) length ++ ; return ( length ) ; }
void LCEQueries ( string str , int n , Query q [ ] , int m ) { for ( int i = 0 ; i < m ; i ++ ) { int L = q [ i ] . L ; int R = q [ i ] . R ; printf ( " LCE ▁ ( % d , ▁ % d ) ▁ = ▁ % d STRNEWLINE " , L , R , LCE ( str , n , L , R ) ) ; } return ; }
int main ( ) { string str = " abbababba " ; int n = str . length ( ) ;
Query q [ ] = { { 1 , 2 } , { 1 , 6 } , { 0 , 5 } } ; int m = sizeof ( q ) / sizeof ( q [ 0 ] ) ; LCEQueries ( str , n , q , m ) ; return ( 0 ) ; }
#define V  5
#define WHITE  1
#define BLACK  2 
struct Node { int data ; Node * left , * right ; } ;
struct subset { int parent , rank , ancestor , child , sibling , color ; } ;
struct Query { int L , R ; } ;
Node * newNode ( int data ) { Node * node = new Node ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
void makeSet ( struct subset subsets [ ] , int i ) { if ( i < 1 i > V ) return ; subsets [ i ] . color = WHITE ; subsets [ i ] . parent = i ; subsets [ i ] . rank = 0 ; return ; }
int findSet ( struct subset subsets [ ] , int i ) {
if ( subsets [ i ] . parent != i ) subsets [ i ] . parent = findSet ( subsets , subsets [ i ] . parent ) ; return subsets [ i ] . parent ; }
void unionSet ( struct subset subsets [ ] , int x , int y ) { int xroot = findSet ( subsets , x ) ; int yroot = findSet ( subsets , y ) ;
if ( subsets [ xroot ] . rank < subsets [ yroot ] . rank ) subsets [ xroot ] . parent = yroot ; else if ( subsets [ xroot ] . rank > subsets [ yroot ] . rank ) subsets [ yroot ] . parent = xroot ;
else { subsets [ yroot ] . parent = xroot ; ( subsets [ xroot ] . rank ) ++ ; } }
void lcaWalk ( int u , struct Query q [ ] , int m , struct subset subsets [ ] ) {
makeSet ( subsets , u ) ;
subsets [ findSet ( subsets , u ) ] . ancestor = u ; int child = subsets [ u ] . child ;
while ( child != 0 ) { lcaWalk ( child , q , m , subsets ) ; unionSet ( subsets , u , child ) ; subsets [ findSet ( subsets , u ) ] . ancestor = u ; child = subsets [ child ] . sibling ; } subsets [ u ] . color = BLACK ; for ( int i = 0 ; i < m ; i ++ ) { if ( q [ i ] . L == u ) { if ( subsets [ q [ i ] . R ] . color == BLACK ) { printf ( " LCA ( % d ▁ % d ) ▁ - > ▁ % d STRNEWLINE " , q [ i ] . L , q [ i ] . R , subsets [ findSet ( subsets , q [ i ] . R ) ] . ancestor ) ; } } else if ( q [ i ] . R == u ) { if ( subsets [ q [ i ] . L ] . color == BLACK ) { printf ( " LCA ( % d ▁ % d ) ▁ - > ▁ % d STRNEWLINE " , q [ i ] . L , q [ i ] . R , subsets [ findSet ( subsets , q [ i ] . L ) ] . ancestor ) ; } } } return ; }
void preprocess ( Node * node , struct subset subsets [ ] ) { if ( node == NULL ) return ;
preprocess ( node -> left , subsets ) ; if ( node -> left != NULL && node -> right != NULL ) {
subsets [ node -> data ] . child = node -> left -> data ; subsets [ node -> left -> data ] . sibling = node -> right -> data ; } else if ( ( node -> left != NULL && node -> right == NULL ) || ( node -> left == NULL && node -> right != NULL ) ) { if ( node -> left != NULL && node -> right == NULL ) subsets [ node -> data ] . child = node -> left -> data ; else subsets [ node -> data ] . child = node -> right -> data ; }
preprocess ( node -> right , subsets ) ; }
void initialise ( struct subset subsets [ ] ) {
memset ( subsets , 0 , ( V + 1 ) * sizeof ( struct subset ) ) ; for ( int i = 1 ; i <= V ; i ++ ) subsets [ i ] . color = WHITE ; return ; }
void printLCAs ( Node * root , Query q [ ] , int m ) {
struct subset * subsets = new subset [ V + 1 ] ;
initialise ( subsets ) ;
preprocess ( root , subsets ) ;
lcaWalk ( root -> data , q , m , subsets ) ; }
Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ;
Query q [ ] = { { 5 , 4 } , { 1 , 3 } , { 2 , 3 } } ; int m = sizeof ( q ) / sizeof ( q [ 0 ] ) ; printLCAs ( root , q , m ) ; return 0 ; }
struct Node { int data ; struct Node * left , * right ; } ;
bool countSingleRec ( Node * root , int & count ) {
if ( root == NULL ) return true ;
bool left = countSingleRec ( root -> left , count ) ; bool right = countSingleRec ( root -> right , count ) ;
if ( left == false right == false ) return false ;
if ( root -> left && root -> data != root -> left -> data ) return false ;
if ( root -> right && root -> data != root -> right -> data ) return false ;
count ++ ; return true ; }
int countSingle ( Node * root ) {
countSingleRec ( root , count ) ; return count ; }
Node * root = newNode ( 5 ) ; root -> left = newNode ( 4 ) ; root -> right = newNode ( 5 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 4 ) ; root -> right -> right = newNode ( 5 ) ; cout << " Count ▁ of ▁ Single ▁ Valued ▁ Subtrees ▁ is ▁ " << countSingle ( root ) ; return 0 ; }
struct Node { int key ; struct Node * left , * right ; } ;
void findLeafDown ( Node * root , int lev , int * minDist ) {
if ( root == NULL ) return ;
if ( root -> left == NULL && root -> right == NULL ) { if ( lev < ( * minDist ) ) * minDist = lev ; return ; }
findLeafDown ( root -> left , lev + 1 , minDist ) ; findLeafDown ( root -> right , lev + 1 , minDist ) ; }
int findThroughParent ( Node * root , Node * x , int * minDist ) {
if ( root == NULL ) return -1 ; if ( root == x ) return 0 ;
int l = findThroughParent ( root -> left , x , minDist ) ;
if ( l != -1 ) {
findLeafDown ( root -> right , l + 2 , minDist ) ; return l + 1 ; }
int r = findThroughParent ( root -> right , x , minDist ) ;
if ( r != -1 ) {
findLeafDown ( root -> left , r + 2 , minDist ) ; return r + 1 ; } return -1 ; }
int minimumDistance ( Node * root , Node * x ) {
int minDist = INT_MAX ;
findLeafDown ( x , 0 , & minDist ) ;
findThroughParent ( root , x , & minDist ) ; return minDist ; }
Node * root = newNode ( 1 ) ; root -> left = newNode ( 12 ) ; root -> right = newNode ( 13 ) ; root -> right -> left = newNode ( 14 ) ; root -> right -> right = newNode ( 15 ) ; root -> right -> left -> left = newNode ( 21 ) ; root -> right -> left -> right = newNode ( 22 ) ; root -> right -> right -> left = newNode ( 23 ) ; root -> right -> right -> right = newNode ( 24 ) ; root -> right -> left -> left -> left = newNode ( 1 ) ; root -> right -> left -> left -> right = newNode ( 2 ) ; root -> right -> left -> right -> left = newNode ( 3 ) ; root -> right -> left -> right -> right = newNode ( 4 ) ; root -> right -> right -> left -> left = newNode ( 5 ) ; root -> right -> right -> left -> right = newNode ( 6 ) ; root -> right -> right -> right -> left = newNode ( 7 ) ; root -> right -> right -> right -> right = newNode ( 8 ) ; Node * x = root -> right ; cout << " The ▁ closest ▁ leaf ▁ to ▁ the ▁ node ▁ with ▁ value ▁ " << x -> key << " ▁ is ▁ at ▁ a ▁ distance ▁ of ▁ " << minimumDistance ( root , x ) << endl ; return 0 ; }
struct Node * newNode ( int data ) { struct Node * node = new Node ; node -> data = data ; node -> left = node -> right = node -> abtr = NULL ; return node ; }
void preorderTraversal ( Node * root , vector < Node * > * even_ptrs , vector < Node * > * odd_ptrs ) { if ( ! root ) return ;
if ( root -> data % 2 == 0 ) ( * even_ptrs ) . push_back ( root ) ;
else ( * odd_ptrs ) . push_back ( root ) ; preorderTraversal ( root -> left , even_ptrs , odd_ptrs ) ; preorderTraversal ( root -> right , even_ptrs , odd_ptrs ) ; }
void createLoops ( Node * root ) { vector < Node * > even_ptrs , odd_ptrs ; preorderTraversal ( root , & even_ptrs , & odd_ptrs ) ; int i ;
for ( i = 1 ; i < even_ptrs . size ( ) ; i ++ ) even_ptrs [ i - 1 ] -> abtr = even_ptrs [ i ] ;
even_ptrs [ i - 1 ] -> abtr = even_ptrs [ 0 ] ;
for ( i = 1 ; i < odd_ptrs . size ( ) ; i ++ ) odd_ptrs [ i - 1 ] -> abtr = odd_ptrs [ i ] ; odd_ptrs [ i - 1 ] -> abtr = odd_ptrs [ 0 ] ; }
void traverseLoop ( Node * start ) { Node * curr = start ; do { cout << curr -> data << " ▁ " ; curr = curr -> abtr ; } while ( curr != start ) ; }
struct Node * root = NULL ; root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; createLoops ( root ) ;
cout << " Odd ▁ nodes : ▁ " ; traverseLoop ( root -> right ) ; cout << endl << " Even ▁ nodes : ▁ " ;
traverseLoop ( root -> left ) ; return 0 ; }
class Node { public : int data ; Node * left , * right ; } ;
Node * extractLeafList ( Node * root , Node * * head_ref ) { if ( root == NULL ) return NULL ; if ( root -> left == NULL && root -> right == NULL ) { root -> right = * head_ref ; if ( * head_ref != NULL ) ( * head_ref ) -> left = root ; * head_ref = root ; return NULL ; } root -> right = extractLeafList ( root -> right , head_ref ) ; root -> left = extractLeafList ( root -> left , head_ref ) ; return root ; }
void print ( Node * root ) { if ( root != NULL ) { print ( root -> left ) ; cout << root -> data << " ▁ " ; print ( root -> right ) ; } }
void printList ( Node * head ) { while ( head ) { cout << head -> data << " ▁ " ; head = head -> right ; } }
int main ( ) { Node * head = NULL ; Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; root -> left -> left -> left = newNode ( 7 ) ; root -> left -> left -> right = newNode ( 8 ) ; root -> right -> right -> left = newNode ( 9 ) ; root -> right -> right -> right = newNode ( 10 ) ; cout << " Inorder ▁ Trvaersal ▁ of ▁ given ▁ Tree ▁ is : STRNEWLINE " ; print ( root ) ; root = extractLeafList ( root , & head ) ; cout << " Extracted Double Linked list is : " ; printList ( head ) ; cout << " Inorder traversal of modified tree is : " print ( root ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ;
void dfs ( int n , int m , bool visit [ ] [ MAX ] , int adj [ ] [ MAX ] , int N , int M ) {
visit [ n ] [ m ] = 1 ;
if ( n + 1 < N && adj [ n ] [ m ] >= adj [ n + 1 ] [ m ] && ! visit [ n + 1 ] [ m ] ) dfs ( n + 1 , m , visit , adj , N , M ) ;
if ( m + 1 < M && adj [ n ] [ m ] >= adj [ n ] [ m + 1 ] && ! visit [ n ] [ m + 1 ] ) dfs ( n , m + 1 , visit , adj , N , M ) ;
if ( n - 1 >= 0 && adj [ n ] [ m ] >= adj [ n - 1 ] [ m ] && ! visit [ n - 1 ] [ m ] ) dfs ( n - 1 , m , visit , adj , N , M ) ;
if ( m - 1 >= 0 && adj [ n ] [ m ] >= adj [ n ] [ m - 1 ] && ! visit [ n ] [ m - 1 ] ) dfs ( n , m - 1 , visit , adj , N , M ) ; } void printMinSources ( int adj [ ] [ MAX ] , int N , int M ) {
vector < pair < long int , pair < int , int > > > x ; for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) x . push_back ( make_pair ( adj [ i ] [ j ] , make_pair ( i , j ) ) ) ;
sort ( x . begin ( ) , x . end ( ) ) ;
bool visit [ N ] [ MAX ] ; memset ( visit , false , sizeof ( visit ) ) ;
for ( int i = x . size ( ) - 1 ; i >= 0 ; i -- ) {
if ( ! visit [ x [ i ] . second . first ] [ x [ i ] . second . second ] ) { cout << x [ i ] . second . first << " ▁ " << x [ i ] . second . second << endl ; dfs ( x [ i ] . second . first , x [ i ] . second . second , visit , adj , N , M ) ; } } }
int main ( ) { int N = 2 , M = 2 ; int adj [ N ] [ MAX ] = { { 3 , 3 } , { 1 , 1 } } ; printMinSources ( adj , N , M ) ; return 0 ; }
bool isStepNum ( int n ) {
int prevDigit = -1 ;
while ( n ) {
int curDigit = n % 10 ;
if ( prevDigit == -1 ) prevDigit = curDigit ; else {
if ( abs ( prevDigit - curDigit ) != 1 ) return false ; } prevDigit = curDigit ; n /= 10 ; } return true ; }
void displaySteppingNumbers ( int n , int m ) {
for ( int i = n ; i <= m ; i ++ ) if ( isStepNum ( i ) ) cout << i << " ▁ " ; }
int main ( ) { int n = 0 , m = 21 ;
displaySteppingNumbers ( n , m ) ; return 0 ; }
void bfs ( int n , int m , int num ) {
queue < int > q ; q . push ( num ) ; while ( ! q . empty ( ) ) {
int stepNum = q . front ( ) ; q . pop ( ) ;
if ( stepNum <= m && stepNum >= n ) cout << stepNum << " ▁ " ;
if ( num == 0 stepNum > m ) continue ;
int lastDigit = stepNum % 10 ;
int stepNumA = stepNum * 10 + ( lastDigit - 1 ) ; int stepNumB = stepNum * 10 + ( lastDigit + 1 ) ;
if ( lastDigit == 0 ) q . push ( stepNumB ) ;
else if ( lastDigit == 9 ) q . push ( stepNumA ) ; else { q . push ( stepNumA ) ; q . push ( stepNumB ) ; } } }
void displaySteppingNumbers ( int n , int m ) {
for ( int i = 0 ; i <= 9 ; i ++ ) bfs ( n , m , i ) ; }
int main ( ) { int n = 0 , m = 21 ;
displaySteppingNumbers ( n , m ) ; return 0 ; }
struct node { struct node * left ; int data ; struct node * right ; } ;
void levelOrder ( node * root ) { if ( root == NULL ) return ;
queue < node * > q ;
q . push ( root ) ;
q . push ( NULL ) ;
while ( q . size ( ) > 1 ) { curr = q . front ( ) ; q . pop ( ) ;
if ( curr == NULL ) { q . push ( NULL ) ; cout << " STRNEWLINE " ; } else {
if ( curr -> left ) q . push ( curr -> left ) ;
if ( curr -> right ) q . push ( curr -> right ) ; cout << curr -> data << " ▁ " ; } } }
node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; levelOrder ( root ) ; return 0 ; }
struct Node { struct Node * left ; int data ; struct Node * right ; } ;
void modifiedLevelOrder ( struct Node * node ) {
if ( node == NULL ) return ; if ( node -> left == NULL && node -> right == NULL ) { cout << node -> data ; return ; }
queue < Node * > myQueue ;
stack < Node * > myStack ; struct Node * temp = NULL ;
int sz ;
int ct = 0 ;
bool rightToLeft = false ;
myQueue . push ( node ) ;
while ( ! myQueue . empty ( ) ) { ct ++ ; sz = myQueue . size ( ) ;
for ( int i = 0 ; i < sz ; i ++ ) { temp = myQueue . front ( ) ; myQueue . pop ( ) ;
if ( rightToLeft == false ) cout << temp -> data << " ▁ " ;
else myStack . push ( temp ) ; if ( temp -> left ) myQueue . push ( temp -> left ) ; if ( temp -> right ) myQueue . push ( temp -> right ) ; } if ( rightToLeft == true ) {
while ( ! myStack . empty ( ) ) { temp = myStack . top ( ) ; myStack . pop ( ) ; cout << temp -> data << " ▁ " ; } }
if ( ct == 2 ) { rightToLeft = ! rightToLeft ; ct = 0 ; } cout << " STRNEWLINE " ; } }
Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> left -> left -> left = newNode ( 8 ) ; root -> left -> left -> right = newNode ( 9 ) ; root -> left -> right -> left = newNode ( 3 ) ; root -> left -> right -> right = newNode ( 1 ) ; root -> right -> left -> left = newNode ( 4 ) ; root -> right -> left -> right = newNode ( 2 ) ; root -> right -> right -> left = newNode ( 7 ) ; root -> right -> right -> right = newNode ( 2 ) ; root -> left -> right -> left -> left = newNode ( 16 ) ; root -> left -> right -> left -> right = newNode ( 17 ) ; root -> right -> left -> right -> left = newNode ( 18 ) ; root -> right -> right -> left -> right = newNode ( 19 ) ; modifiedLevelOrder ( root ) ; return 0 ; }
int find ( int parent [ ] , int i ) { if ( parent [ i ] == -1 ) return i ; return find ( parent , parent [ i ] ) ; }
void Union ( int parent [ ] , int x , int y ) { int xset = find ( parent , x ) ; int yset = find ( parent , y ) ; parent [ xset ] = yset ; }
#include <iostream> NEW_LINE #include <stack> NEW_LINE #include <queue> NEW_LINE using namespace std ; #define LEFT  0 NEW_LINE #define RIGHT  1 NEW_LINE #define ChangeDirection ( Dir )  ((Dir) = 1 - (Dir))
struct node { int data ; struct node * left , * right ; } ;
node * newNode ( int data ) { node * temp = new node ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
void modifiedLevelOrder ( struct node * root ) { if ( ! root ) return ; int dir = LEFT ; struct node * temp ; queue < struct node * > Q ; stack < struct node * > S ; S . push ( root ) ;
while ( ! Q . empty ( ) || ! S . empty ( ) ) { while ( ! S . empty ( ) ) { temp = S . top ( ) ; S . pop ( ) ; cout << temp -> data << " ▁ " ; if ( dir == LEFT ) { if ( temp -> left ) Q . push ( temp -> left ) ; if ( temp -> right ) Q . push ( temp -> right ) ; }
else { if ( temp -> right ) Q . push ( temp -> right ) ; if ( temp -> left ) Q . push ( temp -> left ) ; } } cout << endl ;
while ( ! Q . empty ( ) ) { temp = Q . front ( ) ; Q . pop ( ) ; cout << temp -> data << " ▁ " ; if ( dir == LEFT ) { if ( temp -> left ) S . push ( temp -> left ) ; if ( temp -> right ) S . push ( temp -> right ) ; } else { if ( temp -> right ) S . push ( temp -> right ) ; if ( temp -> left ) S . push ( temp -> left ) ; } } cout << endl ;
ChangeDirection ( dir ) ; } }
node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> left -> left -> left = newNode ( 8 ) ; root -> left -> left -> right = newNode ( 9 ) ; root -> left -> right -> left = newNode ( 3 ) ; root -> left -> right -> right = newNode ( 1 ) ; root -> right -> left -> left = newNode ( 4 ) ; root -> right -> left -> right = newNode ( 2 ) ; root -> right -> right -> left = newNode ( 7 ) ; root -> right -> right -> right = newNode ( 2 ) ; root -> left -> right -> left -> left = newNode ( 16 ) ; root -> left -> right -> left -> right = newNode ( 17 ) ; root -> right -> left -> right -> left = newNode ( 18 ) ; root -> right -> right -> left -> right = newNode ( 19 ) ; modifiedLevelOrder ( root ) ; return 0 ; }
int minnode ( int n , int keyval [ ] , bool mstset [ ] ) { int mini = numeric_limits < int > :: max ( ) ; int mini_index ;
for ( int i = 0 ; i < n ; i ++ ) { if ( mstset [ i ] == false && keyval [ i ] < mini ) { mini = keyval [ i ] , mini_index = i ; } } return mini_index ; }
void findcost ( int n , vector < vector < int > > city ) {
int parent [ n ] ;
int keyval [ n ] ;
bool mstset [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) { keyval [ i ] = numeric_limits < int > :: max ( ) ; mstset [ i ] = false ; }
parent [ 0 ] = -1 ; keyval [ 0 ] = 0 ;
for ( int i = 0 ; i < n - 1 ; i ++ ) {
int u = minnode ( n , keyval , mstset ) ;
mstset [ u ] = true ;
for ( int v = 0 ; v < n ; v ++ ) { if ( city [ u ] [ v ] && mstset [ v ] == false && city [ u ] [ v ] < keyval [ v ] ) { keyval [ v ] = city [ u ] [ v ] ; parent [ v ] = u ; } } }
int cost = 0 ; for ( int i = 1 ; i < n ; i ++ ) cost += city [ parent [ i ] ] [ i ] ; cout << cost << endl ; }
int n1 = 5 ; vector < vector < int > > city1 = { { 0 , 1 , 2 , 3 , 4 } , { 1 , 0 , 5 , 0 , 7 } , { 2 , 5 , 0 , 6 , 0 } , { 3 , 0 , 6 , 0 , 0 } , { 4 , 7 , 0 , 0 , 0 } } ; findcost ( n1 , city1 ) ;
int n2 = 6 ; vector < vector < int > > city2 = { { 0 , 1 , 1 , 100 , 0 , 0 } , { 1 , 0 , 1 , 0 , 0 , 0 } , { 1 , 1 , 0 , 0 , 0 , 0 } , { 100 , 0 , 0 , 0 , 2 , 2 } , { 0 , 0 , 0 , 2 , 0 , 2 } , { 0 , 0 , 0 , 2 , 2 , 0 } } ; findcost ( n2 , city2 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  8 NEW_LINE int solveKTUtil ( int x , int y , int movei , int sol [ N ] [ N ] , int xMove [ ] , int yMove [ ] ) ;
int isSafe ( int x , int y , int sol [ N ] [ N ] ) { return ( x >= 0 && x < N && y >= 0 && y < N && sol [ x ] [ y ] == -1 ) ; }
void printSolution ( int sol [ N ] [ N ] ) { for ( int x = 0 ; x < N ; x ++ ) { for ( int y = 0 ; y < N ; y ++ ) cout << " ▁ " << setw ( 2 ) << sol [ x ] [ y ] << " ▁ " ; cout << endl ; } }
int solveKT ( ) { int sol [ N ] [ N ] ;
for ( int x = 0 ; x < N ; x ++ ) for ( int y = 0 ; y < N ; y ++ ) sol [ x ] [ y ] = -1 ;
int xMove [ 8 ] = { 2 , 1 , -1 , -2 , -2 , -1 , 1 , 2 } ; int yMove [ 8 ] = { 1 , 2 , 2 , 1 , -1 , -2 , -2 , -1 } ;
sol [ 0 ] [ 0 ] = 0 ;
if ( solveKTUtil ( 0 , 0 , 1 , sol , xMove , yMove ) == 0 ) { cout << " Solution ▁ does ▁ not ▁ exist " ; return 0 ; } else printSolution ( sol ) ; return 1 ; }
int solveKTUtil ( int x , int y , int movei , int sol [ N ] [ N ] , int xMove [ N ] , int yMove [ N ] ) { int k , next_x , next_y ; if ( movei == N * N ) return 1 ;
for ( k = 0 ; k < 8 ; k ++ ) { next_x = x + xMove [ k ] ; next_y = y + yMove [ k ] ; if ( isSafe ( next_x , next_y , sol ) ) { sol [ next_x ] [ next_y ] = movei ; if ( solveKTUtil ( next_x , next_y , movei + 1 , sol , xMove , yMove ) == 1 ) return 1 ; else
sol [ next_x ] [ next_y ] = -1 ; } } return 0 ; }
solveKT ( ) ; return 0 ; }
#define V  4 NEW_LINE void printSolution ( int color [ ] ) ;
void printSolution ( int color [ ] ) { cout << " Solution ▁ Exists : " " ▁ Following ▁ are ▁ the ▁ assigned ▁ colors ▁ STRNEWLINE " ; for ( int i = 0 ; i < V ; i ++ ) cout << " ▁ " << color [ i ] ; cout << " STRNEWLINE " ; }
bool isSafe ( bool graph [ V ] [ V ] , int color [ ] ) {
for ( int i = 0 ; i < V ; i ++ ) for ( int j = i + 1 ; j < V ; j ++ ) if ( graph [ i ] [ j ] && color [ j ] == color [ i ] ) return false ; return true ; }
bool graphColoring ( bool graph [ V ] [ V ] , int m , int i , int color [ V ] ) {
if ( i == V ) {
if ( isSafe ( graph , color ) ) {
printSolution ( color ) ; return true ; } return false ; }
for ( int j = 1 ; j <= m ; j ++ ) { color [ i ] = j ;
if ( graphColoring ( graph , m , i + 1 , color ) ) return true ; color [ i ] = 0 ; } return false ; }
bool graph [ V ] [ V ] = { { 0 , 1 , 1 , 1 } , { 1 , 0 , 1 , 0 } , { 1 , 1 , 0 , 1 } , { 1 , 0 , 1 , 0 } , } ;
int m = 3 ;
int color [ V ] ; for ( int i = 0 ; i < V ; i ++ ) color [ i ] = 0 ; if ( ! graphColoring ( graph , m , 0 , color ) ) cout << " Solution ▁ does ▁ not ▁ exist " ; return 0 ; }
int shortestChainLen ( string start , string target , set < string > & D ) { if ( start == target ) return 0 ;
if ( D . find ( target ) == D . end ( ) ) return 0 ;
int level = 0 , wordlength = start . size ( ) ;
queue < string > Q ; Q . push ( start ) ;
while ( ! Q . empty ( ) ) {
++ level ;
int sizeofQ = Q . size ( ) ;
for ( int i = 0 ; i < sizeofQ ; ++ i ) {
string word = Q . front ( ) ; Q . pop ( ) ;
for ( int pos = 0 ; pos < wordlength ; ++ pos ) {
char orig_char = word [ pos ] ;
for ( char c = ' a ' ; c <= ' z ' ; ++ c ) { word [ pos ] = c ;
if ( word == target ) return level + 1 ;
if ( D . find ( word ) == D . end ( ) ) continue ; D . erase ( word ) ;
Q . push ( word ) ; }
word [ pos ] = orig_char ; } } } return 0 ; }
set < string > D ; D . insert ( " poon " ) ; D . insert ( " plee " ) ; D . insert ( " same " ) ; D . insert ( " poie " ) ; D . insert ( " plie " ) ; D . insert ( " poin " ) ; D . insert ( " plea " ) ; string start = " toon " ; string target = " plea " ; cout << " Length ▁ of ▁ shortest ▁ chain ▁ is : ▁ " << shortestChainLen ( start , target , D ) ; return 0 ; }
#include <iostream> NEW_LINE #include <climits> NEW_LINE using namespace std ; #define INF  INT_MAX NEW_LINE #define N  4
int minCost ( int cost [ ] [ N ] ) {
int dist [ N ] ; for ( int i = 0 ; i < N ; i ++ ) dist [ i ] = INF ; dist [ 0 ] = 0 ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( dist [ j ] > dist [ i ] + cost [ i ] [ j ] ) dist [ j ] = dist [ i ] + cost [ i ] [ j ] ; return dist [ N - 1 ] ; }
int main ( ) { int cost [ N ] [ N ] = { { 0 , 15 , 80 , 90 } , { INF , 0 , 40 , 50 } , { INF , INF , 0 , 70 } , { INF , INF , INF , 0 } } ; cout << " The ▁ Minimum ▁ cost ▁ to ▁ reach ▁ station ▁ " << N << " ▁ is ▁ " << minCost ( cost ) ; return 0 ; }
int numOfways ( int n , int k ) { int p = 1 ; if ( k % 2 ) p = -1 ; return ( pow ( n - 1 , k ) + p * ( n - 1 ) ) / n ; }
int main ( ) { int n = 4 , k = 2 ; cout << numOfways ( n , k ) << endl ; return 0 ; }
if ( inMST [ v ] == false && key [ v ] > weight ) {
key [ v ] = weight ; pq . push ( make_pair ( key [ v ] , v ) ) ; parent [ v ] = u ; }
void addEdge ( vector < pair < int , int > > adj [ ] , int u , int v , int wt ) { adj [ u ] . push_back ( make_pair ( v , wt ) ) ; adj [ v ] . push_back ( make_pair ( u , wt ) ) ; }
void printGraph ( vector < pair < int , int > > adj [ ] , int V ) { int v , w ; for ( int u = 0 ; u < V ; u ++ ) { cout << " Node ▁ " << u << " ▁ makes ▁ an ▁ edge ▁ with ▁ STRNEWLINE " ; for ( auto it = adj [ u ] . begin ( ) ; it != adj [ u ] . end ( ) ; it ++ ) { v = it -> first ; w = it -> second ; cout << " TABSYMBOL Node ▁ " << v << " ▁ with ▁ edge ▁ weight ▁ = " << w << " STRNEWLINE " ; } cout << " STRNEWLINE " ; } }
int main ( ) { int V = 5 ; vector < pair < int , int > > adj [ V ] ; addEdge ( adj , 0 , 1 , 10 ) ; addEdge ( adj , 0 , 4 , 20 ) ; addEdge ( adj , 1 , 2 , 30 ) ; addEdge ( adj , 1 , 3 , 40 ) ; addEdge ( adj , 1 , 4 , 50 ) ; addEdge ( adj , 2 , 3 , 60 ) ; addEdge ( adj , 3 , 4 , 70 ) ; printGraph ( adj , V ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int maxindex ( int * dist , int n ) { int mi = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( dist [ i ] > dist [ mi ] ) mi = i ; } return mi ; } void selectKcities ( int n , int weights [ 4 ] [ 4 ] , int k ) { int * dist = new int [ n ] ; vector < int > centers ; for ( int i = 0 ; i < n ; i ++ ) { dist [ i ] = INT_MAX ; }
int max = 0 ; for ( int i = 0 ; i < k ; i ++ ) { centers . push_back ( max ) ; for ( int j = 0 ; j < n ; j ++ ) {
dist [ j ] = min ( dist [ j ] , weights [ max ] [ j ] ) ; }
max = maxindex ( dist , n ) ; }
cout << endl << dist [ max ] << endl ;
for ( int i = 0 ; i < centers . size ( ) ; i ++ ) { cout << centers [ i ] << " ▁ " ; } cout << endl ; }
int main ( ) { int n = 4 ; int weights [ 4 ] [ 4 ] = { { 0 , 4 , 8 , 5 } , { 4 , 0 , 10 , 7 } , { 8 , 10 , 0 , 9 } , { 5 , 7 , 9 , 0 } } ; int k = 2 ;
selectKcities ( n , weights , k ) ; }
#define V  4
void multiply ( int A [ ] [ V ] , int B [ ] [ V ] , int C [ ] [ V ] ) { for ( int i = 0 ; i < V ; i ++ ) { for ( int j = 0 ; j < V ; j ++ ) { C [ i ] [ j ] = 0 ; for ( int k = 0 ; k < V ; k ++ ) C [ i ] [ j ] += A [ i ] [ k ] * B [ k ] [ j ] ; } } }
int getTrace ( int graph [ ] [ V ] ) { int trace = 0 ; for ( int i = 0 ; i < V ; i ++ ) trace += graph [ i ] [ i ] ; return trace ; }
int triangleInGraph ( int graph [ ] [ V ] ) {
int aux2 [ V ] [ V ] ;
int aux3 [ V ] [ V ] ;
for ( int i = 0 ; i < V ; ++ i ) for ( int j = 0 ; j < V ; ++ j ) aux2 [ i ] [ j ] = aux3 [ i ] [ j ] = 0 ;
multiply ( graph , graph , aux2 ) ;
multiply ( graph , aux2 , aux3 ) ; int trace = getTrace ( aux3 ) ; return trace / 6 ; }
int main ( ) { int graph [ V ] [ V ] = { { 0 , 1 , 1 , 0 } , { 1 , 0 , 1 , 1 } , { 1 , 1 , 0 , 1 } , { 0 , 1 , 1 , 0 } } ; printf ( " Total ▁ number ▁ of ▁ Triangle ▁ in ▁ Graph ▁ : ▁ % d STRNEWLINE " , triangleInGraph ( graph ) ) ; return 0 ; }
int power ( int n ) { if ( n == 1 ) return 2 ; return 2 * power ( n - 1 ) ; }
int main ( ) { int n = 4 ; cout << power ( n ) ; return 0 ; }
#define size  4
bool checkStar ( int mat [ ] [ size ] ) {
int vertexD1 = 0 , vertexDn_1 = 0 ;
if ( size == 1 ) return ( mat [ 0 ] [ 0 ] == 0 ) ;
if ( size == 2 ) return ( mat [ 0 ] [ 0 ] == 0 && mat [ 0 ] [ 1 ] == 1 && mat [ 1 ] [ 0 ] == 1 && mat [ 1 ] [ 1 ] == 0 ) ;
for ( int i = 0 ; i < size ; i ++ ) { int degreeI = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( mat [ i ] [ j ] ) degreeI ++ ; if ( degreeI == 1 ) vertexD1 ++ ; else if ( degreeI == size - 1 ) vertexDn_1 ++ ; } return ( vertexD1 == ( size - 1 ) && vertexDn_1 == 1 ) ; }
int main ( ) { int mat [ size ] [ size ] = { { 0 , 1 , 1 , 1 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } } ; checkStar ( mat ) ? cout << " Star ▁ Graph " : cout << " Not ▁ a ▁ Star ▁ Graph " ; return 0 ; }
int fib ( int n ) { if ( n <= 1 ) return n ; return fib ( n - 1 ) + fib ( n - 2 ) ; }
int findVertices ( int n ) {
return fib ( n + 2 ) ; }
int main ( ) { int n = 3 ; cout << findVertices ( n ) ; return 0 ; }
void push ( Node * * head_ref , int new_data ) {
Node * new_node = new Node ( ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void insertAfter ( Node * prev_node , int new_data ) {
if ( prev_node == NULL ) { cout << " the ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL " ; return ; }
Node * new_node = new Node ( ) ; new_node -> data = new_data ;
new_node -> next = prev_node -> next ;
prev_node -> next = new_node ; }
int count ( struct Node * head , int key ) { if ( head == NULL ) return 0 ; if ( head -> data == key ) return 1 + count ( head -> next , key ) ; return count ( head -> next , key ) ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; class Node { public : int data ; Node * next ; } ;
void swapNodes ( Node * * head_ref , int x , int y ) {
if ( x == y ) return ;
Node * prevX = NULL , * currX = * head_ref ; while ( currX && currX -> data != x ) { prevX = currX ; currX = currX -> next ; }
Node * prevY = NULL , * currY = * head_ref ; while ( currY && currY -> data != y ) { prevY = currY ; currY = currY -> next ; }
if ( currX == NULL currY == NULL ) return ;
if ( prevX != NULL ) prevX -> next = currY ;
else * head_ref = currY ;
if ( prevY != NULL ) prevY -> next = currX ;
else * head_ref = currX ;
Node * temp = currY -> next ; currY -> next = currX -> next ; currX -> next = temp ; }
void push ( Node * * head_ref , int new_data ) {
Node * new_node = new Node ( ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( Node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> next ; } }
push ( & start , 7 ) ; push ( & start , 6 ) ; push ( & start , 5 ) ; push ( & start , 4 ) ; push ( & start , 3 ) ; push ( & start , 2 ) ; push ( & start , 1 ) ; cout << " Linked ▁ list ▁ before ▁ calling ▁ swapNodes ( ) ▁ " ; printList ( start ) ; swapNodes ( & start , 4 , 3 ) ; cout << " Linked list after calling swapNodes ( ) " ; printList ( start ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
bool isCircular ( struct Node * head ) {
if ( head == NULL ) return true ;
struct Node * node = head -> next ;
while ( node != NULL && node != head ) node = node -> next ;
return ( node == head ) ; }
Node * newNode ( int data ) { struct Node * temp = new Node ; temp -> data = data ; temp -> next = NULL ; return temp ; }
struct Node * head = newNode ( 1 ) ; head -> next = newNode ( 2 ) ; head -> next -> next = newNode ( 3 ) ; head -> next -> next -> next = newNode ( 4 ) ; isCircular ( head ) ? cout << " Yes STRNEWLINE " : cout << " No STRNEWLINE " ;
head -> next -> next -> next -> next = head ; isCircular ( head ) ? cout << " Yes STRNEWLINE " : cout << " No STRNEWLINE " ; return 0 ; }
struct Node * addToEmpty ( struct Node * last , int data ) {
if ( last != NULL ) return last ;
struct Node * temp = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
temp -> data = data ; last = temp ;
temp -> next = last ; return last ; }
struct Node * addBegin ( struct Node * last , int data ) { if ( last == NULL ) return addToEmpty ( last , data ) ;
struct Node * temp = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
temp -> data = data ;
temp -> next = last -> next ; last -> next = temp ; return last ; }
struct Node { int data ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int new_data ) { struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ; new_node -> next = ( * head_ref ) ; ( * head_ref ) = new_node ; }
void printList ( struct Node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> next ; } cout << endl ; }
int countNodes ( struct Node * s ) { int count = 0 ; while ( s != NULL ) { count ++ ; s = s -> next ; } return count ; }
void swapKth ( struct Node * * head_ref , int k ) {
int n = countNodes ( * head_ref ) ;
if ( n < k ) return ;
if ( 2 * k - 1 == n ) return ;
Node * x = * head_ref ; Node * x_prev = NULL ; for ( int i = 1 ; i < k ; i ++ ) { x_prev = x ; x = x -> next ; }
Node * y = * head_ref ; Node * y_prev = NULL ; for ( int i = 1 ; i < n - k + 1 ; i ++ ) { y_prev = y ; y = y -> next ; }
if ( x_prev ) x_prev -> next = y ;
if ( y_prev ) y_prev -> next = x ;
Node * temp = x -> next ; x -> next = y -> next ; y -> next = temp ;
if ( k == 1 ) * head_ref = y ; if ( k == n ) * head_ref = x ; }
int main ( ) { struct Node * head = NULL ; for ( int i = 8 ; i >= 1 ; i -- ) push ( & head , i ) ; cout << " Original ▁ Linked ▁ List : ▁ " ; printList ( head ) ; for ( int k = 1 ; k < 9 ; k ++ ) { swapKth ( & head , k ) ; cout << " Modified List for k = " printList ( head ) ; } return 0 ; }
struct Node { int data ; struct Node * next , * prev ; } ;
int countPairs ( struct Node * first , struct Node * second , int value ) { int count = 0 ;
while ( first != NULL && second != NULL && first != second && second -> next != first ) {
if ( ( first -> data + second -> data ) == value ) {
count ++ ;
first = first -> next ;
second = second -> prev ; }
else if ( ( first -> data + second -> data ) > value ) second = second -> prev ;
else first = first -> next ; }
return count ; }
int countTriplets ( struct Node * head , int x ) {
if ( head == NULL ) return 0 ; struct Node * current , * first , * last ; int count = 0 ;
last = head ; while ( last -> next != NULL ) last = last -> next ;
for ( current = head ; current != NULL ; current = current -> next ) {
first = current -> next ;
count += countPairs ( first , last , x - current -> data ) ; }
return count ; }
void insert ( struct Node * * head , int data ) {
struct Node * temp = new Node ( ) ;
temp -> data = data ; temp -> next = temp -> prev = NULL ; if ( ( * head ) == NULL ) ( * head ) = temp ; else { temp -> next = * head ; ( * head ) -> prev = temp ; ( * head ) = temp ; } }
struct Node * head = NULL ;
insert ( & head , 9 ) ; insert ( & head , 8 ) ; insert ( & head , 6 ) ; insert ( & head , 5 ) ; insert ( & head , 4 ) ; insert ( & head , 2 ) ; insert ( & head , 1 ) ; int x = 17 ; cout << " Count ▁ = ▁ " << countTriplets ( head , x ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
void deleteNode ( struct Node * * head_ref , struct Node * del ) {
if ( * head_ref == NULL del == NULL ) return ;
if ( * head_ref == del ) * head_ref = del -> next ;
if ( del -> next != NULL ) del -> next -> prev = del -> prev ;
if ( del -> prev != NULL ) del -> prev -> next = del -> next ; free ( del ) ; }
void removeDuplicates ( struct Node * * head_ref ) {
if ( ( * head_ref ) == NULL || ( * head_ref ) -> next == NULL ) return ; struct Node * ptr1 , * ptr2 ;
for ( ptr1 = * head_ref ; ptr1 != NULL ; ptr1 = ptr1 -> next ) { ptr2 = ptr1 -> next ;
while ( ptr2 != NULL ) {
if ( ptr1 -> data == ptr2 -> data ) {
struct Node * next = ptr2 -> next ;
deleteNode ( head_ref , ptr2 ) ;
ptr2 = next ; }
else ptr2 = ptr2 -> next ; } } }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
new_node -> data = new_data ;
new_node -> prev = NULL ;
new_node -> next = ( * head_ref ) ;
if ( ( * head_ref ) != NULL ) ( * head_ref ) -> prev = new_node ;
( * head_ref ) = new_node ; }
void printList ( struct Node * head ) {
if ( head == NULL ) cout << " Doubly ▁ Linked ▁ list ▁ empty " ; while ( head != NULL ) { cout << head -> data << " ▁ " ; head = head -> next ; } }
int main ( ) { struct Node * head = NULL ;
push ( & head , 12 ) ; push ( & head , 12 ) ; push ( & head , 10 ) ; push ( & head , 4 ) ; push ( & head , 8 ) ; push ( & head , 4 ) ; push ( & head , 6 ) ; push ( & head , 4 ) ; push ( & head , 4 ) ; push ( & head , 8 ) ; cout << " Original ▁ Doubly ▁ linked ▁ list : n " ; printList ( head ) ;
removeDuplicates ( & head ) ; cout << " Doubly linked list after " STRNEWLINE " removing duplicates : n " ; printList ( head ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
struct Node { int data ; struct Node * next ; struct Node * prev ; } ;
void deleteNode ( struct Node * * head_ref , struct Node * del ) {
if ( * head_ref == NULL del == NULL ) return ;
if ( * head_ref == del ) * head_ref = del -> next ;
if ( del -> next != NULL ) del -> next -> prev = del -> prev ;
if ( del -> prev != NULL ) del -> prev -> next = del -> next ; free ( del ) ; }
void removeDuplicates ( struct Node * * head_ref ) {
if ( ( * head_ref ) == NULL ) return ;
unordered_set < int > us ; struct Node * current = * head_ref , * next ;
while ( current != NULL ) {
if ( us . find ( current -> data ) != us . end ( ) ) {
next = current -> next ;
deleteNode ( head_ref , current ) ;
current = next ; } else {
us . insert ( current -> data ) ;
current = current -> next ; } } }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
new_node -> data = new_data ;
new_node -> prev = NULL ;
new_node -> next = ( * head_ref ) ;
if ( ( * head_ref ) != NULL ) ( * head_ref ) -> prev = new_node ;
( * head_ref ) = new_node ; }
void printList ( struct Node * head ) {
if ( head == NULL ) cout << " Doubly ▁ Linked ▁ list ▁ empty " ; while ( head != NULL ) { cout << head -> data << " ▁ " ; head = head -> next ; } }
int main ( ) { struct Node * head = NULL ;
push ( & head , 12 ) ; push ( & head , 12 ) ; push ( & head , 10 ) ; push ( & head , 4 ) ; push ( & head , 8 ) ; push ( & head , 4 ) ; push ( & head , 6 ) ; push ( & head , 4 ) ; push ( & head , 4 ) ; push ( & head , 8 ) ; cout << " Original ▁ Doubly ▁ linked ▁ list : n " ; printList ( head ) ;
removeDuplicates ( & head ) ; cout << " Doubly linked list after " STRNEWLINE " removing duplicates : n " ; printList ( head ) ; return 0 ; }
struct Node { int data ; struct Node * next ; struct Node * prev ; } ;
void reverse ( struct Node * * head_ref ) { struct Node * temp = NULL ; struct Node * current = * head_ref ;
while ( current != NULL ) { temp = current -> prev ; current -> prev = current -> next ; current -> next = temp ; current = current -> prev ; }
if ( temp != NULL ) * head_ref = temp -> prev ; }
struct Node * merge ( struct Node * first , struct Node * second ) {
if ( ! first ) return second ;
if ( ! second ) return first ;
if ( first -> data < second -> data ) { first -> next = merge ( first -> next , second ) ; first -> next -> prev = first ; first -> prev = NULL ; return first ; } else { second -> next = merge ( first , second -> next ) ; second -> next -> prev = second ; second -> prev = NULL ; return second ; } }
struct Node * sort ( struct Node * head ) {
if ( head == NULL head -> next == NULL ) return head ; struct Node * current = head -> next ; while ( current != NULL ) {
if ( current -> data < current -> prev -> data ) break ;
current = current -> next ; }
if ( current == NULL ) return head ;
current -> prev -> next = NULL ; current -> prev = NULL ;
reverse ( & current ) ;
return merge ( head , current ) ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
new_node -> data = new_data ;
new_node -> prev = NULL ;
new_node -> next = ( * head_ref ) ;
if ( ( * head_ref ) != NULL ) ( * head_ref ) -> prev = new_node ;
( * head_ref ) = new_node ; }
void printList ( struct Node * head ) {
if ( head == NULL ) cout << " Doubly ▁ Linked ▁ list ▁ empty " ; while ( head != NULL ) { cout << head -> data << " ▁ " ; head = head -> next ; } }
int main ( ) { struct Node * head = NULL ;
push ( & head , 1 ) ; push ( & head , 4 ) ; push ( & head , 6 ) ; push ( & head , 10 ) ; push ( & head , 12 ) ; push ( & head , 7 ) ; push ( & head , 5 ) ; push ( & head , 2 ) ; cout << " Original ▁ Doubly ▁ linked ▁ list : n " ; printList ( head ) ;
head = sort ( head ) ; cout << " Doubly linked list after sorting : n " ; printList ( head ) ; return 0 ; }
class Node { public : Node * prev ; int info ; Node * next ; } ;
void nodeInsetail ( Node * * head , Node * * tail , int key ) { Node * p = new Node ( ) ; p -> info = key ; p -> next = NULL ;
if ( ( * head ) == NULL ) { ( * head ) = p ; ( * tail ) = p ; ( * head ) -> prev = NULL ; return ; }
if ( ( p -> info ) < ( ( * head ) -> info ) ) { p -> prev = NULL ; ( * head ) -> prev = p ; p -> next = ( * head ) ; ( * head ) = p ; return ; }
if ( ( p -> info ) > ( ( * tail ) -> info ) ) { p -> prev = ( * tail ) ; ( * tail ) -> next = p ; ( * tail ) = p ; return ; }
Node * temp = ( * head ) -> next ; while ( ( temp -> info ) < ( p -> info ) ) temp = temp -> next ;
( temp -> prev ) -> next = p ; p -> prev = temp -> prev ; temp -> prev = p ; p -> next = temp ; }
void printList ( Node * temp ) { while ( temp != NULL ) { cout << temp -> info << " ▁ " ; temp = temp -> next ; } }
int main ( ) { Node * left = NULL , * right = NULL ; nodeInsetail ( & left , & right , 30 ) ; nodeInsetail ( & left , & right , 50 ) ; nodeInsetail ( & left , & right , 90 ) ; nodeInsetail ( & left , & right , 10 ) ; nodeInsetail ( & left , & right , 40 ) ; nodeInsetail ( & left , & right , 110 ) ; nodeInsetail ( & left , & right , 60 ) ; nodeInsetail ( & left , & right , 95 ) ; nodeInsetail ( & left , & right , 23 ) ; cout << " Doubly ▁ linked ▁ list ▁ on ▁ printing " " ▁ from ▁ left ▁ to ▁ right STRNEWLINE " ; printList ( left ) ; return 0 ; }
void insertEnd ( struct Node * * start , int value ) {
if ( * start == NULL ) { struct Node * new_node = new Node ; new_node -> data = value ; new_node -> next = new_node -> prev = new_node ; * start = new_node ; return ; }
Node * last = ( * start ) -> prev ;
struct Node * new_node = new Node ; new_node -> data = value ;
new_node -> next = * start ;
( * start ) -> prev = new_node ;
new_node -> prev = last ;
last -> next = new_node ; }
struct Node { int data ; struct Node * next ; } ;
int findDepthRec ( char tree [ ] , int n , int & index ) { if ( index >= n tree [ index ] == ' l ' ) return 0 ;
index ++ ; int left = findDepthRec ( tree , n , index ) ;
index ++ ; int right = findDepthRec ( tree , n , index ) ; return max ( left , right ) + 1 ; }
int findDepth ( char tree [ ] , int n ) { int index = 0 ; findDepthRec ( tree , n , index ) ; }
int main ( ) { char tree [ ] = " nlnnlll " ; int n = strlen ( tree ) ; cout << findDepth ( tree , n ) << endl ; return 0 ; }
struct Node { char data ; struct Node * next ; } ;
Node * newNode ( char key ) { Node * temp = new Node ; temp -> data = key ; temp -> next = NULL ; return temp ; }
void printlist ( Node * head ) { if ( ! head ) { cout << " Empty ▁ List STRNEWLINE " ; return ; } while ( head != NULL ) { cout << head -> data << " ▁ " ; if ( head -> next ) cout << " - > ▁ " ; head = head -> next ; } cout << endl ; }
bool isVowel ( char x ) { return ( x == ' a ' x == ' e ' x == ' i ' x == ' o ' x == ' u ' ) ; }
Node * arrange ( Node * head ) { Node * newHead = head ;
Node * latestVowel ; Node * curr = head ;
if ( head == NULL ) return NULL ;
if ( isVowel ( head -> data ) )
latestVowel = head ; else {
while ( curr -> next != NULL && ! isVowel ( curr -> next -> data ) ) curr = curr -> next ;
if ( curr -> next == NULL ) return head ;
latestVowel = newHead = curr -> next ; curr -> next = curr -> next -> next ; latestVowel -> next = head ; }
while ( curr != NULL && curr -> next != NULL ) { if ( isVowel ( curr -> next -> data ) ) {
if ( curr == latestVowel ) {
latestVowel = curr = curr -> next ; } else {
Node * temp = latestVowel -> next ;
latestVowel -> next = curr -> next ;
latestVowel = latestVowel -> next ;
curr -> next = curr -> next -> next ;
latestVowel -> next = temp ; } } else {
curr = curr -> next ; } } return newHead ; }
int main ( ) { Node * head = newNode ( ' a ' ) ; head -> next = newNode ( ' b ' ) ; head -> next -> next = newNode ( ' c ' ) ; head -> next -> next -> next = newNode ( ' e ' ) ; head -> next -> next -> next -> next = newNode ( ' d ' ) ; head -> next -> next -> next -> next -> next = newNode ( ' o ' ) ; head -> next -> next -> next -> next -> next -> next = newNode ( ' x ' ) ; head -> next -> next -> next -> next -> next -> next -> next = newNode ( ' i ' ) ; printf ( " Linked ▁ list ▁ before ▁ : STRNEWLINE " ) ; printlist ( head ) ; head = arrange ( head ) ; printf ( " Linked ▁ list ▁ after ▁ : STRNEWLINE " ) ; printlist ( head ) ; return 0 ; }
struct Node { int data ; Node * left , * right ; Node ( int x ) { data = x ; left = right = NULL ; } } ;
Node * insert ( Node * root , int x ) { if ( root == NULL ) return new Node ( x ) ; if ( x < root -> data ) root -> left = insert ( root -> left , x ) ; else if ( x > root -> data ) root -> right = insert ( root -> right , x ) ; return root ; }
Node * kthSmallest ( Node * root , int & k ) {
if ( root == NULL ) return NULL ;
Node * left = kthSmallest ( root -> left , k ) ;
if ( left != NULL ) return left ;
k -- ; if ( k == 0 ) return root ;
return kthSmallest ( root -> right , k ) ; }
void printKthSmallest ( Node * root , int k ) {
int count = 0 ; Node * res = kthSmallest ( root , k ) ; if ( res == NULL ) cout << " There ▁ are ▁ less ▁ than ▁ k ▁ nodes ▁ in ▁ the ▁ BST " ; else cout << " K - th ▁ Smallest ▁ Element ▁ is ▁ " << res -> data ; }
int main ( ) { Node * root = NULL ; int keys [ ] = { 20 , 8 , 22 , 4 , 12 , 10 , 14 } ; for ( int x : keys ) root = insert ( root , x ) ; int k = 3 ; printKthSmallest ( root , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; class TreeNode { public : int val ; TreeNode * left ; TreeNode * right ; TreeNode ( int x ) { val = x ; } } ; set < TreeNode * > s ; stack < TreeNode * > st ;
TreeNode * buildTree ( int preorder [ ] , int inorder [ ] , int n ) { TreeNode * root = NULL ; for ( int pre = 0 , in = 0 ; pre < n ; ) { TreeNode * node = NULL ; do { node = new TreeNode ( preorder [ pre ] ) ; if ( root == NULL ) { root = node ; } if ( st . size ( ) > 0 ) { if ( s . find ( st . top ( ) ) != s . end ( ) ) { s . erase ( st . top ( ) ) ; st . top ( ) -> right = node ; st . pop ( ) ; } else { st . top ( ) -> left = node ; } } st . push ( node ) ; } while ( preorder [ pre ++ ] != inorder [ in ] && pre < n ) ; node = NULL ; while ( st . size ( ) > 0 && in < n && st . top ( ) -> val == inorder [ in ] ) { node = st . top ( ) ; st . pop ( ) ; in ++ ; } if ( node != NULL ) { s . insert ( node ) ; st . push ( node ) ; } } return root ; }
void printInorder ( TreeNode * node ) { if ( node == NULL ) return ;
printInorder ( node -> left ) ;
cout << node -> val << " ▁ " ;
printInorder ( node -> right ) ; }
int main ( ) { int in [ ] = { 9 , 8 , 4 , 2 , 10 , 5 , 10 , 1 , 6 , 3 , 13 , 12 , 7 } ; int pre [ ] = { 1 , 2 , 4 , 8 , 9 , 5 , 10 , 10 , 3 , 6 , 7 , 12 , 13 } ; int len = sizeof ( in ) / sizeof ( int ) ; TreeNode * root = buildTree ( pre , in , len ) ; printInorder ( root ) ; return 0 ; }
struct Node { int data ; struct Node * left , * right ; } ;
Node * newNode ( int data ) { Node * temp = new Node ; temp -> data = data ; temp -> right = temp -> left = NULL ; return temp ; } Node * KthLargestUsingMorrisTraversal ( Node * root , int k ) { Node * curr = root ; Node * Klargest = NULL ;
int count = 0 ; while ( curr != NULL ) {
if ( curr -> right == NULL ) {
if ( ++ count == k ) Klargest = curr ;
curr = curr -> left ; } else {
Node * succ = curr -> right ; while ( succ -> left != NULL && succ -> left != curr ) succ = succ -> left ; if ( succ -> left == NULL ) {
succ -> left = curr ;
curr = curr -> right ; }
else { succ -> left = NULL ; if ( ++ count == k ) Klargest = curr ;
curr = curr -> left ; } } } return Klargest ; } int main ( ) {
Node * root = newNode ( 4 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 7 ) ; root -> left -> left = newNode ( 1 ) ; root -> left -> right = newNode ( 3 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 10 ) ; cout << " Finding ▁ K - th ▁ largest ▁ Node ▁ in ▁ BST ▁ : ▁ " << KthLargestUsingMorrisTraversal ( root , 2 ) -> data ; return 0 ; }
struct Node { int key ; Node * left , * right ; } ;
int KSmallestUsingMorris ( Node * root , int k ) {
int count = 0 ;
int ksmall = INT_MIN ;
Node * curr = root ; while ( curr != NULL ) {
if ( curr -> left == NULL ) { count ++ ;
if ( count == k ) ksmall = curr -> key ;
curr = curr -> right ; } else {
Node * pre = curr -> left ; while ( pre -> right != NULL && pre -> right != curr ) pre = pre -> right ;
if ( pre -> right == NULL ) {
pre -> right = curr ; curr = curr -> left ; }
else {
pre -> right = NULL ; count ++ ;
if ( count == k ) ksmall = curr -> key ; curr = curr -> right ; } } }
return ksmall ; }
Node * newNode ( int item ) { Node * temp = new Node ; temp -> key = item ; temp -> left = temp -> right = NULL ; return temp ; }
Node * insert ( Node * node , int key ) {
if ( node == NULL ) return newNode ( key ) ;
if ( key < node -> key ) node -> left = insert ( node -> left , key ) ; else if ( key > node -> key ) node -> right = insert ( node -> right , key ) ;
return node ; }
Node * root = NULL ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ; for ( int k = 1 ; k <= 7 ; k ++ ) cout << KSmallestUsingMorris ( root , k ) << " ▁ " ; return 0 ; }
bool isInorder ( int arr [ ] , int n ) {
if ( n == 0 n == 1 ) return true ; for ( int i = 1 ; i < n ; i ++ )
if ( arr [ i - 1 ] > arr [ i ] ) return false ;
return true ; }
int main ( ) { int arr [ ] = { 19 , 23 , 25 , 30 , 45 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( isInorder ( arr , n ) ) cout << " Yesn " ; else cout << " Non " ; return 0 ; }
struct Node { int data ; struct Node * left ; struct Node * right ; } ;
Node * newNode ( int val ) { Node * temp = new Node ; temp -> data = val ; temp -> left = temp -> right = NULL ; return temp ; }
void storeInorder ( Node * root , vector < int > & v ) { if ( ! root ) return ; storeInorder ( root -> left , v ) ; v . push_back ( root -> data ) ; storeInorder ( root -> right , v ) ; }
bool checkBSTs ( Node * root1 , Node * root2 ) {
if ( ! root1 && ! root2 ) return true ; if ( ( root1 && ! root2 ) || ( ! root1 && root2 ) ) return false ;
vector < int > v1 , v2 ; storeInorder ( root1 , v1 ) ; storeInorder ( root2 , v2 ) ;
return ( v1 == v2 ) ; }
Node * root1 = newNode ( 15 ) ; root1 -> left = newNode ( 10 ) ; root1 -> right = newNode ( 20 ) ; root1 -> left -> left = newNode ( 5 ) ; root1 -> left -> right = newNode ( 12 ) ; root1 -> right -> right = newNode ( 25 ) ;
Node * root2 = newNode ( 15 ) ; root2 -> left = newNode ( 12 ) ; root2 -> right = newNode ( 20 ) ; root2 -> left -> left = newNode ( 5 ) ; root2 -> left -> left -> right = newNode ( 10 ) ; root2 -> right -> right = newNode ( 25 ) ;
if ( checkBSTs ( root1 , root2 ) ) cout << " YES " ; else cout << " NO " ; return 0 ; }
struct Node { int key ; Node * left , * right ; } ;
Node * newNode ( int item ) { Node * temp = new Node ; temp -> key = item ; temp -> left = temp -> right = NULL ; return temp ; }
Node * insert ( Node * node , int key ) {
if ( node == NULL ) return newNode ( key ) ;
if ( key < node -> key ) node -> left = insert ( node -> left , key ) ; else if ( key > node -> key ) node -> right = insert ( node -> right , key ) ;
return node ; }
int findMaxforN ( Node * root , int N ) {
if ( root == NULL ) return -1 ; if ( root -> key == N ) return N ;
else if ( root -> key < N ) { int k = findMaxforN ( root -> right , N ) ; if ( k == -1 ) return root -> key ; else return k ; }
else if ( root -> key > N ) return findMaxforN ( root -> left , N ) ; }
int main ( ) { int N = 4 ;
Node * root = insert ( root , 25 ) ; insert ( root , 2 ) ; insert ( root , 1 ) ; insert ( root , 3 ) ; insert ( root , 12 ) ; insert ( root , 9 ) ; insert ( root , 21 ) ; insert ( root , 19 ) ; insert ( root , 25 ) ; printf ( " % d " , findMaxforN ( root , N ) ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { struct Node * left , * right ; int key ; } ; struct Node * newNode ( int key ) { struct Node * ptr = new Node ; ptr -> key = key ; ptr -> left = ptr -> right = NULL ; return ptr ; }
struct Node * insert ( struct Node * root , int key ) { if ( ! root ) root = newNode ( key ) ; else if ( root -> key > key ) root -> left = insert ( root -> left , key ) ; else if ( root -> key < key ) root -> right = insert ( root -> right , key ) ; return root ; }
int distanceFromRoot ( struct Node * root , int x ) { if ( root -> key == x ) return 0 ; else if ( root -> key > x ) return 1 + distanceFromRoot ( root -> left , x ) ; return 1 + distanceFromRoot ( root -> right , x ) ; }
int distanceBetween2 ( struct Node * root , int a , int b ) { if ( ! root ) return 0 ;
if ( root -> key > a && root -> key > b ) return distanceBetween2 ( root -> left , a , b ) ;
if ( root -> key < a && root -> key < b ) return distanceBetween2 ( root -> right , a , b ) ;
if ( root -> key >= a && root -> key <= b ) return distanceFromRoot ( root , a ) + distanceFromRoot ( root , b ) ; }
int findDistWrapper ( Node * root , int a , int b ) { if ( a > b ) swap ( a , b ) ; return distanceBetween2 ( root , a , b ) ; }
int main ( ) { struct Node * root = NULL ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; int a = 5 , b = 55 ; cout << findDistWrapper ( root , 5 , 35 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct node { int data ; struct node * left , * right ; } ;
void RangeTraversal ( node * root , int n1 , int n2 ) { if ( ! root ) return ; node * curr = root ; while ( curr ) { if ( curr -> left == NULL ) {
if ( curr -> data <= n2 && curr -> data >= n1 ) { cout << curr -> data << " ▁ " ; } curr = curr -> right ; } else { node * pre = curr -> left ;
while ( pre -> right != NULL && pre -> right != curr ) pre = pre -> right ; if ( pre -> right == NULL ) { pre -> right = curr ; curr = curr -> left ; } else { pre -> right = NULL ;
if ( curr -> data <= n2 && curr -> data >= n1 ) { cout << curr -> data << " ▁ " ; } curr = curr -> right ; } } } }
node * newNode ( int data ) { node * temp = new node ; temp -> data = data ; temp -> right = temp -> left = NULL ; return temp ; }
node * root = newNode ( 4 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 7 ) ; root -> left -> left = newNode ( 1 ) ; root -> left -> right = newNode ( 3 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 10 ) ; RangeTraversal ( root , 4 , 12 ) ; return 0 ; }
struct node { int data ; struct node * left , * right ; } ;
bool inRange ( node * root , int low , int high ) { return root -> data >= low && root -> data <= high ; }
bool getCountUtil ( node * root , int low , int high , int * count ) {
if ( root == NULL ) return true ;
bool l = getCountUtil ( root -> left , low , high , count ) ; bool r = getCountUtil ( root -> right , low , high , count ) ;
if ( l && r && inRange ( root , low , high ) ) { ++ * count ; return true ; } return false ; }
int getCount ( node * root , int low , int high ) { int count = 0 ; getCountUtil ( root , low , high , & count ) ; return count ; }
node * newNode ( int data ) { node * temp = new node ; temp -> data = data ; temp -> left = temp -> right = NULL ; return ( temp ) ; }
node * root = newNode ( 10 ) ; root -> left = newNode ( 5 ) ; root -> right = newNode ( 50 ) ; root -> left -> left = newNode ( 1 ) ; root -> right -> left = newNode ( 40 ) ; root -> right -> right = newNode ( 100 ) ;
int l = 5 ; int h = 45 ; cout << " Count ▁ of ▁ subtrees ▁ in ▁ [ " << l << " , ▁ " << h << " ] ▁ is ▁ " << getCount ( root , l , h ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { int data ; struct Node * left ; struct Node * right ; } ;
struct Node * newNode ( int data ) { struct Node * temp = new Node ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
struct Node * insert ( struct Node * root , int data ) { if ( root == NULL ) return newNode ( data ) ; if ( data < root -> data ) root -> left = insert ( root -> left , data ) ; else if ( data > root -> data ) root -> right = insert ( root -> right , data ) ; return root ; }
void inorder ( struct Node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; cout << root -> data << " ▁ " ; inorder ( root -> right ) ; } }
struct Node * leafDelete ( struct Node * root ) { if ( root == NULL ) return NULL ; if ( root -> left == NULL && root -> right == NULL ) { free ( root ) ; return NULL ; }
root -> left = leafDelete ( root -> left ) ; root -> right = leafDelete ( root -> right ) ; return root ; }
int main ( ) { struct Node * root = NULL ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; cout << " Inorder ▁ before ▁ Deleting ▁ the ▁ leaf ▁ Node . " << endl ; inorder ( root ) ; cout << endl ; leafDelete ( root ) ; cout << " INorder ▁ after ▁ Deleting ▁ the ▁ leaf ▁ Node . " << endl ; inorder ( root ) ; return 0 ; }
struct Node { int data ; Node * left , * right ; } ;
struct Node * createNode ( int data ) { Node * new_Node = new Node ; new_Node -> left = NULL ; new_Node -> right = NULL ; new_Node -> data = data ; return new_Node ; }
struct Node * insert ( Node * root , int key ) {
if ( root == NULL ) return createNode ( key ) ;
if ( root -> data > key ) root -> left = insert ( root -> left , key ) ; else if ( root -> data < key ) root -> right = insert ( root -> right , key ) ;
return root ; }
int ksmallestElementSumRec ( Node * root , int k , int & count ) {
if ( root == NULL ) return 0 ; if ( count > k ) return 0 ;
int res = ksmallestElementSumRec ( root -> left , k , count ) ; if ( count >= k ) return res ;
res += root -> data ;
count ++ ; if ( count >= k ) return res ;
return res + ksmallestElementSumRec ( root -> right , k , count ) ; }
int ksmallestElementSum ( struct Node * root , int k ) { int count = 0 ; ksmallestElementSumRec ( root , k , count ) ; }
Node * root = NULL ; root = insert ( root , 20 ) ; root = insert ( root , 8 ) ; root = insert ( root , 4 ) ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 14 ) ; root = insert ( root , 22 ) ; int k = 3 ; cout << ksmallestElementSum ( root , k ) << endl ; return 0 ; }
struct Node { int key ; struct Node * left , * right ; } ;
void findPreSuc ( Node * root , Node * & pre , Node * & suc , int key ) { if ( root == NULL ) return ;
while ( root != NULL ) {
if ( root -> key == key ) {
if ( root -> right ) { suc = root -> right ; while ( suc -> left ) suc = suc -> left ; }
if ( root -> left ) { pre = root -> left ; while ( pre -> right ) pre = pre -> right ; } return ; }
else if ( root -> key < key ) { pre = root ; root = root -> right ; }
else { suc = root ; root = root -> left ; } } }
Node * newNode ( int item ) { Node * temp = new Node ; temp -> key = item ; temp -> left = temp -> right = NULL ; return temp ; }
Node * insert ( Node * node , int key ) { if ( node == NULL ) return newNode ( key ) ; if ( key < node -> key ) node -> left = insert ( node -> left , key ) ; else node -> right = insert ( node -> right , key ) ; return node ; }
int key = 65 ;
Node * root = NULL ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ; Node * pre = NULL , * suc = NULL ; findPreSuc ( root , pre , suc , key ) ; if ( pre != NULL ) cout << " Predecessor ▁ is ▁ " << pre -> key << endl ; else cout << " - 1" ; if ( suc != NULL ) cout << " Successor ▁ is ▁ " << suc -> key ; else cout << " - 1" ; return 0 ; }
class node { public : int key ; node * left ; node * right ; } ;
void convertBSTtoDLL ( node * root , node * * head , node * * tail ) {
if ( root == NULL ) return ;
if ( root -> left ) convertBSTtoDLL ( root -> left , head , tail ) ;
root -> left = * tail ;
if ( * tail ) ( * tail ) -> right = root ; else * head = root ;
* tail = root ;
if ( root -> right ) convertBSTtoDLL ( root -> right , head , tail ) ; }
bool isPresentInDLL ( node * head , node * tail , int sum ) { while ( head != tail ) { int curr = head -> key + tail -> key ; if ( curr == sum ) return true ; else if ( curr > sum ) tail = tail -> left ; else head = head -> right ; } return false ; }
bool isTripletPresent ( node * root ) {
if ( root == NULL ) return false ;
node * head = NULL ; node * tail = NULL ; convertBSTtoDLL ( root , & head , & tail ) ;
while ( ( head -> right != tail ) && ( head -> key < 0 ) ) {
if ( isPresentInDLL ( head -> right , tail , -1 * head -> key ) ) return true ; else head = head -> right ; }
return false ; }
node * newNode ( int num ) { node * temp = new node ( ) ; temp -> key = num ; temp -> left = temp -> right = NULL ; return temp ; }
node * insert ( node * root , int key ) { if ( root == NULL ) return newNode ( key ) ; if ( root -> key > key ) root -> left = insert ( root -> left , key ) ; else root -> right = insert ( root -> right , key ) ; return root ; }
int main ( ) { node * root = NULL ; root = insert ( root , 6 ) ; root = insert ( root , -13 ) ; root = insert ( root , 14 ) ; root = insert ( root , -8 ) ; root = insert ( root , 15 ) ; root = insert ( root , 13 ) ; root = insert ( root , 7 ) ; if ( isTripletPresent ( root ) ) cout << " Present " ; else cout << " Not ▁ Present " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { struct Node * left , * right ; int data ; } ;
Node * createNode ( int x ) { Node * p = new Node ; p -> data = x ; p -> left = p -> right = NULL ; return p ; }
void insertNode ( struct Node * root , int x ) { Node * p = root , * q = NULL ; while ( p != NULL ) { q = p ; if ( p -> data < x ) p = p -> right ; else p = p -> left ; } if ( q == NULL ) p = createNode ( x ) ; else { if ( q -> data < x ) q -> right = createNode ( x ) ; else q -> left = createNode ( x ) ; } }
int maxelpath ( Node * q , int x ) { Node * p = q ; int mx = INT_MIN ;
while ( p -> data != x ) { if ( p -> data > x ) { mx = max ( mx , p -> data ) ; p = p -> left ; } else { mx = max ( mx , p -> data ) ; p = p -> right ; } } return max ( mx , x ) ; }
int maximumElement ( struct Node * root , int x , int y ) { Node * p = root ;
while ( ( x < p -> data && y < p -> data ) || ( x > p -> data && y > p -> data ) ) {
if ( x < p -> data && y < p -> data ) p = p -> left ;
else if ( x > p -> data && y > p -> data ) p = p -> right ; }
return max ( maxelpath ( p , x ) , maxelpath ( p , y ) ) ; }
int main ( ) { int arr [ ] = { 18 , 36 , 9 , 6 , 12 , 10 , 1 , 8 } ; int a = 1 , b = 10 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
struct Node * root = createNode ( arr [ 0 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) insertNode ( root , arr [ i ] ) ; cout << maximumElement ( root , a , b ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { struct Node * left , * right ; int info ;
bool lthread ;
bool rthread ; } ;
struct Node * insert ( struct Node * root , int ikey ) {
Node * ptr = root ;
Node * par = NULL ; while ( ptr != NULL ) {
if ( ikey == ( ptr -> info ) ) { printf ( " Duplicate ▁ Key ▁ ! STRNEWLINE " ) ; return root ; }
par = ptr ;
if ( ikey < ptr -> info ) { if ( ptr -> lthread == false ) ptr = ptr -> left ; else break ; }
else { if ( ptr -> rthread == false ) ptr = ptr -> right ; else break ; } }
Node * tmp = new Node ; tmp -> info = ikey ; tmp -> lthread = true ; tmp -> rthread = true ; if ( par == NULL ) { root = tmp ; tmp -> left = NULL ; tmp -> right = NULL ; } else if ( ikey < ( par -> info ) ) { tmp -> left = par -> left ; tmp -> right = par ; par -> lthread = false ; par -> left = tmp ; } else { tmp -> left = par ; tmp -> right = par -> right ; par -> rthread = false ; par -> right = tmp ; } return root ; }
struct Node * inorderSuccessor ( struct Node * ptr ) {
if ( ptr -> rthread == true ) return ptr -> right ;
ptr = ptr -> right ; while ( ptr -> lthread == false ) ptr = ptr -> left ; return ptr ; }
void inorder ( struct Node * root ) { if ( root == NULL ) printf ( " Tree ▁ is ▁ empty " ) ;
struct Node * ptr = root ; while ( ptr -> lthread == false ) ptr = ptr -> left ;
while ( ptr != NULL ) { printf ( " % d ▁ " , ptr -> info ) ; ptr = inorderSuccessor ( ptr ) ; } }
int main ( ) { struct Node * root = NULL ; root = insert ( root , 20 ) ; root = insert ( root , 10 ) ; root = insert ( root , 30 ) ; root = insert ( root , 5 ) ; root = insert ( root , 16 ) ; root = insert ( root , 14 ) ; root = insert ( root , 17 ) ; root = insert ( root , 13 ) ; inorder ( root ) ; return 0 ; }
struct Node { struct Node * left , * right ; int info ;
bool lthread ;
bool rthread ; } ;
struct Node { int key ; Node * left , * right ;
bool isThreaded ; } ;
Node * createThreaded ( Node * root ) {
if ( root == NULL ) return NULL ; if ( root -> left == NULL && root -> right == NULL ) return root ;
if ( root -> left != NULL ) {
Node * l = createThreaded ( root -> left ) ;
l -> right = root ; l -> isThreaded = true ; }
if ( root -> right == NULL ) return root ;
return createThreaded ( root -> right ) ; }
Node * leftMost ( Node * root ) { while ( root != NULL && root -> left != NULL ) root = root -> left ; return root ; }
void inOrder ( Node * root ) { if ( root == NULL ) return ;
Node * cur = leftMost ( root ) ; while ( cur != NULL ) { cout << cur -> key << " ▁ " ;
if ( cur -> isThreaded ) cur = cur -> right ;
else cur = leftMost ( cur -> right ) ; } }
Node * newNode ( int key ) { Node * temp = new Node ; temp -> left = temp -> right = NULL ; temp -> key = key ; return temp ; }
Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; createThreaded ( root ) ; cout << " Inorder ▁ traversal ▁ of ▁ created ▁ " " threaded ▁ tree ▁ is STRNEWLINE " ; inOrder ( root ) ; return 0 ; }
struct Node { Node * left , * right , * parent ; int key ; } ;
Node * insert ( Node * node , int key ) {
if ( node == NULL ) return newNode ( key ) ;
if ( key < node -> key ) { node -> left = insert ( node -> left , key ) ; node -> left -> parent = node ; } else if ( key > node -> key ) { node -> right = insert ( node -> right , key ) ; node -> right -> parent = node ; }
return node ; }
void inorder ( Node * root ) { bool leftdone = false ;
while ( root ) {
if ( ! leftdone ) { while ( root -> left ) root = root -> left ; }
printf ( " % d ▁ " , root -> key ) ;
leftdone = true ;
if ( root -> right ) { leftdone = false ; root = root -> right ; }
else if ( root -> parent ) {
while ( root -> parent && root == root -> parent -> right ) root = root -> parent ; if ( ! root -> parent ) break ; root = root -> parent ; } else break ; } }
int main ( void ) { Node * root = NULL ; root = insert ( root , 24 ) ; root = insert ( root , 27 ) ; root = insert ( root , 29 ) ; root = insert ( root , 34 ) ; root = insert ( root , 14 ) ; root = insert ( root , 4 ) ; root = insert ( root , 10 ) ; root = insert ( root , 22 ) ; root = insert ( root , 13 ) ; root = insert ( root , 3 ) ; root = insert ( root , 2 ) ; root = insert ( root , 6 ) ; printf ( " Inorder ▁ traversal ▁ is ▁ STRNEWLINE " ) ; inorder ( root ) ; return 0 ; }
class node { public : int key ; node * left ; node * right ; } ;
int Ceil ( node * root , int input ) {
if ( root == NULL ) return -1 ;
if ( root -> key == input ) return root -> key ;
if ( root -> key < input ) return Ceil ( root -> right , input ) ;
int ceil = Ceil ( root -> left , input ) ; return ( ceil >= input ) ? ceil : root -> key ; }
int main ( ) { node * root = newNode ( 8 ) ; root -> left = newNode ( 4 ) ; root -> right = newNode ( 12 ) ; root -> left -> left = newNode ( 2 ) ; root -> left -> right = newNode ( 6 ) ; root -> right -> left = newNode ( 10 ) ; root -> right -> right = newNode ( 14 ) ; for ( int i = 0 ; i < 16 ; i ++ ) cout << i << " ▁ " << Ceil ( root , i ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct node { int key ; int count ; struct node * left , * right ; } ;
struct node * newNode ( int item ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> key = item ; temp -> left = temp -> right = NULL ; temp -> count = 1 ; return temp ; }
void inorder ( struct node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; cout << root -> key << " ( " << root -> count << " ) ▁ " ; inorder ( root -> right ) ; } }
struct node * insert ( struct node * node , int key ) {
if ( node == NULL ) return newNode ( key ) ;
if ( key == node -> key ) { ( node -> count ) ++ ; return node ; }
if ( key < node -> key ) node -> left = insert ( node -> left , key ) ; else node -> right = insert ( node -> right , key ) ;
return node ; }
struct node * minValueNode ( struct node * node ) { struct node * current = node ;
while ( current -> left != NULL ) current = current -> left ; return current ; }
struct node * deleteNode ( struct node * root , int key ) {
if ( root == NULL ) return root ;
if ( key < root -> key ) root -> left = deleteNode ( root -> left , key ) ;
else if ( key > root -> key ) root -> right = deleteNode ( root -> right , key ) ;
else {
if ( root -> count > 1 ) { ( root -> count ) -- ; return root ; }
if ( root -> left == NULL ) { struct node * temp = root -> right ; free ( root ) ; return temp ; } else if ( root -> right == NULL ) { struct node * temp = root -> left ; free ( root ) ; return temp ; }
struct node * temp = minValueNode ( root -> right ) ;
root -> key = temp -> key ;
root -> right = deleteNode ( root -> right , temp -> key ) ; } return root ; }
struct node * root = NULL ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 20 ) ; root = insert ( root , 9 ) ; root = insert ( root , 11 ) ; root = insert ( root , 10 ) ; root = insert ( root , 12 ) ; root = insert ( root , 12 ) ; cout << " Inorder ▁ traversal ▁ of ▁ the ▁ given ▁ tree ▁ " << endl ; inorder ( root ) ; cout << " Delete 20 " root = deleteNode ( root , 20 ) ; cout << " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ STRNEWLINE " ; inorder ( root ) ; cout << " Delete 12 " root = deleteNode ( root , 12 ) ; cout << " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ STRNEWLINE " ; inorder ( root ) ; cout << " Delete 9 " root = deleteNode ( root , 9 ) ; cout << " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ STRNEWLINE " ; inorder ( root ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; class node { public : int key ; node * left , * right ; } ;
node * newNode ( int item ) { node * temp = new node ; temp -> key = item ; temp -> left = temp -> right = NULL ; return temp ; }
void inorder ( node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; cout << root -> key << " ▁ " ; inorder ( root -> right ) ; } }
node * insert ( node * node , int key ) {
if ( node == NULL ) return newNode ( key ) ;
if ( key < node -> key ) node -> left = insert ( node -> left , key ) ; else node -> right = insert ( node -> right , key ) ;
return node ; }
node * minValueNode ( node * Node ) { node * current = Node ;
while ( current -> left != NULL ) current = current -> left ; return current ; }
node * deleteNode ( node * root , int key ) {
if ( root == NULL ) return root ;
if ( key < root -> key ) root -> left = deleteNode ( root -> left , key ) ;
else if ( key > root -> key ) root -> right = deleteNode ( root -> right , key ) ;
else {
if ( root -> left == NULL ) { node * temp = root -> right ; free ( root ) ; return temp ; } else if ( root -> right == NULL ) { node * temp = root -> left ; free ( root ) ; return temp ; }
node * temp = minValueNode ( root -> right ) ;
root -> key = temp -> key ;
root -> right = deleteNode ( root -> right , temp -> key ) ; } return root ; }
node * changeKey ( node * root , int oldVal , int newVal ) {
root = deleteNode ( root , oldVal ) ;
root = insert ( root , newVal ) ;
return root ; }
node * root = NULL ; root = insert ( root , 50 ) ; root = insert ( root , 30 ) ; root = insert ( root , 20 ) ; root = insert ( root , 40 ) ; root = insert ( root , 70 ) ; root = insert ( root , 60 ) ; root = insert ( root , 80 ) ; cout << " Inorder ▁ traversal ▁ of ▁ the ▁ given ▁ tree ▁ STRNEWLINE " ; inorder ( root ) ; root = changeKey ( root , 40 , 10 ) ;
cout << " Inorder traversal of the modified tree " ; inorder ( root ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
bool isLeaf ( int pre [ ] , int & i , int n , int min , int max ) { if ( i >= n ) return false ; if ( pre [ i ] > min && pre [ i ] < max ) { i ++ ; bool left = isLeaf ( pre , i , n , min , pre [ i - 1 ] ) ; bool right = isLeaf ( pre , i , n , pre [ i - 1 ] , max ) ; if ( ! left && ! right ) cout << pre [ i - 1 ] << " ▁ " ; return true ; } return false ; } void printLeaves ( int preorder [ ] , int n ) { int i = 0 ; isLeaf ( preorder , i , n , INT_MIN , INT_MAX ) ; }
int main ( ) { int preorder [ ] = { 890 , 325 , 290 , 530 , 965 } ; int n = sizeof ( preorder ) / sizeof ( preorder [ 0 ] ) ; printLeaves ( preorder , n ) ; return 0 ; }
struct Node { int key ; struct Node * left , * right , * parent ; } ;
struct Node * newNode ( int item ) { struct Node * temp = new Node ; temp -> key = item ; temp -> left = temp -> right = NULL ; temp -> parent = NULL ; return temp ; }
void inorder ( struct Node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; printf ( " Node ▁ : ▁ % d , ▁ " , root -> key ) ; if ( root -> parent == NULL ) printf ( " Parent ▁ : ▁ NULL ▁ STRNEWLINE " ) ; else printf ( " Parent ▁ : ▁ % d ▁ STRNEWLINE " , root -> parent -> key ) ; inorder ( root -> right ) ; } }
struct Node * insert ( struct Node * node , int key ) {
if ( node == NULL ) return newNode ( key ) ;
if ( key < node -> key ) { Node * lchild = insert ( node -> left , key ) ; node -> left = lchild ;
lchild -> parent = node ; } else if ( key > node -> key ) { Node * rchild = insert ( node -> right , key ) ; node -> right = rchild ;
rchild -> parent = node ; }
return node ; }
struct Node * root = NULL ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ;
inorder ( root ) ; return 0 ; }
void pairs ( int arr [ ] , int n , int k ) {
int smallest = INT_MAX ; int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
if ( abs ( arr [ i ] + arr [ j ] - k ) < smallest ) { smallest = abs ( arr [ i ] + arr [ j ] - k ) ; count = 1 ; }
else if ( abs ( arr [ i ] + arr [ j ] - k ) == smallest ) count ++ ; }
cout << " Minimal ▁ Value ▁ = ▁ " << smallest << " STRNEWLINE " ; cout << " Total ▁ Pairs ▁ = ▁ " << count << " STRNEWLINE " ; }
int main ( ) { int arr [ ] = { 3 , 5 , 7 , 5 , 1 , 9 , 9 } ; int k = 12 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; pairs ( arr , n , k ) ; return 0 ; }
int main ( ) { int a [ ] = { 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 } ; int key = 20 ; int arraySize = sizeof ( a ) / sizeof ( a [ 0 ] ) ; int count = 0 ; for ( int i = 0 ; i < arraySize ; i ++ ) { if ( a [ i ] <= key ) { count += 1 ; } } cout << " Rank ▁ of ▁ " << key << " ▁ in ▁ stream ▁ is : ▁ " << count - 1 << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX_SIZE  10
void sortByRow ( int mat [ ] [ MAX_SIZE ] , int n , bool ascending ) { for ( int i = 0 ; i < n ; i ++ ) { if ( ascending ) sort ( mat [ i ] , mat [ i ] + n ) ; else sort ( mat [ i ] , mat [ i ] + n , greater < int > ( ) ) ; } }
void transpose ( int mat [ ] [ MAX_SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ )
swap ( mat [ i ] [ j ] , mat [ j ] [ i ] ) ; }
void sortMatRowAndColWise ( int mat [ ] [ MAX_SIZE ] , int n ) {
sortByRow ( mat , n , true ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n , false ) ;
transpose ( mat , n ) ; }
void printMat ( int mat [ ] [ MAX_SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << mat [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int n = 3 ; int mat [ n ] [ MAX_SIZE ] = { { 3 , 2 , 1 } , { 9 , 8 , 7 } , { 6 , 5 , 4 } } ; cout << " Original ▁ Matrix : STRNEWLINE " ; printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; cout << " Matrix After Sorting : " ; printMat ( mat , n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 100 ; void middlesum ( int mat [ ] [ MAX ] , int n ) { int row_sum = 0 , col_sum = 0 ;
for ( int i = 0 ; i < n ; i ++ ) row_sum += mat [ n / 2 ] [ i ] ; cout << " Sum ▁ of ▁ middle ▁ row ▁ = ▁ " << row_sum << endl ;
for ( int i = 0 ; i < n ; i ++ ) col_sum += mat [ i ] [ n / 2 ] ; cout << " Sum ▁ of ▁ middle ▁ column ▁ = ▁ " << col_sum ; }
int main ( ) { int mat [ ] [ MAX ] = { { 2 , 5 , 7 } , { 3 , 7 , 2 } , { 5 , 6 , 9 } } ; middlesum ( mat , 3 ) ; return 0 ; }
#define M  3 NEW_LINE #define N  3 NEW_LINE using namespace std ;
void rotateMatrix ( int matrix [ ] [ M ] , int k ) {
int temp [ M ] ;
k = k % M ; for ( int i = 0 ; i < N ; i ++ ) {
for ( int t = 0 ; t < M - k ; t ++ ) temp [ t ] = matrix [ i ] [ t ] ;
for ( int j = M - k ; j < M ; j ++ ) matrix [ i ] [ j - M + k ] = matrix [ i ] [ j ] ;
for ( int j = k ; j < M ; j ++ ) matrix [ i ] [ j ] = temp [ j - k ] ; } }
void displayMatrix ( int matrix [ ] [ M ] ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) cout << matrix [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int matrix [ N ] [ M ] = { { 12 , 23 , 34 } , { 45 , 56 , 67 } , { 78 , 89 , 91 } } ; int k = 2 ;
rotateMatrix ( matrix , k ) ;
displayMatrix ( matrix ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; #define n  4 NEW_LINE void interchangeFirstLast ( int m [ ] [ n ] ) { int rows = n ;
for ( int i = 0 ; i < n ; i ++ ) { int t = m [ 0 ] [ i ] ; m [ 0 ] [ i ] = m [ rows - 1 ] [ i ] ; m [ rows - 1 ] [ i ] = t ; } }
int m [ n ] [ n ] = { { 8 , 9 , 7 , 6 } , { 4 , 7 , 6 , 5 } , { 3 , 2 , 1 , 8 } , { 9 , 9 , 7 , 7 } } ; interchangeFirstLast ( m ) ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << m [ i ] [ j ] << " ▁ " ; cout << endl ; } }
struct Node { int data ; Node * left , * right ; } ;
Node * buildUtil ( int in [ ] , int post [ ] , int inStrt , int inEnd , int * pIndex ) {
if ( inStrt > inEnd ) return NULL ;
Node * node = newNode ( post [ * pIndex ] ) ; ( * pIndex ) -- ;
if ( inStrt == inEnd ) return node ;
int iIndex = search ( in , inStrt , inEnd , node -> data ) ;
node -> right = buildUtil ( in , post , iIndex + 1 , inEnd , pIndex ) ; node -> left = buildUtil ( in , post , inStrt , iIndex - 1 , pIndex ) ; return node ; }
int search ( int arr [ ] , int strt , int end , int value ) { int i ; for ( i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) break ; } return i ; }
void preOrder ( Node * node ) { if ( node == NULL ) return ; printf ( " % d ▁ " , node -> data ) ; preOrder ( node -> left ) ; preOrder ( node -> right ) ; }
int main ( ) { int in [ ] = { 4 , 8 , 2 , 5 , 1 , 6 , 3 , 7 } ; int post [ ] = { 8 , 4 , 5 , 2 , 6 , 7 , 3 , 1 } ; int n = sizeof ( in ) / sizeof ( in [ 0 ] ) ; Node * root = buildTree ( in , post , n ) ; cout << " Preorder ▁ of ▁ the ▁ constructed ▁ tree ▁ : ▁ STRNEWLINE " ; preOrder ( root ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; void sortRowWise ( int m [ ] [ 4 ] , int r , int c ) {
for ( int i = 0 ; i < r ; i ++ ) {
for ( int j = 0 ; j < c ; j ++ ) {
for ( int k = 0 ; k < c - j - 1 ; k ++ ) { if ( m [ i ] [ k ] > m [ i ] [ k + 1 ] ) {
swap ( m [ i ] [ k ] , m [ i ] [ k + 1 ] ) ; } } } }
for ( int i = 0 ; i < r ; i ++ ) { for ( int j = 0 ; j < c ; j ++ ) cout << m [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int m [ ] [ 4 ] = { { 9 , 8 , 7 , 1 } , { 7 , 3 , 0 , 2 } , { 9 , 5 , 3 , 2 } , { 6 , 3 , 1 , 2 } } ; int r = sizeof ( m [ 0 ] ) / sizeof ( m [ 0 ] [ 0 ] ) ; int c = sizeof ( m ) / sizeof ( m [ 0 ] ) ; sortRowWise ( m , r , c ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; #define n  3 NEW_LINE bool checkMarkov ( double m [ ] [ n ] ) {
for ( int i = 0 ; i < n ; i ++ ) {
double sum = 0 ; for ( int j = 0 ; j < n ; j ++ ) sum = sum + m [ i ] [ j ] ; if ( sum != 1 ) return false ; } return true ; }
double m [ 3 ] [ 3 ] = { { 0 , 0 , 1 } , { 0.5 , 0 , 0.5 } , { 1 , 0 , 0 } } ;
if ( checkMarkov ( m ) ) cout << " ▁ yes ▁ " ; else cout << " ▁ no ▁ " ; }
#include <bits/stdc++.h> NEW_LINE #define N  4 NEW_LINE using namespace std ;
bool isDiagonalMatrix ( int mat [ N ] [ N ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ )
if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ; return true ; }
int main ( ) { int mat [ N ] [ N ] = { { 4 , 0 , 0 , 0 } , { 0 , 7 , 0 , 0 } , { 0 , 0 , 5 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isDiagonalMatrix ( mat ) ) cout << " Yes " << endl ; else cout << " No " << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  4 NEW_LINE using namespace std ;
bool isScalarMatrix ( int mat [ N ] [ N ] ) {
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ;
for ( int i = 0 ; i < N - 1 ; i ++ ) if ( mat [ i ] [ i ] != mat [ i + 1 ] [ i + 1 ] ) return false ; return true ; }
int main ( ) { int mat [ N ] [ N ] = { { 2 , 0 , 0 , 0 } , { 0 , 2 , 0 , 0 } , { 0 , 0 , 2 , 0 } , { 0 , 0 , 0 , 2 } } ;
if ( isScalarMatrix ( mat ) ) cout << " Yes " << endl ; else cout << " No " << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX_SIZE  10
void sortByRow ( int mat [ MAX_SIZE ] [ MAX_SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ )
sort ( mat [ i ] , mat [ i ] + n ) ; }
void transpose ( int mat [ MAX_SIZE ] [ MAX_SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ )
swap ( mat [ i ] [ j ] , mat [ j ] [ i ] ) ; }
void sortMatRowAndColWise ( int mat [ MAX_SIZE ] [ MAX_SIZE ] , int n ) {
sortByRow ( mat , n ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n ) ;
transpose ( mat , n ) ; }
void printMat ( int mat [ MAX_SIZE ] [ MAX_SIZE ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << mat [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int mat [ MAX_SIZE ] [ MAX_SIZE ] = { { 4 , 1 , 3 } , { 9 , 6 , 8 } , { 5 , 2 , 7 } } ; int n = 3 ; cout << " Original ▁ Matrix : STRNEWLINE " ; printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; cout << " Matrix After Sorting : " ; printMat ( mat , n ) ; return 0 ; }
void doublyEven ( int n ) { int arr [ n ] [ n ] , i , j ;
for ( i = 0 ; i < n ; i ++ ) for ( j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * i ) + j + 1 ;
for ( i = 0 ; i < n / 4 ; i ++ ) for ( j = 0 ; j < n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < n / 4 ; i ++ ) for ( j = 3 * ( n / 4 ) ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * n / 4 ; i < n ; i ++ ) for ( j = 0 ; j < n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * n / 4 ; i < n ; i ++ ) for ( j = 3 * n / 4 ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = n / 4 ; i < 3 * n / 4 ; i ++ ) for ( j = n / 4 ; j < 3 * n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) cout << arr [ i ] [ j ] << " ▁ " ; cout << " STRNEWLINE " ; } }
int main ( ) { int n = 8 ;
doublyEven ( n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  3 NEW_LINE using namespace std ;
bool isMagicSquare ( int mat [ ] [ N ] ) {
int sum = 0 , sum2 = 0 ; for ( int i = 0 ; i < N ; i ++ ) sum = sum + mat [ i ] [ i ] ;
for ( int i = 0 ; i < N ; i ++ ) sum2 = sum2 + mat [ i ] [ N - 1 - i ] ; if ( sum != sum2 ) return false ;
for ( int i = 0 ; i < N ; i ++ ) { int rowSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) rowSum += mat [ i ] [ j ] ;
if ( rowSum != sum ) return false ; }
for ( int i = 0 ; i < N ; i ++ ) { int colSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) colSum += mat [ j ] [ i ] ;
if ( sum != colSum ) return false ; } return true ; }
int main ( ) { int mat [ ] [ N ] = { { 2 , 7 , 6 } , { 9 , 5 , 1 } , { 4 , 3 , 8 } } ; if ( isMagicSquare ( mat ) ) cout << " Magic ▁ Square " ; else cout << " Not ▁ a ▁ magic ▁ Square " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define SIZE  10
int subCount ( int arr [ ] , int n , int k ) {
int mod [ k ] ; memset ( mod , 0 , sizeof ( mod ) ) ;
int cumSum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { cumSum += arr [ i ] ;
mod [ ( ( cumSum % k ) + k ) % k ] ++ ; }
int result = 0 ;
for ( int i = 0 ; i < k ; i ++ )
if ( mod [ i ] > 1 ) result += ( mod [ i ] * ( mod [ i ] - 1 ) ) / 2 ;
result += mod [ 0 ] ; return result ; }
int countSubmatrix ( int mat [ SIZE ] [ SIZE ] , int n , int k ) {
int tot_count = 0 ; int left , right , i ; int temp [ n ] ;
for ( left = 0 ; left < n ; left ++ ) {
memset ( temp , 0 , sizeof ( temp ) ) ;
for ( right = left ; right < n ; right ++ ) {
for ( i = 0 ; i < n ; ++ i ) temp [ i ] += mat [ i ] [ right ] ;
tot_count += subCount ( temp , n , k ) ; } }
return tot_count ; }
int main ( ) { int mat [ ] [ SIZE ] = { { 5 , -1 , 6 } , { -2 , 3 , 8 } , { 7 , 4 , -9 } } ; int n = 3 , k = 4 ; cout << " Count ▁ = ▁ " << countSubmatrix ( mat , n , k ) ; return 0 ; }
int findMinOpeartion ( int matrix [ ] [ 2 ] , int n ) {
int sumRow [ n ] , sumCol [ n ] ; memset ( sumRow , 0 , sizeof ( sumRow ) ) ; memset ( sumCol , 0 , sizeof ( sumCol ) ) ;
for ( int i = 0 ; i < n ; ++ i ) for ( int j = 0 ; j < n ; ++ j ) { sumRow [ i ] += matrix [ i ] [ j ] ; sumCol [ j ] += matrix [ i ] [ j ] ; }
int maxSum = 0 ; for ( int i = 0 ; i < n ; ++ i ) { maxSum = max ( maxSum , sumRow [ i ] ) ; maxSum = max ( maxSum , sumCol [ i ] ) ; } int count = 0 ; for ( int i = 0 , j = 0 ; i < n && j < n ; ) {
int diff = min ( maxSum - sumRow [ i ] , maxSum - sumCol [ j ] ) ;
matrix [ i ] [ j ] += diff ; sumRow [ i ] += diff ; sumCol [ j ] += diff ;
count += diff ;
if ( sumRow [ i ] == maxSum ) ++ i ;
if ( sumCol [ j ] == maxSum ) ++ j ; } return count ; }
void printMatrix ( int matrix [ ] [ 2 ] , int n ) { for ( int i = 0 ; i < n ; ++ i ) { for ( int j = 0 ; j < n ; ++ j ) cout << matrix [ i ] [ j ] << " ▁ " ; cout << " STRNEWLINE " ; } }
int main ( ) { int matrix [ ] [ 2 ] = { { 1 , 2 } , { 3 , 4 } } ; cout << findMinOpeartion ( matrix , 2 ) << " STRNEWLINE " ; printMatrix ( matrix , 2 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int find ( int n , int k ) { if ( n + 1 >= k ) return ( k - 1 ) ; else return ( 2 * n + 1 - k ) ; }
int main ( ) { int n = 4 , k = 7 ; int freq = find ( n , k ) ; if ( freq < 0 ) cout << " ▁ element ▁ not ▁ exist ▁ STRNEWLINE ▁ " ; else cout << " ▁ Frequency ▁ of ▁ " << k << " ▁ is ▁ " << freq << " STRNEWLINE " ; return 0 ; }
void ZigZag ( int rows , int columns , int numbers [ ] ) { int k = 0 ;
int arr [ rows ] [ columns ] ; for ( int i = 0 ; i < rows ; i ++ ) {
if ( i % 2 == 0 ) {
for ( int j = 0 ; j < columns and numbers [ k ] > 0 ; j ++ ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } }
else {
for ( int j = columns - 1 ; j >= 0 and numbers [ k ] > 0 ; j -- ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } } }
for ( int i = 0 ; i < rows ; i ++ ) { for ( int j = 0 ; j < columns ; j ++ ) cout << arr [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int rows = 4 ; int columns = 5 ; int Numbers [ ] = { 3 , 4 , 2 , 2 , 3 , 1 , 5 } ; ZigZag ( rows , columns , Numbers ) ; return 0 ; }
int numberofPosition ( int n , int k , int x , int y , int obstPosx [ ] , int obstPosy [ ] ) {
int d11 , d12 , d21 , d22 , r1 , r2 , c1 , c2 ;
d11 = min ( x - 1 , y - 1 ) ; d12 = min ( n - x , n - y ) ; d21 = min ( n - x , y - 1 ) ; d22 = min ( x - 1 , n - y ) ; r1 = y - 1 ; r2 = n - y ; c1 = x - 1 ; c2 = n - x ;
for ( int i = 0 ; i < k ; i ++ ) { if ( x > obstPosx [ i ] && y > obstPosy [ i ] && x - obstPosx [ i ] == y - obstPosy [ i ] ) d11 = min ( d11 , x - obstPosx [ i ] - 1 ) ; if ( obstPosx [ i ] > x && obstPosy [ i ] > y && obstPosx [ i ] - x == obstPosy [ i ] - y ) d12 = min ( d12 , obstPosx [ i ] - x - 1 ) ; if ( obstPosx [ i ] > x && y > obstPosy [ i ] && obstPosx [ i ] - x == y - obstPosy [ i ] ) d21 = min ( d21 , obstPosx [ i ] - x - 1 ) ; if ( x > obstPosx [ i ] && obstPosy [ i ] > y && x - obstPosx [ i ] == obstPosy [ i ] - y ) d22 = min ( d22 , x - obstPosx [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] < y ) r1 = min ( r1 , y - obstPosy [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] > y ) r2 = min ( r2 , obstPosy [ i ] - y - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] < x ) c1 = min ( c1 , x - obstPosx [ i ] - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] > x ) c2 = min ( c2 , obstPosx [ i ] - x - 1 ) ; } return d11 + d12 + d21 + d22 + r1 + r2 + c1 + c2 ; }
int n = 8 ;
int k = 1 ;
int Qposx = 4 ;
int Qposy = 4 ;
int obstPosx [ ] = { 3 } ;
int obstPosy [ ] = { 5 } ; cout << numberofPosition ( n , k , Qposx , Qposy , obstPosx , obstPosy ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int n = 5 ;
int FindMaxProduct ( int arr [ ] [ n ] , int n ) { int max = 0 , result ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = 0 ; j < n ; j ++ ) {
if ( ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i ] [ j - 1 ] * arr [ i ] [ j - 2 ] * arr [ i ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j ] * arr [ i - 2 ] [ j ] * arr [ i - 3 ] [ j ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j - 1 ] * arr [ i - 2 ] [ j - 2 ] * arr [ i - 3 ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 1 ) <= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j + 1 ] * arr [ i - 2 ] [ j + 2 ] * arr [ i - 3 ] [ j + 3 ] ; if ( max < result ) max = result ; } } } return max ; }
int main ( ) { int arr [ ] [ 5 ] = { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 1 } , { 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 1 , 0 } , { 9 , 6 , 4 , 2 , 3 } } ; cout << FindMaxProduct ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int maxPro ( int a [ 6 ] [ 5 ] , int n , int m , int k ) { int maxi ( 1 ) , mp ( 1 ) ; for ( int i = 0 ; i < n ; ++ i ) {
int wp ( 1 ) ; for ( int l = 0 ; l < k ; ++ l ) { wp *= a [ i ] [ l ] ; }
mp = wp ; for ( int j = k ; j < m ; ++ j ) { wp = wp * a [ i ] [ j ] / a [ i ] [ j - k ] ;
maxi = max ( maxi , max ( mp , wp ) ) ; } } return maxi ; }
int main ( ) { int n = 6 , m = 5 , k = 4 ; int a [ 6 ] [ 5 ] = { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 1 } , { 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 1 , 0 } , { 9 , 6 , 4 , 2 , 3 } , { 1 , 1 , 2 , 1 , 1 } } ;
cout << maxPro ( a , n , m , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  3 NEW_LINE using namespace std ;
int minimumflip ( int mat [ ] [ N ] , int n ) { int transpose [ n ] [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) transpose [ i ] [ j ] = mat [ j ] [ i ] ;
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( transpose [ i ] [ j ] != mat [ i ] [ j ] ) flip ++ ; return flip / 2 ; }
int main ( ) { int n = 3 ; int mat [ N ] [ N ] = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; cout << minimumflip ( mat , n ) << endl ; return 0 ; }
int minimumflip ( int mat [ ] [ N ] , int n ) {
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) flip ++ ; return flip ; }
int main ( ) { int n = 3 ; int mat [ N ] [ N ] = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; cout << minimumflip ( mat , n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  4 NEW_LINE using namespace std ;
bool isLowerTriangularMatrix ( int mat [ N ] [ N ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 0 , 0 , 0 } , { 1 , 4 , 0 , 0 } , { 4 , 6 , 2 , 0 } , { 0 , 4 , 7 , 6 } } ;
if ( isLowerTriangularMatrix ( mat ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  4 NEW_LINE using namespace std ;
bool isUpperTriangularMatrix ( int mat [ N ] [ N ] ) { for ( int i = 1 ; i < N ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 3 , 5 , 3 } , { 0 , 4 , 6 , 2 } , { 0 , 0 , 2 , 5 } , { 0 , 0 , 0 , 6 } } ; if ( isUpperTriangularMatrix ( mat ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  100
void freq ( int ar [ ] [ MAX ] , int m , int n ) { int even = 0 , odd = 0 ; for ( int i = 0 ; i < m ; ++ i ) { for ( int j = 0 ; j < n ; ++ j ) {
if ( ( ar [ i ] [ j ] % 2 ) == 0 ) ++ even ; else ++ odd ; } }
printf ( " ▁ Frequency ▁ of ▁ odd ▁ number ▁ = ▁ % d ▁ STRNEWLINE " , odd ) ; printf ( " ▁ Frequency ▁ of ▁ even ▁ number ▁ = ▁ % d ▁ STRNEWLINE " , even ) ; }
int main ( ) { int m = 3 , n = 3 ; int array [ ] [ MAX ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; freq ( array , m , n ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ;
bool HalfDiagonalSums ( int mat [ ] [ MAX ] , int n ) {
int diag1_left = 0 , diag1_right = 0 ; int diag2_left = 0 , diag2_right = 0 ; for ( int i = 0 , j = n - 1 ; i < n ; i ++ , j -- ) { if ( i < n / 2 ) { diag1_left += mat [ i ] [ i ] ; diag2_left += mat [ j ] [ i ] ; } else if ( i > n / 2 ) { diag1_right += mat [ i ] [ i ] ; diag2_right += mat [ j ] [ i ] ; } } return ( diag1_left == diag2_right && diag2_right == diag2_left && diag1_right == diag2_left && diag2_right == mat [ n / 2 ] [ n / 2 ] ) ; }
int main ( ) { int a [ ] [ MAX ] = { { 2 , 9 , 1 , 4 , -2 } , { 6 , 7 , 2 , 11 , 4 } , { 4 , 2 , 9 , 2 , 4 } , { 1 , 9 , 2 , 4 , 4 } , { 0 , 2 , 4 , 2 , 5 } } ; cout << ( HalfDiagonalSums ( a , 5 ) ? " Yes " : " No " ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 100 ; bool isIdentity ( int mat [ ] [ MAX ] , int N ) { for ( int row = 0 ; row < N ; row ++ ) { for ( int col = 0 ; col < N ; col ++ ) { if ( row == col && mat [ row ] [ col ] != 1 ) return false ; else if ( row != col && mat [ row ] [ col ] != 0 ) return false ; } } return true ; }
int main ( ) { int N = 4 ; int mat [ ] [ MAX ] = { { 1 , 0 , 0 , 0 } , { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isIdentity ( mat , N ) ) cout << " Yes ▁ " ; else cout << " No ▁ " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define mod  100000007
long long modPower ( long long a , long long t ) { long long now = a , ret = 1 ;
while ( t ) { if ( t & 1 ) ret = now * ( ret % mod ) ; now = now * ( now % mod ) ; t >>= 1 ; } return ret ; }
long countWays ( int n , int m , int k ) {
if ( k == -1 && ( n + m ) % 2 == 1 ) return 0 ;
if ( n == 1 m == 1 ) return 1 ;
return ( modPower ( modPower ( ( long long ) 2 , n - 1 ) , m - 1 ) % mod ) ; }
int main ( ) { int n = 2 , m = 7 , k = 1 ; cout << countWays ( n , m , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; void imageSwap ( int mat [ ] [ MAX ] , int n ) {
int row = 0 ;
for ( int j = 0 ; j < n ; j ++ ) {
stack < int > s ; int i = row , k = j ; while ( i < n && k >= 0 ) s . push ( mat [ i ++ ] [ k -- ] ) ;
i = row , k = j ; while ( i < n && k >= 0 ) { mat [ i ++ ] [ k -- ] = s . top ( ) ; s . pop ( ) ; } }
int column = n - 1 ; for ( int j = 1 ; j < n ; j ++ ) {
stack < int > s ; int i = j , k = column ; while ( i < n && k >= 0 ) s . push ( mat [ i ++ ] [ k -- ] ) ;
i = j ; k = column ; while ( i < n && k >= 0 ) { mat [ i ++ ] [ k -- ] = s . top ( ) ; s . pop ( ) ; } } }
void printMatrix ( int mat [ ] [ MAX ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << mat [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; int n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; void imageSwap ( int mat [ ] [ MAX ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j <= i ; j ++ ) mat [ i ] [ j ] = mat [ i ] [ j ] + mat [ j ] [ i ] - ( mat [ j ] [ i ] = mat [ i ] [ j ] ) ; }
void printMatrix ( int mat [ ] [ MAX ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << mat [ i ] [ j ] << " ▁ " ; cout << endl ; } }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; int n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ; return 0 ; }
const int m = 3 ;
const int n = 2 ;
long long countSets ( int a [ n ] [ m ] ) {
long long res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < m ; j ++ ) a [ i ] [ j ] ? u ++ : v ++ ; res += pow ( 2 , u ) - 1 + pow ( 2 , v ) - 1 ; }
for ( int i = 0 ; i < m ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < n ; j ++ ) a [ j ] [ i ] ? u ++ : v ++ ; res += pow ( 2 , u ) - 1 + pow ( 2 , v ) - 1 ; }
return res - ( n * m ) ; }
int main ( ) { int a [ ] [ 3 ] = { ( 1 , 0 , 1 ) , ( 0 , 1 , 0 ) } ; cout << countSets ( a ) ; return 0 ; }
int search ( int mat [ 4 ] [ 4 ] , int n , int x ) { if ( n == 0 ) return -1 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ )
if ( mat [ i ] [ j ] == x ) { cout << " Element ▁ found ▁ at ▁ ( " << i << " , ▁ " << j << " ) STRNEWLINE " ; return 1 ; } } cout << " n ▁ Element ▁ not ▁ found " ; return 0 ; }
int main ( ) { int mat [ 4 ] [ 4 ] = { { 10 , 20 , 30 , 40 } , { 15 , 25 , 35 , 45 } , { 27 , 29 , 37 , 48 } , { 32 , 33 , 39 , 50 } } ; search ( mat , 4 , 29 ) ; return 0 ; }
Node * newNode ( int data ) { Node * newNode = new Node ; newNode -> next = newNode -> child = NULL ; newNode -> data = data ; return newNode ; }
Node * addSibling ( Node * n , int data ) { if ( n == NULL ) return NULL ; while ( n -> next ) n = n -> next ; return ( n -> next = newNode ( data ) ) ; }
Node * addChild ( Node * n , int data ) { if ( n == NULL ) return NULL ;
if ( n -> child ) return addSibling ( n -> child , data ) ; else return ( n -> child = newNode ( data ) ) ; }
void traverseTree ( Node * root ) { if ( root == NULL ) return ; while ( root ) { cout << " ▁ " << root -> data ; if ( root -> child ) traverseTree ( root -> child ) ; root = root -> next ; } }
int main ( ) { Node * root = newNode ( 10 ) ; Node * n1 = addChild ( root , 2 ) ; Node * n2 = addChild ( root , 3 ) ; Node * n3 = addChild ( root , 4 ) ; Node * n4 = addChild ( n3 , 6 ) ; Node * n5 = addChild ( root , 5 ) ; Node * n6 = addChild ( n5 , 7 ) ; Node * n7 = addChild ( n5 , 8 ) ; Node * n8 = addChild ( n5 , 9 ) ; traverseTree ( root ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define SIZE  100
int calculateEnergy ( int mat [ SIZE ] [ SIZE ] , int n ) { int i_des , j_des , q ; int tot_energy = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
q = mat [ i ] [ j ] / n ;
i_des = q ; j_des = mat [ i ] [ j ] - ( n * q ) ;
tot_energy += abs ( i_des - i ) + abs ( j_des - j ) ; } }
return tot_energy ; }
int main ( ) { int mat [ SIZE ] [ SIZE ] = { { 4 , 7 , 0 , 3 } , { 8 , 5 , 6 , 1 } , { 9 , 11 , 10 , 2 } , { 15 , 13 , 14 , 12 } } ; int n = 4 ; cout << " Total ▁ energy ▁ required ▁ = ▁ " << calculateEnergy ( mat , n ) << " ▁ units " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ;
bool isUnique ( int mat [ ] [ MAX ] , int i , int j , int n , int m ) {
int sumrow = 0 ; for ( int k = 0 ; k < m ; k ++ ) { sumrow += mat [ i ] [ k ] ; if ( sumrow > 1 ) return false ; }
int sumcol = 0 ; for ( int k = 0 ; k < n ; k ++ ) { sumcol += mat [ k ] [ j ] ; if ( sumcol > 1 ) return false ; } return true ; } int countUnique ( int mat [ ] [ MAX ] , int n , int m ) { int uniquecount = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] && isUnique ( mat , i , j , n , m ) ) uniquecount ++ ; return uniquecount ; }
int main ( ) { int mat [ ] [ MAX ] = { { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 1 , 0 , 0 , 1 } } ; cout << countUnique ( mat , 3 , 4 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; int countUnique ( int mat [ ] [ MAX ] , int n , int m ) { int rowsum [ n ] , colsum [ m ] ; memset ( colsum , 0 , sizeof ( colsum ) ) ; memset ( rowsum , 0 , sizeof ( rowsum ) ) ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] ) { rowsum [ i ] ++ ; colsum [ j ] ++ ; }
int uniquecount = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] && rowsum [ i ] == 1 && colsum [ j ] == 1 ) uniquecount ++ ; return uniquecount ; }
int main ( ) { int mat [ ] [ MAX ] = { { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 1 , 0 , 0 , 1 } } ; cout << countUnique ( mat , 3 , 4 ) ; return 0 ; }
for ( int i = 0 ; i < m ; ++ i ) for ( int j = 0 ; j < n ; ++ j ) if ( array [ i ] [ j ] == 0 ) ++ counter ; return ( counter > ( ( m * n ) / 2 ) ) ; }
int main ( ) { int array [ ] [ MAX ] = { { 1 , 0 , 3 } , { 0 , 0 , 4 } , { 6 , 0 , 0 } } ; int m = 3 , n = 3 ; if ( isSparse ( array , m , n ) ) cout << " Yes " ; else cout << " No " ; }
#include <iostream> NEW_LINE #define MAX  100 NEW_LINE using namespace std ;
int countCommon ( int mat [ ] [ MAX ] , int n ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( mat [ i ] [ i ] == mat [ i ] [ n - i - 1 ] ) res ++ ; return res ; }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; cout << countCommon ( mat , 3 ) ; return 0 ; }
bool areSumSame ( int a [ ] [ MAX ] , int n , int m ) { int sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum1 = 0 , sum2 = 0 ; for ( int j = 0 ; j < m ; j ++ ) { sum1 += a [ i ] [ j ] ; sum2 += a [ j ] [ i ] ; } if ( sum1 == sum2 ) return true ; } return false ; }
int n = 4 ;
int m = 4 ; int M [ n ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 9 , 5 , 3 , 1 } , { 0 , 3 , 5 , 6 } , { 0 , 4 , 5 , 6 } } ; cout << areSumSame ( M , n , m ) << " STRNEWLINE " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; struct Node { int data ; struct Node * next ; struct Node * child ; } ;
Node * newNode ( int data ) { Node * newNode = new Node ; newNode -> next = newNode -> child = NULL ; newNode -> data = data ; return newNode ; }
Node * addSibling ( Node * n , int data ) { if ( n == NULL ) return NULL ; while ( n -> next ) n = n -> next ; return ( n -> next = newNode ( data ) ) ; }
Node * addChild ( Node * n , int data ) { if ( n == NULL ) return NULL ;
if ( n -> child ) return addSibling ( n -> child , data ) ; else return ( n -> child = newNode ( data ) ) ; }
void traverseTree ( Node * root ) {
if ( root == NULL ) return ; cout << root -> data << " ▁ " ; if ( root -> child == NULL ) return ;
queue < Node * > q ; Node * curr = root -> child ; q . push ( curr ) ; while ( ! q . empty ( ) ) {
curr = q . front ( ) ; q . pop ( ) ;
while ( curr != NULL ) { cout << curr -> data << " ▁ " ; if ( curr -> child != NULL ) { q . push ( curr -> child ) ; } curr = curr -> next ; } } }
int main ( ) { Node * root = newNode ( 10 ) ; Node * n1 = addChild ( root , 2 ) ; Node * n2 = addChild ( root , 3 ) ; Node * n3 = addChild ( root , 4 ) ; Node * n4 = addChild ( n3 , 6 ) ; Node * n5 = addChild ( root , 5 ) ; Node * n6 = addChild ( n5 , 7 ) ; Node * n7 = addChild ( n5 , 8 ) ; Node * n8 = addChild ( n5 , 9 ) ; traverseTree ( root ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  4 NEW_LINE using namespace std ;
void findMax ( int arr [ ] [ N ] ) { int row = 0 , i , j ; for ( i = 0 , j = N - 1 ; i < N ; i ++ ) {
while ( arr [ i ] [ j ] == 1 && j >= 0 ) { row = i ; j -- ; } } cout << " Row ▁ number ▁ = ▁ " << row + 1 ; cout << " , ▁ MaxCount ▁ = ▁ " << N - 1 - j ; }
int main ( ) { int arr [ N ] [ N ] = { 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 0 , 1 , 1 , 1 } ; findMax ( arr ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 100 ;
void transpose ( int mat [ ] [ MAX ] , int tr [ ] [ MAX ] , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) tr [ i ] [ j ] = mat [ j ] [ i ] ; }
bool isSymmetric ( int mat [ ] [ MAX ] , int N ) { int tr [ N ] [ MAX ] ; transpose ( mat , tr , N ) ; for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != tr [ i ] [ j ] ) return false ; return true ; }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 100 ;
bool isSymmetric ( int mat [ ] [ MAX ] , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) return false ; return true ; }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
bool isAllCellTraversed ( vector < vector < pair < int , int > > > grid , int n , int m ) { bool visited [ n ] [ m ] ; int total = n * m ;
int startx = grid [ 0 ] [ 0 ] . first ; int starty = grid [ 0 ] [ 0 ] . second ; for ( int i = 0 ; i < total - 2 ; i ++ ) {
if ( grid [ startx ] [ starty ] . first == -1 and grid [ startx ] [ starty ] . second == -1 ) return false ;
if ( visited [ startx ] [ starty ] == true ) return false ; visited [ startx ] [ starty ] = true ; int x = grid [ startx ] [ starty ] . first ; int y = grid [ startx ] [ starty ] . second ;
startx = x ; starty = y ; }
if ( grid [ startx ] [ starty ] . first == -1 and grid [ startx ] [ starty ] . second == -1 ) return true ; return false ; }
int main ( ) { vector < vector < pair < int , int > > > cell ( 3 , vector < pair < int , int > > ( 2 ) ) ; cell [ 0 ] [ 0 ] = { 0 , 1 } ; cell [ 0 ] [ 1 ] = { 2 , 0 } ; cell [ 1 ] [ 0 ] = { -1 , -1 } ; cell [ 1 ] [ 1 ] = { 1 , 0 } ; cell [ 2 ] [ 0 ] = { 2 , 1 } ; cell [ 2 ] [ 1 ] = { 1 , 1 } ; if ( ! isAllCellTraversed ( cell , 3 , 2 ) ) cout << " true " ; else cout << " false " ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  4 NEW_LINE bool isPalin ( string str ) { int len = str . length ( ) / 2 ; for ( int i = 0 ; i < len ; i ++ ) { if ( str [ i ] != str [ str . length ( ) - i - 1 ] ) return false ; } return true ; }
void palindromicPath ( string str , char a [ ] [ N ] , int i , int j , int m , int n ) {
if ( j < m - 1 i < n - 1 ) { if ( i < n - 1 ) palindromicPath ( str + a [ i ] [ j ] , a , i + 1 , j , m , n ) ; if ( j < m - 1 ) palindromicPath ( str + a [ i ] [ j ] , a , i , j + 1 , m , n ) ; }
else { str = str + a [ n - 1 ] [ m - 1 ] ; if ( isPalin ( str ) ) cout << ( str ) << endl ; } }
int main ( ) { char arr [ ] [ N ] = { { ' a ' , ' a ' , ' a ' , ' b ' } , { ' b ' , ' a ' , ' a ' , ' a ' } , { ' a ' , ' b ' , ' b ' , ' a ' } } ; string str = " " ; palindromicPath ( str , arr , 0 , 0 , 4 , 3 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define n  4 NEW_LINE #define m  4 NEW_LINE using namespace std ;
int findPossibleMoves ( int mat [ n ] [ m ] , int p , int q ) {
int X [ 8 ] = { 2 , 1 , -1 , -2 , -2 , -1 , 1 , 2 } ; int Y [ 8 ] = { 1 , 2 , 2 , 1 , -1 , -2 , -2 , -1 } ; int count = 0 ;
for ( int i = 0 ; i < 8 ; i ++ ) {
int x = p + X [ i ] ; int y = q + Y [ i ] ;
if ( x >= 0 && y >= 0 && x < n && y < m && mat [ x ] [ y ] == 0 ) count ++ ; }
return count ; }
int main ( ) { int mat [ n ] [ m ] = { { 1 , 0 , 1 , 0 } , { 0 , 1 , 1 , 1 } , { 1 , 1 , 0 , 1 } , { 0 , 1 , 1 , 1 } } ; int p = 2 , q = 2 ; cout << findPossibleMoves ( mat , p , q ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; void printDiagonalSums ( int mat [ ] [ MAX ] , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) principal += mat [ i ] [ j ] ;
if ( ( i + j ) == ( n - 1 ) ) secondary += mat [ i ] [ j ] ; } } cout << " Principal ▁ Diagonal : " << principal << endl ; cout << " Secondary ▁ Diagonal : " << secondary << endl ; }
int main ( ) { int a [ ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; void printDiagonalSums ( int mat [ ] [ MAX ] , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { principal += mat [ i ] [ i ] ; secondary += mat [ i ] [ n - i - 1 ] ; } cout << " Principal ▁ Diagonal : " << principal << endl ; cout << " Secondary ▁ Diagonal : " << secondary << endl ; }
int main ( ) { int a [ ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; int getBoundarySum ( int a [ ] [ MAX ] , int m , int n ) { long long int sum = 0 ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( i == 0 ) sum += a [ i ] [ j ] ; else if ( i == m - 1 ) sum += a [ i ] [ j ] ; else if ( j == 0 ) sum += a [ i ] [ j ] ; else if ( j == n - 1 ) sum += a [ i ] [ j ] ; } } return sum ; }
int main ( ) { int a [ ] [ MAX ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; long long int sum = getBoundarySum ( a , 4 , 4 ) ; cout << " Sum ▁ of ▁ boundary ▁ elements ▁ is ▁ " << sum ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 100 ; void printSpiral ( int mat [ ] [ MAX ] , int r , int c ) { int i , a = 0 , b = 2 ; int low_row = ( 0 > a ) ? 0 : a ; int low_column = ( 0 > b ) ? 0 : b - 1 ; int high_row = ( ( a + 1 ) >= r ) ? r - 1 : a + 1 ; int high_column = ( ( b + 1 ) >= c ) ? c - 1 : b + 1 ; while ( ( low_row > 0 - r && low_column > 0 - c ) ) { for ( i = low_column + 1 ; i <= high_column && i < c && low_row >= 0 ; ++ i ) cout << mat [ low_row ] [ i ] << " ▁ " ; low_row -= 1 ; for ( i = low_row + 2 ; i <= high_row && i < r && high_column < c ; ++ i ) cout << mat [ i ] [ high_column ] << " ▁ " ; high_column += 1 ; for ( i = high_column - 2 ; i >= low_column && i >= 0 && high_row < r ; -- i ) cout << mat [ high_row ] [ i ] << " ▁ " ; high_row += 1 ; for ( i = high_row - 2 ; i > low_row && i >= 0 && low_column >= 0 ; -- i ) cout << mat [ i ] [ low_column ] << " ▁ " ; low_column -= 1 ; } cout << endl ; }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int r = 3 , c = 3 ;
printSpiral ( mat , r , c ) ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  100 NEW_LINE using namespace std ; int difference ( int arr [ ] [ MAX ] , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) d1 += arr [ i ] [ j ] ;
if ( i == n - j - 1 ) d2 += arr [ i ] [ j ] ; } }
return abs ( d1 - d2 ) ; }
int main ( ) { int n = 3 ; int arr [ ] [ MAX ] = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , -12 } } ; cout << difference ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  100 NEW_LINE using namespace std ; int difference ( int arr [ ] [ MAX ] , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { d1 += arr [ i ] [ i ] ; d2 += arr [ i ] [ n - i - 1 ] ; }
return abs ( d1 - d2 ) ; }
int main ( ) { int n = 3 ; int arr [ ] [ MAX ] = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , -12 } } ; cout << difference ( arr , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ;
void spiralFill ( int m , int n , int a [ ] [ MAX ] ) {
int val = 1 ;
int k = 0 , l = 0 ; while ( k < m && l < n ) {
for ( int i = l ; i < n ; ++ i ) a [ k ] [ i ] = val ++ ; k ++ ;
for ( int i = k ; i < m ; ++ i ) a [ i ] [ n - 1 ] = val ++ ; n -- ;
if ( k < m ) { for ( int i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = val ++ ; m -- ; }
if ( l < n ) { for ( int i = m - 1 ; i >= k ; -- i ) a [ i ] [ l ] = val ++ ; l ++ ; } } }
int main ( ) { int m = 4 , n = 4 ; int a [ MAX ] [ MAX ] ; spiralFill ( m , n , a ) ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) cout << a [ i ] [ j ] << " ▁ " ; cout << endl ; } return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define MAX  100
void maxMin ( int arr [ ] [ MAX ] , int n ) { int min = INT_MAX ; int max = INT_MIN ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j <= n / 2 ; j ++ ) {
if ( arr [ i ] [ j ] > arr [ i ] [ n - j - 1 ] ) { if ( min > arr [ i ] [ n - j - 1 ] ) min = arr [ i ] [ n - j - 1 ] ; if ( max < arr [ i ] [ j ] ) max = arr [ i ] [ j ] ; } else { if ( min > arr [ i ] [ j ] ) min = arr [ i ] [ j ] ; if ( max < arr [ i ] [ n - j - 1 ] ) max = arr [ i ] [ n - j - 1 ] ; } } } cout << " Maximum ▁ = ▁ " << max << " , ▁ Minimum ▁ = ▁ " << min ; }
int main ( ) { int arr [ MAX ] [ MAX ] = { 5 , 9 , 11 , 25 , 0 , 14 , 21 , 6 , 4 } ; maxMin ( arr , 3 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  4 NEW_LINE #define C  5 NEW_LINE void antiSpiralTraversal ( int m , int n , int a [ R ] [ C ] ) { int i , k = 0 , l = 0 ;
stack < int > stk ; while ( k <= m && l <= n ) {
for ( i = l ; i <= n ; ++ i ) stk . push ( a [ k ] [ i ] ) ; k ++ ;
for ( i = k ; i <= m ; ++ i ) stk . push ( a [ i ] [ n ] ) ; n -- ;
if ( k <= m ) { for ( i = n ; i >= l ; -- i ) stk . push ( a [ m ] [ i ] ) ; m -- ; }
if ( l <= n ) { for ( i = m ; i >= k ; -- i ) stk . push ( a [ i ] [ l ] ) ; l ++ ; } } while ( ! stk . empty ( ) ) { cout << stk . top ( ) << " ▁ " ; stk . pop ( ) ; } }
int main ( ) { int mat [ R ] [ C ] = { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 10 } , { 11 , 12 , 13 , 14 , 15 } , { 16 , 17 , 18 , 19 , 20 } } ; antiSpiralTraversal ( R - 1 , C - 1 , mat ) ; return 0 ; }
const int MAX = 100 ;
int findNormal ( int mat [ ] [ MAX ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] * mat [ i ] [ j ] ; return sqrt ( sum ) ; }
int findTrace ( int mat [ ] [ MAX ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += mat [ i ] [ i ] ; return sum ; }
int main ( ) { int mat [ ] [ MAX ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; cout << " Trace ▁ of ▁ Matrix ▁ = ▁ " << findTrace ( mat , 5 ) << endl ; cout << " Normal ▁ of ▁ Matrix ▁ = ▁ " << findNormal ( mat , 5 ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define N  5 NEW_LINE #define M  5 NEW_LINE using namespace std ;
int minOperation ( bool arr [ N ] [ M ] ) { int ans = 0 ; for ( int i = N - 1 ; i >= 0 ; i -- ) { for ( int j = M - 1 ; j >= 0 ; j -- ) {
if ( arr [ i ] [ j ] == 0 ) {
ans ++ ;
for ( int k = 0 ; k <= i ; k ++ ) { for ( int h = 0 ; h <= j ; h ++ ) {
if ( arr [ k ] [ h ] == 1 ) arr [ k ] [ h ] = 0 ; else arr [ k ] [ h ] = 1 ; } } } } } return ans ; }
int main ( ) { bool mat [ N ] [ M ] = { 0 , 0 , 1 , 1 , 1 , 0 , 0 , 0 , 1 , 1 , 0 , 0 , 0 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; cout << minOperation ( mat ) << endl ; return 0 ; }
int findSum ( int n ) { int ans = 0 , temp = 0 , num ;
for ( int i = 1 ; i <= n && temp < n ; i ++ ) {
temp = i - 1 ;
num = 1 ; while ( temp < n ) { if ( temp + i <= n ) ans += ( i * num ) ; else ans += ( ( n - temp ) * num ) ; temp += i ; num ++ ; } } return ans ; }
int main ( ) { int N = 2 ; cout << findSum ( N ) << endl ; return 0 ; }
void printCoils ( int n ) {
int m = 8 * n * n ;
int coil1 [ m ] ;
coil1 [ 0 ] = 8 * n * n + 2 * n ; int curr = coil1 [ 0 ] ; int nflg = 1 , step = 2 ;
int index = 1 ; while ( index < m ) {
for ( int i = 0 ; i < step ; i ++ ) {
curr = coil1 [ index ++ ] = ( curr - 4 * n * nflg ) ; if ( index >= m ) break ; } if ( index >= m ) break ;
for ( int i = 0 ; i < step ; i ++ ) { curr = coil1 [ index ++ ] = curr + nflg ; if ( index >= m ) break ; } nflg = nflg * ( -1 ) ; step += 2 ; }
int coil2 [ m ] ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) coil2 [ i ] = 16 * n * n + 1 - coil1 [ i ] ;
cout << " Coil ▁ 1 ▁ : ▁ " ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) cout << coil1 [ i ] << " ▁ " ; cout << " Coil 2 : " for ( int i = 0 ; i < 8 * n * n ; i ++ ) cout << coil2 [ i ] << " ▁ " ; }
int main ( ) { int n = 1 ; printCoils ( n ) ; return 0 ; }
int findSum ( int n ) {
int arr [ n ] [ n ] ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = abs ( i - j ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += arr [ i ] [ j ] ; return sum ; }
int main ( ) { int n = 3 ; cout << findSum ( n ) << endl ; return 0 ; }
int findSum ( int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += i * ( n - i ) ; return 2 * sum ; }
int main ( ) { int n = 3 ; cout << findSum ( n ) << endl ; return 0 ; }
int findSum ( int n ) { n -- ; int sum = 0 ; sum += ( n * ( n + 1 ) ) / 2 ; sum += ( n * ( n + 1 ) * ( 2 * n + 1 ) ) / 6 ; return sum ; }
int main ( ) { int n = 3 ; cout << findSum ( n ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  1000 NEW_LINE using namespace std ; void checkHV ( int arr [ ] [ MAX ] , int N , int M ) {
bool horizontal = true , vertical = true ;
for ( int i = 0 , k = N - 1 ; i < N / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < M ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { horizontal = false ; break ; } } }
for ( int i = 0 , k = M - 1 ; i < M / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < N ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { vertical = false ; break ; } } } if ( ! horizontal && ! vertical ) cout << " NO STRNEWLINE " ; else if ( horizontal && ! vertical ) cout << " HORIZONTAL STRNEWLINE " ; else if ( vertical && ! horizontal ) cout << " VERTICAL STRNEWLINE " ; else cout << " BOTH STRNEWLINE " ; }
int main ( ) { int mat [ MAX ] [ MAX ] = { { 1 , 0 , 1 } , { 0 , 0 , 0 } , { 1 , 0 , 1 } } ; checkHV ( mat , 3 , 3 ) ; return 0 ; }
int maxDet ( int n ) { return ( 2 * n * n * n ) ; }
void resMatrix ( int n ) { for ( int i = 0 ; i < 3 ; i ++ ) { for ( int j = 0 ; j < 3 ; j ++ ) {
if ( i == 0 && j == 2 ) cout << "0 ▁ " ; else if ( i == 1 && j == 0 ) cout << "0 ▁ " ; else if ( i == 2 && j == 1 ) cout << "0 ▁ " ;
else cout < < n << " ▁ " ; } cout << " STRNEWLINE " ; } }
int main ( ) { int n = 15 ; cout << " Maximum ▁ Determinant ▁ = ▁ " << maxDet ( n ) ; cout << " Resultant Matrix : " resMatrix ( n ) ; return 0 ; }
int spiralDiaSum ( int n ) { if ( n == 1 ) return 1 ;
return ( 4 * n * n - 6 * n + 6 + spiralDiaSum ( n - 2 ) ) ; }
int main ( ) { int n = 7 ; cout << spiralDiaSum ( n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  3 NEW_LINE #define C  5
int numofneighbour ( int mat [ ] [ C ] , int i , int j ) { int count = 0 ;
if ( i > 0 && mat [ i - 1 ] [ j ] ) count ++ ;
if ( j > 0 && mat [ i ] [ j - 1 ] ) count ++ ;
if ( i < R - 1 && mat [ i + 1 ] [ j ] ) count ++ ;
if ( j < C - 1 && mat [ i ] [ j + 1 ] ) count ++ ; return count ; }
int findperimeter ( int mat [ R ] [ C ] ) { int perimeter = 0 ;
for ( int i = 0 ; i < R ; i ++ ) for ( int j = 0 ; j < C ; j ++ ) if ( mat [ i ] [ j ] ) perimeter += ( 4 - numofneighbour ( mat , i , j ) ) ; return perimeter ; }
int main ( ) { int mat [ R ] [ C ] = { 0 , 1 , 0 , 0 , 0 , 1 , 1 , 1 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , } ; cout << findperimeter ( mat ) << endl ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; const int MAX = 100 ; void printMatrixDiagonal ( int mat [ MAX ] [ MAX ] , int n ) {
int i = 0 , j = 0 ;
bool isUp = true ;
for ( int k = 0 ; k < n * n ; ) {
if ( isUp ) { for ( ; i >= 0 && j < n ; j ++ , i -- ) { cout << mat [ i ] [ j ] << " ▁ " ; k ++ ; }
if ( i < 0 && j <= n - 1 ) i = 0 ; if ( j == n ) i = i + 2 , j -- ; }
else { for ( ; j >= 0 && i < n ; i ++ , j -- ) { cout << mat [ i ] [ j ] << " ▁ " ; k ++ ; }
if ( j < 0 && i <= n - 1 ) j = 0 ; if ( i == n ) j = j + 2 , i -- ; }
isUp = ! isUp ; } }
int main ( ) { int mat [ MAX ] [ MAX ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int n = 3 ; printMatrixDiagonal ( mat , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
int mat [ ] [ 4 ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ;
int n = 4 , mode = 0 , it = 0 , lower = 0 ;
for ( int t = 0 ; t < ( 2 * n - 1 ) ; t ++ ) { int t1 = t ; if ( t1 >= n ) { mode ++ ; t1 = n - 1 ; it -- ; lower ++ ; } else { lower = 0 ; it ++ ; } for ( int i = t1 ; i >= lower ; i -- ) { if ( ( t1 + mode ) % 2 == 0 ) { cout << ( mat [ i ] [ t1 + lower - i ] ) << endl ; } else { cout << ( mat [ t1 + lower - i ] [ i ] ) << endl ; } } } return 0 ; }
int maxRowDiff ( int mat [ ] [ MAX ] , int m , int n ) {
int rowSum [ m ] ;
for ( int i = 0 ; i < m ; i ++ ) { int sum = 0 ; for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] ; rowSum [ i ] = sum ; }
int max_diff = rowSum [ 1 ] - rowSum [ 0 ] ; int min_element = rowSum [ 0 ] ; for ( int i = 1 ; i < m ; i ++ ) {
if ( rowSum [ i ] - min_element > max_diff ) max_diff = rowSum [ i ] - min_element ;
if ( rowSum [ i ] < min_element ) min_element = rowSum [ i ] ; } return max_diff ; }
int main ( ) { int m = 5 , n = 4 ; int mat [ ] [ MAX ] = { { -1 , 2 , 3 , 4 } , { 5 , 3 , -2 , 1 } , { 6 , 7 , 2 , -3 } , { 2 , 9 , 1 , 4 } , { 2 , 1 , -2 , 0 } } ; cout << maxRowDiff ( mat , m , n ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  4 NEW_LINE #define C  4
int getTotalCoverageOfMatrix ( int mat [ R ] [ C ] ) { int res = 0 ;
for ( int i = 0 ; i < R ; i ++ ) {
bool isOne = false ;
for ( int j = 0 ; j < C ; j ++ ) {
if ( mat [ i ] [ j ] == 1 ) isOne = true ;
else if ( isOne ) res ++ ; }
isOne = false ; for ( int j = C - 1 ; j >= 0 ; j -- ) { if ( mat [ i ] [ j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } }
for ( int j = 0 ; j < C ; j ++ ) {
bool isOne = false ; for ( int i = 0 ; i < R ; i ++ ) { if ( mat [ i ] [ j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } isOne = false ; for ( int i = R - 1 ; i >= 0 ; i -- ) { if ( mat [ i ] [ j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } } return res ; }
int main ( ) { int mat [ R ] [ C ] = { { 0 , 0 , 0 , 0 } , { 1 , 0 , 0 , 1 } , { 0 , 1 , 1 , 0 } , { 0 , 1 , 0 , 0 } } ; cout << getTotalCoverageOfMatrix ( mat ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  3 NEW_LINE #define C  4
int gcd ( int a , int b ) { if ( b == 0 ) return a ; return gcd ( b , a % b ) ; }
void replacematrix ( int mat [ R ] [ C ] , int n , int m ) { int rgcd [ R ] = { 0 } , cgcd [ C ] = { 0 } ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < m ; j ++ ) { rgcd [ i ] = gcd ( rgcd [ i ] , mat [ i ] [ j ] ) ; cgcd [ j ] = gcd ( cgcd [ j ] , mat [ i ] [ j ] ) ; } }
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) mat [ i ] [ j ] = max ( rgcd [ i ] , cgcd [ j ] ) ; }
int main ( ) { int m [ R ] [ C ] = { 1 , 2 , 3 , 3 , 4 , 5 , 6 , 6 , 7 , 8 , 9 , 9 , } ; replacematrix ( m , R , C ) ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) cout << m [ i ] [ j ] << " ▁ " ; cout << endl ; } return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  100 NEW_LINE using namespace std ;
int sortedCount ( int mat [ ] [ MAX ] , int r , int c ) {
int result = 0 ;
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = 0 ; j < c - 1 ; j ++ ) if ( mat [ i ] [ j + 1 ] <= mat [ i ] [ j ] ) break ;
if ( j == c - 1 ) result ++ ; }
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = c - 1 ; j > 0 ; j -- ) if ( mat [ i ] [ j - 1 ] <= mat [ i ] [ j ] ) break ;
if ( c > 1 && j == 0 ) result ++ ; } return result ; }
int main ( ) { int m = 4 , n = 5 ; int mat [ ] [ MAX ] = { { 1 , 2 , 3 , 4 , 5 } , { 4 , 3 , 1 , 2 , 6 } , { 8 , 7 , 6 , 5 , 4 } , { 5 , 7 , 8 , 9 , 10 } } ; cout << sortedCount ( mat , m , n ) ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; const int MAX = 1000 ;
int maxXOR ( int mat [ ] [ MAX ] , int N ) {
int r_xor , c_xor ; int max_xor = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { r_xor = 0 , c_xor = 0 ; for ( int j = 0 ; j < N ; j ++ ) {
r_xor = r_xor ^ mat [ i ] [ j ] ;
c_xor = c_xor ^ mat [ j ] [ i ] ; }
if ( max_xor < max ( r_xor , c_xor ) ) max_xor = max ( r_xor , c_xor ) ; }
return max_xor ; }
int main ( ) { int N = 3 ; int mat [ ] [ MAX ] = { { 1 , 5 , 4 } , { 3 , 7 , 2 } , { 5 , 9 , 10 } } ; cout << " maximum ▁ XOR ▁ value ▁ : ▁ " << maxXOR ( mat , N ) ; return 0 ; }
void direction ( ll R , ll C ) { if ( R != C && R % 2 == 0 && C % 2 != 0 && R < C ) { cout << " Left " << endl ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R > C ) { cout << " Up " << endl ; return ; } if ( R == C && R % 2 != 0 && C % 2 != 0 ) { cout << " Right " << endl ; return ; } if ( R == C && R % 2 == 0 && C % 2 == 0 ) { cout << " Left " << endl ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R < C ) { cout << " Right " << endl ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R > C ) { cout << " Down " << endl ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R < C ) { cout << " Left " << endl ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R > C ) { cout << " Up " << endl ; return ; } if ( R != C && R % 2 == 0 && C % 2 != 0 && R > C ) { cout << " Down " << endl ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R < C ) { cout << " Right " << endl ; return ; } }
int main ( ) { ll R = 3 , C = 1 ; direction ( R , C ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  3 NEW_LINE #define C  6 NEW_LINE void spiralPrint ( int m , int n , int a [ R ] [ C ] , int c ) { int i , k = 0 , l = 0 ; int count = 0 ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) { count ++ ; if ( count == c ) cout << a [ k ] [ i ] << " ▁ " ; } k ++ ;
for ( i = k ; i < m ; ++ i ) { count ++ ; if ( count == c ) cout << a [ i ] [ n - 1 ] << " ▁ " ; } n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) { count ++ ; if ( count == c ) cout << a [ m - 1 ] [ i ] << " ▁ " ; } m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) { count ++ ; if ( count == c ) cout << a [ i ] [ l ] << " ▁ " ; } l ++ ; } } }
int main ( ) { int a [ R ] [ C ] = { { 1 , 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 , 17 , 18 } } , k = 17 ; spiralPrint ( R , C , a , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define MAX  100 NEW_LINE using namespace std ;
int findK ( int A [ MAX ] [ MAX ] , int n , int m , int k ) { if ( n < 1 m < 1 ) return -1 ;
if ( k <= m ) return A [ 0 ] [ k - 1 ] ;
if ( k <= ( m + n - 1 ) ) return A [ ( k - m ) ] [ m - 1 ] ;
if ( k <= ( m + n - 1 + m - 1 ) ) return A [ n - 1 ] [ m - 1 - ( k - ( m + n - 1 ) ) ] ;
if ( k <= ( m + n - 1 + m - 1 + n - 2 ) ) return A [ n - 1 - ( k - ( m + n - 1 + m - 1 ) ) ] [ 0 ] ;
return findK ( ( int ( * ) [ MAX ] ) ( & ( A [ 1 ] [ 1 ] ) ) , n - 2 , m - 2 , k - ( 2 * n + 2 * m - 4 ) ) ; }
int main ( ) { int a [ MAX ] [ MAX ] = { { 1 , 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 , 17 , 18 } } ; int k = 17 ; cout << findK ( a , 3 , 6 , k ) << endl ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; #define N  5 NEW_LINE #define M  4
bool checkDiagonal ( int mat [ N ] [ M ] , int i , int j ) { int res = mat [ i ] [ j ] ; while ( ++ i < N && ++ j < M ) {
if ( mat [ i ] [ j ] != res ) return false ; }
return true ; }
bool isToepliz ( int mat [ N ] [ M ] ) {
for ( int i = 0 ; i < M ; i ++ ) {
if ( ! checkDiagonal ( mat , 0 , i ) ) return false ; }
for ( int i = 1 ; i < N ; i ++ ) {
if ( ! checkDiagonal ( mat , i , 0 ) ) return false ; }
return true ; }
int main ( ) { int mat [ N ] [ M ] = { { 6 , 7 , 8 , 9 } , { 4 , 6 , 7 , 8 } , { 1 , 4 , 6 , 7 } , { 0 , 1 , 4 , 6 } , { 2 , 0 , 1 , 4 } } ;
if ( isToepliz ( mat ) ) cout << " Matrix ▁ is ▁ a ▁ Toepliz ▁ " ; else cout << " Matrix ▁ is ▁ not ▁ a ▁ Toepliz ▁ " ; return 0 ; }
#include <iostream> NEW_LINE using namespace std ; #define N  5
int countZeroes ( int mat [ N ] [ N ] ) {
int row = N - 1 , col = 0 ;
int count = 0 ; while ( col < N ) {
while ( mat [ row ] [ col ] )
if ( -- row < 0 ) return count ;
count += ( row + 1 ) ;
col ++ ; } return count ; }
int main ( ) { int mat [ N ] [ N ] = { { 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 1 , 1 } , { 0 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } } ; cout << countZeroes ( mat ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; int countNegative ( int M [ ] [ 4 ] , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < m ; j ++ ) { if ( M [ i ] [ j ] < 0 ) count += 1 ;
else break ; } } return count ; }
int main ( ) { int M [ 3 ] [ 4 ] = { { -3 , -2 , -1 , 1 } , { -2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; cout << countNegative ( M , 3 , 4 ) ; return 0 ; }
int countNegative ( int M [ ] [ 4 ] , int n , int m ) {
int count = 0 ;
int i = 0 ; int j = m - 1 ;
while ( j >= 0 && i < n ) { if ( M [ i ] [ j ] < 0 ) {
count += j + 1 ;
i += 1 ; }
else j -= 1 ; } return count ; }
int main ( ) { int M [ 3 ] [ 4 ] = { { -3 , -2 , -1 , 1 } , { -2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; cout << countNegative ( M , 3 , 4 ) ; return 0 ; }
class node { public : int data ; node * left ; node * right ; } ;
node * bintree2listUtil ( node * root ) {
if ( root == NULL ) return root ;
if ( root -> left != NULL ) {
node * left = bintree2listUtil ( root -> left ) ;
for ( ; left -> right != NULL ; left = left -> right ) ;
left -> right = root ;
root -> left = left ; }
if ( root -> right != NULL ) {
node * right = bintree2listUtil ( root -> right ) ;
for ( ; right -> left != NULL ; right = right -> left ) ;
right -> left = root ;
root -> right = right ; } return root ; }
node * bintree2list ( node * root ) {
if ( root == NULL ) return root ;
root = bintree2listUtil ( root ) ;
while ( root -> left != NULL ) root = root -> left ; return ( root ) ; }
void printList ( node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> right ; } }
node * root = newNode ( 10 ) ; root -> left = newNode ( 12 ) ; root -> right = newNode ( 15 ) ; root -> left -> left = newNode ( 25 ) ; root -> left -> right = newNode ( 30 ) ; root -> right -> left = newNode ( 36 ) ;
node * head = bintree2list ( root ) ;
printList ( head ) ; return 0 ; }
#define N  10
int findLargestPlus ( int mat [ N ] [ N ] ) {
int left [ N ] [ N ] , right [ N ] [ N ] , top [ N ] [ N ] , bottom [ N ] [ N ] ;
for ( int i = 0 ; i < N ; i ++ ) {
top [ 0 ] [ i ] = mat [ 0 ] [ i ] ;
bottom [ N - 1 ] [ i ] = mat [ N - 1 ] [ i ] ;
left [ i ] [ 0 ] = mat [ i ] [ 0 ] ;
right [ i ] [ N - 1 ] = mat [ i ] [ N - 1 ] ; }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 1 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] == 1 ) left [ i ] [ j ] = left [ i ] [ j - 1 ] + 1 ; else left [ i ] [ j ] = 0 ;
if ( mat [ j ] [ i ] == 1 ) top [ j ] [ i ] = top [ j - 1 ] [ i ] + 1 ; else top [ j ] [ i ] = 0 ;
j = N - 1 - j ;
if ( mat [ j ] [ i ] == 1 ) bottom [ j ] [ i ] = bottom [ j + 1 ] [ i ] + 1 ; else bottom [ j ] [ i ] = 0 ;
if ( mat [ i ] [ j ] == 1 ) right [ i ] [ j ] = right [ i ] [ j + 1 ] + 1 ; else right [ i ] [ j ] = 0 ;
j = N - 1 - j ; } }
int n = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
int len = min ( min ( top [ i ] [ j ] , bottom [ i ] [ j ] ) , min ( left [ i ] [ j ] , right [ i ] [ j ] ) ) ;
if ( len > n ) n = len ; } }
if ( n ) return 4 * ( n - 1 ) + 1 ;
return 0 ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } , { 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 } , { 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 } , { 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 } , { 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 } , { 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 } , { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 } } ; cout << findLargestPlus ( mat ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
string findLeft ( string str ) { int n = str . length ( ) ;
while ( n -- ) {
if ( str [ n ] == ' d ' ) { str [ n ] = ' c ' ; break ; } if ( str [ n ] == ' b ' ) { str [ n ] = ' a ' ; break ; }
if ( str [ n ] == ' a ' ) str [ n ] = ' b ' ; else if ( str [ n ] == ' c ' ) str [ n ] = ' d ' ; } return str ; }
int main ( ) { string str = " aacbddc " ; cout << " Left ▁ of ▁ " << str << " ▁ is ▁ " << findLeft ( str ) ; return 0 ; }
void printSpiral ( int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
int x ;
x = min ( min ( i , j ) , min ( n - 1 - i , n - 1 - j ) ) ;
if ( i <= j ) printf ( " % d TABSYMBOL ▁ " , ( n - 2 * x ) * ( n - 2 * x ) - ( i - x ) - ( j - x ) ) ;
else printf ( " % d TABSYMBOL ▁ " , ( n - 2 * x - 2 ) * ( n - 2 * x - 2 ) + ( i - x ) + ( j - x ) ) ; } printf ( " STRNEWLINE " ) ; } }
int main ( ) { int n = 5 ;
printSpiral ( n ) ; return 0 ; }
int findMaxValue ( int mat [ ] [ N ] ) {
int maxValue = INT_MIN ;
for ( int a = 0 ; a < N - 1 ; a ++ ) for ( int b = 0 ; b < N - 1 ; b ++ ) for ( int d = a + 1 ; d < N ; d ++ ) for ( int e = b + 1 ; e < N ; e ++ ) if ( maxValue < ( mat [ d ] [ e ] - mat [ a ] [ b ] ) ) maxValue = mat [ d ] [ e ] - mat [ a ] [ b ] ; return maxValue ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 2 , -1 , -4 , -20 } , { -8 , -3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { -4 , -1 , 1 , 7 , -6 } , { 0 , -4 , 10 , -5 , 1 } } ; cout << " Maximum ▁ Value ▁ is ▁ " << findMaxValue ( mat ) ; return 0 ; }
int findMaxValue ( int mat [ ] [ N ] ) {
int maxValue = INT_MIN ;
int maxArr [ N ] [ N ] ;
maxArr [ N - 1 ] [ N - 1 ] = mat [ N - 1 ] [ N - 1 ] ;
int maxv = mat [ N - 1 ] [ N - 1 ] ; for ( int j = N - 2 ; j >= 0 ; j -- ) { if ( mat [ N - 1 ] [ j ] > maxv ) maxv = mat [ N - 1 ] [ j ] ; maxArr [ N - 1 ] [ j ] = maxv ; }
maxv = mat [ N - 1 ] [ N - 1 ] ; for ( int i = N - 2 ; i >= 0 ; i -- ) { if ( mat [ i ] [ N - 1 ] > maxv ) maxv = mat [ i ] [ N - 1 ] ; maxArr [ i ] [ N - 1 ] = maxv ; }
for ( int i = N - 2 ; i >= 0 ; i -- ) { for ( int j = N - 2 ; j >= 0 ; j -- ) {
if ( maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] > maxValue ) maxValue = maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] ;
maxArr [ i ] [ j ] = max ( mat [ i ] [ j ] , max ( maxArr [ i ] [ j + 1 ] , maxArr [ i + 1 ] [ j ] ) ) ; } } return maxValue ; }
int main ( ) { int mat [ N ] [ N ] = { { 1 , 2 , -1 , -4 , -20 } , { -8 , -3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { -4 , -1 , 1 , 7 , -6 } , { 0 , -4 , 10 , -5 , 1 } } ; cout << " Maximum ▁ Value ▁ is ▁ " << findMaxValue ( mat ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  3 NEW_LINE #define C  4 NEW_LINE void modifyMatrix ( bool mat [ R ] [ C ] ) { bool row [ R ] ; bool col [ C ] ; int i , j ;
for ( i = 0 ; i < R ; i ++ ) { row [ i ] = 0 ; }
for ( i = 0 ; i < C ; i ++ ) { col [ i ] = 0 ; }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( mat [ i ] [ j ] == 1 ) { row [ i ] = 1 ; col [ j ] = 1 ; } } }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( row [ i ] == 1 col [ j ] == 1 ) { mat [ i ] [ j ] = 1 ; } } } }
void printMatrix ( bool mat [ R ] [ C ] ) { int i , j ; for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { cout << mat [ i ] [ j ] ; } cout << endl ; } }
int main ( ) { bool mat [ R ] [ C ] = { { 1 , 0 , 0 , 1 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 } } ; cout << " Input ▁ Matrix ▁ STRNEWLINE " ; printMatrix ( mat ) ; modifyMatrix ( mat ) ; printf ( " Matrix ▁ after ▁ modification ▁ STRNEWLINE " ) ; printMatrix ( mat ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define ROW  4 NEW_LINE #define COL  5
void findUniqueRows ( int M [ ROW ] [ COL ] ) {
for ( int i = 0 ; i < ROW ; i ++ ) { int flag = 0 ;
for ( int j = 0 ; j < i ; j ++ ) { flag = 1 ; for ( int k = 0 ; k <= COL ; k ++ ) if ( M [ i ] [ k ] != M [ j ] [ k ] ) flag = 0 ; if ( flag == 1 ) break ; }
if ( flag == 0 ) {
for ( int j = 0 ; j < COL ; j ++ ) cout << M [ i ] [ j ] << " ▁ " ; cout << endl ; } } }
int main ( ) { int M [ ROW ] [ COL ] = { { 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 1 , 0 } , { 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 0 , 0 } } ; findUniqueRows ( M ) ; return 0 ; }
class node { public : int data ; node * left , * right ; } ;
void inorder ( node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; cout << " TABSYMBOL " << root -> data ; inorder ( root -> right ) ; } }
void fixPrevPtr ( node * root ) { static node * pre = NULL ; if ( root != NULL ) { fixPrevPtr ( root -> left ) ; root -> left = pre ; pre = root ; fixPrevPtr ( root -> right ) ; } }
node * fixNextPtr ( node * root ) { node * prev = NULL ;
while ( root && root -> right != NULL ) root = root -> right ;
while ( root && root -> left != NULL ) { prev = root ; root = root -> left ; root -> right = prev ; }
return ( root ) ; }
node * BTToDLL ( node * root ) {
fixPrevPtr ( root ) ;
return fixNextPtr ( root ) ; }
void printList ( node * root ) { while ( root != NULL ) { cout << " TABSYMBOL " << root -> data ; root = root -> right ; } }
node * root = newNode ( 10 ) ; root -> left = newNode ( 12 ) ; root -> right = newNode ( 15 ) ; root -> left -> left = newNode ( 25 ) ; root -> left -> right = newNode ( 30 ) ; root -> right -> left = newNode ( 36 ) ; cout << " Inorder Tree Traversal " ; inorder ( root ) ; node * head = BTToDLL ( root ) ; cout << " DLL Traversal " printList ( head ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  3 NEW_LINE #define C  3
void swap ( int mat [ R ] [ C ] , int row1 , int row2 , int col ) { for ( int i = 0 ; i < col ; i ++ ) { int temp = mat [ row1 ] [ i ] ; mat [ row1 ] [ i ] = mat [ row2 ] [ i ] ; mat [ row2 ] [ i ] = temp ; } }
int rankOfMatrix ( int mat [ R ] [ C ] ) { int rank = C ; for ( int row = 0 ; row < rank ; row ++ ) {
if ( mat [ row ] [ row ] ) { for ( int col = 0 ; col < R ; col ++ ) { if ( col != row ) {
double mult = ( double ) mat [ col ] [ row ] / mat [ row ] [ row ] ; for ( int i = 0 ; i < rank ; i ++ ) mat [ col ] [ i ] -= mult * mat [ row ] [ i ] ; } } }
else { bool reduce = true ;
for ( int i = row + 1 ; i < R ; i ++ ) {
if ( mat [ i ] [ row ] ) { swap ( mat , row , i , rank ) ; reduce = false ; break ; } }
if ( reduce ) {
rank -- ;
for ( int i = 0 ; i < R ; i ++ ) mat [ i ] [ row ] = mat [ i ] [ rank ] ; }
row -- ; }
} return rank ; }
void display ( int mat [ R ] [ C ] , int row , int col ) { for ( int i = 0 ; i < row ; i ++ ) { for ( int j = 0 ; j < col ; j ++ ) printf ( " ▁ % d " , mat [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } }
int main ( ) { int mat [ ] [ 3 ] = { { 10 , 20 , 10 } , { -20 , -30 , 10 } , { 30 , 50 , 0 } } ; printf ( " Rank ▁ of ▁ the ▁ matrix ▁ is ▁ : ▁ % d " , rankOfMatrix ( mat ) ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define R  3 NEW_LINE #define C  3 NEW_LINE using namespace std ;
struct Cell {
void printSums ( int mat [ ] [ C ] , struct Cell arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int sum = 0 , r = arr [ i ] . r , c = arr [ i ] . c ;
for ( int j = 0 ; j < R ; j ++ ) for ( int k = 0 ; k < C ; k ++ ) if ( j != r && k != c ) sum += mat [ j ] [ k ] ; cout << sum << endl ; } }
int main ( ) { int mat [ ] [ C ] = { { 1 , 1 , 2 } , { 3 , 4 , 6 } , { 5 , 3 , 2 } } ; struct Cell arr [ ] = { { 0 , 0 } , { 1 , 1 } , { 0 , 1 } } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printSums ( mat , arr , n ) ; return 0 ; }
int countIslands ( int mat [ ] [ N ] ) {
int count = 0 ;
for ( int i = 0 ; i < M ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] == ' X ' ) { if ( ( i == 0 mat [ i - 1 ] [ j ] == ' O ' ) && ( j == 0 mat [ i ] [ j - 1 ] == ' O ' ) ) count ++ ; } } } return count ; }
int main ( ) { int mat [ M ] [ N ] = { { ' O ' , ' O ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' } , { ' O ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' O ' } } ; cout << " Number ▁ of ▁ rectangular ▁ islands ▁ is ▁ " << countIslands ( mat ) ; return 0 ; }
#define M  4 NEW_LINE #define N  5
int findCommon ( int mat [ M ] [ N ] ) {
int column [ M ] ;
int min_row ;
int i ; for ( i = 0 ; i < M ; i ++ ) column [ i ] = N - 1 ;
min_row = 0 ;
while ( column [ min_row ] >= 0 ) {
for ( i = 0 ; i < M ; i ++ ) { if ( mat [ i ] [ column [ i ] ] < mat [ min_row ] [ column [ min_row ] ] ) min_row = i ; }
int eq_count = 0 ;
for ( i = 0 ; i < M ; i ++ ) {
if ( mat [ i ] [ column [ i ] ] > mat [ min_row ] [ column [ min_row ] ] ) { if ( column [ i ] == 0 ) return -1 ;
column [ i ] -= 1 ; } else eq_count ++ ; }
if ( eq_count == M ) return mat [ min_row ] [ column [ min_row ] ] ; } return -1 ; }
int main ( ) { int mat [ M ] [ N ] = { { 1 , 2 , 3 , 4 , 5 } , { 2 , 4 , 5 , 8 , 10 } , { 3 , 5 , 7 , 9 , 11 } , { 1 , 3 , 5 , 7 , 9 } , } ; int result = findCommon ( mat ) ; if ( result == -1 ) cout << " No ▁ common ▁ element " ; else cout << " Common ▁ element ▁ is ▁ " << result ; return 0 ; }
#define M  4 NEW_LINE #define N  5
int findCommon ( int mat [ M ] [ N ] ) {
unordered_map < int , int > cnt ; int i , j ; for ( i = 0 ; i < M ; i ++ ) {
cnt [ mat [ i ] [ 0 ] ] ++ ;
for ( j = 1 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] != mat [ i ] [ j - 1 ] ) cnt [ mat [ i ] [ j ] ] ++ ; } }
for ( auto ele : cnt ) { if ( ele . second == M ) return ele . first ; }
return -1 ; }
int main ( ) { int mat [ M ] [ N ] = { { 1 , 2 , 3 , 4 , 5 } , { 2 , 4 , 5 , 8 , 10 } , { 3 , 5 , 7 , 9 , 11 } , { 1 , 3 , 5 , 7 , 9 } , } ; int result = findCommon ( mat ) ; if ( result == -1 ) cout << " No ▁ common ▁ element " ; else cout << " Common ▁ element ▁ is ▁ " << result ; return 0 ; }
#define M  6 NEW_LINE #define N  6
void floodFillUtil ( char mat [ ] [ N ] , int x , int y , char prevV , char newV ) {
if ( x < 0 x > = M y < 0 y > = N ) return ; if ( mat [ x ] [ y ] != prevV ) return ;
mat [ x ] [ y ] = newV ;
floodFillUtil ( mat , x + 1 , y , prevV , newV ) ; floodFillUtil ( mat , x - 1 , y , prevV , newV ) ; floodFillUtil ( mat , x , y + 1 , prevV , newV ) ; floodFillUtil ( mat , x , y - 1 , prevV , newV ) ; }
int replaceSurrounded ( char mat [ ] [ N ] ) {
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' O ' ) mat [ i ] [ j ] = ' - ' ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ 0 ] == ' - ' ) floodFillUtil ( mat , i , 0 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ N - 1 ] == ' - ' ) floodFillUtil ( mat , i , N - 1 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ 0 ] [ i ] == ' - ' ) floodFillUtil ( mat , 0 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ M - 1 ] [ i ] == ' - ' ) floodFillUtil ( mat , M - 1 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' - ' ) mat [ i ] [ j ] = ' X ' ; }
int main ( ) { char mat [ ] [ N ] = { { ' X ' , ' O ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' X ' , ' O ' , ' X ' , ' X ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' O ' , ' X ' , ' X ' , ' X ' , ' X ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' , ' O ' , ' O ' , ' O ' } , } ; replaceSurrounded ( mat ) ; for ( int i = 0 ; i < M ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) cout << mat [ i ] [ j ] << " ▁ " ; cout << endl ; } return 0 ; }
struct node { int data ; node * left ; node * right ; } ;
void BinaryTree2DoubleLinkedList ( node * root , node * * head ) {
if ( root == NULL ) return ;
static node * prev = NULL ;
BinaryTree2DoubleLinkedList ( root -> left , head ) ;
if ( prev == NULL ) * head = root ; else { root -> left = prev ; prev -> right = root ; } prev = root ;
BinaryTree2DoubleLinkedList ( root -> right , head ) ; }
void printList ( node * node ) { while ( node != NULL ) { cout << node -> data << " ▁ " ; node = node -> right ; } }
node * root = newNode ( 10 ) ; root -> left = newNode ( 12 ) ; root -> right = newNode ( 15 ) ; root -> left -> left = newNode ( 25 ) ; root -> left -> right = newNode ( 30 ) ; root -> right -> left = newNode ( 36 ) ;
node * head = NULL ; BinaryTree2DoubleLinkedList ( root , & head ) ;
printList ( head ) ; return 0 ; }
#include <iostream> NEW_LINE #include <climits> NEW_LINE using namespace std ; #define INF  INT_MAX NEW_LINE #define N  4
void youngify ( int mat [ ] [ N ] , int i , int j ) {
int downVal = ( i + 1 < N ) ? mat [ i + 1 ] [ j ] : INF ; int rightVal = ( j + 1 < N ) ? mat [ i ] [ j + 1 ] : INF ;
if ( downVal == INF && rightVal == INF ) return ;
if ( downVal < rightVal ) { mat [ i ] [ j ] = downVal ; mat [ i + 1 ] [ j ] = INF ; youngify ( mat , i + 1 , j ) ; } else { mat [ i ] [ j ] = rightVal ; mat [ i ] [ j + 1 ] = INF ; youngify ( mat , i , j + 1 ) ; } }
int extractMin ( int mat [ ] [ N ] ) { int ret = mat [ 0 ] [ 0 ] ; mat [ 0 ] [ 0 ] = INF ; youngify ( mat , 0 , 0 ) ; return ret ; }
void printSorted ( int mat [ ] [ N ] ) { cout << " Elements ▁ of ▁ matrix ▁ in ▁ sorted ▁ order ▁ n " ; for ( int i = 0 ; i < N * N ; i ++ ) cout << extractMin ( mat ) << " ▁ " ; }
#define n  5
void printSumSimple ( int mat [ ] [ n ] , int k ) {
if ( k > n ) return ;
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
for ( int j = 0 ; j < n - k + 1 ; j ++ ) {
int sum = 0 ; for ( int p = i ; p < k + i ; p ++ ) for ( int q = j ; q < k + j ; q ++ ) sum += mat [ p ] [ q ] ; cout << sum << " ▁ " ; }
cout << endl ; } }
int main ( ) { int mat [ n ] [ n ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; int k = 3 ; printSumSimple ( mat , k ) ; return 0 ; }
#define n  5
void printSumTricky ( int mat [ ] [ n ] , int k ) {
if ( k > n ) return ;
int stripSum [ n ] [ n ] ;
for ( int j = 0 ; j < n ; j ++ ) {
int sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) sum += mat [ i ] [ j ] ; stripSum [ 0 ] [ j ] = sum ;
for ( int i = 1 ; i < n - k + 1 ; i ++ ) { sum += ( mat [ i + k - 1 ] [ j ] - mat [ i - 1 ] [ j ] ) ; stripSum [ i ] [ j ] = sum ; } }
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
int sum = 0 ; for ( int j = 0 ; j < k ; j ++ ) sum += stripSum [ i ] [ j ] ; cout << sum << " ▁ " ;
for ( int j = 1 ; j < n - k + 1 ; j ++ ) { sum += ( stripSum [ i ] [ j + k - 1 ] - stripSum [ i ] [ j - 1 ] ) ; cout << sum << " ▁ " ; } cout << endl ; } }
int main ( ) { int mat [ n ] [ n ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; int k = 3 ; printSumTricky ( mat , k ) ; return 0 ; }
#include <stdio.h> NEW_LINE #define M  3 NEW_LINE #define N  4
void transpose ( int A [ ] [ N ] , int B [ ] [ M ] ) { int i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < M ; j ++ ) B [ i ] [ j ] = A [ j ] [ i ] ; }
int main ( ) { int A [ M ] [ N ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } } ; int B [ N ] [ M ] , i , j ; transpose ( A , B ) ; printf ( " Result ▁ matrix ▁ is ▁ STRNEWLINE " ) ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < M ; j ++ ) printf ( " % d ▁ " , B [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  4
void transpose ( int A [ ] [ N ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) swap ( A [ i ] [ j ] , A [ j ] [ i ] ) ; }
int main ( ) { int A [ N ] [ N ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; transpose ( A ) ; printf ( " Modified ▁ matrix ▁ is ▁ STRNEWLINE " ) ; for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) printf ( " % d ▁ " , A [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define R  5 NEW_LINE #define C  4
bool isValid ( int x , int y1 , int y2 ) { return ( x >= 0 && x < R && y1 >= 0 && y1 < C && y2 >= 0 && y2 < C ) ; }
int getMaxUtil ( int arr [ R ] [ C ] , int mem [ R ] [ C ] [ C ] , int x , int y1 , int y2 ) {
if ( ! isValid ( x , y1 , y2 ) ) return INT_MIN ;
if ( x == R - 1 && y1 == 0 && y2 == C - 1 ) return ( y1 == y2 ) ? arr [ x ] [ y1 ] : arr [ x ] [ y1 ] + arr [ x ] [ y2 ] ;
if ( x == R - 1 ) return INT_MIN ;
if ( mem [ x ] [ y1 ] [ y2 ] != -1 ) return mem [ x ] [ y1 ] [ y2 ] ;
int ans = INT_MIN ;
int temp = ( y1 == y2 ) ? arr [ x ] [ y1 ] : arr [ x ] [ y1 ] + arr [ x ] [ y2 ] ;
ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 - 1 ) ) ; ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 + 1 ) ) ; ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 ) ) ; ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 ) ) ; ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 - 1 ) ) ; ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 + 1 ) ) ; ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 ) ) ; ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 - 1 ) ) ; ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 + 1 ) ) ; return ( mem [ x ] [ y1 ] [ y2 ] = ans ) ; }
int geMaxCollection ( int arr [ R ] [ C ] ) {
int mem [ R ] [ C ] [ C ] ; memset ( mem , -1 , sizeof ( mem ) ) ;
return getMaxUtil ( arr , mem , 0 , 0 , C - 1 ) ; }
int main ( ) { int arr [ R ] [ C ] = { { 3 , 6 , 8 , 2 } , { 5 , 2 , 4 , 3 } , { 1 , 1 , 20 , 10 } , { 1 , 1 , 20 , 10 } , { 1 , 1 , 20 , 10 } , } ; cout << " Maximum ▁ collection ▁ is ▁ " << geMaxCollection ( arr ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define R  3 NEW_LINE #define C  3 NEW_LINE using namespace std ;
int pathCountRec ( int mat [ ] [ C ] , int m , int n , int k ) {
if ( m < 0 n < 0 ) return 0 ; if ( m == 0 && n == 0 ) return ( k == mat [ m ] [ n ] ) ;
return pathCountRec ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountRec ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; }
int pathCount ( int mat [ ] [ C ] , int k ) { return pathCountRec ( mat , R - 1 , C - 1 , k ) ; }
int main ( ) { int k = 12 ; int mat [ R ] [ C ] = { { 1 , 2 , 3 } , { 4 , 6 , 5 } , { 3 , 2 , 1 } } ; cout << pathCount ( mat , k ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE #define R  3 NEW_LINE #define C  3 NEW_LINE #define MAX_K  1000 NEW_LINE using namespace std ; int dp [ R ] [ C ] [ MAX_K ] ; int pathCountDPRecDP ( int mat [ ] [ C ] , int m , int n , int k ) {
if ( m < 0 n < 0 ) return 0 ; if ( m == 0 && n == 0 ) return ( k == mat [ m ] [ n ] ) ;
if ( dp [ m ] [ n ] [ k ] != -1 ) return dp [ m ] [ n ] [ k ] ;
dp [ m ] [ n ] [ k ] = pathCountDPRecDP ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountDPRecDP ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; return dp [ m ] [ n ] [ k ] ; }
int pathCountDP ( int mat [ ] [ C ] , int k ) { memset ( dp , -1 , sizeof dp ) ; return pathCountDPRecDP ( mat , R - 1 , C - 1 , k ) ; }
int main ( ) { int k = 12 ; int mat [ R ] [ C ] = { { 1 , 2 , 3 } , { 4 , 6 , 5 } , { 3 , 2 , 1 } } ; cout << pathCountDP ( mat , k ) ; return 0 ; }
int x [ ] = { 0 , 1 , 1 , -1 , 1 , 0 , -1 , -1 } ; int y [ ] = { 1 , 0 , 1 , 1 , -1 , -1 , 0 , -1 } ;
int dp [ R ] [ C ] ;
bool isvalid ( int i , int j ) { if ( i < 0 j < 0 i > = R j > = C ) return false ; return true ; }
bool isadjacent ( char prev , char curr ) { return ( ( curr - prev ) == 1 ) ; }
int getLenUtil ( char mat [ R ] [ C ] , int i , int j , char prev ) {
if ( ! isvalid ( i , j ) || ! isadjacent ( prev , mat [ i ] [ j ] ) ) return 0 ;
if ( dp [ i ] [ j ] != -1 ) return dp [ i ] [ j ] ;
int ans = 0 ;
for ( int k = 0 ; k < 8 ; k ++ ) ans = max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , mat [ i ] [ j ] ) ) ;
return dp [ i ] [ j ] = ans ; }
int getLen ( char mat [ R ] [ C ] , char s ) { memset ( dp , -1 , sizeof dp ) ; int ans = 0 ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) {
if ( mat [ i ] [ j ] == s ) {
for ( int k = 0 ; k < 8 ; k ++ ) ans = max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , s ) ) ; } } } return ans ; }
int main ( ) { char mat [ R ] [ C ] = { { ' a ' , ' c ' , ' d ' } , { ' h ' , ' b ' , ' a ' } , { ' i ' , ' g ' , ' f ' } } ; cout << getLen ( mat , ' a ' ) << endl ; cout << getLen ( mat , ' e ' ) << endl ; cout << getLen ( mat , ' b ' ) << endl ; cout << getLen ( mat , ' f ' ) << endl ; return 0 ; }
