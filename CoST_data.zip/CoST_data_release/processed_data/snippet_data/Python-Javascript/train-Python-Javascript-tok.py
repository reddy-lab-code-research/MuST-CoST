class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . left = None NEW_LINE self . right = None NEW_LINE self . val = key NEW_LINE DEDENT DEDENT
def sortStack ( input ) : NEW_LINE INDENT tmpStack = [ ] NEW_LINE while ( len ( input ) > 0 ) : NEW_LINE DEDENT
tmp = input [ - 1 ] NEW_LINE input . pop ( ) NEW_LINE
while ( len ( tmpStack ) > 0 and tmpStack [ - 1 ] < tmp ) : NEW_LINE
input . append ( tmpStack [ - 1 ] ) NEW_LINE tmpStack . pop ( ) NEW_LINE
tmpStack . append ( tmp ) NEW_LINE return tmpStack NEW_LINE def sortArrayUsingStacks ( arr , n ) : NEW_LINE
input = [ ] NEW_LINE i = 0 NEW_LINE while ( i < n ) : NEW_LINE INDENT input . append ( arr [ i ] ) NEW_LINE i = i + 1 NEW_LINE DEDENT
tmpStack = sortStack ( input ) NEW_LINE i = 0 NEW_LINE
while ( i < n ) : NEW_LINE INDENT arr [ i ] = tmpStack [ - 1 ] NEW_LINE tmpStack . pop ( ) NEW_LINE i = i + 1 NEW_LINE DEDENT return arr NEW_LINE
arr = [ 10 , 5 , 15 , 45 ] NEW_LINE n = len ( arr ) NEW_LINE arr = sortArrayUsingStacks ( arr , n ) NEW_LINE i = 0 NEW_LINE while ( i < n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE i = i + 1 NEW_LINE DEDENT
def TowerOfHanoi ( n , from_rod , to_rod , aux_rod ) : NEW_LINE INDENT if n == 1 : NEW_LINE INDENT print ( " Move ▁ disk ▁ 1 ▁ from ▁ rod " , from_rod , " to ▁ rod " , to_rod ) NEW_LINE return NEW_LINE DEDENT TowerOfHanoi ( n - 1 , from_rod , aux_rod , to_rod ) NEW_LINE print ( " Move ▁ disk " , n , " from ▁ rod " , from_rod , " to ▁ rod " , to_rod ) NEW_LINE TowerOfHanoi ( n - 1 , aux_rod , to_rod , from_rod ) NEW_LINE DEDENT
n = 4 NEW_LINE
TowerOfHanoi ( n , ' A ' , ' C ' , ' B ' ) NEW_LINE
INT_MIN = - 1000000 NEW_LINE def printMaxOfMin ( arr , n ) : NEW_LINE
for k in range ( 1 , n + 1 ) : NEW_LINE
maxOfMin = INT_MIN ; NEW_LINE
for i in range ( n - k + 1 ) : NEW_LINE
min = arr [ i ] NEW_LINE for j in range ( k ) : NEW_LINE INDENT if ( arr [ i + j ] < min ) : NEW_LINE INDENT min = arr [ i + j ] NEW_LINE DEDENT DEDENT
if ( min > maxOfMin ) : NEW_LINE INDENT maxOfMin = min NEW_LINE DEDENT
print ( maxOfMin , end = " ▁ " ) NEW_LINE
arr = [ 10 , 20 , 30 , 50 , 10 , 70 , 30 ] NEW_LINE n = len ( arr ) NEW_LINE printMaxOfMin ( arr , n ) NEW_LINE
def printMaxOfMin ( arr , n ) : NEW_LINE
s = [ ] NEW_LINE
left = [ - 1 ] * ( n + 1 ) NEW_LINE right = [ n ] * ( n + 1 ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT while ( len ( s ) != 0 and arr [ s [ - 1 ] ] >= arr [ i ] ) : NEW_LINE INDENT s . pop ( ) NEW_LINE DEDENT if ( len ( s ) != 0 ) : NEW_LINE INDENT left [ i ] = s [ - 1 ] NEW_LINE DEDENT s . append ( i ) NEW_LINE DEDENT
while ( len ( s ) != 0 ) : NEW_LINE INDENT s . pop ( ) NEW_LINE DEDENT
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE INDENT while ( len ( s ) != 0 and arr [ s [ - 1 ] ] >= arr [ i ] ) : NEW_LINE INDENT s . pop ( ) NEW_LINE DEDENT if ( len ( s ) != 0 ) : NEW_LINE INDENT right [ i ] = s [ - 1 ] NEW_LINE DEDENT s . append ( i ) NEW_LINE DEDENT
ans = [ 0 ] * ( n + 1 ) NEW_LINE for i in range ( n + 1 ) : NEW_LINE INDENT ans [ i ] = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE
Len = right [ i ] - left [ i ] - 1 NEW_LINE
ans [ Len ] = max ( ans [ Len ] , arr [ i ] ) NEW_LINE
for i in range ( n - 1 , 0 , - 1 ) : NEW_LINE INDENT ans [ i ] = max ( ans [ i ] , ans [ i + 1 ] ) NEW_LINE DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT print ( ans [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def solve ( s , n ) : NEW_LINE
left = 0 NEW_LINE right = 0 NEW_LINE maxlength = 0 NEW_LINE
for i in range ( n ) : NEW_LINE
if ( s [ i ] == ' ( ' ) : NEW_LINE INDENT left += 1 NEW_LINE DEDENT else : NEW_LINE INDENT right += 1 NEW_LINE DEDENT
if ( left == right ) : NEW_LINE INDENT maxlength = max ( maxlength , 2 * right ) NEW_LINE DEDENT
elif ( right > left ) : NEW_LINE INDENT left = right = 0 NEW_LINE DEDENT left = right = 0 NEW_LINE
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE
if ( s [ i ] == ' ( ' ) : NEW_LINE INDENT left += 1 NEW_LINE DEDENT else : NEW_LINE INDENT right += 1 NEW_LINE DEDENT
if ( left == right ) : NEW_LINE INDENT maxlength = max ( maxlength , 2 * left ) NEW_LINE DEDENT
elif ( left > right ) : NEW_LINE INDENT left = right = 0 NEW_LINE DEDENT return maxlength NEW_LINE
print ( solve ( " ( ( ( ) ( ) ( ) ( ) ( ( ( ( ) ) " , 16 ) ) NEW_LINE
def printLeast ( arr ) : NEW_LINE
min_avail = 1 NEW_LINE pos_of_I = 0 NEW_LINE
v = [ ] NEW_LINE
if ( arr [ 0 ] == ' I ' ) : NEW_LINE INDENT v . append ( 1 ) NEW_LINE v . append ( 2 ) NEW_LINE min_avail = 3 NEW_LINE pos_of_I = 1 NEW_LINE DEDENT else : NEW_LINE INDENT v . append ( 2 ) NEW_LINE v . append ( 1 ) NEW_LINE min_avail = 3 NEW_LINE pos_of_I = 0 NEW_LINE DEDENT
for i in range ( 1 , len ( arr ) ) : NEW_LINE INDENT if ( arr [ i ] == ' I ' ) : NEW_LINE INDENT v . append ( min_avail ) NEW_LINE min_avail += 1 NEW_LINE pos_of_I = i + 1 NEW_LINE DEDENT else : NEW_LINE INDENT v . append ( v [ i ] ) NEW_LINE for j in range ( pos_of_I , i + 1 ) : NEW_LINE INDENT v [ j ] += 1 NEW_LINE DEDENT min_avail += 1 NEW_LINE DEDENT DEDENT
print ( * v , sep = ' ▁ ' ) NEW_LINE
printLeast ( " IDID " ) NEW_LINE printLeast ( " I " ) NEW_LINE printLeast ( " DD " ) NEW_LINE printLeast ( " II " ) NEW_LINE printLeast ( " DIDI " ) NEW_LINE printLeast ( " IIDDD " ) NEW_LINE printLeast ( " DDIDDIID " ) NEW_LINE
def PrintMinNumberForPattern ( Strr ) : NEW_LINE
res = ' ' NEW_LINE
stack = [ ] NEW_LINE
for i in range ( len ( Strr ) + 1 ) : NEW_LINE
stack . append ( i + 1 ) NEW_LINE
if ( i == len ( Strr ) or Strr [ i ] == ' I ' ) : NEW_LINE
while len ( stack ) > 0 : NEW_LINE
res += str ( stack . pop ( ) ) NEW_LINE res += ' ▁ ' NEW_LINE print ( res ) NEW_LINE
PrintMinNumberForPattern ( " IDID " ) NEW_LINE PrintMinNumberForPattern ( " I " ) NEW_LINE PrintMinNumberForPattern ( " DD " ) NEW_LINE PrintMinNumberForPattern ( " II " ) NEW_LINE PrintMinNumberForPattern ( " DIDI " ) NEW_LINE PrintMinNumberForPattern ( " IIDDD " ) NEW_LINE PrintMinNumberForPattern ( " DDIDDIID " ) NEW_LINE
def getMinNumberForPattern ( seq ) : NEW_LINE INDENT n = len ( seq ) NEW_LINE if ( n >= 9 ) : NEW_LINE INDENT return " - 1" NEW_LINE DEDENT result = [ None ] * ( n + 1 ) NEW_LINE count = 1 NEW_LINE DEDENT
for i in range ( n + 1 ) : NEW_LINE INDENT if ( i == n or seq [ i ] == ' I ' ) : NEW_LINE INDENT for j in range ( i - 1 , - 2 , - 1 ) : NEW_LINE INDENT result [ j + 1 ] = int ( '0' + str ( count ) ) NEW_LINE count += 1 NEW_LINE if ( j >= 0 and seq [ j ] == ' I ' ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT DEDENT return result NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT inputs = [ " IDID " , " I " , " DD " , " II " , " DIDI " , " IIDDD " , " DDIDDIID " ] NEW_LINE for Input in inputs : NEW_LINE INDENT print ( * ( getMinNumberForPattern ( Input ) ) ) NEW_LINE DEDENT DEDENT
def nextGreater ( arr , n , next , order ) : NEW_LINE
S = [ ] NEW_LINE
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE
while ( S != [ ] and ( arr [ S [ len ( S ) - 1 ] ] <= arr [ i ] if ( order == ' G ' ) else arr [ S [ len ( S ) - 1 ] ] >= arr [ i ] ) ) : NEW_LINE INDENT S . pop ( ) NEW_LINE DEDENT
if ( S != [ ] ) : NEW_LINE INDENT next [ i ] = S [ len ( S ) - 1 ] NEW_LINE DEDENT
else : NEW_LINE INDENT next [ i ] = - 1 NEW_LINE DEDENT
S . append ( i ) NEW_LINE
def nextSmallerOfNextGreater ( arr , n ) : NEW_LINE
NG = [ None ] * n NEW_LINE
RS = [ None ] * n NEW_LINE
nextGreater ( arr , n , NG , ' G ' ) NEW_LINE
nextGreater ( arr , n , RS , ' S ' ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if ( NG [ i ] != - 1 and RS [ NG [ i ] ] != - 1 ) : NEW_LINE INDENT print ( arr [ RS [ NG [ i ] ] ] , end = " ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " - 1" , end = " ▁ " ) NEW_LINE DEDENT DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 5 , 1 , 9 , 2 , 5 , 1 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE nextSmallerOfNextGreater ( arr , n ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . right = None NEW_LINE self . left = None NEW_LINE DEDENT DEDENT
def flipBinaryTree ( root ) : NEW_LINE INDENT if root is None : NEW_LINE INDENT return root NEW_LINE DEDENT if ( root . left is None and root . right is None ) : NEW_LINE INDENT return root NEW_LINE DEDENT DEDENT
flippedRoot = flipBinaryTree ( root . left ) NEW_LINE
root . left . left = root . right NEW_LINE root . left . right = root NEW_LINE root . left = root . right = None NEW_LINE return flippedRoot NEW_LINE
def printLevelOrder ( root ) : NEW_LINE
if root is None : NEW_LINE INDENT return NEW_LINE DEDENT
from Queue import Queue NEW_LINE q = Queue ( ) NEW_LINE
q . put ( root ) NEW_LINE while ( True ) : NEW_LINE
nodeCount = q . qsize ( ) NEW_LINE if nodeCount == 0 : NEW_LINE INDENT break NEW_LINE DEDENT
while nodeCount > 0 : NEW_LINE INDENT node = q . get ( ) NEW_LINE print node . data , NEW_LINE if node . left is not None : NEW_LINE INDENT q . put ( node . left ) NEW_LINE DEDENT if node . right is not None : NEW_LINE INDENT q . put ( node . right ) NEW_LINE DEDENT nodeCount -= 1 NEW_LINE DEDENT print NEW_LINE
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . right . left = Node ( 4 ) NEW_LINE root . right . right = Node ( 5 ) NEW_LINE print " Level ▁ order ▁ traversal ▁ of ▁ given ▁ tree " NEW_LINE printLevelOrder ( root ) NEW_LINE root = flipBinaryTree ( root ) NEW_LINE print   " NEW_LINE Level order traversal of the flipped tree " NEW_LINE printLevelOrder ( root ) NEW_LINE
def heapify ( arr , n , i ) : NEW_LINE
largest = i NEW_LINE
l = 2 * i + 1 NEW_LINE
r = 2 * i + 2 NEW_LINE
if l < n and arr [ largest ] < arr [ l ] : NEW_LINE INDENT largest = l NEW_LINE DEDENT
if r < n and arr [ largest ] < arr [ r ] : NEW_LINE INDENT largest = r NEW_LINE DEDENT
if largest != i : NEW_LINE INDENT arr [ i ] , arr [ largest ] = arr [ largest ] , arr [ i ] NEW_LINE DEDENT
heapify ( arr , n , largest ) NEW_LINE
def heapSort ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE DEDENT
for i in range ( n // 2 - 1 , - 1 , - 1 ) : NEW_LINE INDENT heapify ( arr , n , i ) NEW_LINE DEDENT
for i in range ( n - 1 , 0 , - 1 ) : NEW_LINE
arr [ i ] , arr [ 0 ] = arr [ 0 ] , arr [ i ] NEW_LINE
heapify ( arr , i , 0 ) NEW_LINE
arr = [ 12 , 11 , 13 , 5 , 6 , 7 ] NEW_LINE heapSort ( arr ) NEW_LINE n = len ( arr ) NEW_LINE print ( " Sorted ▁ array ▁ is " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( " % d " % arr [ i ] ) , NEW_LINE DEDENT
def isHeap ( arr , n ) : NEW_LINE
for i in range ( int ( ( n - 2 ) / 2 ) + 1 ) : NEW_LINE
if arr [ 2 * i + 1 ] > arr [ i ] : NEW_LINE INDENT return False NEW_LINE DEDENT
if ( 2 * i + 2 < n and arr [ 2 * i + 2 ] > arr [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE if isHeap ( arr , n ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT DEDENT
def generate_derangement ( N ) : NEW_LINE
S = [ 0 ] * ( N + 1 ) NEW_LINE for i in range ( 1 , N + 1 ) : NEW_LINE INDENT S [ i ] = i NEW_LINE DEDENT
D = [ 0 ] * ( N + 1 ) NEW_LINE for i in range ( 1 , N + 1 , 2 ) : NEW_LINE INDENT if i == N : NEW_LINE DEDENT
D [ N ] = S [ N - 1 ] NEW_LINE D [ N - 1 ] = S [ N ] NEW_LINE else : NEW_LINE D [ i ] = i + 1 NEW_LINE D [ i + 1 ] = i NEW_LINE
for i in range ( 1 , N + 1 ) : NEW_LINE INDENT print ( D [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT generate_derangement ( 10 ) NEW_LINE DEDENT
def heapify ( arr , n , i ) : NEW_LINE
smallest = i NEW_LINE
l = 2 * i + 1 NEW_LINE
r = 2 * i + 2 NEW_LINE
if l < n and arr [ l ] < arr [ smallest ] : NEW_LINE INDENT smallest = l NEW_LINE DEDENT
if r < n and arr [ r ] < arr [ smallest ] : NEW_LINE INDENT smallest = r NEW_LINE DEDENT
if smallest != i : NEW_LINE INDENT ( arr [ i ] , arr [ smallest ] ) = ( arr [ smallest ] , arr [ i ] ) NEW_LINE DEDENT
heapify ( arr , n , smallest ) NEW_LINE
def heapSort ( arr , n ) : NEW_LINE
for i in range ( int ( n / 2 ) - 1 , - 1 , - 1 ) : NEW_LINE INDENT heapify ( arr , n , i ) NEW_LINE DEDENT
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE
arr [ 0 ] , arr [ i ] = arr [ i ] , arr [ 0 ] NEW_LINE
heapify ( arr , i , 0 ) NEW_LINE
def printArray ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 4 , 6 , 3 , 2 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE heapSort ( arr , n ) NEW_LINE print ( " Sorted ▁ array ▁ is ▁ " ) NEW_LINE printArray ( arr , n ) NEW_LINE DEDENT
def sumBetweenTwoKth ( arr , n , k1 , k2 ) : NEW_LINE
arr . sort ( ) NEW_LINE
result = 0 NEW_LINE for i in range ( k1 , k2 - 1 ) : NEW_LINE INDENT result += arr [ i ] NEW_LINE DEDENT return result NEW_LINE
arr = [ 20 , 8 , 22 , 4 , 12 , 10 , 14 ] NEW_LINE k1 = 3 ; k2 = 6 NEW_LINE n = len ( arr ) NEW_LINE print ( sumBetweenTwoKth ( arr , n , k1 , k2 ) ) NEW_LINE
def minSum ( a , n ) : NEW_LINE
a = sorted ( a ) NEW_LINE num1 , num2 = 0 , 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if i % 2 == 0 : NEW_LINE INDENT num1 = num1 * 10 + a [ i ] NEW_LINE DEDENT else : NEW_LINE INDENT num2 = num2 * 10 + a [ i ] NEW_LINE DEDENT DEDENT return num2 + num1 NEW_LINE
arr = [ 5 , 3 , 0 , 7 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ required ▁ sum ▁ is " , minSum ( arr , n ) ) NEW_LINE
class newNode : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . left = self . right = None NEW_LINE DEDENT DEDENT
def count ( root ) : NEW_LINE INDENT if ( root == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT return ( count ( root . left ) + count ( root . right ) + 1 ) NEW_LINE DEDENT
def checkRec ( root , n ) : NEW_LINE
if ( root == None ) : NEW_LINE INDENT return False NEW_LINE DEDENT
if ( count ( root ) == n - count ( root ) ) : NEW_LINE INDENT return True NEW_LINE DEDENT
return ( checkRec ( root . left , n ) or checkRec ( root . right , n ) ) NEW_LINE
def check ( root ) : NEW_LINE
n = count ( root ) NEW_LINE
return checkRec ( root , n ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = newNode ( 5 ) NEW_LINE root . left = newNode ( 1 ) NEW_LINE root . right = newNode ( 6 ) NEW_LINE root . left . left = newNode ( 3 ) NEW_LINE root . right . left = newNode ( 7 ) NEW_LINE root . right . right = newNode ( 4 ) NEW_LINE if check ( root ) : NEW_LINE INDENT print ( " YES " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " NO " ) NEW_LINE DEDENT DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . key = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def count ( node ) : NEW_LINE INDENT if ( node == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT return ( count ( node . left ) + count ( node . right ) + 1 ) NEW_LINE DEDENT
def checkRec ( root , n ) : NEW_LINE INDENT global res NEW_LINE DEDENT
if ( root == None ) : NEW_LINE return 0 NEW_LINE
c = ( checkRec ( root . left , n ) + 1 + checkRec ( root . right , n ) ) NEW_LINE
if ( c == n - c ) : NEW_LINE INDENT res = True NEW_LINE DEDENT
return c NEW_LINE
def check ( root ) : NEW_LINE
n = count ( root ) NEW_LINE
checkRec ( root , n ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT res = False NEW_LINE root = Node ( 5 ) NEW_LINE root . left = Node ( 1 ) NEW_LINE root . right = Node ( 6 ) NEW_LINE root . left . left = Node ( 3 ) NEW_LINE root . right . left = Node ( 7 ) NEW_LINE root . right . right = Node ( 4 ) NEW_LINE check ( root ) NEW_LINE if res : NEW_LINE INDENT print ( " YES " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " NO " ) NEW_LINE DEDENT DEDENT
preIndex = 0 NEW_LINE
class node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def search ( arr , strt , end , value ) : NEW_LINE INDENT for i in range ( strt , end + 1 ) : NEW_LINE INDENT if ( arr [ i ] == value ) : NEW_LINE INDENT return i NEW_LINE DEDENT DEDENT DEDENT
def buildTree ( inn , pre , inStrt , inEnd ) : NEW_LINE INDENT global preIndex NEW_LINE if ( inStrt > inEnd ) : NEW_LINE INDENT return None NEW_LINE DEDENT DEDENT
tNode = node ( pre [ preIndex ] ) NEW_LINE preIndex += 1 NEW_LINE
if ( inStrt == inEnd ) : NEW_LINE INDENT return tNode NEW_LINE DEDENT
inIndex = search ( inn , inStrt , inEnd , tNode . data ) NEW_LINE
tNode . left = buildTree ( inn , pre , inStrt , inIndex - 1 ) NEW_LINE tNode . right = buildTree ( inn , pre , inIndex + 1 , inEnd ) NEW_LINE return tNode NEW_LINE
def checkPostorder ( node , postOrder , index ) : NEW_LINE INDENT if ( node == None ) : NEW_LINE INDENT return index NEW_LINE DEDENT DEDENT
index = checkPostorder ( node . left , postOrder , index ) NEW_LINE
index = checkPostorder ( node . right , postOrder , index ) NEW_LINE
if ( node . data == postOrder [ index ] ) : NEW_LINE INDENT index += 1 NEW_LINE DEDENT else : NEW_LINE INDENT return - 1 NEW_LINE DEDENT return index NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT inOrder = [ 4 , 2 , 5 , 1 , 3 ] NEW_LINE preOrder = [ 1 , 2 , 4 , 5 , 3 ] NEW_LINE postOrder = [ 4 , 5 , 2 , 3 , 1 ] NEW_LINE lenn = len ( inOrder ) NEW_LINE DEDENT
root = buildTree ( inOrder , preOrder , 0 , lenn - 1 ) NEW_LINE
index = checkPostorder ( root , postOrder , 0 ) NEW_LINE
if ( index == lenn ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def printDistance ( mat ) : NEW_LINE INDENT global N , M NEW_LINE ans = [ [ None ] * M for i in range ( N ) ] NEW_LINE DEDENT
for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE INDENT ans [ i ] [ j ] = 999999999999 NEW_LINE DEDENT DEDENT
for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE DEDENT
for k in range ( N ) : NEW_LINE INDENT for l in range ( M ) : NEW_LINE DEDENT
if ( mat [ k ] [ l ] == 1 ) : NEW_LINE INDENT ans [ i ] [ j ] = min ( ans [ i ] [ j ] , abs ( i - k ) + abs ( j - l ) ) NEW_LINE DEDENT
for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE INDENT print ( ans [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
N = 3 NEW_LINE M = 4 NEW_LINE mat = [ [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 1 , 1 ] , [ 0 , 1 , 1 , 0 ] ] NEW_LINE printDistance ( mat ) NEW_LINE
def isChangeable ( notes , n ) : NEW_LINE
fiveCount = 0 NEW_LINE tenCount = 0 NEW_LINE
for i in range ( n ) : NEW_LINE
if ( notes [ i ] == 5 ) : NEW_LINE INDENT fiveCount += 1 NEW_LINE DEDENT elif ( notes [ i ] == 10 ) : NEW_LINE
if ( fiveCount > 0 ) : NEW_LINE INDENT fiveCount -= 1 NEW_LINE tenCount += 1 NEW_LINE DEDENT else : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE
if ( fiveCount > 0 and tenCount > 0 ) : NEW_LINE INDENT fiveCount -= 1 NEW_LINE tenCount -= 1 NEW_LINE DEDENT
elif ( fiveCount >= 3 ) : NEW_LINE INDENT fiveCount -= 3 NEW_LINE DEDENT else : NEW_LINE INDENT return 0 NEW_LINE DEDENT return 1 NEW_LINE
a = [ 5 , 5 , 5 , 10 , 20 ] NEW_LINE n = len ( a ) NEW_LINE
if ( isChangeable ( a , n ) ) : NEW_LINE INDENT print ( " YES " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " NO " ) NEW_LINE DEDENT
def maxDistance ( arr , n ) : NEW_LINE
mp = { } NEW_LINE
maxDict = 0 NEW_LINE for i in range ( n ) : NEW_LINE
if arr [ i ] not in mp . keys ( ) : NEW_LINE INDENT mp [ arr [ i ] ] = i NEW_LINE DEDENT
else : NEW_LINE INDENT maxDict = max ( maxDict , i - mp [ arr [ i ] ] ) NEW_LINE DEDENT return maxDict NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 3 , 2 , 1 , 2 , 1 , 4 , 5 , 8 , 6 , 7 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print maxDistance ( arr , n ) NEW_LINE DEDENT
def checkDuplicatesWithinK ( arr , n , k ) : NEW_LINE
myset = [ ] NEW_LINE
for i in range ( n ) : NEW_LINE
if arr [ i ] in myset : NEW_LINE INDENT return True NEW_LINE DEDENT
myset . append ( arr [ i ] ) NEW_LINE
if ( i >= k ) : NEW_LINE INDENT myset . remove ( arr [ i - k ] ) NEW_LINE DEDENT return False NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 10 , 5 , 3 , 4 , 3 , 5 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE if ( checkDuplicatesWithinK ( arr , n , 3 ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT DEDENT
def mostFrequent ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
max_count = 1 ; res = arr [ 0 ] ; curr_count = 1 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] == arr [ i - 1 ] ) : NEW_LINE INDENT curr_count += 1 NEW_LINE DEDENT else : NEW_LINE INDENT if ( curr_count > max_count ) : NEW_LINE INDENT max_count = curr_count NEW_LINE res = arr [ i - 1 ] NEW_LINE DEDENT curr_count = 1 NEW_LINE DEDENT DEDENT
if ( curr_count > max_count ) : NEW_LINE INDENT max_count = curr_count NEW_LINE res = arr [ n - 1 ] NEW_LINE DEDENT return res NEW_LINE
arr = [ 1 , 5 , 2 , 1 , 3 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( mostFrequent ( arr , n ) ) NEW_LINE
import math as mt NEW_LINE def mostFrequent ( arr , n ) : NEW_LINE
Hash = dict ( ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT if arr [ i ] in Hash . keys ( ) : NEW_LINE INDENT Hash [ arr [ i ] ] += 1 NEW_LINE DEDENT else : NEW_LINE INDENT Hash [ arr [ i ] ] = 1 NEW_LINE DEDENT DEDENT
max_count = 0 NEW_LINE res = - 1 NEW_LINE for i in Hash : NEW_LINE INDENT if ( max_count < Hash [ i ] ) : NEW_LINE INDENT res = i NEW_LINE max_count = Hash [ i ] NEW_LINE DEDENT DEDENT return res NEW_LINE
arr = [ 1 , 5 , 2 , 1 , 3 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( mostFrequent ( arr , n ) ) NEW_LINE
def smallestSubsegment ( a , n ) : NEW_LINE
left = dict ( ) NEW_LINE
count = dict ( ) NEW_LINE
mx = 0 NEW_LINE
mn , strindex = 0 , 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT x = a [ i ] NEW_LINE DEDENT
if ( x not in count . keys ( ) ) : NEW_LINE INDENT left [ x ] = i NEW_LINE count [ x ] = 1 NEW_LINE DEDENT
else : NEW_LINE INDENT count [ x ] += 1 NEW_LINE DEDENT
if ( count [ x ] > mx ) : NEW_LINE INDENT mx = count [ x ] NEW_LINE DEDENT
mn = i - left [ x ] + 1 NEW_LINE strindex = left [ x ] NEW_LINE
elif ( count [ x ] == mx and i - left [ x ] + 1 < mn ) : NEW_LINE INDENT mn = i - left [ x ] + 1 NEW_LINE strindex = left [ x ] NEW_LINE DEDENT
for i in range ( strindex , strindex + mn ) : NEW_LINE INDENT print ( a [ i ] , end = " ▁ " ) NEW_LINE DEDENT
A = [ 1 , 2 , 2 , 2 , 1 ] NEW_LINE n = len ( A ) NEW_LINE smallestSubsegment ( A , n ) NEW_LINE
def findSymPairs ( arr , row ) : NEW_LINE
hM = dict ( ) NEW_LINE
for i in range ( row ) : NEW_LINE
first = arr [ i ] [ 0 ] NEW_LINE sec = arr [ i ] [ 1 ] NEW_LINE
if ( sec in hM . keys ( ) and hM [ sec ] == first ) : NEW_LINE INDENT print ( " ( " , sec , " , " , first , " ) " ) NEW_LINE DEDENT
else : NEW_LINE INDENT hM [ first ] = sec NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ [ 0 for i in range ( 2 ) ] for i in range ( 5 ) ] NEW_LINE arr [ 0 ] [ 0 ] , arr [ 0 ] [ 1 ] = 11 , 20 NEW_LINE arr [ 1 ] [ 0 ] , arr [ 1 ] [ 1 ] = 30 , 40 NEW_LINE arr [ 2 ] [ 0 ] , arr [ 2 ] [ 1 ] = 5 , 10 NEW_LINE arr [ 3 ] [ 0 ] , arr [ 3 ] [ 1 ] = 40 , 30 NEW_LINE arr [ 4 ] [ 0 ] , arr [ 4 ] [ 1 ] = 10 , 5 NEW_LINE findSymPairs ( arr , 5 ) NEW_LINE DEDENT
def groupElements ( arr , n ) : NEW_LINE
visited = [ False ] * n NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT visited [ i ] = False NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE
if ( visited [ i ] == False ) : NEW_LINE
print ( arr [ i ] , end = " ▁ " ) NEW_LINE for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( arr [ i ] == arr [ j ] ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE visited [ j ] = True NEW_LINE DEDENT DEDENT
arr = [ 4 , 6 , 9 , 2 , 3 , 4 , 9 , 6 , 10 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE groupElements ( arr , n ) NEW_LINE
def areDisjoint ( set1 , set2 , m , n ) : NEW_LINE
for i in range ( 0 , m ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE INDENT if ( set1 [ i ] == set2 [ j ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT
return True NEW_LINE
set1 = [ 12 , 34 , 11 , 9 , 3 ] NEW_LINE set2 = [ 7 , 2 , 1 , 5 ] NEW_LINE m = len ( set1 ) NEW_LINE n = len ( set2 ) NEW_LINE print ( " yes " ) if areDisjoint ( set1 , set2 , m , n ) else ( " ▁ No " ) NEW_LINE
def areDisjoint ( set1 , set2 , m , n ) : NEW_LINE
set1 . sort ( ) NEW_LINE set2 . sort ( ) NEW_LINE
i = 0 ; j = 0 NEW_LINE while ( i < m and j < n ) : NEW_LINE INDENT if ( set1 [ i ] < set2 [ j ] ) : NEW_LINE INDENT i += 1 NEW_LINE DEDENT elif ( set2 [ j ] < set1 [ i ] ) : NEW_LINE INDENT j += 1 NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
set1 = [ 12 , 34 , 11 , 9 , 3 ] NEW_LINE set2 = [ 7 , 2 , 1 , 5 ] NEW_LINE m = len ( set1 ) NEW_LINE n = len ( set2 ) NEW_LINE print ( " Yes " ) if areDisjoint ( set1 , set2 , m , n ) else print ( " No " ) NEW_LINE
def findMissing ( a , b , n , m ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT if ( a [ i ] == b [ j ] ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT if ( j == m - 1 ) : NEW_LINE INDENT print ( a [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 1 , 2 , 6 , 3 , 4 , 5 ] NEW_LINE b = [ 2 , 4 , 3 , 1 , 0 ] NEW_LINE n = len ( a ) NEW_LINE m = len ( b ) NEW_LINE findMissing ( a , b , n , m ) NEW_LINE DEDENT
def findMissing ( a , b , n , m ) : NEW_LINE
s = dict ( ) NEW_LINE for i in range ( m ) : NEW_LINE INDENT s [ b [ i ] ] = 1 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if a [ i ] not in s . keys ( ) : NEW_LINE INDENT print ( a [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
a = [ 1 , 2 , 6 , 3 , 4 , 5 ] NEW_LINE b = [ 2 , 4 , 3 , 1 , 0 ] NEW_LINE n = len ( a ) NEW_LINE m = len ( b ) NEW_LINE findMissing ( a , b , n , m ) NEW_LINE
def areEqual ( arr1 , arr2 , n , m ) : NEW_LINE
if ( n != m ) : NEW_LINE INDENT return False NEW_LINE DEDENT
arr1 . sort ( ) NEW_LINE arr2 . sort ( ) NEW_LINE
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( arr1 [ i ] != arr2 [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
return True NEW_LINE
arr1 = [ 3 , 5 , 2 , 5 , 2 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 5 , 2 ] NEW_LINE n = len ( arr1 ) NEW_LINE m = len ( arr2 ) NEW_LINE if ( areEqual ( arr1 , arr2 , n , m ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def find_maximum ( a , n , k ) : NEW_LINE
b = dict ( ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT x = a [ i ] NEW_LINE DEDENT
d = min ( 1 + i , n - i ) NEW_LINE if x not in b . keys ( ) : NEW_LINE INDENT b [ x ] = d NEW_LINE DEDENT else : NEW_LINE
b [ x ] = min ( d , b [ x ] ) NEW_LINE ans = 10 ** 9 NEW_LINE for i in range ( n ) : NEW_LINE x = a [ i ] NEW_LINE
if ( x != ( k - x ) and ( k - x ) in b . keys ( ) ) : NEW_LINE INDENT ans = min ( max ( b [ x ] , b [ k - x ] ) , ans ) NEW_LINE DEDENT return ans NEW_LINE
a = [ 3 , 5 , 8 , 6 , 7 ] NEW_LINE K = 11 NEW_LINE n = len ( a ) NEW_LINE print ( find_maximum ( a , n , K ) ) NEW_LINE
def isProduct ( arr , n , x ) : NEW_LINE
for i in arr : NEW_LINE INDENT for j in arr : NEW_LINE INDENT if i * j == x : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT DEDENT return False NEW_LINE
arr = [ 10 , 20 , 9 , 40 ] NEW_LINE x = 400 NEW_LINE n = len ( arr ) NEW_LINE if ( isProduct ( arr , n , x ) == True ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT x = 900 NEW_LINE if ( isProduct ( arr , n , x ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def isProduct ( arr , n , x ) : NEW_LINE INDENT if n < 2 : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
s = set ( ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
if arr [ i ] == 0 : NEW_LINE INDENT if x == 0 : NEW_LINE INDENT return True NEW_LINE DEDENT else : NEW_LINE INDENT continue NEW_LINE DEDENT DEDENT
if x % arr [ i ] == 0 : NEW_LINE INDENT if x // arr [ i ] in s : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT
s . add ( arr [ i ] ) NEW_LINE return False NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 10 , 20 , 9 , 40 ] NEW_LINE x = 400 NEW_LINE n = len ( arr ) NEW_LINE if isProduct ( arr , n , x ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT x = 190 NEW_LINE if isProduct ( arr , n , x ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT DEDENT
def printMissing ( arr , n , low , high ) : NEW_LINE
points_of_range = [ False ] * ( high - low + 1 ) NEW_LINE for i in range ( n ) : NEW_LINE
if ( low <= arr [ i ] and arr [ i ] <= high ) : NEW_LINE INDENT points_of_range [ arr [ i ] - low ] = True NEW_LINE DEDENT
for x in range ( high - low + 1 ) : NEW_LINE INDENT if ( points_of_range [ x ] == False ) : NEW_LINE INDENT print ( low + x , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 1 , 3 , 5 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE low , high = 1 , 10 NEW_LINE printMissing ( arr , n , low , high ) NEW_LINE
def find ( a , b , k , n1 , n2 ) : NEW_LINE
s = set ( ) NEW_LINE for i in range ( n2 ) : NEW_LINE INDENT s . add ( b [ i ] ) NEW_LINE DEDENT
missing = 0 NEW_LINE for i in range ( n1 ) : NEW_LINE INDENT if a [ i ] not in s : NEW_LINE INDENT missing += 1 NEW_LINE DEDENT if missing == k : NEW_LINE INDENT return a [ i ] NEW_LINE DEDENT DEDENT return - 1 NEW_LINE
a = [ 0 , 2 , 4 , 6 , 8 , 10 , 12 , 14 , 15 ] NEW_LINE b = [ 4 , 10 , 6 , 8 , 12 ] NEW_LINE n1 = len ( a ) NEW_LINE n2 = len ( b ) NEW_LINE k = 3 NEW_LINE print ( find ( a , b , k , n1 , n2 ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . key = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def isFullTree ( root ) : NEW_LINE
if root is None : NEW_LINE INDENT return True NEW_LINE DEDENT
if root . left is None and root . right is None : NEW_LINE INDENT return True NEW_LINE DEDENT
if root . left is not None and root . right is not None : NEW_LINE INDENT return ( isFullTree ( root . left ) and isFullTree ( root . right ) ) NEW_LINE DEDENT
return False NEW_LINE
root = Node ( 10 ) ; NEW_LINE root . left = Node ( 20 ) ; NEW_LINE root . right = Node ( 30 ) ; NEW_LINE root . left . right = Node ( 40 ) ; NEW_LINE root . left . left = Node ( 50 ) ; NEW_LINE root . right . left = Node ( 60 ) ; NEW_LINE root . right . right = Node ( 70 ) ; NEW_LINE root . left . left . left = Node ( 80 ) ; NEW_LINE root . left . left . right = Node ( 90 ) ; NEW_LINE root . left . right . left = Node ( 80 ) ; NEW_LINE root . left . right . right = Node ( 90 ) ; NEW_LINE root . right . left . left = Node ( 80 ) ; NEW_LINE root . right . left . right = Node ( 90 ) ; NEW_LINE root . right . right . left = Node ( 80 ) ; NEW_LINE root . right . right . right = Node ( 90 ) ; NEW_LINE if isFullTree ( root ) : NEW_LINE INDENT print " The ▁ Binary ▁ tree ▁ is ▁ full " NEW_LINE DEDENT else : NEW_LINE INDENT print " Binary ▁ tree ▁ is ▁ not ▁ full " NEW_LINE DEDENT
def findGreatest ( arr , n ) : NEW_LINE INDENT result = - 1 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n - 1 ) : NEW_LINE INDENT for k in range ( j + 1 , n ) : NEW_LINE INDENT if ( arr [ j ] * arr [ k ] == arr [ i ] ) : NEW_LINE INDENT result = max ( result , arr [ i ] ) NEW_LINE DEDENT DEDENT DEDENT DEDENT return result NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 30 , 10 , 9 , 3 , 35 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findGreatest ( arr , n ) ) NEW_LINE DEDENT
def findGreatest ( arr , n ) : NEW_LINE
m = dict ( ) NEW_LINE for i in arr : NEW_LINE INDENT m [ i ] = m . get ( i , 0 ) + 1 NEW_LINE DEDENT
arr = sorted ( arr ) NEW_LINE for i in range ( n - 1 , 0 , - 1 ) : NEW_LINE
j = 0 NEW_LINE while ( j < i and arr [ j ] <= sqrt ( arr [ i ] ) ) : NEW_LINE INDENT if ( arr [ i ] % arr [ j ] == 0 ) : NEW_LINE INDENT result = arr [ i ] // arr [ j ] NEW_LINE DEDENT DEDENT
if ( result != arr [ j ] and ( result in m . keys ( ) ) and m [ result ] > 0 ) : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT
elif ( result == arr [ j ] and ( result in m . keys ( ) ) and m [ result ] > 1 ) : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT j += 1 NEW_LINE return - 1 NEW_LINE
arr = [ 17 , 2 , 1 , 15 , 30 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findGreatest ( arr , n ) ) NEW_LINE
def subset ( ar , n ) : NEW_LINE
res = 0 NEW_LINE
ar . sort ( ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT count = 1 NEW_LINE DEDENT
for i in range ( n - 1 ) : NEW_LINE INDENT if ar [ i ] == ar [ i + 1 ] : NEW_LINE INDENT count += 1 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
res = max ( res , count ) NEW_LINE return res NEW_LINE
ar = [ 5 , 6 , 9 , 3 , 4 , 3 , 4 ] NEW_LINE n = len ( ar ) NEW_LINE print ( subset ( ar , n ) ) NEW_LINE
def minRemove ( a , b , n , m ) : NEW_LINE
countA = dict ( ) NEW_LINE countB = dict ( ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT countA [ a [ i ] ] = countA . get ( a [ i ] , 0 ) + 1 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT countB [ b [ i ] ] = countB . get ( b [ i ] , 0 ) + 1 NEW_LINE DEDENT
res = 0 NEW_LINE for x in countA : NEW_LINE INDENT if x in countB . keys ( ) : NEW_LINE INDENT res += min ( countA [ x ] , countB [ x ] ) NEW_LINE DEDENT DEDENT
return res NEW_LINE
a = [ 1 , 2 , 3 , 4 ] NEW_LINE b = [ 2 , 3 , 4 , 5 , 8 ] NEW_LINE n = len ( a ) NEW_LINE m = len ( b ) NEW_LINE print ( minRemove ( a , b , n , m ) ) NEW_LINE
def countItems ( list1 , list2 ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in list1 : NEW_LINE INDENT for j in list2 : NEW_LINE INDENT if i [ 0 ] == j [ 0 ] and i [ 1 ] != j [ 1 ] : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT DEDENT
return count NEW_LINE
list1 = [ ( " apple " , 60 ) , ( " bread " , 20 ) , ( " wheat " , 50 ) , ( " oil " , 30 ) ] NEW_LINE list2 = [ ( " milk " , 20 ) , ( " bread " , 15 ) , ( " wheat " , 40 ) , ( " apple " , 60 ) ] NEW_LINE print ( " Count ▁ = ▁ " , countItems ( list1 , list2 ) ) NEW_LINE
def makePermutation ( a , n ) : NEW_LINE
count = dict ( ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT if count . get ( a [ i ] ) : NEW_LINE INDENT count [ a [ i ] ] += 1 NEW_LINE DEDENT else : NEW_LINE INDENT count [ a [ i ] ] = 1 ; NEW_LINE DEDENT DEDENT next_missing = 1 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if count [ a [ i ] ] != 1 or a [ i ] > n or a [ i ] < 1 : NEW_LINE INDENT count [ a [ i ] ] -= 1 NEW_LINE DEDENT DEDENT
while count . get ( next_missing ) : NEW_LINE INDENT next_missing += 1 NEW_LINE DEDENT
a [ i ] = next_missing NEW_LINE count [ next_missing ] = 1 NEW_LINE
A = [ 2 , 2 , 3 , 3 ] NEW_LINE n = len ( A ) NEW_LINE makePermutation ( A , n ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( A [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def getPairsCount ( arr , n , sum ) : NEW_LINE
count = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT if arr [ i ] + arr [ j ] == sum : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT DEDENT return count NEW_LINE
arr = [ 1 , 5 , 7 , - 1 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE sum = 6 NEW_LINE print ( " Count ▁ of ▁ pairs ▁ is " , getPairsCount ( arr , n , sum ) ) NEW_LINE
def countPairs ( arr1 , arr2 , m , n , x ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in range ( m ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE DEDENT
if arr1 [ i ] + arr2 [ j ] == x : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT
return count NEW_LINE
arr1 = [ 1 , 3 , 5 , 7 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 8 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE x = 10 NEW_LINE print ( " Count ▁ = ▁ " , countPairs ( arr1 , arr2 , m , n , x ) ) NEW_LINE
def isPresent ( arr , low , high , value ) : NEW_LINE INDENT while ( low <= high ) : NEW_LINE INDENT mid = ( low + high ) // 2 NEW_LINE DEDENT DEDENT
if ( arr [ mid ] == value ) : NEW_LINE INDENT return True NEW_LINE DEDENT elif ( arr [ mid ] > value ) : NEW_LINE INDENT high = mid - 1 NEW_LINE DEDENT else : NEW_LINE INDENT low = mid + 1 NEW_LINE DEDENT
return False NEW_LINE
def countPairs ( arr1 , arr2 , m , n , x ) : NEW_LINE INDENT count = 0 NEW_LINE for i in range ( m ) : NEW_LINE DEDENT
value = x - arr1 [ i ] NEW_LINE
if ( isPresent ( arr2 , 0 , n - 1 , value ) ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
return count NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr1 = [ 1 , 3 , 5 , 7 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 8 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE x = 10 NEW_LINE print ( " Count ▁ = ▁ " , countPairs ( arr1 , arr2 , m , n , x ) ) NEW_LINE DEDENT
def countPairs ( arr1 , arr2 , m , n , x ) : NEW_LINE INDENT count = 0 NEW_LINE us = set ( ) NEW_LINE DEDENT
for i in range ( m ) : NEW_LINE INDENT us . add ( arr1 [ i ] ) NEW_LINE DEDENT
for j in range ( n ) : NEW_LINE
if x - arr2 [ j ] in us : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
return count NEW_LINE
arr1 = [ 1 , 3 , 5 , 7 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 8 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE x = 10 NEW_LINE print ( " Count ▁ = " , countPairs ( arr1 , arr2 , m , n , x ) ) NEW_LINE
def countPairs ( arr1 , arr2 , m , n , x ) : NEW_LINE INDENT count , l , r = 0 , 0 , n - 1 NEW_LINE DEDENT
while ( l < m and r >= 0 ) : NEW_LINE
if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) : NEW_LINE INDENT l += 1 NEW_LINE r -= 1 NEW_LINE count += 1 NEW_LINE DEDENT
elif ( ( arr1 [ l ] + arr2 [ r ] ) < x ) : NEW_LINE INDENT l += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT r -= 1 NEW_LINE DEDENT
return count NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr1 = [ 1 , 3 , 5 , 7 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 8 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE x = 10 NEW_LINE print ( " Count ▁ = " , countPairs ( arr1 , arr2 , m , n , x ) ) NEW_LINE DEDENT
arr = [ 10 , 2 , - 2 , - 20 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE k = - 10 NEW_LINE res = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT summ = 0 NEW_LINE for j in range ( i , n ) : NEW_LINE DEDENT
summ += arr [ j ] NEW_LINE
if summ == k : NEW_LINE INDENT res += 1 NEW_LINE DEDENT print ( res ) NEW_LINE
def findSubarraySum ( arr , n , Sum ) : NEW_LINE
prevSum = defaultdict ( lambda : 0 ) NEW_LINE res = 0 NEW_LINE
currsum = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE
currsum += arr [ i ] NEW_LINE
if currsum == Sum : NEW_LINE INDENT res += 1 NEW_LINE DEDENT
if ( currsum - Sum ) in prevSum : NEW_LINE INDENT res += prevSum [ currsum - Sum ] NEW_LINE DEDENT
prevSum [ currsum ] += 1 NEW_LINE return res NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 10 , 2 , - 2 , - 20 , 10 ] NEW_LINE Sum = - 10 NEW_LINE n = len ( arr ) NEW_LINE print ( findSubarraySum ( arr , n , Sum ) ) NEW_LINE DEDENT
def countPairs ( arr , n ) : NEW_LINE INDENT result = 0 ; NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT product = arr [ i ] * arr [ j ] ; NEW_LINE DEDENT DEDENT DEDENT
for k in range ( 0 , n ) : NEW_LINE
if ( arr [ k ] == product ) : NEW_LINE INDENT result = result + 1 ; NEW_LINE break ; NEW_LINE DEDENT
return result ; NEW_LINE
arr = [ 6 , 2 , 4 , 12 , 5 , 3 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE print ( countPairs ( arr , n ) ) ; NEW_LINE
def countPairs ( arr , n ) : NEW_LINE INDENT result = 0 NEW_LINE DEDENT
Hash = set ( ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT Hash . add ( arr [ i ] ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT product = arr [ i ] * arr [ j ] NEW_LINE DEDENT DEDENT
if product in ( Hash ) : NEW_LINE INDENT result += 1 NEW_LINE DEDENT
return result NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 6 , 2 , 4 , 12 , 5 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countPairs ( arr , n ) ) NEW_LINE DEDENT
def findPairs ( arr1 , arr2 , n , m , x ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , m ) : NEW_LINE INDENT if ( arr1 [ i ] + arr2 [ j ] == x ) : NEW_LINE INDENT print ( arr1 [ i ] , arr2 [ j ] ) NEW_LINE DEDENT DEDENT DEDENT DEDENT
arr1 = [ 1 , 2 , 3 , 7 , 5 , 4 ] NEW_LINE arr2 = [ 0 , 7 , 4 , 3 , 2 , 1 ] NEW_LINE n = len ( arr1 ) NEW_LINE m = len ( arr2 ) NEW_LINE x = 8 NEW_LINE findPairs ( arr1 , arr2 , n , m , x ) NEW_LINE
def findPairs ( arr1 , arr2 , n , m , x ) : NEW_LINE
s = set ( ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT s . add ( arr1 [ i ] ) NEW_LINE DEDENT
for j in range ( 0 , m ) : NEW_LINE INDENT if ( ( x - arr2 [ j ] ) in s ) : NEW_LINE INDENT print ( ( x - arr2 [ j ] ) , ' ' , arr2 [ j ] ) NEW_LINE DEDENT DEDENT
arr1 = [ 1 , 0 , - 4 , 7 , 6 , 4 ] NEW_LINE arr2 = [ 0 , 2 , 4 , - 3 , 2 , 1 ] NEW_LINE x = 8 NEW_LINE n = len ( arr1 ) NEW_LINE m = len ( arr2 ) NEW_LINE findPairs ( arr1 , arr2 , n , m , x ) NEW_LINE
def countFreq ( a , n ) : NEW_LINE
hm = dict ( ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT hm [ a [ i ] ] = hm . get ( a [ i ] , 0 ) + 1 NEW_LINE DEDENT cumul = 0 NEW_LINE
for i in range ( n ) : NEW_LINE
cumul += hm [ a [ i ] ] NEW_LINE
if ( hm [ a [ i ] ] > 0 ) : NEW_LINE INDENT print ( a [ i ] , " - > " , cumul ) NEW_LINE DEDENT
hm [ a [ i ] ] = 0 NEW_LINE
a = [ 1 , 3 , 2 , 4 , 2 , 1 ] NEW_LINE n = len ( a ) NEW_LINE countFreq ( a , n ) NEW_LINE
def findPair ( arr , n ) : NEW_LINE INDENT found = False NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT for k in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] + arr [ j ] == arr [ k ] ) : NEW_LINE INDENT print ( arr [ i ] , arr [ j ] ) NEW_LINE found = True NEW_LINE DEDENT DEDENT DEDENT DEDENT if ( found == False ) : NEW_LINE INDENT print ( " Not ▁ exist " ) NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 10 , 4 , 8 , 13 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE findPair ( arr , n ) NEW_LINE DEDENT
def printPairs ( arr , n , k ) : NEW_LINE INDENT isPairFound = True NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT
if ( i != j and arr [ i ] % arr [ j ] == k ) : NEW_LINE INDENT print ( " ( " , arr [ i ] , " , ▁ " , arr [ j ] , " ) " , sep = " " , end = " ▁ " ) NEW_LINE isPairFound = True NEW_LINE DEDENT return isPairFound NEW_LINE
arr = [ 2 , 3 , 5 , 4 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE if ( printPairs ( arr , n , k ) == False ) : NEW_LINE INDENT print ( " No ▁ such ▁ pair ▁ exists " ) NEW_LINE DEDENT
import math as mt NEW_LINE def findDivisors ( n ) : NEW_LINE INDENT v = [ ] NEW_LINE DEDENT
for i in range ( 1 , mt . floor ( n ** ( .5 ) ) + 1 ) : NEW_LINE INDENT if ( n % i == 0 ) : NEW_LINE DEDENT
if ( n / i == i ) : NEW_LINE INDENT v . append ( i ) NEW_LINE DEDENT else : NEW_LINE INDENT v . append ( i ) NEW_LINE v . append ( n // i ) NEW_LINE DEDENT return v NEW_LINE
def printPairs ( arr , n , k ) : NEW_LINE
occ = dict ( ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT occ [ arr [ i ] ] = True NEW_LINE DEDENT isPairFound = False NEW_LINE for i in range ( n ) : NEW_LINE
if ( occ [ k ] and k < arr [ i ] ) : NEW_LINE INDENT print ( " ( " , k , " , " , arr [ i ] , " ) " , end = " ▁ " ) NEW_LINE isPairFound = True NEW_LINE DEDENT
if ( arr [ i ] >= k ) : NEW_LINE
v = findDivisors ( arr [ i ] - k ) NEW_LINE
for j in range ( len ( v ) ) : NEW_LINE INDENT if ( arr [ i ] % v [ j ] == k and arr [ i ] != v [ j ] and occ [ v [ j ] ] ) : NEW_LINE INDENT print ( " ( " , arr [ i ] , " , " , v [ j ] , " ) " , end = " ▁ " ) NEW_LINE isPairFound = True NEW_LINE DEDENT DEDENT
return isPairFound NEW_LINE
arr = [ 3 , 1 , 2 , 5 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE k = 2 NEW_LINE if ( printPairs ( arr , n , k ) == False ) : NEW_LINE INDENT print ( " No ▁ such ▁ pair ▁ exists " ) NEW_LINE DEDENT
def convert ( arr , n ) : NEW_LINE
temp = [ arr [ i ] for i in range ( n ) ] NEW_LINE
temp . sort ( ) NEW_LINE
umap = { } NEW_LINE
val = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT umap [ temp [ i ] ] = val NEW_LINE val += 1 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT arr [ i ] = umap [ arr [ i ] ] NEW_LINE DEDENT def printArr ( arr , n ) : NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 10 , 20 , 15 , 12 , 11 , 50 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Given ▁ Array ▁ is ▁ " ) NEW_LINE printArr ( arr , n ) NEW_LINE convert ( arr , n ) NEW_LINE print ( " Converted Array is   " ) NEW_LINE printArr ( arr , n ) NEW_LINE DEDENT
ASCII_SIZE = 256 NEW_LINE def getMaxOccuringChar ( str ) : NEW_LINE
count = [ 0 ] * ASCII_SIZE NEW_LINE
for i in str : NEW_LINE INDENT count [ ord ( i ) ] += 1 ; NEW_LINE DEDENT
max = - 1 NEW_LINE
c = ' ' NEW_LINE
for i in str : NEW_LINE INDENT if max < count [ ord ( i ) ] : NEW_LINE INDENT max = count [ ord ( i ) ] NEW_LINE c = i NEW_LINE DEDENT DEDENT return c NEW_LINE
str = " sample ▁ string " NEW_LINE print " Max ▁ occurring ▁ character ▁ is ▁ " + getMaxOccuringChar ( str ) NEW_LINE
MARKER = ' $ ' NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . key = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT subtrees = { } NEW_LINE
def dupSubUtil ( root ) : NEW_LINE INDENT global subtrees NEW_LINE s = " " NEW_LINE DEDENT
if ( root == None ) : NEW_LINE INDENT return s + MARKER NEW_LINE DEDENT
lStr = dupSubUtil ( root . left ) NEW_LINE if ( s in lStr ) : NEW_LINE return s NEW_LINE
rStr = dupSubUtil ( root . right ) NEW_LINE if ( s in rStr ) : NEW_LINE return s NEW_LINE
s = s + root . key + lStr + rStr NEW_LINE
if ( len ( s ) > 3 and s in subtrees ) : NEW_LINE return " " NEW_LINE subtrees [ s ] = 1 NEW_LINE return s NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = Node ( ' A ' ) NEW_LINE root . left = Node ( ' B ' ) NEW_LINE root . right = Node ( ' C ' ) NEW_LINE root . left . left = Node ( ' D ' ) NEW_LINE root . left . right = Node ( ' E ' ) NEW_LINE root . right . right = Node ( ' B ' ) NEW_LINE root . right . right . right = Node ( ' E ' ) NEW_LINE root . right . right . left = Node ( ' D ' ) NEW_LINE str = dupSubUtil ( root ) NEW_LINE if " " in str : NEW_LINE INDENT print ( " ▁ Yes ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " ▁ No ▁ " ) NEW_LINE DEDENT DEDENT
def printFirstRepeating ( arr , n ) : NEW_LINE
Min = - 1 NEW_LINE
myset = dict ( ) NEW_LINE
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE
if arr [ i ] in myset . keys ( ) : NEW_LINE INDENT Min = i NEW_LINE DEDENT
else : NEW_LINE INDENT myset [ arr [ i ] ] = 1 NEW_LINE DEDENT
if ( Min != - 1 ) : NEW_LINE INDENT print ( " The ▁ first ▁ repeating ▁ element ▁ is " , arr [ Min ] ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " There ▁ are ▁ no ▁ repeating ▁ elements " ) NEW_LINE DEDENT
arr = [ 10 , 5 , 3 , 4 , 3 , 5 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE printFirstRepeating ( arr , n ) NEW_LINE
def printFirstRepeating ( arr , n ) : NEW_LINE
k = 0 NEW_LINE
max = n NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( max < arr [ i ] ) : NEW_LINE INDENT max = arr [ i ] NEW_LINE DEDENT DEDENT
a = [ 0 for i in range ( max + 1 ) ] NEW_LINE
b = [ 0 for i in range ( max + 1 ) ] NEW_LINE for i in range ( n ) : NEW_LINE
if ( a [ arr [ i ] ] ) : NEW_LINE INDENT b [ arr [ i ] ] = 1 NEW_LINE k = 1 NEW_LINE continue NEW_LINE DEDENT else : NEW_LINE
a [ arr [ i ] ] = i NEW_LINE if ( k == 0 ) : NEW_LINE print ( " No ▁ repeating ▁ element ▁ found " ) NEW_LINE else : NEW_LINE min = max + 1 NEW_LINE for i in range ( max + 1 ) : NEW_LINE
if ( a [ i ] and ( min > ( a [ i ] ) ) and b [ i ] ) : NEW_LINE INDENT min = a [ i ] NEW_LINE DEDENT print ( arr [ min ] ) NEW_LINE
arr = [ 10 , 5 , 3 , 4 , 3 , 5 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE printFirstRepeating ( arr , n ) NEW_LINE
def findSum ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE sum = arr [ 0 ] NEW_LINE for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( arr [ i ] != arr [ i + 1 ] ) : NEW_LINE INDENT sum = sum + arr [ i + 1 ] NEW_LINE DEDENT DEDENT return sum NEW_LINE
def main ( ) : NEW_LINE INDENT arr = [ 1 , 2 , 3 , 1 , 1 , 4 , 5 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findSum ( arr , n ) ) NEW_LINE DEDENT if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT main ( ) NEW_LINE DEDENT
def findSum ( arr , n ) : NEW_LINE INDENT s = set ( ) NEW_LINE sum = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if arr [ i ] not in s : NEW_LINE INDENT s . add ( arr [ i ] ) NEW_LINE DEDENT DEDENT for i in s : NEW_LINE INDENT sum = sum + i NEW_LINE DEDENT return sum NEW_LINE
arr = [ 1 , 2 , 3 , 1 , 1 , 4 , 5 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findSum ( arr , n ) ) NEW_LINE
def printKDistinct ( arr , n , k ) : NEW_LINE INDENT dist_count = 0 NEW_LINE for i in range ( n ) : NEW_LINE DEDENT
j = 0 NEW_LINE while j < n : NEW_LINE INDENT if ( i != j and arr [ j ] == arr [ i ] ) : NEW_LINE INDENT break NEW_LINE DEDENT j += 1 NEW_LINE DEDENT
if ( j == n ) : NEW_LINE INDENT dist_count += 1 NEW_LINE DEDENT if ( dist_count == k ) : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT return - 1 NEW_LINE
ar = [ 1 , 2 , 1 , 3 , 4 , 2 ] NEW_LINE n = len ( ar ) NEW_LINE k = 2 NEW_LINE print ( printKDistinct ( ar , n , k ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def areMirror ( a , b ) : NEW_LINE
if a is None and b is None : NEW_LINE INDENT return True NEW_LINE DEDENT
if a is None or b is None : NEW_LINE INDENT return False NEW_LINE DEDENT
return ( a . data == b . data and areMirror ( a . left , b . right ) and areMirror ( a . right , b . left ) ) NEW_LINE
root1 = Node ( 1 ) NEW_LINE root2 = Node ( 1 ) NEW_LINE root1 . left = Node ( 2 ) NEW_LINE root1 . right = Node ( 3 ) NEW_LINE root1 . left . left = Node ( 4 ) NEW_LINE root1 . left . right = Node ( 5 ) NEW_LINE root2 . left = Node ( 3 ) NEW_LINE root2 . right = Node ( 2 ) NEW_LINE root2 . right . left = Node ( 5 ) NEW_LINE root2 . right . right = Node ( 4 ) NEW_LINE if areMirror ( root1 , root2 ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def printPairs ( arr , n ) : NEW_LINE INDENT v = [ ] NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE
if ( abs ( arr [ i ] ) == abs ( arr [ j ] ) ) : NEW_LINE INDENT v . append ( abs ( arr [ i ] ) ) NEW_LINE DEDENT
if ( len ( v ) == 0 ) : NEW_LINE INDENT return ; NEW_LINE DEDENT
v . sort ( ) NEW_LINE
for i in range ( len ( v ) ) : NEW_LINE INDENT print ( - v [ i ] , " " , v [ i ] , end = " ▁ " ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 4 , 8 , 9 , - 4 , 1 , - 1 , - 8 , - 9 ] NEW_LINE n = len ( arr ) NEW_LINE printPairs ( arr , n ) NEW_LINE DEDENT
def canPairs ( arr , n , k ) : NEW_LINE
if ( n & 1 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
freq = defaultdict ( lambda : 0 ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT freq [ ( ( arr [ i ] % k ) + k ) % k ] += 1 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE
rem = ( ( arr [ i ] % k ) + k ) % k NEW_LINE
if ( 2 * rem == k ) : NEW_LINE
if ( freq [ rem ] % 2 != 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
elif ( rem == 0 ) : NEW_LINE
if ( freq [ rem ] & 1 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
elif ( freq [ rem ] != freq [ k - rem ] ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT return 1 NEW_LINE
arr = [ 92 , 75 , 65 , 48 , 45 , 35 ] NEW_LINE k = 10 NEW_LINE n = len ( arr ) NEW_LINE
if ( canPairs ( arr , n , k ) ) : NEW_LINE INDENT print ( " True " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " False " ) NEW_LINE DEDENT
def findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) : NEW_LINE INDENT for i in range ( 0 , n1 ) : NEW_LINE INDENT for j in range ( 0 , n2 ) : NEW_LINE INDENT for k in range ( 0 , n3 ) : NEW_LINE INDENT if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT DEDENT DEDENT return False NEW_LINE DEDENT
a1 = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE a2 = [ 2 , 3 , 6 , 1 , 2 ] NEW_LINE a3 = [ 3 , 2 , 4 , 5 , 6 ] NEW_LINE sum = 9 NEW_LINE n1 = len ( a1 ) NEW_LINE n2 = len ( a2 ) NEW_LINE n3 = len ( a3 ) NEW_LINE print ( " Yes " ) if findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) else print ( " No " ) NEW_LINE
def maxLen ( arr ) : NEW_LINE
hash_map = { } NEW_LINE
curr_sum = 0 NEW_LINE
max_len = 0 NEW_LINE
for i in range ( len ( arr ) ) : NEW_LINE
curr_sum += arr [ i ] NEW_LINE if arr [ i ] is 0 and max_len is 0 : NEW_LINE INDENT max_len = 1 NEW_LINE DEDENT if curr_sum is 0 : NEW_LINE INDENT max_len = i + 1 NEW_LINE DEDENT
if curr_sum in hash_map : NEW_LINE INDENT max_len = max ( max_len , i - hash_map [ curr_sum ] ) NEW_LINE DEDENT
else : NEW_LINE INDENT hash_map [ curr_sum ] = i NEW_LINE DEDENT return max_len NEW_LINE
arr = [ 15 , - 2 , 2 , - 8 , 1 , 7 , 10 , 13 ] NEW_LINE print " Length ▁ of ▁ the ▁ longest ▁ 0 ▁ sum ▁ subarray ▁ is ▁ % ▁ d " % maxLen ( arr ) NEW_LINE
def longestSubsequence ( a , n ) : NEW_LINE
mp = defaultdict ( lambda : 0 ) NEW_LINE
dp = [ 0 for i in range ( n ) ] NEW_LINE maximum = - sys . maxsize NEW_LINE
for i in range ( n ) : NEW_LINE
if a [ i ] - 1 in mp : NEW_LINE
lastIndex = mp [ a [ i ] - 1 ] - 1 NEW_LINE dp [ i ] = 1 + dp [ lastIndex ] NEW_LINE else : NEW_LINE dp [ i ] = 1 NEW_LINE mp [ a [ i ] ] = i + 1 NEW_LINE maximum = max ( maximum , dp [ i ] ) NEW_LINE return maximum NEW_LINE
a = [ 3 , 10 , 3 , 11 , 4 , 5 , 6 , 7 , 8 , 12 ] NEW_LINE n = len ( a ) NEW_LINE print ( longestSubsequence ( a , n ) ) NEW_LINE
def longLenSub ( arr , n ) : NEW_LINE
um = defaultdict ( lambda : 0 ) NEW_LINE
longLen = 0 NEW_LINE
for i in range ( n ) : NEW_LINE
len1 = 0 NEW_LINE
if ( arr [ i - 1 ] in um and len1 < um [ arr [ i ] - 1 ] ) : NEW_LINE INDENT len1 = um [ arr [ i ] - 1 ] NEW_LINE DEDENT
if ( arr [ i ] + 1 in um and len1 < um [ arr [ i ] + 1 ] ) : NEW_LINE INDENT len1 = um [ arr [ i ] + 1 ] NEW_LINE DEDENT
um [ arr [ i ] ] = len1 + 1 NEW_LINE
if longLen < um [ arr [ i ] ] : NEW_LINE INDENT longLen = um [ arr [ i ] ] NEW_LINE DEDENT
return longLen NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 , 3 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Longest ▁ length ▁ subsequence ▁ = " , longLenSub ( arr , n ) ) NEW_LINE
def countWindowDistinct ( win , k ) : NEW_LINE INDENT dist_count = 0 NEW_LINE DEDENT
for i in range ( k ) : NEW_LINE
j = 0 NEW_LINE while j < i : NEW_LINE INDENT if ( win [ i ] == win [ j ] ) : NEW_LINE INDENT break NEW_LINE DEDENT else : NEW_LINE INDENT j += 1 NEW_LINE DEDENT DEDENT if ( j == i ) : NEW_LINE INDENT dist_count += 1 NEW_LINE DEDENT return dist_count NEW_LINE
def countDistinct ( arr , n , k ) : NEW_LINE
for i in range ( n - k + 1 ) : NEW_LINE INDENT print ( countWindowDistinct ( arr [ i : k + i ] , k ) ) NEW_LINE DEDENT
arr = [ 1 , 2 , 1 , 3 , 4 , 2 , 3 ] NEW_LINE k = 4 NEW_LINE n = len ( arr ) NEW_LINE countDistinct ( arr , n , k ) NEW_LINE
def areElementsContiguous ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] - arr [ i - 1 ] > 1 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT DEDENT return 1 NEW_LINE
arr = [ 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE if areElementsContiguous ( arr , n ) : print ( " Yes " ) NEW_LINE else : print ( " No " ) NEW_LINE
def areElementsContiguous ( arr , n ) : NEW_LINE
max1 = max ( arr ) NEW_LINE min1 = min ( arr ) NEW_LINE m = max1 - min1 + 1 NEW_LINE
if ( m > n ) : NEW_LINE INDENT return False NEW_LINE DEDENT
visited = [ 0 ] * m NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT visited [ arr [ i ] - min1 ] = True NEW_LINE DEDENT
for i in range ( 0 , m ) : NEW_LINE INDENT if ( visited [ i ] == False ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
arr = [ 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE if ( areElementsContiguous ( arr , n ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def areElementsContiguous ( arr ) : NEW_LINE
us = set ( ) NEW_LINE for i in arr : us . add ( i ) NEW_LINE
count = 1 NEW_LINE
curr_ele = arr [ 0 ] - 1 NEW_LINE
while curr_ele in us : NEW_LINE
count += 1 NEW_LINE
curr_ele -= 1 NEW_LINE
curr_ele = arr [ 0 ] + 1 NEW_LINE
while curr_ele in us : NEW_LINE
count += 1 NEW_LINE
curr_ele += 1 NEW_LINE
return ( count == len ( us ) ) NEW_LINE
arr = [ 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ] NEW_LINE if areElementsContiguous ( arr ) : print ( " Yes " ) NEW_LINE else : print ( " No " ) NEW_LINE
def subArraySum ( arr , n , Sum ) : NEW_LINE
Map = { } NEW_LINE curr_sum = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT curr_sum = curr_sum + arr [ i ] NEW_LINE DEDENT
if curr_sum == Sum : NEW_LINE INDENT print ( " Sum ▁ found ▁ between ▁ indexes ▁ 0 ▁ to " , i ) NEW_LINE return NEW_LINE DEDENT
if ( curr_sum - Sum ) in Map : NEW_LINE INDENT print ( " Sum ▁ found ▁ between ▁ indexes " ,   \ Map [ curr_sum - Sum ] + 1 , " to " , i ) NEW_LINE return NEW_LINE DEDENT
Map [ curr_sum ] = i NEW_LINE
print ( " No ▁ subarray ▁ with ▁ given ▁ sum ▁ exists " ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 10 , 2 , - 2 , - 20 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE Sum = - 10 NEW_LINE subArraySum ( arr , n , Sum ) NEW_LINE DEDENT
def minInsertion ( tr1 ) : NEW_LINE
n = len ( str1 ) NEW_LINE
res = 0 NEW_LINE
count = [ 0 for i in range ( 26 ) ] NEW_LINE
for i in range ( n ) : NEW_LINE INDENT count [ ord ( str1 [ i ] ) - ord ( ' a ' ) ] += 1 NEW_LINE DEDENT
for i in range ( 26 ) : NEW_LINE INDENT if ( count [ i ] % 2 == 1 ) : NEW_LINE INDENT res += 1 NEW_LINE DEDENT DEDENT
if ( res == 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE INDENT return res - 1 NEW_LINE DEDENT
str1 = " geeksforgeeks " NEW_LINE print ( minInsertion ( str1 ) ) NEW_LINE
def maxdiff ( arr , n ) : NEW_LINE INDENT freq = defaultdict ( lambda : 0 ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT freq [ arr [ i ] ] += 1 NEW_LINE DEDENT ans = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE DEDENT
if freq [ arr [ i ] ] > freq [ arr [ j ] ] and arr [ i ] > arr [ j ] : NEW_LINE INDENT ans = max ( ans , freq [ arr [ i ] ] - freq [ arr [ j ] ] ) NEW_LINE DEDENT elif freq [ arr [ i ] ] < freq [ arr [ j ] ] and arr [ i ] < arr [ j ] : NEW_LINE INDENT ans = max ( ans , freq [ arr [ j ] ] - freq [ arr [ i ] ] ) NEW_LINE DEDENT return ans NEW_LINE
arr = [ 3 , 1 , 3 , 2 , 3 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxdiff ( arr , n ) ) NEW_LINE
def findDiff ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE count = 0 ; max_count = 0 ; min_count = n NEW_LINE for i in range ( 0 , ( n - 1 ) ) : NEW_LINE
if arr [ i ] == arr [ i + 1 ] : NEW_LINE INDENT count += 1 NEW_LINE continue NEW_LINE DEDENT else : NEW_LINE INDENT max_count = max ( max_count , count ) NEW_LINE min_count = min ( min_count , count ) NEW_LINE count = 0 NEW_LINE DEDENT return max_count - min_count NEW_LINE
arr = [ 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findDiff ( arr , n ) ) NEW_LINE
def maxDiff ( arr , n ) : NEW_LINE INDENT SubsetSum_1 = 0 NEW_LINE SubsetSum_2 = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT isSingleOccurance = True NEW_LINE for j in range ( i + 1 , n ) : NEW_LINE DEDENT DEDENT
if ( arr [ i ] == arr [ j ] ) : NEW_LINE INDENT isSingleOccurance = False NEW_LINE arr [ i ] = arr [ j ] = 0 NEW_LINE break NEW_LINE DEDENT if ( isSingleOccurance == True ) : NEW_LINE if ( arr [ i ] > 0 ) : NEW_LINE INDENT SubsetSum_1 += arr [ i ] NEW_LINE DEDENT else : NEW_LINE INDENT SubsetSum_2 += arr [ i ] NEW_LINE DEDENT return abs ( SubsetSum_1 - SubsetSum_2 ) NEW_LINE
arr = [ 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Maximum ▁ Difference ▁ = ▁ { } " . format ( maxDiff ( arr , n ) ) ) NEW_LINE
def maxDiff ( arr , n ) : NEW_LINE INDENT result = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
for i in range ( n - 1 ) : NEW_LINE INDENT if ( abs ( arr [ i ] ) != abs ( arr [ i + 1 ] ) ) : NEW_LINE INDENT result += abs ( arr [ i ] ) NEW_LINE DEDENT else : NEW_LINE INDENT pass NEW_LINE DEDENT DEDENT
if ( arr [ n - 2 ] != arr [ n - 1 ] ) : NEW_LINE INDENT result += abs ( arr [ n - 1 ] ) NEW_LINE DEDENT
return result NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Maximum ▁ Difference ▁ = ▁ " , maxDiff ( arr , n ) ) NEW_LINE DEDENT
def maxDiff ( arr , n ) : NEW_LINE INDENT hashPositive = dict ( ) NEW_LINE hashNegative = dict ( ) NEW_LINE SubsetSum_1 , SubsetSum_2 = 0 , 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] > 0 ) : NEW_LINE INDENT hashPositive [ arr [ i ] ] = hashPositive . get ( arr [ i ] , 0 ) + 1 NEW_LINE DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] > 0 and arr [ i ] in hashPositive . keys ( ) and hashPositive [ arr [ i ] ] == 1 ) : NEW_LINE INDENT SubsetSum_1 += arr [ i ] NEW_LINE DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] < 0 ) : NEW_LINE INDENT hashNegative [ abs ( arr [ i ] ) ] = hashNegative . get ( abs ( arr [ i ] ) , 0 ) + 1 NEW_LINE DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] < 0 and abs ( arr [ i ] ) in hashNegative . keys ( ) and hashNegative [ abs ( arr [ i ] ) ] == 1 ) : NEW_LINE INDENT SubsetSum_2 += arr [ i ] NEW_LINE DEDENT DEDENT return abs ( SubsetSum_1 - SubsetSum_2 ) NEW_LINE
arr = [ 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Maximum ▁ Difference ▁ = " , maxDiff ( arr , n ) ) NEW_LINE
def minRange ( arr , n , k ) : NEW_LINE INDENT l = 0 NEW_LINE r = n NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE
s = [ ] NEW_LINE for j in range ( i , n ) : NEW_LINE INDENT s . append ( arr [ j ] ) NEW_LINE if ( len ( s ) == k ) : NEW_LINE INDENT if ( ( j - i ) < ( r - l ) ) : NEW_LINE INDENT r = j NEW_LINE l = i NEW_LINE DEDENT break NEW_LINE DEDENT DEDENT
if ( j == n ) : NEW_LINE INDENT break NEW_LINE DEDENT
if ( l == 0 and r == n ) : NEW_LINE INDENT print ( " Invalid ▁ k " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( l , r ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE minRange ( arr , n , k ) NEW_LINE DEDENT
def minRange ( arr , n , k ) : NEW_LINE
l , r = 0 , n NEW_LINE i = 0 NEW_LINE
j = - 1 NEW_LINE hm = defaultdict ( lambda : 0 ) NEW_LINE while i < n : NEW_LINE INDENT while j < n : NEW_LINE DEDENT
j += 1 NEW_LINE
if len ( hm ) < k and j < n : NEW_LINE INDENT hm [ arr [ j ] ] += 1 NEW_LINE DEDENT
if len ( hm ) == k and ( ( r - l ) >= ( j - i ) ) : NEW_LINE INDENT l , r = i , j NEW_LINE break NEW_LINE DEDENT
if len ( hm ) < k : NEW_LINE INDENT break NEW_LINE DEDENT
while len ( hm ) == k : NEW_LINE INDENT if hm [ arr [ i ] ] == 1 : NEW_LINE INDENT del ( hm [ arr [ i ] ] ) NEW_LINE DEDENT else : NEW_LINE INDENT hm [ arr [ i ] ] -= 1 NEW_LINE DEDENT DEDENT
i += 1 NEW_LINE
if len ( hm ) == k and ( r - l ) >= ( j - i ) : NEW_LINE INDENT l , r = i , j NEW_LINE DEDENT if hm [ arr [ i ] ] == 1 : NEW_LINE del ( hm [ arr [ i ] ] ) NEW_LINE else : NEW_LINE hm [ arr [ i ] ] -= 1 NEW_LINE i += 1 NEW_LINE if l == 0 and r == n : NEW_LINE print ( " Invalid ▁ k " ) NEW_LINE else : NEW_LINE print ( l , r ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 1 , 2 , 2 , 3 , 3 , 4 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE minRange ( arr , n , k ) NEW_LINE DEDENT
import collections NEW_LINE def longest ( a , n , k ) : NEW_LINE INDENT freq = collections . defaultdict ( int ) NEW_LINE start = 0 NEW_LINE end = 0 NEW_LINE now = 0 NEW_LINE l = 0 NEW_LINE for i in range ( n ) : NEW_LINE DEDENT
freq [ a [ i ] ] += 1 NEW_LINE
if ( freq [ a [ i ] ] == 1 ) : NEW_LINE INDENT now += 1 NEW_LINE DEDENT
while ( now > k ) : NEW_LINE
freq [ a [ l ] ] -= 1 NEW_LINE
if ( freq [ a [ l ] ] == 0 ) : NEW_LINE INDENT now -= 1 NEW_LINE DEDENT
l += 1 NEW_LINE
if ( i - l + 1 >= end - start + 1 ) : NEW_LINE INDENT end = i NEW_LINE start = l NEW_LINE DEDENT
for i in range ( start , end + 1 ) : NEW_LINE INDENT print ( a [ i ] , end = " ▁ " ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 6 , 5 , 1 , 2 , 3 , 2 , 1 , 4 , 5 ] NEW_LINE n = len ( a ) NEW_LINE k = 3 NEW_LINE longest ( a , n , k ) NEW_LINE DEDENT
def sum ( a , n ) : NEW_LINE
cnt = dict ( ) NEW_LINE
ans = 0 NEW_LINE pre_sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT ans += ( i * a [ i ] ) - pre_sum NEW_LINE pre_sum += a [ i ] NEW_LINE DEDENT
if ( a [ i ] - 1 ) in cnt : NEW_LINE INDENT ans -= cnt [ a [ i ] - 1 ] NEW_LINE DEDENT
if ( a [ i ] + 1 ) in cnt : NEW_LINE INDENT ans += cnt [ a [ i ] + 1 ] NEW_LINE DEDENT
if a [ i ] not in cnt : NEW_LINE INDENT cnt [ a [ i ] ] = 0 NEW_LINE DEDENT cnt [ a [ i ] ] += 1 NEW_LINE return ans NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 1 , 2 , 3 , 1 , 3 ] NEW_LINE n = len ( a ) NEW_LINE print ( sum ( a , n ) ) NEW_LINE DEDENT
def calculate ( a ) : NEW_LINE
a . sort ( ) NEW_LINE count = 1 NEW_LINE answer = 0 NEW_LINE
for i in range ( 1 , len ( a ) ) : NEW_LINE INDENT if a [ i ] == a [ i - 1 ] : NEW_LINE DEDENT
count += 1 NEW_LINE else : NEW_LINE
answer = answer + count * ( count - 1 ) // 2 NEW_LINE count = 1 NEW_LINE answer = answer + count * ( count - 1 ) // 2 NEW_LINE return answer NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 1 , 2 , 1 , 2 , 4 ] NEW_LINE DEDENT
print ( calculate ( a ) ) NEW_LINE
def calculate ( a ) : NEW_LINE
maximum = max ( a ) NEW_LINE
frequency = [ 0 for x in range ( maximum + 1 ) ] NEW_LINE
for i in a : NEW_LINE
frequency [ i ] += 1 NEW_LINE answer = 0 NEW_LINE
for i in frequency : NEW_LINE
answer = answer + i * ( i - 1 ) // 2 NEW_LINE return answer NEW_LINE
a = [ 1 , 2 , 1 , 2 , 4 ] NEW_LINE
print ( calculate ( a ) ) NEW_LINE
def countSubarrWithEqualZeroAndOne ( arr , n ) : NEW_LINE
um = dict ( ) NEW_LINE curr_sum = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT curr_sum += ( - 1 if ( arr [ i ] == 0 ) else arr [ i ] ) NEW_LINE if um . get ( curr_sum ) : NEW_LINE INDENT um [ curr_sum ] += 1 NEW_LINE DEDENT else : NEW_LINE INDENT um [ curr_sum ] = 1 NEW_LINE DEDENT DEDENT count = 0 NEW_LINE
for itr in um : NEW_LINE
if um [ itr ] > 1 : NEW_LINE INDENT count += ( ( um [ itr ] * int ( um [ itr ] - 1 ) ) / 2 ) NEW_LINE DEDENT
if um . get ( 0 ) : NEW_LINE INDENT count += um [ 0 ] NEW_LINE DEDENT
return int ( count ) NEW_LINE
arr = [ 1 , 0 , 0 , 1 , 0 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Count ▁ = " , countSubarrWithEqualZeroAndOne ( arr , n ) ) NEW_LINE
def lenOfLongSubarr ( arr , n ) : NEW_LINE
um = { i : 0 for i in range ( 10 ) } NEW_LINE sum = 0 NEW_LINE maxLen = 0 NEW_LINE
for i in range ( n ) : NEW_LINE
if arr [ i ] == 0 : NEW_LINE INDENT sum += - 1 NEW_LINE DEDENT else : NEW_LINE INDENT sum += 1 NEW_LINE DEDENT
if ( sum == 1 ) : NEW_LINE INDENT maxLen = i + 1 NEW_LINE DEDENT
elif ( sum not in um ) : NEW_LINE INDENT um [ sum ] = i NEW_LINE DEDENT
if ( ( sum - 1 ) in um ) : NEW_LINE
if ( maxLen < ( i - um [ sum - 1 ] ) ) : NEW_LINE INDENT maxLen = i - um [ sum - 1 ] NEW_LINE DEDENT
return maxLen NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 0 , 1 , 1 , 0 , 0 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Length ▁ = " , lenOfLongSubarr ( arr , n ) ) NEW_LINE DEDENT
def printAllAPTriplets ( arr , n ) : NEW_LINE INDENT s = [ ] ; NEW_LINE for i in range ( 0 , n - 1 ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT DEDENT
diff = arr [ j ] - arr [ i ] ; NEW_LINE if ( ( arr [ i ] - diff ) in arr ) : NEW_LINE INDENT print ( " { } ▁ { } ▁ { } " . format ( ( arr [ i ] - diff ) , arr [ i ] , arr [ j ] ) , end =   " " ) ; NEW_LINE DEDENT s . append ( arr [ i ] ) ; NEW_LINE
arr = [ 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE printAllAPTriplets ( arr , n ) ; NEW_LINE
def printAllAPTriplets ( arr , n ) : NEW_LINE INDENT for i in range ( 1 , n - 1 ) : NEW_LINE DEDENT
j = i - 1 NEW_LINE k = i + 1 NEW_LINE while ( j >= 0 and k < n ) : NEW_LINE
if ( arr [ j ] + arr [ k ] == 2 * arr [ i ] ) : NEW_LINE INDENT print ( arr [ j ] , " " , arr [ i ] , " " , arr [ k ] ) NEW_LINE DEDENT
k += 1 NEW_LINE j -= 1 NEW_LINE
elif ( arr [ j ] + arr [ k ] < 2 * arr [ i ] ) : NEW_LINE INDENT k += 1 NEW_LINE DEDENT else : NEW_LINE INDENT j -= 1 NEW_LINE DEDENT
arr = [ 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 ] NEW_LINE n = len ( arr ) NEW_LINE printAllAPTriplets ( arr , n ) NEW_LINE
def findTriplets ( a , n , sum ) : NEW_LINE
a . sort ( ) NEW_LINE
flag = False NEW_LINE
for i in range ( n - 2 ) : NEW_LINE INDENT if ( i == 0 or a [ i ] > a [ i - 1 ] ) : NEW_LINE DEDENT
start = i + 1 NEW_LINE
end = n - 1 NEW_LINE
target = sum - a [ i ] NEW_LINE while ( start < end ) : NEW_LINE
if ( start > i + 1 and a [ start ] == a [ start - 1 ] ) : NEW_LINE INDENT start += 1 NEW_LINE continue NEW_LINE DEDENT
if ( end < n - 1 and a [ end ] == a [ end + 1 ] ) : NEW_LINE INDENT end -= 1 NEW_LINE continue NEW_LINE DEDENT
if ( target == a [ start ] + a [ end ] ) : NEW_LINE INDENT print ( " [ " , a [ i ] , " , " , a [ start ] , " , " , a [ end ] , " ] " , end = " ▁ " ) NEW_LINE flag = True NEW_LINE start += 1 NEW_LINE end -= 1 NEW_LINE DEDENT
elif ( target > ( a [ start ] + a [ end ] ) ) : NEW_LINE INDENT start += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT end -= 1 NEW_LINE DEDENT
if ( flag == False ) : NEW_LINE INDENT print ( " No ▁ Such ▁ Triplets ▁ Exist " ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 12 , 3 , 6 , 1 , 6 , 9 ] NEW_LINE n = len ( a ) NEW_LINE sum = 24 NEW_LINE DEDENT
findTriplets ( a , n , sum ) NEW_LINE
def countTriplets ( arr , n , m ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in range ( n - 2 ) : NEW_LINE INDENT for j in range ( i + 1 , n - 1 ) : NEW_LINE INDENT for k in range ( j + 1 , n ) : NEW_LINE INDENT if ( arr [ i ] * arr [ j ] * arr [ k ] == m ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT DEDENT DEDENT return count NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 4 , 6 , 2 , 3 , 8 ] NEW_LINE m = 24 NEW_LINE print ( countTriplets ( arr , len ( arr ) , m ) ) NEW_LINE DEDENT
def countPairs ( arr , n ) : NEW_LINE INDENT ans = 0 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT
if ( arr [ i ] == arr [ j ] ) : NEW_LINE INDENT ans += 1 NEW_LINE DEDENT return ans NEW_LINE
arr = [ 1 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countPairs ( arr , n ) ) NEW_LINE
def countPairs ( arr , n ) : NEW_LINE INDENT mp = dict ( ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if arr [ i ] in mp . keys ( ) : NEW_LINE INDENT mp [ arr [ i ] ] += 1 NEW_LINE DEDENT else : NEW_LINE INDENT mp [ arr [ i ] ] = 1 NEW_LINE DEDENT DEDENT
ans = 0 NEW_LINE for it in mp : NEW_LINE INDENT count = mp [ it ] NEW_LINE ans += ( count * ( count - 1 ) ) // 2 NEW_LINE DEDENT return ans NEW_LINE
arr = [ 1 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countPairs ( arr , n ) ) NEW_LINE
N = 5 NEW_LINE
ptr = [ 0 for i in range ( 501 ) ] NEW_LINE
def findSmallestRange ( arr , n , k ) : NEW_LINE INDENT i , minval , maxval , minrange , minel , maxel , flag , minind = 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 NEW_LINE DEDENT
for i in range ( k + 1 ) : NEW_LINE INDENT ptr [ i ] = 0 NEW_LINE DEDENT minrange = 10 ** 9 NEW_LINE while ( 1 ) : NEW_LINE
minind = - 1 NEW_LINE minval = 10 ** 9 NEW_LINE maxval = - 10 ** 9 NEW_LINE flag = 0 NEW_LINE
for i in range ( k ) : NEW_LINE
if ( ptr [ i ] == n ) : NEW_LINE INDENT flag = 1 NEW_LINE break NEW_LINE DEDENT
if ( ptr [ i ] < n and arr [ i ] [ ptr [ i ] ] < minval ) : NEW_LINE
minind = i NEW_LINE minval = arr [ i ] [ ptr [ i ] ] NEW_LINE
if ( ptr [ i ] < n and arr [ i ] [ ptr [ i ] ] > maxval ) : NEW_LINE INDENT maxval = arr [ i ] [ ptr [ i ] ] NEW_LINE DEDENT
if ( flag ) : NEW_LINE INDENT break NEW_LINE DEDENT ptr [ minind ] += 1 NEW_LINE
if ( ( maxval - minval ) < minrange ) : NEW_LINE INDENT minel = minval NEW_LINE maxel = maxval NEW_LINE minrange = maxel - minel NEW_LINE DEDENT print ( " The ▁ smallest ▁ range ▁ is ▁ [ " , minel , maxel , " ] " ) NEW_LINE
arr = [ [ 4 , 7 , 9 , 12 , 15 ] , [ 0 , 8 , 10 , 14 , 20 ] , [ 6 , 12 , 16 , 30 , 50 ] ] NEW_LINE k = len ( arr ) NEW_LINE findSmallestRange ( arr , N , k ) NEW_LINE
def countNum ( arr , n ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( arr [ i ] != arr [ i + 1 ] and arr [ i ] != arr [ i + 1 ] - 1 ) : NEW_LINE INDENT count += arr [ i + 1 ] - arr [ i ] - 1 ; NEW_LINE DEDENT DEDENT return count NEW_LINE
arr = [ 3 , 5 , 8 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countNum ( arr , n ) ) NEW_LINE
def countNum ( arr , n ) : NEW_LINE INDENT s = dict ( ) NEW_LINE count , maxm , minm = 0 , - 10 ** 9 , 10 ** 9 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT s [ arr [ i ] ] = 1 NEW_LINE if ( arr [ i ] < minm ) : NEW_LINE INDENT minm = arr [ i ] NEW_LINE DEDENT if ( arr [ i ] > maxm ) : NEW_LINE INDENT maxm = arr [ i ] NEW_LINE DEDENT DEDENT
for i in range ( minm , maxm + 1 ) : NEW_LINE INDENT if i not in s . keys ( ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
arr = [ 3 , 5 , 8 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countNum ( arr , n ) ) NEW_LINE
def sumoflength ( arr , n ) : NEW_LINE
s = [ ] NEW_LINE
j = 0 NEW_LINE ans = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT while ( j < n and ( arr [ j ] not in s ) ) : NEW_LINE INDENT s . append ( arr [ j ] ) NEW_LINE j += 1 NEW_LINE DEDENT DEDENT
ans += ( ( j - i ) * ( j - i + 1 ) ) // 2 NEW_LINE
s . remove ( arr [ i ] ) NEW_LINE return ans NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 2 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( sumoflength ( arr , n ) ) NEW_LINE DEDENT
def countDistictSubarray ( arr , n ) : NEW_LINE
vis = dict ( ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT vis [ arr [ i ] ] = 1 NEW_LINE DEDENT k = len ( vis ) NEW_LINE
vid = dict ( ) NEW_LINE
ans = 0 NEW_LINE right = 0 NEW_LINE window = 0 NEW_LINE for left in range ( n ) : NEW_LINE INDENT while ( right < n and window < k ) : NEW_LINE INDENT if arr [ right ] in vid . keys ( ) : NEW_LINE INDENT vid [ arr [ right ] ] += 1 NEW_LINE DEDENT else : NEW_LINE INDENT vid [ arr [ right ] ] = 1 NEW_LINE DEDENT if ( vid [ arr [ right ] ] == 1 ) : NEW_LINE INDENT window += 1 NEW_LINE DEDENT right += 1 NEW_LINE DEDENT DEDENT
if ( window == k ) : NEW_LINE INDENT ans += ( n - right + 1 ) NEW_LINE DEDENT
vid [ arr [ left ] ] -= 1 NEW_LINE
if ( vid [ arr [ left ] ] == 0 ) : NEW_LINE INDENT window -= 1 NEW_LINE DEDENT return ans NEW_LINE
arr = [ 2 , 1 , 3 , 2 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countDistictSubarray ( arr , n ) ) NEW_LINE
def countSubarrays ( arr , n ) : NEW_LINE
difference = 0 NEW_LINE ans = 0 NEW_LINE
hash_positive = [ 0 ] * ( n + 1 ) NEW_LINE hash_negative = [ 0 ] * ( n + 1 ) NEW_LINE
hash_positive [ 0 ] = 1 NEW_LINE
for i in range ( n ) : NEW_LINE
if ( arr [ i ] & 1 == 1 ) : NEW_LINE INDENT difference = difference + 1 NEW_LINE DEDENT else : NEW_LINE INDENT difference = difference - 1 NEW_LINE DEDENT
if ( difference < 0 ) : NEW_LINE INDENT ans += hash_negative [ - difference ] NEW_LINE hash_negative [ - difference ] = hash_negative [ - difference ] + 1 NEW_LINE DEDENT
else : NEW_LINE INDENT ans += hash_positive [ difference ] NEW_LINE hash_positive [ difference ] = hash_positive [ difference ] + 1 NEW_LINE DEDENT
return ans NEW_LINE
arr = [ 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE
print ( " Total ▁ Number ▁ of ▁ Even - Odd ▁ subarrays ▁ are ▁ " + str ( countSubarrays ( arr , n ) ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def height ( root ) : NEW_LINE INDENT global ans , k , lh , rh , f NEW_LINE if ( root == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT left_height = height ( root . left ) NEW_LINE right_height = height ( root . right ) NEW_LINE DEDENT
if ( ans < 1 + left_height + right_height ) : NEW_LINE INDENT ans = 1 + left_height + right_height NEW_LINE DEDENT
k = root NEW_LINE
lh = left_height NEW_LINE rh = right_height NEW_LINE return 1 + max ( left_height , right_height ) NEW_LINE
def printArray ( ints , lenn , f ) : NEW_LINE
if ( f == 0 ) : NEW_LINE INDENT for i in range ( lenn - 1 , - 1 , - 1 ) : NEW_LINE INDENT print ( ints [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT elif ( f == 1 ) : NEW_LINE INDENT for i in range ( lenn ) : NEW_LINE INDENT print ( ints [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def printPathsRecur ( node , path , maxm , pathlen ) : NEW_LINE INDENT global f NEW_LINE if ( node == None ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
path [ pathlen ] = node . data NEW_LINE pathlen += 1 NEW_LINE
if ( node . left == None and node . right == None ) : NEW_LINE
if ( pathlen == maxm and ( f == 0 or f == 1 ) ) : NEW_LINE INDENT printArray ( path , pathlen , f ) NEW_LINE f = 2 NEW_LINE DEDENT else : NEW_LINE
printPathsRecur ( node . left , path , maxm , pathlen ) NEW_LINE printPathsRecur ( node . right , path , maxm , pathlen ) NEW_LINE
def diameter ( root ) : NEW_LINE INDENT if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
global ans , lh , rh NEW_LINE
global f , k , pathLen NEW_LINE height_of_tree = height ( root ) NEW_LINE lPath = [ 0 for i in range ( 100 ) ] NEW_LINE
printPathsRecur ( k . left , lPath , lh , 0 ) ; NEW_LINE print ( k . data , end = " ▁ " ) NEW_LINE rPath = [ 0 for i in range ( 100 ) ] NEW_LINE f = 1 NEW_LINE
printPathsRecur ( k . right , rPath , rh , 0 ) NEW_LINE
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE root . left . right . left = Node ( 6 ) NEW_LINE root . left . right . right = Node ( 7 ) NEW_LINE root . left . left . right = Node ( 8 ) NEW_LINE root . left . left . right . left = Node ( 9 ) NEW_LINE diameter ( root ) NEW_LINE
def findLargestd ( S , n ) : NEW_LINE INDENT found = False NEW_LINE DEDENT
S . sort ( ) NEW_LINE
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT
if ( i == j ) : NEW_LINE INDENT continue NEW_LINE DEDENT for k in range ( j + 1 , n ) : NEW_LINE INDENT if ( i == k ) : NEW_LINE INDENT continue NEW_LINE DEDENT for l in range ( k + 1 , n ) : NEW_LINE INDENT if ( i == l ) : NEW_LINE INDENT continue NEW_LINE DEDENT DEDENT DEDENT
if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) : NEW_LINE INDENT found = True NEW_LINE return S [ i ] NEW_LINE DEDENT if ( found == False ) : NEW_LINE return - 1 NEW_LINE
S = [ 2 , 3 , 5 , 7 , 12 ] NEW_LINE n = len ( S ) NEW_LINE ans = findLargestd ( S , n ) NEW_LINE if ( ans == - 1 ) : NEW_LINE INDENT print ( " No ▁ Solution " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Largest ▁ d ▁ such ▁ that ▁ a ▁ + ▁ b ▁ + " , " c ▁ = ▁ d ▁ is " , ans ) NEW_LINE DEDENT
def findFourElements ( arr , n ) : NEW_LINE INDENT mp = dict ( ) NEW_LINE DEDENT
for i in range ( n - 1 ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT mp [ arr [ i ] + arr [ j ] ] = ( i , j ) NEW_LINE DEDENT DEDENT
d = - 10 ** 9 NEW_LINE for i in range ( n - 1 ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT abs_diff = abs ( arr [ i ] - arr [ j ] ) NEW_LINE DEDENT DEDENT
if abs_diff in mp . keys ( ) : NEW_LINE
p = mp [ abs_diff ] NEW_LINE if ( p [ 0 ] != i and p [ 0 ] != j and p [ 1 ] != i and p [ 1 ] != j ) : NEW_LINE INDENT d = max ( d , max ( arr [ i ] , arr [ j ] ) ) NEW_LINE DEDENT return d NEW_LINE
arr = [ 2 , 3 , 5 , 7 , 12 ] NEW_LINE n = len ( arr ) NEW_LINE res = findFourElements ( arr , n ) NEW_LINE if ( res == - 10 ** 9 ) : NEW_LINE INDENT print ( " No ▁ Solution . " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( res ) NEW_LINE DEDENT
def recaman ( n ) : NEW_LINE
arr = [ 0 ] * n NEW_LINE
arr [ 0 ] = 0 NEW_LINE print ( arr [ 0 ] , end = " , ▁ " ) NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT curr = arr [ i - 1 ] - i NEW_LINE for j in range ( 0 , i ) : NEW_LINE DEDENT
if ( ( arr [ j ] == curr ) or curr < 0 ) : NEW_LINE INDENT curr = arr [ i - 1 ] + i NEW_LINE break NEW_LINE DEDENT arr [ i ] = curr NEW_LINE print ( arr [ i ] , end = " , ▁ " ) NEW_LINE
n = 17 NEW_LINE recaman ( n ) NEW_LINE
def recaman ( n ) : NEW_LINE INDENT if ( n <= 0 ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
print ( 0 , " , " , end = ' ' ) NEW_LINE s = set ( [ ] ) NEW_LINE s . add ( 0 ) NEW_LINE
prev = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT curr = prev - i NEW_LINE DEDENT
if ( curr < 0 or curr in s ) : NEW_LINE INDENT curr = prev + i NEW_LINE DEDENT s . add ( curr ) NEW_LINE print ( curr , " , " , end = ' ' ) NEW_LINE prev = curr NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = 17 NEW_LINE recaman ( n ) NEW_LINE DEDENT
def sumOfDiv ( x ) : NEW_LINE
sum = 1 ; NEW_LINE for i in range ( 2 , int ( math . sqrt ( x ) ) ) : NEW_LINE INDENT if x % i == 0 : NEW_LINE INDENT sum += i NEW_LINE DEDENT DEDENT
if i != x / i : NEW_LINE INDENT sum += x / i NEW_LINE DEDENT return int ( sum ) ; NEW_LINE
def isAmbicle ( a , b ) : NEW_LINE INDENT return ( sumOfDiv ( a ) == b and sumOfDiv ( b ) == a ) NEW_LINE DEDENT
def countPairs ( arr , n ) : NEW_LINE
s = set ( ) NEW_LINE count = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT s . add ( arr [ i ] ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if sumOfDiv ( arr [ i ] ) in s : NEW_LINE DEDENT
sum = sumOfDiv ( arr [ i ] ) NEW_LINE if isAmbicle ( arr [ i ] , sum ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
return int ( count / 2 ) ; NEW_LINE
arr1 = [ 220 , 284 , 1184 , 1210 , 2 , 5 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE print ( countPairs ( arr1 , n1 ) ) NEW_LINE arr2 = [ 2620 , 2924 , 5020 , 5564 , 6232 , 6368 ] NEW_LINE n2 = len ( arr2 ) NEW_LINE print ( countPairs ( arr2 , n2 ) ) NEW_LINE
def findArea ( arr , n ) : NEW_LINE
arr . sort ( reverse = True ) NEW_LINE
dimension = [ 0 , 0 ] NEW_LINE
i = 0 NEW_LINE j = 0 NEW_LINE while ( i < n - 1 and j < 2 ) : NEW_LINE
if ( arr [ i ] == arr [ i + 1 ] ) : NEW_LINE INDENT dimension [ j ] = arr [ i ] NEW_LINE j += 1 NEW_LINE i += 1 NEW_LINE DEDENT i += 1 NEW_LINE
return ( dimension [ 0 ] * dimension [ 1 ] ) NEW_LINE
arr = [ 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findArea ( arr , n ) ) NEW_LINE
def findArea ( arr , n ) : NEW_LINE INDENT s = [ ] NEW_LINE DEDENT
first = 0 NEW_LINE second = 0 NEW_LINE for i in range ( n ) : NEW_LINE
if arr [ i ] not in s : NEW_LINE INDENT s . append ( arr [ i ] ) NEW_LINE continue NEW_LINE DEDENT
if ( arr [ i ] > first ) : NEW_LINE INDENT second = first NEW_LINE first = arr [ i ] NEW_LINE DEDENT elif ( arr [ i ] > second ) : NEW_LINE INDENT second = arr [ i ] NEW_LINE DEDENT
return ( first * second ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findArea ( arr , n ) ) NEW_LINE DEDENT
MAX_PATH_SIZE = 1000 NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def printPath ( size ) : NEW_LINE
minimum_Hd = 10 ** 19 NEW_LINE p = [ ] NEW_LINE global Allpaths NEW_LINE
for it in range ( size ) : NEW_LINE INDENT p = Allpaths [ it ] NEW_LINE minimum_Hd = min ( minimum_Hd , p [ 0 ] ) NEW_LINE DEDENT
for it in range ( size ) : NEW_LINE
p = Allpaths [ it ] NEW_LINE noOfUnderScores = abs ( p [ 0 ] - minimum_Hd ) NEW_LINE
for i in range ( noOfUnderScores ) : NEW_LINE INDENT print ( end = " _ ▁ " ) NEW_LINE DEDENT
print ( p [ 1 ] ) NEW_LINE print ( " = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " ) NEW_LINE
def printAllPathsUtil ( root , HD , order ) : NEW_LINE
global Allpaths NEW_LINE if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
if ( root . left == None and root . right == None ) : NEW_LINE
Allpaths [ order ] = [ HD , root . data ] NEW_LINE printPath ( order + 1 ) NEW_LINE return NEW_LINE
Allpaths [ order ] = [ HD , root . data ] NEW_LINE
printAllPathsUtil ( root . left , HD - 1 , order + 1 ) NEW_LINE
printAllPathsUtil ( root . right , HD + 1 , order + 1 ) NEW_LINE def printAllPaths ( root ) : NEW_LINE global Allpaths NEW_LINE
if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT printAllPathsUtil ( root , 0 , 0 ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT Allpaths = [ [ 0 , 0 ] for i in range ( MAX_PATH_SIZE ) ] NEW_LINE root = Node ( ' A ' ) NEW_LINE root . left = Node ( ' B ' ) NEW_LINE root . right = Node ( ' C ' ) NEW_LINE root . left . left = Node ( ' D ' ) NEW_LINE root . left . right = Node ( ' E ' ) NEW_LINE root . right . left = Node ( ' F ' ) NEW_LINE root . right . right = Node ( ' G ' ) NEW_LINE printAllPaths ( root ) NEW_LINE DEDENT
def longLenStrictBitonicSub ( arr , n ) : NEW_LINE
inc , dcr = dict ( ) , dict ( ) NEW_LINE
len_inc , len_dcr = [ 0 ] * n , [ 0 ] * n NEW_LINE
longLen = 0 NEW_LINE
for i in range ( n ) : NEW_LINE
len = 0 NEW_LINE
if inc . get ( arr [ i ] - 1 ) in inc . values ( ) : NEW_LINE INDENT len = inc . get ( arr [ i ] - 1 ) NEW_LINE DEDENT
inc [ arr [ i ] ] = len_inc [ i ] = len + 1 NEW_LINE
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE
len = 0 NEW_LINE
if dcr . get ( arr [ i ] - 1 ) in dcr . values ( ) : NEW_LINE INDENT len = dcr . get ( arr [ i ] - 1 ) NEW_LINE DEDENT
dcr [ arr [ i ] ] = len_dcr [ i ] = len + 1 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if longLen < ( len_inc [ i ] + len_dcr [ i ] - 1 ) : NEW_LINE INDENT longLen = len_inc [ i ] + len_dcr [ i ] - 1 NEW_LINE DEDENT DEDENT
return longLen NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 5 , 2 , 3 , 4 , 5 , 3 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Longest ▁ length ▁ strict ▁ bitonic ▁ subsequence ▁ = " , longLenStrictBitonicSub ( arr , n ) ) NEW_LINE DEDENT
def leftRotate ( arr , d , n ) : NEW_LINE INDENT leftRotateRec ( arr , 0 , d , n ) ; NEW_LINE DEDENT def leftRotateRec ( arr , i , d , n ) : NEW_LINE
if ( d == 0 or d == n ) : NEW_LINE INDENT return ; NEW_LINE DEDENT
if ( n - d == d ) : NEW_LINE INDENT swap ( arr , i , n - d + i , d ) ; NEW_LINE return ; NEW_LINE DEDENT
if ( d < n - d ) : NEW_LINE INDENT swap ( arr , i , n - d + i , d ) ; NEW_LINE leftRotateRec ( arr , i , d , n - d ) ; NEW_LINE DEDENT
else : NEW_LINE INDENT swap ( arr , i , d , n - d ) ; NEW_LINE leftRotateRec ( arr , n - d + i , 2 * d - n , d ) ; NEW_LINE DEDENT
def printArray ( arr , size ) : NEW_LINE INDENT for i in range ( size ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) ; NEW_LINE DEDENT print ( ) ; NEW_LINE DEDENT
def swap ( arr , fi , si , d ) : NEW_LINE INDENT for i in range ( d ) : NEW_LINE INDENT temp = arr [ fi + i ] ; NEW_LINE arr [ fi + i ] = arr [ si + i ] ; NEW_LINE arr [ si + i ] = temp ; NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ; NEW_LINE leftRotate ( arr , 2 , 7 ) ; NEW_LINE printArray ( arr , 7 ) ; NEW_LINE DEDENT
def leftRotate ( arr , d , n ) : NEW_LINE INDENT if ( d == 0 or d == n ) : NEW_LINE INDENT return ; NEW_LINE DEDENT i = d NEW_LINE j = n - d NEW_LINE while ( i != j ) : NEW_LINE DEDENT
if ( i < j ) : NEW_LINE INDENT swap ( arr , d - i , d + j - i , i ) NEW_LINE j -= i NEW_LINE DEDENT
else : NEW_LINE INDENT swap ( arr , d - i , d , j ) NEW_LINE i -= j NEW_LINE DEDENT
swap ( arr , d - i , d , i ) NEW_LINE
def search ( arr , l , h , key ) : NEW_LINE INDENT if l > h : NEW_LINE INDENT return - 1 NEW_LINE DEDENT mid = ( l + h ) // 2 NEW_LINE if arr [ mid ] == key : NEW_LINE INDENT return mid NEW_LINE DEDENT DEDENT
if arr [ l ] <= arr [ mid ] : NEW_LINE
if key >= arr [ l ] and key <= arr [ mid ] : NEW_LINE INDENT return search ( arr , l , mid - 1 , key ) NEW_LINE DEDENT
return search ( arr , mid + 1 , h , key ) NEW_LINE
if key >= arr [ mid ] and key <= arr [ h ] : NEW_LINE INDENT return search ( a , mid + 1 , h , key ) NEW_LINE DEDENT return search ( arr , l , mid - 1 , key ) NEW_LINE
arr = [ 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 ] NEW_LINE key = 6 NEW_LINE i = search ( arr , 0 , len ( arr ) - 1 , key ) NEW_LINE if i != - 1 : NEW_LINE INDENT print ( " Index : ▁ % ▁ d " % i ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Key ▁ not ▁ found " ) NEW_LINE DEDENT
def pairInSortedRotated ( arr , n , x ) : NEW_LINE
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( arr [ i ] > arr [ i + 1 ] ) : NEW_LINE INDENT break ; NEW_LINE DEDENT DEDENT
l = ( i + 1 ) % n NEW_LINE
r = i NEW_LINE
while ( l != r ) : NEW_LINE
if ( arr [ l ] + arr [ r ] == x ) : NEW_LINE INDENT return True ; NEW_LINE DEDENT
if ( arr [ l ] + arr [ r ] < x ) : NEW_LINE INDENT l = ( l + 1 ) % n ; NEW_LINE DEDENT else : NEW_LINE
r = ( n + r - 1 ) % n ; NEW_LINE return False ; NEW_LINE
arr = [ 11 , 15 , 6 , 8 , 9 , 10 ] NEW_LINE sum = 16 NEW_LINE n = len ( arr ) NEW_LINE if ( pairInSortedRotated ( arr , n , sum ) ) : NEW_LINE INDENT print ( " Array ▁ has ▁ two ▁ elements ▁ with ▁ sum ▁ 16" ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Array ▁ doesn ' t ▁ have ▁ two ▁ elements ▁ with ▁ sum ▁ 16 ▁ " ) NEW_LINE DEDENT
def pairsInSortedRotated ( arr , n , x ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if arr [ i ] > arr [ i + 1 ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
l = ( i + 1 ) % n NEW_LINE
r = i NEW_LINE
cnt = 0 NEW_LINE
while ( l != r ) : NEW_LINE
if arr [ l ] + arr [ r ] == x : NEW_LINE INDENT cnt += 1 NEW_LINE DEDENT
if l == ( r - 1 + n ) % n : NEW_LINE INDENT return cnt NEW_LINE DEDENT l = ( l + 1 ) % n NEW_LINE r = ( r - 1 + n ) % n NEW_LINE
elif arr [ l ] + arr [ r ] < x : NEW_LINE INDENT l = ( l + 1 ) % n NEW_LINE DEDENT
else : NEW_LINE INDENT r = ( n + r - 1 ) % n NEW_LINE DEDENT return cnt NEW_LINE
arr = [ 11 , 15 , 6 , 7 , 9 , 10 ] NEW_LINE s = 16 NEW_LINE print ( pairsInSortedRotated ( arr , 6 , s ) ) NEW_LINE
def maxSum ( arr ) : NEW_LINE
arrSum = 0 NEW_LINE
currVal = 0 NEW_LINE n = len ( arr ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT arrSum = arrSum + arr [ i ] NEW_LINE currVal = currVal + ( i * arr [ i ] ) NEW_LINE DEDENT
maxVal = currVal NEW_LINE
for j in range ( 1 , n ) : NEW_LINE INDENT currVal = currVal + arrSum - n * arr [ n - j ] NEW_LINE if currVal > maxVal : NEW_LINE INDENT maxVal = currVal NEW_LINE DEDENT DEDENT
return maxVal NEW_LINE
arr = [ 10 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ] NEW_LINE print " Max ▁ sum ▁ is : ▁ " , maxSum ( arr ) NEW_LINE
def maxSum ( arr , n ) : NEW_LINE
res = - sys . maxsize NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
curr_sum = 0 NEW_LINE
for j in range ( 0 , n ) : NEW_LINE INDENT index = int ( ( i + j ) % n ) NEW_LINE curr_sum += j * arr [ index ] NEW_LINE DEDENT
res = max ( res , curr_sum ) NEW_LINE return res NEW_LINE
arr = [ 8 , 3 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxSum ( arr , n ) ) NEW_LINE
def maxSum ( arr , n ) : NEW_LINE
cum_sum = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT cum_sum += arr [ i ] NEW_LINE DEDENT
curr_val = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT curr_val += i * arr [ i ] NEW_LINE DEDENT
res = curr_val NEW_LINE
for i in range ( 1 , n ) : NEW_LINE
next_val = ( curr_val - ( cum_sum - arr [ i - 1 ] ) + arr [ i - 1 ] * ( n - 1 ) ) NEW_LINE
curr_val = next_val NEW_LINE
res = max ( res , next_val ) NEW_LINE return res NEW_LINE
arr = [ 8 , 3 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxSum ( arr , n ) ) NEW_LINE
def countRotations ( arr , n ) : NEW_LINE
min = arr [ 0 ] NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT if ( min > arr [ i ] ) : NEW_LINE INDENT min = arr [ i ] NEW_LINE min_index = i NEW_LINE DEDENT DEDENT return min_index ; NEW_LINE
arr = [ 15 , 18 , 2 , 3 , 6 , 12 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countRotations ( arr , n ) ) NEW_LINE
def countRotations ( arr , low , high ) : NEW_LINE
if ( high < low ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( high == low ) : NEW_LINE INDENT return low NEW_LINE DEDENT
mid = low + ( high - low ) / 2 ; NEW_LINE mid = int ( mid ) NEW_LINE
if ( mid < high and arr [ mid + 1 ] < arr [ mid ] ) : NEW_LINE INDENT return ( mid + 1 ) NEW_LINE DEDENT
if ( mid > low and arr [ mid ] < arr [ mid - 1 ] ) : NEW_LINE INDENT return mid NEW_LINE DEDENT
if ( arr [ high ] > arr [ mid ] ) : NEW_LINE INDENT return countRotations ( arr , low , mid - 1 ) ; NEW_LINE DEDENT return countRotations ( arr , mid + 1 , high ) NEW_LINE
arr = [ 15 , 18 , 2 , 3 , 6 , 12 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countRotations ( arr , 0 , n - 1 ) ) NEW_LINE
def preprocess ( arr , n ) : NEW_LINE INDENT temp = [ None ] * ( 2 * n ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT temp [ i ] = temp [ i + n ] = arr [ i ] NEW_LINE DEDENT return temp NEW_LINE
def leftRotate ( arr , n , k , temp ) : NEW_LINE
start = k % n NEW_LINE
for i in range ( start , start + n ) : NEW_LINE INDENT print ( temp [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( " " ) NEW_LINE
arr = [ 1 , 3 , 5 , 7 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE temp = preprocess ( arr , n ) NEW_LINE k = 2 NEW_LINE leftRotate ( arr , n , k , temp ) NEW_LINE k = 3 NEW_LINE leftRotate ( arr , n , k , temp ) NEW_LINE k = 4 NEW_LINE leftRotate ( arr , n , k , temp ) NEW_LINE
def leftRotate ( arr , n , k ) : NEW_LINE
for i in range ( k , k + n ) : NEW_LINE INDENT print ( str ( arr [ i % n ] ) , end = " ▁ " ) NEW_LINE DEDENT
arr = [ 1 , 3 , 5 , 7 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE k = 2 ; NEW_LINE leftRotate ( arr , n , k ) NEW_LINE print ( ) NEW_LINE k = 3 ; NEW_LINE leftRotate ( arr , n , k ) NEW_LINE print ( ) NEW_LINE k = 4 NEW_LINE leftRotate ( arr , n , k ) NEW_LINE print ( ) NEW_LINE
def findMin ( arr , low , high ) : NEW_LINE INDENT while ( low < high ) : NEW_LINE INDENT mid = low + ( high - low ) // 2 ; NEW_LINE if ( arr [ mid ] == arr [ high ] ) : NEW_LINE INDENT high -= 1 ; NEW_LINE DEDENT elif ( arr [ mid ] > arr [ high ] ) : NEW_LINE INDENT low = mid + 1 ; NEW_LINE DEDENT else : NEW_LINE INDENT high = mid ; NEW_LINE DEDENT DEDENT return arr [ high ] ; NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr1 = [ 5 , 6 , 1 , 2 , 3 , 4 ] ; NEW_LINE n1 = len ( arr1 ) ; NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " , findMin ( arr1 , 0 , n1 - 1 ) ) ; NEW_LINE arr2 = [ 1 , 2 , 3 , 4 ] ; NEW_LINE n2 = len ( arr2 ) ; NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " , findMin ( arr2 , 0 , n2 - 1 ) ) ; NEW_LINE arr3 = [ 1 ] ; NEW_LINE n3 = len ( arr3 ) ; NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " , findMin ( arr3 , 0 , n3 - 1 ) ) ; NEW_LINE arr4 = [ 1 , 2 ] ; NEW_LINE n4 = len ( arr4 ) ; NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " , findMin ( arr4 , 0 , n4 - 1 ) ) ; NEW_LINE arr5 = [ 2 , 1 ] ; NEW_LINE n5 = len ( arr5 ) ; NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " , findMin ( arr5 , 0 , n5 - 1 ) ) ; NEW_LINE arr6 = [ 5 , 6 , 7 , 1 , 2 , 3 , 4 ] ; NEW_LINE n6 = len ( arr6 ) ; NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " , findMin ( arr6 , 0 , n6 - 1 ) ) ; NEW_LINE arr7 = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ; NEW_LINE n7 = len ( arr7 ) ; NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " , findMin ( arr7 , 0 , n7 - 1 ) ) ; NEW_LINE arr8 = [ 2 , 3 , 4 , 5 , 6 , 7 , 8 , 1 ] ; NEW_LINE n8 = len ( arr8 ) ; NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " , findMin ( arr8 , 0 , n8 - 1 ) ) ; NEW_LINE arr9 = [ 3 , 4 , 5 , 1 , 2 ] ; NEW_LINE n9 = len ( arr9 ) ; NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " , findMin ( arr9 , 0 , n9 - 1 ) ) ; NEW_LINE DEDENT
def reverseArray ( arr , start , end ) : NEW_LINE INDENT while ( start < end ) : NEW_LINE INDENT arr [ start ] , arr [ end ] = arr [ end ] , arr [ start ] NEW_LINE start = start + 1 NEW_LINE end = end - 1 NEW_LINE DEDENT DEDENT
def rightRotate ( arr , d , n ) : NEW_LINE INDENT reverseArray ( arr , 0 , n - 1 ) ; NEW_LINE reverseArray ( arr , 0 , d - 1 ) ; NEW_LINE reverseArray ( arr , d , n - 1 ) ; NEW_LINE DEDENT
def prArray ( arr , size ) : NEW_LINE INDENT for i in range ( 0 , size ) : NEW_LINE INDENT print ( arr [ i ] , end = ' ▁ ' ) NEW_LINE DEDENT DEDENT
arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE rightRotate ( arr , k , n ) NEW_LINE prArray ( arr , n ) NEW_LINE
def maxHamming ( arr , n ) : NEW_LINE
brr = [ 0 ] * ( 2 * n + 1 ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT brr [ i ] = arr [ i ] NEW_LINE DEDENT for i in range ( n ) : NEW_LINE INDENT brr [ n + i ] = arr [ i ] NEW_LINE DEDENT
maxHam = 0 NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT currHam = 0 NEW_LINE k = 0 NEW_LINE for j in range ( i , i + n ) : NEW_LINE INDENT if brr [ j ] != arr [ k ] : NEW_LINE INDENT currHam += 1 NEW_LINE k = k + 1 NEW_LINE DEDENT DEDENT DEDENT
if currHam == n : NEW_LINE INDENT return n NEW_LINE DEDENT maxHam = max ( maxHam , currHam ) NEW_LINE return maxHam NEW_LINE
arr = [ 2 , 4 , 6 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxHamming ( arr , n ) ) NEW_LINE
def leftRotate ( arr , n , k ) : NEW_LINE
mod = k % n NEW_LINE s = " " NEW_LINE
for i in range ( n ) : NEW_LINE INDENT print str ( arr [ ( mod + i ) % n ] ) , NEW_LINE DEDENT print NEW_LINE return NEW_LINE
arr = [ 1 , 3 , 5 , 7 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE k = 2 NEW_LINE
leftRotate ( arr , n , k ) NEW_LINE k = 3 NEW_LINE
leftRotate ( arr , n , k ) NEW_LINE k = 4 NEW_LINE
leftRotate ( arr , n , k ) NEW_LINE
def findElement ( arr , ranges , rotations , index ) : NEW_LINE INDENT for i in range ( rotations - 1 , - 1 , - 1 ) : NEW_LINE DEDENT
left = ranges [ i ] [ 0 ] NEW_LINE right = ranges [ i ] [ 1 ] NEW_LINE
if ( left <= index and right >= index ) : NEW_LINE INDENT if ( index == left ) : NEW_LINE INDENT index = right NEW_LINE DEDENT else : NEW_LINE INDENT index = index - 1 NEW_LINE DEDENT DEDENT
return arr [ index ] NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE
rotations = 2 NEW_LINE
ranges = [ [ 0 , 2 ] , [ 0 , 3 ] ] NEW_LINE index = 1 NEW_LINE print ( findElement ( arr , ranges , rotations , index ) ) NEW_LINE
def splitArr ( arr , n , k ) : NEW_LINE INDENT for i in range ( 0 , k ) : NEW_LINE DEDENT
x = arr [ 0 ] NEW_LINE for j in range ( 0 , n - 1 ) : NEW_LINE INDENT arr [ j ] = arr [ j + 1 ] NEW_LINE DEDENT arr [ n - 1 ] = x NEW_LINE
arr = [ 12 , 10 , 5 , 6 , 52 , 36 ] NEW_LINE n = len ( arr ) NEW_LINE position = 2 NEW_LINE splitArr ( arr , n , position ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = ' ▁ ' ) NEW_LINE DEDENT
def SplitAndAdd ( A , length , rotation ) : NEW_LINE
tmp = [ 0 for i in range ( length * 2 ) ] NEW_LINE
for i in range ( length ) : NEW_LINE INDENT tmp [ i ] = A [ i ] NEW_LINE tmp [ i + length ] = A [ i ] NEW_LINE DEDENT for i in range ( rotation , rotation + length , 1 ) : NEW_LINE INDENT A [ i - rotation ] = tmp [ i ] ; NEW_LINE DEDENT
arr = [ 12 , 10 , 5 , 6 , 52 , 36 ] NEW_LINE n = len ( arr ) NEW_LINE position = 2 NEW_LINE SplitAndAdd ( arr , n , position ) ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE
def fixArray ( ar , n ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE DEDENT
if ( ar [ j ] == i ) : NEW_LINE INDENT ar [ j ] , ar [ i ] = ar [ i ] , ar [ j ] NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE
if ( ar [ i ] != i ) : NEW_LINE INDENT ar [ i ] = - 1 NEW_LINE DEDENT
print ( " Array ▁ after ▁ Rearranging " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( ar [ i ] , end = " ▁ " ) NEW_LINE DEDENT
ar = [ - 1 , - 1 , 6 , 1 , 9 , 3 , 2 , - 1 , 4 , - 1 ] NEW_LINE n = len ( ar ) NEW_LINE
fixArray ( ar , n ) ; NEW_LINE
def rearrangeArr ( arr , n ) : NEW_LINE
evenPos = int ( n / 2 ) NEW_LINE
oddPos = n - evenPos NEW_LINE tempArr = np . empty ( n , dtype = object ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT tempArr [ i ] = arr [ i ] NEW_LINE DEDENT
tempArr . sort ( ) NEW_LINE j = oddPos - 1 NEW_LINE
for i in range ( 0 , n , 2 ) : NEW_LINE INDENT arr [ i ] = tempArr [ j ] NEW_LINE j = j - 1 NEW_LINE DEDENT j = oddPos NEW_LINE
for i in range ( 1 , n , 2 ) : NEW_LINE INDENT arr [ i ] = tempArr [ j ] NEW_LINE j = j + 1 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = ' ▁ ' ) NEW_LINE DEDENT
arr = a . array ( ' i ' , [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ) NEW_LINE rearrangeArr ( arr , 7 ) NEW_LINE
def pushZerosToEnd ( arr , n ) : NEW_LINE
count = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if arr [ i ] != 0 : NEW_LINE DEDENT
arr [ count ] = arr [ i ] NEW_LINE count += 1 NEW_LINE
while count < n : NEW_LINE INDENT arr [ count ] = 0 NEW_LINE count += 1 NEW_LINE DEDENT
arr = [ 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE pushZerosToEnd ( arr , n ) NEW_LINE print ( " Array ▁ after ▁ pushing ▁ all ▁ zeros ▁ to ▁ end ▁ of ▁ array : " ) NEW_LINE print ( arr ) NEW_LINE
def moveZerosToEnd ( arr , n ) : NEW_LINE
count = 0 ; NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] != 0 ) : NEW_LINE INDENT arr [ count ] , arr [ i ] = arr [ i ] , arr [ count ] NEW_LINE count += 1 NEW_LINE DEDENT DEDENT
def printArray ( arr , n ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 0 , 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Original ▁ array : " , end = " ▁ " ) NEW_LINE printArray ( arr , n ) NEW_LINE moveZerosToEnd ( arr , n ) NEW_LINE print ( " Modified array : " , ▁ end = "   " ) NEW_LINE printArray ( arr , n ) NEW_LINE
def printArray ( array , length ) : NEW_LINE INDENT print ( " [ " , end = " " ) NEW_LINE for i in range ( length ) : NEW_LINE INDENT print ( array [ i ] , end = " " ) if ( i < ( length - 1 ) ) : print ( " , " , end = " ▁ " ) else : print ( " ] " ) NEW_LINE DEDENT DEDENT def reverse ( array , start , end ) : NEW_LINE INDENT while ( start < end ) : NEW_LINE INDENT temp = array [ start ] NEW_LINE array [ start ] = array [ end ] NEW_LINE array [ end ] = temp NEW_LINE start += 1 NEW_LINE end -= 1 NEW_LINE DEDENT DEDENT
def rearrange ( array , start , end ) : NEW_LINE
if ( start == end ) : NEW_LINE INDENT return NEW_LINE DEDENT
rearrange ( array , ( start + 1 ) , end ) NEW_LINE
if ( array [ start ] >= 0 ) : NEW_LINE INDENT reverse ( array , ( start + 1 ) , end ) NEW_LINE reverse ( array , start , end ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT array = [ - 12 , - 11 , - 13 , - 5 , - 6 , 7 , 5 , 3 , 6 ] NEW_LINE length = len ( array ) NEW_LINE countNegative = 0 NEW_LINE for i in range ( length ) : NEW_LINE INDENT if ( array [ i ] < 0 ) : NEW_LINE INDENT countNegative += 1 NEW_LINE DEDENT DEDENT print ( " array : ▁ " , end = " " ) NEW_LINE printArray ( array , length ) NEW_LINE rearrange ( array , 0 , ( length - 1 ) ) NEW_LINE reverse ( array , countNegative , ( length - 1 ) ) NEW_LINE print ( " rearranged ▁ array : ▁ " , end = " " ) NEW_LINE printArray ( array , length ) NEW_LINE DEDENT
def pushZerosToEnd ( arr , n ) : NEW_LINE
count = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT if arr [ i ] != 0 : NEW_LINE DEDENT
arr [ count ] = arr [ i ] NEW_LINE count += 1 NEW_LINE
while ( count < n ) : NEW_LINE INDENT arr [ count ] = 0 NEW_LINE count += 1 NEW_LINE DEDENT
def modifyAndRearrangeArr ( ar , n ) : NEW_LINE
if n == 1 : NEW_LINE INDENT return NEW_LINE DEDENT
for i in range ( 0 , n - 1 ) : NEW_LINE
if ( arr [ i ] != 0 ) and ( arr [ i ] == arr [ i + 1 ] ) : NEW_LINE
arr [ i ] = 2 * arr [ i ] NEW_LINE
arr [ i + 1 ] = 0 NEW_LINE
i += 1 NEW_LINE
pushZerosToEnd ( arr , n ) NEW_LINE
def printArray ( arr , n ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 0 , 2 , 2 , 2 , 0 , 6 , 6 , 0 , 0 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Original ▁ array : " , end = " ▁ " ) NEW_LINE printArray ( arr , n ) NEW_LINE modifyAndRearrangeArr ( arr , n ) NEW_LINE print ( " Modified array : " , end = "   " ) NEW_LINE printArray ( arr , n ) NEW_LINE
def shiftAllZeroToLeft ( arr , n ) : NEW_LINE
lastSeenNonZero = 0 NEW_LINE for index in range ( 0 , n ) : NEW_LINE
if ( array [ index ] != 0 ) : NEW_LINE
array [ index ] , array [ lastSeenNonZero ] = array [ lastSeenNonZero ] , array [ index ] NEW_LINE
lastSeenNonZero += 1 NEW_LINE
def reorder ( arr , index , n ) : NEW_LINE INDENT temp = [ 0 ] * n ; NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT temp [ index [ i ] ] = arr [ i ] NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT arr [ i ] = temp [ i ] NEW_LINE index [ i ] = i NEW_LINE DEDENT
arr = [ 50 , 40 , 70 , 60 , 90 ] NEW_LINE index = [ 3 , 0 , 4 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE reorder ( arr , index , n ) NEW_LINE print ( " Reordered ▁ array ▁ is : " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( " Modified Index array is : " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( index [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def reorder ( arr , index , n ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
while ( index [ i ] != i ) : NEW_LINE
oldTargetI = index [ index [ i ] ] NEW_LINE oldTargetE = arr [ index [ i ] ] NEW_LINE
arr [ index [ i ] ] = arr [ i ] NEW_LINE index [ index [ i ] ] = index [ i ] NEW_LINE
index [ i ] = oldTargetI NEW_LINE arr [ i ] = oldTargetE NEW_LINE
arr = [ 50 , 40 , 70 , 60 , 90 ] NEW_LINE index = [ 3 , 0 , 4 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE reorder ( arr , index , n ) NEW_LINE print ( " Reordered ▁ array ▁ is : " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( " Modified Index array is : " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( index [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def printArray ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
def RearrangePosNeg ( arr , n ) : NEW_LINE INDENT for i in range ( 1 , n ) : NEW_LINE INDENT key = arr [ i ] NEW_LINE DEDENT DEDENT
if ( key > 0 ) : NEW_LINE INDENT continue NEW_LINE DEDENT
j = i - 1 NEW_LINE while ( j >= 0 and arr [ j ] > 0 ) : NEW_LINE INDENT arr [ j + 1 ] = arr [ j ] NEW_LINE j = j - 1 NEW_LINE DEDENT
arr [ j + 1 ] = key NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 ] NEW_LINE n = len ( arr ) NEW_LINE RearrangePosNeg ( arr , n ) NEW_LINE printArray ( arr , n ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . key = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def isLeaf ( node ) : NEW_LINE INDENT if node is None : NEW_LINE INDENT return False NEW_LINE DEDENT if node . left is None and node . right is None : NEW_LINE INDENT return True NEW_LINE DEDENT return False NEW_LINE DEDENT
def leftLeavesSum ( root ) : NEW_LINE
res = 0 NEW_LINE
if root is not None : NEW_LINE
if isLeaf ( root . left ) : NEW_LINE INDENT res += root . left . key NEW_LINE DEDENT else : NEW_LINE
res += leftLeavesSum ( root . left ) NEW_LINE
res += leftLeavesSum ( root . right ) NEW_LINE
return res NEW_LINE
root = Node ( 20 ) NEW_LINE root . left = Node ( 9 ) NEW_LINE root . right = Node ( 49 ) NEW_LINE root . right . left = Node ( 23 ) NEW_LINE root . right . right = Node ( 52 ) NEW_LINE root . right . right . left = Node ( 50 ) NEW_LINE root . left . left = Node ( 5 ) NEW_LINE root . left . right = Node ( 12 ) NEW_LINE root . left . right . right = Node ( 12 ) NEW_LINE print " Sum ▁ of ▁ left ▁ leaves ▁ is " , leftLeavesSum ( root ) NEW_LINE
def printArray ( A , size ) : NEW_LINE INDENT for i in range ( 0 , size ) : NEW_LINE INDENT print ( A [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
def reverse ( arr , l , r ) : NEW_LINE INDENT if l < r : NEW_LINE INDENT arr [ l ] , arr [ r ] = arr [ r ] , arr [ l ] NEW_LINE l , r = l + 1 , r - 1 NEW_LINE reverse ( arr , l , r ) NEW_LINE DEDENT DEDENT
def merge ( arr , l , m , r ) : NEW_LINE
i = l NEW_LINE
j = m + 1 NEW_LINE while i <= m and arr [ i ] < 0 : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
while j <= r and arr [ j ] < 0 : NEW_LINE INDENT j += 1 NEW_LINE DEDENT
reverse ( arr , i , m ) NEW_LINE
reverse ( arr , m + 1 , j - 1 ) NEW_LINE
reverse ( arr , i , j - 1 ) NEW_LINE
def RearrangePosNeg ( arr , l , r ) : NEW_LINE INDENT if l < r : NEW_LINE DEDENT
m = l + ( r - l ) // 2 NEW_LINE
RearrangePosNeg ( arr , l , m ) NEW_LINE RearrangePosNeg ( arr , m + 1 , r ) NEW_LINE merge ( arr , l , m , r ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 ] NEW_LINE arr_size = len ( arr ) NEW_LINE RearrangePosNeg ( arr , 0 , arr_size - 1 ) NEW_LINE printArray ( arr , arr_size ) NEW_LINE DEDENT
def RearrangePosNeg ( arr , n ) : NEW_LINE INDENT i = 0 NEW_LINE j = n - 1 NEW_LINE while ( True ) : NEW_LINE DEDENT
while ( arr [ i ] < 0 and i < n ) : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
while ( arr [ j ] > 0 and j >= 0 ) : NEW_LINE INDENT j -= 1 NEW_LINE DEDENT
if ( i < j ) : NEW_LINE INDENT arr [ i ] , arr [ j ] = arr [ j ] , arr [ i ] NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT
arr = [ - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 ] NEW_LINE n = len ( arr ) NEW_LINE RearrangePosNeg ( arr , n ) NEW_LINE print ( * arr ) NEW_LINE
def rearrangeNaive ( arr , n ) : NEW_LINE
temp = [ 0 ] * n NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT temp [ arr [ i ] ] = i NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT arr [ i ] = temp [ i ] NEW_LINE DEDENT
def printArray ( arr , n ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 1 , 3 , 0 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Given ▁ array ▁ is " , end = " ▁ " ) NEW_LINE printArray ( arr , n ) NEW_LINE rearrangeNaive ( arr , n ) NEW_LINE print ( " Modified array is " , ▁ end ▁ = ▁ "   " ) NEW_LINE printArray ( arr , n ) NEW_LINE
def rearrange ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE DEDENT
arr [ arr [ i ] % n ] += i * n NEW_LINE for i in range ( n ) : NEW_LINE
arr [ i ] //= n NEW_LINE
def prArray ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
arr = [ 2 , 0 , 1 , 4 , 5 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Given ▁ array ▁ is ▁ : ▁ " ) NEW_LINE prArray ( arr , n ) NEW_LINE rearrange ( arr , n ) NEW_LINE print ( " Modified ▁ array ▁ is ▁ : " ) NEW_LINE prArray ( arr , n ) NEW_LINE
def rearrange ( arr , n ) : NEW_LINE
temp = n * [ None ] NEW_LINE
small , large = 0 , n - 1 NEW_LINE
flag = True NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if flag is True : NEW_LINE INDENT temp [ i ] = arr [ large ] NEW_LINE large -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT temp [ i ] = arr [ small ] NEW_LINE small += 1 NEW_LINE DEDENT flag = bool ( 1 - flag ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT arr [ i ] = temp [ i ] NEW_LINE DEDENT return arr NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Original ▁ Array " ) NEW_LINE print ( arr ) NEW_LINE print ( " Modified ▁ Array " ) NEW_LINE print ( rearrange ( arr , n ) ) NEW_LINE
def rearrange ( arr , n ) : NEW_LINE
max_idx = n - 1 NEW_LINE min_idx = 0 NEW_LINE
max_elem = arr [ n - 1 ] + 1 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
if i % 2 == 0 : NEW_LINE INDENT arr [ i ] += ( arr [ max_idx ] % max_elem ) * max_elem NEW_LINE max_idx -= 1 NEW_LINE DEDENT
else : NEW_LINE INDENT arr [ i ] += ( arr [ min_idx ] % max_elem ) * max_elem NEW_LINE min_idx += 1 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT arr [ i ] = arr [ i ] / max_elem NEW_LINE DEDENT
arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Original ▁ Array " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT rearrange ( arr , n ) NEW_LINE print ( " Modified Array " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( int ( arr [ i ] ) , end = " ▁ " ) NEW_LINE DEDENT
def rearrange ( arr , n ) : NEW_LINE
max_ele = arr [ n - 1 ] NEW_LINE min_ele = arr [ 0 ] NEW_LINE
for i in range ( n ) : NEW_LINE
if i % 2 == 0 : NEW_LINE INDENT arr [ i ] = max_ele NEW_LINE max_ele -= 1 NEW_LINE DEDENT
else : NEW_LINE INDENT arr [ i ] = min_ele NEW_LINE min_ele += 1 NEW_LINE DEDENT
arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Origianl ▁ Array " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT rearrange ( arr , n ) NEW_LINE print ( " Modified Array " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . key = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def leftLeavesSumRec ( root , isLeft , summ ) : NEW_LINE INDENT if root is None : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
if root . left is None and root . right is None and isLeft == True : NEW_LINE INDENT summ [ 0 ] += root . key NEW_LINE DEDENT
leftLeavesSumRec ( root . left , 1 , summ ) NEW_LINE leftLeavesSumRec ( root . right , 0 , summ ) NEW_LINE
def leftLeavesSum ( root ) : NEW_LINE INDENT summ = [ 0 ] NEW_LINE DEDENT
leftLeavesSumRec ( root , 0 , summ ) NEW_LINE return summ [ 0 ] NEW_LINE
root = Node ( 20 ) ; NEW_LINE root . left = Node ( 9 ) ; NEW_LINE root . right = Node ( 49 ) ; NEW_LINE root . right . left = Node ( 23 ) ; NEW_LINE root . right . right = Node ( 52 ) ; NEW_LINE root . right . right . left = Node ( 50 ) ; NEW_LINE root . left . left = Node ( 5 ) ; NEW_LINE root . left . right = Node ( 12 ) ; NEW_LINE root . left . right . right = Node ( 12 ) ; NEW_LINE print " Sum ▁ of ▁ left ▁ leaves ▁ is " , leftLeavesSum ( root ) NEW_LINE
def rearrange ( arr , n ) : NEW_LINE INDENT j = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] < 0 ) : NEW_LINE INDENT temp = arr [ i ] NEW_LINE arr [ i ] = arr [ j ] NEW_LINE arr [ j ] = temp NEW_LINE j = j + 1 NEW_LINE DEDENT DEDENT DEDENT
print ( arr ) NEW_LINE
arr = [ - 1 , 2 , - 3 , 4 , 5 , 6 , - 7 , 8 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE rearrange ( arr , n ) NEW_LINE
def segregateElements ( arr , n ) : NEW_LINE
temp = [ 0 for k in range ( n ) ] NEW_LINE
j = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] >= 0 ) : NEW_LINE INDENT temp [ j ] = arr [ i ] NEW_LINE j += 1 NEW_LINE DEDENT DEDENT
if ( j == n or j == 0 ) : NEW_LINE INDENT return NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] < 0 ) : NEW_LINE INDENT temp [ j ] = arr [ i ] NEW_LINE j += 1 NEW_LINE DEDENT DEDENT
for k in range ( n ) : NEW_LINE INDENT arr [ k ] = temp [ k ] NEW_LINE DEDENT
arr = [ 1 , - 1 , - 3 , - 2 , 7 , 5 , 11 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE segregateElements ( arr , n ) ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT print arr [ i ] , NEW_LINE DEDENT
def rearrange ( arr , n ) : NEW_LINE INDENT for i in range ( n - 1 ) : NEW_LINE INDENT if ( i % 2 == 0 and arr [ i ] > arr [ i + 1 ] ) : NEW_LINE INDENT temp = arr [ i ] NEW_LINE arr [ i ] = arr [ i + 1 ] NEW_LINE arr [ i + 1 ] = temp NEW_LINE DEDENT if ( i % 2 != 0 and arr [ i ] < arr [ i + 1 ] ) : NEW_LINE INDENT temp = arr [ i ] NEW_LINE arr [ i ] = arr [ i + 1 ] NEW_LINE arr [ i + 1 ] = temp NEW_LINE DEDENT DEDENT DEDENT
def printArray ( arr , size ) : NEW_LINE INDENT for i in range ( size ) : NEW_LINE INDENT print ( arr [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
arr = [ 6 , 4 , 2 , 1 , 8 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Before ▁ rearranging : ▁ " ) NEW_LINE printArray ( arr , n ) NEW_LINE rearrange ( arr , n ) NEW_LINE print ( " After ▁ rearranging : " ) NEW_LINE printArray ( arr , n ) ; NEW_LINE
def rearrange ( a , size ) : NEW_LINE INDENT positive = 0 NEW_LINE negative = 1 NEW_LINE while ( True ) : NEW_LINE DEDENT
while ( positive < size and a [ positive ] >= 0 ) : NEW_LINE INDENT positive = positive + 2 NEW_LINE DEDENT
while ( negative < size and a [ negative ] <= 0 ) : NEW_LINE INDENT negative = negative + 2 NEW_LINE DEDENT
if ( positive < size and negative < size ) : NEW_LINE INDENT temp = a [ positive ] NEW_LINE a [ positive ] = a [ negative ] NEW_LINE a [ negative ] = temp NEW_LINE DEDENT
else : NEW_LINE INDENT break NEW_LINE DEDENT
arr = [ 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE rearrange ( arr , n ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def printArray ( a , n ) : NEW_LINE INDENT for i in a : NEW_LINE INDENT print ( i , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
arr = [ 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE
printArray ( arr , n ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] >= 0 and i % 2 == 1 ) : NEW_LINE DEDENT
for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( arr [ j ] < 0 and j % 2 == 0 ) : NEW_LINE DEDENT
arr [ i ] , arr [ j ] = arr [ j ] , arr [ i ] NEW_LINE break NEW_LINE elif ( arr [ i ] < 0 and i % 2 == 0 ) : NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( arr [ j ] >= 0 and j % 2 == 1 ) : NEW_LINE DEDENT
arr [ i ] , arr [ j ] = arr [ j ] , arr [ i ] NEW_LINE break NEW_LINE
printArray ( arr , n ) ; NEW_LINE
def arrayEvenAndOdd ( arr , n ) : NEW_LINE INDENT ind = 0 ; NEW_LINE a = [ 0 for i in range ( n ) ] NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] % 2 == 0 ) : NEW_LINE INDENT a [ ind ] = arr [ i ] NEW_LINE ind += 1 NEW_LINE DEDENT DEDENT for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] % 2 != 0 ) : NEW_LINE INDENT a [ ind ] = arr [ i ] NEW_LINE ind += 1 NEW_LINE DEDENT DEDENT for i in range ( n ) : NEW_LINE INDENT print ( a [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
arr = [ 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE
arrayEvenAndOdd ( arr , n ) NEW_LINE
def arrayEvenAndOdd ( arr , n ) : NEW_LINE INDENT i = - 1 NEW_LINE j = 0 NEW_LINE while ( j != n ) : NEW_LINE INDENT if ( arr [ j ] % 2 == 0 ) : NEW_LINE INDENT i = i + 1 NEW_LINE DEDENT DEDENT DEDENT
arr [ i ] , arr [ j ] = arr [ j ] , arr [ i ] NEW_LINE j = j + 1 NEW_LINE
for i in arr : NEW_LINE INDENT print ( str ( i ) + " ▁ " , end = ' ' ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE arrayEvenAndOdd ( arr , n ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . left = None NEW_LINE self . right = None NEW_LINE self . val = key NEW_LINE DEDENT DEDENT
def printPostorder ( root ) : NEW_LINE INDENT if root : NEW_LINE DEDENT
printPostorder ( root . left ) NEW_LINE
printPostorder ( root . right ) NEW_LINE
print ( root . val ) , NEW_LINE
def printInorder ( root ) : NEW_LINE INDENT if root : NEW_LINE DEDENT
printInorder ( root . left ) NEW_LINE
print ( root . val ) , NEW_LINE
printInorder ( root . right ) NEW_LINE
def printPreorder ( root ) : NEW_LINE INDENT if root : NEW_LINE DEDENT
print ( root . val ) , NEW_LINE
printPreorder ( root . left ) NEW_LINE
printPreorder ( root . right ) NEW_LINE
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE print " Preorder ▁ traversal ▁ of ▁ binary ▁ tree ▁ is " NEW_LINE printPreorder ( root ) NEW_LINE print   " NEW_LINE Inorder traversal of binary tree is " NEW_LINE printInorder ( root ) NEW_LINE print   " NEW_LINE Postorder traversal of binary tree is " NEW_LINE printPostorder ( root ) NEW_LINE
def largest ( arr , n ) : NEW_LINE INDENT return max ( arr ) NEW_LINE DEDENT
arr = [ 10 , 324 , 45 , 90 , 9808 ] NEW_LINE n = len ( arr ) NEW_LINE print ( largest ( arr , n ) ) NEW_LINE
def find3largest ( arr , n ) : NEW_LINE
arr = sorted ( arr ) NEW_LINE
check = 0 NEW_LINE count = 1 NEW_LINE for i in range ( 1 , n + 1 ) : NEW_LINE INDENT if ( count < 4 ) : NEW_LINE INDENT if ( check != arr [ n - i ] ) : NEW_LINE DEDENT DEDENT
print ( arr [ n - i ] , end = " ▁ " ) NEW_LINE check = arr [ n - i ] NEW_LINE count += 1 NEW_LINE else : NEW_LINE break NEW_LINE
arr = [ 12 , 45 , 1 , - 1 , 45 , 54 , 23 , 5 , 0 , - 10 ] NEW_LINE n = len ( arr ) NEW_LINE find3largest ( arr , n ) NEW_LINE
def findElements ( arr , n ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT count = 0 NEW_LINE for j in range ( 0 , n ) : NEW_LINE INDENT if arr [ j ] > arr [ i ] : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT DEDENT if count >= 2 : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 2 , - 6 , 3 , 5 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE findElements ( arr , n ) NEW_LINE
def findElements ( arr , n ) : NEW_LINE INDENT arr . sort ( ) NEW_LINE for i in range ( 0 , n - 2 ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 2 , - 6 , 3 , 5 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE findElements ( arr , n ) NEW_LINE
import sys NEW_LINE def findElements ( arr , n ) : NEW_LINE INDENT first = - sys . maxsize NEW_LINE second = - sys . maxsize NEW_LINE for i in range ( 0 , n ) : NEW_LINE DEDENT
if ( arr [ i ] > first ) : NEW_LINE INDENT second = first NEW_LINE first = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > second ) : NEW_LINE INDENT second = arr [ i ] NEW_LINE DEDENT for i in range ( 0 , n ) : NEW_LINE if ( arr [ i ] < second ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
arr = [ 2 , - 6 , 3 , 5 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE findElements ( arr , n ) NEW_LINE
def findMean ( a , n ) : NEW_LINE INDENT sum = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT sum += a [ i ] NEW_LINE DEDENT return float ( sum / n ) NEW_LINE DEDENT
def findMedian ( a , n ) : NEW_LINE
sorted ( a ) NEW_LINE
if n % 2 != 0 : NEW_LINE INDENT return float ( a [ int ( n / 2 ) ] ) NEW_LINE DEDENT return float ( ( a [ int ( ( n - 1 ) / 2 ) ] + a [ int ( n / 2 ) ] ) / 2.0 ) NEW_LINE
a = [ 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 ] NEW_LINE n = len ( a ) NEW_LINE
print ( " Mean ▁ = " , findMean ( a , n ) ) NEW_LINE print ( " Median ▁ = " , findMedian ( a , n ) ) NEW_LINE
def printSmall ( arr , n , k ) : NEW_LINE
for i in range ( k , n ) : NEW_LINE
max_var = arr [ k - 1 ] NEW_LINE pos = k - 1 NEW_LINE for j in range ( k - 2 , - 1 , - 1 ) : NEW_LINE INDENT if ( arr [ j ] > max_var ) : NEW_LINE INDENT max_var = arr [ j ] NEW_LINE pos = j NEW_LINE DEDENT DEDENT
if ( max_var > arr [ i ] ) : NEW_LINE INDENT j = pos NEW_LINE while ( j < k - 1 ) : NEW_LINE INDENT arr [ j ] = arr [ j + 1 ] NEW_LINE j += 1 NEW_LINE DEDENT DEDENT
arr [ k - 1 ] = arr [ i ] NEW_LINE
for i in range ( 0 , k ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
arr = [ 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 ] NEW_LINE n = len ( arr ) NEW_LINE k = 5 NEW_LINE printSmall ( arr , n , k ) NEW_LINE
def kSmallestPair ( arr1 , n1 , arr2 , n2 , k ) : NEW_LINE INDENT if ( k > n1 * n2 ) : NEW_LINE INDENT print ( " k ▁ pairs ▁ don ' t ▁ exist " ) NEW_LINE return NEW_LINE DEDENT DEDENT
index2 = [ 0 for i in range ( n1 ) ] NEW_LINE while ( k > 0 ) : NEW_LINE
min_sum = sys . maxsize NEW_LINE min_index = 0 NEW_LINE
for i1 in range ( 0 , n1 , 1 ) : NEW_LINE
if ( index2 [ i1 ] < n2 and arr1 [ i1 ] + arr2 [ index2 [ i1 ] ] < min_sum ) : NEW_LINE
min_index = i1 NEW_LINE
min_sum = arr1 [ i1 ] + arr2 [ index2 [ i1 ] ] NEW_LINE print ( " ( " , arr1 [ min_index ] , " , " , arr2 [ index2 [ min_index ] ] , " ) " , end = " ▁ " ) NEW_LINE index2 [ min_index ] += 1 NEW_LINE k -= 1 NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr1 = [ 1 , 3 , 11 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE arr2 = [ 2 , 4 , 8 ] NEW_LINE n2 = len ( arr2 ) NEW_LINE k = 4 NEW_LINE kSmallestPair ( arr1 , n1 , arr2 , n2 , k ) NEW_LINE DEDENT
def print2largest ( arr , arr_size ) : NEW_LINE
INDENT if ( arr_size < 2 ) : NEW_LINE INDENT print ( " ▁ Invalid ▁ Input ▁ " ) NEW_LINE return NEW_LINE DEDENT DEDENT
INDENT arr . sort NEW_LINE DEDENT
INDENT for i in range ( arr_size - 2 , - 1 , - 1 ) : NEW_LINE DEDENT
if ( arr [ i ] != arr [ arr_size - 1 ] ) : NEW_LINE print ( " The ▁ second ▁ largest ▁ element ▁ is " , arr [ i ] ) NEW_LINE return NEW_LINE INDENT print ( " There ▁ is ▁ no ▁ second ▁ largest ▁ element " ) NEW_LINE DEDENT
arr = [ 12 , 35 , 1 , 10 , 34 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print2largest ( arr , n ) NEW_LINE
def SumNodes ( l ) : NEW_LINE
leafNodeCount = pow ( 2 , l - 1 ) NEW_LINE
vec = [ [ ] for i in range ( l ) ] NEW_LINE
for i in range ( 1 , leafNodeCount + 1 ) : NEW_LINE INDENT vec [ l - 1 ] . append ( i ) NEW_LINE DEDENT
for i in range ( l - 2 , - 1 , - 1 ) : NEW_LINE INDENT k = 0 NEW_LINE DEDENT
while ( k < len ( vec [ i + 1 ] ) - 1 ) : NEW_LINE
vec [ i ] . append ( vec [ i + 1 ] [ k ] + vec [ i + 1 ] [ k + 1 ] ) NEW_LINE k += 2 NEW_LINE Sum = 0 NEW_LINE
for i in range ( l ) : NEW_LINE INDENT for j in range ( len ( vec [ i ] ) ) : NEW_LINE INDENT Sum += vec [ i ] [ j ] NEW_LINE DEDENT DEDENT return Sum NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT l = 3 NEW_LINE print ( SumNodes ( l ) ) NEW_LINE DEDENT
def print2largest ( arr , arr_size ) : NEW_LINE
if ( arr_size < 2 ) : NEW_LINE INDENT print ( " ▁ Invalid ▁ Input ▁ " ) ; NEW_LINE return ; NEW_LINE DEDENT largest = second = - 2454635434 ; NEW_LINE
for i in range ( 0 , arr_size ) : NEW_LINE INDENT largest = max ( largest , arr [ i ] ) ; NEW_LINE DEDENT
for i in range ( 0 , arr_size ) : NEW_LINE INDENT if ( arr [ i ] != largest ) : NEW_LINE INDENT second = max ( second , arr [ i ] ) ; NEW_LINE DEDENT DEDENT if ( second == - 2454635434 ) : NEW_LINE INDENT print ( " There ▁ is ▁ no ▁ second ▁ " + " largest ▁ element " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " The ▁ second ▁ largest ▁ " +   " element is " , second ) ; NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 12 , 35 , 1 , 10 , 34 , 1 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE print2largest ( arr , n ) ; NEW_LINE DEDENT
def findFirstMissing ( arr , start , end , first ) : NEW_LINE INDENT if ( start < end ) : NEW_LINE INDENT mid = int ( ( start + end ) / 2 ) NEW_LINE DEDENT DEDENT
if ( arr [ mid ] != mid + first ) : NEW_LINE INDENT return findFirstMissing ( arr , start , mid , first ) NEW_LINE DEDENT else : NEW_LINE INDENT return findFirstMissing ( arr , mid + 1 , end , first ) NEW_LINE DEDENT return start + first NEW_LINE
def findSmallestMissinginSortedArray ( arr ) : NEW_LINE
if ( arr [ 0 ] != 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( arr [ - 1 ] == len ( arr ) - 1 ) : NEW_LINE INDENT return len ( arr ) NEW_LINE DEDENT first = arr [ 0 ] NEW_LINE return findFirstMissing ( arr , 0 , len ( arr ) - 1 , first ) NEW_LINE
arr = [ 0 , 1 , 2 , 3 , 4 , 5 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE
print ( " First ▁ Missing ▁ element ▁ is ▁ : " , findSmallestMissinginSortedArray ( arr ) ) NEW_LINE
def sumNodes ( l ) : NEW_LINE
leafNodeCount = math . pow ( 2 , l - 1 ) ; NEW_LINE sumLastLevel = 0 ; NEW_LINE
sumLastLevel = ( ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ) ; NEW_LINE
sum = sumLastLevel * l ; NEW_LINE return int ( sum ) ; NEW_LINE
l = 3 ; NEW_LINE print ( sumNodes ( l ) ) ; NEW_LINE
import math NEW_LINE
def buildSparseTable ( arr , n ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT lookup [ i ] [ 0 ] = arr [ i ] NEW_LINE DEDENT j = 1 NEW_LINE
while ( 1 << j ) <= n : NEW_LINE
i = 0 NEW_LINE while ( i + ( 1 << j ) - 1 ) < n : NEW_LINE
if ( lookup [ i ] [ j - 1 ] < lookup [ i + ( 1 << ( j - 1 ) ) ] [ j - 1 ] ) : NEW_LINE INDENT lookup [ i ] [ j ] = lookup [ i ] [ j - 1 ] NEW_LINE DEDENT else : NEW_LINE INDENT lookup [ i ] [ j ] = lookup [ i + ( 1 << ( j - 1 ) ) ] [ j - 1 ] NEW_LINE DEDENT i += 1 NEW_LINE j += 1 NEW_LINE
def query ( L , R ) : NEW_LINE
j = int ( math . log2 ( R - L + 1 ) ) NEW_LINE
if lookup [ L ] [ j ] <= lookup [ R - ( 1 << j ) + 1 ] [ j ] : NEW_LINE INDENT return lookup [ L ] [ j ] NEW_LINE DEDENT else : NEW_LINE INDENT return lookup [ R - ( 1 << j ) + 1 ] [ j ] NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 7 , 2 , 3 , 0 , 5 , 10 , 3 , 12 , 18 ] NEW_LINE n = len ( a ) NEW_LINE MAX = 500 NEW_LINE lookup = [ [ 0 for i in range ( MAX ) ] for j in range ( MAX ) ] NEW_LINE buildSparseTable ( a , n ) NEW_LINE print ( query ( 0 , 4 ) ) NEW_LINE print ( query ( 4 , 7 ) ) NEW_LINE print ( query ( 7 , 8 ) ) NEW_LINE DEDENT
def add ( arr , N , lo , hi , val ) : NEW_LINE INDENT arr [ lo ] += val NEW_LINE if ( hi != N - 1 ) : NEW_LINE INDENT arr [ hi + 1 ] -= val NEW_LINE DEDENT DEDENT
def updateArray ( arr , N ) : NEW_LINE
for i in range ( 1 , N ) : NEW_LINE INDENT arr [ i ] += arr [ i - 1 ] NEW_LINE DEDENT
def printArr ( arr , N ) : NEW_LINE INDENT updateArray ( arr , N ) NEW_LINE for i in range ( N ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
N = 6 NEW_LINE arr = [ 0 for i in range ( N ) ] NEW_LINE
add ( arr , N , 0 , 2 , 100 ) NEW_LINE add ( arr , N , 1 , 5 , 100 ) NEW_LINE add ( arr , N , 2 , 3 , 100 ) NEW_LINE printArr ( arr , N ) NEW_LINE
MAX = 1000 NEW_LINE
tree = [ 0 ] * ( 4 * MAX ) NEW_LINE
arr = [ 0 ] * MAX NEW_LINE
def gcd ( a : int , b : int ) : NEW_LINE INDENT if a == 0 : NEW_LINE INDENT return b NEW_LINE DEDENT return gcd ( b % a , a ) NEW_LINE DEDENT
def lcm ( a : int , b : int ) : NEW_LINE INDENT return ( a * b ) // gcd ( a , b ) NEW_LINE DEDENT
def build ( node : int , start : int , end : int ) : NEW_LINE
if start == end : NEW_LINE INDENT tree [ node ] = arr [ start ] NEW_LINE return NEW_LINE DEDENT mid = ( start + end ) // 2 NEW_LINE
build ( 2 * node , start , mid ) NEW_LINE build ( 2 * node + 1 , mid + 1 , end ) NEW_LINE
left_lcm = tree [ 2 * node ] NEW_LINE right_lcm = tree [ 2 * node + 1 ] NEW_LINE tree [ node ] = lcm ( left_lcm , right_lcm ) NEW_LINE
def query ( node : int , start : int , end : int , l : int , r : int ) : NEW_LINE
if end < l or start > r : NEW_LINE INDENT return 1 NEW_LINE DEDENT
if l <= start and r >= end : NEW_LINE INDENT return tree [ node ] NEW_LINE DEDENT
mid = ( start + end ) // 2 NEW_LINE left_lcm = query ( 2 * node , start , mid , l , r ) NEW_LINE right_lcm = query ( 2 * node + 1 , mid + 1 , end , l , r ) NEW_LINE return lcm ( left_lcm , right_lcm ) NEW_LINE
arr [ 0 ] = 5 NEW_LINE arr [ 1 ] = 7 NEW_LINE arr [ 2 ] = 5 NEW_LINE arr [ 3 ] = 2 NEW_LINE arr [ 4 ] = 10 NEW_LINE arr [ 5 ] = 12 NEW_LINE arr [ 6 ] = 11 NEW_LINE arr [ 7 ] = 17 NEW_LINE arr [ 8 ] = 14 NEW_LINE arr [ 9 ] = 1 NEW_LINE arr [ 10 ] = 44 NEW_LINE
build ( 1 , 0 , 10 ) NEW_LINE
print ( query ( 1 , 0 , 10 , 2 , 5 ) ) NEW_LINE
print ( query ( 1 , 0 , 10 , 5 , 10 ) ) NEW_LINE
print ( query ( 1 , 0 , 10 , 0 , 10 ) ) NEW_LINE
def GCD ( a , b ) : NEW_LINE INDENT if ( b == 0 ) : NEW_LINE INDENT return a NEW_LINE DEDENT return GCD ( b , a % b ) NEW_LINE DEDENT
def FillPrefixSuffix ( prefix , arr , suffix , n ) : NEW_LINE
prefix [ 0 ] = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT prefix [ i ] = GCD ( prefix [ i - 1 ] , arr [ i ] ) NEW_LINE DEDENT
suffix [ n - 1 ] = arr [ n - 1 ] NEW_LINE for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT suffix [ i ] = GCD ( suffix [ i + 1 ] , arr [ i ] ) NEW_LINE DEDENT
def GCDoutsideRange ( l , r , prefix , suffix , n ) : NEW_LINE
if ( l == 0 ) : NEW_LINE INDENT return suffix [ r + 1 ] NEW_LINE DEDENT
if ( r == n - 1 ) : NEW_LINE INDENT return prefix [ l - 1 ] NEW_LINE DEDENT return GCD ( prefix [ l - 1 ] , suffix [ r + 1 ] ) NEW_LINE
arr = [ 2 , 6 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE prefix = [ ] NEW_LINE suffix = [ ] NEW_LINE for i in range ( n + 1 ) : NEW_LINE INDENT prefix . append ( 0 ) NEW_LINE suffix . append ( 0 ) NEW_LINE DEDENT FillPrefixSuffix ( prefix , arr , suffix , n ) NEW_LINE l = 0 NEW_LINE r = 0 NEW_LINE print ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) NEW_LINE l = 1 NEW_LINE r = 1 NEW_LINE print ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) NEW_LINE l = 1 NEW_LINE r = 2 NEW_LINE print ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) NEW_LINE
def countInRange ( arr , n , x , y ) : NEW_LINE
count = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE
if ( arr [ i ] >= x and arr [ i ] <= y ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT return count NEW_LINE
arr = [ 1 , 3 , 4 , 9 , 10 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE
i = 1 NEW_LINE j = 4 NEW_LINE print ( countInRange ( arr , n , i , j ) ) NEW_LINE i = 9 NEW_LINE j = 12 NEW_LINE print ( countInRange ( arr , n , i , j ) ) NEW_LINE
def lowerIndex ( arr , n , x ) : NEW_LINE INDENT l = 0 NEW_LINE h = n - 1 NEW_LINE while ( l <= h ) : NEW_LINE INDENT mid = int ( ( l + h ) / 2 ) NEW_LINE if ( arr [ mid ] >= x ) : NEW_LINE h = mid - 1 NEW_LINE else : NEW_LINE l = mid + 1 NEW_LINE DEDENT return l NEW_LINE DEDENT
def upperIndex ( arr , n , x ) : NEW_LINE INDENT l = 0 NEW_LINE h = n - 1 NEW_LINE while ( l <= h ) : NEW_LINE INDENT mid = int ( ( l + h ) / 2 ) NEW_LINE if ( arr [ mid ] <= x ) : NEW_LINE l = mid + 1 NEW_LINE else : NEW_LINE h = mid - 1 NEW_LINE DEDENT return h NEW_LINE DEDENT
def countInRange ( arr , n , x , y ) : NEW_LINE
INDENT count = 0 ; NEW_LINE count = upperIndex ( arr , n , y ) - lowerIndex ( arr , n , x ) + 1 ; NEW_LINE return count NEW_LINE DEDENT
arr = [ 1 , 3 , 4 , 9 , 10 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE
arr . sort ( ) NEW_LINE
i = 1 NEW_LINE j = 4 NEW_LINE print ( countInRange ( arr , n , i , j ) ) NEW_LINE i = 9 NEW_LINE j = 12 NEW_LINE print ( countInRange ( arr , n , i , j ) ) NEW_LINE
def precompute ( arr , n , pre ) : NEW_LINE INDENT pre [ n - 1 ] = arr [ n - 1 ] * pow ( 2 , 0 ) NEW_LINE i = n - 2 NEW_LINE while ( i >= 0 ) : NEW_LINE INDENT pre [ i ] = ( pre [ i + 1 ] + arr [ i ] * ( 1 << ( n - 1 - i ) ) ) NEW_LINE i -= 1 NEW_LINE DEDENT DEDENT
def decimalOfSubarr ( arr , l , r , n , pre ) : NEW_LINE
if ( r != n - 1 ) : NEW_LINE INDENT return ( ( pre [ l ] - pre [ r + 1 ] ) / ( 1 << ( n - 1 - r ) ) ) NEW_LINE DEDENT return pre [ l ] / ( 1 << ( n - 1 - r ) ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 0 , 1 , 0 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE pre = [ 0 for i in range ( n ) ] NEW_LINE precompute ( arr , n , pre ) NEW_LINE print ( int ( decimalOfSubarr ( arr , 2 , 4 , n , pre ) ) ) NEW_LINE print ( int ( decimalOfSubarr ( arr , 4 , 5 , n , pre ) ) ) NEW_LINE DEDENT
def answerQuery ( a , n , l , r ) : NEW_LINE
count = 0 NEW_LINE
l = l - 1 NEW_LINE
for i in range ( l , r , 1 ) : NEW_LINE INDENT element = a [ i ] NEW_LINE divisors = 0 NEW_LINE DEDENT
for j in range ( l , r , 1 ) : NEW_LINE
if ( a [ j ] % a [ i ] == 0 ) : NEW_LINE INDENT divisors += 1 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT
if ( divisors == ( r - l ) ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
return count NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 1 , 2 , 3 , 5 ] NEW_LINE n = len ( a ) NEW_LINE l = 1 NEW_LINE r = 4 NEW_LINE print ( answerQuery ( a , n , l , r ) ) NEW_LINE l = 2 NEW_LINE r = 4 NEW_LINE print ( answerQuery ( a , n , l , r ) ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . data = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
grid = { } NEW_LINE
def addConsideringGrid ( root , level , index ) : NEW_LINE INDENT global grid NEW_LINE DEDENT
if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
grid [ level - index ] = ( grid . get ( level - index , 0 ) + root . data ) NEW_LINE
addConsideringGrid ( root . left , level + 1 , index - 1 ) NEW_LINE
addConsideringGrid ( root . right , level + 1 , index + 1 ) NEW_LINE def diagonalSum ( root ) : NEW_LINE
addConsideringGrid ( root , 0 , 0 ) NEW_LINE ans = [ ] NEW_LINE
for x in grid : NEW_LINE INDENT ans . append ( grid [ x ] ) NEW_LINE DEDENT return ans NEW_LINE
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 9 ) NEW_LINE root . left . right = Node ( 6 ) NEW_LINE root . right . left = Node ( 4 ) NEW_LINE root . right . right = Node ( 5 ) NEW_LINE root . right . left . right = Node ( 7 ) NEW_LINE root . right . left . left = Node ( 12 ) NEW_LINE root . left . right . left = Node ( 11 ) NEW_LINE root . left . left . right = Node ( 10 ) NEW_LINE
v = diagonalSum ( root ) NEW_LINE
for i in v : NEW_LINE INDENT print ( i , end = " ▁ " ) NEW_LINE DEDENT
import math NEW_LINE one = [ [ 0 for x in range ( 32 ) ] for y in range ( 100001 ) ] NEW_LINE MAX = 2147483647 NEW_LINE
def make_prefix ( A , n ) : NEW_LINE INDENT global one , MAX NEW_LINE for j in range ( 0 , 32 ) : NEW_LINE INDENT one [ 0 ] [ j ] = 0 NEW_LINE DEDENT DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT a = A [ i - 1 ] NEW_LINE for j in range ( 0 , 32 ) : NEW_LINE INDENT x = int ( math . pow ( 2 , j ) ) NEW_LINE DEDENT DEDENT
if ( a & x ) : NEW_LINE INDENT one [ i ] [ j ] = 1 + one [ i - 1 ] [ j ] NEW_LINE DEDENT else : NEW_LINE INDENT one [ i ] [ j ] = one [ i - 1 ] [ j ] NEW_LINE DEDENT
def Solve ( L , R ) : NEW_LINE INDENT global one , MAX NEW_LINE l = L NEW_LINE r = R NEW_LINE tot_bits = r - l + 1 NEW_LINE DEDENT
X = MAX NEW_LINE
for i in range ( 0 , 31 ) : NEW_LINE
x = one [ r ] [ i ] - one [ l - 1 ] [ i ] NEW_LINE
if ( x >= ( tot_bits - x ) ) : NEW_LINE INDENT ith_bit = pow ( 2 , i ) NEW_LINE DEDENT
X = X ^ ith_bit NEW_LINE return X NEW_LINE
n = 5 NEW_LINE q = 3 NEW_LINE A = [ 210 , 11 , 48 , 22 , 133 ] NEW_LINE L = [ 1 , 4 , 2 ] NEW_LINE R = [ 3 , 14 , 4 ] NEW_LINE make_prefix ( A , n ) NEW_LINE for j in range ( 0 , q ) : NEW_LINE INDENT print ( Solve ( L [ j ] , R [ j ] ) , end = " " ) NEW_LINE DEDENT
def type1 ( arr , start , limit ) : NEW_LINE
for i in range ( start , limit + 1 ) : NEW_LINE INDENT arr [ i ] += 1 NEW_LINE DEDENT
def type2 ( arr , query , start , limit ) : NEW_LINE INDENT for i in range ( start , limit + 1 ) : NEW_LINE DEDENT
if ( query [ i ] [ 0 ] == 1 ) : NEW_LINE INDENT type1 ( arr , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) NEW_LINE DEDENT
elif ( query [ i ] [ 0 ] == 2 ) : NEW_LINE INDENT type2 ( arr , query , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) NEW_LINE DEDENT
n = 5 NEW_LINE m = 5 NEW_LINE arr = [ 0 for i in range ( n + 1 ) ] NEW_LINE
temp = [ 1 , 1 , 2 , 1 , 4 , 5 , 2 , 1 , 2 , 2 , 1 , 3 , 2 , 3 , 4 ] NEW_LINE query = [ [ 0 for i in range ( 3 ) ] for j in range ( 6 ) ] NEW_LINE j = 0 NEW_LINE for i in range ( 1 , m + 1 ) : NEW_LINE INDENT query [ i ] [ 0 ] = temp [ j ] NEW_LINE j += 1 NEW_LINE query [ i ] [ 1 ] = temp [ j ] NEW_LINE j += 1 NEW_LINE query [ i ] [ 2 ] = temp [ j ] NEW_LINE j += 1 NEW_LINE DEDENT
for i in range ( 1 , m + 1 ) : NEW_LINE INDENT if ( query [ i ] [ 0 ] == 1 ) : NEW_LINE INDENT type1 ( arr , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) NEW_LINE DEDENT elif ( query [ i ] [ 0 ] == 2 ) : NEW_LINE INDENT type2 ( arr , query , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) NEW_LINE DEDENT DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def record_sum ( record , l , r , n , adder ) : NEW_LINE INDENT for i in range ( l , r + 1 ) : NEW_LINE INDENT record [ i ] += adder NEW_LINE DEDENT DEDENT
n = 5 NEW_LINE m = 5 NEW_LINE arr = [ 0 ] * n NEW_LINE
query = [ [ 1 , 1 , 2 ] , [ 1 , 4 , 5 ] , [ 2 , 1 , 2 ] , [ 2 , 1 , 3 ] , [ 2 , 3 , 4 ] ] NEW_LINE record = [ 0 ] * m NEW_LINE for i in range ( m - 1 , - 1 , - 1 ) : NEW_LINE
if ( query [ i ] [ 0 ] == 2 ) : NEW_LINE INDENT record_sum ( record , query [ i ] [ 1 ] - 1 , query [ i ] [ 2 ] - 1 , m , record [ i ] + 1 ) NEW_LINE DEDENT
else : NEW_LINE INDENT record_sum ( record , i , i , m , 1 ) NEW_LINE DEDENT
for i in range ( m ) : NEW_LINE INDENT if ( query [ i ] [ 0 ] == 1 ) : NEW_LINE INDENT record_sum ( arr , query [ i ] [ 1 ] - 1 , query [ i ] [ 2 ] - 1 , n , record [ i ] ) NEW_LINE DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = ' ▁ ' ) NEW_LINE DEDENT
def solveQuery ( start , end , arr ) : NEW_LINE
frequency = dict ( ) NEW_LINE
for i in range ( start , end + 1 ) : NEW_LINE INDENT if arr [ i ] in frequency . keys ( ) : NEW_LINE INDENT frequency [ arr [ i ] ] += 1 NEW_LINE DEDENT else : NEW_LINE INDENT frequency [ arr [ i ] ] = 1 NEW_LINE DEDENT DEDENT
count = 0 NEW_LINE for x in frequency : NEW_LINE INDENT if x == frequency [ x ] : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
A = [ 1 , 2 , 2 , 3 , 3 , 3 ] NEW_LINE n = len ( A ) NEW_LINE
queries = [ [ 0 , 1 ] , [ 1 , 1 ] , [ 0 , 2 ] , [ 1 , 3 ] , [ 3 , 5 ] , [ 0 , 5 ] ] NEW_LINE
q = len ( queries ) NEW_LINE for i in range ( q ) : NEW_LINE INDENT start = queries [ i ] [ 0 ] NEW_LINE end = queries [ i ] [ 1 ] NEW_LINE print ( " Answer ▁ for ▁ Query ▁ " , ( i + 1 ) , " ▁ = ▁ " , solveQuery ( start , end , A ) ) NEW_LINE DEDENT
def answer_query ( a , n , l , r ) : NEW_LINE
count = 0 NEW_LINE for i in range ( l , r ) : NEW_LINE INDENT if ( a [ i ] == a [ i + 1 ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
a = [ 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 ] NEW_LINE n = len ( a ) NEW_LINE
L = 1 NEW_LINE R = 8 NEW_LINE print ( answer_query ( a , n , L , R ) ) NEW_LINE
L = 0 NEW_LINE R = 4 NEW_LINE print ( answer_query ( a , n , L , R ) ) NEW_LINE
N = 1000 NEW_LINE
prefixans = [ 0 ] * N ; NEW_LINE
def countIndex ( a , n ) : NEW_LINE INDENT global N , prefixans NEW_LINE DEDENT
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( a [ i ] == a [ i + 1 ] ) : NEW_LINE INDENT prefixans [ i ] = 1 NEW_LINE DEDENT if ( i != 0 ) : NEW_LINE INDENT prefixans [ i ] = ( prefixans [ i ] + prefixans [ i - 1 ] ) NEW_LINE DEDENT DEDENT
def answer_query ( l , r ) : NEW_LINE INDENT global N , prefixans NEW_LINE if ( l == 0 ) : NEW_LINE INDENT return prefixans [ r - 1 ] NEW_LINE DEDENT else : NEW_LINE INDENT return ( prefixans [ r - 1 ] - prefixans [ l - 1 ] ) NEW_LINE DEDENT DEDENT
a = [ 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 ] NEW_LINE n = len ( a ) NEW_LINE
countIndex ( a , n ) NEW_LINE
L = 1 NEW_LINE R = 8 NEW_LINE print ( answer_query ( L , R ) ) NEW_LINE
L = 0 NEW_LINE R = 4 NEW_LINE print ( answer_query ( L , R ) ) NEW_LINE
def initializeDiffArray ( A ) : NEW_LINE INDENT n = len ( A ) NEW_LINE DEDENT
D = [ 0 for i in range ( 0 , n + 1 ) ] NEW_LINE D [ 0 ] = A [ 0 ] ; D [ n ] = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT D [ i ] = A [ i ] - A [ i - 1 ] NEW_LINE DEDENT return D NEW_LINE
def update ( D , l , r , x ) : NEW_LINE INDENT D [ l ] += x NEW_LINE D [ r + 1 ] -= x NEW_LINE DEDENT
def printArray ( A , D ) : NEW_LINE INDENT for i in range ( 0 , len ( A ) ) : NEW_LINE INDENT if ( i == 0 ) : NEW_LINE INDENT A [ i ] = D [ i ] NEW_LINE DEDENT DEDENT DEDENT
else : NEW_LINE INDENT A [ i ] = D [ i ] + A [ i - 1 ] NEW_LINE DEDENT print ( A [ i ] , end = " ▁ " ) NEW_LINE print ( " " ) NEW_LINE
A = [ 10 , 5 , 20 , 40 ] NEW_LINE
D = initializeDiffArray ( A ) NEW_LINE
update ( D , 0 , 1 , 10 ) NEW_LINE printArray ( A , D ) NEW_LINE
update ( D , 1 , 3 , 20 ) NEW_LINE update ( D , 2 , 2 , 30 ) NEW_LINE printArray ( A , D ) NEW_LINE
from sys import maxint NEW_LINE def maxSubArraySum ( a , size ) : NEW_LINE INDENT max_so_far = - maxint - 1 NEW_LINE max_ending_here = 0 NEW_LINE for i in range ( 0 , size ) : NEW_LINE INDENT max_ending_here = max_ending_here + a [ i ] NEW_LINE if ( max_so_far < max_ending_here ) : NEW_LINE INDENT max_so_far = max_ending_here NEW_LINE DEDENT if max_ending_here < 0 : NEW_LINE INDENT max_ending_here = 0 NEW_LINE DEDENT DEDENT return max_so_far NEW_LINE DEDENT
a = [ - 13 , - 3 , - 25 , - 20 , - 3 , - 16 , - 23 , - 12 , - 5 , - 22 , - 15 , - 4 , - 7 ] NEW_LINE print " Maximum ▁ contiguous ▁ sum ▁ is " , maxSubArraySum ( a , len ( a ) ) NEW_LINE
def maxSubArraySum ( a , size ) : NEW_LINE INDENT max_so_far = a [ 0 ] NEW_LINE curr_max = a [ 0 ] NEW_LINE for i in range ( 1 , size ) : NEW_LINE INDENT curr_max = max ( a [ i ] , curr_max + a [ i ] ) NEW_LINE max_so_far = max ( max_so_far , curr_max ) NEW_LINE DEDENT return max_so_far NEW_LINE DEDENT
a = [ - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 ] NEW_LINE print " Maximum ▁ contiguous ▁ sum ▁ is " , maxSubArraySum ( a , len ( a ) ) NEW_LINE
def findMinAvgSubarray ( arr , n , k ) : NEW_LINE
if ( n < k ) : return 0 NEW_LINE
res_index = 0 NEW_LINE
curr_sum = 0 NEW_LINE for i in range ( k ) : NEW_LINE INDENT curr_sum += arr [ i ] NEW_LINE DEDENT
min_sum = curr_sum NEW_LINE
for i in range ( k , n ) : NEW_LINE
curr_sum += arr [ i ] - arr [ i - k ] NEW_LINE
if ( curr_sum < min_sum ) : NEW_LINE INDENT min_sum = curr_sum NEW_LINE res_index = ( i - k + 1 ) NEW_LINE DEDENT print ( " Subarray ▁ between ▁ [ " , res_index , " , ▁ " , ( res_index + k - 1 ) , " ] ▁ has ▁ minimum ▁ average " ) NEW_LINE
arr = [ 3 , 7 , 90 , 20 , 10 , 50 , 40 ] NEW_LINE
k = 3 NEW_LINE n = len ( arr ) NEW_LINE findMinAvgSubarray ( arr , n , k ) NEW_LINE
def minJumps ( arr , n ) : NEW_LINE
jumps = [ 0 for i in range ( n ) ] NEW_LINE
for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE
if ( arr [ i ] == 0 ) : NEW_LINE INDENT jumps [ i ] = float ( ' inf ' ) NEW_LINE DEDENT
elif ( arr [ i ] >= n - i - 1 ) : NEW_LINE INDENT jumps [ i ] = 1 NEW_LINE DEDENT
else : NEW_LINE
min = float ( ' inf ' ) NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( j <= arr [ i ] + i ) : NEW_LINE INDENT if ( min > jumps [ j ] ) : NEW_LINE INDENT min = jumps [ j ] NEW_LINE DEDENT DEDENT DEDENT
if ( min != float ( ' inf ' ) ) : NEW_LINE INDENT jumps [ i ] = min + 1 NEW_LINE DEDENT else : NEW_LINE
jumps [ i ] = min NEW_LINE return jumps [ 0 ] NEW_LINE
arr = [ 1 , 3 , 6 , 3 , 2 , 3 , 6 , 8 , 9 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE print ( ' Minimum ▁ number ▁ of ▁ jumps ▁ to ▁ reach ' , ' end ▁ is ' , minJumps ( arr , n - 1 ) ) NEW_LINE
def smallestSubWithSum ( arr , n , x ) : NEW_LINE
min_len = n + 1 NEW_LINE
for start in range ( 0 , n ) : NEW_LINE
curr_sum = arr [ start ] NEW_LINE
if ( curr_sum > x ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
for end in range ( start + 1 , n ) : NEW_LINE
curr_sum += arr [ end ] NEW_LINE
if curr_sum > x and ( end - start + 1 ) < min_len : NEW_LINE INDENT min_len = ( end - start + 1 ) NEW_LINE DEDENT return min_len ; NEW_LINE
arr1 = [ 1 , 4 , 45 , 6 , 10 , 19 ] NEW_LINE x = 51 NEW_LINE n1 = len ( arr1 ) NEW_LINE res1 = smallestSubWithSum ( arr1 , n1 , x ) ; NEW_LINE if res1 == n1 + 1 : NEW_LINE INDENT print ( " Not ▁ possible " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( res1 ) NEW_LINE DEDENT arr2 = [ 1 , 10 , 5 , 2 , 7 ] NEW_LINE n2 = len ( arr2 ) NEW_LINE x = 9 NEW_LINE res2 = smallestSubWithSum ( arr2 , n2 , x ) ; NEW_LINE if res2 == n2 + 1 : NEW_LINE INDENT print ( " Not ▁ possible " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( res2 ) NEW_LINE DEDENT arr3 = [ 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ] NEW_LINE n3 = len ( arr3 ) NEW_LINE x = 280 NEW_LINE res3 = smallestSubWithSum ( arr3 , n3 , x ) NEW_LINE if res3 == n3 + 1 : NEW_LINE INDENT print ( " Not ▁ possible " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( res3 ) NEW_LINE DEDENT
def smallestSubWithSum ( arr , n , x ) : NEW_LINE
curr_sum = 0 NEW_LINE min_len = n + 1 NEW_LINE
start = 0 NEW_LINE end = 0 NEW_LINE while ( end < n ) : NEW_LINE
while ( curr_sum <= x and end < n ) : NEW_LINE INDENT curr_sum += arr [ end ] NEW_LINE end += 1 NEW_LINE DEDENT
while ( curr_sum > x and start < n ) : NEW_LINE
if ( end - start < min_len ) : NEW_LINE INDENT min_len = end - start NEW_LINE DEDENT
curr_sum -= arr [ start ] NEW_LINE start += 1 NEW_LINE return min_len NEW_LINE
arr1 = [ 1 , 4 , 45 , 6 , 10 , 19 ] NEW_LINE x = 51 NEW_LINE n1 = len ( arr1 ) NEW_LINE res1 = smallestSubWithSum ( arr1 , n1 , x ) NEW_LINE print ( " Not ▁ possible " ) if ( res1 == n1 + 1 ) else print ( res1 ) NEW_LINE arr2 = [ 1 , 10 , 5 , 2 , 7 ] NEW_LINE n2 = len ( arr2 ) NEW_LINE x = 9 NEW_LINE res2 = smallestSubWithSum ( arr2 , n2 , x ) NEW_LINE print ( " Not ▁ possible " ) if ( res2 == n2 + 1 ) else print ( res2 ) NEW_LINE arr3 = [ 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ] NEW_LINE n3 = len ( arr3 ) NEW_LINE x = 280 NEW_LINE res3 = smallestSubWithSum ( arr3 , n3 , x ) NEW_LINE print ( " Not ▁ possible " ) if ( res3 == n3 + 1 ) else print ( res3 ) NEW_LINE
def findMaxAverage ( arr , n , k ) : NEW_LINE
if k > n : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
csum = [ 0 ] * n NEW_LINE csum [ 0 ] = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT csum [ i ] = csum [ i - 1 ] + arr [ i ] ; NEW_LINE DEDENT
max_sum = csum [ k - 1 ] NEW_LINE max_end = k - 1 NEW_LINE
for i in range ( k , n ) : NEW_LINE INDENT curr_sum = csum [ i ] - csum [ i - k ] NEW_LINE if curr_sum > max_sum : NEW_LINE INDENT max_sum = curr_sum NEW_LINE max_end = i NEW_LINE DEDENT DEDENT
return max_end - k + 1 NEW_LINE
arr = [ 1 , 12 , - 5 , - 6 , 50 , 3 ] NEW_LINE k = 4 NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ length " , k , " begins ▁ at ▁ index " , findMaxAverage ( arr , n , k ) ) NEW_LINE
def findMaxAverage ( arr , n , k ) : NEW_LINE
if ( k > n ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
sum = arr [ 0 ] NEW_LINE for i in range ( 1 , k ) : NEW_LINE INDENT sum += arr [ i ] NEW_LINE DEDENT max_sum = sum NEW_LINE max_end = k - 1 NEW_LINE
for i in range ( k , n ) : NEW_LINE INDENT sum = sum + arr [ i ] - arr [ i - k ] NEW_LINE if ( sum > max_sum ) : NEW_LINE INDENT max_sum = sum NEW_LINE max_end = i NEW_LINE DEDENT DEDENT
return max_end - k + 1 NEW_LINE
arr = [ 1 , 12 , - 5 , - 6 , 50 , 3 ] NEW_LINE k = 4 NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ length " , k , " begins ▁ at ▁ index " , findMaxAverage ( arr , n , k ) ) NEW_LINE
def countMinOperations ( target , n ) : NEW_LINE
result = 0 ; NEW_LINE
while ( True ) : NEW_LINE
zero_count = 0 ; NEW_LINE
i = 0 ; NEW_LINE while ( i < n ) : NEW_LINE
if ( ( target [ i ] & 1 ) > 0 ) : NEW_LINE INDENT break ; NEW_LINE DEDENT
elif ( target [ i ] == 0 ) : NEW_LINE INDENT zero_count += 1 ; NEW_LINE DEDENT i += 1 ; NEW_LINE
if ( zero_count == n ) : NEW_LINE INDENT return result ; NEW_LINE DEDENT
if ( i == n ) : NEW_LINE
for j in range ( n ) : NEW_LINE INDENT target [ j ] = target [ j ] // 2 ; NEW_LINE DEDENT result += 1 ; NEW_LINE
for j in range ( i , n ) : NEW_LINE INDENT if ( target [ j ] & 1 ) : NEW_LINE INDENT target [ j ] -= 1 ; NEW_LINE result += 1 ; NEW_LINE DEDENT DEDENT
arr = [ 16 , 16 , 16 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE print ( " Minimum ▁ number ▁ of ▁ steps ▁ required ▁ to " , 	 	 " get the given target array is " , countMinOperations ( arr , n ) ) ; NEW_LINE
def findMinOps ( arr , n ) : NEW_LINE
ans = 0 NEW_LINE
i , j = 0 , n - 1 NEW_LINE while i <= j : NEW_LINE
if arr [ i ] == arr [ j ] : NEW_LINE INDENT i += 1 NEW_LINE j -= 1 NEW_LINE DEDENT
elif arr [ i ] > arr [ j ] : NEW_LINE
j -= 1 NEW_LINE arr [ j ] += arr [ j + 1 ] NEW_LINE ans += 1 NEW_LINE
else : NEW_LINE INDENT i += 1 NEW_LINE arr [ i ] += arr [ i - 1 ] NEW_LINE ans += 1 NEW_LINE DEDENT return ans NEW_LINE
arr = [ 1 , 4 , 5 , 9 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Count ▁ of ▁ minimum ▁ operations ▁ is ▁ " + str ( findMinOps ( arr , n ) ) ) NEW_LINE
def findSmallest ( arr , n ) : NEW_LINE
res = 1 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT if arr [ i ] <= res : NEW_LINE INDENT res = res + arr [ i ] NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT return res NEW_LINE
arr1 = [ 1 , 3 , 4 , 5 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE print ( findSmallest ( arr1 , n1 ) ) NEW_LINE arr2 = [ 1 , 2 , 6 , 10 , 11 , 15 ] NEW_LINE n2 = len ( arr2 ) NEW_LINE print ( findSmallest ( arr2 , n2 ) ) NEW_LINE arr3 = [ 1 , 1 , 1 , 1 ] NEW_LINE n3 = len ( arr3 ) NEW_LINE print ( findSmallest ( arr3 , n3 ) ) NEW_LINE arr4 = [ 1 , 1 , 3 , 4 ] NEW_LINE n4 = len ( arr4 ) NEW_LINE print ( findSmallest ( arr4 , n4 ) ) NEW_LINE
def maxSubArraySum ( a , size ) : NEW_LINE INDENT max_so_far = - maxsize - 1 NEW_LINE max_ending_here = 0 NEW_LINE start = 0 NEW_LINE end = 0 NEW_LINE s = 0 NEW_LINE for i in range ( 0 , size ) : NEW_LINE INDENT max_ending_here += a [ i ] NEW_LINE if max_so_far < max_ending_here : NEW_LINE INDENT max_so_far = max_ending_here NEW_LINE start = s NEW_LINE end = i NEW_LINE DEDENT if max_ending_here < 0 : NEW_LINE INDENT max_ending_here = 0 NEW_LINE s = i + 1 NEW_LINE DEDENT DEDENT return ( end - start + 1 ) NEW_LINE DEDENT
a = [ - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 ] NEW_LINE print ( maxSubArraySum ( a , len ( a ) ) ) NEW_LINE
def findMinDiff ( arr , n ) : NEW_LINE
diff = 10 ** 20 NEW_LINE
for i in range ( n - 1 ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT if abs ( arr [ i ] - arr [ j ] ) < diff : NEW_LINE INDENT diff = abs ( arr [ i ] - arr [ j ] ) NEW_LINE DEDENT DEDENT DEDENT
return diff NEW_LINE
arr = [ 1 , 5 , 3 , 19 , 18 , 25 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ difference ▁ is ▁ " + str ( findMinDiff ( arr , n ) ) ) NEW_LINE
def findMinDiff ( arr , n ) : NEW_LINE
arr = sorted ( arr ) NEW_LINE
diff = 10 ** 20 NEW_LINE
for i in range ( n - 1 ) : NEW_LINE INDENT if arr [ i + 1 ] - arr [ i ] < diff : NEW_LINE INDENT diff = arr [ i + 1 ] - arr [ i ] NEW_LINE DEDENT DEDENT
return diff NEW_LINE
arr = [ 1 , 5 , 3 , 19 , 18 , 25 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ difference ▁ is ▁ " + str ( findMinDiff ( arr , n ) ) ) NEW_LINE
a = 2 NEW_LINE b = 10 NEW_LINE size = abs ( b - a ) + 1 NEW_LINE array = [ 0 ] * size NEW_LINE
for i in range ( a , b + 1 ) : NEW_LINE INDENT if ( i % 2 == 0 or i % 5 == 0 ) : NEW_LINE INDENT array [ i - a ] = 1 NEW_LINE DEDENT DEDENT print ( " MULTIPLES ▁ of ▁ 2 ▁ and ▁ 5 : " ) NEW_LINE for i in range ( a , b + 1 ) : NEW_LINE INDENT if ( array [ i - a ] == 1 ) : NEW_LINE INDENT print ( i , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def checkbit ( array , index ) : NEW_LINE INDENT return array [ index >> 5 ] & ( 1 << ( index & 31 ) ) NEW_LINE DEDENT
def setbit ( array , index ) : NEW_LINE INDENT array [ index >> 5 ] |= ( 1 << ( index & 31 ) ) NEW_LINE DEDENT
a = 2 NEW_LINE b = 10 NEW_LINE size = abs ( b - a ) NEW_LINE
size = math . ceil ( size / 32 ) NEW_LINE
array = [ 0 for i in range ( size ) ] NEW_LINE
for i in range ( a , b + 1 ) : NEW_LINE INDENT if ( i % 2 == 0 or i % 5 == 0 ) : NEW_LINE INDENT setbit ( array , i - a ) NEW_LINE DEDENT DEDENT print ( " MULTIPLES ▁ of ▁ 2 ▁ and ▁ 5 : " ) NEW_LINE for i in range ( a , b + 1 ) : NEW_LINE INDENT if ( checkbit ( array , i - a ) ) : NEW_LINE INDENT print ( i , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def longestCommonSum ( arr1 , arr2 , n ) : NEW_LINE
maxLen = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
sum1 = 0 NEW_LINE sum2 = 0 NEW_LINE
for j in range ( i , n ) : NEW_LINE
sum1 += arr1 [ j ] NEW_LINE sum2 += arr2 [ j ] NEW_LINE
if ( sum1 == sum2 ) : NEW_LINE INDENT len = j - i + 1 NEW_LINE if ( len > maxLen ) : NEW_LINE INDENT maxLen = len NEW_LINE DEDENT DEDENT return maxLen NEW_LINE
arr1 = [ 0 , 1 , 0 , 1 , 1 , 1 , 1 ] NEW_LINE arr2 = [ 1 , 1 , 1 , 1 , 1 , 0 , 1 ] NEW_LINE n = len ( arr1 ) NEW_LINE print ( " Length ▁ of ▁ the ▁ longest ▁ common ▁ span ▁ with ▁ same ▁ " " sum ▁ is " , longestCommonSum ( arr1 , arr2 , n ) ) NEW_LINE
def sortInWave ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
for i in range ( 0 , n - 1 , 2 ) : NEW_LINE INDENT arr [ i ] , arr [ i + 1 ] = arr [ i + 1 ] , arr [ i ] NEW_LINE DEDENT
arr = [ 10 , 90 , 49 , 2 , 1 , 5 , 23 ] NEW_LINE sortInWave ( arr , len ( arr ) ) NEW_LINE for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT print arr [ i ] , NEW_LINE DEDENT
def sortInWave ( arr , n ) : NEW_LINE
for i in range ( 0 , n , 2 ) : NEW_LINE
if ( i > 0 and arr [ i ] < arr [ i - 1 ] ) : NEW_LINE INDENT arr [ i ] , arr [ i - 1 ] = arr [ i - 1 ] , arr [ i ] NEW_LINE DEDENT
if ( i < n - 1 and arr [ i ] < arr [ i + 1 ] ) : NEW_LINE INDENT arr [ i ] , arr [ i + 1 ] = arr [ i + 1 ] , arr [ i ] NEW_LINE DEDENT
arr = [ 10 , 90 , 49 , 2 , 1 , 5 , 23 ] NEW_LINE sortInWave ( arr , len ( arr ) ) NEW_LINE for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT print arr [ i ] , NEW_LINE DEDENT
def sortedAfterSwap ( A , B , n ) : NEW_LINE
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( B [ i ] == 1 ) : NEW_LINE INDENT j = i NEW_LINE while ( B [ j ] == 1 ) : NEW_LINE INDENT j = j + 1 NEW_LINE DEDENT DEDENT DEDENT
A = A [ 0 : i ] + sorted ( A [ i : j + 1 ] ) + A [ j + 1 : ] NEW_LINE i = j NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT if ( A [ i ] != i + 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
A = [ 1 , 2 , 5 , 3 , 4 , 6 ] NEW_LINE B = [ 0 , 1 , 1 , 1 , 0 ] NEW_LINE n = len ( A ) NEW_LINE if ( sortedAfterSwap ( A , B , n ) ) : NEW_LINE INDENT print ( " A ▁ can ▁ be ▁ sorted " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " A ▁ can ▁ not ▁ be ▁ sorted " ) NEW_LINE DEDENT
def sortedAfterSwap ( A , B , n ) : NEW_LINE INDENT for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if B [ i ] : NEW_LINE INDENT if A [ i ] != i + 1 : NEW_LINE INDENT A [ i ] , A [ i + 1 ] = A [ i + 1 ] , A [ i ] NEW_LINE DEDENT DEDENT DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT if A [ i ] != i + 1 : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT A = [ 1 , 2 , 5 , 3 , 4 , 6 ] NEW_LINE B = [ 0 , 1 , 1 , 1 , 0 ] NEW_LINE n = len ( A ) NEW_LINE if ( sortedAfterSwap ( A , B , n ) ) : NEW_LINE INDENT print ( " A ▁ can ▁ be ▁ sorted " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " A ▁ can ▁ not ▁ be ▁ sorted " ) NEW_LINE DEDENT DEDENT
def segregate0and1 ( arr , n ) : NEW_LINE INDENT type0 = 0 ; type1 = n - 1 NEW_LINE while ( type0 < type1 ) : NEW_LINE INDENT if ( arr [ type0 ] == 1 ) : NEW_LINE INDENT arr [ type0 ] , arr [ type1 ] = arr [ type1 ] , arr [ type0 ] NEW_LINE type1 -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT type0 += 1 NEW_LINE DEDENT DEDENT DEDENT
arr = [ 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE segregate0and1 ( arr , n ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
if ( not abs ( arr [ i - 1 ] ) < abs ( arr [ i ] ) ) : NEW_LINE INDENT arr [ i - 1 ] , arr [ i ] = arr [ i ] , arr [ i - 1 ] NEW_LINE DEDENT Min = sys . maxsize NEW_LINE x = 0 NEW_LINE y = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE
if ( abs ( arr [ i - 1 ] + arr [ i ] ) <= Min ) : NEW_LINE
Min = abs ( arr [ i - 1 ] + arr [ i ] ) NEW_LINE x = i - 1 NEW_LINE y = i NEW_LINE print ( " The ▁ two ▁ elements ▁ whose ▁ sum ▁ is ▁ minimum ▁ are " , arr [ x ] , " and " , arr [ y ] ) NEW_LINE
arr = [ 1 , 60 , - 10 , 70 , - 80 , 85 ] NEW_LINE n = len ( arr ) NEW_LINE findMinSum ( arr , n ) NEW_LINE
def increasing ( a , n ) : NEW_LINE INDENT for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( a [ i ] >= a [ i + 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE DEDENT
def decreasing ( a , n ) : NEW_LINE INDENT for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( a [ i ] < a [ i + 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE DEDENT def shortestUnsorted ( a , n ) : NEW_LINE
if ( increasing ( a , n ) == True or decreasing ( a , n ) == True ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE INDENT return 3 NEW_LINE DEDENT
ar = [ 7 , 9 , 10 , 8 , 11 ] NEW_LINE n = len ( ar ) NEW_LINE print ( shortestUnsorted ( ar , n ) ) NEW_LINE
def swap ( arr , i , j ) : NEW_LINE INDENT temp = arr [ i ] NEW_LINE arr [ i ] = arr [ j ] NEW_LINE arr [ j ] = temp NEW_LINE DEDENT
def indexOf ( arr , ele ) : NEW_LINE INDENT for i in range ( len ( arr ) ) : NEW_LINE INDENT if ( arr [ i ] == ele ) : NEW_LINE INDENT return i NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT
def minSwaps ( arr , N ) : NEW_LINE INDENT ans = 0 NEW_LINE temp = arr . copy ( ) NEW_LINE temp . sort ( ) NEW_LINE for i in range ( N ) : NEW_LINE DEDENT
if ( arr [ i ] != temp [ i ] ) : NEW_LINE INDENT ans += 1 NEW_LINE DEDENT
swap ( arr , i , indexOf ( arr , temp [ i ] ) ) NEW_LINE return ans NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 101 , 758 , 315 , 730 , 472 , 619 , 460 , 479 ] NEW_LINE n = len ( a ) NEW_LINE DEDENT
print ( minSwaps ( a , n ) ) NEW_LINE
def printUnion ( arr1 , arr2 , m , n ) : NEW_LINE
if ( m > n ) : NEW_LINE INDENT tempp = arr1 NEW_LINE arr1 = arr2 NEW_LINE arr2 = tempp NEW_LINE temp = m NEW_LINE m = n NEW_LINE n = temp NEW_LINE DEDENT
arr1 . sort ( ) NEW_LINE for i in range ( 0 , m ) : NEW_LINE INDENT print ( arr1 [ i ] , end = " ▁ " ) NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) == - 1 ) : NEW_LINE INDENT print ( arr2 [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def printIntersection ( arr1 , arr2 , m , n ) : NEW_LINE
if ( m > n ) : NEW_LINE INDENT tempp = arr1 NEW_LINE arr1 = arr2 NEW_LINE arr2 = tempp NEW_LINE temp = m NEW_LINE m = n NEW_LINE n = temp NEW_LINE DEDENT
arr1 . sort ( ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) != - 1 ) : NEW_LINE INDENT print ( arr2 [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def binarySearch ( arr , l , r , x ) : NEW_LINE INDENT if ( r >= l ) : NEW_LINE INDENT mid = int ( l + ( r - l ) / 2 ) NEW_LINE DEDENT DEDENT
if ( arr [ mid ] == x ) : NEW_LINE INDENT return mid NEW_LINE DEDENT
if ( arr [ mid ] > x ) : NEW_LINE INDENT return binarySearch ( arr , l , mid - 1 , x ) NEW_LINE DEDENT
return binarySearch ( arr , mid + 1 , r , x ) NEW_LINE
return - 1 NEW_LINE
arr1 = [ 7 , 1 , 5 , 2 , 3 , 6 ] NEW_LINE arr2 = [ 3 , 8 , 6 , 20 , 7 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE
print ( " Union ▁ of ▁ two ▁ arrays ▁ is ▁ " ) NEW_LINE printUnion ( arr1 , arr2 , m , n ) NEW_LINE print ( " Intersection of two arrays is   " ) NEW_LINE printIntersection ( arr1 , arr2 , m , n ) NEW_LINE
def intersection ( a , b , n , m ) : NEW_LINE INDENT i = 0 NEW_LINE j = 0 NEW_LINE while ( i < n and j < m ) : NEW_LINE INDENT if ( a [ i ] > b [ j ] ) : NEW_LINE INDENT j += 1 NEW_LINE DEDENT else : NEW_LINE INDENT if ( b [ j ] > a [ i ] ) : NEW_LINE INDENT i += 1 NEW_LINE DEDENT else : NEW_LINE DEDENT DEDENT DEDENT
print ( a [ i ] , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE j += 1 NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 1 , 3 , 2 , 3 , 4 , 5 , 5 , 6 ] NEW_LINE b = [ 3 , 3 , 5 ] NEW_LINE n = len ( a ) NEW_LINE m = len ( b ) NEW_LINE DEDENT
a . sort ( ) NEW_LINE b . sort ( ) NEW_LINE
intersection ( a , b , n , m ) NEW_LINE
def printArr ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def sortArr ( arr , n ) : NEW_LINE INDENT cnt0 = 0 NEW_LINE cnt1 = 0 NEW_LINE cnt2 = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if arr [ i ] == 0 : NEW_LINE INDENT cnt0 += 1 NEW_LINE DEDENT elif arr [ i ] == 1 : NEW_LINE INDENT cnt1 += 1 NEW_LINE DEDENT elif arr [ i ] == 2 : NEW_LINE INDENT cnt2 += 1 NEW_LINE DEDENT DEDENT
i = 0 NEW_LINE
while ( cnt0 > 0 ) : NEW_LINE INDENT arr [ i ] = 0 NEW_LINE i += 1 NEW_LINE cnt0 -= 1 NEW_LINE DEDENT
while ( cnt1 > 0 ) : NEW_LINE INDENT arr [ i ] = 1 NEW_LINE i += 1 NEW_LINE cnt1 -= 1 NEW_LINE DEDENT
while ( cnt2 > 0 ) : NEW_LINE INDENT arr [ i ] = 2 NEW_LINE i += 1 NEW_LINE cnt2 -= 1 NEW_LINE DEDENT
printArr ( arr , n ) NEW_LINE
arr = [ 0 , 1 , 1 , 0 , 1 , 2 , 1 , 2 , 0 , 0 , 0 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE sortArr ( arr , n ) NEW_LINE
def findNumberOfTriangles ( arr , n ) : NEW_LINE
count = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT
for k in range ( j + 1 , n ) : NEW_LINE
if ( arr [ i ] + arr [ j ] > arr [ k ] and arr [ i ] + arr [ k ] > arr [ j ] and arr [ k ] + arr [ j ] > arr [ i ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT return count NEW_LINE
arr = [ 10 , 21 , 22 , 100 , 101 , 200 , 300 ] NEW_LINE size = len ( arr ) NEW_LINE print ( " Total ▁ number ▁ of ▁ triangles ▁ possible ▁ is " , findNumberOfTriangles ( arr , size ) ) NEW_LINE
def CountTriangles ( A ) : NEW_LINE INDENT n = len ( A ) ; NEW_LINE A . sort ( ) ; NEW_LINE count = 0 ; NEW_LINE for i in range ( n - 1 , 0 , - 1 ) : NEW_LINE INDENT l = 0 ; NEW_LINE r = i - 1 ; NEW_LINE while ( l < r ) : NEW_LINE INDENT if ( A [ l ] + A [ r ] > A [ i ] ) : NEW_LINE DEDENT DEDENT DEDENT
count += r - l ; NEW_LINE
r -= 1 ; NEW_LINE
else : NEW_LINE INDENT l += 1 ; NEW_LINE DEDENT print ( " No ▁ of ▁ possible ▁ solutions : ▁ " , count ) ; NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT A = [ 4 , 3 , 5 , 7 , 6 ] ; NEW_LINE CountTriangles ( A ) ; NEW_LINE DEDENT
def countPairsBruteForce ( X , Y , m , n ) : NEW_LINE INDENT ans = 0 NEW_LINE for i in range ( m ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT if ( pow ( X [ i ] , Y [ j ] ) > pow ( Y [ j ] , X [ i ] ) ) : NEW_LINE INDENT ans += 1 NEW_LINE DEDENT DEDENT DEDENT return ans NEW_LINE DEDENT
def countPairsWithDiffK ( arr , n , k ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE INDENT if arr [ i ] - arr [ j ] == k or arr [ j ] - arr [ i ] == k : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
arr = [ 1 , 5 , 3 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE print ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " , countPairsWithDiffK ( arr , n , k ) ) NEW_LINE
def binarySearch ( arr , low , high , x ) : NEW_LINE INDENT if ( high >= low ) : NEW_LINE INDENT mid = low + ( high - low ) // 2 NEW_LINE if x == arr [ mid ] : NEW_LINE INDENT return ( mid ) NEW_LINE DEDENT elif ( x > arr [ mid ] ) : NEW_LINE INDENT return binarySearch ( arr , ( mid + 1 ) , high , x ) NEW_LINE DEDENT else : NEW_LINE INDENT return binarySearch ( arr , low , ( mid - 1 ) , x ) NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT
def countPairsWithDiffK ( arr , n , k ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
for i in range ( 0 , n - 2 ) : NEW_LINE INDENT if ( binarySearch ( arr , i + 1 , n - 1 , arr [ i ] + k ) != - 1 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
arr = [ 1 , 5 , 3 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE print ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " , countPairsWithDiffK ( arr , n , k ) ) NEW_LINE
def countPairsWithDiffK ( arr , n , k ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE l = 0 NEW_LINE r = 0 NEW_LINE while r < n : NEW_LINE INDENT if arr [ r ] - arr [ l ] == k : NEW_LINE INDENT count += 1 NEW_LINE l += 1 NEW_LINE r += 1 NEW_LINE DEDENT DEDENT
elif arr [ r ] - arr [ l ] > k : NEW_LINE INDENT l += 1 NEW_LINE DEDENT else : NEW_LINE INDENT r += 1 NEW_LINE DEDENT return count NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 5 , 3 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE print ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " , countPairsWithDiffK ( arr , n , k ) ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def getSumAlternate ( root ) : NEW_LINE INDENT if ( root == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT sum = root . data NEW_LINE if ( root . left != None ) : NEW_LINE INDENT sum += getSum ( root . left . left ) NEW_LINE sum += getSum ( root . left . right ) NEW_LINE DEDENT if ( root . right != None ) : NEW_LINE INDENT sum += getSum ( root . right . left ) NEW_LINE sum += getSum ( root . right . right ) NEW_LINE DEDENT return sum NEW_LINE DEDENT
def getSum ( root ) : NEW_LINE INDENT if ( root == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT DEDENT
return max ( getSumAlternate ( root ) , ( getSumAlternate ( root . left ) + getSumAlternate ( root . right ) ) ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . right . left = Node ( 4 ) NEW_LINE root . right . left . right = Node ( 5 ) NEW_LINE root . right . left . right . left = Node ( 6 ) NEW_LINE print ( getSum ( root ) ) NEW_LINE DEDENT
def constructArr ( arr , pair , n ) : NEW_LINE INDENT arr [ 0 ] = ( pair [ 0 ] + pair [ 1 ] - pair [ n - 1 ] ) // 2 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT arr [ i ] = pair [ i - 1 ] - arr [ 0 ] NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT pair = [ 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 ] NEW_LINE n = 5 NEW_LINE arr = [ 0 ] * n NEW_LINE constructArr ( arr , pair , n ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def merge ( ar1 , ar2 , m , n ) : NEW_LINE
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE
last = ar1 [ m - 1 ] NEW_LINE j = m - 2 NEW_LINE while ( j >= 0 and ar1 [ j ] > ar2 [ i ] ) : NEW_LINE INDENT ar1 [ j + 1 ] = ar1 [ j ] NEW_LINE j -= 1 NEW_LINE DEDENT
if ( j != m - 2 or last > ar2 [ i ] ) : NEW_LINE INDENT ar1 [ j + 1 ] = ar2 [ i ] NEW_LINE ar2 [ i ] = last NEW_LINE DEDENT
ar1 = [ 1 , 5 , 9 , 10 , 15 , 20 ] NEW_LINE ar2 = [ 2 , 3 , 8 , 13 ] NEW_LINE m = len ( ar1 ) NEW_LINE n = len ( ar2 ) NEW_LINE merge ( ar1 , ar2 , m , n ) NEW_LINE print ( " After Merging First Array : " , ▁ end = " " ) NEW_LINE for i in range ( m ) : NEW_LINE INDENT print ( ar1 [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT print ( " Second Array : " , ▁ end = " " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( ar2 [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT
def minmaxProduct ( arr1 , arr2 , n1 , n2 ) : NEW_LINE
arr1 . sort ( ) NEW_LINE arr2 . sort ( ) NEW_LINE
return arr1 [ n1 - 1 ] * arr2 [ 0 ] NEW_LINE
arr1 = [ 10 , 2 , 3 , 6 , 4 , 1 ] NEW_LINE arr2 = [ 5 , 1 , 4 , 2 , 6 , 9 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE n2 = len ( arr2 ) NEW_LINE print ( minmaxProduct ( arr1 , arr2 , n1 , n2 ) ) NEW_LINE
def minMaxProduct ( arr1 , arr2 , n1 , n2 ) : NEW_LINE
max = arr1 [ 0 ] NEW_LINE
min = arr2 [ 0 ] NEW_LINE i = 1 NEW_LINE while ( i < n1 and i < n2 ) : NEW_LINE
if ( arr1 [ i ] > max ) : NEW_LINE INDENT max = arr1 [ i ] NEW_LINE DEDENT
if ( arr2 [ i ] < min ) : NEW_LINE INDENT min = arr2 [ i ] NEW_LINE DEDENT i += 1 NEW_LINE
while ( i < n1 ) : NEW_LINE INDENT if ( arr1 [ i ] > max ) : NEW_LINE INDENT max = arr1 [ i ] NEW_LINE i += 1 NEW_LINE DEDENT DEDENT while ( i < n2 ) : NEW_LINE INDENT if ( arr2 [ i ] < min ) : NEW_LINE INDENT min = arr2 [ i ] NEW_LINE i += 1 NEW_LINE DEDENT DEDENT return max * min NEW_LINE
arr1 = [ 10 , 2 , 3 , 6 , 4 , 1 ] NEW_LINE arr2 = [ 5 , 1 , 4 , 2 , 6 , 9 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE n2 = len ( arr1 ) NEW_LINE print ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) NEW_LINE
def findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) : NEW_LINE
i , j , k = 0 , 0 , 0 NEW_LINE
while ( i < n1 and j < n2 and k < n3 ) : NEW_LINE
if ( ar1 [ i ] == ar2 [ j ] and ar2 [ j ] == ar3 [ k ] ) : NEW_LINE INDENT print ar1 [ i ] , NEW_LINE i += 1 NEW_LINE j += 1 NEW_LINE k += 1 NEW_LINE DEDENT
elif ar1 [ i ] < ar2 [ j ] : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
elif ar2 [ j ] < ar3 [ k ] : NEW_LINE INDENT j += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT k += 1 NEW_LINE DEDENT
ar1 = [ 1 , 5 , 10 , 20 , 40 , 80 ] NEW_LINE ar2 = [ 6 , 7 , 20 , 80 , 100 ] NEW_LINE ar3 = [ 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 ] NEW_LINE n1 = len ( ar1 ) NEW_LINE n2 = len ( ar2 ) NEW_LINE n3 = len ( ar3 ) NEW_LINE print " Common ▁ elements ▁ are " , NEW_LINE findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) NEW_LINE
def binary_search ( arr , l , r , x ) : NEW_LINE INDENT if r >= l : NEW_LINE INDENT mid = l + ( r - l ) / 2 NEW_LINE if arr [ mid ] == x : NEW_LINE INDENT return mid NEW_LINE DEDENT if arr [ mid ] > x : NEW_LINE INDENT return binary_search ( arr , l , mid - 1 , x ) NEW_LINE DEDENT return binary_search ( arr , mid + 1 , r , x ) NEW_LINE DEDENT return - 1 NEW_LINE DEDENT
def findPos ( a , key ) : NEW_LINE INDENT l , h , val = 0 , 1 , arr [ 0 ] NEW_LINE DEDENT
while val < key : NEW_LINE
l = h NEW_LINE
h = 2 * h NEW_LINE
val = arr [ h ] NEW_LINE
return binary_search ( a , l , h , key ) NEW_LINE
arr = [ 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 ] NEW_LINE ans = findPos ( arr , 10 ) NEW_LINE if ans == - 1 : NEW_LINE INDENT print " Element ▁ not ▁ found " NEW_LINE DEDENT else : NEW_LINE INDENT print " Element ▁ found ▁ at ▁ index " , ans NEW_LINE DEDENT
def findSingle ( ar , n ) : NEW_LINE INDENT res = ar [ 0 ] NEW_LINE DEDENT
for i in range ( 1 , n ) : NEW_LINE INDENT res = res ^ ar [ i ] NEW_LINE DEDENT return res NEW_LINE
ar = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] NEW_LINE print " Element ▁ occurring ▁ once ▁ is " , findSingle ( ar , len ( ar ) ) NEW_LINE
def singleNumber ( nums ) : NEW_LINE
return 2 * sum ( set ( nums ) ) - sum ( nums ) NEW_LINE
a = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] NEW_LINE print ( int ( singleNumber ( a ) ) ) NEW_LINE a = [ 15 , 18 , 16 , 18 , 16 , 15 , 89 ] NEW_LINE print ( int ( singleNumber ( a ) ) ) NEW_LINE
INT_MIN = - 2147483648 NEW_LINE def isPresent ( B , m , x ) : NEW_LINE INDENT for i in range ( 0 , m ) : NEW_LINE INDENT if B [ i ] == x : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT return False NEW_LINE DEDENT
def findMaxSubarraySumUtil ( A , B , n , m ) : NEW_LINE
max_so_far = INT_MIN NEW_LINE curr_max = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE
if isPresent ( B , m , A [ i ] ) == True : NEW_LINE INDENT curr_max = 0 NEW_LINE continue NEW_LINE DEDENT
curr_max = max ( A [ i ] , curr_max + A [ i ] ) NEW_LINE max_so_far = max ( max_so_far , curr_max ) NEW_LINE return max_so_far NEW_LINE
def findMaxSubarraySum ( A , B , n , m ) : NEW_LINE INDENT maxSubarraySum = findMaxSubarraySumUtil ( A , B , n , m ) NEW_LINE DEDENT
if maxSubarraySum == INT_MIN : NEW_LINE INDENT print ( ' Maximum ▁ Subarray ▁ Sum ▁ cant ▁ be ▁ found ' ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( ' The ▁ Maximum ▁ Subarray ▁ Sum ▁ = ' , maxSubarraySum ) NEW_LINE DEDENT
A = [ 3 , 4 , 5 , - 4 , 6 ] NEW_LINE B = [ 1 , 8 , 5 ] NEW_LINE n = len ( A ) NEW_LINE m = len ( B ) NEW_LINE
findMaxSubarraySum ( A , B , n , m ) NEW_LINE
def findMaxSum ( arr , n ) : NEW_LINE INDENT res = - sys . maxsize - 1 NEW_LINE for i in range ( n ) : NEW_LINE INDENT prefix_sum = arr [ i ] NEW_LINE for j in range ( i ) : NEW_LINE INDENT prefix_sum += arr [ j ] NEW_LINE DEDENT suffix_sum = arr [ i ] NEW_LINE j = n - 1 NEW_LINE while ( j > i ) : NEW_LINE INDENT suffix_sum += arr [ j ] NEW_LINE j -= 1 NEW_LINE DEDENT if ( prefix_sum == suffix_sum ) : NEW_LINE INDENT res = max ( res , prefix_sum ) NEW_LINE DEDENT DEDENT return res NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findMaxSum ( arr , n ) ) NEW_LINE DEDENT
def getHeight ( Node ) : NEW_LINE INDENT if ( Node == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE DEDENT
lHeight = getHeight ( Node . left ) NEW_LINE rHeight = getHeight ( Node . right ) NEW_LINE
if ( lHeight > rHeight ) : NEW_LINE INDENT return ( lHeight + 1 ) NEW_LINE DEDENT else : NEW_LINE INDENT return ( rHeight + 1 ) NEW_LINE DEDENT
def getTotalHeight ( root ) : NEW_LINE INDENT if ( root == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT return ( getTotalHeight ( root . left ) + getHeight ( root ) + getTotalHeight ( root . right ) ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = newNode ( 1 ) NEW_LINE root . left = newNode ( 2 ) NEW_LINE root . right = newNode ( 3 ) NEW_LINE root . left . left = newNode ( 4 ) NEW_LINE root . left . right = newNode ( 5 ) NEW_LINE DEDENT print ( " Sum ▁ of ▁ heights ▁ of ▁ all ▁ Nodes ▁ = " , getTotalHeight ( root ) ) NEW_LINE
def findMaxSum ( arr , n ) : NEW_LINE
preSum = [ 0 for i in range ( n ) ] NEW_LINE
suffSum = [ 0 for i in range ( n ) ] NEW_LINE
ans = - 10000000 NEW_LINE
preSum [ 0 ] = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT preSum [ i ] = preSum [ i - 1 ] + arr [ i ] NEW_LINE DEDENT
suffSum [ n - 1 ] = arr [ n - 1 ] NEW_LINE if ( preSum [ n - 1 ] == suffSum [ n - 1 ] ) : NEW_LINE INDENT ans = max ( ans , preSum [ n - 1 ] ) NEW_LINE DEDENT for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT suffSum [ i ] = suffSum [ i + 1 ] + arr [ i ] NEW_LINE if ( suffSum [ i ] == preSum [ i ] ) : NEW_LINE INDENT ans = max ( ans , preSum [ i ] ) NEW_LINE DEDENT DEDENT return ans NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findMaxSum ( arr , n ) ) NEW_LINE DEDENT
def equilibrium ( arr ) : NEW_LINE INDENT left_sum = [ ] NEW_LINE right_sum = [ ] NEW_LINE DEDENT
for i in range ( len ( arr ) ) : NEW_LINE
if ( i ) : NEW_LINE INDENT left_sum . append ( left_sum [ i - 1 ] + arr [ i ] ) NEW_LINE right_sum . append ( right_sum [ i - 1 ] + arr [ len ( arr ) - 1 - i ] ) NEW_LINE DEDENT else : NEW_LINE INDENT left_sum . append ( arr [ i ] ) NEW_LINE right_sum . append ( arr [ len ( arr ) - 1 ] ) NEW_LINE DEDENT
for i in range ( len ( arr ) ) : NEW_LINE INDENT if ( left_sum [ i ] == right_sum [ len ( arr ) - 1 - i ] ) : NEW_LINE INDENT return ( i ) NEW_LINE DEDENT DEDENT
return - 1 NEW_LINE
arr = [ - 7 , 1 , 5 , 2 , - 4 , 3 , 0 ] NEW_LINE print ( ' First ▁ equilibrium ▁ index ▁ is ▁ ' , equilibrium ( arr ) ) NEW_LINE
def printLeaders ( arr , size ) : NEW_LINE INDENT for i in range ( 0 , size ) : NEW_LINE INDENT for j in range ( i + 1 , size ) : NEW_LINE INDENT if arr [ i ] <= arr [ j ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT DEDENT
if j == size - 1 : NEW_LINE INDENT print arr [ i ] , NEW_LINE DEDENT
arr = [ 16 , 17 , 4 , 3 , 5 , 2 ] NEW_LINE printLeaders ( arr , len ( arr ) ) NEW_LINE
def findMajority ( arr , n ) : NEW_LINE INDENT maxCount = 0 NEW_LINE DEDENT
index = - 1 NEW_LINE for i in range ( n ) : NEW_LINE INDENT count = 0 NEW_LINE for j in range ( n ) : NEW_LINE INDENT if ( arr [ i ] == arr [ j ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT DEDENT
if ( count > maxCount ) : NEW_LINE INDENT maxCount = count NEW_LINE index = i NEW_LINE DEDENT
if ( maxCount > n // 2 ) : NEW_LINE INDENT print ( arr [ index ] ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ Majority ▁ Element " ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 1 , 2 , 1 , 3 , 5 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE DEDENT
findMajority ( arr , n ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . data = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT sum = 0 NEW_LINE
def getTotalHeightUtil ( root ) : NEW_LINE INDENT global sum NEW_LINE if ( root == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT lh = getTotalHeightUtil ( root . left ) NEW_LINE rh = getTotalHeightUtil ( root . right ) NEW_LINE h = max ( lh , rh ) + 1 NEW_LINE sum = sum + h NEW_LINE return h NEW_LINE DEDENT def getTotalHeight ( root ) : NEW_LINE INDENT getTotalHeightUtil ( root ) NEW_LINE return sum NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE print ( " Sum ▁ of ▁ heights ▁ of ▁ all ▁ Nodes ▁ = " , getTotalHeight ( root ) ) NEW_LINE DEDENT
def majorityElement ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE count , max_ele , temp , f = 1 , - 1 , arr [ 0 ] , 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE
if ( temp == arr [ i ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT else : NEW_LINE INDENT count = 1 NEW_LINE temp = arr [ i ] NEW_LINE DEDENT
if ( max_ele < count ) : NEW_LINE INDENT max_ele = count NEW_LINE ele = arr [ i ] NEW_LINE if ( max_ele > ( n // 2 ) ) : NEW_LINE INDENT f = 1 NEW_LINE break NEW_LINE DEDENT DEDENT
if f == 1 : NEW_LINE INDENT return ele NEW_LINE DEDENT else : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
arr = [ 1 , 1 , 2 , 1 , 3 , 5 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE
print ( majorityElement ( arr , n ) ) NEW_LINE
def _binarySearch ( arr , low , high , x ) : NEW_LINE INDENT if high >= low : NEW_LINE INDENT mid = ( low + high ) // 2 NEW_LINE DEDENT DEDENT
if ( mid == 0 or x > arr [ mid - 1 ] ) and ( arr [ mid ] == x ) : NEW_LINE INDENT return mid NEW_LINE DEDENT elif x > arr [ mid ] : NEW_LINE INDENT return _binarySearch ( arr , ( mid + 1 ) , high , x ) NEW_LINE DEDENT else : NEW_LINE INDENT return _binarySearch ( arr , low , ( mid - 1 ) , x ) NEW_LINE DEDENT return - 1 NEW_LINE
def isMajority ( arr , n , x ) : NEW_LINE
i = _binarySearch ( arr , 0 , n - 1 , x ) NEW_LINE
if i == - 1 : NEW_LINE INDENT return False NEW_LINE DEDENT
if ( ( i + n // 2 ) <= ( n - 1 ) ) and arr [ i + n // 2 ] == x : NEW_LINE INDENT return True NEW_LINE DEDENT else : NEW_LINE INDENT return False NEW_LINE DEDENT
def isMajorityElement ( arr , n , key ) : NEW_LINE INDENT if ( arr [ n // 2 ] == key ) : NEW_LINE INDENT return True NEW_LINE DEDENT return False NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 2 , 3 , 3 , 3 , 3 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE x = 3 NEW_LINE if ( isMajorityElement ( arr , n , x ) ) : NEW_LINE INDENT print ( x , " ▁ appears ▁ more ▁ than ▁ " , n // 2 , " ▁ times ▁ in ▁ arr [ ] " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( x , " ▁ does ▁ not ▁ appear ▁ more ▁ than " , n // 2 , " ▁ times ▁ in ▁ arr [ ] " ) NEW_LINE DEDENT DEDENT
def isPairSum ( A , N , X ) : NEW_LINE
i = 0 NEW_LINE
j = N - 1 NEW_LINE while ( i < j ) : NEW_LINE
if ( A [ i ] + A [ j ] == X ) : NEW_LINE INDENT return True NEW_LINE DEDENT
elif ( A [ i ] + A [ j ] < X ) : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT j -= 1 NEW_LINE DEDENT return 0 NEW_LINE
arr = [ 3 , 5 , 9 , 2 , 8 , 10 , 11 ] NEW_LINE
val = 17 NEW_LINE
print ( isPairSum ( arr , len ( arr ) , val ) ) NEW_LINE
def findPeak ( arr , n ) : NEW_LINE
if ( n == 1 ) : NEW_LINE return 0 NEW_LINE if ( arr [ 0 ] >= arr [ 1 ] ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT if ( arr [ n - 1 ] >= arr [ n - 2 ] ) : NEW_LINE INDENT return n - 1 NEW_LINE DEDENT
for i in range ( 1 , n - 1 ) : NEW_LINE
if ( arr [ i ] >= arr [ i - 1 ] and arr [ i ] >= arr [ i + 1 ] ) : NEW_LINE INDENT return i NEW_LINE DEDENT
arr = [ 1 , 3 , 20 , 4 , 1 , 0 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Index ▁ of ▁ a ▁ peak ▁ point ▁ is " , findPeak ( arr , n ) ) NEW_LINE
def maxTripletSum ( arr , n ) : NEW_LINE
sm = - 1000000 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT for k in range ( j + 1 , n ) : NEW_LINE INDENT if ( sm < ( arr [ i ] + arr [ j ] + arr [ k ] ) ) : NEW_LINE INDENT sm = arr [ i ] + arr [ j ] + arr [ k ] NEW_LINE DEDENT DEDENT DEDENT DEDENT return sm NEW_LINE
arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxTripletSum ( arr , n ) ) NEW_LINE
def maxTripletSum ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
return ( arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ) NEW_LINE
arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxTripletSum ( arr , n ) ) NEW_LINE
def maxTripletSum ( arr , n ) : NEW_LINE
maxA = - 100000000 NEW_LINE maxB = - 100000000 NEW_LINE maxC = - 100000000 NEW_LINE for i in range ( 0 , n ) : NEW_LINE
if ( arr [ i ] > maxA ) : NEW_LINE INDENT maxC = maxB NEW_LINE maxB = maxA NEW_LINE maxA = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > maxB ) : NEW_LINE INDENT maxC = maxB NEW_LINE maxB = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > maxC ) : NEW_LINE INDENT maxC = arr [ i ] NEW_LINE DEDENT return ( maxA + maxB + maxC ) NEW_LINE
arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxTripletSum ( arr , n ) ) NEW_LINE
def maximum ( a , b , c ) : NEW_LINE INDENT return max ( max ( a , b ) , c ) NEW_LINE DEDENT
def minimum ( a , b , c ) : NEW_LINE INDENT return min ( min ( a , b ) , c ) NEW_LINE DEDENT
def smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) : NEW_LINE
arr1 . sort ( ) NEW_LINE arr2 . sort ( ) NEW_LINE arr3 . sort ( ) NEW_LINE
res_min = 0 ; res_max = 0 ; res_mid = 0 NEW_LINE
i = 0 ; j = 0 ; k = 0 NEW_LINE
diff = 2147483647 NEW_LINE while ( i < n and j < n and k < n ) : NEW_LINE INDENT sum = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] NEW_LINE DEDENT
max = maximum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) NEW_LINE
min = minimum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) NEW_LINE if ( min == arr1 [ i ] ) : NEW_LINE INDENT i += 1 NEW_LINE DEDENT elif ( min == arr2 [ j ] ) : NEW_LINE INDENT j += 1 NEW_LINE DEDENT else : NEW_LINE INDENT k += 1 NEW_LINE DEDENT
if ( diff > ( max - min ) ) : NEW_LINE INDENT diff = max - min NEW_LINE res_max = max NEW_LINE res_mid = sum - ( max + min ) NEW_LINE res_min = min NEW_LINE DEDENT
print ( res_max , " , " , res_mid , " , " , res_min ) NEW_LINE
arr1 = [ 5 , 2 , 8 ] NEW_LINE arr2 = [ 10 , 7 , 12 ] NEW_LINE arr3 = [ 9 , 14 , 6 ] NEW_LINE n = len ( arr1 ) NEW_LINE smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) NEW_LINE
def find3Numbers ( A , arr_size , sum ) : NEW_LINE
A . sort ( ) NEW_LINE
for i in range ( 0 , arr_size - 2 ) : NEW_LINE
l = i + 1 NEW_LINE
r = arr_size - 1 NEW_LINE while ( l < r ) : NEW_LINE INDENT if ( A [ i ] + A [ l ] + A [ r ] == sum ) : NEW_LINE INDENT print ( " Triplet ▁ is " , A [ i ] , ' , ▁ ' , A [ l ] , ' , ▁ ' , A [ r ] ) ; NEW_LINE return True NEW_LINE DEDENT elif ( A [ i ] + A [ l ] + A [ r ] < sum ) : NEW_LINE INDENT l += 1 NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT r -= 1 NEW_LINE DEDENT
return False NEW_LINE
A = [ 1 , 4 , 45 , 6 , 10 , 8 ] NEW_LINE sum = 22 NEW_LINE arr_size = len ( A ) NEW_LINE find3Numbers ( A , arr_size , sum ) NEW_LINE
SIZE = 10 NEW_LINE
def sortMat ( mat , n ) : NEW_LINE
temp = [ 0 ] * ( n * n ) NEW_LINE k = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE INDENT temp [ k ] = mat [ i ] [ j ] NEW_LINE k += 1 NEW_LINE DEDENT DEDENT
temp . sort ( ) NEW_LINE
k = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE INDENT mat [ i ] [ j ] = temp [ k ] NEW_LINE k += 1 NEW_LINE DEDENT DEDENT
def printMat ( mat , n ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
mat = [ [ 5 , 4 , 7 ] , [ 1 , 3 , 8 ] , [ 2 , 9 , 6 ] ] NEW_LINE n = 3 NEW_LINE print ( " Original ▁ Matrix : " ) NEW_LINE printMat ( mat , n ) NEW_LINE sortMat ( mat , n ) NEW_LINE print ( " Matrix After Sorting : " ) NEW_LINE printMat ( mat , n ) NEW_LINE
def subArray ( arr , n ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
for j in range ( i , n ) : NEW_LINE
for k in range ( i , j + 1 ) : NEW_LINE INDENT print ( arr [ k ] , end = " ▁ " ) NEW_LINE DEDENT print ( " " , end = " " ) NEW_LINE
arr = [ 1 , 2 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " All ▁ Non - empty ▁ Subarrays " ) NEW_LINE subArray ( arr , n ) ; NEW_LINE
import math NEW_LINE def printSubsequences ( arr , n ) : NEW_LINE
opsize = math . pow ( 2 , n ) NEW_LINE
for counter in range ( 1 , ( int ) ( opsize ) ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT
if ( counter & ( 1 << j ) ) : NEW_LINE INDENT print ( arr [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE
arr = [ 1 , 2 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " All ▁ Non - empty ▁ Subsequences " ) NEW_LINE printSubsequences ( arr , n ) NEW_LINE
def productArray ( arr , n ) : NEW_LINE
if n == 1 : NEW_LINE INDENT print ( 0 ) NEW_LINE return NEW_LINE DEDENT i , temp = 1 , 1 NEW_LINE
prod = [ 1 for i in range ( n ) ] NEW_LINE
for i in range ( n ) : NEW_LINE INDENT prod [ i ] = temp NEW_LINE temp *= arr [ i ] NEW_LINE DEDENT
temp = 1 NEW_LINE
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE INDENT prod [ i ] *= temp NEW_LINE temp *= arr [ i ] NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT print ( prod [ i ] , end = " ▁ " ) NEW_LINE DEDENT return NEW_LINE
arr = [ 10 , 3 , 5 , 6 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ product ▁ array ▁ is : ▁ n " ) NEW_LINE productArray ( arr , n ) NEW_LINE
def areConsecutive ( arr , n ) : NEW_LINE INDENT if ( n < 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
Min = min ( arr ) NEW_LINE
Max = max ( arr ) NEW_LINE
if ( Max - Min + 1 == n ) : NEW_LINE
visited = [ False for i in range ( n ) ] NEW_LINE for i in range ( n ) : NEW_LINE
if ( visited [ arr [ i ] - Min ] != False ) : NEW_LINE INDENT return False NEW_LINE DEDENT
visited [ arr [ i ] - Min ] = True NEW_LINE
return True NEW_LINE
return False NEW_LINE
arr = [ 5 , 4 , 2 , 3 , 1 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE if ( areConsecutive ( arr , n ) == True ) : NEW_LINE INDENT print ( " Array ▁ elements ▁ are ▁ consecutive ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Array ▁ elements ▁ are ▁ not ▁ consecutive ▁ " ) NEW_LINE DEDENT
def areConsecutive ( arr , n ) : NEW_LINE INDENT if ( n < 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
min = getMin ( arr , n ) NEW_LINE
max = getMax ( arr , n ) NEW_LINE
if ( max - min + 1 == n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] < 0 ) : NEW_LINE INDENT j = - arr [ i ] - min NEW_LINE DEDENT else : NEW_LINE INDENT j = arr [ i ] - min NEW_LINE DEDENT DEDENT DEDENT
if ( arr [ j ] > 0 ) : NEW_LINE INDENT arr [ j ] = - arr [ j ] NEW_LINE DEDENT else : NEW_LINE INDENT return False NEW_LINE DEDENT
return True NEW_LINE
return False NEW_LINE
def getMin ( arr , n ) : NEW_LINE INDENT min = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] < min ) : NEW_LINE INDENT min = arr [ i ] NEW_LINE DEDENT DEDENT return min NEW_LINE DEDENT def getMax ( arr , n ) : NEW_LINE INDENT max = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] > max ) : NEW_LINE INDENT max = arr [ i ] NEW_LINE DEDENT DEDENT return max NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 4 , 5 , 3 , 2 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE if ( areConsecutive ( arr , n ) == True ) : NEW_LINE INDENT print ( " ▁ Array ▁ elements ▁ are ▁ consecutive ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " ▁ Array ▁ elements ▁ are ▁ not ▁ consecutive ▁ " ) NEW_LINE DEDENT DEDENT
def relativeComplement ( arr1 , arr2 , n , m ) : NEW_LINE INDENT i = 0 NEW_LINE j = 0 NEW_LINE while ( i < n and j < m ) : NEW_LINE DEDENT
if ( arr1 [ i ] < arr2 [ j ] ) : NEW_LINE INDENT print ( arr1 [ i ] , " ▁ " , end = " " ) NEW_LINE i += 1 NEW_LINE DEDENT
elif ( arr1 [ i ] > arr2 [ j ] ) : NEW_LINE INDENT j += 1 NEW_LINE DEDENT
elif ( arr1 [ i ] == arr2 [ j ] ) : NEW_LINE INDENT i += 1 NEW_LINE j += 1 NEW_LINE DEDENT
while ( i < n ) : NEW_LINE INDENT print ( arr1 [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT
arr1 = [ 3 , 6 , 10 , 12 , 15 ] NEW_LINE arr2 = [ 1 , 3 , 5 , 10 , 16 ] NEW_LINE n = len ( arr1 ) NEW_LINE m = len ( arr2 ) NEW_LINE relativeComplement ( arr1 , arr2 , n , m ) NEW_LINE
def minOps ( arr , n , k ) : NEW_LINE
max1 = max ( arr ) NEW_LINE res = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
if ( ( max1 - arr [ i ] ) % k != 0 ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
else : NEW_LINE INDENT res += ( max1 - arr [ i ] ) / k NEW_LINE DEDENT
return int ( res ) NEW_LINE
arr = [ 21 , 33 , 9 , 45 , 63 ] NEW_LINE n = len ( arr ) NEW_LINE k = 6 NEW_LINE print ( minOps ( arr , n , k ) ) NEW_LINE
def solve ( A , B , C ) : NEW_LINE
i = len ( A ) - 1 NEW_LINE j = len ( B ) - 1 NEW_LINE k = len ( C ) - 1 NEW_LINE
min_diff = abs ( max ( A [ i ] , B [ j ] , C [ k ] ) - min ( A [ i ] , B [ j ] , C [ k ] ) ) NEW_LINE while i != - 1 and j != - 1 and k != - 1 : NEW_LINE INDENT current_diff = abs ( max ( A [ i ] , B [ j ] , C [ k ] ) - min ( A [ i ] , B [ j ] , C [ k ] ) ) NEW_LINE DEDENT
if current_diff < min_diff : NEW_LINE INDENT min_diff = current_diff NEW_LINE DEDENT
max_term = max ( A [ i ] , B [ j ] , C [ k ] ) NEW_LINE
if A [ i ] == max_term : NEW_LINE INDENT i -= 1 NEW_LINE DEDENT elif B [ j ] == max_term : NEW_LINE INDENT j -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT k -= 1 NEW_LINE DEDENT return min_diff NEW_LINE
A = [ 5 , 8 , 10 , 15 ] NEW_LINE B = [ 6 , 9 , 15 , 78 , 89 ] NEW_LINE C = [ 2 , 3 , 6 , 6 , 8 , 8 , 10 ] NEW_LINE print ( solve ( A , B , C ) ) NEW_LINE
def search ( arr , search_Element ) : NEW_LINE INDENT left = 0 NEW_LINE length = len ( arr ) NEW_LINE position = - 1 NEW_LINE right = length - 1 NEW_LINE DEDENT
for left in range ( 0 , right , 1 ) : NEW_LINE
if ( arr [ left ] == search_Element ) : NEW_LINE INDENT position = left NEW_LINE print ( " Element ▁ found ▁ in ▁ Array ▁ at ▁ " , position + 1 , " ▁ Position ▁ with ▁ " , left + 1 , " ▁ Attempt " ) NEW_LINE break NEW_LINE DEDENT
if ( arr [ right ] == search_Element ) : NEW_LINE INDENT position = right NEW_LINE print ( " Element ▁ found ▁ in ▁ Array ▁ at ▁ " , position + 1 , " ▁ Position ▁ with ▁ " , length - right , " ▁ Attempt " ) NEW_LINE break NEW_LINE DEDENT left += 1 NEW_LINE right -= 1 NEW_LINE
if ( position == - 1 ) : NEW_LINE INDENT print ( " Not ▁ found ▁ in ▁ Array ▁ with ▁ " , left , " ▁ Attempt " ) NEW_LINE DEDENT
arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE search_element = 5 NEW_LINE
search ( arr , search_element ) NEW_LINE
import math NEW_LINE def jumpSearch ( arr , x , n ) : NEW_LINE
step = math . sqrt ( n ) NEW_LINE
prev = 0 NEW_LINE while arr [ int ( min ( step , n ) - 1 ) ] < x : NEW_LINE INDENT prev = step NEW_LINE step += math . sqrt ( n ) NEW_LINE if prev >= n : NEW_LINE INDENT return - 1 NEW_LINE DEDENT DEDENT
while arr [ int ( prev ) ] < x : NEW_LINE INDENT prev += 1 NEW_LINE DEDENT
if prev == min ( step , n ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
if arr [ int ( prev ) ] == x : NEW_LINE INDENT return prev NEW_LINE DEDENT return - 1 NEW_LINE
arr = [ 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 ] NEW_LINE x = 55 NEW_LINE n = len ( arr ) NEW_LINE
index = jumpSearch ( arr , x , n ) NEW_LINE
print ( " Number " , x , " is ▁ at ▁ index " , " % .0f " % index ) NEW_LINE
def interpolationSearch ( arr , lo , hi , x ) : NEW_LINE
if ( lo <= hi and x >= arr [ lo ] and x <= arr [ hi ] ) : NEW_LINE
pos = lo + ( ( hi - lo ) // ( arr [ hi ] - arr [ lo ] ) * ( x - arr [ lo ] ) ) NEW_LINE
if arr [ pos ] == x : NEW_LINE INDENT return pos NEW_LINE DEDENT
if arr [ pos ] < x : NEW_LINE INDENT return interpolationSearch ( arr , pos + 1 , hi , x ) NEW_LINE DEDENT
if arr [ pos ] > x : NEW_LINE INDENT return interpolationSearch ( arr , lo , pos - 1 , x ) NEW_LINE DEDENT return - 1 NEW_LINE
arr = [ 10 , 12 , 13 , 16 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 33 , 35 , 42 , 47 ] NEW_LINE n = len ( arr ) NEW_LINE
x = 18 NEW_LINE index = interpolationSearch ( arr , 0 , n - 1 , x ) NEW_LINE
if index != - 1 : NEW_LINE INDENT print ( " Element ▁ found ▁ at ▁ index " , index ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Element ▁ not ▁ found " ) NEW_LINE DEDENT
def exponentialSearch ( arr , n , x ) : NEW_LINE
if arr [ 0 ] == x : NEW_LINE INDENT return 0 NEW_LINE DEDENT
i = 1 NEW_LINE while i < n and arr [ i ] <= x : NEW_LINE INDENT i = i * 2 NEW_LINE DEDENT
return binarySearch ( arr , i / 2 , min ( i , n - 1 ) , x ) NEW_LINE
def binarySearch ( arr , l , r , x ) : NEW_LINE INDENT if r >= l : NEW_LINE INDENT mid = l + ( r - l ) / 2 NEW_LINE DEDENT DEDENT
if arr [ mid ] == x : NEW_LINE INDENT return mid NEW_LINE DEDENT
if arr [ mid ] > x : NEW_LINE INDENT return binarySearch ( arr , l , mid - 1 , x ) NEW_LINE DEDENT
return binarySearch ( arr , mid + 1 , r , x ) NEW_LINE
return - 1 NEW_LINE
arr = [ 2 , 3 , 4 , 10 , 40 ] NEW_LINE n = len ( arr ) NEW_LINE x = 10 NEW_LINE result = exponentialSearch ( arr , n , x ) NEW_LINE if result == - 1 : NEW_LINE INDENT print " Element ▁ not ▁ found ▁ in ▁ thye ▁ array " NEW_LINE DEDENT else : NEW_LINE INDENT print " Element ▁ is ▁ present ▁ at ▁ index ▁ % d " % ( result ) NEW_LINE DEDENT
def count_sort ( arr ) : NEW_LINE INDENT max_element = int ( max ( arr ) ) NEW_LINE min_element = int ( min ( arr ) ) NEW_LINE range_of_elements = max_element - min_element + 1 NEW_LINE count_arr = [ 0 for _ in range ( range_of_elements ) ] NEW_LINE output_arr = [ 0 for _ in range ( len ( arr ) ) ] NEW_LINE for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT count_arr [ arr [ i ] - min_element ] += 1 NEW_LINE DEDENT for i in range ( 1 , len ( count_arr ) ) : NEW_LINE INDENT count_arr [ i ] += count_arr [ i - 1 ] NEW_LINE DEDENT for i in range ( len ( arr ) - 1 , - 1 , - 1 ) : NEW_LINE INDENT output_arr [ count_arr [ arr [ i ] - min_element ] - 1 ] = arr [ i ] NEW_LINE count_arr [ arr [ i ] - min_element ] -= 1 NEW_LINE DEDENT for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT arr [ i ] = output_arr [ i ] NEW_LINE DEDENT return arr NEW_LINE DEDENT
arr = [ - 5 , - 10 , 0 , - 3 , 8 , 5 , - 1 , 10 ] NEW_LINE ans = count_sort ( arr ) NEW_LINE print ( " Sorted ▁ character ▁ array ▁ is ▁ " + str ( ans ) ) NEW_LINE
def getNextGap ( gap ) : NEW_LINE
gap = ( gap * 10 ) / 13 NEW_LINE if gap < 1 : NEW_LINE INDENT return 1 NEW_LINE DEDENT return gap NEW_LINE
def combSort ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE DEDENT
gap = n NEW_LINE
swapped = True NEW_LINE
while gap != 1 or swapped == 1 : NEW_LINE
gap = getNextGap ( gap ) NEW_LINE
swapped = False NEW_LINE
for i in range ( 0 , n - gap ) : NEW_LINE INDENT if arr [ i ] > arr [ i + gap ] : NEW_LINE DEDENT
/ * Swap arr [ i ] and arr [ i + gap ] * / NEW_LINE INDENT arr [ i ] , arr [ i + gap ] = arr [ i + gap ] , arr [ i ] NEW_LINE DEDENT
/ * Set swapped * / NEW_LINE INDENT swapped = True NEW_LINE DEDENT
arr = [ 8 , 4 , 1 , 3 , - 44 , 23 , - 6 , 28 , 0 ] NEW_LINE combSort ( arr ) NEW_LINE print ( " Sorted ▁ array : " ) NEW_LINE for i in range ( len ( arr ) ) : NEW_LINE INDENT print ( arr [ i ] ) , NEW_LINE DEDENT
def cycleSort ( array ) : NEW_LINE
INDENT writes = 0 NEW_LINE DEDENT
INDENT for cycleStart in range ( 0 , len ( array ) - 1 ) : NEW_LINE DEDENT
item = array [ cycleStart ] NEW_LINE
pos = cycleStart NEW_LINE for i in range ( cycleStart + 1 , len ( array ) ) : NEW_LINE if array [ i ] < item : NEW_LINE INDENT pos += 1 NEW_LINE DEDENT
if pos == cycleStart : NEW_LINE continue NEW_LINE
while item == array [ pos ] : NEW_LINE pos += 1 NEW_LINE
array [ pos ] , item = item , array [ pos ] NEW_LINE writes += 1 NEW_LINE
while pos != cycleStart : NEW_LINE
pos = cycleStart NEW_LINE for i in range ( cycleStart + 1 , len ( array ) ) : NEW_LINE INDENT if array [ i ] < item : NEW_LINE pos += 1 NEW_LINE DEDENT
while item == array [ pos ] : NEW_LINE INDENT pos += 1 NEW_LINE DEDENT
array [ pos ] , item = item , array [ pos ] NEW_LINE writes += 1 NEW_LINE INDENT return writes NEW_LINE DEDENT
arr = [ 1 , 8 , 3 , 9 , 10 , 10 , 2 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE cycleSort ( arr ) NEW_LINE print ( " After ▁ sort ▁ : ▁ " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = ' ▁ ' ) NEW_LINE DEDENT
def findCrossOver ( arr , low , high , x ) : NEW_LINE
if ( arr [ high ] <= x ) : NEW_LINE INDENT return high NEW_LINE DEDENT
if ( arr [ low ] > x ) : NEW_LINE INDENT return low NEW_LINE DEDENT
mid = ( low + high ) // 2 NEW_LINE
if ( arr [ mid ] <= x and arr [ mid + 1 ] > x ) : NEW_LINE INDENT return mid NEW_LINE DEDENT
if ( arr [ mid ] < x ) : NEW_LINE INDENT return findCrossOver ( arr , mid + 1 , high , x ) NEW_LINE DEDENT return findCrossOver ( arr , low , mid - 1 , x ) NEW_LINE
def printKclosest ( arr , x , k , n ) : NEW_LINE
l = findCrossOver ( arr , 0 , n - 1 , x ) NEW_LINE
r = l + 1 NEW_LINE
count = 0 NEW_LINE
if ( arr [ l ] == x ) : NEW_LINE INDENT l -= 1 NEW_LINE DEDENT
while ( l >= 0 and r < n and count < k ) : NEW_LINE INDENT if ( x - arr [ l ] < arr [ r ] - x ) : NEW_LINE INDENT print ( arr [ l ] , end = " ▁ " ) NEW_LINE l -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT print ( arr [ r ] , end = " ▁ " ) NEW_LINE r += 1 NEW_LINE DEDENT count += 1 NEW_LINE DEDENT
while ( count < k and l >= 0 ) : NEW_LINE INDENT print ( arr [ l ] , end = " ▁ " ) NEW_LINE l -= 1 NEW_LINE count += 1 NEW_LINE DEDENT
while ( count < k and r < n ) : NEW_LINE INDENT print ( arr [ r ] , end = " ▁ " ) NEW_LINE r += 1 NEW_LINE count += 1 NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 ] NEW_LINE n = len ( arr ) NEW_LINE x = 35 NEW_LINE k = 4 NEW_LINE printKclosest ( arr , x , 4 , n ) NEW_LINE DEDENT
def countSort ( arr , n , exp ) : NEW_LINE
output = [ 0 ] * n NEW_LINE count = [ 0 ] * n NEW_LINE for i in range ( n ) : NEW_LINE INDENT count [ i ] = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT count [ ( arr [ i ] // exp ) % n ] += 1 NEW_LINE DEDENT
for i in range ( 1 , n ) : NEW_LINE INDENT count [ i ] += count [ i - 1 ] NEW_LINE DEDENT
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE INDENT output [ count [ ( arr [ i ] // exp ) % n ] - 1 ] = arr [ i ] NEW_LINE count [ ( arr [ i ] // exp ) % n ] -= 1 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT arr [ i ] = output [ i ] NEW_LINE DEDENT
def sort ( arr , n ) : NEW_LINE
countSort ( arr , n , 1 ) NEW_LINE
countSort ( arr , n , n ) NEW_LINE
arr = [ 40 , 12 , 45 , 32 , 33 , 1 , 22 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Given ▁ array ▁ is " ) NEW_LINE print ( * arr ) NEW_LINE sort ( arr , n ) NEW_LINE print ( " Sorted ▁ array ▁ is " ) NEW_LINE print ( * arr ) NEW_LINE
def printClosest ( ar1 , ar2 , m , n , x ) : NEW_LINE
diff = sys . maxsize NEW_LINE
l = 0 NEW_LINE r = n - 1 NEW_LINE while ( l < m and r >= 0 ) : NEW_LINE
if abs ( ar1 [ l ] + ar2 [ r ] - x ) < diff : NEW_LINE INDENT res_l = l NEW_LINE res_r = r NEW_LINE diff = abs ( ar1 [ l ] + ar2 [ r ] - x ) NEW_LINE DEDENT
if ar1 [ l ] + ar2 [ r ] > x : NEW_LINE INDENT r = r - 1 NEW_LINE DEDENT
else : NEW_LINE INDENT l = l + 1 NEW_LINE DEDENT
print ( " The ▁ closest ▁ pair ▁ is ▁ [ " , ar1 [ res_l ] , " , " , ar2 [ res_r ] , " ] " ) NEW_LINE
ar1 = [ 1 , 4 , 5 , 7 ] NEW_LINE ar2 = [ 10 , 20 , 30 , 40 ] NEW_LINE m = len ( ar1 ) NEW_LINE n = len ( ar2 ) NEW_LINE x = 38 NEW_LINE printClosest ( ar1 , ar2 , m , n , x ) NEW_LINE
def printClosest ( arr , n , x ) : NEW_LINE
res_l , res_r = 0 , 0 NEW_LINE
l , r , diff = 0 , n - 1 , MAX_VAL NEW_LINE
while r > l : NEW_LINE
if abs ( arr [ l ] + arr [ r ] - x ) < diff : NEW_LINE INDENT res_l = l NEW_LINE res_r = r NEW_LINE diff = abs ( arr [ l ] + arr [ r ] - x ) NEW_LINE DEDENT if arr [ l ] + arr [ r ] > x : NEW_LINE
r -= 1 NEW_LINE else : NEW_LINE
l += 1 NEW_LINE print ( ' The ▁ closest ▁ pair ▁ is ▁ { } ▁ and ▁ { } ' . format ( arr [ res_l ] , arr [ res_r ] ) ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 10 , 22 , 28 , 29 , 30 , 40 ] NEW_LINE n = len ( arr ) NEW_LINE x = 54 NEW_LINE printClosest ( arr , n , x ) NEW_LINE DEDENT
def countOnes ( arr , low , high ) : NEW_LINE INDENT if high >= low : NEW_LINE DEDENT
mid = low + ( high - low ) // 2 NEW_LINE
if ( ( mid == high or arr [ mid + 1 ] == 0 ) and ( arr [ mid ] == 1 ) ) : NEW_LINE INDENT return mid + 1 NEW_LINE DEDENT
if arr [ mid ] == 1 : NEW_LINE INDENT return countOnes ( arr , ( mid + 1 ) , high ) NEW_LINE DEDENT
return countOnes ( arr , low , mid - 1 ) NEW_LINE return 0 NEW_LINE
arr = [ 1 , 1 , 1 , 1 , 0 , 0 , 0 ] NEW_LINE print ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is " , countOnes ( arr , 0 , len ( arr ) - 1 ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def push ( head_ref , new_data ) : NEW_LINE
new_node = Node ( 0 ) NEW_LINE new_node . data = new_data NEW_LINE
new_node . next = ( head_ref ) NEW_LINE
( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE
def insertionSort ( head_ref ) : NEW_LINE
sorted = None NEW_LINE
current = head_ref NEW_LINE while ( current != None ) : NEW_LINE
next = current . next NEW_LINE
sorted = sortedInsert ( sorted , current ) NEW_LINE
current = next NEW_LINE
head_ref = sorted NEW_LINE return head_ref NEW_LINE
def sortedInsert ( head_ref , new_node ) : NEW_LINE INDENT current = None NEW_LINE DEDENT
if ( head_ref == None or ( head_ref ) . data >= new_node . data ) : NEW_LINE INDENT new_node . next = head_ref NEW_LINE head_ref = new_node NEW_LINE DEDENT else : NEW_LINE INDENT current = head_ref NEW_LINE DEDENT
while ( current . next != None and current . next . data < new_node . data ) : NEW_LINE INDENT current = current . next NEW_LINE DEDENT new_node . next = current . next NEW_LINE current . next = new_node NEW_LINE return head_ref NEW_LINE
def printList ( head ) : NEW_LINE INDENT temp = head NEW_LINE while ( temp != None ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT DEDENT
a = None NEW_LINE a = push ( a , 5 ) NEW_LINE a = push ( a , 20 ) NEW_LINE a = push ( a , 4 ) NEW_LINE a = push ( a , 3 ) NEW_LINE a = push ( a , 30 ) NEW_LINE print ( " Linked ▁ List ▁ before ▁ sorting ▁ " ) NEW_LINE printList ( a ) NEW_LINE a = insertionSort ( a ) NEW_LINE print ( " Linked List after sorting   " ) NEW_LINE printList ( a ) NEW_LINE
def minSwaps ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE maxx , minn , l , r = - 1 , arr [ 0 ] , 0 , 0 NEW_LINE for i in range ( n ) : NEW_LINE DEDENT
if arr [ i ] > maxx : NEW_LINE INDENT maxx = arr [ i ] NEW_LINE l = i NEW_LINE DEDENT
if arr [ i ] <= minn : NEW_LINE INDENT minn = arr [ i ] NEW_LINE r = i NEW_LINE DEDENT if r < l : NEW_LINE print ( l + ( n - r - 2 ) ) NEW_LINE else : NEW_LINE print ( l + ( n - r - 1 ) ) NEW_LINE
arr = [ 5 , 6 , 1 , 3 ] NEW_LINE minSwaps ( arr ) NEW_LINE
def MaxActivities ( arr , n ) : NEW_LINE
selected = [ ] NEW_LINE Activity . sort ( key = lambda x : x [ 1 ] ) NEW_LINE
i = 0 NEW_LINE selected . append ( arr [ i ] ) NEW_LINE
for j in range ( 1 , n ) : NEW_LINE
if arr [ j ] [ 0 ] >= arr [ i ] [ 1 ] : NEW_LINE INDENT selected . append ( arr [ j ] ) NEW_LINE i = j NEW_LINE DEDENT return selected NEW_LINE
Activity = [ [ 5 , 9 ] , [ 1 , 2 ] , [ 3 , 4 ] , [ 0 , 6 ] , [ 5 , 7 ] , [ 8 , 9 ] ] NEW_LINE n = len ( Activity ) NEW_LINE selected = MaxActivities ( Activity , n ) NEW_LINE print ( " Following ▁ activities ▁ are ▁ selected ▁ : " ) NEW_LINE print ( selected ) NEW_LINE
global maximum NEW_LINE
def _lis ( arr , n ) : NEW_LINE INDENT global maximum NEW_LINE DEDENT
if n == 1 : NEW_LINE INDENT return 1 NEW_LINE DEDENT
maxEndingHere = 1 NEW_LINE
for i in xrange ( 1 , n ) : NEW_LINE INDENT res = _lis ( arr , i ) NEW_LINE if arr [ i - 1 ] < arr [ n - 1 ] and res + 1 > maxEndingHere : NEW_LINE INDENT maxEndingHere = res + 1 NEW_LINE DEDENT DEDENT
maximum = max ( maximum , maxEndingHere ) NEW_LINE
return maxEndingHere NEW_LINE
def lis ( arr ) : NEW_LINE INDENT global maximum NEW_LINE n = len ( arr ) NEW_LINE DEDENT
maximum = 1 NEW_LINE
_lis ( arr , n ) NEW_LINE
return maximum NEW_LINE
arr = [ 10 , 22 , 9 , 33 , 21 , 50 , 41 , 60 ] NEW_LINE n = len ( arr ) NEW_LINE print " Length ▁ of ▁ lis ▁ is ▁ " , lis ( arr ) NEW_LINE
def lis ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE DEDENT
lis = [ 1 ] * n NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT for j in range ( 0 , i ) : NEW_LINE INDENT if arr [ i ] > arr [ j ] and lis [ i ] < lis [ j ] + 1 : NEW_LINE INDENT lis [ i ] = lis [ j ] + 1 NEW_LINE DEDENT DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT maximum = max ( maximum , lis [ i ] ) NEW_LINE DEDENT return maximum NEW_LINE
arr = [ 10 , 22 , 9 , 33 , 21 , 50 , 41 , 60 ] NEW_LINE print " Length ▁ of ▁ lis ▁ is " , lis ( arr ) NEW_LINE
def minCost ( cost , row , col ) : NEW_LINE
for i in range ( 1 , row ) : NEW_LINE INDENT cost [ i ] [ 0 ] += cost [ i - 1 ] [ 0 ] NEW_LINE DEDENT
for j in range ( 1 , col ) : NEW_LINE INDENT cost [ 0 ] [ j ] += cost [ 0 ] [ j - 1 ] NEW_LINE DEDENT
for i in range ( 1 , row ) : NEW_LINE INDENT for j in range ( 1 , col ) : NEW_LINE INDENT cost [ i ] [ j ] += ( min ( cost [ i - 1 ] [ j - 1 ] , min ( cost [ i - 1 ] [ j ] , cost [ i ] [ j - 1 ] ) ) ) NEW_LINE DEDENT DEDENT
return cost [ row - 1 ] [ col - 1 ] NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT row = 3 NEW_LINE col = 3 NEW_LINE cost = [ [ 1 , 2 , 3 ] , [ 4 , 8 , 2 ] , [ 1 , 5 , 3 ] ] NEW_LINE print ( minCost ( cost , row , col ) ) ; NEW_LINE DEDENT
def count ( S , m , n ) : NEW_LINE
if ( n == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
if ( n < 0 ) : NEW_LINE INDENT return 0 ; NEW_LINE DEDENT
if ( m <= 0 and n >= 1 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
return count ( S , m - 1 , n ) + count ( S , m , n - S [ m - 1 ] ) ; NEW_LINE
arr = [ 1 , 2 , 3 ] NEW_LINE m = len ( arr ) NEW_LINE print ( count ( arr , m , 4 ) ) NEW_LINE
def count ( S , m , n ) : NEW_LINE
table = [ 0 for k in range ( n + 1 ) ] NEW_LINE
table [ 0 ] = 1 NEW_LINE
for i in range ( 0 , m ) : NEW_LINE INDENT for j in range ( S [ i ] , n + 1 ) : NEW_LINE INDENT table [ j ] += table [ j - S [ i ] ] NEW_LINE DEDENT DEDENT return table [ n ] NEW_LINE
arr = [ 1 , 2 , 3 ] NEW_LINE m = len ( arr ) NEW_LINE n = 4 NEW_LINE x = count ( arr , m , n ) NEW_LINE print ( x ) NEW_LINE
import sys NEW_LINE dp = [ [ - 1 for i in range ( 100 ) ] for j in range ( 100 ) ] NEW_LINE
def matrixChainMemoised ( p , i , j ) : NEW_LINE INDENT if ( i == j ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT if ( dp [ i ] [ j ] != - 1 ) : NEW_LINE INDENT return dp [ i ] [ j ] NEW_LINE DEDENT dp [ i ] [ j ] = sys . maxsize NEW_LINE for k in range ( i , j ) : NEW_LINE INDENT dp [ i ] [ j ] = min ( dp [ i ] [ j ] , matrixChainMemoised ( p , i , k ) + matrixChainMemoised ( p , k + 1 , j ) + p [ i - 1 ] * p [ k ] * p [ j ] ) NEW_LINE DEDENT return dp [ i ] [ j ] NEW_LINE DEDENT def MatrixChainOrder ( p , n ) : NEW_LINE INDENT i = 1 NEW_LINE j = n - 1 NEW_LINE return matrixChainMemoised ( p , i , j ) NEW_LINE DEDENT
arr = [ 1 , 2 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ number ▁ of ▁ multiplications ▁ is " , MatrixChainOrder ( arr , n ) ) NEW_LINE
def binomialCoeff ( n , k ) : NEW_LINE INDENT C = [ 0 for i in xrange ( k + 1 ) ] NEW_LINE DEDENT
C [ 0 ] = 1 NEW_LINE for i in range ( 1 , n + 1 ) : NEW_LINE
j = min ( i , k ) NEW_LINE while ( j > 0 ) : NEW_LINE INDENT C [ j ] = C [ j ] + C [ j - 1 ] NEW_LINE j -= 1 NEW_LINE DEDENT return C [ k ] NEW_LINE
n = 5 NEW_LINE k = 2 NEW_LINE print " Value ▁ of ▁ C ( % d , % d ) ▁ is ▁ % d " % ( n , k , binomialCoeff ( n , k ) ) NEW_LINE
def eggDrop ( n , k ) : NEW_LINE
if ( k == 1 or k == 0 ) : NEW_LINE INDENT return k NEW_LINE DEDENT
if ( n == 1 ) : NEW_LINE INDENT return k NEW_LINE DEDENT min = sys . maxsize NEW_LINE
for x in range ( 1 , k + 1 ) : NEW_LINE INDENT res = max ( eggDrop ( n - 1 , x - 1 ) , eggDrop ( n , k - x ) ) NEW_LINE if ( res < min ) : NEW_LINE INDENT min = res NEW_LINE DEDENT DEDENT return min + 1 NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 2 NEW_LINE k = 10 NEW_LINE print ( " Minimum ▁ number ▁ of ▁ trials ▁ in ▁ worst ▁ case ▁ with " , n , " eggs ▁ and " , k , " floors ▁ is " , eggDrop ( n , k ) ) NEW_LINE DEDENT
def cutRod ( price , n ) : NEW_LINE INDENT if ( n <= 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT max_val = - sys . maxsize - 1 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT max_val = max ( max_val , price [ i ] + cutRod ( price , n - i - 1 ) ) NEW_LINE DEDENT return max_val NEW_LINE
arr = [ 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ] NEW_LINE size = len ( arr ) NEW_LINE print ( " Maximum ▁ Obtainable ▁ Value ▁ is " , cutRod ( arr , size ) ) NEW_LINE
def findRoot ( arr , n ) : NEW_LINE
root = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT root += ( arr [ i ] [ 0 ] - arr [ i ] [ 1 ] ) NEW_LINE DEDENT return root NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ [ 1 , 5 ] , [ 2 , 0 ] , [ 3 , 0 ] , [ 4 , 0 ] , [ 5 , 5 ] , [ 6 , 5 ] ] NEW_LINE n = len ( arr ) NEW_LINE print ( findRoot ( arr , n ) ) NEW_LINE DEDENT
def cutRod ( price , n ) : NEW_LINE INDENT val = [ 0 for x in range ( n + 1 ) ] NEW_LINE val [ 0 ] = 0 NEW_LINE DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT max_val = INT_MIN NEW_LINE for j in range ( i ) : NEW_LINE INDENT max_val = max ( max_val , price [ j ] + val [ i - j - 1 ] ) NEW_LINE DEDENT val [ i ] = max_val NEW_LINE DEDENT return val [ n ] NEW_LINE
arr = [ 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ] NEW_LINE size = len ( arr ) NEW_LINE print ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " + str ( cutRod ( arr , size ) ) ) NEW_LINE
def lbs ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE DEDENT
lis = [ 1 for i in range ( n + 1 ) ] NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT for j in range ( 0 , i ) : NEW_LINE INDENT if ( ( arr [ i ] > arr [ j ] ) and ( lis [ i ] < lis [ j ] + 1 ) ) : NEW_LINE INDENT lis [ i ] = lis [ j ] + 1 NEW_LINE DEDENT DEDENT DEDENT
lds = [ 1 for i in range ( n + 1 ) ] NEW_LINE
for i in reversed ( range ( n - 1 ) ) : NEW_LINE INDENT for j in reversed ( range ( i - 1 , n ) ) : NEW_LINE INDENT if ( arr [ i ] > arr [ j ] and lds [ i ] < lds [ j ] + 1 ) : NEW_LINE INDENT lds [ i ] = lds [ j ] + 1 NEW_LINE DEDENT DEDENT DEDENT
maximum = lis [ 0 ] + lds [ 0 ] - 1 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT maximum = max ( ( lis [ i ] + lds [ i ] - 1 ) , maximum ) NEW_LINE DEDENT return maximum NEW_LINE
arr = [ 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 ] NEW_LINE print " Length ▁ of ▁ LBS ▁ is " , lbs ( arr ) NEW_LINE
def isPalindrome ( x ) : NEW_LINE INDENT return x == x [ : : - 1 ] NEW_LINE DEDENT def minPalPartion ( string , i , j ) : NEW_LINE INDENT if i >= j or isPalindrome ( string [ i : j + 1 ] ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT ans = float ( ' inf ' ) NEW_LINE for k in range ( i , j ) : NEW_LINE INDENT count = ( 1 + minPalPartion ( string , i , k ) + minPalPartion ( string , k + 1 , j ) ) NEW_LINE ans = min ( ans , count ) NEW_LINE DEDENT return ans NEW_LINE DEDENT
def main ( ) : NEW_LINE INDENT string = " ababbbabbababa " NEW_LINE print ( " Min ▁ cuts ▁ needed ▁ for ▁ Palindrome ▁ Partitioning ▁ is ▁ " , minPalPartion ( string , 0 , len ( string ) - 1 ) , ) NEW_LINE DEDENT if __name__ == " _ _ main _ _ " : NEW_LINE INDENT main ( ) NEW_LINE DEDENT
def findPartiion ( arr , n ) : NEW_LINE INDENT Sum = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT Sum += arr [ i ] NEW_LINE DEDENT if ( Sum % 2 != 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT part = [ 0 ] * ( ( Sum // 2 ) + 1 ) NEW_LINE
for i in range ( ( Sum // 2 ) + 1 ) : NEW_LINE INDENT part [ i ] = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE
for j in range ( Sum // 2 , arr [ i ] - 1 , - 1 ) : NEW_LINE
if ( part [ j - arr [ i ] ] == 1 or j == arr [ i ] ) : NEW_LINE INDENT part [ j ] = 1 NEW_LINE DEDENT return part [ Sum // 2 ] NEW_LINE
arr = [ 1 , 3 , 3 , 2 , 3 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE
if ( findPartiion ( arr , n ) == 1 ) : NEW_LINE INDENT print ( " Can ▁ be ▁ divided ▁ into ▁ two ▁ subsets ▁ of ▁ equal ▁ sum " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Can ▁ not ▁ be ▁ divided ▁ into ▁ two ▁ subsets ▁ of ▁ equal ▁ sum " ) NEW_LINE DEDENT
INF = 2147483647 NEW_LINE
def printSolution ( p , n ) : NEW_LINE INDENT k = 0 NEW_LINE if p [ n ] == 1 : NEW_LINE INDENT k = 1 NEW_LINE DEDENT else : NEW_LINE INDENT k = printSolution ( p , p [ n ] - 1 ) + 1 NEW_LINE DEDENT print ( ' Line ▁ number ▁ ' , k , ' : ▁ From ▁ word ▁ no . ▁ ' , p [ n ] , ' to ▁ ' , n ) NEW_LINE return k NEW_LINE DEDENT
def solveWordWrap ( l , n , M ) : NEW_LINE
extras = [ [ 0 for i in range ( n + 1 ) ] for i in range ( n + 1 ) ] NEW_LINE
lc = [ [ 0 for i in range ( n + 1 ) ] for i in range ( n + 1 ) ] NEW_LINE
c = [ 0 for i in range ( n + 1 ) ] NEW_LINE
p = [ 0 for i in range ( n + 1 ) ] NEW_LINE
for i in range ( n + 1 ) : NEW_LINE INDENT extras [ i ] [ i ] = M - l [ i - 1 ] NEW_LINE for j in range ( i + 1 , n + 1 ) : NEW_LINE INDENT extras [ i ] [ j ] = ( extras [ i ] [ j - 1 ] - l [ j - 1 ] - 1 ) NEW_LINE DEDENT DEDENT
for i in range ( n + 1 ) : NEW_LINE INDENT for j in range ( i , n + 1 ) : NEW_LINE INDENT if extras [ i ] [ j ] < 0 : NEW_LINE INDENT lc [ i ] [ j ] = INF ; NEW_LINE DEDENT elif j == n and extras [ i ] [ j ] >= 0 : NEW_LINE INDENT lc [ i ] [ j ] = 0 NEW_LINE DEDENT else : NEW_LINE INDENT lc [ i ] [ j ] = ( extras [ i ] [ j ] * extras [ i ] [ j ] ) NEW_LINE DEDENT DEDENT DEDENT
c [ 0 ] = 0 NEW_LINE for j in range ( 1 , n + 1 ) : NEW_LINE INDENT c [ j ] = INF NEW_LINE for i in range ( 1 , j + 1 ) : NEW_LINE INDENT if ( c [ i - 1 ] != INF and lc [ i ] [ j ] != INF and ( ( c [ i - 1 ] + lc [ i ] [ j ] ) < c [ j ] ) ) : NEW_LINE INDENT c [ j ] = c [ i - 1 ] + lc [ i ] [ j ] NEW_LINE p [ j ] = i NEW_LINE DEDENT DEDENT DEDENT printSolution ( p , n ) NEW_LINE
l = [ 3 , 2 , 2 , 5 ] NEW_LINE n = len ( l ) NEW_LINE M = 6 NEW_LINE solveWordWrap ( l , n , M ) NEW_LINE
def maxDivide ( a , b ) : NEW_LINE INDENT while a % b == 0 : NEW_LINE INDENT a = a / b NEW_LINE DEDENT return a NEW_LINE DEDENT
def isUgly ( no ) : NEW_LINE INDENT no = maxDivide ( no , 2 ) NEW_LINE no = maxDivide ( no , 3 ) NEW_LINE no = maxDivide ( no , 5 ) NEW_LINE return 1 if no == 1 else 0 NEW_LINE DEDENT
def getNthUglyNo ( n ) : NEW_LINE INDENT i = 1 NEW_LINE DEDENT
count = 1 NEW_LINE
while n > count : NEW_LINE INDENT i += 1 NEW_LINE if isUgly ( i ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return i NEW_LINE
no = getNthUglyNo ( 150 ) NEW_LINE print ( "150th ▁ ugly ▁ no . ▁ is ▁ " , no ) NEW_LINE
def Sum ( freq , i , j ) : NEW_LINE INDENT s = 0 NEW_LINE for k in range ( i , j + 1 ) : NEW_LINE INDENT s += freq [ k ] NEW_LINE DEDENT return s NEW_LINE DEDENT
def optCost ( freq , i , j ) : NEW_LINE
if j < i : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if j == i : NEW_LINE INDENT return freq [ i ] NEW_LINE DEDENT
fsum = Sum ( freq , i , j ) NEW_LINE
Min = 999999999999 NEW_LINE
for r in range ( i , j + 1 ) : NEW_LINE INDENT cost = ( optCost ( freq , i , r - 1 ) + optCost ( freq , r + 1 , j ) ) NEW_LINE if cost < Min : NEW_LINE INDENT Min = cost NEW_LINE DEDENT DEDENT
return Min + fsum NEW_LINE
def optimalSearchTree ( keys , freq , n ) : NEW_LINE
return optCost ( freq , 0 , n - 1 ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT keys = [ 10 , 12 , 20 ] NEW_LINE freq = [ 34 , 8 , 50 ] NEW_LINE n = len ( keys ) NEW_LINE print ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is " , optimalSearchTree ( keys , freq , n ) ) NEW_LINE DEDENT
def sum ( freq , i , j ) : NEW_LINE INDENT s = 0 NEW_LINE for k in range ( i , j + 1 ) : NEW_LINE INDENT s += freq [ k ] NEW_LINE DEDENT return s NEW_LINE DEDENT
def optimalSearchTree ( keys , freq , n ) : NEW_LINE
cost = [ [ 0 for x in range ( n ) ] for y in range ( n ) ] NEW_LINE
for i in range ( n ) : NEW_LINE INDENT cost [ i ] [ i ] = freq [ i ] NEW_LINE DEDENT
for L in range ( 2 , n + 1 ) : NEW_LINE
for i in range ( n - L + 2 ) : NEW_LINE
j = i + L - 1 NEW_LINE if i >= n or j >= n : NEW_LINE INDENT break NEW_LINE DEDENT cost [ i ] [ j ] = INT_MAX NEW_LINE
for r in range ( i , j + 1 ) : NEW_LINE
c = 0 NEW_LINE if ( r > i ) : NEW_LINE INDENT c += cost [ i ] [ r - 1 ] NEW_LINE DEDENT if ( r < j ) : NEW_LINE INDENT c += cost [ r + 1 ] [ j ] NEW_LINE DEDENT c += sum ( freq , i , j ) NEW_LINE if ( c < cost [ i ] [ j ] ) : NEW_LINE INDENT cost [ i ] [ j ] = c NEW_LINE DEDENT return cost [ 0 ] [ n - 1 ] NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT keys = [ 10 , 12 , 20 ] NEW_LINE freq = [ 34 , 8 , 50 ] NEW_LINE n = len ( keys ) NEW_LINE print ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is " , optimalSearchTree ( keys , freq , n ) ) NEW_LINE DEDENT
def isSubsetSum ( set , n , sum ) : NEW_LINE
if ( sum == 0 ) : NEW_LINE INDENT return True NEW_LINE DEDENT if ( n == 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT
if ( set [ n - 1 ] > sum ) : NEW_LINE INDENT return isSubsetSum ( set , n - 1 , sum ) NEW_LINE DEDENT
return isSubsetSum ( set , n - 1 , sum ) or isSubsetSum ( set , n - 1 , sum - set [ n - 1 ] ) NEW_LINE
set = [ 3 , 34 , 4 , 12 , 5 , 2 ] NEW_LINE sum = 9 NEW_LINE n = len ( set ) NEW_LINE if ( isSubsetSum ( set , n , sum ) == True ) : NEW_LINE INDENT print ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ subset ▁ with ▁ given ▁ sum " ) NEW_LINE DEDENT
def isSubsetSum ( set , n , sum ) : NEW_LINE
subset = ( [ [ False for i in range ( sum + 1 ) ] for i in range ( n + 1 ) ] ) NEW_LINE
for i in range ( n + 1 ) : NEW_LINE INDENT subset [ i ] [ 0 ] = True NEW_LINE DEDENT
for i in range ( 1 , sum + 1 ) : NEW_LINE INDENT subset [ 0 ] [ i ] = False NEW_LINE DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT for j in range ( 1 , sum + 1 ) : NEW_LINE INDENT if j < set [ i - 1 ] : NEW_LINE INDENT subset [ i ] [ j ] = subset [ i - 1 ] [ j ] NEW_LINE DEDENT if j >= set [ i - 1 ] : NEW_LINE INDENT subset [ i ] [ j ] = ( subset [ i - 1 ] [ j ] or subset [ i - 1 ] [ j - set [ i - 1 ] ] ) NEW_LINE DEDENT DEDENT DEDENT
for i in range ( n + 1 ) : NEW_LINE INDENT for j in range ( sum + 1 ) : NEW_LINE INDENT print ( subset [ i ] [ j ] , end = " ▁ " ) NEW_LINE print ( ) NEW_LINE DEDENT DEDENT return subset [ n ] [ sum ] NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT set = [ 3 , 34 , 4 , 12 , 5 , 2 ] NEW_LINE sum = 9 NEW_LINE n = len ( set ) NEW_LINE if ( isSubsetSum ( set , n , sum ) == True ) : NEW_LINE INDENT print ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ subset ▁ with ▁ given ▁ sum " ) NEW_LINE DEDENT DEDENT
def countParenth ( symb , oper , n ) : NEW_LINE INDENT F = [ [ 0 for i in range ( n + 1 ) ] for i in range ( n + 1 ) ] NEW_LINE T = [ [ 0 for i in range ( n + 1 ) ] for i in range ( n + 1 ) ] NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if symb [ i ] == ' F ' : NEW_LINE INDENT F [ i ] [ i ] = 1 NEW_LINE DEDENT else : NEW_LINE INDENT F [ i ] [ i ] = 0 NEW_LINE DEDENT if symb [ i ] == ' T ' : NEW_LINE INDENT T [ i ] [ i ] = 1 NEW_LINE DEDENT else : NEW_LINE INDENT T [ i ] [ i ] = 0 NEW_LINE DEDENT DEDENT
for gap in range ( 1 , n ) : NEW_LINE INDENT i = 0 NEW_LINE for j in range ( gap , n ) : NEW_LINE INDENT T [ i ] [ j ] = F [ i ] [ j ] = 0 NEW_LINE for g in range ( gap ) : NEW_LINE DEDENT DEDENT
k = i + g NEW_LINE
tik = T [ i ] [ k ] + F [ i ] [ k ] NEW_LINE tkj = T [ k + 1 ] [ j ] + F [ k + 1 ] [ j ] NEW_LINE
if oper [ k ] == ' & ' : NEW_LINE INDENT T [ i ] [ j ] += T [ i ] [ k ] * T [ k + 1 ] [ j ] NEW_LINE F [ i ] [ j ] += ( tik * tkj - T [ i ] [ k ] * T [ k + 1 ] [ j ] ) NEW_LINE DEDENT if oper [ k ] == ' | ' : NEW_LINE INDENT F [ i ] [ j ] += F [ i ] [ k ] * F [ k + 1 ] [ j ] NEW_LINE T [ i ] [ j ] += ( tik * tkj - F [ i ] [ k ] * F [ k + 1 ] [ j ] ) NEW_LINE DEDENT if oper [ k ] == ' ^ ' : NEW_LINE INDENT T [ i ] [ j ] += ( F [ i ] [ k ] * T [ k + 1 ] [ j ] + T [ i ] [ k ] * F [ k + 1 ] [ j ] ) NEW_LINE F [ i ] [ j ] += ( T [ i ] [ k ] * T [ k + 1 ] [ j ] + F [ i ] [ k ] * F [ k + 1 ] [ j ] ) NEW_LINE DEDENT i += 1 NEW_LINE return T [ 0 ] [ n - 1 ] NEW_LINE
symbols = " TTFT " NEW_LINE operators = " | & ^ " NEW_LINE n = len ( symbols ) NEW_LINE
print ( countParenth ( symbols , operators , n ) ) NEW_LINE
def getCount ( keypad , n ) : NEW_LINE INDENT if ( keypad == None or n <= 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT if ( n == 1 ) : NEW_LINE INDENT return 10 NEW_LINE DEDENT DEDENT
row = [ 0 , 0 , - 1 , 0 , 1 ] NEW_LINE col = [ 0 , - 1 , 0 , 1 , 0 ] NEW_LINE
count = [ [ 0 ] * ( n + 1 ) ] * 10 NEW_LINE i = 0 NEW_LINE j = 0 NEW_LINE k = 0 NEW_LINE move = 0 NEW_LINE ro = 0 NEW_LINE co = 0 NEW_LINE num = 0 NEW_LINE nextNum = 0 NEW_LINE totalCount = 0 NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT count [ i ] [ 0 ] = 0 NEW_LINE count [ i ] [ 1 ] = 1 NEW_LINE DEDENT
for k in range ( 2 , n + 1 ) : NEW_LINE
for i in range ( 4 ) : NEW_LINE
for j in range ( 3 ) : NEW_LINE
if ( keypad [ i ] [ j ] != ' * ' and keypad [ i ] [ j ] != ' # ' ) : NEW_LINE
num = ord ( keypad [ i ] [ j ] ) - 48 NEW_LINE count [ num ] [ k ] = 0 NEW_LINE
for move in range ( 5 ) : NEW_LINE INDENT ro = i + row [ move ] NEW_LINE co = j + col [ move ] NEW_LINE if ( ro >= 0 and ro <= 3 and co >= 0 and co <= 2 and keypad [ ro ] [ co ] != ' * ' and keypad [ ro ] [ co ] != ' # ' ) : NEW_LINE INDENT nextNum = ord ( keypad [ ro ] [ co ] ) - 48 NEW_LINE count [ num ] [ k ] += count [ nextNum ] [ k - 1 ] NEW_LINE DEDENT DEDENT
totalCount = 0 NEW_LINE for i in range ( 10 ) : NEW_LINE INDENT totalCount += count [ i ] [ n ] NEW_LINE DEDENT return totalCount NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT keypad = [ [ '1' , '2' , '3' ] , [ '4' , '5' , '6' ] , [ '7' , '8' , '9' ] , [ ' * ' , '0' , ' # ' ] ] NEW_LINE print ( " Count ▁ for ▁ numbers ▁ of ▁ length " , 1 , " : " , getCount ( keypad , 1 ) ) NEW_LINE print ( " Count ▁ for ▁ numbers ▁ of ▁ length " , 2 , " : " , getCount ( keypad , 2 ) ) NEW_LINE print ( " Count ▁ for ▁ numbers ▁ of ▁ length " , 3 , " : " , getCount ( keypad , 3 ) ) NEW_LINE print ( " Count ▁ for ▁ numbers ▁ of ▁ length " , 4 , " : " , getCount ( keypad , 4 ) ) NEW_LINE print ( " Count ▁ for ▁ numbers ▁ of ▁ length " , 5 , " : " , getCount ( keypad , 5 ) ) NEW_LINE DEDENT
def getCount ( keypad , n ) : NEW_LINE INDENT if ( not keypad or n <= 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT if ( n == 1 ) : NEW_LINE INDENT return 10 NEW_LINE DEDENT DEDENT
odd = [ 0 ] * 10 NEW_LINE even = [ 0 ] * 10 NEW_LINE i = 0 NEW_LINE j = 0 NEW_LINE useOdd = 0 NEW_LINE totalCount = 0 NEW_LINE for i in range ( 10 ) : NEW_LINE
odd [ i ] = 1 NEW_LINE
for j in range ( 2 , n + 1 ) : NEW_LINE INDENT useOdd = 1 - useOdd NEW_LINE DEDENT
if ( useOdd == 1 ) : NEW_LINE INDENT even [ 0 ] = odd [ 0 ] + odd [ 8 ] NEW_LINE even [ 1 ] = odd [ 1 ] + odd [ 2 ] + odd [ 4 ] NEW_LINE even [ 2 ] = odd [ 2 ] + odd [ 1 ] + odd [ 3 ] + odd [ 5 ] NEW_LINE even [ 3 ] = odd [ 3 ] + odd [ 2 ] + odd [ 6 ] NEW_LINE even [ 4 ] = odd [ 4 ] + odd [ 1 ] + odd [ 5 ] + odd [ 7 ] NEW_LINE even [ 5 ] = odd [ 5 ] + odd [ 2 ] + odd [ 4 ] + odd [ 8 ] + odd [ 6 ] NEW_LINE even [ 6 ] = odd [ 6 ] + odd [ 3 ] + odd [ 5 ] + odd [ 9 ] NEW_LINE even [ 7 ] = odd [ 7 ] + odd [ 4 ] + odd [ 8 ] NEW_LINE even [ 8 ] = odd [ 8 ] + odd [ 0 ] + odd [ 5 ] + odd [ 7 ] + odd [ 9 ] NEW_LINE even [ 9 ] = odd [ 9 ] + odd [ 6 ] + odd [ 8 ] NEW_LINE DEDENT else : NEW_LINE INDENT odd [ 0 ] = even [ 0 ] + even [ 8 ] NEW_LINE odd [ 1 ] = even [ 1 ] + even [ 2 ] + even [ 4 ] NEW_LINE odd [ 2 ] = even [ 2 ] + even [ 1 ] + even [ 3 ] + even [ 5 ] NEW_LINE odd [ 3 ] = even [ 3 ] + even [ 2 ] + even [ 6 ] NEW_LINE odd [ 4 ] = even [ 4 ] + even [ 1 ] + even [ 5 ] + even [ 7 ] NEW_LINE odd [ 5 ] = even [ 5 ] + even [ 2 ] + even [ 4 ] + even [ 8 ] + even [ 6 ] NEW_LINE odd [ 6 ] = even [ 6 ] + even [ 3 ] + even [ 5 ] + even [ 9 ] NEW_LINE odd [ 7 ] = even [ 7 ] + even [ 4 ] + even [ 8 ] NEW_LINE odd [ 8 ] = even [ 8 ] + even [ 0 ] + even [ 5 ] + even [ 7 ] + even [ 9 ] NEW_LINE odd [ 9 ] = even [ 9 ] + even [ 6 ] + even [ 8 ] NEW_LINE DEDENT
totalCount = 0 NEW_LINE if ( useOdd == 1 ) : NEW_LINE INDENT for i in range ( 10 ) : NEW_LINE INDENT totalCount += even [ i ] NEW_LINE DEDENT DEDENT else : NEW_LINE INDENT for i in range ( 10 ) : NEW_LINE INDENT totalCount += odd [ i ] NEW_LINE DEDENT DEDENT return totalCount NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT keypad = [ [ '1' , '2' , '3' ] , [ '4' , '5' , '6' ] , [ '7' , '8' , '9' ] , [ ' * ' , '0' , ' # ' ] ] NEW_LINE print ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ " , 1 , " : ▁ " , getCount ( keypad , 1 ) ) NEW_LINE print ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ " , 2 , " : ▁ " , getCount ( keypad , 2 ) ) NEW_LINE print ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ " , 3 , " : ▁ " , getCount ( keypad , 3 ) ) NEW_LINE print ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ " , 4 , " : ▁ " , getCount ( keypad , 4 ) ) NEW_LINE print ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ " , 5 , " : ▁ " , getCount ( keypad , 5 ) ) NEW_LINE DEDENT
def countRec ( n , sum ) : NEW_LINE
if ( n == 0 ) : NEW_LINE INDENT return ( sum == 0 ) NEW_LINE DEDENT if ( sum == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
ans = 0 NEW_LINE
for i in range ( 0 , 10 ) : NEW_LINE INDENT if ( sum - i >= 0 ) : NEW_LINE INDENT ans = ans + countRec ( n - 1 , sum - i ) NEW_LINE DEDENT DEDENT return ans NEW_LINE
def finalCount ( n , sum ) : NEW_LINE
ans = 0 NEW_LINE
for i in range ( 1 , 10 ) : NEW_LINE INDENT if ( sum - i >= 0 ) : NEW_LINE INDENT ans = ans + countRec ( n - 1 , sum - i ) NEW_LINE DEDENT DEDENT return ans NEW_LINE
n = 2 NEW_LINE sum = 5 NEW_LINE print ( finalCount ( n , sum ) ) NEW_LINE
lookup = [ [ - 1 for i in range ( 501 ) ] for i in range ( 101 ) ] NEW_LINE
def countRec ( n , Sum ) : NEW_LINE
if ( n == 0 ) : NEW_LINE INDENT return Sum == 0 NEW_LINE DEDENT
if ( lookup [ n ] [ Sum ] != - 1 ) : NEW_LINE INDENT return lookup [ n ] [ Sum ] NEW_LINE DEDENT
ans = 0 NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT if ( Sum - i >= 0 ) : NEW_LINE INDENT ans += countRec ( n - 1 , Sum - i ) NEW_LINE DEDENT DEDENT lookup [ n ] [ Sum ] = ans NEW_LINE return lookup [ n ] [ Sum ] NEW_LINE
def finalCount ( n , Sum ) : NEW_LINE
ans = 0 NEW_LINE
for i in range ( 1 , 10 ) : NEW_LINE INDENT if ( Sum - i >= 0 ) : NEW_LINE INDENT ans += countRec ( n - 1 , Sum - i ) NEW_LINE DEDENT DEDENT return ans NEW_LINE
n , Sum = 3 , 5 NEW_LINE print ( finalCount ( n , Sum ) ) NEW_LINE
import math NEW_LINE def findCount ( n , sum ) : NEW_LINE
start = math . pow ( 10 , n - 1 ) ; NEW_LINE end = math . pow ( 10 , n ) - 1 ; NEW_LINE count = 0 ; NEW_LINE i = start ; NEW_LINE while ( i <= end ) : NEW_LINE INDENT cur = 0 ; NEW_LINE temp = i ; NEW_LINE while ( temp != 0 ) : NEW_LINE INDENT cur += temp % 10 ; NEW_LINE temp = temp // 10 ; NEW_LINE DEDENT if ( cur == sum ) : NEW_LINE INDENT count = count + 1 ; NEW_LINE i += 9 ; NEW_LINE DEDENT else : NEW_LINE INDENT i = i + 1 ; NEW_LINE DEDENT DEDENT print ( count ) ; NEW_LINE
n = 3 ; NEW_LINE sum = 5 ; NEW_LINE findCount ( n , sum ) ; NEW_LINE
def countNonDecreasing ( n ) : NEW_LINE
dp = [ [ 0 for i in range ( n + 1 ) ] for i in range ( 10 ) ] NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT dp [ i ] [ 1 ] = 1 NEW_LINE DEDENT
for digit in range ( 10 ) : NEW_LINE
for len in range ( 2 , n + 1 ) : NEW_LINE
for x in range ( digit + 1 ) : NEW_LINE INDENT dp [ digit ] [ len ] += dp [ x ] [ len - 1 ] NEW_LINE DEDENT count = 0 NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT count += dp [ i ] [ n ] NEW_LINE DEDENT return count NEW_LINE
n = 3 NEW_LINE print ( countNonDecreasing ( n ) ) NEW_LINE
def countNonDecreasing ( n ) : NEW_LINE INDENT N = 10 NEW_LINE DEDENT
count = 1 NEW_LINE for i in range ( 1 , n + 1 ) : NEW_LINE INDENT count = int ( count * ( N + i - 1 ) ) NEW_LINE count = int ( count / i ) NEW_LINE DEDENT return count NEW_LINE
n = 3 ; NEW_LINE print ( countNonDecreasing ( n ) ) NEW_LINE
def getMinSquares ( n ) : NEW_LINE
if n <= 3 : NEW_LINE INDENT return n ; NEW_LINE DEDENT
res = n NEW_LINE
for x in range ( 1 , n + 1 ) : NEW_LINE INDENT temp = x * x ; NEW_LINE if temp > n : NEW_LINE INDENT break NEW_LINE DEDENT else : NEW_LINE INDENT res = min ( res , 1 + getMinSquares ( n - temp ) ) NEW_LINE DEDENT DEDENT return res ; NEW_LINE
print ( getMinSquares ( 6 ) ) NEW_LINE
def getMinSquares ( n ) : NEW_LINE
dp = [ 0 , 1 , 2 , 3 ] NEW_LINE
for i in range ( 4 , n + 1 ) : NEW_LINE
dp . append ( i ) NEW_LINE
for x in range ( 1 , int ( ceil ( sqrt ( i ) ) ) + 1 ) : NEW_LINE INDENT temp = x * x ; NEW_LINE if temp > i : NEW_LINE INDENT break NEW_LINE DEDENT else : NEW_LINE INDENT dp [ i ] = min ( dp [ i ] , 1 + dp [ i - temp ] ) NEW_LINE DEDENT DEDENT
return dp [ n ] NEW_LINE
print ( getMinSquares ( 6 ) ) NEW_LINE
def minCoins ( coins , m , V ) : NEW_LINE
if ( V == 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
res = sys . maxsize NEW_LINE
for i in range ( 0 , m ) : NEW_LINE INDENT if ( coins [ i ] <= V ) : NEW_LINE INDENT sub_res = minCoins ( coins , m , V - coins [ i ] ) NEW_LINE DEDENT DEDENT
if ( sub_res != sys . maxsize and sub_res + 1 < res ) : NEW_LINE INDENT res = sub_res + 1 NEW_LINE DEDENT return res NEW_LINE
coins = [ 9 , 6 , 5 , 1 ] NEW_LINE m = len ( coins ) NEW_LINE V = 11 NEW_LINE print ( " Minimum ▁ coins ▁ required ▁ is " , minCoins ( coins , m , V ) ) NEW_LINE
def minCoins ( coins , m , V ) : NEW_LINE
table = [ 0 for i in range ( V + 1 ) ] NEW_LINE
table [ 0 ] = 0 NEW_LINE
for i in range ( 1 , V + 1 ) : NEW_LINE INDENT table [ i ] = sys . maxsize NEW_LINE DEDENT
for i in range ( 1 , V + 1 ) : NEW_LINE
for j in range ( m ) : NEW_LINE INDENT if ( coins [ j ] <= i ) : NEW_LINE INDENT sub_res = table [ i - coins [ j ] ] NEW_LINE if ( sub_res != sys . maxsize and sub_res + 1 < table [ i ] ) : NEW_LINE INDENT table [ i ] = sub_res + 1 NEW_LINE DEDENT DEDENT DEDENT if table [ V ] == sys . maxsize : NEW_LINE return - 1 NEW_LINE return table [ V ] NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT coins = [ 9 , 6 , 5 , 1 ] NEW_LINE m = len ( coins ) NEW_LINE V = 11 NEW_LINE print ( " Minimum ▁ coins ▁ required ▁ is ▁ " , minCoins ( coins , m , V ) ) NEW_LINE DEDENT
def superSeq ( X , Y , m , n ) : NEW_LINE INDENT if ( not m ) : NEW_LINE INDENT return n NEW_LINE DEDENT if ( not n ) : NEW_LINE INDENT return m NEW_LINE DEDENT if ( X [ m - 1 ] == Y [ n - 1 ] ) : NEW_LINE INDENT return 1 + superSeq ( X , Y , m - 1 , n - 1 ) NEW_LINE DEDENT return 1 + min ( superSeq ( X , Y , m - 1 , n ) , superSeq ( X , Y , m , n - 1 ) ) NEW_LINE DEDENT
X = " AGGTAB " NEW_LINE Y = " GXTXAYB " NEW_LINE print ( " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ % d " % superSeq ( X , Y , len ( X ) , len ( Y ) ) ) NEW_LINE
def superSeq ( X , Y , m , n ) : NEW_LINE INDENT dp = [ [ 0 ] * ( n + 2 ) for i in range ( m + 2 ) ] NEW_LINE DEDENT
for i in range ( m + 1 ) : NEW_LINE INDENT for j in range ( n + 1 ) : NEW_LINE DEDENT
if ( not i ) : NEW_LINE INDENT dp [ i ] [ j ] = j NEW_LINE DEDENT elif ( not j ) : NEW_LINE INDENT dp [ i ] [ j ] = i NEW_LINE DEDENT elif ( X [ i - 1 ] == Y [ j - 1 ] ) : NEW_LINE INDENT dp [ i ] [ j ] = 1 + dp [ i - 1 ] [ j - 1 ] NEW_LINE DEDENT else : NEW_LINE INDENT dp [ i ] [ j ] = 1 + min ( dp [ i - 1 ] [ j ] , dp [ i ] [ j - 1 ] ) NEW_LINE DEDENT return dp [ m ] [ n ] NEW_LINE
X = " AGGTAB " NEW_LINE Y = " GXTXAYB " NEW_LINE print ( " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ % d " % superSeq ( X , Y , len ( X ) , len ( Y ) ) ) NEW_LINE
def sumOfDigitsFrom1ToN ( n ) : NEW_LINE
result = 0 NEW_LINE
for x in range ( 1 , n + 1 ) : NEW_LINE INDENT result = result + sumOfDigits ( x ) NEW_LINE DEDENT return result NEW_LINE
def sumOfDigits ( x ) : NEW_LINE INDENT sum = 0 NEW_LINE while ( x != 0 ) : NEW_LINE INDENT sum = sum + x % 10 NEW_LINE x = x // 10 NEW_LINE DEDENT return sum NEW_LINE DEDENT
n = 328 NEW_LINE print ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from ▁ 1 ▁ to " , n , " is " , sumOfDigitsFrom1ToN ( n ) ) NEW_LINE
def sumOfDigitsFrom1ToN ( n ) : NEW_LINE
if ( n < 10 ) : NEW_LINE INDENT return ( n * ( n + 1 ) / 2 ) NEW_LINE DEDENT
d = ( int ) ( math . log10 ( n ) ) NEW_LINE
a = [ 0 ] * ( d + 1 ) NEW_LINE a [ 0 ] = 0 NEW_LINE a [ 1 ] = 45 NEW_LINE for i in range ( 2 , d + 1 ) : NEW_LINE INDENT a [ i ] = a [ i - 1 ] * 10 + 45 * ( int ) ( math . ceil ( math . pow ( 10 , i - 1 ) ) ) NEW_LINE DEDENT
p = ( int ) ( math . ceil ( math . pow ( 10 , d ) ) ) NEW_LINE
msd = n // p NEW_LINE
return ( int ) ( msd * a [ d ] + ( msd * ( msd - 1 ) // 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToN ( n % p ) ) NEW_LINE
n = 328 NEW_LINE print ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from ▁ 1 ▁ to " , n , " is " , sumOfDigitsFrom1ToN ( n ) ) NEW_LINE
def sumOfDigitsFrom1ToNUtil ( n , a ) : NEW_LINE INDENT if ( n < 10 ) : NEW_LINE INDENT return ( n * ( n + 1 ) ) // 2 NEW_LINE DEDENT d = int ( math . log ( n , 10 ) ) NEW_LINE p = int ( math . ceil ( pow ( 10 , d ) ) ) NEW_LINE msd = n // p NEW_LINE return ( msd * a [ d ] + ( msd * ( msd - 1 ) // 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToNUtil ( n % p , a ) ) NEW_LINE DEDENT def sumOfDigitsFrom1ToN ( n ) : NEW_LINE INDENT d = int ( math . log ( n , 10 ) ) NEW_LINE a = [ 0 ] * ( d + 1 ) NEW_LINE a [ 0 ] = 0 NEW_LINE a [ 1 ] = 45 NEW_LINE for i in range ( 2 , d + 1 ) : NEW_LINE INDENT a [ i ] = a [ i - 1 ] * 10 + 45 * int ( math . ceil ( pow ( 10 , i - 1 ) ) ) NEW_LINE DEDENT return sumOfDigitsFrom1ToNUtil ( n , a ) NEW_LINE DEDENT
n = 328 NEW_LINE print ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from ▁ 1 ▁ to " , n , " is " , sumOfDigitsFrom1ToN ( n ) ) NEW_LINE
def countWays ( N ) : NEW_LINE
if ( N == 1 ) : NEW_LINE
return 4 NEW_LINE
countB = 1 NEW_LINE countS = 1 NEW_LINE
for i in range ( 2 , N + 1 ) : NEW_LINE INDENT prev_countB = countB NEW_LINE prev_countS = countS NEW_LINE countS = prev_countB + prev_countS NEW_LINE countB = prev_countS NEW_LINE DEDENT
result = countS + countB NEW_LINE
return ( result * result ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT N = 3 NEW_LINE print ( " Count ▁ of ▁ ways ▁ for ▁ " , N , " ▁ sections ▁ is ▁ " , countWays ( N ) ) NEW_LINE DEDENT
def findoptimal ( N ) : NEW_LINE
if ( N <= 6 ) : NEW_LINE INDENT return N NEW_LINE DEDENT
screen = [ 0 ] * N NEW_LINE
for n in range ( 1 , 7 ) : NEW_LINE INDENT screen [ n - 1 ] = n NEW_LINE DEDENT
for n in range ( 7 , N + 1 ) : NEW_LINE
screen [ n - 1 ] = 0 NEW_LINE
for b in range ( n - 3 , 0 , - 1 ) : NEW_LINE
curr = ( n - b - 1 ) * screen [ b - 1 ] NEW_LINE if ( curr > screen [ n - 1 ] ) : NEW_LINE INDENT screen [ n - 1 ] = curr NEW_LINE DEDENT return screen [ N - 1 ] NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE
for N in range ( 1 , 21 ) : NEW_LINE INDENT print ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with ▁ " , N , " ▁ keystrokes ▁ is ▁ " , findoptimal ( N ) ) NEW_LINE DEDENT
def findoptimal ( N ) : NEW_LINE
if ( N <= 6 ) : NEW_LINE INDENT return N NEW_LINE DEDENT
screen = [ 0 ] * N NEW_LINE
for n in range ( 1 , 7 ) : NEW_LINE INDENT screen [ n - 1 ] = n NEW_LINE DEDENT
for n in range ( 7 , N + 1 ) : NEW_LINE
screen [ n - 1 ] = max ( 2 * screen [ n - 4 ] , max ( 3 * screen [ n - 5 ] , 4 * screen [ n - 6 ] ) ) ; NEW_LINE return screen [ N - 1 ] NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE
for N in range ( 1 , 21 ) : NEW_LINE INDENT print ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with ▁ " , N , " ▁ keystrokes ▁ is ▁ " , findoptimal ( N ) ) NEW_LINE DEDENT
def power ( x , y ) : NEW_LINE INDENT temp = 0 NEW_LINE if ( y == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT temp = power ( x , int ( y / 2 ) ) NEW_LINE if ( y % 2 == 0 ) : NEW_LINE INDENT return temp * temp ; NEW_LINE DEDENT else : NEW_LINE INDENT return x * temp * temp ; NEW_LINE DEDENT DEDENT
def power ( x , y ) : NEW_LINE
if ( y == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
if ( x == 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
return x * power ( x , y - 1 ) NEW_LINE
x = 2 NEW_LINE y = 3 NEW_LINE print ( power ( x , y ) ) NEW_LINE
def area ( x1 , y1 , x2 , y2 , x3 , y3 ) : NEW_LINE INDENT return abs ( ( x1 * ( y2 - y3 ) + x2 * ( y3 - y1 ) + x3 * ( y1 - y2 ) ) / 2.0 ) NEW_LINE DEDENT
def isInside ( x1 , y1 , x2 , y2 , x3 , y3 , x , y ) : NEW_LINE
A = area ( x1 , y1 , x2 , y2 , x3 , y3 ) NEW_LINE
A1 = area ( x , y , x2 , y2 , x3 , y3 ) NEW_LINE
A2 = area ( x1 , y1 , x , y , x3 , y3 ) NEW_LINE
A3 = area ( x1 , y1 , x2 , y2 , x , y ) NEW_LINE
if ( A == A1 + A2 + A3 ) : NEW_LINE INDENT return True NEW_LINE DEDENT else : NEW_LINE INDENT return False NEW_LINE DEDENT
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) : NEW_LINE INDENT print ( ' Inside ' ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( ' Not ▁ Inside ' ) NEW_LINE DEDENT
def printPost ( inn , pre , inStrt , inEnd ) : NEW_LINE INDENT global preIndex , hm NEW_LINE if ( inStrt > inEnd ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
inIndex = hm [ pre [ preIndex ] ] NEW_LINE preIndex += 1 NEW_LINE
printPost ( inn , pre , inStrt , inIndex - 1 ) NEW_LINE
printPost ( inn , pre , inIndex + 1 , inEnd ) NEW_LINE
print ( inn [ inIndex ] , end = " ▁ " ) NEW_LINE def printPostMain ( inn , pre , n ) : NEW_LINE for i in range ( n ) : NEW_LINE INDENT hm [ inn [ i ] ] = i NEW_LINE DEDENT printPost ( inn , pre , 0 , n - 1 ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT hm = { } NEW_LINE preIndex = 0 NEW_LINE inn = [ 4 , 2 , 5 , 1 , 3 , 6 ] NEW_LINE pre = [ 1 , 2 , 4 , 5 , 3 , 6 ] NEW_LINE n = len ( pre ) NEW_LINE printPostMain ( inn , pre , n ) NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . key = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def maxDiffUtil ( t , res ) : NEW_LINE
if ( t == None ) : NEW_LINE INDENT return _MAX , res NEW_LINE DEDENT
if ( t . left == None and t . right == None ) : NEW_LINE INDENT return t . key , res NEW_LINE DEDENT
a , res = maxDiffUtil ( t . left , res ) NEW_LINE b , res = maxDiffUtil ( t . right , res ) NEW_LINE val = min ( a , b ) NEW_LINE
res = max ( res , t . key - val ) NEW_LINE
return min ( val , t . key ) , res NEW_LINE
def maxDiff ( root ) : NEW_LINE
res = _MIN NEW_LINE x , res = maxDiffUtil ( root , res ) NEW_LINE return res NEW_LINE
def inorder ( root ) : NEW_LINE INDENT if ( root ) : NEW_LINE INDENT inorder ( root . left ) NEW_LINE prf ( " % d ▁ " , root . key ) NEW_LINE inorder ( root . right ) NEW_LINE DEDENT DEDENT
root = newNode ( 8 ) NEW_LINE root . left = newNode ( 3 ) NEW_LINE root . left . left = newNode ( 1 ) NEW_LINE root . left . right = newNode ( 6 ) NEW_LINE root . left . right . left = newNode ( 4 ) NEW_LINE root . left . right . right = newNode ( 7 ) NEW_LINE root . right = newNode ( 10 ) NEW_LINE root . right . right = newNode ( 14 ) NEW_LINE root . right . right . left = newNode ( 13 ) NEW_LINE print ( " Maximum ▁ difference ▁ between ▁ a ▁ node ▁ and " , " its ▁ ancestor ▁ is ▁ : " , maxDiff ( root ) ) NEW_LINE
def getAvg ( prev_avg , x , n ) : NEW_LINE INDENT return ( ( prev_avg * n + x ) / ( n + 1 ) ) ; NEW_LINE DEDENT
def streamAvg ( arr , n ) : NEW_LINE INDENT avg = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT avg = getAvg ( avg , arr [ i ] , i ) ; NEW_LINE print ( " Average ▁ of ▁ " , i + 1 , " ▁ numbers ▁ is ▁ " , avg ) ; NEW_LINE DEDENT DEDENT
arr = [ 10 , 20 , 30 , 40 , 50 , 60 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE streamAvg ( arr , n ) ; NEW_LINE
def SieveOfEratosthenes ( n ) : NEW_LINE
prime = [ True for i in range ( n + 1 ) ] NEW_LINE p = 2 NEW_LINE while ( p * p <= n ) : NEW_LINE
if ( prime [ p ] == True ) : NEW_LINE
for i in range ( p * p , n + 1 , p ) : NEW_LINE INDENT prime [ i ] = False NEW_LINE DEDENT p += 1 NEW_LINE
for p in range ( 2 , n + 1 ) : NEW_LINE INDENT if prime [ p ] : NEW_LINE INDENT print p , NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = 30 NEW_LINE print " Following ▁ are ▁ the ▁ prime ▁ numbers ▁ smaller " , NEW_LINE print " than ▁ or ▁ equal ▁ to " , n NEW_LINE SieveOfEratosthenes ( n ) NEW_LINE DEDENT
def maximumNumberDistinctPrimeRange ( m , n ) : NEW_LINE
factorCount = [ 0 ] * ( n + 1 ) NEW_LINE
prime = [ False ] * ( n + 1 ) NEW_LINE
for i in range ( n + 1 ) : NEW_LINE INDENT factorCount [ i ] = 0 NEW_LINE DEDENT
prime [ i ] = True NEW_LINE for i in range ( 2 , n + 1 ) : NEW_LINE
if ( prime [ i ] == True ) : NEW_LINE
factorCount [ i ] = 1 NEW_LINE
for j in range ( i * 2 , n + 1 , i ) : NEW_LINE
factorCount [ j ] += 1 NEW_LINE
prime [ j ] = False NEW_LINE
max = factorCount [ m ] NEW_LINE num = m NEW_LINE
for i in range ( m , n + 1 ) : NEW_LINE
if ( factorCount [ i ] > max ) : NEW_LINE INDENT max = factorCount [ i ] NEW_LINE num = i NEW_LINE DEDENT return num NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT m = 4 NEW_LINE n = 6 NEW_LINE DEDENT
print ( maximumNumberDistinctPrimeRange ( m , n ) ) NEW_LINE
def binomialCoeff ( n , k ) : NEW_LINE INDENT res = 1 NEW_LINE if ( k > n - k ) : NEW_LINE INDENT k = n - k NEW_LINE DEDENT for i in range ( 0 , k ) : NEW_LINE INDENT res = res * ( n - i ) NEW_LINE res = res // ( i + 1 ) NEW_LINE DEDENT return res NEW_LINE DEDENT
def printPascal ( n ) : NEW_LINE
for line in range ( 0 , n ) : NEW_LINE
for i in range ( 0 , line + 1 ) : NEW_LINE INDENT print ( binomialCoeff ( line , i ) , " ▁ " , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE
n = 7 NEW_LINE printPascal ( n ) NEW_LINE
def findCeil ( arr , r , l , h ) : NEW_LINE INDENT while ( l < h ) : NEW_LINE DEDENT
mid = l + ( ( h - l ) >> 1 ) ; NEW_LINE if r > arr [ mid ] : NEW_LINE INDENT l = mid + 1 NEW_LINE DEDENT else : NEW_LINE INDENT h = mid NEW_LINE DEDENT if arr [ l ] >= r : NEW_LINE return l NEW_LINE else : NEW_LINE return - 1 NEW_LINE
def myRand ( arr , freq , n ) : NEW_LINE
prefix = [ 0 ] * n NEW_LINE prefix [ 0 ] = freq [ 0 ] NEW_LINE for i in range ( n ) : NEW_LINE INDENT prefix [ i ] = prefix [ i - 1 ] + freq [ i ] NEW_LINE DEDENT
r = random . randint ( 0 , prefix [ n - 1 ] ) + 1 NEW_LINE
indexc = findCeil ( prefix , r , 0 , n - 1 ) NEW_LINE return arr [ indexc ] NEW_LINE
arr = [ 1 , 2 , 3 , 4 ] NEW_LINE freq = [ 10 , 5 , 20 , 100 ] NEW_LINE n = len ( arr ) NEW_LINE
for i in range ( 5 ) : NEW_LINE INDENT print ( myRand ( arr , freq , n ) ) NEW_LINE DEDENT
def isPerfectSquare ( x ) : NEW_LINE INDENT s = int ( math . sqrt ( x ) ) NEW_LINE return s * s == x NEW_LINE DEDENT
def isFibonacci ( n ) : NEW_LINE
return isPerfectSquare ( 5 * n * n + 4 ) or isPerfectSquare ( 5 * n * n - 4 ) NEW_LINE
for i in range ( 1 , 11 ) : NEW_LINE INDENT if ( isFibonacci ( i ) == True ) : NEW_LINE INDENT print i , " is ▁ a ▁ Fibonacci ▁ Number " NEW_LINE DEDENT else : NEW_LINE INDENT print i , " is ▁ a ▁ not ▁ Fibonacci ▁ Number ▁ " NEW_LINE DEDENT DEDENT
def findTrailingZeros ( n ) : NEW_LINE
count = 0 NEW_LINE
while ( n >= 5 ) : NEW_LINE INDENT n //= 5 NEW_LINE count += n NEW_LINE DEDENT return count NEW_LINE
n = 100 NEW_LINE print ( " Count ▁ of ▁ trailing ▁ 0s ▁ " + " in ▁ 100 ! ▁ is " , findTrailingZeros ( n ) ) NEW_LINE
def catalan ( n ) : NEW_LINE
if n <= 1 : NEW_LINE INDENT return 1 NEW_LINE DEDENT
res = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT res += catalan ( i ) * catalan ( n - i - 1 ) NEW_LINE DEDENT return res NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT print catalan ( i ) , NEW_LINE DEDENT
def catalan ( n ) : NEW_LINE INDENT if ( n == 0 or n == 1 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT DEDENT
catalan = [ 0 ] * ( n + 1 ) NEW_LINE
catalan [ 0 ] = 1 NEW_LINE catalan [ 1 ] = 1 NEW_LINE
for i in range ( 2 , n + 1 ) : NEW_LINE INDENT for j in range ( i ) : NEW_LINE INDENT catalan [ i ] += catalan [ j ] * catalan [ i - j - 1 ] NEW_LINE DEDENT DEDENT
return catalan [ n ] NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT print ( catalan ( i ) , end = " ▁ " ) NEW_LINE DEDENT
def binomialCoefficient ( n , k ) : NEW_LINE INDENT res = 1 NEW_LINE DEDENT
if ( k > n - k ) : NEW_LINE INDENT k = n - k NEW_LINE DEDENT
for i in range ( k ) : NEW_LINE INDENT res = res * ( n - i ) NEW_LINE res = res / ( i + 1 ) NEW_LINE DEDENT return res NEW_LINE
def catalan ( n ) : NEW_LINE
c = binomialCoefficient ( 2 * n , n ) NEW_LINE
return c / ( n + 1 ) NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT print ( catalan ( i ) , end = " ▁ " ) NEW_LINE DEDENT
def catalan ( n ) : NEW_LINE INDENT cat_ = 1 NEW_LINE DEDENT
print ( cat_ , " ▁ " , end = ' ' ) NEW_LINE
for i in range ( 1 , n ) : NEW_LINE
cat_ *= ( 4 * i - 2 ) ; NEW_LINE cat_ //= ( i + 1 ) ; NEW_LINE print ( cat_ , " ▁ " , end = ' ' ) NEW_LINE
n = 5 NEW_LINE
catalan ( n ) NEW_LINE
def printString ( n ) : NEW_LINE INDENT arr = [ 0 ] * 10000 NEW_LINE i = 0 NEW_LINE DEDENT
while ( n > 0 ) : NEW_LINE INDENT arr [ i ] = n % 26 NEW_LINE n = int ( n // 26 ) NEW_LINE i += 1 NEW_LINE DEDENT
for j in range ( 0 , i - 1 ) : NEW_LINE INDENT if ( arr [ j ] <= 0 ) : NEW_LINE INDENT arr [ j ] += 26 NEW_LINE arr [ j + 1 ] = arr [ j + 1 ] - 1 NEW_LINE DEDENT DEDENT for j in range ( i , - 1 , - 1 ) : NEW_LINE INDENT if ( arr [ j ] > 0 ) : NEW_LINE INDENT print ( chr ( ord ( ' A ' ) + ( arr [ j ] - 1 ) ) , end = " " ) ; NEW_LINE DEDENT DEDENT print ( ) ; NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT printString ( 26 ) ; NEW_LINE printString ( 51 ) ; NEW_LINE printString ( 52 ) ; NEW_LINE printString ( 80 ) ; NEW_LINE printString ( 676 ) ; NEW_LINE printString ( 702 ) ; NEW_LINE printString ( 705 ) ; NEW_LINE DEDENT
def getInvCount ( arr ) : NEW_LINE INDENT inv_count = 0 NEW_LINE for i in range ( 0 , 2 ) : NEW_LINE INDENT for j in range ( i + 1 , 3 ) : NEW_LINE DEDENT DEDENT
if ( arr [ j ] [ i ] > 0 and arr [ j ] [ i ] > arr [ i ] [ j ] ) : NEW_LINE INDENT inv_count += 1 NEW_LINE DEDENT return inv_count NEW_LINE
def isSolvable ( puzzle ) : NEW_LINE
invCount = getInvCount ( puzzle ) NEW_LINE
return ( invCount % 2 == 0 ) NEW_LINE
puzzle = [ [ 1 , 8 , 2 ] , [ 0 , 4 , 3 ] , [ 7 , 6 , 5 ] ] NEW_LINE if ( isSolvable ( puzzle ) ) : NEW_LINE INDENT print ( " Solvable " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Not ▁ Solvable " ) NEW_LINE DEDENT
def find ( p ) : NEW_LINE INDENT return math . ceil ( math . sqrt ( 2 * 365 * math . log ( 1 / ( 1 - p ) ) ) ) ; NEW_LINE DEDENT
print ( find ( 0.70 ) ) NEW_LINE
def countSolutions ( n ) : NEW_LINE INDENT res = 0 NEW_LINE x = 0 NEW_LINE while ( x * x < n ) : NEW_LINE INDENT y = 0 NEW_LINE while ( x * x + y * y < n ) : NEW_LINE INDENT res = res + 1 NEW_LINE y = y + 1 NEW_LINE DEDENT x = x + 1 NEW_LINE DEDENT return res NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT print ( " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " , countSolutions ( 6 ) ) NEW_LINE DEDENT
def countSolutions ( n ) : NEW_LINE INDENT x = 0 NEW_LINE res = 0 NEW_LINE yCount = 0 NEW_LINE DEDENT
while ( yCount * yCount < n ) : NEW_LINE INDENT yCount = yCount + 1 NEW_LINE DEDENT
while ( yCount != 0 ) : NEW_LINE
res = res + yCount NEW_LINE
x = x + 1 NEW_LINE
while ( yCount != 0 and ( x * x + ( yCount - 1 ) * ( yCount - 1 ) >= n ) ) : NEW_LINE INDENT yCount = yCount - 1 NEW_LINE DEDENT return res NEW_LINE
print ( " Total ▁ Number ▁ of ▁ distinct ▁ " , , countSolutions ( 6 ) )
MAX_ITER = 1000000 NEW_LINE
def func ( x ) : NEW_LINE INDENT return ( x * x * x - x * x + 2 ) NEW_LINE DEDENT
def regulaFalsi ( a , b ) : NEW_LINE INDENT if func ( a ) * func ( b ) >= 0 : NEW_LINE INDENT print ( " You ▁ have ▁ not ▁ assumed ▁ right ▁ a ▁ and ▁ b " ) NEW_LINE return - 1 NEW_LINE DEDENT DEDENT
c = a NEW_LINE for i in range ( MAX_ITER ) : NEW_LINE
c = ( a * func ( b ) - b * func ( a ) ) / ( func ( b ) - func ( a ) ) NEW_LINE
if func ( c ) == 0 : NEW_LINE INDENT break NEW_LINE DEDENT
elif func ( c ) * func ( a ) < 0 : NEW_LINE INDENT b = c NEW_LINE DEDENT else : NEW_LINE INDENT a = c NEW_LINE DEDENT print ( " The ▁ value ▁ of ▁ root ▁ is ▁ : ▁ " , ' % .4f ' % c ) NEW_LINE
a = - 200 NEW_LINE b = 300 NEW_LINE regulaFalsi ( a , b ) NEW_LINE
def func ( x ) : NEW_LINE INDENT return x * x * x - x * x + 2 NEW_LINE DEDENT
def derivFunc ( x ) : NEW_LINE INDENT return 3 * x * x - 2 * x NEW_LINE DEDENT
def newtonRaphson ( x ) : NEW_LINE INDENT h = func ( x ) / derivFunc ( x ) NEW_LINE while abs ( h ) >= 0.0001 : NEW_LINE INDENT h = func ( x ) / derivFunc ( x ) NEW_LINE DEDENT DEDENT
x = x - h NEW_LINE print ( " The ▁ value ▁ of ▁ the ▁ root ▁ is ▁ : ▁ " , " % .4f " % x ) NEW_LINE
x0 = - 20 NEW_LINE newtonRaphson ( x0 ) NEW_LINE
def oppositeSigns ( x , y ) : NEW_LINE INDENT return ( ( x ^ y ) < 0 ) ; NEW_LINE DEDENT
x = 100 NEW_LINE y = 1 NEW_LINE if ( oppositeSigns ( x , y ) == True ) : NEW_LINE INDENT print " Signs ▁ are ▁ opposite " NEW_LINE DEDENT else : NEW_LINE INDENT print " Signs ▁ are ▁ not ▁ opposite " NEW_LINE DEDENT
def countSetBits ( n ) : NEW_LINE
bitCount = 0 NEW_LINE for i in range ( 1 , n + 1 ) : NEW_LINE INDENT bitCount += countSetBitsUtil ( i ) NEW_LINE DEDENT return bitCount NEW_LINE
def countSetBitsUtil ( x ) : NEW_LINE INDENT if ( x <= 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT return ( 0 if int ( x % 2 ) == 0 else 1 ) + countSetBitsUtil ( int ( x / 2 ) ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = 4 NEW_LINE print ( " Total ▁ set ▁ bit ▁ count ▁ is " , countSetBits ( n ) ) NEW_LINE DEDENT
def countSetBits ( n ) : NEW_LINE INDENT i = 0 NEW_LINE DEDENT
ans = 0 NEW_LINE
while ( ( 1 << i ) <= n ) : NEW_LINE
k = 0 NEW_LINE
change = 1 << i NEW_LINE
for j in range ( 0 , n + 1 ) : NEW_LINE INDENT ans += k NEW_LINE if change == 1 : NEW_LINE DEDENT
k = not k NEW_LINE
change = 1 << i NEW_LINE else : NEW_LINE change -= 1 NEW_LINE
i += 1 NEW_LINE return ans NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 17 NEW_LINE print ( countSetBits ( n ) ) NEW_LINE DEDENT
def getSetBitsFromOneToN ( N ) : NEW_LINE INDENT two = 2 NEW_LINE ans = 0 NEW_LINE n = N NEW_LINE while ( n != 0 ) : NEW_LINE INDENT ans += int ( N / two ) * ( two >> 1 ) NEW_LINE if ( ( N & ( two - 1 ) ) > ( two >> 1 ) - 1 ) : NEW_LINE INDENT ans += ( N & ( two - 1 ) ) - ( two >> 1 ) + 1 NEW_LINE DEDENT two <<= 1 ; NEW_LINE n >>= 1 ; NEW_LINE DEDENT return ans NEW_LINE DEDENT
def swapBits ( num , p1 , p2 , n ) : NEW_LINE INDENT shift1 = 0 NEW_LINE shift2 = 0 NEW_LINE value1 = 0 NEW_LINE value2 = 0 NEW_LINE while ( n > 0 ) : NEW_LINE DEDENT
shift1 = 1 << p1 NEW_LINE
shift2 = 1 << p2 NEW_LINE
value1 = ( ( num & shift1 ) ) NEW_LINE value2 = ( ( num & shift2 ) ) NEW_LINE
if ( ( value1 == 0 and value2 != 0 ) or ( value2 == 0 and value1 != 0 ) ) : NEW_LINE
if ( value1 != 0 ) : NEW_LINE
num = num & ( ~ shift1 ) NEW_LINE
num = num | shift2 NEW_LINE
else : NEW_LINE
num = num & ( ~ shift2 ) NEW_LINE
num = num | shift1 NEW_LINE p1 += 1 NEW_LINE p2 += 1 NEW_LINE n -= 1 NEW_LINE
return num NEW_LINE
res = swapBits ( 28 , 0 , 3 , 2 ) NEW_LINE print ( " Result ▁ = " , res ) NEW_LINE
def Add ( x , y ) : NEW_LINE INDENT if ( y == 0 ) : NEW_LINE INDENT return x NEW_LINE DEDENT else : NEW_LINE INDENT return Add ( x ^ y , ( x & y ) << 1 ) NEW_LINE DEDENT DEDENT
CHAR_BIT = 8 NEW_LINE
def min ( x , y ) : NEW_LINE INDENT return y + ( ( x - y ) & ( ( x - y ) >> ( 32 * CHAR_BIT - 1 ) ) ) NEW_LINE DEDENT
def smallest ( x , y , z ) : NEW_LINE INDENT return min ( x , min ( y , z ) ) NEW_LINE DEDENT
x = 12 NEW_LINE y = 15 NEW_LINE z = 5 NEW_LINE print ( " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ " , smallest ( x , y , z ) ) NEW_LINE
def smallest ( x , y , z ) : NEW_LINE
if ( not ( y / x ) ) : NEW_LINE INDENT return y if ( not ( y / z ) ) else z NEW_LINE DEDENT return x if ( not ( x / z ) ) else z NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT x = 78 NEW_LINE y = 88 NEW_LINE z = 68 NEW_LINE print ( " Minimum ▁ of ▁ 3 ▁ numbers ▁ is " , smallest ( x , y , z ) ) NEW_LINE DEDENT
def changeToZero ( a ) : NEW_LINE INDENT a [ a [ 1 ] ] = a [ not a [ 1 ] ] NEW_LINE return a NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 1 , 0 ] NEW_LINE a = changeToZero ( a ) ; NEW_LINE print ( " ▁ arr [ 0 ] ▁ = ▁ " + str ( a [ 0 ] ) ) NEW_LINE print ( " ▁ arr [ 1 ] ▁ = ▁ " + str ( a [ 1 ] ) ) NEW_LINE DEDENT
def snoob ( x ) : NEW_LINE INDENT next = 0 NEW_LINE if ( x ) : NEW_LINE DEDENT
rightOne = x & - ( x ) NEW_LINE
nextHigherOneBit = x + int ( rightOne ) NEW_LINE
rightOnesPattern = x ^ int ( nextHigherOneBit ) NEW_LINE
rightOnesPattern = ( int ( rightOnesPattern ) / int ( rightOne ) ) NEW_LINE
rightOnesPattern = int ( rightOnesPattern ) >> 2 NEW_LINE
next = nextHigherOneBit | rightOnesPattern NEW_LINE return next NEW_LINE
x = 156 NEW_LINE print ( " Next ▁ higher ▁ number ▁ with ▁ " + " same ▁ number ▁ of ▁ set ▁ bits ▁ is " , snoob ( x ) ) NEW_LINE
def multiplyWith3Point5 ( x ) : NEW_LINE INDENT return ( x << 1 ) + x + ( x >> 1 ) NEW_LINE DEDENT
x = 4 NEW_LINE print ( multiplyWith3Point5 ( x ) ) NEW_LINE
def isPowerOfFour ( n ) : NEW_LINE INDENT return ( n != 0 and ( ( n & ( n - 1 ) ) == 0 ) and not ( n & 0xAAAAAAAA ) ) ; NEW_LINE DEDENT
test_no = 64 ; NEW_LINE if ( isPowerOfFour ( test_no ) ) : NEW_LINE INDENT print ( test_no , " is ▁ a ▁ power ▁ of ▁ 4" ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( test_no , " is ▁ not ▁ a ▁ power ▁ of ▁ 4" ) ; NEW_LINE DEDENT
import math NEW_LINE def logn ( n , r ) : NEW_LINE INDENT return math . log ( n ) / math . log ( r ) NEW_LINE DEDENT def isPowerOfFour ( n ) : NEW_LINE
if ( n == 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT return ( math . floor ( logn ( n , 4 ) ) == math . ceil ( logn ( n , 4 ) ) ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT test_no = 64 NEW_LINE if ( isPowerOfFour ( test_no ) ) : NEW_LINE INDENT print ( test_no , " ▁ is ▁ a ▁ power ▁ of ▁ 4" ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( test_no , " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ) NEW_LINE DEDENT DEDENT
INT_MIN = - 2 ** 31 NEW_LINE INT_MAX = 2 ** 31 NEW_LINE
def findPostOrderUtil ( pre , n , minval , maxval , preIndex ) : NEW_LINE
if ( preIndex [ 0 ] == n ) : NEW_LINE INDENT return NEW_LINE DEDENT
if ( pre [ preIndex [ 0 ] ] < minval or pre [ preIndex [ 0 ] ] > maxval ) : NEW_LINE INDENT return NEW_LINE DEDENT
val = pre [ preIndex [ 0 ] ] NEW_LINE preIndex [ 0 ] += 1 NEW_LINE
findPostOrderUtil ( pre , n , minval , val , preIndex ) NEW_LINE
findPostOrderUtil ( pre , n , val , maxval , preIndex ) NEW_LINE print ( val , end = " ▁ " ) NEW_LINE
def findPostOrder ( pre , n ) : NEW_LINE
preIndex = [ 0 ] NEW_LINE findPostOrderUtil ( pre , n , INT_MIN , INT_MAX , preIndex ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT pre = [ 40 , 30 , 35 , 80 , 100 ] NEW_LINE n = len ( pre ) NEW_LINE DEDENT
findPostOrder ( pre , n ) NEW_LINE
import math NEW_LINE def isPowerOfFour ( n ) : NEW_LINE INDENT return ( n > 0 and 4 ** int ( math . log ( n , 4 ) ) == n ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT test_no = 64 NEW_LINE if ( isPowerOfFour ( test_no ) ) : NEW_LINE INDENT print ( test_no , " ▁ is ▁ a ▁ power ▁ of ▁ 4" ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( test_no , " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ) NEW_LINE DEDENT DEDENT
def getModulo ( n , d ) : NEW_LINE INDENT return ( n & ( d - 1 ) ) NEW_LINE DEDENT
n = 6 NEW_LINE
d = 4 NEW_LINE print ( n , " moduo " , d , " is " , getModulo ( n , d ) ) NEW_LINE
import sys ; NEW_LINE CHAR_BIT = 8 ; NEW_LINE INT_BIT = sys . getsizeof ( int ( ) ) ; NEW_LINE
def Min ( x , y ) : NEW_LINE INDENT return y + ( ( x - y ) & ( ( x - y ) >> ( INT_BIT * CHAR_BIT - 1 ) ) ) ; NEW_LINE DEDENT
def Max ( x , y ) : NEW_LINE INDENT return x - ( ( x - y ) & ( ( x - y ) >> ( INT_BIT * CHAR_BIT - 1 ) ) ) ; NEW_LINE DEDENT
x = 15 ; NEW_LINE y = 6 ; NEW_LINE print ( " Minimum ▁ of " , x , " and " , y , " is " , Min ( x , y ) ) ; NEW_LINE print ( " Maximum ▁ of " , x , " and " , y , " is " , Max ( x , y ) ) ; NEW_LINE
def absbit32 ( x , y ) : NEW_LINE INDENT sub = x - y NEW_LINE mask = ( sub >> 31 ) NEW_LINE return ( sub ^ mask ) - mask NEW_LINE DEDENT
def max ( x , y ) : NEW_LINE INDENT abs = absbit32 ( x , y ) NEW_LINE return ( x + y + abs ) // 2 NEW_LINE DEDENT
def min ( x , y ) : NEW_LINE INDENT abs = absbit32 ( x , y ) NEW_LINE return ( x + y - abs ) // 2 NEW_LINE DEDENT
print ( max ( 2 , 3 ) ) NEW_LINE print ( max ( 2 , - 3 ) ) NEW_LINE print ( max ( - 2 , - 3 ) ) NEW_LINE print ( min ( 2 , 3 ) ) NEW_LINE print ( min ( 2 , - 3 ) ) NEW_LINE print ( min ( - 2 , - 3 ) ) NEW_LINE
def UniqueNumbers2 ( arr , n ) : NEW_LINE INDENT sums = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE DEDENT
sums = ( sums ^ arr [ i ] ) NEW_LINE
INDENT sums = ( sums & - sums ) NEW_LINE DEDENT
INDENT sum1 = 0 NEW_LINE sum2 = 0 NEW_LINE DEDENT
INDENT for i in range ( 0 , len ( arr ) ) : NEW_LINE DEDENT
if ( arr [ i ] & sums ) > 0 : NEW_LINE
sum1 = ( sum1 ^ arr [ i ] ) NEW_LINE else : NEW_LINE
sum2 = ( sum2 ^ arr [ i ] ) NEW_LINE
INDENT print ( " The ▁ non - repeating ▁ elements ▁ are ▁ " , sum1 , " ▁ and ▁ " , sum2 ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 2 , 3 , 7 , 9 , 11 , 2 , 3 , 11 ] NEW_LINE n = len ( arr ) NEW_LINE UniqueNumbers2 ( arr , n ) NEW_LINE DEDENT
def getOddOccurrence ( arr , arr_size ) : NEW_LINE INDENT for i in range ( 0 , arr_size ) : NEW_LINE INDENT count = 0 NEW_LINE for j in range ( 0 , arr_size ) : NEW_LINE INDENT if arr [ i ] == arr [ j ] : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT if ( count % 2 != 0 ) : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT
arr = [ 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE
print ( getOddOccurrence ( arr , n ) ) NEW_LINE
def getOddOccurrence ( arr , size ) : NEW_LINE INDENT Hash = dict ( ) NEW_LINE DEDENT
for i in range ( size ) : NEW_LINE INDENT Hash [ arr [ i ] ] = Hash . get ( arr [ i ] , 0 ) + 1 ; NEW_LINE DEDENT
for i in Hash : NEW_LINE INDENT if ( Hash [ i ] % 2 != 0 ) : NEW_LINE INDENT return i NEW_LINE DEDENT DEDENT return - 1 NEW_LINE
arr = [ 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( getOddOccurrence ( arr , n ) ) NEW_LINE
def fastPow ( N , K ) : NEW_LINE INDENT if ( K == 0 ) : NEW_LINE INDENT return 1 ; NEW_LINE DEDENT temp = fastPow ( N , int ( K / 2 ) ) ; NEW_LINE if ( K % 2 == 0 ) : NEW_LINE INDENT return temp * temp ; NEW_LINE DEDENT else : NEW_LINE INDENT return N * temp * temp ; NEW_LINE DEDENT DEDENT def countWays ( N , K ) : NEW_LINE INDENT return K * fastPow ( K - 1 , N - 1 ) ; NEW_LINE DEDENT
N = 3 ; NEW_LINE K = 3 ; NEW_LINE print ( countWays ( N , K ) ) ; NEW_LINE
def countSetBits ( n ) : NEW_LINE
if ( n == 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE INDENT return 1 + countSetBits ( n & ( n - 1 ) ) NEW_LINE DEDENT
n = 9 NEW_LINE
print ( countSetBits ( n ) ) NEW_LINE
BitsSetTable256 = [ 0 ] * 256 NEW_LINE
def initialize ( ) : NEW_LINE
BitsSetTable256 [ 0 ] = 0 NEW_LINE for i in range ( 256 ) : NEW_LINE INDENT BitsSetTable256 [ i ] = ( i & 1 ) + BitsSetTable256 [ i // 2 ] NEW_LINE DEDENT
def countSetBits ( n ) : NEW_LINE INDENT return ( BitsSetTable256 [ n & 0xff ] + BitsSetTable256 [ ( n >> 8 ) & 0xff ] + BitsSetTable256 [ ( n >> 16 ) & 0xff ] + BitsSetTable256 [ n >> 24 ] ) NEW_LINE DEDENT
initialize ( ) NEW_LINE n = 9 NEW_LINE print ( countSetBits ( n ) ) NEW_LINE
print ( bin ( 4 ) . count ( '1' ) ) ; NEW_LINE print ( bin ( 15 ) . count ( '1' ) ) ; NEW_LINE
def countSetBits ( N ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
INDENT for i in range ( 4 * 8 ) : NEW_LINE INDENT if ( N & ( 1 << i ) ) : NEW_LINE count += 1 NEW_LINE return count NEW_LINE DEDENT DEDENT
N = 15 NEW_LINE print ( countSetBits ( N ) ) NEW_LINE
def countSetBits ( n ) : NEW_LINE INDENT count = 0 NEW_LINE while n : NEW_LINE INDENT count += 1 NEW_LINE n &= ( n - 1 ) NEW_LINE DEDENT return count NEW_LINE DEDENT
def FlippedCount ( a , b ) : NEW_LINE
return countSetBits ( a ^ b ) NEW_LINE
a = 10 NEW_LINE b = 20 NEW_LINE print ( FlippedCount ( a , b ) ) NEW_LINE
def powerof2 ( n ) : NEW_LINE
if n == 1 : NEW_LINE INDENT return True NEW_LINE DEDENT
elif n % 2 != 0 or n == 0 : NEW_LINE INDENT return False NEW_LINE DEDENT
return powerof2 ( n / 2 ) NEW_LINE
print ( powerof2 ( 64 ) ) NEW_LINE
print ( powerof2 ( 12 ) ) NEW_LINE
def PositionRightmostSetbit ( n ) : NEW_LINE
position = 1 NEW_LINE m = 1 NEW_LINE while ( not ( n & m ) ) : NEW_LINE
m = m << 1 NEW_LINE position += 1 NEW_LINE return position NEW_LINE
n = 16 NEW_LINE
print ( PositionRightmostSetbit ( n ) ) NEW_LINE
INT_SIZE = 32 NEW_LINE def Right_most_setbit ( num ) : NEW_LINE INDENT pos = 1 NEW_LINE DEDENT
for i in range ( INT_SIZE ) : NEW_LINE INDENT if not ( num & ( 1 << i ) ) : NEW_LINE INDENT pos += 1 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT return pos NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT num = 18 NEW_LINE pos = Right_most_setbit ( num ) NEW_LINE print ( pos ) NEW_LINE DEDENT
def PositionRightmostSetbit ( n ) : NEW_LINE INDENT p = 1 NEW_LINE DEDENT
INDENT while ( n > 0 ) : NEW_LINE DEDENT
if ( n & 1 ) : NEW_LINE return p NEW_LINE
p += 1 NEW_LINE n = n >> 1 NEW_LINE
INDENT return - 1 ; NEW_LINE DEDENT
n = 18 NEW_LINE
pos = PositionRightmostSetbit ( n ) NEW_LINE if ( pos != - 1 ) : NEW_LINE INDENT print ( pos ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( 0 ) NEW_LINE DEDENT
def bin ( n ) : NEW_LINE INDENT i = 1 << 31 NEW_LINE while ( i > 0 ) : NEW_LINE INDENT if ( ( n & i ) != 0 ) : NEW_LINE INDENT print ( "1" , end = " " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( "0" , end = " " ) NEW_LINE DEDENT i = i // 2 NEW_LINE DEDENT DEDENT
bin ( 7 ) NEW_LINE print ( ) NEW_LINE bin ( 4 ) NEW_LINE
def bin ( n ) : NEW_LINE INDENT if ( n > 1 ) : NEW_LINE INDENT bin ( n >> 1 ) NEW_LINE DEDENT print ( n & 1 , end = " " ) NEW_LINE DEDENT
bin ( 131 ) NEW_LINE print ( ) NEW_LINE bin ( 3 ) NEW_LINE
def swap ( a , b ) : NEW_LINE
a = ( a & b ) + ( a b ) NEW_LINE
b = a + ( ~ b ) + 1 NEW_LINE
a = a + ( ~ b ) + 1 NEW_LINE print ( " After ▁ Swapping : ▁ a ▁ = ▁ " , a , " , ▁ b ▁ = ▁ " , b ) NEW_LINE
a = 5 NEW_LINE b = 10 NEW_LINE
swap ( a , b ) NEW_LINE
def checkSentence ( string ) : NEW_LINE
length = len ( string ) NEW_LINE
if string [ 0 ] < ' A ' or string [ 0 ] > ' Z ' : NEW_LINE INDENT return False NEW_LINE DEDENT
if string [ length - 1 ] != ' . ' : NEW_LINE INDENT return False NEW_LINE DEDENT
prev_state = 0 NEW_LINE curr_state = 0 NEW_LINE
index = 1 NEW_LINE
while ( string [ index ] ) : NEW_LINE
if string [ index ] >= ' A ' and string [ index ] <= ' Z ' : NEW_LINE INDENT curr_state = 0 NEW_LINE DEDENT
elif string [ index ] == ' ▁ ' : NEW_LINE INDENT curr_state = 1 NEW_LINE DEDENT
elif string [ index ] >= ' a ' and string [ index ] <= ' z ' : NEW_LINE INDENT curr_state = 2 NEW_LINE DEDENT
elif string [ index ] == ' . ' : NEW_LINE INDENT curr_state = 3 NEW_LINE DEDENT
if prev_state == curr_state and curr_state != 2 : NEW_LINE INDENT return False NEW_LINE DEDENT
if prev_state == 2 and curr_state == 0 : NEW_LINE INDENT return False NEW_LINE DEDENT
if curr_state == 3 and prev_state != 1 : NEW_LINE INDENT return True NEW_LINE DEDENT index += 1 NEW_LINE prev_state = curr_state NEW_LINE return False NEW_LINE
string = [ " I ▁ love ▁ cinema . " , " The ▁ vertex ▁ is ▁ S . " , " I ▁ am ▁ single . " , " My ▁ name ▁ is ▁ KG . " , " I ▁ lovE ▁ cinema . " , " GeeksQuiz . ▁ is ▁ a ▁ quiz ▁ site . " , " I ▁ love ▁ Geeksquiz ▁ and ▁ Geeksforgeeks . " , " ▁ You ▁ are ▁ my ▁ friend . " , " I ▁ love ▁ cinema " ] NEW_LINE string_size = len ( string ) NEW_LINE for i in xrange ( string_size ) : NEW_LINE INDENT if checkSentence ( string [ i ] ) : NEW_LINE INDENT print " \ " " + string [ i ] + " \ " ▁ is ▁ correct " NEW_LINE DEDENT else : NEW_LINE INDENT print " \ " " + string [ i ] + " \ " ▁ is ▁ incorrect " NEW_LINE DEDENT DEDENT
def maxOnesIndex ( arr , n ) : NEW_LINE
max_count = 0 NEW_LINE
max_index = 0 NEW_LINE
prev_zero = - 1 NEW_LINE
prev_prev_zero = - 1 NEW_LINE
for curr in range ( n ) : NEW_LINE
if ( arr [ curr ] == 0 ) : NEW_LINE
if ( curr - prev_prev_zero > max_count ) : NEW_LINE INDENT max_count = curr - prev_prev_zero NEW_LINE max_index = prev_zero NEW_LINE DEDENT
prev_prev_zero = prev_zero NEW_LINE prev_zero = curr NEW_LINE
if ( n - prev_prev_zero > max_count ) : NEW_LINE INDENT max_index = prev_zero NEW_LINE DEDENT return max_index NEW_LINE
arr = [ 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Index ▁ of ▁ 0 ▁ to ▁ be ▁ replaced ▁ is ▁ " , maxOnesIndex ( arr , n ) ) NEW_LINE
def min ( x , y ) : NEW_LINE INDENT return x if ( x < y ) else y NEW_LINE DEDENT def max ( x , y ) : NEW_LINE INDENT return x if ( x > y ) else y NEW_LINE DEDENT
def findLength ( arr , n ) : NEW_LINE
max_len = 1 NEW_LINE for i in range ( n - 1 ) : NEW_LINE
mn = arr [ i ] NEW_LINE mx = arr [ i ] NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE
mn = min ( mn , arr [ j ] ) NEW_LINE mx = max ( mx , arr [ j ] ) NEW_LINE
if ( ( mx - mn ) == j - i ) : NEW_LINE INDENT max_len = max ( max_len , mx - mn + 1 ) NEW_LINE DEDENT
return max_len NEW_LINE
arr = [ 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Length ▁ of ▁ the ▁ longest ▁ contiguous ▁ subarray ▁ is ▁ " , findLength ( arr , n ) ) NEW_LINE
def printArr ( arr , k ) : NEW_LINE INDENT for i in range ( k ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) ; NEW_LINE DEDENT print ( ) ; NEW_LINE DEDENT
def printSeqUtil ( n , k , len1 , arr ) : NEW_LINE
if ( len1 == k ) : NEW_LINE INDENT printArr ( arr , k ) ; NEW_LINE return ; NEW_LINE DEDENT
i = 1 if ( len1 == 0 ) else ( arr [ len1 - 1 ] + 1 ) ; NEW_LINE
len1 += 1 ; NEW_LINE
while ( i <= n ) : NEW_LINE INDENT arr [ len1 - 1 ] = i ; NEW_LINE printSeqUtil ( n , k , len1 , arr ) ; NEW_LINE i += 1 ; NEW_LINE DEDENT
len1 -= 1 ; NEW_LINE
def printSeq ( n , k ) : NEW_LINE
arr = [ 0 ] * k ; NEW_LINE
len1 = 0 ; NEW_LINE printSeqUtil ( n , k , len1 , arr ) ; NEW_LINE
k = 3 ; NEW_LINE n = 7 ; NEW_LINE printSeq ( n , k ) ; NEW_LINE
def isSubSequence ( string1 , string2 , m , n ) : NEW_LINE
if m == 0 : NEW_LINE INDENT return True NEW_LINE DEDENT if n == 0 : NEW_LINE INDENT return False NEW_LINE DEDENT
if string1 [ m - 1 ] == string2 [ n - 1 ] : NEW_LINE INDENT return isSubSequence ( string1 , string2 , m - 1 , n - 1 ) NEW_LINE DEDENT
return isSubSequence ( string1 , string2 , m , n - 1 ) NEW_LINE
string1 = " gksrek " NEW_LINE string2 = " geeksforgeeks " NEW_LINE if isSubSequence ( string1 , string2 , len ( string1 ) , len ( string2 ) ) : NEW_LINE INDENT print " Yes " NEW_LINE DEDENT else : NEW_LINE INDENT print " No " NEW_LINE DEDENT
def segregate0and1 ( arr , n ) : NEW_LINE
count = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] == 0 ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT DEDENT
for i in range ( 0 , count ) : NEW_LINE INDENT arr [ i ] = 0 NEW_LINE DEDENT
for i in range ( count , n ) : NEW_LINE INDENT arr [ i ] = 1 NEW_LINE DEDENT
def print_arr ( arr , n ) : NEW_LINE INDENT print ( " Array ▁ after ▁ segregation ▁ is ▁ " , end = " " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 0 , 1 , 0 , 1 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE segregate0and1 ( arr , n ) NEW_LINE print_arr ( arr , n ) NEW_LINE
def segregate0and1 ( arr , size ) : NEW_LINE INDENT type0 = 0 NEW_LINE type1 = size - 1 NEW_LINE while ( type0 < type1 ) : NEW_LINE INDENT if ( arr [ type0 ] == 1 ) : NEW_LINE INDENT ( arr [ type0 ] , arr [ type1 ] ) = ( arr [ type1 ] , arr [ type0 ] ) NEW_LINE type1 -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT type0 += 1 NEW_LINE DEDENT DEDENT DEDENT
arr = [ 0 , 1 , 0 , 1 , 1 , 1 ] NEW_LINE arr_size = len ( arr ) NEW_LINE segregate0and1 ( arr , arr_size ) NEW_LINE print ( " Array ▁ after ▁ segregation ▁ is " , end = " ▁ " ) NEW_LINE for i in range ( 0 , arr_size ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def find3Numbers ( nums ) : NEW_LINE
INDENT if ( len ( nums ) < 3 ) : NEW_LINE INDENT print ( " No ▁ such ▁ triplet ▁ found " , end = ' ' ) NEW_LINE return NEW_LINE DEDENT DEDENT
INDENT seq = 1 NEW_LINE DEDENT
INDENT min_num = nums [ 0 ] NEW_LINE DEDENT
INDENT max_seq = - sys . maxsize - 1 NEW_LINE DEDENT
INDENT store_min = min_num NEW_LINE DEDENT
INDENT for i in range ( 1 , len ( nums ) ) : NEW_LINE INDENT if ( nums [ i ] == min_num ) : NEW_LINE continue NEW_LINE elif ( nums [ i ] < min_num ) : NEW_LINE min_num = nums [ i ] NEW_LINE continue NEW_LINE DEDENT DEDENT
elif ( nums [ i ] < max_seq ) : NEW_LINE
max_seq = nums [ i ] NEW_LINE
store_min = min_num NEW_LINE
elif ( nums [ i ] > max_seq ) : NEW_LINE if seq == 1 : NEW_LINE INDENT store_min = min_num NEW_LINE DEDENT seq += 1 NEW_LINE
if ( seq == 3 ) : NEW_LINE INDENT print ( " Triplet : ▁ " + str ( store_min ) + " , ▁ " + str ( max_seq ) + " , ▁ " + str ( nums [ i ] ) ) NEW_LINE return NEW_LINE DEDENT max_seq = nums [ i ] NEW_LINE
INDENT print ( " No ▁ such ▁ triplet ▁ found " , end = ' ' ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT nums = [ 1 , 2 , - 1 , 7 , 5 ] NEW_LINE DEDENT
INDENT find3Numbers ( nums ) NEW_LINE DEDENT
def maxSubarrayProduct ( arr , n ) : NEW_LINE
result = arr [ 0 ] NEW_LINE for i in range ( n ) : NEW_LINE INDENT mul = arr [ i ] NEW_LINE DEDENT
for j in range ( i + 1 , n ) : NEW_LINE
result = max ( result , mul ) NEW_LINE mul *= arr [ j ] NEW_LINE
result = max ( result , mul ) NEW_LINE return result NEW_LINE
arr = [ 1 , - 2 , - 3 , 0 , 7 , - 8 , - 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Maximum ▁ Sub ▁ array ▁ product ▁ is " , maxSubarrayProduct ( arr , n ) ) NEW_LINE
def maxCircularSum ( a , n ) : NEW_LINE
if ( n == 1 ) : NEW_LINE INDENT return a [ 0 ] NEW_LINE DEDENT
sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum += a [ i ] NEW_LINE DEDENT
curr_max = a [ 0 ] NEW_LINE max_so_far = a [ 0 ] NEW_LINE curr_min = a [ 0 ] NEW_LINE min_so_far = a [ 0 ] NEW_LINE
for i in range ( 1 , n ) : NEW_LINE
curr_max = max ( curr_max + a [ i ] , a [ i ] ) NEW_LINE max_so_far = max ( max_so_far , curr_max ) NEW_LINE
curr_min = min ( curr_min + a [ i ] , a [ i ] ) NEW_LINE min_so_far = min ( min_so_far , curr_min ) NEW_LINE if ( min_so_far == sum ) : NEW_LINE return max_so_far NEW_LINE
return max ( max_so_far , sum - min_so_far ) NEW_LINE
a = [ 11 , 10 , - 20 , 5 , - 3 , - 5 , 8 , - 13 , 10 ] NEW_LINE n = len ( a ) NEW_LINE print ( " Maximum ▁ circular ▁ sum ▁ is " , maxCircularSum ( a , n ) ) NEW_LINE
def GetCeilIndex ( arr , T , l , r , key ) : NEW_LINE INDENT while ( r - l > 1 ) : NEW_LINE INDENT m = l + ( r - l ) // 2 NEW_LINE if ( arr [ T [ m ] ] >= key ) : NEW_LINE INDENT r = m NEW_LINE DEDENT else : NEW_LINE INDENT l = m NEW_LINE DEDENT DEDENT return r NEW_LINE DEDENT def LongestIncreasingSubsequence ( arr , n ) : NEW_LINE
tailIndices = [ 0 for i in range ( n + 1 ) ] NEW_LINE
prevIndices = [ - 1 for i in range ( n + 1 ) ] NEW_LINE
len = 1 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] < arr [ tailIndices [ 0 ] ] ) : NEW_LINE DEDENT
tailIndices [ 0 ] = i NEW_LINE elif ( arr [ i ] > arr [ tailIndices [ len - 1 ] ] ) : NEW_LINE
prevIndices [ i ] = tailIndices [ len - 1 ] NEW_LINE tailIndices [ len ] = i NEW_LINE len += 1 NEW_LINE else : NEW_LINE
pos = GetCeilIndex ( arr , tailIndices , - 1 , len - 1 , arr [ i ] ) NEW_LINE prevIndices [ i ] = tailIndices [ pos - 1 ] NEW_LINE tailIndices [ pos ] = i NEW_LINE print ( " LIS ▁ of ▁ given ▁ input " ) NEW_LINE i = tailIndices [ len - 1 ] NEW_LINE while ( i >= 0 ) : NEW_LINE print ( arr [ i ] , " ▁ " , end = " " ) NEW_LINE i = prevIndices [ i ] NEW_LINE print ( ) NEW_LINE return len NEW_LINE
arr = [ 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " LIS size " , LongestIncreasingSubsequence ( arr , n ) ) NEW_LINE
def maxSum ( arr , n ) : NEW_LINE INDENT sum = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
for i in range ( 0 , int ( n / 2 ) ) : NEW_LINE INDENT sum -= ( 2 * arr [ i ] ) NEW_LINE sum += ( 2 * arr [ n - i - 1 ] ) NEW_LINE DEDENT return sum NEW_LINE
arr = [ 4 , 2 , 1 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxSum ( arr , n ) ) NEW_LINE
def threeWayPartition ( arr , n , lowVal , highVal ) : NEW_LINE
start = 0 NEW_LINE end = n - 1 NEW_LINE i = 0 NEW_LINE
while i <= end : NEW_LINE
if arr [ i ] < lowVal : NEW_LINE INDENT temp = arr [ i ] NEW_LINE arr [ i ] = arr [ start ] NEW_LINE arr [ start ] = temp NEW_LINE i += 1 NEW_LINE start += 1 NEW_LINE DEDENT
elif arr [ i ] > highVal : NEW_LINE INDENT temp = arr [ i ] NEW_LINE arr [ i ] = arr [ end ] NEW_LINE arr [ end ] = temp NEW_LINE end -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 14 , 5 , 20 , 4 , 2 , 54 , 20 , 87 , 98 , 3 , 1 , 32 ] NEW_LINE n = len ( arr ) NEW_LINE threeWayPartition ( arr , n , 10 , 20 ) NEW_LINE print ( " Modified ▁ array " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def generateUtil ( A , B , C , i , j , m , n , len , flag ) : NEW_LINE
if ( flag ) : NEW_LINE
if ( len ) : NEW_LINE INDENT printArr ( C , len + 1 ) NEW_LINE DEDENT
for k in range ( i , m ) : NEW_LINE INDENT if ( not len ) : NEW_LINE DEDENT
C [ len ] = A [ k ] NEW_LINE
generateUtil ( A , B , C , k + 1 , j , m , n , len , not flag ) NEW_LINE else : NEW_LINE
if ( A [ k ] > C [ len ] ) : NEW_LINE INDENT C [ len + 1 ] = A [ k ] NEW_LINE generateUtil ( A , B , C , k + 1 , j , m , n , len + 1 , not flag ) NEW_LINE DEDENT else : NEW_LINE
for l in range ( j , n ) : NEW_LINE INDENT if ( B [ l ] > C [ len ] ) : NEW_LINE INDENT C [ len + 1 ] = B [ l ] NEW_LINE generateUtil ( A , B , C , i , l + 1 , m , n , len + 1 , not flag ) NEW_LINE DEDENT DEDENT
def generate ( A , B , m , n ) : NEW_LINE
C = [ ] NEW_LINE for i in range ( m + n + 1 ) : NEW_LINE INDENT C . append ( 0 ) NEW_LINE DEDENT generateUtil ( A , B , C , 0 , 0 , m , n , 0 , True ) NEW_LINE
def printArr ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
A = [ 10 , 15 , 25 ] NEW_LINE B = [ 5 , 20 , 30 ] NEW_LINE n = len ( A ) NEW_LINE m = len ( B ) NEW_LINE generate ( A , B , n , m ) NEW_LINE
def updateindex ( index , a , ai , b , bi ) : NEW_LINE INDENT index [ a ] = ai NEW_LINE index [ b ] = bi NEW_LINE DEDENT
def minSwapsUtil ( arr , pairs , index , i , n ) : NEW_LINE
if ( i > n ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( pairs [ arr [ i ] ] == arr [ i + 1 ] ) : NEW_LINE INDENT return minSwapsUtil ( arr , pairs , index , i + 2 , n ) NEW_LINE DEDENT
one = arr [ i + 1 ] NEW_LINE indextwo = i + 1 NEW_LINE indexone = index [ pairs [ arr [ i ] ] ] NEW_LINE two = arr [ index [ pairs [ arr [ i ] ] ] ] NEW_LINE arr [ i + 1 ] , arr [ indexone ] = arr [ indexone ] , arr [ i + 1 ] NEW_LINE updateindex ( index , one , indexone , two , indextwo ) NEW_LINE a = minSwapsUtil ( arr , pairs , index , i + 2 , n ) NEW_LINE
arr [ i + 1 ] , arr [ indexone ] = arr [ indexone ] , arr [ i + 1 ] NEW_LINE updateindex ( index , one , indextwo , two , indexone ) NEW_LINE one = arr [ i ] NEW_LINE indexone = index [ pairs [ arr [ i + 1 ] ] ] NEW_LINE
two = arr [ index [ pairs [ arr [ i + 1 ] ] ] ] NEW_LINE indextwo = i NEW_LINE arr [ i ] , arr [ indexone ] = arr [ indexone ] , arr [ i ] NEW_LINE updateindex ( index , one , indexone , two , indextwo ) NEW_LINE b = minSwapsUtil ( arr , pairs , index , i + 2 , n ) NEW_LINE
arr [ i ] , arr [ indexone ] = arr [ indexone ] , arr [ i ] NEW_LINE updateindex ( index , one , indextwo , two , indexone ) NEW_LINE
return 1 + min ( a , b ) NEW_LINE
def minSwaps ( n , pairs , arr ) : NEW_LINE
index = [ ] NEW_LINE for i in range ( 2 * n + 1 + 1 ) : NEW_LINE INDENT index . append ( 0 ) NEW_LINE DEDENT
for i in range ( 1 , 2 * n + 1 ) : NEW_LINE INDENT index [ arr [ i ] ] = i NEW_LINE DEDENT
return minSwapsUtil ( arr , pairs , index , 1 , 2 * n ) NEW_LINE
arr = [ 0 , 3 , 5 , 6 , 4 , 1 , 2 ] NEW_LINE
pairs = [ 0 , 3 , 6 , 1 , 5 , 4 , 2 ] NEW_LINE m = len ( pairs ) NEW_LINE
n = m // 2 NEW_LINE
print ( " Min ▁ swaps ▁ required ▁ is ▁ " , minSwaps ( n , pairs , arr ) ) NEW_LINE
def replace_elements ( arr , n ) : NEW_LINE
pos = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT arr [ pos ] = arr [ i ] NEW_LINE pos = pos + 1 NEW_LINE while ( pos > 1 and arr [ pos - 2 ] == arr [ pos - 1 ] ) : NEW_LINE INDENT pos -= 1 NEW_LINE arr [ pos - 1 ] += 1 NEW_LINE DEDENT DEDENT
for i in range ( 0 , pos ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
arr = [ 6 , 4 , 3 , 4 , 3 , 3 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE replace_elements ( arr , n ) NEW_LINE
def arrangeString ( str1 , x , y ) : NEW_LINE INDENT count_0 = 0 NEW_LINE count_1 = 0 NEW_LINE n = len ( str1 ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if str1 [ i ] == '0' : NEW_LINE INDENT count_0 += 1 NEW_LINE DEDENT else : NEW_LINE INDENT count_1 += 1 NEW_LINE DEDENT DEDENT
while count_0 > 0 or count_1 > 0 : NEW_LINE INDENT for i in range ( 0 , x ) : NEW_LINE INDENT if count_0 > 0 : NEW_LINE INDENT print ( "0" , end = " " ) NEW_LINE count_0 -= 1 NEW_LINE DEDENT DEDENT for j in range ( 0 , y ) : NEW_LINE INDENT if count_1 > 0 : NEW_LINE INDENT print ( "1" , end = " " ) NEW_LINE count_1 -= 1 NEW_LINE DEDENT DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT str1 = "01101101101101101000000" NEW_LINE x = 1 NEW_LINE y = 2 NEW_LINE arrangeString ( str1 , x , y ) NEW_LINE DEDENT
def distantAdjacentElement ( a , n ) : NEW_LINE
m = dict ( ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if a [ i ] in m : NEW_LINE INDENT m [ a [ i ] ] += 1 NEW_LINE DEDENT else : NEW_LINE INDENT m [ a [ i ] ] = 1 NEW_LINE DEDENT DEDENT
mx = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if mx < m [ a [ i ] ] : NEW_LINE INDENT mx = m [ a [ i ] ] NEW_LINE DEDENT DEDENT
if mx > ( n + 1 ) // 2 : NEW_LINE INDENT print ( " NO " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " YES " ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 7 , 7 , 7 , 7 ] NEW_LINE n = len ( a ) NEW_LINE distantAdjacentElement ( a , n ) NEW_LINE DEDENT
def rearrange ( n ) : NEW_LINE INDENT global arr NEW_LINE DEDENT
if ( n % 2 == 1 ) : NEW_LINE INDENT return NEW_LINE DEDENT
currIdx = int ( ( n - 1 ) / 2 ) NEW_LINE
while ( currIdx > 0 ) : NEW_LINE INDENT count = currIdx NEW_LINE swapIdx = currIdx NEW_LINE while ( count > 0 ) : NEW_LINE INDENT temp = arr [ swapIdx + 1 ] NEW_LINE arr [ swapIdx + 1 ] = arr [ swapIdx ] NEW_LINE arr [ swapIdx ] = temp NEW_LINE swapIdx = swapIdx + 1 NEW_LINE count = count - 1 NEW_LINE DEDENT currIdx = currIdx - 1 NEW_LINE DEDENT
n = len ( arr ) NEW_LINE rearrange ( n ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( " { } ▁ " . format ( arr [ i ] ) , end = " " ) NEW_LINE DEDENT
def maxDiff ( arr , n ) : NEW_LINE
maxDiff = - 1 NEW_LINE
maxRight = arr [ n - 1 ] NEW_LINE for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT if ( arr [ i ] > maxRight ) : NEW_LINE INDENT maxRight = arr [ i ] NEW_LINE DEDENT else : NEW_LINE INDENT diff = maxRight - arr [ i ] NEW_LINE if ( diff > maxDiff ) : NEW_LINE INDENT maxDiff = diff NEW_LINE DEDENT DEDENT DEDENT return maxDiff NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 2 , 90 , 10 , 110 ] NEW_LINE n = len ( arr ) NEW_LINE DEDENT
print ( " Maximum ▁ difference ▁ is " , maxDiff ( arr , n ) ) NEW_LINE
def maxDiff ( arr , n ) : NEW_LINE
diff = arr [ 1 ] - arr [ 0 ] NEW_LINE curr_sum = diff NEW_LINE max_sum = curr_sum NEW_LINE for i in range ( 1 , n - 1 ) : NEW_LINE
diff = arr [ i + 1 ] - arr [ i ] NEW_LINE
if ( curr_sum > 0 ) : NEW_LINE INDENT curr_sum += diff NEW_LINE DEDENT else : NEW_LINE INDENT curr_sum = diff NEW_LINE DEDENT
if ( curr_sum > max_sum ) : NEW_LINE INDENT max_sum = curr_sum NEW_LINE DEDENT return max_sum NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 80 , 2 , 6 , 3 , 100 ] NEW_LINE n = len ( arr ) NEW_LINE DEDENT
print ( " Maximum ▁ difference ▁ is " , maxDiff ( arr , n ) ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT v = [ 34 , 8 , 10 , 3 , 2 , 80 , 30 , 33 , 1 ] ; NEW_LINE n = len ( v ) ; NEW_LINE maxFromEnd = [ - 38749432 ] * ( n + 1 ) ; NEW_LINE DEDENT
for i in range ( n - 1 , 0 , - 1 ) : NEW_LINE INDENT maxFromEnd [ i ] = max ( maxFromEnd [ i + 1 ] , v [ i ] ) ; NEW_LINE DEDENT result = 0 ; NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT low = i + 1 ; high = n - 1 ; ans = i ; NEW_LINE while ( low <= high ) : NEW_LINE INDENT mid = int ( ( low + high ) / 2 ) ; NEW_LINE if ( v [ i ] <= maxFromEnd [ mid ] ) : NEW_LINE DEDENT DEDENT
ans = max ( ans , mid ) ; NEW_LINE low = mid + 1 ; NEW_LINE else : NEW_LINE high = mid - 1 ; NEW_LINE
result = max ( result , ans - i ) ; NEW_LINE print ( result , end = " " ) ; NEW_LINE
def getPostOrderBST ( pre , N ) : NEW_LINE INDENT pivotPoint = 0 NEW_LINE DEDENT
for i in range ( 1 , N ) : NEW_LINE INDENT if ( pre [ 0 ] <= pre [ i ] ) : NEW_LINE INDENT pivotPoint = i NEW_LINE break NEW_LINE DEDENT DEDENT
for i in range ( pivotPoint - 1 , 0 , - 1 ) : NEW_LINE INDENT print ( pre [ i ] , end = " ▁ " ) NEW_LINE DEDENT
for i in range ( N - 1 , pivotPoint - 1 , - 1 ) : NEW_LINE INDENT print ( pre [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( pre [ 0 ] ) NEW_LINE
def constructLowerArray ( arr , countSmaller , n ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT countSmaller [ i ] = 0 NEW_LINE DEDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( arr [ j ] < arr [ i ] ) : NEW_LINE INDENT countSmaller [ i ] += 1 NEW_LINE DEDENT DEDENT DEDENT
def printArray ( arr , size ) : NEW_LINE INDENT for i in range ( size ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
arr = [ 12 , 10 , 5 , 4 , 2 , 20 , 6 , 1 , 0 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE low = [ 0 ] * n NEW_LINE constructLowerArray ( arr , low , n ) NEW_LINE printArray ( low , n ) NEW_LINE
def segregate ( arr , size ) : NEW_LINE INDENT j = 0 NEW_LINE for i in range ( size ) : NEW_LINE INDENT if ( arr [ i ] <= 0 ) : NEW_LINE INDENT arr [ i ] , arr [ j ] = arr [ j ] , arr [ i ] NEW_LINE DEDENT DEDENT DEDENT
j += 1 NEW_LINE return j NEW_LINE
def findMissingPositive ( arr , size ) : NEW_LINE
for i in range ( size ) : NEW_LINE INDENT if ( abs ( arr [ i ] ) - 1 < size and arr [ abs ( arr [ i ] ) - 1 ] > 0 ) : NEW_LINE INDENT arr [ abs ( arr [ i ] ) - 1 ] = - arr [ abs ( arr [ i ] ) - 1 ] NEW_LINE DEDENT DEDENT
for i in range ( size ) : NEW_LINE INDENT if ( arr [ i ] > 0 ) : NEW_LINE DEDENT
return i + 1 NEW_LINE return size + 1 NEW_LINE
def findMissing ( arr , size ) : NEW_LINE
shift = segregate ( arr , size ) NEW_LINE
return findMissingPositive ( arr [ shift : ] , size - shift ) NEW_LINE
arr = [ 0 , 10 , 2 , - 10 , - 20 ] NEW_LINE arr_size = len ( arr ) NEW_LINE missing = findMissing ( arr , arr_size ) NEW_LINE print ( " The ▁ smallest ▁ positive ▁ missing ▁ number ▁ is ▁ " , missing ) NEW_LINE
def fillDepth ( parent , i , depth ) : NEW_LINE
if depth [ i ] != 0 : NEW_LINE INDENT return NEW_LINE DEDENT
if parent [ i ] == - 1 : NEW_LINE INDENT depth [ i ] = 1 NEW_LINE return NEW_LINE DEDENT
if depth [ parent [ i ] ] == 0 : NEW_LINE INDENT fillDepth ( parent , parent [ i ] , depth ) NEW_LINE DEDENT
depth [ i ] = depth [ parent [ i ] ] + 1 NEW_LINE
def findHeight ( parent ) : NEW_LINE INDENT n = len ( parent ) NEW_LINE DEDENT
depth = [ 0 for i in range ( n ) ] NEW_LINE
for i in range ( n ) : NEW_LINE INDENT fillDepth ( parent , i , depth ) NEW_LINE DEDENT
ht = depth [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT ht = max ( ht , depth [ i ] ) NEW_LINE DEDENT return ht NEW_LINE
parent = [ - 1 , 0 , 0 , 1 , 1 , 3 , 5 ] NEW_LINE print " Height ▁ is ▁ % d " % ( findHeight ( parent ) ) NEW_LINE
def maxRepeating ( arr , n , k ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT arr [ arr [ i ] % k ] += k NEW_LINE DEDENT
max = arr [ 0 ] NEW_LINE result = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if arr [ i ] > max : NEW_LINE INDENT max = arr [ i ] NEW_LINE result = i NEW_LINE DEDENT DEDENT
return result NEW_LINE
arr = [ 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE k = 8 NEW_LINE print ( " The ▁ maximum ▁ repeating ▁ number ▁ is " , maxRepeating ( arr , n , k ) ) NEW_LINE
def maxPathSum ( ar1 , ar2 , m , n ) : NEW_LINE
i , j = 0 , 0 NEW_LINE
result , sum1 , sum2 = 0 , 0 , 0 NEW_LINE
while ( i < m and j < n ) : NEW_LINE
if ar1 [ i ] < ar2 [ j ] : NEW_LINE INDENT sum1 += ar1 [ i ] NEW_LINE i += 1 NEW_LINE DEDENT
elif ar1 [ i ] > ar2 [ j ] : NEW_LINE INDENT sum2 += ar2 [ j ] NEW_LINE j += 1 NEW_LINE DEDENT
else : NEW_LINE
result += max ( sum1 , sum2 ) + ar1 [ i ] NEW_LINE
sum1 = 0 NEW_LINE sum2 = 0 NEW_LINE
i += 1 NEW_LINE j += 1 NEW_LINE
while i < m : NEW_LINE INDENT sum1 += ar1 [ i ] NEW_LINE i += 1 NEW_LINE DEDENT
while j < n : NEW_LINE INDENT sum2 += ar2 [ j ] NEW_LINE j += 1 NEW_LINE DEDENT
result += max ( sum1 , sum2 ) NEW_LINE return result NEW_LINE
ar1 = [ 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 ] NEW_LINE ar2 = [ 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 ] NEW_LINE m = len ( ar1 ) NEW_LINE n = len ( ar2 ) NEW_LINE
print " Maximum ▁ sum ▁ path ▁ is " , maxPathSum ( ar1 , ar2 , m , n ) NEW_LINE
def smallestGreater ( arr , n ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE DEDENT
diff = 1000 ; NEW_LINE closest = - 1 ; NEW_LINE for j in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] < arr [ j ] and arr [ j ] - arr [ i ] < diff ) : NEW_LINE INDENT diff = arr [ j ] - arr [ i ] ; NEW_LINE closest = j ; NEW_LINE DEDENT DEDENT
if ( closest == - 1 ) : NEW_LINE INDENT print ( " _ ▁ " , end = " " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " { } ▁ " . format ( arr [ closest ] ) , end = " " ) ; NEW_LINE DEDENT
ar = [ 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 ] ; NEW_LINE n = len ( ar ) ; NEW_LINE smallestGreater ( ar , n ) ; NEW_LINE
def smallestGreater ( arr , n ) : NEW_LINE INDENT s = set ( ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT s . add ( arr [ i ] ) NEW_LINE DEDENT newAr = [ ] NEW_LINE for p in s : NEW_LINE INDENT newAr . append ( p ) NEW_LINE DEDENT for i in range ( n ) : NEW_LINE INDENT temp = lowerBound ( newAr , 0 , len ( newAr ) , arr [ i ] ) NEW_LINE if ( temp < n ) : NEW_LINE INDENT print ( newAr [ temp ] , end = " ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " _ ▁ " , end = " " ) NEW_LINE DEDENT DEDENT DEDENT
def lowerBound ( vec , low , high , element ) : NEW_LINE INDENT array = [ 0 ] * ( len ( vec ) ) NEW_LINE k = 0 NEW_LINE for val in vec : NEW_LINE INDENT array [ k ] = val NEW_LINE k += 1 NEW_LINE DEDENT while ( low < high ) : NEW_LINE INDENT middle = low + int ( ( high - low ) / 2 ) NEW_LINE if ( element > array [ middle ] ) : NEW_LINE INDENT low = middle + 1 NEW_LINE DEDENT else : NEW_LINE INDENT high = middle NEW_LINE DEDENT DEDENT return low + 1 NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT ar = [ 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 ] NEW_LINE n = len ( ar ) NEW_LINE smallestGreater ( ar , n ) NEW_LINE DEDENT
def findZeroes ( arr , n , m ) : NEW_LINE
wL = wR = 0 NEW_LINE
bestL = bestWindow = 0 NEW_LINE
zeroCount = 0 NEW_LINE
while wR < n : NEW_LINE
if zeroCount <= m : NEW_LINE INDENT if arr [ wR ] == 0 : NEW_LINE INDENT zeroCount += 1 NEW_LINE DEDENT wR += 1 NEW_LINE DEDENT
if zeroCount > m : NEW_LINE INDENT if arr [ wL ] == 0 : NEW_LINE INDENT zeroCount -= 1 NEW_LINE DEDENT wL += 1 NEW_LINE DEDENT
if ( wR - wL > bestWindow ) and ( zeroCount <= m ) : NEW_LINE INDENT bestWindow = wR - wL NEW_LINE bestL = wL NEW_LINE DEDENT
for i in range ( 0 , bestWindow ) : NEW_LINE INDENT if arr [ bestL + i ] == 0 : NEW_LINE INDENT print ( bestL + i , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 1 , 0 , 0 , 1 , 1 , 0 , 1 , 0 , 1 , 1 ] NEW_LINE m = 2 NEW_LINE n = len ( arr ) NEW_LINE print ( " Indexes ▁ of ▁ zeroes ▁ to ▁ be ▁ flipped ▁ are " , end = " ▁ " ) NEW_LINE findZeroes ( arr , n , m ) NEW_LINE
def countIncreasing ( arr , n ) : NEW_LINE
cnt = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE INDENT if arr [ j ] > arr [ j - 1 ] : NEW_LINE INDENT cnt += 1 NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT break NEW_LINE DEDENT return cnt NEW_LINE
arr = [ 1 , 2 , 2 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is " , countIncreasing ( arr , n ) ) NEW_LINE
def countIncreasing ( arr , n ) : NEW_LINE
cnt = 0 NEW_LINE
len = 1 NEW_LINE
for i in range ( 0 , n - 1 ) : NEW_LINE
if arr [ i + 1 ] > arr [ i ] : NEW_LINE INDENT len += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT cnt += ( ( ( len - 1 ) * len ) / 2 ) NEW_LINE len = 1 NEW_LINE DEDENT
if len > 1 : NEW_LINE INDENT cnt += ( ( ( len - 1 ) * len ) / 2 ) NEW_LINE DEDENT return cnt NEW_LINE
arr = [ 1 , 2 , 2 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is " , int ( countIncreasing ( arr , n ) ) ) NEW_LINE
def arraySum ( arr , n ) : NEW_LINE INDENT sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum = sum + arr [ i ] NEW_LINE DEDENT return sum NEW_LINE DEDENT
def maxDiff ( arr , n , k ) : NEW_LINE
arr . sort ( ) NEW_LINE
arraysum = arraySum ( arr , n ) NEW_LINE
diff1 = abs ( arraysum - 2 * arraySum ( arr , k ) ) NEW_LINE
arr . reverse ( ) NEW_LINE
diff2 = abs ( arraysum - 2 * arraySum ( arr , k ) ) NEW_LINE
return ( max ( diff1 , diff2 ) ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 7 , 4 , 8 , - 1 , 5 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE print ( " Maximum ▁ Difference ▁ = " , maxDiff ( arr , n , k ) ) NEW_LINE DEDENT
def minNumber ( a , n , x ) : NEW_LINE
a . sort ( reverse = False ) NEW_LINE k = 0 NEW_LINE while ( a [ int ( ( n - 1 ) / 2 ) ] != x ) : NEW_LINE INDENT a [ n - 1 ] = x NEW_LINE n += 1 NEW_LINE a . sort ( reverse = False ) NEW_LINE k += 1 NEW_LINE DEDENT return k NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT x = 10 NEW_LINE a = [ 10 , 20 , 30 ] NEW_LINE n = 3 NEW_LINE print ( minNumber ( a , n , x ) ) NEW_LINE DEDENT
def minNumber ( a , n , x ) : NEW_LINE INDENT l = 0 NEW_LINE h = 0 NEW_LINE e = 0 NEW_LINE for i in range ( n ) : NEW_LINE DEDENT
if a [ i ] == x : NEW_LINE INDENT e += 1 NEW_LINE DEDENT
elif a [ i ] > x : NEW_LINE INDENT h += 1 NEW_LINE DEDENT
elif a [ i ] < x : NEW_LINE INDENT l += 1 NEW_LINE DEDENT ans = 0 ; NEW_LINE if l > h : NEW_LINE ans = l - h NEW_LINE elif l < h : NEW_LINE ans = h - l - 1 ; NEW_LINE
return ans + 1 - e NEW_LINE
x = 10 NEW_LINE a = [ 10 , 20 , 30 ] NEW_LINE n = len ( a ) NEW_LINE print ( minNumber ( a , n , x ) ) NEW_LINE
def fun ( x ) : NEW_LINE INDENT y = ( x // 4 ) * 4 NEW_LINE DEDENT
ans = 0 NEW_LINE for i in range ( y , x + 1 ) : NEW_LINE INDENT ans ^= i NEW_LINE DEDENT return ans NEW_LINE
def query ( x ) : NEW_LINE
if ( x == 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT k = ( x + 1 ) // 2 NEW_LINE
if x % 2 == 0 : NEW_LINE INDENT return ( ( fun ( k - 1 ) * 2 ) ^ ( k & 1 ) ) NEW_LINE DEDENT else : NEW_LINE INDENT return ( 2 * fun ( k ) ) NEW_LINE DEDENT def allQueries ( q , l , r ) : NEW_LINE for i in range ( q ) : NEW_LINE INDENT print ( query ( r [ i ] ) ^ query ( l [ i ] - 1 ) ) NEW_LINE DEDENT
q = 3 NEW_LINE l = [ 2 , 2 , 5 ] NEW_LINE r = [ 4 , 8 , 9 ] NEW_LINE allQueries ( q , l , r ) NEW_LINE
def preprocess ( arr , N , left , right ) : NEW_LINE
left [ 0 ] = 0 NEW_LINE lastIncr = 0 NEW_LINE for i in range ( 1 , N ) : NEW_LINE
if ( arr [ i ] > arr [ i - 1 ] ) : NEW_LINE INDENT lastIncr = i NEW_LINE DEDENT left [ i ] = lastIncr NEW_LINE
right [ N - 1 ] = N - 1 NEW_LINE firstDecr = N - 1 NEW_LINE i = N - 2 NEW_LINE while ( i >= 0 ) : NEW_LINE
if ( arr [ i ] > arr [ i + 1 ] ) : NEW_LINE INDENT firstDecr = i NEW_LINE DEDENT right [ i ] = firstDecr NEW_LINE i -= 1 NEW_LINE
def isSubarrayMountainForm ( arr , left , right , L , R ) : NEW_LINE
return ( right [ L ] >= left [ R ] ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 2 , 3 , 2 , 4 , 4 , 6 , 3 , 2 ] NEW_LINE N = len ( arr ) NEW_LINE left = [ 0 for i in range ( N ) ] NEW_LINE right = [ 0 for i in range ( N ) ] NEW_LINE preprocess ( arr , N , left , right ) NEW_LINE L = 0 NEW_LINE R = 2 NEW_LINE if ( isSubarrayMountainForm ( arr , left , right , L , R ) ) : NEW_LINE INDENT print ( " Subarray ▁ is ▁ in ▁ mountain ▁ form " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Subarray ▁ is ▁ not ▁ in ▁ mountain ▁ form " ) NEW_LINE DEDENT L = 1 NEW_LINE R = 3 NEW_LINE if ( isSubarrayMountainForm ( arr , left , right , L , R ) ) : NEW_LINE INDENT print ( " Subarray ▁ is ▁ in ▁ mountain ▁ form " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Subarray ▁ is ▁ not ▁ in ▁ mountain ▁ form " ) NEW_LINE DEDENT DEDENT
from math import ceil , floor , log NEW_LINE MAX = 1000 NEW_LINE def sieveOfEratosthenes ( isPrime ) : NEW_LINE INDENT isPrime [ 1 ] = False NEW_LINE for p in range ( 2 , MAX + 1 ) : NEW_LINE INDENT if p * p > MAX : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT
if ( isPrime [ p ] == True ) : NEW_LINE
for i in range ( 2 * p , MAX + 1 , p ) : NEW_LINE INDENT isPrime [ i ] = False NEW_LINE DEDENT
def getMid ( s , e ) : NEW_LINE INDENT return s + ( e - s ) // 2 NEW_LINE DEDENT
def queryPrimesUtil ( st , ss , se , qs , qe , index ) : NEW_LINE
if ( qs <= ss and qe >= se ) : NEW_LINE INDENT return st [ index ] NEW_LINE DEDENT
if ( se < qs or ss > qe ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
mid = getMid ( ss , se ) NEW_LINE return queryPrimesUtil ( st , ss , mid , qs , qe , 2 * index + 1 ) + queryPrimesUtil ( st , mid + 1 , se , qs , qe , 2 * index + 2 ) NEW_LINE
def updateValueUtil ( st , ss , se , i , diff , si ) : NEW_LINE
if ( i < ss or i > se ) : NEW_LINE INDENT return NEW_LINE DEDENT
st [ si ] = st [ si ] + diff NEW_LINE if ( se != ss ) : NEW_LINE INDENT mid = getMid ( ss , se ) NEW_LINE updateValueUtil ( st , ss , mid , i , diff , 2 * si + 1 ) NEW_LINE updateValueUtil ( st , mid + 1 , se , i , diff , 2 * si + 2 ) NEW_LINE DEDENT
def updateValue ( arr , st , n , i , new_val , isPrime ) : NEW_LINE
if ( i < 0 or i > n - 1 ) : NEW_LINE INDENT printf ( " Invalid ▁ Input " ) NEW_LINE return NEW_LINE DEDENT diff , oldValue = 0 , 0 NEW_LINE oldValue = arr [ i ] NEW_LINE
arr [ i ] = new_val NEW_LINE
if ( isPrime [ oldValue ] and isPrime [ new_val ] ) : NEW_LINE INDENT return NEW_LINE DEDENT
if ( ( not isPrime [ oldValue ] ) and ( not isPrime [ new_val ] ) ) : NEW_LINE INDENT return NEW_LINE DEDENT
if ( isPrime [ oldValue ] and not isPrime [ new_val ] ) : NEW_LINE INDENT diff = - 1 NEW_LINE DEDENT
if ( not isPrime [ oldValue ] and isPrime [ new_val ] ) : NEW_LINE INDENT diff = 1 NEW_LINE DEDENT
updateValueUtil ( st , 0 , n - 1 , i , diff , 0 ) NEW_LINE
def queryPrimes ( st , n , qs , qe ) : NEW_LINE INDENT primesInRange = queryPrimesUtil ( st , 0 , n - 1 , qs , qe , 0 ) NEW_LINE print ( " Number ▁ of ▁ Primes ▁ in ▁ subarray ▁ from ▁ " , qs , " ▁ to ▁ " , qe , " ▁ = ▁ " , primesInRange ) NEW_LINE DEDENT
def constructSTUtil ( arr , ss , se , st , si , isPrime ) : NEW_LINE
if ( ss == se ) : NEW_LINE
if ( isPrime [ arr [ ss ] ] ) : NEW_LINE INDENT st [ si ] = 1 NEW_LINE DEDENT else : NEW_LINE INDENT st [ si ] = 0 NEW_LINE DEDENT return st [ si ] NEW_LINE
mid = getMid ( ss , se ) NEW_LINE st [ si ] = constructSTUtil ( arr , ss , mid , st , si * 2 + 1 , isPrime ) + constructSTUtil ( arr , mid + 1 , se , st , si * 2 + 2 , isPrime ) NEW_LINE return st [ si ] NEW_LINE
def constructST ( arr , n , isPrime ) : NEW_LINE
x = ceil ( log ( n , 2 ) ) NEW_LINE
max_size = 2 * pow ( 2 , x ) - 1 NEW_LINE st = [ 0 ] * ( max_size ) NEW_LINE
constructSTUtil ( arr , 0 , n - 1 , st , 0 , isPrime ) NEW_LINE
return st NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 2 , 3 , 5 , 7 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE DEDENT
isPrime = [ True ] * ( MAX + 1 ) NEW_LINE sieveOfEratosthenes ( isPrime ) NEW_LINE
st = constructST ( arr , n , isPrime ) NEW_LINE
start = 0 NEW_LINE end = 4 NEW_LINE queryPrimes ( st , n , start , end ) NEW_LINE
i = 3 NEW_LINE x = 6 NEW_LINE updateValue ( arr , st , n , i , x , isPrime ) NEW_LINE
start = 0 NEW_LINE end = 4 NEW_LINE queryPrimes ( st , n , start , end ) NEW_LINE
def checkEVENodd ( arr , n , l , r ) : NEW_LINE
if ( arr [ r ] == 1 ) : NEW_LINE INDENT print ( " odd " ) NEW_LINE DEDENT
else : NEW_LINE INDENT print ( " even " ) NEW_LINE DEDENT
arr = [ 1 , 1 , 0 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE checkEVENodd ( arr , n , 1 , 3 ) NEW_LINE
def findMean ( arr , l , r ) : NEW_LINE
sum , count = 0 , 0 NEW_LINE
for i in range ( l , r + 1 ) : NEW_LINE INDENT sum += arr [ i ] NEW_LINE count += 1 NEW_LINE DEDENT
mean = math . floor ( sum / count ) NEW_LINE
return mean NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE print ( findMean ( arr , 0 , 2 ) ) NEW_LINE print ( findMean ( arr , 1 , 3 ) ) NEW_LINE print ( findMean ( arr , 0 , 4 ) ) NEW_LINE
import math as mt NEW_LINE MAX = 1000005 NEW_LINE prefixSum = [ 0 for i in range ( MAX ) ] NEW_LINE
def calculatePrefixSum ( arr , n ) : NEW_LINE
prefixSum [ 0 ] = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT prefixSum [ i ] = prefixSum [ i - 1 ] + arr [ i ] NEW_LINE DEDENT
def findMean ( l , r ) : NEW_LINE INDENT if ( l == 0 ) : NEW_LINE INDENT return mt . floor ( prefixSum [ r ] / ( r + 1 ) ) NEW_LINE DEDENT DEDENT
return ( mt . floor ( ( prefixSum [ r ] - prefixSum [ l - 1 ] ) / ( r - l + 1 ) ) ) NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE calculatePrefixSum ( arr , n ) NEW_LINE print ( findMean ( 0 , 2 ) ) NEW_LINE print ( findMean ( 1 , 3 ) ) NEW_LINE print ( findMean ( 0 , 4 ) ) NEW_LINE
def updateQuery ( arr , n , q , l , r , k ) : NEW_LINE
if ( q == 0 ) : NEW_LINE INDENT arr [ l - 1 ] += k NEW_LINE arr [ r ] += - k NEW_LINE DEDENT
else : NEW_LINE INDENT arr [ l - 1 ] += - k NEW_LINE arr [ r ] += k NEW_LINE DEDENT return NEW_LINE
def generateArray ( arr , n ) : NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT arr [ i ] += arr [ i - 1 ] NEW_LINE DEDENT return NEW_LINE
n = 5 NEW_LINE arr = [ 0 for i in range ( n + 1 ) ] NEW_LINE q = 0 ; l = 1 ; r = 3 ; k = 2 NEW_LINE updateQuery ( arr , n , q , l , r , k ) NEW_LINE q , l , r , k = 1 , 3 , 5 , 3 NEW_LINE updateQuery ( arr , n , q , l , r , k ) ; NEW_LINE q , l , r , k = 0 , 2 , 5 , 1 NEW_LINE updateQuery ( arr , n , q , l , r , k ) NEW_LINE
generateArray ( arr , n ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def calculateProduct ( A , L , R , P ) : NEW_LINE
L = L - 1 NEW_LINE R = R - 1 NEW_LINE ans = 1 NEW_LINE for i in range ( R + 1 ) : NEW_LINE INDENT ans = ans * A [ i ] NEW_LINE ans = ans % P NEW_LINE DEDENT return ans NEW_LINE
A = [ 1 , 2 , 3 , 4 , 5 , 6 ] NEW_LINE P = 229 NEW_LINE L = 2 NEW_LINE R = 5 NEW_LINE print ( calculateProduct ( A , L , R , P ) ) NEW_LINE L = 1 NEW_LINE R = 3 NEW_LINE print ( calculateProduct ( A , L , R , P ) ) NEW_LINE
def modInverse ( a , m ) : NEW_LINE INDENT m0 , x0 , x1 = m , 0 , 1 NEW_LINE if m == 1 : NEW_LINE INDENT return 0 NEW_LINE DEDENT while a > 1 : NEW_LINE DEDENT
q = a // m NEW_LINE t = m NEW_LINE
m , a = a % m , t NEW_LINE t = x0 NEW_LINE x0 = x1 - q * x0 NEW_LINE x1 = t NEW_LINE
if x1 < 0 : NEW_LINE INDENT x1 += m0 NEW_LINE DEDENT return x1 NEW_LINE
def calculate_Pre_Product ( A , N , P ) : NEW_LINE INDENT pre_product [ 0 ] = A [ 0 ] NEW_LINE for i in range ( 1 , N ) : NEW_LINE INDENT pre_product [ i ] = pre_product [ i - 1 ] * A [ i ] NEW_LINE pre_product [ i ] = pre_product [ i ] % P NEW_LINE DEDENT DEDENT
def calculate_inverse_product ( A , N , P ) : NEW_LINE INDENT inverse_product [ 0 ] = modInverse ( pre_product [ 0 ] , P ) NEW_LINE for i in range ( 1 , N ) : NEW_LINE INDENT inverse_product [ i ] = modInverse ( pre_product [ i ] , P ) NEW_LINE DEDENT DEDENT
def calculateProduct ( A , L , R , P ) : NEW_LINE
L = L - 1 NEW_LINE R = R - 1 NEW_LINE ans = 0 NEW_LINE if L == 0 : NEW_LINE INDENT ans = pre_product [ R ] NEW_LINE DEDENT else : NEW_LINE INDENT ans = pre_product [ R ] * inverse_product [ L - 1 ] NEW_LINE DEDENT return ans NEW_LINE
A = [ 1 , 2 , 3 , 4 , 5 , 6 ] NEW_LINE N = len ( A ) NEW_LINE
P = 113 NEW_LINE MAX = 100 NEW_LINE pre_product = [ None ] * ( MAX ) NEW_LINE inverse_product = [ None ] * ( MAX ) NEW_LINE
calculate_Pre_Product ( A , N , P ) NEW_LINE calculate_inverse_product ( A , N , P ) NEW_LINE
L , R = 2 , 5 NEW_LINE print ( calculateProduct ( A , L , R , P ) ) NEW_LINE L , R = 1 , 3 NEW_LINE print ( calculateProduct ( A , L , R , P ) ) NEW_LINE
MAX = 10000 NEW_LINE
prefix = [ 0 ] * ( MAX + 1 ) NEW_LINE def buildPrefix ( ) : NEW_LINE
prime = [ 1 ] * ( MAX + 1 ) NEW_LINE p = 2 NEW_LINE while ( p * p <= MAX ) : NEW_LINE
if ( prime [ p ] == 1 ) : NEW_LINE
i = p * 2 NEW_LINE while ( i <= MAX ) : NEW_LINE INDENT prime [ i ] = 0 NEW_LINE i += p NEW_LINE DEDENT p += 1 NEW_LINE
for p in range ( 2 , MAX + 1 ) : NEW_LINE INDENT prefix [ p ] = prefix [ p - 1 ] NEW_LINE if ( prime [ p ] == 1 ) : NEW_LINE INDENT prefix [ p ] += 1 NEW_LINE DEDENT DEDENT
def query ( L , R ) : NEW_LINE INDENT return prefix [ R ] - prefix [ L - 1 ] NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT buildPrefix ( ) NEW_LINE L = 5 NEW_LINE R = 10 NEW_LINE print ( query ( L , R ) ) NEW_LINE L = 1 NEW_LINE R = 10 NEW_LINE print ( query ( L , R ) ) NEW_LINE DEDENT
def command ( brr , a , b ) : NEW_LINE INDENT arr [ a ] ^= 1 NEW_LINE arr [ b + 1 ] ^= 1 NEW_LINE DEDENT
def process ( arr , n ) : NEW_LINE INDENT for k in range ( 1 , n + 1 , 1 ) : NEW_LINE INDENT arr [ k ] ^= arr [ k - 1 ] NEW_LINE DEDENT DEDENT
def result ( arr , n ) : NEW_LINE INDENT for k in range ( 1 , n + 1 , 1 ) : NEW_LINE INDENT print ( arr [ k ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = 5 NEW_LINE m = 3 NEW_LINE arr = [ 0 for i in range ( n + 2 ) ] NEW_LINE DEDENT
command ( arr , 1 , 5 ) NEW_LINE command ( arr , 2 , 5 ) NEW_LINE command ( arr , 3 , 5 ) NEW_LINE
process ( arr , n ) NEW_LINE
result ( arr , n ) NEW_LINE
def incrementByD ( arr , q_arr , n , m , d ) : NEW_LINE INDENT sum = [ 0 for i in range ( n ) ] NEW_LINE DEDENT
for i in range ( m ) : NEW_LINE
sum [ q_arr [ i ] [ 0 ] ] += d NEW_LINE
if ( ( q_arr [ i ] [ 1 ] + 1 ) < n ) : NEW_LINE INDENT sum [ q_arr [ i ] [ 1 ] + 1 ] -= d NEW_LINE DEDENT
arr [ 0 ] += sum [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT sum [ i ] += sum [ i - 1 ] NEW_LINE arr [ i ] += sum [ i ] NEW_LINE DEDENT
def printArray ( arr , n ) : NEW_LINE INDENT for i in arr : NEW_LINE INDENT print ( i , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 3 , 5 , 4 , 8 , 6 , 1 ] NEW_LINE q_arr = [ [ 0 , 3 ] , [ 4 , 5 ] , [ 1 , 4 ] , [ 0 , 1 ] , [ 2 , 5 ] ] NEW_LINE n = len ( arr ) NEW_LINE m = len ( q_arr ) NEW_LINE d = 2 NEW_LINE print ( " Original ▁ Array : " ) NEW_LINE printArray ( arr , n ) NEW_LINE
incrementByD ( arr , q_arr , n , m , d ) NEW_LINE print ( " Modified Array : " ) NEW_LINE printArray ( arr , n ) NEW_LINE
def prefixXOR ( arr , preXOR , n ) : NEW_LINE
for i in range ( 0 , n , 1 ) : NEW_LINE INDENT while ( arr [ i ] % 2 != 1 ) : NEW_LINE INDENT arr [ i ] = int ( arr [ i ] / 2 ) NEW_LINE DEDENT preXOR [ i ] = arr [ i ] NEW_LINE DEDENT
for i in range ( 1 , n , 1 ) : NEW_LINE INDENT preXOR [ i ] = preXOR [ i - 1 ] ^ preXOR [ i ] NEW_LINE DEDENT
def query ( preXOR , l , r ) : NEW_LINE INDENT if ( l == 0 ) : NEW_LINE INDENT return preXOR [ r ] NEW_LINE DEDENT else : NEW_LINE INDENT return preXOR [ r ] ^ preXOR [ l - 1 ] NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 3 , 4 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE preXOR = [ 0 for i in range ( n ) ] NEW_LINE prefixXOR ( arr , preXOR , n ) NEW_LINE print ( query ( preXOR , 0 , 2 ) ) NEW_LINE print ( query ( preXOR , 1 , 2 ) ) NEW_LINE DEDENT
MAX = 100000 NEW_LINE
tree = [ 0 ] * MAX NEW_LINE
lazy = [ False ] * MAX NEW_LINE
def toggle ( node : int , st : int , en : int , us : int , ue : int ) : NEW_LINE
if lazy [ node ] : NEW_LINE
lazy [ node ] = False NEW_LINE tree [ node ] = en - st + 1 - tree [ node ] NEW_LINE
if st < en : NEW_LINE
lazy [ node << 1 ] = not lazy [ node << 1 ] NEW_LINE lazy [ 1 + ( node << 1 ) ] = not lazy [ 1 + ( node << 1 ) ] NEW_LINE
if st > en or us > en or ue < st : NEW_LINE INDENT return NEW_LINE DEDENT
if us <= st and en <= ue : NEW_LINE
tree [ node ] = en - st + 1 - tree [ node ] NEW_LINE
if st < en : NEW_LINE
lazy [ node << 1 ] = not lazy [ node << 1 ] NEW_LINE lazy [ 1 + ( node << 1 ) ] = not lazy [ 1 + ( node << 1 ) ] NEW_LINE return NEW_LINE
mid = ( st + en ) // 2 NEW_LINE toggle ( ( node << 1 ) , st , mid , us , ue ) NEW_LINE toggle ( ( node << 1 ) + 1 , mid + 1 , en , us , ue ) NEW_LINE
if st < en : NEW_LINE INDENT tree [ node ] = tree [ node << 1 ] + tree [ ( node << 1 ) + 1 ] NEW_LINE DEDENT
def countQuery ( node : int , st : int , en : int , qs : int , qe : int ) -> int : NEW_LINE
if st > en or qs > en or qe < st : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if lazy [ node ] : NEW_LINE
lazy [ node ] = False NEW_LINE tree [ node ] = en - st + 1 - tree [ node ] NEW_LINE
if st < en : NEW_LINE
lazy [ node << 1 ] = not lazy [ node << 1 ] NEW_LINE lazy [ ( node << 1 ) + 1 ] = not lazy [ ( node << 1 ) + 1 ] NEW_LINE
if qs <= st and en <= qe : NEW_LINE INDENT return tree [ node ] NEW_LINE DEDENT
mid = ( st + en ) // 2 NEW_LINE return countQuery ( ( node << 1 ) , st , mid , qs , qe ) + countQuery ( ( node << 1 ) + 1 , mid + 1 , en , qs , qe ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 5 NEW_LINE DEDENT
toggle ( 1 , 0 , n - 1 , 1 , 2 ) NEW_LINE
toggle ( 1 , 0 , n - 1 , 2 , 4 ) NEW_LINE
print ( countQuery ( 1 , 0 , n - 1 , 2 , 3 ) ) NEW_LINE
toggle ( 1 , 0 , n - 1 , 2 , 4 ) NEW_LINE
print ( countQuery ( 1 , 0 , n - 1 , 1 , 4 ) ) NEW_LINE
def probability ( a , b , size1 , size2 ) : NEW_LINE
max1 = - ( sys . maxsize - 1 ) NEW_LINE count1 = 0 NEW_LINE for i in range ( size1 ) : NEW_LINE INDENT if a [ i ] > max1 : NEW_LINE INDENT count1 = 1 NEW_LINE DEDENT elif a [ i ] == max1 : NEW_LINE INDENT count1 += 1 NEW_LINE DEDENT DEDENT
max2 = - ( sys . maxsize - 1 ) NEW_LINE count2 = 0 NEW_LINE for i in range ( size2 ) : NEW_LINE INDENT if b [ i ] > max2 : NEW_LINE INDENT max2 = b [ i ] NEW_LINE count2 = 1 NEW_LINE DEDENT elif b [ i ] == max2 : NEW_LINE INDENT count2 += 1 NEW_LINE DEDENT DEDENT
return round ( ( count1 * count2 ) / ( size1 * size2 ) , 6 ) NEW_LINE
a = [ 1 , 2 , 3 ] NEW_LINE b = [ 1 , 3 , 3 ] NEW_LINE size1 = len ( a ) NEW_LINE size2 = len ( b ) NEW_LINE print ( probability ( a , b , size1 , size2 ) ) NEW_LINE
def countDe ( arr , n ) : NEW_LINE INDENT i = 0 NEW_LINE DEDENT
v = arr . copy ( ) NEW_LINE
arr . sort ( ) NEW_LINE
count1 = 0 NEW_LINE i = 0 NEW_LINE while ( i < n ) : NEW_LINE INDENT if ( arr [ i ] != v [ i ] ) : NEW_LINE INDENT count1 = count1 + 1 NEW_LINE DEDENT i = i + 1 NEW_LINE DEDENT
arr . sort ( reverse = True ) NEW_LINE
count2 = 0 NEW_LINE i = 0 NEW_LINE while ( i < n ) : NEW_LINE INDENT if ( arr [ i ] != v [ i ] ) : NEW_LINE INDENT count2 = count2 + 1 NEW_LINE DEDENT i = i + 1 NEW_LINE DEDENT
return ( min ( count1 , count2 ) ) NEW_LINE
arr = [ 5 , 9 , 21 , 17 , 13 ] NEW_LINE n = 5 NEW_LINE print ( " Minimum ▁ Dearrangement ▁ = " , countDe ( arr , n ) ) NEW_LINE
def maxOfSegmentMins ( a , n , k ) : NEW_LINE
if k == 1 : NEW_LINE INDENT return min ( a ) NEW_LINE DEDENT if k == 2 : NEW_LINE INDENT return max ( a [ 0 ] , a [ n - 1 ] ) NEW_LINE DEDENT
return max ( a ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ - 10 , - 9 , - 8 , 2 , 7 , - 6 , - 5 ] NEW_LINE n = len ( a ) NEW_LINE k = 2 NEW_LINE print ( maxOfSegmentMins ( a , n , k ) ) NEW_LINE DEDENT
def printMinimumProduct ( arr , n ) : NEW_LINE
first_min = min ( arr [ 0 ] , arr [ 1 ] ) NEW_LINE second_min = max ( arr [ 0 ] , arr [ 1 ] ) NEW_LINE
for i in range ( 2 , n ) : NEW_LINE INDENT if ( arr [ i ] < first_min ) : NEW_LINE INDENT second_min = first_min NEW_LINE first_min = arr [ i ] NEW_LINE DEDENT elif ( arr [ i ] < second_min ) : NEW_LINE INDENT second_min = arr [ i ] NEW_LINE DEDENT DEDENT return first_min * second_min NEW_LINE
a = [ 11 , 8 , 5 , 7 , 5 , 100 ] NEW_LINE n = len ( a ) NEW_LINE print ( printMinimumProduct ( a , n ) ) NEW_LINE
def noOfTriples ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
count = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if arr [ i ] == arr [ 2 ] : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT
if arr [ 0 ] == arr [ 2 ] : NEW_LINE INDENT return ( count - 2 ) * ( count - 1 ) * ( count ) / 6 NEW_LINE DEDENT
elif arr [ 1 ] == arr [ 2 ] : NEW_LINE INDENT return ( count - 1 ) * ( count ) / 2 NEW_LINE DEDENT
return count NEW_LINE
arr = [ 1 , 3 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( noOfTriples ( arr , n ) ) NEW_LINE
def checkReverse ( arr , n ) : NEW_LINE
temp = [ 0 ] * n NEW_LINE for i in range ( n ) : NEW_LINE INDENT temp [ i ] = arr [ i ] NEW_LINE DEDENT
temp . sort ( ) NEW_LINE
for front in range ( n ) : NEW_LINE INDENT if temp [ front ] != arr [ front ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
for back in range ( n - 1 , - 1 , - 1 ) : NEW_LINE INDENT if temp [ back ] != arr [ back ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if front >= back : NEW_LINE INDENT return True NEW_LINE DEDENT
while front != back : NEW_LINE INDENT front += 1 NEW_LINE if arr [ front - 1 ] < arr [ front ] : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
arr = [ 1 , 2 , 5 , 4 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE if checkReverse ( arr , n ) == True : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def checkReverse ( arr , n ) : NEW_LINE INDENT if ( n == 1 ) : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT
i = 1 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if arr [ i - 1 ] < arr [ i ] : NEW_LINE INDENT if ( i == n ) : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
j = i NEW_LINE while ( j < n and arr [ j ] < arr [ j - 1 ] ) : NEW_LINE INDENT if ( i > 1 and arr [ j ] < arr [ i - 2 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT j += 1 NEW_LINE DEDENT if ( j == n ) : NEW_LINE INDENT return True NEW_LINE DEDENT
k = j NEW_LINE
if ( arr [ k ] < arr [ i - 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT while ( k > 1 and k < n ) : NEW_LINE INDENT if ( arr [ k ] < arr [ k - 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT k += 1 NEW_LINE DEDENT return True NEW_LINE
arr = [ 1 , 3 , 4 , 10 , 9 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE if checkReverse ( arr , n ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def MinOperation ( a , b , n ) : NEW_LINE
a . sort ( reverse = False ) NEW_LINE b . sort ( reverse = False ) NEW_LINE
result = 0 NEW_LINE
for i in range ( 0 , n , 1 ) : NEW_LINE INDENT if ( a [ i ] > b [ i ] ) : NEW_LINE INDENT result = result + abs ( a [ i ] - b [ i ] ) NEW_LINE DEDENT elif ( a [ i ] < b [ i ] ) : NEW_LINE INDENT result = result + abs ( a [ i ] - b [ i ] ) NEW_LINE DEDENT DEDENT return result NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 3 , 1 , 1 ] NEW_LINE b = [ 1 , 2 , 2 ] NEW_LINE n = len ( a ) NEW_LINE print ( MinOperation ( a , b , n ) ) NEW_LINE DEDENT
def sortExceptUandL ( a , l , u , n ) : NEW_LINE
b = [ 0 ] * ( n - ( u - l + 1 ) ) NEW_LINE for i in range ( 0 , l ) : NEW_LINE INDENT b [ i ] = a [ i ] NEW_LINE DEDENT for i in range ( u + 1 , n ) : NEW_LINE INDENT b [ l + ( i - ( u + 1 ) ) ] = a [ i ] NEW_LINE DEDENT
b . sort ( ) NEW_LINE
for i in range ( 0 , l ) : NEW_LINE INDENT a [ i ] = b [ i ] NEW_LINE DEDENT for i in range ( u + 1 , n ) : NEW_LINE INDENT a [ i ] = b [ l + ( i - ( u + 1 ) ) ] NEW_LINE DEDENT
a = [ 5 , 4 , 3 , 12 , 14 , 9 ] NEW_LINE n = len ( a ) NEW_LINE l = 2 NEW_LINE u = 4 NEW_LINE sortExceptUandL ( a , l , u , n ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( " { } ▁ " . format ( a [ i ] ) , end = " " ) NEW_LINE DEDENT
def sortExcept ( arr , k , n ) : NEW_LINE
arr [ k ] , arr [ - 1 ] = arr [ - 1 ] , arr [ k ] NEW_LINE
arr = sorted ( arr , key = lambda i : ( i is arr [ - 1 ] , i ) ) NEW_LINE
last = arr [ - 1 ] NEW_LINE
i = n - 1 NEW_LINE while i > k : NEW_LINE INDENT arr [ i ] = arr [ i - 1 ] NEW_LINE i -= 1 NEW_LINE DEDENT
arr [ k ] = last NEW_LINE return arr NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 10 , 4 , 11 , 7 , 6 , 20 ] NEW_LINE k = 2 NEW_LINE n = len ( a ) NEW_LINE a = sortExcept ( a , k , n ) NEW_LINE print ( " ▁ " . join ( list ( map ( str , a ) ) ) ) NEW_LINE DEDENT
def findMinSwaps ( arr , n ) : NEW_LINE
noOfZeroes = [ 0 ] * n NEW_LINE count = 0 NEW_LINE
noOfZeroes [ n - 1 ] = 1 - arr [ n - 1 ] NEW_LINE for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT noOfZeroes [ i ] = noOfZeroes [ i + 1 ] NEW_LINE if ( arr [ i ] == 0 ) : NEW_LINE INDENT noOfZeroes [ i ] = noOfZeroes [ i ] + 1 NEW_LINE DEDENT DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] == 1 ) : NEW_LINE INDENT count = count + noOfZeroes [ i ] NEW_LINE DEDENT DEDENT return count NEW_LINE
arr = [ 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findMinSwaps ( arr , n ) ) NEW_LINE
def minswaps ( arr ) : NEW_LINE INDENT count = 0 NEW_LINE num_unplaced_zeros = 0 NEW_LINE for index in range ( len ( arr ) - 1 , - 1 , - 1 ) : NEW_LINE INDENT if arr [ index ] == 0 : NEW_LINE INDENT num_unplaced_zeros += 1 NEW_LINE DEDENT else : NEW_LINE INDENT count += num_unplaced_zeros NEW_LINE DEDENT DEDENT return count NEW_LINE DEDENT
arr = [ 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 ] NEW_LINE print ( minswaps ( arr ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def push ( head_ref , new_data ) : NEW_LINE INDENT new_node = Node ( ) NEW_LINE new_node . data = new_data NEW_LINE new_node . next = head_ref NEW_LINE head_ref = new_node NEW_LINE return head_ref NEW_LINE DEDENT
def printList ( head ) : NEW_LINE INDENT while ( head != None ) : NEW_LINE INDENT print ( head . data , end = " - > " ) NEW_LINE head = head . next NEW_LINE DEDENT DEDENT
def sortlist ( arr , N , head ) : NEW_LINE
hash = dict ( ) NEW_LINE temp = head NEW_LINE while ( temp != None ) : NEW_LINE INDENT hash [ temp . data ] = hash . get ( temp . data , 0 ) + 1 NEW_LINE temp = temp . next NEW_LINE DEDENT temp = head NEW_LINE
for i in range ( N ) : NEW_LINE
frequency = hash . get ( arr [ i ] , 0 ) NEW_LINE while ( frequency > 0 ) : NEW_LINE INDENT frequency = frequency - 1 NEW_LINE DEDENT
temp . data = arr [ i ] NEW_LINE temp = temp . next NEW_LINE
head = None NEW_LINE arr = [ 5 , 1 , 3 , 2 , 8 ] NEW_LINE N = len ( arr ) NEW_LINE
head = push ( head , 3 ) NEW_LINE head = push ( head , 2 ) NEW_LINE head = push ( head , 5 ) NEW_LINE head = push ( head , 8 ) NEW_LINE head = push ( head , 5 ) NEW_LINE head = push ( head , 2 ) NEW_LINE head = push ( head , 1 ) NEW_LINE
sortlist ( arr , N , head ) NEW_LINE
print ( " Sorted ▁ List : " ) NEW_LINE printList ( head ) NEW_LINE
def printRepeating ( arr , size ) : NEW_LINE
s = set ( ) NEW_LINE for i in range ( size ) : NEW_LINE INDENT if arr [ i ] not in s : NEW_LINE INDENT s . add ( arr [ i ] ) NEW_LINE DEDENT DEDENT
for i in s : NEW_LINE INDENT print ( i , end = " ▁ " ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 3 , 2 , 2 , 1 ] NEW_LINE size = len ( arr ) NEW_LINE printRepeating ( arr , size ) NEW_LINE DEDENT
def maxPartitions ( arr , n ) : NEW_LINE INDENT ans = 0 ; max_so_far = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE DEDENT
max_so_far = max ( max_so_far , arr [ i ] ) NEW_LINE
if ( max_so_far == i ) : NEW_LINE INDENT ans += 1 NEW_LINE DEDENT return ans NEW_LINE
arr = [ 1 , 0 , 2 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxPartitions ( arr , n ) ) NEW_LINE
def rankify ( A ) : NEW_LINE
R = [ 0 for x in range ( len ( A ) ) ] NEW_LINE
for i in range ( len ( A ) ) : NEW_LINE INDENT ( r , s ) = ( 1 , 1 ) NEW_LINE for j in range ( len ( A ) ) : NEW_LINE INDENT if j != i and A [ j ] < A [ i ] : NEW_LINE INDENT r += 1 NEW_LINE DEDENT if j != i and A [ j ] == A [ i ] : NEW_LINE INDENT s += 1 NEW_LINE DEDENT DEDENT DEDENT
R [ i ] = r + ( s - 1 ) / 2 NEW_LINE return R NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT A = [ 1 , 2 , 5 , 2 , 1 , 25 , 2 ] NEW_LINE print ( A ) NEW_LINE print ( rankify ( A ) ) NEW_LINE DEDENT
def min_noOf_operation ( arr , n , k ) : NEW_LINE INDENT res = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT noOfSubtraction = 0 NEW_LINE if ( arr [ i ] > arr [ i - 1 ] ) : NEW_LINE DEDENT DEDENT
noOfSubtraction = ( arr [ i ] - arr [ i - 1 ] ) / k ; NEW_LINE
if ( ( arr [ i ] - arr [ i - 1 ] ) % k != 0 ) : NEW_LINE INDENT noOfSubtraction += 1 NEW_LINE DEDENT
arr [ i ] = arr [ i ] - k * noOfSubtraction NEW_LINE
res = res + noOfSubtraction NEW_LINE return int ( res ) NEW_LINE
arr = [ 1 , 1 , 2 , 3 ] NEW_LINE N = len ( arr ) NEW_LINE k = 5 NEW_LINE print ( min_noOf_operation ( arr , N , k ) ) NEW_LINE
def maxSum ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum += arr [ i ] * i NEW_LINE DEDENT return sum NEW_LINE
arr = [ 3 , 5 , 6 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxSum ( arr , n ) ) NEW_LINE
def countPairs ( a , n , k ) : NEW_LINE INDENT res = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( abs ( a [ j ] - a [ i ] ) < k ) : NEW_LINE INDENT res += 1 NEW_LINE DEDENT DEDENT DEDENT return res NEW_LINE DEDENT
a = [ 1 , 10 , 4 , 2 ] NEW_LINE k = 3 NEW_LINE n = len ( a ) NEW_LINE print ( countPairs ( a , n , k ) , end = " " ) NEW_LINE
def countPairs ( a , n , k ) : NEW_LINE
a . sort ( ) NEW_LINE res = 0 NEW_LINE for i in range ( n ) : NEW_LINE
j = i + 1 NEW_LINE while ( j < n and a [ j ] - a [ i ] < k ) : NEW_LINE INDENT res += 1 NEW_LINE j += 1 NEW_LINE DEDENT return res NEW_LINE
a = [ 1 , 10 , 4 , 2 ] NEW_LINE k = 3 NEW_LINE n = len ( a ) NEW_LINE print ( countPairs ( a , n , k ) , end = " " ) NEW_LINE
def sortedMerge ( a , b , res , n , m ) : NEW_LINE
a . sort ( ) NEW_LINE b . sort ( ) NEW_LINE
i , j , k = 0 , 0 , 0 NEW_LINE while ( i < n and j < m ) : NEW_LINE INDENT if ( a [ i ] <= b [ j ] ) : NEW_LINE INDENT res [ k ] = a [ i ] NEW_LINE i += 1 NEW_LINE k += 1 NEW_LINE DEDENT else : NEW_LINE INDENT res [ k ] = b [ j ] NEW_LINE j += 1 NEW_LINE k += 1 NEW_LINE DEDENT DEDENT
while ( i < n ) : NEW_LINE INDENT res [ k ] = a [ i ] NEW_LINE i += 1 NEW_LINE k += 1 NEW_LINE DEDENT
while ( j < m ) : NEW_LINE INDENT res [ k ] = b [ j ] NEW_LINE j += 1 NEW_LINE k += 1 NEW_LINE DEDENT
a = [ 10 , 5 , 15 ] NEW_LINE b = [ 20 , 3 , 2 , 12 ] NEW_LINE n = len ( a ) NEW_LINE m = len ( b ) NEW_LINE
res = [ 0 for i in range ( n + m ) ] NEW_LINE sortedMerge ( a , b , res , n , m ) NEW_LINE print " Sorted ▁ merged ▁ list ▁ : " NEW_LINE for i in range ( n + m ) : NEW_LINE INDENT print res [ i ] , NEW_LINE DEDENT
def findMaxPairs ( a , b , n , k ) : NEW_LINE
a . sort ( ) NEW_LINE
b . sort ( ) NEW_LINE
flag = [ False ] * n NEW_LINE
result = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT if ( abs ( a [ i ] - b [ j ] ) <= k and flag [ j ] == False ) : NEW_LINE DEDENT DEDENT
result += 1 NEW_LINE
flag [ j ] = True NEW_LINE
break NEW_LINE return result NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 10 , 15 , 20 ] NEW_LINE b = [ 17 , 12 , 24 ] NEW_LINE n = len ( a ) NEW_LINE k = 3 NEW_LINE print ( findMaxPairs ( a , b , n , k ) ) NEW_LINE DEDENT
def findMaxPairs ( a , b , n , k ) : NEW_LINE
a . sort ( ) NEW_LINE
b . sort ( ) NEW_LINE result = 0 NEW_LINE j = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if j < n : NEW_LINE INDENT if abs ( a [ i ] - b [ j ] ) <= k : NEW_LINE INDENT result += 1 NEW_LINE DEDENT DEDENT DEDENT
j += 1 NEW_LINE
elif a [ i ] > b [ j ] : NEW_LINE INDENT j += 1 NEW_LINE DEDENT return result NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 10 , 15 , 20 ] NEW_LINE b = [ 17 , 12 , 24 ] NEW_LINE n = len ( a ) NEW_LINE k = 3 NEW_LINE print ( findMaxPairs ( a , b , n , k ) ) NEW_LINE DEDENT
def sumOfMinAbsDifferences ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
sum = 0 NEW_LINE
sum += abs ( arr [ 0 ] - arr [ 1 ] ) ; NEW_LINE
sum += abs ( arr [ n - 1 ] - arr [ n - 2 ] ) ; NEW_LINE
for i in range ( 1 , n - 1 ) : NEW_LINE INDENT sum += min ( abs ( arr [ i ] - arr [ i - 1 ] ) , abs ( arr [ i ] - arr [ i + 1 ] ) ) NEW_LINE DEDENT
return sum ; NEW_LINE
arr = [ 5 , 10 , 1 , 4 , 8 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Sum ▁ = ▁ " , sumOfMinAbsDifferences ( arr , n ) ) NEW_LINE
def findSmallestDifference ( A , B , m , n ) : NEW_LINE
A . sort ( ) NEW_LINE B . sort ( ) NEW_LINE a = 0 NEW_LINE b = 0 NEW_LINE
result = sys . maxsize NEW_LINE
while ( a < m and b < n ) : NEW_LINE INDENT if ( abs ( A [ a ] - B [ b ] ) < result ) : NEW_LINE INDENT result = abs ( A [ a ] - B [ b ] ) NEW_LINE DEDENT DEDENT
if ( A [ a ] < B [ b ] ) : NEW_LINE INDENT a += 1 NEW_LINE DEDENT else : NEW_LINE INDENT b += 1 NEW_LINE DEDENT
return result NEW_LINE
A = [ 1 , 2 , 11 , 5 ] NEW_LINE
B = [ 4 , 12 , 19 , 23 , 127 , 235 ] NEW_LINE
m = len ( A ) NEW_LINE n = len ( B ) NEW_LINE
print ( findSmallestDifference ( A , B , m , n ) ) NEW_LINE
def arraySortedOrNot ( arr , n ) : NEW_LINE
if ( n == 0 or n == 1 ) : NEW_LINE INDENT return True NEW_LINE DEDENT
return ( arr [ n - 1 ] >= arr [ n - 2 ] and arraySortedOrNot ( arr , n - 1 ) ) NEW_LINE
arr = [ 20 , 23 , 23 , 45 , 78 , 88 ] NEW_LINE n = len ( arr ) NEW_LINE
if ( arraySortedOrNot ( arr , n ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def arraySortedOrNot ( arr , n ) : NEW_LINE
if ( n == 0 or n == 1 ) : NEW_LINE INDENT return True NEW_LINE DEDENT for i in range ( 1 , n ) : NEW_LINE
if ( arr [ i - 1 ] > arr [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT
return True NEW_LINE
arr = [ 20 , 23 , 23 , 45 , 78 , 88 ] NEW_LINE n = len ( arr ) NEW_LINE if ( arraySortedOrNot ( arr , n ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def findLarger ( arr , n ) : NEW_LINE
x = sorted ( arr ) NEW_LINE
for i in range ( n / 2 , n ) : NEW_LINE INDENT print ( x [ i ] ) , NEW_LINE DEDENT
arr = [ 1 , 3 , 6 , 1 , 0 , 9 ] NEW_LINE n = len ( arr ) ; NEW_LINE findLarger ( arr , n ) NEW_LINE
def minSwapsToSort ( arr , n ) : NEW_LINE
arrPos = [ [ 0 for x in range ( 2 ) ] for y in range ( n ) ] NEW_LINE for i in range ( n ) : NEW_LINE INDENT arrPos [ i ] [ 0 ] = arr [ i ] NEW_LINE arrPos [ i ] [ 1 ] = i NEW_LINE DEDENT
arrPos . sort ( ) NEW_LINE
vis = [ False ] * ( n ) NEW_LINE
ans = 0 NEW_LINE
for i in range ( n ) : NEW_LINE
if ( vis [ i ] or arrPos [ i ] [ 1 ] == i ) : NEW_LINE INDENT continue NEW_LINE DEDENT
cycle_size = 0 NEW_LINE j = i NEW_LINE while ( not vis [ j ] ) : NEW_LINE INDENT vis [ j ] = 1 NEW_LINE DEDENT
j = arrPos [ j ] [ 1 ] NEW_LINE cycle_size += 1 NEW_LINE
ans += ( cycle_size - 1 ) NEW_LINE
return ans NEW_LINE
def minSwapToMakeArraySame ( a , b , n ) : NEW_LINE
mp = { } NEW_LINE for i in range ( n ) : NEW_LINE INDENT mp [ b [ i ] ] = i NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT b [ i ] = mp [ a [ i ] ] NEW_LINE DEDENT
return minSwapsToSort ( b , n ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 3 , 6 , 4 , 8 ] NEW_LINE b = [ 4 , 6 , 8 , 3 ] NEW_LINE n = len ( a ) NEW_LINE print ( minSwapToMakeArraySame ( a , b , n ) ) NEW_LINE DEDENT
def findSingle ( ar , n ) : NEW_LINE
res = ar [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT res = res ^ ar [ i ] NEW_LINE DEDENT return res NEW_LINE
ar = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] NEW_LINE print " Element ▁ occurring ▁ once ▁ is " , findSingle ( ar , len ( ar ) ) NEW_LINE
def singleNumber ( nums ) : NEW_LINE
return 2 * sum ( set ( nums ) ) - sum ( nums ) NEW_LINE
a = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] NEW_LINE print ( int ( singleNumber ( a ) ) ) NEW_LINE a = [ 15 , 18 , 16 , 18 , 16 , 15 , 89 ] NEW_LINE print ( int ( singleNumber ( a ) ) ) NEW_LINE
def singleelement ( arr , n ) : NEW_LINE INDENT low = 0 NEW_LINE high = n - 2 NEW_LINE mid = 0 NEW_LINE while ( low <= high ) : NEW_LINE INDENT mid = ( low + high ) // 2 NEW_LINE if ( arr [ mid ] == arr [ mid ^ 1 ] ) : NEW_LINE INDENT low = mid + 1 NEW_LINE DEDENT else : NEW_LINE INDENT high = mid - 1 NEW_LINE DEDENT DEDENT return arr [ low ] NEW_LINE DEDENT
arr = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] NEW_LINE size = len ( arr ) NEW_LINE arr . sort ( ) NEW_LINE print ( singleelement ( arr , size ) ) NEW_LINE
def countTriplets ( arr , n , sum ) : NEW_LINE
ans = 0 NEW_LINE
for i in range ( 0 , n - 2 ) : NEW_LINE
for j in range ( i + 1 , n - 1 ) : NEW_LINE
for k in range ( j + 1 , n ) : NEW_LINE INDENT if ( arr [ i ] + arr [ j ] + arr [ k ] < sum ) : NEW_LINE INDENT ans += 1 NEW_LINE DEDENT DEDENT return ans NEW_LINE
arr = [ 5 , 1 , 3 , 4 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE sum = 12 NEW_LINE print ( countTriplets ( arr , n , sum ) ) NEW_LINE
def countTriplets ( arr , n , sum ) : NEW_LINE
arr . sort ( ) NEW_LINE
ans = 0 NEW_LINE
for i in range ( 0 , n - 2 ) : NEW_LINE
j = i + 1 NEW_LINE k = n - 1 NEW_LINE
while ( j < k ) : NEW_LINE
if ( arr [ i ] + arr [ j ] + arr [ k ] >= sum ) : NEW_LINE INDENT k = k - 1 NEW_LINE DEDENT
else : NEW_LINE
ans += ( k - j ) NEW_LINE j = j + 1 NEW_LINE return ans NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 5 , 1 , 3 , 4 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE sum = 12 NEW_LINE print ( countTriplets ( arr , n , sum ) ) NEW_LINE DEDENT
def countTriplets ( a , n ) : NEW_LINE
s = set ( ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT s . add ( a [ i ] ) NEW_LINE DEDENT
count = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n , 1 ) : NEW_LINE DEDENT
xr = a [ i ] ^ a [ j ] NEW_LINE
if ( xr in s and xr != a [ i ] and xr != a [ j ] ) : NEW_LINE INDENT count += 1 ; NEW_LINE DEDENT
return int ( count / 3 ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 1 , 3 , 5 , 10 , 14 , 15 ] NEW_LINE n = len ( a ) NEW_LINE print ( countTriplets ( a , n ) ) NEW_LINE DEDENT
def getMissingNo ( a , n ) : NEW_LINE INDENT i , total = 0 , 1 NEW_LINE for i in range ( 2 , n + 2 ) : NEW_LINE INDENT total += i NEW_LINE total -= a [ i - 2 ] NEW_LINE DEDENT return total NEW_LINE DEDENT
arr = [ 1 , 2 , 3 , 5 ] NEW_LINE print ( getMissingNo ( arr , len ( arr ) ) ) NEW_LINE
def getMissingNo ( a , n ) : NEW_LINE INDENT n_elements_sum = n * ( n + 1 ) // 2 NEW_LINE return n_elements_sum - sum ( a ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 1 , 2 , 4 , 5 , 6 ] NEW_LINE n = len ( a ) + 1 NEW_LINE miss = getMissingNo ( a , n ) NEW_LINE print ( miss ) NEW_LINE DEDENT
def countOccurrences ( arr , n , x ) : NEW_LINE INDENT res = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if x == arr [ i ] : NEW_LINE INDENT res += 1 NEW_LINE DEDENT DEDENT return res NEW_LINE DEDENT
arr = [ 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE x = 2 NEW_LINE print ( countOccurrences ( arr , n , x ) ) NEW_LINE
def binarySearch ( arr , l , r , x ) : NEW_LINE INDENT if ( r < l ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT mid = int ( l + ( r - l ) / 2 ) NEW_LINE DEDENT
if arr [ mid ] == x : NEW_LINE INDENT return mid NEW_LINE DEDENT
if arr [ mid ] > x : NEW_LINE INDENT return binarySearch ( arr , l , mid - 1 , x ) NEW_LINE DEDENT
return binarySearch ( arr , mid + 1 , r , x ) NEW_LINE
def countOccurrences ( arr , n , x ) : NEW_LINE INDENT ind = binarySearch ( arr , 0 , n - 1 , x ) NEW_LINE DEDENT
if ind == - 1 : NEW_LINE INDENT return 0 NEW_LINE DEDENT
count = 1 NEW_LINE left = ind - 1 NEW_LINE while ( left >= 0 and arr [ left ] == x ) : NEW_LINE INDENT count += 1 NEW_LINE left -= 1 NEW_LINE DEDENT
right = ind + 1 ; NEW_LINE while ( right < n and arr [ right ] == x ) : NEW_LINE INDENT count += 1 NEW_LINE right += 1 NEW_LINE DEDENT return count NEW_LINE
arr = [ 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE x = 2 NEW_LINE print ( countOccurrences ( arr , n , x ) ) NEW_LINE
def printClosest ( arr , n , x ) : NEW_LINE
res_l , res_r = 0 , 0 NEW_LINE
l , r , diff = 0 , n - 1 , MAX_VAL NEW_LINE
while r > l : NEW_LINE
if abs ( arr [ l ] + arr [ r ] - x ) < diff : NEW_LINE INDENT res_l = l NEW_LINE res_r = r NEW_LINE diff = abs ( arr [ l ] + arr [ r ] - x ) NEW_LINE DEDENT if arr [ l ] + arr [ r ] > x : NEW_LINE
r -= 1 NEW_LINE else : NEW_LINE
l += 1 NEW_LINE print ( ' The ▁ closest ▁ pair ▁ is ▁ { } ▁ and ▁ { } ' . format ( arr [ res_l ] , arr [ res_r ] ) ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 10 , 22 , 28 , 29 , 30 , 40 ] NEW_LINE n = len ( arr ) NEW_LINE x = 54 NEW_LINE printClosest ( arr , n , x ) NEW_LINE DEDENT
def constructTree ( n , d , h ) : NEW_LINE INDENT if d == 1 : NEW_LINE DEDENT
if n == 2 and h == 1 : NEW_LINE INDENT print ( "1 ▁ 2" ) NEW_LINE return 0 NEW_LINE DEDENT
print ( " - 1" ) NEW_LINE return 0 NEW_LINE if d > 2 * h : NEW_LINE print ( " - 1" ) NEW_LINE return 0 NEW_LINE
for i in range ( 1 , h + 1 ) : NEW_LINE INDENT print ( i , " ▁ " , i + 1 ) NEW_LINE DEDENT if d > h : NEW_LINE
print ( 1 , " ▁ " , h + 2 ) NEW_LINE for i in range ( h + 2 , d + 1 ) : NEW_LINE INDENT print ( i , " ▁ " , i + 1 ) NEW_LINE DEDENT
for i in range ( d + 1 , n ) : NEW_LINE INDENT k = 1 NEW_LINE if d == h : NEW_LINE INDENT k = 2 NEW_LINE DEDENT print ( k , " ▁ " , i + 1 ) NEW_LINE DEDENT
n = 5 NEW_LINE d = 3 NEW_LINE h = 2 NEW_LINE constructTree ( n , d , h ) NEW_LINE
def countOnes ( arr , low , high ) : NEW_LINE INDENT if high >= low : NEW_LINE DEDENT
mid = low + ( high - low ) // 2 NEW_LINE
if ( ( mid == high or arr [ mid + 1 ] == 0 ) and ( arr [ mid ] == 1 ) ) : NEW_LINE INDENT return mid + 1 NEW_LINE DEDENT
if arr [ mid ] == 1 : NEW_LINE INDENT return countOnes ( arr , ( mid + 1 ) , high ) NEW_LINE DEDENT
return countOnes ( arr , low , mid - 1 ) NEW_LINE return 0 NEW_LINE
arr = [ 1 , 1 , 1 , 1 , 0 , 0 , 0 ] NEW_LINE print ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is " , countOnes ( arr , 0 , len ( arr ) - 1 ) ) NEW_LINE
def findMissingUtil ( arr1 , arr2 , N ) : NEW_LINE
if N == 1 : NEW_LINE INDENT return arr1 [ 0 ] ; NEW_LINE DEDENT
if arr1 [ 0 ] != arr2 [ 0 ] : NEW_LINE INDENT return arr1 [ 0 ] NEW_LINE DEDENT
lo = 0 NEW_LINE hi = N - 1 NEW_LINE
while ( lo < hi ) : NEW_LINE INDENT mid = ( lo + hi ) / 2 NEW_LINE DEDENT
if arr1 [ mid ] == arr2 [ mid ] : NEW_LINE INDENT lo = mid NEW_LINE DEDENT else : NEW_LINE INDENT hi = mid NEW_LINE DEDENT
if lo == hi - 1 : NEW_LINE INDENT break NEW_LINE DEDENT
return arr1 [ hi ] NEW_LINE
def findMissing ( arr1 , arr2 , M , N ) : NEW_LINE INDENT if N == M - 1 : NEW_LINE INDENT print ( " Missing ▁ Element ▁ is " , findMissingUtil ( arr1 , arr2 , M ) ) NEW_LINE DEDENT elif M == N - 1 : NEW_LINE INDENT print ( " Missing ▁ Element ▁ is " , findMissingUtil ( arr2 , arr1 , N ) ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Invalid ▁ Input " ) NEW_LINE DEDENT DEDENT
arr1 = [ 1 , 4 , 5 , 7 , 9 ] NEW_LINE arr2 = [ 4 , 5 , 7 , 9 ] NEW_LINE M = len ( arr1 ) NEW_LINE N = len ( arr2 ) NEW_LINE findMissing ( arr1 , arr2 , M , N ) NEW_LINE
def findMissing ( arr1 , arr2 , M , N ) : NEW_LINE INDENT if ( M != N - 1 and N != M - 1 ) : NEW_LINE INDENT print ( " Invalid ▁ Input " ) NEW_LINE return NEW_LINE DEDENT DEDENT
res = 0 NEW_LINE for i in range ( 0 , M ) : NEW_LINE INDENT res = res ^ arr1 [ i ] ; NEW_LINE DEDENT for i in range ( 0 , N ) : NEW_LINE INDENT res = res ^ arr2 [ i ] NEW_LINE DEDENT print ( " Missing ▁ element ▁ is " , res ) NEW_LINE
arr1 = [ 4 , 1 , 5 , 9 , 7 ] NEW_LINE arr2 = [ 7 , 5 , 9 , 4 ] NEW_LINE M = len ( arr1 ) NEW_LINE N = len ( arr2 ) NEW_LINE findMissing ( arr1 , arr2 , M , N ) NEW_LINE
def findFourElements ( arr , n , X ) : NEW_LINE
mp = { } NEW_LINE for i in range ( n - 1 ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT mp [ arr [ i ] + arr [ j ] ] = [ i , j ] NEW_LINE DEDENT DEDENT
for i in range ( n - 1 ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT summ = arr [ i ] + arr [ j ] NEW_LINE DEDENT DEDENT
if ( X - summ ) in mp : NEW_LINE
p = mp [ X - summ ] NEW_LINE if ( p [ 0 ] != i and p [ 0 ] != j and p [ 1 ] != i and p [ 1 ] != j ) : NEW_LINE INDENT print ( arr [ i ] , " , ▁ " , arr [ j ] , " , ▁ " , arr [ p [ 0 ] ] , " , ▁ " , arr [ p [ 1 ] ] , sep = " " ) NEW_LINE return NEW_LINE DEDENT
arr = [ 10 , 20 , 30 , 40 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE X = 91 NEW_LINE
findFourElements ( arr , n , X ) NEW_LINE
def fourSum ( X , arr , Map , N ) : NEW_LINE
temp = [ 0 for i in range ( N ) ] NEW_LINE
for i in range ( N - 1 ) : NEW_LINE
for j in range ( i + 1 , N ) : NEW_LINE
curr_sum = arr [ i ] + arr [ j ] NEW_LINE
if ( X - curr_sum ) in Map : NEW_LINE
p = Map [ X - curr_sum ] NEW_LINE if ( p [ 0 ] != i and p [ 1 ] != i and p [ 0 ] != j and p [ 1 ] != j and temp [ p [ 0 ] ] == 0 and temp [ p [ 1 ] ] == 0 and temp [ i ] == 0 and temp [ j ] == 0 ) : NEW_LINE
print ( arr [ i ] , " , " , arr [ j ] , " , " , arr [ p [ 0 ] ] , " , " , arr [ p [ 1 ] ] , sep = " " ) NEW_LINE temp [ p [ 1 ] ] = 1 NEW_LINE temp [ i ] = 1 NEW_LINE temp [ j ] = 1 NEW_LINE break NEW_LINE
def twoSum ( nums , N ) : NEW_LINE INDENT Map = { } NEW_LINE for i in range ( N - 1 ) : NEW_LINE INDENT for j in range ( i + 1 , N ) : NEW_LINE INDENT Map [ nums [ i ] + nums [ j ] ] = [ ] NEW_LINE Map [ nums [ i ] + nums [ j ] ] . append ( i ) NEW_LINE Map [ nums [ i ] + nums [ j ] ] . append ( j ) NEW_LINE DEDENT DEDENT return Map NEW_LINE DEDENT
arr = [ 10 , 20 , 30 , 40 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE X = 91 NEW_LINE Map = twoSum ( arr , n ) NEW_LINE
fourSum ( X , arr , Map , n ) NEW_LINE
def search ( arr , n , x ) : NEW_LINE
i = 0 NEW_LINE while ( i < n ) : NEW_LINE
if ( arr [ i ] == x ) : NEW_LINE INDENT return i NEW_LINE DEDENT
i = i + abs ( arr [ i ] - x ) NEW_LINE print ( " number ▁ is ▁ not ▁ present ! " ) NEW_LINE return - 1 NEW_LINE
arr = [ 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE x = 3 NEW_LINE print ( " Element " , x , " ▁ is ▁ present ▁ at ▁ index ▁ " , search ( arr , n , 3 ) ) NEW_LINE
import sys NEW_LINE def thirdLargest ( arr , arr_size ) : NEW_LINE
if ( arr_size < 3 ) : NEW_LINE INDENT print ( " ▁ Invalid ▁ Input ▁ " ) NEW_LINE return NEW_LINE DEDENT
first = arr [ 0 ] NEW_LINE for i in range ( 1 , arr_size ) : NEW_LINE INDENT if ( arr [ i ] > first ) : NEW_LINE INDENT first = arr [ i ] NEW_LINE DEDENT DEDENT
second = - sys . maxsize NEW_LINE for i in range ( 0 , arr_size ) : NEW_LINE INDENT if ( arr [ i ] > second and arr [ i ] < first ) : NEW_LINE INDENT second = arr [ i ] NEW_LINE DEDENT DEDENT
third = - sys . maxsize NEW_LINE for i in range ( 0 , arr_size ) : NEW_LINE INDENT if ( arr [ i ] > third and arr [ i ] < second ) : NEW_LINE INDENT third = arr [ i ] NEW_LINE DEDENT DEDENT print ( " The ▁ Third ▁ Largest " , " element ▁ is " , third ) NEW_LINE
arr = [ 12 , 13 , 1 , 10 , 34 , 16 ] NEW_LINE n = len ( arr ) NEW_LINE thirdLargest ( arr , n ) NEW_LINE
import sys NEW_LINE def thirdLargest ( arr , arr_size ) : NEW_LINE
if ( arr_size < 3 ) : NEW_LINE INDENT print ( " ▁ Invalid ▁ Input ▁ " ) NEW_LINE return NEW_LINE DEDENT
first = arr [ 0 ] NEW_LINE second = - sys . maxsize NEW_LINE third = - sys . maxsize NEW_LINE
for i in range ( 1 , arr_size ) : NEW_LINE
if ( arr [ i ] > first ) : NEW_LINE INDENT third = second NEW_LINE second = first NEW_LINE first = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > second ) : NEW_LINE INDENT third = second NEW_LINE second = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > third ) : NEW_LINE INDENT third = arr [ i ] NEW_LINE DEDENT print ( " The ▁ third ▁ Largest " , " element ▁ is " , third ) NEW_LINE
arr = [ 12 , 13 , 1 , 10 , 34 , 16 ] NEW_LINE n = len ( arr ) NEW_LINE thirdLargest ( arr , n ) NEW_LINE
def checkPair ( arr , n ) : NEW_LINE INDENT s = set ( ) NEW_LINE sum = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT sum += arr [ i ] NEW_LINE DEDENT
if sum % 2 != 0 : NEW_LINE INDENT return False NEW_LINE DEDENT sum = sum / 2 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT val = sum - arr [ i ] NEW_LINE if arr [ i ] not in s : NEW_LINE INDENT s . add ( arr [ i ] ) NEW_LINE DEDENT DEDENT
if val in s : NEW_LINE INDENT print ( " Pair ▁ elements ▁ are " , arr [ i ] , " and " , int ( val ) ) NEW_LINE DEDENT
arr = [ 2 , 11 , 5 , 1 , 4 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE if checkPair ( arr , n ) == False : NEW_LINE INDENT print ( " No ▁ pair ▁ found " ) NEW_LINE DEDENT
def search ( arr , n , x ) : NEW_LINE
if ( arr [ n - 1 ] == x ) : NEW_LINE INDENT return " Found " NEW_LINE DEDENT backup = arr [ n - 1 ] NEW_LINE arr [ n - 1 ] = x NEW_LINE
i = 0 NEW_LINE while ( i < n ) : NEW_LINE
if ( arr [ i ] == x ) : NEW_LINE
arr [ n - 1 ] = backup NEW_LINE
if ( i < n - 1 ) : NEW_LINE INDENT return " Found " NEW_LINE DEDENT
return " Not ▁ Found " NEW_LINE i = i + 1 NEW_LINE
arr = [ 4 , 6 , 1 , 5 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE x = 1 NEW_LINE print ( search ( arr , n , x ) ) NEW_LINE
def sequence ( a ) : NEW_LINE INDENT if ( len ( a ) == 0 ) : NEW_LINE INDENT return [ 0 , 0 ] NEW_LINE DEDENT s = 0 NEW_LINE e = len ( a ) - 1 NEW_LINE while ( s < e ) : NEW_LINE INDENT m = ( s + e ) // 2 NEW_LINE DEDENT DEDENT
if ( a [ m ] >= m + a [ 0 ] ) : NEW_LINE INDENT s = m + 1 NEW_LINE DEDENT
else : NEW_LINE INDENT e = m NEW_LINE DEDENT return [ a [ s ] , len ( a ) - ( a [ len ( a ) - 1 ] - a [ 0 ] ) ] NEW_LINE
p = sequence ( [ 1 , 2 , 3 , 4 , 4 , 4 , 5 , 6 ] ) NEW_LINE print ( " Repeated ▁ element ▁ is " , p [ 0 ] , " , ▁ it ▁ appears " , p [ 1 ] , " times " ) NEW_LINE
def findMajority ( arr , n ) : NEW_LINE INDENT return arr [ int ( n / 2 ) ] NEW_LINE DEDENT
arr = [ 1 , 2 , 2 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findMajority ( arr , n ) ) NEW_LINE
def minAdjDifference ( arr , n ) : NEW_LINE INDENT if ( n < 2 ) : return NEW_LINE DEDENT
res = abs ( arr [ 1 ] - arr [ 0 ] ) NEW_LINE for i in range ( 2 , n ) : NEW_LINE INDENT res = min ( res , abs ( arr [ i ] - arr [ i - 1 ] ) ) NEW_LINE DEDENT
res = min ( res , abs ( arr [ n - 1 ] - arr [ 0 ] ) ) NEW_LINE print ( " Min ▁ Difference ▁ = ▁ " , res ) NEW_LINE
a = [ 10 , 12 , 13 , 15 , 10 ] NEW_LINE n = len ( a ) NEW_LINE minAdjDifference ( a , n ) NEW_LINE
MAX = 100000 NEW_LINE def Print3Smallest ( arr , n ) : NEW_LINE INDENT firstmin = MAX NEW_LINE secmin = MAX NEW_LINE thirdmin = MAX NEW_LINE for i in range ( 0 , n ) : NEW_LINE DEDENT
if arr [ i ] < firstmin : NEW_LINE INDENT thirdmin = secmin NEW_LINE secmin = firstmin NEW_LINE firstmin = arr [ i ] NEW_LINE DEDENT
elif arr [ i ] < secmin : NEW_LINE INDENT thirdmin = secmin NEW_LINE secmin = arr [ i ] NEW_LINE DEDENT
elif arr [ i ] < thirdmin : NEW_LINE INDENT thirdmin = arr [ i ] NEW_LINE DEDENT print ( " First ▁ min ▁ = ▁ " , firstmin ) NEW_LINE print ( " Second ▁ min ▁ = ▁ " , secmin ) NEW_LINE print ( " Third ▁ min ▁ = ▁ " , thirdmin ) NEW_LINE
arr = [ 4 , 9 , 1 , 32 , 12 ] NEW_LINE n = len ( arr ) NEW_LINE Print3Smallest ( arr , n ) NEW_LINE
def getMin ( arr , n ) : NEW_LINE INDENT if ( n == 1 ) : NEW_LINE INDENT return arr [ 0 ] NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT return min ( getMin ( arr [ 1 : ] , n - 1 ) , arr [ 0 ] ) NEW_LINE DEDENT def getMax ( arr , n ) : NEW_LINE if ( n == 1 ) : NEW_LINE INDENT return arr [ 0 ] NEW_LINE DEDENT
else : NEW_LINE INDENT return max ( getMax ( arr [ 1 : ] , n - 1 ) , arr [ 0 ] ) NEW_LINE DEDENT
arr = [ 12 , 1234 , 45 , 67 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ element ▁ of ▁ array : ▁ " , getMin ( arr , n ) ) ; NEW_LINE print ( " Maximum ▁ element ▁ of ▁ array : ▁ " , getMax ( arr , n ) ) ; NEW_LINE
def getMin ( arr , n ) : NEW_LINE INDENT return min ( arr ) NEW_LINE DEDENT def getMax ( arr , n ) : NEW_LINE INDENT return max ( arr ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 12 , 1234 , 45 , 67 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ element ▁ of ▁ array : ▁ " , getMin ( arr , n ) ) NEW_LINE print ( " Maximum ▁ element ▁ of ▁ array : ▁ " , getMax ( arr , n ) ) NEW_LINE DEDENT
def findCounts ( arr , n ) : NEW_LINE
hash = [ 0 for i in range ( n ) ] NEW_LINE
i = 0 NEW_LINE while ( i < n ) : NEW_LINE
hash [ arr [ i ] - 1 ] += 1 NEW_LINE
i += 1 NEW_LINE print ( " Below ▁ are ▁ counts ▁ of ▁ all ▁ elements " ) NEW_LINE for i in range ( n ) : NEW_LINE print ( i + 1 , " - > " , hash [ i ] , end = " ▁ " ) NEW_LINE print ( ) NEW_LINE
arr = [ 2 , 3 , 3 , 2 , 5 ] NEW_LINE findCounts ( arr , len ( arr ) ) NEW_LINE arr1 = [ 1 ] NEW_LINE findCounts ( arr1 , len ( arr1 ) ) NEW_LINE arr3 = [ 4 , 4 , 4 , 4 ] NEW_LINE findCounts ( arr3 , len ( arr3 ) ) NEW_LINE arr2 = [ 1 , 3 , 5 , 7 , 9 , 1 , 3 , 5 , 7 , 9 , 1 ] NEW_LINE findCounts ( arr2 , len ( arr2 ) ) NEW_LINE arr4 = [ 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 ] NEW_LINE findCounts ( arr4 , len ( arr4 ) ) NEW_LINE arr5 = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 ] NEW_LINE findCounts ( arr5 , len ( arr5 ) ) NEW_LINE arr6 = [ 11 , 10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 ] NEW_LINE findCounts ( arr6 , len ( arr6 ) ) NEW_LINE
def findCounts ( arr , n ) : NEW_LINE
i = 0 NEW_LINE while i < n : NEW_LINE
if arr [ i ] <= 0 : NEW_LINE INDENT i += 1 NEW_LINE continue NEW_LINE DEDENT
elementIndex = arr [ i ] - 1 NEW_LINE
if arr [ elementIndex ] > 0 : NEW_LINE INDENT arr [ i ] = arr [ elementIndex ] NEW_LINE DEDENT
arr [ elementIndex ] = - 1 NEW_LINE else : NEW_LINE
arr [ elementIndex ] -= 1 NEW_LINE
arr [ i ] = 0 NEW_LINE i += 1 NEW_LINE print ( " Below ▁ are ▁ counts ▁ of ▁ all ▁ elements " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE print ( " % d ▁ - > ▁ % d " % ( i + 1 , abs ( arr [ i ] ) ) ) NEW_LINE print ( " " ) NEW_LINE
arr = [ 2 , 3 , 3 , 2 , 5 ] NEW_LINE findCounts ( arr , len ( arr ) ) NEW_LINE arr1 = [ 1 ] NEW_LINE findCounts ( arr1 , len ( arr1 ) ) NEW_LINE arr3 = [ 4 , 4 , 4 , 4 ] NEW_LINE findCounts ( arr3 , len ( arr3 ) ) NEW_LINE arr2 = [ 1 , 3 , 5 , 7 , 9 , 1 , 3 , 5 , 7 , 9 , 1 ] NEW_LINE findCounts ( arr2 , len ( arr2 ) ) NEW_LINE arr4 = [ 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 ] NEW_LINE findCounts ( arr4 , len ( arr4 ) ) NEW_LINE arr5 = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 ] NEW_LINE findCounts ( arr5 , len ( arr5 ) ) NEW_LINE arr6 = [ 11 , 10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 ] NEW_LINE findCounts ( arr6 , len ( arr6 ) ) NEW_LINE
def printfrequency ( arr , n ) : NEW_LINE
for j in range ( n ) : NEW_LINE INDENT arr [ j ] = arr [ j ] - 1 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT arr [ arr [ i ] % n ] = arr [ arr [ i ] % n ] + n NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT print ( i + 1 , " - > " , arr [ i ] // n ) NEW_LINE DEDENT
arr = [ 2 , 3 , 3 , 2 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE printfrequency ( arr , n ) NEW_LINE
def deleteElement ( arr , n , x ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] == x ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if ( i < n ) : NEW_LINE
n = n - 1 ; NEW_LINE for j in range ( i , n , 1 ) : NEW_LINE INDENT arr [ j ] = arr [ j + 1 ] NEW_LINE DEDENT return n NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 11 , 15 , 6 , 8 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE x = 6 NEW_LINE DEDENT
n = deleteElement ( arr , n , x ) NEW_LINE print ( " Modified ▁ array ▁ is " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def deleteElement ( arr , n , x ) : NEW_LINE
if arr [ n - 1 ] == x : NEW_LINE INDENT return n - 1 NEW_LINE DEDENT
prev = arr [ n - 1 ] NEW_LINE for i in range ( n - 2 , 1 , - 1 ) : NEW_LINE INDENT if arr [ i ] != x : NEW_LINE INDENT curr = arr [ i ] NEW_LINE arr [ i ] = prev NEW_LINE prev = curr NEW_LINE DEDENT DEDENT
if i < 0 : NEW_LINE INDENT return 0 NEW_LINE DEDENT
arr [ i ] = prev NEW_LINE return n - 1 NEW_LINE
arr = [ 11 , 15 , 6 , 8 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE x = 6 NEW_LINE
n = deleteElement ( arr , n , x ) NEW_LINE print ( " Modified ▁ array ▁ is " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def getInvCount ( arr , n ) : NEW_LINE
invcount = 0 NEW_LINE for i in range ( 1 , n - 1 ) : NEW_LINE
small = 0 NEW_LINE for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( arr [ i ] > arr [ j ] ) : NEW_LINE INDENT small += 1 NEW_LINE DEDENT DEDENT
great = 0 ; NEW_LINE for j in range ( i - 1 , - 1 , - 1 ) : NEW_LINE INDENT if ( arr [ i ] < arr [ j ] ) : NEW_LINE INDENT great += 1 NEW_LINE DEDENT DEDENT
invcount += great * small NEW_LINE return invcount NEW_LINE
arr = [ 8 , 4 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Inversion ▁ Count ▁ : " , getInvCount ( arr , n ) ) NEW_LINE
def maxWater ( arr , n ) : NEW_LINE
res = 0 ; NEW_LINE
for i in range ( 1 , n - 1 ) : NEW_LINE
left = arr [ i ] ; NEW_LINE for j in range ( i ) : NEW_LINE INDENT left = max ( left , arr [ j ] ) ; NEW_LINE DEDENT
right = arr [ i ] ; NEW_LINE for j in range ( i + 1 , n ) : NEW_LINE INDENT right = max ( right , arr [ j ] ) ; NEW_LINE DEDENT
res = res + ( min ( left , right ) - arr [ i ] ) ; NEW_LINE return res ; NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE print ( maxWater ( arr , n ) ) ; NEW_LINE DEDENT
def findWater ( arr , n ) : NEW_LINE
left = [ 0 ] * n NEW_LINE
right = [ 0 ] * n NEW_LINE
water = 0 NEW_LINE
left [ 0 ] = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT left [ i ] = max ( left [ i - 1 ] , arr [ i ] ) NEW_LINE DEDENT
right [ n - 1 ] = arr [ n - 1 ] NEW_LINE for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT right [ i ] = max ( right [ i + 1 ] , arr [ i ] ) ; NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT water += min ( left [ i ] , right [ i ] ) - arr [ i ] NEW_LINE DEDENT return water NEW_LINE
arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is " , findWater ( arr , n ) ) NEW_LINE
def findWater ( arr , n ) : NEW_LINE
result = 0 NEW_LINE
left_max = 0 NEW_LINE right_max = 0 NEW_LINE
lo = 0 NEW_LINE hi = n - 1 NEW_LINE while ( lo <= hi ) : NEW_LINE INDENT if ( arr [ lo ] < arr [ hi ] ) : NEW_LINE INDENT if ( arr [ lo ] > left_max ) : NEW_LINE DEDENT DEDENT
left_max = arr [ lo ] NEW_LINE else : NEW_LINE
result += left_max - arr [ lo ] NEW_LINE lo += 1 NEW_LINE else : NEW_LINE if ( arr [ hi ] > right_max ) : NEW_LINE
right_max = arr [ hi ] NEW_LINE else : NEW_LINE result += right_max - arr [ hi ] NEW_LINE hi -= 1 NEW_LINE return result NEW_LINE
arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " , findWater ( arr , n ) ) NEW_LINE
def maxWater ( arr , n ) : NEW_LINE INDENT size = n - 1 NEW_LINE DEDENT
prev = arr [ 0 ] NEW_LINE
prev_index = 0 NEW_LINE water = 0 NEW_LINE
temp = 0 NEW_LINE for i in range ( 1 , size + 1 ) : NEW_LINE
if ( arr [ i ] >= prev ) : NEW_LINE INDENT prev = arr [ i ] NEW_LINE prev_index = i NEW_LINE DEDENT
temp = 0 NEW_LINE else : NEW_LINE
water += prev - arr [ i ] NEW_LINE
temp += prev - arr [ i ] NEW_LINE
if ( prev_index < size ) : NEW_LINE
water -= temp NEW_LINE
prev = arr [ size ] NEW_LINE
for i in range ( size , prev_index - 1 , - 1 ) : NEW_LINE
if ( arr [ i ] >= prev ) : NEW_LINE INDENT prev = arr [ i ] NEW_LINE DEDENT else : NEW_LINE INDENT water += prev - arr [ i ] NEW_LINE DEDENT
return water NEW_LINE
arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxWater ( arr , n ) ) NEW_LINE
def maxWater ( arr , n ) : NEW_LINE
left = 0 NEW_LINE right = n - 1 NEW_LINE
l_max = 0 NEW_LINE r_max = 0 NEW_LINE
result = 0 NEW_LINE while ( left <= right ) : NEW_LINE
if r_max <= l_max : NEW_LINE
result += max ( 0 , r_max - arr [ right ] ) NEW_LINE
r_max = max ( r_max , arr [ right ] ) NEW_LINE
right -= 1 NEW_LINE else : NEW_LINE
result += max ( 0 , l_max - arr [ left ] ) NEW_LINE
l_max = max ( l_max , arr [ left ] ) NEW_LINE
left += 1 NEW_LINE return result NEW_LINE
arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxWater ( arr , n ) ) NEW_LINE
def missingK ( a , k , n ) : NEW_LINE INDENT difference = 0 NEW_LINE ans = 0 NEW_LINE count = k NEW_LINE flag = 0 NEW_LINE DEDENT
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT difference = 0 NEW_LINE DEDENT
if ( ( a [ i ] + 1 ) != a [ i + 1 ] ) : NEW_LINE
difference += ( a [ i + 1 ] - a [ i ] ) - 1 NEW_LINE
if ( difference >= count ) : NEW_LINE INDENT ans = a [ i ] + count NEW_LINE flag = 1 NEW_LINE break NEW_LINE DEDENT else : NEW_LINE INDENT count -= difference NEW_LINE DEDENT
if ( flag ) : NEW_LINE INDENT return ans NEW_LINE DEDENT else : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
a = [ 1 , 5 , 11 , 19 ] NEW_LINE
k = 11 NEW_LINE n = len ( a ) NEW_LINE
missing = missingK ( a , k , n ) NEW_LINE print ( missing ) NEW_LINE
median = 0 NEW_LINE i = 0 NEW_LINE j = 0 NEW_LINE
def maximum ( a , b ) : NEW_LINE INDENT return a if a > b else b NEW_LINE DEDENT
def minimum ( a , b ) : NEW_LINE INDENT return a if a < b else b NEW_LINE DEDENT
def findMedianSortedArrays ( a , n , b , m ) : NEW_LINE INDENT global median , i , j NEW_LINE min_index = 0 NEW_LINE max_index = n NEW_LINE while ( min_index <= max_index ) : NEW_LINE INDENT i = int ( ( min_index + max_index ) / 2 ) NEW_LINE j = int ( ( ( n + m + 1 ) / 2 ) - i ) NEW_LINE DEDENT DEDENT
if ( i < n and j > 0 and b [ j - 1 ] > a [ i ] ) : NEW_LINE INDENT min_index = i + 1 NEW_LINE DEDENT
elif ( i > 0 and j < m and b [ j ] < a [ i - 1 ] ) : NEW_LINE INDENT max_index = i - 1 NEW_LINE DEDENT
else : NEW_LINE
if ( i == 0 ) : NEW_LINE INDENT median = b [ j - 1 ] NEW_LINE DEDENT
elif ( j == 0 ) : NEW_LINE INDENT median = a [ i - 1 ] NEW_LINE DEDENT else : NEW_LINE INDENT median = maximum ( a [ i - 1 ] , b [ j - 1 ] ) NEW_LINE DEDENT break NEW_LINE
if ( ( n + m ) % 2 == 1 ) : NEW_LINE INDENT return median NEW_LINE DEDENT
if ( i == n ) : NEW_LINE INDENT return ( ( median + b [ j ] ) / 2.0 ) NEW_LINE DEDENT
if ( j == m ) : NEW_LINE INDENT return ( ( median + a [ i ] ) / 2.0 ) NEW_LINE DEDENT return ( ( median + minimum ( a [ i ] , b [ j ] ) ) / 2.0 ) NEW_LINE
a = [ 900 ] NEW_LINE b = [ 10 , 13 , 14 ] NEW_LINE n = len ( a ) NEW_LINE m = len ( b ) NEW_LINE
if ( n < m ) : NEW_LINE INDENT print ( " The ▁ median ▁ is ▁ : ▁ { } " . format ( findMedianSortedArrays ( a , n , b , m ) ) ) NEW_LINE DEDENT else : NEW_LINE INDENT echo ( " The ▁ median ▁ is ▁ : ▁ { } " . format ( findMedianSortedArrays ( b , m , a , n ) ) ) NEW_LINE DEDENT
def printUncommon ( arr1 , arr2 , n1 , n2 ) : NEW_LINE INDENT i = 0 NEW_LINE j = 0 NEW_LINE k = 0 NEW_LINE while ( i < n1 and j < n2 ) : NEW_LINE DEDENT
if ( arr1 [ i ] < arr2 [ j ] ) : NEW_LINE INDENT print ( arr1 [ i ] , end = " ▁ " ) NEW_LINE i = i + 1 NEW_LINE k = k + 1 NEW_LINE DEDENT elif ( arr2 [ j ] < arr1 [ i ] ) : NEW_LINE INDENT print ( arr2 [ j ] , end = " ▁ " ) NEW_LINE k = k + 1 NEW_LINE j = j + 1 NEW_LINE DEDENT
else : NEW_LINE INDENT i = i + 1 NEW_LINE j = j + 1 NEW_LINE DEDENT
while ( i < n1 ) : NEW_LINE INDENT print ( arr1 [ i ] , end = " ▁ " ) NEW_LINE i = i + 1 NEW_LINE k = k + 1 NEW_LINE DEDENT while ( j < n2 ) : NEW_LINE INDENT print ( arr2 [ j ] , end = " ▁ " ) NEW_LINE j = j + 1 NEW_LINE k = k + 1 NEW_LINE DEDENT
arr1 = [ 10 , 20 , 30 ] NEW_LINE arr2 = [ 20 , 25 , 30 , 40 , 50 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE n2 = len ( arr2 ) NEW_LINE printUncommon ( arr1 , arr2 , n1 , n2 ) NEW_LINE
def leastFrequent ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
min_count = n + 1 NEW_LINE res = - 1 NEW_LINE curr_count = 1 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] == arr [ i - 1 ] ) : NEW_LINE INDENT curr_count = curr_count + 1 NEW_LINE DEDENT else : NEW_LINE INDENT if ( curr_count < min_count ) : NEW_LINE INDENT min_count = curr_count NEW_LINE res = arr [ i - 1 ] NEW_LINE DEDENT curr_count = 1 NEW_LINE DEDENT DEDENT
if ( curr_count < min_count ) : NEW_LINE INDENT min_count = curr_count NEW_LINE res = arr [ n - 1 ] NEW_LINE DEDENT return res NEW_LINE
arr = [ 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( leastFrequent ( arr , n ) ) NEW_LINE
import math as mt NEW_LINE def leastFrequent ( arr , n ) : NEW_LINE
Hash = dict ( ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT if arr [ i ] in Hash . keys ( ) : NEW_LINE INDENT Hash [ arr [ i ] ] += 1 NEW_LINE DEDENT else : NEW_LINE INDENT Hash [ arr [ i ] ] = 1 NEW_LINE DEDENT DEDENT
min_count = n + 1 NEW_LINE res = - 1 NEW_LINE for i in Hash : NEW_LINE INDENT if ( min_count >= Hash [ i ] ) : NEW_LINE INDENT res = i NEW_LINE min_count = Hash [ i ] NEW_LINE DEDENT DEDENT return res NEW_LINE
arr = [ 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( leastFrequent ( arr , n ) ) NEW_LINE
M = 4 ; NEW_LINE
def maximumSum ( a , n ) : NEW_LINE INDENT global M ; NEW_LINE DEDENT
sum = a [ n - 1 ] [ M - 1 ] ; NEW_LINE prev = a [ n - 1 ] [ M - 1 ] ; NEW_LINE
for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT for j in range ( M - 1 , - 1 , - 1 ) : NEW_LINE INDENT if ( a [ i ] [ j ] < prev ) : NEW_LINE INDENT prev = a [ i ] [ j ] ; NEW_LINE sum += prev ; NEW_LINE break ; NEW_LINE DEDENT DEDENT DEDENT
if ( j == - 1 ) : NEW_LINE INDENT return 0 ; NEW_LINE DEDENT return sum ; NEW_LINE
arr = [ [ 1 , 7 , 3 , 4 ] , [ 4 , 2 , 5 , 1 ] , [ 9 , 5 , 1 , 8 ] ] ; NEW_LINE n = len ( arr ) ; NEW_LINE print ( maximumSum ( arr , n ) ) ; NEW_LINE
M = 4 NEW_LINE
def maximumSum ( a , n ) : NEW_LINE
prev = max ( max ( a ) ) NEW_LINE
Sum = prev NEW_LINE for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT max_smaller = - 10 ** 9 NEW_LINE for j in range ( M - 1 , - 1 , - 1 ) : NEW_LINE INDENT if ( a [ i ] [ j ] < prev and a [ i ] [ j ] > max_smaller ) : NEW_LINE INDENT max_smaller = a [ i ] [ j ] NEW_LINE DEDENT DEDENT DEDENT
if ( max_smaller == - 10 ** 9 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT prev = max_smaller NEW_LINE Sum += max_smaller NEW_LINE return Sum NEW_LINE
arr = [ [ 1 , 7 , 3 , 4 ] , [ 4 , 2 , 5 , 1 ] , [ 9 , 5 , 1 , 8 ] ] NEW_LINE n = len ( arr ) NEW_LINE print ( maximumSum ( arr , n ) ) NEW_LINE
def countPairs ( A , n , k ) : NEW_LINE INDENT ans = 0 NEW_LINE DEDENT
A . sort ( ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT
x = 0 NEW_LINE
while ( ( A [ i ] * math . pow ( k , x ) ) <= A [ j ] ) : NEW_LINE INDENT if ( ( A [ i ] * math . pow ( k , x ) ) == A [ j ] ) : NEW_LINE INDENT ans += 1 NEW_LINE break NEW_LINE DEDENT x += 1 NEW_LINE DEDENT return ans NEW_LINE
A = [ 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 ] NEW_LINE n = len ( A ) NEW_LINE k = 3 NEW_LINE print ( countPairs ( A , n , k ) ) NEW_LINE
def minDistance ( arr , n ) : NEW_LINE INDENT maximum_element = arr [ 0 ] NEW_LINE min_dis = n NEW_LINE index = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE DEDENT
if ( maximum_element == arr [ i ] ) : NEW_LINE INDENT min_dis = min ( min_dis , ( i - index ) ) NEW_LINE index = i NEW_LINE DEDENT
elif ( maximum_element < arr [ i ] ) : NEW_LINE INDENT maximum_element = arr [ i ] NEW_LINE min_dis = n NEW_LINE index = i NEW_LINE DEDENT
else : NEW_LINE INDENT continue NEW_LINE DEDENT return min_dis NEW_LINE
arr = [ 6 , 3 , 1 , 3 , 6 , 4 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ distance ▁ = " , minDistance ( arr , n ) ) NEW_LINE
def findValue ( arr , n , k ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] == k ) : NEW_LINE INDENT k = k * 2 NEW_LINE DEDENT DEDENT return k NEW_LINE
arr = [ 2 , 3 , 4 , 10 , 8 , 1 ] NEW_LINE k = 2 NEW_LINE n = len ( arr ) NEW_LINE print ( findValue ( arr , n , k ) ) NEW_LINE
def dupLastIndex ( arr , n ) : NEW_LINE
if ( arr == None or n <= 0 ) : NEW_LINE INDENT return NEW_LINE DEDENT
for i in range ( n - 1 , 0 , - 1 ) : NEW_LINE INDENT if ( arr [ i ] == arr [ i - 1 ] ) : NEW_LINE INDENT print ( " Last ▁ index : " , i ,   " Last " , ▁ " duplicate item : " , arr [ i ] ) NEW_LINE return NEW_LINE DEDENT DEDENT
print ( " no ▁ duplicate ▁ found " ) NEW_LINE
arr = [ 1 , 5 , 5 , 6 , 6 , 7 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE dupLastIndex ( arr , n ) NEW_LINE
def findSmallest ( a , n ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE INDENT if ( ( a [ j ] % a [ i ] ) >= 1 ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT
if ( j == n - 1 ) : NEW_LINE INDENT return a [ i ] NEW_LINE DEDENT return - 1 NEW_LINE
a = [ 25 , 20 , 5 , 10 , 100 ] NEW_LINE n = len ( a ) NEW_LINE print ( findSmallest ( a , n ) ) NEW_LINE
def min_element ( a ) : NEW_LINE INDENT m = 10000000 NEW_LINE for i in range ( 0 , len ( a ) ) : NEW_LINE INDENT if ( a [ i ] < m ) : NEW_LINE INDENT m = a [ i ] NEW_LINE DEDENT DEDENT return m NEW_LINE DEDENT
def findSmallest ( a , n ) : NEW_LINE
smallest = min_element ( a ) NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT if ( a [ i ] % smallest >= 1 ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT DEDENT return smallest NEW_LINE
a = [ 25 , 20 , 5 , 10 , 100 ] NEW_LINE n = len ( a ) NEW_LINE print ( findSmallest ( a , n ) ) NEW_LINE
def printMax ( arr , k , n ) : NEW_LINE
brr = arr . copy ( ) NEW_LINE
brr . sort ( reverse = True ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] in brr [ 0 : k ] ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 50 , 8 , 45 , 12 , 25 , 40 , 84 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE printMax ( arr , k , n ) NEW_LINE
def findIndex ( arr ) : NEW_LINE
maxIndex = 0 NEW_LINE for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT if ( arr [ i ] > arr [ maxIndex ] ) : NEW_LINE INDENT maxIndex = i NEW_LINE DEDENT DEDENT
for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT if ( maxIndex != i and arr [ maxIndex ] < ( 2 * arr [ i ] ) ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT DEDENT return maxIndex NEW_LINE
arr = [ 3 , 6 , 1 , 0 ] NEW_LINE print ( findIndex ( arr ) ) NEW_LINE
def find_consecutive_steps ( arr , len ) : NEW_LINE INDENT count = 0 ; maximum = 0 NEW_LINE for index in range ( 1 , len ) : NEW_LINE DEDENT
if ( arr [ index ] > arr [ index - 1 ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT else : NEW_LINE INDENT maximum = max ( maximum , count ) NEW_LINE count = 0 NEW_LINE DEDENT return max ( maximum , count ) NEW_LINE
arr = [ 1 , 2 , 3 , 4 ] NEW_LINE len = len ( arr ) NEW_LINE print ( find_consecutive_steps ( arr , len ) ) NEW_LINE
def CalculateMax ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE min_sum = arr [ 0 ] + arr [ 1 ] NEW_LINE max_sum = arr [ n - 1 ] + arr [ n - 2 ] NEW_LINE return abs ( max_sum - min_sum ) NEW_LINE
arr = [ 6 , 7 , 1 , 11 ] NEW_LINE n = len ( arr ) NEW_LINE print ( CalculateMax ( arr , n ) ) NEW_LINE
def calculate ( a , n ) : NEW_LINE
a . sort ( ) ; NEW_LINE
s = [ ] ; NEW_LINE i = 0 ; NEW_LINE j = n - 1 ; NEW_LINE while ( i < j ) : NEW_LINE INDENT s . append ( ( a [ i ] + a [ j ] ) ) ; NEW_LINE i += 1 ; NEW_LINE j -= 1 ; NEW_LINE DEDENT mini = min ( s ) ; NEW_LINE maxi = max ( s ) ; NEW_LINE return abs ( maxi - mini ) ; NEW_LINE
a = [ 2 , 6 , 4 , 3 ] ; NEW_LINE n = len ( a ) ; NEW_LINE print ( calculate ( a , n ) ) ; NEW_LINE
def printMinDiffPairs ( arr , n ) : NEW_LINE INDENT if n <= 1 : return NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
minDiff = arr [ 1 ] - arr [ 0 ] NEW_LINE for i in range ( 2 , n ) : NEW_LINE INDENT minDiff = min ( minDiff , arr [ i ] - arr [ i - 1 ] ) NEW_LINE DEDENT
for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] - arr [ i - 1 ] ) == minDiff : NEW_LINE INDENT print ( " ( " + str ( arr [ i - 1 ] ) + " , ▁ " + str ( arr [ i ] ) + " ) , ▁ " , end = ' ' ) NEW_LINE DEDENT DEDENT
arr = [ 5 , 3 , 2 , 4 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE printMinDiffPairs ( arr , n ) NEW_LINE
def calculateDiff ( i , j , arr ) : NEW_LINE
return abs ( arr [ i ] - arr [ j ] ) + abs ( i - j ) NEW_LINE
def maxDistance ( arr , n ) : NEW_LINE
result = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i , n ) : NEW_LINE DEDENT
if ( calculateDiff ( i , j , arr ) > result ) : NEW_LINE INDENT result = calculateDiff ( i , j , arr ) NEW_LINE DEDENT return result NEW_LINE
arr = [ - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxDistance ( arr , n ) ) NEW_LINE
def maxDistance ( array ) : NEW_LINE
max1 = - 2147483648 NEW_LINE min1 = + 2147483647 NEW_LINE max2 = - 2147483648 NEW_LINE min2 = + 2147483647 NEW_LINE for i in range ( len ( array ) ) : NEW_LINE
max1 = max ( max1 , array [ i ] + i ) NEW_LINE min1 = min ( min1 , array [ i ] + i ) NEW_LINE max2 = max ( max2 , array [ i ] - i ) NEW_LINE min2 = min ( min2 , array [ i ] - i ) NEW_LINE
return max ( max1 - min1 , max2 - min2 ) NEW_LINE
array = [ - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 ] NEW_LINE print ( maxDistance ( array ) ) NEW_LINE
def extrema ( a , n ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in range ( 1 , n - 1 ) : NEW_LINE
count += ( a [ i ] > a [ i - 1 ] and a [ i ] > a [ i + 1 ] ) ; NEW_LINE
count += ( a [ i ] < a [ i - 1 ] and a [ i ] < a [ i + 1 ] ) ; NEW_LINE return count NEW_LINE
a = [ 1 , 0 , 2 , 1 ] NEW_LINE n = len ( a ) NEW_LINE print ( extrema ( a , n ) ) NEW_LINE
def findClosest ( arr , n , target ) : NEW_LINE
if ( target <= arr [ 0 ] ) : NEW_LINE INDENT return arr [ 0 ] NEW_LINE DEDENT if ( target >= arr [ n - 1 ] ) : NEW_LINE INDENT return arr [ n - 1 ] NEW_LINE DEDENT
i = 0 ; j = n ; mid = 0 NEW_LINE while ( i < j ) : NEW_LINE INDENT mid = ( i + j ) // 2 NEW_LINE if ( arr [ mid ] == target ) : NEW_LINE INDENT return arr [ mid ] NEW_LINE DEDENT DEDENT
if ( target < arr [ mid ] ) : NEW_LINE
if ( mid > 0 and target > arr [ mid - 1 ] ) : NEW_LINE INDENT return getClosest ( arr [ mid - 1 ] , arr [ mid ] , target ) NEW_LINE DEDENT
j = mid NEW_LINE
else : NEW_LINE INDENT if ( mid < n - 1 and target < arr [ mid + 1 ] ) : NEW_LINE INDENT return getClosest ( arr [ mid ] , arr [ mid + 1 ] , target ) NEW_LINE DEDENT DEDENT
i = mid + 1 NEW_LINE
return arr [ mid ] NEW_LINE
def getClosest ( val1 , val2 , target ) : NEW_LINE INDENT if ( target - val1 >= val2 - target ) : NEW_LINE INDENT return val2 NEW_LINE DEDENT else : NEW_LINE INDENT return val1 NEW_LINE DEDENT DEDENT
arr = [ 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE target = 11 NEW_LINE print ( findClosest ( arr , n , target ) ) NEW_LINE
def _sum ( a , n ) : NEW_LINE
maxSum = - 9999999 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT maxSum = max ( maxSum , a [ i ] + a [ j ] ) NEW_LINE DEDENT DEDENT
c = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT if a [ i ] + a [ j ] == maxSum : NEW_LINE INDENT c += 1 NEW_LINE DEDENT DEDENT DEDENT return c NEW_LINE
array = [ 1 , 1 , 1 , 2 , 2 , 2 ] NEW_LINE n = len ( array ) NEW_LINE print ( _sum ( array , n ) ) NEW_LINE
def sum ( a , n ) : NEW_LINE
maxVal = a [ 0 ] ; maxCount = 1 NEW_LINE secondMax = sys . maxsize NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( a [ i ] == maxVal ) : NEW_LINE INDENT maxCount += 1 NEW_LINE DEDENT elif ( a [ i ] > maxVal ) : NEW_LINE INDENT secondMax = maxVal NEW_LINE secondMaxCount = maxCount NEW_LINE maxVal = a [ i ] NEW_LINE maxCount = 1 NEW_LINE DEDENT elif ( a [ i ] == secondMax ) : NEW_LINE INDENT secondMax = a [ i ] NEW_LINE secondMaxCount += 1 NEW_LINE DEDENT elif ( a [ i ] > secondMax ) : NEW_LINE INDENT secondMax = a [ i ] NEW_LINE secondMaxCount = 1 NEW_LINE DEDENT DEDENT
if ( maxCount > 1 ) : NEW_LINE INDENT return maxCount * ( maxCount - 1 ) / 2 NEW_LINE DEDENT
return secondMaxCount NEW_LINE
array = [ 1 , 1 , 1 , 2 , 2 , 2 , 3 ] NEW_LINE n = len ( array ) NEW_LINE print ( sum ( array , n ) ) NEW_LINE
def printSmall ( arr , asize , n ) : NEW_LINE
copy_arr = arr . copy ( ) NEW_LINE
copy_arr . sort ( ) NEW_LINE
for i in range ( asize ) : NEW_LINE INDENT if binary_search ( copy_arr , low = 0 , high = n , ele = arr [ i ] ) > - 1 : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 ] NEW_LINE asize = len ( arr ) NEW_LINE n = 5 NEW_LINE printSmall ( arr , asize , n ) NEW_LINE DEDENT
def printKMissing ( arr , n , k ) : NEW_LINE INDENT arr . sort ( ) NEW_LINE DEDENT
i = 0 NEW_LINE while ( i < n and arr [ i ] <= 0 ) : NEW_LINE INDENT i = i + 1 NEW_LINE DEDENT
count = 0 NEW_LINE curr = 1 NEW_LINE while ( count < k and i < n ) : NEW_LINE INDENT if ( arr [ i ] != curr ) : NEW_LINE INDENT print ( str ( curr ) + " ▁ " , end = ' ' ) NEW_LINE count = count + 1 NEW_LINE DEDENT else : NEW_LINE INDENT i = i + 1 NEW_LINE DEDENT curr = curr + 1 NEW_LINE DEDENT
while ( count < k ) : NEW_LINE INDENT print ( str ( curr ) + " ▁ " , end = ' ' ) NEW_LINE curr = curr + 1 NEW_LINE count = count + 1 NEW_LINE DEDENT
arr = [ 2 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE printKMissing ( arr , n , k ) ; NEW_LINE
def printmissingk ( arr , n , k ) : NEW_LINE
d = { } NEW_LINE
for i in range ( len ( arr ) ) : NEW_LINE INDENT d [ arr [ i ] ] = arr [ i ] NEW_LINE DEDENT cnt = 1 NEW_LINE fl = 0 NEW_LINE
for i in range ( n + k ) : NEW_LINE INDENT if cnt not in d : NEW_LINE INDENT fl += 1 NEW_LINE print ( cnt , end = " ▁ " ) NEW_LINE if fl == k : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT cnt += 1 NEW_LINE DEDENT print ( ) NEW_LINE
arr = [ 1 , 4 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE printmissingk ( arr , n , k ) NEW_LINE
def nobleInteger ( arr , size ) : NEW_LINE INDENT for i in range ( 0 , size ) : NEW_LINE INDENT count = 0 NEW_LINE for j in range ( 0 , size ) : NEW_LINE INDENT if ( arr [ i ] < arr [ j ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT DEDENT DEDENT
if ( count == arr [ i ] ) : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT return - 1 NEW_LINE
arr = [ 10 , 3 , 20 , 40 , 2 ] NEW_LINE size = len ( arr ) NEW_LINE res = nobleInteger ( arr , size ) NEW_LINE if ( res != - 1 ) : NEW_LINE INDENT print ( " The ▁ noble ▁ integer ▁ is ▁ " , res ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ Noble ▁ Integer ▁ Found " ) NEW_LINE DEDENT
def nobleInteger ( arr ) : NEW_LINE INDENT arr . sort ( ) NEW_LINE DEDENT
n = len ( arr ) NEW_LINE for i in range ( n - 1 ) : NEW_LINE INDENT if arr [ i ] == arr [ i + 1 ] : NEW_LINE INDENT continue NEW_LINE DEDENT DEDENT
if arr [ i ] == n - i - 1 : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT if arr [ n - 1 ] == 0 : NEW_LINE return arr [ n - 1 ] NEW_LINE return - 1 NEW_LINE
arr = [ 10 , 3 , 20 , 40 , 2 ] NEW_LINE res = nobleInteger ( arr ) NEW_LINE if res != - 1 : NEW_LINE INDENT print ( " The ▁ noble ▁ integer ▁ is " , res ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ Noble ▁ Integer ▁ Found " ) NEW_LINE DEDENT
def findMinSum ( a , b , n ) : NEW_LINE
a . sort ( ) NEW_LINE b . sort ( ) NEW_LINE
sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum = sum + abs ( a [ i ] - b [ i ] ) NEW_LINE DEDENT return sum NEW_LINE
a = [ 4 , 1 , 8 , 7 ] NEW_LINE b = [ 2 , 3 , 6 , 5 ] NEW_LINE n = len ( a ) NEW_LINE print ( findMinSum ( a , b , n ) ) NEW_LINE
def checkIsAP ( arr , n ) : NEW_LINE INDENT if ( n == 1 ) : return True NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
d = arr [ 1 ] - arr [ 0 ] NEW_LINE for i in range ( 2 , n ) : NEW_LINE INDENT if ( arr [ i ] - arr [ i - 1 ] != d ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
arr = [ 20 , 15 , 5 , 0 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Yes " ) if ( checkIsAP ( arr , n ) ) else print ( " No " ) NEW_LINE
def checkIsAP ( arr , n ) : NEW_LINE INDENT hm = { } NEW_LINE smallest = float ( ' inf ' ) NEW_LINE second_smallest = float ( ' inf ' ) NEW_LINE for i in range ( n ) : NEW_LINE DEDENT
if ( arr [ i ] < smallest ) : NEW_LINE INDENT second_smallest = smallest NEW_LINE smallest = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] != smallest and arr [ i ] < second_smallest ) : NEW_LINE INDENT second_smallest = arr [ i ] NEW_LINE DEDENT
if arr [ i ] not in hm : NEW_LINE INDENT hm [ arr [ i ] ] = 1 NEW_LINE DEDENT
else : NEW_LINE INDENT return False NEW_LINE DEDENT
diff = second_smallest - smallest NEW_LINE
for i in range ( n - 1 ) : NEW_LINE INDENT if ( second_smallest ) not in hm : NEW_LINE INDENT return False NEW_LINE DEDENT second_smallest += diff NEW_LINE DEDENT return True NEW_LINE
arr = [ 20 , 15 , 5 , 0 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE if ( checkIsAP ( arr , n ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def minProductSubset ( a , n ) : NEW_LINE INDENT if ( n == 1 ) : NEW_LINE INDENT return a [ 0 ] NEW_LINE DEDENT DEDENT
max_neg = float ( ' - inf ' ) NEW_LINE min_pos = float ( ' inf ' ) NEW_LINE count_neg = 0 NEW_LINE count_zero = 0 NEW_LINE prod = 1 NEW_LINE for i in range ( 0 , n ) : NEW_LINE
if ( a [ i ] == 0 ) : NEW_LINE INDENT count_zero = count_zero + 1 NEW_LINE continue NEW_LINE DEDENT
if ( a [ i ] < 0 ) : NEW_LINE INDENT count_neg = count_neg + 1 NEW_LINE max_neg = max ( max_neg , a [ i ] ) NEW_LINE DEDENT
if ( a [ i ] > 0 ) : NEW_LINE INDENT min_pos = min ( min_pos , a [ i ] ) NEW_LINE DEDENT prod = prod * a [ i ] NEW_LINE
if ( count_zero == n or ( count_neg == 0 and count_zero > 0 ) ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( count_neg == 0 ) : NEW_LINE INDENT return min_pos NEW_LINE DEDENT
if ( ( count_neg & 1 ) == 0 and count_neg != 0 ) : NEW_LINE
prod = int ( prod / max_neg ) NEW_LINE return prod NEW_LINE
a = [ - 1 , - 1 , - 2 , 4 , 3 ] NEW_LINE n = len ( a ) NEW_LINE print ( minProductSubset ( a , n ) ) NEW_LINE
def countPairs ( a , n ) : NEW_LINE
mn = + 2147483647 NEW_LINE mx = - 2147483648 NEW_LINE for i in range ( n ) : NEW_LINE INDENT mn = min ( mn , a [ i ] ) NEW_LINE mx = max ( mx , a [ i ] ) NEW_LINE DEDENT
c1 = 0 NEW_LINE
c2 = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( a [ i ] == mn ) : NEW_LINE INDENT c1 += 1 NEW_LINE DEDENT if ( a [ i ] == mx ) : NEW_LINE INDENT c2 += 1 NEW_LINE DEDENT DEDENT
if ( mn == mx ) : NEW_LINE INDENT return n * ( n - 1 ) // 2 NEW_LINE DEDENT else : NEW_LINE INDENT return c1 * c2 NEW_LINE DEDENT
a = [ 3 , 2 , 1 , 1 , 3 ] NEW_LINE n = len ( a ) NEW_LINE print ( countPairs ( a , n ) ) NEW_LINE
def binary_search ( a , x , lo = 0 , hi = None ) : NEW_LINE INDENT if hi is None : NEW_LINE INDENT hi = len ( a ) NEW_LINE DEDENT while lo < hi : NEW_LINE INDENT mid = ( lo + hi ) // 2 NEW_LINE midval = a [ mid ] NEW_LINE if midval < x : NEW_LINE INDENT lo = mid + 1 NEW_LINE DEDENT elif midval > x : NEW_LINE INDENT hi = mid NEW_LINE DEDENT else : NEW_LINE INDENT return mid NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT def findElement ( a , n , b ) : NEW_LINE
a . sort ( ) NEW_LINE
mx = a [ n - 1 ] NEW_LINE while ( b < max ) : NEW_LINE
if ( binary_search ( a , b , 0 , n ) != - 1 ) : NEW_LINE INDENT b *= 2 NEW_LINE DEDENT else : NEW_LINE INDENT return b NEW_LINE DEDENT return b NEW_LINE
a = [ 1 , 2 , 3 ] NEW_LINE n = len ( a ) NEW_LINE b = 1 NEW_LINE print findElement ( a , n , b ) NEW_LINE
Mod = 1000000007 NEW_LINE
def findSum ( arr , n ) : NEW_LINE INDENT sum = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
i = 0 NEW_LINE while i < n and arr [ i ] < 0 : NEW_LINE INDENT if i != n - 1 and arr [ i + 1 ] <= 0 : NEW_LINE INDENT sum = ( sum + ( arr [ i ] * arr [ i + 1 ] ) % Mod ) % Mod NEW_LINE i += 2 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
j = n - 1 NEW_LINE while j >= 0 and arr [ j ] > 0 : NEW_LINE INDENT if j != 0 and arr [ j - 1 ] > 0 : NEW_LINE INDENT sum = ( sum + ( arr [ j ] * arr [ j - 1 ] ) % Mod ) % Mod NEW_LINE j -= 2 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if j > i : NEW_LINE INDENT sum = ( sum + ( arr [ i ] * arr [ j ] ) % Mod ) % Mod NEW_LINE DEDENT
elif i == j : NEW_LINE INDENT sum = ( sum + arr [ i ] ) % Mod NEW_LINE DEDENT return sum NEW_LINE
arr = [ - 1 , 9 , 4 , 5 , - 4 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findSum ( arr , n ) ) NEW_LINE
def push ( self , new_data ) : NEW_LINE
new_node = Node ( new_data ) NEW_LINE
new_node . next = self . head NEW_LINE
self . head = new_node NEW_LINE
def insertAfter ( self , prev_node , new_data ) : NEW_LINE
if prev_node is None : NEW_LINE INDENT print " The ▁ given ▁ previous ▁ node ▁ must ▁ inLinkedList . " NEW_LINE return NEW_LINE DEDENT
new_node = Node ( new_data ) NEW_LINE
new_node . next = prev_node . next NEW_LINE
prev_node . next = new_node NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = next NEW_LINE DEDENT DEDENT
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = " ▁ " ) NEW_LINE node = node . next NEW_LINE DEDENT print ( " " ) NEW_LINE DEDENT
def newNode ( key ) : NEW_LINE INDENT temp = Node ( 0 ) NEW_LINE temp . data = key NEW_LINE temp . next = None NEW_LINE return temp NEW_LINE DEDENT
def insertBeg ( head , val ) : NEW_LINE INDENT temp = newNode ( val ) NEW_LINE temp . next = head NEW_LINE head = temp NEW_LINE return head NEW_LINE DEDENT
def rearrangeOddEven ( head ) : NEW_LINE INDENT odd = [ ] NEW_LINE even = [ ] NEW_LINE i = 1 NEW_LINE while ( head != None ) : NEW_LINE INDENT if ( head . data % 2 != 0 and i % 2 == 0 ) : NEW_LINE DEDENT DEDENT
odd . append ( head ) NEW_LINE elif ( head . data % 2 == 0 and i % 2 != 0 ) : NEW_LINE
even . append ( head ) NEW_LINE head = head . next NEW_LINE i = i + 1 NEW_LINE while ( len ( odd ) != 0 and len ( even ) != 0 ) : NEW_LINE
odd [ - 1 ] . data , even [ - 1 ] . data = even [ - 1 ] . data , odd [ - 1 ] . data NEW_LINE odd . pop ( ) NEW_LINE even . pop ( ) NEW_LINE return head NEW_LINE
head = newNode ( 8 ) NEW_LINE head = insertBeg ( head , 7 ) NEW_LINE head = insertBeg ( head , 6 ) NEW_LINE head = insertBeg ( head , 5 ) NEW_LINE head = insertBeg ( head , 3 ) NEW_LINE head = insertBeg ( head , 2 ) NEW_LINE head = insertBeg ( head , 1 ) NEW_LINE print ( " Linked ▁ List : " ) NEW_LINE printList ( head ) NEW_LINE rearrangeOddEven ( head ) NEW_LINE print ( " Linked ▁ List ▁ after ▁ " , " Rearranging : " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = " ▁ " ) NEW_LINE node = node . next NEW_LINE DEDENT print ( " ▁ " ) NEW_LINE DEDENT
def newNode ( key ) : NEW_LINE INDENT temp = Node ( ) NEW_LINE temp . data = key NEW_LINE temp . next = None NEW_LINE return temp NEW_LINE DEDENT
def insertBeg ( head , val ) : NEW_LINE INDENT temp = newNode ( val ) NEW_LINE temp . next = head NEW_LINE head = temp NEW_LINE return head NEW_LINE DEDENT
def rearrange ( head ) : NEW_LINE
even = None NEW_LINE temp = None NEW_LINE prev_temp = None NEW_LINE i = None NEW_LINE j = None NEW_LINE k = None NEW_LINE l = None NEW_LINE ptr = None NEW_LINE
temp = ( head ) . next NEW_LINE prev_temp = head NEW_LINE while ( temp != None ) : NEW_LINE
x = temp . next NEW_LINE
if ( temp . data % 2 != 0 ) : NEW_LINE INDENT prev_temp . next = x NEW_LINE temp . next = ( head ) NEW_LINE ( head ) = temp NEW_LINE DEDENT else : NEW_LINE INDENT prev_temp = temp NEW_LINE DEDENT
temp = x NEW_LINE
temp = ( head ) . next NEW_LINE prev_temp = ( head ) NEW_LINE while ( temp != None and temp . data % 2 != 0 ) : NEW_LINE INDENT prev_temp = temp NEW_LINE temp = temp . next NEW_LINE DEDENT even = temp NEW_LINE
prev_temp . next = None NEW_LINE
i = head NEW_LINE j = even NEW_LINE while ( j != None and i != None ) : NEW_LINE
k = i . next NEW_LINE l = j . next NEW_LINE i . next = j NEW_LINE j . next = k NEW_LINE
ptr = j NEW_LINE
i = k NEW_LINE j = l NEW_LINE if ( i == None ) : NEW_LINE
ptr . next = j NEW_LINE
return head NEW_LINE
head = newNode ( 8 ) NEW_LINE head = insertBeg ( head , 7 ) NEW_LINE head = insertBeg ( head , 6 ) NEW_LINE head = insertBeg ( head , 3 ) NEW_LINE head = insertBeg ( head , 5 ) NEW_LINE head = insertBeg ( head , 1 ) NEW_LINE head = insertBeg ( head , 2 ) NEW_LINE head = insertBeg ( head , 10 ) NEW_LINE print ( " Linked ▁ List : " ) NEW_LINE printList ( head ) NEW_LINE print ( " Rearranged ▁ List " ) NEW_LINE head = rearrange ( head ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . data = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def minDepth ( root ) : NEW_LINE
if root is None : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if root . left is None and root . right is None : NEW_LINE INDENT return 1 NEW_LINE DEDENT
if root . left is None : NEW_LINE INDENT return minDepth ( root . right ) + 1 NEW_LINE DEDENT
if root . right is None : NEW_LINE INDENT return minDepth ( root . left ) + 1 NEW_LINE DEDENT return min ( minDepth ( root . left ) , minDepth ( root . right ) ) + 1 NEW_LINE
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE print minDepth ( root ) NEW_LINE
def deleteAlt ( head ) : NEW_LINE INDENT if ( head == None ) : NEW_LINE INDENT return NEW_LINE DEDENT node = head . next NEW_LINE if ( node == None ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
head . next = node . next NEW_LINE
deleteAlt ( head . next ) NEW_LINE
def areIdentical ( a , b ) : NEW_LINE
if ( a == None and b == None ) : NEW_LINE INDENT return True NEW_LINE DEDENT
if ( a != None and b != None ) : NEW_LINE INDENT return ( ( a . data == b . data ) and areIdentical ( a . next , b . next ) ) NEW_LINE DEDENT
return False NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def rotate ( head_ref , k ) : NEW_LINE INDENT if ( k == 0 ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
current = head_ref NEW_LINE
while ( current . next != None ) : NEW_LINE INDENT current = current . next NEW_LINE DEDENT current . next = head_ref NEW_LINE current = head_ref NEW_LINE
for i in range ( k - 1 ) : NEW_LINE INDENT current = current . next NEW_LINE DEDENT
head_ref = current . next NEW_LINE current . next = None NEW_LINE return head_ref NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE
new_node = Node ( ) NEW_LINE
new_node . data = new_data NEW_LINE
new_node . next = ( head_ref ) NEW_LINE
( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = ' ▁ ' ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
for i in range ( 60 , 0 , - 10 ) : NEW_LINE INDENT head = push ( head , i ) NEW_LINE DEDENT print ( " Given ▁ linked ▁ list ▁ " ) NEW_LINE printList ( head ) NEW_LINE head = rotate ( head , 4 ) NEW_LINE print ( " Rotated Linked list   " ) NEW_LINE printList ( head ) NEW_LINE
self . head = None NEW_LINE
class Node ( object ) : NEW_LINE INDENT def __init__ ( self , d ) : NEW_LINE INDENT self . data = d NEW_LINE self . next = None NEW_LINE DEDENT DEDENT def sortList ( self ) : NEW_LINE
count = [ 0 , 0 , 0 ] NEW_LINE ptr = self . head NEW_LINE
while ptr != None : NEW_LINE INDENT count [ ptr . data ] += 1 NEW_LINE ptr = ptr . next NEW_LINE DEDENT i = 0 NEW_LINE ptr = self . head NEW_LINE
while ptr != None : NEW_LINE INDENT if count [ i ] == 0 : NEW_LINE INDENT i += 1 NEW_LINE DEDENT else : NEW_LINE INDENT ptr . data = i NEW_LINE count [ i ] -= 1 NEW_LINE ptr = ptr . next NEW_LINE DEDENT DEDENT
def push ( self , new_data ) : NEW_LINE
new_node = self . Node ( new_data ) NEW_LINE
new_node . next = self . head NEW_LINE
self . head = new_node NEW_LINE
def printList ( self ) : NEW_LINE INDENT temp = self . head NEW_LINE while temp != None : NEW_LINE INDENT print str ( temp . data ) , NEW_LINE temp = temp . next NEW_LINE DEDENT print ' ' NEW_LINE DEDENT
llist = LinkedList ( ) NEW_LINE llist . push ( 0 ) NEW_LINE llist . push ( 1 ) NEW_LINE llist . push ( 0 ) NEW_LINE llist . push ( 2 ) NEW_LINE llist . push ( 1 ) NEW_LINE llist . push ( 1 ) NEW_LINE llist . push ( 2 ) NEW_LINE llist . push ( 1 ) NEW_LINE llist . push ( 2 ) NEW_LINE print " Linked ▁ List ▁ before ▁ sorting " NEW_LINE llist . printList ( ) NEW_LINE llist . sortList ( ) NEW_LINE print " Linked ▁ List ▁ after ▁ sorting " NEW_LINE llist . printList ( ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE self . child = None NEW_LINE DEDENT DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def rearrange ( head ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT return head NEW_LINE DEDENT
prev , curr = head , head . next NEW_LINE while ( curr ) : NEW_LINE
if ( prev . data > curr . data ) : NEW_LINE INDENT prev . data , curr . data = curr . data , prev . data NEW_LINE DEDENT
if ( curr . next and curr . next . data > curr . data ) : NEW_LINE INDENT curr . next . data , curr . data = curr . data , curr . next . data NEW_LINE DEDENT prev = curr . next NEW_LINE if ( not curr . next ) : NEW_LINE INDENT break NEW_LINE DEDENT curr = curr . next . next NEW_LINE return head NEW_LINE
def push ( head , k ) : NEW_LINE INDENT tem = Node ( k ) NEW_LINE tem . data = k NEW_LINE tem . next = head NEW_LINE head = tem NEW_LINE return head NEW_LINE DEDENT
def display ( head ) : NEW_LINE INDENT curr = head NEW_LINE while ( curr != None ) : NEW_LINE INDENT print ( curr . data , end = " ▁ " ) NEW_LINE curr = curr . next NEW_LINE DEDENT DEDENT
head = push ( head , 7 ) NEW_LINE head = push ( head , 3 ) NEW_LINE head = push ( head , 8 ) NEW_LINE head = push ( head , 6 ) NEW_LINE head = push ( head , 9 ) NEW_LINE head = rearrange ( head ) NEW_LINE display ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . data = key NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
left = None NEW_LINE
def printlist ( head ) : NEW_LINE INDENT while ( head != None ) : NEW_LINE INDENT print ( head . data , end = " ▁ " ) NEW_LINE if ( head . next != None ) : NEW_LINE INDENT print ( " - > " , end = " " ) NEW_LINE DEDENT head = head . next NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
def rearrange ( head ) : NEW_LINE INDENT global left NEW_LINE if ( head != None ) : NEW_LINE INDENT left = head NEW_LINE reorderListUtil ( left ) NEW_LINE DEDENT DEDENT def reorderListUtil ( right ) : NEW_LINE INDENT global left NEW_LINE if ( right == None ) : NEW_LINE INDENT return NEW_LINE DEDENT reorderListUtil ( right . next ) NEW_LINE DEDENT
if ( left == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
if ( left != right and left . next != right ) : NEW_LINE INDENT temp = left . next NEW_LINE left . next = right NEW_LINE right . next = temp NEW_LINE left = temp NEW_LINE DEDENT else : NEW_LINE
if ( left . next == right ) : NEW_LINE
left . next . next = None NEW_LINE left = None NEW_LINE else : NEW_LINE
left . next = None NEW_LINE left = None NEW_LINE
head = Node ( 1 ) NEW_LINE head . next = Node ( 2 ) NEW_LINE head . next . next = Node ( 3 ) NEW_LINE head . next . next . next = Node ( 4 ) NEW_LINE head . next . next . next . next = Node ( 5 ) NEW_LINE
printlist ( head ) NEW_LINE
rearrange ( head ) NEW_LINE
printlist ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , d ) : NEW_LINE INDENT self . data = d NEW_LINE self . next = None NEW_LINE DEDENT DEDENT class LinkedList : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . head = None NEW_LINE DEDENT DEDENT
def newNode ( self , key ) : NEW_LINE INDENT temp = Node ( key ) NEW_LINE self . next = None NEW_LINE return temp NEW_LINE DEDENT
def rearrangeEvenOdd ( self , head ) : NEW_LINE
if ( self . head == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT
odd = self . head NEW_LINE even = self . head . next NEW_LINE
evenFirst = even NEW_LINE while ( 1 == 1 ) : NEW_LINE
if ( odd == None or even == None or ( even . next ) == None ) : NEW_LINE INDENT odd . next = evenFirst NEW_LINE break NEW_LINE DEDENT
odd . next = even . next NEW_LINE odd = even . next NEW_LINE
if ( odd . next == None ) : NEW_LINE INDENT even . next = None NEW_LINE odd . next = evenFirst NEW_LINE break NEW_LINE DEDENT
even . next = odd . next NEW_LINE even = odd . next NEW_LINE return head NEW_LINE
def printlist ( self , node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = " " ) NEW_LINE print ( " - > " , end = " " ) NEW_LINE node = node . next NEW_LINE DEDENT print ( " NULL " ) NEW_LINE DEDENT
ll = LinkedList ( ) NEW_LINE ll . push ( 5 ) NEW_LINE ll . push ( 4 ) NEW_LINE ll . push ( 3 ) NEW_LINE ll . push ( 2 ) NEW_LINE ll . push ( 1 ) NEW_LINE print ( " Given ▁ Linked ▁ List " ) NEW_LINE ll . printlist ( ll . head ) NEW_LINE start = ll . rearrangeEvenOdd ( ll . head ) NEW_LINE print ( " Modified Linked List " ) NEW_LINE ll . printlist ( start ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def newNode ( data ) : NEW_LINE INDENT new_node = Node ( 0 ) NEW_LINE new_node . data = data NEW_LINE new_node . next = None NEW_LINE return new_node NEW_LINE DEDENT
def addWithCarry ( head ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
res = head . data + addWithCarry ( head . next ) NEW_LINE
head . data = int ( ( res ) % 10 ) NEW_LINE return int ( ( res ) / 10 ) NEW_LINE
def addOne ( head ) : NEW_LINE
carry = addWithCarry ( head ) NEW_LINE
if ( carry != 0 ) : NEW_LINE INDENT newNode = Node ( 0 ) NEW_LINE newNode . data = carry NEW_LINE newNode . next = head NEW_LINE DEDENT
return newNode NEW_LINE return head NEW_LINE
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = " " ) NEW_LINE node = node . next NEW_LINE DEDENT print ( " " ) NEW_LINE DEDENT
head = newNode ( 1 ) NEW_LINE head . next = newNode ( 9 ) NEW_LINE head . next . next = newNode ( 9 ) NEW_LINE head . next . next . next = newNode ( 9 ) NEW_LINE print ( " List ▁ is ▁ " ) NEW_LINE printList ( head ) NEW_LINE head = addOne ( head ) NEW_LINE print ( " Resultant list is   " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE self . arbit = None NEW_LINE DEDENT DEDENT
def reverse ( head ) : NEW_LINE INDENT prev = None NEW_LINE current = head NEW_LINE next = None NEW_LINE while ( current != None ) : NEW_LINE INDENT next = current . next NEW_LINE current . next = prev NEW_LINE prev = current NEW_LINE current = next NEW_LINE DEDENT return prev NEW_LINE DEDENT
def populateArbit ( head ) : NEW_LINE
head = reverse ( head ) NEW_LINE
max = head NEW_LINE
temp = head . next NEW_LINE while ( temp != None ) : NEW_LINE
temp . arbit = max NEW_LINE
if ( max . data < temp . data ) : NEW_LINE INDENT max = temp NEW_LINE DEDENT
temp = temp . next NEW_LINE
return reverse ( head ) NEW_LINE
def printNextArbitPointers ( node ) : NEW_LINE INDENT print ( " Node Next Pointer Arbit Pointer " ) NEW_LINE while ( node != None ) : NEW_LINE INDENT print ( node . data , " TABSYMBOL TABSYMBOL " , end = " " ) NEW_LINE if ( node . next != None ) : NEW_LINE INDENT print ( node . next . data , " TABSYMBOL TABSYMBOL " , end = " " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " None " , " TABSYMBOL TABSYMBOL " , end = " " ) NEW_LINE DEDENT if ( node . arbit != None ) : NEW_LINE INDENT print ( node . arbit . data , end = " " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " None " , end = " " ) NEW_LINE DEDENT print ( " " ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
def newNode ( data ) : NEW_LINE INDENT new_node = Node ( 0 ) NEW_LINE new_node . data = data NEW_LINE new_node . next = None NEW_LINE return new_node NEW_LINE DEDENT
head = newNode ( 5 ) NEW_LINE head . next = newNode ( 10 ) NEW_LINE head . next . next = newNode ( 2 ) NEW_LINE head . next . next . next = newNode ( 3 ) NEW_LINE head = populateArbit ( head ) NEW_LINE print ( " Resultant Linked List is : " ) NEW_LINE printNextArbitPointers ( head ) NEW_LINE
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE self . arbit = None NEW_LINE DEDENT DEDENT
maxNode = newNode ( None ) NEW_LINE def populateArbit ( head ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
if ( head . next == None ) : NEW_LINE INDENT maxNode = head NEW_LINE return NEW_LINE DEDENT
populateArbit ( head . next ) NEW_LINE
head . arbit = maxNode NEW_LINE
if ( head . data > maxNode . data and maxNode . data != None ) : NEW_LINE INDENT maxNode = head NEW_LINE DEDENT return NEW_LINE
def printNextArbitPointers ( node ) : NEW_LINE INDENT print ( " Node TABSYMBOL Next ▁ Pointer TABSYMBOL Arbit ▁ Pointer " ) NEW_LINE while ( node != None ) : NEW_LINE INDENT print ( node . data , " TABSYMBOL TABSYMBOL " , end = " " ) NEW_LINE if ( node . next ) : NEW_LINE INDENT print ( node . next . data , " TABSYMBOL TABSYMBOL " , end = " " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " NULL " , " TABSYMBOL TABSYMBOL " , end = " " ) NEW_LINE DEDENT if ( node . arbit ) : NEW_LINE INDENT print ( node . arbit . data , end = " " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " NULL " , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
head = newNode ( 5 ) NEW_LINE head . next = newNode ( 10 ) NEW_LINE head . next . next = newNode ( 2 ) NEW_LINE head . next . next . next = newNode ( 3 ) NEW_LINE populateArbit ( head ) NEW_LINE print ( " Resultant ▁ Linked ▁ List ▁ is : " ) NEW_LINE printNextArbitPointers ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , new_data ) : NEW_LINE INDENT self . data = new_data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def deleteLast ( head , x ) : NEW_LINE INDENT temp = head NEW_LINE ptr = None NEW_LINE while ( temp != None ) : NEW_LINE DEDENT
if ( temp . data == x ) : NEW_LINE INDENT ptr = temp NEW_LINE DEDENT temp = temp . next NEW_LINE
if ( ptr != None and ptr . next == None ) : NEW_LINE INDENT temp = head NEW_LINE while ( temp . next != ptr ) : NEW_LINE INDENT temp = temp . next NEW_LINE DEDENT temp . next = None NEW_LINE DEDENT
if ( ptr != None and ptr . next != None ) : NEW_LINE INDENT ptr . data = ptr . next . data NEW_LINE temp = ptr . next NEW_LINE ptr . next = ptr . next . next NEW_LINE DEDENT return head NEW_LINE
def newNode ( x ) : NEW_LINE INDENT node = Node ( 0 ) NEW_LINE node . data = x NEW_LINE node . next = None NEW_LINE return node NEW_LINE DEDENT
def display ( head ) : NEW_LINE INDENT temp = head NEW_LINE if ( head == None ) : NEW_LINE INDENT print ( " None " ) NEW_LINE return NEW_LINE DEDENT while ( temp != None ) : NEW_LINE INDENT print ( temp . data , " ▁ - > ▁ " , end = " " ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( " None " ) NEW_LINE DEDENT
head = newNode ( 1 ) NEW_LINE head . next = newNode ( 2 ) NEW_LINE head . next . next = newNode ( 3 ) NEW_LINE head . next . next . next = newNode ( 4 ) NEW_LINE head . next . next . next . next = newNode ( 5 ) NEW_LINE head . next . next . next . next . next = newNode ( 4 ) NEW_LINE head . next . next . next . next . next . next = newNode ( 4 ) NEW_LINE print ( " Created ▁ Linked ▁ list : ▁ " ) NEW_LINE display ( head ) NEW_LINE head = deleteLast ( head , 4 ) NEW_LINE print ( " List ▁ after ▁ deletion ▁ of ▁ 4 : ▁ " ) NEW_LINE display ( head ) NEW_LINE
def flattenList2 ( head ) : NEW_LINE INDENT headcop = head NEW_LINE save = [ ] NEW_LINE save . append ( head ) NEW_LINE prev = None NEW_LINE while ( len ( save ) != 0 ) : NEW_LINE INDENT temp = save [ - 1 ] NEW_LINE save . pop ( ) NEW_LINE if ( temp . next ) : NEW_LINE INDENT save . append ( temp . next ) NEW_LINE DEDENT if ( temp . down ) : NEW_LINE INDENT save . append ( temp . down ) NEW_LINE DEDENT if ( prev != None ) : NEW_LINE INDENT prev . next = temp NEW_LINE DEDENT prev = temp NEW_LINE DEDENT return headcop NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , new_data ) : NEW_LINE INDENT self . data = new_data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT def newNode ( data ) : NEW_LINE INDENT temp = Node ( 0 ) NEW_LINE temp . data = data NEW_LINE temp . next = None NEW_LINE return temp NEW_LINE DEDENT
def getLength ( Node ) : NEW_LINE INDENT size = 0 NEW_LINE while ( Node != None ) : NEW_LINE INDENT Node = Node . next NEW_LINE size = size + 1 NEW_LINE DEDENT return size NEW_LINE DEDENT
def paddZeros ( sNode , diff ) : NEW_LINE INDENT if ( sNode == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT zHead = newNode ( 0 ) NEW_LINE diff = diff - 1 NEW_LINE temp = zHead NEW_LINE while ( diff > 0 ) : NEW_LINE INDENT diff = diff - 1 NEW_LINE temp . next = newNode ( 0 ) NEW_LINE temp = temp . next NEW_LINE DEDENT temp . next = sNode NEW_LINE return zHead NEW_LINE DEDENT borrow = True NEW_LINE
def subtractLinkedListHelper ( l1 , l2 ) : NEW_LINE INDENT global borrow NEW_LINE if ( l1 == None and l2 == None and not borrow ) : NEW_LINE INDENT return None NEW_LINE DEDENT l3 = None NEW_LINE l4 = None NEW_LINE if ( l1 != None ) : NEW_LINE INDENT l3 = l1 . next NEW_LINE DEDENT if ( l2 != None ) : NEW_LINE INDENT l4 = l2 . next NEW_LINE DEDENT previous = subtractLinkedListHelper ( l3 , l4 ) NEW_LINE d1 = l1 . data NEW_LINE d2 = l2 . data NEW_LINE sub = 0 NEW_LINE DEDENT
if ( borrow ) : NEW_LINE INDENT d1 = d1 - 1 NEW_LINE borrow = False NEW_LINE DEDENT
if ( d1 < d2 ) : NEW_LINE INDENT borrow = True NEW_LINE d1 = d1 + 10 NEW_LINE DEDENT
sub = d1 - d2 NEW_LINE
current = newNode ( sub ) NEW_LINE
current . next = previous NEW_LINE return current NEW_LINE
def subtractLinkedList ( l1 , l2 ) : NEW_LINE
if ( l1 == None and l2 == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT
len1 = getLength ( l1 ) NEW_LINE len2 = getLength ( l2 ) NEW_LINE lNode = None NEW_LINE sNode = None NEW_LINE temp1 = l1 NEW_LINE temp2 = l2 NEW_LINE
if ( len1 != len2 ) : NEW_LINE INDENT if ( len1 > len2 ) : NEW_LINE INDENT lNode = l1 NEW_LINE DEDENT else : NEW_LINE INDENT lNode = l2 NEW_LINE DEDENT if ( len1 > len2 ) : NEW_LINE INDENT sNode = l2 NEW_LINE DEDENT else : NEW_LINE INDENT sNode = l1 NEW_LINE DEDENT sNode = paddZeros ( sNode , abs ( len1 - len2 ) ) NEW_LINE DEDENT else : NEW_LINE
while ( l1 != None and l2 != None ) : NEW_LINE INDENT if ( l1 . data != l2 . data ) : NEW_LINE INDENT if ( l1 . data > l2 . data ) : NEW_LINE INDENT lNode = temp1 NEW_LINE DEDENT else : NEW_LINE INDENT lNode = temp2 NEW_LINE DEDENT if ( l1 . data > l2 . data ) : NEW_LINE INDENT sNode = temp2 NEW_LINE DEDENT else : NEW_LINE INDENT sNode = temp1 NEW_LINE DEDENT break NEW_LINE DEDENT l1 = l1 . next NEW_LINE l2 = l2 . next NEW_LINE DEDENT global borrow NEW_LINE
borrow = False NEW_LINE return subtractLinkedListHelper ( lNode , sNode ) NEW_LINE
def printList ( Node ) : NEW_LINE INDENT while ( Node != None ) : NEW_LINE INDENT print ( Node . data , end = " ▁ " ) NEW_LINE Node = Node . next NEW_LINE DEDENT print ( " ▁ " ) NEW_LINE DEDENT
head1 = newNode ( 1 ) NEW_LINE head1 . next = newNode ( 0 ) NEW_LINE head1 . next . next = newNode ( 0 ) NEW_LINE head2 = newNode ( 1 ) NEW_LINE result = subtractLinkedList ( head1 , head2 ) NEW_LINE printList ( result ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def newNode ( data ) : NEW_LINE INDENT new_node = Node ( ) NEW_LINE new_node . data = data NEW_LINE new_node . next = None NEW_LINE return new_node NEW_LINE DEDENT
def partition ( head , x ) : NEW_LINE
smallerHead = None NEW_LINE smallerLast = None NEW_LINE greaterLast = None NEW_LINE greaterHead = None NEW_LINE equalHead = None NEW_LINE equalLast = None NEW_LINE
while ( head != None ) : NEW_LINE
if ( head . data == x ) : NEW_LINE INDENT if ( equalHead == None ) : NEW_LINE INDENT equalHead = equalLast = head NEW_LINE DEDENT else : NEW_LINE INDENT equalLast . next = head NEW_LINE equalLast = equalLast . next NEW_LINE DEDENT DEDENT
elif ( head . data < x ) : NEW_LINE INDENT if ( smallerHead == None ) : NEW_LINE INDENT smallerLast = smallerHead = head NEW_LINE DEDENT else : NEW_LINE INDENT smallerLast . next = head NEW_LINE smallerLast = head NEW_LINE DEDENT DEDENT else : NEW_LINE
if ( greaterHead == None ) : NEW_LINE INDENT greaterLast = greaterHead = head NEW_LINE DEDENT else : NEW_LINE INDENT greaterLast . next = head NEW_LINE greaterLast = head NEW_LINE DEDENT head = head . next NEW_LINE
if ( greaterLast != None ) : NEW_LINE INDENT greaterLast . next = None NEW_LINE DEDENT
if ( smallerHead == None ) : NEW_LINE INDENT if ( equalHead == None ) : NEW_LINE INDENT return greaterHead NEW_LINE DEDENT equalLast . next = greaterHead NEW_LINE return equalHead NEW_LINE DEDENT
if ( equalHead == None ) : NEW_LINE INDENT smallerLast . next = greaterHead NEW_LINE return smallerHead NEW_LINE DEDENT
smallerLast . next = equalHead NEW_LINE equalLast . next = greaterHead NEW_LINE return smallerHead NEW_LINE
def printList ( head ) : NEW_LINE INDENT temp = head NEW_LINE while ( temp != None ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT DEDENT
head = newNode ( 10 ) NEW_LINE head . next = newNode ( 4 ) NEW_LINE head . next . next = newNode ( 5 ) NEW_LINE head . next . next . next = newNode ( 30 ) NEW_LINE head . next . next . next . next = newNode ( 2 ) NEW_LINE head . next . next . next . next . next = newNode ( 50 ) NEW_LINE x = 3 NEW_LINE head = partition ( head , x ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def getLoopstart ( loop_node , head ) : NEW_LINE INDENT ptr1 = loop_node NEW_LINE ptr2 = loop_node NEW_LINE DEDENT
k = 1 NEW_LINE i = 0 NEW_LINE while ( ptr1 . next != ptr2 ) : NEW_LINE INDENT ptr1 = ptr1 . next NEW_LINE k = k + 1 NEW_LINE DEDENT
ptr1 = head NEW_LINE
ptr2 = head NEW_LINE i = 0 NEW_LINE while ( i < k ) : NEW_LINE INDENT ptr2 = ptr2 . next NEW_LINE i = i + 1 NEW_LINE DEDENT
while ( ptr2 != ptr1 ) : NEW_LINE INDENT ptr1 = ptr1 . next NEW_LINE ptr2 = ptr2 . next NEW_LINE DEDENT return ptr1 NEW_LINE
def detectAndgetLoopstarting ( head ) : NEW_LINE INDENT slow_p = head NEW_LINE fast_p = head NEW_LINE loop_start = None NEW_LINE DEDENT
while ( slow_p != None and fast_p != None and fast_p . next != None ) : NEW_LINE INDENT slow_p = slow_p . next NEW_LINE fast_p = fast_p . next . next NEW_LINE DEDENT
if ( slow_p == fast_p ) : NEW_LINE INDENT loop_start = getLoopstart ( slow_p , head ) NEW_LINE break NEW_LINE DEDENT
return loop_start NEW_LINE
def isPalindromeUtil ( head , loop_start ) : NEW_LINE INDENT ptr = head NEW_LINE s = [ ] NEW_LINE DEDENT
count = 0 NEW_LINE while ( ptr != loop_start or count != 1 ) : NEW_LINE INDENT s . append ( ptr . data ) NEW_LINE if ( ptr == loop_start ) : NEW_LINE INDENT count = 1 NEW_LINE DEDENT ptr = ptr . next NEW_LINE DEDENT ptr = head NEW_LINE count = 0 NEW_LINE
while ( ptr != loop_start or count != 1 ) : NEW_LINE
if ( ptr . data == s [ - 1 ] ) : NEW_LINE INDENT s . pop ( ) NEW_LINE DEDENT
else : NEW_LINE INDENT return False NEW_LINE DEDENT if ( ptr == loop_start ) : NEW_LINE INDENT count = 1 NEW_LINE DEDENT ptr = ptr . next NEW_LINE
return True NEW_LINE
def isPalindrome ( head ) : NEW_LINE
loop_start = detectAndgetLoopstarting ( head ) NEW_LINE
return isPalindromeUtil ( head , loop_start ) NEW_LINE def newNode ( key ) : NEW_LINE temp = Node ( 0 ) NEW_LINE temp . data = key NEW_LINE temp . next = None NEW_LINE return temp NEW_LINE
head = newNode ( 50 ) NEW_LINE head . next = newNode ( 20 ) NEW_LINE head . next . next = newNode ( 15 ) NEW_LINE head . next . next . next = newNode ( 20 ) NEW_LINE head . next . next . next . next = newNode ( 50 ) NEW_LINE
head . next . next . next . next . next = head . next . next NEW_LINE if ( isPalindrome ( head ) == True ) : NEW_LINE INDENT print ( " Palindrome " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Not ▁ Palindrome " ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def countCommon ( a , b ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
while ( a != None and b != None ) : NEW_LINE
if ( a . data == b . data ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT a = a . next NEW_LINE b = b . next NEW_LINE return count NEW_LINE
def maxPalindrome ( head ) : NEW_LINE INDENT result = 0 NEW_LINE prev = None NEW_LINE curr = head NEW_LINE DEDENT
while ( curr != None ) : NEW_LINE
next = curr . next NEW_LINE curr . next = prev NEW_LINE
result = max ( result , 2 * countCommon ( prev , next ) + 1 ) NEW_LINE
result = max ( result , 2 * countCommon ( curr , next ) ) NEW_LINE
prev = curr NEW_LINE curr = next NEW_LINE return result NEW_LINE
def newNode ( key ) : NEW_LINE INDENT temp = Node ( 0 ) NEW_LINE temp . data = key NEW_LINE temp . next = None NEW_LINE return temp NEW_LINE DEDENT
head = newNode ( 2 ) NEW_LINE head . next = newNode ( 4 ) NEW_LINE head . next . next = newNode ( 3 ) NEW_LINE head . next . next . next = newNode ( 4 ) NEW_LINE head . next . next . next . next = newNode ( 2 ) NEW_LINE head . next . next . next . next . next = newNode ( 15 ) NEW_LINE print ( maxPalindrome ( head ) ) NEW_LINE
list = [ ] NEW_LINE
list . append ( 1 ) NEW_LINE list . append ( 2 ) NEW_LINE list . append ( 3 ) NEW_LINE
for it in list : NEW_LINE INDENT print ( it , end = ' ▁ ' ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def newNode ( x ) : NEW_LINE INDENT temp = Node ( 0 ) NEW_LINE temp . data = x NEW_LINE temp . next = None NEW_LINE return temp NEW_LINE DEDENT
def printList ( head ) : NEW_LINE INDENT temp = head NEW_LINE while ( temp != None ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
def moveToEnd ( head , key ) : NEW_LINE
pKey = head NEW_LINE
pCrawl = head NEW_LINE while ( pCrawl != None ) : NEW_LINE
if ( pCrawl != pKey and pCrawl . data != key ) : NEW_LINE INDENT pKey . data = pCrawl . data NEW_LINE pCrawl . data = key NEW_LINE pKey = pKey . next NEW_LINE DEDENT
if ( pKey . data != key ) : NEW_LINE INDENT pKey = pKey . next NEW_LINE DEDENT
pCrawl = pCrawl . next NEW_LINE return head NEW_LINE
head = newNode ( 10 ) NEW_LINE head . next = newNode ( 20 ) NEW_LINE head . next . next = newNode ( 10 ) NEW_LINE head . next . next . next = newNode ( 30 ) NEW_LINE head . next . next . next . next = newNode ( 40 ) NEW_LINE head . next . next . next . next . next = newNode ( 10 ) NEW_LINE head . next . next . next . next . next . next = newNode ( 60 ) NEW_LINE print ( " Before moveToEnd ( ) , the Linked list is " ) NEW_LINE printList ( head ) NEW_LINE key = 10 NEW_LINE head = moveToEnd ( head , key ) NEW_LINE print ( " After moveToEnd ( ) , the Linked list is " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT def newNode ( x ) : NEW_LINE INDENT temp = Node ( x ) NEW_LINE return temp NEW_LINE DEDENT
def keyToEnd ( head , key ) : NEW_LINE
tail = head NEW_LINE if ( head == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT while ( tail . next != None ) : NEW_LINE INDENT tail = tail . next NEW_LINE DEDENT
last = tail NEW_LINE current = head NEW_LINE prev = None NEW_LINE
prev2 = None NEW_LINE
while ( current != tail ) : NEW_LINE INDENT if ( current . data == key and prev2 == None ) : NEW_LINE INDENT prev = current NEW_LINE current = current . next NEW_LINE head = current NEW_LINE last . next = prev NEW_LINE last = last . next NEW_LINE last . next = None NEW_LINE prev = None NEW_LINE DEDENT else : NEW_LINE INDENT if ( current . data == key and prev2 != None ) : NEW_LINE INDENT prev = current NEW_LINE current = current . next NEW_LINE prev2 . next = current NEW_LINE last . next = prev NEW_LINE last = last . next NEW_LINE last . next = None NEW_LINE DEDENT elif ( current != tail ) : NEW_LINE INDENT prev2 = current NEW_LINE current = current . next NEW_LINE DEDENT DEDENT DEDENT return head NEW_LINE
def printList ( head ) : NEW_LINE INDENT temp = head NEW_LINE while ( temp != None ) : NEW_LINE INDENT print ( temp . data , end = ' ▁ ' ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = newNode ( 5 ) NEW_LINE root . next = newNode ( 2 ) NEW_LINE root . next . next = newNode ( 2 ) NEW_LINE root . next . next . next = newNode ( 7 ) NEW_LINE root . next . next . next . next = newNode ( 2 ) NEW_LINE root . next . next . next . next . next = newNode ( 2 ) NEW_LINE root . next . next . next . next . next . next = newNode ( 2 ) NEW_LINE key = 2 NEW_LINE print ( " Linked ▁ List ▁ before ▁ operations ▁ : " ) NEW_LINE printList ( root ) NEW_LINE print ( " Linked ▁ List ▁ after ▁ operations ▁ : " ) NEW_LINE root = keyToEnd ( root , key ) NEW_LINE printList ( root ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def freeList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT next = node . next NEW_LINE node = next NEW_LINE DEDENT return node NEW_LINE DEDENT
def deleteKthNode ( head , k ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT if ( k == 1 ) : NEW_LINE INDENT freeList ( head ) NEW_LINE return None NEW_LINE DEDENT
ptr = head NEW_LINE prev = None NEW_LINE
count = 0 NEW_LINE while ( ptr != None ) : NEW_LINE
count = count + 1 NEW_LINE
if ( k == count ) : NEW_LINE
prev . next = ptr . next NEW_LINE
count = 0 NEW_LINE
if ( count != 0 ) : NEW_LINE INDENT prev = ptr NEW_LINE DEDENT ptr = prev . next NEW_LINE return head NEW_LINE
def displayList ( head ) : NEW_LINE INDENT temp = head NEW_LINE while ( temp != None ) : NEW_LINE INDENT print ( temp . data , end = ' ▁ ' ) NEW_LINE temp = temp . next NEW_LINE DEDENT DEDENT
def newNode ( x ) : NEW_LINE INDENT temp = Node ( x ) NEW_LINE temp . data = x NEW_LINE temp . next = None NEW_LINE return temp NEW_LINE DEDENT
head = newNode ( 1 ) NEW_LINE head . next = newNode ( 2 ) NEW_LINE head . next . next = newNode ( 3 ) NEW_LINE head . next . next . next = newNode ( 4 ) NEW_LINE head . next . next . next . next = newNode ( 5 ) NEW_LINE head . next . next . next . next . next = newNode ( 6 ) NEW_LINE head . next . next . next . next . next . next = newNode ( 7 ) NEW_LINE head . next . next . next . next . next . next . next = newNode ( 8 ) NEW_LINE k = 3 NEW_LINE head = deleteKthNode ( head , k ) NEW_LINE displayList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , d ) : NEW_LINE INDENT self . data = d NEW_LINE self . next = None NEW_LINE self . head = None NEW_LINE DEDENT DEDENT
def LinkedListLength ( self ) : NEW_LINE INDENT while ( self . head != None and self . head . next != None ) : NEW_LINE INDENT self . head = self . head . next . next NEW_LINE DEDENT if ( self . head == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT return 1 NEW_LINE DEDENT
def push ( self , info ) : NEW_LINE
node = Node ( info ) NEW_LINE
node . next = ( self . head ) NEW_LINE
( self . head ) = node NEW_LINE
head = Node ( 0 ) NEW_LINE
head . push ( 4 ) NEW_LINE head . push ( 5 ) NEW_LINE head . push ( 7 ) NEW_LINE head . push ( 2 ) NEW_LINE head . push ( 9 ) NEW_LINE head . push ( 6 ) NEW_LINE head . push ( 1 ) NEW_LINE head . push ( 2 ) NEW_LINE head . push ( 0 ) NEW_LINE head . push ( 5 ) NEW_LINE head . push ( 5 ) NEW_LINE check = head . LinkedListLength ( ) NEW_LINE
if ( check == 0 ) : NEW_LINE INDENT print ( " Even " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Odd " ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT head = None NEW_LINE n = 0 NEW_LINE sum = 0 NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE INDENT global head NEW_LINE DEDENT
new_node = Node ( 0 ) NEW_LINE
new_node . data = new_data NEW_LINE
new_node . next = head_ref NEW_LINE
head_ref = new_node NEW_LINE head = head_ref NEW_LINE
def sumOfLastN_Nodes ( head ) : NEW_LINE INDENT global sum NEW_LINE global n NEW_LINE DEDENT
if ( head == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
sumOfLastN_Nodes ( head . next ) NEW_LINE
if ( n > 0 ) : NEW_LINE
sum = sum + head . data NEW_LINE
n = n - 1 NEW_LINE
def sumOfLastN_NodesUtil ( head , n ) : NEW_LINE INDENT global sum NEW_LINE DEDENT
if ( n <= 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT sum = 0 NEW_LINE
sumOfLastN_Nodes ( head ) NEW_LINE
return sum NEW_LINE
head = None NEW_LINE
push ( head , 12 ) NEW_LINE push ( head , 4 ) NEW_LINE push ( head , 8 ) NEW_LINE push ( head , 6 ) NEW_LINE push ( head , 10 ) NEW_LINE n = 2 NEW_LINE print ( " Sum ▁ of ▁ last ▁ " , n , " ▁ nodes ▁ = ▁ " , sumOfLastN_NodesUtil ( head , n ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT head = None NEW_LINE n = 0 NEW_LINE sum = 0 NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE INDENT global head NEW_LINE DEDENT
new_node = Node ( 0 ) NEW_LINE
new_node . data = new_data NEW_LINE
new_node . next = head_ref NEW_LINE
head_ref = new_node NEW_LINE head = head_ref NEW_LINE
def sumOfLastN_NodesUtil ( head , n ) : NEW_LINE INDENT global sum NEW_LINE DEDENT
if ( n <= 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT st = [ ] NEW_LINE sum = 0 NEW_LINE
while ( head != None ) : NEW_LINE
st . append ( head . data ) NEW_LINE
head = head . next NEW_LINE
while ( n ) : NEW_LINE INDENT n -= 1 NEW_LINE sum += st [ 0 ] NEW_LINE st . pop ( 0 ) NEW_LINE DEDENT
return sum NEW_LINE
head = None NEW_LINE
push ( head , 12 ) NEW_LINE push ( head , 4 ) NEW_LINE push ( head , 8 ) NEW_LINE push ( head , 6 ) NEW_LINE push ( head , 10 ) NEW_LINE n = 2 NEW_LINE print ( " Sum ▁ of ▁ last " , n , " nodes ▁ = " , sumOfLastN_NodesUtil ( head , n ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . next = None NEW_LINE DEDENT DEDENT head = None NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE
new_Node = Node ( new_data ) NEW_LINE
new_Node . data = new_data NEW_LINE
new_Node . next = head_ref NEW_LINE
head_ref = new_Node NEW_LINE head = head_ref NEW_LINE return head NEW_LINE def reverseList ( ) : NEW_LINE global head ; NEW_LINE current , prev , next = None , None , None ; NEW_LINE current = head ; NEW_LINE prev = None ; NEW_LINE while ( current != None ) : NEW_LINE INDENT next = current . next ; NEW_LINE current . next = prev ; NEW_LINE prev = current ; NEW_LINE current = next ; NEW_LINE DEDENT head = prev ; NEW_LINE
def sumOfLastN_NodesUtil ( n ) : NEW_LINE
if ( n <= 0 ) : NEW_LINE INDENT return 0 ; NEW_LINE DEDENT
reverseList ( ) ; NEW_LINE sum = 0 ; NEW_LINE current = head ; NEW_LINE
while ( current != None and n > 0 ) : NEW_LINE
sum += current . data ; NEW_LINE
current = current . next ; NEW_LINE n -= 1 ; NEW_LINE
reverseList ( ) ; NEW_LINE
return sum ; NEW_LINE
head = push ( head , 12 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 8 ) NEW_LINE head = push ( head , 6 ) NEW_LINE head = push ( head , 10 ) NEW_LINE n = 2 ; NEW_LINE print ( " Sum ▁ of ▁ last ▁ " , n , " ▁ Nodes ▁ = ▁ " , sumOfLastN_NodesUtil ( n ) ) ; NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . next = None NEW_LINE DEDENT DEDENT head = None NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE
new_Node = Node ( new_data ) NEW_LINE
new_Node . data = new_data NEW_LINE
new_Node . next = head_ref NEW_LINE
head_ref = new_Node NEW_LINE head = head_ref NEW_LINE return head NEW_LINE
def sumOfLastN_NodesUtil ( head , n ) : NEW_LINE
if ( n <= 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT sum = 0 NEW_LINE len = 0 NEW_LINE temp = head NEW_LINE
while ( temp != None ) : NEW_LINE INDENT len += 1 NEW_LINE temp = temp . next NEW_LINE DEDENT
c = len - n NEW_LINE temp = head NEW_LINE
while ( temp != None and c > 0 ) : NEW_LINE
temp = temp . next NEW_LINE c -= 1 NEW_LINE
while ( temp != None ) : NEW_LINE
sum += temp . data NEW_LINE
temp = temp . next NEW_LINE
return sum NEW_LINE
head = push ( head , 12 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 8 ) NEW_LINE head = push ( head , 6 ) NEW_LINE head = push ( head , 10 ) NEW_LINE n = 2 NEW_LINE print ( " Sum ▁ of ▁ last ▁ " , n , " ▁ Nodes ▁ = ▁ " , sumOfLastN_NodesUtil ( head , n ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = " ▁ " ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
def mergeKLists ( arr , last ) : NEW_LINE
for i in range ( 1 , last + 1 ) : NEW_LINE INDENT while ( True ) : NEW_LINE DEDENT
head_0 = arr [ 0 ] NEW_LINE head_i = arr [ i ] NEW_LINE
if ( head_i == None ) : NEW_LINE INDENT break NEW_LINE DEDENT
if ( head_0 . data >= head_i . data ) : NEW_LINE INDENT arr [ i ] = head_i . next NEW_LINE head_i . next = head_0 NEW_LINE arr [ 0 ] = head_i NEW_LINE DEDENT else : NEW_LINE
while ( head_0 . next != None ) : NEW_LINE
if ( head_0 . next . data >= head_i . data ) : NEW_LINE INDENT arr [ i ] = head_i . next NEW_LINE head_i . next = head_0 . next NEW_LINE head_0 . next = head_i NEW_LINE break NEW_LINE DEDENT
head_0 = head_0 . next NEW_LINE
if ( head_0 . next == None ) : NEW_LINE INDENT arr [ i ] = head_i . next NEW_LINE head_i . next = None NEW_LINE head_0 . next = head_i NEW_LINE head_0 . next . next = None NEW_LINE break NEW_LINE DEDENT return arr [ 0 ] NEW_LINE
k = 3 NEW_LINE
n = 4 NEW_LINE
arr = [ None for i in range ( k ) ] NEW_LINE arr [ 0 ] = Node ( 1 ) NEW_LINE arr [ 0 ] . next = Node ( 3 ) NEW_LINE arr [ 0 ] . next . next = Node ( 5 ) NEW_LINE arr [ 0 ] . next . next . next = Node ( 7 ) NEW_LINE arr [ 1 ] = Node ( 2 ) NEW_LINE arr [ 1 ] . next = Node ( 4 ) NEW_LINE arr [ 1 ] . next . next = Node ( 6 ) NEW_LINE arr [ 1 ] . next . next . next = Node ( 8 ) NEW_LINE arr [ 2 ] = Node ( 0 ) NEW_LINE arr [ 2 ] . next = Node ( 9 ) NEW_LINE arr [ 2 ] . next . next = Node ( 10 ) NEW_LINE arr [ 2 ] . next . next . next = Node ( 11 ) NEW_LINE
head = mergeKLists ( arr , k - 1 ) NEW_LINE printList ( head ) NEW_LINE
import math NEW_LINE class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def newNode ( key ) : NEW_LINE INDENT temp = Node ( key ) NEW_LINE temp . data = key NEW_LINE temp . next = None NEW_LINE return temp NEW_LINE DEDENT
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = " ▁ " ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
def merge ( h1 , h2 ) : NEW_LINE INDENT if ( h1 == None ) : NEW_LINE INDENT return h2 NEW_LINE DEDENT if ( h2 == None ) : NEW_LINE INDENT return h1 NEW_LINE DEDENT DEDENT
if ( h1 . data < h2 . data ) : NEW_LINE INDENT h1 . next = merge ( h1 . next , h2 ) NEW_LINE return h1 NEW_LINE DEDENT else : NEW_LINE INDENT h2 . next = merge ( h1 , h2 . next ) NEW_LINE return h2 NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT head1 = newNode ( 1 ) NEW_LINE head1 . next = newNode ( 3 ) NEW_LINE head1 . next . next = newNode ( 5 ) NEW_LINE DEDENT
head2 = newNode ( 0 ) NEW_LINE head2 . next = newNode ( 2 ) NEW_LINE head2 . next . next = newNode ( 4 ) NEW_LINE
mergedhead = merge ( head1 , head2 ) NEW_LINE printList ( mergedhead ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def newNode ( key ) : NEW_LINE INDENT temp = Node ( 0 ) NEW_LINE temp . data = key NEW_LINE temp . next = None NEW_LINE return temp NEW_LINE DEDENT
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = " ▁ " ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
def mergeUtil ( h1 , h2 ) : NEW_LINE
if ( h1 . next == None ) : NEW_LINE INDENT h1 . next = h2 NEW_LINE return h1 NEW_LINE DEDENT
curr1 = h1 NEW_LINE next1 = h1 . next NEW_LINE curr2 = h2 NEW_LINE next2 = h2 . next NEW_LINE while ( next1 != None and curr2 != None ) : NEW_LINE
if ( ( curr2 . data ) >= ( curr1 . data ) and ( curr2 . data ) <= ( next1 . data ) ) : NEW_LINE INDENT next2 = curr2 . next NEW_LINE curr1 . next = curr2 NEW_LINE curr2 . next = next1 NEW_LINE DEDENT
curr1 = curr2 NEW_LINE curr2 = next2 NEW_LINE else : NEW_LINE
if ( next1 . next ) : NEW_LINE INDENT next1 = next1 . next NEW_LINE curr1 = curr1 . next NEW_LINE DEDENT
else : NEW_LINE INDENT next1 . next = curr2 NEW_LINE return h1 NEW_LINE DEDENT return h1 NEW_LINE
def merge ( h1 , h2 ) : NEW_LINE INDENT if ( h1 == None ) : NEW_LINE INDENT return h2 NEW_LINE DEDENT if ( h2 == None ) : NEW_LINE INDENT return h1 NEW_LINE DEDENT DEDENT
if ( h1 . data < h2 . data ) : NEW_LINE INDENT return mergeUtil ( h1 , h2 ) NEW_LINE DEDENT else : NEW_LINE INDENT return mergeUtil ( h2 , h1 ) NEW_LINE DEDENT
head1 = newNode ( 1 ) NEW_LINE head1 . next = newNode ( 3 ) NEW_LINE head1 . next . next = newNode ( 5 ) NEW_LINE
head2 = newNode ( 0 ) NEW_LINE head2 . next = newNode ( 2 ) NEW_LINE head2 . next . next = newNode ( 4 ) NEW_LINE
mergedhead = merge ( head1 , head2 ) NEW_LINE printList ( mergedhead ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def swapNodes ( head_ref , currX , currY , prevY ) : NEW_LINE
head_ref = currY NEW_LINE
prevY . next = currX NEW_LINE
temp = currY . next NEW_LINE currY . next = currX . next NEW_LINE currX . next = temp NEW_LINE return head_ref NEW_LINE
def recurSelectionSort ( head ) : NEW_LINE
if ( head . next == None ) : NEW_LINE INDENT return head NEW_LINE DEDENT
min = head NEW_LINE
beforeMin = None NEW_LINE ptr = head NEW_LINE
while ( ptr . next != None ) : NEW_LINE
if ( ptr . next . data < min . data ) : NEW_LINE INDENT min = ptr . next NEW_LINE beforeMin = ptr NEW_LINE DEDENT ptr = ptr . next NEW_LINE
if ( min != head ) : NEW_LINE INDENT head = swapNodes ( head , head , min , beforeMin ) NEW_LINE DEDENT
head . next = recurSelectionSort ( head . next ) NEW_LINE return head NEW_LINE
def sort ( head_ref ) : NEW_LINE
if ( ( head_ref ) == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT
head_ref = recurSelectionSort ( head_ref ) NEW_LINE return head_ref NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE
new_node = Node ( 0 ) NEW_LINE
new_node . data = new_data NEW_LINE
new_node . next = ( head_ref ) NEW_LINE
( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE
def printList ( head ) : NEW_LINE INDENT while ( head != None ) : NEW_LINE INDENT print ( head . data , end = " ▁ " ) NEW_LINE head = head . next NEW_LINE DEDENT DEDENT
head = None NEW_LINE
head = push ( head , 6 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 8 ) NEW_LINE head = push ( head , 12 ) NEW_LINE head = push ( head , 10 ) NEW_LINE print ( " Linked ▁ list ▁ before ▁ sorting : " ) NEW_LINE printList ( head ) NEW_LINE
head = sort ( head ) NEW_LINE print (   " Linked list after sorting : " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE
def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT
def insertAtMid ( head , x ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT head = Node ( x ) NEW_LINE DEDENT else : NEW_LINE
newNode = Node ( x ) NEW_LINE ptr = head NEW_LINE length = 0 NEW_LINE
while ( ptr != None ) : NEW_LINE INDENT ptr = ptr . next NEW_LINE length += 1 NEW_LINE DEDENT
if ( length % 2 == 0 ) : NEW_LINE INDENT count = length / 2 NEW_LINE DEDENT else : NEW_LINE INDENT ( length + 1 ) / 2 NEW_LINE DEDENT ptr = head NEW_LINE
while ( count > 1 ) : NEW_LINE INDENT count -= 1 NEW_LINE ptr = ptr . next NEW_LINE DEDENT
newNode . next = ptr . next NEW_LINE ptr . next = newNode NEW_LINE
def display ( head ) : NEW_LINE INDENT temp = head NEW_LINE while ( temp != None ) : NEW_LINE INDENT print ( str ( temp . data ) , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT DEDENT
head = Node ( 1 ) NEW_LINE head . next = Node ( 2 ) NEW_LINE head . next . next = Node ( 4 ) NEW_LINE head . next . next . next = Node ( 5 ) NEW_LINE print ( " Linked ▁ list ▁ before ▁ insertion : ▁ " , end = " " ) NEW_LINE display ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def getNode ( data ) : NEW_LINE
newNode = Node ( 0 ) NEW_LINE
newNode . data = data NEW_LINE newNode . next = None NEW_LINE return newNode NEW_LINE
def insertAfterNthNode ( head , n , x ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
newNode = getNode ( x ) NEW_LINE ptr = head NEW_LINE len = 0 NEW_LINE i = 0 NEW_LINE
while ( ptr != None ) : NEW_LINE INDENT len = len + 1 NEW_LINE ptr = ptr . next NEW_LINE DEDENT
ptr = head NEW_LINE i = 1 NEW_LINE while ( i <= ( len - n ) ) : NEW_LINE INDENT ptr = ptr . next NEW_LINE i = i + 1 NEW_LINE DEDENT
newNode . next = ptr . next NEW_LINE ptr . next = newNode NEW_LINE
def printList ( head ) : NEW_LINE INDENT while ( head != None ) : NEW_LINE INDENT print ( head . data , end = " ▁ " ) NEW_LINE head = head . next NEW_LINE DEDENT DEDENT
head = getNode ( 1 ) NEW_LINE head . next = getNode ( 3 ) NEW_LINE head . next . next = getNode ( 4 ) NEW_LINE head . next . next . next = getNode ( 5 ) NEW_LINE n = 4 NEW_LINE x = 2 NEW_LINE print ( " Original ▁ Linked ▁ List : ▁ " ) NEW_LINE printList ( head ) NEW_LINE insertAfterNthNode ( head , n , x ) NEW_LINE print ( ) NEW_LINE print ( " Linked ▁ List ▁ After ▁ Insertion : ▁ " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def getNode ( data ) : NEW_LINE
newNode = Node ( data ) NEW_LINE return newNode NEW_LINE
def insertAfterNthNode ( head , n , x ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
newNode = getNode ( x ) NEW_LINE
slow_ptr = head NEW_LINE fast_ptr = head NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT fast_ptr = fast_ptr . next NEW_LINE DEDENT
while ( fast_ptr . next != None ) : NEW_LINE
slow_ptr = slow_ptr . next NEW_LINE fast_ptr = fast_ptr . next NEW_LINE
newNode . next = slow_ptr . next NEW_LINE slow_ptr . next = newNode NEW_LINE
def printList ( head ) : NEW_LINE INDENT while ( head != None ) : NEW_LINE INDENT print ( head . data , end = ' ▁ ' ) NEW_LINE head = head . next NEW_LINE DEDENT DEDENT
head = getNode ( 1 ) NEW_LINE head . next = getNode ( 3 ) NEW_LINE head . next . next = getNode ( 4 ) NEW_LINE head . next . next . next = getNode ( 5 ) NEW_LINE n = 4 NEW_LINE x = 2 NEW_LINE print ( " Original ▁ Linked ▁ List : ▁ " , end = ' ' ) NEW_LINE printList ( head ) NEW_LINE insertAfterNthNode ( head , n , x ) NEW_LINE print ( " Linked List After Insertion :   " , end = ' ' ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def rotateHelper ( blockHead , blockTail , d , tail , k ) : NEW_LINE INDENT if ( d == 0 ) : NEW_LINE INDENT return blockHead , tail NEW_LINE DEDENT DEDENT
if ( d > 0 ) : NEW_LINE INDENT temp = blockHead NEW_LINE i = 1 NEW_LINE while temp . next . next != None and i < k - 1 : NEW_LINE INDENT temp = temp . next NEW_LINE i += 1 NEW_LINE DEDENT blockTail . next = blockHead NEW_LINE tail = temp NEW_LINE return rotateHelper ( blockTail , temp , d - 1 , tail , k ) NEW_LINE DEDENT
if ( d < 0 ) : NEW_LINE INDENT blockTail . next = blockHead NEW_LINE tail = blockHead NEW_LINE return rotateHelper ( blockHead . next , blockHead , d + 1 , tail , k ) NEW_LINE DEDENT
def rotateByBlocks ( head , k , d ) : NEW_LINE
if ( head == None or head . next == None ) : NEW_LINE INDENT return head NEW_LINE DEDENT
if ( d == 0 ) : NEW_LINE INDENT return head NEW_LINE DEDENT temp = head NEW_LINE tail = None NEW_LINE
i = 1 NEW_LINE while temp . next != None and i < k : NEW_LINE INDENT temp = temp . next NEW_LINE i += 1 NEW_LINE DEDENT
nextBlock = temp . next NEW_LINE
if ( i < k ) : NEW_LINE INDENT head , tail = rotateHelper ( head , temp , d % k , tail , i ) NEW_LINE DEDENT else : NEW_LINE INDENT head , tail = rotateHelper ( head , temp , d % k , tail , k ) NEW_LINE DEDENT
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ; NEW_LINE
return head ; NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE INDENT new_node = Node ( new_data ) NEW_LINE new_node . data = new_data NEW_LINE new_node . next = ( head_ref ) NEW_LINE ( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE DEDENT
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = ' ▁ ' ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
head = None NEW_LINE
for i in range ( 9 , 0 , - 1 ) : NEW_LINE INDENT head = push ( head , i ) NEW_LINE DEDENT print ( " Given ▁ linked ▁ list ▁ " ) NEW_LINE printList ( head ) NEW_LINE
k = 3 NEW_LINE d = 2 NEW_LINE head = rotateByBlocks ( head , k , d ) NEW_LINE print ( " Rotated by blocks Linked list   " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def countRotation ( head ) : NEW_LINE
count = 0 NEW_LINE
min = head . data NEW_LINE
while ( head != None ) : NEW_LINE
if ( min > head . data ) : NEW_LINE INDENT break NEW_LINE DEDENT count += 1 NEW_LINE
head = head . next NEW_LINE return count NEW_LINE
def push ( head , data ) : NEW_LINE
newNode = Node ( data ) NEW_LINE
newNode . data = data NEW_LINE
newNode . next = ( head ) NEW_LINE
( head ) = newNode NEW_LINE return head NEW_LINE
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = ' ▁ ' ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
head = None NEW_LINE
head = push ( head , 12 ) NEW_LINE head = push ( head , 11 ) NEW_LINE head = push ( head , 8 ) NEW_LINE head = push ( head , 5 ) NEW_LINE head = push ( head , 18 ) NEW_LINE head = push ( head , 15 ) NEW_LINE printList ( head ) ; NEW_LINE print ( ) NEW_LINE print ( " Linked ▁ list ▁ rotated ▁ elements : ▁ " , end = ' ' ) NEW_LINE
print ( countRotation ( head ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def setMiddleHead ( head ) : NEW_LINE INDENT if ( head == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT DEDENT
one_node = head NEW_LINE
two_node = head NEW_LINE
prev = None NEW_LINE while ( two_node != None and two_node . next != None ) : NEW_LINE
prev = one_node NEW_LINE
one_node = one_node . next NEW_LINE
two_node = two_node . next . next NEW_LINE
prev . next = prev . next . next NEW_LINE one_node . next = head NEW_LINE head = one_node NEW_LINE return head NEW_LINE
def push ( head , new_data ) : NEW_LINE
new_node = Node ( new_data ) NEW_LINE
new_node . next = head NEW_LINE
head = new_node NEW_LINE return head NEW_LINE
def printList ( head ) : NEW_LINE INDENT temp = head NEW_LINE while ( temp != None ) : NEW_LINE INDENT print ( str ( temp . data ) , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( " " ) NEW_LINE DEDENT
head = None NEW_LINE for i in range ( 5 , 0 , - 1 ) : NEW_LINE INDENT head = push ( head , i ) NEW_LINE DEDENT print ( " ▁ list ▁ before : ▁ " , end = " " ) NEW_LINE printList ( head ) NEW_LINE head = setMiddleHead ( head ) NEW_LINE print ( " ▁ list ▁ After : ▁ " , end = " " ) NEW_LINE printList ( head ) NEW_LINE
def insertAfter ( self , prev_node , new_data ) : NEW_LINE
if prev_node is None : NEW_LINE INDENT print ( " This ▁ node ▁ doesn ' t ▁ exist ▁ in ▁ DLL " ) NEW_LINE return NEW_LINE DEDENT
new_node = Node ( data = new_data ) NEW_LINE
new_node . next = prev_node . next NEW_LINE
prev_node . next = new_node NEW_LINE
new_node . prev = prev_node NEW_LINE
if new_node . next is not None : NEW_LINE INDENT new_node . next . prev = new_node NEW_LINE DEDENT
import math NEW_LINE class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE self . prev = None NEW_LINE DEDENT DEDENT
def insert ( head_ref , data ) : NEW_LINE
new_node = Node ( data ) NEW_LINE
new_node . data = data NEW_LINE
if ( head_ref == None ) : NEW_LINE INDENT new_node . next = new_node NEW_LINE new_node . prev = new_node NEW_LINE DEDENT else : NEW_LINE
last = head_ref . prev NEW_LINE
new_node . next = head_ref NEW_LINE new_node . prev = last NEW_LINE
last . next = new_node NEW_LINE head_ref . prev = new_node NEW_LINE
head_ref = new_node NEW_LINE return head_ref NEW_LINE
def merge ( first , second ) : NEW_LINE
if ( first == None ) : NEW_LINE INDENT return second NEW_LINE DEDENT
if ( second == None ) : NEW_LINE INDENT return first NEW_LINE DEDENT
if ( first . data < second . data ) : NEW_LINE INDENT first . next = merge ( first . next , second ) NEW_LINE first . next . prev = first NEW_LINE first . prev = None NEW_LINE return first NEW_LINE DEDENT else : NEW_LINE INDENT second . next = merge ( first , second . next ) NEW_LINE second . next . prev = second NEW_LINE second . prev = None NEW_LINE return second NEW_LINE DEDENT
def mergeUtil ( head1 , head2 ) : NEW_LINE
if ( head1 == None ) : NEW_LINE INDENT return head2 NEW_LINE DEDENT
if ( head2 == None ) : NEW_LINE INDENT return head1 NEW_LINE DEDENT
if ( head1 . prev . data < head2 . prev . data ) : NEW_LINE INDENT last_node = head2 . prev NEW_LINE DEDENT else : NEW_LINE INDENT last_node = head1 . prev NEW_LINE DEDENT
head1 . prev . next = None NEW_LINE head2 . prev . next = None NEW_LINE
finalHead = merge ( head1 , head2 ) NEW_LINE
finalHead . prev = last_node NEW_LINE last_node . next = finalHead NEW_LINE return finalHead NEW_LINE
def printList ( head ) : NEW_LINE INDENT temp = head NEW_LINE while ( temp . next != head ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( temp . data , end = " ▁ " ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT head1 = None NEW_LINE head2 = None NEW_LINE DEDENT
head1 = insert ( head1 , 8 ) NEW_LINE head1 = insert ( head1 , 5 ) NEW_LINE head1 = insert ( head1 , 3 ) NEW_LINE head1 = insert ( head1 , 1 ) NEW_LINE
head2 = insert ( head2 , 11 ) NEW_LINE head2 = insert ( head2 , 9 ) NEW_LINE head2 = insert ( head2 , 7 ) NEW_LINE head2 = insert ( head2 , 2 ) NEW_LINE newHead = mergeUtil ( head1 , head2 ) NEW_LINE print ( " Final ▁ Sorted ▁ List : ▁ " , end = " " ) NEW_LINE printList ( newHead ) NEW_LINE
import math NEW_LINE class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT def newNode ( val ) : NEW_LINE INDENT temp = Node ( val ) NEW_LINE temp . data = val NEW_LINE temp . prev = None NEW_LINE temp . next = None NEW_LINE return temp NEW_LINE DEDENT def printList ( head ) : NEW_LINE INDENT while ( head . next != None ) : NEW_LINE INDENT print ( head . data , end = " < - - > " ) NEW_LINE head = head . next NEW_LINE DEDENT print ( head . data ) NEW_LINE DEDENT
def insert ( head , val ) : NEW_LINE INDENT temp = newNode ( val ) NEW_LINE temp . next = head NEW_LINE ( head ) . prev = temp NEW_LINE ( head ) = temp NEW_LINE return head NEW_LINE DEDENT
def reverseList ( head ) : NEW_LINE INDENT left = head NEW_LINE right = head NEW_LINE DEDENT
while ( right . next != None ) : NEW_LINE INDENT right = right . next NEW_LINE DEDENT
while ( left != right and left . prev != right ) : NEW_LINE
t = left . data NEW_LINE left . data = right . data NEW_LINE right . data = t NEW_LINE
left = left . next NEW_LINE
right = right . prev NEW_LINE return head NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT head = newNode ( 5 ) NEW_LINE head = insert ( head , 4 ) NEW_LINE head = insert ( head , 3 ) NEW_LINE head = insert ( head , 2 ) NEW_LINE head = insert ( head , 1 ) NEW_LINE printList ( head ) NEW_LINE print ( " List ▁ After ▁ Reversing " ) NEW_LINE head = reverseList ( head ) NEW_LINE printList ( head ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . prev = None NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def getNode ( data ) : NEW_LINE
newNode = Node ( 0 ) NEW_LINE
newNode . data = data NEW_LINE newNode . prev = newNode . next = None NEW_LINE return newNode NEW_LINE
def sortedInsert ( head_ref , newNode ) : NEW_LINE INDENT current = None NEW_LINE DEDENT
if ( head_ref == None ) : NEW_LINE INDENT head_ref = newNode NEW_LINE DEDENT
elif ( ( head_ref ) . data >= newNode . data ) : NEW_LINE INDENT newNode . next = head_ref NEW_LINE newNode . next . prev = newNode NEW_LINE head_ref = newNode NEW_LINE DEDENT else : NEW_LINE INDENT current = head_ref NEW_LINE DEDENT
while ( current . next != None and current . next . data < newNode . data ) : NEW_LINE INDENT current = current . next NEW_LINE DEDENT
newNode . next = current . next NEW_LINE
if ( current . next != None ) : NEW_LINE INDENT newNode . next . prev = newNode NEW_LINE DEDENT current . next = newNode NEW_LINE newNode . prev = current NEW_LINE return head_ref ; NEW_LINE
def insertionSort ( head_ref ) : NEW_LINE
sorted = None NEW_LINE
current = head_ref NEW_LINE while ( current != None ) : NEW_LINE
next = current . next NEW_LINE
current . prev = current . next = None NEW_LINE
sorted = sortedInsert ( sorted , current ) NEW_LINE
current = next NEW_LINE
head_ref = sorted NEW_LINE return head_ref NEW_LINE
def printList ( head ) : NEW_LINE INDENT while ( head != None ) : NEW_LINE INDENT print ( head . data , end = " ▁ " ) NEW_LINE head = head . next NEW_LINE DEDENT DEDENT
def push ( head_ref , new_data ) : NEW_LINE
new_node = Node ( 0 ) NEW_LINE
new_node . data = new_data NEW_LINE
new_node . next = ( head_ref ) NEW_LINE new_node . prev = None NEW_LINE
if ( ( head_ref ) != None ) : NEW_LINE INDENT ( head_ref ) . prev = new_node NEW_LINE DEDENT
( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE
head = None NEW_LINE
head = push ( head , 9 ) NEW_LINE head = push ( head , 3 ) NEW_LINE head = push ( head , 5 ) NEW_LINE head = push ( head , 10 ) NEW_LINE head = push ( head , 12 ) NEW_LINE head = push ( head , 8 ) NEW_LINE print ( " Doubly ▁ Linked ▁ List ▁ Before ▁ Sorting " ) NEW_LINE printList ( head ) NEW_LINE head = insertionSort ( head ) NEW_LINE print ( " Doubly Linked List After Sorting " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data , next , prev ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = next NEW_LINE self . prev = prev NEW_LINE DEDENT DEDENT
def push ( head_ref , new_data ) : NEW_LINE INDENT new_node = Node ( new_data , head_ref , None ) NEW_LINE if head_ref != None : NEW_LINE INDENT head_ref . prev = new_node NEW_LINE head_ref = new_node NEW_LINE DEDENT return head_ref NEW_LINE DEDENT
def isPalindrome ( left ) : NEW_LINE INDENT if left == None : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT
right = left NEW_LINE while right . next != None : NEW_LINE INDENT right = right . next NEW_LINE DEDENT while left != right : NEW_LINE INDENT if left . data != right . data : NEW_LINE INDENT return False NEW_LINE DEDENT left = left . next NEW_LINE right = right . prev NEW_LINE DEDENT return True NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT head = None NEW_LINE head = push ( head , ' l ' ) NEW_LINE head = push ( head , ' e ' ) NEW_LINE head = push ( head , ' v ' ) NEW_LINE head = push ( head , ' e ' ) NEW_LINE head = push ( head , ' l ' ) NEW_LINE if isPalindrome ( head ) : NEW_LINE INDENT print ( " It ▁ is ▁ Palindrome " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Not ▁ Palindrome " ) NEW_LINE DEDENT DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . key = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def printLevels ( root , low , high ) : NEW_LINE INDENT Q = [ ] NEW_LINE DEDENT
marker = Node ( 11114 ) NEW_LINE
level = 1 NEW_LINE
Q . append ( root ) NEW_LINE Q . append ( marker ) NEW_LINE
while ( len ( Q ) > 0 ) : NEW_LINE
n = Q [ 0 ] NEW_LINE Q . pop ( 0 ) NEW_LINE
if n == marker : NEW_LINE
print NEW_LINE level += 1 NEW_LINE
if len ( Q ) == 0 or level > high : NEW_LINE INDENT break NEW_LINE DEDENT
Q . append ( marker ) NEW_LINE
continue NEW_LINE
if level >= low : NEW_LINE INDENT print n . key , NEW_LINE DEDENT
if n . left is not None : NEW_LINE INDENT Q . append ( n . left ) NEW_LINE Q . append ( n . right ) NEW_LINE DEDENT
root = Node ( 20 ) NEW_LINE root . left = Node ( 8 ) NEW_LINE root . right = Node ( 22 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 12 ) NEW_LINE root . left . right . left = Node ( 10 ) NEW_LINE root . left . right . right = Node ( 14 ) NEW_LINE print " Level ▁ Order ▁ Traversal ▁ between ▁ given ▁ two ▁ levels ▁ is " , NEW_LINE printLevels ( root , 2 , 3 ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT def printKDistant ( root , k ) : NEW_LINE INDENT if root is None : NEW_LINE INDENT return NEW_LINE DEDENT if k == 0 : NEW_LINE INDENT print root . data , NEW_LINE DEDENT else : NEW_LINE INDENT printKDistant ( root . left , k - 1 ) NEW_LINE printKDistant ( root . right , k - 1 ) NEW_LINE DEDENT DEDENT
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE root . right . left = Node ( 8 ) NEW_LINE printKDistant ( root , 2 ) NEW_LINE
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = self . right = None NEW_LINE DEDENT DEDENT
def printKDistant ( root , klevel ) : NEW_LINE INDENT q = [ ] NEW_LINE level = 1 NEW_LINE flag = False NEW_LINE q . append ( root ) NEW_LINE DEDENT
q . append ( None ) NEW_LINE while ( len ( q ) ) : NEW_LINE INDENT temp = q [ 0 ] NEW_LINE DEDENT
if ( level == klevel and temp != None ) : NEW_LINE INDENT flag = True NEW_LINE print ( temp . data , end = " ▁ " ) NEW_LINE DEDENT q . pop ( 0 ) NEW_LINE if ( temp == None ) : NEW_LINE INDENT if ( len ( q ) ) : NEW_LINE INDENT q . append ( None ) NEW_LINE DEDENT level += 1 NEW_LINE DEDENT
if ( level > klevel ) : NEW_LINE INDENT break NEW_LINE DEDENT else : NEW_LINE if ( temp . left ) : NEW_LINE INDENT q . append ( temp . left ) NEW_LINE DEDENT if ( temp . right ) : NEW_LINE INDENT q . append ( temp . right ) NEW_LINE DEDENT print ( ) NEW_LINE return flag NEW_LINE
root = newNode ( 20 ) NEW_LINE root . left = newNode ( 10 ) NEW_LINE root . right = newNode ( 30 ) NEW_LINE root . left . left = newNode ( 5 ) NEW_LINE root . left . right = newNode ( 15 ) NEW_LINE root . left . right . left = newNode ( 12 ) NEW_LINE root . right . left = newNode ( 25 ) NEW_LINE root . right . right = newNode ( 40 ) NEW_LINE print ( " data ▁ at ▁ level ▁ 1 ▁ : ▁ " , end = " " ) NEW_LINE ret = printKDistant ( root , 1 ) NEW_LINE if ( ret == False ) : NEW_LINE INDENT print ( " Number ▁ exceeds ▁ total " , " number ▁ of ▁ levels " ) NEW_LINE DEDENT print ( " data ▁ at ▁ level ▁ 2 ▁ : ▁ " , end = " " ) NEW_LINE ret = printKDistant ( root , 2 ) NEW_LINE if ( ret == False ) : NEW_LINE INDENT print ( " Number ▁ exceeds ▁ total " , " number ▁ of ▁ levels " ) NEW_LINE DEDENT print ( " data ▁ at ▁ level ▁ 3 ▁ : ▁ " , end = " " ) NEW_LINE ret = printKDistant ( root , 3 ) NEW_LINE if ( ret == False ) : NEW_LINE INDENT print ( " Number ▁ exceeds ▁ total " , " number ▁ of ▁ levels " ) NEW_LINE DEDENT print ( " data ▁ at ▁ level ▁ 6 ▁ : ▁ " , end = " " ) NEW_LINE ret = printKDistant ( root , 6 ) NEW_LINE if ( ret == False ) : NEW_LINE INDENT print ( " Number ▁ exceeds ▁ total ▁ number ▁ of ▁ levels " ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def printLeafNodes ( root : Node ) -> None : NEW_LINE
if ( not root ) : NEW_LINE INDENT return NEW_LINE DEDENT
if ( not root . left and not root . right ) : NEW_LINE INDENT print ( root . data , end = " ▁ " ) NEW_LINE return NEW_LINE DEDENT
if root . left : NEW_LINE INDENT printLeafNodes ( root . left ) NEW_LINE DEDENT
if root . right : NEW_LINE INDENT printLeafNodes ( root . right ) NEW_LINE DEDENT
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . right . left = Node ( 5 ) NEW_LINE root . right . right = Node ( 8 ) NEW_LINE root . right . left . left = Node ( 6 ) NEW_LINE root . right . left . right = Node ( 7 ) NEW_LINE root . right . right . left = Node ( 9 ) NEW_LINE root . right . right . right = Node ( 10 ) NEW_LINE
printLeafNodes ( root ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def printkDistanceNodeDown ( root , k ) : NEW_LINE
if root is None or k < 0 : NEW_LINE INDENT return NEW_LINE DEDENT
if k == 0 : NEW_LINE INDENT print root . data NEW_LINE return NEW_LINE DEDENT
printkDistanceNodeDown ( root . left , k - 1 ) NEW_LINE printkDistanceNodeDown ( root . right , k - 1 ) NEW_LINE
def printkDistanceNode ( root , target , k ) : NEW_LINE
if root is None : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
if root == target : NEW_LINE INDENT printkDistanceNodeDown ( root , k ) NEW_LINE return 0 NEW_LINE DEDENT
dl = printkDistanceNode ( root . left , target , k ) NEW_LINE
if dl != - 1 : NEW_LINE
if dl + 1 == k : NEW_LINE INDENT print root . data NEW_LINE DEDENT
else : NEW_LINE INDENT printkDistanceNodeDown ( root . right , k - dl - 2 ) NEW_LINE DEDENT
return 1 + dl NEW_LINE
dr = printkDistanceNode ( root . right , target , k ) NEW_LINE if dr != - 1 : NEW_LINE INDENT if ( dr + 1 == k ) : NEW_LINE INDENT print root . data NEW_LINE DEDENT else : NEW_LINE INDENT printkDistanceNodeDown ( root . left , k - dr - 2 ) NEW_LINE DEDENT return 1 + dr NEW_LINE DEDENT
return - 1 NEW_LINE
root = Node ( 20 ) NEW_LINE root . left = Node ( 8 ) NEW_LINE root . right = Node ( 22 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 12 ) NEW_LINE root . left . right . left = Node ( 10 ) NEW_LINE root . left . right . right = Node ( 14 ) NEW_LINE target = root . left . right NEW_LINE printkDistanceNode ( root , target , 2 ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . key = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def printSingles ( root ) : NEW_LINE
if root is None : NEW_LINE INDENT return NEW_LINE DEDENT
if root . left is not None and root . right is not None : NEW_LINE INDENT printSingles ( root . left ) NEW_LINE printSingles ( root . right ) NEW_LINE DEDENT
elif root . right is not None : NEW_LINE INDENT print root . right . key , NEW_LINE printSingles ( root . right ) NEW_LINE DEDENT
elif root . left is not None : NEW_LINE INDENT print root . left . key , NEW_LINE printSingles ( root . left ) NEW_LINE DEDENT
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . right = Node ( 4 ) NEW_LINE root . right . left = Node ( 5 ) NEW_LINE root . right . left . left = Node ( 6 ) NEW_LINE printSingles ( root ) NEW_LINE
class newNode : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . key = key NEW_LINE self . left = self . right = None NEW_LINE DEDENT DEDENT
def kDistantFromLeafUtil ( node , path , visited , pathLen , k ) : NEW_LINE
if ( node == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
path [ pathLen ] = node . key NEW_LINE visited [ pathLen ] = False NEW_LINE pathLen += 1 NEW_LINE
if ( node . left == None and node . right == None and pathLen - k - 1 >= 0 and visited [ pathLen - k - 1 ] == False ) : NEW_LINE INDENT print ( path [ pathLen - k - 1 ] , end = " ▁ " ) NEW_LINE visited [ pathLen - k - 1 ] = True NEW_LINE return NEW_LINE DEDENT
kDistantFromLeafUtil ( node . left , path , visited , pathLen , k ) NEW_LINE kDistantFromLeafUtil ( node . right , path , visited , pathLen , k ) NEW_LINE
def printKDistantfromLeaf ( node , k ) : NEW_LINE INDENT global MAX_HEIGHT NEW_LINE path = [ None ] * MAX_HEIGHT NEW_LINE visited = [ False ] * MAX_HEIGHT NEW_LINE kDistantFromLeafUtil ( node , path , visited , 0 , k ) NEW_LINE DEDENT
root = newNode ( 1 ) NEW_LINE root . left = newNode ( 2 ) NEW_LINE root . right = newNode ( 3 ) NEW_LINE root . left . left = newNode ( 4 ) NEW_LINE root . left . right = newNode ( 5 ) NEW_LINE root . right . left = newNode ( 6 ) NEW_LINE root . right . right = newNode ( 7 ) NEW_LINE root . right . left . right = newNode ( 8 ) NEW_LINE print ( " Nodes ▁ at ▁ distance ▁ 2 ▁ are : " , end = " ▁ " ) NEW_LINE printKDistantfromLeaf ( root , 2 ) NEW_LINE
COUNT = [ 10 ] NEW_LINE
class newNode : NEW_LINE
def __init__ ( self , key ) : NEW_LINE INDENT self . data = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT
def print2DUtil ( root , space ) : NEW_LINE
if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
space += COUNT [ 0 ] NEW_LINE
print2DUtil ( root . right , space ) NEW_LINE
print ( ) NEW_LINE for i in range ( COUNT [ 0 ] , space ) : NEW_LINE INDENT print ( end = " ▁ " ) NEW_LINE DEDENT print ( root . data ) NEW_LINE
print2DUtil ( root . left , space ) NEW_LINE
def print2D ( root ) : NEW_LINE
print2DUtil ( root , 0 ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = newNode ( 1 ) NEW_LINE root . left = newNode ( 2 ) NEW_LINE root . right = newNode ( 3 ) NEW_LINE root . left . left = newNode ( 4 ) NEW_LINE root . left . right = newNode ( 5 ) NEW_LINE root . right . left = newNode ( 6 ) NEW_LINE root . right . right = newNode ( 7 ) NEW_LINE root . left . left . left = newNode ( 8 ) NEW_LINE root . left . left . right = newNode ( 9 ) NEW_LINE root . left . right . left = newNode ( 10 ) NEW_LINE root . left . right . right = newNode ( 11 ) NEW_LINE root . right . left . left = newNode ( 12 ) NEW_LINE root . right . left . right = newNode ( 13 ) NEW_LINE root . right . right . left = newNode ( 14 ) NEW_LINE root . right . right . right = newNode ( 15 ) NEW_LINE print2D ( root ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def leftViewUtil ( root , level , max_level ) : NEW_LINE
if root is None : NEW_LINE INDENT return NEW_LINE DEDENT
if ( max_level [ 0 ] < level ) : NEW_LINE INDENT print " % ▁ d TABSYMBOL " % ( root . data ) , NEW_LINE max_level [ 0 ] = level NEW_LINE DEDENT
leftViewUtil ( root . left , level + 1 , max_level ) NEW_LINE leftViewUtil ( root . right , level + 1 , max_level ) NEW_LINE
def leftView ( root ) : NEW_LINE INDENT max_level = [ 0 ] NEW_LINE leftViewUtil ( root , 1 , max_level ) NEW_LINE DEDENT
root = Node ( 12 ) NEW_LINE root . left = Node ( 10 ) NEW_LINE root . right = Node ( 20 ) NEW_LINE root . right . left = Node ( 25 ) NEW_LINE root . right . right = Node ( 40 ) NEW_LINE leftView ( root ) NEW_LINE
def rotate ( arr , N , X ) : NEW_LINE
nextPower = 1 NEW_LINE
while ( nextPower <= N ) : NEW_LINE INDENT nextPower *= 2 NEW_LINE DEDENT
if ( X == 1 ) : NEW_LINE INDENT ans = nextPower - N NEW_LINE return ans NEW_LINE DEDENT
prevPower = nextPower // 2 NEW_LINE
return 2 * ( N - prevPower ) + 1 NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE X = 1 NEW_LINE N = len ( arr ) NEW_LINE print ( rotate ( arr , N , X ) ) NEW_LINE
def printMat ( mat ) : NEW_LINE
for i in range ( len ( mat ) ) : NEW_LINE
for j in range ( len ( mat [ 0 ] ) ) : NEW_LINE
print ( mat [ i ] [ j ] , end = " ▁ " ) NEW_LINE print ( ) NEW_LINE
def performSwap ( mat , i , j ) : NEW_LINE INDENT N = len ( mat ) NEW_LINE DEDENT
ei = N - 1 - i NEW_LINE
ej = N - 1 - j NEW_LINE
temp = mat [ i ] [ j ] NEW_LINE mat [ i ] [ j ] = mat [ ej ] [ i ] NEW_LINE mat [ ej ] [ i ] = mat [ ei ] [ ej ] NEW_LINE mat [ ei ] [ ej ] = mat [ j ] [ ei ] NEW_LINE mat [ j ] [ ei ] = temp NEW_LINE
def rotate ( mat , N , K ) : NEW_LINE
K = K % 4 NEW_LINE
while ( K > 0 ) : NEW_LINE
for i in range ( int ( N / 2 ) ) : NEW_LINE
for j in range ( i , N - i - 1 ) : NEW_LINE
if ( i != j and ( i + j ) != N - 1 ) : NEW_LINE
performSwap ( mat , i , j ) NEW_LINE K -= 1 NEW_LINE
printMat ( mat ) NEW_LINE
K = 5 NEW_LINE mat = [ [ 1 , 2 , 3 , 4 ] , [ 6 , 7 , 8 , 9 ] , [ 11 , 12 , 13 , 14 ] , [ 16 , 17 , 18 , 19 ] ] NEW_LINE N = len ( mat ) NEW_LINE rotate ( mat , N , K ) NEW_LINE
def findMaximumZeros ( st , n ) : NEW_LINE
c0 = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if ( st [ i ] == '0' ) : NEW_LINE INDENT c0 += 1 NEW_LINE DEDENT DEDENT
if ( c0 == n ) : NEW_LINE
print ( n ) NEW_LINE return NEW_LINE
s = st + st NEW_LINE
mx = 0 NEW_LINE
for i in range ( n ) : NEW_LINE
cs = 0 NEW_LINE ce = 0 NEW_LINE
for j in range ( i , i + n ) : NEW_LINE INDENT if ( s [ j ] == '0' ) : NEW_LINE INDENT cs += 1 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
for j in range ( i + n - 1 , i - 1 , - 1 ) : NEW_LINE INDENT if ( s [ j ] == '0' ) : NEW_LINE INDENT ce += 1 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
val = cs + ce NEW_LINE
mx = max ( val , mx ) NEW_LINE
print ( mx ) NEW_LINE
s = "1001" NEW_LINE
n = len ( s ) NEW_LINE findMaximumZeros ( s , n ) NEW_LINE
def findMaximumZeros ( string , n ) : NEW_LINE
c0 = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( string [ i ] == '0' ) : NEW_LINE INDENT c0 += 1 NEW_LINE DEDENT DEDENT
if ( c0 == n ) : NEW_LINE
print ( n , end = " " ) NEW_LINE return NEW_LINE
mx = 0 NEW_LINE
cnt = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( string [ i ] == '0' ) : NEW_LINE INDENT cnt += 1 NEW_LINE DEDENT else : NEW_LINE INDENT mx = max ( mx , cnt ) NEW_LINE cnt = 0 NEW_LINE DEDENT DEDENT
mx = max ( mx , cnt ) NEW_LINE
start = 0 NEW_LINE end = n - 1 NEW_LINE cnt = 0 NEW_LINE
while ( string [ start ] != '1' and start < n ) : NEW_LINE INDENT cnt += 1 NEW_LINE start += 1 NEW_LINE DEDENT
while ( string [ end ] != '1' and end >= 0 ) : NEW_LINE INDENT cnt += 1 NEW_LINE end -= 1 NEW_LINE DEDENT
mx = max ( mx , cnt ) NEW_LINE
print ( mx , end = " " ) NEW_LINE
s = "1001" NEW_LINE
n = len ( s ) NEW_LINE findMaximumZeros ( s , n ) NEW_LINE
def rotateMatrix ( mat ) : NEW_LINE INDENT i = 0 NEW_LINE mat1 = [ ] NEW_LINE DEDENT
for it in mat : NEW_LINE
it . reverse ( ) NEW_LINE
it1 = it [ : i ] NEW_LINE it1 . reverse ( ) NEW_LINE
it2 = it [ i : ] NEW_LINE it2 . reverse ( ) NEW_LINE
i += 1 NEW_LINE mat1 . append ( it1 + it2 ) NEW_LINE
for rows in mat1 : NEW_LINE INDENT for cols in rows : NEW_LINE INDENT print ( cols , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] NEW_LINE rotateMatrix ( mat ) NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = self . right = None NEW_LINE DEDENT DEDENT
def getLeafCount ( node ) : NEW_LINE
if ( not node ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
q = Queue ( ) NEW_LINE
count = 0 NEW_LINE q . put ( node ) NEW_LINE while ( not q . empty ( ) ) : NEW_LINE INDENT temp = q . queue [ 0 ] NEW_LINE q . get ( ) NEW_LINE if ( temp . left != None ) : NEW_LINE INDENT q . put ( temp . left ) NEW_LINE DEDENT if ( temp . right != None ) : NEW_LINE INDENT q . put ( temp . right ) NEW_LINE DEDENT if ( temp . left == None and temp . right == None ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
root = newNode ( 1 ) NEW_LINE root . left = newNode ( 2 ) NEW_LINE root . right = newNode ( 3 ) NEW_LINE root . left . left = newNode ( 4 ) NEW_LINE root . left . right = newNode ( 5 ) NEW_LINE
print ( getLeafCount ( root ) ) NEW_LINE
def rotateArray ( arr , N ) : NEW_LINE
v = arr NEW_LINE
v . sort ( reverse = False ) NEW_LINE
for i in range ( 1 , N + 1 , 1 ) : NEW_LINE
x = arr [ N - 1 ] NEW_LINE i = N - 1 NEW_LINE while ( i > 0 ) : NEW_LINE INDENT arr [ i ] = arr [ i - 1 ] NEW_LINE arr [ 0 ] = x NEW_LINE i -= 1 NEW_LINE DEDENT
if ( arr == v ) : NEW_LINE INDENT print ( " YES " ) NEW_LINE return NEW_LINE DEDENT
print ( " NO " ) NEW_LINE
arr = [ 3 , 4 , 5 , 1 , 2 ] NEW_LINE
N = len ( arr ) NEW_LINE
rotateArray ( arr , N ) NEW_LINE
def findLargestRotation ( num ) : NEW_LINE
ans = num NEW_LINE
length = len ( str ( num ) ) NEW_LINE x = 10 ** ( length - 1 ) NEW_LINE
for i in range ( 1 , length ) : NEW_LINE
lastDigit = num % 10 NEW_LINE
num = num // 10 NEW_LINE
num += ( lastDigit * x ) NEW_LINE
if ( num > ans ) : NEW_LINE INDENT ans = num NEW_LINE DEDENT
print ( ans ) NEW_LINE
N = 657 NEW_LINE findLargestRotation ( N ) NEW_LINE
def numberOfDigit ( N ) : NEW_LINE
digit = 0 NEW_LINE
while ( N > 0 ) : NEW_LINE
digit += 1 NEW_LINE
N //= 10 NEW_LINE return digit NEW_LINE
def rotateNumberByK ( N , K ) : NEW_LINE
X = numberOfDigit ( N ) NEW_LINE
K = ( ( K % X ) + X ) % X NEW_LINE
left_no = N // pow ( 10 , X - K ) NEW_LINE
N = N % pow ( 10 , X - K ) NEW_LINE
left_digit = numberOfDigit ( left_no ) NEW_LINE
N = N * pow ( 10 , left_digit ) + left_no NEW_LINE print ( N ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT N , K = 12345 , 7 NEW_LINE DEDENT
rotateNumberByK ( N , K ) NEW_LINE
def minMovesToSort ( arr , N ) : NEW_LINE
count = 0 NEW_LINE
index = 0 NEW_LINE
for i in range ( N - 1 ) : NEW_LINE
if ( arr [ i ] < arr [ i + 1 ] ) : NEW_LINE
count += 1 NEW_LINE
index = i NEW_LINE
if ( count == 0 ) : NEW_LINE INDENT print ( "0" ) NEW_LINE DEDENT elif ( count == N - 1 ) : NEW_LINE INDENT print ( N - 1 ) NEW_LINE DEDENT elif ( count == 1 and arr [ 0 ] <= arr [ N - 1 ] ) : NEW_LINE INDENT print ( index + 1 ) NEW_LINE DEDENT
else : NEW_LINE INDENT print ( " - 1" ) NEW_LINE DEDENT
arr = [ 2 , 1 , 5 , 4 , 2 ] NEW_LINE N = len ( arr ) NEW_LINE
minMovesToSort ( arr , N ) NEW_LINE
import sys NEW_LINE N = 3 NEW_LINE
def findMaximumDiagonalSumOMatrixf ( A ) : NEW_LINE
maxDiagonalSum = - sys . maxsize - 1 NEW_LINE
for i in range ( N ) : NEW_LINE
curr = 0 NEW_LINE
for j in range ( N ) : NEW_LINE
curr += A [ j ] [ ( i + j ) % N ] NEW_LINE
maxDiagonalSum = max ( maxDiagonalSum , curr ) NEW_LINE
for i in range ( N ) : NEW_LINE
curr = 0 NEW_LINE
for j in range ( N ) : NEW_LINE
curr += A [ ( i + j ) % N ] [ j ] NEW_LINE
maxDiagonalSum = max ( maxDiagonalSum , curr ) NEW_LINE return maxDiagonalSum NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 1 , 2 ] , [ 2 , 1 , 2 ] , [ 1 , 2 , 2 ] ] NEW_LINE print ( findMaximumDiagonalSumOMatrixf ( mat ) ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def countLeaves ( node ) : NEW_LINE
if ( node == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( node . left == None and node . right == None ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
return countLeaves ( node . left ) + countLeaves ( node . right ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE DEDENT
print ( countLeaves ( root ) ) NEW_LINE
def MaxSum ( arr , n , k ) : NEW_LINE INDENT i , max_sum = 0 , 0 NEW_LINE sum = 0 NEW_LINE DEDENT
while i < k : NEW_LINE INDENT sum += arr [ i ] NEW_LINE i += 1 NEW_LINE DEDENT max_sum = sum NEW_LINE
while ( i < n ) : NEW_LINE
sum = sum - arr [ i - k ] + arr [ i ] NEW_LINE if ( max_sum < sum ) : NEW_LINE INDENT max_sum = sum NEW_LINE DEDENT i += 1 NEW_LINE
return max_sum NEW_LINE
def gcd ( n1 , n2 ) : NEW_LINE
if ( n2 == 0 ) : NEW_LINE INDENT return n1 NEW_LINE DEDENT
else : NEW_LINE INDENT return gcd ( n2 , n1 % n2 ) NEW_LINE DEDENT
def RotateArr ( arr , n , d ) : NEW_LINE
i = 0 NEW_LINE j = 0 NEW_LINE d = d % n NEW_LINE
no_of_sets = gcd ( d , n ) NEW_LINE for i in range ( no_of_sets ) : NEW_LINE INDENT temp = arr [ i ] NEW_LINE j = i NEW_LINE DEDENT
while ( True ) : NEW_LINE INDENT k = j + d NEW_LINE if ( k >= n ) : NEW_LINE INDENT k = k - n NEW_LINE DEDENT if ( k == i ) : NEW_LINE INDENT break NEW_LINE DEDENT arr [ j ] = arr [ k ] NEW_LINE j = k NEW_LINE DEDENT
arr [ j ] = temp NEW_LINE
return arr NEW_LINE
def performQuery ( arr , Q , q ) : NEW_LINE INDENT N = len ( arr ) NEW_LINE DEDENT
for i in range ( q ) : NEW_LINE
if ( Q [ i ] [ 0 ] == 1 ) : NEW_LINE INDENT arr = RotateArr ( arr , N , Q [ i ] [ 1 ] ) NEW_LINE DEDENT
for t in arr : NEW_LINE INDENT print ( t , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE
else : NEW_LINE INDENT print ( MaxSum ( arr , N , Q [ i ] [ 1 ] ) ) NEW_LINE DEDENT
arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE q = 5 NEW_LINE
Q = [ [ 1 , 2 ] , [ 2 , 3 ] , [ 1 , 3 ] , [ 1 , 1 ] , [ 2 , 4 ] ] NEW_LINE
performQuery ( arr , Q , q ) NEW_LINE
def getMinimumRemoval ( str ) : NEW_LINE INDENT n = len ( str ) NEW_LINE DEDENT
ans = n NEW_LINE
if ( n % 2 == 0 ) : NEW_LINE
freqEven = { } NEW_LINE freqOdd = { } NEW_LINE for ch in range ( ord ( ' a ' ) , ord ( ' z ' ) + 1 ) : NEW_LINE INDENT freqEven [ chr ( ch ) ] = 0 NEW_LINE freqOdd [ chr ( ch ) ] = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if ( i % 2 == 0 ) : NEW_LINE INDENT if str [ i ] in freqEven : NEW_LINE INDENT freqEven [ str [ i ] ] += 1 NEW_LINE DEDENT DEDENT else : NEW_LINE INDENT if str [ i ] in freqOdd : NEW_LINE INDENT freqOdd [ str [ i ] ] += 1 NEW_LINE DEDENT DEDENT DEDENT
evenMax = 0 NEW_LINE oddMax = 0 NEW_LINE for ch in range ( ord ( ' a ' ) , ord ( ' z ' ) + 1 ) : NEW_LINE INDENT evenMax = max ( evenMax , freqEven [ chr ( ch ) ] ) NEW_LINE oddMax = max ( oddMax , freqOdd [ chr ( ch ) ] ) NEW_LINE DEDENT
ans = ans - evenMax - oddMax NEW_LINE
else : NEW_LINE
freq = { } NEW_LINE for ch in range ( ' a ' , ' z ' ) : NEW_LINE INDENT freq [ chr ( ch ) ] = 0 NEW_LINE DEDENT for i in range ( n ) : NEW_LINE INDENT if str [ i ] in freq : NEW_LINE INDENT freq [ str [ i ] ] += 1 NEW_LINE DEDENT DEDENT
strMax = 0 NEW_LINE for ch in range ( ' a ' , ' z ' ) : NEW_LINE INDENT strMax = max ( strMax , freq [ chr ( ch ) ] ) NEW_LINE DEDENT
ans = ans - strMax NEW_LINE return ans NEW_LINE
str = " geeksgeeks " NEW_LINE print ( getMinimumRemoval ( str ) ) NEW_LINE
def findAltSubSeq ( s ) : NEW_LINE
n = len ( s ) NEW_LINE ans = - sys . maxsize - 1 NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT for j in range ( 10 ) : NEW_LINE INDENT cur , f = 0 , 0 NEW_LINE DEDENT DEDENT
for k in range ( n ) : NEW_LINE INDENT if ( f == 0 and ord ( s [ k ] ) - ord ( '0' ) == i ) : NEW_LINE INDENT f = 1 NEW_LINE DEDENT DEDENT
cur += 1 NEW_LINE elif ( f == 1 and ord ( s [ k ] ) - ord ( '0' ) == j ) : NEW_LINE f = 0 NEW_LINE
cur += 1 NEW_LINE
if i != j and cur % 2 == 1 : NEW_LINE
cur -= 1 NEW_LINE
ans = max ( cur , ans ) NEW_LINE
return ans NEW_LINE
s = "100210601" NEW_LINE print ( findAltSubSeq ( s ) ) NEW_LINE
def getFirstElement ( a , N , K , M ) : NEW_LINE
K %= N NEW_LINE
if ( K >= M ) : NEW_LINE
index = ( N - K ) + ( M - 1 ) NEW_LINE
else : NEW_LINE
index = ( M - K - 1 ) NEW_LINE result = a [ index ] NEW_LINE
return result NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE N = len ( a ) NEW_LINE K , M = 3 , 2 NEW_LINE print ( getFirstElement ( a , N , K , M ) ) NEW_LINE DEDENT
def getFirstElement ( a , N , K , M ) : NEW_LINE
K %= N NEW_LINE
index = ( K + M - 1 ) % N NEW_LINE result = a [ index ] NEW_LINE
return result NEW_LINE
a = [ 3 , 4 , 5 , 23 ] NEW_LINE
N = len ( a ) NEW_LINE
K = 2 NEW_LINE M = 1 NEW_LINE
print ( getFirstElement ( a , N , K , M ) ) NEW_LINE
def left_rotate ( arr ) : NEW_LINE INDENT last = arr [ 1 ] ; NEW_LINE for i in range ( 3 , len ( arr ) , 2 ) : NEW_LINE INDENT arr [ i - 2 ] = arr [ i ] NEW_LINE DEDENT arr [ len ( arr ) - 1 ] = last NEW_LINE DEDENT
def right_rotate ( arr ) : NEW_LINE INDENT start = arr [ len ( arr ) - 2 ] NEW_LINE for i in range ( len ( arr ) - 4 , - 1 , - 2 ) : NEW_LINE INDENT arr [ i + 2 ] = arr [ i ] NEW_LINE DEDENT arr [ 0 ] = start NEW_LINE DEDENT
def rotate ( arr ) : NEW_LINE INDENT left_rotate ( arr ) NEW_LINE right_rotate ( arr ) NEW_LINE for i in range ( len ( arr ) ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 1 , 2 , 3 , 4 , 5 , 6 ] NEW_LINE rotate ( arr ) ; NEW_LINE
def maximumMatchingPairs ( perm1 , perm2 , n ) : NEW_LINE
left = [ 0 ] * n NEW_LINE right = [ 0 ] * n NEW_LINE
mp1 = { } NEW_LINE mp2 = { } NEW_LINE for i in range ( n ) : NEW_LINE INDENT mp1 [ perm1 [ i ] ] = i NEW_LINE DEDENT for j in range ( n ) : NEW_LINE INDENT mp2 [ perm2 [ j ] ] = j NEW_LINE DEDENT for i in range ( n ) : NEW_LINE
idx2 = mp2 [ perm1 [ i ] ] NEW_LINE idx1 = i NEW_LINE if ( idx1 == idx2 ) : NEW_LINE
left [ i ] = 0 NEW_LINE right [ i ] = 0 NEW_LINE elif ( idx1 < idx2 ) : NEW_LINE
left [ i ] = ( n - ( idx2 - idx1 ) ) NEW_LINE right [ i ] = ( idx2 - idx1 ) NEW_LINE else : NEW_LINE
left [ i ] = ( idx1 - idx2 ) NEW_LINE right [ i ] = ( n - ( idx1 - idx2 ) ) NEW_LINE
freq1 = defaultdict ( int ) NEW_LINE freq2 = defaultdict ( int ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT freq1 [ left [ i ] ] += 1 NEW_LINE freq2 [ right [ i ] ] += 1 NEW_LINE DEDENT ans = 0 NEW_LINE for i in range ( n ) : NEW_LINE
ans = max ( ans , max ( freq1 [ left [ i ] ] , freq2 [ right [ i ] ] ) ) NEW_LINE
return ans NEW_LINE
P1 = [ 5 , 4 , 3 , 2 , 1 ] NEW_LINE P2 = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE n = len ( P1 ) NEW_LINE
print ( maximumMatchingPairs ( P1 , P2 , n ) ) NEW_LINE
def reverse ( arr , s , e ) : NEW_LINE INDENT while s < e : NEW_LINE INDENT tem = arr [ s ] NEW_LINE arr [ s ] = arr [ e ] NEW_LINE arr [ e ] = tem NEW_LINE s = s + 1 NEW_LINE e = e - 1 NEW_LINE DEDENT DEDENT
def fun ( arr , k ) : NEW_LINE INDENT n = len ( arr ) - 1 NEW_LINE v = n - k NEW_LINE if v >= 0 : NEW_LINE INDENT reverse ( arr , 0 , v ) NEW_LINE reverse ( arr , v + 1 , n ) NEW_LINE reverse ( arr , 0 , n ) NEW_LINE return arr NEW_LINE DEDENT DEDENT
arr = [ 1 , 2 , 3 , 4 ] NEW_LINE for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT count = 0 NEW_LINE p = fun ( arr , i ) NEW_LINE print ( p , end = " ▁ " ) NEW_LINE DEDENT
def countRotation ( arr , n ) : NEW_LINE INDENT for i in range ( 1 , n ) : NEW_LINE DEDENT
if ( arr [ i ] < arr [ i - 1 ] ) : NEW_LINE
return i NEW_LINE
return 0 NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr1 = [ 4 , 5 , 1 , 2 , 3 ] NEW_LINE n = len ( arr1 ) NEW_LINE print ( countRotation ( arr1 , n ) ) NEW_LINE DEDENT
def countRotation ( arr , low , high ) : NEW_LINE
if ( low > high ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT mid = low + ( high - low ) // 2 NEW_LINE
if ( mid < high and arr [ mid ] > arr [ mid + 1 ] ) : NEW_LINE
return mid + 1 NEW_LINE
if ( mid > low and arr [ mid ] < arr [ mid - 1 ] ) : NEW_LINE
return mid NEW_LINE
if ( arr [ mid ] > arr [ low ] ) : NEW_LINE
return countRotation ( arr , mid + 1 , high ) NEW_LINE if ( arr [ mid ] < arr [ high ] ) : NEW_LINE
return countRotation ( arr , low , mid - 1 ) NEW_LINE else : NEW_LINE
rightIndex = countRotation ( arr , mid + 1 , high ) NEW_LINE leftIndex = countRotation ( arr , low , mid - 1 ) NEW_LINE if ( rightIndex == 0 ) : NEW_LINE INDENT return leftIndex NEW_LINE DEDENT return rightIndex NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr1 = [ 4 , 5 , 1 , 2 , 3 ] NEW_LINE N = len ( arr1 ) NEW_LINE print ( countRotation ( arr1 , 0 , N - 1 ) ) NEW_LINE DEDENT
MAX = 100005 NEW_LINE
seg = [ 0 ] * ( 4 * MAX ) NEW_LINE
def build ( node , l , r , a ) : NEW_LINE INDENT if ( l == r ) : NEW_LINE INDENT seg [ node ] = a [ l ] NEW_LINE DEDENT else : NEW_LINE INDENT mid = ( l + r ) // 2 NEW_LINE build ( 2 * node , l , mid , a ) NEW_LINE build ( 2 * node + 1 , mid + 1 , r , a ) NEW_LINE seg [ node ] = ( seg [ 2 * node ] seg [ 2 * node + 1 ] ) NEW_LINE DEDENT DEDENT
def query ( node , l , r , start , end , a ) : NEW_LINE
if ( l > end or r < start ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT if ( start <= l and r <= end ) : NEW_LINE INDENT return seg [ node ] NEW_LINE DEDENT
mid = ( l + r ) // 2 NEW_LINE
return ( ( query ( 2 * node , l , mid , start , end , a ) ) | ( query ( 2 * node + 1 , mid + 1 , r , start , end , a ) ) ) NEW_LINE
def orsum ( a , n , q , k ) : NEW_LINE
build ( 1 , 0 , n - 1 , a ) NEW_LINE
for j in range ( q ) : NEW_LINE
i = k [ j ] % ( n // 2 ) NEW_LINE
sec = query ( 1 , 0 , n - 1 , n // 2 - i , n - i - 1 , a ) NEW_LINE
first = ( query ( 1 , 0 , n - 1 , 0 , n // 2 - 1 - i , a ) | query ( 1 , 0 , n - 1 , n - i , n - 1 , a ) ) NEW_LINE temp = sec + first NEW_LINE
print ( temp ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 7 , 44 , 19 , 86 , 65 , 39 , 75 , 101 ] NEW_LINE n = len ( a ) NEW_LINE q = 2 NEW_LINE k = [ 4 , 2 ] NEW_LINE orsum ( a , n , q , k ) NEW_LINE DEDENT
def maximumEqual ( a , b , n ) : NEW_LINE
store = [ 0 ] * 10 ** 5 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT store [ b [ i ] ] = i + 1 NEW_LINE DEDENT
ans = [ 0 ] * 10 ** 5 NEW_LINE
for i in range ( n ) : NEW_LINE
d = abs ( store [ a [ i ] ] - ( i + 1 ) ) NEW_LINE
if ( store [ a [ i ] ] < i + 1 ) : NEW_LINE INDENT d = n - d NEW_LINE DEDENT
ans [ d ] += 1 NEW_LINE finalans = 0 NEW_LINE
for i in range ( 10 ** 5 ) : NEW_LINE INDENT finalans = max ( finalans , ans [ i ] ) NEW_LINE DEDENT
print ( finalans ) NEW_LINE
A = [ 6 , 7 , 3 , 9 , 5 ] NEW_LINE B = [ 7 , 3 , 9 , 5 , 6 ] NEW_LINE size = len ( A ) NEW_LINE
maximumEqual ( A , B , size ) NEW_LINE
def rotatedSumQuery ( arr , n , query , Q ) : NEW_LINE
prefix = [ 0 ] * ( 2 * n ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT prefix [ i ] = arr [ i ] NEW_LINE prefix [ i + n ] = arr [ i ] NEW_LINE DEDENT
for i in range ( 1 , 2 * n ) : NEW_LINE INDENT prefix [ i ] += prefix [ i - 1 ] ; NEW_LINE DEDENT
start = 0 ; NEW_LINE for q in range ( Q ) : NEW_LINE
if ( query [ q ] [ 0 ] == 1 ) : NEW_LINE INDENT k = query [ q ] [ 1 ] NEW_LINE start = ( start + k ) % n ; NEW_LINE DEDENT
elif ( query [ q ] [ 0 ] == 2 ) : NEW_LINE INDENT L = query [ q ] [ 1 ] NEW_LINE R = query [ q ] [ 2 ] NEW_LINE DEDENT
if ( start + L == 0 ) : NEW_LINE
print ( prefix [ start + R ] ) NEW_LINE else : NEW_LINE
print ( prefix [ start + R ] - prefix [ start + L - 1 ] ) NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 , 6 ] ; NEW_LINE
Q = 5 NEW_LINE
query = [ [ 2 , 1 , 3 ] , [ 1 , 3 ] , [ 2 , 0 , 3 ] , [ 1 , 4 ] , [ 2 , 3 , 5 ] ] NEW_LINE n = len ( arr ) ; NEW_LINE rotatedSumQuery ( arr , n , query , Q ) ; NEW_LINE
def isConversionPossible ( s1 , s2 , x ) : NEW_LINE INDENT n = len ( s1 ) NEW_LINE s1 = list ( s1 ) NEW_LINE s2 = list ( s2 ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE
diff = ord ( s2 [ i ] ) - ord ( s1 [ i ] ) NEW_LINE if diff == 0 : NEW_LINE INDENT continue NEW_LINE DEDENT
if diff < 0 : NEW_LINE INDENT diff = diff + 26 NEW_LINE DEDENT
if diff > x : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT s1 = " you " NEW_LINE s2 = " ara " NEW_LINE x = 6 NEW_LINE DEDENT
result = isConversionPossible ( s1 , s2 , x ) NEW_LINE if result : NEW_LINE INDENT print ( " YES " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " NO " ) NEW_LINE DEDENT
def RightRotate ( a , n , k ) : NEW_LINE
k = k % n ; NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT if ( i < k ) : NEW_LINE DEDENT
print ( a [ n + i - k ] , end = " ▁ " ) ; NEW_LINE else : NEW_LINE
print ( a [ i - k ] , end = " ▁ " ) ; NEW_LINE print ( " " ) ; NEW_LINE
Array = [ 1 , 2 , 3 , 4 , 5 ] ; NEW_LINE N = len ( Array ) ; NEW_LINE K = 2 ; NEW_LINE RightRotate ( Array , N , K ) ; NEW_LINE
def countRotation ( n ) : NEW_LINE INDENT count = 0 ; NEW_LINE DEDENT
while n > 0 : NEW_LINE INDENT digit = n % 10 NEW_LINE DEDENT
if ( digit % 2 == 0 ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT n = int ( n / 10 ) NEW_LINE return count ; NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 10203 ; NEW_LINE print ( countRotation ( n ) ) ; NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def push ( head_ref , new_data ) : NEW_LINE
new_node = Node ( new_data ) NEW_LINE
new_node . data = new_data NEW_LINE
new_node . next = ( head_ref ) NEW_LINE
( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = ' ▁ - > ▁ ' ) NEW_LINE node = node . next NEW_LINE DEDENT print ( " NULL " ) NEW_LINE DEDENT
def rightRotate ( head , k ) : NEW_LINE
if ( not head ) : NEW_LINE INDENT return head NEW_LINE DEDENT
tmp = head NEW_LINE len = 1 NEW_LINE while ( tmp . next != None ) : NEW_LINE INDENT tmp = tmp . next NEW_LINE len += 1 NEW_LINE DEDENT
if ( k > len ) : NEW_LINE INDENT k = k % len NEW_LINE DEDENT
k = len - k NEW_LINE
if ( k == 0 or k == len ) : NEW_LINE INDENT return head NEW_LINE DEDENT
current = head NEW_LINE cnt = 1 NEW_LINE while ( cnt < k and current != None ) : NEW_LINE INDENT current = current . next NEW_LINE cnt += 1 NEW_LINE DEDENT
if ( current == None ) : NEW_LINE INDENT return head NEW_LINE DEDENT
kthnode = current NEW_LINE
tmp . next = head NEW_LINE
head = kthnode . next NEW_LINE
kthnode . next = None NEW_LINE
return head NEW_LINE
head = None NEW_LINE head = push ( head , 5 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 3 ) NEW_LINE head = push ( head , 2 ) NEW_LINE head = push ( head , 1 ) NEW_LINE k = 2 NEW_LINE
updated_head = rightRotate ( head , k ) NEW_LINE
printList ( updated_head ) NEW_LINE
def isPossible ( a , n ) : NEW_LINE
if ( n <= 2 ) : NEW_LINE INDENT return True ; NEW_LINE DEDENT flag = 0 ; NEW_LINE
for i in range ( n - 2 ) : NEW_LINE INDENT if ( not ( a [ i ] > a [ i + 1 ] and a [ i + 1 ] > a [ i + 2 ] ) ) : NEW_LINE INDENT flag = 1 ; NEW_LINE break ; NEW_LINE DEDENT DEDENT
if ( flag == 0 ) : NEW_LINE INDENT return True ; NEW_LINE DEDENT flag = 0 ; NEW_LINE
for i in range ( n - 2 ) : NEW_LINE INDENT if ( not ( a [ i ] < a [ i + 1 ] and a [ i + 1 ] < a [ i + 2 ] ) ) : NEW_LINE INDENT flag = 1 ; NEW_LINE break ; NEW_LINE DEDENT DEDENT
if ( flag == 0 ) : NEW_LINE INDENT return True ; NEW_LINE DEDENT
val1 = sys . maxsize ; mini = - 1 ; NEW_LINE val2 = - sys . maxsize ; maxi = - 1 ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( a [ i ] < val1 ) : NEW_LINE INDENT mini = i ; NEW_LINE val1 = a [ i ] ; NEW_LINE DEDENT if ( a [ i ] > val2 ) : NEW_LINE INDENT maxi = i ; NEW_LINE val2 = a [ i ] ; NEW_LINE DEDENT DEDENT flag = 1 ; NEW_LINE
for i in range ( maxi ) : NEW_LINE INDENT if ( a [ i ] > a [ i + 1 ] ) : NEW_LINE INDENT flag = 0 ; NEW_LINE break ; NEW_LINE DEDENT DEDENT
if ( flag == 1 and maxi + 1 == mini ) : NEW_LINE INDENT flag = 1 ; NEW_LINE DEDENT
for i in range ( mini , n - 1 ) : NEW_LINE INDENT if ( a [ i ] > a [ i + 1 ] ) : NEW_LINE INDENT flag = 0 ; NEW_LINE break ; NEW_LINE DEDENT DEDENT if ( flag == 1 ) : NEW_LINE INDENT return True ; NEW_LINE DEDENT flag = 1 ; NEW_LINE
for i in range ( mini ) : NEW_LINE INDENT if ( a [ i ] < a [ i + 1 ] ) : NEW_LINE INDENT flag = 0 ; NEW_LINE break ; NEW_LINE DEDENT DEDENT
if ( flag == 1 and maxi - 1 == mini ) : NEW_LINE INDENT flag = 1 ; NEW_LINE DEDENT
for i in range ( maxi , n - 1 ) : NEW_LINE INDENT if ( a [ i ] < a [ i + 1 ] ) : NEW_LINE INDENT flag = 0 ; NEW_LINE break ; NEW_LINE DEDENT DEDENT if ( flag == 1 ) : NEW_LINE INDENT return True ; NEW_LINE DEDENT
return False ; NEW_LINE
a = [ 4 , 5 , 6 , 2 , 3 ] ; NEW_LINE n = len ( a ) ; NEW_LINE if ( isPossible ( a , n ) ) : NEW_LINE INDENT print ( " Yes " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) ; NEW_LINE DEDENT
def cntRotations ( s , n ) : NEW_LINE
str = s + s ; NEW_LINE
pre = [ 0 ] * ( 2 * n ) ; NEW_LINE
for i in range ( 2 * n ) : NEW_LINE INDENT if ( i != 0 ) : NEW_LINE INDENT pre [ i ] += pre [ i - 1 ] ; NEW_LINE DEDENT if ( str [ i ] == ' a ' or str [ i ] == ' e ' or str [ i ] == ' i ' or str [ i ] == ' o ' or str [ i ] == ' u ' ) : NEW_LINE INDENT pre [ i ] += 1 ; NEW_LINE DEDENT DEDENT
ans = 0 ; NEW_LINE
for i in range ( n - 1 , 2 * n - 1 , 1 ) : NEW_LINE
r = i ; l = i - n ; NEW_LINE
x1 = pre [ r ] ; NEW_LINE if ( l >= 0 ) : NEW_LINE INDENT x1 -= pre [ l ] ; NEW_LINE DEDENT r = ( int ) ( i - n / 2 ) ; NEW_LINE
left = pre [ r ] ; NEW_LINE if ( l >= 0 ) : NEW_LINE INDENT left -= pre [ l ] ; NEW_LINE DEDENT
right = x1 - left ; NEW_LINE
if ( left > right ) : NEW_LINE INDENT ans += 1 ; NEW_LINE DEDENT
return ans ; NEW_LINE
s = " abecidft " ; NEW_LINE n = len ( s ) ; NEW_LINE print ( cntRotations ( s , n ) ) ; NEW_LINE
def cntRotations ( s , n ) : NEW_LINE INDENT lh , rh , ans = 0 , 0 , 0 NEW_LINE DEDENT
for i in range ( n // 2 ) : NEW_LINE INDENT if ( s [ i ] == ' a ' or s [ i ] == ' e ' or s [ i ] == ' i ' or s [ i ] == ' o ' or s [ i ] == ' u ' ) : NEW_LINE INDENT lh += 1 NEW_LINE DEDENT DEDENT
for i in range ( n // 2 , n ) : NEW_LINE INDENT if ( s [ i ] == ' a ' or s [ i ] == ' e ' or s [ i ] == ' i ' or s [ i ] == ' o ' or s [ i ] == ' u ' ) : NEW_LINE INDENT rh += 1 NEW_LINE DEDENT DEDENT
if ( lh > rh ) : NEW_LINE INDENT ans += 1 NEW_LINE DEDENT
for i in range ( 1 , n ) : NEW_LINE INDENT if ( s [ i - 1 ] == ' a ' or s [ i - 1 ] == ' e ' or s [ i - 1 ] == ' i ' or s [ i - 1 ] == ' o ' or s [ i - 1 ] == ' u ' ) : NEW_LINE INDENT rh += 1 NEW_LINE lh -= 1 NEW_LINE DEDENT if ( s [ ( i - 1 + n // 2 ) % n ] == ' a ' or s [ ( i - 1 + n // 2 ) % n ] == ' e ' or s [ ( i - 1 + n // 2 ) % n ] == ' i ' or s [ ( i - 1 + n // 2 ) % n ] == ' o ' or s [ ( i - 1 + n // 2 ) % n ] == ' u ' ) : NEW_LINE INDENT rh -= 1 NEW_LINE lh += 1 NEW_LINE DEDENT if ( lh > rh ) : NEW_LINE INDENT ans += 1 NEW_LINE DEDENT DEDENT
return ans NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT s = " abecidft " NEW_LINE n = len ( s ) NEW_LINE DEDENT
print ( cntRotations ( s , n ) ) NEW_LINE
size = 2 NEW_LINE
def performQueries ( string , n , queries , q ) : NEW_LINE
ptr = 0 ; NEW_LINE
for i in range ( q ) : NEW_LINE
if ( queries [ i ] [ 0 ] == 1 ) : NEW_LINE
ptr = ( ptr + queries [ i ] [ 1 ] ) % n ; NEW_LINE else : NEW_LINE k = queries [ i ] [ 1 ] ; NEW_LINE
index = ( ptr + k - 1 ) % n ; NEW_LINE
print ( string [ index ] ) ; NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT string = " abcdefgh " ; NEW_LINE n = len ( string ) ; NEW_LINE queries = [ [ 1 , 2 ] , [ 2 , 2 ] , [ 1 , 4 ] , [ 2 , 7 ] ] ; NEW_LINE q = len ( queries ) ; NEW_LINE performQueries ( string , n , queries , q ) ; NEW_LINE DEDENT
def ReverseArray ( arr , left , right ) : NEW_LINE INDENT while ( left < right ) : NEW_LINE INDENT temp = arr [ left ] ; NEW_LINE arr [ left ] = arr [ right ] ; NEW_LINE arr [ right ] = temp ; NEW_LINE left += 1 ; NEW_LINE right -= 1 ; NEW_LINE DEDENT DEDENT
def RotateAndCheck ( str1 , str2 , d ) : NEW_LINE INDENT if ( len ( str1 ) != len ( str2 ) ) : NEW_LINE INDENT return False ; NEW_LINE DEDENT DEDENT
left_rot_str1 = [ ] ; right_rot_str1 = [ ] ; NEW_LINE left_flag = True ; right_flag = True ; NEW_LINE str1_size = len ( str1 ) ; NEW_LINE
for i in range ( str1_size ) : NEW_LINE INDENT left_rot_str1 . append ( str1 [ i ] ) ; NEW_LINE right_rot_str1 . append ( str1 [ i ] ) ; NEW_LINE DEDENT
ReverseArray ( left_rot_str1 , 0 , d - 1 ) ; NEW_LINE ReverseArray ( left_rot_str1 , d , str1_size - 1 ) ; NEW_LINE ReverseArray ( left_rot_str1 , 0 , str1_size - 1 ) ; NEW_LINE
ReverseArray ( right_rot_str1 , 0 , str1_size - d - 1 ) ; NEW_LINE ReverseArray ( right_rot_str1 , str1_size - d , str1_size - 1 ) ; NEW_LINE ReverseArray ( right_rot_str1 , 0 , str1_size - 1 ) ; NEW_LINE
for i in range ( str1_size ) : NEW_LINE
if ( left_rot_str1 [ i ] != str2 [ i ] ) : NEW_LINE INDENT left_flag = False ; NEW_LINE DEDENT
if ( right_rot_str1 [ i ] != str2 [ i ] ) : NEW_LINE INDENT right_flag = False ; NEW_LINE DEDENT
if ( left_flag or right_flag ) : NEW_LINE INDENT return True ; NEW_LINE DEDENT return False ; NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT str1 = list ( " abcdefg " ) ; NEW_LINE str2 = list ( " cdefgab " ) ; NEW_LINE DEDENT
d = 2 ; NEW_LINE
d = d % len ( str1 ) ; NEW_LINE if ( RotateAndCheck ( str1 , str2 , d ) ) : NEW_LINE INDENT print ( " Yes " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) ; NEW_LINE DEDENT
def countOddRotations ( n ) : NEW_LINE INDENT odd_count = 0 ; even_count = 0 NEW_LINE while n != 0 : NEW_LINE INDENT digit = n % 10 NEW_LINE if digit % 2 == 0 : NEW_LINE INDENT odd_count += 1 NEW_LINE DEDENT else : NEW_LINE INDENT even_count += 1 NEW_LINE DEDENT n = n // 10 NEW_LINE DEDENT print ( " Odd ▁ = " , odd_count ) NEW_LINE print ( " Even ▁ = " , even_count ) NEW_LINE DEDENT
n = 1234 NEW_LINE countOddRotations ( n ) NEW_LINE
def numberofDigits ( n ) : NEW_LINE INDENT cnt = 0 NEW_LINE while n > 0 : NEW_LINE INDENT cnt += 1 NEW_LINE n //= 10 NEW_LINE DEDENT return cnt NEW_LINE DEDENT
def cal ( num ) : NEW_LINE INDENT digit = numberofDigits ( num ) NEW_LINE powTen = pow ( 10 , digit - 1 ) NEW_LINE for i in range ( digit - 1 ) : NEW_LINE INDENT firstDigit = num // powTen NEW_LINE DEDENT DEDENT
left = ( num * 10 + firstDigit - ( firstDigit * powTen * 10 ) ) NEW_LINE print ( left , end = " ▁ " ) NEW_LINE
num = left NEW_LINE
num = 1445 NEW_LINE cal ( num ) NEW_LINE
def CheckKCycles ( n , s ) : NEW_LINE INDENT ff = True NEW_LINE for i in range ( 1 , n ) : NEW_LINE DEDENT
x = int ( s [ i : ] + s [ 0 : i ] ) NEW_LINE
if ( x >= int ( s ) ) : NEW_LINE INDENT continue NEW_LINE DEDENT ff = False NEW_LINE break NEW_LINE if ( ff ) : NEW_LINE print ( " Yes " ) NEW_LINE else : NEW_LINE print ( " No " ) NEW_LINE
n = 3 NEW_LINE s = "123" NEW_LINE CheckKCycles ( n , s ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def rotateSubList ( A , m , n , k ) : NEW_LINE INDENT size = n - m + 1 NEW_LINE DEDENT
if ( k > size ) : NEW_LINE INDENT k = k % size NEW_LINE DEDENT
if ( k == 0 or k == size ) : NEW_LINE INDENT head = A NEW_LINE while ( head != None ) : NEW_LINE INDENT print ( head . data ) NEW_LINE head = head . next NEW_LINE DEDENT return NEW_LINE DEDENT
link = None NEW_LINE if ( m == 1 ) : NEW_LINE INDENT link = A NEW_LINE DEDENT
c = A NEW_LINE
count = 0 NEW_LINE end = None NEW_LINE
pre = None NEW_LINE while ( c != None ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT
if ( count == m - 1 ) : NEW_LINE INDENT pre = c NEW_LINE link = c . next NEW_LINE DEDENT if ( count == n - k ) : NEW_LINE INDENT if ( m == 1 ) : NEW_LINE INDENT end = c NEW_LINE A = c . next NEW_LINE DEDENT else : NEW_LINE INDENT end = c NEW_LINE DEDENT DEDENT
pre . next = c . next NEW_LINE
if ( count == n ) : NEW_LINE INDENT d = c . next NEW_LINE c . next = link NEW_LINE end . next = d NEW_LINE head = A NEW_LINE while ( head != None ) : NEW_LINE INDENT print ( head . data , end = " ▁ " ) NEW_LINE head = head . next NEW_LINE DEDENT return NEW_LINE DEDENT c = c . next NEW_LINE
def push ( head , val ) : NEW_LINE INDENT new_node = Node ( val ) NEW_LINE new_node . data = val NEW_LINE new_node . next = head NEW_LINE head = new_node NEW_LINE return head NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT head = None NEW_LINE head = push ( head , 70 ) NEW_LINE head = push ( head , 60 ) NEW_LINE head = push ( head , 50 ) NEW_LINE head = push ( head , 40 ) NEW_LINE head = push ( head , 30 ) NEW_LINE head = push ( head , 20 ) NEW_LINE head = push ( head , 10 ) NEW_LINE tmp = head NEW_LINE print ( " Given ▁ List : ▁ " , end = " " ) NEW_LINE while ( tmp != None ) : NEW_LINE INDENT print ( tmp . data , end = " ▁ " ) NEW_LINE tmp = tmp . next NEW_LINE DEDENT print ( ) NEW_LINE m = 3 NEW_LINE n = 6 NEW_LINE k = 2 NEW_LINE print ( " After ▁ rotation ▁ of ▁ sublist : ▁ " , end = " " ) NEW_LINE rotateSubList ( head , m , n , k ) NEW_LINE DEDENT
def rightRotationDivisor ( N ) : NEW_LINE INDENT lastDigit = N % 10 NEW_LINE rightRotation = ( lastDigit * 10 ** int ( log10 ( N ) ) + N // 10 ) NEW_LINE return rightRotation % N == 0 NEW_LINE DEDENT
def generateNumbers ( m ) : NEW_LINE INDENT for i in range ( 10 ** ( m - 1 ) , 10 ** m ) : NEW_LINE INDENT if rightRotationDivisor ( i ) : NEW_LINE INDENT print ( i ) NEW_LINE DEDENT DEDENT DEDENT
m = 3 NEW_LINE generateNumbers ( m ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE self . next = None NEW_LINE DEDENT DEDENT next = None NEW_LINE
def populateNext ( p ) : NEW_LINE INDENT global next NEW_LINE DEDENT
if ( p != None ) : NEW_LINE
populateNext ( p . right ) NEW_LINE
p . next = next NEW_LINE
next = p NEW_LINE
populateNext ( p . left ) NEW_LINE
root = newnode ( 10 ) NEW_LINE root . left = newnode ( 8 ) NEW_LINE root . right = newnode ( 12 ) NEW_LINE root . left . left = newnode ( 3 ) NEW_LINE
p = populateNext ( root ) NEW_LINE
ptr = root . left . left NEW_LINE while ( ptr != None ) : NEW_LINE
out = 0 NEW_LINE if ( ptr . next != None ) : NEW_LINE INDENT out = ptr . next . data NEW_LINE DEDENT else : NEW_LINE INDENT out = - 1 NEW_LINE DEDENT print ( " Next ▁ of " , ptr . data , " is " , out ) NEW_LINE ptr = ptr . next NEW_LINE
def generateNumbers ( m ) : NEW_LINE INDENT numbers = [ ] NEW_LINE for y in range ( 1 , 10 ) : NEW_LINE INDENT k_max = ( ( 10 ** ( m - 2 ) * ( 10 * y + 1 ) ) // ( 10 ** ( m - 1 ) + y ) ) NEW_LINE for k in range ( 1 , k_max + 1 ) : NEW_LINE INDENT x = ( ( y * ( 10 ** ( m - 1 ) - k ) ) // ( 10 * k - 1 ) ) NEW_LINE if ( ( y * ( 10 ** ( m - 1 ) - k ) ) % ( 10 * k - 1 ) == 0 ) : NEW_LINE INDENT numbers . append ( 10 * x + y ) NEW_LINE DEDENT DEDENT DEDENT for n in sorted ( numbers ) : NEW_LINE INDENT print ( n ) NEW_LINE DEDENT DEDENT
m = 3 NEW_LINE generateNumbers ( m ) NEW_LINE
def checkIfSortRotated ( arr , n ) : NEW_LINE INDENT minEle = sys . maxsize NEW_LINE maxEle = - sys . maxsize - 1 NEW_LINE minIndex = - 1 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if arr [ i ] < minEle : NEW_LINE INDENT minEle = arr [ i ] NEW_LINE minIndex = i NEW_LINE DEDENT DEDENT flag1 = 1 NEW_LINE
for i in range ( 1 , minIndex ) : NEW_LINE INDENT if arr [ i ] < arr [ i - 1 ] : NEW_LINE INDENT flag1 = 0 NEW_LINE break NEW_LINE DEDENT DEDENT flag2 = 2 NEW_LINE
for i in range ( minIndex + 1 , n ) : NEW_LINE INDENT if arr [ i ] < arr [ i - 1 ] : NEW_LINE INDENT flag2 = 0 NEW_LINE break NEW_LINE DEDENT DEDENT
if ( flag1 and flag2 and arr [ n - 1 ] < arr [ 0 ] ) : NEW_LINE INDENT print ( " YES " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " NO " ) NEW_LINE DEDENT
arr = [ 3 , 4 , 5 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE
checkIfSortRotated ( arr , n ) NEW_LINE
N = 4 NEW_LINE
def rotate90Clockwise ( arr ) : NEW_LINE INDENT global N NEW_LINE DEDENT
for j in range ( N ) : NEW_LINE INDENT for i in range ( N - 1 , - 1 , - 1 ) : NEW_LINE INDENT print ( arr [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
arr = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 ] ] NEW_LINE rotate90Clockwise ( arr ) ; NEW_LINE
def occurredOnce ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
if arr [ 0 ] != arr [ 1 ] : NEW_LINE INDENT print ( arr [ 0 ] , end = " ▁ " ) NEW_LINE DEDENT
for i in range ( 1 , n - 1 ) : NEW_LINE INDENT if ( arr [ i ] != arr [ i + 1 ] and arr [ i ] != arr [ i - 1 ] ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
if arr [ n - 2 ] != arr [ n - 1 ] : NEW_LINE INDENT print ( arr [ n - 1 ] , end = " ▁ " ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE occurredOnce ( arr , n ) NEW_LINE DEDENT
def occurredOnce ( arr , n ) : NEW_LINE INDENT mp = dict ( ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if arr [ i ] in mp . keys ( ) : NEW_LINE INDENT mp [ arr [ i ] ] += 1 NEW_LINE DEDENT else : NEW_LINE INDENT mp [ arr [ i ] ] = 1 NEW_LINE DEDENT DEDENT
for it in mp : NEW_LINE INDENT if mp [ it ] == 1 : NEW_LINE INDENT print ( it , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE occurredOnce ( arr , n ) NEW_LINE
def occurredOnce ( arr , n ) : NEW_LINE INDENT i = 1 NEW_LINE len = n NEW_LINE DEDENT
if arr [ 0 ] == arr [ len - 1 ] : NEW_LINE INDENT i = 2 NEW_LINE len -= 1 NEW_LINE DEDENT
while i < n : NEW_LINE
if arr [ i ] == arr [ i - 1 ] : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT print ( arr [ i - 1 ] , end = " ▁ " ) NEW_LINE DEDENT i += 1 NEW_LINE
if ( arr [ n - 1 ] != arr [ 0 ] and arr [ n - 1 ] != arr [ n - 2 ] ) : NEW_LINE INDENT print ( arr [ n - 1 ] ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE occurredOnce ( arr , n ) NEW_LINE DEDENT
def rvereseArray ( arr , start , end ) : NEW_LINE INDENT while start < end : NEW_LINE INDENT temp = arr [ start ] NEW_LINE arr [ start ] = arr [ end ] NEW_LINE arr [ end ] = temp NEW_LINE start += 1 NEW_LINE end -= 1 NEW_LINE DEDENT DEDENT
def printArray ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def splitArr ( arr , k , n ) : NEW_LINE INDENT rvereseArray ( arr , 0 , n - 1 ) NEW_LINE rvereseArray ( arr , 0 , n - k - 1 ) NEW_LINE rvereseArray ( arr , n - k , n - 1 ) NEW_LINE DEDENT
arr = [ 12 , 10 , 5 , 6 , 52 , 36 ] NEW_LINE n = len ( arr ) NEW_LINE k = 2 NEW_LINE
splitArr ( arr , k , n ) NEW_LINE printArray ( arr , n ) NEW_LINE
def isRotation ( a : str , b : str ) -> bool : NEW_LINE INDENT n = len ( a ) NEW_LINE m = len ( b ) NEW_LINE if ( n != m ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
lps = [ 0 for _ in range ( n ) ] NEW_LINE
length = 0 NEW_LINE i = 1 NEW_LINE
lps [ 0 ] = 0 NEW_LINE
while ( i < n ) : NEW_LINE INDENT if ( a [ i ] == b [ length ] ) : NEW_LINE INDENT length += 1 NEW_LINE lps [ i ] = length NEW_LINE i += 1 NEW_LINE DEDENT else : NEW_LINE INDENT if ( length == 0 ) : NEW_LINE INDENT lps [ i ] = 0 NEW_LINE i += 1 NEW_LINE DEDENT else : NEW_LINE INDENT length = lps [ length - 1 ] NEW_LINE DEDENT DEDENT DEDENT i = 0 NEW_LINE
for k in range ( lps [ n - 1 ] , m ) : NEW_LINE INDENT if ( b [ k ] != a [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT i += 1 NEW_LINE DEDENT return True NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT s1 = " ABACD " NEW_LINE s2 = " CDABA " NEW_LINE print ( "1" if isRotation ( s1 , s2 ) else "0" ) NEW_LINE DEDENT
def countRotationsDivBy8 ( n ) : NEW_LINE INDENT l = len ( n ) NEW_LINE count = 0 NEW_LINE DEDENT
if ( l == 1 ) : NEW_LINE INDENT oneDigit = int ( n [ 0 ] ) NEW_LINE if ( oneDigit % 8 == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT return 0 NEW_LINE DEDENT
if ( l == 2 ) : NEW_LINE
first = int ( n [ 0 ] ) * 10 + int ( n [ 1 ] ) NEW_LINE
second = int ( n [ 1 ] ) * 10 + int ( n [ 0 ] ) NEW_LINE if ( first % 8 == 0 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT if ( second % 8 == 0 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT return count NEW_LINE
threeDigit = 0 NEW_LINE for i in range ( 0 , ( l - 2 ) ) : NEW_LINE INDENT threeDigit = ( int ( n [ i ] ) * 100 + int ( n [ i + 1 ] ) * 10 + int ( n [ i + 2 ] ) ) NEW_LINE if ( threeDigit % 8 == 0 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT
threeDigit = ( int ( n [ l - 1 ] ) * 100 + int ( n [ 0 ] ) * 10 + int ( n [ 1 ] ) ) NEW_LINE if ( threeDigit % 8 == 0 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
threeDigit = ( int ( n [ l - 2 ] ) * 100 + int ( n [ l - 1 ] ) * 10 + int ( n [ 0 ] ) ) NEW_LINE if ( threeDigit % 8 == 0 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
return count NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = "43262488612" NEW_LINE print ( " Rotations : " , countRotationsDivBy8 ( n ) ) NEW_LINE DEDENT
def minimunMoves ( arr , n ) : NEW_LINE INDENT ans = sys . maxsize NEW_LINE for i in range ( n ) : NEW_LINE INDENT curr_count = 0 NEW_LINE DEDENT DEDENT
for j in range ( n ) : NEW_LINE INDENT tmp = arr [ j ] + arr [ j ] NEW_LINE DEDENT
index = tmp . find ( arr [ i ] ) NEW_LINE
if ( index == len ( arr [ i ] ) ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT curr_count += index NEW_LINE ans = min ( curr_count , ans ) NEW_LINE return ans NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ " xzzwo " , " zwoxz " , " zzwox " , " xzzwo " ] NEW_LINE n = len ( arr ) NEW_LINE print ( minimunMoves ( arr , n ) ) NEW_LINE DEDENT
def restoreSortedArray ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] > arr [ i + 1 ] ) : NEW_LINE DEDENT DEDENT
reverse ( arr , 0 , i ) ; NEW_LINE reverse ( arr , i + 1 , n ) ; NEW_LINE reverse ( arr , 0 , n ) ; NEW_LINE def reverse ( arr , i , j ) : NEW_LINE while ( i < j ) : NEW_LINE temp = arr [ i ] ; NEW_LINE arr [ i ] = arr [ j ] ; NEW_LINE arr [ j ] = temp ; NEW_LINE i += 1 ; NEW_LINE j -= 1 ; NEW_LINE
def printArray ( arr , size ) : NEW_LINE INDENT for i in range ( size ) : NEW_LINE INDENT print ( arr [ i ] , end = " " ) ; NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 3 , 4 , 5 , 1 , 2 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE restoreSortedArray ( arr , n - 1 ) ; NEW_LINE printArray ( arr , n ) ; NEW_LINE DEDENT
def findStartIndexOfArray ( arr , low , high ) : NEW_LINE INDENT if ( low > high ) : NEW_LINE INDENT return - 1 ; NEW_LINE DEDENT if ( low == high ) : NEW_LINE INDENT return low ; NEW_LINE DEDENT mid = low + ( high - low ) / 2 ; NEW_LINE if ( arr [ mid ] > arr [ mid + 1 ] ) : NEW_LINE INDENT return mid + 1 ; NEW_LINE DEDENT if ( arr [ mid - 1 ] > arr [ mid ] ) : NEW_LINE INDENT return mid ; NEW_LINE DEDENT if ( arr [ low ] > arr [ mid ] ) : NEW_LINE INDENT return findStartIndexOfArray ( arr , low , mid - 1 ) ; NEW_LINE DEDENT else : NEW_LINE INDENT return findStartIndexOfArray ( arr , mid + 1 , high ) ; NEW_LINE DEDENT DEDENT
def restoreSortedArray ( arr , n ) : NEW_LINE
if ( arr [ 0 ] < arr [ n - 1 ] ) : NEW_LINE INDENT return ; NEW_LINE DEDENT start = findStartIndexOfArray ( arr , 0 , n - 1 ) ; NEW_LINE
reverse ( arr , 0 , start ) ; NEW_LINE reverse ( arr , start , n ) ; NEW_LINE reverse ( arr ) ; NEW_LINE
def printArray ( arr , size ) : NEW_LINE INDENT for i in range ( size ) : NEW_LINE INDENT print ( arr [ i ] , end = " " ) ; NEW_LINE DEDENT DEDENT def reverse ( arr , i , j ) : NEW_LINE INDENT while ( i < j ) : NEW_LINE INDENT temp = arr [ i ] ; NEW_LINE arr [ i ] = arr [ j ] ; NEW_LINE arr [ j ] = temp ; NEW_LINE i += 1 ; NEW_LINE j -= 1 ; NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 2 , 3 , 4 , 5 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE restoreSortedArray ( arr , n ) ; NEW_LINE printArray ( arr , n ) ; NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def countRotation ( head ) : NEW_LINE
count = 0 NEW_LINE
min = head . data NEW_LINE
while ( head != None ) : NEW_LINE
if ( min > head . data ) : NEW_LINE INDENT break NEW_LINE DEDENT count += 1 NEW_LINE
head = head . next NEW_LINE return count NEW_LINE
def push ( head , data ) : NEW_LINE
newNode = Node ( data ) NEW_LINE
newNode . data = data NEW_LINE
newNode . next = ( head ) NEW_LINE
( head ) = newNode NEW_LINE return head NEW_LINE
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = ' ▁ ' ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
head = None NEW_LINE
head = push ( head , 12 ) NEW_LINE head = push ( head , 11 ) NEW_LINE head = push ( head , 8 ) NEW_LINE head = push ( head , 5 ) NEW_LINE head = push ( head , 18 ) NEW_LINE head = push ( head , 15 ) NEW_LINE printList ( head ) ; NEW_LINE print ( ) NEW_LINE print ( " Linked ▁ list ▁ rotated ▁ elements : ▁ " , end = ' ' ) NEW_LINE
print ( countRotation ( head ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def rotateHelper ( blockHead , blockTail , d , tail , k ) : NEW_LINE INDENT if ( d == 0 ) : NEW_LINE INDENT return blockHead , tail NEW_LINE DEDENT DEDENT
if ( d > 0 ) : NEW_LINE INDENT temp = blockHead NEW_LINE i = 1 NEW_LINE while temp . next . next != None and i < k - 1 : NEW_LINE INDENT temp = temp . next NEW_LINE i += 1 NEW_LINE DEDENT blockTail . next = blockHead NEW_LINE tail = temp NEW_LINE return rotateHelper ( blockTail , temp , d - 1 , tail , k ) NEW_LINE DEDENT
if ( d < 0 ) : NEW_LINE INDENT blockTail . next = blockHead NEW_LINE tail = blockHead NEW_LINE return rotateHelper ( blockHead . next , blockHead , d + 1 , tail , k ) NEW_LINE DEDENT
def rotateByBlocks ( head , k , d ) : NEW_LINE
if ( head == None or head . next == None ) : NEW_LINE INDENT return head NEW_LINE DEDENT
if ( d == 0 ) : NEW_LINE INDENT return head NEW_LINE DEDENT temp = head NEW_LINE tail = None NEW_LINE
i = 1 NEW_LINE while temp . next != None and i < k : NEW_LINE INDENT temp = temp . next NEW_LINE i += 1 NEW_LINE DEDENT
nextBlock = temp . next NEW_LINE
if ( i < k ) : NEW_LINE INDENT head , tail = rotateHelper ( head , temp , d % k , tail , i ) NEW_LINE DEDENT else : NEW_LINE INDENT head , tail = rotateHelper ( head , temp , d % k , tail , k ) NEW_LINE DEDENT
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ; NEW_LINE
return head ; NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE INDENT new_node = Node ( new_data ) NEW_LINE new_node . data = new_data NEW_LINE new_node . next = ( head_ref ) NEW_LINE ( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE DEDENT
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = ' ▁ ' ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
head = None NEW_LINE
for i in range ( 9 , 0 , - 1 ) : NEW_LINE INDENT head = push ( head , i ) NEW_LINE DEDENT print ( " Given ▁ linked ▁ list ▁ " ) NEW_LINE printList ( head ) NEW_LINE
k = 3 NEW_LINE d = 2 NEW_LINE head = rotateByBlocks ( head , k , d ) NEW_LINE print ( " Rotated by blocks Linked list   " ) NEW_LINE printList ( head ) NEW_LINE
def isRotation ( x , y ) : NEW_LINE
x64 = x | ( x << 32 ) NEW_LINE while ( x64 >= y ) : NEW_LINE
if ( ( x64 ) == y ) : NEW_LINE INDENT return True NEW_LINE DEDENT
x64 >>= 1 NEW_LINE return False NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT x = 122 NEW_LINE y = 2147483678 NEW_LINE if ( isRotation ( x , y ) == False ) : NEW_LINE INDENT print ( " yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " no " ) NEW_LINE DEDENT DEDENT
def leftrotate ( s , d ) : NEW_LINE INDENT tmp = s [ d : ] + s [ 0 : d ] NEW_LINE return tmp NEW_LINE DEDENT
def rightrotate ( s , d ) : NEW_LINE INDENT return leftrotate ( s , len ( s ) - d ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT str1 = " GeeksforGeeks " NEW_LINE print ( leftrotate ( str1 , 2 ) ) NEW_LINE str2 = " GeeksforGeeks " NEW_LINE print ( rightrotate ( str2 , 2 ) ) NEW_LINE DEDENT
def countRotations ( n ) : NEW_LINE INDENT l = len ( n ) NEW_LINE DEDENT
if ( l == 1 ) : NEW_LINE INDENT oneDigit = ( int ) ( n [ 0 ] ) NEW_LINE if ( oneDigit % 4 == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT return 0 NEW_LINE DEDENT
count = 0 NEW_LINE for i in range ( 0 , l - 1 ) : NEW_LINE INDENT twoDigit = ( int ) ( n [ i ] ) * 10 + ( int ) ( n [ i + 1 ] ) NEW_LINE if ( twoDigit % 4 == 0 ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT DEDENT
twoDigit = ( int ) ( n [ l - 1 ] ) * 10 + ( int ) ( n [ 0 ] ) NEW_LINE if ( twoDigit % 4 == 0 ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT return count NEW_LINE
n = "4834" NEW_LINE print ( " Rotations : ▁ " , countRotations ( n ) ) NEW_LINE
def isRotated ( str1 , str2 ) : NEW_LINE INDENT if ( len ( str1 ) != len ( str2 ) ) : NEW_LINE INDENT return False NEW_LINE DEDENT if ( len ( str1 ) < 2 ) : NEW_LINE INDENT return str1 == str2 NEW_LINE DEDENT clock_rot = " " NEW_LINE anticlock_rot = " " NEW_LINE l = len ( str2 ) NEW_LINE DEDENT
anticlock_rot = ( anticlock_rot + str2 [ l - 2 : ] + str2 [ 0 : l - 2 ] ) NEW_LINE
clock_rot = clock_rot + str2 [ 2 : ] + str2 [ 0 : 2 ] NEW_LINE
return ( str1 == clock_rot or str1 == anticlock_rot ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT str1 = " geeks " NEW_LINE str2 = " eksge " NEW_LINE DEDENT if isRotated ( str1 , str2 ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def minLexRotation ( str_ ) : NEW_LINE
n = len ( str_ ) NEW_LINE
arr = [ 0 ] * n NEW_LINE
concat = str_ + str_ NEW_LINE
for i in range ( n ) : NEW_LINE INDENT arr [ i ] = concat [ i : n + i ] NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
return arr [ 0 ] NEW_LINE
print ( minLexRotation ( " GEEKSFORGEEKS " ) ) NEW_LINE print ( minLexRotation ( " GEEKSQUIZ " ) ) NEW_LINE print ( minLexRotation ( " BCABDADAB " ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def rotate ( head_ref , k ) : NEW_LINE INDENT if ( k == 0 ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
current = head_ref NEW_LINE
while ( current . next != None ) : NEW_LINE INDENT current = current . next NEW_LINE DEDENT current . next = head_ref NEW_LINE current = head_ref NEW_LINE
for i in range ( k - 1 ) : NEW_LINE INDENT current = current . next NEW_LINE DEDENT
head_ref = current . next NEW_LINE current . next = None NEW_LINE return head_ref NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE
new_node = Node ( ) NEW_LINE
new_node . data = new_data NEW_LINE
new_node . next = ( head_ref ) NEW_LINE
( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE
def printList ( node ) : NEW_LINE INDENT while ( node != None ) : NEW_LINE INDENT print ( node . data , end = ' ▁ ' ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
for i in range ( 60 , 0 , - 10 ) : NEW_LINE INDENT head = push ( head , i ) NEW_LINE DEDENT print ( " Given ▁ linked ▁ list ▁ " ) NEW_LINE printList ( head ) NEW_LINE head = rotate ( head , 4 ) NEW_LINE print ( " Rotated Linked list   " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def push ( head_ref , data ) : NEW_LINE
ptr1 = Node ( ) NEW_LINE temp = head_ref ; NEW_LINE ptr1 . data = data ; NEW_LINE ptr1 . next = head_ref ; NEW_LINE
if ( head_ref != None ) : NEW_LINE
while ( temp . next != head_ref ) : NEW_LINE INDENT temp = temp . next ; NEW_LINE DEDENT temp . next = ptr1 ; NEW_LINE else : NEW_LINE
ptr1 . next = ptr1 ; NEW_LINE head_ref = ptr1 ; NEW_LINE return head_ref NEW_LINE
def delteteNode ( head_ref , delt ) : NEW_LINE
if ( head_ref == delt ) : NEW_LINE INDENT head_ref = delt . next ; NEW_LINE DEDENT temp = head_ref ; NEW_LINE
while ( temp . next != delt ) : NEW_LINE INDENT temp = temp . next ; NEW_LINE DEDENT
temp . next = delt . next ; NEW_LINE
del ( delt ) ; NEW_LINE return head_ref ; NEW_LINE
def isEvenParity ( x ) : NEW_LINE
parity = 0 ; NEW_LINE while ( x != 0 ) : NEW_LINE INDENT if ( x & 1 ) != 0 : NEW_LINE INDENT parity += 1 NEW_LINE DEDENT x = x >> 1 ; NEW_LINE DEDENT if ( parity % 2 == 0 ) : NEW_LINE INDENT return True ; NEW_LINE DEDENT else : NEW_LINE INDENT return False ; NEW_LINE DEDENT
def delteteEvenParityNodes ( head ) : NEW_LINE INDENT if ( head == None ) : NEW_LINE INDENT return head ; NEW_LINE DEDENT if ( head == head . next ) : NEW_LINE INDENT if ( isEvenParity ( head . data ) ) : NEW_LINE INDENT head = None ; NEW_LINE DEDENT return head ; NEW_LINE DEDENT ptr = head ; NEW_LINE next = None NEW_LINE DEDENT
while True : NEW_LINE INDENT next = ptr . next ; NEW_LINE DEDENT
if ( isEvenParity ( ptr . data ) ) : NEW_LINE INDENT head = delteteNode ( head , ptr ) ; NEW_LINE DEDENT
ptr = next ; NEW_LINE if ( ptr == head ) : NEW_LINE INDENT break NEW_LINE DEDENT if ( head == head . next ) : NEW_LINE if ( isEvenParity ( head . data ) ) : NEW_LINE INDENT head = None ; NEW_LINE DEDENT return head ; NEW_LINE return head ; NEW_LINE
def printList ( head ) : NEW_LINE INDENT if ( head == None ) : NEW_LINE INDENT print ( " Empty ▁ List " ) NEW_LINE return ; NEW_LINE DEDENT temp = head ; NEW_LINE if ( head != None ) : NEW_LINE INDENT while True : NEW_LINE INDENT print ( temp . data , end = ' ▁ ' ) NEW_LINE temp = temp . next NEW_LINE if temp == head : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT DEDENT
head = None ; NEW_LINE
head = push ( head , 21 ) ; NEW_LINE head = push ( head , 13 ) ; NEW_LINE head = push ( head , 6 ) ; NEW_LINE head = push ( head , 34 ) ; NEW_LINE head = push ( head , 9 ) ; NEW_LINE head = push ( head , 11 ) ; NEW_LINE head = delteteEvenParityNodes ( head ) ; NEW_LINE printList ( head ) ; NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def push ( head_ref , data ) : NEW_LINE
ptr1 = Node ( data ) NEW_LINE temp = head_ref NEW_LINE ptr1 . data = data NEW_LINE ptr1 . next = head_ref NEW_LINE
if ( head_ref != None ) : NEW_LINE
while ( temp . next != head_ref ) : NEW_LINE INDENT temp = temp . next NEW_LINE DEDENT temp . next = ptr1 NEW_LINE else : NEW_LINE
ptr1 . next = ptr1 NEW_LINE head_ref = ptr1 NEW_LINE return head_ref NEW_LINE
def delteteNode ( head_ref , delt ) : NEW_LINE INDENT temp = head_ref NEW_LINE DEDENT
if ( head_ref == delt ) : NEW_LINE INDENT head_ref = delt . next NEW_LINE DEDENT
while ( temp . next != delt ) : NEW_LINE INDENT temp = temp . next NEW_LINE DEDENT
temp . next = delt . next NEW_LINE
del ( delt ) NEW_LINE return NEW_LINE
def digitSum ( num ) : NEW_LINE INDENT sum = 0 NEW_LINE while ( num != 0 ) : NEW_LINE INDENT sum += ( num % 10 ) NEW_LINE num //= 10 NEW_LINE DEDENT return sum NEW_LINE DEDENT
def delteteEvenDigitSumNodes ( head ) : NEW_LINE INDENT ptr = head NEW_LINE next = None NEW_LINE DEDENT
while True : NEW_LINE
if ( not ( digitSum ( ptr . data ) & 1 ) ) : NEW_LINE INDENT delteteNode ( head , ptr ) NEW_LINE DEDENT
next = ptr . next NEW_LINE ptr = next NEW_LINE if ( ptr == head ) : NEW_LINE INDENT break NEW_LINE DEDENT
def printList ( head ) : NEW_LINE INDENT temp = head NEW_LINE if ( head != None ) : NEW_LINE INDENT while True : NEW_LINE INDENT print ( temp . data , end = ' ▁ ' ) NEW_LINE temp = temp . next NEW_LINE if ( temp == head ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT DEDENT
head = None NEW_LINE
head = push ( head , 21 ) NEW_LINE head = push ( head , 13 ) NEW_LINE head = push ( head , 6 ) NEW_LINE head = push ( head , 34 ) NEW_LINE head = push ( head , 11 ) NEW_LINE head = push ( head , 9 ) NEW_LINE delteteEvenDigitSumNodes ( head ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def push ( head_ref , data ) : NEW_LINE
ptr1 = Node ( ) NEW_LINE temp = head_ref ; NEW_LINE ptr1 . data = data ; NEW_LINE ptr1 . next = head_ref ; NEW_LINE
if ( head_ref != None ) : NEW_LINE
while ( temp . next != head_ref ) : NEW_LINE INDENT temp = temp . next ; NEW_LINE DEDENT temp . next = ptr1 ; NEW_LINE else : NEW_LINE
ptr1 . next = ptr1 ; NEW_LINE head_ref = ptr1 ; NEW_LINE return head_ref NEW_LINE
def deleteNode ( head_ref , delt ) : NEW_LINE INDENT temp = head_ref ; NEW_LINE DEDENT
if ( head_ref == delt ) : NEW_LINE INDENT head_ref = delt . next ; NEW_LINE DEDENT
while ( temp . next != delt ) : NEW_LINE INDENT temp = temp . next ; NEW_LINE DEDENT
temp . next = delt . next ; NEW_LINE
del ( delt ) ; NEW_LINE return ; NEW_LINE
def largestElement ( head_ref ) : NEW_LINE
current = None NEW_LINE
current = head_ref ; NEW_LINE
maxEle = - 10000000 NEW_LINE
while ( True ) : NEW_LINE
if ( current . data > maxEle ) : NEW_LINE INDENT maxEle = current . data ; NEW_LINE DEDENT current = current . next ; NEW_LINE if ( current == head_ref ) : NEW_LINE INDENT break NEW_LINE DEDENT return maxEle ; NEW_LINE
def createHash ( hashmap , maxElement ) : NEW_LINE INDENT prev = 0 NEW_LINE curr = 1 ; NEW_LINE DEDENT
hashmap . add ( prev ) ; NEW_LINE hashmap . add ( curr ) ; NEW_LINE
while ( curr <= maxElement ) : NEW_LINE INDENT temp = curr + prev ; NEW_LINE hashmap . add ( temp ) ; NEW_LINE prev = curr ; NEW_LINE curr = temp ; NEW_LINE DEDENT
def deleteFibonacciNodes ( head ) : NEW_LINE
maxEle = largestElement ( head ) ; NEW_LINE
hashmap = set ( ) NEW_LINE createHash ( hashmap , maxEle ) ; NEW_LINE ptr = head ; NEW_LINE next = None NEW_LINE
while ( True ) : NEW_LINE
if ( ptr . data in hashmap ) : NEW_LINE INDENT deleteNode ( head , ptr ) ; NEW_LINE DEDENT
next = ptr . next ; NEW_LINE ptr = next ; NEW_LINE if ( ptr == head ) : NEW_LINE INDENT break NEW_LINE DEDENT
def printList ( head ) : NEW_LINE INDENT temp = head ; NEW_LINE if ( head != None ) : NEW_LINE INDENT while ( True ) : NEW_LINE INDENT print ( temp . data , end = ' ▁ ' ) NEW_LINE temp = temp . next NEW_LINE if ( temp == head ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT DEDENT
head = None ; NEW_LINE
head = push ( head , 20 ) ; NEW_LINE head = push ( head , 13 ) ; NEW_LINE head = push ( head , 6 ) ; NEW_LINE head = push ( head , 34 ) ; NEW_LINE head = push ( head , 11 ) ; NEW_LINE head = push ( head , 9 ) ; NEW_LINE deleteFibonacciNodes ( head ) ; NEW_LINE printList ( head ) ; NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def push ( head_ref , data ) : NEW_LINE INDENT ptr1 = Node ( data ) NEW_LINE temp = head_ref NEW_LINE ptr1 . data = data NEW_LINE ptr1 . next = head_ref NEW_LINE DEDENT
if ( head_ref != None ) : NEW_LINE INDENT while ( temp . next != head_ref ) : NEW_LINE INDENT temp = temp . next NEW_LINE DEDENT temp . next = ptr1 NEW_LINE DEDENT else : NEW_LINE
ptr1 . next = ptr1 NEW_LINE head_ref = ptr1 NEW_LINE return head_ref NEW_LINE
def deleteNode ( head_ref , delete ) : NEW_LINE INDENT temp = head_ref NEW_LINE DEDENT
if ( head_ref == delete ) : NEW_LINE INDENT head_ref = delete . next NEW_LINE DEDENT
while ( temp . next != delete ) : NEW_LINE INDENT temp = temp . next NEW_LINE DEDENT
temp . next = delete . next NEW_LINE
def deleteoddNodes ( head ) : NEW_LINE INDENT ptr = head NEW_LINE next = None NEW_LINE DEDENT
next = ptr . next NEW_LINE ptr = next NEW_LINE while ( ptr != head ) : NEW_LINE INDENT if ( ptr . data % 2 == 1 ) : NEW_LINE INDENT deleteNode ( head , ptr ) NEW_LINE DEDENT DEDENT
next = ptr . next NEW_LINE ptr = next NEW_LINE return head NEW_LINE
def prList ( head ) : NEW_LINE INDENT temp = head NEW_LINE if ( head != None ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE while ( temp != head ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT DEDENT DEDENT
head = None NEW_LINE
head = push ( head , 2 ) NEW_LINE head = push ( head , 12 ) NEW_LINE head = push ( head , 11 ) NEW_LINE head = push ( head , 57 ) NEW_LINE head = push ( head , 61 ) NEW_LINE head = push ( head , 56 ) NEW_LINE print ( " List ▁ after ▁ deletion ▁ : ▁ " , end = " " ) NEW_LINE head = deleteoddNodes ( head ) NEW_LINE prList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . next = None NEW_LINE self . data = 0 NEW_LINE DEDENT DEDENT
def create ( ) : NEW_LINE INDENT new_node = Node ( ) NEW_LINE new_node . next = None NEW_LINE return new_node NEW_LINE DEDENT
def find_head ( random ) : NEW_LINE
if ( random == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT head = None NEW_LINE var = random NEW_LINE
while ( not ( var . data > var . next . data or var . next == random ) ) : NEW_LINE INDENT var = var . next NEW_LINE DEDENT
return var . next NEW_LINE
def sortedInsert ( head_ref , new_node ) : NEW_LINE INDENT current = head_ref NEW_LINE DEDENT
if ( current == None ) : NEW_LINE INDENT new_node . next = new_node NEW_LINE head_ref = new_node NEW_LINE DEDENT
elif ( current . data >= new_node . data ) : NEW_LINE
while ( current . next != head_ref ) : NEW_LINE INDENT current = current . next NEW_LINE DEDENT current . next = new_node NEW_LINE new_node . next = head_ref NEW_LINE head_ref = new_node NEW_LINE else : NEW_LINE
while ( current . next != head_ref and current . next . data < new_node . data ) : NEW_LINE INDENT current = current . next NEW_LINE DEDENT new_node . next = current . next NEW_LINE current . next = new_node NEW_LINE
return head_ref NEW_LINE
def printList ( start ) : NEW_LINE INDENT temp = 0 NEW_LINE if ( start != None ) : NEW_LINE INDENT temp = start NEW_LINE while True : NEW_LINE INDENT print ( temp . data , end = ' ▁ ' ) NEW_LINE temp = temp . next NEW_LINE if ( temp == start ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 12 , 56 , 2 , 11 , 1 , 90 ] NEW_LINE DEDENT
start = None ; NEW_LINE temp = 0 NEW_LINE
for i in range ( 6 ) : NEW_LINE
if ( start != None ) : NEW_LINE INDENT for j in range ( randint ( 0 , 10 ) ) : NEW_LINE INDENT start = start . next NEW_LINE DEDENT DEDENT temp = create ( ) NEW_LINE temp . data = arr [ i ] NEW_LINE start = sortedInsert ( find_head ( start ) , temp ) NEW_LINE
printList ( find_head ( start ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def addToEmpty ( last , data ) : NEW_LINE
if ( last != None ) : NEW_LINE INDENT return last NEW_LINE DEDENT
temp = Node ( data ) NEW_LINE last = temp NEW_LINE
last . next = last NEW_LINE return last NEW_LINE
def addBegin ( last , data ) : NEW_LINE
if ( last == None ) : NEW_LINE INDENT return addToEmpty ( data ) NEW_LINE DEDENT
temp = Node ( data ) NEW_LINE temp . next = last . next NEW_LINE last . next = temp NEW_LINE return last NEW_LINE
def traverse ( last ) : NEW_LINE
if ( last == None ) : NEW_LINE INDENT print ( " List ▁ is ▁ empty . " ) NEW_LINE return NEW_LINE DEDENT
p = last . next NEW_LINE
while True : NEW_LINE INDENT print ( p . data , end = " ▁ " ) NEW_LINE p = p . next NEW_LINE if p == last . next : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT print ( ) NEW_LINE
def length ( last ) : NEW_LINE
x = 0 NEW_LINE
if ( last == None ) : NEW_LINE INDENT return x NEW_LINE DEDENT
itr = last . next NEW_LINE while ( itr . next != last . next ) : NEW_LINE INDENT x += 1 NEW_LINE itr = itr . next NEW_LINE DEDENT
return ( x + 1 ) NEW_LINE
def split ( last , k ) : NEW_LINE
passs = Node ( - 1 ) NEW_LINE
if ( last == None ) : NEW_LINE INDENT return last NEW_LINE DEDENT
itr = last NEW_LINE for i in range ( k ) : NEW_LINE INDENT itr = itr . next NEW_LINE DEDENT
newLast = itr NEW_LINE passs . next = itr . next NEW_LINE newLast . next = last . next NEW_LINE last . next = passs . next NEW_LINE
return newLast NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT clist = None NEW_LINE clist = addToEmpty ( clist , 12 ) NEW_LINE clist = addBegin ( clist , 10 ) NEW_LINE clist = addBegin ( clist , 8 ) NEW_LINE clist = addBegin ( clist , 6 ) NEW_LINE clist = addBegin ( clist , 4 ) NEW_LINE clist = addBegin ( clist , 2 ) NEW_LINE print ( " Original ▁ list : " , end = " " ) NEW_LINE traverse ( clist ) NEW_LINE k = 4 NEW_LINE DEDENT
clist2 = split ( clist , k ) NEW_LINE
print ( " The ▁ new ▁ lists ▁ are : " , end = " " ) NEW_LINE traverse ( clist2 ) NEW_LINE traverse ( clist ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = self . right = None NEW_LINE DEDENT DEDENT v = [ ] NEW_LINE
def inorder ( root ) : NEW_LINE INDENT global v NEW_LINE if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
inorder ( root . left ) NEW_LINE
v . append ( root . data ) NEW_LINE
inorder ( root . right ) NEW_LINE
def bTreeToCList ( root ) : NEW_LINE INDENT global v NEW_LINE DEDENT
if ( root == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT
v = [ ] NEW_LINE
inorder ( root ) NEW_LINE
head_ref = Node ( v [ 0 ] ) NEW_LINE
curr = head_ref NEW_LINE i = 1 NEW_LINE
while ( i < len ( v ) ) : NEW_LINE
temp = curr NEW_LINE
curr . right = Node ( v [ i ] ) NEW_LINE
curr = curr . right NEW_LINE
curr . left = temp NEW_LINE i = i + 1 NEW_LINE
curr . right = head_ref NEW_LINE
head_ref . left = curr NEW_LINE
return head_ref NEW_LINE
def displayCList ( head ) : NEW_LINE INDENT print ( " Circular ▁ Doubly ▁ Linked ▁ List ▁ is ▁ : " , end = " " ) NEW_LINE itr = head NEW_LINE while ( True ) : NEW_LINE INDENT print ( itr . data , end = " ▁ " ) NEW_LINE itr = itr . right NEW_LINE if ( head == itr ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT print ( ) NEW_LINE DEDENT
root = Node ( 10 ) NEW_LINE root . left = Node ( 12 ) NEW_LINE root . right = Node ( 15 ) NEW_LINE root . left . left = Node ( 25 ) NEW_LINE root . left . right = Node ( 30 ) NEW_LINE root . right . left = Node ( 36 ) NEW_LINE head = bTreeToCList ( root ) NEW_LINE displayCList ( head ) NEW_LINE
def DeleteLast ( head ) : NEW_LINE INDENT current = head NEW_LINE temp = head NEW_LINE previous = None NEW_LINE DEDENT
if ( head == None ) : NEW_LINE INDENT print ( " List is empty " ) NEW_LINE return None NEW_LINE DEDENT
if ( current . next == current ) : NEW_LINE INDENT head = None NEW_LINE return None NEW_LINE DEDENT
while ( current . next != head ) : NEW_LINE INDENT previous = current NEW_LINE current = current . next NEW_LINE DEDENT previous . next = current . next NEW_LINE head = previous . next NEW_LINE return head NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def printMinMax ( head ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT return ; NEW_LINE DEDENT
current = head ; NEW_LINE
min = 1000000000 NEW_LINE max = - 1000000000 ; NEW_LINE
while True : NEW_LINE
if ( current . data < min ) : NEW_LINE INDENT min = current . data ; NEW_LINE DEDENT
if ( current . data > max ) : NEW_LINE INDENT max = current . data ; NEW_LINE DEDENT current = current . next ; NEW_LINE if ( current == head ) : NEW_LINE INDENT break NEW_LINE DEDENT print ( ' Minimum ▁ = ▁ { } , ▁ Maximum ▁ = ▁ { } ' . format ( min , max ) ) NEW_LINE
def insertNode ( head , data ) : NEW_LINE INDENT current = head ; NEW_LINE DEDENT
newNode = Node ( ) NEW_LINE
if not newNode : NEW_LINE INDENT print ( " Memory Error " ) ; NEW_LINE return head NEW_LINE DEDENT
newNode . data = data ; NEW_LINE
if ( head == None ) : NEW_LINE INDENT newNode . next = newNode ; NEW_LINE head = newNode ; NEW_LINE return head NEW_LINE DEDENT
else : NEW_LINE
while ( current . next != head ) : NEW_LINE INDENT current = current . next ; NEW_LINE DEDENT
newNode . next = head ; NEW_LINE
current . next = newNode ; NEW_LINE return head NEW_LINE
def displayList ( head ) : NEW_LINE INDENT current = head ; NEW_LINE DEDENT
if ( head == None ) : NEW_LINE INDENT print ( " Display List is empty " ) ; NEW_LINE return ; NEW_LINE DEDENT
else : NEW_LINE INDENT while True : NEW_LINE INDENT print ( current . data , end = ' ▁ ' ) ; NEW_LINE current = current . next ; NEW_LINE if ( current == head ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT print ( ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT Head = None ; NEW_LINE Head = insertNode ( Head , 99 ) ; NEW_LINE Head = insertNode ( Head , 11 ) ; NEW_LINE Head = insertNode ( Head , 22 ) ; NEW_LINE Head = insertNode ( Head , 33 ) ; NEW_LINE Head = insertNode ( Head , 44 ) ; NEW_LINE Head = insertNode ( Head , 55 ) ; NEW_LINE Head = insertNode ( Head , 66 ) ; NEW_LINE print ( " Initial ▁ List : ▁ " , end = ' ' ) NEW_LINE displayList ( Head ) ; NEW_LINE printMinMax ( Head ) ; NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def push ( head_ref , data ) : NEW_LINE INDENT ptr1 = Node ( data ) NEW_LINE temp = head_ref NEW_LINE ptr1 . data = data NEW_LINE ptr1 . next = head_ref NEW_LINE DEDENT
if ( head_ref != None ) : NEW_LINE INDENT while ( temp . next != head_ref ) : NEW_LINE INDENT temp = temp . next NEW_LINE DEDENT temp . next = ptr1 NEW_LINE DEDENT else : NEW_LINE
ptr1 . next = ptr1 NEW_LINE head_ref = ptr1 NEW_LINE return head_ref NEW_LINE
def deleteNode ( head_ref , delete ) : NEW_LINE INDENT temp = head_ref NEW_LINE DEDENT
if ( head_ref == delete ) : NEW_LINE INDENT head_ref = delete . next NEW_LINE DEDENT
while ( temp . next != delete ) : NEW_LINE INDENT temp = temp . next NEW_LINE DEDENT
temp . next = delete . next NEW_LINE
def deleteEvenNodes ( head ) : NEW_LINE INDENT ptr = head NEW_LINE next = None NEW_LINE DEDENT
next = ptr . next NEW_LINE ptr = next NEW_LINE while ( ptr != head ) : NEW_LINE INDENT if ( ptr . data % 2 == 0 ) : NEW_LINE INDENT deleteNode ( head , ptr ) NEW_LINE DEDENT DEDENT
next = ptr . next NEW_LINE ptr = next NEW_LINE return head NEW_LINE
def prList ( head ) : NEW_LINE INDENT temp = head NEW_LINE if ( head != None ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE while ( temp != head ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT DEDENT DEDENT
head = None NEW_LINE
head = push ( head , 61 ) NEW_LINE head = push ( head , 12 ) NEW_LINE head = push ( head , 56 ) NEW_LINE head = push ( head , 2 ) NEW_LINE head = push ( head , 11 ) NEW_LINE head = push ( head , 57 ) NEW_LINE print ( " List ▁ after ▁ deletion ▁ : ▁ " , end = " " ) NEW_LINE head = deleteEvenNodes ( head ) NEW_LINE prList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def push ( head , data ) : NEW_LINE INDENT if not head : NEW_LINE INDENT head = Node ( data ) NEW_LINE head . next = head NEW_LINE return head NEW_LINE DEDENT lnode = head NEW_LINE DEDENT
while ( lnode and lnode . next is not head ) : NEW_LINE INDENT lnode = lnode . next NEW_LINE DEDENT
ptr1 = Node ( data ) NEW_LINE ptr1 . next = head NEW_LINE lnode . next = ptr1 NEW_LINE head = ptr1 NEW_LINE return head NEW_LINE
def sumOfList ( head ) : NEW_LINE INDENT temp = head NEW_LINE tsum = temp . data NEW_LINE temp = temp . next NEW_LINE while ( temp is not head ) : NEW_LINE INDENT tsum += temp . data NEW_LINE temp = temp . next NEW_LINE DEDENT return tsum NEW_LINE DEDENT
head = None NEW_LINE
head = push ( head , 12 ) NEW_LINE head = push ( head , 56 ) NEW_LINE head = push ( head , 2 ) NEW_LINE head = push ( head , 11 ) NEW_LINE print ( " Sum ▁ of ▁ circular ▁ list ▁ is ▁ = ▁ { } " . format ( sumOfList ( head ) ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def prList ( head ) : NEW_LINE INDENT if ( head == None ) : NEW_LINE INDENT return NEW_LINE DEDENT temp = head NEW_LINE print ( temp . data , end = " - > " ) NEW_LINE temp = temp . next NEW_LINE while ( temp != head ) : NEW_LINE INDENT print ( temp . data , end = " - > " ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( head . data ) NEW_LINE DEDENT
def deleteK ( head_ref , k ) : NEW_LINE INDENT head = head_ref NEW_LINE DEDENT
if ( head == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
curr = head NEW_LINE prev = None NEW_LINE while True : NEW_LINE
if ( curr . next == head and curr == head ) : NEW_LINE INDENT break NEW_LINE DEDENT
prList ( head ) NEW_LINE
for i in range ( k ) : NEW_LINE INDENT prev = curr NEW_LINE curr = curr . next NEW_LINE DEDENT
if ( curr == head ) : NEW_LINE INDENT prev = head NEW_LINE while ( prev . next != head ) : NEW_LINE INDENT prev = prev . next NEW_LINE DEDENT head = curr . next NEW_LINE prev . next = head NEW_LINE head_ref = head NEW_LINE DEDENT
elif ( curr . next == head ) : NEW_LINE INDENT prev . next = head NEW_LINE DEDENT else : NEW_LINE INDENT prev . next = curr . next NEW_LINE DEDENT
def insertNode ( head_ref , x ) : NEW_LINE
head = head_ref NEW_LINE temp = Node ( x ) NEW_LINE
if ( head == None ) : NEW_LINE INDENT temp . next = temp NEW_LINE head_ref = temp NEW_LINE return head_ref NEW_LINE DEDENT
else : NEW_LINE INDENT temp1 = head NEW_LINE while ( temp1 . next != head ) : NEW_LINE INDENT temp1 = temp1 . next NEW_LINE DEDENT temp1 . next = temp NEW_LINE temp . next = head NEW_LINE DEDENT return head NEW_LINE
head = None NEW_LINE head = insertNode ( head , 1 ) NEW_LINE head = insertNode ( head , 2 ) NEW_LINE head = insertNode ( head , 3 ) NEW_LINE head = insertNode ( head , 4 ) NEW_LINE head = insertNode ( head , 5 ) NEW_LINE head = insertNode ( head , 6 ) NEW_LINE head = insertNode ( head , 7 ) NEW_LINE head = insertNode ( head , 8 ) NEW_LINE head = insertNode ( head , 9 ) NEW_LINE k = 4 NEW_LINE
deleteK ( head , k ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def insertNode ( start , value ) : NEW_LINE
if ( start == None ) : NEW_LINE INDENT new_node = Node ( value ) NEW_LINE new_node . data = value NEW_LINE new_node . next = new_node NEW_LINE new_node . prev = new_node NEW_LINE start = new_node NEW_LINE return new_node NEW_LINE DEDENT
last = start . prev NEW_LINE
new_node = Node ( value ) NEW_LINE new_node . data = value NEW_LINE
new_node . next = start NEW_LINE
( start ) . prev = new_node NEW_LINE
new_node . prev = last NEW_LINE
last . next = new_node NEW_LINE return start NEW_LINE
def displayList ( start ) : NEW_LINE INDENT temp = start NEW_LINE while ( temp . next != start ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( temp . data ) NEW_LINE DEDENT
def searchList ( start , search ) : NEW_LINE
temp = start NEW_LINE
count = 0 NEW_LINE flag = 0 NEW_LINE value = 0 NEW_LINE
if ( temp == None ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT else : NEW_LINE
while ( temp . next != start ) : NEW_LINE
count = count + 1 NEW_LINE
if ( temp . data == search ) : NEW_LINE INDENT flag = 1 NEW_LINE count = count - 1 NEW_LINE break NEW_LINE DEDENT
temp = temp . next NEW_LINE
if ( temp . data == search ) : NEW_LINE INDENT count = count + 1 NEW_LINE flag = 1 NEW_LINE DEDENT
if ( flag == 1 ) : NEW_LINE INDENT print ( search , " found ▁ at ▁ location ▁ " , count ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( search , " ▁ not ▁ found " ) NEW_LINE DEDENT return - 1 NEW_LINE
start = None NEW_LINE
start = insertNode ( start , 4 ) NEW_LINE
start = insertNode ( start , 5 ) NEW_LINE
start = insertNode ( start , 7 ) NEW_LINE
start = insertNode ( start , 8 ) NEW_LINE
start = insertNode ( start , 6 ) NEW_LINE print ( " Created ▁ circular ▁ doubly ▁ linked ▁ list ▁ is : ▁ " , end = " " ) NEW_LINE displayList ( start ) NEW_LINE searchList ( start , 5 ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . prev = None NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def getNode ( ) : NEW_LINE INDENT return ( Node ( 0 ) ) NEW_LINE DEDENT
def displayList ( temp ) : NEW_LINE INDENT t = temp NEW_LINE if ( temp == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE INDENT print ( " The ▁ list ▁ is : ▁ " , end = " ▁ " ) NEW_LINE while ( temp . next != t ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( temp . data ) NEW_LINE return 1 NEW_LINE DEDENT DEDENT
def countList ( start ) : NEW_LINE
temp = start NEW_LINE
count = 0 NEW_LINE
while ( temp . next != start ) : NEW_LINE INDENT temp = temp . next NEW_LINE count = count + 1 NEW_LINE DEDENT
count = count + 1 NEW_LINE return count NEW_LINE
def insertAtLocation ( start , data , loc ) : NEW_LINE
temp = None NEW_LINE newNode = None NEW_LINE i = 0 NEW_LINE count = 0 NEW_LINE
newNode = getNode ( ) NEW_LINE
temp = start NEW_LINE
count = countList ( start ) NEW_LINE
if ( temp == None or count < loc ) : NEW_LINE INDENT return start NEW_LINE DEDENT else : NEW_LINE
newNode . data = data NEW_LINE
i = 1 ; NEW_LINE while ( i < loc - 1 ) : NEW_LINE INDENT temp = temp . next NEW_LINE i = i + 1 NEW_LINE DEDENT
newNode . next = temp . next NEW_LINE
( temp . next ) . prev = newNode NEW_LINE
temp . next = newNode NEW_LINE
newNode . prev = temp NEW_LINE return start NEW_LINE return start NEW_LINE
def createList ( arr , n , start ) : NEW_LINE
newNode = None NEW_LINE temp = None NEW_LINE i = 0 NEW_LINE
while ( i < n ) : NEW_LINE
newNode = getNode ( ) NEW_LINE
newNode . data = arr [ i ] NEW_LINE
if ( i == 0 ) : NEW_LINE INDENT start = newNode NEW_LINE newNode . prev = start NEW_LINE newNode . next = start NEW_LINE DEDENT else : NEW_LINE
temp = ( start ) . prev NEW_LINE
temp . next = newNode NEW_LINE newNode . next = start NEW_LINE newNode . prev = temp NEW_LINE temp = start NEW_LINE temp . prev = newNode NEW_LINE i = i + 1 ; NEW_LINE return start NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE
start = None NEW_LINE
start = createList ( arr , n , start ) NEW_LINE
displayList ( start ) NEW_LINE
start = insertAtLocation ( start , 8 , 3 ) NEW_LINE
displayList ( start ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def getNode ( data ) : NEW_LINE INDENT newNode = Node ( data ) NEW_LINE newNode . data = data NEW_LINE return newNode NEW_LINE DEDENT
def insertEnd ( head , new_node ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT new_node . next = new_node NEW_LINE new_node . prev = new_node NEW_LINE head = new_node NEW_LINE return head NEW_LINE DEDENT
last = head . prev NEW_LINE
new_node . next = head NEW_LINE
head . prev = new_node NEW_LINE
new_node . prev = last NEW_LINE
last . next = new_node NEW_LINE return head NEW_LINE
def reverse ( head ) : NEW_LINE INDENT if ( head == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT DEDENT
new_head = None NEW_LINE
last = head . prev NEW_LINE
curr = last NEW_LINE
while ( curr . prev != last ) : NEW_LINE INDENT prev = curr . prev NEW_LINE DEDENT
new_head = insertEnd ( new_head , curr ) NEW_LINE curr = prev NEW_LINE new_head = insertEnd ( new_head , curr ) NEW_LINE
return new_head NEW_LINE
def display ( head ) : NEW_LINE INDENT if ( head == None ) : NEW_LINE INDENT return NEW_LINE DEDENT temp = head NEW_LINE print ( " Forward ▁ direction : ▁ " , end = " " ) NEW_LINE while ( temp . next != head ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( temp . data ) NEW_LINE last = head . prev NEW_LINE temp = last NEW_LINE print ( " Backward ▁ direction : ▁ " , end = " " ) NEW_LINE while ( temp . prev != last ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . prev NEW_LINE DEDENT print ( temp . data ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT head = None NEW_LINE head = insertEnd ( head , getNode ( 1 ) ) NEW_LINE head = insertEnd ( head , getNode ( 2 ) ) NEW_LINE head = insertEnd ( head , getNode ( 3 ) ) NEW_LINE head = insertEnd ( head , getNode ( 4 ) ) NEW_LINE head = insertEnd ( head , getNode ( 5 ) ) NEW_LINE print ( " Current ▁ list : " ) NEW_LINE display ( head ) NEW_LINE head = reverse ( head ) NEW_LINE print ( " Reversed list : " ) NEW_LINE display ( head ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . prev = None NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def getNode ( ) : NEW_LINE INDENT return ( Node ( 0 ) ) NEW_LINE DEDENT
def displayList ( temp ) : NEW_LINE INDENT t = temp NEW_LINE if ( temp == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE INDENT print ( " The ▁ list ▁ is : ▁ " , end = " ▁ " ) NEW_LINE while ( temp . next != t ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( temp . data ) NEW_LINE return 1 NEW_LINE DEDENT DEDENT
def createList ( arr , n , start ) : NEW_LINE
newNode = None NEW_LINE temp = None NEW_LINE i = 0 NEW_LINE
while ( i < n ) : NEW_LINE
newNode = getNode ( ) NEW_LINE
newNode . data = arr [ i ] NEW_LINE
if ( i == 0 ) : NEW_LINE INDENT start = newNode NEW_LINE newNode . prev = start NEW_LINE newNode . next = start NEW_LINE DEDENT else : NEW_LINE
temp = ( start ) . prev NEW_LINE
temp . next = newNode NEW_LINE newNode . next = start NEW_LINE newNode . prev = temp NEW_LINE temp = start NEW_LINE temp . prev = newNode NEW_LINE i = i + 1 NEW_LINE return start NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE
start = None NEW_LINE
start = createList ( arr , n , start ) NEW_LINE
displayList ( start ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT def newNode ( data ) : NEW_LINE INDENT node = Node ( data ) NEW_LINE return node NEW_LINE DEDENT
def alivesol ( Num ) : NEW_LINE INDENT if ( Num == 1 ) : NEW_LINE INDENT return 1 ; NEW_LINE DEDENT DEDENT
last = newNode ( 1 ) ; NEW_LINE last . next = last ; NEW_LINE for i in range ( 2 , Num + 1 ) : NEW_LINE INDENT temp = newNode ( i ) ; NEW_LINE temp . next = last . next ; NEW_LINE last . next = temp ; NEW_LINE last = temp ; NEW_LINE DEDENT
curr = last . next ; NEW_LINE
temp = None NEW_LINE while ( curr . next != curr ) : NEW_LINE INDENT temp = curr ; NEW_LINE curr = curr . next ; NEW_LINE temp . next = curr . next ; NEW_LINE DEDENT
del curr ; NEW_LINE temp = temp . next ; NEW_LINE curr = temp ; NEW_LINE
res = temp . data ; NEW_LINE del temp ; NEW_LINE return res ; NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT N = 100 ; NEW_LINE print ( alivesol ( N ) ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , d ) : NEW_LINE INDENT self . data = d NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def finddepth ( root ) : NEW_LINE
if ( not root ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
left = finddepth ( root . left ) NEW_LINE
right = finddepth ( root . right ) NEW_LINE
return 1 + max ( left , right ) NEW_LINE
def dfs ( root , curr , depth ) : NEW_LINE
if ( not root ) : NEW_LINE INDENT return None NEW_LINE DEDENT
if ( curr == depth ) : NEW_LINE INDENT return root NEW_LINE DEDENT
left = dfs ( root . left , curr + 1 , depth ) NEW_LINE
right = dfs ( root . right , curr + 1 , depth ) NEW_LINE
if ( left != None and right != None ) : NEW_LINE INDENT return root NEW_LINE DEDENT
return left if left else right NEW_LINE
def lcaOfDeepestLeaves ( root ) : NEW_LINE
if ( not root ) : NEW_LINE INDENT return None NEW_LINE DEDENT
depth = finddepth ( root ) - 1 NEW_LINE
return dfs ( root , 0 , depth ) NEW_LINE
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE root . right . left = Node ( 6 ) NEW_LINE root . right . right = Node ( 7 ) NEW_LINE root . right . left . left = Node ( 8 ) NEW_LINE root . right . left . right = Node ( 9 ) NEW_LINE print ( lcaOfDeepestLeaves ( root ) . data ) NEW_LINE
def filter ( x , y , z ) : NEW_LINE INDENT if ( x != - 1 and y != - 1 ) : NEW_LINE INDENT return z NEW_LINE DEDENT return y if x == - 1 else x NEW_LINE DEDENT
def samePathUtil ( mtrx , vrtx , v1 , v2 , i ) : NEW_LINE INDENT ans = - 1 NEW_LINE DEDENT
if ( i == v1 or i == v2 ) : NEW_LINE INDENT return i NEW_LINE DEDENT for j in range ( 0 , vrtx ) : NEW_LINE
if ( mtrx [ i ] [ j ] == 1 ) : NEW_LINE
ans = filter ( ans , samePathUtil ( mtrx , vrtx , v1 , v2 , j ) , i ) NEW_LINE
return ans NEW_LINE
def isVertexAtSamePath ( mtrx , vrtx , v1 , v2 , i ) : NEW_LINE INDENT lca = samePathUtil ( mtrx , vrtx , v1 - 1 , v2 - 1 , i ) NEW_LINE if ( lca == v1 - 1 or lca == v2 - 1 ) : NEW_LINE INDENT return True NEW_LINE DEDENT return False NEW_LINE DEDENT
vrtx = 7 NEW_LINE edge = 6 NEW_LINE mtrx = [ [ 0 , 1 , 1 , 1 , 0 , 0 , 0 ] , [ 0 , 0 , 0 , 0 , 1 , 0 , 0 ] , [ 0 , 0 , 0 , 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 0 , 0 , 0 , 0 ] , [ 0 , 0 , 0 , 0 , 0 , 0 , 0 ] , [ 0 , 0 , 0 , 0 , 0 , 0 , 0 ] ] NEW_LINE v1 = 1 NEW_LINE v2 = 5 NEW_LINE if ( isVertexAtSamePath ( mtrx , vrtx , v1 , v2 , 0 ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
MAX = 1000 NEW_LINE
lg = 10 NEW_LINE
level = [ 0 for i in range ( MAX ) ] NEW_LINE lca = [ [ 0 for i in range ( lg ) ] for j in range ( MAX ) ] NEW_LINE dist = [ [ 0 for i in range ( lg ) ] for j in range ( MAX ) ] NEW_LINE
graph = [ [ ] for i in range ( MAX ) ] NEW_LINE def addEdge ( u , v , cost ) : NEW_LINE INDENT global graph NEW_LINE graph [ u ] . append ( [ v , cost ] ) NEW_LINE graph [ v ] . append ( [ u , cost ] ) NEW_LINE DEDENT
def dfs ( node , parent , h , cost ) : NEW_LINE
lca [ node ] [ 0 ] = parent NEW_LINE
level [ node ] = h NEW_LINE if ( parent != - 1 ) : NEW_LINE INDENT dist [ node ] [ 0 ] = cost NEW_LINE DEDENT for i in range ( 1 , lg ) : NEW_LINE INDENT if ( lca [ node ] [ i - 1 ] != - 1 ) : NEW_LINE DEDENT
lca [ node ] [ i ] = lca [ lca [ node ] [ i - 1 ] ] [ i - 1 ] NEW_LINE dist [ node ] [ i ] = ( dist [ node ] [ i - 1 ] + dist [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ) NEW_LINE for i in graph [ node ] : NEW_LINE if ( i [ 0 ] == parent ) : NEW_LINE continue NEW_LINE dfs ( i [ 0 ] , node , h + 1 , i [ 1 ] ) NEW_LINE
def findDistance ( u , v ) : NEW_LINE INDENT ans = 0 NEW_LINE DEDENT
if ( level [ u ] > level [ v ] ) : NEW_LINE INDENT temp = u NEW_LINE u = v NEW_LINE v = temp NEW_LINE DEDENT
i = lg - 1 NEW_LINE while ( i >= 0 ) : NEW_LINE INDENT if ( lca [ v ] [ i ] != - 1 and level [ lca [ v ] [ i ] ] >= level [ u ] ) : NEW_LINE DEDENT
ans += dist [ v ] [ i ] NEW_LINE v = lca [ v ] [ i ] NEW_LINE i -= 1 NEW_LINE
if ( v == u ) : NEW_LINE INDENT print ( ans ) NEW_LINE DEDENT else : NEW_LINE
i = lg - 1 NEW_LINE while ( i >= 0 ) : NEW_LINE INDENT if ( lca [ v ] [ i ] != lca [ u ] [ i ] ) : NEW_LINE DEDENT
ans += dist [ u ] [ i ] + dist [ v ] [ i ] NEW_LINE v = lca [ v ] [ i ] NEW_LINE u = lca [ u ] [ i ] NEW_LINE i -= 1 NEW_LINE
ans += ( dist [ u ] [ 0 ] + dist [ v ] [ 0 ] ) NEW_LINE print ( ans ) NEW_LINE
n = 5 NEW_LINE
addEdge ( 1 , 2 , 2 ) NEW_LINE addEdge ( 1 , 3 , 3 ) NEW_LINE addEdge ( 2 , 4 , 5 ) NEW_LINE addEdge ( 2 , 5 , 7 ) NEW_LINE
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT for j in range ( lg ) : NEW_LINE INDENT lca [ i ] [ j ] = - 1 NEW_LINE dist [ i ] [ j ] = 0 NEW_LINE DEDENT DEDENT
dfs ( 1 , - 1 , 0 , 0 ) NEW_LINE
findDistance ( 1 , 3 ) NEW_LINE
findDistance ( 2 , 3 ) NEW_LINE
findDistance ( 3 , 5 ) NEW_LINE
MAX = 1000 NEW_LINE weight = [ 0 for i in range ( MAX ) ] NEW_LINE level = [ 0 for i in range ( MAX ) ] NEW_LINE par = [ 0 for i in range ( MAX ) ] NEW_LINE prime = [ True for i in range ( MAX + 1 ) ] NEW_LINE graph = [ [ ] for i in range ( MAX ) ] NEW_LINE
def SieveOfEratosthenes ( ) : NEW_LINE
for p in range ( 2 , MAX + 1 ) : NEW_LINE INDENT if p * p > MAX + 1 : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if ( prime [ p ] == True ) : NEW_LINE
for i in range ( p * p , MAX + 1 , p ) : NEW_LINE INDENT prime [ i ] = False NEW_LINE DEDENT
def dfs ( node , parent , h ) : NEW_LINE
par [ node ] = parent NEW_LINE
level [ node ] = h NEW_LINE for child in graph [ node ] : NEW_LINE INDENT if ( child == parent ) : NEW_LINE INDENT continue NEW_LINE DEDENT dfs ( child , node , h + 1 ) NEW_LINE DEDENT
def findPrimeOnPath ( u , v ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
if ( level [ u ] > level [ v ] ) : NEW_LINE INDENT u , v = v , u NEW_LINE DEDENT d = level [ v ] - level [ u ] NEW_LINE
while ( d ) : NEW_LINE
if ( prime [ weight [ v ] ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT v = par [ v ] NEW_LINE d -= 1 NEW_LINE
if ( v == u ) : NEW_LINE INDENT if ( prime [ weight [ v ] ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT return count NEW_LINE DEDENT
while ( v != u ) : NEW_LINE INDENT if ( prime [ weight [ v ] ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT if ( prime [ weight [ u ] ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT u = par [ u ] NEW_LINE v = par [ v ] NEW_LINE DEDENT
if ( prime [ weight [ v ] ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT return count NEW_LINE
SieveOfEratosthenes ( ) NEW_LINE
weight [ 1 ] = 5 NEW_LINE weight [ 2 ] = 10 NEW_LINE weight [ 3 ] = 11 NEW_LINE weight [ 4 ] = 8 NEW_LINE weight [ 5 ] = 6 NEW_LINE
graph [ 1 ] . append ( 2 ) NEW_LINE graph [ 2 ] . append ( 3 ) NEW_LINE graph [ 2 ] . append ( 4 ) NEW_LINE graph [ 1 ] . append ( 5 ) NEW_LINE dfs ( 1 , - 1 , 0 ) NEW_LINE u = 3 NEW_LINE v = 5 NEW_LINE print ( findPrimeOnPath ( u , v ) ) NEW_LINE
import sys NEW_LINE MAX = 1000 NEW_LINE
log = 10 NEW_LINE
level = [ 0 for i in range ( MAX ) ] ; NEW_LINE lca = [ [ - 1 for j in range ( log ) ] for i in range ( MAX ) ] NEW_LINE minWeight = [ [ sys . maxsize for j in range ( log ) ] for i in range ( MAX ) ] NEW_LINE maxWeight = [ [ - sys . maxsize for j in range ( log ) ] for i in range ( MAX ) ] NEW_LINE
graph = [ [ ] for i in range ( MAX ) ] NEW_LINE
weight = [ 0 for i in range ( MAX ) ] NEW_LINE def addEdge ( u , v ) : NEW_LINE INDENT graph [ u ] . append ( v ) ; NEW_LINE graph [ v ] . append ( u ) ; NEW_LINE DEDENT
def dfs ( node , parent , h ) : NEW_LINE
lca [ node ] [ 0 ] = parent ; NEW_LINE
level [ node ] = h ; NEW_LINE if ( parent != - 1 ) : NEW_LINE INDENT minWeight [ node ] [ 0 ] = ( min ( weight [ node ] , weight [ parent ] ) ) ; NEW_LINE maxWeight [ node ] [ 0 ] = ( max ( weight [ node ] , weight [ parent ] ) ) ; NEW_LINE DEDENT for i in range ( 1 , log ) : NEW_LINE INDENT if ( lca [ node ] [ i - 1 ] != - 1 ) : NEW_LINE DEDENT
lca [ node ] [ i ] = lca [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ; NEW_LINE minWeight [ node ] [ i ] = min ( minWeight [ node ] [ i - 1 ] , minWeight [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ) ; NEW_LINE maxWeight [ node ] [ i ] = max ( maxWeight [ node ] [ i - 1 ] , maxWeight [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ) ; NEW_LINE for i in graph [ node ] : NEW_LINE if ( i == parent ) : NEW_LINE continue ; NEW_LINE dfs ( i , node , h + 1 ) ; NEW_LINE
def findMinMaxWeight ( u , v ) : NEW_LINE INDENT minWei = sys . maxsize NEW_LINE maxWei = - sys . maxsize NEW_LINE DEDENT
if ( level [ u ] > level [ v ] ) : NEW_LINE INDENT u , v = v , u NEW_LINE DEDENT
for i in range ( log - 1 , - 1 , - 1 ) : NEW_LINE INDENT if ( lca [ v ] [ i ] != - 1 and level [ lca [ v ] [ i ] ] >= level [ u ] ) : NEW_LINE DEDENT
minWei = min ( minWei , minWeight [ v ] [ i ] ) ; NEW_LINE maxWei = max ( maxWei , maxWeight [ v ] [ i ] ) ; NEW_LINE v = lca [ v ] [ i ] ; NEW_LINE
if ( v == u ) : NEW_LINE INDENT print ( str ( minWei ) + ' ▁ ' + str ( maxWei ) ) NEW_LINE DEDENT else : NEW_LINE
for i in range ( log - 1 , - 1 , - 1 ) : NEW_LINE INDENT if ( lca [ v ] [ i ] != lca [ u ] [ i ] ) : NEW_LINE DEDENT
minWei = ( min ( minWei , min ( minWeight [ v ] [ i ] , minWeight [ u ] [ i ] ) ) ) ; NEW_LINE
maxWei = max ( maxWei , max ( maxWeight [ v ] [ i ] , maxWeight [ u ] [ i ] ) ) ; NEW_LINE v = lca [ v ] [ i ] ; NEW_LINE u = lca [ u ] [ i ] ; NEW_LINE
minWei = min ( minWei , min ( minWeight [ v ] [ 0 ] , minWeight [ u ] [ 0 ] ) ) ; NEW_LINE
maxWei = max ( maxWei , max ( maxWeight [ v ] [ 0 ] , maxWeight [ u ] [ 0 ] ) ) ; NEW_LINE print ( str ( minWei ) + ' ▁ ' + str ( maxWei ) ) NEW_LINE
n = 5 ; NEW_LINE
addEdge ( 1 , 2 ) ; NEW_LINE addEdge ( 1 , 5 ) ; NEW_LINE addEdge ( 2 , 4 ) ; NEW_LINE addEdge ( 2 , 3 ) ; NEW_LINE weight [ 1 ] = - 1 ; NEW_LINE weight [ 2 ] = 5 ; NEW_LINE weight [ 3 ] = - 1 ; NEW_LINE weight [ 4 ] = 3 ; NEW_LINE weight [ 5 ] = - 2 ; NEW_LINE
dfs ( 1 , - 1 , 0 ) ; NEW_LINE
findMinMaxWeight ( 1 , 3 ) ; NEW_LINE
findMinMaxWeight ( 2 , 4 ) ; NEW_LINE
findMinMaxWeight ( 3 , 5 ) ; NEW_LINE
T = 1 NEW_LINE def dfs ( node : int , parent : int , g : List [ List [ int ] ] , level : List [ int ] , t_in : List [ int ] , t_out : List [ int ] ) -> None : NEW_LINE INDENT global T NEW_LINE DEDENT
if ( parent == - 1 ) : NEW_LINE INDENT level [ node ] = 1 NEW_LINE DEDENT else : NEW_LINE INDENT level [ node ] = level [ parent ] + 1 NEW_LINE DEDENT
t_in [ node ] = T NEW_LINE for i in g [ node ] : NEW_LINE INDENT if ( i != parent ) : NEW_LINE INDENT T += 1 NEW_LINE dfs ( i , node , g , level , t_in , t_out ) NEW_LINE DEDENT DEDENT T += 1 NEW_LINE
t_out [ node ] = T NEW_LINE def findLCA ( n : int , g : List [ List [ int ] ] , v : List [ int ] ) -> int : NEW_LINE
level = [ 0 for _ in range ( n + 1 ) ] NEW_LINE
t_in = [ 0 for _ in range ( n + 1 ) ] NEW_LINE
t_out = [ 0 for _ in range ( n + 1 ) ] NEW_LINE
dfs ( 1 , - 1 , g , level , t_in , t_out ) NEW_LINE mint = INT_MAX NEW_LINE maxt = INT_MIN NEW_LINE minv = - 1 NEW_LINE maxv = - 1 NEW_LINE for i in v : NEW_LINE
if ( t_in [ i ] < mint ) : NEW_LINE INDENT mint = t_in [ i ] NEW_LINE minv = i NEW_LINE DEDENT
if ( t_out [ i ] > maxt ) : NEW_LINE INDENT maxt = t_out [ i ] NEW_LINE maxv = i NEW_LINE DEDENT
if ( minv == maxv ) : NEW_LINE INDENT return minv NEW_LINE DEDENT
lev = min ( level [ minv ] , level [ maxv ] ) NEW_LINE node = 0 NEW_LINE l = INT_MIN NEW_LINE for i in range ( n ) : NEW_LINE
if ( level [ i ] > lev ) : NEW_LINE INDENT continue NEW_LINE DEDENT
if ( t_in [ i ] <= mint and t_out [ i ] >= maxt and level [ i ] > l ) : NEW_LINE INDENT node = i NEW_LINE l = level [ i ] NEW_LINE DEDENT return node NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 10 NEW_LINE g = [ [ ] for _ in range ( n + 1 ) ] NEW_LINE g [ 1 ] . append ( 2 ) NEW_LINE g [ 2 ] . append ( 1 ) NEW_LINE g [ 1 ] . append ( 3 ) NEW_LINE g [ 3 ] . append ( 1 ) NEW_LINE g [ 1 ] . append ( 4 ) NEW_LINE g [ 4 ] . append ( 1 ) NEW_LINE g [ 2 ] . append ( 5 ) NEW_LINE g [ 5 ] . append ( 2 ) NEW_LINE g [ 2 ] . append ( 6 ) NEW_LINE g [ 6 ] . append ( 2 ) NEW_LINE g [ 3 ] . append ( 7 ) NEW_LINE g [ 7 ] . append ( 3 ) NEW_LINE g [ 4 ] . append ( 10 ) NEW_LINE g [ 10 ] . append ( 4 ) NEW_LINE g [ 8 ] . append ( 7 ) NEW_LINE g [ 7 ] . append ( 8 ) NEW_LINE g [ 9 ] . append ( 7 ) NEW_LINE g [ 7 ] . append ( 9 ) NEW_LINE v = [ 7 , 3 , 8 ] NEW_LINE print ( findLCA ( n , g , v ) ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . data = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def FindPath ( root , path , key ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT return False NEW_LINE DEDENT path . append ( root . data ) NEW_LINE if root . data == key : NEW_LINE INDENT return True NEW_LINE DEDENT if ( FindPath ( root . left , path , key ) or FindPath ( root . right , path , key ) ) : NEW_LINE INDENT return True NEW_LINE DEDENT path . pop ( ) NEW_LINE return False NEW_LINE DEDENT
def minMaxNodeInPath ( root , a , b ) : NEW_LINE
Path1 = [ ] NEW_LINE
Path2 = [ ] NEW_LINE
min1 , max1 = float ( ' inf ' ) , float ( ' - inf ' ) NEW_LINE
min2 , max2 = float ( ' inf ' ) , float ( ' - inf ' ) NEW_LINE i , j = 0 , 0 NEW_LINE
if ( FindPath ( root , Path1 , a ) and FindPath ( root , Path2 , b ) ) : NEW_LINE
while i < len ( Path1 ) and i < len ( Path2 ) : NEW_LINE INDENT if Path1 [ i ] != Path2 [ i ] : NEW_LINE INDENT break NEW_LINE DEDENT i += 1 NEW_LINE DEDENT i -= 1 NEW_LINE j = i NEW_LINE
while i < len ( Path1 ) : NEW_LINE INDENT if min1 > Path1 [ i ] : NEW_LINE INDENT min1 = Path1 [ i ] NEW_LINE DEDENT if max1 < Path1 [ i ] : NEW_LINE INDENT max1 = Path1 [ i ] NEW_LINE DEDENT i += 1 NEW_LINE DEDENT
while j < len ( Path2 ) : NEW_LINE INDENT if min2 > Path2 [ j ] : NEW_LINE INDENT min2 = Path2 [ j ] NEW_LINE DEDENT if max2 < Path2 [ j ] : NEW_LINE INDENT max2 = Path2 [ j ] NEW_LINE DEDENT j += 1 NEW_LINE DEDENT
print ( " Min ▁ = " , min ( min1 , min2 ) ) NEW_LINE
print ( " Max ▁ = " , max ( max1 , max2 ) ) NEW_LINE
else : NEW_LINE INDENT print ( " Min = - 1 Max = - 1 " ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT root = Node ( 20 ) NEW_LINE root . left = Node ( 8 ) NEW_LINE root . right = Node ( 22 ) NEW_LINE root . left . left = Node ( 5 ) NEW_LINE root . left . right = Node ( 3 ) NEW_LINE root . right . left = Node ( 4 ) NEW_LINE root . right . right = Node ( 25 ) NEW_LINE root . left . right . left = Node ( 10 ) NEW_LINE root . left . right . right = Node ( 14 ) NEW_LINE a , b = 5 , 14 NEW_LINE minMaxNodeInPath ( root , a , b ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def newNode ( data ) : NEW_LINE INDENT node = Node ( ) NEW_LINE node . data = data NEW_LINE node . left = None NEW_LINE node . right = None NEW_LINE return node NEW_LINE DEDENT
def getPath ( root , arr , x ) : NEW_LINE
if ( root == None ) : NEW_LINE INDENT return False NEW_LINE DEDENT
arr . append ( root . data ) NEW_LINE
if ( root . data == x ) : NEW_LINE INDENT return True NEW_LINE DEDENT
if ( getPath ( root . left , arr , x ) or getPath ( root . right , arr , x ) ) : NEW_LINE INDENT return True NEW_LINE DEDENT
arr . pop ( ) NEW_LINE return False NEW_LINE
def sumOddNodes ( root , n1 , n2 ) : NEW_LINE
path1 = [ ] NEW_LINE
path2 = [ ] NEW_LINE getPath ( root , path1 , n1 ) NEW_LINE getPath ( root , path2 , n2 ) NEW_LINE intersection = - 1 NEW_LINE
i = 0 NEW_LINE j = 0 NEW_LINE while ( i != len ( path1 ) or j != len ( path2 ) ) : NEW_LINE
if ( i == j and path1 [ i ] == path2 [ j ] ) : NEW_LINE INDENT i = i + 1 NEW_LINE j = j + 1 NEW_LINE DEDENT else : NEW_LINE INDENT intersection = j - 1 NEW_LINE break NEW_LINE DEDENT sum = 0 NEW_LINE i = len ( path1 ) - 1 NEW_LINE
while ( i > intersection ) : NEW_LINE INDENT if ( path1 [ i ] % 2 != 0 ) : NEW_LINE INDENT sum += path1 [ i ] NEW_LINE DEDENT i = i - 1 NEW_LINE DEDENT i = intersection NEW_LINE while ( i < len ( path2 ) ) : NEW_LINE INDENT if ( path2 [ i ] % 2 != 0 ) : NEW_LINE INDENT sum += path2 [ i ] NEW_LINE DEDENT i = i + 1 NEW_LINE DEDENT return sum NEW_LINE
root = newNode ( 1 ) NEW_LINE root . left = newNode ( 2 ) NEW_LINE root . right = newNode ( 3 ) NEW_LINE root . left . left = newNode ( 4 ) NEW_LINE root . left . right = newNode ( 5 ) NEW_LINE root . right . right = newNode ( 6 ) NEW_LINE node1 = 5 NEW_LINE node2 = 6 NEW_LINE print ( sumOddNodes ( root , node1 , node2 ) ) NEW_LINE
MAX = 1000 NEW_LINE
def findLCA ( n1 , n2 , parent ) : NEW_LINE
visited = [ False for i in range ( MAX ) ] NEW_LINE visited [ n1 ] = True NEW_LINE
while ( parent [ n1 ] != - 1 ) : NEW_LINE INDENT visited [ n1 ] = True NEW_LINE DEDENT
n1 = parent [ n1 ] NEW_LINE visited [ n1 ] = True NEW_LINE
while ( visited [ n2 ] == False ) : NEW_LINE INDENT n2 = parent [ n2 ] NEW_LINE DEDENT return n2 NEW_LINE
def insertAdj ( parent , i , j ) : NEW_LINE INDENT parent [ i ] = j NEW_LINE DEDENT
parent = [ 0 for i in range ( MAX ) ] NEW_LINE
parent [ 20 ] = - 1 NEW_LINE insertAdj ( parent , 8 , 20 ) NEW_LINE insertAdj ( parent , 22 , 20 ) NEW_LINE insertAdj ( parent , 4 , 8 ) NEW_LINE insertAdj ( parent , 12 , 8 ) NEW_LINE insertAdj ( parent , 10 , 12 ) NEW_LINE insertAdj ( parent , 14 , 12 ) NEW_LINE print ( findLCA ( 10 , 14 , parent ) ) NEW_LINE
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . key = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def insert ( root , key ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT root = newNode ( key ) NEW_LINE DEDENT elif root . key > key : NEW_LINE INDENT root . left = insert ( root . left , key ) NEW_LINE DEDENT elif root . key < key : NEW_LINE INDENT root . right = insert ( root . right , key ) NEW_LINE DEDENT return root NEW_LINE DEDENT
def distanceFromRoot ( root , x ) : NEW_LINE INDENT if root . key == x : NEW_LINE INDENT return 0 NEW_LINE DEDENT elif root . key > x : NEW_LINE INDENT return 1 + distanceFromRoot ( root . left , x ) NEW_LINE DEDENT return 1 + distanceFromRoot ( root . right , x ) NEW_LINE DEDENT
def distanceBetween2 ( root , a , b ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT return 0 NEW_LINE DEDENT DEDENT
if root . key > a and root . key > b : NEW_LINE INDENT return distanceBetween2 ( root . left , a , b ) NEW_LINE DEDENT
if root . key < a and root . key < b : NEW_LINE INDENT return distanceBetween2 ( root . right , a , b ) NEW_LINE DEDENT
if root . key >= a and root . key <= b : NEW_LINE INDENT return ( distanceFromRoot ( root , a ) + distanceFromRoot ( root , b ) ) NEW_LINE DEDENT
def findDistWrapper ( root , a , b ) : NEW_LINE INDENT if a > b : NEW_LINE INDENT a , b = b , a NEW_LINE DEDENT return distanceBetween2 ( root , a , b ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = None NEW_LINE root = insert ( root , 20 ) NEW_LINE insert ( root , 10 ) NEW_LINE insert ( root , 5 ) NEW_LINE insert ( root , 15 ) NEW_LINE insert ( root , 30 ) NEW_LINE insert ( root , 25 ) NEW_LINE insert ( root , 35 ) NEW_LINE a , b = 5 , 55 NEW_LINE print ( findDistWrapper ( root , 5 , 35 ) ) NEW_LINE DEDENT
MAXN = 1001 NEW_LINE
depth = [ 0 for i in range ( MAXN ) ] ; NEW_LINE
parent = [ 0 for i in range ( MAXN ) ] ; NEW_LINE adj = [ [ ] for i in range ( MAXN ) ] NEW_LINE def addEdge ( u , v ) : NEW_LINE INDENT adj [ u ] . append ( v ) ; NEW_LINE adj [ v ] . append ( u ) ; NEW_LINE DEDENT def dfs ( cur , prev ) : NEW_LINE
parent [ cur ] = prev ; NEW_LINE
depth [ cur ] = depth [ prev ] + 1 ; NEW_LINE
for i in range ( len ( adj [ cur ] ) ) : NEW_LINE INDENT if ( adj [ cur ] [ i ] != prev ) : NEW_LINE INDENT dfs ( adj [ cur ] [ i ] , cur ) ; NEW_LINE DEDENT DEDENT def preprocess ( ) : NEW_LINE
depth [ 0 ] = - 1 ; NEW_LINE
dfs ( 1 , 0 ) ; NEW_LINE
def LCANaive ( u , v ) : NEW_LINE INDENT if ( u == v ) : NEW_LINE INDENT return u ; NEW_LINE DEDENT if ( depth [ u ] > depth [ v ] ) : NEW_LINE INDENT u , v = v , u NEW_LINE DEDENT v = parent [ v ] ; NEW_LINE return LCANaive ( u , v ) ; NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE
addEdge ( 1 , 2 ) ; NEW_LINE addEdge ( 1 , 3 ) ; NEW_LINE addEdge ( 1 , 4 ) ; NEW_LINE addEdge ( 2 , 5 ) ; NEW_LINE addEdge ( 2 , 6 ) ; NEW_LINE addEdge ( 3 , 7 ) ; NEW_LINE addEdge ( 4 , 8 ) ; NEW_LINE addEdge ( 4 , 9 ) ; NEW_LINE addEdge ( 9 , 10 ) ; NEW_LINE addEdge ( 9 , 11 ) ; NEW_LINE addEdge ( 7 , 12 ) ; NEW_LINE addEdge ( 7 , 13 ) ; NEW_LINE preprocess ( ) ; NEW_LINE print ( ' LCA ( 11,8 ) ▁ : ▁ ' + str ( LCANaive ( 11 , 8 ) ) ) NEW_LINE print ( ' LCA ( 3,13 ) ▁ : ▁ ' + str ( LCANaive ( 3 , 13 ) ) ) NEW_LINE
MAXN = 100001 NEW_LINE tree = [ 0 ] * MAXN NEW_LINE for i in range ( MAXN ) : NEW_LINE INDENT tree [ i ] = [ ] NEW_LINE DEDENT
def dfs ( cur : int , prev : int , pathNumber : int , ptr : int , node : int ) -> None : NEW_LINE INDENT global tree , path , flag NEW_LINE for i in range ( len ( tree [ cur ] ) ) : NEW_LINE INDENT if ( tree [ cur ] [ i ] != prev and not flag ) : NEW_LINE DEDENT DEDENT
path [ pathNumber ] [ ptr ] = tree [ cur ] [ i ] NEW_LINE if ( tree [ cur ] [ i ] == node ) : NEW_LINE
flag = True NEW_LINE
path [ pathNumber ] [ ptr + 1 ] = - 1 NEW_LINE return NEW_LINE dfs ( tree [ cur ] [ i ] , cur , pathNumber , ptr + 1 , node ) NEW_LINE
def LCA ( a : int , b : int ) -> int : NEW_LINE INDENT global flag NEW_LINE DEDENT
if ( a == b ) : NEW_LINE INDENT return a NEW_LINE DEDENT
path [ 1 ] [ 0 ] = path [ 2 ] [ 0 ] = 1 NEW_LINE
flag = False NEW_LINE dfs ( 1 , 0 , 1 , 1 , a ) NEW_LINE
flag = False NEW_LINE dfs ( 1 , 0 , 2 , 1 , b ) NEW_LINE
i = 0 NEW_LINE while ( path [ 1 ] [ i ] == path [ 2 ] [ i ] ) : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
return path [ 1 ] [ i - 1 ] NEW_LINE def addEdge ( a : int , b : int ) -> None : NEW_LINE tree [ a ] . append ( b ) NEW_LINE tree [ b ] . append ( a ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 8 NEW_LINE DEDENT
addEdge ( 1 , 2 ) NEW_LINE addEdge ( 1 , 3 ) NEW_LINE addEdge ( 2 , 4 ) NEW_LINE addEdge ( 2 , 5 ) NEW_LINE addEdge ( 2 , 6 ) NEW_LINE addEdge ( 3 , 7 ) NEW_LINE addEdge ( 3 , 8 ) NEW_LINE print ( " LCA ( 4 , ▁ 7 ) ▁ = ▁ { } " . format ( LCA ( 4 , 7 ) ) ) NEW_LINE print ( " LCA ( 4 , ▁ 6 ) ▁ = ▁ { } " . format ( LCA ( 4 , 6 ) ) ) NEW_LINE
V = 5 NEW_LINE
WHITE = 1 NEW_LINE
BLACK = 2 NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
class subset : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . parent = 0 NEW_LINE self . rank = 0 NEW_LINE self . ancestor = 0 NEW_LINE self . child = 0 NEW_LINE self . sibling = 0 NEW_LINE self . color = 0 NEW_LINE DEDENT DEDENT
class Query : NEW_LINE INDENT def __init__ ( self , L , R ) : NEW_LINE INDENT self . L = L NEW_LINE self . R = R NEW_LINE DEDENT DEDENT
def newNode ( data ) : NEW_LINE INDENT node = Node ( ) NEW_LINE node . data = data NEW_LINE node . left = node . right = None NEW_LINE return ( node ) NEW_LINE DEDENT
def makeSet ( subsets , i ) : NEW_LINE INDENT if ( i < 1 or i > V ) : NEW_LINE INDENT return NEW_LINE DEDENT subsets [ i ] . color = WHITE NEW_LINE subsets [ i ] . parent = i NEW_LINE subsets [ i ] . rank = 0 NEW_LINE return NEW_LINE DEDENT
def findSet ( subsets , i ) : NEW_LINE
if ( subsets [ i ] . parent != i ) : NEW_LINE INDENT subsets [ i ] . parent = findSet ( subsets , subsets [ i ] . parent ) NEW_LINE DEDENT return subsets [ i ] . parent NEW_LINE
def unionSet ( subsets , x , y ) : NEW_LINE INDENT xroot = findSet ( subsets , x ) NEW_LINE yroot = findSet ( subsets , y ) NEW_LINE DEDENT
if ( subsets [ xroot ] . rank < subsets [ yroot ] . rank ) : NEW_LINE INDENT subsets [ xroot ] . parent = yroot NEW_LINE DEDENT elif ( subsets [ xroot ] . rank > subsets [ yroot ] . rank ) : NEW_LINE INDENT subsets [ yroot ] . parent = xroot NEW_LINE DEDENT
else : NEW_LINE INDENT subsets [ yroot ] . parent = xroot NEW_LINE ( subsets [ xroot ] . rank ) += 1 NEW_LINE DEDENT
def lcaWalk ( u , q , m , subsets ) : NEW_LINE
makeSet ( subsets , u ) NEW_LINE
subsets [ findSet ( subsets , u ) ] . ancestor = u NEW_LINE child = subsets [ u ] . child NEW_LINE
while ( child != 0 ) : NEW_LINE INDENT lcaWalk ( child , q , m , subsets ) NEW_LINE unionSet ( subsets , u , child ) NEW_LINE subsets [ findSet ( subsets , u ) ] . ancestor = u NEW_LINE child = subsets [ child ] . sibling NEW_LINE DEDENT subsets [ u ] . color = BLACK NEW_LINE for i in range ( m ) : NEW_LINE INDENT if ( q [ i ] . L == u ) : NEW_LINE INDENT if ( subsets [ q [ i ] . R ] . color == BLACK ) : NEW_LINE INDENT print ( " LCA ( % d ▁ % d ) ▁ - > ▁ % d " % ( q [ i ] . L , q [ i ] . R , subsets [ findSet ( subsets , q [ i ] . R ) ] . ancestor ) ) NEW_LINE DEDENT DEDENT elif ( q [ i ] . R == u ) : NEW_LINE INDENT if ( subsets [ q [ i ] . L ] . color == BLACK ) : NEW_LINE INDENT print ( " LCA ( % d ▁ % d ) ▁ - > ▁ % d " % ( q [ i ] . L , q [ i ] . R , subsets [ findSet ( subsets , q [ i ] . L ) ] . ancestor ) ) NEW_LINE DEDENT DEDENT DEDENT return NEW_LINE
def preprocess ( node , subsets ) : NEW_LINE INDENT if ( node == None ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
preprocess ( node . left , subsets ) NEW_LINE if ( node . left != None and node . right != None ) : NEW_LINE
subsets [ node . data ] . child = node . left . data NEW_LINE subsets [ node . left . data ] . sibling = node . right . data NEW_LINE elif ( ( node . left != None and node . right == None ) or ( node . left == None and node . right != None ) ) : NEW_LINE if ( node . left != None and node . right == None ) : NEW_LINE INDENT subsets [ node . data ] . child = node . left . data NEW_LINE DEDENT else : NEW_LINE INDENT subsets [ node . data ] . child = node . right . data NEW_LINE DEDENT
preprocess ( node . right , subsets ) NEW_LINE
def initialise ( subsets ) : NEW_LINE
for i in range ( 1 , V + 1 ) : NEW_LINE INDENT subsets [ i ] . color = WHITE NEW_LINE DEDENT return NEW_LINE
def printLCAs ( root , q , m ) : NEW_LINE
subsets = [ subset ( ) for _ in range ( V + 1 ) ] NEW_LINE
initialise ( subsets ) NEW_LINE
preprocess ( root , subsets ) NEW_LINE
lcaWalk ( root . data , q , m , subsets ) NEW_LINE
root = newNode ( 1 ) NEW_LINE root . left = newNode ( 2 ) NEW_LINE root . right = newNode ( 3 ) NEW_LINE root . left . left = newNode ( 4 ) NEW_LINE root . left . right = newNode ( 5 ) NEW_LINE
q = [ Query ( 5 , 4 ) , Query ( 1 , 3 ) , Query ( 2 , 3 ) ] NEW_LINE m = len ( q ) NEW_LINE printLCAs ( root , q , m ) NEW_LINE
def countSingleRec ( root , count ) : NEW_LINE
if root is None : NEW_LINE INDENT return True NEW_LINE DEDENT
left = countSingleRec ( root . left , count ) NEW_LINE right = countSingleRec ( root . right , count ) NEW_LINE
if left == False or right == False : NEW_LINE INDENT return False NEW_LINE DEDENT
if root . left and root . data != root . left . data : NEW_LINE INDENT return False NEW_LINE DEDENT
if root . right and root . data != root . right . data : NEW_LINE INDENT return False NEW_LINE DEDENT
count [ 0 ] += 1 NEW_LINE return True NEW_LINE
def countSingle ( root ) : NEW_LINE
countSingleRec ( root , count ) NEW_LINE return count [ 0 ] NEW_LINE
root = Node ( 5 ) NEW_LINE root . left = Node ( 4 ) NEW_LINE root . right = Node ( 5 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 4 ) NEW_LINE root . right . right = Node ( 5 ) NEW_LINE countSingle ( root ) NEW_LINE print " Count ▁ of ▁ Single ▁ Valued ▁ Subtress ▁ is " , countSingle ( root ) NEW_LINE
def findLeafDown ( root , lev , minDist ) : NEW_LINE
if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
if ( root . left == None and root . right == None ) : NEW_LINE INDENT if ( lev < ( minDist [ 0 ] ) ) : NEW_LINE INDENT minDist [ 0 ] = lev NEW_LINE DEDENT return NEW_LINE DEDENT
findLeafDown ( root . left , lev + 1 , minDist ) NEW_LINE findLeafDown ( root . right , lev + 1 , minDist ) NEW_LINE
def findThroughParent ( root , x , minDist ) : NEW_LINE
if ( root == None ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT if ( root == x ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
l = findThroughParent ( root . left , x , minDist ) NEW_LINE
if ( l != - 1 ) : NEW_LINE
findLeafDown ( root . right , l + 2 , minDist ) NEW_LINE return l + 1 NEW_LINE
r = findThroughParent ( root . right , x , minDist ) NEW_LINE
if ( r != - 1 ) : NEW_LINE
findLeafDown ( root . left , r + 2 , minDist ) NEW_LINE return r + 1 NEW_LINE return - 1 NEW_LINE
def minimumDistance ( root , x ) : NEW_LINE
minDist = [ 999999999999 ] NEW_LINE
findLeafDown ( x , 0 , minDist ) NEW_LINE
findThroughParent ( root , x , minDist ) NEW_LINE return minDist [ 0 ] NEW_LINE
root = newNode ( 1 ) NEW_LINE root . left = newNode ( 12 ) NEW_LINE root . right = newNode ( 13 ) NEW_LINE root . right . left = newNode ( 14 ) NEW_LINE root . right . right = newNode ( 15 ) NEW_LINE root . right . left . left = newNode ( 21 ) NEW_LINE root . right . left . right = newNode ( 22 ) NEW_LINE root . right . right . left = newNode ( 23 ) NEW_LINE root . right . right . right = newNode ( 24 ) NEW_LINE root . right . left . left . left = newNode ( 1 ) NEW_LINE root . right . left . left . right = newNode ( 2 ) NEW_LINE root . right . left . right . left = newNode ( 3 ) NEW_LINE root . right . left . right . right = newNode ( 4 ) NEW_LINE root . right . right . left . left = newNode ( 5 ) NEW_LINE root . right . right . left . right = newNode ( 6 ) NEW_LINE root . right . right . right . left = newNode ( 7 ) NEW_LINE root . right . right . right . right = newNode ( 8 ) NEW_LINE x = root . right NEW_LINE print ( " The ▁ closest ▁ leaf ▁ to ▁ the ▁ node ▁ with ▁ value " , x . key , " is ▁ at ▁ a ▁ distance ▁ of " , minimumDistance ( root , x ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def printInorder ( root ) : NEW_LINE INDENT if root is not None : NEW_LINE INDENT printInorder ( root . left ) NEW_LINE print root . data , NEW_LINE printInorder ( root . right ) NEW_LINE DEDENT DEDENT
def RemoveHalfNodes ( root ) : NEW_LINE INDENT if root is None : NEW_LINE INDENT return None NEW_LINE DEDENT root . left = RemoveHalfNodes ( root . left ) NEW_LINE root . right = RemoveHalfNodes ( root . right ) NEW_LINE if root . left is None and root . right is None : NEW_LINE INDENT return root NEW_LINE DEDENT DEDENT
if root . left is None : NEW_LINE INDENT new_root = root . right NEW_LINE temp = root NEW_LINE root = None NEW_LINE del ( temp ) NEW_LINE return new_root NEW_LINE DEDENT
if root . right is None : NEW_LINE INDENT new_root = root . left NEW_LINE temp = root NEW_LINE root = None NEW_LINE del ( temp ) NEW_LINE return new_root NEW_LINE DEDENT return root NEW_LINE
root = Node ( 2 ) NEW_LINE root . left = Node ( 7 ) NEW_LINE root . right = Node ( 5 ) NEW_LINE root . left . right = Node ( 6 ) NEW_LINE root . left . right . left = Node ( 1 ) NEW_LINE root . left . right . right = Node ( 11 ) NEW_LINE root . right . right = Node ( 9 ) NEW_LINE root . right . right . left = Node ( 4 ) NEW_LINE print " Inorder ▁ traversal ▁ of ▁ given ▁ tree " NEW_LINE printInorder ( root ) NEW_LINE NewRoot = RemoveHalfNodes ( root ) NEW_LINE print   " NEW_LINE Inorder traversal of the modified tree " NEW_LINE printInorder ( NewRoot ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE self . abtr = None NEW_LINE DEDENT DEDENT even_ptrs = [ ] NEW_LINE odd_ptrs = [ ] NEW_LINE
def preorderTraversal ( root ) : NEW_LINE INDENT global even_ptrs , odd_ptrs NEW_LINE if ( not root ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
if ( root . data % 2 == 0 ) : NEW_LINE INDENT even_ptrs . append ( root ) NEW_LINE DEDENT
else : NEW_LINE INDENT odd_ptrs . append ( root ) NEW_LINE DEDENT preorderTraversal ( root . left ) NEW_LINE preorderTraversal ( root . right ) NEW_LINE
def createLoops ( root ) : NEW_LINE INDENT preorderTraversal ( root ) NEW_LINE DEDENT
i = 1 NEW_LINE while i < len ( even_ptrs ) : NEW_LINE INDENT even_ptrs [ i - 1 ] . abtr = even_ptrs [ i ] NEW_LINE i += 1 NEW_LINE DEDENT
even_ptrs [ i - 1 ] . abtr = even_ptrs [ 0 ] NEW_LINE
i = 1 NEW_LINE while i < len ( odd_ptrs ) : NEW_LINE INDENT odd_ptrs [ i - 1 ] . abtr = odd_ptrs [ i ] NEW_LINE i += 1 NEW_LINE DEDENT odd_ptrs [ i - 1 ] . abtr = odd_ptrs [ 0 ] NEW_LINE
def traverseLoop ( start ) : NEW_LINE INDENT curr = start NEW_LINE while True and curr : NEW_LINE INDENT print ( curr . data , end = " ▁ " ) NEW_LINE curr = curr . abtr NEW_LINE if curr == start : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT print ( ) NEW_LINE DEDENT
root = None NEW_LINE root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE root . right . left = Node ( 6 ) NEW_LINE root . right . right = Node ( 7 ) NEW_LINE createLoops ( root ) NEW_LINE
print ( " Odd ▁ nodes : " , end = " ▁ " ) NEW_LINE traverseLoop ( root . right ) NEW_LINE print ( " Even ▁ nodes : " , end = " ▁ " ) NEW_LINE
traverseLoop ( root . left ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def extractLeafList ( root ) : NEW_LINE INDENT if root is None : NEW_LINE INDENT return None NEW_LINE DEDENT if root . left is None and root . right is None : NEW_LINE INDENT root . right = extractLeafList . head NEW_LINE if extractLeafList . head is not None : NEW_LINE INDENT extractLeafList . head . left = root NEW_LINE DEDENT extractLeafList . head = root NEW_LINE return None NEW_LINE DEDENT root . right = extractLeafList ( root . right ) NEW_LINE root . left = extractLeafList ( root . left ) NEW_LINE return root NEW_LINE DEDENT
def printInorder ( root ) : NEW_LINE INDENT if root is not None : NEW_LINE INDENT printInorder ( root . left ) NEW_LINE print root . data , NEW_LINE printInorder ( root . right ) NEW_LINE DEDENT DEDENT
def printList ( head ) : NEW_LINE INDENT while ( head ) : NEW_LINE INDENT if head . data is not None : NEW_LINE INDENT print head . data , NEW_LINE DEDENT head = head . right NEW_LINE DEDENT DEDENT
extractLeafList . head = Node ( None ) NEW_LINE root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE root . right . right = Node ( 6 ) NEW_LINE root . left . left . left = Node ( 7 ) NEW_LINE root . left . left . right = Node ( 8 ) NEW_LINE root . right . right . left = Node ( 9 ) NEW_LINE root . right . right . right = Node ( 10 ) NEW_LINE print " Inorder ▁ traversal ▁ of ▁ given ▁ tree ▁ is : " NEW_LINE printInorder ( root ) NEW_LINE root = extractLeafList ( root ) NEW_LINE print   " NEW_LINE Extract Double Linked List is : " NEW_LINE printList ( extractLeafList . head ) NEW_LINE print   " NEW_LINE Inorder traversal of modified tree is : " NEW_LINE printInorder ( root ) NEW_LINE
MAX = 100 NEW_LINE
def dfs ( n , m , visit , adj , N , M ) : NEW_LINE
visit [ n ] [ m ] = 1 NEW_LINE
if ( n + 1 < N and adj [ n ] [ m ] >= adj [ n + 1 ] [ m ] and not visit [ n + 1 ] [ m ] ) : NEW_LINE INDENT dfs ( n + 1 , m , visit , adj , N , M ) NEW_LINE DEDENT
if ( m + 1 < M and adj [ n ] [ m ] >= adj [ n ] [ m + 1 ] and not visit [ n ] [ m + 1 ] ) : NEW_LINE INDENT dfs ( n , m + 1 , visit , adj , N , M ) NEW_LINE DEDENT
if ( n - 1 >= 0 and adj [ n ] [ m ] >= adj [ n - 1 ] [ m ] and not visit [ n - 1 ] [ m ] ) : NEW_LINE INDENT dfs ( n - 1 , m , visit , adj , N , M ) NEW_LINE DEDENT
if ( m - 1 >= 0 and adj [ n ] [ m ] >= adj [ n ] [ m - 1 ] and not visit [ n ] [ m - 1 ] ) : NEW_LINE INDENT dfs ( n , m - 1 , visit , adj , N , M ) NEW_LINE DEDENT def printMinSources ( adj , N , M ) : NEW_LINE
x = [ ] NEW_LINE for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE INDENT x . append ( [ adj [ i ] [ j ] , [ i , j ] ] ) NEW_LINE DEDENT DEDENT
x . sort ( ) NEW_LINE
visit = [ [ False for i in range ( MAX ) ] for i in range ( N ) ] NEW_LINE
for i in range ( len ( x ) - 1 , - 1 , - 1 ) : NEW_LINE
if ( not visit [ x [ i ] [ 1 ] [ 0 ] ] [ x [ i ] [ 1 ] [ 1 ] ] ) : NEW_LINE INDENT print ( ' { } ▁ { } ' . format ( x [ i ] [ 1 ] [ 0 ] , x [ i ] [ 1 ] [ 1 ] ) ) NEW_LINE dfs ( x [ i ] [ 1 ] [ 0 ] , x [ i ] [ 1 ] [ 1 ] , visit , adj , N , M ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT N = 2 NEW_LINE M = 2 NEW_LINE adj = [ [ 3 , 3 ] , [ 1 , 1 ] ] NEW_LINE printMinSources ( adj , N , M ) NEW_LINE DEDENT
def isStepNum ( n ) : NEW_LINE
prevDigit = - 1 NEW_LINE
while ( n ) : NEW_LINE
curDigit = n % 10 NEW_LINE
if ( prevDigit == - 1 ) : NEW_LINE INDENT prevDigit = curDigit NEW_LINE DEDENT else : NEW_LINE
if ( abs ( prevDigit - curDigit ) != 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT prevDigit = curDigit NEW_LINE n //= 10 NEW_LINE return True NEW_LINE
def displaySteppingNumbers ( n , m ) : NEW_LINE
for i in range ( n , m + 1 ) : NEW_LINE INDENT if ( isStepNum ( i ) ) : NEW_LINE INDENT print ( i , end = " ▁ " ) NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n , m = 0 , 21 NEW_LINE DEDENT
displaySteppingNumbers ( n , m ) NEW_LINE
def bfs ( n , m , num ) : NEW_LINE
q = [ ] NEW_LINE q . append ( num ) NEW_LINE while len ( q ) > 0 : NEW_LINE
stepNum = q [ 0 ] NEW_LINE q . pop ( 0 ) ; NEW_LINE
if ( stepNum <= m and stepNum >= n ) : NEW_LINE INDENT print ( stepNum , end = " ▁ " ) NEW_LINE DEDENT
if ( num == 0 or stepNum > m ) : NEW_LINE INDENT continue NEW_LINE DEDENT
lastDigit = stepNum % 10 NEW_LINE
stepNumA = stepNum * 10 + ( lastDigit - 1 ) NEW_LINE stepNumB = stepNum * 10 + ( lastDigit + 1 ) NEW_LINE
if ( lastDigit == 0 ) : NEW_LINE INDENT q . append ( stepNumB ) NEW_LINE DEDENT
elif ( lastDigit == 9 ) : NEW_LINE INDENT q . append ( stepNumA ) NEW_LINE DEDENT else : NEW_LINE INDENT q . append ( stepNumA ) NEW_LINE q . append ( stepNumB ) NEW_LINE DEDENT
def displaySteppingNumbers ( n , m ) : NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT bfs ( n , m , i ) NEW_LINE DEDENT
n , m = 0 , 21 NEW_LINE
displaySteppingNumbers ( n , m ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . data = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def levelOrder ( root ) : NEW_LINE INDENT if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
q = queue ( ) NEW_LINE
q . append ( root ) NEW_LINE
q . append ( None ) NEW_LINE
while ( len ( q ) > 1 ) : NEW_LINE INDENT curr = q . popleft ( ) NEW_LINE DEDENT
if ( curr == None ) : NEW_LINE q . append ( None ) NEW_LINE print ( ) NEW_LINE else : NEW_LINE
if ( curr . left ) : NEW_LINE INDENT q . append ( curr . left ) NEW_LINE DEDENT
if ( curr . right ) : NEW_LINE INDENT q . append ( curr . right ) NEW_LINE DEDENT print ( curr . data , end = " ▁ " ) NEW_LINE
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE root . right . right = Node ( 6 ) NEW_LINE levelOrder ( root ) NEW_LINE
from collections import deque NEW_LINE class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def modifiedLevelOrder ( node ) : NEW_LINE
if ( node == None ) : NEW_LINE INDENT return NEW_LINE DEDENT if ( node . left == None and node . right == None ) : NEW_LINE INDENT print ( node . data , end = " ▁ " ) NEW_LINE return NEW_LINE DEDENT
myQueue = deque ( ) NEW_LINE
myStack = [ ] NEW_LINE temp = None NEW_LINE
sz = 0 NEW_LINE
ct = 0 NEW_LINE
rightToLeft = False NEW_LINE
myQueue . append ( node ) NEW_LINE
while ( len ( myQueue ) > 0 ) : NEW_LINE INDENT ct += 1 NEW_LINE sz = len ( myQueue ) NEW_LINE DEDENT
for i in range ( sz ) : NEW_LINE INDENT temp = myQueue . popleft ( ) NEW_LINE DEDENT
if ( rightToLeft == False ) : NEW_LINE INDENT print ( temp . data , end = " ▁ " ) NEW_LINE DEDENT
else : NEW_LINE INDENT myStack . append ( temp ) NEW_LINE DEDENT if ( temp . left ) : NEW_LINE INDENT myQueue . append ( temp . left ) NEW_LINE DEDENT if ( temp . right ) : NEW_LINE INDENT myQueue . append ( temp . right ) NEW_LINE DEDENT if ( rightToLeft == True ) : NEW_LINE
while ( len ( myStack ) > 0 ) : NEW_LINE INDENT temp = myStack [ - 1 ] NEW_LINE del myStack [ - 1 ] NEW_LINE print ( temp . data , end = " ▁ " ) NEW_LINE DEDENT
if ( ct == 2 ) : NEW_LINE INDENT rightToLeft = not rightToLeft NEW_LINE ct = 0 NEW_LINE DEDENT print ( ) NEW_LINE
root = Node ( 1 ) NEW_LINE root . left = Node ( 2 ) NEW_LINE root . right = Node ( 3 ) NEW_LINE root . left . left = Node ( 4 ) NEW_LINE root . left . right = Node ( 5 ) NEW_LINE root . right . left = Node ( 6 ) NEW_LINE root . right . right = Node ( 7 ) NEW_LINE root . left . left . left = Node ( 8 ) NEW_LINE root . left . left . right = Node ( 9 ) NEW_LINE root . left . right . left = Node ( 3 ) NEW_LINE root . left . right . right = Node ( 1 ) NEW_LINE root . right . left . left = Node ( 4 ) NEW_LINE root . right . left . right = Node ( 2 ) NEW_LINE root . right . right . left = Node ( 7 ) NEW_LINE root . right . right . right = Node ( 2 ) NEW_LINE root . left . right . left . left = Node ( 16 ) NEW_LINE root . left . right . left . right = Node ( 17 ) NEW_LINE root . right . left . right . left = Node ( 18 ) NEW_LINE root . right . right . left . right = Node ( 19 ) NEW_LINE modifiedLevelOrder ( root ) NEW_LINE
def find ( parent , i ) : NEW_LINE INDENT if ( parent [ i ] == - 1 ) : NEW_LINE INDENT return i NEW_LINE DEDENT return find ( parent , parent [ i ] ) NEW_LINE DEDENT
def Union ( parent , x , y ) : NEW_LINE INDENT xset = find ( parent , x ) NEW_LINE yset = find ( parent , y ) NEW_LINE parent [ xset ] = yset NEW_LINE DEDENT
def minnode ( n , keyval , mstset ) : NEW_LINE INDENT mini = 999999999999 NEW_LINE mini_index = None NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if ( mstset [ i ] == False and keyval [ i ] < mini ) : NEW_LINE INDENT mini = keyval [ i ] NEW_LINE mini_index = i NEW_LINE DEDENT DEDENT return mini_index NEW_LINE
def findcost ( n , city ) : NEW_LINE
parent = [ None ] * n NEW_LINE
keyval = [ None ] * n NEW_LINE
mstset = [ None ] * n NEW_LINE
for i in range ( n ) : NEW_LINE INDENT keyval [ i ] = 9999999999999 NEW_LINE mstset [ i ] = False NEW_LINE DEDENT
parent [ 0 ] = - 1 NEW_LINE keyval [ 0 ] = 0 NEW_LINE
for i in range ( n - 1 ) : NEW_LINE
u = minnode ( n , keyval , mstset ) NEW_LINE
mstset [ u ] = True NEW_LINE
for v in range ( n ) : NEW_LINE INDENT if ( city [ u ] [ v ] and mstset [ v ] == False and city [ u ] [ v ] < keyval [ v ] ) : NEW_LINE INDENT keyval [ v ] = city [ u ] [ v ] NEW_LINE parent [ v ] = u NEW_LINE DEDENT DEDENT
cost = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT cost += city [ parent [ i ] ] [ i ] NEW_LINE DEDENT print ( cost ) NEW_LINE
n1 = 5 NEW_LINE city1 = [ [ 0 , 1 , 2 , 3 , 4 ] , [ 1 , 0 , 5 , 0 , 7 ] , [ 2 , 5 , 0 , 6 , 0 ] , [ 3 , 0 , 6 , 0 , 0 ] , [ 4 , 7 , 0 , 0 , 0 ] ] NEW_LINE findcost ( n1 , city1 ) NEW_LINE
n2 = 6 NEW_LINE city2 = [ [ 0 , 1 , 1 , 100 , 0 , 0 ] , [ 1 , 0 , 1 , 0 , 0 , 0 ] , [ 1 , 1 , 0 , 0 , 0 , 0 ] , [ 100 , 0 , 0 , 0 , 2 , 2 ] , [ 0 , 0 , 0 , 2 , 0 , 2 ] , [ 0 , 0 , 0 , 2 , 2 , 0 ] ] NEW_LINE findcost ( n2 , city2 ) NEW_LINE
n = 8 NEW_LINE
def isSafe ( x , y , board ) : NEW_LINE INDENT if ( x >= 0 and y >= 0 and x < n and y < n and board [ x ] [ y ] == - 1 ) : NEW_LINE INDENT return True NEW_LINE DEDENT return False NEW_LINE DEDENT
def printSolution ( n , board ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( board [ i ] [ j ] , end = ' ▁ ' ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
def solveKT ( n ) : NEW_LINE
board = [ [ - 1 for i in range ( n ) ] for i in range ( n ) ] NEW_LINE
move_x = [ 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 ] NEW_LINE move_y = [ 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 ] NEW_LINE
board [ 0 ] [ 0 ] = 0 NEW_LINE
pos = 1 NEW_LINE if ( not solveKTUtil ( n , board , 0 , 0 , move_x , move_y , pos ) ) : NEW_LINE INDENT print ( " Solution ▁ does ▁ not ▁ exist " ) NEW_LINE DEDENT else : NEW_LINE INDENT printSolution ( n , board ) NEW_LINE DEDENT
def solveKTUtil ( n , board , curr_x , curr_y , move_x , move_y , pos ) : NEW_LINE INDENT if ( pos == n ** 2 ) : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT
for i in range ( 8 ) : NEW_LINE INDENT new_x = curr_x + move_x [ i ] NEW_LINE new_y = curr_y + move_y [ i ] NEW_LINE if ( isSafe ( new_x , new_y , board ) ) : NEW_LINE INDENT board [ new_x ] [ new_y ] = pos NEW_LINE if ( solveKTUtil ( n , board , new_x , new_y , move_x , move_y , pos + 1 ) ) : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT DEDENT
board [ new_x ] [ new_y ] = - 1 NEW_LINE return False NEW_LINE
solveKT ( n ) NEW_LINE
def printSolution ( color ) : NEW_LINE INDENT print ( " Solution ▁ Exists : " " ▁ Following ▁ are ▁ the ▁ assigned ▁ colors ▁ " ) NEW_LINE for i in range ( 4 ) : NEW_LINE INDENT print ( color [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def isSafe ( graph , color ) : NEW_LINE
for i in range ( 4 ) : NEW_LINE INDENT for j in range ( i + 1 , 4 ) : NEW_LINE INDENT if ( graph [ i ] [ j ] and color [ j ] == color [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT return True NEW_LINE
def graphColoring ( graph , m , i , color ) : NEW_LINE
if ( i == 4 ) : NEW_LINE
if ( isSafe ( graph , color ) ) : NEW_LINE
printSolution ( color ) NEW_LINE return True NEW_LINE return False NEW_LINE
for j in range ( 1 , m + 1 ) : NEW_LINE INDENT color [ i ] = j NEW_LINE DEDENT
if ( graphColoring ( graph , m , i + 1 , color ) ) : NEW_LINE INDENT return True NEW_LINE DEDENT color [ i ] = 0 NEW_LINE return False NEW_LINE
graph = [ [ 0 , 1 , 1 , 1 ] , [ 1 , 0 , 1 , 0 ] , [ 1 , 1 , 0 , 1 ] , [ 1 , 0 , 1 , 0 ] , ] NEW_LINE
m = 3 NEW_LINE
color = [ 0 for i in range ( 4 ) ] NEW_LINE if ( not graphColoring ( graph , m , 0 , color ) ) : NEW_LINE INDENT print ( " Solution ▁ does ▁ not ▁ exist " ) NEW_LINE DEDENT
def shortestChainLen ( start , target , D ) : NEW_LINE INDENT if start == target : NEW_LINE return 0 NEW_LINE DEDENT
if target not in D : NEW_LINE INDENT return 0 NEW_LINE DEDENT
level , wordlength = 0 , len ( start ) NEW_LINE
Q = deque ( ) NEW_LINE Q . append ( start ) NEW_LINE
while ( len ( Q ) > 0 ) : NEW_LINE
level += 1 NEW_LINE
sizeofQ = len ( Q ) NEW_LINE
for i in range ( sizeofQ ) : NEW_LINE
word = [ j for j in Q . popleft ( ) ] NEW_LINE
for pos in range ( wordlength ) : NEW_LINE
orig_char = word [ pos ] NEW_LINE
for c in range ( ord ( ' a ' ) , ord ( ' z ' ) + 1 ) : NEW_LINE INDENT word [ pos ] = chr ( c ) NEW_LINE DEDENT
if ( " " . join ( word ) == target ) : NEW_LINE INDENT return level + 1 NEW_LINE DEDENT
if ( " " . join ( word ) not in D ) : NEW_LINE INDENT continue NEW_LINE DEDENT del D [ " " . join ( word ) ] NEW_LINE
Q . append ( " " . join ( word ) ) NEW_LINE
word [ pos ] = orig_char NEW_LINE return 0 NEW_LINE
D = { } NEW_LINE D [ " poon " ] = 1 NEW_LINE D [ " plee " ] = 1 NEW_LINE D [ " same " ] = 1 NEW_LINE D [ " poie " ] = 1 NEW_LINE D [ " plie " ] = 1 NEW_LINE D [ " poin " ] = 1 NEW_LINE D [ " plea " ] = 1 NEW_LINE start = " toon " NEW_LINE target = " plea " NEW_LINE print ( " Length ▁ of ▁ shortest ▁ chain ▁ is : ▁ " , shortestChainLen ( start , target , D ) ) NEW_LINE
INF = 2147483647 NEW_LINE N = 4 NEW_LINE
def minCost ( cost ) : NEW_LINE
dist = [ 0 for i in range ( N ) ] NEW_LINE for i in range ( N ) : NEW_LINE INDENT dist [ i ] = INF NEW_LINE DEDENT dist [ 0 ] = 0 NEW_LINE
for i in range ( N ) : NEW_LINE INDENT for j in range ( i + 1 , N ) : NEW_LINE INDENT if ( dist [ j ] > dist [ i ] + cost [ i ] [ j ] ) : NEW_LINE INDENT dist [ j ] = dist [ i ] + cost [ i ] [ j ] NEW_LINE DEDENT DEDENT DEDENT return dist [ N - 1 ] NEW_LINE
cost = [ [ 0 , 15 , 80 , 90 ] , [ INF , 0 , 40 , 50 ] , [ INF , INF , 0 , 70 ] , [ INF , INF , INF , 0 ] ] NEW_LINE print ( " The ▁ Minimum ▁ cost ▁ to ▁ reach ▁ station ▁ " , N , " ▁ is ▁ " , minCost ( cost ) ) NEW_LINE
def numOfways ( n , k ) : NEW_LINE INDENT p = 1 NEW_LINE if ( k % 2 ) : NEW_LINE INDENT p = - 1 NEW_LINE DEDENT return ( pow ( n - 1 , k ) + p * ( n - 1 ) ) / n NEW_LINE DEDENT
n = 4 NEW_LINE k = 2 NEW_LINE print ( numOfways ( n , k ) ) NEW_LINE
if ( inMST [ v ] == False and key [ v ] > weight ) : NEW_LINE
INDENT key [ v ] = weight NEW_LINE pq . append ( [ key [ v ] , v ] ) NEW_LINE parent [ v ] = u NEW_LINE DEDENT
def addEdge ( adj , u , v , wt ) : NEW_LINE INDENT adj [ u ] . append ( [ v , wt ] ) NEW_LINE adj [ v ] . append ( [ u , wt ] ) NEW_LINE return adj NEW_LINE DEDENT
def printGraph ( adj , V ) : NEW_LINE INDENT v , w = 0 , 0 NEW_LINE for u in range ( V ) : NEW_LINE INDENT print ( " Node " , u , " makes ▁ an ▁ edge ▁ with " ) NEW_LINE for it in adj [ u ] : NEW_LINE INDENT v = it [ 0 ] NEW_LINE w = it [ 1 ] NEW_LINE print ( " TABSYMBOL Node " , v , " with ▁ edge ▁ weight ▁ = " , w ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT V = 5 NEW_LINE adj = [ [ ] for i in range ( V ) ] NEW_LINE adj = addEdge ( adj , 0 , 1 , 10 ) NEW_LINE adj = addEdge ( adj , 0 , 4 , 20 ) NEW_LINE adj = addEdge ( adj , 1 , 2 , 30 ) NEW_LINE adj = addEdge ( adj , 1 , 3 , 40 ) NEW_LINE adj = addEdge ( adj , 1 , 4 , 50 ) NEW_LINE adj = addEdge ( adj , 2 , 3 , 60 ) NEW_LINE adj = addEdge ( adj , 3 , 4 , 70 ) NEW_LINE printGraph ( adj , V ) NEW_LINE DEDENT
def maxindex ( dist , n ) : NEW_LINE INDENT mi = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( dist [ i ] > dist [ mi ] ) : NEW_LINE INDENT mi = i NEW_LINE DEDENT DEDENT return mi NEW_LINE DEDENT def selectKcities ( n , weights , k ) : NEW_LINE INDENT dist = [ 0 ] * n NEW_LINE centers = [ ] NEW_LINE for i in range ( n ) : NEW_LINE INDENT dist [ i ] = 10 ** 9 NEW_LINE DEDENT DEDENT
max = 0 NEW_LINE for i in range ( k ) : NEW_LINE INDENT centers . append ( max ) NEW_LINE for j in range ( n ) : NEW_LINE DEDENT
dist [ j ] = min ( dist [ j ] , weights [ max ] [ j ] ) NEW_LINE
max = maxindex ( dist , n ) NEW_LINE
print ( dist [ max ] ) NEW_LINE
for i in centers : NEW_LINE INDENT print ( i , end = " ▁ " ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = 4 NEW_LINE weights = [ [ 0 , 4 , 8 , 5 ] , [ 4 , 0 , 10 , 7 ] , [ 8 , 10 , 0 , 9 ] , [ 5 , 7 , 9 , 0 ] ] NEW_LINE k = 2 NEW_LINE DEDENT
selectKcities ( n , weights , k ) NEW_LINE
V = 4 NEW_LINE
def multiply ( A , B , C ) : NEW_LINE INDENT global V NEW_LINE for i in range ( V ) : NEW_LINE INDENT for j in range ( V ) : NEW_LINE INDENT C [ i ] [ j ] = 0 NEW_LINE for k in range ( V ) : NEW_LINE INDENT C [ i ] [ j ] += A [ i ] [ k ] * B [ k ] [ j ] NEW_LINE DEDENT DEDENT DEDENT DEDENT
def getTrace ( graph ) : NEW_LINE INDENT global V NEW_LINE trace = 0 NEW_LINE for i in range ( V ) : NEW_LINE INDENT trace += graph [ i ] [ i ] NEW_LINE DEDENT return trace NEW_LINE DEDENT
def triangleInGraph ( graph ) : NEW_LINE INDENT global V NEW_LINE DEDENT
aux2 = [ [ None ] * V for i in range ( V ) ] NEW_LINE
aux3 = [ [ None ] * V for i in range ( V ) ] NEW_LINE
for i in range ( V ) : NEW_LINE INDENT for j in range ( V ) : NEW_LINE INDENT aux2 [ i ] [ j ] = aux3 [ i ] [ j ] = 0 NEW_LINE DEDENT DEDENT
multiply ( graph , graph , aux2 ) NEW_LINE
multiply ( graph , aux2 , aux3 ) NEW_LINE trace = getTrace ( aux3 ) NEW_LINE return trace // 6 NEW_LINE
graph = [ [ 0 , 1 , 1 , 0 ] , [ 1 , 0 , 1 , 1 ] , [ 1 , 1 , 0 , 1 ] , [ 0 , 1 , 1 , 0 ] ] NEW_LINE print ( " Total ▁ number ▁ of ▁ Triangle ▁ in ▁ Graph ▁ : " , triangleInGraph ( graph ) ) NEW_LINE
def power ( n ) : NEW_LINE INDENT if n == 1 : NEW_LINE INDENT return 2 NEW_LINE DEDENT return 2 * power ( n - 1 ) NEW_LINE DEDENT
n = 4 NEW_LINE print ( power ( n ) ) NEW_LINE
size = 4 NEW_LINE
def checkStar ( mat ) : NEW_LINE INDENT global size NEW_LINE DEDENT
vertexD1 = 0 NEW_LINE vertexDn_1 = 0 NEW_LINE
if ( size == 1 ) : NEW_LINE INDENT return ( mat [ 0 ] [ 0 ] == 0 ) NEW_LINE DEDENT
if ( size == 2 ) : NEW_LINE INDENT return ( mat [ 0 ] [ 0 ] == 0 and mat [ 0 ] [ 1 ] == 1 and mat [ 1 ] [ 0 ] == 1 and mat [ 1 ] [ 1 ] == 0 ) NEW_LINE DEDENT
for i in range ( 0 , size ) : NEW_LINE INDENT degreeI = 0 NEW_LINE for j in range ( 0 , size ) : NEW_LINE INDENT if ( mat [ i ] [ j ] ) : NEW_LINE INDENT degreeI = degreeI + 1 NEW_LINE DEDENT DEDENT if ( degreeI == 1 ) : NEW_LINE INDENT vertexD1 = vertexD1 + 1 NEW_LINE DEDENT elif ( degreeI == size - 1 ) : NEW_LINE INDENT vertexDn_1 = vertexDn_1 + 1 NEW_LINE DEDENT DEDENT return ( vertexD1 == ( size - 1 ) and vertexDn_1 == 1 ) NEW_LINE
mat = [ [ 0 , 1 , 1 , 1 ] , [ 1 , 0 , 0 , 0 ] , [ 1 , 0 , 0 , 0 ] , [ 1 , 0 , 0 , 0 ] ] NEW_LINE if ( checkStar ( mat ) ) : NEW_LINE INDENT print ( " Star ▁ Graph " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Not ▁ a ▁ Star ▁ Graph " ) NEW_LINE DEDENT
def fib ( n ) : NEW_LINE INDENT if n <= 1 : NEW_LINE INDENT return n NEW_LINE DEDENT return fib ( n - 1 ) + fib ( n - 2 ) NEW_LINE DEDENT
def findVertices ( n ) : NEW_LINE
return fib ( n + 2 ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 3 NEW_LINE print ( findVertices ( n ) ) NEW_LINE DEDENT
def push ( self , new_data ) : NEW_LINE
new_node = Node ( new_data ) NEW_LINE
new_node . next = self . head NEW_LINE
self . head = new_node NEW_LINE
def insertAfter ( self , prev_node , new_data ) : NEW_LINE
if prev_node is None : NEW_LINE INDENT print " The ▁ given ▁ previous ▁ node ▁ must ▁ inLinkedList . " NEW_LINE return NEW_LINE DEDENT
new_node = Node ( new_data ) NEW_LINE
new_node . next = prev_node . next NEW_LINE
prev_node . next = new_node NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def __init__ ( self ) : NEW_LINE INDENT self . head = None NEW_LINE DEDENT
def push ( self , new_data ) : NEW_LINE
new_node = Node ( new_data ) NEW_LINE
new_node . next = self . head NEW_LINE
self . head = new_node NEW_LINE
def getCountRec ( self , node ) : NEW_LINE
if ( not node ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
else : NEW_LINE INDENT return 1 + self . getCountRec ( node . next ) NEW_LINE DEDENT
def getCount ( self ) : NEW_LINE INDENT return self . getCountRec ( self . head ) NEW_LINE DEDENT
llist = LinkedList ( ) NEW_LINE llist . push ( 1 ) NEW_LINE llist . push ( 3 ) NEW_LINE llist . push ( 1 ) NEW_LINE llist . push ( 2 ) NEW_LINE llist . push ( 1 ) NEW_LINE print ' Count ▁ of ▁ nodes ▁ is ▁ : ' , llist . getCount ( ) NEW_LINE
def count ( self , temp , key ) : NEW_LINE INDENT if temp is None : NEW_LINE INDENT return 0 NEW_LINE DEDENT if temp . data == key : NEW_LINE INDENT return 1 + count ( temp . next , key ) NEW_LINE DEDENT return count ( temp . next , key ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT class LinkedList : NEW_LINE
def __init__ ( self ) : NEW_LINE INDENT self . head = None NEW_LINE DEDENT
def isPalindrome ( self , head ) : NEW_LINE INDENT slow_ptr = head NEW_LINE fast_ptr = head NEW_LINE prev_of_slow_ptr = head NEW_LINE DEDENT
midnode = None NEW_LINE
res = True NEW_LINE if ( head != None and head . next != None ) : NEW_LINE
while ( fast_ptr != None and fast_ptr . next != None ) : NEW_LINE
fast_ptr = fast_ptr . next . next NEW_LINE prev_of_slow_ptr = slow_ptr NEW_LINE slow_ptr = slow_ptr . next NEW_LINE
if ( fast_ptr != None ) : NEW_LINE INDENT midnode = slow_ptr NEW_LINE slow_ptr = slow_ptr . next NEW_LINE DEDENT
second_half = slow_ptr NEW_LINE
prev_of_slow_ptr . next = None NEW_LINE
second_half = self . reverse ( second_half ) NEW_LINE
res = self . compareLists ( head , second_half ) NEW_LINE
second_half = self . reverse ( second_half ) NEW_LINE if ( midnode != None ) : NEW_LINE
prev_of_slow_ptr . next = midnode NEW_LINE midnode . next = second_half NEW_LINE else : NEW_LINE prev_of_slow_ptr . next = second_half NEW_LINE return res NEW_LINE
def reverse ( self , second_half ) : NEW_LINE INDENT prev = None NEW_LINE current = second_half NEW_LINE next = None NEW_LINE while current != None : NEW_LINE INDENT next = current . next NEW_LINE current . next = prev NEW_LINE prev = current NEW_LINE current = next NEW_LINE DEDENT second_half = prev NEW_LINE return second_half NEW_LINE DEDENT
def compareLists ( self , head1 , head2 ) : NEW_LINE INDENT temp1 = head1 NEW_LINE temp2 = head2 NEW_LINE while ( temp1 and temp2 ) : NEW_LINE INDENT if ( temp1 . data == temp2 . data ) : NEW_LINE INDENT temp1 = temp1 . next NEW_LINE temp2 = temp2 . next NEW_LINE DEDENT else : NEW_LINE INDENT return 0 NEW_LINE DEDENT DEDENT DEDENT
if ( temp1 == None and temp2 == None ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
return 0 NEW_LINE
def push ( self , new_data ) : NEW_LINE
new_node = Node ( new_data ) NEW_LINE
new_node . next = self . head NEW_LINE
self . head = new_node NEW_LINE
def printList ( self ) : NEW_LINE INDENT temp = self . head NEW_LINE while ( temp ) : NEW_LINE INDENT print ( temp . data , end = " - > " ) NEW_LINE temp = temp . next NEW_LINE DEDENT print ( " NULL " ) NEW_LINE DEDENT
l = LinkedList ( ) NEW_LINE s = [ ' a ' , ' b ' , ' a ' , ' c ' , ' a ' , ' b ' , ' a ' ] NEW_LINE for i in range ( 7 ) : NEW_LINE INDENT l . push ( s [ i ] ) NEW_LINE l . printList ( ) NEW_LINE if ( l . isPalindrome ( l . head ) != False ) : NEW_LINE INDENT print ( " Is Palindrome " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Not Palindrome " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
class LinkedList ( object ) : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . head = None NEW_LINE DEDENT DEDENT
class Node ( object ) : NEW_LINE INDENT def __init__ ( self , d ) : NEW_LINE INDENT self . data = d NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def swapNodes ( self , x , y ) : NEW_LINE
if x == y : NEW_LINE INDENT return NEW_LINE DEDENT
prevX = None NEW_LINE currX = self . head NEW_LINE while currX != None and currX . data != x : NEW_LINE INDENT prevX = currX NEW_LINE currX = currX . next NEW_LINE DEDENT
prevY = None NEW_LINE currY = self . head NEW_LINE while currY != None and currY . data != y : NEW_LINE INDENT prevY = currY NEW_LINE currY = currY . next NEW_LINE DEDENT
if currX == None or currY == None : NEW_LINE INDENT return NEW_LINE DEDENT
if prevX != None : NEW_LINE INDENT prevX . next = currY NEW_LINE DEDENT
else : NEW_LINE INDENT self . head = currY NEW_LINE DEDENT
if prevY != None : NEW_LINE INDENT prevY . next = currX NEW_LINE DEDENT
else : NEW_LINE INDENT self . head = currX NEW_LINE DEDENT
temp = currX . next NEW_LINE currX . next = currY . next NEW_LINE currY . next = temp NEW_LINE
def push ( self , new_data ) : NEW_LINE
new_Node = self . Node ( new_data ) NEW_LINE
new_Node . next = self . head NEW_LINE
self . head = new_Node NEW_LINE
def printList ( self ) : NEW_LINE INDENT tNode = self . head NEW_LINE while tNode != None : NEW_LINE INDENT print tNode . data , NEW_LINE tNode = tNode . next NEW_LINE DEDENT DEDENT
llist . push ( 7 ) NEW_LINE llist . push ( 6 ) NEW_LINE llist . push ( 5 ) NEW_LINE llist . push ( 4 ) NEW_LINE llist . push ( 3 ) NEW_LINE llist . push ( 2 ) NEW_LINE llist . push ( 1 ) NEW_LINE print " Linked ▁ list ▁ before ▁ calling ▁ swapNodes ( ) ▁ " NEW_LINE llist . printList ( ) NEW_LINE llist . swapNodes ( 4 , 3 ) NEW_LINE print   " NEW_LINE Linked list after calling swapNodes ( )   " NEW_LINE llist . printList ( ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def getJosephusPosition ( m , n ) : NEW_LINE
head = Node ( 1 ) NEW_LINE prev = head NEW_LINE for i in range ( 2 , n + 1 ) : NEW_LINE INDENT prev . next = Node ( i ) NEW_LINE prev = prev . next NEW_LINE DEDENT
prev . next = head NEW_LINE
ptr1 = head NEW_LINE ptr2 = head NEW_LINE while ( ptr1 . next != ptr1 ) : NEW_LINE
count = 1 NEW_LINE while ( count != m ) : NEW_LINE INDENT ptr2 = ptr1 NEW_LINE ptr1 = ptr1 . next NEW_LINE count += 1 NEW_LINE DEDENT
ptr2 . next = ptr1 . next NEW_LINE ptr1 = ptr2 . next NEW_LINE print ( " Last ▁ person ▁ left ▁ standing ▁ ( Josephus ▁ Position ) ▁ is ▁ " , ptr1 . data ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = 14 NEW_LINE m = 2 NEW_LINE getJosephusPosition ( m , n ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data , next = None ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = next NEW_LINE DEDENT DEDENT class LinkedList : NEW_LINE INDENT def __init__ ( self , * args , ** kwargs ) : NEW_LINE INDENT self . head = Node ( None ) NEW_LINE DEDENT DEDENT
def push ( self , data ) : NEW_LINE INDENT node = Node ( data ) NEW_LINE node . next = self . head NEW_LINE self . head = node NEW_LINE DEDENT
def printList ( self ) : NEW_LINE INDENT node = self . head NEW_LINE while node . next is not None : NEW_LINE INDENT print ( node . data , end = " ▁ " ) NEW_LINE node = node . next NEW_LINE DEDENT DEDENT
def countNodes ( self ) : NEW_LINE INDENT count = 0 NEW_LINE node = self . head NEW_LINE while node . next is not None : NEW_LINE INDENT count += 1 NEW_LINE node = node . next NEW_LINE DEDENT return count NEW_LINE DEDENT
def swapKth ( self , k ) : NEW_LINE
n = self . countNodes ( ) NEW_LINE
if n < k : NEW_LINE INDENT return NEW_LINE DEDENT
if ( 2 * k - 1 ) == n : NEW_LINE INDENT return NEW_LINE DEDENT
x = self . head NEW_LINE x_prev = Node ( None ) NEW_LINE for i in range ( k - 1 ) : NEW_LINE INDENT x_prev = x NEW_LINE x = x . next NEW_LINE DEDENT
y = self . head NEW_LINE y_prev = Node ( None ) NEW_LINE for i in range ( n - k ) : NEW_LINE INDENT y_prev = y NEW_LINE y = y . next NEW_LINE DEDENT
if x_prev is not None : NEW_LINE INDENT x_prev . next = y NEW_LINE DEDENT
if y_prev is not None : NEW_LINE INDENT y_prev . next = x NEW_LINE DEDENT
temp = x . next NEW_LINE x . next = y . next NEW_LINE y . next = temp NEW_LINE
if k == 1 : NEW_LINE INDENT self . head = y NEW_LINE DEDENT if k == n : NEW_LINE INDENT self . head = x NEW_LINE DEDENT
llist = LinkedList ( ) NEW_LINE for i in range ( 8 , 0 , - 1 ) : NEW_LINE INDENT llist . push ( i ) NEW_LINE DEDENT llist . printList ( ) NEW_LINE for i in range ( 1 , 9 ) : NEW_LINE INDENT llist . swapKth ( i ) NEW_LINE print ( " Modified ▁ List ▁ for ▁ k ▁ = ▁ " , i ) NEW_LINE llist . printList ( ) NEW_LINE print ( " " ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . next = None NEW_LINE self . prev = None NEW_LINE DEDENT DEDENT
def countPairs ( first , second , value ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
while ( first != None and second != None and first != second and second . next != first ) : NEW_LINE
if ( ( first . data + second . data ) == value ) : NEW_LINE
count += 1 NEW_LINE
first = first . next NEW_LINE
second = second . prev NEW_LINE
elif ( ( first . data + second . data ) > value ) : NEW_LINE INDENT second = second . prev NEW_LINE DEDENT
else : NEW_LINE INDENT first = first . next NEW_LINE DEDENT
return count NEW_LINE
def countTriplets ( head , x ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT current , first , last = head , None , None NEW_LINE count = 0 NEW_LINE
last = head NEW_LINE while ( last . next != None ) : NEW_LINE INDENT last = last . next NEW_LINE DEDENT
while current != None : NEW_LINE
first = current . next NEW_LINE
count , current = count + countPairs ( first , last , x - current . data ) , current . next NEW_LINE
return count NEW_LINE
def insert ( head , data ) : NEW_LINE
temp = Node ( data ) NEW_LINE
if ( head == None ) : NEW_LINE INDENT head = temp NEW_LINE DEDENT else : NEW_LINE INDENT temp . next = head NEW_LINE head . prev = temp NEW_LINE head = temp NEW_LINE DEDENT return head NEW_LINE
head = None NEW_LINE
head = insert ( head , 9 ) NEW_LINE head = insert ( head , 8 ) NEW_LINE head = insert ( head , 6 ) NEW_LINE head = insert ( head , 5 ) NEW_LINE head = insert ( head , 4 ) NEW_LINE head = insert ( head , 2 ) NEW_LINE head = insert ( head , 1 ) NEW_LINE x = 17 NEW_LINE print ( " Count ▁ = ▁ " , countTriplets ( head , x ) ) NEW_LINE
def deleteNode ( head_ref , del_ ) : NEW_LINE
if ( head_ref == None or del_ == None ) : NEW_LINE INDENT return head_ref NEW_LINE DEDENT
if ( head_ref == del_ ) : NEW_LINE INDENT head_ref = del_ . next NEW_LINE DEDENT
if ( del_ . next != None ) : NEW_LINE INDENT del_ . next . prev = del_ . prev NEW_LINE DEDENT
if ( del_ . prev != None ) : NEW_LINE INDENT del_ . prev . next = del_ . next NEW_LINE DEDENT return head_ref NEW_LINE
def removeDuplicates ( head_ref ) : NEW_LINE
if ( ( head_ref ) == None or ( head_ref ) . next == None ) : NEW_LINE INDENT return head_ref NEW_LINE DEDENT ptr1 = head_ref NEW_LINE ptr2 = None NEW_LINE
while ( ptr1 != None ) : NEW_LINE INDENT ptr2 = ptr1 . next NEW_LINE DEDENT
while ( ptr2 != None ) : NEW_LINE
if ( ptr1 . data == ptr2 . data ) : NEW_LINE
next = ptr2 . next NEW_LINE
head_ref = deleteNode ( head_ref , ptr2 ) NEW_LINE
ptr2 = next NEW_LINE
else : NEW_LINE INDENT ptr2 = ptr2 . next NEW_LINE DEDENT ptr1 = ptr1 . next NEW_LINE return head_ref NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE
new_node = Node ( ) NEW_LINE
new_node . data = new_data NEW_LINE
new_node . prev = None NEW_LINE
new_node . next = ( head_ref ) NEW_LINE
if ( ( head_ref ) != None ) : NEW_LINE INDENT ( head_ref ) . prev = new_node NEW_LINE DEDENT
( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE
def printList ( head ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT print ( " Doubly ▁ Linked ▁ list ▁ empty " ) NEW_LINE DEDENT while ( head != None ) : NEW_LINE INDENT print ( head . data , end = " ▁ " ) NEW_LINE head = head . next NEW_LINE DEDENT
head = None NEW_LINE
head = push ( head , 12 ) NEW_LINE head = push ( head , 12 ) NEW_LINE head = push ( head , 10 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 8 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 6 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 8 ) NEW_LINE print ( " Original ▁ Doubly ▁ linked ▁ list : " ) NEW_LINE printList ( head ) NEW_LINE
head = removeDuplicates ( head ) NEW_LINE print ( " Doubly linked list after removing duplicates : " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . data = 0 NEW_LINE self . next = None NEW_LINE self . prev = None NEW_LINE DEDENT DEDENT
def deleteNode ( head_ref , del_ ) : NEW_LINE
if ( head_ref == None or del_ == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT
if ( head_ref == del_ ) : NEW_LINE INDENT head_ref = del_ . next NEW_LINE DEDENT
if ( del_ . next != None ) : NEW_LINE INDENT del_ . next . prev = del_ . prev NEW_LINE DEDENT
if ( del_ . prev != None ) : NEW_LINE INDENT del_ . prev . next = del_ . next NEW_LINE DEDENT return head_ref NEW_LINE
def removeDuplicates ( head_ref ) : NEW_LINE
if ( ( head_ref ) == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT
us = set ( ) NEW_LINE current = head_ref NEW_LINE next = None NEW_LINE
while ( current != None ) : NEW_LINE
if ( ( current . data ) in us ) : NEW_LINE
next = current . next NEW_LINE
head_ref = deleteNode ( head_ref , current ) NEW_LINE
current = next NEW_LINE else : NEW_LINE
us . add ( current . data ) NEW_LINE
current = current . next NEW_LINE return head_ref NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE
new_node = Node ( ) NEW_LINE
new_node . data = new_data NEW_LINE
new_node . prev = None NEW_LINE
new_node . next = ( head_ref ) NEW_LINE
if ( ( head_ref ) != None ) : NEW_LINE INDENT ( head_ref ) . prev = new_node NEW_LINE DEDENT
( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE
def printList ( head ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT print ( " Doubly ▁ Linked ▁ list ▁ empty " ) NEW_LINE DEDENT while ( head != None ) : NEW_LINE INDENT print ( head . data , end = " ▁ " ) NEW_LINE head = head . next NEW_LINE DEDENT
head = None NEW_LINE
head = push ( head , 12 ) NEW_LINE head = push ( head , 12 ) NEW_LINE head = push ( head , 10 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 8 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 6 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 8 ) NEW_LINE print ( " Original ▁ Doubly ▁ linked ▁ list : " ) NEW_LINE printList ( head ) NEW_LINE
head = removeDuplicates ( head ) NEW_LINE print ( " Doubly linked list after removing duplicates : " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , next = None , prev = None , data = None ) : NEW_LINE INDENT self . next = next NEW_LINE self . prev = prev NEW_LINE self . data = data NEW_LINE DEDENT DEDENT
def reverse ( head_ref ) : NEW_LINE INDENT temp = None NEW_LINE current = head_ref NEW_LINE DEDENT
while ( current != None ) : NEW_LINE INDENT temp = current . prev NEW_LINE current . prev = current . next NEW_LINE current . next = temp NEW_LINE current = current . prev NEW_LINE DEDENT
if ( temp != None ) : NEW_LINE INDENT head_ref = temp . prev NEW_LINE return head_ref NEW_LINE DEDENT
def merge ( first , second ) : NEW_LINE
if ( first == None ) : NEW_LINE INDENT return second NEW_LINE DEDENT
if ( second == None ) : NEW_LINE INDENT return first NEW_LINE DEDENT
if ( first . data < second . data ) : NEW_LINE INDENT first . next = merge ( first . next , second ) NEW_LINE first . next . prev = first NEW_LINE first . prev = None NEW_LINE return first NEW_LINE DEDENT else : NEW_LINE INDENT second . next = merge ( first , second . next ) NEW_LINE second . next . prev = second NEW_LINE second . prev = None NEW_LINE return second NEW_LINE DEDENT
def sort ( head ) : NEW_LINE
if ( head == None or head . next == None ) : NEW_LINE INDENT return head NEW_LINE DEDENT current = head . next NEW_LINE while ( current != None ) : NEW_LINE
if ( current . data < current . prev . data ) : NEW_LINE INDENT break NEW_LINE DEDENT
current = current . next NEW_LINE
if ( current == None ) : NEW_LINE INDENT return head NEW_LINE DEDENT
current . prev . next = None NEW_LINE current . prev = None NEW_LINE
current = reverse ( current ) NEW_LINE
return merge ( head , current ) NEW_LINE
def push ( head_ref , new_data ) : NEW_LINE
new_node = Node ( ) NEW_LINE
new_node . data = new_data NEW_LINE
new_node . prev = None NEW_LINE
new_node . next = ( head_ref ) NEW_LINE
if ( ( head_ref ) != None ) : NEW_LINE INDENT ( head_ref ) . prev = new_node NEW_LINE DEDENT
( head_ref ) = new_node NEW_LINE return head_ref NEW_LINE
def printList ( head ) : NEW_LINE
if ( head == None ) : NEW_LINE INDENT print ( " Doubly ▁ Linked ▁ list ▁ empty " ) NEW_LINE DEDENT while ( head != None ) : NEW_LINE INDENT print ( head . data , end = " ▁ " ) NEW_LINE head = head . next NEW_LINE DEDENT
head = None NEW_LINE
head = push ( head , 1 ) NEW_LINE head = push ( head , 4 ) NEW_LINE head = push ( head , 6 ) NEW_LINE head = push ( head , 10 ) NEW_LINE head = push ( head , 12 ) NEW_LINE head = push ( head , 7 ) NEW_LINE head = push ( head , 5 ) NEW_LINE head = push ( head , 2 ) NEW_LINE print ( " Original ▁ Doubly ▁ linked ▁ list : n " ) NEW_LINE printList ( head ) NEW_LINE
head = sort ( head ) NEW_LINE print ( " Doubly linked list after sorting : " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . info = data NEW_LINE self . next = None NEW_LINE self . prev = None NEW_LINE DEDENT DEDENT head = None NEW_LINE tail = None NEW_LINE
def nodeInsetail ( key ) : NEW_LINE INDENT global head NEW_LINE global tail NEW_LINE p = Node ( 0 ) NEW_LINE p . info = key NEW_LINE p . next = None NEW_LINE DEDENT
if ( ( head ) == None ) : NEW_LINE INDENT ( head ) = p NEW_LINE ( tail ) = p NEW_LINE ( head ) . prev = None NEW_LINE return NEW_LINE DEDENT
if ( ( p . info ) < ( ( head ) . info ) ) : NEW_LINE INDENT p . prev = None NEW_LINE ( head ) . prev = p NEW_LINE p . next = ( head ) NEW_LINE ( head ) = p NEW_LINE return NEW_LINE DEDENT
if ( ( p . info ) > ( ( tail ) . info ) ) : NEW_LINE INDENT p . prev = ( tail ) NEW_LINE ( tail ) . next = p NEW_LINE ( tail ) = p NEW_LINE return NEW_LINE DEDENT
temp = ( head ) . next NEW_LINE while ( ( temp . info ) < ( p . info ) ) : NEW_LINE INDENT temp = temp . next NEW_LINE DEDENT
( temp . prev ) . next = p NEW_LINE p . prev = temp . prev NEW_LINE temp . prev = p NEW_LINE p . next = temp NEW_LINE
def printList ( temp ) : NEW_LINE INDENT while ( temp != None ) : NEW_LINE INDENT print ( temp . info , end = " ▁ " ) NEW_LINE temp = temp . next NEW_LINE DEDENT DEDENT
nodeInsetail ( 30 ) NEW_LINE nodeInsetail ( 50 ) NEW_LINE nodeInsetail ( 90 ) NEW_LINE nodeInsetail ( 10 ) NEW_LINE nodeInsetail ( 40 ) NEW_LINE nodeInsetail ( 110 ) NEW_LINE nodeInsetail ( 60 ) NEW_LINE nodeInsetail ( 95 ) NEW_LINE nodeInsetail ( 23 ) NEW_LINE print ( " Doubly linked list on printing from left to right " ) NEW_LINE printList ( head ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def findDepthRec ( tree , n , index ) : NEW_LINE INDENT if ( index [ 0 ] >= n or tree [ index [ 0 ] ] == ' l ' ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT DEDENT
index [ 0 ] += 1 NEW_LINE left = findDepthRec ( tree , n , index ) NEW_LINE
index [ 0 ] += 1 NEW_LINE right = findDepthRec ( tree , n , index ) NEW_LINE return ( max ( left , right ) + 1 ) NEW_LINE
def findDepth ( tree , n ) : NEW_LINE INDENT index = [ 0 ] NEW_LINE return findDepthRec ( tree , n , index ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT tree = " nlnnlll " NEW_LINE n = len ( tree ) NEW_LINE print ( findDepth ( tree , n ) ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . next = None NEW_LINE DEDENT DEDENT
def printlist ( head ) : NEW_LINE INDENT if ( not head ) : NEW_LINE INDENT print ( " Empty ▁ List " ) NEW_LINE return NEW_LINE DEDENT while ( head != None ) : NEW_LINE INDENT print ( head . data , end = " ▁ " ) NEW_LINE if ( head . next ) : NEW_LINE INDENT print ( end = " - > ▁ " ) NEW_LINE DEDENT head = head . next NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
def isVowel ( x ) : NEW_LINE INDENT return ( x == ' a ' or x == ' e ' or x == ' i ' or x == ' o ' or x == ' u ' or x == ' A ' or x == ' E ' or x == ' I ' or x == ' O ' or x == ' U ' ) NEW_LINE DEDENT
def arrange ( head ) : NEW_LINE INDENT newHead = head NEW_LINE DEDENT
latestVowel = None NEW_LINE curr = head NEW_LINE
if ( head == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT
if ( isVowel ( head . data ) ) : NEW_LINE
latestVowel = head NEW_LINE else : NEW_LINE
while ( curr . next != None and not isVowel ( curr . next . data ) ) : NEW_LINE INDENT curr = curr . next NEW_LINE DEDENT
if ( curr . next == None ) : NEW_LINE INDENT return head NEW_LINE DEDENT
latestVowel = newHead = curr . next NEW_LINE curr . next = curr . next . next NEW_LINE latestVowel . next = head NEW_LINE
while ( curr != None and curr . next != None ) : NEW_LINE INDENT if ( isVowel ( curr . next . data ) ) : NEW_LINE DEDENT
if ( curr == latestVowel ) : NEW_LINE
latestVowel = curr = curr . next NEW_LINE else : NEW_LINE
temp = latestVowel . next NEW_LINE
latestVowel . next = curr . next NEW_LINE
latestVowel = latestVowel . next NEW_LINE
curr . next = curr . next . next NEW_LINE
latestVowel . next = temp NEW_LINE else : NEW_LINE
curr = curr . next NEW_LINE return newHead NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT head = Node ( ' a ' ) NEW_LINE head . next = Node ( ' b ' ) NEW_LINE head . next . next = Node ( ' c ' ) NEW_LINE head . next . next . next = Node ( ' e ' ) NEW_LINE head . next . next . next . next = Node ( ' d ' ) NEW_LINE head . next . next . next . next . next = Node ( ' o ' ) NEW_LINE head . next . next . next . next . next . next = Node ( ' x ' ) NEW_LINE head . next . next . next . next . next . next . next = Node ( ' i ' ) NEW_LINE print ( " Linked ▁ list ▁ before ▁ : " ) NEW_LINE printlist ( head ) NEW_LINE head = arrange ( head ) NEW_LINE print ( " Linked ▁ list ▁ after ▁ : " ) NEW_LINE printlist ( head ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . data = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def insert ( root , x ) : NEW_LINE INDENT if ( root == None ) : NEW_LINE INDENT return Node ( x ) NEW_LINE DEDENT if ( x < root . data ) : NEW_LINE INDENT root . left = insert ( root . left , x ) NEW_LINE DEDENT elif ( x > root . data ) : NEW_LINE INDENT root . right = insert ( root . right , x ) NEW_LINE DEDENT return root NEW_LINE DEDENT
def kthSmallest ( root ) : NEW_LINE INDENT global k NEW_LINE DEDENT
if ( root == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT
left = kthSmallest ( root . left ) NEW_LINE
if ( left != None ) : NEW_LINE INDENT return left NEW_LINE DEDENT
k -= 1 NEW_LINE if ( k == 0 ) : NEW_LINE INDENT return root NEW_LINE DEDENT
return kthSmallest ( root . right ) NEW_LINE
def printKthSmallest ( root ) : NEW_LINE
count = 0 NEW_LINE res = kthSmallest ( root ) NEW_LINE if ( res == None ) : NEW_LINE INDENT print ( " There ▁ are ▁ less ▁ than ▁ k ▁ nodes ▁ in ▁ the ▁ BST " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " K - th ▁ Smallest ▁ Element ▁ is ▁ " , res . data ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = None NEW_LINE keys = [ 20 , 8 , 22 , 4 , 12 , 10 , 14 ] NEW_LINE for x in keys : NEW_LINE INDENT root = insert ( root , x ) NEW_LINE DEDENT k = 3 NEW_LINE printKthSmallest ( root ) NEW_LINE DEDENT
class TreeNode : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . val = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT s = set ( ) NEW_LINE st = [ ] NEW_LINE
def buildTree ( preorder , inorder , n ) : NEW_LINE INDENT root = None ; NEW_LINE pre = 0 NEW_LINE in_t = 0 NEW_LINE while pre < n : NEW_LINE INDENT node = None ; NEW_LINE while True : NEW_LINE INDENT node = TreeNode ( preorder [ pre ] ) NEW_LINE if ( root == None ) : NEW_LINE INDENT root = node ; NEW_LINE DEDENT if ( len ( st ) > 0 ) : NEW_LINE INDENT if ( st [ - 1 ] in s ) : NEW_LINE INDENT s . discard ( st [ - 1 ] ) ; NEW_LINE st [ - 1 ] . right = node ; NEW_LINE st . pop ( ) ; NEW_LINE DEDENT else : NEW_LINE INDENT st [ - 1 ] . left = node ; NEW_LINE DEDENT DEDENT st . append ( node ) ; NEW_LINE if pre >= n or preorder [ pre ] == inorder [ in_t ] : NEW_LINE INDENT pre += 1 NEW_LINE break NEW_LINE DEDENT pre += 1 NEW_LINE DEDENT node = None ; NEW_LINE while ( len ( st ) > 0 and in_t < n and st [ - 1 ] . val == inorder [ in_t ] ) : NEW_LINE INDENT node = st [ - 1 ] ; NEW_LINE st . pop ( ) ; NEW_LINE in_t += 1 NEW_LINE DEDENT if ( node != None ) : NEW_LINE INDENT s . add ( node ) ; NEW_LINE st . append ( node ) ; NEW_LINE DEDENT DEDENT return root ; NEW_LINE DEDENT
def printInorder ( node ) : NEW_LINE INDENT if ( node == None ) : NEW_LINE INDENT return ; NEW_LINE DEDENT DEDENT
printInorder ( node . left ) ; NEW_LINE
print ( node . val , end = " ▁ " ) ; NEW_LINE
printInorder ( node . right ) ; NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT in_t = [ 9 , 8 , 4 , 2 , 10 , 5 , 10 , 1 , 6 , 3 , 13 , 12 , 7 ] NEW_LINE pre = [ 1 , 2 , 4 , 8 , 9 , 5 , 10 , 10 , 3 , 6 , 7 , 12 , 13 ] NEW_LINE l = len ( in_t ) NEW_LINE root = buildTree ( pre , in_t , l ) ; NEW_LINE printInorder ( root ) ; NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . right = self . left = None NEW_LINE DEDENT DEDENT def KthLargestUsingMorrisTraversal ( root , k ) : NEW_LINE INDENT curr = root NEW_LINE Klargest = None NEW_LINE DEDENT
count = 0 NEW_LINE while ( curr != None ) : NEW_LINE
if ( curr . right == None ) : NEW_LINE
count += 1 NEW_LINE if ( count == k ) : NEW_LINE INDENT Klargest = curr NEW_LINE DEDENT
curr = curr . left NEW_LINE else : NEW_LINE
succ = curr . right NEW_LINE while ( succ . left != None and succ . left != curr ) : NEW_LINE INDENT succ = succ . left NEW_LINE DEDENT if ( succ . left == None ) : NEW_LINE
succ . left = curr NEW_LINE
curr = curr . right NEW_LINE
else : NEW_LINE INDENT succ . left = None NEW_LINE count += 1 NEW_LINE if ( count == k ) : NEW_LINE INDENT Klargest = curr NEW_LINE DEDENT DEDENT
curr = curr . left NEW_LINE return Klargest NEW_LINE
root = newNode ( 4 ) NEW_LINE root . left = newNode ( 2 ) NEW_LINE root . right = newNode ( 7 ) NEW_LINE root . left . left = newNode ( 1 ) NEW_LINE root . left . right = newNode ( 3 ) NEW_LINE root . right . left = newNode ( 6 ) NEW_LINE root . right . right = newNode ( 10 ) NEW_LINE print ( " Finding ▁ K - th ▁ largest ▁ Node ▁ in ▁ BST ▁ : ▁ " , KthLargestUsingMorrisTraversal ( root , 2 ) . data ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . key = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def KSmallestUsingMorris ( root , k ) : NEW_LINE
count = 0 NEW_LINE
ksmall = - 9999999999 NEW_LINE
curr = root NEW_LINE while curr != None : NEW_LINE
if curr . left == None : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
if count == k : NEW_LINE INDENT ksmall = curr . key NEW_LINE DEDENT
curr = curr . right NEW_LINE else : NEW_LINE
pre = curr . left NEW_LINE while ( pre . right != None and pre . right != curr ) : NEW_LINE INDENT pre = pre . right NEW_LINE DEDENT
if pre . right == None : NEW_LINE
pre . right = curr NEW_LINE curr = curr . left NEW_LINE
else : NEW_LINE
pre . right = None NEW_LINE count += 1 NEW_LINE
if count == k : NEW_LINE INDENT ksmall = curr . key NEW_LINE DEDENT curr = curr . right NEW_LINE
return ksmall NEW_LINE
def insert ( node , key ) : NEW_LINE
if node == None : NEW_LINE INDENT return Node ( key ) NEW_LINE DEDENT
if key < node . key : NEW_LINE INDENT node . left = insert ( node . left , key ) NEW_LINE DEDENT elif key > node . key : NEW_LINE INDENT node . right = insert ( node . right , key ) NEW_LINE DEDENT
return node NEW_LINE
root = None NEW_LINE root = insert ( root , 50 ) NEW_LINE insert ( root , 30 ) NEW_LINE insert ( root , 20 ) NEW_LINE insert ( root , 40 ) NEW_LINE insert ( root , 70 ) NEW_LINE insert ( root , 60 ) NEW_LINE insert ( root , 80 ) NEW_LINE for k in range ( 1 , 8 ) : NEW_LINE INDENT print ( KSmallestUsingMorris ( root , k ) , end = " ▁ " ) NEW_LINE DEDENT
def isInorder ( arr , n ) : NEW_LINE
if ( n == 0 or n == 1 ) : NEW_LINE INDENT return True NEW_LINE DEDENT for i in range ( 1 , n , 1 ) : NEW_LINE
if ( arr [ i - 1 ] > arr [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT
return True NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 19 , 23 , 25 , 30 , 45 ] NEW_LINE n = len ( arr ) NEW_LINE if ( isInorder ( arr , n ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT DEDENT
class Node : NEW_LINE INDENT def __init__ ( self ) : NEW_LINE INDENT self . val = 0 NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def Node_ ( val1 ) : NEW_LINE INDENT temp = Node ( ) NEW_LINE temp . val = val1 NEW_LINE temp . left = temp . right = None NEW_LINE return temp NEW_LINE DEDENT v = [ ] NEW_LINE
def storeInorder ( root ) : NEW_LINE INDENT if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT storeInorder ( root . left ) NEW_LINE v . append ( root . data ) NEW_LINE storeInorder ( root . right ) NEW_LINE DEDENT
def checkBSTs ( root1 , root2 ) : NEW_LINE
if ( root1 != None and root2 != None ) : NEW_LINE INDENT return True NEW_LINE DEDENT if ( ( root1 == None and root2 != None ) or ( root1 != None and root2 == None ) ) : NEW_LINE INDENT return False NEW_LINE DEDENT
v1 = [ ] NEW_LINE v2 = [ ] NEW_LINE v = v1 NEW_LINE storeInorder ( root1 ) NEW_LINE v1 = v NEW_LINE v = v2 NEW_LINE storeInorder ( root2 ) NEW_LINE v2 = v NEW_LINE
return ( v1 == v2 ) NEW_LINE
root1 = Node_ ( 15 ) NEW_LINE root1 . left = Node_ ( 10 ) NEW_LINE root1 . right = Node_ ( 20 ) NEW_LINE root1 . left . left = Node_ ( 5 ) NEW_LINE root1 . left . right = Node_ ( 12 ) NEW_LINE root1 . right . right = Node_ ( 25 ) NEW_LINE
root2 = Node_ ( 15 ) NEW_LINE root2 . left = Node_ ( 12 ) NEW_LINE root2 . right = Node_ ( 20 ) NEW_LINE root2 . left . left = Node_ ( 5 ) NEW_LINE root2 . left . left . right = Node_ ( 10 ) NEW_LINE root2 . right . right = Node_ ( 25 ) NEW_LINE
if ( checkBSTs ( root1 , root2 ) ) : NEW_LINE INDENT print ( " YES " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " NO " ) NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . key = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def insert ( node , key ) : NEW_LINE
if node == None : NEW_LINE INDENT return newNode ( key ) NEW_LINE DEDENT
if key < node . key : NEW_LINE INDENT node . left = insert ( node . left , key ) NEW_LINE DEDENT elif key > node . key : NEW_LINE INDENT node . right = insert ( node . right , key ) NEW_LINE DEDENT
return node NEW_LINE
def findMaxforN ( root , N ) : NEW_LINE
if root == None : NEW_LINE INDENT return - 1 NEW_LINE DEDENT if root . key == N : NEW_LINE INDENT return N NEW_LINE DEDENT
elif root . key < N : NEW_LINE INDENT k = findMaxforN ( root . right , N ) NEW_LINE if k == - 1 : NEW_LINE INDENT return root . key NEW_LINE DEDENT else : NEW_LINE INDENT return k NEW_LINE DEDENT DEDENT
elif root . key > N : NEW_LINE INDENT return findMaxforN ( root . left , N ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT N = 4 NEW_LINE DEDENT
root = None NEW_LINE root = insert ( root , 25 ) NEW_LINE insert ( root , 2 ) NEW_LINE insert ( root , 1 ) NEW_LINE insert ( root , 3 ) NEW_LINE insert ( root , 12 ) NEW_LINE insert ( root , 9 ) NEW_LINE insert ( root , 21 ) NEW_LINE insert ( root , 19 ) NEW_LINE insert ( root , 25 ) NEW_LINE print ( findMaxforN ( root , N ) ) NEW_LINE
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . key = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def insert ( root , key ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT root = newNode ( key ) NEW_LINE DEDENT elif root . key > key : NEW_LINE INDENT root . left = insert ( root . left , key ) NEW_LINE DEDENT elif root . key < key : NEW_LINE INDENT root . right = insert ( root . right , key ) NEW_LINE DEDENT return root NEW_LINE DEDENT
def distanceFromRoot ( root , x ) : NEW_LINE INDENT if root . key == x : NEW_LINE INDENT return 0 NEW_LINE DEDENT elif root . key > x : NEW_LINE INDENT return 1 + distanceFromRoot ( root . left , x ) NEW_LINE DEDENT return 1 + distanceFromRoot ( root . right , x ) NEW_LINE DEDENT
def distanceBetween2 ( root , a , b ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT return 0 NEW_LINE DEDENT DEDENT
if root . key > a and root . key > b : NEW_LINE INDENT return distanceBetween2 ( root . left , a , b ) NEW_LINE DEDENT
if root . key < a and root . key < b : NEW_LINE INDENT return distanceBetween2 ( root . right , a , b ) NEW_LINE DEDENT
if root . key >= a and root . key <= b : NEW_LINE INDENT return ( distanceFromRoot ( root , a ) + distanceFromRoot ( root , b ) ) NEW_LINE DEDENT
def findDistWrapper ( root , a , b ) : NEW_LINE INDENT if a > b : NEW_LINE INDENT a , b = b , a NEW_LINE DEDENT return distanceBetween2 ( root , a , b ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = None NEW_LINE root = insert ( root , 20 ) NEW_LINE insert ( root , 10 ) NEW_LINE insert ( root , 5 ) NEW_LINE insert ( root , 15 ) NEW_LINE insert ( root , 30 ) NEW_LINE insert ( root , 25 ) NEW_LINE insert ( root , 35 ) NEW_LINE a , b = 5 , 55 NEW_LINE print ( findDistWrapper ( root , 5 , 35 ) ) NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def RangeTraversal ( root , n1 , n2 ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT return NEW_LINE DEDENT curr = root NEW_LINE while curr : NEW_LINE INDENT if curr . left == None : NEW_LINE DEDENT DEDENT
if curr . data <= n2 and curr . data >= n1 : NEW_LINE INDENT print ( curr . data , end = " ▁ " ) NEW_LINE DEDENT curr = curr . right NEW_LINE else : NEW_LINE pre = curr . left NEW_LINE
while ( pre . right != None and pre . right != curr ) : NEW_LINE INDENT pre = pre . right NEW_LINE DEDENT if pre . right == None : NEW_LINE INDENT pre . right = curr ; NEW_LINE curr = curr . left NEW_LINE DEDENT else : NEW_LINE INDENT pre . right = None NEW_LINE DEDENT
if curr . data <= n2 and curr . data >= n1 : NEW_LINE INDENT print ( curr . data , end = " ▁ " ) NEW_LINE DEDENT curr = curr . right NEW_LINE
root = newNode ( 4 ) NEW_LINE root . left = newNode ( 2 ) NEW_LINE root . right = newNode ( 7 ) NEW_LINE root . left . left = newNode ( 1 ) NEW_LINE root . left . right = newNode ( 3 ) NEW_LINE root . right . left = newNode ( 6 ) NEW_LINE root . right . right = newNode ( 10 ) NEW_LINE RangeTraversal ( root , 4 , 12 ) NEW_LINE
def inRange ( root , low , high ) : NEW_LINE INDENT return root . data >= low and root . data <= high NEW_LINE DEDENT
def getCountUtil ( root , low , high , count ) : NEW_LINE
if root == None : NEW_LINE INDENT return True NEW_LINE DEDENT
l = getCountUtil ( root . left , low , high , count ) NEW_LINE r = getCountUtil ( root . right , low , high , count ) NEW_LINE
if l and r and inRange ( root , low , high ) : NEW_LINE INDENT count [ 0 ] += 1 NEW_LINE return True NEW_LINE DEDENT return False NEW_LINE
def getCount ( root , low , high ) : NEW_LINE INDENT count = [ 0 ] NEW_LINE getCountUtil ( root , low , high , count ) NEW_LINE return count NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
root = newNode ( 10 ) NEW_LINE root . left = newNode ( 5 ) NEW_LINE root . right = newNode ( 50 ) NEW_LINE root . left . left = newNode ( 1 ) NEW_LINE root . right . left = newNode ( 40 ) NEW_LINE root . right . right = newNode ( 100 ) NEW_LINE
l = 5 NEW_LINE h = 45 NEW_LINE print ( " Count ▁ of ▁ subtrees ▁ in ▁ [ " , l , " , ▁ " , h , " ] ▁ is ▁ " , getCount ( root , l , h ) ) NEW_LINE
class newNode : NEW_LINE
def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT
def insert ( root , data ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT return newNode ( data ) NEW_LINE DEDENT if data < root . data : NEW_LINE INDENT root . left = insert ( root . left , data ) NEW_LINE DEDENT elif data > root . data : NEW_LINE INDENT root . right = insert ( root . right , data ) NEW_LINE DEDENT return root NEW_LINE DEDENT
def inorder ( root ) : NEW_LINE INDENT if root != None : NEW_LINE INDENT inorder ( root . left ) NEW_LINE print ( root . data , end = " ▁ " ) NEW_LINE inorder ( root . right ) NEW_LINE DEDENT DEDENT
def leafDelete ( root ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT return None NEW_LINE DEDENT if root . left == None and root . right == None : NEW_LINE INDENT return None NEW_LINE DEDENT DEDENT
root . left = leafDelete ( root . left ) NEW_LINE root . right = leafDelete ( root . right ) NEW_LINE return root NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = None NEW_LINE root = insert ( root , 20 ) NEW_LINE insert ( root , 10 ) NEW_LINE insert ( root , 5 ) NEW_LINE insert ( root , 15 ) NEW_LINE insert ( root , 30 ) NEW_LINE insert ( root , 25 ) NEW_LINE insert ( root , 35 ) NEW_LINE print ( " Inorder ▁ before ▁ Deleting ▁ the ▁ leaf ▁ Node . " ) NEW_LINE inorder ( root ) NEW_LINE leafDelete ( root ) NEW_LINE print ( ) NEW_LINE print ( " INorder ▁ after ▁ Deleting ▁ the ▁ leaf ▁ Node . " ) NEW_LINE inorder ( root ) NEW_LINE DEDENT
class createNode : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . data = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def insert ( root , key ) : NEW_LINE
if ( root == None ) : NEW_LINE INDENT return createNode ( key ) NEW_LINE DEDENT
if ( root . data > key ) : NEW_LINE INDENT root . left = insert ( root . left , key ) NEW_LINE DEDENT elif ( root . data < key ) : NEW_LINE INDENT root . right = insert ( root . right , key ) NEW_LINE DEDENT
return root NEW_LINE
def ksmallestElementSumRec ( root , k , count ) : NEW_LINE
if ( root == None ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT if ( count [ 0 ] > k [ 0 ] ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
res = ksmallestElementSumRec ( root . left , k , count ) NEW_LINE if ( count [ 0 ] >= k [ 0 ] ) : NEW_LINE INDENT return res NEW_LINE DEDENT
res += root . data NEW_LINE
count [ 0 ] += 1 NEW_LINE if ( count [ 0 ] >= k [ 0 ] ) : NEW_LINE INDENT return res NEW_LINE DEDENT
return res + ksmallestElementSumRec ( root . right , k , count ) NEW_LINE
def ksmallestElementSum ( root , k ) : NEW_LINE INDENT count = [ 0 ] NEW_LINE return ksmallestElementSumRec ( root , k , count ) NEW_LINE DEDENT
root = None NEW_LINE root = insert ( root , 20 ) NEW_LINE root = insert ( root , 8 ) NEW_LINE root = insert ( root , 4 ) NEW_LINE root = insert ( root , 12 ) NEW_LINE root = insert ( root , 10 ) NEW_LINE root = insert ( root , 14 ) NEW_LINE root = insert ( root , 22 ) NEW_LINE k = [ 3 ] NEW_LINE print ( ksmallestElementSum ( root , k ) ) NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . data = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def insert ( node , data ) : NEW_LINE
if node is None : NEW_LINE INDENT return Node ( data ) NEW_LINE DEDENT else : NEW_LINE
if data <= node . data : NEW_LINE INDENT temp = insert ( node . left , data ) NEW_LINE node . left = temp NEW_LINE temp . parent = node NEW_LINE DEDENT else : NEW_LINE INDENT temp = insert ( node . right , data ) NEW_LINE node . right = temp NEW_LINE temp . parent = node NEW_LINE DEDENT
return node NEW_LINE def inOrderSuccessor ( n ) : NEW_LINE
if n . right is not None : NEW_LINE INDENT return minValue ( n . right ) NEW_LINE DEDENT
p = n . parent NEW_LINE while ( p is not None ) : NEW_LINE INDENT if n != p . right : NEW_LINE INDENT break NEW_LINE DEDENT n = p NEW_LINE p = p . parent NEW_LINE DEDENT return p NEW_LINE
def minValue ( node ) : NEW_LINE INDENT current = node NEW_LINE DEDENT
while ( current is not None ) : NEW_LINE INDENT if current . left is None : NEW_LINE INDENT break NEW_LINE DEDENT current = current . left NEW_LINE DEDENT return current NEW_LINE
root = None NEW_LINE root = insert ( root , 20 ) NEW_LINE root = insert ( root , 8 ) ; NEW_LINE root = insert ( root , 22 ) ; NEW_LINE root = insert ( root , 4 ) ; NEW_LINE root = insert ( root , 12 ) ; NEW_LINE root = insert ( root , 10 ) ; NEW_LINE root = insert ( root , 14 ) ; NEW_LINE temp = root . left . right . right NEW_LINE succ = inOrderSuccessor ( root , temp ) NEW_LINE if succ is not None : NEW_LINE INDENT print   " NEW_LINE DEDENT Inorder Successor of % d is % d " \
			%(temp.data, succ.data)
 else : NEW_LINE INDENT print   " NEW_LINE DEDENT Inorder Successor doesn ' t exist " NEW_LINE
def findPreSuc ( root , pre , suc , key ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
while root != None : NEW_LINE
if root . key == key : NEW_LINE
if root . right : NEW_LINE INDENT suc [ 0 ] = root . right NEW_LINE while suc [ 0 ] . left : NEW_LINE INDENT suc [ 0 ] = suc [ 0 ] . left NEW_LINE DEDENT DEDENT
if root . left : NEW_LINE INDENT pre [ 0 ] = root . left NEW_LINE while pre [ 0 ] . right : NEW_LINE INDENT pre [ 0 ] = pre [ 0 ] . right NEW_LINE DEDENT DEDENT return NEW_LINE
elif root . key < key : NEW_LINE INDENT pre [ 0 ] = root NEW_LINE root = root . right NEW_LINE DEDENT
else : NEW_LINE INDENT suc [ 0 ] = root NEW_LINE root = root . left NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . key = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def insert ( node , key ) : NEW_LINE INDENT if node == None : NEW_LINE INDENT return newNode ( key ) NEW_LINE DEDENT if key < node . key : NEW_LINE INDENT node . left = insert ( node . left , key ) NEW_LINE DEDENT else : NEW_LINE INDENT node . right = insert ( node . right , key ) NEW_LINE DEDENT return node NEW_LINE DEDENT
key = 65 NEW_LINE
root = None NEW_LINE root = insert ( root , 50 ) NEW_LINE insert ( root , 30 ) NEW_LINE insert ( root , 20 ) NEW_LINE insert ( root , 40 ) NEW_LINE insert ( root , 70 ) NEW_LINE insert ( root , 60 ) NEW_LINE insert ( root , 80 ) NEW_LINE pre , suc = [ None ] , [ None ] NEW_LINE findPreSuc ( root , pre , suc , key ) NEW_LINE if pre [ 0 ] != None : NEW_LINE INDENT print ( " Predecessor ▁ is " , pre [ 0 ] . key ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " - 1" ) NEW_LINE DEDENT if suc [ 0 ] != None : NEW_LINE INDENT print ( " Successor ▁ is " , suc [ 0 ] . key ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " - 1" ) NEW_LINE DEDENT
class createNode : NEW_LINE
def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT
def insertNode ( root , x ) : NEW_LINE INDENT p , q = root , None NEW_LINE while p != None : NEW_LINE INDENT q = p NEW_LINE if p . data < x : NEW_LINE INDENT p = p . right NEW_LINE DEDENT else : NEW_LINE INDENT p = p . left NEW_LINE DEDENT DEDENT if q == None : NEW_LINE INDENT p = createNode ( x ) NEW_LINE DEDENT else : NEW_LINE INDENT if q . data < x : NEW_LINE INDENT q . right = createNode ( x ) NEW_LINE DEDENT else : NEW_LINE INDENT q . left = createNode ( x ) NEW_LINE DEDENT DEDENT DEDENT
def maxelpath ( q , x ) : NEW_LINE INDENT p = q NEW_LINE mx = - 999999999999 NEW_LINE DEDENT
while p . data != x : NEW_LINE INDENT if p . data > x : NEW_LINE INDENT mx = max ( mx , p . data ) NEW_LINE p = p . left NEW_LINE DEDENT else : NEW_LINE INDENT mx = max ( mx , p . data ) NEW_LINE p = p . right NEW_LINE DEDENT DEDENT return max ( mx , x ) NEW_LINE
def maximumElement ( root , x , y ) : NEW_LINE INDENT p = root NEW_LINE DEDENT
while ( ( x < p . data and y < p . data ) or ( x > p . data and y > p . data ) ) : NEW_LINE
if x < p . data and y < p . data : NEW_LINE INDENT p = p . left NEW_LINE DEDENT
elif x > p . data and y > p . data : NEW_LINE INDENT p = p . right NEW_LINE DEDENT
return max ( maxelpath ( p , x ) , maxelpath ( p , y ) ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 18 , 36 , 9 , 6 , 12 , 10 , 1 , 8 ] NEW_LINE a , b = 1 , 10 NEW_LINE n = len ( arr ) NEW_LINE DEDENT
root = createNode ( arr [ 0 ] ) NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT insertNode ( root , arr [ i ] ) NEW_LINE DEDENT print ( maximumElement ( root , a , b ) ) NEW_LINE
class newNode : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE DEDENT
self . info = key NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE self . lthread = True NEW_LINE
self . rthread = True NEW_LINE
def insert ( root , ikey ) : NEW_LINE
ptr = root NEW_LINE
par = None NEW_LINE while ptr != None : NEW_LINE
if ikey == ( ptr . info ) : NEW_LINE INDENT print ( " Duplicate ▁ Key ▁ ! " ) NEW_LINE return root NEW_LINE DEDENT
par = ptr NEW_LINE
if ikey < ptr . info : NEW_LINE INDENT if ptr . lthread == False : NEW_LINE INDENT ptr = ptr . left NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT if ptr . rthread == False : NEW_LINE INDENT ptr = ptr . right NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
tmp = newNode ( ikey ) NEW_LINE if par == None : NEW_LINE INDENT root = tmp NEW_LINE tmp . left = None NEW_LINE tmp . right = None NEW_LINE DEDENT elif ikey < ( par . info ) : NEW_LINE INDENT tmp . left = par . left NEW_LINE tmp . right = par NEW_LINE par . lthread = False NEW_LINE par . left = tmp NEW_LINE DEDENT else : NEW_LINE INDENT tmp . left = par NEW_LINE tmp . right = par . right NEW_LINE par . rthread = False NEW_LINE par . right = tmp NEW_LINE DEDENT return root NEW_LINE
def inorderSuccessor ( ptr ) : NEW_LINE
if ptr . rthread == True : NEW_LINE INDENT return ptr . right NEW_LINE DEDENT
ptr = ptr . right NEW_LINE while ptr . lthread == False : NEW_LINE INDENT ptr = ptr . left NEW_LINE DEDENT return ptr NEW_LINE
def inorder ( root ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT print ( " Tree ▁ is ▁ empty " ) NEW_LINE DEDENT DEDENT
ptr = root NEW_LINE while ptr . lthread == False : NEW_LINE INDENT ptr = ptr . left NEW_LINE DEDENT
while ptr != None : NEW_LINE INDENT print ( ptr . info , end = " ▁ " ) NEW_LINE ptr = inorderSuccessor ( ptr ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = None NEW_LINE root = insert ( root , 20 ) NEW_LINE root = insert ( root , 10 ) NEW_LINE root = insert ( root , 30 ) NEW_LINE root = insert ( root , 5 ) NEW_LINE root = insert ( root , 16 ) NEW_LINE root = insert ( root , 14 ) NEW_LINE root = insert ( root , 17 ) NEW_LINE root = insert ( root , 13 ) NEW_LINE inorder ( root ) NEW_LINE DEDENT
def createThreaded ( root ) : NEW_LINE
if root == None : NEW_LINE INDENT return None NEW_LINE DEDENT if root . left == None and root . right == None : NEW_LINE INDENT return root NEW_LINE DEDENT
if root . left != None : NEW_LINE
l = createThreaded ( root . left ) NEW_LINE
l . right = root NEW_LINE l . isThreaded = True NEW_LINE
if root . right == None : NEW_LINE INDENT return root NEW_LINE DEDENT
return createThreaded ( root . right ) NEW_LINE
def leftMost ( root ) : NEW_LINE INDENT while root != None and root . left != None : NEW_LINE INDENT root = root . left NEW_LINE DEDENT return root NEW_LINE DEDENT
def inOrder ( root ) : NEW_LINE INDENT if root == None : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
cur = leftMost ( root ) NEW_LINE while cur != None : NEW_LINE INDENT print ( cur . key , end = " ▁ " ) NEW_LINE DEDENT
if cur . isThreaded : NEW_LINE INDENT cur = cur . right NEW_LINE DEDENT
else : NEW_LINE INDENT cur = leftMost ( cur . right ) NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . left = self . right = None NEW_LINE self . key = key NEW_LINE self . isThreaded = None NEW_LINE DEDENT DEDENT
root = newNode ( 1 ) NEW_LINE root . left = newNode ( 2 ) NEW_LINE root . right = newNode ( 3 ) NEW_LINE root . left . left = newNode ( 4 ) NEW_LINE root . left . right = newNode ( 5 ) NEW_LINE root . right . left = newNode ( 6 ) NEW_LINE root . right . right = newNode ( 7 ) NEW_LINE createThreaded ( root ) NEW_LINE print ( " Inorder ▁ traversal ▁ of ▁ created " , " threaded ▁ tree ▁ is " ) NEW_LINE inOrder ( root ) NEW_LINE
class newNode : NEW_LINE INDENT def __init__ ( self , item ) : NEW_LINE INDENT self . key = item NEW_LINE self . parent = self . left = self . right = None NEW_LINE DEDENT DEDENT
def insert ( node , key ) : NEW_LINE
if node == None : NEW_LINE INDENT return newNode ( key ) NEW_LINE DEDENT
if key < node . key : NEW_LINE INDENT node . left = insert ( node . left , key ) NEW_LINE node . left . parent = node NEW_LINE DEDENT elif key > node . key : NEW_LINE INDENT node . right = insert ( node . right , key ) NEW_LINE node . right . parent = node NEW_LINE DEDENT
return node NEW_LINE
def inorder ( root ) : NEW_LINE INDENT leftdone = False NEW_LINE DEDENT
while root : NEW_LINE
if leftdone == False : NEW_LINE INDENT while root . left : NEW_LINE INDENT root = root . left NEW_LINE DEDENT DEDENT
print ( root . key , end = " ▁ " ) NEW_LINE
leftdone = True NEW_LINE
if root . right : NEW_LINE INDENT leftdone = False NEW_LINE root = root . right NEW_LINE DEDENT
elif root . parent : NEW_LINE
while root . parent and root == root . parent . right : NEW_LINE INDENT root = root . parent NEW_LINE DEDENT if root . parent == None : NEW_LINE INDENT break NEW_LINE DEDENT root = root . parent NEW_LINE else : NEW_LINE break NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = None NEW_LINE root = insert ( root , 24 ) NEW_LINE root = insert ( root , 27 ) NEW_LINE root = insert ( root , 29 ) NEW_LINE root = insert ( root , 34 ) NEW_LINE root = insert ( root , 14 ) NEW_LINE root = insert ( root , 4 ) NEW_LINE root = insert ( root , 10 ) NEW_LINE root = insert ( root , 22 ) NEW_LINE root = insert ( root , 13 ) NEW_LINE root = insert ( root , 3 ) NEW_LINE root = insert ( root , 2 ) NEW_LINE root = insert ( root , 6 ) NEW_LINE print ( " Inorder ▁ traversal ▁ is ▁ " ) NEW_LINE inorder ( root ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . key = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def ceil ( root , inp ) : NEW_LINE
if root == None : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
if root . key == inp : NEW_LINE INDENT return root . key NEW_LINE DEDENT
if root . key < inp : NEW_LINE INDENT return ceil ( root . right , inp ) NEW_LINE DEDENT
val = ceil ( root . left , inp ) NEW_LINE return val if val >= inp else root . key NEW_LINE
root = Node ( 8 ) NEW_LINE root . left = Node ( 4 ) NEW_LINE root . right = Node ( 12 ) NEW_LINE root . left . left = Node ( 2 ) NEW_LINE root . left . right = Node ( 6 ) NEW_LINE root . right . left = Node ( 10 ) NEW_LINE root . right . right = Node ( 14 ) NEW_LINE for i in range ( 16 ) : NEW_LINE INDENT print " % ▁ d ▁ % ▁ d " % ( i , ceil ( root , i ) ) NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . key = data NEW_LINE self . count = 1 NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def inorder ( root ) : NEW_LINE INDENT if root != None : NEW_LINE INDENT inorder ( root . left ) NEW_LINE print ( root . key , " ( " , root . count , " ) " , end = " ▁ " ) NEW_LINE inorder ( root . right ) NEW_LINE DEDENT DEDENT
def insert ( node , key ) : NEW_LINE
if node == None : NEW_LINE INDENT k = newNode ( key ) NEW_LINE return k NEW_LINE DEDENT
if key == node . key : NEW_LINE INDENT ( node . count ) += 1 NEW_LINE return node NEW_LINE DEDENT
if key < node . key : NEW_LINE INDENT node . left = insert ( node . left , key ) NEW_LINE DEDENT else : NEW_LINE INDENT node . right = insert ( node . right , key ) NEW_LINE DEDENT
return node NEW_LINE
def minValueNode ( node ) : NEW_LINE INDENT current = node NEW_LINE DEDENT
while current . left != None : NEW_LINE INDENT current = current . left NEW_LINE DEDENT return current NEW_LINE
def deleteNode ( root , key ) : NEW_LINE
if root == None : NEW_LINE INDENT return root NEW_LINE DEDENT
if key < root . key : NEW_LINE INDENT root . left = deleteNode ( root . left , key ) NEW_LINE DEDENT
elif key > root . key : NEW_LINE INDENT root . right = deleteNode ( root . right , key ) NEW_LINE DEDENT
else : NEW_LINE
if root . count > 1 : NEW_LINE INDENT root . count -= 1 NEW_LINE return root NEW_LINE DEDENT
if root . left == None : NEW_LINE INDENT temp = root . right NEW_LINE return temp NEW_LINE DEDENT elif root . right == None : NEW_LINE INDENT temp = root . left NEW_LINE return temp NEW_LINE DEDENT
temp = minValueNode ( root . right ) NEW_LINE
root . key = temp . key NEW_LINE
root . right = deleteNode ( root . right , temp . key ) NEW_LINE return root NEW_LINE
root = None NEW_LINE root = insert ( root , 12 ) NEW_LINE root = insert ( root , 10 ) NEW_LINE root = insert ( root , 20 ) NEW_LINE root = insert ( root , 9 ) NEW_LINE root = insert ( root , 11 ) NEW_LINE root = insert ( root , 10 ) NEW_LINE root = insert ( root , 12 ) NEW_LINE root = insert ( root , 12 ) NEW_LINE print ( " Inorder ▁ traversal ▁ of ▁ the ▁ given ▁ tree " ) NEW_LINE inorder ( root ) NEW_LINE print ( ) NEW_LINE print ( " Delete ▁ 20" ) NEW_LINE root = deleteNode ( root , 20 ) NEW_LINE print ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree " ) NEW_LINE inorder ( root ) NEW_LINE print ( ) NEW_LINE print ( " Delete ▁ 12" ) NEW_LINE root = deleteNode ( root , 12 ) NEW_LINE print ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree " ) NEW_LINE inorder ( root ) NEW_LINE print ( ) NEW_LINE print ( " Delete ▁ 9" ) NEW_LINE root = deleteNode ( root , 9 ) NEW_LINE print ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree " ) NEW_LINE inorder ( root ) NEW_LINE
class newNode : NEW_LINE INDENT def __init__ ( self , key ) : NEW_LINE INDENT self . key = key NEW_LINE self . left = self . right = None NEW_LINE DEDENT DEDENT
def inorder ( root ) : NEW_LINE INDENT if root != None : NEW_LINE INDENT inorder ( root . left ) NEW_LINE print ( root . key , end = " ▁ " ) NEW_LINE inorder ( root . right ) NEW_LINE DEDENT DEDENT
def insert ( node , key ) : NEW_LINE
if node == None : NEW_LINE INDENT return newNode ( key ) NEW_LINE DEDENT
if key < node . key : NEW_LINE INDENT node . left = insert ( node . left , key ) NEW_LINE DEDENT else : NEW_LINE INDENT node . right = insert ( node . right , key ) NEW_LINE DEDENT
return node NEW_LINE
def minValueNode ( node ) : NEW_LINE INDENT current = node NEW_LINE DEDENT
while current . left != None : NEW_LINE INDENT current = current . left NEW_LINE DEDENT return current NEW_LINE
def deleteNode ( root , key ) : NEW_LINE
if root == None : NEW_LINE INDENT return root NEW_LINE DEDENT
if key < root . key : NEW_LINE INDENT root . left = deleteNode ( root . left , key ) NEW_LINE DEDENT
elif key > root . key : NEW_LINE INDENT root . right = deleteNode ( root . right , key ) NEW_LINE DEDENT
else : NEW_LINE
if root . left == None : NEW_LINE INDENT temp = root . right NEW_LINE return temp NEW_LINE DEDENT elif root . right == None : NEW_LINE INDENT temp = root . left NEW_LINE return temp NEW_LINE DEDENT
temp = minValueNode ( root . right ) NEW_LINE
root . key = temp . key NEW_LINE
root . right = deleteNode ( root . right , temp . key ) NEW_LINE return root NEW_LINE
def changeKey ( root , oldVal , newVal ) : NEW_LINE
root = deleteNode ( root , oldVal ) NEW_LINE
root = insert ( root , newVal ) NEW_LINE
return root NEW_LINE
root = None NEW_LINE root = insert ( root , 50 ) NEW_LINE root = insert ( root , 30 ) NEW_LINE root = insert ( root , 20 ) NEW_LINE root = insert ( root , 40 ) NEW_LINE root = insert ( root , 70 ) NEW_LINE root = insert ( root , 60 ) NEW_LINE root = insert ( root , 80 ) NEW_LINE print ( " Inorder ▁ traversal ▁ of ▁ the ▁ given ▁ tree " ) NEW_LINE inorder ( root ) NEW_LINE root = changeKey ( root , 40 , 10 ) NEW_LINE print ( ) NEW_LINE
print ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree " ) NEW_LINE inorder ( root ) NEW_LINE
def isLeaf ( pre , i , n , Min , Max ) : NEW_LINE INDENT if i [ 0 ] >= n : NEW_LINE INDENT return False NEW_LINE DEDENT if pre [ i [ 0 ] ] > Min and pre [ i [ 0 ] ] < Max : NEW_LINE INDENT i [ 0 ] += 1 NEW_LINE left = isLeaf ( pre , i , n , Min , pre [ i [ 0 ] - 1 ] ) NEW_LINE right = isLeaf ( pre , i , n , pre [ i [ 0 ] - 1 ] , Max ) NEW_LINE if left == False and right == False : NEW_LINE INDENT print ( pre [ i [ 0 ] - 1 ] , end = " ▁ " ) NEW_LINE DEDENT return True NEW_LINE DEDENT return False NEW_LINE DEDENT def printLeaves ( preorder , n ) : NEW_LINE INDENT i = [ 0 ] NEW_LINE INT_MIN , INT_MAX = - 999999999999 , 999999999999 NEW_LINE isLeaf ( preorder , i , n , INT_MIN , INT_MAX ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT preorder = [ 890 , 325 , 290 , 530 , 965 ] NEW_LINE n = len ( preorder ) NEW_LINE printLeaves ( preorder , n ) NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , item ) : NEW_LINE INDENT self . key = item NEW_LINE self . left = self . right = None NEW_LINE self . parent = None NEW_LINE DEDENT DEDENT
def inorder ( root ) : NEW_LINE INDENT if root != None : NEW_LINE INDENT inorder ( root . left ) NEW_LINE print ( " Node ▁ : " , root . key , " , ▁ " , end = " " ) NEW_LINE if root . parent == None : NEW_LINE INDENT print ( " Parent ▁ : ▁ NULL " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Parent ▁ : ▁ " , root . parent . key ) NEW_LINE DEDENT inorder ( root . right ) NEW_LINE DEDENT DEDENT
def insert ( node , key ) : NEW_LINE
if node == None : NEW_LINE INDENT return newNode ( key ) NEW_LINE DEDENT
if key < node . key : NEW_LINE INDENT lchild = insert ( node . left , key ) NEW_LINE node . left = lchild NEW_LINE DEDENT
lchild . parent = node NEW_LINE elif key > node . key : NEW_LINE rchild = insert ( node . right , key ) NEW_LINE node . right = rchild NEW_LINE
rchild . parent = node NEW_LINE
return node NEW_LINE
root = None NEW_LINE root = insert ( root , 50 ) NEW_LINE insert ( root , 30 ) NEW_LINE insert ( root , 20 ) NEW_LINE insert ( root , 40 ) NEW_LINE insert ( root , 70 ) NEW_LINE insert ( root , 60 ) NEW_LINE insert ( root , 80 ) NEW_LINE
inorder ( root ) NEW_LINE
def pairs ( arr , n , k ) : NEW_LINE
smallest = 999999999999 NEW_LINE count = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT
if abs ( arr [ i ] + arr [ j ] - k ) < smallest : NEW_LINE INDENT smallest = abs ( arr [ i ] + arr [ j ] - k ) NEW_LINE count = 1 NEW_LINE DEDENT
elif abs ( arr [ i ] + arr [ j ] - k ) == smallest : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
print ( " Minimal ▁ Value ▁ = ▁ " , smallest ) NEW_LINE print ( " Total ▁ Pairs ▁ = ▁ " , count ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 3 , 5 , 7 , 5 , 1 , 9 , 9 ] NEW_LINE k = 12 NEW_LINE n = len ( arr ) NEW_LINE pairs ( arr , n , k ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 ] NEW_LINE key = 20 NEW_LINE arraySize = len ( a ) NEW_LINE count = 0 NEW_LINE for i in range ( arraySize ) : NEW_LINE INDENT if a [ i ] <= key : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT print ( " Rank ▁ of " , key , " in ▁ stream ▁ is : " , count - 1 ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def insert ( node , data ) : NEW_LINE INDENT global succ NEW_LINE DEDENT
root = node NEW_LINE if ( node == None ) : NEW_LINE INDENT return Node ( data ) NEW_LINE DEDENT
if ( data < node . data ) : NEW_LINE INDENT root . left = insert ( node . left , data ) NEW_LINE DEDENT elif ( data > node . data ) : NEW_LINE INDENT root . right = insert ( node . right , data ) NEW_LINE DEDENT
return root NEW_LINE
def check ( num ) : NEW_LINE INDENT sum = 0 NEW_LINE i = num NEW_LINE DEDENT
if ( num < 10 or num > 99 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE INDENT sum_of_digits = ( i % 10 ) + ( i // 10 ) NEW_LINE prod_of_digits = ( i % 10 ) * ( i // 10 ) NEW_LINE sum = sum_of_digits + prod_of_digits NEW_LINE DEDENT if ( sum == num ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT else : NEW_LINE INDENT return 0 NEW_LINE DEDENT
def countSpecialDigit ( rt ) : NEW_LINE INDENT global c NEW_LINE if ( rt == None ) : NEW_LINE INDENT return NEW_LINE DEDENT else : NEW_LINE INDENT x = check ( rt . data ) NEW_LINE if ( x == 1 ) : NEW_LINE INDENT c += 1 NEW_LINE DEDENT countSpecialDigit ( rt . left ) NEW_LINE countSpecialDigit ( rt . right ) NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = None NEW_LINE c = 0 NEW_LINE root = insert ( root , 50 ) NEW_LINE root = insert ( root , 29 ) NEW_LINE root = insert ( root , 59 ) NEW_LINE root = insert ( root , 19 ) NEW_LINE root = insert ( root , 53 ) NEW_LINE root = insert ( root , 556 ) NEW_LINE root = insert ( root , 56 ) NEW_LINE root = insert ( root , 94 ) NEW_LINE root = insert ( root , 13 ) NEW_LINE DEDENT
countSpecialDigit ( root ) NEW_LINE print ( c ) NEW_LINE
MAX_SIZE = 10 NEW_LINE
def sortByRow ( mat , n , ascending ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT if ( ascending ) : NEW_LINE INDENT mat [ i ] . sort ( ) NEW_LINE DEDENT else : NEW_LINE INDENT mat [ i ] . sort ( reverse = True ) NEW_LINE DEDENT DEDENT DEDENT
def transpose ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT DEDENT
temp = mat [ i ] [ j ] NEW_LINE mat [ i ] [ j ] = mat [ j ] [ i ] NEW_LINE mat [ j ] [ i ] = temp NEW_LINE
def sortMatRowAndColWise ( mat , n ) : NEW_LINE
sortByRow ( mat , n , True ) NEW_LINE
transpose ( mat , n ) NEW_LINE
sortByRow ( mat , n , False ) NEW_LINE
transpose ( mat , n ) NEW_LINE
def printMat ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , " ▁ " , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
n = 3 NEW_LINE mat = [ [ 3 , 2 , 1 ] , [ 9 , 8 , 7 ] , [ 6 , 5 , 4 ] ] NEW_LINE print ( " Original ▁ Matrix : " ) NEW_LINE printMat ( mat , n ) NEW_LINE sortMatRowAndColWise ( mat , n ) NEW_LINE print ( " Matrix ▁ After ▁ Sorting : " ) NEW_LINE printMat ( mat , n ) NEW_LINE
def middlesum ( mat , n ) : NEW_LINE INDENT row_sum = 0 NEW_LINE col_sum = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT row_sum += mat [ n // 2 ] [ i ] NEW_LINE DEDENT print ( " Sum ▁ of ▁ middle ▁ row ▁ = ▁ " , row_sum ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT col_sum += mat [ i ] [ n // 2 ] NEW_LINE DEDENT print ( " Sum ▁ of ▁ middle ▁ column ▁ = ▁ " , col_sum ) NEW_LINE
mat = [ [ 2 , 5 , 7 ] , [ 3 , 7 , 2 ] , [ 5 , 6 , 9 ] ] NEW_LINE middlesum ( mat , 3 ) NEW_LINE
M = 3 NEW_LINE N = 3 NEW_LINE matrix = [ [ 12 , 23 , 34 ] , [ 45 , 56 , 67 ] , [ 78 , 89 , 91 ] ] NEW_LINE
def rotateMatrix ( k ) : NEW_LINE INDENT global M , N , matrix NEW_LINE DEDENT
temp = [ 0 ] * M NEW_LINE
k = k % M NEW_LINE for i in range ( 0 , N ) : NEW_LINE
for t in range ( 0 , M - k ) : NEW_LINE INDENT temp [ t ] = matrix [ i ] [ t ] NEW_LINE DEDENT
for j in range ( M - k , M ) : NEW_LINE INDENT matrix [ i ] [ j - M + k ] = matrix [ i ] [ j ] NEW_LINE DEDENT
for j in range ( k , M ) : NEW_LINE INDENT matrix [ i ] [ j ] = temp [ j - k ] NEW_LINE DEDENT
def displayMatrix ( ) : NEW_LINE INDENT global M , N , matrix NEW_LINE for i in range ( 0 , N ) : NEW_LINE INDENT for j in range ( 0 , M ) : NEW_LINE INDENT print ( " { } ▁ " . format ( matrix [ i ] [ j ] ) , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
k = 2 NEW_LINE
rotateMatrix ( k ) NEW_LINE
displayMatrix ( ) NEW_LINE
def interchangeFirstLast ( mat , n , m ) : NEW_LINE INDENT rows = n NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT t = mat [ 0 ] [ i ] NEW_LINE mat [ 0 ] [ i ] = mat [ rows - 1 ] [ i ] NEW_LINE mat [ rows - 1 ] [ i ] = t NEW_LINE DEDENT
mat = [ [ 8 , 9 , 7 , 6 ] , [ 4 , 7 , 6 , 5 ] , [ 3 , 2 , 1 , 8 ] , [ 9 , 9 , 7 , 7 ] ] NEW_LINE n = 4 NEW_LINE m = 4 NEW_LINE interchangeFirstLast ( mat , n , m ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( " " ) NEW_LINE DEDENT
def buildUtil ( In , post , inStrt , inEnd , pIndex ) : NEW_LINE
if ( inStrt > inEnd ) : NEW_LINE INDENT return None NEW_LINE DEDENT
node = newNode ( post [ pIndex [ 0 ] ] ) NEW_LINE pIndex [ 0 ] -= 1 NEW_LINE
if ( inStrt == inEnd ) : NEW_LINE INDENT return node NEW_LINE DEDENT
iIndex = search ( In , inStrt , inEnd , node . data ) NEW_LINE
node . right = buildUtil ( In , post , iIndex + 1 , inEnd , pIndex ) NEW_LINE node . left = buildUtil ( In , post , inStrt , iIndex - 1 , pIndex ) NEW_LINE return node NEW_LINE
def search ( arr , strt , end , value ) : NEW_LINE INDENT i = 0 NEW_LINE for i in range ( strt , end + 1 ) : NEW_LINE INDENT if ( arr [ i ] == value ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT return i NEW_LINE DEDENT
def preOrder ( node ) : NEW_LINE INDENT if node == None : NEW_LINE INDENT return NEW_LINE DEDENT print ( node . data , end = " ▁ " ) NEW_LINE preOrder ( node . left ) NEW_LINE preOrder ( node . right ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT In = [ 4 , 8 , 2 , 5 , 1 , 6 , 3 , 7 ] NEW_LINE post = [ 8 , 4 , 5 , 2 , 6 , 7 , 3 , 1 ] NEW_LINE n = len ( In ) NEW_LINE root = buildTree ( In , post , n ) NEW_LINE print ( " Preorder ▁ of ▁ the ▁ constructed ▁ tree ▁ : " ) NEW_LINE preOrder ( root ) NEW_LINE DEDENT
def sortRowWise ( m ) : NEW_LINE
for i in range ( len ( m ) ) : NEW_LINE
for j in range ( len ( m [ i ] ) ) : NEW_LINE
for k in range ( len ( m [ i ] ) - j - 1 ) : NEW_LINE INDENT if ( m [ i ] [ k ] > m [ i ] [ k + 1 ] ) : NEW_LINE DEDENT
t = m [ i ] [ k ] NEW_LINE m [ i ] [ k ] = m [ i ] [ k + 1 ] NEW_LINE m [ i ] [ k + 1 ] = t NEW_LINE
for i in range ( len ( m ) ) : NEW_LINE INDENT for j in range ( len ( m [ i ] ) ) : NEW_LINE INDENT print ( m [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
m = [ [ 9 , 8 , 7 , 1 ] , [ 7 , 3 , 0 , 2 ] , [ 9 , 5 , 3 , 2 ] , [ 6 , 3 , 1 , 2 ] ] NEW_LINE sortRowWise ( m ) NEW_LINE
def checkMarkov ( m ) : NEW_LINE
for i in range ( 0 , len ( m ) ) : NEW_LINE
sm = 0 NEW_LINE for j in range ( 0 , len ( m [ i ] ) ) : NEW_LINE INDENT sm = sm + m [ i ] [ j ] NEW_LINE DEDENT if ( sm != 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
m = [ [ 0 , 0 , 1 ] , [ 0.5 , 0 , 0.5 ] , [ 1 , 0 , 0 ] ] NEW_LINE
if ( checkMarkov ( m ) ) : NEW_LINE INDENT print ( " ▁ yes ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " ▁ no ▁ " ) NEW_LINE DEDENT
N = 4 NEW_LINE
def isDiagonalMatrix ( mat ) : NEW_LINE INDENT for i in range ( 0 , N ) : NEW_LINE INDENT for j in range ( 0 , N ) : NEW_LINE DEDENT DEDENT
if ( ( i != j ) and ( mat [ i ] [ j ] != 0 ) ) : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
mat = [ [ 4 , 0 , 0 , 0 ] , [ 0 , 7 , 0 , 0 ] , [ 0 , 0 , 5 , 0 ] , [ 0 , 0 , 0 , 1 ] ] NEW_LINE if ( isDiagonalMatrix ( mat ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
N = 4 NEW_LINE
def isScalarMatrix ( mat ) : NEW_LINE
for i in range ( 0 , N ) : NEW_LINE INDENT for j in range ( 0 , N ) : NEW_LINE INDENT if ( ( i != j ) and ( mat [ i ] [ j ] != 0 ) ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT
for i in range ( 0 , N - 1 ) : NEW_LINE INDENT if ( mat [ i ] [ i ] != mat [ i + 1 ] [ i + 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
mat = [ [ 2 , 0 , 0 , 0 ] , [ 0 , 2 , 0 , 0 ] , [ 0 , 0 , 2 , 0 ] , [ 0 , 0 , 0 , 2 ] ] NEW_LINE
if ( isScalarMatrix ( mat ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
MAX_SIZE = 10 NEW_LINE
def sortByRow ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE DEDENT
for j in range ( n - 1 ) : NEW_LINE INDENT if mat [ i ] [ j ] > mat [ i ] [ j + 1 ] : NEW_LINE INDENT temp = mat [ i ] [ j ] NEW_LINE mat [ i ] [ j ] = mat [ i ] [ j + 1 ] NEW_LINE mat [ i ] [ j + 1 ] = temp NEW_LINE DEDENT DEDENT
def transpose ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT DEDENT
t = mat [ i ] [ j ] NEW_LINE mat [ i ] [ j ] = mat [ j ] [ i ] NEW_LINE mat [ j ] [ i ] = t NEW_LINE
def sortMatRowAndColWise ( mat , n ) : NEW_LINE
sortByRow ( mat , n ) NEW_LINE
transpose ( mat , n ) NEW_LINE
sortByRow ( mat , n ) NEW_LINE
transpose ( mat , n ) NEW_LINE
def printMat ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( str ( mat [ i ] [ j ] ) , end = " ▁ " ) NEW_LINE DEDENT print ( ) ; NEW_LINE DEDENT DEDENT
mat = [ [ 4 , 1 , 3 ] , [ 9 , 6 , 8 ] , [ 5 , 2 , 7 ] ] NEW_LINE n = 3 NEW_LINE print ( " Original ▁ Matrix : " ) NEW_LINE printMat ( mat , n ) NEW_LINE sortMatRowAndColWise ( mat , n ) NEW_LINE print ( " Matrix After Sorting : " ) NEW_LINE printMat ( mat , n ) NEW_LINE
def DoublyEven ( n ) : NEW_LINE
arr = [ [ ( n * y ) + x + 1 for x in range ( n ) ] for y in range ( n ) ] NEW_LINE
for i in range ( 0 , n / 4 ) : NEW_LINE INDENT for j in range ( 0 , n / 4 ) : NEW_LINE INDENT arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( 0 , n / 4 ) : NEW_LINE INDENT for j in range ( 3 * ( n / 4 ) , n ) : NEW_LINE INDENT arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( 3 * ( n / 4 ) , n ) : NEW_LINE INDENT for j in range ( 0 , n / 4 ) : NEW_LINE INDENT arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( 3 * ( n / 4 ) , n ) : NEW_LINE INDENT for j in range ( 3 * ( n / 4 ) , n ) : NEW_LINE INDENT arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( n / 4 , 3 * ( n / 4 ) ) : NEW_LINE INDENT for j in range ( n / 4 , 3 * ( n / 4 ) ) : NEW_LINE INDENT arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ' % 2d ▁ ' % ( arr [ i ] [ j ] ) , NEW_LINE DEDENT print NEW_LINE DEDENT
n = 8 NEW_LINE
DoublyEven ( n ) NEW_LINE
N = 3 NEW_LINE
def isMagicSquare ( mat ) : NEW_LINE
s = 0 NEW_LINE for i in range ( 0 , N ) : NEW_LINE INDENT s = s + mat [ i ] [ i ] NEW_LINE DEDENT
s2 = 0 NEW_LINE for i in range ( 0 , N ) : NEW_LINE INDENT s2 = s2 + mat [ i ] [ N - i - 1 ] NEW_LINE DEDENT if ( s != s2 ) : NEW_LINE INDENT return False NEW_LINE DEDENT
for i in range ( 0 , N ) : NEW_LINE INDENT rowSum = 0 ; NEW_LINE for j in range ( 0 , N ) : NEW_LINE INDENT rowSum += mat [ i ] [ j ] NEW_LINE DEDENT DEDENT
if ( rowSum != s ) : NEW_LINE INDENT return False NEW_LINE DEDENT
for i in range ( 0 , N ) : NEW_LINE INDENT colSum = 0 NEW_LINE for j in range ( 0 , N ) : NEW_LINE INDENT colSum += mat [ j ] [ i ] NEW_LINE DEDENT DEDENT
if ( s != colSum ) : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
mat = [ [ 2 , 7 , 6 ] , [ 9 , 5 , 1 ] , [ 4 , 3 , 8 ] ] NEW_LINE if ( isMagicSquare ( mat ) ) : NEW_LINE INDENT print ( " Magic ▁ Square " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Not ▁ a ▁ magic ▁ Square " ) NEW_LINE DEDENT
def subCount ( arr , n , k ) : NEW_LINE
mod = [ 0 ] * k ; NEW_LINE
cumSum = 0 ; NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT cumSum = cumSum + arr [ i ] ; NEW_LINE DEDENT
mod [ ( ( cumSum % k ) + k ) % k ] = mod [ ( ( cumSum % k ) + k ) % k ] + 1 ; NEW_LINE
result = 0 ; NEW_LINE
for i in range ( 0 , k ) : NEW_LINE
if ( mod [ i ] > 1 ) : NEW_LINE INDENT result = result + int ( ( mod [ i ] * ( mod [ i ] - 1 ) ) / 2 ) ; NEW_LINE DEDENT
result = result + mod [ 0 ] ; NEW_LINE return result ; NEW_LINE
def countSubmatrix ( mat , n , k ) : NEW_LINE
tot_count = 0 ; NEW_LINE temp = [ 0 ] * n ; NEW_LINE
for left in range ( 0 , n - 1 ) : NEW_LINE
for right in range ( left , n ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT temp [ i ] = ( temp [ i ] + mat [ i ] [ right ] ) ; NEW_LINE DEDENT
tot_count = ( tot_count + subCount ( temp , n , k ) ) ; NEW_LINE
return tot_count ; NEW_LINE
mat = [ [ 5 , - 1 , 6 ] , [ - 2 , 3 , 8 ] , [ 7 , 4 , - 9 ] ] ; NEW_LINE n = 3 ; NEW_LINE k = 4 ; NEW_LINE print ( " Count ▁ = ▁ { } " . format ( countSubmatrix ( mat , n , k ) ) ) ; NEW_LINE
def findMinOpeartion ( matrix , n ) : NEW_LINE
sumRow = [ 0 ] * n NEW_LINE sumCol = [ 0 ] * n NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT sumRow [ i ] += matrix [ i ] [ j ] NEW_LINE sumCol [ j ] += matrix [ i ] [ j ] NEW_LINE DEDENT DEDENT
maxSum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT maxSum = max ( maxSum , sumRow [ i ] ) NEW_LINE maxSum = max ( maxSum , sumCol [ i ] ) NEW_LINE DEDENT count = 0 NEW_LINE i = 0 NEW_LINE j = 0 NEW_LINE while i < n and j < n : NEW_LINE
diff = min ( maxSum - sumRow [ i ] , maxSum - sumCol [ j ] ) NEW_LINE
matrix [ i ] [ j ] += diff NEW_LINE sumRow [ i ] += diff NEW_LINE sumCol [ j ] += diff NEW_LINE
count += diff NEW_LINE
if ( sumRow [ i ] == maxSum ) : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
if ( sumCol [ j ] == maxSum ) : NEW_LINE INDENT j += 1 NEW_LINE DEDENT return count NEW_LINE
def printMatrix ( matrix , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( matrix [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT matrix = [ [ 1 , 2 ] , [ 3 , 4 ] ] NEW_LINE print ( findMinOpeartion ( matrix , 2 ) ) NEW_LINE printMatrix ( matrix , 2 ) NEW_LINE DEDENT
import math NEW_LINE def find ( n , k ) : NEW_LINE INDENT if ( n + 1 >= k ) : NEW_LINE INDENT return ( k - 1 ) NEW_LINE DEDENT else : NEW_LINE INDENT return ( 2 * n + 1 - k ) NEW_LINE DEDENT DEDENT
n = 4 NEW_LINE k = 7 NEW_LINE freq = find ( n , k ) NEW_LINE if ( freq < 0 ) : NEW_LINE INDENT print ( " ▁ element ▁ not ▁ exist " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " ▁ Frequency ▁ of ▁ " , k , " ▁ is ▁ " , freq ) NEW_LINE DEDENT
def ZigZag ( rows , columns , numbers ) : NEW_LINE INDENT k = 0 NEW_LINE DEDENT
arr = [ [ 0 for i in range ( columns ) ] for j in range ( rows ) ] NEW_LINE for i in range ( rows ) : NEW_LINE
if ( i % 2 == 0 ) : NEW_LINE
j = 0 NEW_LINE while j < columns and numbers [ k ] > 0 : NEW_LINE
arr [ i ] [ j ] = k + 1 NEW_LINE
numbers [ k ] -= 1 NEW_LINE
if numbers [ k ] == 0 : NEW_LINE INDENT k += 1 NEW_LINE DEDENT j += 1 NEW_LINE
else : NEW_LINE
j = columns - 1 NEW_LINE while j >= 0 and numbers [ k ] > 0 : NEW_LINE
arr [ i ] [ j ] = k + 1 NEW_LINE
numbers [ k ] -= 1 NEW_LINE
if numbers [ k ] == 0 : NEW_LINE INDENT k += 1 NEW_LINE DEDENT j -= 1 NEW_LINE
for i in arr : NEW_LINE INDENT for j in i : NEW_LINE INDENT print ( j , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
rows = 4 ; NEW_LINE columns = 5 ; NEW_LINE Numbers = [ 3 , 4 , 2 , 2 , 3 , 1 , 5 ] NEW_LINE ZigZag ( rows , columns , Numbers ) NEW_LINE
n = 5 NEW_LINE
def FindMaxProduct ( arr , n ) : NEW_LINE INDENT max = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE
for j in range ( n ) : NEW_LINE
if ( ( j - 3 ) >= 0 ) : NEW_LINE INDENT result = ( arr [ i ] [ j ] * arr [ i ] [ j - 1 ] * arr [ i ] [ j - 2 ] * arr [ i ] [ j - 3 ] ) NEW_LINE if ( max < result ) : NEW_LINE INDENT max = result NEW_LINE DEDENT DEDENT
if ( ( i - 3 ) >= 0 ) : NEW_LINE INDENT result = ( arr [ i ] [ j ] * arr [ i - 1 ] [ j ] * arr [ i - 2 ] [ j ] * arr [ i - 3 ] [ j ] ) NEW_LINE if ( max < result ) : NEW_LINE INDENT max = result NEW_LINE DEDENT DEDENT
if ( ( i - 3 ) >= 0 and ( j - 3 ) >= 0 ) : NEW_LINE INDENT result = ( arr [ i ] [ j ] * arr [ i - 1 ] [ j - 1 ] * arr [ i - 2 ] [ j - 2 ] * arr [ i - 3 ] [ j - 3 ] ) NEW_LINE if ( max < result ) : NEW_LINE INDENT max = result NEW_LINE DEDENT DEDENT
if ( ( i - 3 ) >= 0 and ( j - 1 ) <= 0 ) : NEW_LINE INDENT result = ( arr [ i ] [ j ] * arr [ i - 1 ] [ j + 1 ] * arr [ i - 2 ] [ j + 2 ] * arr [ i - 3 ] [ j + 3 ] ) NEW_LINE if ( max < result ) : NEW_LINE INDENT max = result NEW_LINE DEDENT DEDENT return max NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 6 , 7 , 8 , 9 , 1 ] , [ 2 , 3 , 4 , 5 , 6 ] , [ 7 , 8 , 9 , 1 , 0 ] , [ 9 , 6 , 4 , 2 , 3 ] ] NEW_LINE print ( FindMaxProduct ( arr , n ) ) NEW_LINE DEDENT
N = 3 NEW_LINE
def minimumflip ( mat , n ) : NEW_LINE INDENT transpose = [ [ 0 ] * n ] * n NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT transpose [ i ] [ j ] = mat [ j ] [ i ] NEW_LINE DEDENT DEDENT
flip = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT if transpose [ i ] [ j ] != mat [ i ] [ j ] : NEW_LINE INDENT flip += 1 NEW_LINE DEDENT DEDENT DEDENT return int ( flip / 2 ) NEW_LINE
n = 3 NEW_LINE mat = [ [ 0 , 0 , 1 ] , [ 1 , 1 , 1 ] , [ 1 , 0 , 0 ] ] NEW_LINE print ( minimumflip ( mat , n ) ) NEW_LINE
def minimumflip ( mat , n ) : NEW_LINE
flip = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( i ) : NEW_LINE INDENT if mat [ i ] [ j ] != mat [ j ] [ i ] : NEW_LINE INDENT flip += 1 NEW_LINE DEDENT DEDENT DEDENT return flip NEW_LINE
n = 3 NEW_LINE mat = [ [ 0 , 0 , 1 ] , [ 1 , 1 , 1 ] , [ 1 , 0 , 0 ] ] NEW_LINE print ( minimumflip ( mat , n ) ) NEW_LINE
def islowertriangular ( M ) : NEW_LINE INDENT for i in range ( 0 , len ( M ) ) : NEW_LINE INDENT for j in range ( i + 1 , len ( M ) ) : NEW_LINE INDENT if ( M [ i ] [ j ] != 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT return True NEW_LINE DEDENT
M = [ [ 1 , 0 , 0 , 0 ] , [ 1 , 4 , 0 , 0 ] , [ 4 , 6 , 2 , 0 ] , [ 0 , 4 , 7 , 6 ] ] NEW_LINE
if islowertriangular ( M ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def isuppertriangular ( M ) : NEW_LINE INDENT for i in range ( 1 , len ( M ) ) : NEW_LINE INDENT for j in range ( 0 , i ) : NEW_LINE INDENT if ( M [ i ] [ j ] != 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT return True NEW_LINE DEDENT
M = [ [ 1 , 3 , 5 , 3 ] , [ 0 , 4 , 6 , 2 ] , [ 0 , 0 , 2 , 5 ] , [ 0 , 0 , 0 , 6 ] ] NEW_LINE if isuppertriangular ( M ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
MAX = 100 NEW_LINE
def freq ( ar , m , n ) : NEW_LINE INDENT even = 0 NEW_LINE odd = 0 NEW_LINE for i in range ( m ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE DEDENT DEDENT
if ( ( ar [ i ] [ j ] % 2 ) == 0 ) : NEW_LINE INDENT even += 1 NEW_LINE DEDENT else : NEW_LINE INDENT odd += 1 NEW_LINE DEDENT
print ( " ▁ Frequency ▁ of ▁ odd ▁ number ▁ = " , odd ) NEW_LINE print ( " ▁ Frequency ▁ of ▁ even ▁ number ▁ = " , even ) NEW_LINE
m = 3 NEW_LINE n = 3 NEW_LINE array = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] NEW_LINE freq ( array , m , n ) NEW_LINE
MAX = 100 NEW_LINE
def HalfDiagonalSums ( mat , n ) : NEW_LINE
diag1_left = 0 NEW_LINE diag1_right = 0 NEW_LINE diag2_left = 0 NEW_LINE diag2_right = 0 NEW_LINE i = 0 NEW_LINE j = n - 1 NEW_LINE while i < n : NEW_LINE INDENT if ( i < n // 2 ) : NEW_LINE INDENT diag1_left += mat [ i ] [ i ] NEW_LINE diag2_left += mat [ j ] [ i ] NEW_LINE DEDENT elif ( i > n // 2 ) : NEW_LINE INDENT diag1_right += mat [ i ] [ i ] NEW_LINE diag2_right += mat [ j ] [ i ] NEW_LINE DEDENT i += 1 NEW_LINE j -= 1 NEW_LINE DEDENT return ( diag1_left == diag2_right and diag2_right == diag2_left and diag1_right == diag2_left and diag2_right == mat [ n // 2 ] [ n // 2 ] ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ [ 2 , 9 , 1 , 4 , - 2 ] , [ 6 , 7 , 2 , 11 , 4 ] , [ 4 , 2 , 9 , 2 , 4 ] , [ 1 , 9 , 2 , 4 , 4 ] , [ 0 , 2 , 4 , 2 , 5 ] ] NEW_LINE print ( " Yes " ) if ( HalfDiagonalSums ( a , 5 ) ) else print ( " No " ) NEW_LINE DEDENT
MAX = 100 ; NEW_LINE def isIdentity ( mat , N ) : NEW_LINE INDENT for row in range ( N ) : NEW_LINE INDENT for col in range ( N ) : NEW_LINE INDENT if ( row == col and mat [ row ] [ col ] != 1 ) : NEW_LINE INDENT return False ; NEW_LINE DEDENT elif ( row != col and mat [ row ] [ col ] != 0 ) : NEW_LINE INDENT return False ; NEW_LINE DEDENT DEDENT DEDENT return True ; NEW_LINE DEDENT
N = 4 ; NEW_LINE mat = [ [ 1 , 0 , 0 , 0 ] , [ 0 , 1 , 0 , 0 ] , [ 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 1 ] ] ; NEW_LINE if ( isIdentity ( mat , N ) ) : NEW_LINE INDENT print ( " Yes ▁ " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ " ) ; NEW_LINE DEDENT
def modPower ( a , t ) : NEW_LINE INDENT now = a ; NEW_LINE ret = 1 ; NEW_LINE mod = 100000007 ; NEW_LINE DEDENT
while ( t ) : NEW_LINE INDENT if ( t & 1 ) : NEW_LINE INDENT ret = now * ( ret % mod ) ; NEW_LINE DEDENT now = now * ( now % mod ) ; NEW_LINE t >>= 1 ; NEW_LINE DEDENT return ret ; NEW_LINE
def countWays ( n , m , k ) : NEW_LINE INDENT mod = 100000007 ; NEW_LINE DEDENT
if ( k == - 1 and ( ( n + m ) % 2 == 1 ) ) : NEW_LINE INDENT return 0 ; NEW_LINE DEDENT
if ( n == 1 or m == 1 ) : NEW_LINE INDENT return 1 ; NEW_LINE DEDENT
return ( modPower ( modPower ( 2 , n - 1 ) , m - 1 ) % mod ) ; NEW_LINE
n = 2 ; NEW_LINE m = 7 ; NEW_LINE k = 1 ; NEW_LINE print ( countWays ( n , m , k ) ) ; NEW_LINE
MAX = 100 NEW_LINE def imageSwap ( mat , n ) : NEW_LINE
row = 0 NEW_LINE
for j in range ( n ) : NEW_LINE
s = [ ] NEW_LINE i = row NEW_LINE k = j NEW_LINE while ( i < n and k >= 0 ) : NEW_LINE INDENT s . append ( mat [ i ] [ k ] ) NEW_LINE i += 1 NEW_LINE k -= 1 NEW_LINE DEDENT
i = row NEW_LINE k = j NEW_LINE while ( i < n and k >= 0 ) : NEW_LINE INDENT mat [ i ] [ k ] = s [ - 1 ] NEW_LINE k -= 1 NEW_LINE i += 1 NEW_LINE s . pop ( ) NEW_LINE DEDENT
column = n - 1 NEW_LINE for j in range ( 1 , n ) : NEW_LINE
s = [ ] NEW_LINE i = j NEW_LINE k = column NEW_LINE while ( i < n and k >= 0 ) : NEW_LINE INDENT s . append ( mat [ i ] [ k ] ) NEW_LINE i += 1 NEW_LINE k -= 1 NEW_LINE DEDENT
i = j NEW_LINE k = column NEW_LINE while ( i < n and k >= 0 ) : NEW_LINE INDENT mat [ i ] [ k ] = s [ - 1 ] NEW_LINE i += 1 NEW_LINE k -= 1 NEW_LINE s . pop ( ) NEW_LINE DEDENT
def printMatrix ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
mat = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 ] ] NEW_LINE n = 4 NEW_LINE imageSwap ( mat , n ) NEW_LINE printMatrix ( mat , n ) NEW_LINE
from builtins import range NEW_LINE MAX = 100 ; NEW_LINE def imageSwap ( mat , n ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 ) : NEW_LINE INDENT t = mat [ i ] [ j ] ; NEW_LINE mat [ i ] [ j ] = mat [ j ] [ i ] NEW_LINE mat [ j ] [ i ] = t NEW_LINE DEDENT DEDENT
def printMatrix ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " ▁ " ) ; NEW_LINE DEDENT print ( ) ; NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT mat = [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 ] ; NEW_LINE n = 4 ; NEW_LINE imageSwap ( mat , n ) ; NEW_LINE printMatrix ( mat , n ) ; NEW_LINE DEDENT
m = 3 NEW_LINE
n = 2 NEW_LINE
def countSets ( a ) : NEW_LINE
res = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT u = 0 NEW_LINE v = 0 NEW_LINE for j in range ( m ) : NEW_LINE INDENT if a [ i ] [ j ] : NEW_LINE INDENT u += 1 NEW_LINE DEDENT else : NEW_LINE INDENT v += 1 NEW_LINE DEDENT DEDENT res += pow ( 2 , u ) - 1 + pow ( 2 , v ) - 1 NEW_LINE DEDENT
for i in range ( m ) : NEW_LINE INDENT u = 0 NEW_LINE v = 0 NEW_LINE for j in range ( n ) : NEW_LINE INDENT if a [ j ] [ i ] : NEW_LINE INDENT u += 1 NEW_LINE DEDENT else : NEW_LINE INDENT v += 1 NEW_LINE DEDENT DEDENT res += pow ( 2 , u ) - 1 + pow ( 2 , v ) - 1 NEW_LINE DEDENT
return res - ( n * m ) NEW_LINE
a = [ [ 1 , 0 , 1 ] , [ 0 , 1 , 0 ] ] NEW_LINE print ( countSets ( a ) ) NEW_LINE
def search ( mat , n , x ) : NEW_LINE INDENT if ( n == 0 ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE DEDENT
if ( mat [ i ] [ j ] == x ) : NEW_LINE INDENT print ( " Element ▁ found ▁ at ▁ ( " , i , " , " , j , " ) " ) NEW_LINE return 1 NEW_LINE DEDENT print ( " ▁ Element ▁ not ▁ found " ) NEW_LINE return 0 NEW_LINE
mat = [ [ 10 , 20 , 30 , 40 ] , [ 15 , 25 , 35 , 45 ] , [ 27 , 29 , 37 , 48 ] , [ 32 , 33 , 39 , 50 ] ] NEW_LINE search ( mat , 4 , 29 ) NEW_LINE
def fill0X ( m , n ) : NEW_LINE
i , k , l = 0 , 0 , 0 NEW_LINE
r = m NEW_LINE c = n NEW_LINE
a = [ [ None ] * n for i in range ( m ) ] NEW_LINE
x = ' X ' NEW_LINE
while k < m and l < n : NEW_LINE
for i in range ( l , n ) : NEW_LINE INDENT a [ k ] [ i ] = x NEW_LINE DEDENT k += 1 NEW_LINE
for i in range ( k , m ) : NEW_LINE INDENT a [ i ] [ n - 1 ] = x NEW_LINE DEDENT n -= 1 NEW_LINE
if k < m : NEW_LINE INDENT for i in range ( n - 1 , l - 1 , - 1 ) : NEW_LINE INDENT a [ m - 1 ] [ i ] = x NEW_LINE DEDENT m -= 1 NEW_LINE DEDENT
if l < n : NEW_LINE INDENT for i in range ( m - 1 , k - 1 , - 1 ) : NEW_LINE INDENT a [ i ] [ l ] = x NEW_LINE DEDENT l += 1 NEW_LINE DEDENT
x = ' X ' if x == '0' else '0' NEW_LINE
for i in range ( r ) : NEW_LINE INDENT for j in range ( c ) : NEW_LINE INDENT print ( a [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT print ( " Output ▁ for ▁ m ▁ = ▁ 5 , ▁ n ▁ = ▁ 6" ) NEW_LINE fill0X ( 5 , 6 ) NEW_LINE print ( " Output ▁ for ▁ m ▁ = ▁ 4 , ▁ n ▁ = ▁ 4" ) NEW_LINE fill0X ( 4 , 4 ) NEW_LINE print ( " Output ▁ for ▁ m ▁ = ▁ 3 , ▁ n ▁ = ▁ 4" ) NEW_LINE fill0X ( 3 , 4 ) NEW_LINE DEDENT
class newNode : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . Next = self . child = None NEW_LINE self . data = data NEW_LINE DEDENT DEDENT
def addSibling ( n , data ) : NEW_LINE INDENT if ( n == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT while ( n . Next ) : NEW_LINE INDENT n = n . Next NEW_LINE DEDENT n . Next = newNode ( data ) NEW_LINE return n . Next NEW_LINE DEDENT
def addChild ( n , data ) : NEW_LINE INDENT if ( n == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT DEDENT
if ( n . child ) : NEW_LINE INDENT return addSibling ( n . child , data ) NEW_LINE DEDENT else : NEW_LINE INDENT n . child = newNode ( data ) NEW_LINE return n . child NEW_LINE DEDENT
def traverseTree ( root ) : NEW_LINE INDENT if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT while ( root ) : NEW_LINE INDENT print ( root . data , end = " ▁ " ) NEW_LINE if ( root . child ) : NEW_LINE INDENT traverseTree ( root . child ) NEW_LINE DEDENT root = root . Next NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = newNode ( 10 ) NEW_LINE n1 = addChild ( root , 2 ) NEW_LINE n2 = addChild ( root , 3 ) NEW_LINE n3 = addChild ( root , 4 ) NEW_LINE n4 = addChild ( n3 , 6 ) NEW_LINE n5 = addChild ( root , 5 ) NEW_LINE n6 = addChild ( n5 , 7 ) NEW_LINE n7 = addChild ( n5 , 8 ) NEW_LINE n8 = addChild ( n5 , 9 ) NEW_LINE traverseTree ( root ) NEW_LINE DEDENT
n = 4 NEW_LINE
def calculateEnergy ( mat , n ) : NEW_LINE INDENT tot_energy = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE DEDENT
q = mat [ i ] [ j ] // n NEW_LINE
i_des = q NEW_LINE j_des = mat [ i ] [ j ] - ( n * q ) NEW_LINE
tot_energy += ( abs ( i_des - i ) + abs ( j_des - j ) ) NEW_LINE
return tot_energy NEW_LINE
mat = [ [ 4 , 7 , 0 , 3 ] , [ 8 , 5 , 6 , 1 ] , [ 9 , 11 , 10 , 2 ] , [ 15 , 13 , 14 , 12 ] ] NEW_LINE print ( " Total ▁ energy ▁ required ▁ = ▁ " , calculateEnergy ( mat , n ) , " units " ) NEW_LINE
MAX = 100 NEW_LINE
def isUnique ( mat , i , j , n , m ) : NEW_LINE
sumrow = 0 NEW_LINE for k in range ( m ) : NEW_LINE INDENT sumrow += mat [ i ] [ k ] NEW_LINE if ( sumrow > 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
sumcol = 0 NEW_LINE for k in range ( n ) : NEW_LINE INDENT sumcol += mat [ k ] [ j ] NEW_LINE if ( sumcol > 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE def countUnique ( mat , n , m ) : NEW_LINE uniquecount = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT if ( mat [ i ] [ j ] and isUnique ( mat , i , j , n , m ) ) : NEW_LINE INDENT uniquecount += 1 NEW_LINE DEDENT DEDENT DEDENT return uniquecount NEW_LINE
mat = [ [ 0 , 1 , 0 , 0 ] , [ 0 , 0 , 1 , 0 ] , [ 1 , 0 , 0 , 1 ] ] NEW_LINE print ( countUnique ( mat , 3 , 4 ) ) NEW_LINE
MAX = 100 ; NEW_LINE def countUnique ( mat , n , m ) : NEW_LINE INDENT rowsum = [ 0 ] * n ; NEW_LINE colsum = [ 0 ] * m ; NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT if ( mat [ i ] [ j ] != 0 ) : NEW_LINE INDENT rowsum [ i ] += 1 ; NEW_LINE colsum [ j ] += 1 ; NEW_LINE DEDENT DEDENT DEDENT
uniquecount = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT if ( mat [ i ] [ j ] != 0 and rowsum [ i ] == 1 and colsum [ j ] == 1 ) : NEW_LINE INDENT uniquecount += 1 ; NEW_LINE DEDENT DEDENT DEDENT return uniquecount ; NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT mat = [ [ 0 , 1 , 0 , 0 ] , [ 0 , 0 , 1 , 0 ] , [ 1 , 0 , 0 , 1 ] ] ; NEW_LINE print ( countUnique ( mat , 3 , 4 ) ) ; NEW_LINE DEDENT
for i in range ( 0 , m ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE INDENT if ( array [ i ] [ j ] == 0 ) : NEW_LINE INDENT counter = counter + 1 NEW_LINE DEDENT DEDENT DEDENT return ( counter > ( ( m * n ) // 2 ) ) NEW_LINE
array = [ [ 1 , 0 , 3 ] , [ 0 , 0 , 4 ] , [ 6 , 0 , 0 ] ] NEW_LINE m = 3 NEW_LINE n = 3 NEW_LINE if ( isSparse ( array , m , n ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
Max = 100 NEW_LINE
def countCommon ( mat , n ) : NEW_LINE INDENT res = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if mat [ i ] [ i ] == mat [ i ] [ n - i - 1 ] : NEW_LINE INDENT res = res + 1 NEW_LINE DEDENT DEDENT return res NEW_LINE DEDENT
mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] NEW_LINE print ( countCommon ( mat , 3 ) ) NEW_LINE
def areSumSame ( a , n , m ) : NEW_LINE INDENT sum1 = 0 NEW_LINE sum2 = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT sum1 = 0 NEW_LINE sum2 = 0 NEW_LINE for j in range ( 0 , m ) : NEW_LINE INDENT sum1 += a [ i ] [ j ] NEW_LINE sum2 += a [ j ] [ i ] NEW_LINE DEDENT if ( sum1 == sum2 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT DEDENT return 0 NEW_LINE DEDENT
n = 4 ; NEW_LINE
m = 4 ; NEW_LINE M = [ [ 1 , 2 , 3 , 4 ] , [ 9 , 5 , 3 , 1 ] , [ 0 , 3 , 5 , 6 ] , [ 0 , 4 , 5 , 6 ] ] NEW_LINE print ( areSumSame ( M , n , m ) ) NEW_LINE
from collections import deque NEW_LINE
class Node : NEW_LINE INDENT def __init__ ( self , x ) : NEW_LINE INDENT self . data = x NEW_LINE self . next = None NEW_LINE self . child = None NEW_LINE DEDENT DEDENT
def addSibling ( n , data ) : NEW_LINE INDENT if ( n == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT while ( n . next ) : NEW_LINE INDENT n = n . next NEW_LINE DEDENT n . next = Node ( data ) NEW_LINE return n NEW_LINE DEDENT
def addChild ( n , data ) : NEW_LINE INDENT if ( n == None ) : NEW_LINE INDENT return None NEW_LINE DEDENT DEDENT
if ( n . child ) : NEW_LINE INDENT return addSibling ( n . child , data ) NEW_LINE DEDENT else : NEW_LINE INDENT n . child = Node ( data ) NEW_LINE return n NEW_LINE DEDENT
def traverseTree ( root ) : NEW_LINE
if ( root == None ) : NEW_LINE INDENT return NEW_LINE DEDENT print ( root . data , end = " ▁ " ) NEW_LINE if ( root . child == None ) : NEW_LINE INDENT return NEW_LINE DEDENT
q = deque ( ) NEW_LINE curr = root . child NEW_LINE q . append ( curr ) NEW_LINE while ( len ( q ) > 0 ) : NEW_LINE
curr = q . popleft ( ) NEW_LINE
while ( curr != None ) : NEW_LINE INDENT print ( curr . data , end = " ▁ " ) NEW_LINE if ( curr . child != None ) : NEW_LINE INDENT q . append ( curr . child ) NEW_LINE DEDENT curr = curr . next NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT root = Node ( 10 ) NEW_LINE n1 = addChild ( root , 2 ) NEW_LINE n2 = addChild ( root , 3 ) NEW_LINE n3 = addChild ( root , 4 ) NEW_LINE n4 = addChild ( n3 , 6 ) NEW_LINE n5 = addChild ( root , 5 ) NEW_LINE n6 = addChild ( n5 , 7 ) NEW_LINE n7 = addChild ( n5 , 8 ) NEW_LINE n8 = addChild ( n5 , 9 ) NEW_LINE traverseTree ( root ) NEW_LINE DEDENT
N = 4 NEW_LINE
def findMax ( arr ) : NEW_LINE INDENT row = 0 NEW_LINE j = N - 1 NEW_LINE for i in range ( 0 , N ) : NEW_LINE DEDENT
while ( arr [ i ] [ j ] == 1 and j >= 0 ) : NEW_LINE INDENT row = i NEW_LINE j -= 1 NEW_LINE DEDENT print ( " Row ▁ number ▁ = ▁ " , row + 1 , " , ▁ MaxCount ▁ = ▁ " , N - 1 - j ) NEW_LINE
arr = [ [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 0 ] , [ 0 , 1 , 1 , 1 ] ] NEW_LINE findMax ( arr ) NEW_LINE
def transpose ( mat , tr , N ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT tr [ i ] [ j ] = mat [ j ] [ i ] NEW_LINE DEDENT DEDENT DEDENT
def isSymmetric ( mat , N ) : NEW_LINE INDENT tr = [ [ 0 for j in range ( len ( mat [ 0 ] ) ) ] for i in range ( len ( mat ) ) ] NEW_LINE transpose ( mat , tr , N ) NEW_LINE for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT if ( mat [ i ] [ j ] != tr [ i ] [ j ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT return True NEW_LINE DEDENT
mat = [ [ 1 , 3 , 5 ] , [ 3 , 2 , 4 ] , [ 5 , 4 , 1 ] ] NEW_LINE if ( isSymmetric ( mat , 3 ) ) : NEW_LINE INDENT print " Yes " NEW_LINE DEDENT else : NEW_LINE INDENT print " No " NEW_LINE DEDENT
def isSymmetric ( mat , N ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT return True NEW_LINE DEDENT
mat = [ [ 1 , 3 , 5 ] , [ 3 , 2 , 4 ] , [ 5 , 4 , 1 ] ] NEW_LINE if ( isSymmetric ( mat , 3 ) ) : NEW_LINE INDENT print " Yes " NEW_LINE DEDENT else : NEW_LINE INDENT print " No " NEW_LINE DEDENT
def isPalin ( str ) : NEW_LINE INDENT l = len ( str ) // 2 NEW_LINE for i in range ( l ) : NEW_LINE INDENT if ( str [ i ] != str [ len ( str ) - i - 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE DEDENT
def palindromicPath ( str , a , i , j , m , n ) : NEW_LINE
if ( j < m - 1 or i < n - 1 ) : NEW_LINE INDENT if ( i < n - 1 ) : NEW_LINE INDENT palindromicPath ( str + a [ i ] [ j ] , a , i + 1 , j , m , n ) NEW_LINE DEDENT if ( j < m - 1 ) : NEW_LINE INDENT palindromicPath ( str + a [ i ] [ j ] , a , i , j + 1 , m , n ) NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT str = str + a [ n - 1 ] [ m - 1 ] NEW_LINE if isPalin ( str ) : NEW_LINE INDENT print ( str ) NEW_LINE DEDENT DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ [ ' a ' , ' a ' , ' a ' , ' b ' ] , [ ' b ' , ' a ' , ' a ' , ' a ' ] , [ ' a ' , ' b ' , ' b ' , ' a ' ] ] NEW_LINE str = " " NEW_LINE palindromicPath ( str , arr , 0 , 0 , 4 , 3 ) NEW_LINE DEDENT
n = 4 ; NEW_LINE m = 4 ; NEW_LINE
def findPossibleMoves ( mat , p , q ) : NEW_LINE INDENT global n , m ; NEW_LINE DEDENT
X = [ 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 ] ; NEW_LINE Y = [ 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 ] ; NEW_LINE count = 0 ; NEW_LINE
for i in range ( 8 ) : NEW_LINE
x = p + X [ i ] ; NEW_LINE y = q + Y [ i ] ; NEW_LINE
if ( x >= 0 and y >= 0 and x < n and y < m and mat [ x ] [ y ] == 0 ) : NEW_LINE INDENT count += 1 ; NEW_LINE DEDENT
return count ; NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT mat = [ [ 1 , 0 , 1 , 0 ] , [ 0 , 1 , 1 , 1 ] , [ 1 , 1 , 0 , 1 ] , [ 0 , 1 , 1 , 1 ] ] ; NEW_LINE p , q = 2 , 2 ; NEW_LINE print ( findPossibleMoves ( mat , p , q ) ) ; NEW_LINE DEDENT
MAX = 100 NEW_LINE def printDiagonalSums ( mat , n ) : NEW_LINE INDENT principal = 0 NEW_LINE secondary = 0 ; NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT DEDENT
if ( i == j ) : NEW_LINE INDENT principal += mat [ i ] [ j ] NEW_LINE DEDENT
if ( ( i + j ) == ( n - 1 ) ) : NEW_LINE INDENT secondary += mat [ i ] [ j ] NEW_LINE DEDENT print ( " Principal ▁ Diagonal : " , principal ) NEW_LINE print ( " Secondary ▁ Diagonal : " , secondary ) NEW_LINE
a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] NEW_LINE printDiagonalSums ( a , 4 ) NEW_LINE
MAX = 100 NEW_LINE def printDiagonalSums ( mat , n ) : NEW_LINE INDENT principal = 0 NEW_LINE secondary = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT principal += mat [ i ] [ i ] NEW_LINE secondary += mat [ i ] [ n - i - 1 ] NEW_LINE DEDENT print ( " Principal ▁ Diagonal : " , principal ) NEW_LINE print ( " Secondary ▁ Diagonal : " , secondary ) NEW_LINE DEDENT
a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] NEW_LINE printDiagonalSums ( a , 4 ) NEW_LINE
MAX = 100 NEW_LINE def printBoundary ( a , m , n ) : NEW_LINE INDENT sum = 0 NEW_LINE for i in range ( m ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT if ( i == 0 ) : NEW_LINE INDENT sum += a [ i ] [ j ] NEW_LINE DEDENT elif ( i == m - 1 ) : NEW_LINE INDENT sum += a [ i ] [ j ] NEW_LINE DEDENT elif ( j == 0 ) : NEW_LINE INDENT sum += a [ i ] [ j ] NEW_LINE DEDENT elif ( j == n - 1 ) : NEW_LINE INDENT sum += a [ i ] [ j ] NEW_LINE DEDENT DEDENT DEDENT return sum NEW_LINE DEDENT
a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] NEW_LINE sum = printBoundary ( a , 4 , 4 ) NEW_LINE print " Sum ▁ of ▁ boundary ▁ elements ▁ is " , sum NEW_LINE
MAX = 100 NEW_LINE def printSpiral ( mat , r , c ) : NEW_LINE INDENT a = 0 NEW_LINE b = 2 NEW_LINE low_row = 0 if ( 0 > a ) else a NEW_LINE low_column = 0 if ( 0 > b ) else b - 1 NEW_LINE high_row = r - 1 if ( ( a + 1 ) >= r ) else a + 1 NEW_LINE high_column = c - 1 if ( ( b + 1 ) >= c ) else b + 1 NEW_LINE while ( ( low_row > 0 - r and low_column > 0 - c ) ) : NEW_LINE INDENT i = low_column + 1 NEW_LINE while ( i <= high_column and i < c and low_row >= 0 ) : NEW_LINE INDENT print ( mat [ low_row ] [ i ] , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE DEDENT low_row -= 1 NEW_LINE i = low_row + 2 NEW_LINE while ( i <= high_row and i < r and high_column < c ) : NEW_LINE INDENT print ( mat [ i ] [ high_column ] , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE DEDENT high_column += 1 NEW_LINE i = high_column - 2 NEW_LINE while ( i >= low_column and i >= 0 and high_row < r ) : NEW_LINE INDENT print ( mat [ high_row ] [ i ] , end = " ▁ " ) NEW_LINE i -= 1 NEW_LINE DEDENT high_row += 1 NEW_LINE i = high_row - 2 NEW_LINE while ( i > low_row and i >= 0 and low_column >= 0 ) : NEW_LINE INDENT print ( mat [ i ] [ low_column ] , end = " ▁ " ) NEW_LINE i -= 1 NEW_LINE DEDENT low_column -= 1 NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] NEW_LINE r = 3 NEW_LINE c = 3 NEW_LINE DEDENT
printSpiral ( mat , r , c ) NEW_LINE
N = 3 ; NEW_LINE
def interchangeDiagonals ( array ) : NEW_LINE
for i in range ( N ) : NEW_LINE INDENT if ( i != N / 2 ) : NEW_LINE INDENT temp = array [ i ] [ i ] ; NEW_LINE array [ i ] [ i ] = array [ i ] [ N - i - 1 ] ; NEW_LINE array [ i ] [ N - i - 1 ] = temp ; NEW_LINE DEDENT DEDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT print ( array [ i ] [ j ] , end = " ▁ " ) ; NEW_LINE DEDENT print ( ) ; NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT array = [ 4 , 5 , 6 ] , [ 1 , 2 , 3 ] , [ 7 , 8 , 9 ] ; NEW_LINE interchangeDiagonals ( array ) ; NEW_LINE DEDENT
def difference ( arr , n ) : NEW_LINE
d1 = 0 NEW_LINE d2 = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT
if ( i == j ) : NEW_LINE INDENT d1 += arr [ i ] [ j ] NEW_LINE DEDENT
if ( i == n - j - 1 ) : NEW_LINE INDENT d2 += arr [ i ] [ j ] NEW_LINE DEDENT
return abs ( d1 - d2 ) ; NEW_LINE
n = 3 NEW_LINE arr = [ [ 11 , 2 , 4 ] , [ 4 , 5 , 6 ] , [ 10 , 8 , - 12 ] ] NEW_LINE print ( difference ( arr , n ) ) NEW_LINE
def difference ( arr , n ) : NEW_LINE
d1 = 0 NEW_LINE d2 = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT d1 = d1 + arr [ i ] [ i ] NEW_LINE d2 = d2 + arr [ i ] [ n - i - 1 ] NEW_LINE DEDENT
return abs ( d1 - d2 ) NEW_LINE
n = 3 NEW_LINE arr = [ [ 11 , 2 , 4 ] , [ 4 , 5 , 6 ] , [ 10 , 8 , - 12 ] ] NEW_LINE print ( difference ( arr , n ) ) NEW_LINE
def spiralFill ( m , n , a ) : NEW_LINE
val = 1 NEW_LINE
k , l = 0 , 0 NEW_LINE while ( k < m and l < n ) : NEW_LINE
for i in range ( l , n ) : NEW_LINE INDENT a [ k ] [ i ] = val NEW_LINE val += 1 NEW_LINE DEDENT k += 1 NEW_LINE
for i in range ( k , m ) : NEW_LINE INDENT a [ i ] [ n - 1 ] = val NEW_LINE val += 1 NEW_LINE DEDENT n -= 1 NEW_LINE
if ( k < m ) : NEW_LINE INDENT for i in range ( n - 1 , l - 1 , - 1 ) : NEW_LINE INDENT a [ m - 1 ] [ i ] = val NEW_LINE val += 1 NEW_LINE DEDENT m -= 1 NEW_LINE DEDENT
if ( l < n ) : NEW_LINE INDENT for i in range ( m - 1 , k - 1 , - 1 ) : NEW_LINE INDENT a [ i ] [ l ] = val NEW_LINE val += 1 NEW_LINE DEDENT l += 1 NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT m , n = 4 , 4 NEW_LINE a = [ [ 0 for j in range ( m ) ] for i in range ( n ) ] NEW_LINE spiralFill ( m , n , a ) NEW_LINE for i in range ( m ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( a [ i ] [ j ] , end = ' ▁ ' ) NEW_LINE DEDENT print ( ' ' ) NEW_LINE DEDENT DEDENT
MAX = 100 NEW_LINE
def MAXMIN ( arr , n ) : NEW_LINE INDENT MIN = 10 ** 9 NEW_LINE MAX = - 10 ** 9 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( n // 2 + 1 ) : NEW_LINE DEDENT
if ( arr [ i ] [ j ] > arr [ i ] [ n - j - 1 ] ) : NEW_LINE INDENT if ( MIN > arr [ i ] [ n - j - 1 ] ) : NEW_LINE INDENT MIN = arr [ i ] [ n - j - 1 ] NEW_LINE DEDENT if ( MAX < arr [ i ] [ j ] ) : NEW_LINE INDENT MAX = arr [ i ] [ j ] NEW_LINE DEDENT DEDENT else : NEW_LINE INDENT if ( MIN > arr [ i ] [ j ] ) : NEW_LINE INDENT MIN = arr [ i ] [ j ] NEW_LINE DEDENT if ( MAX < arr [ i ] [ n - j - 1 ] ) : NEW_LINE INDENT MAX = arr [ i ] [ n - j - 1 ] NEW_LINE DEDENT DEDENT print ( " MAXimum ▁ = " , MAX , " , ▁ MINimum ▁ = " , MIN ) NEW_LINE
arr = [ [ 5 , 9 , 11 ] , [ 25 , 0 , 14 ] , [ 21 , 6 , 4 ] ] NEW_LINE MAXMIN ( arr , 3 ) NEW_LINE
R = 4 NEW_LINE C = 5 NEW_LINE def antiSpiralTraversal ( m , n , a ) : NEW_LINE INDENT k = 0 NEW_LINE l = 0 NEW_LINE DEDENT
stk = [ ] NEW_LINE while ( k <= m and l <= n ) : NEW_LINE
for i in range ( l , n + 1 ) : NEW_LINE INDENT stk . append ( a [ k ] [ i ] ) NEW_LINE DEDENT k += 1 NEW_LINE
for i in range ( k , m + 1 ) : NEW_LINE INDENT stk . append ( a [ i ] [ n ] ) NEW_LINE DEDENT n -= 1 NEW_LINE
if ( k <= m ) : NEW_LINE INDENT for i in range ( n , l - 1 , - 1 ) : NEW_LINE INDENT stk . append ( a [ m ] [ i ] ) NEW_LINE DEDENT m -= 1 NEW_LINE DEDENT
if ( l <= n ) : NEW_LINE INDENT for i in range ( m , k - 1 , - 1 ) : NEW_LINE INDENT stk . append ( a [ i ] [ l ] ) NEW_LINE DEDENT l += 1 NEW_LINE DEDENT while len ( stk ) != 0 : NEW_LINE print ( str ( stk [ - 1 ] ) , end = " ▁ " ) NEW_LINE stk . pop ( ) NEW_LINE
mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 6 , 7 , 8 , 9 , 10 ] , [ 11 , 12 , 13 , 14 , 15 ] , [ 16 , 17 , 18 , 19 , 20 ] ] ; NEW_LINE antiSpiralTraversal ( R - 1 , C - 1 , mat ) NEW_LINE
MAX = 100 ; NEW_LINE
def findNormal ( mat , n ) : NEW_LINE INDENT sum = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT sum += mat [ i ] [ j ] * mat [ i ] [ j ] ; NEW_LINE DEDENT DEDENT return math . floor ( math . sqrt ( sum ) ) ; NEW_LINE DEDENT
def findTrace ( mat , n ) : NEW_LINE INDENT sum = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum += mat [ i ] [ i ] ; NEW_LINE DEDENT return sum ; NEW_LINE DEDENT
mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] ; NEW_LINE print ( " Trace ▁ of ▁ Matrix ▁ = " , findTrace ( mat , 5 ) ) ; NEW_LINE print ( " Normal ▁ of ▁ Matrix ▁ = " , findNormal ( mat , 5 ) ) ; NEW_LINE
def minOperation ( arr ) : NEW_LINE INDENT ans = 0 NEW_LINE for i in range ( N - 1 , - 1 , - 1 ) : NEW_LINE INDENT for j in range ( M - 1 , - 1 , - 1 ) : NEW_LINE DEDENT DEDENT
if ( arr [ i ] [ j ] == 0 ) : NEW_LINE
ans += 1 NEW_LINE
for k in range ( i + 1 ) : NEW_LINE INDENT for h in range ( j + 1 ) : NEW_LINE DEDENT
if ( arr [ k ] [ h ] == 1 ) : NEW_LINE INDENT arr [ k ] [ h ] = 0 NEW_LINE DEDENT else : NEW_LINE INDENT arr [ k ] [ h ] = 1 NEW_LINE DEDENT return ans NEW_LINE
mat = [ [ 0 , 0 , 1 , 1 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] ] NEW_LINE M = 5 NEW_LINE N = 5 NEW_LINE print ( minOperation ( mat ) ) NEW_LINE
def findSum ( n ) : NEW_LINE INDENT ans = 0 ; temp = 0 ; NEW_LINE DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT if temp < n : NEW_LINE DEDENT
temp = i - 1 NEW_LINE
num = 1 NEW_LINE while temp < n : NEW_LINE INDENT if temp + i <= n : NEW_LINE INDENT ans += i * num NEW_LINE DEDENT else : NEW_LINE INDENT ans += ( n - temp ) * num NEW_LINE DEDENT temp += i NEW_LINE num += 1 NEW_LINE DEDENT return ans NEW_LINE
N = 2 NEW_LINE print ( findSum ( N ) ) NEW_LINE
def printCoils ( n ) : NEW_LINE
m = 8 * n * n NEW_LINE
coil1 = [ 0 ] * m NEW_LINE
coil1 [ 0 ] = 8 * n * n + 2 * n NEW_LINE curr = coil1 [ 0 ] NEW_LINE nflg = 1 NEW_LINE step = 2 NEW_LINE
index = 1 NEW_LINE while ( index < m ) : NEW_LINE
for i in range ( step ) : NEW_LINE
curr = coil1 [ index ] = ( curr - 4 * n * nflg ) NEW_LINE index += 1 NEW_LINE if ( index >= m ) : NEW_LINE INDENT break NEW_LINE DEDENT if ( index >= m ) : NEW_LINE break NEW_LINE
for i in range ( step ) : NEW_LINE INDENT curr = coil1 [ index ] = curr + nflg NEW_LINE index += 1 NEW_LINE if ( index >= m ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT nflg = nflg * ( - 1 ) NEW_LINE step += 2 NEW_LINE
coil2 = [ 0 ] * m NEW_LINE i = 0 NEW_LINE while ( i < 8 * n * n ) : NEW_LINE INDENT coil2 [ i ] = 16 * n * n + 1 - coil1 [ i ] NEW_LINE i += 1 NEW_LINE DEDENT
print ( " Coil ▁ 1 ▁ : " , end = " ▁ " ) NEW_LINE i = 0 NEW_LINE while ( i < 8 * n * n ) : NEW_LINE INDENT print ( coil1 [ i ] , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE DEDENT print ( " Coil 2 : " , ▁ end ▁ = ▁ "   " ) NEW_LINE i = 0 NEW_LINE while ( i < 8 * n * n ) : NEW_LINE INDENT print ( coil2 [ i ] , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE DEDENT
n = 1 NEW_LINE printCoils ( n ) NEW_LINE
def findSum ( n ) : NEW_LINE
arr = [ [ 0 for x in range ( n ) ] for y in range ( n ) ] NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT arr [ i ] [ j ] = abs ( i - j ) NEW_LINE DEDENT DEDENT
sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT sum += arr [ i ] [ j ] NEW_LINE DEDENT DEDENT return sum NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 3 NEW_LINE print ( findSum ( n ) ) NEW_LINE DEDENT
def findSum ( n ) : NEW_LINE INDENT sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum += i * ( n - i ) NEW_LINE DEDENT return 2 * sum NEW_LINE DEDENT
n = 3 NEW_LINE print ( findSum ( n ) ) NEW_LINE
def findSum ( n ) : NEW_LINE INDENT n -= 1 NEW_LINE sum = 0 NEW_LINE sum += ( n * ( n + 1 ) ) / 2 NEW_LINE sum += ( n * ( n + 1 ) * ( 2 * n + 1 ) ) / 6 NEW_LINE return int ( sum ) NEW_LINE DEDENT
n = 3 NEW_LINE print ( findSum ( n ) ) NEW_LINE
MAX = 1000 NEW_LINE def checkHV ( arr , N , M ) : NEW_LINE
horizontal = True NEW_LINE vertical = True NEW_LINE
i = 0 NEW_LINE k = N - 1 NEW_LINE while ( i < N // 2 ) : NEW_LINE
for j in range ( M ) : NEW_LINE
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) : NEW_LINE INDENT horizontal = False NEW_LINE break NEW_LINE DEDENT i += 1 NEW_LINE k -= 1 NEW_LINE
i = 0 NEW_LINE k = M - 1 NEW_LINE while ( i < M // 2 ) : NEW_LINE
for j in range ( N ) : NEW_LINE
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) : NEW_LINE INDENT vertical = False NEW_LINE break NEW_LINE DEDENT i += 1 NEW_LINE k -= 1 NEW_LINE if ( not horizontal and not vertical ) : NEW_LINE print ( " NO " ) NEW_LINE elif ( horizontal and not vertical ) : NEW_LINE print ( " HORIZONTAL " ) NEW_LINE elif ( vertical and not horizontal ) : NEW_LINE print ( " VERTICAL " ) NEW_LINE else : NEW_LINE print ( " BOTH " ) NEW_LINE
mat = [ [ 1 , 0 , 1 ] , [ 0 , 0 , 0 ] , [ 1 , 0 , 1 ] ] NEW_LINE checkHV ( mat , 3 , 3 ) NEW_LINE
def maxDet ( n ) : NEW_LINE INDENT return 2 * n * n * n NEW_LINE DEDENT
def resMatrix ( n ) : NEW_LINE INDENT for i in range ( 3 ) : NEW_LINE INDENT for j in range ( 3 ) : NEW_LINE DEDENT DEDENT
if i == 0 and j == 2 : NEW_LINE INDENT print ( "0" , end = " ▁ " ) NEW_LINE DEDENT elif i == 1 and j == 0 : NEW_LINE INDENT print ( "0" , end = " ▁ " ) NEW_LINE DEDENT elif i == 2 and j == 1 : NEW_LINE INDENT print ( "0" , end = " ▁ " ) NEW_LINE DEDENT
else : NEW_LINE INDENT print ( n , end = " ▁ " ) NEW_LINE DEDENT print ( " " ) NEW_LINE
n = 15 NEW_LINE print ( " Maximum ▁ Detrminat = " , maxDet ( n ) ) NEW_LINE print ( " Resultant ▁ Matrix : " ) NEW_LINE resMatrix ( n ) NEW_LINE
def spiralDiaSum ( n ) : NEW_LINE INDENT if n == 1 : NEW_LINE INDENT return 1 NEW_LINE DEDENT DEDENT
return ( 4 * n * n - 6 * n + 6 + spiralDiaSum ( n - 2 ) ) NEW_LINE
n = 7 ; NEW_LINE print ( spiralDiaSum ( n ) ) NEW_LINE
R = 3 NEW_LINE C = 5 NEW_LINE
def numofneighbour ( mat , i , j ) : NEW_LINE INDENT count = 0 ; NEW_LINE DEDENT
if ( i > 0 and mat [ i - 1 ] [ j ] ) : NEW_LINE INDENT count += 1 ; NEW_LINE DEDENT
if ( j > 0 and mat [ i ] [ j - 1 ] ) : NEW_LINE INDENT count += 1 ; NEW_LINE DEDENT
if ( i < R - 1 and mat [ i + 1 ] [ j ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
if ( j < C - 1 and mat [ i ] [ j + 1 ] ) : NEW_LINE INDENT count += 1 ; NEW_LINE DEDENT return count ; NEW_LINE
def findperimeter ( mat ) : NEW_LINE INDENT perimeter = 0 ; NEW_LINE DEDENT
for i in range ( 0 , R ) : NEW_LINE INDENT for j in range ( 0 , C ) : NEW_LINE INDENT if ( mat [ i ] [ j ] ) : NEW_LINE INDENT perimeter += ( 4 - numofneighbour ( mat , i , j ) ) ; NEW_LINE DEDENT DEDENT DEDENT return perimeter ; NEW_LINE
mat = [ [ 0 , 1 , 0 , 0 , 0 ] , [ 1 , 1 , 1 , 0 , 0 ] , [ 1 , 0 , 0 , 0 , 0 ] ] NEW_LINE print ( findperimeter ( mat ) , end = " " ) ; NEW_LINE
MAX = 100 NEW_LINE def printMatrixDiagonal ( mat , n ) : NEW_LINE
i = 0 NEW_LINE j = 0 NEW_LINE k = 0 NEW_LINE
isUp = True NEW_LINE
while k < n * n : NEW_LINE
if isUp : NEW_LINE INDENT while i >= 0 and j < n : NEW_LINE INDENT print ( str ( mat [ i ] [ j ] ) , end = " ▁ " ) NEW_LINE k += 1 NEW_LINE j += 1 NEW_LINE i -= 1 NEW_LINE DEDENT DEDENT
if i < 0 and j <= n - 1 : NEW_LINE INDENT i = 0 NEW_LINE DEDENT if j == n : NEW_LINE INDENT i = i + 2 NEW_LINE j -= 1 NEW_LINE DEDENT
else : NEW_LINE INDENT while j >= 0 and i < n : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " ▁ " ) NEW_LINE k += 1 NEW_LINE i += 1 NEW_LINE j -= 1 NEW_LINE DEDENT DEDENT
if j < 0 and i <= n - 1 : NEW_LINE INDENT j = 0 NEW_LINE DEDENT if i == n : NEW_LINE INDENT j = j + 2 NEW_LINE i -= 1 NEW_LINE DEDENT
isUp = not isUp NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] NEW_LINE n = 3 NEW_LINE printMatrixDiagonal ( mat , n ) NEW_LINE DEDENT
mat = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 ] ] ; NEW_LINE
n = 4 NEW_LINE mode = 0 NEW_LINE it = 0 NEW_LINE lower = 0 NEW_LINE
for t in range ( 2 * n - 1 ) : NEW_LINE INDENT t1 = t NEW_LINE if ( t1 >= n ) : NEW_LINE INDENT mode += 1 NEW_LINE t1 = n - 1 NEW_LINE it -= 1 NEW_LINE lower += 1 NEW_LINE DEDENT else : NEW_LINE INDENT lower = 0 NEW_LINE it += 1 NEW_LINE DEDENT for i in range ( t1 , lower - 1 , - 1 ) : NEW_LINE INDENT if ( ( t1 + mode ) % 2 == 0 ) : NEW_LINE INDENT print ( ( mat [ i ] [ t1 + lower - i ] ) ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( mat [ t1 + lower - i ] [ i ] ) NEW_LINE DEDENT DEDENT DEDENT
def maxRowDiff ( mat , m , n ) : NEW_LINE
rowSum = [ 0 ] * m NEW_LINE
for i in range ( 0 , m ) : NEW_LINE INDENT sum = 0 NEW_LINE for j in range ( 0 , n ) : NEW_LINE INDENT sum += mat [ i ] [ j ] NEW_LINE DEDENT rowSum [ i ] = sum NEW_LINE DEDENT
max_diff = rowSum [ 1 ] - rowSum [ 0 ] NEW_LINE min_element = rowSum [ 0 ] NEW_LINE for i in range ( 1 , m ) : NEW_LINE
if ( rowSum [ i ] - min_element > max_diff ) : NEW_LINE INDENT max_diff = rowSum [ i ] - min_element NEW_LINE DEDENT
if ( rowSum [ i ] < min_element ) : NEW_LINE INDENT min_element = rowSum [ i ] NEW_LINE DEDENT return max_diff NEW_LINE
m = 5 NEW_LINE n = 4 NEW_LINE mat = [ [ - 1 , 2 , 3 , 4 ] , [ 5 , 3 , - 2 , 1 ] , [ 6 , 7 , 2 , - 3 ] , [ 2 , 9 , 1 , 4 ] , [ 2 , 1 , - 2 , 0 ] ] NEW_LINE print ( maxRowDiff ( mat , m , n ) ) NEW_LINE
R = 4 NEW_LINE C = 4 NEW_LINE
def getTotalCoverageOfMatrix ( mat ) : NEW_LINE INDENT res = 0 NEW_LINE DEDENT
for i in range ( R ) : NEW_LINE
isOne = False NEW_LINE
for j in range ( C ) : NEW_LINE
if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT isOne = True NEW_LINE DEDENT
elif ( isOne ) : NEW_LINE INDENT res += 1 NEW_LINE DEDENT
isOne = False NEW_LINE for j in range ( C - 1 , - 1 , - 1 ) : NEW_LINE INDENT if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT isOne = True NEW_LINE DEDENT elif ( isOne ) : NEW_LINE INDENT res += 1 NEW_LINE DEDENT DEDENT
for j in range ( C ) : NEW_LINE
isOne = False NEW_LINE for i in range ( R ) : NEW_LINE INDENT if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT isOne = True NEW_LINE DEDENT elif ( isOne ) : NEW_LINE INDENT res += 1 NEW_LINE DEDENT DEDENT isOne = False NEW_LINE for i in range ( R - 1 , - 1 , - 1 ) : NEW_LINE INDENT if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT isOne = True NEW_LINE DEDENT elif ( isOne ) : NEW_LINE INDENT res += 1 NEW_LINE DEDENT DEDENT return res NEW_LINE
mat = [ [ 0 , 0 , 0 , 0 ] , [ 1 , 0 , 0 , 1 ] , [ 0 , 1 , 1 , 0 ] , [ 0 , 1 , 0 , 0 ] ] NEW_LINE print ( getTotalCoverageOfMatrix ( mat ) ) NEW_LINE
R = 3 NEW_LINE C = 4 NEW_LINE
def gcd ( a , b ) : NEW_LINE INDENT if ( b == 0 ) : NEW_LINE INDENT return a NEW_LINE DEDENT return gcd ( b , a % b ) NEW_LINE DEDENT
def replacematrix ( mat , n , m ) : NEW_LINE INDENT rgcd = [ 0 ] * R NEW_LINE cgcd = [ 0 ] * C NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT rgcd [ i ] = gcd ( rgcd [ i ] , mat [ i ] [ j ] ) NEW_LINE cgcd [ j ] = gcd ( cgcd [ j ] , mat [ i ] [ j ] ) NEW_LINE DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT mat [ i ] [ j ] = max ( rgcd [ i ] , cgcd [ j ] ) NEW_LINE DEDENT DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT m = [ [ 1 , 2 , 3 , 3 ] , [ 4 , 5 , 6 , 6 ] , [ 7 , 8 , 9 , 9 ] ] NEW_LINE replacematrix ( m , R , C ) NEW_LINE for i in range ( R ) : NEW_LINE INDENT for j in range ( C ) : NEW_LINE INDENT print ( m [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
def sortedCount ( mat , r , c ) : NEW_LINE
result = 0 NEW_LINE
for i in range ( r ) : NEW_LINE
j = 0 NEW_LINE for j in range ( c - 1 ) : NEW_LINE INDENT if mat [ i ] [ j + 1 ] <= mat [ i ] [ j ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if j == c - 2 : NEW_LINE INDENT result += 1 NEW_LINE DEDENT
for i in range ( 0 , r ) : NEW_LINE
j = 0 NEW_LINE for j in range ( c - 1 , 0 , - 1 ) : NEW_LINE INDENT if mat [ i ] [ j - 1 ] <= mat [ i ] [ j ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if c > 1 and j == 1 : NEW_LINE INDENT result += 1 NEW_LINE DEDENT return result NEW_LINE
m , n = 4 , 5 NEW_LINE mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 4 , 3 , 1 , 2 , 6 ] , [ 8 , 7 , 6 , 5 , 4 ] , [ 5 , 7 , 8 , 9 , 10 ] ] NEW_LINE print ( sortedCount ( mat , m , n ) ) NEW_LINE
MAX = 1000 NEW_LINE
def maxXOR ( mat , N ) : NEW_LINE
max_xor = 0 NEW_LINE
for i in range ( N ) : NEW_LINE INDENT r_xor = 0 NEW_LINE c_xor = 0 NEW_LINE for j in range ( N ) : NEW_LINE DEDENT
r_xor = r_xor ^ mat [ i ] [ j ] NEW_LINE
c_xor = c_xor ^ mat [ j ] [ i ] NEW_LINE
if ( max_xor < max ( r_xor , c_xor ) ) : NEW_LINE INDENT max_xor = max ( r_xor , c_xor ) NEW_LINE DEDENT
return max_xor NEW_LINE
N = 3 NEW_LINE mat = [ [ 1 , 5 , 4 ] , [ 3 , 7 , 2 ] , [ 5 , 9 , 10 ] ] NEW_LINE print ( " maximum ▁ XOR ▁ value ▁ : ▁ " , maxXOR ( mat , N ) ) NEW_LINE
def direction ( R , C ) : NEW_LINE INDENT if ( R != C and R % 2 == 0 and C % 2 != 0 and R < C ) : NEW_LINE INDENT print ( " Left " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 == 0 and C % 2 == 0 and R > C ) : NEW_LINE INDENT print ( " Up " ) NEW_LINE return NEW_LINE DEDENT if R == C and R % 2 != 0 and C % 2 != 0 : NEW_LINE INDENT print ( " Right " ) NEW_LINE return NEW_LINE DEDENT if R == C and R % 2 == 0 and C % 2 == 0 : NEW_LINE INDENT print ( " Left " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 != 0 and C % 2 != 0 and R < C ) : NEW_LINE INDENT print ( " Right " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 != 0 and C % 2 != 0 and R > C ) : NEW_LINE INDENT print ( " Down " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 == 0 and C % 2 != 0 and R < C ) : NEW_LINE INDENT print ( " Left " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 == 0 and C % 2 == 0 and R > C ) : NEW_LINE INDENT print ( " Up " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 != 0 and C % 2 != 0 and R > C ) : NEW_LINE INDENT print ( " Down " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 != 0 and C % 2 != 0 and R < C ) : NEW_LINE INDENT print ( " Right " ) NEW_LINE return NEW_LINE DEDENT DEDENT
R = 3 ; C = 1 NEW_LINE direction ( R , C ) NEW_LINE
R = 3 NEW_LINE C = 6 NEW_LINE def spiralPrint ( m , n , a , c ) : NEW_LINE INDENT k = 0 NEW_LINE l = 0 NEW_LINE count = 0 NEW_LINE DEDENT
while ( k < m and l < n ) : NEW_LINE
for i in range ( l , n ) : NEW_LINE INDENT count += 1 NEW_LINE if ( count == c ) : NEW_LINE INDENT print ( a [ k ] [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT k += 1 NEW_LINE
for i in range ( k , m ) : NEW_LINE INDENT count += 1 NEW_LINE if ( count == c ) : NEW_LINE INDENT print ( a [ i ] [ n - 1 ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT n -= 1 NEW_LINE
if ( k < m ) : NEW_LINE INDENT for i in range ( n - 1 , l - 1 , - 1 ) : NEW_LINE INDENT count += 1 NEW_LINE if ( count == c ) : NEW_LINE INDENT print ( a [ m - 1 ] [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT m -= 1 NEW_LINE DEDENT
if ( l < n ) : NEW_LINE INDENT for i in range ( m - 1 , k - 1 , - 1 ) : NEW_LINE INDENT count += 1 NEW_LINE if ( count == c ) : NEW_LINE INDENT print ( a [ i ] [ l ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT l += 1 NEW_LINE DEDENT
a = [ [ 1 , 2 , 3 , 4 , 5 , 6 ] , [ 7 , 8 , 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 , 17 , 18 ] ] NEW_LINE k = 17 NEW_LINE spiralPrint ( R , C , a , k ) NEW_LINE
MAX = 100 NEW_LINE
def findK ( A , n , m , k ) : NEW_LINE INDENT if ( n < 1 or m < 1 ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT DEDENT
if ( k <= m ) : NEW_LINE INDENT return A [ 0 ] [ k - 1 ] NEW_LINE DEDENT
if ( k <= ( m + n - 1 ) ) : NEW_LINE INDENT return A [ ( k - m ) ] [ m - 1 ] NEW_LINE DEDENT
if ( k <= ( m + n - 1 + m - 1 ) ) : NEW_LINE INDENT return A [ n - 1 ] [ m - 1 - ( k - ( m + n - 1 ) ) ] NEW_LINE DEDENT
if ( k <= ( m + n - 1 + m - 1 + n - 2 ) ) : NEW_LINE INDENT return A [ n - 1 - ( k - ( m + n - 1 + m - 1 ) ) ] [ 0 ] NEW_LINE DEDENT
A . pop ( 0 ) NEW_LINE [ j . pop ( 0 ) for j in A ] NEW_LINE return findK ( A , n - 2 , m - 2 , k - ( 2 * n + 2 * m - 4 ) ) NEW_LINE
a = [ [ 1 , 2 , 3 , 4 , 5 , 6 ] , [ 7 , 8 , 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 , 17 , 18 ] ] NEW_LINE k = 17 NEW_LINE print ( findK ( a , 3 , 6 , k ) ) NEW_LINE
N = 5 NEW_LINE M = 4 NEW_LINE
def checkDiagonal ( mat , i , j ) : NEW_LINE INDENT res = mat [ i ] [ j ] NEW_LINE i += 1 NEW_LINE j += 1 NEW_LINE while ( i < N and j < M ) : NEW_LINE DEDENT
if ( mat [ i ] [ j ] != res ) : NEW_LINE INDENT return False NEW_LINE DEDENT i += 1 NEW_LINE j += 1 NEW_LINE
return True NEW_LINE
def isToeplitz ( mat ) : NEW_LINE
for j in range ( M ) : NEW_LINE
if not ( checkDiagonal ( mat , 0 , j ) ) : NEW_LINE INDENT return False NEW_LINE DEDENT
for i in range ( 1 , N ) : NEW_LINE
if not ( checkDiagonal ( mat , i , 0 ) ) : NEW_LINE INDENT return False NEW_LINE DEDENT
return True NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 6 , 7 , 8 , 9 ] , [ 4 , 6 , 7 , 8 ] , [ 1 , 4 , 6 , 7 ] , [ 0 , 1 , 4 , 6 ] , [ 2 , 0 , 1 , 4 ] ] NEW_LINE DEDENT
if ( isToeplitz ( mat ) ) : NEW_LINE INDENT print ( " Matrix ▁ is ▁ a ▁ Toeplitz " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Matrix ▁ is ▁ not ▁ a ▁ Toeplitz " ) NEW_LINE DEDENT
N = 5 ; NEW_LINE
def countZeroes ( mat ) : NEW_LINE
row = N - 1 ; NEW_LINE col = 0 ; NEW_LINE
count = 0 ; NEW_LINE while ( col < N ) : NEW_LINE
while ( mat [ row ] [ col ] ) : NEW_LINE
if ( row < 0 ) : NEW_LINE INDENT return count ; NEW_LINE DEDENT row = row - 1 ; NEW_LINE
count = count + ( row + 1 ) ; NEW_LINE
col = col + 1 ; NEW_LINE return count ; NEW_LINE
mat = [ [ 0 , 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 0 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] ] ; NEW_LINE print ( countZeroes ( mat ) ) ; NEW_LINE
def countNegative ( M , n , m ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT if M [ i ] [ j ] < 0 : NEW_LINE INDENT count += 1 NEW_LINE DEDENT else : NEW_LINE DEDENT DEDENT
break NEW_LINE return count NEW_LINE
M = [ [ - 3 , - 2 , - 1 , 1 ] , [ - 2 , 2 , 3 , 4 ] , [ 4 , 5 , 7 , 8 ] ] NEW_LINE print ( countNegative ( M , 3 , 4 ) ) NEW_LINE
def countNegative ( M , n , m ) : NEW_LINE
count = 0 NEW_LINE
i = 0 NEW_LINE j = m - 1 NEW_LINE
while j >= 0 and i < n : NEW_LINE INDENT if M [ i ] [ j ] < 0 : NEW_LINE DEDENT
count += ( j + 1 ) NEW_LINE
i += 1 NEW_LINE else : NEW_LINE
j -= 1 NEW_LINE return count NEW_LINE
M = [ [ - 3 , - 2 , - 1 , 1 ] , [ - 2 , 2 , 3 , 4 ] , [ 4 , 5 , 7 , 8 ] ] NEW_LINE print ( countNegative ( M , 3 , 4 ) ) NEW_LINE
class Node ( object ) : NEW_LINE INDENT def __init__ ( self , item ) : NEW_LINE INDENT self . data = item NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def BTToDLLUtil ( root ) : NEW_LINE
if root is None : NEW_LINE INDENT return root NEW_LINE DEDENT
if root . left : NEW_LINE
left = BTToDLLUtil ( root . left ) NEW_LINE
while left . right : NEW_LINE INDENT left = left . right NEW_LINE DEDENT
left . right = root NEW_LINE
root . left = left NEW_LINE
if root . right : NEW_LINE
right = BTToDLLUtil ( root . right ) NEW_LINE
while right . left : NEW_LINE INDENT right = right . left NEW_LINE DEDENT
right . left = root NEW_LINE
root . right = right NEW_LINE return root NEW_LINE
def BTToDLL ( root ) : NEW_LINE
if root is None : NEW_LINE INDENT return root NEW_LINE DEDENT
root = BTToDLLUtil ( root ) NEW_LINE
while root . left : NEW_LINE INDENT root = root . left NEW_LINE DEDENT return root NEW_LINE
def print_list ( head ) : NEW_LINE INDENT if head is None : NEW_LINE INDENT return NEW_LINE DEDENT while head : NEW_LINE INDENT print ( head . data , end = " ▁ " ) NEW_LINE head = head . right NEW_LINE DEDENT DEDENT
root = Node ( 10 ) NEW_LINE root . left = Node ( 12 ) NEW_LINE root . right = Node ( 15 ) NEW_LINE root . left . left = Node ( 25 ) NEW_LINE root . left . right = Node ( 30 ) NEW_LINE root . right . left = Node ( 36 ) NEW_LINE
head = BTToDLL ( root ) NEW_LINE
print_list ( head ) NEW_LINE
N = 10 NEW_LINE
def findLargestPlus ( mat ) : NEW_LINE
left = [ [ 0 for x in range ( N ) ] for y in range ( N ) ] NEW_LINE right = [ [ 0 for x in range ( N ) ] for y in range ( N ) ] NEW_LINE top = [ [ 0 for x in range ( N ) ] for y in range ( N ) ] NEW_LINE bottom = [ [ 0 for x in range ( N ) ] for y in range ( N ) ] NEW_LINE
for i in range ( N ) : NEW_LINE
top [ 0 ] [ i ] = mat [ 0 ] [ i ] NEW_LINE
bottom [ N - 1 ] [ i ] = mat [ N - 1 ] [ i ] NEW_LINE
left [ i ] [ 0 ] = mat [ i ] [ 0 ] NEW_LINE
right [ i ] [ N - 1 ] = mat [ i ] [ N - 1 ] NEW_LINE
for i in range ( N ) : NEW_LINE INDENT for j in range ( 1 , N ) : NEW_LINE DEDENT
if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT left [ i ] [ j ] = left [ i ] [ j - 1 ] + 1 NEW_LINE DEDENT else : NEW_LINE INDENT left [ i ] [ j ] = 0 NEW_LINE DEDENT
if ( mat [ j ] [ i ] == 1 ) : NEW_LINE INDENT top [ j ] [ i ] = top [ j - 1 ] [ i ] + 1 NEW_LINE DEDENT else : NEW_LINE INDENT top [ j ] [ i ] = 0 NEW_LINE DEDENT
j = N - 1 - j NEW_LINE
if ( mat [ j ] [ i ] == 1 ) : NEW_LINE INDENT bottom [ j ] [ i ] = bottom [ j + 1 ] [ i ] + 1 NEW_LINE DEDENT else : NEW_LINE INDENT bottom [ j ] [ i ] = 0 NEW_LINE DEDENT
if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT right [ i ] [ j ] = right [ i ] [ j + 1 ] + 1 NEW_LINE DEDENT else : NEW_LINE INDENT right [ i ] [ j ] = 0 NEW_LINE DEDENT
j = N - 1 - j NEW_LINE
n = 0 NEW_LINE
for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE DEDENT
l = min ( min ( top [ i ] [ j ] , bottom [ i ] [ j ] ) , min ( left [ i ] [ j ] , right [ i ] [ j ] ) ) NEW_LINE
if ( l > n ) : NEW_LINE INDENT n = l NEW_LINE DEDENT
if ( n ) : NEW_LINE INDENT return 4 * ( n - 1 ) + 1 NEW_LINE DEDENT
return 0 NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 ] , [ 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 ] , [ 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 ] , [ 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 ] , [ 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 ] , [ 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 ] , [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 ] , [ 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 ] , [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 ] ] NEW_LINE print ( findLargestPlus ( mat ) ) NEW_LINE DEDENT
def findLeft ( str ) : NEW_LINE INDENT n = len ( str ) - 1 ; NEW_LINE DEDENT
while ( n > 0 ) : NEW_LINE
if ( str [ n ] == ' d ' ) : NEW_LINE INDENT str = str [ 0 : n ] + ' c ' + str [ n + 1 : ] ; NEW_LINE break ; NEW_LINE DEDENT if ( str [ n ] == ' b ' ) : NEW_LINE INDENT str = str [ 0 : n ] + ' a ' + str [ n + 1 : ] ; NEW_LINE break ; NEW_LINE DEDENT
if ( str [ n ] == ' a ' ) : NEW_LINE INDENT str = str [ 0 : n ] + ' b ' + str [ n + 1 : ] ; NEW_LINE DEDENT elif ( str [ n ] == ' c ' ) : NEW_LINE INDENT str = str [ 0 : n ] + ' d ' + str [ n + 1 : ] ; NEW_LINE DEDENT n -= 1 ; NEW_LINE return str ; NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT str = " aacbddc " ; NEW_LINE print ( " Left ▁ of " , str , " is " , findLeft ( str ) ) ; NEW_LINE DEDENT
def printSpiral ( n ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT DEDENT
x = min ( min ( i , j ) , min ( n - 1 - i , n - 1 - j ) ) NEW_LINE
if ( i <= j ) : NEW_LINE INDENT print ( ( n - 2 * x ) * ( n - 2 * x ) - ( i - x ) - ( j - x ) , end = " TABSYMBOL " ) NEW_LINE DEDENT
else : NEW_LINE INDENT print ( ( ( n - 2 * x - 2 ) * ( n - 2 * x - 2 ) + ( i - x ) + ( j - x ) ) , end = " TABSYMBOL " ) NEW_LINE DEDENT print ( ) NEW_LINE
n = 5 NEW_LINE
printSpiral ( n ) NEW_LINE
def findMaxValue ( mat ) : NEW_LINE
maxValue = 0 NEW_LINE
for a in range ( N - 1 ) : NEW_LINE INDENT for b in range ( N - 1 ) : NEW_LINE INDENT for d in range ( a + 1 , N ) : NEW_LINE INDENT for e in range ( b + 1 , N ) : NEW_LINE INDENT if maxValue < int ( mat [ d ] [ e ] - mat [ a ] [ b ] ) : NEW_LINE INDENT maxValue = int ( mat [ d ] [ e ] - mat [ a ] [ b ] ) ; NEW_LINE DEDENT DEDENT DEDENT DEDENT DEDENT return maxValue ; NEW_LINE
mat = [ [ 1 , 2 , - 1 , - 4 , - 20 ] , [ - 8 , - 3 , 4 , 2 , 1 ] , [ 3 , 8 , 6 , 1 , 3 ] , [ - 4 , - 1 , 1 , 7 , - 6 ] , [ 0 , - 4 , 10 , - 5 , 1 ] ] ; NEW_LINE print ( " Maximum ▁ Value ▁ is ▁ " + str ( findMaxValue ( mat ) ) ) NEW_LINE
def findMaxValue ( mat ) : NEW_LINE
maxValue = - sys . maxsize - 1 NEW_LINE
maxArr = [ [ 0 for x in range ( N ) ] for y in range ( N ) ] NEW_LINE
maxArr [ N - 1 ] [ N - 1 ] = mat [ N - 1 ] [ N - 1 ] NEW_LINE
maxv = mat [ N - 1 ] [ N - 1 ] ; NEW_LINE for j in range ( N - 2 , - 1 , - 1 ) : NEW_LINE INDENT if ( mat [ N - 1 ] [ j ] > maxv ) : NEW_LINE INDENT maxv = mat [ N - 1 ] [ j ] NEW_LINE DEDENT maxArr [ N - 1 ] [ j ] = maxv NEW_LINE DEDENT
maxv = mat [ N - 1 ] [ N - 1 ] ; NEW_LINE for i in range ( N - 2 , - 1 , - 1 ) : NEW_LINE INDENT if ( mat [ i ] [ N - 1 ] > maxv ) : NEW_LINE INDENT maxv = mat [ i ] [ N - 1 ] NEW_LINE DEDENT maxArr [ i ] [ N - 1 ] = maxv NEW_LINE DEDENT
for i in range ( N - 2 , - 1 , - 1 ) : NEW_LINE INDENT for j in range ( N - 2 , - 1 , - 1 ) : NEW_LINE DEDENT
if ( maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] > maxValue ) : NEW_LINE INDENT maxValue = ( maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] ) NEW_LINE DEDENT
maxArr [ i ] [ j ] = max ( mat [ i ] [ j ] , max ( maxArr [ i ] [ j + 1 ] , maxArr [ i + 1 ] [ j ] ) ) NEW_LINE return maxValue NEW_LINE
mat = [ [ 1 , 2 , - 1 , - 4 , - 20 ] , [ - 8 , - 3 , 4 , 2 , 1 ] , [ 3 , 8 , 6 , 1 , 3 ] , [ - 4 , - 1 , 1 , 7 , - 6 ] , [ 0 , - 4 , 10 , - 5 , 1 ] ] NEW_LINE print ( " Maximum ▁ Value ▁ is " , findMaxValue ( mat ) ) NEW_LINE
R = 3 NEW_LINE C = 4 NEW_LINE def modifyMatrix ( mat ) : NEW_LINE INDENT row = [ 0 ] * R NEW_LINE col = [ 0 ] * C NEW_LINE DEDENT
for i in range ( 0 , R ) : NEW_LINE INDENT row [ i ] = 0 NEW_LINE DEDENT
for i in range ( 0 , C ) : NEW_LINE INDENT col [ i ] = 0 NEW_LINE DEDENT
for i in range ( 0 , R ) : NEW_LINE INDENT for j in range ( 0 , C ) : NEW_LINE INDENT if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT row [ i ] = 1 NEW_LINE col [ j ] = 1 NEW_LINE DEDENT DEDENT DEDENT
for i in range ( 0 , R ) : NEW_LINE INDENT for j in range ( 0 , C ) : NEW_LINE INDENT if ( row [ i ] == 1 or col [ j ] == 1 ) : NEW_LINE INDENT mat [ i ] [ j ] = 1 NEW_LINE DEDENT DEDENT DEDENT
def printMatrix ( mat ) : NEW_LINE INDENT for i in range ( 0 , R ) : NEW_LINE INDENT for j in range ( 0 , C ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
mat = [ [ 1 , 0 , 0 , 1 ] , [ 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 0 ] ] NEW_LINE print ( " Input ▁ Matrix ▁ n " ) NEW_LINE printMatrix ( mat ) NEW_LINE modifyMatrix ( mat ) NEW_LINE print ( " Matrix ▁ after ▁ modification ▁ n " ) NEW_LINE printMatrix ( mat ) NEW_LINE
ROW = 4 NEW_LINE COL = 5 NEW_LINE
def findUniqueRows ( M ) : NEW_LINE
for i in range ( ROW ) : NEW_LINE INDENT flag = 0 NEW_LINE DEDENT
for j in range ( i ) : NEW_LINE INDENT flag = 1 NEW_LINE for k in range ( COL ) : NEW_LINE INDENT if ( M [ i ] [ k ] != M [ j ] [ k ] ) : NEW_LINE INDENT flag = 0 NEW_LINE DEDENT DEDENT if ( flag == 1 ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if ( flag == 0 ) : NEW_LINE
for j in range ( COL ) : NEW_LINE INDENT print ( M [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT M = [ [ 0 , 1 , 0 , 0 , 1 ] , [ 1 , 0 , 1 , 1 , 0 ] , [ 0 , 1 , 0 , 0 , 1 ] , [ 1 , 0 , 1 , 0 , 0 ] ] NEW_LINE findUniqueRows ( M ) NEW_LINE DEDENT
class Node : NEW_LINE INDENT def __init__ ( self , data ) : NEW_LINE INDENT self . data = data NEW_LINE self . left = None NEW_LINE self . right = None NEW_LINE DEDENT DEDENT
def inorder ( root ) : NEW_LINE INDENT if root is not None : NEW_LINE INDENT inorder ( root . left ) NEW_LINE print " TABSYMBOL % d " % ( root . data ) , NEW_LINE inorder ( root . right ) NEW_LINE DEDENT DEDENT
def fixPrevPtr ( root ) : NEW_LINE INDENT if root is not None : NEW_LINE INDENT fixPrevPtr ( root . left ) NEW_LINE root . left = fixPrevPtr . pre NEW_LINE fixPrevPtr . pre = root NEW_LINE fixPrevPtr ( root . right ) NEW_LINE DEDENT DEDENT
def fixNextPtr ( root ) : NEW_LINE INDENT prev = None NEW_LINE DEDENT
while ( root and root . right != None ) : NEW_LINE INDENT root = root . right NEW_LINE DEDENT
while ( root and root . left != None ) : NEW_LINE INDENT prev = root NEW_LINE root = root . left NEW_LINE root . right = prev NEW_LINE DEDENT
return root NEW_LINE
def BTToDLL ( root ) : NEW_LINE
fixPrevPtr ( root ) NEW_LINE
return fixNextPtr ( root ) NEW_LINE
def printList ( root ) : NEW_LINE INDENT while ( root != None ) : NEW_LINE INDENT print " TABSYMBOL % d " % ( root . data ) , NEW_LINE root = root . right NEW_LINE DEDENT DEDENT
root = Node ( 10 ) NEW_LINE root . left = Node ( 12 ) NEW_LINE root . right = Node ( 15 ) NEW_LINE root . left . left = Node ( 25 ) NEW_LINE root . left . right = Node ( 30 ) NEW_LINE root . right . left = Node ( 36 ) NEW_LINE print   " NEW_LINE INDENT Inorder Tree Traversal NEW_LINE DEDENT " NEW_LINE inorder ( root ) NEW_LINE fixPrevPtr . pre = None NEW_LINE head = BTToDLL ( root ) NEW_LINE print   " NEW_LINE INDENT DLL Traversal NEW_LINE DEDENT " NEW_LINE printList ( head ) NEW_LINE
class rankMatrix ( object ) : NEW_LINE INDENT def __init__ ( self , Matrix ) : NEW_LINE INDENT self . R = len ( Matrix ) NEW_LINE self . C = len ( Matrix [ 0 ] ) NEW_LINE DEDENT DEDENT
def swap ( self , Matrix , row1 , row2 , col ) : NEW_LINE INDENT for i in range ( col ) : NEW_LINE INDENT temp = Matrix [ row1 ] [ i ] NEW_LINE Matrix [ row1 ] [ i ] = Matrix [ row2 ] [ i ] NEW_LINE Matrix [ row2 ] [ i ] = temp NEW_LINE DEDENT DEDENT
def rankOfMatrix ( self , Matrix ) : NEW_LINE INDENT rank = self . C NEW_LINE for row in range ( 0 , rank , 1 ) : NEW_LINE DEDENT
if Matrix [ row ] [ row ] != 0 : NEW_LINE INDENT for col in range ( 0 , self . R , 1 ) : NEW_LINE INDENT if col != row : NEW_LINE DEDENT DEDENT
multiplier = ( Matrix [ col ] [ row ] / Matrix [ row ] [ row ] ) NEW_LINE for i in range ( rank ) : NEW_LINE INDENT Matrix [ col ] [ i ] -= ( multiplier * Matrix [ row ] [ i ] ) NEW_LINE DEDENT
else : NEW_LINE INDENT reduce = True NEW_LINE DEDENT
for i in range ( row + 1 , self . R , 1 ) : NEW_LINE
if Matrix [ i ] [ row ] != 0 : NEW_LINE INDENT self . swap ( Matrix , row , i , rank ) NEW_LINE reduce = False NEW_LINE break NEW_LINE DEDENT
if reduce : NEW_LINE
rank -= 1 NEW_LINE
for i in range ( 0 , self . R , 1 ) : NEW_LINE INDENT Matrix [ i ] [ row ] = Matrix [ i ] [ rank ] NEW_LINE DEDENT
row -= 1 NEW_LINE
return ( rank ) NEW_LINE
def Display ( self , Matrix , row , col ) : NEW_LINE INDENT for i in range ( row ) : NEW_LINE INDENT for j in range ( col ) : NEW_LINE INDENT print ( " ▁ " + str ( Matrix [ i ] [ j ] ) ) NEW_LINE DEDENT print ( ' ' ) NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT Matrix = [ [ 10 , 20 , 10 ] , [ - 20 , - 30 , 10 ] , [ 30 , 50 , 0 ] ] NEW_LINE RankMatrix = rankMatrix ( Matrix ) NEW_LINE print ( " Rank ▁ of ▁ the ▁ Matrix ▁ is : " , ( RankMatrix . rankOfMatrix ( Matrix ) ) ) NEW_LINE DEDENT
class Cell : NEW_LINE INDENT def __init__ ( self , r , c ) : NEW_LINE DEDENT
def printSums ( mat , arr , n ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT Sum = 0 ; r = arr [ i ] . r ; c = arr [ i ] . c NEW_LINE DEDENT
for j in range ( 0 , R ) : NEW_LINE INDENT for k in range ( 0 , C ) : NEW_LINE INDENT if j != r and k != c : NEW_LINE INDENT Sum += mat [ j ] [ k ] NEW_LINE DEDENT DEDENT DEDENT print ( Sum ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 1 , 2 ] , [ 3 , 4 , 6 ] , [ 5 , 3 , 2 ] ] NEW_LINE R = C = 3 NEW_LINE arr = [ Cell ( 0 , 0 ) , Cell ( 1 , 1 ) , Cell ( 0 , 1 ) ] NEW_LINE n = len ( arr ) NEW_LINE printSums ( mat , arr , n ) NEW_LINE DEDENT
def countIslands ( mat ) : NEW_LINE
count = 0 ; NEW_LINE
for i in range ( 0 , M ) : NEW_LINE INDENT for j in range ( 0 , N ) : NEW_LINE DEDENT
if ( mat [ i ] [ j ] == ' X ' ) : NEW_LINE INDENT if ( ( i == 0 or mat [ i - 1 ] [ j ] == ' O ' ) and ( j == 0 or mat [ i ] [ j - 1 ] == ' O ' ) ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
M = 6 NEW_LINE N = 3 NEW_LINE mat = [ [ ' O ' , ' O ' , ' O ' ] , [ ' X ' , ' X ' , ' O ' ] , [ ' X ' , ' X ' , ' O ' ] , [ ' O ' , ' O ' , ' X ' ] , [ ' O ' , ' O ' , ' X ' ] , [ ' X ' , ' X ' , ' O ' ] ] NEW_LINE print ( " Number ▁ of ▁ rectangular ▁ islands ▁ is " , countIslands ( mat ) ) NEW_LINE
M = 4 NEW_LINE N = 5 NEW_LINE
def findCommon ( mat ) : NEW_LINE
column = [ N - 1 ] * M NEW_LINE
min_row = 0 NEW_LINE
while ( column [ min_row ] >= 0 ) : NEW_LINE
for i in range ( M ) : NEW_LINE INDENT if ( mat [ i ] [ column [ i ] ] < mat [ min_row ] [ column [ min_row ] ] ) : NEW_LINE INDENT min_row = i NEW_LINE DEDENT DEDENT
eq_count = 0 NEW_LINE
for i in range ( M ) : NEW_LINE
if ( mat [ i ] [ column [ i ] ] > mat [ min_row ] [ column [ min_row ] ] ) : NEW_LINE INDENT if ( column [ i ] == 0 ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT DEDENT
column [ i ] -= 1 NEW_LINE else : NEW_LINE eq_count += 1 NEW_LINE
if ( eq_count == M ) : NEW_LINE INDENT return mat [ min_row ] [ column [ min_row ] ] NEW_LINE DEDENT return - 1 NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 2 , 4 , 5 , 8 , 10 ] , [ 3 , 5 , 7 , 9 , 11 ] , [ 1 , 3 , 5 , 7 , 9 ] ] NEW_LINE result = findCommon ( mat ) NEW_LINE if ( result == - 1 ) : NEW_LINE INDENT print ( " No ▁ common ▁ element " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Common ▁ element ▁ is " , result ) NEW_LINE DEDENT DEDENT
M = 4 NEW_LINE N = 5 NEW_LINE
def findCommon ( mat ) : NEW_LINE INDENT global M NEW_LINE global N NEW_LINE DEDENT
cnt = dict ( ) NEW_LINE cnt = defaultdict ( lambda : 0 , cnt ) NEW_LINE i = 0 NEW_LINE j = 0 NEW_LINE while ( i < M ) : NEW_LINE
cnt [ mat [ i ] [ 0 ] ] = cnt [ mat [ i ] [ 0 ] ] + 1 NEW_LINE j = 1 NEW_LINE
while ( j < N ) : NEW_LINE
if ( mat [ i ] [ j ] != mat [ i ] [ j - 1 ] ) : NEW_LINE INDENT cnt [ mat [ i ] [ j ] ] = cnt [ mat [ i ] [ j ] ] + 1 NEW_LINE DEDENT j = j + 1 NEW_LINE i = i + 1 NEW_LINE
for ele in cnt : NEW_LINE INDENT if ( cnt [ ele ] == M ) : NEW_LINE INDENT return ele NEW_LINE DEDENT DEDENT
return - 1 NEW_LINE
mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 2 , 4 , 5 , 8 , 10 ] , [ 3 , 5 , 7 , 9 , 11 ] , [ 1 , 3 , 5 , 7 , 9 ] , ] NEW_LINE result = findCommon ( mat ) NEW_LINE if ( result == - 1 ) : NEW_LINE INDENT print ( " No ▁ common ▁ element " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Common ▁ element ▁ is ▁ " , result ) NEW_LINE DEDENT
M = 6 NEW_LINE N = 6 NEW_LINE
def floodFillUtil ( mat , x , y , prevV , newV ) : NEW_LINE
if ( x < 0 or x >= M or y < 0 or y >= N ) : NEW_LINE INDENT return NEW_LINE DEDENT if ( mat [ x ] [ y ] != prevV ) : NEW_LINE INDENT return NEW_LINE DEDENT
mat [ x ] [ y ] = newV NEW_LINE
floodFillUtil ( mat , x + 1 , y , prevV , newV ) NEW_LINE floodFillUtil ( mat , x - 1 , y , prevV , newV ) NEW_LINE floodFillUtil ( mat , x , y + 1 , prevV , newV ) NEW_LINE floodFillUtil ( mat , x , y - 1 , prevV , newV ) NEW_LINE
def replaceSurrounded ( mat ) : NEW_LINE
for i in range ( M ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT if ( mat [ i ] [ j ] == ' O ' ) : NEW_LINE INDENT mat [ i ] [ j ] = ' - ' NEW_LINE DEDENT DEDENT DEDENT
for i in range ( M ) : NEW_LINE INDENT if ( mat [ i ] [ 0 ] == ' - ' ) : NEW_LINE INDENT floodFillUtil ( mat , i , 0 , ' - ' , ' O ' ) NEW_LINE DEDENT DEDENT
for i in range ( M ) : NEW_LINE INDENT if ( mat [ i ] [ N - 1 ] == ' - ' ) : NEW_LINE INDENT floodFillUtil ( mat , i , N - 1 , ' - ' , ' O ' ) NEW_LINE DEDENT DEDENT
for i in range ( N ) : NEW_LINE INDENT if ( mat [ 0 ] [ i ] == ' - ' ) : NEW_LINE INDENT floodFillUtil ( mat , 0 , i , ' - ' , ' O ' ) NEW_LINE DEDENT DEDENT
for i in range ( N ) : NEW_LINE INDENT if ( mat [ M - 1 ] [ i ] == ' - ' ) : NEW_LINE INDENT floodFillUtil ( mat , M - 1 , i , ' - ' , ' O ' ) NEW_LINE DEDENT DEDENT
for i in range ( M ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT if ( mat [ i ] [ j ] == ' - ' ) : NEW_LINE INDENT mat [ i ] [ j ] = ' X ' NEW_LINE DEDENT DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT mat = [ [ ' X ' , ' O ' , ' X ' , ' O ' , ' X ' , ' X ' ] , [ ' X ' , ' O ' , ' X ' , ' X ' , ' O ' , ' X ' ] , [ ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' X ' ] , [ ' O ' , ' X ' , ' X ' , ' X ' , ' X ' , ' X ' ] , [ ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' O ' ] , [ ' O ' , ' O ' , ' X ' , ' O ' , ' O ' , ' O ' ] ] ; NEW_LINE replaceSurrounded ( mat ) NEW_LINE for i in range ( M ) : NEW_LINE INDENT print ( * mat [ i ] ) NEW_LINE DEDENT DEDENT
import sys NEW_LINE INF = sys . maxsize NEW_LINE N = 4 NEW_LINE
def youngify ( mat , i , j ) : NEW_LINE
downVal = mat [ i + 1 ] [ j ] if ( i + 1 < N ) else INF NEW_LINE rightVal = mat [ i ] [ j + 1 ] if ( j + 1 < N ) else INF NEW_LINE
if ( downVal == INF and rightVal == INF ) : NEW_LINE INDENT return NEW_LINE DEDENT
if ( downVal < rightVal ) : NEW_LINE INDENT mat [ i ] [ j ] = downVal NEW_LINE mat [ i + 1 ] [ j ] = INF NEW_LINE youngify ( mat , i + 1 , j ) NEW_LINE DEDENT else : NEW_LINE INDENT mat [ i ] [ j ] = rightVal NEW_LINE mat [ i ] [ j + 1 ] = INF NEW_LINE youngify ( mat , i , j + 1 ) NEW_LINE DEDENT
def extractMin ( mat ) : NEW_LINE INDENT ret = mat [ 0 ] [ 0 ] NEW_LINE mat [ 0 ] [ 0 ] = INF NEW_LINE youngify ( mat , 0 , 0 ) NEW_LINE return ret NEW_LINE DEDENT
def printSorted ( mat ) : NEW_LINE INDENT print ( " Elements ▁ of ▁ matrix ▁ in ▁ sorted ▁ order ▁ n " ) NEW_LINE i = 0 NEW_LINE while i < N * N : NEW_LINE INDENT print ( extractMin ( mat ) , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE DEDENT DEDENT
n = 5 NEW_LINE
def printSumSimple ( mat , k ) : NEW_LINE
if ( k > n ) : NEW_LINE INDENT return NEW_LINE DEDENT
for i in range ( n - k + 1 ) : NEW_LINE
for j in range ( n - k + 1 ) : NEW_LINE
sum = 0 NEW_LINE for p in range ( i , k + i ) : NEW_LINE INDENT for q in range ( j , k + j ) : NEW_LINE INDENT sum += mat [ p ] [ q ] NEW_LINE DEDENT DEDENT print ( sum , end = " ▁ " ) NEW_LINE
print ( ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] NEW_LINE k = 3 NEW_LINE printSumSimple ( mat , k ) NEW_LINE DEDENT
n = 5 NEW_LINE
def printSumTricky ( mat , k ) : NEW_LINE INDENT global n NEW_LINE DEDENT
if k > n : NEW_LINE INDENT return NEW_LINE DEDENT
stripSum = [ [ None ] * n for i in range ( n ) ] NEW_LINE
for j in range ( n ) : NEW_LINE
Sum = 0 NEW_LINE for i in range ( k ) : NEW_LINE INDENT Sum += mat [ i ] [ j ] NEW_LINE DEDENT stripSum [ 0 ] [ j ] = Sum NEW_LINE
for i in range ( 1 , n - k + 1 ) : NEW_LINE INDENT Sum += ( mat [ i + k - 1 ] [ j ] - mat [ i - 1 ] [ j ] ) NEW_LINE stripSum [ i ] [ j ] = Sum NEW_LINE DEDENT
for i in range ( n - k + 1 ) : NEW_LINE
Sum = 0 NEW_LINE for j in range ( k ) : NEW_LINE INDENT Sum += stripSum [ i ] [ j ] NEW_LINE DEDENT print ( Sum , end = " ▁ " ) NEW_LINE
for j in range ( 1 , n - k + 1 ) : NEW_LINE INDENT Sum += ( stripSum [ i ] [ j + k - 1 ] - stripSum [ i ] [ j - 1 ] ) NEW_LINE print ( Sum , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE
mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] NEW_LINE k = 3 NEW_LINE printSumTricky ( mat , k ) NEW_LINE
M = 3 NEW_LINE N = 4 NEW_LINE
def transpose ( A , B ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE INDENT B [ i ] [ j ] = A [ j ] [ i ] NEW_LINE DEDENT DEDENT DEDENT
A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] ] NEW_LINE B = [ [ 0 for x in range ( M ) ] for y in range ( N ) ] NEW_LINE transpose ( A , B ) NEW_LINE print ( " Result ▁ matrix ▁ is " ) NEW_LINE for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE INDENT print ( B [ i ] [ j ] , " ▁ " , end = ' ' ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
N = 4 NEW_LINE
def transpose ( A ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( i + 1 , N ) : NEW_LINE INDENT A [ i ] [ j ] , A [ j ] [ i ] = A [ j ] [ i ] , A [ i ] [ j ] NEW_LINE DEDENT DEDENT DEDENT
A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] NEW_LINE transpose ( A ) NEW_LINE print ( " Modified ▁ matrix ▁ is " ) NEW_LINE for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT print ( A [ i ] [ j ] , " ▁ " , end = ' ' ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
R = 5 NEW_LINE C = 4 NEW_LINE intmin = - 10000000 NEW_LINE intmax = 10000000 NEW_LINE
def isValid ( x , y1 , y2 ) : NEW_LINE INDENT return ( ( x >= 0 and x < R and y1 >= 0 and y1 < C and y2 >= 0 and y2 < C ) ) NEW_LINE DEDENT
def getMaxUtil ( arr , mem , x , y1 , y2 ) : NEW_LINE
if isValid ( x , y1 , y2 ) == False : NEW_LINE INDENT return intmin NEW_LINE DEDENT
if x == R - 1 and y1 == 0 and y2 == C - 1 : NEW_LINE INDENT if y1 == y2 : NEW_LINE INDENT return arr [ x ] [ y1 ] NEW_LINE DEDENT else : NEW_LINE INDENT return arr [ x ] [ y1 ] + arr [ x ] [ y2 ] NEW_LINE DEDENT DEDENT
if x == R - 1 : NEW_LINE INDENT return intmin NEW_LINE DEDENT
if mem [ x ] [ y1 ] [ y2 ] != - 1 : NEW_LINE INDENT return mem [ x ] [ y1 ] [ y2 ] NEW_LINE DEDENT
ans = intmin NEW_LINE
temp = 0 NEW_LINE if y1 == y2 : NEW_LINE INDENT temp = arr [ x ] [ y1 ] NEW_LINE DEDENT else : NEW_LINE INDENT temp = arr [ x ] [ y1 ] + arr [ x ] [ y2 ] NEW_LINE DEDENT
ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 - 1 ) ) NEW_LINE ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 + 1 ) ) NEW_LINE ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 ) ) NEW_LINE ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 ) ) NEW_LINE ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 - 1 ) ) NEW_LINE ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 + 1 ) ) NEW_LINE ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 ) ) NEW_LINE ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 - 1 ) ) NEW_LINE ans = max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 + 1 ) ) NEW_LINE mem [ x ] [ y1 ] [ y2 ] = ans NEW_LINE return ans NEW_LINE
def geMaxCollection ( arr ) : NEW_LINE
mem = [ [ [ - 1 for i in range ( C ) ] for i in range ( C ) ] for i in range ( R ) ] NEW_LINE
return getMaxUtil ( arr , mem , 0 , 0 , C - 1 ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ [ 3 , 6 , 8 , 2 ] , [ 5 , 2 , 4 , 3 ] , [ 1 , 1 , 20 , 10 ] , [ 1 , 1 , 20 , 10 ] , [ 1 , 1 , 20 , 10 ] , ] NEW_LINE print ( ' Maximum ▁ collection ▁ is ▁ ' , geMaxCollection ( arr ) ) NEW_LINE DEDENT
R = 3 NEW_LINE C = 3 NEW_LINE
def pathCountRec ( mat , m , n , k ) : NEW_LINE
if m < 0 or n < 0 : NEW_LINE INDENT return 0 NEW_LINE DEDENT elif m == 0 and n == 0 : NEW_LINE INDENT return k == mat [ m ] [ n ] NEW_LINE DEDENT
return ( pathCountRec ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountRec ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ) NEW_LINE
def pathCount ( mat , k ) : NEW_LINE INDENT return pathCountRec ( mat , R - 1 , C - 1 , k ) NEW_LINE DEDENT
k = 12 NEW_LINE mat = [ [ 1 , 2 , 3 ] , [ 4 , 6 , 5 ] , [ 3 , 2 , 1 ] ] NEW_LINE print ( pathCount ( mat , k ) ) NEW_LINE
R = 3 NEW_LINE C = 3 NEW_LINE MAX_K = 1000 NEW_LINE def pathCountDPRecDP ( mat , m , n , k ) : NEW_LINE
if m < 0 or n < 0 : NEW_LINE INDENT return 0 NEW_LINE DEDENT elif m == 0 and n == 0 : NEW_LINE INDENT return k == mat [ m ] [ n ] NEW_LINE DEDENT
if ( dp [ m ] [ n ] [ k ] != - 1 ) : NEW_LINE INDENT return dp [ m ] [ n ] [ k ] NEW_LINE DEDENT
dp [ m ] [ n ] [ k ] = ( pathCountDPRecDP ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountDPRecDP ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ) NEW_LINE return dp [ m ] [ n ] [ k ] NEW_LINE
def pathCountDP ( mat , k ) : NEW_LINE INDENT return pathCountDPRecDP ( mat , R - 1 , C - 1 , k ) NEW_LINE DEDENT
k = 12 NEW_LINE dp = [ [ [ - 1 for col in range ( MAX_K ) ] for col in range ( C ) ] for row in range ( R ) ] NEW_LINE mat = [ [ 1 , 2 , 3 ] , [ 4 , 6 , 5 ] , [ 3 , 2 , 1 ] ] NEW_LINE print ( pathCountDP ( mat , k ) ) NEW_LINE
x = [ 0 , 1 , 1 , - 1 , 1 , 0 , - 1 , - 1 ] NEW_LINE y = [ 1 , 0 , 1 , 1 , - 1 , - 1 , 0 , - 1 ] NEW_LINE
dp = [ [ 0 for i in range ( C ) ] for i in range ( R ) ] NEW_LINE
def isvalid ( i , j ) : NEW_LINE INDENT if ( i < 0 or j < 0 or i >= R or j >= C ) : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE DEDENT
def isadjacent ( prev , curr ) : NEW_LINE INDENT if ( ord ( curr ) - ord ( prev ) ) == 1 : NEW_LINE INDENT return True NEW_LINE DEDENT return False NEW_LINE DEDENT
def getLenUtil ( mat , i , j , prev ) : NEW_LINE
if ( isvalid ( i , j ) == False or isadjacent ( prev , mat [ i ] [ j ] ) == False ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( dp [ i ] [ j ] != - 1 ) : NEW_LINE INDENT return dp [ i ] [ j ] NEW_LINE DEDENT
ans = 0 NEW_LINE
for k in range ( 8 ) : NEW_LINE INDENT ans = max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , mat [ i ] [ j ] ) ) NEW_LINE DEDENT
dp [ i ] [ j ] = ans NEW_LINE return dp [ i ] [ j ] NEW_LINE
def getLen ( mat , s ) : NEW_LINE INDENT for i in range ( R ) : NEW_LINE INDENT for j in range ( C ) : NEW_LINE INDENT dp [ i ] [ j ] = - 1 NEW_LINE DEDENT DEDENT ans = 0 NEW_LINE for i in range ( R ) : NEW_LINE INDENT for j in range ( C ) : NEW_LINE DEDENT DEDENT
if ( mat [ i ] [ j ] == s ) : NEW_LINE
for k in range ( 8 ) : NEW_LINE INDENT ans = max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , s ) ) ; NEW_LINE DEDENT return ans NEW_LINE
mat = [ [ ' a ' , ' c ' , ' d ' ] , [ ' h ' , ' b ' , ' a ' ] , [ ' i ' , ' g ' , ' f ' ] ] NEW_LINE print ( getLen ( mat , ' a ' ) ) NEW_LINE print ( getLen ( mat , ' e ' ) ) NEW_LINE print ( getLen ( mat , ' b ' ) ) NEW_LINE print ( getLen ( mat , ' f ' ) ) NEW_LINE
n = 3 NEW_LINE
def findLongestFromACell ( i , j , mat , dp ) : NEW_LINE
if ( i < 0 or i >= n or j < 0 or j >= n ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( dp [ i ] [ j ] != - 1 ) : NEW_LINE INDENT return dp [ i ] [ j ] NEW_LINE DEDENT
x , y , z , w = - 1 , - 1 , - 1 , - 1 NEW_LINE
if ( j < n - 1 and ( ( mat [ i ] [ j ] + 1 ) == mat [ i ] [ j + 1 ] ) ) : NEW_LINE INDENT x = 1 + findLongestFromACell ( i , j + 1 , mat , dp ) NEW_LINE DEDENT if ( j > 0 and ( mat [ i ] [ j ] + 1 == mat [ i ] [ j - 1 ] ) ) : NEW_LINE INDENT y = 1 + findLongestFromACell ( i , j - 1 , mat , dp ) NEW_LINE DEDENT if ( i > 0 and ( mat [ i ] [ j ] + 1 == mat [ i - 1 ] [ j ] ) ) : NEW_LINE INDENT z = 1 + findLongestFromACell ( i - 1 , j , mat , dp ) NEW_LINE DEDENT if ( i < n - 1 and ( mat [ i ] [ j ] + 1 == mat [ i + 1 ] [ j ] ) ) : NEW_LINE INDENT w = 1 + findLongestFromACell ( i + 1 , j , mat , dp ) NEW_LINE DEDENT
dp [ i ] [ j ] = max ( x , max ( y , max ( z , max ( w , 1 ) ) ) ) NEW_LINE return dp [ i ] [ j ] NEW_LINE
def finLongestOverAll ( mat ) : NEW_LINE
result = 1 NEW_LINE
dp = [ [ - 1 for i in range ( n ) ] for i in range ( n ) ] NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT if ( dp [ i ] [ j ] == - 1 ) : NEW_LINE INDENT findLongestFromACell ( i , j , mat , dp ) NEW_LINE DEDENT DEDENT DEDENT
result = max ( result , dp [ i ] [ j ] ) ; NEW_LINE return result NEW_LINE
mat = [ [ 1 , 2 , 9 ] , [ 5 , 3 , 8 ] , [ 4 , 6 , 7 ] ] NEW_LINE print ( " Length ▁ of ▁ the ▁ longest ▁ path ▁ is ▁ " , finLongestOverAll ( mat ) ) NEW_LINE
