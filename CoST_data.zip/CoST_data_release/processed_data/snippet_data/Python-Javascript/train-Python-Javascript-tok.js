class Node { constructor ( item ) { this . key = item ; this . left = this . right = null ; } }
function sortStack ( input ) { var tmpStack = [ ] ; while ( input . length != 0 ) {
var tmp = input [ input . length - 1 ] ; input . pop ( ) ;
while ( tmpStack . length != 0 && tmpStack [ tmpStack . length - 1 ] < tmp ) {
input . push ( tmpStack [ tmpStack . length - 1 ] ) ; tmpStack . pop ( ) ; }
tmpStack . push ( tmp ) ; } return tmpStack ; } function sortArrayUsingStacks ( arr , n ) {
var input = [ ] ; for ( var i = 0 ; i < n ; i ++ ) input . push ( arr [ i ] ) ;
var tmpStack = sortStack ( input ) ;
for ( var i = 0 ; i < n ; i ++ ) { arr [ i ] = tmpStack [ tmpStack . length - 1 ] ; tmpStack . pop ( ) ; } }
var arr = [ 10 , 5 , 15 , 45 ] ; var n = arr . length ; sortArrayUsingStacks ( arr , n ) ; for ( var i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function towerOfHanoi ( n , from_rod , to_rod , aux_rod ) { if ( n == 1 ) { document . write ( " " + from_rod + " " + to_rod + " " ) ; return ; } towerOfHanoi ( n - 1 , from_rod , aux_rod , to_rod ) ; document . write ( " " + n + " " + from_rod + " " + to_rod + " " ) ; towerOfHanoi ( n - 1 , aux_rod , to_rod , from_rod ) ; }
var n = 4 ;
towerOfHanoi ( n , ' ' , ' ' , ' ' ) ;
var arr = [ 10 , 20 , 30 , 50 , 10 , 70 , 30 ] ; function printMaxOfMin ( n ) {
for ( k = 1 ; k <= n ; k ++ ) {
var maxOfMin = Number . MIN_VALUE ;
for ( i = 0 ; i <= n - k ; i ++ ) {
var min = arr [ i ] ; for ( j = 1 ; j < k ; j ++ ) { if ( arr [ i + j ] < min ) min = arr [ i + j ] ; }
if ( min > maxOfMin ) maxOfMin = min ; }
document . write ( maxOfMin + " " ) ; } }
printMaxOfMin ( arr . length ) ;
let arr = [ 10 , 20 , 30 , 50 , 10 , 70 , 30 ] ; function printMaxOfMin ( n ) {
let s = [ ] ;
for ( let i = 0 ; i < n ; i ++ ) { left [ i ] = - 1 ; right [ i ] = n ; }
for ( let i = 0 ; i < n ; i ++ ) { while ( s . length > 0 && arr [ s [ s . length - 1 ] ] >= arr [ i ] ) { s . pop ( ) ; } if ( s . length > 0 ) { left [ i ] = s [ s . length - 1 ] ; } s . push ( i ) ; }
while ( s . length > 0 ) { s . pop ( ) ; }
for ( let i = n - 1 ; i >= 0 ; i -- ) { while ( s . length > 0 && arr [ s [ s . length - 1 ] ] >= arr [ i ] ) { s . pop ( ) ; } if ( s . length > 0 ) { right [ i ] = s [ s . length - 1 ] ; } s . push ( i ) ; }
let ans = new Array ( n + 1 ) ; ans . fill ( 0 ) ; for ( let i = 0 ; i <= n ; i ++ ) { ans [ i ] = 0 ; }
for ( let i = 0 ; i < n ; i ++ ) {
let len = right [ i ] - left [ i ] - 1 ;
ans [ len ] = Math . max ( ans [ len ] , arr [ i ] ) ; }
for ( let i = n - 1 ; i >= 1 ; i -- ) { ans [ i ] = Math . max ( ans [ i ] , ans [ i + 1 ] ) ; }
for ( let i = 1 ; i <= n ; i ++ ) { document . write ( ans [ i ] + " " ) ; } } printMaxOfMin ( arr . length ) ;
function solve ( s , n ) {
let left = 0 , right = 0 , maxlength = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( s [ i ] == ' ' ) left ++ ; else right ++ ;
if ( left == right ) maxlength = max ( maxlength , 2 * right ) ;
else if ( right > left ) left = right = 0 ; } left = right = 0 ;
for ( let i = n - 1 ; i >= 0 ; i -- ) {
if ( s [ i ] == ' ' ) left ++ ; else right ++ ;
if ( left == right ) maxlength = Math . max ( maxlength , 2 * left ) ;
else if ( left > right ) left = right = 0 ; } return maxlength ; }
document . write ( solve ( " " , 16 ) ) ;
function printLeast ( arr ) {
let min_avail = 1 , pos_of_I = 0 ;
let al = [ ] ;
if ( arr [ 0 ] == ' ' ) { al . push ( 1 ) ; al . push ( 2 ) ; min_avail = 3 ; pos_of_I = 1 ; } else { al . push ( 2 ) ; al . push ( 1 ) ; min_avail = 3 ; pos_of_I = 0 ; }
for ( let i = 1 ; i < arr . length ; i ++ ) { if ( arr [ i ] == ' ' ) { al . push ( min_avail ) ; min_avail ++ ; pos_of_I = i + 1 ; } else { al . push ( al [ i ] ) ; for ( let j = pos_of_I ; j <= i ; j ++ ) al [ j ] = al [ j ] + 1 ; min_avail ++ ; } }
for ( let i = 0 ; i < al . length ; i ++ ) document . write ( al [ i ] + " " ) ; document . write ( " " ) ; }
printLeast ( " " ) ; printLeast ( " " ) ; printLeast ( " " ) ; printLeast ( " " ) ; printLeast ( " " ) ; printLeast ( " " ) ; printLeast ( " " ) ;
function PrintMinNumberForPattern ( seq ) {
let result = " " ;
let stk = [ ] ;
for ( let i = 0 ; i <= seq . length ; i ++ ) {
stk . push ( i + 1 ) ;
if ( i == seq . length seq [ i ] == ' ' ) {
while ( stk . length != 0 ) {
result += ( stk [ stk . length - 1 ] ) . toString ( ) ; result += " " ; stk . pop ( ) ; } } } document . write ( result + " " ) ; }
PrintMinNumberForPattern ( " " ) ; PrintMinNumberForPattern ( " " ) ; PrintMinNumberForPattern ( " " ) ; PrintMinNumberForPattern ( " " ) ; PrintMinNumberForPattern ( " " ) ; PrintMinNumberForPattern ( " " ) ; PrintMinNumberForPattern ( " " ) ;
function getMinNumberForPattern ( seq ) { let n = seq . length ; if ( n >= 9 ) return " " ; let result = new Array ( n + 1 ) ; let count = 1 ;
for ( let i = 0 ; i <= n ; i ++ ) { if ( i == n seq [ i ] == ' ' ) { for ( let j = i - 1 ; j >= - 1 ; j -- ) { result [ j + 1 ] = String . fromCharCode ( ' ' . charCodeAt ( ) + count ++ ) ; if ( j >= 0 && seq [ j ] == ' ' ) break ; } } } return result . join ( " " ) ; }
let inputs = [ " " , " " , " " , " " , " " , " " , " " ] ; for ( let input = 0 ; input < inputs . length ; input ++ ) { document . write ( getMinNumberForPattern ( inputs [ input ] ) + " " ) ; }
function nextGreater ( arr , next , order ) {
let stack = [ ] ;
for ( let i = arr . length - 1 ; i >= 0 ; i -- ) {
while ( stack . length != 0 && ( ( order == ' ' ) ? arr [ stack [ stack . length - 1 ] ] <= arr [ i ] : arr [ stack [ stack . length - 1 ] ] >= arr [ i ] ) ) stack . pop ( ) ;
if ( stack . length != 0 ) next [ i ] = stack [ stack . length - 1 ] ;
else next [ i ] = - 1 ;
stack . push ( i ) ; } }
function nextSmallerOfNextGreater ( arr ) {
let NG = new Array ( arr . length ) ;
let RS = new Array ( arr . length ) ; for ( let i = 0 ; i < arr . length ; i ++ ) { NG [ i ] = 0 ; RS [ i ] = 0 ; }
nextGreater ( arr , NG , ' ' ) ;
nextGreater ( arr , RS , ' ' ) ;
for ( let i = 0 ; i < arr . length ; i ++ ) { if ( NG [ i ] != - 1 && RS [ NG [ i ] ] != - 1 ) document . write ( arr [ RS [ NG [ i ] ] ] + " " ) ; else document . write ( " " ) ; } }
let arr = [ 5 , 1 , 9 , 2 , 5 , 1 , 7 ] ; nextSmallerOfNextGreater ( arr ) ;
class Node { constructor ( data ) { this . data = data ; this . left = this . right = null ; } } ;
function flipBinaryTree ( root ) { if ( root == null ) return root ; if ( root . left == null && root . right == null ) return root ;
let flippedRoot = flipBinaryTree ( root . left ) ;
root . left . left = root . right ; root . left . right = root ; root . left = root . right = null ; return flippedRoot ; }
function printLevelOrder ( root ) {
if ( root == null ) return ;
let q = [ ] ;
q . push ( root ) ; while ( true ) {
let nodeCount = q . length ; if ( nodeCount == 0 ) break ;
while ( nodeCount > 0 ) { let node = q . shift ( ) ; document . write ( node . data + " " ) ; if ( node . left != null ) q . push ( node . left ) ; if ( node . right != null ) q . push ( node . right ) ; nodeCount -- ; } document . write ( " " ) ; } }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . right . left = new Node ( 4 ) ; root . right . right = new Node ( 5 ) ; document . write ( " " ) ; printLevelOrder ( root ) ; root = flipBinaryTree ( root ) ; document . write ( " " ) ; printLevelOrder ( root ) ;
function heapify ( arr , n , i ) {
var largest = i ;
var l = 2 * i + 1 ;
var r = 2 * i + 2 ;
if ( l < n && arr [ l ] > arr [ largest ] ) largest = l ;
if ( r < n && arr [ r ] > arr [ largest ] ) largest = r ;
if ( largest != i ) { var swap = arr [ i ] ; arr [ i ] = arr [ largest ] ; arr [ largest ] = swap ;
heapify ( arr , n , largest ) ; } }
function sort ( arr ) { var n = arr . length ;
for ( var i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( var i = n - 1 ; i > 0 ; i -- ) {
var temp = arr [ 0 ] ; arr [ 0 ] = arr [ i ] ; arr [ i ] = temp ;
heapify ( arr , i , 0 ) ; } }
var arr = [ 12 , 11 , 13 , 5 , 6 , 7 ] ; var n = arr . length ; sort ( arr ) ; document . write ( " " ) ; printArray ( arr , n ) ;
function isHeap ( arr , n ) {
for ( let i = 0 ; i <= Math . floor ( ( n - 2 ) / 2 ) ; i ++ ) {
if ( arr [ 2 * i + 1 ] > arr [ i ] ) return false ;
if ( 2 * i + 2 < n && arr [ 2 * i + 2 ] > arr [ i ] ) return false ; } return true ; }
let arr = [ 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 ] ; let n = arr . length ; if ( isHeap ( arr , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function generate_derangement ( N ) {
let S = [ ] ; for ( let i = 1 ; i <= N ; i ++ ) S [ i ] = i ;
let D = [ ] ; for ( let i = 1 ; i <= N ; i += 2 ) { if ( i == N ) {
D [ N ] = S [ N - 1 ] ; D [ N - 1 ] = S [ N ] ; } else { D [ i ] = i + 1 ; D [ i + 1 ] = i ; } }
for ( let i = 1 ; i <= N ; i ++ ) document . write ( D [ i ] + " " ) ; document . write ( " " ) ; }
generate_derangement ( 10 ) ;
function heapify ( arr , n , i ) {
var smallest = i ;
var l = 2 * i + 1 ;
var r = 2 * i + 2 ;
if ( l < n && arr [ l ] < arr [ smallest ] ) smallest = l ;
if ( r < n && arr [ r ] < arr [ smallest ] ) smallest = r ;
if ( smallest != i ) { [ arr [ i ] , arr [ smallest ] ] = [ arr [ smallest ] , arr [ i ] ]
heapify ( arr , n , smallest ) ; } }
function heapSort ( arr , n ) {
for ( var i = parseInt ( n / 2 - 1 ) ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( var i = n - 1 ; i >= 0 ; i -- ) {
[ arr [ 0 ] , arr [ i ] ] = [ arr [ i ] , arr [ 0 ] ]
heapify ( arr , i , 0 ) ; } }
function printArray ( arr , n ) { for ( var i = 0 ; i < n ; ++ i ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; }
var arr = [ 4 , 6 , 3 , 2 , 9 ] ; var n = arr . length ; heapSort ( arr , n ) ; document . write ( " " ) ; printArray ( arr , n ) ;
function sumBetweenTwoKth ( arr , k1 , k2 ) {
arr . sort ( function ( a , b ) { return a - b } ) ;
var result = 0 ; for ( var i = k1 ; i < k2 - 1 ; i ++ ) result += arr [ i ] ; return result ; }
var arr = [ 20 , 8 , 22 , 4 , 12 , 10 , 14 ] ; var k1 = 3 , k2 = 6 ; var n = arr . length ; document . write ( sumBetweenTwoKth ( arr , k1 , k2 ) ) ;
function minSum ( a , n ) {
a . sort ( ) ; let num1 = 0 ; let num2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) num1 = num1 * 10 + a [ i ] ; else num2 = num2 * 10 + a [ i ] ; } return num2 + num1 ; }
let arr = [ 5 , 3 , 0 , 7 , 4 ] ; let n = arr . length ; document . write ( " " + minSum ( arr , n ) ) ;
class Node { constructor ( key ) { this . key = key ; this . left = this . right = null ; } }
function count ( node ) { if ( node == null ) return 0 ; return count ( node . left ) + count ( node . right ) + 1 ; }
function checkRec ( node , n ) {
if ( node == null ) return false ;
if ( count ( node ) == n - count ( node ) ) return true ;
return checkRec ( node . left , n ) || checkRec ( node . right , n ) ; }
function check ( node ) {
let n = count ( node ) ;
return checkRec ( node , n ) ; }
let root = new Node ( 5 ) ; root . left = new Node ( 1 ) ; root . right = new Node ( 6 ) ; root . left . left = new Node ( 3 ) ; root . right . left = new Node ( 7 ) ; root . right . right = new Node ( 4 ) ; if ( check ( root ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
class Node { constructor ( key ) { this . key = key ; this . left = this . right = null ; } } class Res { constructor ( ) { this . res = false ; } } var root ;
function count ( node ) { if ( node == null ) return 0 ; return count ( node . left ) + count ( node . right ) + 1 ; }
function checkRec ( root , n , res ) {
if ( root == null ) return 0 ;
var c = checkRec ( root . left , n , res ) + 1 + checkRec ( root . right , n , res ) ;
if ( c == n - c ) res . res = true ;
return c ; }
function check ( root ) {
var n = count ( root ) ;
res = new Res ( ) ; checkRec ( root , n , res ) ; return res . res ; }
root = new Node ( 5 ) ; root . left = new Node ( 1 ) ; root . right = new Node ( 6 ) ; root . left . left = new Node ( 3 ) ; root . right . left = new Node ( 7 ) ; root . right . right = new Node ( 4 ) ; if ( check ( root ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
let preIndex = 0 ;
class Node {
function search ( arr , strt , end , value ) { for ( let i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) return i ; } return - 1 ; }
function buildTree ( In , pre , inStrt , inEnd ) { if ( inStrt > inEnd ) return null ;
let tNode = new Node ( pre [ preIndex ++ ] ) ;
if ( inStrt == inEnd ) return tNode ;
let inIndex = search ( In , inStrt , inEnd , tNode . data ) ;
tNode . left = buildTree ( In , pre , inStrt , inIndex - 1 ) ; tNode . right = buildTree ( In , pre , inIndex + 1 , inEnd ) ; return tNode ; }
function checkPostorder ( node , postOrder , index ) { if ( node == null ) return index ;
index = checkPostorder ( node . left , postOrder , index ) ;
index = checkPostorder ( node . right , postOrder , index ) ;
if ( node . data == postOrder [ index ] ) index ++ ; else return - 1 ; return index ; }
let inOrder = [ 4 , 2 , 5 , 1 , 3 ] ; let preOrder = [ 1 , 2 , 4 , 5 , 3 ] ; let postOrder = [ 4 , 5 , 2 , 3 , 1 ] ; let len = inOrder . length ;
let root = buildTree ( inOrder , preOrder , 0 , len - 1 ) ;
let index = checkPostorder ( root , postOrder , 0 ) ;
if ( index == len ) document . write ( " " ) ; else document . write ( " " ) ;
function printDistance ( mat ) { let ans = new Array ( N ) ;
for ( let i = 0 ; i < N ; i ++ ) { ans [ i ] = new Array ( M ) ; for ( let j = 0 ; j < M ; j ++ ) { ans [ i ] [ j ] = Number . MAX_VALUE ; } }
for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < M ; j ++ ) {
for ( let k = 0 ; k < N ; k ++ ) for ( let l = 0 ; l < M ; l ++ ) {
if ( mat [ k ] [ l ] == 1 ) ans [ i ] [ j ] = Math . min ( ans [ i ] [ j ] , Math . abs ( i - k ) + Math . abs ( j - l ) ) ; } }
for ( let i = 0 ; i < N ; i ++ ) { for ( let j = 0 ; j < M ; j ++ ) document . write ( ans [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let mat = [ [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 1 , 1 ] , [ 0 , 1 , 1 , 0 ] ] printDistance ( mat ) ;
function isChangeable ( notes , n ) {
let fiveCount = 0 ; let tenCount = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( notes [ i ] == 5 ) fiveCount ++ ; else if ( notes [ i ] == 10 ) {
if ( fiveCount > 0 ) { fiveCount -- ; tenCount ++ ; } else return 0 ; } else {
if ( fiveCount > 0 && tenCount > 0 ) { fiveCount -- ; tenCount -- ; }
else if ( fiveCount >= 3 ) { fiveCount -= 3 ; } else return 0 ; } } return 1 ; }
let a = [ 5 , 5 , 5 , 10 , 20 ] ; let n = a . length ;
if ( isChangeable ( a , n ) > 0 ) document . write ( " " ) ; else document . write ( " " ) ;
function maxDistance ( arr , n ) {
let map = new Map ( ) ;
let max_dist = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( ! map . has ( arr [ i ] ) ) map . set ( arr [ i ] , i ) ;
else max_dist = Math . max ( max_dist , i - map . get ( arr [ i ] ) ) ; } return max_dist ; }
let arr = [ 3 , 2 , 1 , 2 , 1 , 4 , 5 , 8 , 6 , 7 , 4 , 2 ] ; let n = arr . length ; document . write ( maxDistance ( arr , n ) ) ;
function checkDuplicatesWithinK ( arr , n , k ) {
let myset = [ ] ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( arr . includes ( arr [ i ] ) ) { return true ; }
myset . add ( arr [ i ] ) ;
if ( i >= k ) { index = array . indexOf ( arr [ i - k ] ) ; array . splice ( index , 1 ) ; } } return false ; }
let arr = [ 10 , 5 , 3 , 4 , 3 , 5 , 6 ] ; let n = arr . length ; if ( checkDuplicatesWithinK ( arr , n , 3 ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function mostFrequent ( arr , n ) {
arr . sort ( ) ;
let max_count = 1 , res = arr [ 0 ] ; let curr_count = 1 ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
let arr = [ 1 , 5 , 2 , 1 , 3 , 2 , 1 ] ; let n = arr . length ; document . write ( mostFrequent ( arr , n ) ) ;
function mostFrequent ( arr , n ) {
var hash = new Map ( ) ; for ( var i = 0 ; i < n ; i ++ ) { if ( hash . has ( arr [ i ] ) ) hash . set ( arr [ i ] , hash . get ( arr [ i ] ) + 1 ) else hash . set ( arr [ i ] , 1 ) }
var max_count = 0 , res = - 1 ; hash . forEach ( ( value , key ) => { if ( max_count < value ) { res = key ; max_count = value ; } } ) ; return res ; }
var arr = [ 1 , 5 , 2 , 1 , 3 , 2 , 1 ] ; var n = arr . length ; document . write ( mostFrequent ( arr , n ) ) ;
function smallestSubsegment ( a , n ) {
let left = new Map ( ) ;
let count = new Map ( ) ;
let mx = 0 ;
let mn = - 1 , strindex = - 1 ; for ( let i = 0 ; i < n ; i ++ ) { let x = a [ i ] ;
if ( count . get ( x ) == null ) { left . set ( x , i ) ; count . set ( x , 1 ) ; }
else count . set ( x , count . get ( x ) + 1 ) ;
if ( count . get ( x ) > mx ) { mx = count . get ( x ) ;
mn = i - left . get ( x ) + 1 ; strindex = left . get ( x ) ; }
else if ( ( count . get ( x ) == mx ) && ( i - left . get ( x ) + 1 < mn ) ) { mn = i - left . get ( x ) + 1 ; strindex = left . get ( x ) ; } }
for ( let i = strindex ; i < strindex + mn ; i ++ ) document . write ( a [ i ] + " " ) ; }
let A = [ 1 , 2 , 2 , 2 , 1 ] ; let n = A . length ; smallestSubsegment ( A , n ) ;
function findSymPairs ( arr ) {
let hM = new Map ( ) ;
for ( let i = 0 ; i < arr . length ; i ++ ) {
let first = arr [ i ] [ 0 ] ; let sec = arr [ i ] [ 1 ] ;
if ( val != null && val == first ) document . write ( " " + sec + " " + first + " " ) ;
else hM . set ( first , sec ) ; } }
let arr = new Array ( 5 ) ; for ( let i = 0 ; i < arr . length ; i ++ ) { arr [ i ] = new Array ( 2 ) ; for ( let j = 0 ; j < 2 ; j ++ ) { arr [ i ] [ j ] = 0 ; } } arr [ 0 ] [ 0 ] = 11 ; arr [ 0 ] [ 1 ] = 20 ; arr [ 1 ] [ 0 ] = 30 ; arr [ 1 ] [ 1 ] = 40 ; arr [ 2 ] [ 0 ] = 5 ; arr [ 2 ] [ 1 ] = 10 ; arr [ 3 ] [ 0 ] = 40 ; arr [ 3 ] [ 1 ] = 30 ; arr [ 4 ] [ 0 ] = 10 ; arr [ 4 ] [ 1 ] = 5 ; findSymPairs ( arr ) ;
function groupElements ( arr , n ) {
let visited = Array ( n ) . fill ( 0 ) ; for ( let i = 0 ; i < n ; i ++ ) { visited [ i ] = false ; }
for ( let i = 0 ; i < n ; i ++ ) {
if ( ! visited [ i ] ) {
document . write ( arr [ i ] + " " ) ; for ( let j = i + 1 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) { document . write ( arr [ i ] + " " ) ; visited [ j ] = true ; } } } } }
let arr = [ 4 , 6 , 9 , 2 , 3 , 4 , 9 , 6 , 10 , 4 ] ; let n = arr . length ; groupElements ( arr , n ) ;
function aredisjoint ( set1 , set2 ) {
for ( let i = 0 ; i < set1 . length ; i ++ ) { for ( let j = 0 ; j < set2 . length ; j ++ ) { if ( set1 [ i ] == set2 [ j ] ) return false ; } }
return true ; }
let set1 = [ 12 , 34 , 11 , 9 , 3 ] ; let set2 = [ 7 , 2 , 1 , 5 ] ; result = aredisjoint ( set1 , set2 ) ; if ( result ) document . write ( " " ) ; else document . write ( " " ) ;
function aredisjoint ( set1 , set2 ) { let i = 0 , j = 0 ;
set1 . sort ( function ( a , b ) { return a - b } ) ; set2 . sort ( function ( a , b ) { return a - b } ) ;
while ( i < set1 . length && j < set2 . length ) { if ( set1 [ i ] < set2 [ j ] ) i ++ ; else if ( set1 [ i ] > set2 [ j ] ) j ++ ;
else return false ; } return true ; }
let set1 = [ 12 , 34 , 11 , 9 , 3 ] ; let set2 = [ 7 , 2 , 1 , 5 ] ; result = aredisjoint ( set1 , set2 ) ; if ( result ) document . write ( " " ) ; else document . write ( " " ) ;
function findMissing ( a , b , n , m ) { for ( let i = 0 ; i < n ; i ++ ) { let j ; for ( j = 0 ; j < m ; j ++ ) if ( a [ i ] == b [ j ] ) break ; if ( j == m ) document . write ( a [ i ] + " " ) ; } }
let a = [ 1 , 2 , 6 , 3 , 4 , 5 ] ; let b = [ 2 , 4 , 3 , 1 , 0 ] ; let n = a . length ; let m = b . length ; findMissing ( a , b , n , m ) ;
function findMissing ( a , b , n , m ) {
let s = new Set ( ) ; for ( let i = 0 ; i < m ; i ++ ) s . add ( b [ i ] ) ;
for ( let i = 0 ; i < n ; i ++ ) if ( ! s . has ( a [ i ] ) ) document . write ( a [ i ] + " " ) ; }
let a = [ 1 , 2 , 6 , 3 , 4 , 5 ] ; let b = [ 2 , 4 , 3 , 1 , 0 ] ; let n = a . length ; let m = b . length ; findMissing ( a , b , n , m ) ;
function areEqual ( arr1 , arr2 ) { let n = arr1 . length ; let m = arr2 . length ;
if ( n != m ) return false ;
arr1 . sort ( ) ; arr2 . sort ( ) ;
for ( let i = 0 ; i < n ; i ++ ) if ( arr1 [ i ] != arr2 [ i ] ) return false ;
return true ; }
let arr1 = [ 3 , 5 , 2 , 5 , 2 ] ; let arr2 = [ 2 , 3 , 5 , 5 , 2 ] ; if ( areEqual ( arr1 , arr2 ) ) document . write ( " " ) ; else document . write ( " " ) ;
function find_maximum ( a , n , k ) {
let b = new Map ( ) ; for ( let i = 0 ; i < n ; i ++ ) { let x = a [ i ] ;
let d = Math . min ( 1 + i , n - i ) ; if ( ! b . has ( x ) ) b . set ( x , d ) ; else {
b . set ( x , Math . min ( d , b . get ( x ) ) ) ; } } let ans = Number . MAX_VALUE ; for ( let i = 0 ; i < n ; i ++ ) { let x = a [ i ] ;
if ( x != k - x && b . has ( k - x ) ) ans = Math . min ( Math . max ( b . get ( x ) , b . get ( k - x ) ) , ans ) ; } return ans ; }
let a = [ 3 , 5 , 8 , 6 , 7 ] ; let K = 11 ; let n = a . length ; document . write ( find_maximum ( a , n , K ) ) ;
function isProduct ( arr , n , x ) {
for ( var i = 0 ; i < n - 1 ; i ++ ) for ( var j = i + 1 ; i < n ; i ++ ) if ( arr [ i ] * arr [ j ] == x ) return true ; return false ; }
var arr = [ 10 , 20 , 9 , 40 ] ; var x = 400 ; var n = arr . length ; isProduct ( arr , n , x ) ? document . write ( " " ) : document . write ( " " ) ; x = 190 ; isProduct ( arr , n , x ) ? document . write ( " " ) : document . write ( " " ) ;
function isProduct ( arr , n , x ) {
let hset = new Set ( ) ; if ( n < 2 ) return false ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] == 0 ) { if ( x == 0 ) return true ; else continue ; }
if ( x % arr [ i ] == 0 ) { if ( hset . has ( x / arr [ i ] ) ) return true ;
hset . add ( arr [ i ] ) ; } } return false ; }
let arr = [ 10 , 20 , 9 , 40 ] ; let x = 400 ; let n = arr . length ; if ( isProduct ( arr , arr . length , x ) ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ; x = 190 ; if ( isProduct ( arr , arr . length , x ) ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ;
function prletMissing ( arr , low , high ) {
let polets_of_range = Array ( high - low + 1 ) . fill ( 0 ) ; for ( let i = 0 ; i < arr . length ; i ++ ) {
if ( low <= arr [ i ] && arr [ i ] <= high ) polets_of_range [ arr [ i ] - low ] = true ; }
for ( let x = 0 ; x <= high - low ; x ++ ) { if ( polets_of_range [ x ] == false ) document . write ( ( low + x ) + " " ) ; } }
let arr = [ 1 , 3 , 5 , 4 ] ; let low = 1 , high = 10 ; prletMissing ( arr , low , high ) ;
function find ( a , b , k , n1 , n2 ) {
var s = new Set ( ) ; for ( var i = 0 ; i < n2 ; i ++ ) s . add ( b [ i ] ) ;
var missing = 0 ; for ( var i = 0 ; i < n1 ; i ++ ) { if ( ! s . has ( a [ i ] ) ) missing ++ ; if ( missing == k ) return a [ i ] ; } return - 1 ; }
var a = [ 0 , 2 , 4 , 6 , 8 , 10 , 12 , 14 , 15 ] ; var b = [ 4 , 10 , 6 , 8 , 12 ] ; var n1 = a . length ; var n2 = b . length ; var k = 3 ; document . write ( find ( a , b , k , n1 , n2 ) ) ;
class Node { constructor ( item ) { this . data = item ; this . left = this . right = null ; } } var root ;
function isFullTree ( node ) {
if ( node == null ) return true ;
if ( node . left == null && node . right == null ) return true ;
if ( ( node . left != null ) && ( node . right != null ) ) return ( isFullTree ( node . left ) && isFullTree ( node . right ) ) ;
return false ; }
root = new Node ( 10 ) ; root . left = new Node ( 20 ) ; root . right = new Node ( 30 ) ; root . left . right = new Node ( 40 ) ; root . left . left = new Node ( 50 ) ; root . right . left = new Node ( 60 ) ; root . left . left . left = new Node ( 80 ) ; root . right . right = new Node ( 70 ) ; root . left . left . right = new Node ( 90 ) ; root . left . right . left = new Node ( 80 ) ; root . left . right . right = new Node ( 90 ) ; root . right . left . left = new Node ( 80 ) ; root . right . left . right = new Node ( 90 ) ; root . right . right . left = new Node ( 80 ) ; root . right . right . right = new Node ( 90 ) ; if ( isFullTree ( root ) ) document . write ( " " ) ; else document . write ( " " ) ;
function findGreatest ( arr , n ) { let result = - 1 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n - 1 ; j ++ ) for ( let k = j + 1 ; k < n ; k ++ ) if ( arr [ j ] * arr [ k ] == arr [ i ] ) result = Math . max ( result , arr [ i ] ) ; return result ; }
let arr = [ 30 , 10 , 9 , 3 , 35 ] ; let n = arr . length ; document . write ( findGreatest ( arr , n ) ) ;
function findGreatest ( arr , n ) {
let m = new Map ( ) ; for ( let i = 0 ; i < n ; i ++ ) { if ( m . has ( arr [ i ] ) ) { m . set ( arr [ i ] , m [ arr [ i ] ] + 1 ) ; } else { m . set ( arr [ i ] , m . get ( arr [ i ] ) ) ; } }
arr . sort ( function ( a , b ) { return a - b ; } ) ; for ( let i = n - 1 ; i > 1 ; i -- ) {
for ( let j = 0 ; j < i && arr [ j ] <= Math . sqrt ( arr [ i ] ) ; j ++ ) { if ( arr [ i ] % arr [ j ] == 0 ) { let result = Math . floor ( arr [ i ] / arr [ j ] ) ;
if ( result != arr [ j ] && m [ result ] == null m [ result ] > 0 ) { return arr [ i ] ; }
else if ( result == arr [ j ] && m [ result ] > 1 ) { return arr [ i ] ; } } } } return - 1 ; }
let arr = [ 17 , 2 , 1 , 15 , 30 ] ; let n = arr . length ; document . write ( findGreatest ( arr , n ) ) ;
function subset ( ar , n ) {
let res = 0 ;
ar . sort ( ) ;
for ( let i = 0 ; i < n ; i ++ ) { let count = 1 ;
for ( ; i < n - 1 ; i ++ ) { if ( ar [ i ] == ar [ i + 1 ] ) count ++ ; else break ; }
res = Math . max ( res , count ) ; } return res ; }
let arr = [ 5 , 6 , 9 , 3 , 4 , 3 , 4 ] ; let n = 7 ; document . write ( subset ( arr , n ) ) ;
function minRemove ( a , b , n , m ) {
let countA = new Map ( ) ; let countB = new Map ( ) ;
for ( let i = 0 ; i < n ; i ++ ) { if ( countA . has ( a [ i ] ) ) countA . set ( a [ i ] , countA . get ( a [ i ] ) + 1 ) ; else countA . set ( a [ i ] , 1 ) ; }
for ( let i = 0 ; i < m ; i ++ ) { if ( countB . has ( b [ i ] ) ) countB . set ( b [ i ] , countB . get ( b [ i ] ) + 1 ) ; else countB . set ( b [ i ] , 1 ) ; }
let res = 0 ; for ( let x of countA . keys ( ) ) if ( countB . has ( x ) ) res += Math . min ( countB . get ( x ) , countA . get ( x ) ) ;
return res ; }
let a = [ 1 , 2 , 3 , 4 ] ; let b = [ 2 , 3 , 4 , 5 , 8 ] ; let n = a . length ; let m = b . length ; document . write ( minRemove ( a , b , n , m ) ) ;
function countItems ( list1 , m , list2 , n ) { var count = 0 ;
for ( var i = 0 ; i < m ; i ++ ) for ( var j = 0 ; j < n ; j ++ ) if ( list1 [ i ] [ 0 ] === list2 [ j ] [ 0 ] && ( list1 [ i ] [ 1 ] != list2 [ j ] [ 1 ] ) ) count ++ ;
return count ; }
var list1 = [ [ " " , 60 ] , [ " " , 20 ] , [ " " , 50 ] , [ " " , 30 ] ] ; var list2 = [ [ " " , 20 ] , [ " " , 15 ] , [ " " , 40 ] , [ " " , 60 ] ] ; var m = list1 . length ; var n = list2 . length ; document . write ( " " + countItems ( list1 , m , list2 , n ) ) ;
function makePermutation ( a , n ) {
var count = new Map ( ) ; for ( var i = 0 ; i < n ; i ++ ) { if ( count . has ( a [ i ] ) ) count . set ( a [ i ] , count . get ( a [ i ] ) + 1 ) else count . set ( a [ i ] , 1 ) } var next_missing = 1 ; for ( var i = 0 ; i < n ; i ++ ) { if ( count . get ( a [ i ] ) != 1 a [ i ] > n a [ i ] < 1 ) { count . set ( a [ i ] , count . get ( a [ i ] ) - 1 ) ;
while ( count . has ( next_missing ) ) next_missing ++ ;
a [ i ] = next_missing ; count . set ( next_missing , 1 ) ; } } }
var A = [ 2 , 2 , 3 , 3 ] ; var n = A . length ; makePermutation ( A , n ) ; for ( var i = 0 ; i < n ; i ++ ) document . write ( A [ i ] + " " ) ;
function getPairsCount ( arr , n , sum ) {
let count = 0 ;
for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] + arr [ j ] == sum ) count ++ ; return count ; }
let arr = [ 1 , 5 , 7 , - 1 , 5 ] ; let n = arr . length ; let sum = 6 ; document . write ( " " + getPairsCount ( arr , n , sum ) ) ;
function countPairs ( arr1 , arr2 , m , n , x ) { let count = 0 ;
for ( let i = 0 ; i < m ; i ++ ) for ( let j = 0 ; j < n ; j ++ )
if ( ( arr1 [ i ] + arr2 [ j ] ) == x ) count ++ ;
return count ; }
let arr1 = [ 1 , 3 , 5 , 7 ] ; let arr2 = [ 2 , 3 , 5 , 8 ] ; let m = arr1 . length ; let n = arr2 . length ; let x = 10 ; document . write ( " " + countPairs ( arr1 , arr2 , m , n , x ) ) ;
function isPresent ( arr , low , high , value ) { while ( low <= high ) { let mid = Math . floor ( ( low + high ) / 2 ) ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
function countPairs ( arr1 , arr2 , m , n , x ) { let count = 0 ; for ( let i = 0 ; i < m ; i ++ ) {
let value = x - arr1 [ i ] ;
if ( isPresent ( arr2 , 0 , n - 1 , value ) ) count ++ ; }
return count ; }
let arr1 = [ 1 , 3 , 5 , 7 ] ; let arr2 = [ 2 , 3 , 5 , 8 ] ; let m = arr1 . length ; let n = arr2 . length ; let x = 10 ; document . write ( " " + countPairs ( arr1 , arr2 , m , n , x ) ) ;
function countPairs ( arr1 , arr2 , m , n , x ) { let count = 0 ; let us = new Set ( ) ;
for ( let i = 0 ; i < m ; i ++ ) us . add ( arr1 [ i ] ) ;
for ( let j = 0 ; j < n ; j ++ )
if ( us . has ( x - arr2 [ j ] ) ) count ++ ;
return count ; }
let arr1 = [ 1 , 3 , 5 , 7 ] ; let arr2 = [ 2 , 3 , 5 , 8 ] ; let m = arr1 . length ; let n = arr2 . length ; let x = 10 ; document . write ( " " + countPairs ( arr1 , arr2 , m , n , x ) ) ;
function countPairs ( arr1 , arr2 , m , n , x ) { let count = 0 ; let l = 0 , r = n - 1 ;
while ( l < m && r >= 0 ) {
if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) { l ++ ; r -- ; count ++ ; }
else if ( ( arr1 [ l ] + arr2 [ r ] ) < x ) l ++ ;
else r -- ; }
return count ; }
let arr1 = [ 1 , 3 , 5 , 7 ] ; let arr2 = [ 2 , 3 , 5 , 8 ] ; let m = arr1 . length ; let n = arr2 . length ; let x = 10 ; document . write ( " " + countPairs ( arr1 , arr2 , m , n , x ) ) ;
let arr = [ 10 , 2 , - 2 , - 20 , 10 ] ; let k = - 10 ; let n = arr . length ; let res = 0 ;
for ( let i = 0 ; i < n ; i ++ ) { let sum = 0 ; for ( let j = i ; j < n ; j ++ ) {
sum += arr [ j ] ;
if ( sum == k ) res ++ ; } } document . write ( res ) ;
function findSubarraySum ( arr , n , sum ) {
let prevSum = new Map ( ) ; let res = 0 ;
let currsum = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
currsum += arr [ i ] ;
if ( currsum == sum ) res ++ ;
if ( prevSum . has ( currsum - sum ) ) res += prevSum . get ( currsum - sum ) ;
let count = prevSum . get ( currsum ) ; if ( count == null ) prevSum . set ( currsum , 1 ) ; else prevSum . set ( currsum , count + 1 ) ; } return res ; }
let arr = [ 10 , 2 , - 2 , - 20 , 10 ] ; let sum = - 10 ; let n = arr . length ; document . write ( findSubarraySum ( arr , n , sum ) ) ;
function countPairs ( arr , n ) { var result = 0 ; for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { var product = arr [ i ] * arr [ j ] ;
for ( k = 0 ; k < n ; k ++ ) {
if ( arr [ k ] == product ) { result ++ ; break ; } } } }
return result ; }
var arr = [ 6 , 2 , 4 , 12 , 5 , 3 ] ; var n = arr . length ; document . write ( countPairs ( arr , n ) ) ;
function countPairs ( arr , n ) { var result = 0 ;
var Hash = new Set ( ) ;
for ( i = 0 ; i < n ; i ++ ) { Hash . add ( arr [ i ] ) ; }
for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { var product = arr [ i ] * arr [ j ] ;
if ( Hash . has ( product ) ) { result ++ ; } } }
return result ; }
var arr = [ 6 , 2 , 4 , 12 , 5 , 3 ] ; var n = arr . length ; document . write ( countPairs ( arr , n ) ) ;
function findPairs ( arr1 , arr2 , n , m , x ) { for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < m ; j ++ ) if ( arr1 [ i ] + arr2 [ j ] == x ) document . write ( arr1 [ i ] + " " + arr2 [ j ] + " " ) ; }
let arr1 = [ 1 , 2 , 3 , 7 , 5 , 4 ] ; let arr2 = [ 0 , 7 , 4 , 3 , 2 , 1 ] ; let n = arr1 . length ; let m = arr2 . length ; let x = 8 ; findPairs ( arr1 , arr2 , n , m , x ) ;
function findPairs ( arr1 , arr2 , n , m , x ) {
let s = new Map ( ) ; for ( let i = 0 ; i < n ; i ++ ) s . set ( arr1 [ i ] , 0 ) ;
for ( let j = 0 ; j < m ; j ++ ) if ( s . has ( x - arr2 [ j ] ) ) document . write ( x - arr2 [ j ] + " " + arr2 [ j ] + " " ) ; }
let arr1 = [ 1 , 0 , - 4 , 7 , 6 , 4 ] ; let arr2 = [ 0 , 2 , 4 , - 3 , 2 , 1 ] ; let x = 8 ; findPairs ( arr1 , arr2 , arr1 . length , arr2 . length , x ) ;
function countFreq ( a , n ) {
let hm = new Array ( n ) ; for ( let i = 0 ; i < hm . length ; i ++ ) { hm [ i ] = 0 ; } for ( let i = 0 ; i < n ; i ++ ) hm [ a [ i ] ] ++ ; let cumul = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
cumul += hm [ a [ i ] ] ;
if ( hm [ a [ i ] ] != 0 ) { document . write ( a [ i ] + " " + cumul + " " ) ; }
hm [ a [ i ] ] = 0 ; } }
let a = [ 1 , 3 , 2 , 4 , 2 , 1 ] ; let n = a . length ; countFreq ( a , n ) ;
function findPair ( arr , n ) { let found = false ; for ( let i = 0 ; i < n ; i ++ ) { for ( let j = i + 1 ; j < n ; j ++ ) { for ( let k = 0 ; k < n ; k ++ ) { if ( arr [ i ] + arr [ j ] == arr [ k ] ) { document . write ( arr [ i ] + " " + arr [ j ] + " " ) ; found = true ; } } } } if ( found == false ) document . write ( " " ) ; }
let arr = [ 10 , 4 , 8 , 13 , 5 ] ; let n = arr . length ; findPair ( arr , n ) ;
function printPairs ( arr , n , k ) { let isPairFound = true ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( i != j && arr [ i ] % arr [ j ] == k ) { document . write ( " " + arr [ i ] + " " + arr [ j ] + " " + " " ) ; isPairFound = true ; } } } return isPairFound ; }
let arr = [ 2 , 3 , 5 , 4 , 7 ] ; let k = 3 ; if ( printPairs ( arr , arr . length , k ) == false ) document . write ( " " ) ;
function findDivisors ( n ) { let v = [ ] ;
for ( let i = 1 ; i <= Math . sqrt ( n ) ; i ++ ) { if ( n % i == 0 ) {
if ( n / i == i ) v . push ( i ) ; else { v . push ( i ) ; v . push ( Math . floor ( n / i ) ) ; } } } return v ; }
function printPairs ( arr , n , k ) {
let occ = new Map ( ) ; for ( let i = 0 ; i < n ; i ++ ) occ . set ( arr [ i ] , true ) ; let isPairFound = false ; for ( let i = 0 ; i < n ; i ++ ) {
if ( occ . get ( k ) && k < arr [ i ] ) { document . write ( " " + k + " " + arr [ i ] + " " ) ; isPairFound = true ; }
if ( arr [ i ] >= k ) {
let v = findDivisors ( arr [ i ] - k ) ;
for ( let j = 0 ; j < v . length ; j ++ ) { if ( arr [ i ] % v [ j ] == k && arr [ i ] != v [ j ] && occ . get ( v [ j ] ) ) { document . write ( " " + arr [ i ] + " " + v [ j ] + " " ) ; isPairFound = true ; } }
v = [ ] ; } } return isPairFound ; }
let arr = [ 3 , 1 , 2 , 5 , 4 ] ; let k = 2 ; if ( printPairs ( arr , arr . length , k ) == false ) document . write ( " " ) ;
function convert ( arr , n ) {
let temp = [ ... arr ] ;
temp . sort ( ( a , b ) => a - b ) ;
let umap = new Map ( ) ;
let val = 0 ; for ( let i = 0 ; i < n ; i ++ ) umap . set ( temp [ i ] , val ++ ) ;
for ( let i = 0 ; i < n ; i ++ ) arr [ i ] = umap . get ( arr [ i ] ) ; } function prletArr ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 10 , 20 , 15 , 12 , 11 , 50 ] ; let n = arr . length ; document . write ( " " + " " ) ; prletArr ( arr , n ) ; convert ( arr , n ) ; document . write ( " " + " " + " " ) ; prletArr ( arr , n ) ;
let ASCII_SIZE = 256 ; function getMaxOccuringChar ( str ) {
let count = new Array ( ASCII_SIZE ) ; for ( let i = 0 ; i < ASCII_SIZE ; i ++ ) { count [ i ] = 0 ; }
let len = str . length ; for ( let i = 0 ; i < len ; i ++ ) { count [ str [ i ] . charCodeAt ( 0 ) ] += 1 ; }
let max = - 1 ;
let result = ' ' ;
for ( let i = 0 ; i < len ; i ++ ) { if ( max < count [ str [ i ] . charCodeAt ( 0 ) ] ) { max = count [ str [ i ] . charCodeAt ( 0 ) ] ; result = str [ i ] ; } } return result ; }
let str = " " ; document . write ( " " , getMaxOccuringChar ( str ) ) ;
let MARKER = ' ' ;
class Node { constructor ( data ) { this . data = data ; } }
function dupSubUtil ( root , subtrees ) { let s = " " ;
if ( root == null ) return s + MARKER ;
let lStr = dupSubUtil ( root . left , subtrees ) ; if ( lStr == ( s ) ) return s ;
let rStr = dupSubUtil ( root . right , subtrees ) ; if ( rStr == ( s ) ) return s ;
s = s + root . data + lStr + rStr ;
if ( s . length > 3 && subtrees . has ( s ) ) return " " ; subtrees . add ( s ) ; return s ; }
let root = new Node ( ' ' ) ; root . left = new Node ( ' ' ) ; root . right = new Node ( ' ' ) ; root . left . left = new Node ( ' ' ) ; root . left . right = new Node ( ' ' ) ; root . right . right = new Node ( ' ' ) ; root . right . right . right = new Node ( ' ' ) ; root . right . right . left = new Node ( ' ' ) ; let str = dupSub ( root ) ; if ( str == ( " " ) ) document . write ( " " ) ; else document . write ( " " ) ;
function printFirstRepeating ( arr ) {
let min = - 1 ;
let set = new Set ( ) ;
for ( let i = arr . length - 1 ; i >= 0 ; i -- ) {
if ( set . has ( arr [ i ] ) ) min = i ;
else set . add ( arr [ i ] ) ; }
if ( min != - 1 ) document . write ( " " + arr [ min ] ) ; else document . write ( " " ) ; }
let arr = [ 10 , 5 , 3 , 4 , 3 , 5 , 6 ] ; printFirstRepeating ( arr ) ;
function printFirstRepeating ( arr , n ) {
var k = 0 ;
var max = n ; for ( i = 0 ; i < n ; i ++ ) if ( max < arr [ i ] ) max = arr [ i ] ;
var a = Array ( max + 1 ) . fill ( 0 ) ;
var b = Array ( max + 1 ) . fill ( 0 ) ; for ( var i = 0 ; i < n ; i ++ ) {
if ( a [ arr [ i ] ] != 0 ) { b [ arr [ i ] ] = 1 ; k = 1 ; continue ; } else
a [ arr [ i ] ] = i ; } if ( k == 0 ) document . write ( " " ) ; else { var min = max + 1 ;
for ( i = 0 ; i < max + 1 ; i ++ ) if ( a [ i ] != 0 && min > a [ i ] && b [ i ] != 0 ) min = a [ i ] ; document . write ( arr [ min ] ) ; } document . write ( " " ) ; }
var arr = [ 10 , 5 , 3 , 4 , 3 , 5 , 6 ] ; var n = arr . length ; printFirstRepeating ( arr , n ) ;
function findSum ( arr , n ) {
arr . sort ( ) ; let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) sum = sum + arr [ i ] ; } return sum ; }
let arr = [ 1 , 2 , 3 , 1 , 1 , 4 , 5 , 6 ] ; let n = arr . length ; document . write ( findSum ( arr , n ) ) ;
function findSum ( arr , n ) { let sum = 0 ;
let s = new Set ( ) ; for ( let i = 0 ; i < n ; i ++ ) { if ( ! s . has ( arr [ i ] ) ) { sum += arr [ i ] ; s . add ( arr [ i ] ) ; } } return sum ; }
let arr = [ 1 , 2 , 3 , 1 , 1 , 4 , 5 , 6 ] ; let n = arr . length ; document . write ( findSum ( arr , n ) ) ;
function printKDistinct ( arr , n , k ) { var dist_count = 0 ; for ( var i = 0 ; i < n ; i ++ ) {
var j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ j ] == arr [ i ] ) break ;
if ( j == n ) dist_count ++ ; if ( dist_count == k ) return arr [ i ] ; } return - 1 ; }
var ar = [ 1 , 2 , 1 , 3 , 4 , 2 ] ; var n = ar . length ; var k = 2 ; document . write ( printKDistinct ( ar , n , k ) ) ;
class Node { Node ( data ) { this . data = data ; this . left = this . right = null ; } } var a , b ;
function areMirror ( a , b ) {
if ( a == null && b == null ) return true ;
if ( a == null b == null ) return false ;
return a . data == b . data && areMirror ( a . left , b . right ) && areMirror ( a . right , b . left ) ; }
a = new Node ( 1 ) ; b = new Node ( 1 ) ; left = new Node ( 2 ) ; right = new Node ( 3 ) ; left . left = new Node ( 4 ) ; left . right = new Node ( 5 ) ; left = new Node ( 3 ) ; right = new Node ( 2 ) ; right . left = new Node ( 5 ) ; right . right = new Node ( 4 ) ; if ( areMirror ( a , b ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
function printPairs ( arr , n ) { let v = [ ] ;
for ( let i = 0 ; i < n ; i ++ )
for ( let j = i + 1 ; j < n ; j ++ )
if ( Math . abs ( arr [ i ] ) == Math . abs ( arr [ j ] ) ) v . push ( Math . abs ( arr [ i ] ) ) ;
if ( v . length == 0 ) return ;
v . sort ( function ( a , b ) { return a - b ; } ) ;
for ( let i = 0 ; i < v . length ; i ++ ) document . write ( - v [ i ] + " " + v [ i ] ) ; }
let arr = [ 4 , 8 , 9 , - 4 , 1 , - 1 , - 8 , - 9 ] ; let n = arr . length ; printPairs ( arr , n ) ;
function canPairs ( ar , k ) {
if ( ar . length % 2 == 1 ) return false ;
let hm = new Map ( ) ;
for ( let i = 0 ; i < ar . length ; i ++ ) { let rem = ( ( ar [ i ] % k ) + k ) % k ; if ( ! hm . has ( rem ) ) { hm . set ( rem , 0 ) ; } hm . set ( rem , hm . get ( rem ) + 1 ) ; }
for ( let i = 0 ; i < ar . length ; i ++ ) {
let rem = ( ( ar [ i ] % k ) + k ) % k ;
if ( 2 * rem == k ) {
if ( hm . get ( rem ) % 2 == 1 ) return false ; }
else if ( rem == 0 ) {
if ( hm . get ( rem ) % 2 == 1 ) return false ; }
else { if ( hm . get ( k - rem ) != hm . get ( rem ) ) return false ; } } return true ; }
let arr = [ 92 , 75 , 65 , 48 , 45 , 35 ] ; let k = 10 ;
let ans = canPairs ( arr , k ) ; if ( ans ) document . write ( " " ) ; else document . write ( " " ) ;
function findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) { for ( var i = 0 ; i < n1 ; i ++ ) for ( var j = 0 ; j < n2 ; j ++ ) for ( var k = 0 ; k < n3 ; k ++ ) if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) return true ; return false ; }
var a1 = [ 1 , 2 , 3 , 4 , 5 ] ; var a2 = [ 2 , 3 , 6 , 1 , 2 ] ; var a3 = [ 3 , 2 , 4 , 5 , 6 ] ; var sum = 9 ; var n1 = a1 . length ; var n2 = a2 . length ; var n3 = a3 . length ; findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) ? document . write ( " " ) : document . write ( " " ) ;
function maxLen ( arr ) {
let hM = new Map ( ) ;
let sum = 0 ;
let max_len = 0 ;
for ( let i = 0 ; i < arr . length ; i ++ ) {
sum += arr [ i ] ; if ( arr [ i ] == 0 && max_len == 0 ) max_len = 1 ; if ( sum == 0 ) max_len = i + 1 ;
let prev_i = hM . get ( sum ) ; if ( prev_i != null ) max_len = Math . max ( max_len , i - prev_i ) ;
else hM . set ( sum , i ) ; } return max_len ; }
let arr = [ 15 , - 2 , 2 , - 8 , 1 , 7 , 10 , 23 ] ; document . write ( " " + maxLen ( arr ) ) ;
function longestSubsequence ( a , n ) {
var mp = new Map ( ) ;
var dp = Array ( n ) . fill ( 0 ) ; var maximum = - 1000000000 ;
for ( var i = 0 ; i < n ; i ++ ) {
if ( mp . has ( a [ i ] - 1 ) ) {
var lastIndex = mp . get ( a [ i ] - 1 ) - 1 ; dp [ i ] = 1 + dp [ lastIndex ] ; } else dp [ i ] = 1 ; mp . set ( a [ i ] , i + 1 ) ; maximum = Math . max ( maximum , dp [ i ] ) ; } return maximum ; }
var a = [ 3 , 10 , 3 , 11 , 4 , 5 , 6 , 7 , 8 , 12 ] ; var n = a . length ; document . write ( longestSubsequence ( a , n ) ) ;
function longLenSub ( arr , n ) {
let um = new Map ( ) ;
let longLen = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
let len = 0 ;
if ( um . has ( arr [ i ] - 1 ) && len < um . get ( arr [ i ] - 1 ) ) len = um . get ( arr [ i ] - 1 ) ;
if ( um . has ( arr [ i ] + 1 ) && len < um . get ( arr [ i ] + 1 ) ) len = um . get ( arr [ i ] + 1 ) ;
um . set ( arr [ i ] , len + 1 ) ;
if ( longLen < um . get ( arr [ i ] ) ) longLen = um . get ( arr [ i ] ) ; }
return longLen ; }
let arr = [ 1 , 2 , 3 , 4 , 5 , 3 , 2 ] ; let n = arr . length ; document . write ( " " + longLenSub ( arr , n ) ) ;
function countWindowDistinct ( win , k ) { let dist_count = 0 ;
for ( let i = 0 ; i < k ; i ++ ) {
let j ; for ( j = 0 ; j < i ; j ++ ) if ( win [ i ] == win [ j ] ) break ; if ( j == i ) dist_count ++ ; } return dist_count ; }
function countDistinct ( arr , n , k ) {
for ( let i = 0 ; i <= n - k ; i ++ ) document . write ( countWindowDistinct ( arr . slice ( i , arr . length ) , k ) + " " ) ; }
let arr = [ 1 , 2 , 1 , 3 , 4 , 2 , 3 ] , k = 4 ; countDistinct ( arr , arr . length , k ) ;
function areElementsContiguous ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ;
for ( let i = 1 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] > 1 ) return false ; return true ; }
let arr = [ 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ] ; let n = arr . length ; if ( areElementsContiguous ( arr , n ) ) document . write ( " " ) ; else document . write ( " " ) ;
function areElementsContiguous ( arr , n ) {
let max = Number . MIN_VALUE ; let min = Number . MAX_VALUE ; for ( let i = 0 ; i < n ; i ++ ) { max = Math . max ( max , arr [ i ] ) ; min = Math . min ( min , arr [ i ] ) ; } let m = max - min + 1 ;
if ( m > n ) return false ;
let visited = new Array ( n ) ; visited . fill ( false ) ;
for ( let i = 0 ; i < n ; i ++ ) visited [ arr [ i ] - min ] = true ;
for ( let i = 0 ; i < m ; i ++ ) if ( visited [ i ] == false ) return false ; return true ; }
let arr = [ 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ] ; let n = arr . length ; if ( areElementsContiguous ( arr , n ) ) document . write ( " " ) ; else document . write ( " " ) ;
function areElementsContiguous ( arr , n ) {
var us = new Set ( ) ; for ( var i = 0 ; i < n ; i ++ ) us . add ( arr [ i ] ) ;
var count = 1 ;
var curr_ele = arr [ 0 ] - 1 ;
while ( us . has ( curr_ele ) ) {
count ++ ;
curr_ele -- ; }
curr_ele = arr [ 0 ] + 1 ;
while ( us . has ( curr_ele ) ) {
count ++ ;
curr_ele ++ ; }
return ( count == ( us . size ) ) ; }
var arr = [ 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ] ; var n = arr . length ; if ( areElementsContiguous ( arr , n ) ) document . write ( " " ) ; else document . write ( " " ) ;
function subArraySum ( arr , n , sum ) {
let cur_sum = 0 ; let start = 0 ; let end = - 1 ; let hashMap = new Map ( ) ; for ( let i = 0 ; i < n ; i ++ ) { cur_sum = cur_sum + arr [ i ] ;
if ( cur_sum - sum == 0 ) { start = 0 ; end = i ; break ; }
if ( hashMap . has ( cur_sum - sum ) ) { start = hashMap . get ( cur_sum - sum ) + 1 ; end = i ; break ; }
hashMap . set ( cur_sum , i ) ; }
if ( end == - 1 ) { document . write ( " " ) ; } else { document . write ( " " + start + " " + end ) ; } }
let arr = [ 10 , 2 , - 2 , - 20 , 10 ] ; let n = arr . length ; let sum = - 10 ; subArraySum ( arr , n , sum ) ;
function minInsertion ( str ) {
let n = str . length ;
let res = 0 ;
let count = new Array ( 26 ) ; for ( let i = 0 ; i < count . length ; i ++ ) { count [ i ] = 0 ; }
for ( let i = 0 ; i < n ; i ++ ) count [ str [ i ] . charCodeAt ( 0 ) - ' ' . charCodeAt ( 0 ) ] ++ ;
for ( let i = 0 ; i < 26 ; i ++ ) { if ( count [ i ] % 2 == 1 ) res ++ ; }
return ( res == 0 ) ? 0 : res - 1 ; }
let str = " " ; document . write ( minInsertion ( str ) ) ;
function maxdiff ( arr , n ) { let freq = new Map ( ) ;
for ( let i = 0 ; i < n ; i ++ ) freq . set ( arr [ i ] , freq . get ( arr [ i ] ) == null ? 1 : freq . get ( arr [ i ] ) + 1 ) ; let ans = 0 ; for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( freq . get ( arr [ i ] ) > freq . get ( arr [ j ] ) && arr [ i ] > arr [ j ] ) ans = Math . max ( ans , freq . get ( arr [ i ] ) - freq . get ( arr [ j ] ) ) ; else if ( freq . get ( arr [ i ] ) < freq . get ( arr [ j ] ) && arr [ i ] < arr [ j ] ) ans = Math . max ( ans , freq . get ( arr [ j ] ) - freq . get ( arr [ i ] ) ) ; } } return ans ; }
let arr = [ 3 , 1 , 3 , 2 , 3 , 2 ] ; let n = arr . length ; document . write ( maxdiff ( arr , n ) ) ;
function findDiff ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ; let count = 0 , max_count = 0 , min_count = n ; for ( let i = 0 ; i < ( n - 1 ) ; i ++ ) {
if ( arr [ i ] == arr [ i + 1 ] ) { count += 1 ; continue ; } else { max_count = Math . max ( max_count , count ) ; min_count = Math . min ( min_count , count ) ; count = 0 ; } } return ( max_count - min_count ) ; }
let arr = [ 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 ] ; let n = arr . length ; document . write ( findDiff ( arr , n ) ) ;
function maxDiff ( arr , n ) { let SubsetSum_1 = 0 , SubsetSum_2 = 0 ; for ( let i = 0 ; i <= n - 1 ; i ++ ) { let isSingleOccurance = true ; for ( let j = i + 1 ; j <= n - 1 ; j ++ ) {
if ( arr [ i ] == arr [ j ] ) { isSingleOccurance = false ; arr [ i ] = arr [ j ] = 0 ; break ; } } if ( isSingleOccurance ) { if ( arr [ i ] > 0 ) SubsetSum_1 += arr [ i ] ; else SubsetSum_2 += arr [ i ] ; } } return Math . abs ( SubsetSum_1 - SubsetSum_2 ) ; }
let arr = [ 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 ] ; let n = arr . length ; document . write ( " " + maxDiff ( arr , n ) ) ;
function maxDiff ( arr , n ) { var result = 0 ;
arr . sort ( ( a , b ) => a - b )
for ( var i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) result += Math . abs ( arr [ i ] ) ; else i ++ ; }
if ( arr [ n - 2 ] != arr [ n - 1 ] ) result += Math . abs ( arr [ n - 1 ] ) ;
return result ; }
var arr = [ 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 ] ; var n = arr . length ; document . write ( " " + maxDiff ( arr , n ) ) ;
function maxDiff ( arr , n ) { let hashPositive = new Map ( ) ; let hashNegative = new Map ( ) ; let SubsetSum_1 = 0 , SubsetSum_2 = 0 ;
for ( let i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] > 0 ) { if ( hashPositive . has ( arr [ i ] ) ) { hashPositive . set ( arr [ i ] , hashPositive . get ( arr [ i ] ) + 1 ) ; } else { hashPositive . set ( arr [ i ] , 1 ) ; } } }
for ( let i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] > 0 && hashPositive . has ( arr [ i ] ) ) { if ( hashPositive . get ( arr [ i ] ) == 1 ) { SubsetSum_1 += arr [ i ] ; } } }
for ( let i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] < 0 ) { if ( hashNegative . has ( Math . abs ( arr [ i ] ) ) ) { hashNegative . set ( Math . abs ( arr [ i ] ) , hashNegative . get ( Math . abs ( arr [ i ] ) ) + 1 ) ; } else { hashNegative . set ( Math . abs ( arr [ i ] ) , 1 ) ; } } }
for ( let i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] < 0 && hashNegative . has ( Math . abs ( arr [ i ] ) ) ) { if ( hashNegative . get ( Math . abs ( arr [ i ] ) ) == 1 ) { SubsetSum_2 += arr [ i ] ; } } } return Math . abs ( SubsetSum_1 - SubsetSum_2 ) ; }
let arr = [ 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 ] ; let n = arr . length ; document . write ( " " + maxDiff ( arr , n ) ) ;
function minRange ( arr , n , k ) { let l = 0 , r = n ;
for ( let i = 0 ; i < n ; i ++ ) {
let s = new Set ( ) ; let j ; for ( j = i ; j < n ; j ++ ) { s . add ( arr [ j ] ) ; if ( s . size == k ) { if ( ( j - i ) < ( r - l ) ) { r = j ; l = i ; } break ; } }
if ( j == n ) break ; }
if ( l == 0 && r == n ) document . write ( " " ) ; else document . write ( l + " " + r ) ; }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ; let n = arr . length ; let k = 3 ; minRange ( arr , n , k ) ;
function minRange ( arr , n , k ) {
let l = 0 , r = n ;
let j = - 1 ; let hm = new Map ( ) ; for ( let i = 0 ; i < n ; i ++ ) { while ( j < n ) {
j ++ ;
if ( j < n && hm . size < k ) { if ( hm . has ( arr [ j ] ) ) hm . set ( arr [ j ] , hm . get ( arr [ j ] ) + 1 ) ; else hm . set ( arr [ j ] , 1 ) ; }
if ( hm . size == k && ( ( r - l ) >= ( j - i ) ) ) { l = i ; r = j ; break ; } }
if ( hm . size < k ) break ;
while ( hm . size == k ) { if ( hm . has ( arr [ i ] ) && hm . get ( arr [ i ] ) == 1 ) hm . delete ( arr [ i ] ) ; else if ( hm . has ( arr [ i ] ) ) hm . set ( arr [ i ] , hm . get ( arr [ i ] ) - 1 ) ;
i ++ ;
if ( hm . size == k && ( r - l ) >= ( j - i ) ) { l = i ; r = j ; } } if ( hm . has ( arr [ i ] ) && hm . get ( arr [ i ] ) == 1 ) hm . delete ( arr [ i ] ) ; else if ( hm . has ( arr [ i ] ) ) hm . set ( arr [ i ] , hm . get ( arr [ i ] ) - 1 ) ; } if ( l == 0 && r == n ) document . write ( " " ) ; else document . write ( l + " " + r ) ; }
let arr = [ 1 , 1 , 2 , 2 , 3 , 3 , 4 , 5 ] ; let n = arr . length ; let k = 3 ; minRange ( arr , n , k ) ;
function longest ( a , n , k ) { var freq = Array ( 7 ) . fill ( 0 ) ; var start = 0 , end = 0 , now = 0 , l = 0 ; for ( var i = 0 ; i < n ; i ++ ) {
freq [ a [ i ] ] ++ ;
if ( freq [ a [ i ] ] == 1 ) now ++ ;
while ( now > k ) {
freq [ a [ l ] ] -- ;
if ( freq [ a [ l ] ] == 0 ) now -- ;
l ++ ; }
if ( i - l + 1 >= end - start + 1 ) { end = i ; start = l ; } }
for ( var i = start ; i <= end ; i ++ ) document . write ( a [ i ] + " " ) ; }
var a = [ 6 , 5 , 1 , 2 , 3 , 2 , 1 , 4 , 5 ] ; var n = a . length ; var k = 3 ; longest ( a , n , k ) ;
function sum ( a , n ) {
var cnt = new Map ( ) ;
var ans = 0 , pre_sum = 0 ; for ( var i = 0 ; i < n ; i ++ ) { ans += ( i * a [ i ] ) - pre_sum ; pre_sum += a [ i ] ;
if ( cnt . has ( a [ i ] - 1 ) ) ans -= cnt . get ( a [ i ] - 1 ) ;
if ( cnt . has ( a [ i ] + 1 ) ) ans += cnt . get ( a [ i ] + 1 ) ;
if ( cnt . has ( a [ i ] ) ) cnt . set ( a [ i ] , cnt . get ( a [ i ] ) + 1 ) else cnt . set ( a [ i ] , 1 ) } return ans ; }
var a = [ 1 , 2 , 3 , 1 , 3 ] ; var n = a . length ; document . write ( sum ( a , n ) ) ;
function calculate ( a , n ) {
a . sort ( ) ; let count = 1 ; let answer = 0 ;
for ( let i = 1 ; i < n ; i ++ ) { if ( a [ i ] == a [ i - 1 ] ) {
count += 1 ; } else {
answer = answer + Math . floor ( ( count * ( count - 1 ) ) / 2 ) ; count = 1 ; } } answer = answer + Math . floor ( ( count * ( count - 1 ) ) / 2 ) ; return answer ; }
let a = [ 1 , 2 , 1 , 2 , 4 ] ; let n = a . length ;
document . write ( calculate ( a , n ) ) ;
function calculate ( a , n ) {
let maximum = Math . max ( ... a ) ;
let frequency = new Array ( maximum + 1 ) . fill ( 0 ) ;
for ( let i = 0 ; i < n ; i ++ ) {
frequency [ a [ i ] ] += 1 ; } let answer = 0 ;
for ( let i = 0 ; i < maximum + 1 ; i ++ ) {
answer = answer + frequency [ i ] * ( frequency [ i ] - 1 ) ; } return parseInt ( answer / 2 ) ; }
let a = [ 1 , 2 , 1 , 2 , 4 ] ; let n = a . length ;
document . write ( calculate ( a , n ) ) ;
function countSubarrWithEqualZeroAndOne ( arr , n ) {
var um = new Map ( ) ; var curr_sum = 0 ;
for ( var i = 0 ; i < n ; i ++ ) { curr_sum += ( arr [ i ] == 0 ) ? - 1 : arr [ i ] ; if ( um . has ( curr_sum ) ) um . set ( curr_sum , um . get ( curr_sum ) + 1 ) ; else um . set ( curr_sum , 1 ) } var count = 0 ;
um . forEach ( ( value , key ) => {
if ( value > 1 ) count += ( ( value * ( value - 1 ) ) / 2 ) ; } ) ;
if ( um . has ( 0 ) ) count += um . get ( 0 ) ;
return count ; }
var arr = [ 1 , 0 , 0 , 1 , 0 , 1 , 1 ] ; var n = arr . length ; document . write ( " " + countSubarrWithEqualZeroAndOne ( arr , n ) ) ;
function lenOfLongSubarr ( arr , n ) {
var um = new Map ( ) ; var sum = 0 , maxLen = 0 ;
for ( var i = 0 ; i < n ; i ++ ) {
sum += arr [ i ] == 0 ? - 1 : 1 ;
if ( sum == 1 ) maxLen = i + 1 ;
else if ( ! um . has ( sum ) ) um . set ( sum , i ) ;
if ( um . has ( sum - 1 ) ) {
if ( maxLen < ( i - um . get ( sum - 1 ) ) ) maxLen = i - um . get ( sum - 1 ) ; } }
return maxLen ; }
var arr = [ 0 , 1 , 1 , 0 , 0 , 1 ] ; var n = arr . length ; document . write ( " " + lenOfLongSubarr ( arr , n ) ) ;
function printAllAPTriplets ( arr , n ) { const s = new Set ( ) for ( let i = 0 ; i < n - 1 ; i ++ ) { for ( let j = i + 1 ; j < n ; j ++ ) {
let diff = arr [ j ] - arr [ i ] ; if ( s . has ( arr [ i ] - diff ) ) document . write ( arr [ i ] - diff + " " + arr [ i ] + " " + arr [ j ] + " " ) ; } s . add ( arr [ i ] ) ; } }
let arr = [ 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 ] ; let n = arr . length ; printAllAPTriplets ( arr , n ) ;
function printAllAPTriplets ( arr , n ) { for ( let i = 1 ; i < n - 1 ; i ++ ) {
for ( let j = i - 1 , k = i + 1 ; j >= 0 && k < n ; ) {
if ( arr [ j ] + arr [ k ] == 2 * arr [ i ] ) { document . write ( arr [ j ] + " " + arr [ i ] + " " + arr [ k ] + " " ) ;
k ++ ; j -- ; }
else if ( arr [ j ] + arr [ k ] < 2 * arr [ i ] ) k ++ ; else j -- ; } } }
let arr = [ 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 ] ; let n = arr . length ; printAllAPTriplets ( arr , n ) ;
function findTriplets ( a , n , sum ) { let i ;
a . sort ( function ( a , b ) { return a - b } ) ;
let flag = false ;
for ( i = 0 ; i < n - 2 ; i ++ ) { if ( i == 0 a [ i ] > a [ i - 1 ] ) {
let start = i + 1 ;
let end = n - 1 ;
let target = sum - a [ i ] ; while ( start < end ) {
if ( start > i + 1 && a [ start ] == a [ start - 1 ] ) { start ++ ; continue ; }
if ( end < n - 1 && a [ end ] == a [ end + 1 ] ) { end -- ; continue ; }
if ( target == a [ start ] + a [ end ] ) { document . write ( " " + a [ i ] + " " + a [ start ] + " " + a [ end ] + " " ) ; flag = true ; start ++ ; end -- ; }
else if ( target > ( a [ start ] + a [ end ] ) ) { start ++ ; }
else { end -- ; } } } }
if ( flag == false ) { document . write ( " " ) ; } }
let a = [ 12 , 3 , 6 , 1 , 6 , 9 ] ; let n = a . length ; let sum = 24 ;
a . sort ( ) ; findTriplets ( a , n , sum ) ;
/ *function countTriplets(arr,n,m) { let count = 0 ;
for ( let i = 0 ; i < n - 2 ; i ++ ) for ( let j = i + 1 ; j < n - 1 ; j ++ ) for ( let k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] * arr [ j ] * arr [ k ] == m ) count ++ ; return count ; }
let arr = [ 1 , 4 , 6 , 2 , 3 , 8 ] ; let m = 24 ; document . write ( countTriplets ( arr , arr . length , m ) ) ;
function countPairs ( arr , n ) { let ans = 0 ;
for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ )
if ( arr [ i ] == arr [ j ] ) ans ++ ; return ans ; }
let arr = [ 1 , 1 , 2 ] ; let n = arr . length ; document . write ( countPairs ( arr , n ) ) ;
function countPairs ( arr , n ) { let hm = new Map ( ) ;
for ( let i = 0 ; i < n ; i ++ ) { if ( hm . has ( arr [ i ] ) ) hm . set ( arr [ i ] , hm . get ( arr [ i ] ) + 1 ) ; else hm . set ( arr [ i ] , 1 ) ; } let ans = 0 ;
for ( let [ key , value ] of hm . entries ( ) ) { let count = value ; ans += ( count * ( count - 1 ) ) / 2 ; } return ans ; }
let arr = [ 1 , 2 , 3 , 1 ] ; document . write ( countPairs ( arr , arr . length ) ) ;
let N = 5 ;
let ptr = new Array ( 501 ) ;
function findSmallestRange ( arr , n , k ) { let i , minval , maxval , minrange , minel = 0 , maxel = 0 , flag , minind ;
for ( i = 0 ; i <= k ; i ++ ) { ptr [ i ] = 0 ; } minrange = Number . MAX_VALUE ; while ( true ) {
minind = - 1 ; minval = Number . MAX_VALUE ; maxval = Number . MIN_VALUE ; flag = 0 ;
for ( i = 0 ; i < k ; i ++ ) {
if ( ptr [ i ] == n ) { flag = 1 ; break ; }
if ( ptr [ i ] < n && arr [ i ] [ ptr [ i ] ] < minval ) {
minind = i ; minval = arr [ i ] [ ptr [ i ] ] ; }
if ( ptr [ i ] < n && arr [ i ] [ ptr [ i ] ] > maxval ) { maxval = arr [ i ] [ ptr [ i ] ] ; } }
if ( flag == 1 ) { break ; } ptr [ minind ] ++ ;
if ( ( maxval - minval ) < minrange ) { minel = minval ; maxel = maxval ; minrange = maxel - minel ; } } document . write ( " " + minel + " " + maxel + " " ) ; }
let arr = [ [ 4 , 7 , 9 , 12 , 15 ] , [ 0 , 8 , 10 , 14 , 20 ] , [ 6 , 12 , 16 , 30 , 50 ] ] let k = arr . length ; findSmallestRange ( arr , N , k ) ;
function countNum ( arr , n ) { let count = 0 ;
arr . sort ( ) ;
for ( let i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) count += arr [ i + 1 ] - arr [ i ] - 1 ; return count ; }
let arr = [ 3 , 5 , 8 , 6 ] ; let n = arr . length ; document . write ( countNum ( arr , n ) ) ;
function countNum ( arr , n ) { let s = new Set ( ) ; let count = 0 , maxm = Number . MIN_VALUE , minm = Number . MAX_VALUE ;
for ( let i = 0 ; i < n ; i ++ ) { s . add ( arr [ i ] ) ; if ( arr [ i ] < minm ) minm = arr [ i ] ; if ( arr [ i ] > maxm ) maxm = arr [ i ] ; }
for ( let i = minm ; i <= maxm ; i ++ ) if ( ! s . has ( i ) ) count ++ ; return count ; }
let arr = [ 3 , 5 , 8 , 6 ] ; let n = arr . length ; document . write ( countNum ( arr , n ) ) ;
function sumoflength ( arr , n ) {
let s = new Set ( ) ;
let j = 0 , ans = 0 ;
for ( let i = 0 ; i < n ; i ++ ) { while ( j < n && ! s . has ( arr [ j ] ) ) { s . add ( arr [ i ] ) ; j ++ ; }
ans += Math . floor ( ( ( j - i ) * ( j - i + 1 ) ) / 2 ) ;
s . delete ( arr [ i ] ) ; } return ans ; }
let arr = [ 1 , 2 , 3 , 4 ] ; let n = arr . length ; document . write ( sumoflength ( arr , n ) ) ;
/ *function countDistictSubarray(arr,n) {
let vis = new Map ( ) ; for ( let i = 0 ; i < n ; ++ i ) vis . set ( arr [ i ] , 1 ) ; let k = vis . size ;
let vid = new Map ( ) ;
let ans = 0 , right = 0 , window = 0 ; for ( let left = 0 ; left < n ; left ++ ) { while ( right < n && window < k ) { if ( vid . has ( arr [ right ] ) ) vid . set ( arr [ right ] , vid . get ( arr [ right ] ) + 1 ) ; else vid . set ( arr [ right ] , 1 ) ; if ( vid . get ( arr [ right ] ) == 1 ) window ++ ; right ++ ; }
if ( window == k ) ans += ( n - right + 1 ) ;
if ( vid . has ( arr [ left ] ) ) vid . set ( arr [ left ] , vid . get ( arr [ left ] ) - 1 ) ;
if ( vid . get ( arr [ left ] ) == 0 ) -- window ; } return ans ; }
let arr = [ 2 , 1 , 3 , 2 , 3 ] ; document . write ( countDistictSubarray ( arr , arr . length ) ) ;
function countSubarrays ( arr , n ) {
let difference = 0 ; let ans = 0 ;
for ( let i = 0 ; i < n + 1 ; i ++ ) { hash_positive [ i ] = 0 ; hash_negative [ i ] = 0 ; }
hash_positive [ 0 ] = 1 ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( ( arr [ i ] & 1 ) == 1 ) { difference ++ ; } else { difference -- ; }
if ( difference < 0 ) { ans += hash_negative [ - difference ] ; hash_negative [ - difference ] ++ ; }
else { ans += hash_positive [ difference ] ; hash_positive [ difference ] ++ ; } }
return ans ; }
let arr = [ 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 ] ; let n = arr . length ;
document . write ( " " + " " + countSubarrays ( arr , n ) ) ;
class Node { constructor ( val ) { this . data = val ; this . left = this . right = null ; } } let ans , lh , rh , f ; let k ; let Root ;
function height ( root ) { if ( root == null ) return 0 ; let left_height = height ( root . left ) ; let right_height = height ( root . right ) ;
if ( ans < 1 + left_height + right_height ) { ans = 1 + left_height + right_height ;
k = root ;
lh = left_height ; rh = right_height ; } return 1 + Math . max ( left_height , right_height ) ; }
function printArray ( ints , len ) { let i ;
if ( f == 0 ) { for ( i = len - 1 ; i >= 0 ; i -- ) { document . write ( ints [ i ] + " " ) ; } } else if ( f == 1 ) { for ( i = 0 ; i < len ; i ++ ) { document . write ( ints [ i ] + " " ) ; } } }
function printPathsRecur ( node , path , pathLen , max ) { if ( node == null ) return ;
path [ pathLen ] = node . data ; pathLen ++ ;
if ( node . left == null && node . right == null ) {
if ( pathLen == max && ( f == 0 f == 1 ) ) { printArray ( path , pathLen ) ; f = 2 ; } } else {
printPathsRecur ( node . left , path , pathLen , max ) ; printPathsRecur ( node . right , path , pathLen , max ) ; } }
function diameter ( root ) { if ( root == null ) return ;
ans = Number . MIN_VALUE ; lh = 0 ; rh = 0 ;
f = 0 ; let height_of_tree = height ( root ) ; let lPath = new Array ( 100 ) ; let pathlen = 0 ;
printPathsRecur ( k . left , lPath , pathlen , lh ) ; document . write ( k . data + " " ) ; let rPath = new Array ( 100 ) ; f = 1 ;
printPathsRecur ( k . right , rPath , pathlen , rh ) ; }
Root = new Node ( 1 ) ; Root . left = new Node ( 2 ) ; Root . right = new Node ( 3 ) ; Root . left . left = new Node ( 4 ) ; Root . left . right = new Node ( 5 ) ; Root . left . right . left = new Node ( 6 ) ; Root . left . right . right = new Node ( 7 ) ; Root . left . left . right = new Node ( 8 ) ; Root . left . left . right . left = new Node ( 9 ) ; diameter ( Root ) ;
function findLargestd ( S , n ) { let found = false ;
S . sort ( ) ;
for ( let i = n - 1 ; i >= 0 ; i -- ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( i == j ) continue ; for ( let k = j + 1 ; k < n ; k ++ ) { if ( i == k ) continue ; for ( let l = k + 1 ; l < n ; l ++ ) { if ( i == l ) continue ;
if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) { found = true ; return S [ i ] ; } } } } } if ( found == false ) return Number . MAX_VALUE ; return - 1 ; }
let S = [ 2 , 3 , 5 , 7 , 12 ] ; let n = S . length ; let ans = findLargestd ( S , n ) ; if ( ans == Number . MAX_VALUE ) document . write ( " " ) ; else document . write ( " " + " " + ans ) ;
function findFourElements ( arr , n ) { let map = new Map ( ) ;
for ( let i = 0 ; i < n - 1 ; i ++ ) { for ( let j = i + 1 ; j < n ; j ++ ) { map . set ( arr [ i ] + arr [ j ] , new Indexes ( i , j ) ) ; } } let d = Number . MIN_VALUE ;
for ( let i = 0 ; i < n - 1 ; i ++ ) { for ( let j = i + 1 ; j < n ; j ++ ) { let abs_diff = Math . abs ( arr [ i ] - arr [ j ] ) ;
if ( map . has ( abs_diff ) ) { let indexes = map . get ( abs_diff ) ;
if ( indexes . getI ( ) != i && indexes . getI ( ) != j && indexes . getJ ( ) != i && indexes . getJ ( ) != j ) { d = Math . max ( d , Math . max ( arr [ i ] , arr [ j ] ) ) ; } } } } return d ; }
let arr = [ 2 , 3 , 5 , 7 , 12 ] ; let n = arr . length ; let res = findFourElements ( arr , n ) ; if ( res == Number . MIN_VALUE ) document . write ( " " ) ; else document . write ( res ) ;
function recaman ( n ) {
let arr = new Array ( n ) ;
arr [ 0 ] = 0 ; document . write ( arr [ 0 ] + " " ) ;
for ( let i = 1 ; i < n ; i ++ ) { let curr = arr [ i - 1 ] - i ; let j ; for ( j = 0 ; j < i ; j ++ ) {
if ( ( arr [ j ] == curr ) curr < 0 ) { curr = arr [ i - 1 ] + i ; break ; } } arr [ i ] = curr ; document . write ( arr [ i ] + " " ) ; } }
let n = 17 ; recaman ( n ) ;
function recaman ( n ) { if ( n <= 0 ) return ;
document . write ( 0 + " " ) ; let s = new Set ( ) ; s . add ( 0 ) ;
let prev = 0 ; for ( let i = 1 ; i < n ; i ++ ) { let curr = prev - i ;
if ( curr < 0 || s . has ( curr ) ) curr = prev + i ; s . add ( curr ) ; document . write ( curr + " " ) ; prev = curr ; } }
let n = 17 ; recaman ( n ) ;
function sumOfDiv ( x ) {
let sum = 1 ; for ( let i = 2 ; i <= Math . sqrt ( x ) ; i ++ ) { if ( x % i == 0 ) { sum += i ;
if ( x / i != i ) sum += x / i ; } } return sum ; }
function isAmicable ( a , b ) { return ( sumOfDiv ( a ) == b && sumOfDiv ( b ) == a ) ; }
function countPairs ( arr , n ) {
let s = new Set ( ) ; let count = 0 ; for ( let i = 0 ; i < n ; i ++ ) s . add ( arr [ i ] ) ;
for ( let i = 0 ; i < n ; i ++ ) { if ( s . has ( sumOfDiv ( arr [ i ] ) ) ) {
let sum = sumOfDiv ( arr [ i ] ) ; if ( isAmicable ( arr [ i ] , sum ) ) count ++ ; } }
return Math . floor ( count / 2 ) ; }
let arr1 = [ 220 , 284 , 1184 , 1210 , 2 , 5 ] ; let n1 = arr1 . length ; document . write ( countPairs ( arr1 , n1 ) + " " ) ; let arr2 = [ 2620 , 2924 , 5020 , 5564 , 6232 , 6368 ] ; let n2 = arr2 . length ; document . write ( countPairs ( arr2 , n2 ) + " " ) ;
function findArea ( arr , n ) {
arr . sort ( ( a , b ) => { return b - a ; } )
var dimension = [ 0 , 0 ] ;
for ( var i = 0 , j = 0 ; i < n - 1 && j < 2 ; i ++ )
if ( arr [ i ] == arr [ i + 1 ] ) dimension [ j ++ ] = arr [ i ++ ] ;
return ( dimension [ 0 ] * dimension [ 1 ] ) ; }
var arr = [ 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 ] ; var n = arr . length ; document . write ( findArea ( arr , n ) ) ;
function findArea ( arr , n ) { let s = new Set ( ) ;
let first = 0 , second = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( ! s . has ( arr [ i ] ) ) { s . add ( arr [ i ] ) ; continue ; }
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; } else if ( arr [ i ] > second ) second = arr [ i ] ; }
return ( first * second ) ; }
let arr = [ 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 ] ; let n = arr . length ; document . write ( findArea ( arr , n ) ) ;
let MAX_PATH_SIZE = 1000 ;
class Node {
function printPath ( path , size ) {
let minimum_Hd = Number . MAX_VALUE ; let p ;
for ( let it = 0 ; it < size ; it ++ ) { p = path [ it ] ; minimum_Hd = Math . min ( minimum_Hd , p . Hd ) ; }
for ( let it = 0 ; it < size ; it ++ ) {
p = path [ it ] ; let noOfUnderScores = Math . abs ( p . Hd - minimum_Hd ) ;
for ( let i = 0 ; i < noOfUnderScores ; i ++ ) document . write ( " " ) ;
document . write ( p . key + " " ) ; } document . write ( " " ) ; }
function printAllPathsUtil ( root , AllPath , HD , order ) {
if ( root == null ) return ;
if ( root . left == null && root . right == null ) {
AllPath [ order ] = new PATH ( HD , root . data ) ; printPath ( AllPath , order + 1 ) ; return ; }
AllPath [ order ] = new PATH ( HD , root . data ) ;
printAllPathsUtil ( root . left , AllPath , HD - 1 , order + 1 ) ;
printAllPathsUtil ( root . right , AllPath , HD + 1 , order + 1 ) ; } function printAllPaths ( root ) {
if ( root == null ) return ; let Allpaths = [ ] ; for ( let i = 0 ; i < MAX_PATH_SIZE ; i ++ ) { Allpaths . push ( new PATH ( ) ) ; } printAllPathsUtil ( root , Allpaths , 0 , 0 ) ; }
let root = new Node ( ' ' ) ; root . left = new Node ( ' ' ) ; root . right = new Node ( ' ' ) ; root . left . left = new Node ( ' ' ) ; root . left . right = new Node ( ' ' ) ; root . right . left = new Node ( ' ' ) ; root . right . right = new Node ( ' ' ) ; printAllPaths ( root ) ;
function longLenStrictBitonicSub ( arr , n ) {
var inc = new Map ( ) , dcr = new Map ( ) ;
var len_inc = Array ( n ) , len_dcr = Array ( n ) ;
var longLen = 0 ;
for ( var i = 0 ; i < n ; i ++ ) {
var len = 0 ;
if ( inc . has ( arr [ i ] - 1 ) ) len = inc . get ( arr [ i ] - 1 ) ;
len_inc [ i ] = len + 1 ; inc . set ( arr [ i ] , len_inc [ i ] ) ; }
for ( var i = n - 1 ; i >= 0 ; i -- ) {
var len = 0 ;
if ( dcr . has ( arr [ i ] - 1 ) ) len = dcr . get ( arr [ i ] - 1 ) ;
len_dcr [ i ] = len + 1 ; dcr . set ( arr [ i ] , len_dcr [ i ] ) ; }
for ( var i = 0 ; i < n ; i ++ ) if ( longLen < ( len_inc [ i ] + len_dcr [ i ] - 1 ) ) longLen = len_inc [ i ] + len_dcr [ i ] - 1 ;
return longLen ; }
var arr = [ 1 , 5 , 2 , 3 , 4 , 5 , 3 , 2 ] ; var n = arr . length ; document . write ( " " + longLenStrictBitonicSub ( arr , n ) ) ;
let leftRotate = ( arr , d , n ) => {
if ( d == 0 d == n ) return ;
if ( n - d == d ) { arr = swap ( arr , 0 , n - d , d ) ; return ; }
if ( d < n - d ) { arr = swap ( arr , 0 , n - d , d ) ; leftRotate ( arr , d , n - d ) ; }
else { arr = swap ( arr , 0 , d , n - d ) ; leftRotate ( arr + n - d , 2 * d - n , d ) ; } }
let printArray = ( arr , size ) => { ans = ' ' for ( let i = 0 ; i < size ; i ++ ) ans += arr [ i ] + " " ; document . write ( ans ) }
let swap = ( arr , fi , si , d ) => { for ( let i = 0 ; i < d ; i ++ ) { let temp = arr [ fi + i ] ; arr [ fi + i ] = arr [ si + i ] ; arr [ si + i ] = temp ; } return arr }
arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ; leftRotate ( arr , 2 , 7 ) ; printArray ( arr , 7 ) ;
function leftRotate ( arr , d , n ) { if ( d == 0 d == n ) return ; let i = d ; let j = n - d ; while ( i != j ) {
if ( i < j ) { arr = swap ( arr , d - i , d + j - i , i ) ; j -= i ; }
else { arr = swap ( arr , d - i , d , j ) ; i -= j ; } }
arr = swap ( arr , d - i , d , i ) ; }
function search ( arr , l , h , key ) { if ( l > h ) return - 1 ; let mid = Math . floor ( ( l + h ) / 2 ) ; if ( arr [ mid ] == key ) return mid ;
if ( arr [ l ] <= arr [ mid ] ) {
if ( key >= arr [ l ] && key <= arr [ mid ] ) return search ( arr , l , mid - 1 , key ) ;
return search ( arr , mid + 1 , h , key ) ; }
if ( key >= arr [ mid ] && key <= arr [ h ] ) return search ( arr , mid + 1 , h , key ) ; return search ( arr , l , mid - 1 , key ) ; }
let arr = [ 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 ] ; let n = arr . length ; let key = 6 ; let i = search ( arr , 0 , n - 1 , key ) ; if ( i != - 1 ) document . write ( " " + i + " " ) ; else document . write ( " " ) ;
function pairInSortedRotated ( arr , n , x ) {
let i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
let l = ( i + 1 ) % n ;
let r = i ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) return true ;
if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return false ; }
let arr = [ 11 , 15 , 6 , 8 , 9 , 10 ] ; let sum = 16 ; let n = arr . length ; if ( pairInSortedRotated ( arr , n , sum ) ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ;
function pairsInSortedRotated ( arr , n , x ) {
let i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
let l = ( i + 1 ) % n ;
let r = i ;
let cnt = 0 ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) { cnt ++ ;
if ( l == ( r - 1 + n ) % n ) { return cnt ; } l = ( l + 1 ) % n ; r = ( r - 1 + n ) % n ; }
else if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return cnt ; }
let arr = [ 11 , 15 , 6 , 7 , 9 , 10 ] ; let sum = 16 ; let n = arr . length ; document . write ( pairsInSortedRotated ( arr , n , sum ) ) ;
function maxSum ( arr , n ) {
let arrSum = 0 ;
let currVal = 0 ; for ( let i = 0 ; i < n ; i ++ ) { arrSum = arrSum + arr [ i ] ; currVal = currVal + ( i * arr [ i ] ) ; }
let maxVal = currVal ;
for ( let j = 1 ; j < n ; j ++ ) { currVal = currVal + arrSum - n * arr [ n - j ] ; if ( currVal > maxVal ) maxVal = currVal ; }
return maxVal ; }
let arr = [ 10 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ] ; let n = arr . length ; document . write ( " " + maxSum ( arr , n ) ) ;
function maxSum ( arr , n ) {
var res = Number . MIN_VALUE ;
for ( i = 0 ; i < n ; i ++ ) {
var curr_sum = 0 ;
for ( j = 0 ; j < n ; j ++ ) { var index = ( i + j ) % n ; curr_sum += j * arr [ index ] ; }
res = Math . max ( res , curr_sum ) ; } return res ; }
var arr = [ 8 , 3 , 1 , 2 ] ; var n = arr . length ; document . write ( maxSum ( arr , n ) ) ;
function maxSum ( arr , n ) {
let cum_sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) cum_sum += arr [ i ] ;
let curr_val = 0 ; for ( let i = 0 ; i < n ; i ++ ) curr_val += i * arr [ i ] ;
let res = curr_val ;
for ( let i = 1 ; i < n ; i ++ ) {
let next_val = curr_val - ( cum_sum - arr [ i - 1 ] ) + arr [ i - 1 ] * ( n - 1 ) ;
curr_val = next_val ;
res = Math . max ( res , next_val ) ; } return res ; }
let arr = [ 8 , 3 , 1 , 2 ] ; let n = arr . length ; document . write ( maxSum ( arr , n ) + " " ) ;
function countRotations ( arr , n ) {
let min = arr [ 0 ] , min_index = - 1 ; for ( let i = 0 ; i < n ; i ++ ) { if ( min > arr [ i ] ) { min = arr [ i ] ; min_index = i ; } } return min_index ; }
let arr = [ 15 , 18 , 2 , 3 , 6 , 12 ] ; let n = arr . length ; document . write ( countRotations ( arr , n ) ) ;
function countRotations ( arr , low , high ) {
if ( high < low ) return 0 ;
if ( high == low ) return low ;
let mid = Math . floor ( low + ( high - low ) / 2 ) ;
if ( mid < high && arr [ mid + 1 ] < arr [ mid ] ) return ( mid + 1 ) ;
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) return mid ;
if ( arr [ high ] > arr [ mid ] ) return countRotations ( arr , low , mid - 1 ) ; return countRotations ( arr , mid + 1 , high ) ; }
let arr = [ 15 , 18 , 2 , 3 , 6 , 12 ] ; let n = arr . length ; document . write ( countRotations ( arr , 0 , n - 1 ) ) ;
function preprocess ( arr , n , temp ) {
for ( i = 0 ; i < n ; i ++ ) temp [ i ] = temp [ i + n ] = arr [ i ] ; }
function leftRotate ( arr , n , k , temp ) {
var start = k % n ;
for ( i = start ; i < start + n ; i ++ ) document . write ( temp [ i ] + " " ) ; document . write ( " " ) ; }
var arr = [ 1 , 3 , 5 , 7 , 9 ] ; var n = arr . length ; var temp = Array ( 2 * n ) . fill ( 0 ) ; preprocess ( arr , n , temp ) ; var k = 2 ; leftRotate ( arr , n , k , temp ) ; k = 3 ; leftRotate ( arr , n , k , temp ) ; k = 4 ; leftRotate ( arr , n , k , temp ) ;
function leftRotate ( arr , n , k ) {
for ( let i = k ; i < k + n ; i ++ ) document . write ( arr [ i % n ] + " " ) ; }
let arr = [ 1 , 3 , 5 , 7 , 9 ] ; n = arr . length ; k = 2 ; leftRotate ( arr , n , k ) ; document . write ( " " ) ; k = 3 ; leftRotate ( arr , n , k ) ; document . write ( " " ) ; k = 4 ; leftRotate ( arr , n , k ) ; document . write ( " " ) ;
function findMin ( arr , low , high ) { while ( low < high ) { let mid = Math . floor ( low + ( high - low ) / 2 ) ; if ( arr [ mid ] == arr [ high ] ) high -- ; else if ( arr [ mid ] > arr [ high ] ) low = mid + 1 ; else high = mid ; } return arr [ high ] ; }
var arr1 = [ 5 , 6 , 1 , 2 , 3 , 4 ] ; var n1 = arr1 . length ; document . write ( " " + findMin ( arr1 , 0 , n1 - 1 ) + " " ) ; var arr2 = [ 1 , 2 , 3 , 4 ] ; var n2 = arr2 . length ; document . write ( " " + findMin ( arr2 , 0 , n2 - 1 ) + " " ) ; var arr3 = [ 1 ] ; var n3 = arr3 . length ; document . write ( " " + findMin ( arr3 , 0 , n3 - 1 ) + " " ) ; var arr4 = [ 1 , 2 ] ; var n4 = arr4 . length ; document . write ( " " + findMin ( arr4 , 0 , n4 - 1 ) + " " ) ; var arr5 = [ 2 , 1 ] ; var n5 = arr5 . length ; document . write ( " " + findMin ( arr5 , 0 , n5 - 1 ) + " " ) ; var arr6 = [ 5 , 6 , 7 , 1 , 2 , 3 , 4 ] ; var n6 = arr6 . length ; document . write ( " " + findMin ( arr6 , 0 , n6 - 1 ) + " " ) ; var arr7 = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ; var n7 = arr7 . length ; document . write ( " " + findMin ( arr7 , 0 , n7 - 1 ) + " " ) ; var arr8 = [ 2 , 3 , 4 , 5 , 6 , 7 , 8 , 1 ] ; var n8 = arr8 . length ; document . write ( " " + findMin ( arr8 , 0 , n8 - 1 ) + " " ) ; var arr9 = [ 3 , 4 , 5 , 1 , 2 ] ; var n9 = arr9 . length ; document . write ( " " + findMin ( arr9 , 0 , n9 - 1 ) + " " ) ;
function reverseArray ( arr , start , end ) { while ( start < end ) { let temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } return arr ; }
function rightRotate ( arr , d , n ) { arr = reverseArray ( arr , 0 , n - 1 ) ; arr = reverseArray ( arr , 0 , d - 1 ) ; arr = reverseArray ( arr , d , n - 1 ) ; return arr ; }
function printArray ( arr , size ) { for ( let i = 0 ; i < size ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 ] ; let n = arr . length ; let k = 3 ; arr = rightRotate ( arr , k , n ) ; printArray ( arr , n ) ;
function maxHamming ( arr , n ) {
let brr = new Array ( 2 * n + 1 ) ; for ( let i = 0 ; i < n ; i ++ ) brr [ i ] = arr [ i ] ; for ( let i = 0 ; i < n ; i ++ ) brr [ n + i ] = arr [ i ] ;
let maxHam = 0 ;
for ( let i = 1 ; i < n ; i ++ ) { let currHam = 0 ; for ( let j = i , k = 0 ; j < ( i + n ) ; j ++ , k ++ ) if ( brr [ j ] != arr [ k ] ) currHam ++ ;
if ( currHam == n ) return n ; maxHam = max ( maxHam , currHam ) ; } return maxHam ; }
let arr = [ 2 , 4 , 6 , 8 ] ; let n = arr . length ; document . write ( maxHamming ( arr , n ) ) ;
function leftRotate ( arr , n , k ) {
let mod = k % n ;
for ( let i = 0 ; i < n ; i ++ ) document . write ( ( arr [ ( mod + i ) % n ] ) + " " ) ; document . write ( " " ) ; }
let arr = [ 1 , 3 , 5 , 7 , 9 ] ; let n = arr . length ; let k = 2 ;
leftRotate ( arr , n , k ) ; document . write ( " " ) ; k = 3 ;
leftRotate ( arr , n , k ) ; document . write ( " " ) ; k = 4 ;
leftRotate ( arr , n , k ) ;
let findElement = ( arr , ranges , rotations , index ) => { for ( let i = rotations - 1 ; i >= 0 ; i -- ) {
let left = ranges [ i ] [ 0 ] ; let right = ranges [ i ] [ 1 ] ;
if ( left <= index && right >= index ) { if ( index == left ) index = right ; else index -- ; } }
return arr [ index ] ; }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ;
let rotations = 2 ;
let ranges = [ [ 0 , 2 ] , [ 0 , 3 ] ] ; let index = 1 ; document . write ( findElement ( arr , ranges , rotations , index ) ) ;
function splitArr ( arr , n , k ) { for ( let i = 0 ; i < k ; i ++ ) {
let x = arr [ 0 ] ; for ( let j = 0 ; j < n - 1 ; ++ j ) arr [ j ] = arr [ j + 1 ] ; arr [ n - 1 ] = x ; } }
let arr = [ 12 , 10 , 5 , 6 , 52 , 36 ] ; let n = arr . length ; let position = 2 ; splitArr ( arr , 6 , position ) ; for ( let i = 0 ; i < n ; ++ i ) document . write ( arr [ i ] + " " ) ;
function SplitAndAdd ( A , Length , rotation ) {
let tmp = new Array ( Length * 2 ) ; for ( let i = 0 ; i < tmp . length ; i ++ ) { tmp [ i ] = 0 ; }
for ( let i = 0 ; i < Length ; i ++ ) { tmp [ i ] = A [ i ] tmp [ i + Length ] = A [ i ] } for ( let i = rotation ; i < rotation + Length ; i ++ ) { A [ i - rotation ] = tmp [ i ] ; } }
let arr = [ 12 , 10 , 5 , 6 , 52 , 36 ] ; let n = arr . length ; let position = 2 ; SplitAndAdd ( arr , n , position ) ; for ( let i = 0 ; i < n ; ++ i ) document . write ( arr [ i ] + " " ) ;
function fixArray ( ar , n ) { var i , j , temp ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) {
if ( ar [ j ] == i ) { temp = ar [ j ] ; ar [ j ] = ar [ i ] ; ar [ i ] = temp ; break ; } } }
for ( i = 0 ; i < n ; i ++ ) {
if ( ar [ i ] != i ) { ar [ i ] = - 1 ; } }
document . write ( " " ) ; document . write ( " " ) ; for ( i = 0 ; i < n ; i ++ ) { document . write ( ar [ i ] + " " ) ; } }
var n , ar = [ - 1 , - 1 , 6 , 1 , 9 , 3 , 2 , - 1 , 4 , - 1 ] ; n = ar . length ;
fixArray ( ar , n ) ;
function rearrangeArr ( arr , n ) {
let evenPos = Math . floor ( n / 2 ) ;
let oddPos = n - evenPos ; let tempArr = new Array ( n ) ;
for ( let i = 0 ; i < n ; i ++ ) tempArr [ i ] = arr [ i ] ;
tempArr . sort ( ) ; let j = oddPos - 1 ;
for ( let i = 0 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j -- ; } j = oddPos ;
for ( let i = 1 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j ++ ; }
for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ; let size = arr . length ; rearrangeArr ( arr , size ) ;
function pushZerosToEnd ( arr , n ) {
let count = 0 ;
for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
let arr = [ 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 ] ; let n = arr . length ; pushZerosToEnd ( arr , n ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function moveZerosToEnd ( arr , n ) {
let count = 0 ;
for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 ) { temp = arr [ count ] ; arr [ count ] = arr [ i ] ; arr [ i ] = temp ; count = count + 1 ; } }
function printArray ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 0 , 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 ] ; let n = arr . length ; document . write ( " " ) ; printArray ( arr , n ) ; moveZerosToEnd ( arr , n ) ; document . write ( " " + " " ) ; printArray ( arr , n ) ;
function printArray ( array , Length ) { document . write ( " " ) ; for ( let i = 0 ; i < Length ; i ++ ) { document . write ( array [ i ] ) ; if ( i < ( Length - 1 ) ) document . write ( " " ) ; else document . write ( " " ) ; } } function reverse ( array , start , end ) { while ( start < end ) { let temp = array [ start ] ; array [ start ] = array [ end ] ; array [ end ] = temp ; start ++ ; end -- ; } }
function rearrange ( array , start , end ) {
if ( start == end ) return ;
rearrange ( array , ( start + 1 ) , end ) ;
if ( array [ start ] >= 0 ) { reverse ( array , ( start + 1 ) , end ) ; reverse ( array , start , end ) ; } }
let array = [ - 12 , - 11 , - 13 , - 5 , - 6 , 7 , 5 , 3 , 6 ] ; let length = array . length ; let countNegative = 0 ; for ( let i = 0 ; i < length ; i ++ ) { if ( array [ i ] < 0 ) countNegative ++ ; } document . write ( " " ) ; printArray ( array , length ) ; rearrange ( array , 0 , ( length - 1 ) ) ; reverse ( array , countNegative , ( length - 1 ) ) ; document . write ( " " ) ; printArray ( array , length ) ;
function pushZerosToEnd ( arr , n ) {
var count = 0 ;
for ( var i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
function modifyAndRearrangeArr ( arr , n ) {
if ( n == 1 ) return ;
for ( var i = 0 ; i < n - 1 ; i ++ ) {
if ( arr [ i ] != 0 && arr [ i ] == arr [ i + 1 ] ) {
arr [ i ] = 2 * arr [ i ] ;
arr [ i + 1 ] = 0 ;
i ++ ; } }
pushZerosToEnd ( arr , n ) ; }
function printArray ( arr , n ) { for ( var i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
var arr = [ 0 , 2 , 2 , 2 , 0 , 6 , 6 , 0 , 0 , 8 ] ; var n = arr . length ; document . write ( " " ) ; printArray ( arr , n ) ; modifyAndRearrangeArr ( arr , n ) ; document . write ( " " ) ; document . write ( " " ) ; printArray ( arr , n ) ;
function shiftAllZeroToLeft ( array , n ) {
let lastSeenNonZero = 0 ; for ( let index = 0 ; index < n ; index ++ ) {
if ( array [ index ] != 0 ) {
swap ( array , array [ index ] , array [ lastSeenNonZero ] ) ;
lastSeenNonZero ++ ; } } } }
function reorder ( arr , index , n ) { var temp = [ ... Array ( n ) ] ;
for ( var i = 0 ; i < n ; i ++ ) temp [ index [ i ] ] = arr [ i ] ;
for ( var i = 0 ; i < n ; i ++ ) { arr [ i ] = temp [ i ] ; index [ i ] = i ; } }
var arr = [ 50 , 40 , 70 , 60 , 90 ] ; var index = [ 3 , 0 , 4 , 1 , 2 ] ; var n = arr . length ; reorder ( arr , index , n ) ; document . write ( " " ) ; document . write ( " " ) ; for ( var i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; document . write ( " " ) ; document . write ( " " ) ; for ( var i = 0 ; i < n ; i ++ ) document . write ( index [ i ] + " " ) ;
function reorder ( arr , index , n ) {
for ( let i = 0 ; i < n ; i ++ ) {
while ( index [ i ] != i ) {
let oldTargetI = index [ index [ i ] ] ; let oldTargetE = arr [ index [ i ] ] ;
arr [ index [ i ] ] = arr [ i ] ; index [ index [ i ] ] = index [ i ] ;
index [ i ] = oldTargetI ; arr [ i ] = oldTargetE ; } } }
let arr = [ 50 , 40 , 70 , 60 , 90 ] ; let index = [ 3 , 0 , 4 , 1 , 2 ] ; let n = arr . length ; reorder ( arr , index , n ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( index [ i ] + " " ) ;
function printArray ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; }
function RearrangePosNeg ( arr , n ) { let key , j ; for ( let i = 1 ; i < n ; i ++ ) { key = arr [ i ] ;
if ( key > 0 ) continue ;
j = i - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { arr [ j + 1 ] = arr [ j ] ; j = j - 1 ; }
arr [ j + 1 ] = key ; } }
let arr = [ - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 ] ; let n = arr . length ; RearrangePosNeg ( arr , n ) ; printArray ( arr , n ) ;
class Node { constructor ( k ) { this . data = k ; this . left = null ; this . right = null ; } }
function isLeaf ( node ) { if ( node == null ) return false ; if ( node . left == null && node . right == null ) return true ; return false ; }
function leftLeavesSum ( node ) {
let res = 0 ;
if ( node != null ) {
if ( isLeaf ( node . left ) ) res += node . left . data ;
else res += leftLeavesSum ( node . left ) ;
res += leftLeavesSum ( node . right ) ; }
return res ; }
root = new Node ( 20 ) ; root . left = new Node ( 9 ) ; root . right = new Node ( 49 ) ; root . left . right = new Node ( 12 ) ; root . left . left = new Node ( 5 ) ; root . right . left = new Node ( 23 ) ; root . right . right = new Node ( 52 ) ; root . left . right . right = new Node ( 12 ) ; root . right . right . left = new Node ( 50 ) ; document . write ( " " + leftLeavesSum ( root ) ) ;
function printArray ( A , size ) { for ( let i = 0 ; i < size ; i ++ ) document . write ( A [ i ] + " " ) ; document . write ( " " ) ; }
function reverse ( arr , l , r ) { if ( l < r ) { arr = swap ( arr , l , r ) ; reverse ( arr , ++ l , -- r ) ; } }
function merge ( arr , l , m , r ) {
let i = l ;
let j = m + 1 ; while ( i <= m && arr [ i ] < 0 ) i ++ ;
while ( j <= r && arr [ j ] < 0 ) j ++ ;
reverse ( arr , i , m ) ;
reverse ( arr , m + 1 , j - 1 ) ;
reverse ( arr , i , j - 1 ) ; }
function RearrangePosNeg ( arr , l , r ) { if ( l < r ) {
let m = l + Math . floor ( ( r - l ) / 2 ) ;
RearrangePosNeg ( arr , l , m ) ; RearrangePosNeg ( arr , m + 1 , r ) ; merge ( arr , l , m , r ) ; } } function swap ( arr , i , j ) { let temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; return arr ; }
let arr = [ - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 ] ; let arr_size = arr . length ; RearrangePosNeg ( arr , 0 , arr_size - 1 ) ; printArray ( arr , arr_size ) ;
function RearrangePosNeg ( arr ) { var i = 0 ; var j = arr . length - 1 ; while ( true ) {
while ( arr [ i ] < 0 && i < arr . length ) i ++ ;
while ( arr [ j ] > 0 && j >= 0 ) j -- ;
if ( i < j ) { var temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } else break ; } }
var arr = [ - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 ] ; RearrangePosNeg ( arr ) ; for ( i = 0 ; i < arr . length ; i ++ ) document . write ( arr [ i ] + " " ) ;
function rearrangeNaive ( arr , n ) {
let temp = new Array ( n ) , i ;
for ( i = 0 ; i < n ; i ++ ) temp [ arr [ i ] ] = i ;
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
function printArray ( arr , n ) { let i ; for ( i = 0 ; i < n ; i ++ ) document . write ( " " + arr [ i ] ) ; document . write ( " " ) ; }
let arr = [ 1 , 3 , 0 , 2 ] ; let n = arr . length ; document . write ( " " ) ; printArray ( arr , n ) ; rearrangeNaive ( arr , n ) ; document . write ( " " ) ; printArray ( arr , n ) ;
function rearrange ( arr , n ) { for ( i = 0 ; i < n ; i ++ ) {
arr [ arr [ i ] % n ] += i * n ; } for ( i = 0 ; i < n ; i ++ ) {
arr [ i ] = parseInt ( arr [ i ] / n ) ; } }
function printArray ( arr , n ) { for ( i = 0 ; i < n ; i ++ ) { document . write ( arr [ i ] + " " ) ; } document . write ( ) ; }
var arr = [ 2 , 0 , 1 , 4 , 5 , 3 ] ; var n = arr . length ; document . write ( " " + " " ) ; printArray ( arr , n ) ; rearrange ( arr , n ) ; document . write ( " " ) document . write ( " " + " " ) ; printArray ( arr , n ) ;
function rearrange ( arr , n ) {
let temp = new Array ( n ) ;
let small = 0 , large = n - 1 ;
let flag = true ;
for ( let i = 0 ; i < n ; i ++ ) { if ( flag ) temp [ i ] = arr [ large -- ] ; else temp [ i ] = arr [ small ++ ] ; flag = ! flag ; }
for ( let i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 ] ; let n = arr . length ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; rearrange ( arr , n ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function rearrange ( arr , n ) {
let max_idx = n - 1 , min_idx = 0 ;
let max_elem = arr [ n - 1 ] + 1 ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] += ( arr [ max_idx ] % max_elem ) * max_elem ; max_idx -- ; }
else { arr [ i ] += ( arr [ min_idx ] % max_elem ) * max_elem ; min_idx ++ ; } }
for ( let i = 0 ; i < n ; i ++ ) arr [ i ] = Math . floor ( arr [ i ] / max_elem ) ; }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ] ; let n = arr . length ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; rearrange ( arr , n ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function rearrange ( arr , n ) {
let max_ele = arr [ n - 1 ] ; let min_ele = arr [ 0 ] ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] = max_ele ; max_ele -= 1 ; }
else { arr [ i ] = min_ele ; min_ele += 1 ; } } }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ] ; let n = arr . length ; document . write ( " " + " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; rearrange ( arr , n ) ; document . write ( " " + " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
class Node { constructor ( item ) { this . data = item ; this . left = this . right = null ; } }
function leftLeavesSumRec ( node , isleft , summ ) { if ( node == null ) return ;
if ( node . left == null && node . right == null && isleft ) summ . sum = summ . sum + node . data ;
leftLeavesSumRec ( node . left , true , summ ) ; leftLeavesSumRec ( node . right , false , summ ) ; }
function leftLeavesSum ( node ) { suum = new Sum ( ) ;
leftLeavesSumRec ( node , false , suum ) ; return suum . sum ; }
root = new Node ( 20 ) ; root . left = new Node ( 9 ) ; root . right = new Node ( 49 ) ; root . left . right = new Node ( 12 ) ; root . left . left = new Node ( 5 ) ; root . right . left = new Node ( 23 ) ; root . right . right = new Node ( 52 ) ; root . left . right . right = new Node ( 12 ) ; root . right . right . left = new Node ( 50 ) ; document . write ( " " + leftLeavesSum ( root ) ) ;
function rearrange ( arr , n ) { let j = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < 0 ) { if ( i != j ) { let temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } j ++ ; } } }
function printArray ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ - 1 , 2 , - 3 , 4 , 5 , 6 , - 7 , 8 , 9 ] ; let n = arr . length ; rearrange ( arr , n ) ; printArray ( arr , n ) ;
function segregateElements ( arr , n ) {
let temp = new Array ( n ) ;
let j = 0 ; for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] >= 0 ) temp [ j ++ ] = arr [ i ] ;
if ( j == n j == 0 ) return ;
for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] < 0 ) temp [ j ++ ] = arr [ i ] ;
for ( let i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
let arr = [ 1 , - 1 , - 3 , - 2 , 7 , 5 , 11 , 6 ] ; let n = arr . length ; segregateElements ( arr , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
let rearrange = ( arr , n ) => { for ( let i = 0 ; i < n - 1 ; i ++ ) { if ( i % 2 == 0 && arr [ i ] > arr [ i + 1 ] ) { let temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } if ( i % 2 != 0 && arr [ i ] < arr [ i + 1 ] ) { let temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } } }
let printArray = ( arr , size ) => { ans = ' ' ; for ( let i = 0 ; i < size ; i ++ ) { ans += arr [ i ] + " " ; } document . write ( ans ) ; }
let arr = [ 6 , 4 , 2 , 1 , 8 , 3 ] ; let n = arr . length ; document . write ( " " ) ; printArray ( arr , n ) ; rearrange ( arr , n ) ; document . write ( " " ) ; document . write ( " " ) ; printArray ( arr , n ) ;
function rearrange ( a , size ) { let positive = 0 ; let negative = 1 ; let temp ; while ( true ) {
while ( positive < size && a [ positive ] >= 0 ) positive += 2 ;
while ( negative < size && a [ negative ] <= 0 ) negative += 2 ;
if ( positive < size && negative < size ) { temp = a [ positive ] ; a [ positive ] = a [ negative ] ; a [ negative ] = temp ; }
else break ; } }
let arr = [ 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 ] ; let n = arr . length ; rearrange ( arr , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function printArray ( a , n ) { for ( let i = 0 ; i < n ; i ++ ) document . write ( a [ i ] + " " ) ; document . write ( " " ) ; }
let arr = [ 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 ] ; let n = arr . length ;
printArray ( arr , n ) ; for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] >= 0 && i % 2 == 1 ) {
for ( let j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < 0 && j % 2 == 0 ) {
swap ( arr , i , j ) ; break ; } } } else if ( arr [ i ] < 0 && i % 2 == 0 ) {
for ( let j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] >= 0 && j % 2 == 1 ) {
swap ( arr , i , j ) ; break ; } } } }
printArray ( arr , n ) ;
function arrayEvenAndOdd ( arr , n ) { let a = [ ] ; let ind = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] % 2 == 0 ) { a [ ind ] = arr [ i ] ; ind ++ ; } } for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] % 2 != 0 ) { a [ ind ] = arr [ i ] ; ind ++ ; } } for ( let i = 0 ; i < n ; i ++ ) { document . write ( a [ i ] + " " ) ; } document . write ( ' ' ) ; }
let arr = [ 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 ] ; let n = arr . length ;
arrayEvenAndOdd ( arr , n ) ;
function arrayEvenAndOdd ( arr , n ) { let i = - 1 , j = 0 ; let t ; while ( j != n ) { if ( arr [ j ] % 2 == 0 ) { i ++ ;
let temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } j ++ ; }
for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 ] ; let n = arr . length ; arrayEvenAndOdd ( arr , n ) ;
class Node { constructor ( val ) { this . key = val ; this . left = null ; this . right = null ; } }
function printPostorder ( node ) { if ( node == null ) return ;
printPostorder ( node . left ) ;
printPostorder ( node . right ) ;
document . write ( node . key + " " ) ; }
function printInorder ( node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
document . write ( node . key + " " ) ;
printInorder ( node . right ) ; }
function printPreorder ( node ) { if ( node == null ) return ;
document . write ( node . key + " " ) ;
printPreorder ( node . left ) ;
printPreorder ( node . right ) ; }
root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; document . write ( " " ) ; printPreorder ( root ) ; document . write ( " " ) ; printInorder ( root ) ; document . write ( " " ) ; printPostorder ( root ) ;
function largest ( arr , n ) { arr . sort ( ) ; return arr [ n - 1 ] ; }
let arr = [ 10 , 324 , 45 , 90 , 9808 ] ; let n = arr . length ; document . write ( largest ( arr , n ) ) ;
function find3largest ( arr ) {
arr . sort ( ( a , b ) => a - b ) ;
let check = 0 , count = 1 ; for ( let i = 1 ; i <= arr . length ; i ++ ) { if ( count < 4 ) { if ( check != arr [ arr . length - i ] ) {
document . write ( arr [ arr . length - i ] + " " ) ; check = arr [ arr . length - i ] ; count ++ ; } } else break ; } }
let arr = [ 12 , 45 , 1 , - 1 , 45 , 54 , 23 , 5 , 0 , - 10 ] ; find3largest ( arr ) ;
function findElements ( arr , n ) {
for ( let i = 0 ; i < n ; i ++ ) { let count = 0 ; for ( let j = 0 ; j < n ; j ++ ) if ( arr [ j ] > arr [ i ] ) count ++ ; if ( count >= 2 ) document . write ( arr [ i ] + " " ) ; } }
let arr = [ 2 , - 6 , 3 , 5 , 1 ] ; let n = arr . length ; findElements ( arr , n ) ;
function findElements ( arr , n ) { arr . sort ( ) ; for ( let i = 0 ; i < n - 2 ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 2 , - 6 , 3 , 5 , 1 ] ; let n = arr . length ; findElements ( arr , n ) ;
function findElements ( arr , n ) { let first = Number . MIN_VALUE ; let second = Number . MAX_VALUE ; for ( let i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) second = arr [ i ] ; } for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] < second ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 2 , - 6 , 3 , 5 , 1 ] ; let n = arr . length ; findElements ( arr , n ) ;
function findMean ( a , n ) { let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) sum += a [ i ] ; return sum / n ; }
function findMedian ( a , n ) {
a . sort ( ) ;
if ( n % 2 != 0 ) return a [ n / 2 ] ; return ( a [ Math . floor ( ( n - 1 ) / 2 ) ] + a [ n / 2 ] ) / 2 ; }
let a = [ 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 ] let n = a . length ;
document . write ( " " + findMean ( a , n ) + " " ) ; document . write ( " " + findMedian ( a , n ) ) ;
function printSmall ( arr , n , k ) {
for ( let i = k ; i < n ; ++ i ) {
let max_var = arr [ k - 1 ] ; let pos = k - 1 ; for ( let j = k - 2 ; j >= 0 ; j -- ) { if ( arr [ j ] > max_var ) { max_var = arr [ j ] ; pos = j ; } }
if ( max_var > arr [ i ] ) { let j = pos ; while ( j < k - 1 ) { arr [ j ] = arr [ j + 1 ] ; j ++ ; }
arr [ k - 1 ] = arr [ i ] ; } }
for ( let i = 0 ; i < k ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 ] ; let n = 10 ; let k = 5 ; printSmall ( arr , n , k ) ;
function kSmallestPair ( arr1 , n1 , arr2 , n2 , k ) { if ( k > n1 * n2 ) { document . write ( " " ) ; return ; }
let index2 = new Array ( n1 ) ; index2 . fill ( 0 ) ; while ( k > 0 ) {
let min_sum = Number . MAX_VALUE ; let min_index = 0 ;
for ( let i1 = 0 ; i1 < n1 ; i1 ++ ) {
if ( index2 [ i1 ] < n2 && arr1 [ i1 ] + arr2 [ index2 [ i1 ] ] < min_sum ) {
min_index = i1 ;
min_sum = arr1 [ i1 ] + arr2 [ index2 [ i1 ] ] ; } } document . write ( " " + arr1 [ min_index ] + " " + arr2 [ index2 [ min_index ] ] + " " ) ; index2 [ min_index ] ++ ; k -- ; } }
let arr1 = [ 1 , 3 , 11 ] ; let n1 = arr1 . length ; let arr2 = [ 2 , 4 , 8 ] ; let n2 = arr2 . length ; let k = 4 ; kSmallestPair ( arr1 , n1 , arr2 , n2 , k ) ;
function print2largest ( arr , arr_size ) { let i , first , second ;
if ( arr_size < 2 ) { document . write ( " " ) ; return ; }
arr . sort ( ) ;
for ( i = arr_size - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] != arr [ arr_size - 1 ] ) { document . write ( " " + arr [ i ] ) ; return ; } } document . write ( " " ) ; }
let arr = [ 12 , 35 , 1 , 10 , 34 , 1 ] ; let n = arr . length ; print2largest ( arr , n ) ;
function sumNodes ( l ) {
let leafNodeCount = Math . pow ( 2 , l - 1 ) ;
let vec = [ ] ;
for ( let i = 1 ; i <= leafNodeCount ; i ++ ) { vec [ l - 1 ] . push ( i ) ; }
for ( let i = l - 2 ; i >= 0 ; i -- ) { let k = 0 ;
while ( k < vec [ i + 1 ] . length - 1 ) {
vec [ i ] . push ( vec [ i + 1 ] [ k ] + vec [ i + 1 ] [ k + 1 ] ) ; k += 2 ; } } let sum = 0 ;
for ( let i = 0 ; i < l ; i ++ ) { for ( let j = 0 ; j < vec [ i ] . length ; j ++ ) { sum += vec [ i ] [ j ] ; } } return sum ; }
let l = 3 ; document . write ( sumNodes ( l ) ) ;
function print2largest ( arr , arr_size ) { let i ;
if ( arr_size < 2 ) { document . write ( " " ) ; return ; } let largest = second = - 2454635434 ;
for ( i = 0 ; i < arr_size ; i ++ ) { if ( arr [ i ] > largest ) { largest = arr [ i ] ; } }
for ( i = 0 ; i < arr_size ; i ++ ) { if ( arr [ i ] > second && arr [ i ] < largest ) { second = arr [ i ] ; } } if ( second == - 2454635434 ) { document . write ( " " ) ; } else { document . write ( " " + second ) ; return ; } }
let arr = [ 12 , 35 , 1 , 10 , 34 , 1 ] ; let n = arr . length ; print2largest ( arr , n ) ;
function findFirstMissing ( arr , start , end , first ) { if ( start < end ) { let mid = ( start + end ) / 2 ;
if ( arr [ mid ] != mid + first ) return findFirstMissing ( arr , start , mid , first ) ; else return findFirstMissing ( arr , mid + 1 , end , first ) ; } return start + first ; }
function findSmallestMissinginSortedArray ( arr ) {
if ( arr [ 0 ] != 0 ) return 0 ;
if ( arr [ arr . length - 1 ] == arr . length - 1 ) return arr . length ; let first = arr [ 0 ] ; return findFirstMissing ( arr , 0 , arr . length - 1 , first ) ; }
let arr = [ 0 , 1 , 2 , 3 , 4 , 5 , 7 ] ; let n = arr . length ;
document . write ( " " + findSmallestMissinginSortedArray ( arr ) ) ;
function sumNodes ( l ) {
let leafNodeCount = Math . pow ( 2 , l - 1 ) ; let sumLastLevel = 0 ;
sumLastLevel = ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ;
let sum = sumLastLevel * l ; return sum ; }
let l = 3 ; document . write ( sumNodes ( l ) ) ;
var MAX = 500 ;
function buildSparseTable ( arr , n ) {
for ( var i = 0 ; i < n ; i ++ ) lookup [ i ] [ 0 ] = arr [ i ] ;
for ( var j = 1 ; ( 1 << j ) <= n ; j ++ ) {
for ( var i = 0 ; ( i + ( 1 << j ) - 1 ) < n ; i ++ ) {
if ( lookup [ i ] [ j - 1 ] < lookup [ i + ( 1 << ( j - 1 ) ) ] [ j - 1 ] ) lookup [ i ] [ j ] = lookup [ i ] [ j - 1 ] ; else lookup [ i ] [ j ] = lookup [ i + ( 1 << ( j - 1 ) ) ] [ j - 1 ] ; } } }
function query ( L , R ) {
var j = parseInt ( Math . log2 ( R - L + 1 ) ) ;
if ( lookup [ L ] [ j ] <= lookup [ R - ( 1 << j ) + 1 ] [ j ] ) return lookup [ L ] [ j ] ; else return lookup [ R - ( 1 << j ) + 1 ] [ j ] ; }
var a = [ 7 , 2 , 3 , 0 , 5 , 10 , 3 , 12 , 18 ] ; var n = a . length ; buildSparseTable ( a , n ) ; document . write ( query ( 0 , 4 ) + " " ) ; document . write ( query ( 4 , 7 ) + " " ) ; document . write ( query ( 7 , 8 ) ) ;
function add ( arr , N , lo , hi , val ) { arr [ lo ] += val ; if ( hi != N - 1 ) arr [ hi + 1 ] -= val ; }
function updateArray ( arr , N ) {
for ( let i = 1 ; i < N ; i ++ ) arr [ i ] += arr [ i - 1 ] ; }
function printArr ( arr , N ) { updateArray ( arr , N ) ; for ( let i = 0 ; i < N ; i ++ ) document . write ( " " + arr [ i ] + " " ) ; document . write ( " " ) ; }
let N = 6 ; let arr = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { arr [ i ] = 0 ; }
add ( arr , N , 0 , 2 , 100 ) ; add ( arr , N , 1 , 5 , 100 ) ; add ( arr , N , 2 , 3 , 100 ) ; printArr ( arr , N ) ;
const MAX = 1000
var tree = new Array ( 4 * MAX ) ;
var arr = new Array ( MAX ) ;
function gcd ( a , b ) { if ( a == 0 ) return b ; return gcd ( b % a , a ) ; }
function lcm ( a , b ) { return Math . floor ( a * b / gcd ( a , b ) ) ; }
function build ( node , start , end ) {
if ( start == end ) { tree [ node ] = arr [ start ] ; return ; } let mid = Math . floor ( ( start + end ) / 2 ) ;
build ( 2 * node , start , mid ) ; build ( 2 * node + 1 , mid + 1 , end ) ;
let left_lcm = tree [ 2 * node ] ; let right_lcm = tree [ 2 * node + 1 ] ; tree [ node ] = lcm ( left_lcm , right_lcm ) ; }
function query ( node , start , end , l , r ) {
if ( end < l start > r ) return 1 ;
if ( l <= start && r >= end ) return tree [ node ] ;
let mid = Math . floor ( ( start + end ) / 2 ) ; let left_lcm = query ( 2 * node , start , mid , l , r ) ; let right_lcm = query ( 2 * node + 1 , mid + 1 , end , l , r ) ; return lcm ( left_lcm , right_lcm ) ; }
arr [ 0 ] = 5 ; arr [ 1 ] = 7 ; arr [ 2 ] = 5 ; arr [ 3 ] = 2 ; arr [ 4 ] = 10 ; arr [ 5 ] = 12 ; arr [ 6 ] = 11 ; arr [ 7 ] = 17 ; arr [ 8 ] = 14 ; arr [ 9 ] = 1 ; arr [ 10 ] = 44 ;
build ( 1 , 0 , 10 ) ;
document . write ( query ( 1 , 0 , 10 , 2 , 5 ) + " " ) ;
document . write ( query ( 1 , 0 , 10 , 5 , 10 ) + " " ) ;
document . write ( query ( 1 , 0 , 10 , 0 , 10 ) + " " ) ;
function GCD ( a , b ) { if ( b == 0 ) return a ; return GCD ( b , a % b ) ; }
function FillPrefixSuffix ( prefix , arr , suffix , n ) {
prefix [ 0 ] = arr [ 0 ] ; for ( i = 1 ; i < n ; i ++ ) prefix [ i ] = GCD ( prefix [ i - 1 ] , arr [ i ] ) ;
suffix [ n - 1 ] = arr [ n - 1 ] ; for ( i = n - 2 ; i >= 0 ; i -- ) suffix [ i ] = GCD ( suffix [ i + 1 ] , arr [ i ] ) ; }
function GCDoutsideRange ( l , r , prefix , suffix , n ) {
if ( l == 0 ) return suffix [ r + 1 ] ;
if ( r == n - 1 ) return prefix [ l - 1 ] ; return GCD ( prefix [ l - 1 ] , suffix [ r + 1 ] ) ; }
var arr = [ 2 , 6 , 9 ] ; var n = arr . length ; var prefix = Array ( n ) . fill ( 0 ) ; var suffix = Array ( n ) . fill ( 0 ) ; FillPrefixSuffix ( prefix , arr , suffix , n ) ; var l = 0 , r = 0 ; document . write ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; document . write ( " " ) ; l = 1 ; r = 1 ; document . write ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; document . write ( " " ) ; l = 1 ; r = 2 ; document . write ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; document . write ( " " ) ;
function countInRange ( arr , n , x , y ) {
let count = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] >= x && arr [ i ] <= y ) count ++ ; } return count ; }
let arr = [ 1 , 3 , 4 , 9 , 10 , 3 ] ; let n = arr . length ;
let i = 1 , j = 4 ; document . write ( countInRange ( arr , n , i , j ) + " " ) ; i = 9 ; j = 12 ; document . write ( countInRange ( arr , n , i , j ) ) ;
function lowerIndex ( arr , n , x ) { let l = 0 , h = n - 1 ; while ( l <= h ) { let mid = parseInt ( ( l + h ) / 2 , 10 ) ; if ( arr [ mid ] >= x ) h = mid - 1 ; else l = mid + 1 ; } return l ; }
function upperIndex ( arr , n , y ) { let l = 0 , h = n - 1 ; while ( l <= h ) { let mid = parseInt ( ( l + h ) / 2 , 10 ) ; if ( arr [ mid ] <= y ) l = mid + 1 ; else h = mid - 1 ; } return h ; }
function countInRange ( arr , n , x , y ) {
let count = 0 ; count = upperIndex ( arr , n , y ) - lowerIndex ( arr , n , x ) + 1 ; return count ; }
let arr = [ 1 , 4 , 4 , 9 , 10 , 3 ] ; let n = arr . length ;
arr . sort ( function ( a , b ) { return a - b } ) ;
let i = 1 , j = 4 ; document . write ( countInRange ( arr , n , i , j ) + " " ) ; ; i = 9 ; j = 12 ; document . write ( countInRange ( arr , n , i , j ) ) ;
function precompute ( arr , n , pre ) { for ( let i = 0 ; i < n ; i ++ ) pre [ i ] = 0 ; pre [ n - 1 ] = arr [ n - 1 ] * ( Math . pow ( 2 , 0 ) ) ; for ( let i = n - 2 ; i >= 0 ; i -- ) pre [ i ] = pre [ i + 1 ] + arr [ i ] * ( 1 << ( n - 1 - i ) ) ; }
function decimalOfSubarr ( arr , l , r , n , pre ) {
if ( r != n - 1 ) return ( pre [ l ] - pre [ r + 1 ] ) / ( 1 << ( n - 1 - r ) ) ; return pre [ l ] / ( 1 << ( n - 1 - r ) ) ; }
let arr = [ 1 , 0 , 1 , 0 , 1 , 1 ] ; let n = arr . length ; let pre = new Array ( n ) precompute ( arr , n , pre ) ; document . write ( decimalOfSubarr ( arr , 2 , 4 , n , pre ) + " " ) ; document . write ( decimalOfSubarr ( arr , 4 , 5 , n , pre ) ) ;
function answerQuery ( a , n , l , r ) {
var count = 0 ;
l = l - 1 ;
for ( i = l ; i < r ; i ++ ) { var element = a [ i ] ; var divisors = 0 ;
for ( j = l ; j < r ; j ++ ) {
if ( a [ j ] % a [ i ] == 0 ) divisors ++ ; else break ; }
if ( divisors == ( r - l ) ) count ++ ; }
return count ; }
var a = [ 1 , 2 , 3 , 5 ] ; var n = a . length ; var l = 1 , r = 4 ; document . write ( answerQuery ( a , n , l , r ) + " " ) ; l = 2 ; r = 4 ; document . write ( answerQuery ( a , n , l , r ) ) ;
class Node { constructor ( data ) { this . data = data ; this . left = null ; this . right = null ; } }
let grid = new Map ( ) ;
function addConsideringGrid ( root , level , index ) {
if ( root == null ) return ;
if ( grid . has ( level - index ) ) { grid . set ( level - index , grid . get ( level - index ) + ( root . data ) ) ; } else { grid . set ( level - index , root . data ) ; }
addConsideringGrid ( root . left , level + 1 , index - 1 ) ;
addConsideringGrid ( root . right , level + 1 , index + 1 ) ; } function diagonalSum ( root ) {
addConsideringGrid ( root , 0 , 0 ) ; let ans = [ ] ;
for ( let [ key , value ] of grid ) { ans . push ( value ) ; } return ans ; }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 9 ) ; root . left . right = new Node ( 6 ) ; root . right . left = new Node ( 4 ) ; root . right . right = new Node ( 5 ) ; root . right . left . right = new Node ( 7 ) ; root . right . left . left = new Node ( 12 ) ; root . left . right . left = new Node ( 11 ) ; root . left . left . right = new Node ( 10 ) ;
let v = diagonalSum ( root ) ;
for ( let i = 0 ; i < v . length ; i ++ ) document . write ( v [ i ] + " " ) ;
const MAX = 2147483647 ; let one = new Array ( 100001 ) ; for ( let i = 0 ; i < 100001 ; i ++ ) one [ i ] = new Array ( 32 ) ;
function make_prefix ( A , n ) { for ( let j = 0 ; j < 32 ; j ++ ) one [ 0 ] [ j ] = 0 ;
for ( let i = 1 ; i <= n ; i ++ ) { let a = A [ i - 1 ] ; for ( let j = 0 ; j < 32 ; j ++ ) { let x = Math . pow ( 2 , j ) ;
if ( a & x ) one [ i ] [ j ] = 1 + one [ i - 1 ] [ j ] ; else one [ i ] [ j ] = one [ i - 1 ] [ j ] ; } } }
function Solve ( L , R ) { let l = L , r = R ; let tot_bits = r - l + 1 ;
let X = MAX ;
for ( let i = 0 ; i < 31 ; i ++ ) {
let x = one [ r ] [ i ] - one [ l - 1 ] [ i ] ;
if ( x >= tot_bits - x ) { let ith_bit = Math . pow ( 2 , i ) ;
X = X ^ ith_bit ; } } return X ; }
let n = 5 , q = 3 ; let A = [ 210 , 11 , 48 , 22 , 133 ] ; let L = [ 1 , 4 , 2 ] , R = [ 3 , 14 , 4 ] ; make_prefix ( A , n ) ; for ( let j = 0 ; j < q ; j ++ ) document . write ( Solve ( L [ j ] , R [ j ] ) + " " ) ;
function type1 ( arr , start , limit ) {
for ( let i = start ; i <= limit ; i ++ ) arr [ i ] ++ ; }
function type2 ( arr , query , start , limit ) { for ( let i = start ; i <= limit ; i ++ ) {
if ( query [ i ] [ 0 ] == 1 ) type1 ( arr , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ;
else if ( query [ i ] [ 0 ] == 2 ) type2 ( arr , query , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ; } }
let n = 5 , m = 5 ; let arr = new Array ( n + 1 ) ; for ( let i = 0 ; i < arr . length ; i ++ ) { arr [ i ] = 0 ; }
let temp = [ 1 , 1 , 2 , 1 , 4 , 5 , 2 , 1 , 2 , 2 , 1 , 3 , 2 , 3 , 4 ] ; let query = new Array ( 6 ) ; for ( let i = 0 ; i < 6 ; i ++ ) { query [ i ] = new Array ( 4 ) ; for ( let j = 0 ; j < 4 ; j ++ ) { query [ i ] [ j ] = 0 ; } } let j = 0 ; for ( let i = 1 ; i <= m ; i ++ ) { query [ i ] [ 0 ] = temp [ j ++ ] ; query [ i ] [ 1 ] = temp [ j ++ ] ; query [ i ] [ 2 ] = temp [ j ++ ] ; }
for ( let i = 1 ; i <= m ; i ++ ) if ( query [ i ] [ 0 ] == 1 ) type1 ( arr , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ; else if ( query [ i ] [ 0 ] == 2 ) type2 ( arr , query , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ;
for ( let i = 1 ; i <= n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ;
function record_sum ( record , l , r , n , adder ) { for ( let i = l ; i <= r ; i ++ ) { record [ i ] += adder ; } }
let n = 5 , m = 5 ; let arr = new Array ( n ) ;
for ( let i = 0 ; i < arr . length ; i ++ ) { arr [ i ] = 0 ; } let query = [ [ 1 , 1 , 2 ] , [ 1 , 4 , 5 ] , [ 2 , 1 , 2 ] , [ 2 , 1 , 3 ] , [ 2 , 3 , 4 ] ] ; let record = new Array ( m ) ; for ( let i = 0 ; i < record . length ; i ++ ) { record [ i ] = 0 ; } for ( let i = m - 1 ; i >= 0 ; i -- ) {
if ( query [ i ] [ 0 ] == 2 ) { record_sum ( record , query [ i ] [ 1 ] - 1 , query [ i ] [ 2 ] - 1 , m , record [ i ] + 1 ) ; }
else { record_sum ( record , i , i , m , 1 ) ; } }
for ( let i = 0 ; i < m ; i ++ ) { if ( query [ i ] [ 0 ] == 1 ) { record_sum ( arr , query [ i ] [ 1 ] - 1 , query [ i ] [ 2 ] - 1 , n , record [ i ] ) ; } }
for ( let i = 0 ; i < n ; i ++ ) { document . write ( arr [ i ] + " " ) ; }
function solveQuery ( start , end , arr ) {
let mp = new Map ( ) ;
for ( let i = start ; i <= end ; i ++ ) mp . set ( arr [ i ] , mp . get ( arr [ i ] ) == null ? 1 : mp . get ( arr [ i ] ) + 1 ) ;
let count = 0 ; for ( let [ key , value ] of mp . entries ( ) ) if ( key == value ) count ++ ; return count ; }
let A = [ 1 , 2 , 2 , 3 , 3 , 3 ] ; let n = A . length ;
let queries = [ [ 0 , 1 ] , [ 1 , 1 ] , [ 0 , 2 ] , [ 1 , 3 ] , [ 3 , 5 ] , [ 0 , 5 ] ] ;
let q = queries . length ; for ( let i = 0 ; i < q ; i ++ ) { let start = queries [ i ] [ 0 ] ; let end = queries [ i ] [ 1 ] ; document . write ( " " + ( i + 1 ) + " " + solveQuery ( start , end , A ) + " " ) ; }
function answer_query ( a , n , l , r ) {
var count = 0 ; for ( var i = l ; i < r ; i ++ ) if ( a [ i ] == a [ i + 1 ] ) count += 1 ; return count ; }
var a = [ 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 ] var n = a . length ;
var L , R ; L = 1 ; R = 8 ; document . write ( answer_query ( a , n , L , R ) + " " ) ;
L = 0 ; R = 4 ; document . write ( answer_query ( a , n , L , R ) ) ;
const N = 1000 ;
let prefixans = new Uint8Array ( N ) ;
function countIndex ( a , n ) {
for ( let i = 0 ; i < n ; i ++ ) { if ( a [ i ] == a [ i + 1 ] ) prefixans [ i ] = 1 ; if ( i != 0 ) prefixans [ i ] += prefixans [ i - 1 ] ; } }
function answer_query ( l , r ) { if ( l == 0 ) return prefixans [ r - 1 ] ; else return prefixans [ r - 1 ] - prefixans [ l - 1 ] ; }
let a = [ 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 ] ; let n = a . length ;
countIndex ( a , n ) ; let L , R ;
L = 1 ; R = 8 ; document . write ( answer_query ( L , R ) + " " ) ;
L = 0 ; R = 4 ; document . write ( answer_query ( L , R ) + " " ) ;
function initializeDiffArray ( A ) { let n = A . length ;
let D = [ ] ; D [ 0 ] = A [ 0 ] , D [ n ] = 0 ; for ( let i = 1 ; i < n ; i ++ ) D [ i ] = A [ i ] - A [ i - 1 ] ; return D ; }
function update ( D , l , r , x ) { D [ l ] += x ; D [ r + 1 ] -= x ; return D ; }
function printArray ( A , D ) { for ( let i = 0 ; i < A . length ; i ++ ) { if ( i == 0 ) A [ i ] = D [ i ] ;
else A [ i ] = D [ i ] + A [ i - 1 ] ; document . write ( A [ i ] + " " ) ; } document . write ( " " ) ; }
let A = [ 10 , 5 , 20 , 40 ] ;
let D = initializeDiffArray ( A ) ;
D = update ( D , 0 , 1 , 10 ) ; printArray ( A , D ) ;
D = update ( D , 1 , 3 , 20 ) ; D = update ( D , 2 , 2 , 30 ) ; printArray ( A , D ) ;
function maxSubArraySum ( a , size ) { var maxint = Math . pow ( 2 , 53 ) var max_so_far = - maxint - 1 var max_ending_here = 0 for ( var i = 0 ; i < size ; i ++ ) { max_ending_here = max_ending_here + a [ i ] if ( max_so_far < max_ending_here ) max_so_far = max_ending_here if ( max_ending_here < 0 ) max_ending_here = 0 } return max_so_far }
var a = [ - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 ] document . write ( " " , maxSubArraySum ( a , a . length ) )
function maxSubArraySum ( a , size ) { let max_so_far = a [ 0 ] ; let curr_max = a [ 0 ] ; for ( let i = 1 ; i < size ; i ++ ) { curr_max = Math . max ( a [ i ] , curr_max + a [ i ] ) ; max_so_far = Math . max ( max_so_far , curr_max ) ; } return max_so_far ; }
let a = [ - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 ] ; let n = a . length ; document . write ( " " , maxSubArraySum ( a , n ) ) ;
function findMinAvgSubarray ( arr , n , k ) {
if ( n < k ) return ;
let res_index = 0 ;
let curr_sum = 0 ; for ( let i = 0 ; i < k ; i ++ ) curr_sum += arr [ i ] ;
let min_sum = curr_sum ;
for ( let i = k ; i < n ; i ++ ) {
curr_sum += arr [ i ] - arr [ i - k ] ;
if ( curr_sum < min_sum ) { min_sum = curr_sum ; res_index = ( i - k + 1 ) ; } } document . write ( " " + res_index + " " + ( res_index + k - 1 ) + " " ) ; }
let arr = [ 3 , 7 , 90 , 20 , 10 , 50 , 40 ] ;
let k = 3 ; let n = arr . length ; findMinAvgSubarray ( arr , n , k ) ;
function minJumps ( arr , n ) {
var jumps = Array . from ( { length : n } , ( _ , i ) => 0 ) ; var min ;
for ( i = n - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] == 0 ) jumps [ i ] = Number . MAX_VALUE ;
else if ( arr [ i ] >= n - i - 1 ) jumps [ i ] = 1 ;
else {
min = Number . MAX_VALUE ;
for ( j = i + 1 ; j < n && j <= arr [ i ] + i ; j ++ ) { if ( min > jumps [ j ] ) min = jumps [ j ] ; }
if ( min != Number . MAX_VALUE ) jumps [ i ] = min + 1 ; else
jumps [ i ] = min ; } } return jumps [ 0 ] ; }
var arr = [ 1 , 3 , 6 , 1 , 0 , 9 ] ; var size = arr . length ; document . write ( " " + " " + minJumps ( arr , size ) ) ;
function smallestSubWithSum ( arr , n , x ) {
let min_len = n + 1 ;
for ( let start = 0 ; start < n ; start ++ ) {
let curr_sum = arr [ start ] ;
if ( curr_sum > x ) return 1 ;
for ( let end = start + 1 ; end < n ; end ++ ) {
curr_sum += arr [ end ] ;
if ( curr_sum > x && ( end - start + 1 ) < min_len ) min_len = ( end - start + 1 ) ; } } return min_len ; }
let arr1 = [ 1 , 4 , 45 , 6 , 10 , 19 ] ; let x = 51 ; let n1 = arr1 . length ; let res1 = smallestSubWithSum ( arr1 , n1 , x ) ; ( res1 == n1 + 1 ) ? document . write ( " " ) : document . write ( res1 + " " ) ; let arr2 = [ 1 , 10 , 5 , 2 , 7 ] ; let n2 = arr2 . length ; x = 9 ; let res2 = smallestSubWithSum ( arr2 , n2 , x ) ; ( res2 == n2 + 1 ) ? document . write ( " " ) : document . write ( res2 + " " ) ; let arr3 = [ 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ] ; let n3 = arr3 . length ; x = 280 ; let res3 = smallestSubWithSum ( arr3 , n3 , x ) ; ( res3 == n3 + 1 ) ? document . write ( " " ) : document . write ( res3 + " " ) ;
function smallestSubWithSum ( arr , n , x ) {
let curr_sum = 0 , min_len = n + 1 ;
let start = 0 , end = 0 ; while ( end < n ) {
while ( curr_sum <= x && end < n ) curr_sum += arr [ end ++ ] ;
while ( curr_sum > x && start < n ) {
if ( end - start < min_len ) min_len = end - start ;
curr_sum -= arr [ start ++ ] ; } } return min_len ; }
let arr1 = [ 1 , 4 , 45 , 6 , 10 , 19 ] ; let x = 51 ; let n1 = arr1 . length ; let res1 = smallestSubWithSum ( arr1 , n1 , x ) ; ( res1 == n1 + 1 ) ? document . write ( " " ) : document . write ( res1 + " " ) ; let arr2 = [ 1 , 10 , 5 , 2 , 7 ] ; let n2 = arr2 . length ; x = 9 ; let res2 = smallestSubWithSum ( arr2 , n2 , x ) ; ( res2 == n2 + 1 ) ? document . write ( " " ) : document . write ( res2 + " " ) ; let arr3 = [ 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ] ; let n3 = arr3 . length ; x = 280 ; let res3 = smallestSubWithSum ( arr3 , n3 , x ) ; ( res3 == n3 + 1 ) ? document . write ( " " ) : document . write ( res3 + " " ) ;
function findMaxAverage ( arr , n , k ) {
if ( k > n ) return - 1 ;
let csum = new Array ( n ) ; csum [ 0 ] = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) csum [ i ] = csum [ i - 1 ] + arr [ i ] ;
let max_sum = csum [ k - 1 ] , max_end = k - 1 ;
for ( let i = k ; i < n ; i ++ ) { let curr_sum = csum [ i ] - csum [ i - k ] ; if ( curr_sum > max_sum ) { max_sum = curr_sum ; max_end = i ; } }
return max_end - k + 1 ; }
let arr = [ 1 , 12 , - 5 , - 6 , 50 , 3 ] ; let k = 4 ; let n = arr . length ; document . write ( " " + " " + k + " " + findMaxAverage ( arr , n , k ) ) ;
function findMaxAverage ( arr , n , k ) {
if ( k > n ) return - 1 ;
let sum = arr [ 0 ] ; for ( let i = 1 ; i < k ; i ++ ) sum += arr [ i ] ; let max_sum = sum ; let max_end = k - 1 ;
for ( let i = k ; i < n ; i ++ ) { sum = sum + arr [ i ] - arr [ i - k ] ; if ( sum > max_sum ) { max_sum = sum ; max_end = i ; } }
return max_end - k + 1 ; }
let arr = [ 1 , 12 , - 5 , - 6 , 50 , 3 ] ; let k = 4 ; let n = arr . length ; document . write ( " " + " " + k + " " + findMaxAverage ( arr , n , k ) ) ;
function countMinOperations ( n ) {
let result = 0 ;
while ( true ) {
let zero_count = 0 ;
let i ; for ( i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] % 2 == 1 ) break ;
else if ( arr [ i ] == 0 ) zero_count ++ ; }
if ( zero_count == n ) return result ;
if ( i == n ) {
for ( let j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] / 2 ; result ++ ; }
for ( let j = i ; j < n ; j ++ ) { if ( arr [ j ] % 2 == 1 ) { arr [ j ] -- ; result ++ ; } } } }
document . write ( " " + " " + " " + countMinOperations ( arr . length ) ) ;
function findMinOps ( arr , n ) {
let ans = 0 ;
for ( let i = 0 , j = n - 1 ; i <= j ; ) {
if ( arr [ i ] == arr [ j ] ) { i ++ ; j -- ; }
else if ( arr [ i ] > arr [ j ] ) {
j -- ; arr [ j ] += arr [ j + 1 ] ; ans ++ ; }
else { i ++ ; arr [ i ] += arr [ i - 1 ] ; ans ++ ; } } return ans ; }
let arr = [ 1 , 4 , 5 , 9 , 1 ] ; document . write ( " " + findMinOps ( arr , arr . length ) ) ;
function findSmallest ( arr , n ) {
var res = 1 ;
for ( i = 0 ; i < n && arr [ i ] <= res ; i ++ ) res = res + arr [ i ] ; return res ; }
var arr1 = [ 1 , 3 , 4 , 5 ] ; var n1 = arr1 . length ; document . write ( findSmallest ( arr1 , n1 ) + " " ) ; var arr2 = [ 1 , 2 , 6 , 10 , 11 , 15 ] ; var n2 = arr2 . length ; document . write ( findSmallest ( arr2 , n2 ) + " " ) ; var arr3 = [ 1 , 1 , 1 , 1 ] ; var n3 = arr3 . length ; document . write ( findSmallest ( arr3 , n3 ) + " " ) ; var arr4 = [ 1 , 1 , 3 , 4 ] ; var n4 = arr4 . length ; document . write ( findSmallest ( arr4 , n4 ) + " " ) ;
function maxSubArraySum ( a , size ) { let max_so_far = Number . MIN_VALUE , max_ending_here = 0 , start = 0 , end = 0 , s = 0 ; for ( let i = 0 ; i < size ; i ++ ) { max_ending_here += a [ i ] ; if ( max_so_far < max_ending_here ) { max_so_far = max_ending_here ; start = s ; end = i ; } if ( max_ending_here < 0 ) { max_ending_here = 0 ; s = i + 1 ; } } return ( end - start + 1 ) ; }
let a = [ - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 ] ; let n = a . length ; document . write ( maxSubArraySum ( a , n ) ) ;
function findMinDiff ( arr , n ) {
let diff = Number . MAX_VALUE ;
for ( let i = 0 ; i < n - 1 ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) if ( Math . abs ( ( arr [ i ] - arr [ j ] ) ) < diff ) diff = Math . abs ( ( arr [ i ] - arr [ j ] ) ) ;
return diff ; }
let arr = [ 1 , 5 , 3 , 19 , 18 , 25 ] ; document . write ( " " + findMinDiff ( arr , arr . length ) ) ;
function findMinDiff ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ;
let diff = Number . MAX_VALUE ;
for ( let i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i + 1 ] - arr [ i ] < diff ) diff = arr [ i + 1 ] - arr [ i ] ;
return diff ; }
let arr = [ 1 , 5 , 3 , 19 , 18 , 25 ] ; document . write ( " " + findMinDiff ( arr , arr . length ) ) ;
let a = 2 , b = 10 ; let size = Math . abs ( b - a ) + 1 ; let array = [ ] ;
for ( let i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) array [ i - a ] = 1 ; document . write ( " " + " " + " " ) ; for ( let i = a ; i <= b ; i ++ ) if ( array [ i - a ] == 1 ) document . write ( i + " " ) ;
function checkbit ( array , index ) { return array [ index >> 5 ] & ( 1 << ( index & 31 ) ) ; }
function setbit ( array , index ) { array [ index >> 5 ] |= ( 1 << ( index & 31 ) ) ; }
let a = 2 , b = 10 ; let size = Math . abs ( b - a ) ;
size = Math . ceil ( size / 32 ) ;
let array = new Array ( size ) ;
for ( let i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) setbit ( array , i - a ) ; document . write ( " " ) ; for ( let i = a ; i <= b ; i ++ ) if ( checkbit ( array , i - a ) ) document . write ( i + " " ) ;
function longestCommonSum ( n ) {
let maxLen = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
let sum1 = 0 , sum2 = 0 ;
for ( let j = i ; j < n ; j ++ ) {
sum1 += arr1 [ j ] ; sum2 += arr2 [ j ] ;
if ( sum1 == sum2 ) { let len = j - i + 1 ; if ( len > maxLen ) maxLen = len ; } } } return maxLen ; }
document . write ( " " + " " ) ; document . write ( longestCommonSum ( arr1 . length ) ) ;
function sortInWave ( arr , n ) {
arr . sort ( ( a , b ) => a - b ) ;
for ( let i = 0 ; i < n - 1 ; i += 2 ) swap ( arr , i , i + 1 ) ; }
let arr = [ 10 , 90 , 49 , 2 , 1 , 5 , 23 ] ; let n = arr . length ; sortInWave ( arr , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function sortInWave ( arr , n ) {
for ( let i = 0 ; i < n ; i += 2 ) {
if ( i > 0 && arr [ i - 1 ] > arr [ i ] ) swap ( arr , i - 1 , i ) ;
if ( i < n - 1 && arr [ i ] < arr [ i + 1 ] ) swap ( arr , i , i + 1 ) ; } }
let arr = [ 10 , 90 , 49 , 2 , 1 , 5 , 23 ] ; let n = arr . length ; sortInWave ( arr , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function sortedAfterSwap ( A , B , n ) { let i , j ;
for ( i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] ) { j = i ; while ( B [ j ] ) { j ++ ; }
A . sort ( ) ; i = j ; } }
for ( i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) { return false ; } } return true ; }
let A = [ 1 , 2 , 5 , 3 , 4 , 6 ] ; let B = [ false , true , true , true , false ] ; let n = A . length ; if ( sortedAfterSwap ( A , B , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function sortedAfterSwap ( A , B , n ) { let t = 0 ; for ( let i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] != 0 ) { if ( A [ i ] != i + 1 ) t = A [ i ] ; A [ i ] = A [ i + 1 ] ; A [ i + 1 ] = t ; } }
for ( let i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) return 0 ; } return 1 ; }
let A = [ 1 , 2 , 5 , 3 , 4 , 6 ] ; let B = [ 0 , 1 , 1 , 1 , 0 ] ; let n = A . length ; if ( sortedAfterSwap ( A , B , n ) == 0 ) document . write ( " " ) ; else document . write ( " " ) ;
let type0 = 0 ; let type1 = n - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type0 ] = arr [ type0 ] + arr [ type1 ] ; arr [ type1 ] = arr [ type0 ] - arr [ type1 ] ; arr [ type0 ] = arr [ type0 ] - arr [ type1 ] ; type1 -- ; } else { type0 ++ ; } } }
let arr = [ 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 ] ; segregate0and1 ( arr , arr . length ) ; for ( let i = 0 ; i < arr . length ; i ++ ) document . write ( arr [ i ] + " " ) ;
function findMinSum ( arr , n ) { for ( let i = 1 ; i < n ; i ++ ) { if ( ! ( Math . abs ( arr [ i - 1 ] ) < Math . abs ( arr [ i ] ) ) ) { let temp = arr [ i - 1 ] ; arr [ i - 1 ] = arr [ i ] ; arr [ i ] = temp ; } } let min = Number . MAX_VALUE ; let x = 0 , y = 0 ; for ( let i = 1 ; i < n ; i ++ ) {
if ( Math . abs ( arr [ i - 1 ] + arr [ i ] ) <= min ) {
min = Math . abs ( arr [ i - 1 ] + arr [ i ] ) ; x = i - 1 ; y = i ; } } document . write ( " " + " " + arr [ x ] + " " + arr [ y ] ) ; }
let arr = [ 1 , 60 , - 10 , 70 , - 80 , 85 ] ; let n = arr . length ; findMinSum ( arr , n ) ;
function increasing ( a , n ) { for ( let i = 0 ; i < n - 1 ; i ++ ) if ( a [ i ] >= a [ i + 1 ] ) return false ; return true ; }
function decreasing ( arr , n ) { for ( let i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] < arr [ i + 1 ] ) return false ; return true ; } function shortestUnsorted ( a , n ) {
if ( increasing ( a , n ) == true || decreasing ( a , n ) == true ) return 0 ; else return 3 ; }
let ar = [ 7 , 9 , 10 , 8 , 11 ] ; let n = ar . length ; document . write ( shortestUnsorted ( ar , n ) ) ;
function swap ( arr , i , j ) { let temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; }
function indexOf ( arr , ele ) { for ( let i = 0 ; i < arr . length ; i ++ ) { if ( arr [ i ] == ele ) { return i ; } } return - 1 ; }
function minSwaps ( arr , N ) { let ans = 0 ; let temp = [ ... arr ] ; temp . sort ( function ( a , b ) { return a - b ; } ) ; for ( let i = 0 ; i < N ; i ++ ) {
if ( arr [ i ] != temp [ i ] ) { ans ++ ;
swap ( arr , i , indexOf ( arr , temp [ i ] ) ) ; } } return ans ; }
let a = [ 101 , 758 , 315 , 730 , 472 , 619 , 460 , 479 ] ; let n = a . length ;
document . write ( minSwaps ( a , n ) ) ;
function printUnion ( arr1 , arr2 , m , n ) {
if ( m > n ) { let tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; let temp = m ; m = n ; n = temp ; }
arr1 . sort ( ( a , b ) => a - b ) ; for ( let i = 0 ; i < m ; i ++ ) document . write ( arr1 [ i ] + " " ) ;
for ( let i = 0 ; i < n ; i ++ ) if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) == - 1 ) document . write ( arr2 [ i ] + " " ) ; }
function printIntersection ( arr1 , arr2 , m , n ) {
if ( m > n ) { let tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; let temp = m ; m = n ; n = temp ; }
arr1 . sort ( ( a , b ) => a - b ) ;
for ( let i = 0 ; i < n ; i ++ ) if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) != - 1 ) document . write ( arr2 [ i ] + " " ) ; }
function binarySearch ( arr , l , r , x ) { if ( r >= l ) { let mid = l + Math . floor ( ( r - l ) / 2 ) ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
let arr1 = [ 7 , 1 , 5 , 2 , 3 , 6 ] ; let arr2 = [ 3 , 8 , 6 , 20 , 7 ] ; let m = arr1 . length ; let n = arr2 . length ;
document . write ( " " ) ; printUnion ( arr1 , arr2 , m , n ) ; document . write ( " " ) ; printIntersection ( arr1 , arr2 , m , n ) ;
function intersection ( a , b , n , m ) { let i = 0 , j = 0 ; while ( i < n && j < m ) { if ( a [ i ] > b [ j ] ) { j ++ ; } else if ( b [ j ] > a [ i ] ) { i ++ ; } else {
document . write ( a [ i ] + " " ) ; i ++ ; j ++ ; } } }
let a = [ 1 , 3 , 2 , 3 , 4 , 5 , 5 , 6 ] ; let b = [ 3 , 3 , 5 ] let n = a . length ; let m = b . length ;
a . sort ( ) ; b . sort ( ) ;
intersection ( a , b , n , m ) ;
function printArr ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
function sortArr ( arr , n ) { let i , cnt0 = 0 , cnt1 = 0 , cnt2 = 0 ;
for ( i = 0 ; i < n ; i ++ ) { switch ( arr [ i ] ) { case 0 : cnt0 ++ ; break ; case 1 : cnt1 ++ ; break ; case 2 : cnt2 ++ ; break ; } }
i = 0 ;
while ( cnt0 > 0 ) { arr [ i ++ ] = 0 ; cnt0 -- ; }
while ( cnt1 > 0 ) { arr [ i ++ ] = 1 ; cnt1 -- ; }
while ( cnt2 > 0 ) { arr [ i ++ ] = 2 ; cnt2 -- ; }
printArr ( arr , n ) ; }
let arr = [ 0 , 1 , 1 , 0 , 1 , 2 , 1 , 2 , 0 , 0 , 0 , 1 ] ; let n = arr . length ; sortArr ( arr , n ) ;
function findNumberOfTriangles ( arr , n ) {
let count = 0 ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = i + 1 ; j < n ; j ++ ) {
for ( let k = j + 1 ; k < n ; k ++ )
if ( arr [ i ] + arr [ j ] > arr [ k ] && arr [ i ] + arr [ k ] > arr [ j ] && arr [ k ] + arr [ j ] > arr [ i ] ) count ++ ; } } return count ; }
let arr = [ 10 , 21 , 22 , 100 , 101 , 200 , 300 ] ; let size = arr . length ; document . write ( " " + findNumberOfTriangles ( arr , size ) ) ;
function CountTriangles ( A ) { var n = A . length ; A . sort ( ) ; var count = 0 ; for ( i = n - 1 ; i >= 1 ; i -- ) { var l = 0 , r = i - 1 ; while ( l < r ) { if ( A [ l ] + A [ r ] > A [ i ] ) {
count += r - l ;
r -- ;
} else { l ++ ; } } } document . write ( " " + count ) ; }
var A = [ 4 , 3 , 5 , 7 , 6 ] ; CountTriangles ( A ) ;
function countPairsBruteForce ( X , Y , m , n ) { let ans = 0 ; for ( let i = 0 ; i < m ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) { if ( ( Math . pow ( X [ i ] , Y [ j ] ) > Math . pow ( Y [ j ] , X [ i ] ) ) ) { ans += 1 ; } } } return ans ; }
function countPairsWithDiffK ( arr , n , k ) { count = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
for ( let j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] - arr [ j ] == k arr [ j ] - arr [ i ] == k ) count ++ ; } return count ; }
arr = new Array ( 1 , 5 , 3 , 4 , 2 ) ; n = arr . length ; k = 3 ; document . write ( " " + countPairsWithDiffK ( arr , n , k ) ) ;
function binarySearch ( arr , low , high , x ) { if ( high >= low ) { let mid = low + Math . floor ( ( high - low ) / 2 ) ; if ( x == arr [ mid ] ) return mid ; if ( x > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
function countPairsWithDiffK ( arr , n , k ) { let count = 0 , i ;
arr . sort ( ( a , b ) => a - b ) ;
for ( i = 0 ; i < n - 1 ; i ++ ) if ( binarySearch ( arr , i + 1 , n - 1 , arr [ i ] + k ) != - 1 ) count ++ ; return count ; }
let arr = [ 1 , 5 , 3 , 4 , 2 ] ; let n = arr . length ; let k = 3 ; document . write ( " " + countPairsWithDiffK ( arr , n , k ) ) ;
function countPairsWithDiffK ( arr , n , k ) { let count = 0 ;
arr . sort ( ) ; let l = 0 ; let r = 0 ; while ( r < n ) { if ( arr [ r ] - arr [ l ] == k ) { count ++ ; l ++ ; r ++ ; } else if ( arr [ r ] - arr [ l ] > k ) l ++ ;
else r ++ ; } return count ; }
let arr = [ 1 , 5 , 3 , 4 , 2 ] ; let n = arr . length ; let k = 3 ; document . write ( " " + countPairsWithDiffK ( arr , n , k ) ) ;
class Node { constructor ( data ) { this . data = data ; this . left = this . right = null ; } }
function getSumAlternate ( root ) { if ( root == null ) return 0 ; let sum = root . data ; if ( root . left != null ) { sum += getSum ( root . left . left ) ; sum += getSum ( root . left . right ) ; } if ( root . right != null ) { sum += getSum ( root . right . left ) ; sum += getSum ( root . right . right ) ; } return sum ; }
function getSum ( root ) { if ( root == null ) return 0 ;
return Math . max ( getSumAlternate ( root ) , ( getSumAlternate ( root . left ) + getSumAlternate ( root . right ) ) ) ; }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . right . left = new Node ( 4 ) ; root . right . left . right = new Node ( 5 ) ; root . right . left . right . left = new Node ( 6 ) ; document . write ( getSum ( root ) ) ;
function constructArr ( arr , pair , n ) { arr [ 0 ] = Math . floor ( ( pair [ 0 ] + pair [ 1 ] - pair [ n - 1 ] ) / 2 ) ; for ( let i = 1 ; i < n ; i ++ ) arr [ i ] = pair [ i - 1 ] - arr [ 0 ] ; }
let pair = [ 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 ] ; let n = 5 ; let arr = new Array ( n ) ; constructArr ( arr , pair , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
let arr1 = [ 1 , 5 , 9 , 10 , 15 , 20 ] ; let arr2 = [ 2 , 3 , 8 , 13 ] ; function merge ( m , n ) {
for ( let i = n - 1 ; i >= 0 ; i -- ) {
let j , last = arr1 [ m - 1 ] ; for ( j = m - 2 ; j >= 0 && arr1 [ j ] > arr2 [ i ] ; j -- ) arr1 [ j + 1 ] = arr1 [ j ] ;
if ( j != m - 2 last > arr2 [ i ] ) { arr1 [ j + 1 ] = arr2 [ i ] ; arr2 [ i ] = last ; } } }
merge ( arr1 . length , arr2 . length ) ; document . write ( " " ) ; for ( let i = 0 ; i < arr1 . length ; i ++ ) { document . write ( arr1 [ i ] + " " ) ; } document . write ( " " ) ; for ( let i = 0 ; i < arr2 . length ; i ++ ) { document . write ( arr2 [ i ] + " " ) ; }
function minMaxProduct ( arr1 , arr2 , n1 , n2 ) {
arr1 . sort ( ( a , b ) => a - b ) ; arr2 . sort ( ( a , b ) => a - b ) ;
return ( arr1 [ n1 - 1 ] * arr2 [ 0 ] ) ; }
let arr1 = [ 10 , 2 , 3 , 6 , 4 , 1 ] ; let arr2 = [ 5 , 1 , 4 , 2 , 6 , 9 ] ; let n1 = arr1 . length ; let n2 = arr2 . length ; document . write ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ;
function minMaxProduct ( arr1 , arr2 , n1 , n2 ) {
let max = arr1 [ 0 ] ;
let min = arr2 [ 0 ] ; let i ; for ( i = 1 ; i < n1 && i < n2 ; ++ i ) {
if ( arr1 [ i ] > max ) max = arr1 [ i ] ;
if ( arr2 [ i ] < min ) min = arr2 [ i ] ; }
while ( i < n1 ) { if ( arr1 [ i ] > max ) max = arr1 [ i ] ; i ++ ; } while ( i < n2 ) { if ( arr2 [ i ] < min ) min = arr2 [ i ] ; i ++ ; } return max * min ; }
let arr1 = [ 10 , 2 , 3 , 6 , 4 , 1 ] ; let arr2 = [ 5 , 1 , 4 , 2 , 6 , 9 ] ; let n1 = 6 ; let n2 = 6 ; document . write ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ;
function findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) {
var i = 0 , j = 0 , k = 0 ;
while ( i < n1 && j < n2 && k < n3 ) {
if ( ar1 [ i ] == ar2 [ j ] && ar2 [ j ] == ar3 [ k ] ) { document . write ( ar1 [ i ] + " " ) ; i ++ ; j ++ ; k ++ ; }
else if ( ar1 [ i ] < ar2 [ j ] ) i ++ ;
else if ( ar2 [ j ] < ar3 [ k ] ) j ++ ;
else k ++ ; } }
var ar1 = [ 1 , 5 , 10 , 20 , 40 , 80 ] ; var ar2 = [ 6 , 7 , 20 , 80 , 100 ] ; var ar3 = [ 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 ] ; var n1 = ar1 . length ; var n2 = ar2 . length ; var n3 = ar3 . length ; document . write ( " " ) ; findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) ;
function binarySearch ( arr , l , r , x ) { if ( r >= l ) { let mid = l + Math . floor ( ( r - l ) / 2 ) ; if ( arr [ mid ] == x ) return mid ; if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ; return binarySearch ( arr , mid + 1 , r , x ) ; } return - 1 ; }
function findPos ( arr , key ) { let l = 0 , h = 1 ; let val = arr [ 0 ] ;
while ( val < key ) {
l = h ;
h = 2 * h ;
val = arr [ h ] ; }
return binarySearch ( arr , l , h , key ) ; }
let arr = [ 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 ] ; let ans = findPos ( arr , 10 ) ; if ( ans == - 1 ) document . write ( " " ) ; else document . write ( " " + ans ) ;
function findSingle ( ar , ar_size ) {
let res = ar [ 0 ] ; for ( let i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
let ar = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] ; let n = ar . length ; document . write ( " " + findSingle ( ar , n ) ) ;
function singleNumber ( nums , n ) { let m = new Map ( ) ; let sum1 = 0 , sum2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( ! m . has ( nums [ i ] ) ) { sum1 += nums [ i ] ; m . set ( nums [ i ] , 1 ) ; } sum2 += nums [ i ] ; }
return ( 2 * ( sum1 ) - sum2 ) ; }
let a = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] ; let n = 7 ; document . write ( singleNumber ( a , n ) + " " ) ; let b = [ 15 , 18 , 16 , 18 , 16 , 15 , 89 ] ; document . write ( singleNumber ( b , n ) ) ;
function isPresent ( B , m , x ) { for ( let i = 0 ; i < m ; i ++ ) if ( B [ i ] == x ) return true ; return false ; }
function findMaxSubarraySumUtil ( A , B , n , m ) {
let max_so_far = - 2147483648 , curr_max = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( isPresent ( B , m , A [ i ] ) ) { curr_max = 0 ; continue ; }
curr_max = Math . max ( A [ i ] , curr_max + A [ i ] ) ; max_so_far = Math . max ( max_so_far , curr_max ) ; } return max_so_far ; }
function findMaxSubarraySum ( A , B , n , m ) { let maxSubarraySum = findMaxSubarraySumUtil ( A , B , n , m ) ;
if ( maxSubarraySum == - 2147483648 ) { document . write ( " " + " " + " " ) ; } else { document . write ( " " + maxSubarraySum ) ; } }
let A = [ 3 , 4 , 5 , - 4 , 6 ] ; let B = [ 1 , 8 , 5 ] ; let n = A . length ; let m = B . length ;
findMaxSubarraySum ( A , B , n , m ) ;
function findMaxSum ( arr , n ) { var res = - 1000000000 ; for ( var i = 0 ; i < n ; i ++ ) { var prefix_sum = arr [ i ] ; for ( var j = 0 ; j < i ; j ++ ) prefix_sum += arr [ j ] ; var suffix_sum = arr [ i ] ; for ( var j = n - 1 ; j > i ; j -- ) suffix_sum += arr [ j ] ; if ( prefix_sum == suffix_sum ) res = Math . max ( res , prefix_sum ) ; } return res ; }
var arr = [ - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 ] ; var n = arr . length ; document . write ( findMaxSum ( arr , n ) ) ;
function getHeight ( Node ) { if ( Node == null ) return 0 ; else {
let lHeight = getHeight ( Node . left ) ; let rHeight = getHeight ( Node . right ) ;
if ( lHeight > rHeight ) return ( lHeight + 1 ) ; else return ( rHeight + 1 ) ; } }
function getTotalHeight ( root ) { if ( root == null ) return 0 ; return getTotalHeight ( root . left ) + getHeight ( root ) + getTotalHeight ( root . right ) ; }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; document . write ( " " + getTotalHeight ( root ) ) ;
function findMaxSum ( arr , n ) {
let preSum = new Array ( n ) ; preSum . fill ( 0 ) ;
let suffSum = new Array ( n ) ; suffSum . fill ( 0 ) ;
let ans = Number . MIN_VALUE ;
preSum [ 0 ] = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) preSum [ i ] = preSum [ i - 1 ] + arr [ i ] ;
suffSum [ n - 1 ] = arr [ n - 1 ] ; if ( preSum [ n - 1 ] == suffSum [ n - 1 ] ) ans = Math . max ( ans , preSum [ n - 1 ] ) ; for ( let i = n - 2 ; i >= 0 ; i -- ) { suffSum [ i ] = suffSum [ i + 1 ] + arr [ i ] ; if ( suffSum [ i ] == preSum [ i ] ) ans = Math . max ( ans , preSum [ i ] ) ; } return ans ; }
let arr = [ - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 ] ; let n = arr . length ; document . write ( findMaxSum ( arr , n ) ) ;
function equilibrium ( a , n ) { if ( n == 1 ) return ( 0 ) ; var forward = new Array ( 0 ) ; var rev = new Array ( 0 ) ;
for ( let i = 0 ; i < n ; i ++ ) { if ( i ) { forward [ i ] = forward [ i - 1 ] + a [ i ] ; } else { forward [ i ] = a [ i ] ; } }
for ( let i = n - 1 ; i > 0 ; i -- ) { if ( i <= n - 2 ) { rev [ i ] = rev [ i + 1 ] + a [ i ] ; } else { rev [ i ] = a [ i ] ; } }
for ( let i = 0 ; i < n ; i ++ ) { if ( forward [ i ] == rev [ i ] ) { return i ; } } return - 1 ;
}
arr = new Array ( - 7 , 1 , 5 , 2 , - 4 , 3 , 0 ) ; n = arr . length ; document . write ( " " + equilibrium ( arr , n ) + " " ) ;
function printLeaders ( arr , size ) { for ( let i = 0 ; i < size ; i ++ ) { let j ; for ( j = i + 1 ; j < size ; j ++ ) { if ( arr [ i ] <= arr [ j ] ) break ; }
if ( j == size ) document . write ( arr [ i ] + " " ) ; } }
let arr = [ 16 , 17 , 4 , 3 , 5 , 2 ] ; let n = arr . length ;
function findMajority ( arr , n ) { let maxCount = 0 ;
let index = - 1 ; for ( let i = 0 ; i < n ; i ++ ) { let count = 0 ; for ( let j = 0 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; }
if ( count > maxCount ) { maxCount = count ; index = i ; } }
if ( maxCount > n / 2 ) document . write ( arr [ index ] ) ; else document . write ( " " ) ; }
let arr = [ 1 , 1 , 2 , 1 , 3 , 5 , 1 ] ; let n = arr . length ;
findMajority ( arr , n ) ;
class Node { constructor ( data ) { this . data = data ; this . left = this . right = null ; } } let sum ;
function getTotalHeightUtil ( root ) { if ( root == null ) { return 0 ; } let lh = getTotalHeightUtil ( root . left ) ; let rh = getTotalHeightUtil ( root . right ) ; let h = Math . max ( lh , rh ) + 1 ; sum = sum + h ; return h ; } function getTotalHeight ( root ) { sum = 0 ; getTotalHeightUtil ( root ) ; return sum ; }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; document . write ( " " , getTotalHeight ( root ) ) ;
function majorityElement ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ; let count = 1 , max_ele = - 1 , temp = arr [ 0 ] , ele = 0 , f = 0 ; for ( let i = 1 ; i < n ; i ++ ) {
if ( temp == arr [ i ] ) { count ++ ; } else { count = 1 ; temp = arr [ i ] ; }
if ( max_ele < count ) { max_ele = count ; ele = arr [ i ] ; if ( max_ele > parseInt ( n / 2 , 10 ) ) { f = 1 ; break ; } } }
return ( f == 1 ? ele : - 1 ) ; }
let arr = [ 1 , 1 , 2 , 1 , 3 , 5 , 1 ] ; let n = 7 ;
document . write ( majorityElement ( arr , n ) ) ;
function _binarySearch ( arr , low , high , x ) { if ( high >= low ) { let mid = parseInt ( ( low + high ) / 2 , 10 ) ;
if ( ( mid == 0 x > arr [ mid - 1 ] ) && ( arr [ mid ] == x ) ) return mid ; else if ( x > arr [ mid ] ) return _binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return _binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
function isMajority ( arr , n , x ) {
let i = _binarySearch ( arr , 0 , n - 1 , x ) ;
if ( i == - 1 ) return false ;
if ( ( ( i + parseInt ( n / 2 , 10 ) ) <= ( n - 1 ) ) && arr [ i + parseInt ( n / 2 , 10 ) ] == x ) return true ; else return false ; }
function isMajorityElement ( arr , n , key ) { if ( arr [ parseInt ( n / 2 , 10 ) ] == key ) return true ; else return false ; }
let arr = [ 1 , 2 , 3 , 3 , 3 , 3 , 10 ] ; let n = arr . length ; let x = 3 ; if ( isMajorityElement ( arr , n , x ) ) document . write ( x + " " + parseInt ( n / 2 , 10 ) + " " ) ; else document . write ( x + " " + " " + parseInt ( n / 2 , 10 ) + " " ) ;
function isPairSum ( A , N , X ) {
var i = 0 ;
var j = N - 1 ; while ( i < j ) {
if ( A [ i ] + A [ j ] == X ) return true ;
else if ( A [ i ] + A [ j ] < X ) i ++ ;
else j -- ; } return false ; }
var arr = [ 3 , 5 , 9 , 2 , 8 , 10 , 11 ] ;
var val = 17 ;
document . write ( isPairSum ( arr , arrSize , val ) ) ;
function findPeak ( arr , n ) {
if ( n == 1 ) return 0 ; if ( arr [ 0 ] >= arr [ 1 ] ) return 0 ; if ( arr [ n - 1 ] >= arr [ n - 2 ] ) return n - 1 ;
for ( var i = 1 ; i < n - 1 ; i ++ ) {
if ( arr [ i ] >= arr [ i - 1 ] && arr [ i ] >= arr [ i + 1 ] ) return i ; } }
var arr = [ 1 , 3 , 20 , 4 , 1 , 0 ] ; var n = arr . length ; document . write ( " " + findPeak ( arr , n ) ) ;
function maxTripletSum ( arr , n ) {
let sum = - 1000000 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) for ( let k = j + 1 ; k < n ; k ++ ) if ( sum < arr [ i ] + arr [ j ] + arr [ k ] ) sum = arr [ i ] + arr [ j ] + arr [ k ] ; return sum ; }
let arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] ; let n = arr . length ; document . write ( maxTripletSum ( arr , n ) ) ;
function maxTripletSum ( arr , n ) {
arr . sort ( ) ;
return arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ; }
let arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] ; let n = arr . length ; document . write ( maxTripletSum ( arr , n ) ) ;
function maxTripletSum ( arr , n ) {
let maxA = Number . MIN_SAFE_INTEGER ; let maxB = Number . MIN_SAFE_INTEGER ; let maxC = Number . MIN_SAFE_INTEGER ; for ( let i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > maxA ) { maxC = maxB ; maxB = maxA ; maxA = arr [ i ] ; }
else if ( arr [ i ] > maxB ) { maxC = maxB ; maxB = arr [ i ] ; }
else if ( arr [ i ] > maxC ) maxC = arr [ i ] ; } return ( maxA + maxB + maxC ) ; }
let arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] ; let n = arr . length ; document . write ( maxTripletSum ( arr , n ) ) ;
function maximum ( a , b , c ) { return Math . max ( Math . max ( a , b ) , c ) ; }
function minimum ( a , b , c ) { return Math . min ( Math . min ( a , b ) , c ) ; }
function smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) {
arr1 . sort ( function ( a , b ) { return a - b } ) ; arr2 . sort ( function ( a , b ) { return a - b } ) ; arr3 . sort ( function ( a , b ) { return a - b } ) ;
let res_min = 0 , res_max = 0 , res_mid = 0 ;
let i = 0 , j = 0 , k = 0 ;
let diff = 2147483647 ; while ( i < n && j < n && k < n ) { let sum = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
let max = maximum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ;
let min = minimum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ; if ( min == arr1 [ i ] ) i ++ ; else if ( min == arr2 [ j ] ) j ++ ; else k ++ ;
if ( diff > ( max - min ) ) { diff = max - min ; res_max = max ; res_mid = sum - ( max + min ) ; res_min = min ; } }
document . write ( res_max + " " + res_mid + " " + res_min ) ; }
let arr1 = [ 5 , 2 , 8 ] ; let arr2 = [ 10 , 7 , 12 ] ; let arr3 = [ 9 , 14 , 6 ] ; let n = arr1 . length ; smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) ;
function find3Numbers ( A , arr_size , sum ) { let l , r ;
A . sort ( ( a , b ) => a - b ) ;
for ( let i = 0 ; i < arr_size - 2 ; i ++ ) {
l = i + 1 ;
r = arr_size - 1 ; while ( l < r ) { if ( A [ i ] + A [ l ] + A [ r ] == sum ) { document . write ( " " + A [ i ] + " " + A [ l ] + " " + A [ r ] ) ; return true ; } else if ( A [ i ] + A [ l ] + A [ r ] < sum ) l ++ ;
else r -- ; } }
return false ; }
let A = [ 1 , 4 , 45 , 6 , 10 , 8 ] ; let sum = 22 ; let arr_size = A . length ; find3Numbers ( A , arr_size , sum ) ;
let SIZE = 10
function sortMat ( mat , n ) {
let temp = new Array ( n * n ) ; let k = 0 ;
for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n ; j ++ ) temp [ k ++ ] = mat [ i ] [ j ] ;
temp . sort ( ) ;
k = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n ; j ++ ) mat [ i ] [ j ] = temp [ k ++ ] ; }
function printMat ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) document . write ( mat [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let mat = [ [ 5 , 4 , 7 ] , [ 1 , 3 , 8 ] , [ 2 , 9 , 6 ] ] ; let n = 3 ; document . write ( " " + " " ) ; printMat ( mat , n ) ; sortMat ( mat , n ) ; document . write ( " " ) ; document . write ( " " + " " ) ; printMat ( mat , n ) ;
function subArray ( n ) {
for ( let i = 0 ; i < n ; i ++ ) {
for ( let j = i ; j < n ; j ++ ) {
for ( let k = i ; k <= j ; k ++ ) document . write ( arr [ k ] + " " ) ; document . write ( " " ) ; } } }
document . write ( " " + " " ) ; subArray ( arr . length ) ;
function printSubsequences ( arr , n ) {
let opsize = parseInt ( Math . pow ( 2 , n ) , 10 ) ;
for ( let counter = 1 ; counter < opsize ; counter ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( ( counter & ( 1 << j ) ) != 0 ) document . write ( arr [ j ] + " " ) ; } document . write ( " " ) ; } }
let arr = [ 1 , 2 , 3 , 4 ] ; let n = arr . length ; document . write ( " " + " " ) ; printSubsequences ( arr , n ) ;
function productArray ( arr , n ) {
if ( n == 1 ) { document . write ( " " ) ; return ; } var i , temp = 1 ;
var prod = Array ( n ) . fill ( 0 ) ;
for ( i = 0 ; i < n ; i ++ ) { prod [ i ] = temp ; temp *= arr [ i ] ; }
temp = 1 ;
for ( i = n - 1 ; i >= 0 ; i -- ) { prod [ i ] *= temp ; temp *= arr [ i ] ; }
for ( i = 0 ; i < n ; i ++ ) document . write ( prod [ i ] + " " ) ; return ; }
var arr = [ 10 , 3 , 5 , 6 , 2 ] ; var n = arr . length ; document . write ( " " ) ; productArray ( arr , n ) ;
function areConsecutive ( arr , n ) { if ( n < 1 ) return false ;
let min = getMin ( arr , n ) ;
let max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) {
let visited = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) { visited [ i ] = false ; } let i ; for ( i = 0 ; i < n ; i ++ ) {
if ( visited [ arr [ i ] - min ] != false ) { return false ; }
visited [ arr [ i ] - min ] = true ; }
return true ; }
return false ; }
let arr = [ 5 , 4 , 2 , 3 , 1 , 6 ] let n = arr . length ; if ( areConsecutive ( arr , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function areConsecutive ( arr , n ) { if ( n < 1 ) return false ;
let min = getMin ( arr , n ) ;
let max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) { let i ; for ( i = 0 ; i < n ; i ++ ) { let j ; if ( arr [ i ] < 0 ) j = - arr [ i ] - min ; else j = arr [ i ] - min ;
if ( arr [ j ] > 0 ) arr [ j ] = - arr [ j ] ; else return false ; }
return true ; }
return false ; }
function getMin ( arr , n ) { let min = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } function getMax ( arr , n ) { let max = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
let arr = [ 5 , 4 , 2 , 3 , 1 , 6 ] ; let n = arr . length ; if ( areConsecutive ( arr , n ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
function relativeComplement ( arr1 , arr2 , n , m ) { let i = 0 , j = 0 ; while ( i < n && j < m ) {
if ( arr1 [ i ] < arr2 [ j ] ) { document . write ( arr1 [ i ] + " " ) ; i ++ ;
} else if ( arr1 [ i ] > arr2 [ j ] ) { j ++ ;
} else if ( arr1 [ i ] == arr2 [ j ] ) { i ++ ; j ++ ; } }
while ( i < n ) document . write ( arr1 [ i ] + " " ) ; }
let arr1 = [ 3 , 6 , 10 , 12 , 15 ] ; let arr2 = [ 1 , 3 , 5 , 10 , 16 ] ; let n = arr1 . length ; let m = arr2 . length ; relativeComplement ( arr1 , arr2 , n , m ) ;
function minOps ( arr , n , k ) {
var max = arr [ 0 ] ; for ( var i = 0 ; i < arr . length ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } var res = 0 ;
for ( var i = 0 ; i < n ; i ++ ) {
if ( ( max - arr [ i ] ) % k != 0 ) return - 1 ;
else res += ( max - arr [ i ] ) / k ; }
return res ; }
var arr = [ 21 , 33 , 9 , 45 , 63 ] ; var n = arr . length ; var k = 6 ; document . write ( minOps ( arr , n , k ) ) ;
function solve ( A , B , C ) { let i , j , k ;
i = A . length - 1 ; j = B . length - 1 ; k = C . length - 1 ; let min_diff , current_diff , max_term ;
min_diff = Math . abs ( Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) - Math . min ( A [ i ] , Math . min ( B [ j ] , C [ k ] ) ) ) ; while ( i != - 1 && j != - 1 && k != - 1 ) { current_diff = Math . abs ( Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) - Math . min ( A [ i ] , Math . min ( B [ j ] , C [ k ] ) ) ) ;
if ( current_diff < min_diff ) min_diff = current_diff ;
max_term = Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) ;
if ( A [ i ] == max_term ) i -= 1 ; else if ( B [ j ] == max_term ) j -= 1 ; else k -= 1 ; } return min_diff ; }
let D = [ 5 , 8 , 10 , 15 ] ; let E = [ 6 , 9 , 15 , 78 , 89 ] ; let F = [ 2 , 3 , 6 , 6 , 8 , 8 , 10 ] ; document . write ( solve ( D , E , F ) ) ;
function search ( arr , search_Element ) { let left = 0 ; let length = arr . length ; let right = length - 1 ; let position = - 1 ;
for ( left = 0 ; left <= right ; ) {
if ( arr [ left ] == search_Element ) { position = left ; document . write ( " " + ( position + 1 ) + " " + ( left + 1 ) + " " ) ; break ; }
if ( arr [ right ] == search_Element ) { position = right ; document . write ( " " + ( position + 1 ) + " " + ( length - right ) + " " ) ; break ; } left ++ ; right -- ; }
if ( position == - 1 ) document . write ( " " + left + " " ) ; }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ; let search_element = 5 ;
search ( arr , search_element ) ;
function jumpSearch ( arr , x , n ) {
let step = Math . sqrt ( n ) ;
let prev = 0 ; while ( arr [ Math . min ( step , n ) - 1 ] < x ) { prev = step ; step += Math . sqrt ( n ) ; if ( prev >= n ) return - 1 ; }
while ( arr [ prev ] < x ) { prev ++ ;
if ( prev == Math . min ( step , n ) ) return - 1 ; }
if ( arr [ prev ] == x ) return prev ; return - 1 ; }
let arr = [ 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 ] ; let x = 55 ; let n = arr . length ;
let index = jumpSearch ( arr , x , n ) ;
document . write ( ` ${ x } ${ index } ` ) ;
function interpolationSearch ( arr , lo , hi , x ) { let pos ;
if ( lo <= hi && x >= arr [ lo ] && x <= arr [ hi ] ) {
pos = lo + Math . floor ( ( ( hi - lo ) / ( arr [ hi ] - arr [ lo ] ) ) * ( x - arr [ lo ] ) ) ; ;
if ( arr [ pos ] == x ) { return pos ; }
if ( arr [ pos ] < x ) { return interpolationSearch ( arr , pos + 1 , hi , x ) ; }
if ( arr [ pos ] > x ) { return interpolationSearch ( arr , lo , pos - 1 , x ) ; } } return - 1 ; }
let arr = [ 10 , 12 , 13 , 16 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 33 , 35 , 42 , 47 ] ; let n = arr . length ;
let x = 18 let index = interpolationSearch ( arr , 0 , n - 1 , x ) ;
if ( index != - 1 ) { document . write ( ` ${ index } ` ) } else { document . write ( " " ) ; }
function exponentialSearch ( arr , n , x ) {
if ( arr [ 0 ] == x ) return 0 ;
let i = 1 ; while ( i < n && arr [ i ] <= x ) i = i * 2 ;
return binarySearch ( arr , i / 2 , Math . min ( i , n - 1 ) , x ) ; }
function binarySearch ( arr , l , r , x ) { if ( r >= l ) { let mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
let arr = [ 2 , 3 , 4 , 10 , 40 ] ; let n = arr . length ; let x = 10 ; let result = exponentialSearch ( arr , n , x ) ; if ( result == - 1 ) document . write ( " " ) ; else document . write ( " " + result ) ;
function countSort ( arr ) { var max = Math . max . apply ( Math , arr ) ; var min = Math . min . apply ( Math , arr ) ; var range = max - min + 1 ; var count = Array . from ( { length : range } , ( _ , i ) => 0 ) ; var output = Array . from ( { length : arr . length } , ( _ , i ) => 0 ) ; for ( i = 0 ; i < arr . length ; i ++ ) { count [ arr [ i ] - min ] ++ ; } for ( i = 1 ; i < count . length ; i ++ ) { count [ i ] += count [ i - 1 ] ; } for ( i = arr . length - 1 ; i >= 0 ; i -- ) { output [ count [ arr [ i ] - min ] - 1 ] = arr [ i ] ; count [ arr [ i ] - min ] -- ; } for ( i = 0 ; i < arr . length ; i ++ ) { arr [ i ] = output [ i ] ; } }
var arr = [ - 5 , - 10 , 0 , - 3 , 8 , 5 , - 1 , 10 ] ; countSort ( arr ) ; printArray ( arr ) ;
function getNextGap ( gap ) {
gap = parseInt ( ( gap * 10 ) / 13 , 10 ) ; if ( gap < 1 ) return 1 ; return gap ; }
function sort ( arr ) { let n = arr . length ;
let gap = n ;
let swapped = true ;
while ( gap != 1 swapped == true ) {
gap = getNextGap ( gap ) ;
swapped = false ;
for ( let i = 0 ; i < n - gap ; i ++ ) { if ( arr [ i ] > arr [ i + gap ] ) {
let temp = arr [ i ] ; arr [ i ] = arr [ i + gap ] ; arr [ i + gap ] = temp ;
swapped = true ; } } } }
let arr = [ 8 , 4 , 1 , 56 , 3 , - 44 , 23 , - 6 , 28 , 0 ] ; sort ( arr ) ; document . write ( " " + " " ) ; for ( let i = 0 ; i < arr . length ; ++ i ) document . write ( arr [ i ] + " " ) ;
function cycleSort ( arr , n ) {
let writes = 0 ;
for ( let cycle_start = 0 ; cycle_start <= n - 2 ; cycle_start ++ ) {
let item = arr [ cycle_start ] ;
let pos = cycle_start ; for ( let i = cycle_start + 1 ; i < n ; i ++ ) if ( arr [ i ] < item ) pos ++ ;
if ( pos == cycle_start ) continue ;
while ( item == arr [ pos ] ) pos += 1 ;
if ( pos != cycle_start ) { let temp = item ; item = arr [ pos ] ; arr [ pos ] = temp ; writes ++ ; }
while ( pos != cycle_start ) { pos = cycle_start ;
for ( let i = cycle_start + 1 ; i < n ; i ++ ) if ( arr [ i ] < item ) pos += 1 ;
while ( item == arr [ pos ] ) pos += 1 ;
if ( item != arr [ pos ] ) { let temp = item ; item = arr [ pos ] ; arr [ pos ] = temp ; writes ++ ; } } } }
let arr = [ 1 , 8 , 3 , 9 , 10 , 10 , 2 , 4 ] ; let n = arr . length ; cycleSort ( arr , n ) ; document . write ( " " + " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function findCrossOver ( arr , low , high , x ) {
if ( arr [ high ] <= x ) return high
if ( arr [ low ] > x ) return low
var mid = ( low + high ) / 2
if ( arr [ mid ] <= x && arr [ mid + 1 ] > x ) return mid
if ( arr [ mid ] < x ) return findCrossOver ( arr , mid + 1 , high , x ) return findCrossOver ( arr , low , mid - 1 , x ) }
function printKclosest ( arr , x , k , n ) {
var l = findCrossOver ( arr , 0 , n - 1 , x )
var r = l + 1
var count = 0
if ( arr [ l ] == x ) l -= 1
while ( l >= 0 && r < n && count < k ) { if ( x - arr [ l ] < arr [ r ] - x ) { document . write ( arr [ l ] + " " ) l -= 1 } else { document . write ( arr [ r ] + " " ) r += 1 } count += 1 }
while ( count < k && l >= 0 ) { print ( arr [ l ] ) l -= 1 count += 1 }
while ( count < k && r < n ) { print ( arr [ r ] ) r += 1 count += 1 } }
var arr = [ 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 ] var n = arr . length var x = 35 var k = 4 printKclosest ( arr , x , 4 , n )
function countSort ( arr , n , exp ) {
let output = new Array ( n ) ; let count = new Array ( n ) ; count . fill ( 0 ) ; output . fill ( 0 ) ; let i ; for ( i = 0 ; i < n ; i ++ ) count [ i ] = 0 ;
for ( i = 0 ; i < n ; i ++ ) count [ parseInt ( arr [ i ] / exp , 10 ) % n ] ++ ;
for ( i = 1 ; i < n ; i ++ ) count [ i ] += count [ i - 1 ] ;
for ( i = n - 1 ; i >= 0 ; i -- ) { output [ count [ parseInt ( arr [ i ] / exp , 10 ) % n ] - 1 ] = arr [ i ] ; count [ parseInt ( arr [ i ] / exp , 10 ) % n ] -- ; }
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = output [ i ] ; }
function sort ( arr , n ) {
countSort ( arr , n , 1 ) ;
countSort ( arr , n , n ) ; }
let arr = [ 40 , 12 , 45 , 32 , 33 , 1 , 22 ] ; let n = arr . length ; document . write ( " " + " " ) ; printArr ( arr , n ) ; sort ( arr , n ) ; document . write ( " " + " " ) ; printArr ( arr , n ) ;
function printClosest ( ar1 , ar2 , m , n , x ) {
let diff = Number . MAX_VALUE ;
let l = 0 , r = n - 1 ; while ( l < m && r >= 0 ) {
if ( Math . abs ( ar1 [ l ] + ar2 [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( ar1 [ l ] + ar2 [ r ] - x ) ; }
if ( ar1 [ l ] + ar2 [ r ] > x ) r -- ;
else l ++ ; }
document . write ( " " + ar1 [ res_l ] + " " + ar2 [ res_r ] + " " ) ; }
let ar1 = [ 1 , 4 , 5 , 7 ] ; let ar2 = [ 10 , 20 , 30 , 40 ] ; let m = ar1 . length ; let n = ar2 . length ; let x = 38 ; printClosest ( ar1 , ar2 , m , n , x ) ;
function printClosest ( arr , n , x ) {
let res_l = 0 , res_r = 0 ;
let l = 0 , r = n - 1 , diff = Number . MAX_VALUE ;
while ( r > l ) {
if ( Math . abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } document . write ( " " + arr [ res_l ] + " " + arr [ res_r ] ) ; }
let arr = [ 10 , 22 , 28 , 29 , 30 , 40 ] , x = 54 ; let n = arr . length ; printClosest ( arr , n , x ) ;
function countOnes ( arr , low , high ) { if ( high >= low ) {
let mid = Math . trunc ( low + ( high - low ) / 2 ) ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
let arr = [ 1 , 1 , 1 , 1 , 0 , 0 , 0 ] ; let n = arr . length ; document . write ( " " + countOnes ( arr , 0 , n - 1 ) ) ;
var head = null ; var sorted = null ; class node { constructor ( val ) { this . val = val ; this . next = null ; } }
function push ( val ) {
var newnode = new node ( val ) ;
newnode . next = head ;
head = newnode ; }
function insertionSort ( headref ) {
var sorted = null ; var current = headref ;
while ( current != null ) {
var next = current . next ;
sortedInsert ( current ) ;
current = next ; }
head = sorted ; }
function sortedInsert ( newnode ) {
if ( sorted == null sorted . val >= newnode . val ) { newnode . next = sorted ; sorted = newnode ; } else { var current = sorted ;
while ( current . next != null && current . next . val < newnode . val ) { current = current . next ; } newnode . next = current . next ; current . next = newnode ; } }
function printlist ( head ) { while ( head != null ) { document . write ( head . val + " " ) ; head = head . next ; } }
push ( 5 ) ; push ( 20 ) ; push ( 4 ) ; push ( 3 ) ; push ( 30 ) ; document . write ( " " ) ; printlist ( head ) ; insertionSort ( head ) ; document . write ( " " ) ; printlist ( sorted ) ;
function solve ( a , n ) { let maxx = - 1 , minn = a [ 0 ] , l = 0 , r = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( a [ i ] > maxx ) { maxx = a [ i ] ; l = i ; }
if ( a [ i ] <= minn ) { minn = a [ i ] ; r = i ; } } if ( r < l ) document . write ( l + ( n - r - 2 ) ) ; else document . write ( l + ( n - r - 1 ) ) ; }
let a = [ 5 , 6 , 1 , 3 ] ; let n = a . length ; solve ( a , n ) ;
function MaxActivities ( arr , n ) {
let selected = [ ] ; Activity = Activity . sort ( function ( a , b ) { return a [ 1 ] - b [ 1 ] ; } ) ;
let i = 0 selected . push ( arr [ i ] ) ;
for ( let j = 1 ; j < n ; j ++ ) {
if ( arr [ j ] [ 0 ] >= arr [ i ] [ 1 ] ) { selected . push ( arr [ j ] ) ; i = j ; } } return selected ; }
Activity = [ [ 5 , 9 ] , [ 1 , 2 ] , [ 3 , 4 ] , [ 0 , 6 ] , [ 5 , 7 ] , [ 8 , 9 ] ] ; n = Activity . length ; selected = MaxActivities ( Activity , n ) ; document . write ( " " ) console . log ( selected ) for ( let i = 0 ; i < selected . length ; i ++ ) document . write ( " " + selected [ i ] + " " )
let max_ref ;
function _lis ( arr , n ) {
if ( n == 1 ) return 1 ;
let res , max_ending_here = 1 ;
for ( let i = 1 ; i < n ; i ++ ) { res = _lis ( arr , i ) ; if ( arr [ i - 1 ] < arr [ n - 1 ] && res + 1 > max_ending_here ) max_ending_here = res + 1 ; }
if ( max_ref < max_ending_here ) max_ref = max_ending_here ;
return max_ending_here ; }
function lis ( arr , n ) {
max_ref = 1 ;
_lis ( arr , n ) ;
return max_ref ; }
let arr = [ 10 , 22 , 9 , 33 , 21 , 50 , 41 , 60 ] let n = arr . length ; document . write ( " " + lis ( arr , n ) + " " ) ;
function lis ( arr , n ) { let lis = Array ( n ) . fill ( 0 ) ; let i , j , max = 0 ;
for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
for ( i = 0 ; i < n ; i ++ ) if ( max < lis [ i ] ) max = lis [ i ] ; return max ; }
let arr = [ 10 , 22 , 9 , 33 , 21 , 50 , 41 , 60 ] ; let n = arr . length ; document . write ( " " + lis ( arr , n ) + " " ) ;
var row = 3 ; var col = 3 ; function minCost ( cost ) {
for ( i = 1 ; i < row ; i ++ ) { cost [ i ] [ 0 ] += cost [ i - 1 ] [ 0 ] ; }
for ( j = 1 ; j < col ; j ++ ) { cost [ 0 ] [ j ] += cost [ 0 ] [ j - 1 ] ; }
for ( i = 1 ; i < row ; i ++ ) { for ( j = 1 ; j < col ; j ++ ) { cost [ i ] [ j ] += Math . min ( cost [ i - 1 ] [ j - 1 ] , Math . min ( cost [ i - 1 ] [ j ] , cost [ i ] [ j - 1 ] ) ) ; } }
return cost [ row - 1 ] [ col - 1 ] ; }
var cost = [ [ 1 , 2 , 3 ] , [ 4 , 8 , 2 ] , [ 1 , 5 , 3 ] ] ; document . write ( minCost ( cost ) + ' ' ) ;
function count ( S , m , n ) {
if ( n == 0 ) return 1 ;
if ( n < 0 ) return 0 ;
if ( m <= 0 && n >= 1 ) return 0 ;
return count ( S , m - 1 , n ) + count ( S , m , n - S [ m - 1 ] ) ; }
var arr = [ 1 , 2 , 3 ] ; var m = arr . length ; document . write ( count ( arr , m , 4 ) ) ;
function count ( S , m , n ) {
let table = new Array ( n + 1 ) ; table . fill ( 0 ) ;
table [ 0 ] = 1 ;
for ( let i = 0 ; i < m ; i ++ ) for ( let j = S [ i ] ; j <= n ; j ++ ) table [ j ] += table [ j - S [ i ] ] ; return table [ n ] ; }
let arr = [ 1 , 2 , 3 ] ; let m = arr . length ; let n = 4 ; document . write ( count ( arr , m , n ) ) ;
let dp = new Array ( 100 ) ; for ( var i = 0 ; i < dp . length ; i ++ ) { dp [ i ] = new Array ( 2 ) ; }
function matrixChainMemoised ( p , i , j ) { if ( i == j ) { return 0 ; } if ( dp [ i ] [ j ] != - 1 ) { return dp [ i ] [ j ] ; } dp [ i ] [ j ] = Number . MAX_VALUE ; for ( let k = i ; k < j ; k ++ ) { dp [ i ] [ j ] = Math . min ( dp [ i ] [ j ] , matrixChainMemoised ( p , i , k ) + matrixChainMemoised ( p , k + 1 , j ) + p [ i - 1 ] * p [ k ] * p [ j ] ) ; } return dp [ i ] [ j ] ; } function MatrixChainOrder ( p , n ) { let i = 1 , j = n - 1 ; return matrixChainMemoised ( p , i , j ) ; }
let arr = [ 1 , 2 , 3 , 4 ] ; let n = arr . length ; for ( var i = 0 ; i < dp . length ; i ++ ) { for ( var j = 0 ; j < dp . length ; j ++ ) { dp [ i ] [ j ] = - 1 ; } } document . write ( " " + MatrixChainOrder ( arr , n ) ) ;
function binomialCoeff ( n , k ) { let C = new Array ( k + 1 ) ; C . fill ( 0 ) ;
C [ 0 ] = 1 ; for ( let i = 1 ; i <= n ; i ++ ) {
for ( let j = Math . min ( i , k ) ; j > 0 ; j -- ) C [ j ] = C [ j ] + C [ j - 1 ] ; } return C [ k ] ; }
let n = 5 , k = 2 ; document . write ( " " + n + " " + k + " " + binomialCoeff ( n , k ) ) ;
function eggDrop ( n , k ) {
if ( k == 1 k == 0 ) return k ;
if ( n == 1 ) return k ; let min = Number . MAX_VALUE ; let x , res ;
for ( x = 1 ; x <= k ; x ++ ) { res = Math . max ( eggDrop ( n - 1 , x - 1 ) , eggDrop ( n , k - x ) ) ; if ( res < min ) min = res ; } return min + 1 ; }
let n = 2 , k = 10 ; document . write ( " " + " " + n + " " + k + " " + eggDrop ( n , k ) ) ;
function cutRod ( price , n ) { if ( n <= 0 ) return 0 ; let max_val = Number . MIN_VALUE ;
for ( let i = 0 ; i < n ; i ++ ) max_val = Math . max ( max_val , price [ i ] + cutRod ( price , n - i - 1 ) ) ; return max_val ; }
let arr = [ 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ] ; let size = arr . length ; document . write ( " " + cutRod ( arr , size ) ) ;
const findRoot = ( nodeList ) => {
let root = 0 ; nodeList . forEach ( element => root += ( Number ( element [ 0 ] ) - Number ( element [ 1 ] ) ) ) ; return root ; }
let nodeList = [ [ 1 , 5 ] , [ 2 , 0 ] , [ 3 , 0 ] , [ 4 , 0 ] , [ 5 , 5 ] , [ 6 , 5 ] ] ; let root = findRoot ( nodeList ) ; document . write ( root ) ;
function cutRod ( price , n ) { let val = new Array ( n + 1 ) ; val [ 0 ] = 0 ;
for ( let i = 1 ; i <= n ; i ++ ) { let max_val = Number . MIN_VALUE ; for ( let j = 0 ; j < i ; j ++ ) max_val = Math . max ( max_val , price [ j ] + val [ i - j - 1 ] ) ; val [ i ] = max_val ; } return val [ n ] ; }
let arr = [ 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ] ; let size = arr . length ; document . write ( " " + cutRod ( arr , size ) + " " ) ;
function lbs ( arr , n ) { let i , j ;
let lis = new Array ( n ) for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
let lds = new Array ( n ) ; for ( i = 0 ; i < n ; i ++ ) lds [ i ] = 1 ;
for ( i = n - 2 ; i >= 0 ; i -- ) for ( j = n - 1 ; j > i ; j -- ) if ( arr [ i ] > arr [ j ] && lds [ i ] < lds [ j ] + 1 ) lds [ i ] = lds [ j ] + 1 ;
let max = lis [ 0 ] + lds [ 0 ] - 1 ; for ( i = 1 ; i < n ; i ++ ) if ( lis [ i ] + lds [ i ] - 1 > max ) max = lis [ i ] + lds [ i ] - 1 ; return max ; }
let arr = [ 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 ] let n = arr . length ; document . write ( " " + lbs ( arr , n ) ) ;
function isPalindrome ( String , i , j ) { while ( i < j ) { if ( String [ i ] != String [ j ] ) return false ; i ++ ; j -- ; } return true ; } function minPalPartion ( String , i , j ) { if ( i >= j || isPalindrome ( String , i , j ) ) return 0 ; let ans = Number . MAX_VALUE , count ; for ( let k = i ; k < j ; k ++ ) { count = minPalPartion ( String , i , k ) + minPalPartion ( String , k + 1 , j ) + 1 ; ans = Math . min ( ans , count ) ; } return ans ; }
let str = " " ; document . write ( " " + " " + minPalPartion ( str , 0 , str . length - 1 ) ) ;
function findPartiion ( arr , n ) { let sum = 0 ; let i , j ;
for ( i = 0 ; i < n ; i ++ ) sum += arr [ i ] ; if ( sum % 2 != 0 ) return false ; let part = new Array ( parseInt ( sum / 2 + 1 , 10 ) ) ;
for ( i = 0 ; i <= parseInt ( sum / 2 , 10 ) ; i ++ ) { part [ i ] = false ; }
for ( i = 0 ; i < n ; i ++ ) {
for ( j = parseInt ( sum / 2 , 10 ) ; j >= arr [ i ] ; j -- ) {
if ( part [ j - arr [ i ] ] == true j == arr [ i ] ) part [ j ] = true ; } } return part [ parseInt ( sum / 2 , 10 ) ] ; }
let arr = [ 1 , 3 , 3 , 2 , 3 , 2 ] ; let n = arr . length ;
if ( findPartiion ( arr , n ) == true ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ;
let MAX = Number . MAX_VALUE ;
function printSolution ( p , n ) { let k ; if ( p [ n ] == 1 ) k = 1 ; else k = printSolution ( p , p [ n ] - 1 ) + 1 ; document . write ( " " + " " + k + " " + " " + " " + p [ n ] + " " + " " + " " + n + " " ) ; return k ; }
function solveWordWrap ( l , n , M ) {
let extras = new Array ( n + 1 ) ;
let lc = new Array ( n + 1 ) ; for ( let i = 0 ; i < n + 1 ; i ++ ) { extras [ i ] = new Array ( n + 1 ) ; lc [ i ] = new Array ( n + 1 ) ; for ( let j = 0 ; j < n + 1 ; j ++ ) { extras [ i ] [ j ] = 0 ; lc [ i ] [ j ] = 0 ; } }
let c = new Array ( n + 1 ) ;
let p = new Array ( n + 1 ) ;
for ( let i = 1 ; i <= n ; i ++ ) { extras [ i ] [ i ] = M - l [ i - 1 ] ; for ( let j = i + 1 ; j <= n ; j ++ ) extras [ i ] [ j ] = extras [ i ] [ j - 1 ] - l [ j - 1 ] - 1 ; }
for ( let i = 1 ; i <= n ; i ++ ) { for ( let j = i ; j <= n ; j ++ ) { if ( extras [ i ] [ j ] < 0 ) lc [ i ] [ j ] = MAX ; else if ( j == n && extras [ i ] [ j ] >= 0 ) lc [ i ] [ j ] = 0 ; else lc [ i ] [ j ] = extras [ i ] [ j ] * extras [ i ] [ j ] ; } }
c [ 0 ] = 0 ; for ( let j = 1 ; j <= n ; j ++ ) { c [ j ] = MAX ; for ( let i = 1 ; i <= j ; i ++ ) { if ( c [ i - 1 ] != MAX && lc [ i ] [ j ] != MAX && ( c [ i - 1 ] + lc [ i ] [ j ] < c [ j ] ) ) { c [ j ] = c [ i - 1 ] + lc [ i ] [ j ] ; p [ j ] = i ; } } } printSolution ( p , n ) ; }
let l = [ 3 , 2 , 2 , 5 ] ; let n = l . length ; let M = 6 ; solveWordWrap ( l , n , M ) ;
function maxDivide ( a , b ) { while ( a % b == 0 ) a = a / b ; return a ; }
function isUgly ( no ) { no = maxDivide ( no , 2 ) ; no = maxDivide ( no , 3 ) ; no = maxDivide ( no , 5 ) ; return ( no == 1 ) ? 1 : 0 ; }
function getNthUglyNo ( n ) { var i = 1 ;
var count = 1 ;
while ( n > count ) { i ++ ; if ( isUgly ( i ) == 1 ) count ++ ; } return i ; }
var no = getNthUglyNo ( 150 ) ; document . write ( " " + " " + no ) ;
function sum ( freq , i , j ) { var s = 0 ; for ( var k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
function optCost ( freq , i , j ) {
if ( j < i ) return 0 ;
if ( j == i ) return freq [ i ] ;
var fsum = sum ( freq , i , j ) ;
var min = Number . MAX_SAFE_INTEGER ;
for ( var r = i ; r <= j ; ++ r ) { var cost = optCost ( freq , i , r - 1 ) + optCost ( freq , r + 1 , j ) ; if ( cost < min ) min = cost ; }
return min + fsum ; }
function optimalSearchTree ( keys , freq , n ) {
return optCost ( freq , 0 , n - 1 ) ; }
var keys = [ 10 , 12 , 20 ] ; var freq = [ 34 , 8 , 50 ] ; var n = keys . length ; document . write ( " " + optimalSearchTree ( keys , freq , n ) ) ;
function sum ( freq , i , j ) { var s = 0 ; for ( var k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
function optimalSearchTree ( keys , freq , n ) {
var cost = new Array ( n ) ; for ( var i = 0 ; i < n ; i ++ ) cost [ i ] = new Array ( n ) ;
for ( var i = 0 ; i < n ; i ++ ) cost [ i ] [ i ] = freq [ i ] ;
for ( var L = 2 ; L <= n ; L ++ ) {
for ( var i = 0 ; i <= n - L + 1 ; i ++ ) {
var j = i + L - 1 ; if ( i >= n j >= n ) break cost [ i ] [ j ] = Number . MAX_SAFE_INTEGER ;
for ( var r = i ; r <= j ; r ++ ) {
var c = 0 ; if ( r > i ) c += cost [ i ] [ r - 1 ] if ( r < j ) c += cost [ r + 1 ] [ j ] c += sum ( freq , i , j ) ; if ( c < cost [ i ] [ j ] ) cost [ i ] [ j ] = c ; } } } return cost [ 0 ] [ n - 1 ] ; }
var keys = [ 10 , 12 , 20 ] ; var freq = [ 34 , 8 , 50 ] ; var n = keys . length ; document . write ( " " + optimalSearchTree ( keys , freq , n ) ) ;
function isSubsetSum ( set , n , sum ) {
if ( sum == 0 ) return true ; if ( n == 0 ) return false ;
if ( set [ n - 1 ] > sum ) return isSubsetSum ( set , n - 1 , sum ) ;
return isSubsetSum ( set , n - 1 , sum ) || isSubsetSum ( set , n - 1 , sum - set [ n - 1 ] ) ; }
let set = [ 3 , 34 , 4 , 12 , 5 , 2 ] ; let sum = 9 ; let n = set . length ; if ( isSubsetSum ( set , n , sum ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
function isSubsetSum ( set , n , sum ) {
let subset = new Array ( sum + 1 ) ; for ( let i = 0 ; i < sum + 1 ; i ++ ) { subset [ i ] = new Array ( sum + 1 ) ; for ( let j = 0 ; j < n + 1 ; j ++ ) { subset [ i ] [ j ] = 0 ; } }
for ( let i = 0 ; i <= n ; i ++ ) subset [ 0 ] [ i ] = true ;
for ( let i = 1 ; i <= sum ; i ++ ) subset [ i ] [ 0 ] = false ;
for ( let i = 1 ; i <= sum ; i ++ ) { for ( let j = 1 ; j <= n ; j ++ ) { subset [ i ] [ j ] = subset [ i ] [ j - 1 ] ; if ( i >= set [ j - 1 ] ) subset [ i ] [ j ] = subset [ i ] [ j ] || subset [ i - set [ j - 1 ] ] [ j - 1 ] ; } }
for ( int i = 0 ; i <= sum ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) System . out . println ( subset [ i ] [ j ] ) ; } return subset [ sum ] [ n ] ; }
let set = [ 3 , 34 , 4 , 12 , 5 , 2 ] ; let sum = 9 ; let n = set . length ; if ( isSubsetSum ( set , n , sum ) == true ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ;
function countParenth ( symb , oper , n ) { let F = new Array ( n ) ; let T = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) { F [ i ] = new Array ( n ) ; T [ i ] = new Array ( n ) ; for ( let j = 0 ; j < n ; j ++ ) { F [ i ] [ j ] = 0 ; T [ i ] [ j ] = 0 ; } }
for ( let i = 0 ; i < n ; i ++ ) { F [ i ] [ i ] = ( symb [ i ] == ' ' ) ? 1 : 0 ; T [ i ] [ i ] = ( symb [ i ] == ' ' ) ? 1 : 0 ; }
for ( let gap = 1 ; gap < n ; ++ gap ) { for ( let i = 0 , j = gap ; j < n ; ++ i , ++ j ) { T [ i ] [ j ] = F [ i ] [ j ] = 0 ; for ( let g = 0 ; g < gap ; g ++ ) {
let k = i + g ;
let tik = T [ i ] [ k ] + F [ i ] [ k ] ; let tkj = T [ k + 1 ] [ j ] + F [ k + 1 ] [ j ] ;
if ( oper [ k ] == ' ' ) { T [ i ] [ j ] += T [ i ] [ k ] * T [ k + 1 ] [ j ] ; F [ i ] [ j ] += ( tik * tkj - T [ i ] [ k ] * T [ k + 1 ] [ j ] ) ; } if ( oper [ k ] == ' ' ) { F [ i ] [ j ] += F [ i ] [ k ] * F [ k + 1 ] [ j ] ; T [ i ] [ j ] += ( tik * tkj - F [ i ] [ k ] * F [ k + 1 ] [ j ] ) ; } if ( oper [ k ] == ' ' ) { T [ i ] [ j ] += F [ i ] [ k ] * T [ k + 1 ] [ j ] + T [ i ] [ k ] * F [ k + 1 ] [ j ] ; F [ i ] [ j ] += T [ i ] [ k ] * T [ k + 1 ] [ j ] + F [ i ] [ k ] * F [ k + 1 ] [ j ] ; } } } } return T [ 0 ] [ n - 1 ] ; }
let symbols = " " . split ( ' ' ) ; let operators = " " . split ( ' ' ) ; let n = symbols . length ;
document . write ( countParenth ( symbols , operators , n ) ) ;
function getCount ( keypad , n ) { if ( keypad == null n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
let row = [ 0 , 0 , - 1 , 0 , 1 ] ; let col = [ 0 , - 1 , 0 , 1 , 0 ] ;
let count = new Array ( 10 ) ; for ( let i = 0 ; i < 10 ; i ++ ) { count [ i ] = new Array ( n + 1 ) ; for ( let j = 0 ; j < n + 1 ; j ++ ) { count [ i ] [ j ] = 0 ; } } let i = 0 , j = 0 , k = 0 , move = 0 , ro = 0 , co = 0 , num = 0 ; let nextNum = 0 , totalCount = 0 ;
for ( i = 0 ; i <= 9 ; i ++ ) { count [ i ] [ 0 ] = 0 ; count [ i ] [ 1 ] = 1 ; }
for ( k = 2 ; k <= n ; k ++ ) {
for ( i = 0 ; i < 4 ; i ++ ) {
for ( j = 0 ; j < 3 ; j ++ ) {
if ( keypad [ i ] [ j ] != ' ' && keypad [ i ] [ j ] != ' ' ) {
num = keypad [ i ] [ j ] . charCodeAt ( 0 ) - ' ' . charCodeAt ( 0 ) ; count [ num ] [ k ] = 0 ;
for ( move = 0 ; move < 5 ; move ++ ) { ro = i + row [ move ] ; co = j + col [ move ] ; if ( ro >= 0 && ro <= 3 && co >= 0 && co <= 2 && keypad [ ro ] [ co ] != ' ' && keypad [ ro ] [ co ] != ' ' ) { nextNum = keypad [ ro ] [ co ] . charCodeAt ( 0 ) - ' ' . charCodeAt ( 0 ) ; count [ num ] [ k ] += count [ nextNum ] [ k - 1 ] ; } } } } } }
totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ ) totalCount += count [ i ] [ n ] ; return totalCount ; }
let keypad = [ [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] ] ; document . write ( " " + 1 + " " + getCount ( keypad , 1 ) + " " ) document . write ( " " + 2 + " " + getCount ( keypad , 2 ) + " " ) document . write ( " " + 3 + " " + getCount ( keypad , 3 ) + " " ) document . write ( " " + 4 + " " + getCount ( keypad , 4 ) + " " ) document . write ( " " + 5 + " " + getCount ( keypad , 5 ) + " " )
function getCount ( keypad , n ) { if ( keypad == null n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
var odd = Array . from ( { length : 10 } , ( _ , i ) => 0 ) ; var even = Array . from ( { length : 10 } , ( _ , i ) => 0 ) ; var i = 0 , j = 0 , useOdd = 0 , totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ )
odd [ i ] = 1 ;
for ( j = 2 ; j <= n ; j ++ ) { useOdd = 1 - useOdd ;
if ( useOdd == 1 ) { even [ 0 ] = odd [ 0 ] + odd [ 8 ] ; even [ 1 ] = odd [ 1 ] + odd [ 2 ] + odd [ 4 ] ; even [ 2 ] = odd [ 2 ] + odd [ 1 ] + odd [ 3 ] + odd [ 5 ] ; even [ 3 ] = odd [ 3 ] + odd [ 2 ] + odd [ 6 ] ; even [ 4 ] = odd [ 4 ] + odd [ 1 ] + odd [ 5 ] + odd [ 7 ] ; even [ 5 ] = odd [ 5 ] + odd [ 2 ] + odd [ 4 ] + odd [ 8 ] + odd [ 6 ] ; even [ 6 ] = odd [ 6 ] + odd [ 3 ] + odd [ 5 ] + odd [ 9 ] ; even [ 7 ] = odd [ 7 ] + odd [ 4 ] + odd [ 8 ] ; even [ 8 ] = odd [ 8 ] + odd [ 0 ] + odd [ 5 ] + odd [ 7 ] + odd [ 9 ] ; even [ 9 ] = odd [ 9 ] + odd [ 6 ] + odd [ 8 ] ; } else { odd [ 0 ] = even [ 0 ] + even [ 8 ] ; odd [ 1 ] = even [ 1 ] + even [ 2 ] + even [ 4 ] ; odd [ 2 ] = even [ 2 ] + even [ 1 ] + even [ 3 ] + even [ 5 ] ; odd [ 3 ] = even [ 3 ] + even [ 2 ] + even [ 6 ] ; odd [ 4 ] = even [ 4 ] + even [ 1 ] + even [ 5 ] + even [ 7 ] ; odd [ 5 ] = even [ 5 ] + even [ 2 ] + even [ 4 ] + even [ 8 ] + even [ 6 ] ; odd [ 6 ] = even [ 6 ] + even [ 3 ] + even [ 5 ] + even [ 9 ] ; odd [ 7 ] = even [ 7 ] + even [ 4 ] + even [ 8 ] ; odd [ 8 ] = even [ 8 ] + even [ 0 ] + even [ 5 ] + even [ 7 ] + even [ 9 ] ; odd [ 9 ] = even [ 9 ] + even [ 6 ] + even [ 8 ] ; } }
totalCount = 0 ; if ( useOdd == 1 ) { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += even [ i ] ; } else { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += odd [ i ] ; } return totalCount ; }
var keypad = [ [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] ] ; document . write ( " " + 1 + " " + getCount ( keypad , 1 ) ) ; document . write ( " " + 2 + " " + getCount ( keypad , 2 ) ) ; document . write ( " " + 3 + " " + getCount ( keypad , 3 ) ) ; document . write ( " " + 4 + " " + getCount ( keypad , 4 ) ) ; document . write ( " " + 5 + " " + getCount ( keypad , 5 ) ) ;
function countRec ( n , sum ) {
if ( n == 0 ) return sum == 0 ; if ( sum == 0 ) return 1 ;
let ans = 0 ;
for ( let i = 0 ; i <= 9 ; i ++ ) { if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; } return ans ; }
function finalCount ( n , sum ) {
let ans = 0 ;
for ( let i = 1 ; i <= 9 ; i ++ ) { if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; } return ans ; }
let n = 2 , sum = 5 ; document . write ( finalCount ( n , sum ) ) ;
let lookup = new Array ( 101 ) ;
function countRec ( n , sum ) {
if ( n == 0 ) return sum == 0 ? 1 : 0 ;
if ( lookup [ n ] [ sum ] != - 1 ) return lookup [ n ] [ sum ] ;
let ans = 0 ;
for ( let i = 0 ; i < 10 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return lookup [ n ] [ sum ] = ans ; }
function finalCount ( n , sum ) {
let ans = 0 ;
for ( let i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
let n = 3 , sum = 5 ; document . write ( finalCount ( n , sum ) ) ;
function findCount ( n , sum ) {
let start = Math . pow ( 10 , n - 1 ) ; let end = Math . pow ( 10 , n ) - 1 ; let count = 0 ; let i = start ; while ( i <= end ) { let cur = 0 ; let temp = i ; while ( temp != 0 ) { cur += temp % 10 ; temp = parseInt ( temp / 10 ) ; } if ( cur == sum ) { count ++ ; i += 9 ; } else i ++ ; } document . write ( count ) ; }
let n = 3 ; let sum = 5 ; findCount ( n , sum ) ;
function countNonDecreasing ( n ) {
let dp = new Array ( 10 ) ; for ( let i = 0 ; i < 10 ; i ++ ) { dp [ i ] = new Array ( n + 1 ) ; } for ( let i = 0 ; i < 10 ; i ++ ) { for ( let j = 0 ; j < n + 1 ; j ++ ) { dp [ i ] [ j ] = 0 ; } }
for ( let i = 0 ; i < 10 ; i ++ ) dp [ i ] [ 1 ] = 1 ;
for ( let digit = 0 ; digit <= 9 ; digit ++ ) {
for ( let len = 2 ; len <= n ; len ++ ) {
for ( let x = 0 ; x <= digit ; x ++ ) dp [ digit ] [ len ] += dp [ x ] [ len - 1 ] ; } } let count = 0 ;
for ( let i = 0 ; i < 10 ; i ++ ) count += dp [ i ] [ n ] ; return count ; }
let n = 3 ; document . write ( countNonDecreasing ( n ) ) ;
function countNonDecreasing ( n ) { let N = 10 ;
let count = 1 ; for ( let i = 1 ; i <= n ; i ++ ) { count *= ( N + i - 1 ) ; count = Math . floor ( count / i ) ; } return count ; }
let n = 3 ; document . write ( countNonDecreasing ( n ) ) ;
function getMinSquares ( n ) {
if ( n <= 3 ) return n ;
let res = n ;
for ( let x = 1 ; x <= n ; x ++ ) { let temp = x * x ; if ( temp > n ) break ; else res = Math . min ( res , 1 + getMinSquares ( n - temp ) ) ; } return res ; }
document . write ( getMinSquares ( 6 ) ) ;
function getMinSquares ( n ) {
dp [ 0 ] = 0 ; dp [ 1 ] = 1 ; dp [ 2 ] = 2 ; dp [ 3 ] = 3 ;
for ( var i = 4 ; i <= n ; i ++ ) {
dp [ i ] = i ;
for ( var x = 1 ; x <= Math . ceil ( Math . sqrt ( i ) ) ; x ++ ) { var temp = x * x ; if ( temp > i ) break ; else dp [ i ] = Math . min ( dp [ i ] , 1 + dp [ i - temp ] ) ; } }
var res = dp [ n ] ; return res ; }
document . write ( getMinSquares ( 6 ) ) ;
function minCoins ( coins , m , V ) {
if ( V == 0 ) return 0 ;
let res = Number . MAX_VALUE ;
for ( let i = 0 ; i < m ; i ++ ) { if ( coins [ i ] <= V ) { let sub_res = minCoins ( coins , m , V - coins [ i ] ) ;
if ( sub_res != Number . MAX_VALUE && sub_res + 1 < res ) res = sub_res + 1 ; } } return res ; }
let coins = [ 9 , 6 , 5 , 1 ] ; let m = coins . length ; let V = 11 ; document . write ( " " + minCoins ( coins , m , V ) ) ;
function minCoins ( coins , m , v ) {
let table = new Array ( V + 1 ) ;
for ( let i = 0 ; i < V + 1 ; i ++ ) { table [ i ] = 0 ; }
for ( let i = 1 ; i <= V ; i ++ ) { table [ i ] = Number . MAX_VALUE ; }
for ( let i = 1 ; i <= V ; i ++ ) {
for ( let j = 0 ; j < m ; j ++ ) if ( coins [ j ] <= i ) { let sub_res = table [ i - coins [ j ] ] ; if ( sub_res != Number . MAX_VALUE && sub_res + 1 < table [ i ] ) table [ i ] = sub_res + 1 ; } } if ( table [ V ] == Number . MAX_VALUE ) return - 1 ; return table [ V ] ; }
let coins = [ 9 , 6 , 5 , 1 ] ; let m = coins . length ; let V = 11 ; document . write ( " " + minCoins ( coins , m , V ) )
function superSeq ( X , Y , m , n ) { if ( m == 0 ) return n ; if ( n == 0 ) return m ; if ( X . charAt ( m - 1 ) == Y . charAt ( n - 1 ) ) return 1 + superSeq ( X , Y , m - 1 , n - 1 ) ; return 1 + Math . min ( superSeq ( X , Y , m - 1 , n ) , superSeq ( X , Y , m , n - 1 ) ) ; }
var X = " " ; var Y = " " ; document . write ( " " + " " + superSeq ( X , Y , X . length , Y . length ) ) ;
function superSeq ( X , Y , m , n ) { var dp = Array ( m + 1 ) . fill ( 0 ) . map ( x => Array ( n + 1 ) . fill ( 0 ) ) ;
for ( var i = 0 ; i <= m ; i ++ ) { for ( var j = 0 ; j <= n ; j ++ ) {
if ( i == 0 ) dp [ i ] [ j ] = j ; else if ( j == 0 ) dp [ i ] [ j ] = i ; else if ( X . charAt ( i - 1 ) == Y . charAt ( j - 1 ) ) dp [ i ] [ j ] = 1 + dp [ i - 1 ] [ j - 1 ] ; else dp [ i ] [ j ] = 1 + Math . min ( dp [ i - 1 ] [ j ] , dp [ i ] [ j - 1 ] ) ; } } return dp [ m ] [ n ] ; }
var X = " " ; var Y = " " ; document . write ( " " + superSeq ( X , Y , X . length , Y . length ) ) ;
function sumOfDigitsFrom1ToN ( n ) {
let result = 0 ;
for ( let x = 1 ; x <= n ; x ++ ) result += sumOfDigits ( x ) ; return result ; }
function sumOfDigits ( x ) { let sum = 0 ; while ( x != 0 ) { sum += x % 10 ; x = parseInt ( x / 10 , 10 ) ; } return sum ; }
let n = 328 ; document . write ( " " + " " + n + " " + sumOfDigitsFrom1ToN ( n ) ) ;
function sumOfDigitsFrom1ToN ( n ) {
if ( n < 10 ) return ( n * ( n + 1 ) / 2 ) ;
let d = parseInt ( Math . log ( n ) / Math . log ( 10 ) , 10 ) ;
let a = new Array ( d + 1 ) ; a [ 0 ] = 0 ; a [ 1 ] = 45 ; for ( let i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * parseInt ( Math . ceil ( Math . pow ( 10 , i - 1 ) ) , 10 ) ;
let p = parseInt ( Math . ceil ( Math . pow ( 10 , d ) ) , 10 ) ;
let msd = parseInt ( n / p , 10 ) ;
return ( msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToN ( n % p ) ) ; }
let n = 328 ; document . write ( " " + n + " " + sumOfDigitsFrom1ToN ( n ) ) ;
function sumOfDigitsFrom1ToNUtil ( n , a ) { if ( n < 10 ) return ( n * ( n + 1 ) / 2 ) ; var d = ( parseInt ) ( Math . log10 ( n ) ) ; var p = ( Math . ceil ( Math . pow ( 10 , d ) ) ) ; var msd = ( parseInt ) ( n / p ) ; return ( msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToNUtil ( n % p , a ) ) ; } function sumOfDigitsFrom1ToN ( n ) { var d = ( parseInt ) ( Math . log10 ( n ) ) ; var a = new Array ( d + 1 ) . fill ( 0 ) ; a [ 0 ] = 0 ; a [ 1 ] = 45 ; for ( var i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * ( parseInt ) ( Math . ceil ( Math . pow ( 10 , i - 1 ) ) ) ; return sumOfDigitsFrom1ToNUtil ( n , a ) ; }
var n = 328 ; document . write ( " " + n + " " + sumOfDigitsFrom1ToN ( n ) )
function countWays ( N ) {
if ( N == 1 )
return 4 ;
let countB = 1 , countS = 1 , prev_countB , prev_countS ;
for ( let i = 2 ; i <= N ; i ++ ) { prev_countB = countB ; prev_countS = countS ; countS = prev_countB + prev_countS ; countB = prev_countS ; }
let result = countS + countB ;
return ( result * result ) ; }
N = 3 ; document . write ( " " + N + " " + countWays ( N ) ) ;
function findoptimal ( N ) {
if ( N <= 6 ) return N ;
let screen = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { screen [ i ] = 0 ; }
let n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = 0 ;
for ( b = n - 3 ; b >= 1 ; b -- ) {
let curr = ( n - b - 1 ) * screen [ b - 1 ] ; if ( curr > screen [ n - 1 ] ) screen [ n - 1 ] = curr ; } } return screen [ N - 1 ] ; }
let N ;
for ( N = 1 ; N <= 20 ; N ++ ) document . write ( " " + N + " " + findoptimal ( N ) + " " ) ;
function findoptimal ( N ) {
if ( N <= 6 ) return N ;
let screen = [ ] ;
let n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = Math . max ( 2 * screen [ n - 4 ] , Math . max ( 3 * screen [ n - 5 ] , 4 * screen [ n - 6 ] ) ) ; } return screen [ N - 1 ] ; }
let N ;
for ( N = 1 ; N <= 20 ; N ++ ) document . write ( " " + N + " " + findoptimal ( N ) + " " ) ;
function power ( x , y ) { var temp ; if ( y == 0 ) return 1 ; temp = power ( x , y / 2 ) ; if ( y % 2 == 0 ) return temp * temp ; else return x * temp * temp ; }
function power ( x , y ) {
if ( y == 0 ) return 1 ;
if ( x == 0 ) return 0 ;
return x * power ( x , y - 1 ) ; }
var x = 2 ; var y = 3 ; document . write ( power ( x , y ) ) ;
function area ( x1 , y1 , x2 , y2 , x3 , y3 ) { return Math . abs ( ( x1 * ( y2 - y3 ) + x2 * ( y3 - y1 ) + x3 * ( y1 - y2 ) ) / 2.0 ) ; }
function isInside ( x1 , y1 , x2 , y2 , x3 , y3 , x , y ) {
let A = area ( x1 , y1 , x2 , y2 , x3 , y3 ) ;
let A1 = area ( x , y , x2 , y2 , x3 , y3 ) ;
let A2 = area ( x1 , y1 , x , y , x3 , y3 ) ;
let A3 = area ( x1 , y1 , x2 , y2 , x , y ) ;
return ( A == A1 + A2 + A3 ) ; }
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) document . write ( " " ) ; else document . write ( " " ) ;
let preIndex = 0 ; function printPost ( In , pre , inStrt , inEnd , hm ) { if ( inStrt > inEnd ) return ;
let inIndex = hm . get ( pre [ preIndex ++ ] ) ;
printPost ( In , pre , inStrt , inIndex - 1 , hm ) ;
printPost ( In , pre , inIndex + 1 , inEnd , hm ) ;
document . write ( In [ inIndex ] + " " ) ; } function printPostMain ( In , pre ) { let n = pre . length ; let hm = new Map ( ) ; for ( let i = 0 ; i < n ; i ++ ) hm . set ( In [ i ] , i ) ; printPost ( In , pre , 0 , n - 1 , hm ) ; }
let In = [ 4 , 2 , 5 , 1 , 3 , 6 ] ; let pre = [ 1 , 2 , 4 , 5 , 3 , 6 ] ; printPostMain ( In , pre ) ;
class Node { constructor ( key ) { this . key = key ; this . left = this . right = null ; } }
function maxDiffUtil ( t , res ) {
if ( t == null ) return Number . MAX_VALUE ;
if ( t . left == null && t . right == null ) return t . key ;
var val = Math . min ( maxDiffUtil ( t . left , res ) , maxDiffUtil ( t . right , res ) ) ;
res . r = Math . max ( res . r , t . key - val ) ;
return Math . min ( val , t . key ) ; }
function maxDiff ( root ) {
res = new Res ( ) ; maxDiffUtil ( root , res ) ; return res . r ; }
function inorder ( root ) { if ( root != null ) { inorder ( root . left ) ; document . write ( root . key + " " ) ; inorder ( root . right ) ; } }
root = new Node ( 8 ) ; root . left = new Node ( 3 ) ; root . left . left = new Node ( 1 ) ; root . left . right = new Node ( 6 ) ; root . left . right . left = new Node ( 4 ) ; root . left . right . right = new Node ( 7 ) ; root . right = new Node ( 10 ) ; root . right . right = new Node ( 14 ) ; root . right . right . left = new Node ( 13 ) ; document . write ( " " + " " + maxDiff ( root ) ) ;
function getAvg ( prev_avg , x , n ) { return ( prev_avg * n + x ) / ( n + 1 ) ; }
function streamAvg ( arr , n ) { let avg = 0 ; for ( let i = 0 ; i < n ; i ++ ) { avg = getAvg ( avg , arr [ i ] , i ) ; document . write ( " " + ( i + 1 ) + " " + avg . toFixed ( 6 ) + " " ) ; } return ; }
let arr = [ 10 , 20 , 30 , 40 , 50 , 60 ] ; let n = arr . length ; streamAvg ( arr , n ) ;
function sieveOfEratosthenes ( n ) {
prime = Array . from ( { length : n + 1 } , ( _ , i ) => true ) ; for ( p = 2 ; p * p <= n ; p ++ ) {
if ( prime [ p ] == true ) {
for ( i = p * p ; i <= n ; i += p ) prime [ i ] = false ; } }
for ( i = 2 ; i <= n ; i ++ ) { if ( prime [ i ] == true ) document . write ( i + " " ) ; } }
var n = 30 ; document . write ( " " ) ; document . write ( " " + n + " " ) ; sieveOfEratosthenes ( n ) ;
function maximumNumberDistinctPrimeRange ( m , n ) {
let factorCount = new Array ( n + 1 ) ;
let prime = new Array ( n + 1 ) ;
for ( let i = 0 ; i <= n ; i ++ ) { factorCount [ i ] = 0 ;
prime [ i ] = true ; } for ( let i = 2 ; i <= n ; i ++ ) {
if ( prime [ i ] == true ) {
factorCount [ i ] = 1 ;
for ( let j = i * 2 ; j <= n ; j += i ) {
factorCount [ j ] ++ ;
prime [ j ] = false ; } } }
let max = factorCount [ m ] ; let num = m ;
for ( let i = m ; i <= n ; i ++ ) {
if ( factorCount [ i ] > max ) { max = factorCount [ i ] ; num = i ; } } return num ; }
let m = 4 , n = 6 ;
document . write ( maximumNumberDistinctPrimeRange ( m , n ) ) ;
function binomialCoeff ( n , k ) { let res = 1 ; if ( k > n - k ) k = n - k ; for ( let i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
function printPascal ( n ) {
for ( let line = 0 ; line < n ; line ++ ) {
for ( let i = 0 ; i <= line ; i ++ ) document . write ( binomialCoeff ( line , i ) + " " ) ; document . write ( " " ) ; } }
let n = 7 ; printPascal ( n ) ;
function findCeil ( arr , r , l , h ) { let mid ; while ( l < h ) {
mid = l + ( ( h - l ) >> 1 ) ; ( r > arr [ mid ] ) ? ( l = mid + 1 ) : ( h = mid ) ; } return ( arr [ l ] >= r ) ? l : - 1 ; }
function myRand ( arr , freq , n ) {
let prefix = [ ] ; let i ; prefix [ 0 ] = freq [ 0 ] ; for ( i = 1 ; i < n ; ++ i ) prefix [ i ] = prefix [ i - 1 ] + freq [ i ] ;
let r = Math . floor ( ( Math . random ( ) * prefix [ n - 1 ] ) ) + 1 ;
let indexc = findCeil ( prefix , r , 0 , n - 1 ) ; return arr [ indexc ] ; }
let arr = [ 1 , 2 , 3 , 4 ] ; let freq = [ 10 , 5 , 20 , 100 ] ; let i ; let n = arr . length ;
for ( i = 0 ; i < 5 ; i ++ ) document . write ( myRand ( arr , freq , n ) ) ;
function isPerfectSquare ( x ) { let s = parseInt ( Math . sqrt ( x ) ) ; return ( s * s == x ) ; }
function isFibonacci ( n ) {
return isPerfectSquare ( 5 * n * n + 4 ) || isPerfectSquare ( 5 * n * n - 4 ) ; }
for ( let i = 1 ; i <= 10 ; i ++ ) isFibonacci ( i ) ? document . write ( i + " " ) : document . write ( i + " " ) ;
function findTrailingZeros ( n ) {
let count = 0 ;
for ( let i = 5 ; Math . floor ( n / i ) >= 1 ; i *= 5 ) count += Math . floor ( n / i ) ; return count ; }
let n = 100 ; document . write ( " " + 100 + " " + findTrailingZeros ( n ) ) ;
function catalan ( n ) {
if ( n <= 1 ) return 1 ;
let res = 0 ; for ( let i = 0 ; i < n ; i ++ ) res += catalan ( i ) * catalan ( n - i - 1 ) ; return res ; }
for ( let i = 0 ; i < 10 ; i ++ ) document . write ( catalan ( i ) + " " ) ;
function catalanDP ( n ) {
let catalan = [ ] ;
catalan [ 0 ] = catalan [ 1 ] = 1 ;
for ( let i = 2 ; i <= n ; i ++ ) { catalan [ i ] = 0 ; for ( let j = 0 ; j < i ; j ++ ) catalan [ i ] += catalan [ j ] * catalan [ i - j - 1 ] ; }
return catalan [ n ] ; }
for ( let i = 0 ; i < 10 ; i ++ ) document . write ( catalanDP ( i ) + " " ) ;
function binomialCoeff ( n , k ) { let res = 1 ;
if ( k > n - k ) k = n - k ;
for ( let i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res = Math . floor ( res / ( i + 1 ) ) ; } return res ; }
function catalan ( n ) {
c = binomialCoeff ( 2 * ( n ) , n ) ;
return Math . floor ( c / ( n + 1 ) ) ; }
for ( let i = 0 ; i < 10 ; i ++ ) document . write ( catalan ( i ) + " " ) ;
function catalan ( n ) { let cat_ = 1 ;
document . write ( cat_ + " " ) ;
for ( let i = 1 ; i < n ; i ++ ) {
cat_ *= ( 4 * i - 2 ) ; cat_ /= ( i + 1 ) ; document . write ( cat_ + " " ) ; } }
let n = 5 ;
catalan ( n ) ;
function printString ( n ) { let arr = [ ] ; let i = 0 ;
while ( n ) { arr [ i ] = n % 26 ; n = Math . floor ( n / 26 ) ; i ++ ; }
for ( let j = 0 ; j < i - 1 ; j ++ ) { if ( arr [ j ] <= 0 ) { arr [ j ] += 26 ; arr [ j + 1 ] = arr [ j + 1 ] - 1 ; } } let ans = ' ' ; for ( let j = i ; j >= 0 ; j -- ) { if ( arr [ j ] > 0 ) ans += String . fromCharCode ( 65 + arr [ j ] - 1 ) ; } document . write ( ans + " " ) ; }
printString ( 26 ) ; printString ( 51 ) ; printString ( 52 ) ; printString ( 80 ) ; printString ( 676 ) ; printString ( 702 ) ; printString ( 705 ) ;
function getInvCount ( arr ) { let inv_count = 0 ; for ( let i = 0 ; i < 2 ; i ++ ) { for ( let j = i + 1 ; j < 3 ; j ++ ) {
if ( arr [ j ] [ i ] > 0 && arr [ j ] [ i ] > arr [ i ] [ j ] ) inv_count += 1 ; } } return inv_count ; }
function isSolvable ( puzzle ) {
let invCount = getInvCount ( puzzle ) ;
return ( invCount % 2 == 0 ) ; }
puzzle = [ [ 1 , 8 , 2 ] , [ 0 , 4 , 3 ] , [ 7 , 6 , 5 ] ] ; if ( isSolvable ( puzzle ) ) document . write ( " " ) ; else document . write ( " " ) ;
function find ( p ) { return Math . ceil ( Math . sqrt ( 2 * 365 * Math . log ( 1 / ( 1 - p ) ) ) ) ; }
document . write ( find ( 0.70 ) ) ;
function countSolutions ( n ) { let res = 0 ; for ( let x = 0 ; x * x < n ; x ++ ) { for ( let y = 0 ; x * x + y * y < n ; y ++ ) { res ++ ; } } return res ; }
document . write ( " " + countSolutions ( 6 ) ) ;
function countSolutions ( n ) { let x = 0 , yCount , res = 0 ;
for ( yCount = 0 ; yCount * yCount < n ; yCount ++ ) ;
while ( yCount != 0 ) {
res += yCount ;
x ++ ;
while ( yCount != 0 && ( x * x + ( yCount - 1 ) * ( yCount - 1 ) >= n ) ) yCount -- ; } return res ; }
document . write ( " " + " " + countSolutions ( 6 ) ) ;
let MAX_ITER = 1000000
function func ( x ) { return x * x * x - x * x + 2 ; }
function regulaFalsi ( a , b ) { if ( func ( a ) * func ( b ) >= 0 ) { document . write ( " " ) ; return ; }
let c = a ; for ( let i = 0 ; i < MAX_ITER ; i ++ ) {
c = Math . floor ( ( a * func ( b ) - b * func ( a ) ) / ( func ( b ) - func ( a ) ) ) ;
if ( func ( c ) == 0 ) { break ; }
else if ( func ( c ) * func ( a ) < 0 ) { b = c ; } else { a = c ; } } document . write ( " " + c ) ; }
let a = - 200 ; let b = 300 ; regulaFalsi ( a , b ) ;
function func ( x ) { return x * x * x - x * x + 2 ; }
function derivFunc ( x ) { return 3 * x * x - 2 * x ; }
function newtonRaphson ( x ) { let h = func ( x ) / derivFunc ( x ) ; while ( Math . abs ( h ) >= EPSILON ) { h = func ( x ) / derivFunc ( x ) ;
x = x - h ; } document . write ( " " + " " + Math . round ( x * 100.0 ) / 100.0 ) ; }
let x0 = - 20 ; newtonRaphson ( x0 ) ;
function oppositeSigns ( x , y ) { return ( ( x ^ y ) < 0 ) ; }
let x = 100 , y = - 100 ; if ( oppositeSigns ( x , y ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
function countSetBits ( n ) {
let bitCount = 0 ; for ( let i = 1 ; i <= n ; i ++ ) { bitCount += countSetBitsUtil ( i ) ; } return bitCount ; }
function countSetBitsUtil ( x ) { if ( x <= 0 ) { return 0 ; } return ( x % 2 == 0 ? 0 : 1 ) + countSetBitsUtil ( Math . floor ( x / 2 ) ) ; }
let n = 4 ; document . write ( " " ) ; document . write ( countSetBits ( n ) ) ;
function countSetBits ( n ) { let i = 0 ;
let ans = 0 ;
while ( ( 1 << i ) <= n ) {
let k = 0 ;
let change = 1 << i ;
for ( let j = 0 ; j <= n ; j ++ ) { ans += k ; if ( change == 1 ) {
k = ! k ;
change = 1 << i ; } else { change -- ; } }
i ++ ; } return ans ; }
let n = 17 ; document . write ( countSetBits ( n ) ) ;
function getSetBitsFromOneToN ( N ) { var two = 2 var ans = 0 var n = N while ( n != 0 ) { ans += Math . floor ( N / two ) * ( two >> 1 ) if ( ( N & ( two - 1 ) ) > ( two >> 1 ) - 1 ) ans += ( N & ( two - 1 ) ) - ( two >> 1 ) + 1 two <<= 1 ; n >>= 1 ; } return ans }
function swapBits ( num , p1 , p2 , n ) { let shift1 , shift2 , value1 , value2 ; while ( n -- > 0 ) {
shift1 = 1 << p1 ;
shift2 = 1 << p2 ;
value1 = ( ( num & shift1 ) ) ; value2 = ( ( num & shift2 ) ) ;
if ( ( value1 == 0 && value2 != 0 ) || ( value2 == 0 && value1 != 0 ) ) {
if ( value1 != 0 ) {
num = num & ( ~ shift1 ) ;
num = num | shift2 ; }
else {
num = num & ( ~ shift2 ) ;
num = num | shift1 ; } } p1 ++ ; p2 ++ ; }
return num ; }
let res = swapBits ( 28 , 0 , 3 , 2 ) ; document . write ( " " + res ) ;
function Add ( x , y ) { if ( y == 0 ) return x ; else return Add ( x ^ y , ( x & y ) << 1 ) ; }
let CHAR_BIT = 8 ;
function min ( x , y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( 32 * CHAR_BIT - 1 ) ) ) }
function smallest ( x , y , z ) { return Math . min ( x , Math . min ( y , z ) ) ; }
let x = 12 , y = 15 , z = 5 ; document . write ( " " + smallest ( x , y , z ) ) ;
function smallest ( x , y , z ) {
if ( ! ( y / x ) ) return ( ! ( y / z ) ) ? y : z ; return ( ! ( x / z ) ) ? x : z ; }
let x = 78 , y = 88 , z = 68 ; document . write ( " " + smallest ( x , y , z ) ) ;
function changeToZero ( a ) { a [ a [ 1 ] ] = a [ 1 - a [ 1 ] ] ; }
let arr ; arr = [ ] ; arr [ 0 ] = 1 ; arr [ 1 ] = 0 ; changeToZero ( arr ) ; document . write ( " " + arr [ 0 ] + " " ) ; document . write ( " " + arr [ 1 ] ) ;
function snoob ( x ) { let rightOne , nextHigherOneBit , rightOnesPattern , next = 0 ; if ( x > 0 ) {
rightOne = x & - x ;
nextHigherOneBit = x + rightOne ;
rightOnesPattern = x ^ nextHigherOneBit ;
rightOnesPattern = ( rightOnesPattern ) / rightOne ;
rightOnesPattern >>= 2 ;
next = nextHigherOneBit | rightOnesPattern ; } return next ; }
let x = 156 ; document . write ( " " + " " + snoob ( x ) ) ;
function multiplyWith3Point5 ( x ) { return ( x << 1 ) + x + ( x >> 1 ) ; }
var x = 4 ; document . write ( multiplyWith3Point5 ( x ) ) ;
function isPowerOfFour ( n ) { return n != 0 && ( ( n & ( n - 1 ) ) == 0 ) && ! ( n & 0xAAAAAAAA ) ; }
test_no = 64 ; if ( isPowerOfFour ( test_no ) ) document . write ( test_no + " " ) ; else document . write ( test_no + " " ) ;
function logn ( n , r ) { return Math . log ( n ) / Math . log ( r ) ; } function isPowerOfFour ( n ) {
if ( n == 0 ) return false ; return Math . floor ( logn ( n , 4 ) ) == Math . ceil ( logn ( n , 4 ) ) ; }
let test_no = 64 ; if ( isPowerOfFour ( test_no ) ) document . write ( test_no + " " ) ; else document . write ( test_no + " " ) ;
class INT { constructor ( d ) { this . data = d ; } }
function findPostOrderUtil ( pre , n , minval , maxval , preIndex ) {
if ( preIndex . data == n ) return ;
if ( pre [ preIndex . data ] < minval pre [ preIndex . data ] > maxval ) { return ; }
let val = pre [ preIndex . data ] ; preIndex . data ++ ;
findPostOrderUtil ( pre , n , minval , val , preIndex ) ;
findPostOrderUtil ( pre , n , val , maxval , preIndex ) ; document . write ( val + " " ) ; }
function findPostOrder ( pre , n ) {
let preIndex = new INT ( 0 ) ; findPostOrderUtil ( pre , n , Number . MIN_VALUE , Number . MAX_VALUE , preIndex ) ; }
let pre = [ 40 , 30 , 35 , 80 , 100 ] ; let n = pre . length ;
findPostOrder ( pre , n ) ;
function isPowerOfFour ( n ) { return ( n > 0 && Math . pow ( 4 , ( Math . log2 ( n ) / Math . log2 ( 4 ) ) == n ) ) ; }
let test_no = 64 ; if ( isPowerOfFour ( test_no ) ) document . write ( test_no + " " ) ; else document . write ( test_no + " " ) ;
function getModulo ( n , d ) { return ( n & ( d - 1 ) ) ; }
n = 6 ;
d = 4 ; document . write ( n + " " + d + " " + getModulo ( n , d ) ) ;
var CHAR_BIT = 4 ; var INT_BIT = 8 ;
function min ( x , y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( INT_BIT * CHAR_BIT - 1 ) ) ) ; }
function max ( x , y ) { return x - ( ( x - y ) & ( ( x - y ) >> ( INT_BIT * CHAR_BIT - 1 ) ) ) ; }
var x = 15 ; var y = 6 ; document . write ( " " + x + " " + y + " " + min ( x , y ) + " " ) ; document . write ( " " + x + " " + y + " " + max ( x , y ) ) ;
function absbit32 ( x , y ) { var sub = x - y ; var mask = ( sub >> 31 ) ; return ( sub ^ mask ) - mask ; }
function max ( x , y ) { var abs = absbit32 ( x , y ) ; return ( x + y + abs ) / 2 ; }
function min ( x , y ) { var abs = absbit32 ( x , y ) ; return ( x + y - abs ) / 2 ; }
document . write ( max ( 2 , 3 ) + " " ) ; document . write ( max ( 2 , - 3 ) + " " ) ; document . write ( max ( - 2 , - 3 ) + " " ) ; document . write ( min ( 2 , 3 ) + " " ) ; document . write ( min ( 2 , - 3 ) + " " ) ; document . write ( min ( - 2 , - 3 ) ) ;
function UniqueNumbers2 ( arr , n ) { let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
sum = ( sum ^ arr [ i ] ) ; }
sum = ( sum & - sum ) ;
let sum1 = 0 ; let sum2 = 0 ;
for ( let i = 0 ; i < arr . length ; i ++ ) {
if ( ( arr [ i ] & sum ) > 0 ) {
sum1 = ( sum1 ^ arr [ i ] ) ; } else {
sum2 = ( sum2 ^ arr [ i ] ) ; } }
document . write ( " " + " " + sum1 + " " + sum2 ) ; }
let arr = [ 2 , 3 , 7 , 9 , 11 , 2 , 3 , 11 ] ; let n = arr . length ; UniqueNumbers2 ( arr , n ) ;
function getOddOccurrence ( arr , arr_size ) { for ( let i = 0 ; i < arr_size ; i ++ ) { let count = 0 ; for ( let j = 0 ; j < arr_size ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; } if ( count % 2 != 0 ) return arr [ i ] ; } return - 1 ; }
let arr = [ 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 ] ; let n = arr . length ;
document . write ( getOddOccurrence ( arr , n ) ) ;
function getOddOccurrence ( arr , n ) { let hmap = new Map ( ) ;
for ( let i = 0 ; i < n ; i ++ ) { if ( hmap . has ( arr [ i ] ) ) { let val = hmap . get ( arr [ i ] ) ;
for ( let [ key , value ] of hmap . entries ( ) ) { if ( hmap . get ( key ) % 2 != 0 ) return key ; } return - 1 ; }
let arr = [ 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 ] ; let n = arr . length ; document . write ( getOddOccurrence ( arr , n ) ) ;
function fastPow ( N , K ) { if ( K == 0 ) return 1 ; let temp = fastPow ( N , Math . floor ( K / 2 ) ) ; if ( K % 2 == 0 ) return temp * temp ; else return N * temp * temp ; } function countWays ( N , K ) { return K * fastPow ( K - 1 , N - 1 ) ; }
let N = 3 , K = 3 ; document . write ( countWays ( N , K ) ) ;
function countSetBits ( n ) {
if ( n == 0 ) return 0 ; else return 1 + countSetBits ( n & ( n - 1 ) ) ; }
var n = 9 ;
document . write ( countSetBits ( n ) ) ;
var BitsSetTable256 = Array . from ( { length : 256 } , ( _ , i ) => 0 ) ;
function initialize ( ) {
BitsSetTable256 [ 0 ] = 0 ; for ( var i = 0 ; i < 256 ; i ++ ) { BitsSetTable256 [ i ] = ( i & 1 ) + BitsSetTable256 [ parseInt ( i / 2 ) ] ; } }
function countSetBits ( n ) { return ( BitsSetTable256 [ n & 0xff ] + BitsSetTable256 [ ( n >> 8 ) & 0xff ] + BitsSetTable256 [ ( n >> 16 ) & 0xff ] + BitsSetTable256 [ n >> 24 ] ) ; }
initialize ( ) ; var n = 9 ; document . write ( countSetBits ( n ) ) ;
document . write ( ( 4 ) . toString ( 2 ) . split ( ' ' ) . filter ( x => x == ' ' ) . length + " " ) ; document . write ( ( 15 ) . toString ( 2 ) . split ( ' ' ) . filter ( x => x == ' ' ) . length ) ;
function countSetBits ( N ) { var count = 0 ;
for ( i = 0 ; i < 4 * 8 ; i ++ ) { if ( ( N & ( 1 << i ) ) != 0 ) count ++ ; } return count ; }
var N = 15 ; document . write ( countSetBits ( N ) ) ;
function countSetBits ( n ) { var count = 0 ; while ( n != 0 ) { count ++ ; n &= ( n - 1 ) ; } return count ; }
function FlippedCount ( a , b ) {
return countSetBits ( a ^ b ) ; }
var a = 10 ; var b = 20 ; document . write ( FlippedCount ( a , b ) ) ;
function powerOf2 ( n ) {
if ( n == 1 ) return true ;
else if ( n % 2 != 0 n == 0 ) return false ;
return powerOf2 ( n / 2 ) ; }
var n = 64 ;
var m = 12 ; if ( powerOf2 ( n ) == true ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ; if ( powerOf2 ( m ) == true ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ;
function PositionRightmostSetbit ( n ) {
let position = 1 ; let m = 1 ; while ( ( n & m ) == 0 ) {
m = m << 1 ; position ++ ; } return position ; }
let n = 16 ;
document . write ( PositionRightmostSetbit ( n ) ) ;
let INT_SIZE = 32 ; function Right_most_setbit ( num ) { let pos = 1 ;
for ( let i = 0 ; i < INT_SIZE ; i ++ ) { if ( ( num & ( 1 << i ) ) == 0 ) pos ++ ; else break ; } return pos ; }
let num = 18 ; let pos = Right_most_setbit ( num ) ; document . write ( pos ) ;
function Last_set_bit ( n ) { let p = 1 ;
while ( n > 0 ) {
if ( ( n & 1 ) > 0 ) { return p ; }
p ++ ; n = n >> 1 ; }
return - 1 ; }
let n = 18 ;
let pos = Last_set_bit ( n ) ; if ( pos != - 1 ) { document . write ( pos ) ; } else { document . write ( 0 ) ; }
function bin ( n ) { let i ; document . write ( " " ) ; for ( i = 1 << 30 ; i > 0 ; i = Math . floor ( i / 2 ) ) { if ( ( n & i ) != 0 ) { document . write ( " " ) ; } else { document . write ( " " ) ; } } }
bin ( 7 ) ; document . write ( " " ) ; bin ( 4 ) ;
function bin ( n ) { if ( n > 1 ) bin ( n >> 1 ) ; document . write ( n & 1 ) ; }
bin ( 131 ) ; document . write ( " " ) ; bin ( 3 ) ;
function swap ( a , b ) {
a = ( a & b ) + ( a b ) ;
b = a + ( ~ b ) + 1 ;
a = a + ( ~ b ) + 1 ; document . write ( " " + a + " " + b ) ; }
let a = 5 , b = 10 ;
swap ( a , b ) ;
function checkSentence ( str ) {
var len = str . length ;
if ( str [ 0 ] . charCodeAt ( 0 ) < " " . charCodeAt ( 0 ) || str [ 0 ] . charCodeAt ( 0 ) > " " . charCodeAt ( 0 ) ) return false ;
if ( str [ len - 1 ] !== " " ) return false ;
var prev_state = 0 , curr_state = 0 ;
var index = 1 ;
while ( index <= str . length ) {
if ( str [ index ] . charCodeAt ( 0 ) >= " " . charCodeAt ( 0 ) && str [ index ] . charCodeAt ( 0 ) <= " " . charCodeAt ( 0 ) ) curr_state = 0 ;
else if ( str [ index ] === " " ) curr_state = 1 ;
else if ( str [ index ] . charCodeAt ( 0 ) >= " " . charCodeAt ( 0 ) && str [ index ] . charCodeAt ( 0 ) <= " " . charCodeAt ( 0 ) ) curr_state = 2 ;
else if ( str [ index ] === " " ) curr_state = 3 ;
if ( prev_state === curr_state && curr_state !== 2 ) return false ; if ( prev_state === 2 && curr_state === 0 ) return false ;
if ( curr_state === 3 && prev_state !== 1 ) return index + 1 == str . length ; index ++ ;
prev_state = curr_state ; } return false ; }
var str = [ " " , " " , " " , " " , " " , " " , " " , " " , " " , ] ; var str_size = str . length ; var i = 0 ; for ( i = 0 ; i < str_size ; i ++ ) { var temp = str [ i ] . split ( " " ) ; if ( checkSentence ( temp ) ) document . write ( ' ' + str [ i ] + ' ' + " " + " " ) ; else document . write ( ' ' + str [ i ] + ' ' + " " + " " ) ; }
function maxOnesIndex ( arr , n ) {
let max_count = 0 ;
let max_index = 0 ;
let prev_zero = - 1 ;
let prev_prev_zero = - 1 ;
for ( let curr = 0 ; curr < n ; ++ curr ) {
if ( arr [ curr ] == 0 ) {
if ( curr - prev_prev_zero > max_count ) { max_count = curr - prev_prev_zero ; max_index = prev_zero ; }
prev_prev_zero = prev_zero ; prev_zero = curr ; } }
if ( n - prev_prev_zero > max_count ) max_index = prev_zero ; return max_index ; }
let arr = [ 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 ] ; let n = arr . length ; document . write ( " " + maxOnesIndex ( arr , n ) ) ;
function min ( x , y ) { return ( x < y ) ? x : y ; } function max ( x , y ) { return ( x > y ) ? x : y ; }
function findLength ( arr , n ) {
let max_len = 1 ; for ( let i = 0 ; i < n - 1 ; i ++ ) {
let mn = arr [ i ] , mx = arr [ i ] ;
for ( let j = i + 1 ; j < n ; j ++ ) {
mn = min ( mn , arr [ j ] ) ; mx = max ( mx , arr [ j ] ) ;
if ( ( mx - mn ) == j - i ) max_len = Math . max ( max_len , mx - mn + 1 ) ; } }
return max_len ; }
let arr = [ 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 ] ; let n = arr . length ; document . write ( " " + findLength ( arr , n ) ) ;
function printArr ( arr , k ) { for ( let i = 0 ; i < k ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; }
function printSeqUtil ( n , k , len , arr ) {
if ( len == k ) { printArr ( arr , k ) ; return ; }
let i = ( len == 0 ) ? 1 : arr [ len - 1 ] + 1 ;
len ++ ;
while ( i <= n ) { arr [ len - 1 ] = i ; printSeqUtil ( n , k , len , arr ) ; i ++ ; }
len -- ; }
function printSeq ( n , k ) {
let arr = new Array ( k ) ;
let len = 0 ; printSeqUtil ( n , k , len , arr ) ; }
let k = 3 , n = 7 ; printSeq ( n , k ) ;
function isSubSequence ( str1 , str2 , m , n ) {
if ( m == 0 ) return true ; if ( n == 0 ) return false ;
if ( str1 [ m - 1 ] == str2 [ n - 1 ] ) return isSubSequence ( str1 , str2 , m - 1 , n - 1 ) ;
return isSubSequence ( str1 , str2 , m , n - 1 ) ; }
let str1 = " " ; let str2 = " " ; let m = str1 . length ; let n = str2 . length ; let res = isSubSequence ( str1 , str2 , m , n ) ; if ( res ) document . write ( " " ) ; else document . write ( " " ) ;
function segregate0and1 ( arr , n ) {
let count = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 0 ) count ++ ; }
for ( let i = 0 ; i < count ; i ++ ) arr [ i ] = 0 ;
for ( let i = count ; i < n ; i ++ ) arr [ i ] = 1 ; }
function print ( arr , n ) { document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 0 , 1 , 0 , 1 , 1 , 1 ] ; let n = arr . length ; segregate0and1 ( arr , n ) ; print ( arr , n ) ;
function segregate0and1 ( arr , size ) { let type0 = 0 ; let type1 = size - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type1 ] = arr [ type1 ] + arr [ type0 ] ; arr [ type0 ] = arr [ type1 ] - arr [ type0 ] ; arr [ type1 ] = arr [ type1 ] - arr [ type0 ] ; type1 -- ; } else type0 ++ ; } }
let arr = [ 0 , 1 , 0 , 1 , 1 , 1 ] ; let i , arr_size = arr . length ; segregate0and1 ( arr , arr_size ) ; document . write ( " " ) ; for ( i = 0 ; i < arr_size ; i ++ ) document . write ( arr [ i ] + " " ) ;
function find3Numbers ( nums ) {
if ( nums . length < 3 ) { document . write ( " " ) ; return ; }
let seq = 1 ;
let min_num = nums [ 0 ] ;
let max_seq = Number . MIN_VALUE ;
let store_min = min_num ;
for ( let i = 1 ; i < nums . length ; i ++ ) { if ( nums [ i ] == min_num ) continue ; else if ( nums [ i ] < min_num ) { min_num = nums [ i ] ; continue ; }
else if ( nums [ i ] < max_seq ) {
max_seq = nums [ i ] ;
store_min = min_num ; }
else if ( nums [ i ] > max_seq ) { seq ++ ;
if ( seq == 3 ) { document . write ( " " + store_min + " " + max_seq + " " + nums [ i ] ) ; return ; } max_seq = nums [ i ] ; } }
document . write ( " " ) ; }
let nums = [ 1 , 2 , - 1 , 7 , 5 ] ;
find3Numbers ( nums ) ;
function maxSubarrayProduct ( arr , n ) {
let result = arr [ 0 ] ; for ( let i = 0 ; i < n ; i ++ ) { let mul = arr [ i ] ;
for ( let j = i + 1 ; j < n ; j ++ ) {
result = Math . max ( result , mul ) ; mul *= arr [ j ] ; }
result = Math . max ( result , mul ) ; } return result ; }
let arr = [ 1 , - 2 , - 3 , 0 , 7 , - 8 , - 2 ] ; let n = arr . length ; document . write ( " " + maxSubarrayProduct ( arr , n ) ) ;
function maxCircularSum ( a , n ) {
if ( n == 1 ) return a [ 0 ] ;
let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) { sum += a [ i ] ; }
let curr_max = a [ 0 ] , max_so_far = a [ 0 ] , curr_min = a [ 0 ] , min_so_far = a [ 0 ] ;
for ( let i = 1 ; i < n ; i ++ ) {
curr_max = Math . max ( curr_max + a [ i ] , a [ i ] ) ; max_so_far = Math . max ( max_so_far , curr_max ) ;
curr_min = Math . min ( curr_min + a [ i ] , a [ i ] ) ; min_so_far = Math . min ( min_so_far , curr_min ) ; } if ( min_so_far == sum ) return max_so_far ;
return Math . max ( max_so_far , sum - min_so_far ) ; }
let a = [ 11 , 10 , - 20 , 5 , - 3 , - 5 , 8 , - 13 , 10 ] ; let n = a . length ; document . write ( " " + maxCircularSum ( a , n ) ) ;
function GetCeilIndex ( arr , T , l , r , key ) { while ( r - l > 1 ) { let m = l + parseInt ( ( r - l ) / 2 , 10 ) ; if ( arr [ T [ m ] ] >= key ) r = m ; else l = m ; } return r ; } function LongestIncreasingSubsequence ( arr , n ) {
let tailIndices = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) tailIndices [ i ] = 0 ; let prevIndices = new Array ( n ) ;
for ( let i = 0 ; i < n ; i ++ ) prevIndices [ i ] = - 1 ;
let len = 1 ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ tailIndices [ 0 ] ] )
tailIndices [ 0 ] = i ; else if ( arr [ i ] > arr [ tailIndices [ len - 1 ] ] ) {
prevIndices [ i ] = tailIndices [ len - 1 ] ; tailIndices [ len ++ ] = i ; } else {
let pos = GetCeilIndex ( arr , tailIndices , - 1 , len - 1 , arr [ i ] ) ; prevIndices [ i ] = tailIndices [ pos - 1 ] ; tailIndices [ pos ] = i ; } } document . write ( " " + " " ) ; for ( let i = tailIndices [ len - 1 ] ; i >= 0 ; i = prevIndices [ i ] ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; return len ; }
let arr = [ 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 ] ; let n = arr . length ; document . write ( " " + LongestIncreasingSubsequence ( arr , n ) ) ;
function maxSum ( arr , n ) { let sum = 0 ;
arr . sort ( ) ;
for ( let i = 0 ; i < n / 2 ; i ++ ) { sum -= ( 2 * arr [ i ] ) ; sum += ( 2 * arr [ n - i - 1 ] ) ; } return sum ; }
let arr = [ 4 , 2 , 1 , 8 ] ; let n = arr . length ; document . write ( maxSum ( arr , n ) ) ;
function threeWayPartition ( arr , n , lowVal , highVal ) {
let start = 0 , end = n - 1 ;
for ( let i = 0 ; i <= end ; ) {
if ( arr [ i ] < lowVal ) { let temp = arr [ start ] ; arr [ start ] = arr [ i ] ; arr [ i ] = temp ; start ++ ; i ++ ; }
else if ( arr [ i ] > highVal ) { let temp = arr [ end ] ; arr [ end ] = arr [ i ] ; arr [ i ] = temp ; end -- ; } else i ++ ; } }
let arr = [ 1 , 14 , 5 , 20 , 4 , 2 , 54 , 20 , 87 , 98 , 3 , 1 , 32 ] ; let n = arr . length ; threeWayPartition ( arr , n , 10 , 20 ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function generateUtil ( A , B , C , i , j , m , n , len , flag ) {
if ( flag ) {
if ( len != 0 ) printArr ( C , len + 1 ) ;
for ( var k = i ; k < m ; k ++ ) { if ( len == 0 ) {
C [ len ] = A [ k ] ;
generateUtil ( A , B , C , k + 1 , j , m , n , len , ! flag ) ; }
else if ( A [ k ] > C [ len ] ) { C [ len + 1 ] = A [ k ] ; generateUtil ( A , B , C , k + 1 , j , m , n , len + 1 , ! flag ) ; } } }
else { for ( var l = j ; l < n ; l ++ ) { if ( B [ l ] > C [ len ] ) { C [ len + 1 ] = B [ l ] ; generateUtil ( A , B , C , i , l + 1 , m , n , len + 1 , ! flag ) ; } } } }
function generate ( A , B , m , n ) { var C = Array ( m + n ) . fill ( 0 ) ;
generateUtil ( A , B , C , 0 , 0 , m , n , 0 , true ) ; }
function printArr ( arr , n ) { for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; }
var A = [ 10 , 15 , 25 ] ; var B = [ 5 , 20 , 30 ] ; var n = A . length ; var m = B . length ; generate ( A , B , n , m ) ;
function updateindex ( index , a , ai , b , bi ) { index [ a ] = ai ; index [ b ] = bi ; }
function minSwapsUtil ( arr , pairs , index , i , n ) {
if ( i > n ) return 0 ;
if ( pairs [ arr [ i ] ] == arr [ i + 1 ] ) return minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
var one = arr [ i + 1 ] ; var indextwo = i + 1 ; var indexone = index [ pairs [ arr [ i ] ] ] ; var two = arr [ index [ pairs [ arr [ i ] ] ] ] ; arr [ i + 1 ] = arr [ i + 1 ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i + 1 ] ) ; updateindex ( index , one , indexone , two , indextwo ) ; var a = minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
arr [ i + 1 ] = arr [ i + 1 ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i + 1 ] ) ; updateindex ( index , one , indextwo , two , indexone ) ; one = arr [ i ] ; indexone = index [ pairs [ arr [ i + 1 ] ] ] ;
two = arr [ index [ pairs [ arr [ i + 1 ] ] ] ] ; indextwo = i ; arr [ i ] = arr [ i ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i ] ) ; updateindex ( index , one , indexone , two , indextwo ) ; var b = minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
arr [ i ] = arr [ i ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i ] ) ; updateindex ( index , one , indextwo , two , indexone ) ;
return 1 + Math . min ( a , b ) ; }
function minSwaps ( n , pairs , arr ) {
var index = Array ( 2 * n + 1 ) . fill ( 0 ) ;
for ( i = 1 ; i <= 2 * n ; i ++ ) index [ arr [ i ] ] = i ;
return minSwapsUtil ( arr , pairs , index , 1 , 2 * n ) ; }
var arr = [ 0 , 3 , 5 , 6 , 4 , 1 , 2 ] ;
var pairs = [ 0 , 3 , 6 , 1 , 5 , 4 , 2 ] ; var m = pairs . length ;
var n = m / 2 ;
document . write ( " " + minSwaps ( n , pairs , arr ) ) ;
function replace_elements ( arr , n ) {
let pos = 0 ; for ( let i = 0 ; i < n ; i ++ ) { arr [ pos ++ ] = arr [ i ] ; while ( pos > 1 && arr [ pos - 2 ] == arr [ pos - 1 ] ) { pos -- ; arr [ pos - 1 ] ++ ; } }
for ( let i = 0 ; i < pos ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 6 , 4 , 3 , 4 , 3 , 3 , 5 ] ; let n = arr . length replace_elements ( arr , n ) ;
function arrangeString ( str , x , y ) { let count_0 = 0 ; let count_1 = 0 ; let len = str . length ;
for ( let i = 0 ; i < len ; i ++ ) { if ( str [ i ] == ' ' ) count_0 ++ ; else count_1 ++ ; }
while ( count_0 > 0 count_1 > 0 ) { for ( let j = 0 ; j < x && count_0 > 0 ; j ++ ) { if ( count_0 > 0 ) { document . write ( " " ) ; count_0 -- ; } } for ( let j = 0 ; j < y && count_1 > 0 ; j ++ ) { if ( count_1 > 0 ) { document . write ( " " ) ; count_1 -- ; } } } }
let str = " " ; let x = 1 ; let y = 2 ; arrangeString ( str , x , y ) ;
function distinctAdjacentElement ( a , n ) {
let m = new Map ( ) ;
for ( let i = 0 ; i < n ; ++ i ) { m [ a [ i ] ] ++ ; if ( m . has ( a [ i ] ) ) { m . set ( a [ i ] , m . get ( a [ i ] ) + 1 ) } else { m . set ( a [ i ] , 1 ) } }
let mx = 0 ;
for ( let i = 0 ; i < n ; ++ i ) if ( mx < m . get ( a [ i ] ) ) mx = m . get ( a [ i ] ) ;
if ( mx > Math . floor ( ( n + 1 ) / 2 ) ) document . write ( " " + " " ) ; else document . write ( " " ) ; }
let a = [ 7 , 7 , 7 , 7 ] ; let n = a . length ; distinctAdjacentElement ( a , n ) ;
function rearrange ( arr , n ) {
if ( arr == null n % 2 == 1 ) return ;
let currIdx = Math . floor ( ( n - 1 ) / 2 ) ;
while ( currIdx > 0 ) { let count = currIdx , swapIdx = currIdx ; while ( count -- > 0 ) { let temp = arr [ swapIdx + 1 ] ; arr [ swapIdx + 1 ] = arr [ swapIdx ] ; arr [ swapIdx ] = temp ; swapIdx ++ ; } currIdx -- ; } }
let arr = [ 1 , 3 , 5 , 2 , 4 , 6 ] ; let n = arr . length ; rearrange ( arr , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( " " + arr [ i ] ) ;
function maxDiff ( arr , n ) {
let maxDiff = - 1 ;
let maxRight = arr [ n - 1 ] ; for ( let i = n - 2 ; i >= 0 ; i -- ) { if ( arr [ i ] > maxRight ) maxRight = arr [ i ] ; else { let diff = maxRight - arr [ i ] ; if ( diff > maxDiff ) { maxDiff = diff ; } } } return maxDiff ; }
let arr = [ 1 , 2 , 90 , 10 , 110 ] ; let n = arr . length ;
document . write ( " " + maxDiff ( arr , n ) ) ;
function maxDiff ( arr , n ) {
let diff = arr [ 1 ] - arr [ 0 ] ; let curr_sum = diff ; let max_sum = curr_sum ; for ( let i = 1 ; i < n - 1 ; i ++ ) {
diff = arr [ i + 1 ] - arr [ i ] ;
if ( curr_sum > 0 ) curr_sum += diff ; else curr_sum = diff ;
if ( curr_sum > max_sum ) max_sum = curr_sum ; } return max_sum ; }
let arr = [ 80 , 2 , 6 , 3 , 100 ] ; let n = arr . length ;
document . write ( " " + maxDiff ( arr , n ) ) ;
let v = [ 34 , 8 , 10 , 3 , 2 , 80 , 30 , 33 , 1 ] ; let n = v . length ; let maxFromEnd = new Array ( n + 1 ) ; for ( let i = 0 ; i < maxFromEnd . length ; i ++ ) maxFromEnd [ i ] = Number . MIN_VALUE ;
for ( let i = v . length - 1 ; i >= 0 ; i -- ) { maxFromEnd [ i ] = Math . max ( maxFromEnd [ i + 1 ] , v [ i ] ) ; } let result = 0 ; for ( let i = 0 ; i < v . length ; i ++ ) { let low = i + 1 , high = v . length - 1 , ans = i ; while ( low <= high ) { let mid = parseInt ( ( low + high ) / 2 , 10 ) ; if ( v [ i ] <= maxFromEnd [ mid ] ) {
ans = Math . max ( ans , mid ) ; low = mid + 1 ; } else { high = mid - 1 ; } }
result = Math . max ( result , ans - i ) ; } document . write ( result ) ;
function getPostOrderBST ( pre , N ) { var pivotPoint = 0 ;
for ( var i = 1 ; i < N ; i ++ ) { if ( pre [ 0 ] <= pre [ i ] ) { pivotPoint = i ; break ; } }
for ( var i = pivotPoint - 1 ; i > 0 ; i -- ) { document . write ( pre [ i ] + " " ) ; }
for ( var i = N - 1 ; i >= pivotPoint ; i -- ) { document . write ( pre [ i ] + " " ) ; } document . write ( pre [ 0 ] ) ; }
function constructLowerArray ( arr , countSmaller , n ) { let i , j ;
for ( i = 0 ; i < n ; i ++ ) countSmaller [ i ] = 0 ; for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < arr [ i ] ) countSmaller [ i ] ++ ; } } }
function printArray ( arr , size ) { let i ; for ( i = 0 ; i < size ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; }
let arr = [ 12 , 10 , 5 , 4 , 2 , 20 , 6 , 1 , 0 , 2 ] ; let n = arr . length ; let low = new Array ( n ) ; constructLowerArray ( arr , low , n ) ; printArray ( low , n ) ;
function segregate ( arr , size ) { let j = 0 , i ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] <= 0 ) { let temp ; temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ;
j ++ ; } } return j ; }
function findMissingPositive ( arr , size ) { let i ;
for ( i = 0 ; i < size ; i ++ ) { let x = Math . abs ( arr [ i ] ) ; if ( x - 1 < size && arr [ x - 1 ] > 0 ) arr [ x - 1 ] = - arr [ x - 1 ] ; }
for ( i = 0 ; i < size ; i ++ ) if ( arr [ i ] > 0 )
return i + 1 ; return size + 1 ; }
function findMissing ( arr , size ) {
let shift = segregate ( arr , size ) ; let arr2 = new Array ( size - shift ) ; let j = 0 ; for ( let i = shift ; i < size ; i ++ ) { arr2 [ j ] = arr [ i ] ; j ++ ; }
return findMissingPositive ( arr2 , j ) ; }
let arr = [ 0 , 10 , 2 , - 10 , - 20 ] ; let arr_size = arr . length ; let missing = findMissing ( arr , arr_size ) ; document . write ( " " + missing ) ;
function fillDepth ( parent , i , depth ) {
if ( depth [ i ] != 0 ) { return ; }
if ( parent [ i ] == - 1 ) { depth [ i ] = 1 ; return ; }
if ( depth [ parent [ i ] ] == 0 ) { fillDepth ( parent , parent [ i ] , depth ) ; }
depth [ i ] = depth [ parent [ i ] ] + 1 ; }
function findHeight ( parent , n ) {
var depth = Array ( n ) . fill ( 0 ) ; for ( i = 0 ; i < n ; i ++ ) { depth [ i ] = 0 ; }
for ( i = 0 ; i < n ; i ++ ) { fillDepth ( parent , i , depth ) ; }
var ht = depth [ 0 ] ; for ( i = 1 ; i < n ; i ++ ) { if ( ht < depth [ i ] ) { ht = depth [ i ] ; } } return ht ; }
var parent = [ - 1 , 0 , 0 , 1 , 1 , 3 , 5 ] ; var n = parent . length ; document . write ( " " + findHeight ( parent , n ) ) ;
function maxRepeating ( arr , n , k ) {
for ( let i = 0 ; i < n ; i ++ ) arr [ arr [ i ] % k ] += k ;
let max = arr [ 0 ] , result = 0 ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; result = i ; } }
return result ; }
let arr = [ 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 ] ; let n = arr . length ; let k = 8 ; document . write ( " " + maxRepeating ( arr , n , k ) + " " ) ;
function maxPathSum ( ar1 , ar2 , m , n ) {
let i = 0 , j = 0 ;
let result = 0 , sum1 = 0 , sum2 = 0 ;
while ( i < m && j < n ) {
if ( ar1 [ i ] < ar2 [ j ] ) sum1 += ar1 [ i ++ ] ;
else if ( ar1 [ i ] > ar2 [ j ] ) sum2 += ar2 [ j ++ ] ;
else {
result += Math . max ( sum1 , sum2 ) + ar1 [ i ] ;
sum1 = 0 ; sum2 = 0 ;
i ++ ; j ++ ; } }
while ( i < m ) sum1 += ar1 [ i ++ ] ;
while ( j < n ) sum2 += ar2 [ j ++ ] ;
result += Math . max ( sum1 , sum2 ) ; return result ; }
let ar1 = [ 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 ] ; let ar2 = [ 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 ] ; let m = ar1 . length ; let n = ar2 . length ;
document . write ( " " + maxPathSum ( ar1 , ar2 , m , n ) ) ;
function smallestGreater ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) {
let diff = Number . MAX_VALUE ; let closest = - 1 ; for ( let j = 0 ; j < n ; j ++ ) { if ( arr [ i ] < arr [ j ] && arr [ j ] - arr [ i ] < diff ) { diff = arr [ j ] - arr [ i ] ; closest = j ; } }
if ( closest == - 1 ) document . write ( " " ) ; else document . write ( arr [ closest ] + " " ) ; } }
let ar = [ 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 ] ; let n = ar . length ; smallestGreater ( ar , n ) ;
function smallestGreater ( arr , n ) { let s = new Set ( ) ; for ( let i = 0 ; i < n ; i ++ ) s . add ( arr [ i ] ) ; let newAr = [ ] ; for ( let p of s . values ( ) ) { newAr . push ( p ) ; } newAr . sort ( function ( a , b ) { return a - b ; } ) ; for ( let i = 0 ; i < n ; i ++ ) { let temp = lowerBound ( newAr , 0 , newAr . length , arr [ i ] ) ; if ( temp < n ) document . write ( newAr [ temp ] + " " ) ; else document . write ( " " ) ; } }
function lowerBound ( vec , low , high , element ) { let array = [ ... vec ] ; while ( low < high ) { let middle = Math . floor ( low + ( high - low ) / 2 ) ; if ( element > array [ middle ] ) { low = middle + 1 ; } else { high = middle ; } } return low + 1 ; }
let ar = [ 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 ] ; let n = ar . length ; smallestGreater ( ar , n ) ;
function findZeroes ( arr , n , m ) {
let wL = 0 ; let wR = 0 ;
let bestL = 0 ; let bestWindow = 0 ;
let zeroCount = 0 ;
while ( wR < n ) {
if ( zeroCount <= m ) { if ( arr [ wR ] == 0 ) zeroCount ++ ; wR ++ ; }
if ( zeroCount > m ) { if ( arr [ wL ] == 0 ) zeroCount -- ; wL ++ ; }
if ( ( wR - wL > bestWindow ) && ( zeroCount <= m ) ) { bestWindow = wR - wL ; bestL = wL ; } }
for ( let i = 0 ; i < bestWindow ; i ++ ) { if ( arr [ bestL + i ] == 0 ) document . write ( bestL + i + " " ) ; } }
let arr = new Array ( 1 , 0 , 0 , 1 , 1 , 0 , 1 , 0 , 1 , 1 ) ; let m = 2 ; let n = arr . length ; document . write ( " " ) ; findZeroes ( arr , n , m ) ;
function countIncreasing ( arr , n ) {
let cnt = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
for ( let j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] > arr [ j - 1 ] ) cnt ++ ;
else break ; } } return cnt ; }
let arr = [ 1 , 2 , 2 , 4 ] ; let n = arr . length ; document . write ( " " + " " + countIncreasing ( arr , n ) ) ;
let arr = [ 1 , 2 , 2 , 4 ] ; function countIncreasing ( n ) {
let cnt = 0 ;
let len = 1 ;
for ( let i = 0 ; i < n - 1 ; ++ i ) {
if ( arr [ i + 1 ] > arr [ i ] ) len ++ ;
else { cnt += ( ( ( len - 1 ) * len ) / 2 ) ; len = 1 ; } }
if ( len > 1 ) cnt += ( ( ( len - 1 ) * len ) / 2 ) ; return cnt ; }
document . write ( " " + " " + countIncreasing ( arr . length ) ) ;
function arraySum ( arr , n ) { var sum = 0 ; for ( var i = 0 ; i < n ; i ++ ) sum = sum + arr [ i ] ; return sum ; }
function maxDiff ( arr , n , k ) {
arr . sort ( ( a , b ) => a - b ) ;
var arraysum = arraySum ( arr , n ) ;
var diff1 = Math . abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
arr . reverse ( ) ;
var diff2 = Math . abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
return ( Math . max ( diff1 , diff2 ) ) ; }
var arr = [ 1 , 7 , 4 , 8 , - 1 , 5 , 2 , 1 ] ; var n = arr . length ; var k = 3 ; document . write ( " " + maxDiff ( arr , n , k ) ) ;
function minNumber ( a , n , x ) {
a . sort ( ) ; let k ; for ( k = 0 ; a [ parseInt ( ( n - 1 ) / 2 , 10 ) ] != x ; k ++ ) { a [ n ++ ] = x ; a . sort ( ) ; } return k ; }
let x = 10 ; let a = [ 10 , 20 , 30 ] ; let n = 3 ; document . write ( minNumber ( a , n , x ) ) ;
function minNumber ( a , n , x ) { let l = 0 , h = 0 , e = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == x ) e ++ ;
else if ( a [ i ] > x ) h ++ ;
else if ( a [ i ] < x ) l ++ ; } let ans = 0 ; if ( l > h ) ans = l - h ; else if ( l < h ) ans = h - l - 1 ;
return ans + 1 - e ; }
let x = 10 ; let a = [ 10 , 20 , 30 ] ; let n = a . length ; document . write ( minNumber ( a , n , x ) ) ;
function fun ( x ) { let y = parseInt ( x / 4 ) * 4 ;
let ans = 0 ; for ( let i = y ; i <= x ; i ++ ) ans ^= i ; return ans ; }
function query ( x ) {
if ( x == 0 ) return 0 ; let k = parseInt ( ( x + 1 ) / 2 ) ;
return ( x %= 2 ) ? 2 * fun ( k ) : ( ( fun ( k - 1 ) * 2 ) ^ ( k & 1 ) ) ; } function allQueries ( q , l , r ) { for ( let i = 0 ; i < q ; i ++ ) document . write ( ( query ( r [ i ] ) ^ query ( l [ i ] - 1 ) ) + " " ) ; }
let q = 3 ; let l = [ 2 , 2 , 5 ] ; let r = [ 4 , 8 , 9 ] ; allQueries ( q , l , r ) ;
function preprocess ( arr , N , left , right ) {
left [ 0 ] = 0 ; let lastIncr = 0 ; for ( let i = 1 ; i < N ; i ++ ) {
if ( arr [ i ] > arr [ i - 1 ] ) lastIncr = i ; left [ i ] = lastIncr ; }
right [ N - 1 ] = N - 1 ; let firstDecr = N - 1 ; for ( let i = N - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] > arr [ i + 1 ] ) firstDecr = i ; right [ i ] = firstDecr ; } }
function isSubarrayMountainForm ( arr , left , right , L , R ) {
return ( right [ L ] >= left [ R ] ) ; }
let arr = [ 2 , 3 , 2 , 4 , 4 , 6 , 3 , 2 ] ; let N = arr . length ; let left = new Array ( N ) ; let right = new Array ( N ) ; preprocess ( arr , N , left , right ) ; let L = 0 ; let R = 2 ; if ( isSubarrayMountainForm ( arr , left , right , L , R ) ) document . write ( " " + " " + " " ) ; else document . write ( " " + " " + " " ) ; L = 1 ; R = 3 ; if ( isSubarrayMountainForm ( arr , left , right , L , R ) ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ;
let MAX = 1000 ; function sieveOfEratosthenes ( isPrime ) { isPrime [ 1 ] = false ; for ( let p = 2 ; p * p <= MAX ; p ++ ) {
if ( isPrime [ p ] == true ) {
for ( let i = p * 2 ; i <= MAX ; i += p ) isPrime [ i ] = false ; } } }
function getMid ( s , e ) { return Math . floor ( s + ( e - s ) / 2 ) ; }
function queryPrimesUtil ( st , ss , se , qs , qe , index ) {
if ( qs <= ss && qe >= se ) return st [ index ] ;
if ( se < qs ss > qe ) return 0 ;
let mid = getMid ( ss , se ) ; return queryPrimesUtil ( st , ss , mid , qs , qe , 2 * index + 1 ) + queryPrimesUtil ( st , mid + 1 , se , qs , qe , 2 * index + 2 ) ; }
function updateValueUtil ( st , ss , se , i , diff , si ) {
if ( i < ss i > se ) return ;
st [ si ] = st [ si ] + diff ; if ( se != ss ) { let mid = getMid ( ss , se ) ; updateValueUtil ( st , ss , mid , i , diff , 2 * si + 1 ) ; updateValueUtil ( st , mid + 1 , se , i , diff , 2 * si + 2 ) ; } }
function updateValue ( arr , st , n , i , new_val , isPrime ) {
if ( i < 0 i > n - 1 ) { document . write ( " " ) ; return ; } let diff = 0 ; let oldValue ; oldValue = arr [ i ] ;
arr [ i ] = new_val ;
if ( isPrime [ oldValue ] && isPrime [ new_val ] ) return ;
if ( ( ! isPrime [ oldValue ] ) && ( ! isPrime [ new_val ] ) ) return ;
if ( isPrime [ oldValue ] && ! isPrime [ new_val ] ) { diff = - 1 ; }
if ( ! isPrime [ oldValue ] && isPrime [ new_val ] ) { diff = 1 ; }
updateValueUtil ( st , 0 , n - 1 , i , diff , 0 ) ; }
function queryPrimes ( st , n , qs , qe ) { let primesInRange = queryPrimesUtil ( st , 0 , n - 1 , qs , qe , 0 ) ; document . write ( " " + qs + " " + qe + " " + primesInRange + " " ) ; }
function constructSTUtil ( arr , ss , se , st , si , isPrime ) {
if ( ss == se ) {
if ( isPrime [ arr [ ss ] ] ) st [ si ] = 1 ; else st [ si ] = 0 ; return st [ si ] ; }
let mid = getMid ( ss , se ) ; st [ si ] = constructSTUtil ( arr , ss , mid , st , si * 2 + 1 , isPrime ) + constructSTUtil ( arr , mid + 1 , se , st , si * 2 + 2 , isPrime ) ; return st [ si ] ; }
function constructST ( arr , n , isPrime ) {
let x = ( Math . ceil ( Math . log ( n ) / Math . log ( 2 ) ) ) ;
let max_size = 2 * Math . pow ( 2 , x ) - 1 ; let st = new Array ( max_size ) ;
constructSTUtil ( arr , 0 , n - 1 , st , 0 , isPrime ) ;
return st ; }
let arr = [ 1 , 2 , 3 , 5 , 7 , 9 ] ; let n = arr . length ;
let isPrime = new Array ( MAX + 1 ) ; isPrime . fill ( true ) ; sieveOfEratosthenes ( isPrime ) ;
let st = constructST ( arr , n , isPrime ) ;
let start = 0 ; let end = 4 ; queryPrimes ( st , n , start , end ) ;
let i = 3 ; let x = 6 ; updateValue ( arr , st , n , i , x , isPrime ) ;
start = 0 ; end = 4 ; queryPrimes ( st , n , start , end ) ;
function checkEVENodd ( arr , n , l , r ) {
if ( arr [ r ] == 1 ) document . write ( " " ) ;
else document . write ( " " ) ; }
let arr = [ 1 , 1 , 0 , 1 ] ; let n = arr . length ; checkEVENodd ( arr , n , 1 , 3 ) ;
function findMean ( arr , l , r ) {
let sum = 0 , count = 0 ;
for ( let i = l ; i <= r ; i ++ ) { sum += arr [ i ] ; count ++ ; }
let mean = Math . floor ( sum / count ) ;
return mean ; }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ; document . write ( findMean ( arr , 0 , 2 ) + " " ) ; document . write ( findMean ( arr , 1 , 3 ) + " " ) ; document . write ( findMean ( arr , 0 , 4 ) + " " ) ;
let MAX = 1000005 ; let prefixSum = new Array ( MAX ) ; prefixSum . fill ( 0 ) ;
function calculatePrefixSum ( arr , n ) {
prefixSum [ 0 ] = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) prefixSum [ i ] = prefixSum [ i - 1 ] + arr [ i ] ; }
function findMean ( l , r ) { if ( l == 0 ) return parseInt ( Math . floor ( prefixSum [ r ] / ( r + 1 ) ) , 10 ) ;
return parseInt ( Math . floor ( ( prefixSum [ r ] - prefixSum [ l - 1 ] ) / ( r - l + 1 ) ) , 10 ) ; }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ; let n = arr . length ; calculatePrefixSum ( arr , n ) ; document . write ( findMean ( 1 , 2 ) + " " ) ; document . write ( findMean ( 1 , 3 ) + " " ) ; document . write ( findMean ( 1 , 4 ) + " " ) ;
function updateQuery ( arr , n , q , l , r , k ) {
if ( q == 0 ) { arr [ l - 1 ] += k ; arr [ r ] += - k ; }
else { arr [ l - 1 ] += - k ; arr [ r ] += k ; } return ; }
function generateArray ( arr , n ) {
for ( i = 1 ; i < n ; ++ i ) arr [ i ] += arr [ i - 1 ] ; }
var n = 5 ; var arr = Array ( n + 1 ) . fill ( 0 ) ; var q = 0 , l = 1 , r = 3 , k = 2 ; updateQuery ( arr , n , q , l , r , k ) ; q = 1 ; l = 3 ; r = 5 ; k = 3 ; updateQuery ( arr , n , q , l , r , k ) ; q = 0 ; l = 2 ; r = 5 ; k = 1 ; updateQuery ( arr , n , q , l , r , k ) ;
generateArray ( arr , n ) ;
for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function calculateProduct ( A , L , R , P ) {
L = L - 1 ; R = R - 1 ; let ans = 1 ; for ( let i = L ; i <= R ; i ++ ) { ans = ans * A [ i ] ; ans = ans % P ; } return ans ; }
let A = [ 1 , 2 , 3 , 4 , 5 , 6 ] ; let P = 229 ; let L = 2 , R = 5 ; document . write ( calculateProduct ( A , L , R , P ) + " " ) ; L = 1 ; R = 3 ; document . write ( calculateProduct ( A , L , R , P ) + " " ) ;
function modInverse ( a , m ) { let m0 = m , t , q ; let x0 = 0 , x1 = 1 ; if ( m == 1 ) return 0 ; while ( a > 1 ) {
q = parseInt ( a / m , 10 ) ; t = m ;
m = a % m ; a = t ; t = x0 ; x0 = x1 - q * x0 ; x1 = t ; }
if ( x1 < 0 ) x1 += m0 ; return x1 ; }
function calculate_Pre_Product ( A , N , P ) { pre_product [ 0 ] = A [ 0 ] ; for ( let i = 1 ; i < N ; i ++ ) { pre_product [ i ] = pre_product [ i - 1 ] * A [ i ] ; pre_product [ i ] = pre_product [ i ] % P ; } }
function calculate_inverse_product ( A , N , P ) { inverse_product [ 0 ] = modInverse ( pre_product [ 0 ] , P ) ; for ( let i = 1 ; i < N ; i ++ ) inverse_product [ i ] = modInverse ( pre_product [ i ] , P ) ; }
function calculateProduct ( A , L , R , P ) {
L = L - 1 ; R = R - 1 ; let ans ; if ( L == 0 ) ans = pre_product [ R ] ; else ans = pre_product [ R ] * inverse_product [ L - 1 ] ; return ans ; }
let A = [ 1 , 2 , 3 , 4 , 5 , 6 ] ;
let P = 113 ;
calculate_Pre_Product ( A , A . length , P ) ; calculate_inverse_product ( A , A . length , P ) ;
let L = 2 , R = 5 ; document . write ( calculateProduct ( A , L , R , P ) + " " ) ; L = 1 ; R = 3 ; document . write ( calculateProduct ( A , L , R , P ) ) ;
let MAX = 10000 ;
let prefix = [ ] ; function buildPrefix ( ) {
let prime = [ ] ; for ( let p = 1 ; p <= MAX + 1 ; p ++ ) { prime [ p ] = true ; } for ( let p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == true ) {
for ( let i = p * 2 ; i <= MAX ; i += p ) prime [ i ] = false ; } }
prefix [ 0 ] = prefix [ 1 ] = 0 ; for ( let p = 2 ; p <= MAX ; p ++ ) { prefix [ p ] = prefix [ p - 1 ] ; if ( prime [ p ] ) prefix [ p ] ++ ; } }
function query ( L , R ) { return prefix [ R ] - prefix [ L - 1 ] ; }
buildPrefix ( ) ; let L = 5 , R = 10 ; document . write ( query ( L , R ) + " " ) ; L = 1 ; R = 10 ; document . write ( query ( L , R ) ) ;
function command ( arr , a , b ) { arr [ a ] ^= 1 ; arr [ b + 1 ] ^= 1 ; }
function process ( arr , n ) { for ( var k = 1 ; k <= n ; k ++ ) arr [ k ] ^= arr [ k - 1 ] ; }
function result ( arr , n ) { for ( var k = 1 ; k <= n ; k ++ ) document . write ( arr [ k ] + " " ) ; }
var n = 5 , m = 3 ; var arr = Array ( n + 2 ) . fill ( 0 ) ;
command ( arr , 1 , 5 ) ; command ( arr , 2 , 5 ) ; command ( arr , 3 , 5 ) ;
process ( arr , n ) ;
result ( arr , n ) ;
function incrementByD ( arr , q_arr , n , m , d ) { let sum = new Array ( n ) ; for ( let i = 0 ; i < sum . length ; i ++ ) { sum [ i ] = 0 ; }
for ( let i = 0 ; i < m ; i ++ ) {
sum [ q_arr [ i ] . start ] += d ;
if ( ( q_arr [ i ] . end + 1 ) < n ) sum [ q_arr [ i ] . end + 1 ] -= d ; }
arr [ 0 ] += sum [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) { sum [ i ] += sum [ i - 1 ] ; arr [ i ] += sum [ i ] ; } }
function printArray ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 3 , 5 , 4 , 8 , 6 , 1 ] ; let q_arr = new Array ( 5 ) ; q_arr [ 0 ] = new query ( 0 , 3 ) ; q_arr [ 1 ] = new query ( 4 , 5 ) ; q_arr [ 2 ] = new query ( 1 , 4 ) ; q_arr [ 3 ] = new query ( 0 , 1 ) ; q_arr [ 4 ] = new query ( 2 , 5 ) ; let n = arr . length ; let m = q_arr . length ; let d = 2 ; document . write ( " " ) ; printArray ( arr , n ) ;
incrementByD ( arr , q_arr , n , m , d ) ; document . write ( " " ) ; printArray ( arr , n ) ;
function prefixXOR ( arr , preXOR , n ) {
for ( let i = 0 ; i < n ; i ++ ) { while ( arr [ i ] % 2 != 1 ) arr [ i ] = parseInt ( arr [ i ] / 2 ) ; preXOR [ i ] = arr [ i ] ; }
for ( let i = 1 ; i < n ; i ++ ) preXOR [ i ] = preXOR [ i - 1 ] ^ preXOR [ i ] ; }
function query ( preXOR , l , r ) { if ( l == 0 ) return preXOR [ r ] ; else return preXOR [ r ] ^ preXOR [ l - 1 ] ; }
let arr = [ 3 , 4 , 5 ] ; let n = arr . length ; let preXOR = new Array ( n ) ; prefixXOR ( arr , preXOR , n ) ; document . write ( query ( preXOR , 0 , 2 ) + " " ) ; document . write ( query ( preXOR , 1 , 2 ) + " " ) ;
let MAX = 100000 ;
let tree = new Array ( MAX ) ;
let lazy = new Array ( MAX ) ; for ( let i = 0 ; i < MAX ; i ++ ) { tree [ i ] = 0 ; lazy [ i ] = false ; }
function toggle ( node , st , en , us , ue ) {
if ( lazy [ node ] ) {
lazy [ node ] = false ; tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ 1 + ( node << 1 ) ] = ! lazy [ 1 + ( node << 1 ) ] ; } }
if ( st > en us > en ue < st ) { return ; }
if ( us <= st && en <= ue ) {
tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ 1 + ( node << 1 ) ] = ! lazy [ 1 + ( node << 1 ) ] ; } return ; }
let mid = Math . floor ( ( st + en ) / 2 ) ; toggle ( ( node << 1 ) , st , mid , us , ue ) ; toggle ( ( node << 1 ) + 1 , mid + 1 , en , us , ue ) ;
if ( st < en ) { tree [ node ] = tree [ node << 1 ] + tree [ ( node << 1 ) + 1 ] ; } }
function countQuery ( node , st , en , qs , qe ) {
if ( st > en qs > en qe < st ) { return 0 ; }
if ( lazy [ node ] ) {
lazy [ node ] = false ; tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ ( node << 1 ) + 1 ] = ! lazy [ ( node << 1 ) + 1 ] ; } }
if ( qs <= st && en <= qe ) { return tree [ node ] ; }
let mid = Math . floor ( ( st + en ) / 2 ) ; return countQuery ( ( node << 1 ) , st , mid , qs , qe ) + countQuery ( ( node << 1 ) + 1 , mid + 1 , en , qs , qe ) ; }
let n = 5 ;
toggle ( 1 , 0 , n - 1 , 1 , 2 ) ;
toggle ( 1 , 0 , n - 1 , 2 , 4 ) ;
document . write ( countQuery ( 1 , 0 , n - 1 , 2 , 3 ) + " " ) ;
toggle ( 1 , 0 , n - 1 , 2 , 4 ) ;
document . write ( countQuery ( 1 , 0 , n - 1 , 1 , 4 ) + " " ) ;
function probability ( a , b , size1 , size2 ) {
let max1 = Number . MIN_VALUE , count1 = 0 ; for ( let i = 0 ; i < size1 ; i ++ ) { if ( a [ i ] > max1 ) { max1 = a [ i ] ; count1 = 1 ; } else if ( a [ i ] == max1 ) { count1 ++ ; } }
let max2 = Number . MIN_VALUE , count2 = 0 ; for ( let i = 0 ; i < size2 ; i ++ ) { if ( b [ i ] > max2 ) { max2 = b [ i ] ; count2 = 1 ; } else if ( b [ i ] == max2 ) { count2 ++ ; } }
return ( count1 * count2 ) / ( size1 * size2 ) ; }
let a = [ 1 , 2 , 3 ] ; let b = [ 1 , 3 , 3 ] ; let size1 = a . length ; let size2 = b . length ; document . write ( probability ( a , b , size1 , size2 ) ) ;
function countDe ( arr , n ) { let v = [ ] ;
for ( let i = 0 ; i < n ; i ++ ) v [ i ] = arr [ i ] ;
arr . sort ( ) ;
let count1 = 0 ; for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count1 ++ ;
arr . reverse ( ) ;
let count2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count2 ++ ;
return ( Math . min ( count1 , count2 ) ) ; }
let arr = [ 5 , 9 , 21 , 17 , 13 ] ; let n = 5 ; document . write ( " " + countDe ( arr , n ) ) ;
function maxOfSegmentMins ( a , n , k ) {
if ( k == 1 ) { a . sort ( ) ; return a [ 0 ] ; } if ( k == 2 ) return Math . max ( a [ 0 ] , a [ n - 1 ] ) ;
return a [ n - 1 ] ; }
var a = [ - 10 , - 9 , - 8 , 2 , 7 , - 6 , - 5 ] ; var n = a . length ; var k = 2 ; document . write ( maxOfSegmentMins ( a , n , k ) ) ;
function printMinimumProduct ( arr , n ) {
let first_min = Math . min ( arr [ 0 ] , arr [ 1 ] ) ; let second_min = Math . max ( arr [ 0 ] , arr [ 1 ] ) ;
for ( let i = 2 ; i < n ; i ++ ) { if ( arr [ i ] < first_min ) { second_min = first_min ; first_min = arr [ i ] ; } else if ( arr [ i ] < second_min ) second_min = arr [ i ] ; } return first_min * second_min ; }
let a = [ 11 , 8 , 5 , 7 , 5 , 100 ] ; let n = a . length ; document . write ( printMinimumProduct ( a , n ) ) ;
function noOfTriples ( arr , n ) {
arr . sort ( ) ;
let count = 0 ; for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] == arr [ 2 ] ) count ++ ;
if ( arr [ 0 ] == arr [ 2 ] ) return ( count - 2 ) * ( count - 1 ) * ( count ) / 6 ;
else if ( arr [ 1 ] == arr [ 2 ] ) return ( count - 1 ) * ( count ) / 2 ;
return count ; }
let arr = [ 1 , 3 , 3 , 4 ] ; let n = arr . length ; document . write ( noOfTriples ( arr , n ) ) ;
function checkReverse ( arr , n ) {
let temp = [ ] ; for ( let i = 0 ; i < n ; i ++ ) { temp [ i ] = arr [ i ] ; }
temp . sort ( ) ;
let front ; for ( front = 0 ; front < n ; front ++ ) { if ( temp [ front ] != arr [ front ] ) { break ; } }
let back ; for ( back = n - 1 ; back >= 0 ; back -- ) { if ( temp [ back ] != arr [ back ] ) { break ; } }
if ( front >= back ) { return true ; }
do { front ++ ; if ( arr [ front - 1 ] < arr [ front ] ) { return false ; } } while ( front != back ) ; return true ; }
let arr = [ 1 , 2 , 5 , 4 , 3 ] ; let n = arr . length ; if ( checkReverse ( arr , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function checkReverse ( arr , n ) { if ( n == 1 ) return true ;
let i ; for ( i = 1 ; i < n && arr [ i - 1 ] < arr [ i ] ; i ++ ) ; if ( i == n ) return true ;
let j = i ; while ( j < n && arr [ j ] < arr [ j - 1 ] ) { if ( i > 1 && arr [ j ] < arr [ i - 2 ] ) return false ; j ++ ; } if ( j == n ) return true ;
let k = j ;
if ( arr [ k ] < arr [ i - 1 ] ) return false ; while ( k > 1 && k < n ) { if ( arr [ k ] < arr [ k - 1 ] ) return false ; k ++ ; } return true ; }
let arr = [ 1 , 3 , 4 , 10 , 9 , 8 ] ; let n = arr . length ; if ( checkReverse ( arr , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function MinOperation ( a , b , n ) {
a . sort ( function ( a , b ) { return a - b } ) ; b . sort ( function ( a , b ) { return a - b } ) ;
let result = 0 ;
for ( let i = 0 ; i < n ; ++ i ) { if ( a [ i ] > b [ i ] ) result = result + Math . abs ( a [ i ] - b [ i ] ) ; else if ( a [ i ] < b [ i ] ) result = result + Math . abs ( a [ i ] - b [ i ] ) ; } return result ; }
let a = [ 3 , 1 , 1 ] ; let b = [ 1 , 2 , 2 ] ; let n = a . length ; document . write ( MinOperation ( a , b , n ) ) ;
function sortExceptUandL ( a , l , u , n ) {
let b = [ ] ; for ( let i = 0 ; i < l ; i ++ ) b [ i ] = a [ i ] ; for ( let i = u + 1 ; i < n ; i ++ ) b [ l + ( i - ( u + 1 ) ) ] = a [ i ] ;
b . sort ( ) ;
for ( let i = 0 ; i < l ; i ++ ) a [ i ] = b [ i ] ; for ( let i = u + 1 ; i < n ; i ++ ) a [ i ] = b [ l + ( i - ( u + 1 ) ) ] ; }
let a = [ 5 , 4 , 3 , 12 , 14 , 9 ] ; let n = a . length ; let l = 2 , u = 4 ; sortExceptUandL ( a , l , u , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( a [ i ] + " " ) ;
function sortExceptK ( arr , k , n ) {
let temp = arr [ k ] ; arr [ k ] = arr [ n - 1 ] ; arr [ n - 1 ] = temp ;
arr . sort ( function ( a , b ) { return a - b } ) ;
let last = arr [ n - 1 ] ;
for ( let i = n - 1 ; i > k ; i -- ) arr [ i ] = arr [ i - 1 ] ;
arr [ k ] = last ;
temp = arr [ k ] ; arr [ k ] = arr [ n - 1 ] ; arr [ n - 1 ] = temp ; return 0 ; } let a = [ 10 , 4 , 11 , 7 , 6 , 20 ] ; let k = 2 ; let n = a . length ; sortExceptK ( a , k , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( a [ i ] + " " ) ;
function findMinSwaps ( arr , n ) {
let noOfZeroes = [ ] ; let i , count = 0 ;
noOfZeroes [ n - 1 ] = 1 - arr [ n - 1 ] ; for ( i = n - 2 ; i >= 0 ; i -- ) { noOfZeroes [ i ] = noOfZeroes [ i + 1 ] ; if ( arr [ i ] == 0 ) noOfZeroes [ i ] ++ ; }
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 1 ) count += noOfZeroes [ i ] ; } return count ; }
let ar = [ 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 ] ; document . write ( findMinSwaps ( ar , ar . length ) ) ;
function minswaps ( arr , n ) { var count = 0 ; var num_unplaced_zeros = 0 ; for ( var index = n - 1 ; index >= 0 ; index -- ) { if ( arr [ index ] == 0 ) num_unplaced_zeros += 1 ; else count += num_unplaced_zeros ; } return count ; }
var arr = [ 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 ] ; document . write ( minswaps ( arr , 9 ) ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } ;
function push ( head_ref , new_data ) { var new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
function printList ( head ) { while ( head != null ) { document . write ( head . data + " " ) ; head = head . next ; } }
function sortlist ( arr , N , head ) {
var hash = new Map ( ) ; var temp = head ; while ( temp != null ) { if ( hash . has ( temp . data ) ) hash . set ( temp . data , hash . get ( temp . data ) + 1 ) ; else hash . set ( temp . data , 1 ) ; temp = temp . next ; } temp = head ;
for ( var i = 0 ; i < N ; i ++ ) {
var frequency = hash . get ( arr [ i ] ) ; while ( frequency -- > 0 ) {
temp . data = arr [ i ] ; temp = temp . next ; } } }
var head = null ; var arr = [ 5 , 1 , 3 , 2 , 8 ] ; var N = arr . length ;
head = push ( head , 3 ) ; head = push ( head , 2 ) ; head = push ( head , 5 ) ; head = push ( head , 8 ) ; head = push ( head , 5 ) ; head = push ( head , 2 ) ; head = push ( head , 1 ) ;
sortlist ( arr , N , head ) ;
document . write ( " " + " " ) ; printList ( head ) ;
function printRepeating ( arr , size ) {
var s = new Set ( arr ) ;
[ ... s ] . sort ( ( a , b ) => a - b ) . forEach ( x => { document . write ( x + " " ) } ) ; }
var arr = [ 1 , 3 , 2 , 2 , 1 ] ; var n = arr . length ; printRepeating ( arr , n ) ;
function maxPartitions ( arr , n ) { let ans = 0 , max_so_far = 0 ; for ( let i = 0 ; i < n ; ++ i ) {
max_so_far = Math . max ( max_so_far , arr [ i ] ) ;
if ( max_so_far == i ) ans ++ ; } return ans ; }
let arr = [ 1 , 0 , 2 , 3 , 4 ] ; let n = arr . length ; document . write ( maxPartitions ( arr , n ) ) ;
function rankify ( A , n ) {
var R = [ ... Array ( n ) ] ;
for ( var i = 0 ; i < n ; i ++ ) { var r = 1 , s = 1 ; for ( var j = 0 ; j < n ; j ++ ) { if ( j != i && A [ j ] < A [ i ] ) r += 1 ; if ( j != i && A [ j ] == A [ i ] ) s += 1 ; }
R [ i ] = parseFloat ( r + parseFloat ( s - 1 ) / parseFloat ( 2 ) ) ; } for ( var i = 0 ; i < n ; i ++ ) document . write ( parseFloat ( R [ i ] ) . toFixed ( 1 ) + " " ) ; }
var A = [ 1 , 2 , 5 , 2 , 1 , 25 , 2 ] ; var n = A . length ; for ( var i = 0 ; i < n ; i ++ ) document . write ( A [ i ] + " " ) ; document . write ( " " ) ; rankify ( A , n ) ;
function min_noOf_operation ( arr , n , k ) { let noOfSubtraction ; let res = 0 ; for ( let i = 1 ; i < n ; i ++ ) { noOfSubtraction = 0 ; if ( arr [ i ] > arr [ i - 1 ] ) {
noOfSubtraction = ( arr [ i ] - arr [ i - 1 ] ) / k ;
if ( ( arr [ i ] - arr [ i - 1 ] ) % k != 0 ) noOfSubtraction ++ ;
arr [ i ] = arr [ i ] - k * noOfSubtraction ; }
res = res + noOfSubtraction ; } return res ; }
let arr = [ 1 , 1 , 2 , 3 ] ; let N = 4 ; let k = 5 ; document . write ( Math . floor ( min_noOf_operation ( arr , N , k ) ) ) ;
function maxSum ( arr , n ) {
arr . sort ( ) ;
let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) sum += ( arr [ i ] * i ) ; return sum ; }
let arr = [ 3 , 5 , 6 , 1 ] ; let n = arr . length ; document . write ( maxSum ( arr , n ) ) ;
function countPairs ( a , n , k ) { var res = 0 ; for ( var i = 0 ; i < n ; i ++ ) for ( var j = i + 1 ; j < n ; j ++ ) if ( Math . abs ( a [ j ] - a [ i ] ) < k ) res ++ ; return res ; }
var a = [ 1 , 10 , 4 , 2 ] ; var k = 3 ; var n = a . length ; document . write ( countPairs ( a , n , k ) ) ;
function countPairs ( a , n , k ) {
a . sort ( ( a , b ) => a - b ) ; let res = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
let j = i + 1 ; while ( j < n && a [ j ] - a [ i ] < k ) { res ++ ; j ++ ; } } return res ; }
let a = [ 1 , 10 , 4 , 2 ] ; let k = 3 ; let n = a . length ; document . write ( countPairs ( a , n , k ) + " " ) ;
function sortedMerge ( a , b , res , n , m ) {
a . sort ( ( a , b ) => a - b ) ; b . sort ( ( a , b ) => a - b ) ;
let i = 0 , j = 0 , k = 0 ; while ( i < n && j < m ) { if ( a [ i ] <= b [ j ] ) { res [ k ] = a [ i ] ; i += 1 ; k += 1 ; } else { res [ k ] = b [ j ] ; j += 1 ; k += 1 ; } }
while ( i < n ) { res [ k ] = a [ i ] ; i += 1 ; k += 1 ; }
while ( j < m ) { res [ k ] = b [ j ] ; j += 1 ; k += 1 ; } }
let a = [ 10 , 5 , 15 ] ; let b = [ 20 , 3 , 2 , 12 ] ; let n = a . length ; let m = b . length ;
let res = new Array ( n + m ) ; sortedMerge ( a , b , res , n , m ) ; document . write ( " " ) ; for ( let i = 0 ; i < n + m ; i ++ ) document . write ( " " + res [ i ] ) ;
function findMaxPairs ( a , b , n , k ) {
a . sort ( function ( c , d ) { return c - d ; } ) ;
b . sort ( function ( c , d ) { return c - d ; } )
let flag = new Array ( n ) ; for ( let i = 0 ; i < flag . length ; i ++ ) { flag [ i ] = false ; }
let result = 0 ; for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) { if ( Math . abs ( a [ i ] - b [ j ] ) <= k && flag [ j ] == false ) {
result ++ ;
flag [ j ] = true ;
break ; } } } return result ; }
let a = [ 10 , 15 , 20 ] ; let b = [ 17 , 12 , 24 ] ; let n = a . length ; let k = 3 ; document . write ( findMaxPairs ( a , b , n , k ) ) ;
function findMaxPairs ( a , b , n , k ) {
a . sort ( function ( a , b ) { return a - b } ) ;
b . sort ( function ( a , b ) { return a - b } ) ; let result = 0 ; for ( let i = 0 , j = 0 ; i < n && j < n ; ) { if ( Math . abs ( a [ i ] - b [ j ] ) <= k ) { result ++ ;
i ++ ; j ++ ; }
else if ( a [ i ] > b [ j ] ) j ++ ;
let a = [ 10 , 15 , 20 ] ; let b = [ 17 , 12 , 24 ] ; let n = a . length ; let k = 3 ; document . write ( findMaxPairs ( a , b , n , k ) ) ;
function sumOfMinAbsDifferences ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ;
let sum = 0 ;
sum += Math . abs ( arr [ 0 ] - arr [ 1 ] ) ;
sum += Math . abs ( arr [ n - 1 ] - arr [ n - 2 ] ) ;
for ( let i = 1 ; i < n - 1 ; i ++ ) sum += Math . min ( Math . abs ( arr [ i ] - arr [ i - 1 ] ) , Math . abs ( arr [ i ] - arr [ i + 1 ] ) ) ;
return sum ; }
let arr = [ 5 , 10 , 1 , 4 , 8 , 7 ] ; let n = arr . length ; document . write ( " " + sumOfMinAbsDifferences ( arr , n ) ) ;
function findSmallestDifference ( A , B , m , n ) {
A . sort ( ( a , b ) => a - b ) ; B . sort ( ( a , b ) => a - b ) ; let a = 0 , b = 0 ;
let result = Number . MAX_SAFE_INTEGER ;
while ( a < m && b < n ) { if ( Math . abs ( A [ a ] - B [ b ] ) < result ) result = Math . abs ( A [ a ] - B [ b ] ) ;
if ( A [ a ] < B [ b ] ) a ++ ; else b ++ ; }
return result ; }
let A = [ 1 , 2 , 11 , 5 ] ;
let B = [ 4 , 12 , 19 , 23 , 127 , 235 ] ;
let m = A . length ; let n = B . length ;
document . write ( findSmallestDifference ( A , B , m , n ) ) ;
function arraySortedOrNot ( a , n ) {
if ( n == 1 n == 0 ) { return true ; }
return a [ n - 1 ] >= a [ n - 2 ] && arraySortedOrNot ( a , n - 1 ) ; }
let arr = [ 20 , 23 , 23 , 45 , 78 , 88 ] ; let n = arr . length ;
if ( arraySortedOrNot ( arr , n ) ) { document . write ( " " + " " ) ; } else { document . write ( " " + " " ) ; }
function arraySortedOrNot ( arr , n ) {
if ( n == 0 n == 1 ) return true ; for ( let i = 1 ; i < n ; i ++ )
if ( arr [ i - 1 ] > arr [ i ] ) return false ;
return true ; }
let arr = [ 20 , 23 , 23 , 45 , 78 , 88 ] ; let n = arr . length ; if ( arraySortedOrNot ( arr , n ) ) document . write ( " " ) ; else document . write ( " " ) ;
function findLarger ( arr , n ) {
arr . sort ( ) ;
for ( let i = n - 1 ; i >= n / 2 ; i -- ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 1 , 3 , 6 , 1 , 0 , 9 ] ; let n = arr . length ; findLarger ( arr , n ) ;
function minSwapsToSort ( arr , n ) {
let arrPos = [ ] ; for ( let i = 0 ; i < n ; i ++ ) { arrPos . push ( [ arr [ i ] , i ] ) ; }
arrPos . sort ( function ( a , b ) { return a [ 0 ] - b [ 0 ] ; } ) ;
let vis = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) { vis [ i ] = false ; }
let ans = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( vis [ i ] arrPos [ i ] [ 1 ] == i ) continue ;
let cycle_size = 0 ; let j = i ; while ( ! vis [ j ] ) { vis [ j ] = true ;
j = arrPos [ j ] [ 1 ] ; cycle_size ++ ; }
ans += ( cycle_size - 1 ) ; }
return ans ; }
function minSwapToMakeArraySame ( a , b , n ) {
let mp = new Map ( ) ; for ( let i = 0 ; i < n ; i ++ ) { mp . set ( b [ i ] , i ) ; }
for ( let i = 0 ; i < n ; i ++ ) b [ i ] = mp . get ( a [ i ] ) ;
return minSwapsToSort ( b , n ) ; }
let a = [ 3 , 6 , 4 , 8 ] ; let b = [ 4 , 6 , 8 , 3 ] ; let n = a . length ; document . write ( minSwapToMakeArraySame ( a , b , n ) ) ;
function findSingle ( ar , ar_size ) {
let res = ar [ 0 ] ; for ( let i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
let ar = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] ; let n = ar . length ; document . write ( " " + findSingle ( ar , n ) ) ;
function singleNumber ( nums , n ) { let m = new Map ( ) ; let sum1 = 0 , sum2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( ! m . has ( nums [ i ] ) ) { sum1 += nums [ i ] ; m . set ( nums [ i ] , 1 ) ; } sum2 += nums [ i ] ; }
return ( 2 * ( sum1 ) - sum2 ) ; }
let a = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] ; let n = 7 ; document . write ( singleNumber ( a , n ) + " " ) ; let b = [ 15 , 18 , 16 , 18 , 16 , 15 , 89 ] ; document . write ( singleNumber ( b , n ) ) ;
function singleelement ( arr , n ) { let low = 0 , high = n - 2 ; let mid ; while ( low <= high ) { mid = ( low + high ) / 2 ; if ( arr [ mid ] == arr [ mid ^ 1 ] ) { low = mid + 1 ; } else { high = mid - 1 ; } } return arr [ low ] ; }
let arr = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] ; let size = arr . length ; document . write ( singleelement ( arr , size ) ) ;
let arr = [ 5 , 1 , 3 , 4 , 7 ] ; function countTriplets ( n , sum ) {
let ans = 0 ;
for ( let i = 0 ; i < n - 2 ; i ++ ) {
for ( let j = i + 1 ; j < n - 1 ; j ++ ) {
for ( let k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] + arr [ j ] + arr [ k ] < sum ) ans ++ ; } } return ans ; }
let sum = 12 ; document . write ( countTriplets ( arr . length , sum ) ) ;
let arr = [ 5 , 1 , 3 , 4 , 7 ] ; function countTriplets ( n , sum ) {
arr . sort ( function ( a , b ) { return b - a } ) ;
let ans = 0 ;
for ( let i = 0 ; i < n - 2 ; i ++ ) {
let j = i + 1 , k = n - 1 ;
while ( j < k ) {
if ( arr [ i ] + arr [ j ] + arr [ k ] >= sum ) k -- ;
else {
ans += ( k - j ) ; j ++ ; } } } return ans ; }
let sum = 12 ; document . write ( countTriplets ( arr . length , sum ) ) ;
function countTriplets ( a , n ) {
var s = [ ] ; for ( i = 0 ; i < n ; i ++ ) s . push ( a [ i ] ) ;
var count = 0 ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) {
var xr = a [ i ] ^ a [ j ] ;
if ( s . includes ( xr ) && xr != a [ i ] && xr != a [ j ] ) count ++ ; } }
return count / 3 ; }
var a = [ 1 , 3 , 5 , 10 , 14 , 15 ] ; var n = a . length ; document . write ( countTriplets ( a , n ) ) ;
function getMissingNo ( a ) { let n = a . length ; let i , total = 1 ; for ( i = 2 ; i <= ( n + 1 ) ; i ++ ) { total += i ; total -= a [ i - 2 ] ; } return total ; }
let arr = [ 1 , 2 , 3 , 5 ] ; document . write ( getMissingNo ( arr ) ) ;
function getMissingNo ( a , n ) { let n_elements_sum = Math . floor ( n * ( n + 1 ) / 2 ) ; let sum = 0 ; for ( let i = 0 ; i < n - 1 ; i ++ ) sum += a [ i ] ; return n_elements_sum - sum ; }
let a = [ 1 , 2 , 4 , 5 , 6 ] ; let n = a . length + 1 ; let miss = getMissingNo ( a , n ) document . write ( miss ) ;
function countOccurrences ( arr , n , x ) { let res = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( x == arr [ i ] ) res ++ ; } return res ; }
arr = [ 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 ] let n = arr . length ; let x = 2 ; document . write ( countOccurrences ( arr , n , x ) ) ;
function binarySearch ( arr , l , r , x ) { if ( r < l ) return - 1 ; var mid = l + parseInt ( ( r - l ) / 2 ) ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
function countOccurrences ( arr , n , x ) { var ind = binarySearch ( arr , 0 , n - 1 , x ) ;
if ( ind == - 1 ) return 0 ;
var count = 1 ; var left = ind - 1 ; while ( left >= 0 && arr [ left ] == x ) count ++ , left -- ;
var right = ind + 1 ; while ( right < n && arr [ right ] == x ) count ++ , right ++ ; return count ; }
var arr = [ 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 ] ; var n = arr . length ; var x = 2 ; document . write ( countOccurrences ( arr , n , x ) ) ;
function printClosest ( arr , n , x ) {
let res_l = 0 , res_r = 0 ;
let l = 0 , r = n - 1 , diff = Number . MAX_VALUE ;
while ( r > l ) {
if ( Math . abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } document . write ( " " + arr [ res_l ] + " " + arr [ res_r ] ) ; }
let arr = [ 10 , 22 , 28 , 29 , 30 , 40 ] , x = 54 ; let n = arr . length ; printClosest ( arr , n , x ) ;
function constructTree ( n , d , h ) { if ( d == 1 ) {
if ( n == 2 && h == 1 ) { document . write ( " " , " " ) ; return ; }
document . write ( " " , " " ) ; return ; } if ( d > 2 * h ) { document . write ( " " , " " ) ; return ; }
for ( var i = 1 ; i <= h ; i ++ ) document . write ( i + " " + ( i + 1 ) , " " ) ; if ( d > h ) {
document . write ( " " + " " + ( h + 2 ) , " " ) ; for ( var i = h + 2 ; i <= d ; i ++ ) { document . write ( i + " " + ( i + 1 ) , " " ) ; } }
for ( var i = d + 1 ; i < n ; i ++ ) { var k = 1 ; if ( d == h ) k = 2 ; document . write ( k + " " + ( i + 1 ) , " " ) ; } }
var n = 5 , d = 3 , h = 2 ; constructTree ( n , d , h ) ;
function countOnes ( arr , low , high ) { if ( high >= low ) {
let mid = Math . trunc ( low + ( high - low ) / 2 ) ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
let arr = [ 1 , 1 , 1 , 1 , 0 , 0 , 0 ] ; let n = arr . length ; document . write ( " " + countOnes ( arr , 0 , n - 1 ) ) ;
function findMissingUtil ( arr1 , arr2 , N ) {
if ( N == 1 ) return arr1 [ 0 ] ;
if ( arr1 [ 0 ] != arr2 [ 0 ] ) return arr1 [ 0 ] ;
let lo = 0 , hi = N - 1 ;
while ( lo < hi ) { let mid = parseInt ( ( lo + hi ) / 2 , 10 ) ;
if ( arr1 [ mid ] == arr2 [ mid ] ) lo = mid ; else hi = mid ;
if ( lo == hi - 1 ) break ; }
return arr1 [ hi ] ; }
function findMissing ( arr1 , arr2 , M , N ) { if ( N == M - 1 ) document . write ( " " + findMissingUtil ( arr1 , arr2 , M ) + " " ) ; else if ( M == N - 1 ) document . write ( " " + findMissingUtil ( arr2 , arr1 , N ) + " " ) ; else document . write ( " " + " " ) ; }
let arr1 = [ 1 , 4 , 5 , 7 , 9 ] ; let arr2 = [ 4 , 5 , 7 , 9 ] ; let M = arr1 . length ; let N = arr2 . length ; findMissing ( arr1 , arr2 , M , N ) ;
function findMissing ( arr1 , arr2 , M , N ) { if ( M != N - 1 && N != M - 1 ) { document . write ( " " ) ; return ; }
let res = 0 ; for ( let i = 0 ; i < M ; i ++ ) res = res ^ arr1 [ i ] ; for ( let i = 0 ; i < N ; i ++ ) res = res ^ arr2 [ i ] ; document . write ( " " + res ) ; }
let arr1 = [ 4 , 1 , 5 , 9 , 7 ] ; let arr2 = [ 7 , 5 , 9 , 4 ] ; let M = arr1 . length ; let N = arr2 . length ; findMissing ( arr1 , arr2 , M , N ) ;
function findFourElements ( arr , n , X ) {
let mp = new Map ( ) ; for ( let i = 0 ; i < n - 1 ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) mp . set ( arr [ i ] + arr [ j ] , [ i , j ] ) ;
for ( let i = 0 ; i < n - 1 ; i ++ ) { for ( let j = i + 1 ; j < n ; j ++ ) { let sum = arr [ i ] + arr [ j ] ;
if ( mp . has ( X - sum ) ) {
let p = mp . get ( X - sum ) ; if ( p [ 0 ] != i && p [ 0 ] != j && p [ 1 ] != i && p [ 1 ] != j ) { document . write ( arr [ i ] + " " + arr [ j ] + " " + arr [ p [ 0 ] ] + " " + arr [ p [ 1 ] ] ) ; return ; } } } } }
let arr = [ 10 , 20 , 30 , 40 , 1 , 2 ] ; let n = arr . length ; let X = 91 ;
findFourElements ( arr , n , X ) ;
function fourSum ( X , arr , map ) { let temp = new Array ( arr . length ) ;
for ( let i = 0 ; i < temp . length ; i ++ ) temp [ i ] = 0 ;
for ( let i = 0 ; i < arr . length - 1 ; i ++ ) {
for ( let j = i + 1 ; j < arr . length ; j ++ ) {
let curr_sum = arr [ i ] + arr [ j ] ;
if ( map . has ( X - curr_sum ) ) {
let p = map . get ( X - curr_sum ) ; if ( p . first != i && p . sec != i && p . first != j && p . sec != j && temp [ p . first ] == 0 && temp [ p . sec ] == 0 && temp [ i ] == 0 && temp [ j ] == 0 ) {
document . write ( arr [ i ] + " " + arr [ j ] + " " + arr [ p . first ] + " " + arr [ p . sec ] ) ; temp [ p . sec ] = 1 ; temp [ i ] = 1 ; temp [ j ] = 1 ; break ; } } } } }
function twoSum ( nums ) { let map = new Map ( ) ; for ( let i = 0 ; i < nums . length - 1 ; i ++ ) { for ( let j = i + 1 ; j < nums . length ; j ++ ) { map . set ( nums [ i ] + nums [ j ] , new pair ( i , j ) ) ; } } return map ; }
let arr = [ 10 , 20 , 30 , 40 , 1 , 2 ] ; let n = arr . length ; let X = 91 ; let map = twoSum ( arr ) ;
fourSum ( X , arr , map ) ;
function search ( arr , n , x ) {
let i = 0 ; while ( i < n ) {
if ( arr [ i ] == x ) return i ;
i = i + Math . abs ( arr [ i ] - x ) ; } document . write ( " " ) ; return - 1 ; }
let arr = [ 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 ] ; let n = arr . length ; let x = 3 ; document . write ( " " + x + " " + search ( arr , n , 3 ) ) ;
function thirdLargest ( arr , arr_size ) {
if ( arr_size < 3 ) { document . write ( " " ) ; return ; }
let first = arr [ 0 ] ; for ( let i = 1 ; i < arr_size ; i ++ ) if ( arr [ i ] > first ) first = arr [ i ] ;
let second = Number . MIN_VALUE ; for ( let i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > second && arr [ i ] < first ) second = arr [ i ] ;
let third = Number . MIN_VALUE ; for ( let i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > third && arr [ i ] < second ) third = arr [ i ] ; document . write ( " " + " " , third ) ; }
let arr = [ 12 , 13 , 1 , 10 , 34 , 16 ] ; let n = arr . length ; thirdLargest ( arr , n ) ;
function thirdLargest ( arr , arr_size ) {
if ( arr_size < 3 ) { document . write ( " " ) ; return ; }
var first = arr [ 0 ] , second = - 1000000000 , third = - 1000000000 ;
for ( var i = 1 ; i < arr_size ; i ++ ) {
if ( arr [ i ] > first ) { third = second ; second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) { third = second ; second = arr [ i ] ; }
else if ( arr [ i ] > third ) third = arr [ i ] ; } document . write ( " " + third ) ; }
var arr = [ 12 , 13 , 1 , 10 , 34 , 16 ] ; var n = arr . length ; thirdLargest ( arr , n ) ;
function checkPair ( arr , n ) {
let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) { sum += arr [ i ] ; }
if ( sum % 2 != 0 ) { return false ; } sum = Math . floor ( sum / 2 ) ;
let s = new Set ( ) ; for ( let i = 0 ; i < n ; i ++ ) { let val = sum - arr [ i ] ;
if ( ! s . has ( arr [ i ] ) ) { s . add ( arr [ i ] ) } if ( s . has ( val ) ) { document . write ( " " + arr [ i ] + " " + val + " " ) ; return true ; } s . add ( arr [ i ] ) ; } return false ; }
let arr = [ 2 , 11 , 5 , 1 , 4 , 7 ] ; let n = arr . length ; if ( checkPair ( arr , n ) == false ) { document . write ( " " ) ; }
function search ( arr , n , x ) {
if ( arr [ n - 1 ] == x ) return " " ; let backup = arr [ n - 1 ] ; arr [ n - 1 ] = x ;
for ( let i = 0 ; ; i ++ ) {
if ( arr [ i ] == x ) {
arr [ n - 1 ] = backup ;
if ( i < n - 1 ) return " " ;
return " " ; } } }
let arr = [ 4 , 6 , 1 , 5 , 8 ] ; let n = arr . length ; let x = 1 ; document . write ( search ( arr , n , x ) ) ;
function sequence ( a ) { if ( a . length == 0 ) return [ 0 , 0 ] let s = 0 let e = a . length - 1 while ( s < e ) { let m = Math . floor ( ( s + e ) / 2 ) ;
if ( a [ m ] >= m + a [ 0 ] ) s = m + 1
else e = m } return [ a [ s ] , a . length - ( a [ a . length - 1 ] - a [ 0 ] ) ] }
let p = sequence ( [ 1 , 2 , 3 , 4 , 4 , 4 , 5 , 6 ] ) document . write ( " " + p [ 0 ] + " " + p [ 1 ] + " " )
function findMajority ( arr , n ) { return arr [ Math . floor ( n / 2 ) ] ; }
let arr = [ 1 , 2 , 2 , 3 ] ; let n = arr . length ; document . write ( findMajority ( arr , n ) ) ;
function minAdjDifference ( arr , n ) { if ( n < 2 ) return ;
let res = Math . abs ( arr [ 1 ] - arr [ 0 ] ) ; for ( let i = 2 ; i < n ; i ++ ) res = Math . min ( res , Math . abs ( arr [ i ] - arr [ i - 1 ] ) ) ;
res = Math . min ( res , Math . abs ( arr [ n - 1 ] - arr [ 0 ] ) ) ; document . write ( " " + res ) ; }
let a = [ 10 , 12 , 13 , 15 , 10 ] ; let n = a . length ; minAdjDifference ( a , n ) ;
let MAX = 100000 function Print3Smallest ( array , n ) { let firstmin = MAX , secmin = MAX , thirdmin = MAX ; for ( let i = 0 ; i < n ; i ++ ) {
if ( array [ i ] < firstmin ) { thirdmin = secmin ; secmin = firstmin ; firstmin = array [ i ] ; }
else if ( array [ i ] < secmin ) { thirdmin = secmin ; secmin = array [ i ] ; }
else if ( array [ i ] < thirdmin ) thirdmin = array [ i ] ; } document . write ( " " + firstmin + " " ) ; document . write ( " " + secmin + " " ) ; document . write ( " " + thirdmin + " " ) ; }
let array = [ 4 , 9 , 1 , 32 , 12 ] ; let n = array . length ; Print3Smallest ( array , n ) ;
function getMin ( arr , i , n ) {
return ( n == 1 ) ? arr [ i ] : Math . min ( arr [ i ] , getMin ( arr , i + 1 , n - 1 ) ) ; } function getMax ( arr , i , n ) {
return ( n == 1 ) ? arr [ i ] : Math . max ( arr [ i ] , getMax ( arr , i + 1 , n - 1 ) ) ; }
var arr = [ 12 , 1234 , 45 , 67 , 1 ] ; var n = arr . length ; document . write ( " " + getMin ( arr , 0 , n ) + " " ) ; document . write ( " " + getMax ( arr , 0 , n ) ) ;
function getMin ( arr , n ) { return Math . min . apply ( Math , arr ) ; } function getMax ( arr , n ) { return Math . max . apply ( Math , arr ) ; }
var arr = [ 12 , 1234 , 45 , 67 , 1 ] ; var n = arr . length ; document . write ( " " + getMin ( arr , n ) + " " ) ; document . write ( " " + getMax ( arr , n ) ) ;
function findCounts ( arr , n ) {
let hash = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) { hash [ i ] = 0 ; }
let i = 0 ; while ( i < n ) {
hash [ arr [ i ] - 1 ] ++ ;
i ++ ; } document . write ( " " + " " ) ; for ( i = 0 ; i < n ; i ++ ) { document . write ( ( i + 1 ) + " " + hash [ i ] + " " ) ; } }
let arr = [ 2 , 3 , 3 , 2 , 5 ] ; findCounts ( arr , arr . length ) ; let arr1 = [ 1 ] ; findCounts ( arr1 , arr1 . length ) ; let arr3 = [ 4 , 4 , 4 , 4 ] ; findCounts ( arr3 , arr3 . length ) ; let arr2 = [ 1 , 3 , 5 , 7 , 9 , 1 , 3 , 5 , 7 , 9 , 1 ] ; findCounts ( arr2 , arr2 . length ) ; let arr4 = [ 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 ] ; findCounts ( arr4 , arr4 . length ) ; let arr5 = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 ] ; findCounts ( arr5 , arr5 . length ) ; let arr6 = [ 11 , 10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 ] ; findCounts ( arr6 , arr6 . length ) ;
function findCounts ( arr , n ) {
let i = 0 ; while ( i < n ) {
if ( arr [ i ] <= 0 ) { i ++ ; continue ; }
let elementIndex = arr [ i ] - 1 ;
if ( arr [ elementIndex ] > 0 ) { arr [ i ] = arr [ elementIndex ] ;
arr [ elementIndex ] = - 1 ; } else {
arr [ elementIndex ] -- ;
arr [ i ] = 0 ; i ++ ; } } document . write ( " " ) ; for ( let j = 0 ; j < n ; j ++ ) document . write ( j + 1 + " " + Math . abs ( arr [ j ] ) + " " ) ; }
let arr = [ 2 , 3 , 3 , 2 , 5 ] ; findCounts ( arr , arr . length ) ; let arr1 = [ 1 ] ; findCounts ( arr1 , arr1 . length ) ; let arr3 = [ 4 , 4 , 4 , 4 ] ; findCounts ( arr3 , arr3 . length ) ; let arr2 = [ 1 , 3 , 5 , 7 , 9 , 1 , 3 , 5 , 7 , 9 , 1 ] ; findCounts ( arr2 , arr2 . length ) ; let arr4 = [ 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 ] ; findCounts ( arr4 , arr4 . length ) ; let arr5 = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 ] ; findCounts ( arr5 , arr5 . length ) ; let arr6 = [ 11 , 10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 ] ; findCounts ( arr6 , arr6 . length ) ;
function printfrequency ( arr , n ) {
for ( let j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] - 1 ;
for ( let i = 0 ; i < n ; i ++ ) arr [ arr [ i ] % n ] = arr [ arr [ i ] % n ] + n ;
for ( let i = 0 ; i < n ; i ++ ) document . write ( ( i + 1 ) + " " + parseInt ( arr [ i ] / n , 10 ) + " " ) ; }
let arr = [ 2 , 3 , 3 , 2 , 5 ] ; let n = arr . length ; printfrequency ( arr , n ) ;
function deleteElement ( arr , n , x ) {
let i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == x ) break ;
if ( i < n ) {
n = n - 1 ; for ( let j = i ; j < n ; j ++ ) arr [ j ] = arr [ j + 1 ] ; } return n ; }
let arr = [ 11 , 15 , 6 , 8 , 9 , 10 ] ; let n = arr . length ; let x = 6 ;
n = deleteElement ( arr , n , x ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function deleteElement ( arr , n , x ) {
if ( arr [ n - 1 ] == x ) return ( n - 1 ) ;
let prev = arr [ n - 1 ] , i ; for ( i = n - 2 ; i >= 0 && arr [ i ] != x ; i -- ) { let curr = arr [ i ] ; arr [ i ] = prev ; prev = curr ; }
if ( i < 0 ) return 0 ;
arr [ i ] = prev ; return ( n - 1 ) ; }
let arr = [ 11 , 15 , 6 , 8 , 9 , 10 ] ; let n = arr . length ; let x = 6 ;
n = deleteElement ( arr , n , x ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function getInvCount ( arr , n ) {
let invcount = 0 ; for ( let i = 0 ; i < n - 1 ; i ++ ) {
let small = 0 ; for ( let j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) small ++ ;
let great = 0 ; for ( let j = i - 1 ; j >= 0 ; j -- ) if ( arr [ i ] < arr [ j ] ) great ++ ;
invcount += great * small ; } return invcount ; }
let arr = [ 8 , 4 , 2 , 1 ] ; let n = arr . length ; document . write ( " " + getInvCount ( arr , n ) ) ;
function maxWater ( arr , n ) {
let res = 0 ;
for ( let i = 1 ; i < n - 1 ; i ++ ) {
let left = arr [ i ] ; for ( let j = 0 ; j < i ; j ++ ) { left = Math . max ( left , arr [ j ] ) ; }
let right = arr [ i ] ; for ( let j = i + 1 ; j < n ; j ++ ) { right = Math . max ( right , arr [ j ] ) ; }
res += Math . min ( left , right ) - arr [ i ] ; } return res ; }
let arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] ; let n = arr . length ; document . write ( maxWater ( arr , n ) ) ;
function findWater ( n ) {
let left = new Array ( n ) ;
let right = new Array ( n ) ;
let water = 0 ;
left [ 0 ] = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) left [ i ] = Math . max ( left [ i - 1 ] , arr [ i ] ) ;
right [ n - 1 ] = arr [ n - 1 ] ; for ( let i = n - 2 ; i >= 0 ; i -- ) right [ i ] = Math . max ( right [ i + 1 ] , arr [ i ] ) ;
for ( let i = 0 ; i < n ; i ++ ) water += Math . min ( left [ i ] , right [ i ] ) - arr [ i ] ; return water ; }
document . write ( " " + findWater ( arr . length ) ) ;
function findWater ( arr , n ) {
let result = 0 ;
let left_max = 0 , right_max = 0 ;
let lo = 0 , hi = n - 1 ; while ( lo <= hi ) { if ( arr [ lo ] < arr [ hi ] ) { if ( arr [ lo ] > left_max )
left_max = arr [ lo ] ; else
result += left_max - arr [ lo ] ; lo ++ ; } else { if ( arr [ hi ] > right_max )
right_max = arr [ hi ] ; else result += right_max - arr [ hi ] ; hi -- ; } } return result ; }
let arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] ; let n = arr . length ; document . write ( " " + " " + findWater ( arr , n ) ) ;
function maxWater ( arr , n ) { let size = n - 1 ;
let prev = arr [ 0 ] ;
let prev_index = 0 ; let water = 0 ;
let temp = 0 ; for ( let i = 1 ; i <= size ; i ++ ) {
if ( arr [ i ] >= prev ) { prev = arr [ i ] ; prev_index = i ;
temp = 0 ; } else {
water += prev - arr [ i ] ;
temp += prev - arr [ i ] ; } }
if ( prev_index < size ) {
water -= temp ;
prev = arr [ size ] ;
for ( let i = size ; i >= prev_index ; i -- ) {
if ( arr [ i ] >= prev ) { prev = arr [ i ] ; } else { water += prev - arr [ i ] ; } } }
return water ; }
let arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] ; let n = arr . length ; document . write ( maxWater ( arr , n ) ) ;
function maxWater ( arr , n ) {
let left = 0 ; let right = n - 1 ;
let l_max = 0 ; let r_max = 0 ;
let result = 0 ; while ( left <= right ) {
if ( r_max <= l_max ) {
result += Math . max ( 0 , r_max - arr [ right ] ) ;
r_max = Math . max ( r_max , arr [ right ] ) ;
right -= 1 ; } else {
result += Math . max ( 0 , l_max - arr [ left ] ) ;
l_max = Math . max ( l_max , arr [ left ] ) ;
left += 1 ; } } return result ; }
let arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] ; let n = arr . length ; document . write ( maxWater ( arr , n ) ) ;
function missingK ( a , k , n ) { let difference = 0 , ans = 0 , count = k ; let flag = false ;
for ( let i = 0 ; i < n - 1 ; i ++ ) { difference = 0 ;
if ( ( a [ i ] + 1 ) != a [ i + 1 ] ) {
difference += ( a [ i + 1 ] - a [ i ] ) - 1 ;
if ( difference >= count ) { ans = a [ i ] + count ; flag = true ; break ; } else count -= difference ; } }
if ( flag ) return ans ; else return - 1 ; }
let a = [ 1 , 5 , 11 , 19 ] ;
let k = 11 ; let n = a . length ;
let missing = missingK ( a , k , n ) ; document . write ( missing ) ;
let a = [ 900 ] ; let b = [ 10 , 13 , 14 ] ;
function maximum ( a , b ) { return a > b ? a : b ; }
function minimum ( a , b ) { return a < b ? a : b ; }
function findMedianSortedArrays ( n , m ) { let min_index = 0 , max_index = n , i = 0 , j = 0 , median = 0 ; while ( min_index <= max_index ) { i = Math . floor ( ( min_index + max_index ) / 2 ) ; j = Math . floor ( ( n + m + 1 ) / 2 ) - i ;
if ( i < n && j > 0 && b [ j - 1 ] > a [ i ] ) min_index = i + 1 ;
else if ( i > 0 && j < m && b [ j ] < a [ i - 1 ] ) max_index = i - 1 ;
else {
if ( i == 0 ) median = b [ j - 1 ] ;
else if ( j == 0 ) median = a [ i - 1 ] ; else median = maximum ( a [ i - 1 ] , b [ j - 1 ] ) ; break ; } }
if ( ( n + m ) % 2 == 1 ) return median ;
if ( i == n ) return ( median + b [ j ] ) / 2.0 ;
if ( j == m ) return ( median + a [ i ] ) / 2.0 ; return ( median + minimum ( a [ i ] , b [ j ] ) ) / 2.0 ; }
let n = a . length ; let m = b . length ;
if ( n < m ) document . write ( " " + findMedianSortedArrays ( n , m ) ) ; else document . write ( " " + findMedianSortedArrays ( m , n ) ) ;
function prletUncommon ( arr1 , arr2 , n1 , n2 ) { let i = 0 , j = 0 , k = 0 ; while ( i < n1 && j < n2 ) {
if ( arr1 [ i ] < arr2 [ j ] ) { document . write ( arr1 [ i ] + " " ) ; i ++ ; k ++ ; } else if ( arr2 [ j ] < arr1 [ i ] ) { document . write ( arr2 [ j ] + " " ) ; k ++ ; j ++ ; }
else { i ++ ; j ++ ; } }
while ( i < n1 ) { document . write ( arr1 [ i ] + " " ) ; i ++ ; k ++ ; } while ( j < n2 ) { document . write ( arr2 [ j ] + " " ) ; j ++ ; k ++ ; } }
let arr1 = [ 10 , 20 , 30 ] ; let arr2 = [ 20 , 25 , 30 , 40 , 50 ] ; let n1 = arr1 . length ; let n2 = arr2 . length ; prletUncommon ( arr1 , arr2 , n1 , n2 ) ;
function leastFrequent ( arr , n ) {
arr . sort ( ) ;
let min_count = n + 1 , res = - 1 ; let curr_count = 1 ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
let arr = [ 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 ] ; let n = arr . length ; document . write ( leastFrequent ( arr , n ) ) ;
function leastFrequent ( arr , n ) {
var hash = new Map ( ) ; for ( var i = 0 ; i < n ; i ++ ) { if ( hash . has ( arr [ i ] ) ) hash . set ( arr [ i ] , hash . get ( arr [ i ] ) + 1 ) else hash . set ( arr [ i ] , 1 ) ; }
var min_count = n + 1 , res = - 1 ; hash . forEach ( ( value , key ) => { if ( min_count >= value ) { res = key ; min_count = value ; } } ) ; return res ; }
var arr = [ 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 ] ; var n = arr . length ; document . write ( leastFrequent ( arr , n ) ) ;
let M = 4 ;
function maximumSum ( a , n ) {
let prev = Math . max ( a [ n - 1 ] [ 0 ] , a [ n - 1 ] [ M - 1 ] + 1 ) ;
let sum = prev ; for ( let i = n - 2 ; i >= 0 ; i -- ) { let max_smaller = Number . MIN_VALUE ; for ( let j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i ] [ j ] < prev && a [ i ] [ j ] > max_smaller ) max_smaller = a [ i ] [ j ] ; }
if ( max_smaller == Number . MIN_VALUE ) return 0 ; prev = max_smaller ; sum += max_smaller ; } return sum ; }
let arr = [ [ 1 , 7 , 3 , 4 ] , [ 4 , 2 , 5 , 1 ] , [ 9 , 5 , 1 , 8 ] ] ; let n = arr . length ; document . write ( maximumSum ( arr , n ) ) ;
let M = 4 ;
function maximumSum ( a , n ) {
let prev = Math . max ( a [ n - 1 ] [ 0 ] , a [ n - 1 ] [ M - 1 ] + 1 ) ;
let sum = prev ; for ( let i = n - 2 ; i >= 0 ; i -- ) { let max_smaller = Number . MIN_VALUE ; for ( let j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i ] [ j ] < prev && a [ i ] [ j ] > max_smaller ) max_smaller = a [ i ] [ j ] ; }
if ( max_smaller == Number . MIN_VALUE ) return 0 ; prev = max_smaller ; sum += max_smaller ; } return sum ; }
let arr = [ [ 1 , 7 , 3 , 4 ] , [ 4 , 2 , 5 , 1 ] , [ 9 , 5 , 1 , 8 ] ] ; let n = arr . length ; document . write ( maximumSum ( arr , n ) ) ;
function countPairs ( A , n , k ) { var ans = 0 ;
A . sort ( ( a , b ) => a - b )
for ( var i = 0 ; i < n ; i ++ ) { for ( var j = i + 1 ; j < n ; j ++ ) {
var x = 0 ;
while ( ( A [ i ] * Math . pow ( k , x ) ) <= A [ j ] ) { if ( ( A [ i ] * Math . pow ( k , x ) ) == A [ j ] ) { ans ++ ; break ; } x ++ ; } } } return ans ; }
var A = [ 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 ] ; var n = A . length ; var k = 3 ; document . write ( countPairs ( A , n , k ) ) ;
function minDistance ( arr , n ) { let maximum_element = arr [ 0 ] ; let min_dis = n ; let index = 0 ; for ( let i = 1 ; i < n ; i ++ ) {
if ( maximum_element == arr [ i ] ) { min_dis = Math . min ( min_dis , ( i - index ) ) ; index = i ; }
else if ( maximum_element < arr [ i ] ) { maximum_element = arr [ i ] ; min_dis = n ; index = i ; }
else continue ; } return min_dis ; }
let arr = [ 6 , 3 , 1 , 3 , 6 , 4 , 6 ] ; let n = arr . length ; document . write ( " " + minDistance ( arr , n ) ) ;
function findValue ( arr , n , k ) {
for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] == k ) k *= 2 ; return k ; }
let arr = [ 2 , 3 , 4 , 10 , 8 , 1 ] , k = 2 ; let n = arr . length ; document . write ( findValue ( arr , n , k ) ) ;
function dupLastIndex ( arr , n ) {
if ( arr == null n <= 0 ) return ;
for ( let i = n - 1 ; i > 0 ; i -- ) { if ( arr [ i ] == arr [ i - 1 ] ) { document . write ( " " + i + " " ) ; document . write ( " " + arr [ i ] + " " ) ; return ; } }
document . write ( " " ) ; }
let arr = [ 1 , 5 , 5 , 6 , 6 , 7 , 9 ] ; let n = arr . length ; dupLastIndex ( arr , n ) ;
function findSmallest ( a , n ) {
for ( let i = 0 ; i < n ; i ++ ) { let j ; for ( j = 0 ; j < n ; j ++ ) if ( a [ j ] % a [ i ] >= 1 ) break ;
if ( j == n ) return a [ i ] ; } return - 1 ; }
let a = [ 25 , 20 , 5 , 10 , 100 ] ; let n = a . length ; document . write ( findSmallest ( a , n ) ) ;
function min_element ( a ) { let min = Number . MAX_VALUE ; let i ; for ( i = 0 ; i < a . length ; i ++ ) { if ( a [ i ] < min ) min = a [ i ] ; } return min ; }
function findSmallest ( a , n ) {
let smallest = min_element ( a ) ;
for ( let i = 1 ; i < n ; i ++ ) if ( a [ i ] % smallest >= 1 ) return - 1 ; return smallest ; }
let a = [ 25 , 20 , 5 , 10 , 100 ] ; let n = a . length ; document . write ( findSmallest ( a , n ) ) ;
function printMax ( arr , k , n ) {
var brr = arr . slice ( ) ;
brr . sort ( ( a , b ) => b - a ) ;
for ( var i = 0 ; i < n ; ++ i ) if ( brr . indexOf ( arr [ i ] ) < k ) document . write ( arr [ i ] + " " ) ; }
var arr = [ 50 , 8 , 45 , 12 , 25 , 40 , 84 ] ; var n = arr . length ; var k = 3 ; printMax ( arr , k , n ) ;
function findIndex ( arr , len ) {
let maxIndex = 0 ; for ( let i = 0 ; i < len ; ++ i ) if ( arr [ i ] > arr [ maxIndex ] ) maxIndex = i ;
for ( let i = 0 ; i < len ; ++ i ) if ( maxIndex != i && arr [ maxIndex ] < 2 * arr [ i ] ) return - 1 ; return maxIndex ; }
let arr = [ 3 , 6 , 1 , 0 ] ; let len = arr . length ; document . write ( findIndex ( arr , len ) ) ;
function find_consecutive_steps ( arr , len ) { let count = 0 ; let maximum = 0 ; for ( let index = 1 ; index < len ; index ++ ) {
if ( arr [ index ] > arr [ index - 1 ] ) count ++ ; else { maximum = Math . max ( maximum , count ) ; count = 0 ; } } return Math . max ( maximum , count ) ; }
let arr = [ 1 , 2 , 3 , 4 ] ; let len = arr . length ; document . write ( find_consecutive_steps ( arr , len ) ) ;
function CalculateMax ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ; let min_sum = arr [ 0 ] + arr [ 1 ] ; let max_sum = arr [ n - 1 ] + arr [ n - 2 ] ; return ( Math . abs ( max_sum - min_sum ) ) ; }
let arr = [ 6 , 7 , 1 , 11 ] ; let n = arr . length ; document . write ( CalculateMax ( arr , n ) ) ;
function calculate ( a , n ) {
a . sort ( ) ; let i , j ;
let s = [ ] ; for ( i = 0 , j = n - 1 ; i < j ; i ++ , j -- ) s . push ( ( a [ i ] + a [ j ] ) ) ; let mini = Math . min ( ... s ) ; let maxi = Math . max ( ... s ) ; return Math . abs ( maxi - mini ) ; }
let a = [ 2 , 6 , 4 , 3 ] ; let n = a . length ; document . write ( calculate ( a , n ) ) ;
function printMinDiffPairs ( arr , n ) { if ( n <= 1 ) return ;
arr . sort ( ) ;
let minDiff = arr [ 1 ] - arr [ 0 ] ; for ( let i = 2 ; i < n ; i ++ ) minDiff = Math . min ( minDiff , arr [ i ] - arr [ i - 1 ] ) ;
for ( let i = 1 ; i < n ; i ++ ) { if ( ( arr [ i ] - arr [ i - 1 ] ) == minDiff ) { document . write ( " " + arr [ i - 1 ] + " " + arr [ i ] + " " ) ; } } }
let arr = [ 5 , 3 , 2 , 4 , 1 ] ; let n = arr . length ; printMinDiffPairs ( arr , n ) ;
let MAX = 256 ; function calculateDiff ( i , j , array ) {
return Math . abs ( array [ i ] - array [ j ] ) + Math . abs ( i - j ) ; }
function maxDistance ( array ) {
let result = 0 ;
for ( let i = 0 ; i < array . length ; i ++ ) { for ( let j = i ; j < array . length ; j ++ ) {
result = Math . max ( result , calculateDiff ( i , j , array ) ) ; } } return result ; }
let array = [ - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 ] ; document . write ( maxDistance ( array ) ) ;
function maxDistance ( array ) {
let max1 = Number . MIN_VALUE ; let min1 = Number . MAX_VALUE ; let max2 = Number . MIN_VALUE ; let min2 = Number . MAX_VALUE ; for ( let i = 0 ; i < array . length ; i ++ ) {
max1 = Math . max ( max1 , array [ i ] + i ) ; min1 = Math . min ( min1 , array [ i ] + i ) ; max2 = Math . max ( max2 , array [ i ] - i ) ; min2 = Math . min ( min2 , array [ i ] - i ) ; }
return Math . max ( max1 - min1 , max2 - min2 ) ; }
let array = [ - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 ] ; document . write ( maxDistance ( array ) ) ;
function extrema ( a , n ) { let count = 0 ;
for ( let i = 1 ; i < n - 1 ; i ++ ) {
if ( a [ i ] > a [ i - 1 ] && a [ i ] > a [ i + 1 ] ) count += 1 ;
if ( a [ i ] < a [ i - 1 ] && a [ i ] < a [ i + 1 ] ) count += 1 ; } return count ; }
let a = [ 1 , 0 , 2 , 1 ] ; let n = a . length ; document . write ( extrema ( a , n ) ) ;
function findClosest ( arr , target ) { let n = arr . length ;
if ( target <= arr [ 0 ] ) return arr [ 0 ] ; if ( target >= arr [ n - 1 ] ) return arr [ n - 1 ] ;
let i = 0 , j = n , mid = 0 ; while ( i < j ) { mid = ( i + j ) / 2 ; if ( arr [ mid ] == target ) return arr [ mid ] ;
if ( target < arr [ mid ] ) {
if ( mid > 0 && target > arr [ mid - 1 ] ) return getClosest ( arr [ mid - 1 ] , arr [ mid ] , target ) ;
j = mid ; }
else { if ( mid < n - 1 && target < arr [ mid + 1 ] ) return getClosest ( arr [ mid ] , arr [ mid + 1 ] , target ) ;
i = mid + 1 ; } }
return arr [ mid ] ; }
function getClosest ( val1 , val2 , target ) { if ( target - val1 >= val2 - target ) return val2 ; else return val1 ; }
let arr = [ 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 ] ; let target = 11 ; document . write ( findClosest ( arr , target ) ) ;
function sum ( a , n ) {
let maxSum = Number . MIN_VALUE ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) maxSum = Math . max ( maxSum , a [ i ] + a [ j ] ) ;
let c = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) if ( a [ i ] + a [ j ] == maxSum ) c ++ ; return c ; }
let array = [ 1 , 1 , 1 , 2 , 2 , 2 ] ; let n = array . length ; document . write ( sum ( array , n ) ) ;
function sum ( a , n ) {
let maxVal = a [ 0 ] , maxCount = 1 ; let secondMax = Number . MIN_VALUE ; let secondMaxCount = 0 ; for ( let i = 1 ; i < n ; i ++ ) { if ( a [ i ] == maxVal ) maxCount ++ ; else if ( a [ i ] > maxVal ) { secondMax = maxVal ; secondMaxCount = maxCount ; maxVal = a [ i ] ; maxCount = 1 ; } else if ( a [ i ] == secondMax ) { secondMax = a [ i ] ; secondMaxCount ++ ; } else if ( a [ i ] > secondMax ) { secondMax = a [ i ] ; secondMaxCount = 1 ; } }
if ( maxCount > 1 ) return maxCount * parseInt ( ( maxCount - 1 ) / 2 , 10 ) ;
return secondMaxCount ; }
let array = [ 1 , 1 , 1 , 2 , 2 , 2 , 3 ] ; let n = array . length ; document . write ( sum ( array , n ) ) ;
function printSmall ( arr , asize , n ) {
let copy_arr = [ ... arr ] ;
copy_arr . sort ( ( a , b ) => a - b ) ;
for ( let i = 0 ; i < asize ; ++ i ) { if ( arr [ i ] < copy_arr [ n ] ) document . write ( arr [ i ] + " " ) ; } }
let arr = [ 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 ] ; let asize = arr . length ; let n = 5 ; printSmall ( arr , asize , n ) ;
function printKMissing ( arr , n , k ) { arr . sort ( ( a , b ) => a - b ) ;
let i = 0 ; while ( i < n && arr [ i ] <= 0 ) i ++ ;
let count = 0 , curr = 1 ; while ( count < k && i < n ) { if ( arr [ i ] != curr ) { document . write ( curr + " " ) ; count ++ ; } else i ++ ; curr ++ ; }
while ( count < k ) { document . write ( curr , " " ) ; curr ++ ; count ++ ; } }
let arr = new Array ( 2 , 3 , 4 ) ; let n = arr . length ; let k = 3 ; printKMissing ( arr , n , k ) ;
function printmissingk ( arr , n , k ) {
let d = new Map ( ) ;
for ( let i = 0 ; i < n ; i ++ ) d . set ( arr [ i ] , arr [ i ] ) ; let cnt = 1 ; let fl = 0 ;
for ( let i = 0 ; i < ( n + k ) ; i ++ ) { if ( ! d . has ( cnt ) ) { fl += 1 ; document . write ( cnt + " " ) ; if ( fl == k ) break ; } cnt += 1 ; } }
let arr = [ 1 , 4 , 3 ] ; let n = arr . length ; let k = 3 ; printmissingk ( arr , n , k ) ;
function nobleInteger ( arr ) { let size = arr . length ; for ( let i = 0 ; i < size ; i ++ ) { let count = 0 ; for ( let j = 0 ; j < size ; j ++ ) if ( arr [ i ] < arr [ j ] ) count ++ ;
if ( count == arr [ i ] ) return arr [ i ] ; } return - 1 ; }
let arr = [ 10 , 3 , 20 , 40 , 2 ] ; let res = nobleInteger ( arr ) ; if ( res != - 1 ) document . write ( " " + " " + res ) ; else document . write ( " " + " " ) ;
function nobleInteger ( arr ) { arr . sort ( function ( a , b ) { return a - b ; } ) ;
let n = arr . length ; for ( let i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] == arr [ i + 1 ] ) continue ;
if ( arr [ i ] == n - i - 1 ) return arr [ i ] ; } if ( arr [ n - 1 ] == 0 ) return arr [ n - 1 ] ; return - 1 ; }
let arr = [ 10 , 3 , 20 , 40 , 2 ] ; let res = nobleInteger ( arr ) ; if ( res != - 1 ) document . write ( " " + res ) ; else document . write ( " " ) ;
function findMinSum ( a , b , n ) {
a . sort ( ) ; b . sort ( ) ;
let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) sum = sum + Math . abs ( a [ i ] - b [ i ] ) ; return sum ; }
let a = [ 4 , 1 , 8 , 7 ] ; let b = [ 2 , 3 , 6 , 5 ] ; let n = a . length ; document . write ( findMinSum ( a , b , n ) ) ;
function checkIsAP ( arr , n ) { if ( n == 1 ) return true ;
arr . sort ( ( a , b ) => a - b ) ;
let d = arr [ 1 ] - arr [ 0 ] ; for ( let i = 2 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] != d ) return false ; return true ; }
let arr = [ 20 , 15 , 5 , 0 , 10 ] ; let n = arr . length ; ( checkIsAP ( arr , n ) ) ? ( document . write ( " " + " " ) ) : ( document . write ( " " + " " ) ) ;
function checkIsAP ( arr , n ) { var hm = new Map ( ) ; var smallest = 1000000000 , second_smallest = 1000000000 ; for ( var i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] < smallest ) { second_smallest = smallest ; smallest = arr [ i ] ; }
else if ( arr [ i ] != smallest && arr [ i ] < second_smallest ) second_smallest = arr [ i ] ;
if ( ! hm . has ( arr [ i ] ) ) { hm . set ( arr [ i ] , 1 ) ; }
else return false ; }
var diff = second_smallest - smallest ;
for ( var i = 0 ; i < n - 1 ; i ++ ) { if ( ! hm . has ( second_smallest ) ) return false ; second_smallest += diff ; } return true ; }
var arr = [ 20 , 15 , 5 , 0 , 10 ] ; var n = arr . length ; ( checkIsAP ( arr , n ) ) ? ( document . write ( " " ) ) : ( document . write ( " " ) ) ;
function minProductSubset ( a , n ) { if ( n == 1 ) return a [ 0 ] ;
let negmax = Number . MIN_VALUE ; let posmin = Number . MIN_VALUE ; let count_neg = 0 , count_zero = 0 ; let product = 1 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == 0 ) { count_zero ++ ; continue ; }
if ( a [ i ] < 0 ) { count_neg ++ ; negmax = Math . max ( negmax , a [ i ] ) ; }
if ( a [ i ] > 0 && a [ i ] < posmin ) { posmin = a [ i ] ; } product *= a [ i ] ; }
if ( count_zero == n || ( count_neg == 0 && count_zero > 0 ) ) return 0 ;
if ( count_neg == 0 ) return posmin ;
if ( count_neg % 2 == 0 && count_neg != 0 ) {
product = parseInt ( product / negmax , 10 ) ; } return product ; }
let a = [ - 1 , - 1 , - 2 , 4 , 3 ] ; let n = 5 ; document . write ( minProductSubset ( a , n ) ) ;
function countPairs ( a , n ) {
let mn = Number . MAX_VALUE ; let mx = Number . MIN_VALUE ; for ( let i = 0 ; i < n ; i ++ ) { mn = Math . min ( mn , a [ i ] ) ; mx = Math . max ( mx , a [ i ] ) ; }
let c1 = 0 ;
let c2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( a [ i ] == mn ) c1 ++ ; if ( a [ i ] == mx ) c2 ++ ; }
if ( mn == mx ) return n * ( n - 1 ) / 2 ; else return c1 * c2 ; }
let a = [ 3 , 2 , 1 , 1 , 3 ] ; let n = a . length ; document . write ( countPairs ( a , n ) ) ;
function binary_search ( a , x , lo = 0 , hi = null ) { if ( hi == null ) hi = a . length ; while ( lo < hi ) { mid = Math . floor ( ( lo + hi ) / 2 ) ; midval = a [ mid ] ; if ( midval < x ) lo = mid + 1 ; else if ( midval > x ) hi = mid ; else return mid ; } return - 1 ; } function findElement ( a , n , b ) {
a . sort ( ( a , b ) => a - b ) ;
let max = a [ n - 1 ] ; while ( b < max ) {
if ( binary_search ( a , a + n , b ) ) b *= 2 ; else return b ; } return b ; }
let a = [ 1 , 2 , 3 ] ; let n = a . length ; let b = 1 ; document . write ( findElement ( a , n , b ) ) ;
let Mod = 1000000007 ;
function findSum ( arr , n ) { let sum = 0 ;
arr . sort ( ) ;
let i = 0 ; while ( i < n && arr [ i ] < 0 ) { if ( i != n - 1 && arr [ i + 1 ] <= 0 ) { sum = ( sum + ( arr [ i ] * arr [ i + 1 ] ) % Mod ) % Mod ; i += 2 ; } else break ; }
let j = n - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { if ( j != 0 && arr [ j - 1 ] > 0 ) { sum = ( sum + ( arr [ j ] * arr [ j - 1 ] ) % Mod ) % Mod ; j -= 2 ; } else break ; }
if ( j > i ) sum = ( sum + ( arr [ i ] * arr [ j ] ) % Mod ) % Mod ;
else if ( i == j ) sum = ( sum + arr [ i ] ) % Mod ; return sum ; }
let arr = [ - 1 , 9 , 4 , 5 , - 4 , 7 ] ; let n = arr . length ; document . write ( findSum ( arr , n ) ) ;
function push ( new_data ) {
var new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function insertAfter ( prev_node , new_data ) {
if ( prev_node == null ) { document . write ( " " ) ; return ; }
var new_node = new Node ( new_data ) ;
new_node . next = prev_node . next ;
prev_node . next = new_node ; }
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } document . write ( ) ; }
function newNode ( key ) { var temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
function insertBeg ( head , val ) { var temp = newNode ( val ) ; temp . next = head ; head = temp ; return head ; }
function rearrangeOddEven ( head ) { var odd = [ ] ; var even = [ ] ; var i = 1 ; while ( head != null ) { if ( head . data % 2 != 0 && i % 2 == 0 ) {
odd . push ( head ) ; } else if ( head . data % 2 == 0 && i % 2 != 0 ) {
even . push ( head ) ; } head = head . next ; i ++ ; } while ( odd . length > 0 && even . length > 0 ) {
var k = odd [ odd . length - 1 ] . data ; odd [ odd . length - 1 ] . data = even [ even . length - 1 ] . data ; even [ even . length - 1 ] . data = k ; odd . pop ( ) ; even . pop ( ) ; } }
var head = newNode ( 8 ) ; head = insertBeg ( head , 7 ) ; head = insertBeg ( head , 6 ) ; head = insertBeg ( head , 5 ) ; head = insertBeg ( head , 3 ) ; head = insertBeg ( head , 2 ) ; head = insertBeg ( head , 1 ) ; document . write ( " " ) ; printList ( head ) ; rearrangeOddEven ( head ) ; document . write ( " " + " " ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } document . write ( " " ) ; }
function newNode ( key ) { var temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
function insertBeg ( head , val ) { var temp = newNode ( val ) ; temp . next = head ; head = temp ; return head ; }
function rearrange ( head ) {
var even ; var temp , prev_temp ; var i , j , k , l , ptr = null ;
temp = ( head ) . next ; prev_temp = head ; while ( temp != null ) {
var x = temp . next ;
if ( temp . data % 2 != 0 ) { prev_temp . next = x ; temp . next = ( head ) ; ( head ) = temp ; } else { prev_temp = temp ; }
temp = x ; }
temp = ( head ) . next ; prev_temp = ( head ) ; while ( temp != null && temp . data % 2 != 0 ) { prev_temp = temp ; temp = temp . next ; } even = temp ;
prev_temp . next = null ;
i = head ; j = even ; while ( j != null && i != null ) {
k = i . next ; l = j . next ; i . next = j ; j . next = k ;
ptr = j ;
i = k ; j = l ; } if ( i == null ) {
ptr . next = j ; }
return head ; }
var head = newNode ( 8 ) ; head = insertBeg ( head , 7 ) ; head = insertBeg ( head , 6 ) ; head = insertBeg ( head , 3 ) ; head = insertBeg ( head , 5 ) ; head = insertBeg ( head , 1 ) ; head = insertBeg ( head , 2 ) ; head = insertBeg ( head , 10 ) ; document . write ( " " ) ; printList ( head ) ; document . write ( " " ) ; head = rearrange ( head ) ; printList ( head ) ;
class Node { constructor ( item ) { this . data = item ; this . left = this . right = null ; } }
function minimumDepth ( root ) {
if ( root == null ) return 0 ;
if ( root . left == null && root . right == null ) return 1 ;
if ( root . left == null ) return minimumDepth ( root . right ) + 1 ;
if ( root . right == null ) return minimumDepth ( root . left ) + 1 ; return Math . min ( minimumDepth ( root . left ) , minimumDepth ( root . right ) ) + 1 ; }
root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; document . write ( " " + " " + minimumDepth ( root ) ) ;
function deleteAlt ( head ) { if ( head == null ) return ; var node = head . next ; if ( node == null ) return ;
head . next = node . next ;
head . next = deleteAlt ( head . next ) ; }
function areIdenticalRecur ( a , b ) {
if ( a == null && b == null ) return true ;
if ( a != null && b != null ) return ( a . data == b . data ) && areIdenticalRecur ( a . next , b . next ) ;
return false ; }
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } var head = null ;
function rotate ( k ) { if ( k == 0 ) return ;
var current = head ;
while ( current . next != null ) current = current . next ; current . next = head ; current = head ;
for ( i = 0 ; i < k - 1 ; i ++ ) current = current . next ;
head = current . next ; current . next = null ; }
function push ( new_data ) {
var new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head ;
head = new_node ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } }
for ( i = 60 ; i > 0 ; i -= 10 ) push ( i ) ; document . write ( " " ) ; printList ( head ) ; rotate ( 4 ) ; document . write ( " " ) ; printList ( head ) ;
var head ;
class Node { constructor ( val ) { this . data = val ; this . next = null ; } } function sortList ( ) {
var count = [ 0 , 0 , 0 ] ; var ptr = head ;
while ( ptr != null ) { count [ ptr . data ] ++ ; ptr = ptr . next ; } var i = 0 ; ptr = head ;
while ( ptr != null ) { if ( count [ i ] == 0 ) i ++ ; else { ptr . data = i ; -- count [ i ] ; ptr = ptr . next ; } } }
function push ( new_data ) {
var new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function printList ( ) { var temp = head ; while ( temp != null ) { document . write ( temp . data + " " ) ; temp = temp . next ; } document . write ( " " ) ; }
push ( 0 ) ; push ( 1 ) ; push ( 0 ) ; push ( 2 ) ; push ( 1 ) ; push ( 1 ) ; push ( 2 ) ; push ( 1 ) ; push ( 2 ) ; document . write ( " " ) ; printList ( ) ; sortList ( ) ; document . write ( " " ) ; printList ( ) ;
class List { constructor ( ) { this . data = 0 ; this . next = null ; this . child = null ; } }
class Node { constructor ( ) { this . data ; this . next = null ; } }
function rearrange ( head ) {
if ( head == null ) return null ;
let prev = head , curr = head . next ; while ( curr != null ) {
if ( prev . data > curr . data ) { let t = prev . data ; prev . data = curr . data ; curr . data = t ; }
if ( curr . next != null && curr . next . data > curr . data ) { let t = curr . next . data ; curr . next . data = curr . data ; curr . data = t ; } prev = curr . next ; if ( curr . next == null ) break ; curr = curr . next . next ; } return head ; }
function push ( head , k ) { let tem = new Node ( ) ; tem . data = k ; tem . next = head ; head = tem ; return head ; }
function display ( head ) { let curr = head ; while ( curr != null ) { document . write ( curr . data + " " ) ; curr = curr . next ; } }
let head = null ; head = push ( head , 7 ) ; head = push ( head , 3 ) ; head = push ( head , 8 ) ; head = push ( head , 6 ) ; head = push ( head , 9 ) ; head = rearrange ( head ) ; display ( head ) ;
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
var left = null ;
function printlist ( head ) { while ( head != null ) { document . write ( head . data + " " ) ; if ( head . next != null ) { document . write ( " " ) ; } head = head . next ; } document . write ( " " ) ; }
function rearrange ( head ) { if ( head != null ) { left = head ; reorderListUtil ( left ) ; } } function reorderListUtil ( right ) { if ( right == null ) { return ; } reorderListUtil ( right . next ) ;
if ( left == null ) { return ; }
if ( left != right && left . next != right ) { var temp = left . next ; left . next = right ; right . next = temp ; left = temp ;
} else { if ( left . next == right ) {
left . next . next = null ; left = null ; } else {
left . next = null ; left = null ; } } }
var head = new Node ( 1 ) ; head . next = new Node ( 2 ) ; head . next . next = new Node ( 3 ) ; head . next . next . next = new Node ( 4 ) ; head . next . next . next . next = new Node ( 5 ) ;
printlist ( head ) ;
rearrange ( head ) ;
printlist ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function newNode ( key ) { var temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
function rearrangeEvenOdd ( head ) {
if ( head == null ) return null ;
var odd = head ; var even = head . next ;
var evenFirst = even ; while ( 1 == 1 ) {
if ( odd == null || even == null || ( even . next ) == null ) { odd . next = evenFirst ; break ; }
odd . next = even . next ; odd = even . next ;
if ( odd . next == null ) { even . next = null ; odd . next = evenFirst ; break ; }
even . next = odd . next ; even = odd . next ; } return head ; }
function printlist ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } document . write ( " " ) ; }
var head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; document . write ( " " ) ; printlist ( head ) ; head = rearrangeEvenOdd ( head ) ; document . write ( " " ) ; printlist ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function newNode ( data ) { var new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
function addWithCarry ( head ) {
if ( head == null ) return 1 ;
var res = head . data + addWithCarry ( head . next ) ;
head . data = res % 10 ; return parseInt ( res / 10 ) ; }
function addOne ( head ) {
var carry = addWithCarry ( head ) ; var newNodes = null ;
if ( carry > 0 ) { newNodes = newNode ( carry ) ; newNodes . next = head ;
return newNodes ; } return head ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data ) ; node = node . next ; } document . write ( " " ) ; }
var head = newNode ( 1 ) ; head . next = newNode ( 9 ) ; head . next . next = newNode ( 9 ) ; head . next . next . next = newNode ( 9 ) ; document . write ( " " ) ; printList ( head ) ; head = addOne ( head ) ; document . write ( " " ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( val ) { this . data = val ; this . arbit = null ; this . next = null ; } }
function reverse ( head ) { var prev = null , current = head , next = null ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } return prev ; }
function populateArbit ( head ) {
head = reverse ( head ) ;
var max = head ;
var temp = head . next ; while ( temp != null ) {
temp . arbit = max ;
if ( max . data < temp . data ) max = temp ;
temp = temp . next ; }
return reverse ( head ) ; }
function printNextArbitPointers ( node ) { document . write ( " " ) ; while ( node != null ) { document . write ( node . data + " " ) ; if ( node . next != null ) document . write ( node . next . data + " " ) ; else document . write ( " " + " " ) ; if ( node . arbit != null ) document . write ( node . arbit . data ) ; else document . write ( " " ) ; document . write ( " " ) ; node = node . next ; } }
function newNode ( data ) { var new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
var head = newNode ( 5 ) ; head . next = newNode ( 10 ) ; head . next . next = newNode ( 2 ) ; head . next . next . next = newNode ( 3 ) ; head = populateArbit ( head ) ; document . write ( " " ) ; printNextArbitPointers ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . arbit = null ; this . next = null ; } } var maxNode ;
function populateArbit ( head ) {
if ( head == null ) return ;
if ( head . next == null ) { maxNode = head ; return ; }
populateArbit ( head . next ) ;
head . arbit = maxNode ;
if ( head . data > maxNode . data ) maxNode = head ; return ; }
function printNextArbitPointers ( node ) { document . write ( " " ) ; while ( node != null ) { document . write ( node . data + " " ) ; if ( node . next != null ) document . write ( node . next . data + " " ) ; else document . write ( " " + " " ) ; if ( node . arbit != null ) document . write ( node . arbit . data ) ; else document . write ( " " ) ; document . write ( " " ) ; node = node . next ; } }
var head = newNode ( 5 ) ; head . next = newNode ( 10 ) ; head . next . next = newNode ( 2 ) ; head . next . next . next = newNode ( 3 ) ; populateArbit ( head ) ; document . write ( " " ) ; printNextArbitPointers ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function deleteLast ( head , x ) { var temp = head , ptr = null ; while ( temp != null ) {
if ( temp . data == x ) ptr = temp ; temp = temp . next ; }
if ( ptr != null && ptr . next == null ) { temp = head ; while ( temp . next != ptr ) temp = temp . next ; temp . next = null ; }
if ( ptr != null && ptr . next != null ) { ptr . data = ptr . next . data ; temp = ptr . next ; ptr . next = ptr . next . next ; } }
function newNode ( x ) { var node = new Node ( ) ; node . data = x ; node . next = null ; return node ; }
function display ( head ) { var temp = head ; if ( head == null ) { document . write ( " " ) ; return ; } while ( temp != null ) { document . write ( temp . data + " " ) ; temp = temp . next ; } document . write ( " " ) ; }
var head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; head . next . next . next . next . next = newNode ( 4 ) ; head . next . next . next . next . next . next = newNode ( 4 ) ; document . write ( " " ) ; display ( head ) ; deleteLast ( head , 4 ) ; document . write ( " " ) ; display ( head ) ;
function flattenList2 ( head ) { var headcop = head ; var save = new Stack ( ) ; save . push ( head ) ; var prev = null ; while ( ! save . isEmpty ( ) ) { var temp = save . pop ( ) ; if ( temp . next ) save . push ( temp . next ) ; if ( temp . down ) save . push ( temp . down ) ; if ( prev != null ) prev . next = temp ; prev = temp ; } return headcop ; }
class Node { constructor ( d ) { this . data = d ; this . next = null ; } }
function getLength ( node ) { var size = 0 ; while ( node != null ) { node = node . next ; size ++ ; } return size ; }
function paddZeros ( sNode , diff ) { if ( sNode == null ) return null ; var zHead = new Node ( 0 ) ; diff -- ; var temp = zHead ; while ( ( diff -- ) != 0 ) { temp . next = new Node ( 0 ) ; temp = temp . next ; } temp . next = sNode ; return zHead ; }
function subtractLinkedListHelper ( l1 , l2 ) { if ( l1 == null && l2 == null && borrow == false ) return null ; var previous = subtractLinkedListHelper ( ( l1 != null ) ? l1 . next : null , ( l2 != null ) ? l2 . next : null ) ; var d1 = l1 . data ; var d2 = l2 . data ; var sub = 0 ;
if ( borrow ) { d1 -- ; borrow = false ; }
if ( d1 < d2 ) { borrow = true ; d1 = d1 + 10 ; }
sub = d1 - d2 ;
var current = new Node ( sub ) ;
current . next = previous ; return current ; }
function subtractLinkedList ( l1 , l2 ) {
if ( l1 == null && l2 == null ) return null ;
var len1 = getLength ( l1 ) ; var len2 = getLength ( l2 ) ; var lNode = null , sNode = null ; var temp1 = l1 ; var temp2 = l2 ;
if ( len1 != len2 ) { lNode = len1 > len2 ? l1 : l2 ; sNode = len1 > len2 ? l2 : l1 ; sNode = paddZeros ( sNode , Math . abs ( len1 - len2 ) ) ; } else {
while ( l1 != null && l2 != null ) { if ( l1 . data != l2 . data ) { lNode = l1 . data > l2 . data ? temp1 : temp2 ; sNode = l1 . data > l2 . data ? temp2 : temp1 ; break ; } l1 = l1 . next ; l2 = l2 . next ; } }
borrow = false ; return subtractLinkedListHelper ( lNode , sNode ) ; }
function printList ( head ) { var temp = head ; while ( temp != null ) { document . write ( temp . data + " " ) ; temp = temp . next ; } }
var head = new Node ( 1 ) ; head . next = new Node ( 0 ) ; head . next . next = new Node ( 0 ) ; var head2 = new Node ( 1 ) ; var result = subtractLinkedList ( head , head2 ) ; printList ( result ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function newNode ( data ) { var new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
function partition ( head , x ) {
var smallerHead = null , smallerLast = null ; var greaterLast = null , greaterHead = null ; var equalHead = null , equalLast = null ;
while ( head != null ) {
if ( head . data == x ) { if ( equalHead == null ) equalHead = equalLast = head ; else { equalLast . next = head ; equalLast = equalLast . next ; } }
else if ( head . data < x ) { if ( smallerHead == null ) smallerLast = smallerHead = head ; else { smallerLast . next = head ; smallerLast = head ; }
} else { if ( greaterHead == null ) greaterLast = greaterHead = head ; else { greaterLast . next = head ; greaterLast = head ; } } head = head . next ; }
if ( greaterLast != null ) greaterLast . next = null ;
if ( smallerHead == null ) { if ( equalHead == null ) return greaterHead ; equalLast . next = greaterHead ; return equalHead ; }
if ( equalHead == null ) { smallerLast . next = greaterHead ; return smallerHead ; }
smallerLast . next = equalHead ; equalLast . next = greaterHead ; return smallerHead ; }
function printList ( head ) { var temp = head ; while ( temp != null ) { document . write ( temp . data + " " ) ; temp = temp . next ; } }
var head = newNode ( 10 ) ; head . next = newNode ( 4 ) ; head . next . next = newNode ( 5 ) ; head . next . next . next = newNode ( 30 ) ; head . next . next . next . next = newNode ( 2 ) ; head . next . next . next . next . next = newNode ( 50 ) ; var x = 3 ; head = partition ( head , x ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function getLoopstart ( loop_node , head ) { var ptr1 = loop_node ; var ptr2 = loop_node ;
var k = 1 , i ; while ( ptr1 . next != ptr2 ) { ptr1 = ptr1 . next ; k ++ ; }
ptr1 = head ;
ptr2 = head ; for ( i = 0 ; i < k ; i ++ ) ptr2 = ptr2 . next ;
while ( ptr2 != ptr1 ) { ptr1 = ptr1 . next ; ptr2 = ptr2 . next ; } return ptr1 ; }
function detectAndgetLoopstarting ( head ) { var slow_p = head , fast_p = head , loop_start = null ;
while ( slow_p != null && fast_p != null && fast_p . next != null ) { slow_p = slow_p . next ; fast_p = fast_p . next . next ;
if ( slow_p == fast_p ) { loop_start = getLoopstart ( slow_p , head ) ; break ; } }
return loop_start ; }
function isPalindromeUtil ( head , loop_start ) { var ptr = head ; var s = [ ] ;
var count = 0 ; while ( ptr != loop_start count != 1 ) { s . push ( ptr . data ) ; if ( ptr == loop_start ) count = 1 ; ptr = ptr . next ; } ptr = head ; count = 0 ;
while ( ptr != loop_start count != 1 ) {
var stk = s . pop ( ) ; if ( ptr . data == stk ) ;
else { s . push ( stk ) ; return false ; } if ( ptr == loop_start ) count = 1 ; ptr = ptr . next ; }
return true ; }
function isPalindrome ( head ) {
var loop_start = detectAndgetLoopstarting ( head ) ;
return isPalindromeUtil ( head , loop_start ) ; } function newNode ( key ) { var temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
var head = newNode ( 50 ) ; head . next = newNode ( 20 ) ; head . next . next = newNode ( 15 ) ; head . next . next . next = newNode ( 20 ) ; head . next . next . next . next = newNode ( 50 ) ;
head . next . next . next . next . next = head . next . next ; if ( isPalindrome ( head ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function countCommon ( a , b ) { var count = 0 ;
for ( ; a != null && b != null ; a = a . next , b = b . next )
if ( a . data == b . data ) ++ count ; else break ; return count ; }
function maxPalindrome ( head ) { var result = 0 ; var prev = null , curr = head ;
while ( curr != null ) {
var next = curr . next ; curr . next = prev ;
result = Math . max ( result , 2 * countCommon ( prev , next ) + 1 ) ;
result = Math . max ( result , 2 * countCommon ( curr , next ) ) ;
prev = curr ; curr = next ; } return result ; }
function newNode ( key ) { var temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
var head = newNode ( 2 ) ; head . next = newNode ( 4 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 2 ) ; head . next . next . next . next . next = newNode ( 15 ) ; document . write ( maxPalindrome ( head ) ) ;
var list = [ ] ;
list . push ( 1 ) ; list . push ( 2 ) ; list . push ( 3 ) ;
for ( var i = 0 ; i < list . length ; i ++ ) { document . write ( list [ i ] + " " ) ; }
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function newNode ( x ) { var temp = new Node ( ) ; temp . data = x ; temp . next = null ; return temp ; }
function printList ( head ) { var temp = head ; while ( temp != null ) { document . write ( temp . data + " " ) ; temp = temp . next ; } document . write ( " " ) ; }
function moveToEnd ( head , key ) {
var pKey = head ;
var pCrawl = head ; while ( pCrawl != null ) {
if ( pCrawl != pKey && pCrawl . data != key ) { pKey . data = pCrawl . data ; pCrawl . data = key ; pKey = pKey . next ; }
if ( pKey . data != key ) pKey = pKey . next ;
pCrawl = pCrawl . next ; } }
var head = newNode ( 10 ) ; head . next = newNode ( 20 ) ; head . next . next = newNode ( 10 ) ; head . next . next . next = newNode ( 30 ) ; head . next . next . next . next = newNode ( 40 ) ; head . next . next . next . next . next = newNode ( 10 ) ; head . next . next . next . next . next . next = newNode ( 60 ) ; document . write ( " " ) ; printList ( head ) ; var key = 10 ; moveToEnd ( head , key ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( val ) { this . data = val ; this . next = null ; } } var root ;
function keyToEnd ( head , key ) {
var tail = head ; if ( head == null ) { return null ; } while ( tail . next != null ) { tail = tail . next ; }
var last = tail ; var current = head ; var prev = null ;
var prev2 = null ;
while ( current != tail ) { if ( current . data == key && prev2 == null ) { prev = current ; current = current . next ; head = current ; last . next = prev ; last = last . next ; last . next = null ; prev = null ; } else { if ( current . data == key && prev2 != null ) { prev = current ; current = current . next ; prev2 . next = current ; last . next = prev ; last = last . next ; last . next = null ; } else if ( current != tail ) { prev2 = current ; current = current . next ; } } } return head ; }
function display ( root ) { while ( root != null ) { document . write ( root . data + " " ) ; root = root . next ; } }
root = new Node ( 5 ) ; root . next = new Node ( 2 ) ; root . next . next = new Node ( 2 ) ; root . next . next . next = new Node ( 7 ) ; root . next . next . next . next = new Node ( 2 ) ; root . next . next . next . next . next = new Node ( 2 ) ; root . next . next . next . next . next . next = new Node ( 2 ) ; var key = 2 ; document . write ( " " ) ; display ( root ) ; document . write ( " " ) ; root = keyToEnd ( root , key ) ; display ( root ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function freeList ( node ) { while ( node != null ) { next = node . next ; node = next ; } return node ; }
function deleteKthNode ( head , k ) {
if ( head == null ) return null ; if ( k == 1 ) { head = freeList ( head ) ; return null ; }
var ptr = head , prev = null ;
var count = 0 ; while ( ptr != null ) {
count ++ ;
if ( k == count ) {
prev . next = ptr . next ;
count = 0 ; }
if ( count != 0 ) prev = ptr ; ptr = prev . next ; } return head ; }
function displayList ( head ) { temp = head ; while ( temp != null ) { document . write ( temp . data + " " ) ; temp = temp . next ; } }
function newNode ( x ) { temp = new Node ( ) ; temp . data = x ; temp . next = null ; return temp ; }
head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; head . next . next . next . next . next = newNode ( 6 ) ; head . next . next . next . next . next . next = newNode ( 7 ) ; head . next . next . next . next . next . next . next = newNode ( 8 ) ; var k = 3 ; head = deleteKthNode ( head , k ) ; displayList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function LinkedListLength ( head ) { while ( head != null && head . next != null ) { head = head . next . next ; } if ( head == null ) return 0 ; return 1 ; }
function push ( head , info ) {
node = new Node ( ) ;
node . next = ( head ) ;
( head ) = node ; }
head = null ;
push ( head , 4 ) ; push ( head , 5 ) ; push ( head , 7 ) ; push ( head , 2 ) ; push ( head , 9 ) ; push ( head , 6 ) ; push ( head , 1 ) ; push ( head , 2 ) ; push ( head , 0 ) ; push ( head , 5 ) ; push ( head , 5 ) ; var check = LinkedListLength ( head ) ;
if ( check == 0 ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
class Node { constructor ( ) { this . data ; this . next ; } } let head ; let n , sum ;
function push ( head_ref , new_data ) {
let new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; head = head_ref ; }
function sumOfLastN_Nodes ( head ) {
if ( head == null ) return ;
sumOfLastN_Nodes ( head . next ) ;
if ( n > 0 ) {
sum = sum + head . data ;
-- n ; } }
function sumOfLastN_NodesUtil ( head , n ) {
if ( n <= 0 ) return 0 ; sum = 0 ;
sumOfLastN_Nodes ( head ) ;
return sum ; }
head = null ;
push ( head , 12 ) ; push ( head , 4 ) ; push ( head , 8 ) ; push ( head , 6 ) ; push ( head , 10 ) ; n = 2 ; document . write ( " " + n + " " + sumOfLastN_NodesUtil ( head , n ) ) ;
class Node { constructor ( ) { let data , next ; } }
function push ( head_ref , new_data ) {
let new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; return head_ref ; }
function sumOfLastN_NodesUtil ( head , n ) {
if ( n <= 0 ) return 0 ; let st = [ ] ; let sum = 0 ;
while ( head != null ) {
st . push ( head . data ) ;
head = head . next ; }
while ( n -- > 0 ) { sum += st [ st . length - 1 ] ; st . pop ( ) ; }
return sum ; }
let head = null ;
head = push ( head , 12 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 6 ) ; head = push ( head , 10 ) ; let n = 2 ; document . write ( " " + n + " " + sumOfLastN_NodesUtil ( head , n ) ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } var head ;
function push ( head_ref , new_data ) {
var new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; head = head_ref ; } function reverseList ( head_ref ) { var current , prev , next ; current = head_ref ; prev = null ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } head_ref = prev ; head = head_ref ; }
function sumOfLastN_NodesUtil ( n ) {
if ( n <= 0 ) return 0 ;
reverseList ( head ) ; var sum = 0 ; var current = head ;
while ( current != null && n -- > 0 ) {
sum += current . data ;
current = current . next ; }
reverseList ( head ) ;
return sum ; }
push ( head , 12 ) ; push ( head , 4 ) ; push ( head , 8 ) ; push ( head , 6 ) ; push ( head , 10 ) ; var n = 2 ; document . write ( " " + n + " " + sumOfLastN_NodesUtil ( n ) ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } var head ;
function push ( head_ref , new_data ) {
new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; head = head_ref ; }
function sumOfLastN_NodesUtil ( head , n ) {
if ( n <= 0 ) return 0 ; var sum = 0 , len = 0 ; temp = head ;
while ( temp != null ) { len ++ ; temp = temp . next ; }
var c = len - n ; temp = head ;
while ( temp != null && c -- > 0 ) {
temp = temp . next ; }
while ( temp != null ) {
sum += temp . data ;
temp = temp . next ; }
return sum ; }
push ( head , 12 ) ; push ( head , 4 ) ; push ( head , 8 ) ; push ( head , 6 ) ; push ( head , 10 ) ; var n = 2 ; document . write ( " " + n + " " + sumOfLastN_NodesUtil ( head , n ) ) ;
class Node {
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } document . write ( " " ) ; }
function mergeKLists ( arr , last ) {
for ( let i = 1 ; i <= last ; i ++ ) { while ( true ) {
let head_0 = arr [ 0 ] ; let head_i = arr [ i ] ;
if ( head_i == null ) break ;
if ( head_0 . data >= head_i . data ) { arr [ i ] = head_i . next ; head_i . next = head_0 ; arr [ 0 ] = head_i ; } else {
while ( head_0 . next != null ) {
if ( head_0 . next . data >= head_i . data ) { arr [ i ] = head_i . next ; head_i . next = head_0 . next ; head_0 . next = head_i ; break ; }
head_0 = head_0 . next ;
if ( head_0 . next == null ) { arr [ i ] = head_i . next ; head_i . next = null ; head_0 . next = head_i ; head_0 . next . next = null ; break ; } } } } } return arr [ 0 ] ; }
let k = 3 ;
let n = 4 ;
let arr = new Array ( k ) ; arr [ 0 ] = new Node ( 1 ) ; arr [ 0 ] . next = new Node ( 3 ) ; arr [ 0 ] . next . next = new Node ( 5 ) ; arr [ 0 ] . next . next . next = new Node ( 7 ) ; arr [ 1 ] = new Node ( 2 ) ; arr [ 1 ] . next = new Node ( 4 ) ; arr [ 1 ] . next . next = new Node ( 6 ) ; arr [ 1 ] . next . next . next = new Node ( 8 ) ; arr [ 2 ] = new Node ( 0 ) ; arr [ 2 ] . next = new Node ( 9 ) ; arr [ 2 ] . next . next = new Node ( 10 ) ; arr [ 2 ] . next . next . next = new Node ( 11 ) ;
head = mergeKLists ( arr , k - 1 ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function newNode ( key ) { temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } }
function merge ( h1 , h2 ) { if ( h1 == null ) return h2 ; if ( h2 == null ) return h1 ;
if ( h1 . data < h2 . data ) { h1 . next = merge ( h1 . next , h2 ) ; return h1 ; } else { h2 . next = merge ( h1 , h2 . next ) ; return h2 ; } }
head1 = newNode ( 1 ) ; head1 . next = newNode ( 3 ) ; head1 . next . next = newNode ( 5 ) ;
head2 = newNode ( 0 ) ; head2 . next = newNode ( 2 ) ; head2 . next . next = newNode ( 4 ) ;
mergedhead = merge ( head1 , head2 ) ; printList ( mergedhead ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function newNode ( key ) { var temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } }
function mergeUtil ( h1 , h2 ) {
if ( h1 . next == null ) { h1 . next = h2 ; return h1 ; }
var curr1 = h1 , next1 = h1 . next ; var curr2 = h2 , next2 = h2 . next ; while ( next1 != null && curr2 != null ) {
if ( ( curr2 . data ) >= ( curr1 . data ) && ( curr2 . data ) <= ( next1 . data ) ) { next2 = curr2 . next ; curr1 . next = curr2 ; curr2 . next = next1 ;
curr1 = curr2 ; curr2 = next2 ; } else {
if ( next1 . next != null ) { next1 = next1 . next ; curr1 = curr1 . next ; }
else { next1 . next = curr2 ; return h1 ; } } } return h1 ; }
function merge ( h1 , h2 ) { if ( h1 == null ) return h2 ; if ( h2 == null ) return h1 ;
if ( h1 . data < h2 . data ) return mergeUtil ( h1 , h2 ) ; else return mergeUtil ( h2 , h1 ) ; }
var head1 = newNode ( 1 ) ; head1 . next = newNode ( 3 ) ; head1 . next . next = newNode ( 5 ) ;
var head2 = newNode ( 0 ) ; head2 . next = newNode ( 2 ) ; head2 . next . next = newNode ( 4 ) ;
var mergedhead = merge ( head1 , head2 ) ; printList ( mergedhead ) ;
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
function swapNodes ( head_ref , currX , currY , prevY ) {
head_ref = currY ;
prevY . next = currX ;
var temp = currY . next ; currY . next = currX . next ; currX . next = temp ; return head_ref ; }
function recurSelectionSort ( head ) {
if ( head . next == null ) return head ;
var min = head ;
var beforeMin = null ; var ptr ;
for ( ptr = head ; ptr . next != null ; ptr = ptr . next ) {
if ( ptr . next . data < min . data ) { min = ptr . next ; beforeMin = ptr ; } }
if ( min != head ) head = swapNodes ( head , head , min , beforeMin ) ;
head . next = recurSelectionSort ( head . next ) ; return head ; }
function sort ( head_ref ) {
if ( ( head_ref ) == null ) return null ;
head_ref = recurSelectionSort ( head_ref ) ; return head_ref ; }
function push ( head_ref , new_data ) {
var new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ;
( head_ref ) = new_node ; return head_ref ; }
function printList ( head ) { while ( head != null ) { document . write ( head . data + " " ) ; head = head . next ; } }
var head = null ;
head = push ( head , 6 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 12 ) ; head = push ( head , 10 ) ; document . write ( " " ) ; printList ( head ) ;
head = sort ( head ) ; document . write ( " " ) ; printList ( head ) ;
class Node {
constructor ( d ) { this . data = d ; this . next = null ; } }
function insertAtMid ( x ) {
if ( head == null ) head = new Node ( x ) ; else {
var newNode = new Node ( x ) ; var ptr = head ; var len = 0 ;
while ( ptr != null ) { len ++ ; ptr = ptr . next ; }
var count = ( ( len % 2 ) == 0 ) ? ( len / 2 ) : ( len + 1 ) / 2 ; ptr = head ;
while ( count -- > 1 ) ptr = ptr . next ;
newNode . next = ptr . next ; ptr . next = newNode ; } }
function display ( ) { var temp = head ; while ( temp != null ) { document . write ( temp . data + " " ) ; temp = temp . next ; } }
head = new Node ( 1 ) ; head . next = new Node ( 2 ) ; head . next . next = new Node ( 4 ) ; head . next . next . next = new Node ( 5 ) ; document . write ( " " + " " ) ; display ( ) ; var x = 3 ; insertAtMid ( x ) ; document . write ( " " + " " ) ; display ( ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function getNode ( data ) {
var newNode = new Node ( ) ;
newNode . data = data ; newNode . next = null ; return newNode ; }
function insertAfterNthNode ( head , n , x ) {
if ( head == null ) return ;
var newNode = getNode ( x ) ; var ptr = head ; var len = 0 , i ;
while ( ptr != null ) { len ++ ; ptr = ptr . next ; }
ptr = head ; for ( i = 1 ; i <= ( len - n ) ; i ++ ) ptr = ptr . next ;
newNode . next = ptr . next ; ptr . next = newNode ; }
function printList ( head ) { while ( head != null ) { document . write ( head . data + " " ) ; head = head . next ; } }
var head = getNode ( 1 ) ; head . next = getNode ( 3 ) ; head . next . next = getNode ( 4 ) ; head . next . next . next = getNode ( 5 ) ; var n = 4 , x = 2 ; document . write ( " " ) ; printList ( head ) ; insertAfterNthNode ( head , n , x ) ; document . write ( ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function getNode ( data ) {
var newNode = new Node ( ) ;
function insertAfterNthNode ( head , n , x ) {
if ( head == null ) return ;
var newNode = getNode ( x ) ;
var slow_ptr = head ; var fast_ptr = head ;
for ( var i = 1 ; i <= n - 1 ; i ++ ) fast_ptr = fast_ptr . next ;
while ( fast_ptr . next != null ) {
slow_ptr = slow_ptr . next ; fast_ptr = fast_ptr . next ; }
newNode . next = slow_ptr . next ; slow_ptr . next = newNode ; }
function printList ( head ) { while ( head != null ) { document . write ( head . data + " " ) ; head = head . next ; } }
var head = getNode ( 1 ) ; head . next = getNode ( 3 ) ; head . next . next = getNode ( 4 ) ; head . next . next . next = getNode ( 5 ) ; var n = 4 , x = 2 ; document . write ( " " ) ; printList ( head ) ; insertAfterNthNode ( head , n , x ) ; document . write ( " " ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } var tail ;
function rotateHelper ( blockHead , blockTail , d , k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { var temp = blockHead ; for ( i = 1 ; temp . next . next != null && i < k - 1 ; i ++ ) temp = temp . next ; blockTail . next = blockHead ; tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , k ) ; }
if ( d < 0 ) { blockTail . next = blockHead ; tail = blockHead ; return rotateHelper ( blockHead . next , blockHead , d + 1 , k ) ; } return blockHead ; }
function rotateByBlocks ( head , k , d ) {
if ( head == null head . next == null ) return head ;
if ( d == 0 ) return head ; var temp = head ; tail = null ;
var i ; for ( i = 1 ; temp . next != null && i < k ; i ++ ) temp = temp . next ;
var nextBlock = temp . next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , i ) ; else head = rotateHelper ( head , temp , d % k , k ) ;
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
function push ( head_ref , new_data ) { var new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } }
var head = null ;
for ( i = 9 ; i > 0 ; i -= 1 ) head = push ( head , i ) ; document . write ( " " ) ; printList ( head ) ;
var k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function countRotation ( head ) {
let count = 0 ;
let min = head . data ;
while ( head != null ) {
if ( min > head . data ) break ; count ++ ;
head = head . next ; } return count ; }
function push ( head , data ) {
let newNode = new Node ( ) ;
newNode . data = data ;
newNode . next = ( head ) ;
( head ) = newNode ; return head ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } }
let head = null ;
head = push ( head , 12 ) ; head = push ( head , 11 ) ; head = push ( head , 8 ) ; head = push ( head , 5 ) ; head = push ( head , 18 ) ; head = push ( head , 15 ) ; printList ( head ) ; document . write ( " " ) ; document . write ( " " ) ;
document . write ( countRotation ( head ) + " " ) ;
class Node { constructor ( val ) { this . data = val ; this . next = null ; } } var head ;
function setMiddleHead ( ) { if ( head == null ) return ;
one_node = head ;
two_node = head ;
prev = null ; while ( two_node != null && two_node . next != null ) {
prev = one_node ;
two_node = two_node . next . next ;
one_node = one_node . next ; }
prev . next = prev . next . next ; one_node . next = head ; head = one_node ; }
function push ( new_data ) {
new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function printList ( ptr ) { while ( ptr != null ) { document . write ( ptr . data + " " ) ; ptr = ptr . next ; } document . write ( " " ) ; }
head = null ; var i ; for ( i = 5 ; i > 0 ; i -- ) push ( i ) ; document . write ( " " ) ; printList ( head ) ; setMiddleHead ( ) ; document . write ( " " ) ; printList ( head ) ;
function InsertAfter ( prev_Node , new_data ) {
if ( prev_Node == null ) { document . write ( " " ) ; return ; }
let new_node = new Node ( new_data ) ;
new_node . next = prev_Node . next ;
prev_Node . next = new_node ;
new_node . prev = prev_Node ;
if ( new_node . next != null ) new_node . next . prev = new_node ; }
class Node { constructor ( ) { this . data = 0 ; this . next = this . prev = null ; } }
function insert ( head_ref , data ) {
new_node = new Node ( ) ;
new_node . data = data ;
if ( head_ref == null ) { new_node . next = new_node ; new_node . prev = new_node ; } else {
last = ( head_ref ) . prev ;
new_node . next = head_ref ; new_node . prev = last ;
last . next = ( head_ref ) . prev = new_node ; }
head_ref = new_node ; return head_ref ; }
function merge ( first , second ) {
if ( first == null ) return second ;
if ( second == null ) return first ;
if ( first . data < second . data ) { first . next = merge ( first . next , second ) ; first . next . prev = first ; first . prev = null ; return first ; } else { second . next = merge ( first , second . next ) ; second . next . prev = second ; second . prev = null ; return second ; } }
function mergeUtil ( head1 , head2 ) {
if ( head1 == null ) return head2 ;
if ( head2 == null ) return head1 ;
last_node = null ; if ( head1 . prev . data < head2 . prev . data ) last_node = head2 . prev ; else last_node = head1 . prev ;
head1 . prev . next = head2 . prev . next = null ;
finalHead = merge ( head1 , head2 ) ;
finalHead . prev = last_node ; last_node . next = finalHead ; return finalHead ; }
function printList ( head ) { temp = head ; while ( temp . next != head ) { document . write ( temp . data + " " ) ; temp = temp . next ; } document . write ( temp . data + " " ) ; }
head1 = null , head2 = null ;
head1 = insert ( head1 , 8 ) ; head1 = insert ( head1 , 5 ) ; head1 = insert ( head1 , 3 ) ; head1 = insert ( head1 , 1 ) ;
head2 = insert ( head2 , 11 ) ; head2 = insert ( head2 , 9 ) ; head2 = insert ( head2 , 7 ) ; head2 = insert ( head2 , 2 ) ; newHead = mergeUtil ( head1 , head2 ) ; document . write ( " " ) ; printList ( newHead ) ;
class Node { constructor ( val ) { this . data = val ; this . prev = null ; this . next = null ; } } function newNode ( val ) { var temp = new Node ( ) ; temp . data = val ; temp . prev = temp . next = null ; return temp ; } function printList ( head ) { while ( head . next != null ) { document . write ( head . data + " " ) ; head = head . next ; } document . write ( head . data ) ; }
function insert ( head , val ) { var temp = newNode ( val ) ; temp . next = head ; ( head ) . prev = temp ; ( head ) = temp ; return head ; }
function reverseList ( head ) { var left = head , right = head ;
while ( right . next != null ) right = right . next ;
while ( left != right && left . prev != right ) {
var t = left . data ; left . data = right . data ; right . data = t ;
left = left . next ;
right = right . prev ; } return head ; }
var head = newNode ( 5 ) ; head = insert ( head , 4 ) ; head = insert ( head , 3 ) ; head = insert ( head , 2 ) ; head = insert ( head , 1 ) ; printList ( head ) ; document . write ( " " ) ; head = reverseList ( head ) ; printList ( head ) ;
class Node { constructor ( val ) { this . data = val ; this . prev = null ; this . next = null ; } }
function getNode ( data ) {
var newNode = new Node ( ) ;
newNode . data = data ; newNode . prev = newNode . next = null ; return newNode ; }
function sortedInsert ( head_ref , newNode ) { var current ;
if ( head_ref == null ) head_ref = newNode ;
else if ( ( head_ref ) . data >= newNode . data ) { newNode . next = head_ref ; newNode . next . prev = newNode ; head_ref = newNode ; } else { current = head_ref ;
while ( current . next != null && current . next . data < newNode . data ) current = current . next ;
newNode . next = current . next ;
if ( current . next != null ) newNode . next . prev = newNode ; current . next = newNode ; newNode . prev = current ; } return head_ref ; }
function insertionSort ( head_ref ) {
var sorted = null ;
var current = head_ref ; while ( current != null ) {
var next = current . next ;
current . prev = current . next = null ;
sorted = sortedInsert ( sorted , current ) ;
current = next ; }
head_ref = sorted ; return head_ref ; }
function printList ( head ) { while ( head != null ) { document . write ( head . data + " " ) ; head = head . next ; } }
function push ( head_ref , new_data ) {
var new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ; new_node . prev = null ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
var head = null ;
head = push ( head , 9 ) ; head = push ( head , 3 ) ; head = push ( head , 5 ) ; head = push ( head , 10 ) ; head = push ( head , 12 ) ; head = push ( head , 8 ) ; document . write ( " " ) ; printList ( head ) ; head = insertionSort ( head ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . prev = null ; this . next = null ; } }
function push ( head_ref , new_data ) { var new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; new_node . prev = null ; if ( head_ref != null ) head_ref . prev = new_node ; head_ref = new_node ; return head_ref ; }
function isPalindrome ( left ) { if ( left == null ) return true ;
var right = left ; while ( right . next != null ) right = right . next ; while ( left != right ) { if ( left . data != right . data ) return false ; left = left . next ; right = right . prev ; } return true ; }
var head = null ; head = push ( head , ' ' ) ; head = push ( head , ' ' ) ; head = push ( head , ' ' ) ; head = push ( head , ' ' ) ; head = push ( head , ' ' ) ; if ( isPalindrome ( head ) ) document . write ( " " ) ; else document . write ( " " ) ;
class Node { constructor ( item ) { this . data = item ; this . left = null ; this . right = null ; } } var root = null ;
function printLevels ( node , low , high ) { var Q = [ ] ;
var marker = new Node ( 4 ) ;
var level = 1 ;
Q . push ( node ) ; Q . push ( marker ) ;
while ( Q . length > 0 ) {
var n = Q [ 0 ] ; Q . shift ( ) ;
if ( n == marker ) {
document . write ( " " ) ; level ++ ;
if ( Q . length == 0 level > high ) { break ; }
Q . push ( marker ) ;
continue ; }
if ( level >= low ) { document . write ( n . data + " " ) ; }
if ( n . left != null ) { Q . push ( n . left ) ; } if ( n . right != null ) { Q . push ( n . right ) ; } } }
root = new Node ( 20 ) ; root . left = new Node ( 8 ) ; root . right = new Node ( 22 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 12 ) ; root . left . right . left = new Node ( 10 ) ; root . left . right . right = new Node ( 14 ) ; document . write ( " " ) ; printLevels ( root , 2 , 3 ) ;
class Node { constructor ( item ) { this . data = item ; this . left = null ; this . right = null ; } } var root = null ; function printKDistant ( node , k ) { if ( node == null k < 0 ) { return ; } if ( k == 0 ) { document . write ( node . data + " " ) ; return ; } printKDistant ( node . left , k - 1 ) ; printKDistant ( node . right , k - 1 ) ; }
root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 8 ) ; printKDistant ( root , 2 ) ;
class Node { constructor ( data ) { this . left = null ; this . right = null ; this . data = data ; } }
function printKDistant ( root , klevel ) { let q = [ ] ; let level = 1 ; let flag = false ; q . push ( root ) ;
q . push ( null ) ; while ( q . length > 0 ) { let temp = q [ 0 ] ;
if ( level == klevel && temp != null ) { flag = true ; document . write ( temp . data + " " ) ; } q . shift ( ) ; if ( temp == null ) { if ( q [ 0 ] != null ) q . push ( null ) ; level += 1 ;
if ( level > klevel ) break ; } else { if ( temp . left != null ) q . push ( temp . left ) ; if ( temp . right != null ) q . push ( temp . right ) ; } } document . write ( " " ) ; return flag ; }
let root = newNode ( 20 ) ; root . left = newNode ( 10 ) ; root . right = newNode ( 30 ) ; root . left . left = newNode ( 5 ) ; root . left . right = newNode ( 15 ) ; root . left . right . left = newNode ( 12 ) ; root . right . left = newNode ( 25 ) ; root . right . right = newNode ( 40 ) ; document . write ( " " ) ; let ret = printKDistant ( root , 1 ) ; if ( ret == false ) document . write ( " " + " " + " " ) ; document . write ( " " ) ; ret = printKDistant ( root , 2 ) ; if ( ret == false ) document . write ( " " + " " + " " ) ; document . write ( " " ) ; ret = printKDistant ( root , 3 ) ; if ( ret == false ) document . write ( " " + " " + " " ) ; document . write ( " " ) ; ret = printKDistant ( root , 6 ) ; if ( ret == false ) document . write ( " " + " " + " " ) ;
class Node { constructor ( ) { this . data = 0 ; this . left = null ; this . right = null ; } } ;
function printLeafNodes ( root ) {
if ( root == null ) return ;
if ( root . left == null && root . right == null ) { document . write ( root . data + " " ) ; return ; }
if ( root . left != null ) printLeafNodes ( root . left ) ;
if ( root . right != null ) printLeafNodes ( root . right ) ; }
var root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . right . left = newNode ( 5 ) ; root . right . right = newNode ( 8 ) ; root . right . left . left = newNode ( 6 ) ; root . right . left . right = newNode ( 7 ) ; root . right . right . left = newNode ( 9 ) ; root . right . right . right = newNode ( 10 ) ;
printLeafNodes ( root ) ;
class Node { constructor ( item ) { this . data = item ; this . left = null ; this . right = null ; } } var root = null ;
function printkdistanceNodeDown ( node , k ) {
if ( node == null k < 0 ) { return ; }
if ( k == 0 ) { document . write ( node . data ) ; document . write ( " " ) ; return ; }
printkdistanceNodeDown ( node . left , k - 1 ) ; printkdistanceNodeDown ( node . right , k - 1 ) ; }
function printkdistanceNode ( node , target , k ) {
if ( node == null ) { return - 1 ; }
if ( node == target ) { printkdistanceNodeDown ( node , k ) ; return 0 ; }
var dl = printkdistanceNode ( node . left , target , k ) ;
if ( dl != - 1 ) {
if ( dl + 1 == k ) { document . write ( node . data ) ; document . write ( " " ) ; }
else { printkdistanceNodeDown ( node . right , k - dl - 2 ) ; }
return 1 + dl ; }
var dr = printkdistanceNode ( node . right , target , k ) ; if ( dr != - 1 ) { if ( dr + 1 == k ) { document . write ( node . data ) ; document . write ( " " ) ; } else { printkdistanceNodeDown ( node . left , k - dr - 2 ) ; } return 1 + dr ; }
return - 1 ; }
root = new Node ( 20 ) ; root . left = new Node ( 8 ) ; root . right = new Node ( 22 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 12 ) ; root . left . right . left = new Node ( 10 ) ; root . left . right . right = new Node ( 14 ) ; var target = root . left . right ; printkdistanceNode ( root , target , 2 ) ;
class Node { constructor ( item ) { this . data = item ; this . left = null ; this . right = null ; } } class BinaryTree { constructor ( ) { this . root = null ; }
printSingles ( node ) {
if ( node == null ) { return ; }
if ( node . left != null && node . right != null ) { this . printSingles ( node . left ) ; this . printSingles ( node . right ) ; }
else if ( node . right != null ) { document . write ( node . right . data + " " ) ; this . printSingles ( node . right ) ; }
else if ( node . left != null ) { document . write ( node . left . data + " " ) ; this . printSingles ( node . left ) ; } } }
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . right = new Node ( 4 ) ; tree . root . right . left = new Node ( 5 ) ; tree . root . right . left . right = new Node ( 6 ) ; tree . printSingles ( tree . root ) ;
class Node { constructor ( item ) { this . left = null ; this . right = null ; this . data = item ; } } let root ;
function kDistantFromLeafUtil ( node , path , visited , pathLen , k ) {
if ( node == null ) return ;
path [ pathLen ] = node . data ; visited [ pathLen ] = false ; pathLen ++ ;
if ( node . left == null && node . right == null && ( pathLen - k - 1 ) >= 0 && visited [ pathLen - k - 1 ] == false ) { document . write ( path [ pathLen - k - 1 ] + " " ) ; visited [ pathLen - k - 1 ] = true ; return ; }
kDistantFromLeafUtil ( node . left , path , visited , pathLen , k ) ; kDistantFromLeafUtil ( node . right , path , visited , pathLen , k ) ; }
function printKDistantfromLeaf ( node , k ) { let path = new Array ( 1000 ) ; path . fill ( 0 ) ; let visited = new Array ( 1000 ) ; visited . fill ( false ) ; kDistantFromLeafUtil ( node , path , visited , 0 , k ) ; }
root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; root . right . left . right = new Node ( 8 ) ; document . write ( " " ) ; printKDistantfromLeaf ( root , 2 ) ;
let COUNT = 10 ;
class Node {
constructor ( data ) { this . data = data ; this . left = null ; this . right = null ; } }
function print2DUtil ( root , space ) {
if ( root == null ) return ;
space += COUNT ;
print2DUtil ( root . right , space ) ;
document . write ( " " ) ; for ( let i = COUNT ; i < space ; i ++ ) document . write ( " " ) ; document . write ( root . data + " " ) ;
print2DUtil ( root . left , space ) ; }
function print2D ( root ) {
print2DUtil ( root , 0 ) ; }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; root . left . left . left = new Node ( 8 ) ; root . left . left . right = new Node ( 9 ) ; root . left . right . left = new Node ( 10 ) ; root . left . right . right = new Node ( 11 ) ; root . right . left . left = new Node ( 12 ) ; root . right . left . right = new Node ( 13 ) ; root . right . right . left = new Node ( 14 ) ; root . right . right . right = new Node ( 15 ) ; print2D ( root ) ;
class Node { constructor ( item ) { this . data = item ; this . left = null ; this . right = null ; } }
function leftViewUtil ( node , level ) {
if ( node == null ) { return ; }
if ( max_level < level ) { document . write ( " " + node . data ) ; max_level = level ; }
leftViewUtil ( node . left , level + 1 ) ; leftViewUtil ( node . right , level + 1 ) ; }
function leftView ( ) { leftViewUtil ( root , 1 ) ; }
root = new Node ( 12 ) ; root . left = new Node ( 10 ) ; root . right = new Node ( 30 ) ; root . right . left = new Node ( 25 ) ; root . right . right = new Node ( 40 ) ; leftView ( ) ;
function rotate ( arr , N , X ) {
let nextPower = 1 ;
while ( nextPower <= N ) nextPower *= 2 ;
if ( X == 1 ) return nextPower - N ;
let prevPower = nextPower / 2 ;
return 2 * ( N - prevPower ) + 1 ; }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ; let X = 1 ; let N = arr . length ; document . write ( rotate ( arr , N , X ) ) ;
function print ( mat ) {
for ( let i = 0 ; i < mat . length ; i ++ ) {
for ( let j = 0 ; j < mat [ 0 ] . length ; j ++ )
document . write ( mat [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
function performSwap ( mat , i , j ) { let N = mat . length ;
let ei = N - 1 - i ;
let ej = N - 1 - j ;
let temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ ej ] [ i ] ; mat [ ej ] [ i ] = mat [ ei ] [ ej ] ; mat [ ei ] [ ej ] = mat [ j ] [ ei ] ; mat [ j ] [ ei ] = temp ; }
function rotate ( mat , N , K ) {
K = K % 4 ;
while ( K -- > 0 ) {
for ( let i = 0 ; i < N / 2 ; i ++ ) {
for ( let j = i ; j < N - i - 1 ; j ++ ) {
if ( i != j && ( i + j ) != N - 1 ) {
performSwap ( mat , i , j ) ; } } } }
print ( mat ) ; }
let K = 5 ; let mat = [ [ 1 , 2 , 3 , 4 ] , [ 6 , 7 , 8 , 9 ] , [ 11 , 12 , 13 , 14 ] , [ 16 , 17 , 18 , 19 ] , ] ; let N = mat . length ; rotate ( mat , N , K ) ;
function findMaximumZeros ( str , n ) {
var c0 = 0 ; var i ;
for ( i = 0 ; i < n ; ++ i ) { if ( str [ i ] == ' ' ) c0 ++ ; }
if ( c0 == n ) {
document . write ( n ) ; return ; }
var s = str + str ;
var mx = 0 ; var j ;
for ( i = 0 ; i < n ; ++ i ) {
var cs = 0 ; var ce = 0 ;
for ( j = i ; j < i + n ; ++ j ) { if ( s [ j ] == ' ' ) cs ++ ; else break ; }
for ( j = i + n - 1 ; j >= i ; -- j ) { if ( s [ j ] == ' ' ) ce ++ ; else break ; }
var val = cs + ce ;
mx = Math . max ( val , mx ) ; }
document . write ( mx ) ; }
var s = " " ;
var n = s . length ; findMaximumZeros ( s , n ) ;
function findMaximumZeros ( str , n ) {
var c0 = 0 ; for ( var i = 0 ; i < n ; ++ i ) { if ( str [ i ] == ' ' ) c0 ++ ; }
if ( c0 == n ) {
document . write ( n ) ; return ; }
var mx = 0 ;
var cnt = 0 ; for ( var i = 0 ; i < n ; i ++ ) { if ( str [ i ] == ' ' ) cnt ++ ; else { mx = Math . max ( mx , cnt ) ; cnt = 0 ; } }
mx = Math . max ( mx , cnt ) ;
var start = 0 , end = n - 1 ; cnt = 0 ;
while ( str [ start ] != ' ' && start < n ) { cnt ++ ; start ++ ; }
while ( str [ end ] != ' ' && end >= 0 ) { cnt ++ ; end -- ; }
mx = Math . max ( mx , cnt ) ;
document . write ( mx ) ; }
var s = " " ;
var n = s . length ; findMaximumZeros ( s , n ) ;
function rotateMatrix ( mat ) { let i = 0 ;
for ( let rows = 0 ; rows < mat . length ; rows ++ ) {
reverse ( mat [ rows ] , 0 , mat [ rows ] . length - 1 ) ;
reverse ( mat [ rows ] , 0 , i - 1 ) ;
reverse ( mat [ rows ] , i , mat [ rows ] . length - 1 ) ;
i ++ ; }
for ( let rows = 0 ; rows < mat . length ; rows ++ ) { for ( let cols = 0 ; cols < mat [ rows ] . length ; cols ++ ) { document . write ( mat [ rows ] [ cols ] + " " ) ; } document . write ( " " ) ; } }
let mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] ; rotateMatrix ( mat ) ;
class Node { constructor ( data ) { this . data = data ; this . left = this . right = null ; } }
function getLeafCount ( node ) {
if ( node == null ) { return 0 ; }
let q = [ ] ;
let count = 0 ; q . push ( node ) ; while ( q . length != 0 ) { let temp = q . shift ( ) ; if ( temp . left != null ) { q . push ( temp . left ) ; } if ( temp . right != null ) { q . push ( temp . right ) ; } if ( temp . left == null && temp . right == null ) { count ++ ; } } return count ; }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ;
document . write ( getLeafCount ( root ) ) ;
function rotateArray ( arr , N ) {
let v = arr ;
v . sort ( ( a , b ) => a - b ) ;
for ( let i = 1 ; i <= N ; ++ i ) {
let x = arr [ N - 1 ] ; i = N - 1 ; while ( i -- ) { arr [ i ] = arr [ i - 1 ] ; arr [ 0 ] = x ; }
let isEqual = arr . every ( ( e , i ) => { return arr [ i ] == v [ i ] } ) if ( isEqual ) { document . write ( " " ) ; return ; } }
document . write ( " " ) ; }
let arr = [ 3 , 4 , 5 , 1 , 2 ] ;
let N = arr . length ;
rotateArray ( arr , N ) ;
function findLargestRotation ( num ) {
let ans = num ;
let len = Math . floor ( Math . log10 ( num ) + 1 ) ; let x = Math . pow ( 10 , len - 1 ) ;
for ( let i = 1 ; i < len ; i ++ ) {
let lastDigit = num % 10 ;
num = parseInt ( num / 10 ) ;
num += ( lastDigit * x ) ;
if ( num > ans ) { ans = num ; } }
document . write ( ans ) ; }
let N = 657 ; findLargestRotation ( N ) ;
function numberOfDigit ( N ) {
let digit = 0 ;
while ( N > 0 ) {
digit ++ ;
N = Math . floor ( N / 10 ) ; } return digit ; }
function rotateNumberByK ( N , K ) {
let X = numberOfDigit ( N ) ;
K = ( ( K % X ) + X ) % X ;
let left_no = Math . floor ( N / Math . floor ( Math . pow ( 10 , X - K ) ) ) ;
N = N % Math . floor ( Math . pow ( 10 , X - K ) ) ;
let left_digit = numberOfDigit ( left_no ) ;
N = ( N * Math . floor ( Math . pow ( 10 , left_digit ) ) ) + left_no ; document . write ( N ) ; }
let N = 12345 , K = 7 ;
rotateNumberByK ( N , K ) ;
function minMovesToSort ( arr , N ) {
let count = 0 ;
let index = 0 ;
for ( let i = 0 ; i < N - 1 ; i ++ ) {
if ( arr [ i ] < arr [ i + 1 ] ) {
count ++ ;
index = i ; } }
if ( count == 0 ) { document . write ( " " ) ; } else if ( count == N - 1 ) { document . write ( N - 1 ) ; } else if ( count == 1 && arr [ 0 ] <= arr [ N - 1 ] ) { document . write ( index + 1 ) ; }
else { document . write ( " " ) ; } }
let arr = [ 2 , 1 , 5 , 4 , 2 ] ; let N = arr . length ;
minMovesToSort ( arr , N ) ;
let N = 3 ;
function findMaximumDiagonalSumOMatrixf ( A ) {
let maxDiagonalSum = Number . MIN_VALUE ;
for ( let i = 0 ; i < N ; i ++ ) {
let curr = 0 ;
for ( let j = 0 ; j < N ; j ++ ) {
curr += A [ j ] [ ( i + j ) % N ] ; }
maxDiagonalSum = Math . max ( maxDiagonalSum , curr ) ; }
for ( let i = 0 ; i < N ; i ++ ) {
let curr = 0 ;
for ( let j = 0 ; j < N ; j ++ ) {
curr += A [ ( i + j ) % N ] [ j ] ; }
maxDiagonalSum = Math . max ( maxDiagonalSum , curr ) ; } return maxDiagonalSum ; }
let mat = [ [ 1 , 1 , 2 ] , [ 2 , 1 , 2 ] , [ 1 , 2 , 2 ] ] ; document . write ( findMaximumDiagonalSumOMatrixf ( mat ) ) ;
class Node { constructor ( data ) { this . data = data ; this . next = this . right = null ; } }
function countLeaves ( node ) {
if ( node == null ) return 0 ;
if ( node . left == null && node . right == null ) return 1 ;
return countLeaves ( node . left ) + countLeaves ( node . right ) ; }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ;
document . write ( countLeaves ( root ) ) ;
function MaxSum ( arr , n , k ) { var i , max_sum = 0 , sum = 0 ;
for ( i = 0 ; i < k ; i ++ ) { sum += arr [ i ] ; } max_sum = sum ;
while ( i < n ) {
sum = sum - arr [ i - k ] + arr [ i ] ; if ( max_sum < sum ) { max_sum = sum ; } i ++ ; }
return max_sum ; }
function gcd ( n1 , n2 ) {
if ( n2 == 0 ) { return n1 ; }
else { return gcd ( n2 , n1 % n2 ) ; } }
function RotateArr ( arr , n , d ) {
var i = 0 , j = 0 ; d = d % n ;
var no_of_sets = gcd ( d , n ) ; for ( i = 0 ; i < no_of_sets ; i ++ ) { var temp = arr [ i ] ; j = i ;
while ( true ) { var k = j + d ; if ( k >= n ) k = k - n ; if ( k == i ) break ; arr [ j ] = arr [ k ] ; j = k ; }
arr [ j ] = temp ; }
return arr ; }
function performQuery ( arr , Q , q ) { var N = arr . length ;
for ( i = 0 ; i < q ; i ++ ) {
if ( Q [ i ] [ 0 ] == 1 ) { arr = RotateArr ( arr , N , Q [ i ] [ 1 ] ) ;
for ( var t = 0 ; t < arr . length ; t ++ ) { document . write ( arr [ t ] + " " ) ; } document . write ( " " ) ; }
else { document . write ( MaxSum ( arr , N , Q [ i ] [ 1 ] ) + " " ) ; } } }
var arr = [ 1 , 2 , 3 , 4 , 5 ] ; var q = 5 ;
var Q = [ [ 1 , 2 ] , [ 2 , 3 ] , [ 1 , 3 ] , [ 1 , 1 ] , [ 2 , 4 ] ] ;
performQuery ( arr , Q , q ) ;
function getMinimumRemoval ( str ) { var n = str . length ;
var ans = n ;
if ( n % 2 === 0 ) {
var freqEven = new Array ( 128 ) . fill ( 0 ) ; var freqOdd = new Array ( 128 ) . fill ( 0 ) ;
for ( var i = 0 ; i < n ; i ++ ) { if ( i % 2 === 0 ) { freqEven [ str [ i ] . charCodeAt ( 0 ) ] ++ ; } else { freqOdd [ str [ i ] . charCodeAt ( 0 ) ] ++ ; } }
var evenMax = 0 , oddMax = 0 ; for ( var chr = " " . charCodeAt ( 0 ) ; chr <= " " . charCodeAt ( 0 ) ; chr ++ ) { evenMax = Math . max ( evenMax , freqEven [ chr ] ) ; oddMax = Math . max ( oddMax , freqOdd [ chr ] ) ; }
ans = ans - evenMax - oddMax ; }
else {
var freq = new Array ( 128 ) . fill ( 0 ) ; for ( var i = 0 ; i < n ; i ++ ) { freq [ str [ i ] . charCodeAt ( 0 ) ] ++ ; }
var strMax = 0 ; for ( var chr = " " . charCodeAt ( 0 ) ; chr <= " " . charCodeAt ( 0 ) ; chr ++ ) { strMax = Math . max ( strMax , freq [ chr ] ) ; }
ans = ans - strMax ; } return ans ; }
var str = " " ; document . write ( getMinimumRemoval ( str ) ) ;
function findAltSubSeq ( s ) {
var n = s . length , ans = - 1000000000 ;
for ( var i = 0 ; i < 10 ; i ++ ) { for ( var j = 0 ; j < 10 ; j ++ ) { var cur = 0 , f = 0 ;
for ( var k = 0 ; k < n ; k ++ ) { if ( f == 0 && s [ k ] - ' ' == i ) { f = 1 ;
cur ++ ; } else if ( f == 1 && s [ k ] - ' ' == j ) { f = 0 ;
cur ++ ; } }
if ( i != j && cur % 2 == 1 )
cur -- ;
ans = Math . max ( cur , ans ) ; } }
return ans ; }
var s = " " ; document . write ( findAltSubSeq ( s ) ) ;
function getFirstElement ( a , N , K , M ) {
K %= N ; let index ;
if ( K >= M )
index = ( N - K ) + ( M - 1 ) ;
else
index = ( M - K - 1 ) ; let result = a [ index ] ;
return result ; }
let a = [ 1 , 2 , 3 , 4 , 5 ] ; let N = 5 ; let K = 3 , M = 2 ; document . write ( getFirstElement ( a , N , K , M ) ) ;
function getFirstElement ( a , N , K , M ) {
K %= N ;
var index = ( K + M - 1 ) % N ; var result = a [ index ] ;
return result ; }
var a = [ 3 , 4 , 5 , 23 ] ;
var N = a . length ;
var K = 2 , M = 1 ;
document . write ( getFirstElement ( a , N , K , M ) ) ;
function left_rotate ( arr ) { let last = arr [ 1 ] ; for ( let i = 3 ; i < 6 ; i = i + 2 ) { arr [ i - 2 ] = arr [ i ] ; } arr [ 6 - 1 ] = last ; }
function right_rotate ( arr ) { let start = arr [ 6 - 2 ] ; for ( let i = 6 - 4 ; i >= 0 ; i = i - 2 ) { arr [ i + 2 ] = arr [ i ] ; } arr [ 0 ] = start ; }
function rotate ( arr ) { left_rotate ( arr ) ; right_rotate ( arr ) ; for ( let i = 0 ; i < 6 ; i ++ ) { document . write ( arr [ i ] + " " ) ; } }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 ] ; rotate ( arr ) ;
function maximumMatchingPairs ( perm1 , perm2 , n ) {
var left = Array ( n ) ; var right = Array ( n ) ;
var mp1 = new Map ( ) , mp2 = new Map ( ) ; for ( var i = 0 ; i < n ; i ++ ) { mp1 . set ( perm1 [ i ] , i ) ; } for ( var j = 0 ; j < n ; j ++ ) { mp2 . set ( perm2 [ j ] , j ) ; } for ( var i = 0 ; i < n ; i ++ ) {
var idx2 = mp2 . get ( perm1 [ i ] ) ; var idx1 = i ; if ( idx1 == idx2 ) {
left [ i ] = 0 ; right [ i ] = 0 ; } else if ( idx1 < idx2 ) {
left [ i ] = ( n - ( idx2 - idx1 ) ) ; right [ i ] = ( idx2 - idx1 ) ; } else {
left [ i ] = ( idx1 - idx2 ) ; right [ i ] = ( n - ( idx1 - idx2 ) ) ; } }
var freq1 = new Map ( ) , freq2 = new Map ( ) ; for ( var i = 0 ; i < n ; i ++ ) { if ( freq1 . has ( left [ i ] ) ) freq1 . set ( left [ i ] , freq1 . get ( left [ i ] ) + 1 ) else freq1 . set ( left [ i ] , 1 ) if ( freq2 . has ( right [ i ] ) ) freq2 . set ( right [ i ] , freq2 . get ( right [ i ] ) + 1 ) else freq2 . set ( right [ i ] , 1 ) } var ans = 0 ; for ( var i = 0 ; i < n ; i ++ ) {
ans = Math . max ( ans , Math . max ( freq1 . get ( left [ i ] ) , freq2 . get ( right [ i ] ) ) ) ; }
return ans ; }
var P1 = [ 5 , 4 , 3 , 2 , 1 ] ; var P2 = [ 1 , 2 , 3 , 4 , 5 ] ; var n = P1 . length ;
document . write ( maximumMatchingPairs ( P1 , P2 , n ) ) ;
function reverse ( arr , s , e ) { while ( s < e ) { var tem = arr [ s ] ; arr [ s ] = arr [ e ] ; arr [ e ] = tem ; s = s + 1 ; e = e - 1 ; } }
function fun ( arr , k ) { var n = 4 - 1 ; var v = n - k ; if ( v >= 0 ) { reverse ( arr , 0 , v ) ; reverse ( arr , v + 1 , n ) ; reverse ( arr , 0 , n ) ; } }
arr [ 0 ] = 1 ; arr [ 1 ] = 2 ; arr [ 2 ] = 3 ; arr [ 3 ] = 4 ; for ( i = 0 ; i < 4 ; i ++ ) { fun ( arr , i ) ; document . write ( " " ) ; for ( j = 0 ; j < 4 ; j ++ ) { document . write ( arr [ j ] + " " ) ; } document . write ( " " ) ; }
function countRotation ( arr , n ) { for ( let i = 1 ; i < n ; i ++ ) {
if ( arr [ i ] < arr [ i - 1 ] ) {
return i ; } }
return 0 ; }
let arr1 = [ 4 , 5 , 1 , 2 , 3 ] ; document . write ( countRotation ( arr1 , arr1 . length ) ) ;
function countRotation ( arr , low , high ) {
if ( low > high ) { return 0 ; } let mid = low + Math . floor ( ( high - low ) / 2 ) ;
if ( mid < high && arr [ mid ] > arr [ mid + 1 ] ) {
return mid + 1 ; }
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) {
return mid ; }
if ( arr [ mid ] > arr [ low ] ) {
return countRotation ( arr , mid + 1 , high ) ; } if ( arr [ mid ] < arr [ high ] ) {
return countRotation ( arr , low , mid - 1 ) ; } else {
let rightIndex = countRotation ( arr , mid + 1 , high ) ; let leftIndex = countRotation ( arr , low , mid - 1 ) ; if ( rightIndex == 0 ) { return leftIndex ; } return rightIndex ; } }
let arr1 = [ 4 , 5 , 1 , 2 , 3 ] ; document . write ( countRotation ( arr1 , 0 , arr1 . length - 1 ) ) ;
const MAX = 100005 ;
var seg = Array ( 4 * MAX ) . fill ( 0 ) ;
function build ( node , l , r , a ) { if ( l == r ) seg [ node ] = a [ l ] ; else { var mid = parseInt ( ( l + r ) / 2 ) ; build ( 2 * node , l , mid , a ) ; build ( 2 * node + 1 , mid + 1 , r , a ) ; seg [ node ] = ( seg [ 2 * node ] seg [ 2 * node + 1 ] ) ; } }
function query ( node , l , r , start , end , a ) {
if ( l > end r < start ) return 0 ; if ( start <= l && r <= end ) return seg [ node ] ;
var mid = parseInt ( ( l + r ) / 2 ) ;
return ( ( query ( 2 * node , l , mid , start , end , a ) ) | ( query ( 2 * node + 1 , mid + 1 , r , start , end , a ) ) ) ; }
function orsum ( a , n , q , k ) {
build ( 1 , 0 , n - 1 , a ) ;
for ( j = 0 ; j < q ; j ++ ) {
var i = k [ j ] % ( n / 2 ) ;
var sec = query ( 1 , 0 , n - 1 , n / 2 - i , n - i - 1 , a ) ;
var first = ( query ( 1 , 0 , n - 1 , 0 , n / 2 - 1 - i , a ) | query ( 1 , 0 , n - 1 , n - i , n - 1 , a ) ) ; var temp = sec + first ;
document . write ( temp + " " ) ; } }
var a = [ 7 , 44 , 19 , 86 , 65 , 39 , 75 , 101 ] ; var n = a . length ; var q = 2 ; var k = [ 4 , 2 ] ; orsum ( a , n , q , k ) ;
function maximumEqual ( a , b , n ) {
let store = Array . from ( { length : 1e5 } , ( _ , i ) => 0 ) ;
for ( let i = 0 ; i < n ; i ++ ) { store [ b [ i ] ] = i + 1 ; }
let ans = Array . from ( { length : 1e5 } , ( _ , i ) => 0 ) ;
for ( let i = 0 ; i < n ; i ++ ) {
let d = Math . abs ( store [ a [ i ] ] - ( i + 1 ) ) ;
if ( store [ a [ i ] ] < i + 1 ) { d = n - d ; }
ans [ d ] ++ ; } let finalans = 0 ;
for ( let i = 0 ; i < 1e5 ; i ++ ) finalans = Math . max ( finalans , ans [ i ] ) ;
document . write ( finalans + " " ) ; }
let A = [ 6 , 7 , 3 , 9 , 5 ] ; let B = [ 7 , 3 , 9 , 5 , 6 ] ; let size = A . length ;
maximumEqual ( A , B , size ) ;
function rotatedSumQuery ( arr , n , query , Q ) {
let prefix = [ ] ;
for ( let i = 0 ; i < n ; i ++ ) { prefix [ i ] = arr [ i ] ; prefix [ i + n ] = arr [ i ] ; }
for ( let i = 1 ; i < 2 * n ; i ++ ) prefix [ i ] += prefix [ i - 1 ] ;
let start = 0 ; for ( let q = 0 ; q < Q ; q ++ ) {
if ( query [ q ] [ 0 ] == 1 ) { let k = query [ q ] [ 1 ] ; start = ( start + k ) % n ; }
else if ( query [ q ] [ 0 ] == 2 ) { let L , R ; L = query [ q ] [ 1 ] ; R = query [ q ] [ 2 ] ;
if ( start + L == 0 )
document . write ( prefix [ start + R ] + " " ) ; else
document . write ( prefix [ start + R ] - prefix [ start + L - 1 ] + " " ) ; } } }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 ] ;
let Q = 5 ;
let query = [ [ 2 , 1 , 3 ] , [ 1 , 3 ] , [ 2 , 0 , 3 ] , [ 1 , 4 ] , [ 2 , 3 , 5 ] ] ; let n = arr . length ; rotatedSumQuery ( arr , n , query , Q ) ;
function isConversionPossible ( s1 , s2 , x ) { let diff = 0 , n ; n = s1 . length ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( s1 [ i ] == s2 [ i ] ) continue ;
diff = ( ( s2 [ i ] . charCodeAt ( 0 ) - s1 [ i ] . charCodeAt ( 0 ) ) + 26 ) % 26 ;
if ( diff > x ) { document . write ( " " ) ; return ; } } document . write ( " " ) ; }
let s1 = " " ; let s2 = " " ; let x = 6 ;
isConversionPossible ( s1 , s2 , x ) ;
function RightRotate ( a , n , k ) {
k = k % n ; for ( let i = 0 ; i < n ; i ++ ) { if ( i < k ) {
document . write ( a [ n + i - k ] + " " ) ; } else {
document . write ( ( a [ i - k ] ) + " " ) ; } } document . write ( " " ) ; }
let Array = [ 1 , 2 , 3 , 4 , 5 ] ; let N = Array . length ; let K = 2 ; RightRotate ( Array , N , K ) ;
function countRotation ( n ) { let count = 0 ;
do { let digit = n % 10 ;
if ( digit == 0 ) count ++ ; n = parseInt ( n / 10 ) ; } while ( n != 0 ) ; return count ; }
let n = 10203 ; document . write ( countRotation ( n ) ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function push ( head_ref , new_data ) {
var new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ;
( head_ref ) = new_node ; return head_ref ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } document . write ( " " ) ; }
function rightRotate ( head , k ) {
if ( head == null ) return head ;
var tmp = head ; var len = 1 ; while ( tmp . next != null ) { tmp = tmp . next ; len ++ ; }
if ( k > len ) k = k % len ;
k = len - k ;
if ( k == 0 k == len ) return head ;
var current = head ; var cnt = 1 ; while ( cnt < k && current != null ) { current = current . next ; cnt ++ ; }
if ( current == null ) return head ;
var kthnode = current ;
tmp . next = head ;
head = kthnode . next ;
kthnode . next = null ;
return head ; }
var head = null ; head = push ( head , 5 ) ; head = push ( head , 4 ) ; head = push ( head , 3 ) ; head = push ( head , 2 ) ; head = push ( head , 1 ) ; var k = 2 ;
var updated_head = rightRotate ( head , k ) ;
printList ( updated_head ) ;
function isPossible ( a , n ) {
if ( n <= 2 ) return true ; var flag = 0 ;
for ( i = 0 ; i < n - 2 ; i ++ ) { if ( ! ( a [ i ] > a [ i + 1 ] && a [ i + 1 ] > a [ i + 2 ] ) ) { flag = 1 ; break ; } }
if ( flag == 0 ) return true ; flag = 0 ;
for ( i = 0 ; i < n - 2 ; i ++ ) { if ( ! ( a [ i ] < a [ i + 1 ] && a [ i + 1 ] < a [ i + 2 ] ) ) { flag = 1 ; break ; } }
if ( flag == 0 ) return true ;
var val1 = Number . MAX_VALUE , mini = - 1 , val2 = Number . MIN_VALUE , maxi = 0 ; for ( i = 0 ; i < n ; i ++ ) { if ( a [ i ] < val1 ) { mini = i ; val1 = a [ i ] ; } if ( a [ i ] > val2 ) { maxi = i ; val2 = a [ i ] ; } } flag = 1 ;
for ( i = 0 ; i < maxi ; i ++ ) { if ( a [ i ] > a [ i + 1 ] ) { flag = 0 ; break ; } }
if ( flag == 1 && maxi + 1 == mini ) { flag = 1 ;
for ( i = mini ; i < n - 1 ; i ++ ) { if ( a [ i ] > a [ i + 1 ] ) { flag = 0 ; break ; } } if ( flag == 1 ) return true ; } flag = 1 ;
for ( i = 0 ; i < mini ; i ++ ) { if ( a [ i ] < a [ i + 1 ] ) { flag = 0 ; break ; } }
if ( flag == 1 && maxi - 1 == mini ) { flag = 1 ;
for ( i = maxi ; i < n - 1 ; i ++ ) { if ( a [ i ] < a [ i + 1 ] ) { flag = 0 ; break ; } } if ( flag == 1 ) return true ; }
return false ; }
var a = [ 4 , 5 , 6 , 2 , 3 ] ; var n = a . length ; if ( isPossible ( a , n ) ) document . write ( " " ) ; else document . write ( " " ) ;
function cntRotations ( s , n ) {
let str = s + s ;
let pre = new Array ( 2 * n ) ; pre . fill ( 0 ) ;
for ( let i = 0 ; i < 2 * n ; i ++ ) { if ( i != 0 ) pre [ i ] += pre [ i - 1 ] ; if ( str [ i ] == ' ' str [ i ] == ' ' str [ i ] == ' ' str [ i ] == ' ' str [ i ] == ' ' ) { pre [ i ] ++ ; } }
let ans = 0 ;
for ( let i = n - 1 ; i < 2 * n - 1 ; i ++ ) {
let r = i , l = i - n ;
let x1 = pre [ r ] ; if ( l >= 0 ) x1 -= pre [ l ] ; r = i - parseInt ( n / 2 , 10 ) ;
let left = pre [ r ] ; if ( l >= 0 ) left -= pre [ l ] ;
let right = x1 - left ;
if ( left > right ) { ans ++ ; } }
return ans ; }
let s = " " ; let n = s . length ; document . write ( cntRotations ( s , n ) ) ;
function cntRotations ( s , n ) { let lh = 0 , rh = 0 , i , ans = 0 ;
for ( i = 0 ; i < parseInt ( n / 2 , 10 ) ; ++ i ) if ( s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' ) { lh ++ ; }
for ( i = parseInt ( n / 2 , 10 ) ; i < n ; ++ i ) if ( s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' ) { rh ++ ; }
if ( lh > rh ) ans ++ ;
for ( i = 1 ; i < n ; ++ i ) { if ( s [ i - 1 ] == ' ' s [ i - 1 ] == ' ' s [ i - 1 ] == ' ' s [ i - 1 ] == ' ' s [ i - 1 ] == ' ' ) { rh ++ ; lh -- ; } if ( s [ ( i - 1 + n / 2 ) % n ] == ' ' || s [ ( i - 1 + n / 2 ) % n ] == ' ' || s [ ( i - 1 + n / 2 ) % n ] == ' ' || s [ ( i - 1 + n / 2 ) % n ] == ' ' || s [ ( i - 1 + n / 2 ) % n ] == ' ' ) { rh -- ; lh ++ ; } if ( lh > rh ) ans ++ ; }
return ans ; }
let s = [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] ; let n = s . length ;
document . write ( cntRotations ( s , n ) ) ;
var size = 2 ;
function performQueries ( str , n , queries , q ) {
var ptr = 0 ;
for ( var i = 0 ; i < q ; i ++ ) {
if ( queries [ i ] [ 0 ] == 1 ) {
ptr = ( ptr + queries [ i ] [ 1 ] ) % n ; } else { var k = queries [ i ] [ 1 ] ;
var index = ( ptr + k - 1 ) % n ;
document . write ( str [ index ] + " " ) ; } } }
var str = " " ; var n = str . length ; var queries = [ [ 1 , 2 ] , [ 2 , 2 ] , [ 1 , 4 ] , [ 2 , 7 ] ] ; var q = queries . length ; performQueries ( str , n , queries , q ) ;
function ReverseArray ( arr , left , right ) { var temp ; while ( left < right ) { temp = arr [ left ] ; arr [ left ] = arr [ right ] ; arr [ right ] = temp ; left ++ ; right -- ; } }
function RotateAndCheck ( str1 , str2 , d ) { if ( str1 . length !== str2 . length ) return false ;
var left_rot_str1 = [ ] ; var right_rot_str1 = [ ] ; var left_flag = true , right_flag = true ; var str1_size = str1 . length ;
for ( var i = 0 ; i < str1_size ; i ++ ) { left_rot_str1 . push ( str1 [ i ] ) ; right_rot_str1 . push ( str1 [ i ] ) ; }
ReverseArray ( left_rot_str1 , 0 , d - 1 ) ; ReverseArray ( left_rot_str1 , d , str1_size - 1 ) ; ReverseArray ( left_rot_str1 , 0 , str1_size - 1 ) ;
ReverseArray ( right_rot_str1 , 0 , str1_size - d - 1 ) ; ReverseArray ( right_rot_str1 , str1_size - d , str1_size - 1 ) ; ReverseArray ( right_rot_str1 , 0 , str1_size - 1 ) ;
for ( var i = 0 ; i < str1_size ; i ++ ) {
if ( left_rot_str1 [ i ] !== str2 [ i ] ) { left_flag = false ; }
if ( right_rot_str1 [ i ] !== str2 [ i ] ) { right_flag = false ; } }
if ( left_flag right_flag ) return true ; return false ; }
var str1 = " " ; var str2 = " " ;
var d = 2 ;
d = d % str1 . length ; if ( RotateAndCheck ( str1 , str2 , d ) ) document . write ( " " ) ; else document . write ( " " ) ;
function countOddRotations ( n ) { var odd_count = 0 , even_count = 0 ; do { var digit = n % 10 ; if ( digit % 2 == 1 ) odd_count ++ ; else even_count ++ ; n = parseInt ( n / 10 ) ; } while ( n != 0 ) ; document . write ( " " + odd_count + " " ) ; document . write ( " " + even_count + " " ) ; }
var n = 1234 ; countOddRotations ( n ) ;
function numberOfDigits ( n ) { let cnt = 0 ; while ( n > 0 ) { cnt ++ ; n = parseInt ( n / 10 , 10 ) ; } return cnt ; }
function cal ( num ) { let digits = numberOfDigits ( num ) ; let powTen = Math . pow ( 10 , digits - 1 ) ; for ( let i = 0 ; i < digits - 1 ; i ++ ) { let firstDigit = parseInt ( num / powTen , 10 ) ;
let left = ( ( num * 10 ) + firstDigit ) - ( firstDigit * powTen * 10 ) ; document . write ( left + " " ) ;
num = left ; } }
let num = 1445 ; cal ( num ) ;
function CheckKCycles ( n , s ) { var ff = true ; var x = 0 ; for ( i = 1 ; i < n ; i ++ ) {
x = ( s . substring ( i ) + s . substring ( 0 , i ) ) . length ;
if ( x >= s . length ) { continue ; } ff = false ; break ; } if ( ff ) { document . write ( " " ) ; } else { document . write ( " " ) ; } }
var n = 3 ; var s = " " ; CheckKCycles ( n , s ) ;
class ListNode { constructor ( ) { this . data = 0 ; this . next = null ; } }
function rotateSubList ( A , m , n , k ) { var size = n - m + 1 ;
if ( k > size ) { k = k % size ; }
if ( k == 0 k == size ) { var head = A ; while ( head != null ) { document . write ( head . data ) ; head = head . next ; } return ; }
var link = null ; if ( m == 1 ) { link = A ; }
var c = A ;
var count = 0 ; var end = null ;
var pre = null ; while ( c != null ) { count ++ ;
if ( count == m - 1 ) { pre = c ; link = c . next ; } if ( count == n - k ) { if ( m == 1 ) { end = c ; A = c . next ; } else { end = c ;
pre . next = c . next ; } }
if ( count == n ) { var d = c . next ; c . next = link ; end . next = d ; var head = A ; while ( head != null ) { document . write ( head . data + " " ) ; head = head . next ; } return ; } c = c . next ; } }
function push ( head , val ) { var new_node = new ListNode ( ) ; new_node . data = val ; new_node . next = head ; head = new_node ; return head ; }
var head = null ; head = push ( head , 70 ) ; head = push ( head , 60 ) ; head = push ( head , 50 ) ; head = push ( head , 40 ) ; head = push ( head , 30 ) ; head = push ( head , 20 ) ; head = push ( head , 10 ) ; var tmp = head ; document . write ( " " ) ; while ( tmp != null ) { document . write ( tmp . data + " " ) ; tmp = tmp . next ; } document . write ( " " ) ; var m = 3 , n = 6 , k = 2 ; document . write ( " " ) ; rotateSubList ( head , m , n , k ) ;
function rightRotationDivisor ( N ) { let lastDigit = N % 10 ; let rightRotation = ( lastDigit * Math . pow ( 10 , Math . floor ( ( Math . log10 ( N ) ) ) ) + Math . floor ( N / 10 ) ) ; return ( rightRotation % N == 0 ) ; }
function generateNumbers ( m ) { for ( let i = Math . floor ( Math . pow ( 10 , ( m - 1 ) ) ) ; i < Math . floor ( Math . pow ( 10 , m ) ) ; i ++ ) if ( rightRotationDivisor ( i ) ) document . write ( i + " " ) ; }
let m = 3 ; generateNumbers ( m ) ;
class Node { constructor ( x ) { this . data = x ; this . left = null ; this . right = null ; } } let root ; let next = null ;
function populateNext ( node ) {
if ( node != null ) {
populateNext ( node . right ) ;
node . next = next ;
next = node ;
populateNext ( node . left ) ; } }
root = new Node ( 10 ) root . left = new Node ( 8 ) root . right = new Node ( 12 ) root . left . left = new Node ( 3 )
p = populateNext ( root )
ptr = root . left . left while ( ptr != null ) {
let print = ptr . next != null ? ptr . next . data : - 1 ; document . write ( " " + ptr . data + " " + print + " " ) ; ptr = ptr . next ; }
function generateNumbers ( m ) { let numbers = [ ] ; let k_max , x ; for ( let y = 0 ; y < 10 ; y ++ ) { k_max = Math . floor ( ( Math . pow ( 10 , m - 2 ) * ( 10 * y + 1 ) ) / Math . floor ( Math . pow ( 10 , m - 1 ) + y ) ) ; for ( let k = 1 ; k <= k_max ; k ++ ) { x = Math . floor ( ( y * ( Math . pow ( 10 , m - 1 ) - k ) ) / ( 10 * k - 1 ) ) ; if ( Math . floor ( ( y * ( Math . pow ( 10 , m - 1 ) - k ) ) % ( 10 * k - 1 ) ) == 0 ) numbers . push ( 10 * x + y ) ; } } numbers . sort ( function ( a , b ) { return a - b ; } ) ; for ( let i = 0 ; i < numbers . length ; i ++ ) document . write ( numbers [ i ] + " " ) ; }
let m = 3 ; generateNumbers ( m ) ;
let minIndex = - 1 ;
for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < minEle ) { minEle = arr [ i ] ; minIndex = i ; } } let flag1 = true ;
for ( let i = 1 ; i < minIndex ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag1 = false ; break ; } } let flag2 = true ;
for ( let i = minIndex + 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag2 = false ; break ; } }
if ( flag1 && flag2 && ( arr [ n - 1 ] < arr [ 0 ] ) ) document . write ( " " ) ; else document . write ( " " ) ; }
let arr = [ 3 , 4 , 5 , 1 , 2 ] ; let n = arr . length ;
checkIfSortRotated ( arr , n ) ;
var N = 4 ;
function rotate90Clockwise ( arr ) {
for ( j = 0 ; j < N ; j ++ ) { for ( i = N - 1 ; i >= 0 ; i -- ) document . write ( arr [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
var arr = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 ] ] ; rotate90Clockwise ( arr ) ;
function occurredOnce ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b ; } ) ;
if ( arr [ 0 ] != arr [ 1 ] ) document . write ( arr [ 0 ] + " " ) ;
for ( let i = 1 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i - 1 ] ) document . write ( arr [ i ] + " " ) ;
if ( arr [ n - 2 ] != arr [ n - 1 ] ) document . write ( arr [ n - 1 ] + " " ) ; }
let arr = [ 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ] ; let n = arr . length ; occurredOnce ( arr , n ) ;
function occurredOnce ( arr , n ) { let mp = new Map ( ) ;
for ( let i = 0 ; i < n ; i ++ ) { if ( mp . has ( arr [ i ] ) ) mp . set ( arr [ i ] , 1 + mp . get ( arr [ i ] ) ) ; else mp . set ( arr [ i ] , 1 ) ; }
for ( let [ key , value ] of mp . entries ( ) ) { if ( value == 1 ) document . write ( key + " " ) ; } }
let arr = [ 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ] ; let n = arr . length ; occurredOnce ( arr , n ) ;
function occurredOnce ( arr , n ) { var i = 1 , len = n ;
if ( arr [ 0 ] == arr [ len - 1 ] ) { i = 2 ; len -- ; }
for ( ; i < n ; i ++ )
if ( arr [ i ] == arr [ i - 1 ] ) i ++ ;
else document . write ( arr [ i - 1 ] + " " ) ;
if ( arr [ n - 1 ] != arr [ 0 ] && arr [ n - 1 ] != arr [ n - 2 ] ) document . write ( arr [ n - 1 ] ) ; }
var arr = [ 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ] ; var n = arr . length ; occurredOnce ( arr , n ) ;
function rvereseArray ( arr , start , end ) { while ( start < end ) { let temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
function printArray ( arr , size ) { for ( let i = 0 ; i < size ; i ++ ) document . write ( arr [ i ] + " " ) ; }
function splitArr ( arr , k , n ) { rvereseArray ( arr , 0 , n - 1 ) ; rvereseArray ( arr , 0 , n - k - 1 ) ; rvereseArray ( arr , n - k , n - 1 ) ; }
let arr = new Array ( 12 , 10 , 5 , 6 , 52 , 36 ) ; let n = arr . length ; let k = 2 ;
splitArr ( arr , k , n ) ; printArray ( arr , n ) ;
function isRotation ( a , b ) { var n = a . length ; var m = b . length ; if ( n != m ) return false ;
var lps = Array . from ( { length : n } , ( _ , i ) => 0 ) ;
var len = 0 ; var i = 1 ;
lps [ 0 ] = 0 ;
while ( i < n ) { if ( a . charAt ( i ) == b . charAt ( len ) ) { lps [ i ] = ++ len ; ++ i ; } else { if ( len == 0 ) { lps [ i ] = 0 ; ++ i ; } else { len = lps [ len - 1 ] ; } } } i = 0 ;
for ( k = lps [ n - 1 ] ; k < m ; ++ k ) { if ( b . charAt ( k ) != a . charAt ( i ++ ) ) return false ; } return true ; }
var s1 = " " ; var s2 = " " ; document . write ( isRotation ( s1 , s2 ) ? " " : " " ) ;
function countRotationsDivBy8 ( n ) { let len = n . length ; let count = 0 ;
if ( len == 1 ) { let oneDigit = n [ 0 ] - ' ' ; if ( oneDigit % 8 == 0 ) return 1 ; return 0 ; }
if ( len == 2 ) {
let first = ( n [ 0 ] - ' ' ) * 10 + ( n [ 1 ] - ' ' ) ;
let second = ( n [ 1 ] - ' ' ) * 10 + ( n [ 0 ] - ' ' ) ; if ( first % 8 == 0 ) count ++ ; if ( second % 8 == 0 ) count ++ ; return count ; }
let threeDigit ; for ( let i = 0 ; i < ( len - 2 ) ; i ++ ) { threeDigit = ( n [ i ] - ' ' ) * 100 + ( n [ i + 1 ] - ' ' ) * 10 + ( n [ i + 2 ] - ' ' ) ; if ( threeDigit % 8 == 0 ) count ++ ; }
threeDigit = ( n [ len - 1 ] - ' ' ) * 100 + ( n [ 0 ] - ' ' ) * 10 + ( n [ 1 ] - ' ' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
threeDigit = ( n [ len - 2 ] - ' ' ) * 100 + ( n [ len - 1 ] - ' ' ) * 10 + ( n [ 0 ] - ' ' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
return count ; }
let n = " " ; document . write ( " " + countRotationsDivBy8 ( n ) ) ;
function minimunMoves ( arr , n ) { let ans = Number . MAX_VALUE ; for ( let i = 0 ; i < n ; i ++ ) { let curr_count = 0 ;
let tmp = " " ; for ( let j = 0 ; j < n ; j ++ ) { tmp = arr [ j ] + arr [ j ] ;
let index = tmp . indexOf ( arr [ i ] ) ;
if ( index == arr [ i ] . length ) return - 1 ; curr_count += index ; } ans = Math . min ( curr_count , ans ) ; } return ans ; }
let arr = [ " " , " " , " " , " " ] ; let n = arr . length ; document . write ( minimunMoves ( arr , n ) ) ;
function restoreSortedArray ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] > arr [ i + 1 ] ) {
reverse ( arr , 0 , i ) ; reverse ( arr , i + 1 , n ) ; reverse ( arr , 0 , n ) ; } } } function reverse ( arr , i , j ) { let temp ; while ( i < j ) { temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; i ++ ; j -- ; } }
function printArray ( arr , size ) { for ( let i = 0 ; i < size ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 3 , 4 , 5 , 1 , 2 ] ; let n = arr . length ; restoreSortedArray ( arr , n - 1 ) ; printArray ( arr , n )
function findStartIndexOfArray ( arr , low , high ) { if ( low > high ) { return - 1 ; } if ( low == high ) { return low ; } let mid = low + parseInt ( ( high - low ) / 2 , 10 ) ; if ( arr [ mid ] > arr [ mid + 1 ] ) { return mid + 1 ; } if ( arr [ mid - 1 ] > arr [ mid ] ) { return mid ; } if ( arr [ low ] > arr [ mid ] ) { return findStartIndexOfArray ( arr , low , mid - 1 ) ; } else { return findStartIndexOfArray ( arr , mid + 1 , high ) ; } }
function restoreSortedArray ( arr , n ) {
if ( arr [ 0 ] < arr [ n - 1 ] ) { return ; } let start = findStartIndexOfArray ( arr , 0 , n - 1 ) ;
arr . sort ( ) ; }
function printArray ( arr , size ) { for ( let i = 0 ; i < size ; i ++ ) { document . write ( arr [ i ] + " " ) ; } }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ; let n = arr . length ; restoreSortedArray ( arr , n ) ; printArray ( arr , n ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function countRotation ( head ) {
let count = 0 ;
let min = head . data ;
while ( head != null ) {
if ( min > head . data ) break ; count ++ ;
head = head . next ; } return count ; }
function push ( head , data ) {
let newNode = new Node ( ) ;
newNode . data = data ;
newNode . next = ( head ) ;
( head ) = newNode ; return head ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } }
let head = null ;
head = push ( head , 12 ) ; head = push ( head , 11 ) ; head = push ( head , 8 ) ; head = push ( head , 5 ) ; head = push ( head , 18 ) ; head = push ( head , 15 ) ; printList ( head ) ; document . write ( " " ) ; document . write ( " " ) ;
document . write ( countRotation ( head ) + " " ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } var tail ;
function rotateHelper ( blockHead , blockTail , d , k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { var temp = blockHead ; for ( i = 1 ; temp . next . next != null && i < k - 1 ; i ++ ) temp = temp . next ; blockTail . next = blockHead ; tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , k ) ; }
if ( d < 0 ) { blockTail . next = blockHead ; tail = blockHead ; return rotateHelper ( blockHead . next , blockHead , d + 1 , k ) ; } return blockHead ; }
function rotateByBlocks ( head , k , d ) {
if ( head == null head . next == null ) return head ;
if ( d == 0 ) return head ; var temp = head ; tail = null ;
var i ; for ( i = 1 ; temp . next != null && i < k ; i ++ ) temp = temp . next ;
var nextBlock = temp . next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , i ) ; else head = rotateHelper ( head , temp , d % k , k ) ;
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
function push ( head_ref , new_data ) { var new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } }
var head = null ;
for ( i = 9 ; i > 0 ; i -= 1 ) head = push ( head , i ) ; document . write ( " " ) ; printList ( head ) ;
var k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; document . write ( " " ) ; printList ( head ) ;
function isRotation ( x , y ) {
var x64 = x | ( x << 32 ) ; while ( x64 >= y ) {
if ( x64 == y ) { return true ; }
x64 >>= 1 ; } return false ; }
var x = 122 ; var y = 2147483678 ; if ( isRotation ( x , y ) == false ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function leftrotate ( str , d ) { var ans = str . substring ( d , str . length ) + str . substring ( 0 , d ) ; return ans ; }
function rightrotate ( str , d ) { return leftrotate ( str , str . length - d ) ; }
var str1 = " " ; document . write ( leftrotate ( str1 , 2 ) + " " ) ; var str2 = " " ; document . write ( rightrotate ( str2 , 2 ) + " " ) ;
function countRotations ( n ) { let len = n . length ;
if ( len == 1 ) { let oneDigit = n [ 0 ] - ' ' ; if ( oneDigit % 4 == 0 ) return 1 ; return 0 ; }
let twoDigit ; let count = 0 ; for ( let i = 0 ; i < ( len - 1 ) ; i ++ ) { twoDigit = ( n [ i ] - ' ' ) * 10 + ( n [ i + 1 ] - ' ' ) ; if ( twoDigit % 4 == 0 ) count ++ ; }
twoDigit = ( n [ len - 1 ] - ' ' ) * 10 + ( n [ 0 ] - ' ' ) ; if ( twoDigit % 4 == 0 ) count ++ ; return count ; }
let n = " " ; document . write ( " " + countRotations ( n ) ) ;
function isRotated ( str1 , str2 ) { if ( str1 . length != str2 . length ) return false ; if ( str1 . length < 2 ) { return str1 . localeCompare ( str2 ) ; } let clock_rot = " " ; let anticlock_rot = " " ; let len = str2 . length ;
anticlock_rot = anticlock_rot + str2 . substring ( len - 2 , len + 1 ) + str2 . substring ( 0 , len - 1 ) ;
clock_rot = clock_rot + str2 . substring ( 2 , str2 . length - 2 + 1 ) + str2 . substring ( 0 , 2 + 1 ) ;
return ( str1 . localeCompare ( clock_rot ) || str1 . localeCompare ( anticlock_rot ) ) ; }
let str1 = " " ; let str2 = " " ; document . write ( isRotated ( str1 , str2 ) ? " " : " " ) ;
function minLexRotation ( str ) {
let n = str . length ;
let arr = new Array ( n ) ;
let concat = str + str ;
for ( let i = 0 ; i < n ; i ++ ) { arr [ i ] = concat . substring ( i , i + n ) ; }
arr . sort ( ) ;
return arr [ 0 ] ; }
document . write ( minLexRotation ( " " ) + " " ) ; document . write ( minLexRotation ( " " ) + " " ) ; document . write ( minLexRotation ( " " ) + " " ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } var head = null ;
function rotate ( k ) { if ( k == 0 ) return ;
var current = head ;
while ( current . next != null ) current = current . next ; current . next = head ; current = head ;
for ( i = 0 ; i < k - 1 ; i ++ ) current = current . next ;
head = current . next ; current . next = null ; }
function push ( new_data ) {
var new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head ;
head = new_node ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } }
for ( i = 60 ; i > 0 ; i -= 10 ) push ( i ) ; document . write ( " " ) ; printList ( head ) ; rotate ( 4 ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
function push ( head_ref , data ) {
var ptr1 = new Node ( ) ; var temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) {
while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
function deleteNode ( head_ref , del ) {
if ( head_ref == del ) head_ref = del . next ; var temp = head_ref ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ;
return ; }
function isEvenParity ( x ) {
var parity = 0 ; while ( x != 0 ) { if ( ( x & 1 ) != 0 ) parity ++ ; x = x >> 1 ; } if ( parity % 2 == 0 ) return true ; else return false ; }
function deleteEvenParityNodes ( head ) { if ( head == null ) return ; if ( head == head . next ) { if ( isEvenParity ( head . data ) ) head = null ; return ; } var ptr = head ; var next ;
do { next = ptr . next ;
if ( isEvenParity ( ptr . data ) ) deleteNode ( head , ptr ) ;
ptr = next ; } while ( ptr != head ) ; if ( head == head . next ) { if ( isEvenParity ( head . data ) ) head = null ; return ; } }
function printList ( head ) { if ( head == null ) { document . write ( " " ) ; return ; } var temp = head ; if ( head != null ) { do { document . write ( temp . data + " " ) ; temp = temp . next ; } while ( temp != head ) ; } }
var head = null ;
head = push ( head , 21 ) ; head = push ( head , 13 ) ; head = push ( head , 6 ) ; head = push ( head , 34 ) ; head = push ( head , 9 ) ; head = push ( head , 11 ) ; deleteEvenParityNodes ( head ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function push ( head_ref , data ) {
var ptr1 = new Node ( ) ; var temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) {
while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
function deleteNode ( head_ref , del ) { var temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ;
del = null ; return ; }
function digitSum ( num ) { var sum = 0 ; while ( num > 0 ) { sum += ( num % 10 ) ; num = parseInt ( num / 10 ) ; } return sum ; }
function deleteEvenDigitSumNodes ( head ) { var ptr = head ; var next ;
do {
if ( ! ( digitSum ( ptr . data ) % 2 == 1 ) ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; }
function printList ( head ) { var temp = head ; if ( head != null ) { do { document . write ( temp . data + " " ) ; temp = temp . next ; } while ( temp != head ) ; } }
var head = null ;
head = push ( head , 21 ) ; head = push ( head , 13 ) ; head = push ( head , 6 ) ; head = push ( head , 34 ) ; head = push ( head , 11 ) ; head = push ( head , 9 ) ; deleteEvenDigitSumNodes ( head ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function push ( head_ref , data ) {
var ptr1 = new Node ( ) ; var temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) {
while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
function deleteNode ( head_ref , del ) { var temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ;
del = null ; return ; }
function largestElement ( head_ref ) {
var current ;
current = head_ref ;
var maxEle = Number . MIN_VALUE ;
do {
if ( current . data > maxEle ) { maxEle = current . data ; } current = current . next ; } while ( current != head_ref ) ; return maxEle ; }
function createHash ( hash , maxElement ) { var prev = 0 , curr = 1 ;
hash . add ( prev ) ; hash . add ( curr ) ;
while ( curr <= maxElement ) { var temp = curr + prev ; hash . add ( temp ) ; prev = curr ; curr = temp ; } }
function deleteFibonacciNodes ( head ) {
var maxEle = largestElement ( head ) ;
var hash = new Set ( ) ; createHash ( hash , maxEle ) ; var ptr = head ; var next ;
do {
if ( hash . has ( ptr . data ) ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; }
function printList ( head ) { var temp = head ; if ( head != null ) { do { document . write ( temp . data + " " ) ; temp = temp . next ; } while ( temp != head ) ; } }
var head = null ;
head = push ( head , 20 ) ; head = push ( head , 13 ) ; head = push ( head , 6 ) ; head = push ( head , 34 ) ; head = push ( head , 11 ) ; head = push ( head , 9 ) ; deleteFibonacciNodes ( head ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } ;
function push ( head_ref , data ) { var ptr1 = new Node ( ) ; var temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) { while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; return head_ref ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
function deleteNode ( head_ref , del ) { var temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ; return head_ref ; }
function deleteoddNodes ( head ) { var ptr = head ; var next ;
if ( ptr . data % 2 == 1 ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; return head ; }
function printList ( head ) { var temp = head ; if ( head != null ) { do { document . write ( temp . data + " " ) ; temp = temp . next ; } while ( temp != head ) ; } }
var head = null ;
head = push ( head , 2 ) ; head = push ( head , 12 ) ; head = push ( head , 11 ) ; head = push ( head , 57 ) ; head = push ( head , 61 ) ; head = push ( head , 56 ) ; document . write ( " " ) ; head = deleteoddNodes ( head ) ; printList ( head ) ;
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
function create ( ) { var new_node = new Node ( ) ; new_node . next = null ; return new_node ; }
function find_head ( random ) {
if ( random == null ) return null ; var head , vari = random ;
while ( ! ( vari . data > vari . next . data vari . next == random ) ) { vari = vari . next ; }
return vari . next ; }
function sortedInsert ( head_ref , new_node ) { var current = head_ref ;
if ( current == null ) { new_node . next = new_node ; head_ref = new_node ; }
else if ( current . data >= new_node . data ) {
while ( current . next != head_ref ) current = current . next ; current . next = new_node ; new_node . next = head_ref ; head_ref = new_node ; } else {
while ( current . next != head_ref && current . next . data < new_node . data ) { current = current . next ; } new_node . next = current . next ; current . next = new_node ; }
return head_ref ; }
function printList ( start ) { var temp ; if ( start != null ) { temp = start ; do { document . write ( temp . data + " " ) ; temp = temp . next ; } while ( temp != start ) ; } }
var arr = [ 12 , 56 , 2 , 11 , 1 , 90 ] ; var list_size , i ;
var start = null ; var temp ;
for ( i = 0 ; i < 6 ; i ++ ) {
if ( start != null ) for ( j = 0 ; j < ( Math . random ( ) * 10 ) ; j ++ ) start = start . next ; temp = create ( ) ; temp . data = arr [ i ] ; start = sortedInsert ( find_head ( start ) , temp ) ; }
printList ( find_head ( start ) ) ;
class Node { constructor ( ) { let data ; let next ; } }
function addToEmpty ( last , data ) {
if ( last != null ) return last ;
temp . data = data ; last = temp ;
last . next = last ; return last ; }
function addBegin ( last , data ) {
if ( last == null ) return addToEmpty ( data ) ;
temp . data = data ; temp . next = last . next ; last . next = temp ; return last ; }
function traverse ( last ) { let p ;
if ( last == null ) { document . write ( " " ) ; return ; }
p = last . next ;
do { document . write ( p . data + " " ) ; p = p . next ; } while ( p != last . next ) ; document . write ( " " ) ; }
function length ( last ) {
let x = 0 ;
if ( last == null ) return x ;
let itr = last . next ; while ( itr . next != last . next ) { x ++ ; itr = itr . next ; }
return ( x + 1 ) ; }
function split ( last , k ) {
let pass = new Node ( ) ;
if ( last == null ) return last ;
let newLast , itr = last ; for ( let i = 0 ; i < k ; i ++ ) { itr = itr . next ; }
newLast = itr ; pass . next = itr . next ; newLast . next = last . next ; last . next = pass . next ;
return newLast ; }
let clist = null ; clist = addToEmpty ( clist , 12 ) ; clist = addBegin ( clist , 10 ) ; clist = addBegin ( clist , 8 ) ; clist = addBegin ( clist , 6 ) ; clist = addBegin ( clist , 4 ) ; clist = addBegin ( clist , 2 ) ; document . write ( " " ) ; traverse ( clist ) ; let k = 4 ;
let clist2 = split ( clist , k )
document . write ( " " ) ; traverse ( clist2 ) ; traverse ( clist ) ;
class Node { constructor ( val ) { this . data = val ; this . left = null ; this . right = null ; } }
function inorder ( root , v ) { if ( root == null ) return ;
inorder ( root . left , v ) ;
v . push ( root . data ) ;
inorder ( root . right , v ) ; }
function bTreeToCList ( root ) {
if ( root == null ) return null ;
var v = [ ] ;
inorder ( root , v ) ;
var head_ref = new Node ( v [ 0 ] ) ;
var curr = head_ref ;
for ( i = 1 ; i < v . length ; i ++ ) {
var temp = curr ;
curr . right = new Node ( v [ i ] ) ;
curr = curr . right ;
curr . left = temp ; }
curr . right = head_ref ;
head_ref . left = curr ;
return head_ref ; }
function displayCList ( head ) { document . write ( " " ) ; var itr = head ; do { document . write ( itr . data + " " ) ; itr = itr . right ; } while ( head != itr ) ; document . write ( ) ; }
var root = new Node ( 10 ) ; root . left = new Node ( 12 ) ; root . right = new Node ( 15 ) ; root . left . left = new Node ( 25 ) ; root . left . right = new Node ( 30 ) ; root . right . left = new Node ( 36 ) ; var head = bTreeToCList ( root ) ; displayCList ( head ) ;
function DeleteLast ( head ) { let current = head , temp = head , previous = null ;
if ( head == null ) { document . write ( " " ) ; return null ; }
if ( current . next == current ) { head = null ; return null ; }
while ( current . next != head ) { previous = current ; current = current . next ; } previous . next = current . next ; head = previous . next ; return head ; }
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function printMinMax ( head ) {
if ( head == null ) { return ; }
current = head ;
var min = Number . MAX_VALUE , max = Number . MIN_VALUE ;
while ( current . next != head ) {
if ( current . data < min ) { min = current . data ; }
if ( current . data > max ) { max = current . data ; } current = current . next ; } document . write ( " " + min + " " + max ) ; }
function insertNode ( head , data ) { var current = head ;
var newNode = new Node ( ) ;
if ( newNode == null ) { document . write ( " " ) ; return null ; }
newNode . data = data ;
if ( head == null ) { newNode . next = newNode ; head = newNode ; return head ; }
else {
while ( current . next != head ) { current = current . next ; }
newNode . next = head ;
current . next = newNode ; } return head ; }
function displayList ( head ) { var current = head ;
if ( head == null ) { document . write ( " " ) ; return ; }
else { do { document . write ( current . data + " " ) ; current = current . next ; } while ( current != head ) ; } }
var Head = null ; Head = insertNode ( Head , 99 ) ; Head = insertNode ( Head , 11 ) ; Head = insertNode ( Head , 22 ) ; Head = insertNode ( Head , 33 ) ; Head = insertNode ( Head , 44 ) ; Head = insertNode ( Head , 55 ) ; Head = insertNode ( Head , 66 ) ; document . write ( " " ) ; displayList ( Head ) ; printMinMax ( Head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function push ( head_ref , data ) { var ptr1 = new Node ( ) ; var temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) { while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; return head_ref ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
function deleteNode ( head_ref , del ) { var temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ; return head_ref ; }
function deleteEvenNodes ( head ) { var ptr = head ; var next ;
if ( ptr . data % 2 == 0 ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; return head ; }
function printList ( head ) { var temp = head ; if ( head != null ) { do { document . write ( temp . data + " " ) ; temp = temp . next ; } while ( temp != head ) ; } }
var head = null ;
head = push ( head , 61 ) ; head = push ( head , 12 ) ; head = push ( head , 56 ) ; head = push ( head , 2 ) ; head = push ( head , 11 ) ; head = push ( head , 57 ) ; document . write ( " " ) ; head = deleteEvenNodes ( head ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function push ( head_ref , data ) { var ptr1 = new Node ( ) ; var temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) { while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
function sumOfList ( head ) { var temp = head ; var sum = 0 ; if ( head != null ) { do { temp = temp . next ; sum += temp . data ; } while ( temp != head ) ; } return sum ; }
var head = null ;
head = push ( head , 12 ) ; head = push ( head , 56 ) ; head = push ( head , 2 ) ; head = push ( head , 11 ) ; document . write ( " " + " " + sumOfList ( head ) ) ;
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
function printList ( head ) { if ( head == null ) return ; var temp = head ; do { document . write ( temp . data + " " ) ; temp = temp . next ; } while ( temp != head ) ; document . write ( head . data + " " ) ; }
function deleteK ( head_ref , k ) { var head = head_ref ;
if ( head == null ) return null ;
var curr = head , prev = null ; while ( true ) {
if ( curr . next == head && curr == head ) break ;
printList ( head ) ;
for ( i = 0 ; i < k ; i ++ ) { prev = curr ; curr = curr . next ; }
if ( curr == head ) { prev = head ; while ( prev . next != head ) prev = prev . next ; head = curr . next ; prev . next = head ; head_ref = head ; }
else if ( curr . next == head ) { prev . next = head ; } else { prev . next = curr . next ; } } return head ; }
function insertNode ( head_ref , x ) {
var head = head_ref ; var temp = new Node ( x ) ;
if ( head == null ) { temp . next = temp ; head_ref = temp ; return head_ref ; }
else { var temp1 = head ; while ( temp1 . next != head ) temp1 = temp1 . next ; temp1 . next = temp ; temp . next = head ; } return head ; }
var head = null ; head = insertNode ( head , 1 ) ; head = insertNode ( head , 2 ) ; head = insertNode ( head , 3 ) ; head = insertNode ( head , 4 ) ; head = insertNode ( head , 5 ) ; head = insertNode ( head , 6 ) ; head = insertNode ( head , 7 ) ; head = insertNode ( head , 8 ) ; head = insertNode ( head , 9 ) ; var k = 4 ;
head = deleteK ( head , k ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = this . prev = null ; } }
function insertNode ( start , value ) {
if ( start == null ) { let new_node = new Node ( ) ; new_node . data = value ; new_node . next = new_node . prev = new_node ; start = new_node ; return new_node ; }
let last = ( start ) . prev ;
let new_node = new Node ( ) ; new_node . data = value ;
new_node . next = start ;
( start ) . prev = new_node ;
new_node . prev = last ;
last . next = new_node ; return start ; }
function displayList ( start ) { let temp = start ; while ( temp . next != start ) { document . write ( temp . data + " " ) ; temp = temp . next ; } document . write ( temp . data + " " ) ; }
function searchList ( start , search ) {
let temp = start ;
let count = 0 , flag = 0 , value ;
if ( temp == null ) return - 1 ; else {
while ( temp . next != start ) {
count ++ ;
if ( temp . data == search ) { flag = 1 ; count -- ; break ; }
temp = temp . next ; }
if ( temp . data == search ) { count ++ ; flag = 1 ; }
if ( flag == 1 ) document . write ( " " + search + " " + count ) ; else document . write ( " " + search + " " ) ; } return - 1 ; }
let start = null ;
start = insertNode ( start , 4 ) ;
start = insertNode ( start , 5 ) ;
start = insertNode ( start , 7 ) ;
start = insertNode ( start , 8 ) ;
start = insertNode ( start , 6 ) ; document . write ( " " ) ; displayList ( start ) ; searchList ( start , 5 ) ;
class node { constructor ( ) { this . data = 0 ; this . next = null ; this . prev = null ; } }
function getNode ( ) { return new node ( ) ; }
function displayList ( temp ) { var t = temp ; if ( temp == null ) return 0 ; else { document . write ( " " ) ; while ( temp . next != t ) { document . write ( temp . data + " " ) ; temp = temp . next ; } document . write ( temp . data + " " ) ; return 1 ; } }
function countList ( start ) {
var temp = start ;
var count = 0 ;
while ( temp . next != start ) { temp = temp . next ; count ++ ; }
count ++ ; return count ; }
function insertAtLocation ( start , data , loc ) {
var temp , newNode ; var i , count ;
newNode = getNode ( ) ;
temp = start ;
count = countList ( start ) ;
if ( temp == null count < loc ) return start ; else {
newNode . data = data ;
for ( i = 1 ; i < loc - 1 ; i ++ ) { temp = temp . next ; }
newNode . next = temp . next ;
temp . next . prev = newNode ;
temp . next = newNode ;
newNode . prev = temp ; return start ; } }
function createList ( arr , n , start ) {
var newNode , temp ; var i ;
for ( i = 0 ; i < n ; i ++ ) {
newNode = getNode ( ) ;
newNode . data = arr [ i ] ;
if ( i == 0 ) { start = newNode ; newNode . prev = start ; newNode . next = start ; } else {
temp = start . prev ;
temp . next = newNode ; newNode . next = start ; newNode . prev = temp ; temp = start ; temp . prev = newNode ; } } return start ; }
var arr = [ 1 , 2 , 3 , 4 , 5 , 6 ] ; var n = arr . length ;
var start = null ;
start = createList ( arr , n , start ) ;
displayList ( start ) ;
start = insertAtLocation ( start , 8 , 3 ) ;
displayList ( start ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; this . prev = null ; } }
function getNode ( data ) { var newNode = new Node ( ) ; newNode . data = data ; return newNode ; }
function insertEnd ( head , new_node ) {
if ( head == null ) { new_node . next = new_node . prev = new_node ; head = new_node ; return head ; }
var last = head . prev ;
new_node . next = head ;
head . prev = new_node ;
new_node . prev = last ;
last . next = new_node ; return head ; }
function reverse ( head ) { if ( head == null ) return null ;
var new_head = null ;
var last = head . prev ;
var curr = last , prev ;
while ( curr . prev != last ) { prev = curr . prev ;
new_head = insertEnd ( new_head , curr ) ; curr = prev ; } new_head = insertEnd ( new_head , curr ) ;
return new_head ; }
function display ( head ) { if ( head == null ) return ; var temp = head ; document . write ( " " ) ; while ( temp . next != head ) { document . write ( temp . data + " " ) ; temp = temp . next ; } document . write ( temp . data + " " ) ; var last = head . prev ; temp = last ; document . write ( " " ) ; while ( temp . prev != last ) { document . write ( temp . data + " " ) ; temp = temp . prev ; } document . write ( temp . data + " " ) ; }
var head = null ; head = insertEnd ( head , getNode ( 1 ) ) ; head = insertEnd ( head , getNode ( 2 ) ) ; head = insertEnd ( head , getNode ( 3 ) ) ; head = insertEnd ( head , getNode ( 4 ) ) ; head = insertEnd ( head , getNode ( 5 ) ) ; document . write ( " " ) ; display ( head ) ; head = reverse ( head ) ; document . write ( " " ) ; display ( head ) ;
class node { constructor ( ) { this . data = 0 ; this . next = this . prev = null ; } }
function getNode ( ) { return new node ( ) ; }
function displayList ( temp ) { let t = temp ; if ( temp == null ) return 0 ; else { document . write ( " " ) ; while ( temp . next != t ) { document . write ( temp . data + " " ) ; temp = temp . next ; } document . write ( temp . data ) ; return 1 ; } }
function createList ( arr , n , start ) {
let newNode , temp ; let i ;
for ( i = 0 ; i < n ; i ++ ) {
newNode = getNode ( ) ;
newNode . data = arr [ i ] ;
if ( i == 0 ) { start = newNode ; newNode . prev = start ; newNode . next = start ; } else {
temp = ( start ) . prev ;
temp . next = newNode ; newNode . next = start ; newNode . prev = temp ; temp = start ; temp . prev = newNode ; } } return start ; }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ; let n = arr . length ;
let start = null ;
start = createList ( arr , n , start ) ;
displayList ( start ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } function newNode ( data ) { var node = new Node ( ) ; node . data = data ; node . next = null ; return node ; }
function alivesol ( Num ) { if ( Num == 1 ) return 1 ;
var last = newNode ( 1 ) ; last . next = last ; for ( var i = 2 ; i <= Num ; i ++ ) { var tem = newNode ( i ) ; tem . next = last . next ; last . next = tem ; last = tem ; }
var curr = last . next ;
var tem1 = new Node ( ) ; while ( curr . next != curr ) { tem1 = curr ; curr = curr . next ; tem1 . next = curr . next ;
tem1 = tem1 . next ; curr = tem1 ; }
var res = tem1 . data ; return res ; }
var N = 100 ; document . write ( alivesol ( N ) + " " ) ;
class Node { constructor ( data ) { this . left = null ; this . right = null ; this . data = data ; } }
function findDepth ( root ) {
if ( root == null ) return 0 ;
let left = findDepth ( root . left ) ;
let right = findDepth ( root . right ) ;
return 1 + Math . max ( left , right ) ; }
function DFS ( root , curr , depth ) {
if ( root == null ) return null ;
if ( curr == depth ) return root ;
let left = DFS ( root . left , curr + 1 , depth ) ;
let right = DFS ( root . right , curr + 1 , depth ) ;
if ( left != null && right != null ) return root ;
return ( left != null ) ? left : right ; }
function lcaOfDeepestLeaves ( root ) {
if ( root == null ) return null ;
let depth = findDepth ( root ) - 1 ;
return DFS ( root , 0 , depth ) ; }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; root . right . left . left = new Node ( 8 ) ; root . right . left . right = new Node ( 9 ) ; document . write ( lcaOfDeepestLeaves ( root ) . data ) ;
function filter ( x , y , z ) { if ( x != - 1 && y != - 1 ) { return z ; } return x == - 1 ? y : x ; }
function samePathUtil ( mtrx , vrtx , v1 , v2 , i ) { let ans = - 1 ;
if ( i == v1 i == v2 ) return i ; for ( let j = 0 ; j < vrtx ; j ++ ) {
if ( mtrx [ i ] [ j ] == 1 ) {
ans = filter ( ans , samePathUtil ( mtrx , vrtx , v1 , v2 , j ) , i ) ; } }
return ans ; }
function isVertexAtSamePath ( mtrx , vrtx , v1 , v2 , i ) { let lca = samePathUtil ( mtrx , vrtx , v1 - 1 , v2 - 1 , i ) ; if ( lca == v1 - 1 lca == v2 - 1 ) return true ; return false ; }
let vrtx = 7 ; let mtrx = [ [ 0 , 1 , 1 , 1 , 0 , 0 , 0 ] , [ 0 , 0 , 0 , 0 , 1 , 0 , 0 ] , [ 0 , 0 , 0 , 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 0 , 0 , 0 , 0 ] , [ 0 , 0 , 0 , 0 , 0 , 0 , 0 ] , [ 0 , 0 , 0 , 0 , 0 , 0 , 0 ] ] ; let v1 = 1 , v2 = 5 ; if ( isVertexAtSamePath ( mtrx , vrtx , v1 , v2 , 0 ) ) document . write ( " " ) ; else document . write ( " " ) ;
let MAX = 1000 ;
let log = 10 ;
let level = new Array ( MAX ) ; let lca = new Array ( MAX ) ; let dist = new Array ( MAX ) ;
let graph = [ ] ; function addEdge ( u , v , cost ) { graph [ u ] . push ( [ v , cost ] ) ; graph [ v ] . push ( [ u , cost ] ) ; }
function dfs ( node , parent , h , cost ) {
lca [ node ] [ 0 ] = parent ;
level [ node ] = h ; if ( parent != - 1 ) { dist [ node ] [ 0 ] = cost ; } for ( let i = 1 ; i < log ; i ++ ) { if ( lca [ node ] [ i - 1 ] != - 1 ) {
lca [ node ] [ i ] = lca [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ; dist [ node ] [ i ] = dist [ node ] [ i - 1 ] + dist [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ; } } for ( let i = 0 ; i < graph [ node ] . length ; i ++ ) { if ( graph [ node ] [ i ] [ 0 ] == parent ) continue ; dfs ( graph [ node ] [ i ] [ 0 ] , node , h + 1 , graph [ node ] [ i ] [ 1 ] ) ; } }
function findDistance ( u , v ) { let ans = 0 ;
if ( level [ u ] > level [ v ] ) { let temp = u ; u = v ; v = temp ; }
for ( let i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v ] [ i ] != - 1 && level [ lca [ v ] [ i ] ] >= level [ u ] ) {
ans += dist [ v ] [ i ] ; v = lca [ v ] [ i ] ; } }
if ( v == u ) { document . write ( ans + " " ) ; } else {
for ( let i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v ] [ i ] != lca [ u ] [ i ] ) {
ans += dist [ u ] [ i ] + dist [ v ] [ i ] ; v = lca [ v ] [ i ] ; u = lca [ u ] [ i ] ; } }
ans += dist [ u ] [ 0 ] + dist [ v ] [ 0 ] ; document . write ( ans + " " ) ; } }
let n = 5 ; for ( let i = 0 ; i < MAX ; i ++ ) { graph . push ( [ ] ) ; }
addEdge ( 1 , 2 , 2 ) ; addEdge ( 1 , 3 , 3 ) ; addEdge ( 2 , 4 , 5 ) ; addEdge ( 2 , 5 , 7 ) ;
for ( let i = 1 ; i <= n ; i ++ ) { lca [ i ] = new Array ( log ) ; dist [ i ] = new Array ( log ) ; for ( let j = 0 ; j < log ; j ++ ) { lca [ i ] [ j ] = - 1 ; dist [ i ] [ j ] = 0 ; } }
dfs ( 1 , - 1 , 0 , 0 ) ;
findDistance ( 1 , 3 ) ;
findDistance ( 2 , 3 ) ;
findDistance ( 3 , 5 ) ;
var MAX = 1000 ; var weight = Array ( MAX ) ; var level = Array ( MAX ) ; var par = Array ( MAX ) ; var prime = Array ( MAX + 1 ) . fill ( true ) ; var graph = Array . from ( Array ( MAX ) , ( ) => Array ( ) ) ;
function SieveOfEratosthenes ( ) {
for ( var p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == true ) {
for ( var i = p * p ; i <= MAX ; i += p ) prime [ i ] = false ; } } }
function dfs ( node , parent , h ) {
par [ node ] = parent ;
level [ node ] = h ; graph [ node ] . forEach ( child => { if ( child != parent ) dfs ( child , node , h + 1 ) ; } ) ; }
function findPrimeOnPath ( u , v ) { var count = 0 ;
if ( level [ u ] > level [ v ] ) { [ u , v ] = [ v , u ] } var d = level [ v ] - level [ u ] ;
while ( d -- ) {
if ( prime [ weight [ v ] ] ) count ++ ; v = par [ v ] ; }
if ( v == u ) { if ( prime [ weight [ v ] ] ) count ++ ; return count ; }
while ( v != u ) { if ( prime [ weight [ v ] ] ) count ++ ; if ( prime [ weight [ u ] ] ) count ++ ; u = par [ u ] ; v = par [ v ] ; }
if ( prime [ weight [ v ] ] ) count ++ ; return count ; }
SieveOfEratosthenes ( ) ;
weight [ 1 ] = 5 ; weight [ 2 ] = 10 ; weight [ 3 ] = 11 ; weight [ 4 ] = 8 ; weight [ 5 ] = 6 ;
graph [ 1 ] . push ( 2 ) ; graph [ 2 ] . push ( 3 ) ; graph [ 2 ] . push ( 4 ) ; graph [ 1 ] . push ( 5 ) ; dfs ( 1 , - 1 , 0 ) ; var u = 3 , v = 5 ; document . write ( findPrimeOnPath ( u , v ) ) ;
let MAX = 1000 ;
let log = 10 ;
let level = new Array ( MAX ) ; level . fill ( 0 ) ; let lca = new Array ( MAX ) ; let minWeight = new Array ( MAX ) ; let maxWeight = new Array ( MAX ) ;
let graph = new Array ( MAX ) ;
let weight = new Array ( MAX ) ; weight . fill ( 0 ) ; function addEdge ( u , v ) { graph [ u ] . push ( v ) ; graph [ v ] . push ( u ) ; }
function dfs ( node , parent , h ) {
lca [ node ] [ 0 ] = parent ;
level [ node ] = h ; if ( parent != - 1 ) { minWeight [ node ] [ 0 ] = Math . min ( weight [ node ] , weight [ parent ] ) ; maxWeight [ node ] [ 0 ] = Math . max ( weight [ node ] , weight [ parent ] ) ; } for ( let i = 1 ; i < log ; i ++ ) { if ( lca [ node ] [ i - 1 ] != - 1 ) {
lca [ node ] [ i ] = lca [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ; minWeight [ node ] [ i ] = Math . min ( minWeight [ node ] [ i - 1 ] , minWeight [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ) ; maxWeight [ node ] [ i ] = Math . max ( maxWeight [ node ] [ i - 1 ] , maxWeight [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ) ; } } for ( let i = 0 ; i < graph [ node ] . length ; i ++ ) { if ( graph [ node ] [ i ] == parent ) continue ; dfs ( graph [ node ] [ i ] , node , h + 1 ) ; } }
function findMinMaxWeight ( u , v ) { let minWei = Number . MAX_VALUE ; let maxWei = Number . MIN_VALUE ;
if ( level [ u ] > level [ v ] ) { let temp = u ; u = v ; v = temp ; }
for ( let i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v ] [ i ] != - 1 && level [ lca [ v ] [ i ] ] >= level [ u ] ) {
minWei = Math . min ( minWei , minWeight [ v ] [ i ] ) ; maxWei = Math . max ( maxWei , maxWeight [ v ] [ i ] ) ; v = lca [ v ] [ i ] ; } }
if ( v == u ) { document . write ( minWei + " " + maxWei + " " ) ; } else {
for ( let i = log - 1 ; i >= 0 ; i -- ) { if ( v == - 1 ) v ++ ; if ( lca [ v ] [ i ] != lca [ u ] [ i ] ) {
minWei = Math . min ( minWei , Math . min ( minWeight [ v ] [ i ] , minWeight [ u ] [ i ] ) ) ;
maxWei = Math . max ( maxWei , Math . max ( maxWeight [ v ] [ i ] , maxWeight [ u ] [ i ] ) ) ; v = lca [ v ] [ i ] ; u = lca [ u ] [ i ] ; } }
if ( u == - 1 ) u ++ ; minWei = Math . min ( minWei , Math . min ( minWeight [ v ] [ 0 ] , minWeight [ u ] [ 0 ] ) ) ;
maxWei = Math . max ( maxWei , Math . max ( maxWeight [ v ] [ 0 ] , maxWeight [ u ] [ 0 ] ) ) ; document . write ( minWei + " " + maxWei + " " ) ; } }
let n = 5 ; for ( let i = 0 ; i < graph . length ; i ++ ) graph [ i ] = [ ] ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 5 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 3 ) ; weight [ 1 ] = - 1 ; weight [ 2 ] = 5 ; weight [ 3 ] = - 1 ; weight [ 4 ] = 3 ; weight [ 5 ] = - 2 ;
dfs ( 1 , - 1 , 0 ) ;
findMinMaxWeight ( 1 , 3 ) ;
findMinMaxWeight ( 2 , 4 ) ;
findMinMaxWeight ( 3 , 5 ) ;
let T = 1 ; function dfs ( node , parent , g , level , t_in , t_out ) {
if ( parent == - 1 ) { level [ node ] = 1 ; } else { level [ node ] = level [ parent ] + 1 ; }
t_in [ node ] = T ; for ( let i = 0 ; i < g [ node ] . length ; i ++ ) { if ( g [ node ] [ i ] != parent ) { T ++ ; dfs ( g [ node ] [ i ] , node , g , level , t_in , t_out ) ; } } T ++ ;
t_out [ node ] = T ; } function findLCA ( n , g , v ) {
let level = new Array ( n + 1 ) ;
let t_in = new Array ( n + 1 ) ;
let t_out = new Array ( n + 1 ) ;
dfs ( 1 , - 1 , g , level , t_in , t_out ) ; let mint = Number . MAX_VALUE , maxt = Number . MIN_VALUE ; let minv = - 1 , maxv = - 1 ; for ( let i = 0 ; i < v . length ; i ++ ) {
if ( t_in [ v [ i ] ] < mint ) { mint = t_in [ v [ i ] ] ; minv = v [ i ] ; }
if ( t_out [ v [ i ] ] > maxt ) { maxt = t_out [ v [ i ] ] ; maxv = v [ i ] ; } }
if ( minv == maxv ) { return minv ; }
let lev = Math . min ( level [ minv ] , level [ maxv ] ) ; let node = 0 , l = Number . MIN_VALUE ; for ( let i = 1 ; i <= n ; i ++ ) {
if ( level [ i ] > lev ) continue ;
if ( t_in [ i ] <= mint && t_out [ i ] >= maxt && level [ i ] > l ) { node = i ; l = level [ i ] ; } } return node ; }
let n = 10 ; let g = new Array ( n + 1 ) ; for ( let i = 0 ; i < g . length ; i ++ ) g [ i ] = [ ] ; g [ 1 ] . push ( 2 ) ; g [ 2 ] . push ( 1 ) ; g [ 1 ] . push ( 3 ) ; g [ 3 ] . push ( 1 ) ; g [ 1 ] . push ( 4 ) ; g [ 4 ] . push ( 1 ) ; g [ 2 ] . push ( 5 ) ; g [ 5 ] . push ( 2 ) ; g [ 2 ] . push ( 6 ) ; g [ 6 ] . push ( 2 ) ; g [ 3 ] . push ( 7 ) ; g [ 7 ] . push ( 3 ) ; g [ 4 ] . push ( 10 ) ; g [ 10 ] . push ( 4 ) ; g [ 8 ] . push ( 7 ) ; g [ 7 ] . push ( 8 ) ; g [ 9 ] . push ( 7 ) ; g [ 7 ] . push ( 9 ) ; let v = [ ] ; v . push ( 7 ) ; v . push ( 3 ) ; v . push ( 8 ) ; document . write ( findLCA ( n , g , v ) + " " ) ;
class Node { constructor ( key ) { this . left = null ; this . right = null ; this . data = key ; } }
function FindPath ( root , key ) { if ( root == null ) return false ; path . push ( root . data ) ; if ( root . data == key ) return true ; if ( FindPath ( root . left , key ) || FindPath ( root . right , key ) ) return true ; path . pop ( ) ; return false ; }
function minMaxNodeInPath ( root , a , b ) {
path = [ ] ; let flag = true ;
let Path2 = [ ] , Path1 = [ ] ;
let min1 = Number . MAX_VALUE ; let max1 = Number . MIN_VALUE ;
let min2 = Number . MAX_VALUE ; let max2 = Number . MIN_VALUE ; let i = 0 ; let j = 0 ; flag = FindPath ( root , a ) ; Path1 = path ; path = [ ] ; flag &= FindPath ( root , b ) ; Path2 = path ;
if ( flag ) {
for ( i = 0 ; i < Path1 . length && i < Path2 . length ; i ++ ) if ( Path1 [ i ] != Path2 [ i ] ) break ; i -- ; j = i ;
for ( ; i < Path1 . length ; i ++ ) { if ( min1 > Path1 [ i ] ) min1 = Path1 [ i ] ; if ( max1 < Path1 [ i ] ) max1 = Path1 [ i ] ; }
for ( ; j < Path2 . length ; j ++ ) { if ( min2 > Path2 [ j ] ) min2 = Path2 [ j ] ; if ( max2 < Path2 [ j ] ) max2 = Path2 [ j ] ; }
document . write ( " " + Math . min ( min1 , min2 ) + " " ) ;
document . write ( " " + Math . max ( max1 , max2 ) + " " ) ; }
else document . write ( " " + " " ) ; return 0 ; }
let root = newNode ( 20 ) ; root . left = newNode ( 8 ) ; root . right = newNode ( 22 ) ; root . left . left = newNode ( 5 ) ; root . left . right = newNode ( 3 ) ; root . right . left = newNode ( 4 ) ; root . right . right = newNode ( 25 ) ; root . left . right . left = newNode ( 10 ) ; root . left . right . right = newNode ( 14 ) ; let a = 5 ; let b = 14 ; minMaxNodeInPath ( root , a , b ) ;
class Node { constructor ( data ) { this . left = null ; this . right = null ; this . data = data ; } }
function newNode ( data ) { let node = new Node ( data ) ; return node ; }
function getPath ( root , arr , x ) {
if ( root == null ) return false ;
arr . push ( root . data ) ;
if ( root . data == x ) return true ;
if ( getPath ( root . left , arr , x ) || getPath ( root . right , arr , x ) ) return true ;
arr . pop ( ) ; return false ; }
function sumOddNodes ( root , n1 , n2 ) {
let path1 = [ ] ;
let path2 = [ ] ; getPath ( root , path1 , n1 ) ; getPath ( root , path2 , n2 ) ; let intersection = - 1 ;
let i = 0 , j = 0 ; while ( i != path1 . length j != path2 . length ) {
if ( i == j && path1 [ i ] == path2 [ j ] ) { i ++ ; j ++ ; } else { intersection = j - 1 ; break ; } } let sum = 0 ;
for ( i = path1 . length - 1 ; i > intersection ; i -- ) if ( path1 [ i ] % 2 != 0 ) sum += path1 [ i ] ; for ( i = intersection ; i < path2 . length ; i ++ ) if ( path2 [ i ] % 2 != 0 ) sum += path2 [ i ] ; return sum ; }
let root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . right = newNode ( 6 ) ; let node1 = 5 ; let node2 = 6 ; document . write ( sumOddNodes ( root , node1 , node2 ) ) ;
const MAX = 1000 ;
function findLCA ( n1 , n2 , parent ) {
let visited = new Array ( MAX ) . fill ( false ) ; visited [ n1 ] = true ;
while ( parent [ n1 ] != - 1 ) { visited [ n1 ] = true ;
n1 = parent [ n1 ] ; } visited [ n1 ] = true ;
while ( ! visited [ n2 ] ) n2 = parent [ n2 ] ; return n2 ; }
function insertAdj ( parent , i , j ) { parent [ i ] = j ; }
let parent = new Array ( MAX ) ;
parent [ 20 ] = - 1 ; insertAdj ( parent , 8 , 20 ) ; insertAdj ( parent , 22 , 20 ) ; insertAdj ( parent , 4 , 8 ) ; insertAdj ( parent , 12 , 8 ) ; insertAdj ( parent , 10 , 12 ) ; insertAdj ( parent , 14 , 12 ) ; document . write ( findLCA ( 10 , 14 , parent ) ) ;
class Node { constructor ( ) { this . key = 0 ; this . left = null ; this . right = null ; } } function newNode ( key ) { var ptr = new Node ( ) ; ptr . key = key ; ptr . left = null ; ptr . right = null ; return ptr ; }
function insert ( root , key ) { if ( root == null ) root = newNode ( key ) ; else if ( root . key > key ) root . left = insert ( root . left , key ) ; else if ( root . key < key ) root . right = insert ( root . right , key ) ; return root ; }
function distanceFromRoot ( root , x ) { if ( root . key == x ) return 0 ; else if ( root . key > x ) return 1 + distanceFromRoot ( root . left , x ) ; return 1 + distanceFromRoot ( root . right , x ) ; }
function distanceBetween2 ( root , a , b ) { if ( root == null ) return 0 ;
if ( root . key > a && root . key > b ) return distanceBetween2 ( root . left , a , b ) ;
if ( root . key < a && root . key < b ) return distanceBetween2 ( root . right , a , b ) ;
if ( root . key >= a && root . key <= b ) return distanceFromRoot ( root , a ) + distanceFromRoot ( root , b ) ; return 0 ; }
function findDistWrapper ( root , a , b ) { var temp = 0 ; if ( a > b ) { temp = a ; a = b ; b = temp ; } return distanceBetween2 ( root , a , b ) ; }
var root = null ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; document . write ( findDistWrapper ( root , 5 , 35 ) ) ;
var MAXN = 1001 ;
var depth = Array ( MAXN ) ;
var parent = Array ( MAXN ) ; var adj = Array . from ( Array ( MAXN ) , ( ) => Array ( ) ) ; function addEdge ( u , v ) { adj [ u ] . push ( v ) ; adj [ v ] . push ( u ) ; } function dfs ( cur , prev ) {
parent [ cur ] = prev ;
depth [ cur ] = depth [ prev ] + 1 ;
for ( var i = 0 ; i < adj [ cur ] . length ; i ++ ) if ( adj [ cur ] [ i ] != prev ) dfs ( adj [ cur ] [ i ] , cur ) ; } function preprocess ( ) {
depth [ 0 ] = - 1 ;
dfs ( 1 , 0 ) ; }
function LCANaive ( u , v ) { if ( u == v ) return u ; if ( depth [ u ] > depth [ v ] ) { var temp = u ; u = v ; v = temp ; } v = parent [ v ] ; return LCANaive ( u , v ) ; }
for ( var i = 0 ; i < MAXN ; i ++ ) adj [ i ] = [ ] ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 1 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 4 , 8 ) ; addEdge ( 4 , 9 ) ; addEdge ( 9 , 10 ) ; addEdge ( 9 , 11 ) ; addEdge ( 7 , 12 ) ; addEdge ( 7 , 13 ) ; preprocess ( ) ; document . write ( " " + LCANaive ( 11 , 8 ) + " " ) ; document . write ( " " + LCANaive ( 3 , 13 ) ) ;
let MAXN = 100001 ; let tree = new Array ( MAXN ) ; let path = new Array ( 3 ) ; for ( let i = 0 ; i < 3 ; i ++ ) { path [ i ] = new Array ( MAXN ) ; for ( let j = 0 ; j < MAXN ; j ++ ) { path [ i ] [ j ] = 0 ; } } let flag ;
/ function dfs ( cur , prev , pathNumber , ptr , node ) { for ( let i = 0 ; i < tree [ cur ] . length ; i ++ ) { if ( tree [ cur ] [ i ] != prev && ! flag ) {
path [ pathNumber ] [ ptr ] = tree [ cur ] [ i ] ; if ( tree [ cur ] [ i ] == node ) {
flag = true ;
path [ pathNumber ] [ ptr + 1 ] = - 1 ; return ; } dfs ( tree [ cur ] [ i ] , cur , pathNumber , ptr + 1 , node ) ; } } }
function LCA ( a , b ) {
if ( a == b ) return a ;
path [ 1 ] [ 0 ] = path [ 2 ] [ 0 ] = 1 ;
flag = false ; dfs ( 1 , 0 , 1 , 1 , a ) ;
flag = false ; dfs ( 1 , 0 , 2 , 1 , b ) ;
let i = 0 ; while ( i < MAXN && path [ 1 ] [ i ] == path [ 2 ] [ i ] ) i ++ ;
return path [ 1 ] [ i - 1 ] ; } function addEdge ( a , b ) { tree [ a ] . push ( b ) ; tree [ b ] . push ( a ) ; }
for ( let i = 0 ; i < MAXN ; i ++ ) tree [ i ] = [ ] ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 3 , 8 ) ; document . write ( " " + LCA ( 4 , 7 ) + " " ) ; document . write ( " " + LCA ( 4 , 6 ) + " " ) ;
let V = 5 ;
let WHITE = 1 ;
let BLACK = 2 ;
class Node { constructor ( data ) { this . data = data ; this . left = this . right = null ; } }
class subset { constructor ( ) { this . parent = 0 ; this . rank = 0 ; this . ancestor = 0 ; this . child = 0 ; this . sibling = 0 ; this . color = 0 ; } }
class Query { constructor ( L , R ) { this . L = L ; this . R = R ; } }
function newNode ( data ) { let node = new Node ( ) ; node . data = data ; node . left = node . right = null ; return ( node ) ; }
function makeSet ( subsets , i ) { if ( i < 1 i > V ) return ; subsets [ i ] . color = WHITE ; subsets [ i ] . parent = i ; subsets [ i ] . rank = 0 ; return ; }
function findSet ( subsets , i ) {
if ( subsets [ i ] . parent != i ) subsets [ i ] . parent = findSet ( subsets , subsets [ i ] . parent ) ; return subsets [ i ] . parent ; }
function unionSet ( subsets , x , y ) { let xroot = findSet ( subsets , x ) ; let yroot = findSet ( subsets , y ) ;
if ( subsets [ xroot ] . rank < subsets [ yroot ] . rank ) subsets [ xroot ] . parent = yroot ; else if ( subsets [ xroot ] . rank > subsets [ yroot ] . rank ) subsets [ yroot ] . parent = xroot ;
else { subsets [ yroot ] . parent = xroot ; ( subsets [ xroot ] . rank ) ++ ; } }
function lcaWalk ( u , q , m , subsets ) {
makeSet ( subsets , u ) ;
subsets [ findSet ( subsets , u ) ] . ancestor = u ; let child = subsets [ u ] . child ;
while ( child != 0 ) { lcaWalk ( child , q , m , subsets ) ; unionSet ( subsets , u , child ) ; subsets [ findSet ( subsets , u ) ] . ancestor = u ; child = subsets [ child ] . sibling ; } subsets [ u ] . color = BLACK ; for ( let i = 0 ; i < m ; i ++ ) { if ( q [ i ] . L == u ) { if ( subsets [ q [ i ] . R ] . color == BLACK ) { document . write ( " " + q [ i ] . L + " " + q [ i ] . R + " " , subsets [ findSet ( subsets , q [ i ] . R ) ] . ancestor + " " ) ; } } else if ( q [ i ] . R == u ) { if ( subsets [ q [ i ] . L ] . color == BLACK ) { document . write ( " " + q [ i ] . L + " " + q [ i ] . R + " " , subsets [ findSet ( subsets , q [ i ] . L ) ] . ancestor + " " ) ; } } } return ; }
function preprocess ( node , subsets ) { if ( node == null ) return ;
preprocess ( node . left , subsets ) ; if ( node . left != null && node . right != null ) {
subsets [ node . data ] . child = node . left . data ; subsets [ node . left . data ] . sibling = node . right . data ; } else if ( ( node . left != null && node . right == null ) || ( node . left == null && node . right != null ) ) { if ( node . left != null && node . right == null ) subsets [ node . data ] . child = node . left . data ; else subsets [ node . data ] . child = node . right . data ; }
preprocess ( node . right , subsets ) ; }
function initialise ( subsets ) {
for ( let i = 1 ; i < subsets . length ; i ++ ) { subsets [ i ] = new subset ( ) ; subsets [ i ] . color = WHITE ; } return ; }
function printLCAs ( root , q , m ) {
let subsets = new Array ( V + 1 ) ;
initialise ( subsets ) ;
preprocess ( root , subsets ) ;
lcaWalk ( root . data , q , m , subsets ) ; }
let root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ;
let q = new Array ( 3 ) ; q [ 0 ] = new Query ( 5 , 4 ) ; q [ 1 ] = new Query ( 1 , 3 ) ; q [ 2 ] = new Query ( 2 , 3 ) ; let m = q . length ; printLCAs ( root , q , m ) ;
function countSingleRec ( node , c ) {
if ( node == null ) return true ;
var left = countSingleRec ( node . left , c ) ; var right = countSingleRec ( node . right , c ) ;
if ( left == false right == false ) return false ;
if ( node . left != null && node . data != node . left . data ) return false ;
if ( node . right != null && node . data != node . right . data ) return false ;
c . count ++ ; return true ; }
function countSingle ( ) { return countSingle ( root ) ; } function countSingle ( node ) {
countSingleRec ( node , ct ) ; return ct . count ; }
root = new Node ( 5 ) ; root . left = new Node ( 4 ) ; root . right = new Node ( 5 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 4 ) ; root . right . right = new Node ( 5 ) ; document . write ( " " + countSingle ( root ) ) ;
function findLeafDown ( root , lev , minDist ) {
if ( root == null ) return ;
if ( root . left == null && root . right == null ) { if ( lev < ( minDist . minDis ) ) minDist . minDis = lev ; return ; }
findLeafDown ( root . left , lev + 1 , minDist ) ; findLeafDown ( root . right , lev + 1 , minDist ) ; }
function findThroughParent ( root , x , minDist ) {
if ( root == null ) return - 1 ; if ( root == x ) return 0 ;
var l = findThroughParent ( root . left , x , minDist ) ;
if ( l != - 1 ) {
findLeafDown ( root . right , l + 2 , minDist ) ; return l + 1 ; }
var r = findThroughParent ( root . right , x , minDist ) ;
if ( r != - 1 ) {
findLeafDown ( root . left , r + 2 , minDist ) ; return r + 1 ; } return - 1 ; }
function minimumDistance ( root , x ) {
d = new Distance ( ) ;
findLeafDown ( x , 0 , d ) ;
findThroughParent ( root , x , d ) ; return d . minDis ; }
root = new Node ( 1 ) ; root . left = new Node ( 12 ) ; root . right = new Node ( 13 ) ; root . right . left = new Node ( 14 ) ; root . right . right = new Node ( 15 ) ; root . right . left . left = new Node ( 21 ) ; root . right . left . right = new Node ( 22 ) ; root . right . right . left = new Node ( 23 ) ; root . right . right . right = new Node ( 24 ) ; root . right . left . left . left = new Node ( 1 ) ; root . right . left . left . right = new Node ( 2 ) ; root . right . left . right . left = new Node ( 3 ) ; root . right . left . right . right = new Node ( 4 ) ; root . right . right . left . left = new Node ( 5 ) ; root . right . right . left . right = new Node ( 6 ) ; root . right . right . right . left = new Node ( 7 ) ; root . right . right . right . right = new Node ( 8 ) ; x = root . right ; document . write ( " " + x . key + " " + minimumDistance ( root , x ) ) ;
class Node { constructor ( item ) { this . data = item ; this . left = this . right = null ; } } var root ;
function printInorder ( node ) { if ( node != null ) { printInorder ( node . left ) ; document . write ( node . data + " " ) ; printInorder ( node . right ) ; } }
function RemoveHalfNodes ( node ) { if ( node == null ) return null ; node . left = RemoveHalfNodes ( node . left ) ; node . right = RemoveHalfNodes ( node . right ) ; if ( node . left == null && node . right == null ) return node ;
if ( node . left == null ) { new_root = node . right ; return new_root ; }
if ( node . right == null ) { new_root = node . left ; return new_root ; } return node ; }
NewRoot = null ; root = new Node ( 2 ) ; root . left = new Node ( 7 ) ; root . right = new Node ( 5 ) ; root . left . right = new Node ( 6 ) ; root . left . right . left = new Node ( 1 ) ; root . left . right . right = new Node ( 11 ) ; root . right . right = new Node ( 9 ) ; root . right . right . left = new Node ( 4 ) ; document . write ( " " ) ; printInorder ( root ) ; NewRoot = RemoveHalfNodes ( root ) ; document . write ( " " ) ; printInorder ( NewRoot ) ; script
class Node { constructor ( data ) { this . data = data ; this . left = this . right = this . abtr = null ; } } let even_ptrs = [ ] ; let odd_ptrs = [ ] ;
function preorderTraversal ( root ) { if ( root == null ) return ;
if ( root . data % 2 == 0 ) ( even_ptrs ) . push ( root ) ;
else ( odd_ptrs ) . push ( root ) ; preorderTraversal ( root . left ) ; preorderTraversal ( root . right ) ; }
function createLoops ( root ) { preorderTraversal ( root ) ; let i ;
for ( i = 1 ; i < even_ptrs . length ; i ++ ) even_ptrs [ i - 1 ] . abtr = even_ptrs [ i ] ;
even_ptrs [ i - 1 ] . abtr = even_ptrs [ 0 ] ;
for ( i = 1 ; i < odd_ptrs . length ; i ++ ) odd_ptrs [ i - 1 ] . abtr = odd_ptrs [ i ] ; odd_ptrs [ i - 1 ] . abtr = odd_ptrs [ 0 ] ; }
function traverseLoop ( start ) { let curr = start ; do { document . write ( curr . data + " " ) ; curr = curr . abtr ; } while ( curr != start ) ; }
let root = null ; root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; createLoops ( root ) ;
document . write ( " " ) ; traverseLoop ( root . right ) ; document . write ( " " ) ;
traverseLoop ( root . left ) ;
class Node { constructor ( val ) { this . data = val ; this . left = null ; this . right = null ; } }
function extractLeafList ( root ) { if ( root == null ) return null ; if ( root . left == null && root . right == null ) { if ( head == null ) { head = root ; prev = root ; } else { prev . right = root ; root . left = prev ; prev = root ; } return null ; } root . left = extractLeafList ( root . left ) ; root . right = extractLeafList ( root . right ) ; return root ; }
function inorder ( node ) { if ( node == null ) return ; inorder ( node . left ) ; document . write ( node . data + " " ) ; inorder ( node . right ) ; }
function printDLL ( head ) { var last = null ; while ( head != null ) { document . write ( head . data + " " ) ; last = head ; head = head . right ; } }
root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . right = new Node ( 6 ) ; root . left . left . left = new Node ( 7 ) ; root . left . left . right = new Node ( 8 ) ; root . right . right . left = new Node ( 9 ) ; root . right . right . right = new Node ( 10 ) ; document . write ( " " ) ; inorder ( root ) ; extractLeafList ( root ) ; document . write ( " " ) ; document . write ( " " ) ; printDLL ( head ) ; document . write ( " " ) ; document . write ( " " ) ; inorder ( root ) ;
var MAX = 100 ;
function dfs ( n , m , visit , adj , N , M ) {
visit [ n ] [ m ] = 1 ;
if ( n + 1 < N && adj [ n ] [ m ] >= adj [ n + 1 ] [ m ] && ! visit [ n + 1 ] [ m ] ) dfs ( n + 1 , m , visit , adj , N , M ) ;
if ( m + 1 < M && adj [ n ] [ m ] >= adj [ n ] [ m + 1 ] && ! visit [ n ] [ m + 1 ] ) dfs ( n , m + 1 , visit , adj , N , M ) ;
if ( n - 1 >= 0 && adj [ n ] [ m ] >= adj [ n - 1 ] [ m ] && ! visit [ n - 1 ] [ m ] ) dfs ( n - 1 , m , visit , adj , N , M ) ;
if ( m - 1 >= 0 && adj [ n ] [ m ] >= adj [ n ] [ m - 1 ] && ! visit [ n ] [ m - 1 ] ) dfs ( n , m - 1 , visit , adj , N , M ) ; } function printMinSources ( adj , N , M ) {
var x = [ ] ; for ( var i = 0 ; i < N ; i ++ ) for ( var j = 0 ; j < M ; j ++ ) x . push ( [ adj [ i ] [ j ] , [ i , j ] ] ) ;
x = x . sort ( ) ;
var visit = new Array ( N ) ; for ( var i = 0 ; i < N ; i ++ ) { visit [ i ] = [ ] ; for ( var j = 0 ; j < MAX ; j ++ ) { visit [ i ] . push ( false ) ; } }
for ( var i = x . length - 1 ; i >= 0 ; i -- ) {
if ( ! visit [ x [ i ] [ 1 ] [ 0 ] ] [ x [ i ] [ 1 ] [ 1 ] ] ) { document . write ( x [ i ] [ 1 ] [ 0 ] + " " + x [ i ] [ 1 ] [ 1 ] + " " ) ; dfs ( x [ i ] [ 1 ] [ 0 ] , x [ i ] [ 1 ] [ 1 ] , visit , adj , N , M ) ; } } }
var N = 2 var M = 2 var adj = [ [ 3 , 3 ] , [ 1 , 1 ] ] printMinSources ( adj , N , M )
function isStepNum ( n ) {
let prevDigit = - 1 ;
while ( n > 0 ) {
let curDigit = n % 10 ;
if ( prevDigit == - 1 ) prevDigit = curDigit ; else {
if ( Math . abs ( prevDigit - curDigit ) != 1 ) return false ; } prevDigit = curDigit ; n = parseInt ( n / 10 , 10 ) ; } return true ; }
function displaySteppingNumbers ( n , m ) {
for ( let i = n ; i <= m ; i ++ ) if ( isStepNum ( i ) ) document . write ( i + " " ) ; }
let n = 0 , m = 21 ;
displaySteppingNumbers ( n , m ) ;
function bfs ( n , m , num ) {
let q = [ ] ; q . push ( num ) ; while ( q . length != 0 ) {
let stepNum = q . shift ( ) ;
if ( stepNum <= m && stepNum >= n ) { document . write ( stepNum + " " ) ; }
if ( stepNum == 0 stepNum > m ) continue ;
let lastDigit = stepNum % 10 ;
let stepNumA = stepNum * 10 + ( lastDigit - 1 ) ; let stepNumB = stepNum * 10 + ( lastDigit + 1 ) ;
if ( lastDigit == 0 ) q . push ( stepNumB ) ;
else if ( lastDigit == 9 ) q . push ( stepNumA ) ; else { q . push ( stepNumA ) ; q . push ( stepNumB ) ; } } }
function displaySteppingNumbers ( n , m ) {
for ( let i = 0 ; i <= 9 ; i ++ ) bfs ( n , m , i ) ; }
let n = 0 , m = 21 ;
displaySteppingNumbers ( n , m ) ;
class Node { constructor ( data ) { this . data = data ; this . left = null ; this . right = null ; } }
function levelOrder ( root ) { if ( root == null ) return ;
let q = [ ] ;
q . push ( root ) ;
q . push ( null ) ;
while ( q . length != 0 ) { let curr = q . shift ( ) ;
if ( curr == null ) { if ( q . length != 0 ) { q . push ( null ) ; document . write ( " " ) ; } } else {
if ( curr . left != null ) q . push ( curr . left ) ;
if ( curr . right != null ) q . push ( curr . right ) ; document . write ( curr . data + " " ) ; } } }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . right = new Node ( 6 ) ; levelOrder ( root ) ;
class Node { constructor ( data ) { this . data = data ; this . left = this . right = null ; } }
function modifiedLevelOrder ( node ) {
if ( node == null ) return ; if ( node . left == null && node . right == null ) { document . write ( node . data ) ; return ; }
let myQueue = [ ] ;
let myStack = [ ] ; let temp = null ;
let sz ;
let ct = 0 ;
let rightToLeft = false ;
myQueue . push ( node ) ;
while ( myQueue . length != 0 ) { ct ++ ; sz = myQueue . length ;
for ( let i = 0 ; i < sz ; i ++ ) { temp = myQueue . shift ( ) ;
if ( rightToLeft == false ) document . write ( temp . data + " " ) ;
else myStack . push ( temp ) ; if ( temp . left != null ) myQueue . push ( temp . left ) ; if ( temp . right != null ) myQueue . push ( temp . right ) ; } if ( rightToLeft == true ) {
while ( myStack . length != 0 ) { temp = myStack . pop ( ) ; document . write ( temp . data + " " ) ; } }
if ( ct == 2 ) { rightToLeft = ! rightToLeft ; ct = 0 ; } document . write ( " " ) ; } }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; root . left . left . left = new Node ( 8 ) ; root . left . left . right = new Node ( 9 ) ; root . left . right . left = new Node ( 3 ) ; root . left . right . right = new Node ( 1 ) ; root . right . left . left = new Node ( 4 ) ; root . right . left . right = new Node ( 2 ) ; root . right . right . left = new Node ( 7 ) ; root . right . right . right = new Node ( 2 ) ; root . left . right . left . left = new Node ( 16 ) ; root . left . right . left . right = new Node ( 17 ) ; root . right . left . right . left = new Node ( 18 ) ; root . right . right . left . right = new Node ( 19 ) ; modifiedLevelOrder ( root ) ;
function find ( parent , i ) { if ( parent [ i ] == - 1 ) return i ; return find ( parent , parent [ i ] ) ; }
function Union ( parent , x , y ) { let xset = find ( parent , x ) ; let yset = find ( parent , y ) ; parent [ xset ] = yset ; }
function minnode ( n , keyval , mstset ) { let mini = Number . MAX_VALUE ; let mini_index = 0 ;
for ( let i = 0 ; i < n ; i ++ ) { if ( mstset [ i ] == false && keyval [ i ] < mini ) { mini = keyval [ i ] ; mini_index = i ; } } return mini_index ; }
function findcost ( n , city ) {
let parent = Array ( n ) . fill ( 0 ) ;
let keyval = Array ( n ) . fill ( 0 ) ;
let mstset = Array ( n ) . fill ( 0 ) ;
for ( let i = 0 ; i < n ; i ++ ) { keyval [ i ] = Number . MAX_VALUE ; mstset [ i ] = false ; }
parent [ 0 ] = - 1 ; keyval [ 0 ] = 0 ;
for ( let i = 0 ; i < n - 1 ; i ++ ) {
let u = minnode ( n , keyval , mstset ) ;
mstset [ u ] = true ;
for ( let v = 0 ; v < n ; v ++ ) { if ( city [ u ] [ v ] > 0 && mstset [ v ] == false && city [ u ] [ v ] < keyval [ v ] ) { keyval [ v ] = city [ u ] [ v ] ; parent [ v ] = u ; } } }
let cost = 0 ; for ( let i = 1 ; i < n ; i ++ ) cost += city [ parent [ i ] ] [ i ] ; document . write ( cost + " " ) ; }
let n1 = 5 ; let city1 = [ [ 0 , 1 , 2 , 3 , 4 ] , [ 1 , 0 , 5 , 0 , 7 ] , [ 2 , 5 , 0 , 6 , 0 ] , [ 3 , 0 , 6 , 0 , 0 ] , [ 4 , 7 , 0 , 0 , 0 ] ] ; findcost ( n1 , city1 ) ;
let n2 = 6 ; let city2 = [ [ 0 , 1 , 1 , 100 , 0 , 0 ] , [ 1 , 0 , 1 , 0 , 0 , 0 ] , [ 1 , 1 , 0 , 0 , 0 , 0 ] , [ 100 , 0 , 0 , 0 , 2 , 2 ] , [ 0 , 0 , 0 , 2 , 0 , 2 ] , [ 0 , 0 , 0 , 2 , 2 , 0 ] ] ; findcost ( n2 , city2 ) ;
let N = 8 ;
function isSafe ( x , y , sol ) { return ( x >= 0 && x < N && y >= 0 && y < N && sol [ x ] [ y ] == - 1 ) ; }
function printSolution ( sol ) { for ( let x = 0 ; x < N ; x ++ ) { for ( let y = 0 ; y < N ; y ++ ) document . write ( sol [ x ] [ y ] + " " ) ; document . write ( " " ) ; } }
function solveKT ( ) { let sol = new Array ( 8 ) ; for ( var i = 0 ; i < sol . length ; i ++ ) { sol [ i ] = new Array ( 2 ) ; }
for ( let x = 0 ; x < N ; x ++ ) for ( let y = 0 ; y < N ; y ++ ) sol [ x ] [ y ] = - 1 ;
let xMove = [ 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 ] ; let yMove = [ 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 ] ;
sol [ 0 ] [ 0 ] = 0 ;
if ( ! solveKTUtil ( 0 , 0 , 1 , sol , xMove , yMove ) ) { document . write ( " " ) ; return false ; } else printSolution ( sol ) ; return true ; }
function solveKTUtil ( x , y , movei , sol , xMove , yMove ) { let k , next_x , next_y ; if ( movei == N * N ) return true ;
for ( k = 0 ; k < 8 ; k ++ ) { next_x = x + xMove [ k ] ; next_y = y + yMove [ k ] ; if ( isSafe ( next_x , next_y , sol ) ) { sol [ next_x ] [ next_y ] = movei ; if ( solveKTUtil ( next_x , next_y , movei + 1 , sol , xMove , yMove ) ) return true ; else
sol [ next_x ] [ next_y ] = - 1 ; } } return false ; }
solveKT ( ) ;
function printSolution ( color ) { document . write ( " " + " " ) ; for ( let i = 0 ; i < V ; i ++ ) document . write ( " " + color [ i ] ) ; document . write ( " " ) ; }
function isSafe ( graph , color ) {
for ( let i = 0 ; i < V ; i ++ ) for ( let j = i + 1 ; j < V ; j ++ ) if ( graph [ i ] [ j ] && color [ j ] == color [ i ] ) return false ; return true ; }
function graphColoring ( graph , m , i , color ) {
if ( i == V ) {
if ( isSafe ( graph , color ) ) {
printSolution ( color ) ; return true ; } return false ; }
for ( let j = 1 ; j <= m ; j ++ ) { color [ i ] = j ;
if ( graphColoring ( graph , m , i + 1 , color ) ) return true ; color [ i ] = 0 ; } return false ; }
let graph = [ [ false , true , true , true ] , [ true , false , true , false ] , [ true , true , false , true ] , [ true , false , true , false ] ] ;
let m = 3 ;
let color = new Array ( V ) ; for ( let i = 0 ; i < V ; i ++ ) color [ i ] = 0 ; if ( ! graphColoring ( graph , m , 0 , color ) ) document . write ( " " ) ;
function shortestChainLen ( start , target , D ) { if ( start == target ) return 0 ;
if ( ! D . has ( target ) ) return 0 ;
let level = 0 , wordlength = start . length ;
let Q = [ ] ; Q . push ( start ) ;
while ( Q . length != 0 ) {
++ level ;
let sizeofQ = Q . length ;
for ( let i = 0 ; i < sizeofQ ; ++ i ) {
let word = Q [ 0 ] . split ( " " ) ; Q . shift ( ) ;
for ( let pos = 0 ; pos < wordlength ; ++ pos ) {
let orig_char = word [ pos ] ;
for ( let c = ' ' . charCodeAt ( 0 ) ; c <= ' ' . charCodeAt ( 0 ) ; ++ c ) { word [ pos ] = String . fromCharCode ( c ) ;
if ( word . join ( " " ) == target ) return level + 1 ;
if ( ! D . has ( word . join ( " " ) ) ) continue ; D . delete ( word . join ( " " ) ) ;
Q . push ( word . join ( " " ) ) ; }
word [ pos ] = orig_char ; } } } return 0 ; }
let D = new Set ( ) ; D . add ( " " ) ; D . add ( " " ) ; D . add ( " " ) ; D . add ( " " ) ; D . add ( " " ) ; D . add ( " " ) ; D . add ( " " ) ; let start = " " ; let target = " " ; document . write ( " " + shortestChainLen ( start , target , D ) ) ;
let INF = Number . MAX_VALUE , N = 4 ;
function minCost ( cost ) {
let dist = new Array ( N ) ; dist . fill ( 0 ) ; for ( let i = 0 ; i < N ; i ++ ) dist [ i ] = INF ; dist [ 0 ] = 0 ;
for ( let i = 0 ; i < N ; i ++ ) for ( let j = i + 1 ; j < N ; j ++ ) if ( dist [ j ] > dist [ i ] + cost [ i ] [ j ] ) dist [ j ] = dist [ i ] + cost [ i ] [ j ] ; return dist [ N - 1 ] ; }
let cost = [ [ 0 , 15 , 80 , 90 ] , [ INF , 0 , 40 , 50 ] , [ INF , INF , 0 , 70 ] , [ INF , INF , INF , 0 ] ] ; document . write ( " " + " " + N + " " + minCost ( cost ) ) ;
function numOfways ( n , k ) { let p = 1 ; if ( k % 2 != 0 ) p = - 1 ; return ( Math . pow ( n - 1 , k ) + p * ( n - 1 ) ) / n ; }
let n = 4 , k = 2 ; document . write ( numOfways ( n , k ) ) ;
if ( inMST [ v ] == false && key [ v ] > weight ) {
key [ v ] = weight ; value = [ key [ v ] , v ] ; pq . push ( value ) ; parent [ v ] = u ; }
function addEdge ( adj , u , v , wt ) { adj [ u ] . push ( [ v , wt ] ) ; adj [ v ] . push ( [ u , wt ] ) ; return adj ; }
function printGraph ( adj , V ) { let v = 0 , w = 0 ; for ( let u = 0 ; u < V ; u ++ ) { document . write ( " " + u + " " ) ; for ( let it = 0 ; it < adj [ u ] . length ; it ++ ) { v = adj [ u ] [ it ] [ 0 ] ; w = adj [ u ] [ it ] [ 1 ] ; document . write ( " " + v + " " + w + " " ) } } }
let V = 5 ; let adj = new Array ( V ) ; for ( let i = 0 ; i < V ; i ++ ) { adj [ i ] = [ ] ; } adj = addEdge ( adj , 0 , 1 , 10 ) adj = addEdge ( adj , 0 , 4 , 20 ) adj = addEdge ( adj , 1 , 2 , 30 ) adj = addEdge ( adj , 1 , 3 , 40 ) adj = addEdge ( adj , 1 , 4 , 50 ) adj = addEdge ( adj , 2 , 3 , 60 ) adj = addEdge ( adj , 3 , 4 , 70 ) printGraph ( adj , V ) ;
function maxindex ( dist , n ) { let mi = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( dist [ i ] > dist [ mi ] ) mi = i ; } return mi ; } function selectKcities ( n , weights , k ) { let dist = new Array ( n ) ; let centers = [ ] ; for ( let i = 0 ; i < n ; i ++ ) { dist [ i ] = Number . MAX_VALUE ; }
let max = 0 ; for ( let i = 0 ; i < k ; i ++ ) { centers . push ( max ) ; for ( let j = 0 ; j < n ; j ++ ) {
dist [ j ] = Math . min ( dist [ j ] , weights [ max ] [ j ] ) ; }
max = maxindex ( dist , n ) ; }
document . write ( dist [ max ] + " " ) ;
for ( let i = 0 ; i < centers . length ; i ++ ) { document . write ( centers [ i ] + " " ) ; } document . write ( " " ) ; }
let n = 4 ; let weights = [ [ 0 , 4 , 8 , 5 ] , [ 4 , 0 , 10 , 7 ] , [ 8 , 10 , 0 , 9 ] , [ 5 , 7 , 9 , 0 ] ] let k = 2
selectKcities ( n , weights , k )
let V = 4 ;
function multiply ( A , B , C ) { for ( let i = 0 ; i < V ; i ++ ) { for ( let j = 0 ; j < V ; j ++ ) { C [ i ] [ j ] = 0 ; for ( let k = 0 ; k < V ; k ++ ) C [ i ] [ j ] += A [ i ] [ k ] * B [ k ] [ j ] ; } } }
function getTrace ( graph ) { let trace = 0 ; for ( let i = 0 ; i < V ; i ++ ) trace += graph [ i ] [ i ] ; return trace ; }
function triangleInGraph ( graph ) {
let aux2 = new Array ( V ) ;
let aux3 = new Array ( V ) ;
for ( let i = 0 ; i < V ; ++ i ) { aux2 [ i ] = new Array ( V ) ; aux3 [ i ] = new Array ( V ) ; for ( let j = 0 ; j < V ; ++ j ) { aux2 [ i ] [ j ] = aux3 [ i ] [ j ] = 0 ; } }
multiply ( graph , graph , aux2 ) ;
multiply ( graph , aux2 , aux3 ) ; let trace = getTrace ( aux3 ) ; return ( trace / 6 ) ; }
let graph = [ [ 0 , 1 , 1 , 0 ] , [ 1 , 0 , 1 , 1 ] , [ 1 , 1 , 0 , 1 ] , [ 0 , 1 , 1 , 0 ] ] ; document . write ( " " + triangleInGraph ( graph ) ) ;
function power ( n ) { if ( n == 1 ) return 2 ; return 2 * power ( n - 1 ) ; }
var n = 4 ; document . write ( power ( n ) ) ;
var size = 4 ;
function checkStar ( mat ) {
var vertexD1 = 0 , vertexDn_1 = 0 ;
if ( size == 1 ) return ( mat [ 0 ] [ 0 ] == 0 ) ;
if ( size == 2 ) return ( mat [ 0 ] [ 0 ] == 0 && mat [ 0 ] [ 1 ] == 1 && mat [ 1 ] [ 0 ] == 1 && mat [ 1 ] [ 1 ] == 0 ) ;
for ( var i = 0 ; i < size ; i ++ ) { var degreeI = 0 ; for ( var j = 0 ; j < size ; j ++ ) if ( mat [ i ] [ j ] ) degreeI ++ ; if ( degreeI == 1 ) vertexD1 ++ ; else if ( degreeI == size - 1 ) vertexDn_1 ++ ; } return ( vertexD1 == ( size - 1 ) && vertexDn_1 == 1 ) ; }
var mat = [ [ 0 , 1 , 1 , 1 ] , [ 1 , 0 , 0 , 0 ] , [ 1 , 0 , 0 , 0 ] , [ 1 , 0 , 0 , 0 ] ] ; checkStar ( mat ) ? document . write ( " " ) : document . write ( " " ) ;
function fib ( n ) { if ( n <= 1 ) return n ; return fib ( n - 1 ) + fib ( n - 2 ) ; }
function findVertices ( n ) {
return fib ( n + 2 ) ; }
var n = 3 ; document . write ( findVertices ( n ) ) ;
function push ( new_data ) {
var new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function insertAfter ( prev_node , new_data ) {
if ( prev_node == null ) { document . write ( " " ) ; return ; }
var new_node = new Node ( new_data ) ;
new_node . next = prev_node . next ;
prev_node . next = new_node ; }
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
var head ;
function push ( new_data ) {
var new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function getCountRec ( node ) {
if ( node == null ) return 0 ;
return 1 + getCountRec ( node . next ) ; }
function getCount ( ) { return getCountRec ( head ) ; }
push ( 1 ) ; push ( 3 ) ; push ( 1 ) ; push ( 2 ) ; push ( 1 ) ; document . write ( " " + getCount ( ) ) ;
function count ( head , key ) { if ( head == null ) return 0 ; if ( head . data == key ) return 1 + count ( head . next , key ) ; return count ( head . next , key ) ; }
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
var head ; var slow_ptr , fast_ptr , second_half ;
function isPalindrome ( head ) { slow_ptr = head ; fast_ptr = head ; var prev_of_slow_ptr = head ;
var midnode = null ;
var res = true ; if ( head != null && head . next != null ) {
while ( fast_ptr != null && fast_ptr . next != null ) { fast_ptr = fast_ptr . next . next ;
prev_of_slow_ptr = slow_ptr ; slow_ptr = slow_ptr . next ; }
if ( fast_ptr != null ) { midnode = slow_ptr ; slow_ptr = slow_ptr . next ; }
second_half = slow_ptr ;
prev_of_slow_ptr . next = null ;
reverse ( ) ;
res = compareLists ( head , second_half ) ;
reverse ( ) ; if ( midnode != null ) {
prev_of_slow_ptr . next = midnode ; midnode . next = second_half ; } else prev_of_slow_ptr . next = second_half ; } return res ; }
function reverse ( ) { var prev = null ; var current = second_half ; var next ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } second_half = prev ; }
function compareLists ( head1 , head2 ) { var temp1 = head1 ; var temp2 = head2 ; while ( temp1 != null && temp2 != null ) { if ( temp1 . data == temp2 . data ) { temp1 = temp1 . next ; temp2 = temp2 . next ; } else return false ; }
if ( temp1 == null && temp2 == null ) return true ;
return false ; }
function push ( new_data ) {
var new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function printList ( ptr ) { while ( ptr != null ) { document . write ( ptr . data + " " ) ; ptr = ptr . next ; } document . write ( " " ) ; }
var str = [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] ; var string = str . toString ( ) ; for ( i = 0 ; i < 7 ; i ++ ) { push ( str [ i ] ) ; printList ( head ) ; if ( isPalindrome ( head ) != false ) { document . write ( " " ) ; document . write ( " " ) ; } else { document . write ( " " ) ; document . write ( " " ) ; } }
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
var head ;
function swapNodes ( x , y ) {
if ( x == y ) return ;
var prevX = null , currX = head ; while ( currX != null && currX . data != x ) { prevX = currX ; currX = currX . next ; }
var prevY = null , currY = head ; while ( currY != null && currY . data != y ) { prevY = currY ; currY = currY . next ; }
if ( currX == null currY == null ) return ;
if ( prevX != null ) prevX . next = currY ;
else head = currY ;
if ( prevY != null ) prevY . next = currX ;
else head = currX ;
var temp = currX . next ; currX . next = currY . next ; currY . next = temp ; }
function push ( new_data ) {
var new_Node = new Node ( new_data ) ;
new_Node . next = head ;
head = new_Node ; }
function printList ( ) { var tNode = head ; while ( tNode != null ) { document . write ( tNode . data + " " ) ; tNode = tNode . next ; } }
push ( 7 ) ; push ( 6 ) ; push ( 5 ) ; push ( 4 ) ; push ( 3 ) ; push ( 2 ) ; push ( 1 ) ; document . write ( " " ) ; printList ( ) ; swapNodes ( 4 , 3 ) ; document . write ( " " ) ; printList ( ) ;
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
function getJosephusPosition ( m , n ) {
var head = new Node ( 1 ) ; var prev = head ; for ( i = 2 ; i <= n ; i ++ ) { prev . next = new Node ( i ) ; prev = prev . next ; }
prev . next = head ;
var ptr1 = head , ptr2 = head ; while ( ptr1 . next != ptr1 ) {
var count = 1 ; while ( count != m ) { ptr2 = ptr1 ; ptr1 = ptr1 . next ; count ++ ; }
ptr2 . next = ptr1 . next ; ptr1 = ptr2 . next ; } document . write ( " " + " " + ptr1 . data ) ; }
var n = 14 , m = 2 ; getJosephusPosition ( m , n ) ;
class Node { constructor ( val ) { this . data = val ; this . next = null ; } } var head ;
function push ( new_data ) { new_node = new Node ( new_data ) ; new_node . next = head ; head = new_node ; }
function printList ( ) { node = head ; while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } document . write ( " " ) ; }
function countNodes ( ) { var count = 0 ; s = head ; while ( s != null ) { count ++ ; s = s . next ; } return count ; }
function swapKth ( k ) {
var n = countNodes ( ) ;
if ( n < k ) return ;
if ( 2 * k - 1 == n ) return ;
x = head ; x_prev = null ; for ( i = 1 ; i < k ; i ++ ) { x_prev = x ; x = x . next ; }
y = head ; y_prev = null ; for ( i = 1 ; i < n - k + 1 ; i ++ ) { y_prev = y ; y = y . next ; }
if ( x_prev != null ) x_prev . next = y ;
if ( y_prev != null ) y_prev . next = x ;
temp = x . next ; x . next = y . next ; y . next = temp ;
if ( k == 1 ) head = y ; if ( k == n ) head = x ; }
for ( let i = 8 ; i >= 1 ; i -- ) push ( i ) ; document . write ( " " ) ; printList ( ) ; document . write ( " " ) ; for ( let i = 1 ; i < 9 ; i ++ ) { swapKth ( i ) ; document . write ( " " + i + " " ) ; printList ( ) ; document . write ( " " ) ; }
class Node { constructor ( data ) { this . data = data ; this . next = this . prev = null ; } }
function countPairs ( first , second , value ) { let count = 0 ;
while ( first != null && second != null && first != second && second . next != first ) {
if ( ( first . data + second . data ) == value ) {
count ++ ;
first = first . next ;
second = second . prev ; }
else if ( ( first . data + second . data ) > value ) second = second . prev ;
else first = first . next ; }
return count ; }
function countTriplets ( head , x ) {
if ( head == null ) return 0 ; let current , first , last ; let count = 0 ;
last = head ; while ( last . next != null ) last = last . next ;
for ( current = head ; current != null ; current = current . next ) {
first = current . next ;
count += countPairs ( first , last , x - current . data ) ; }
return count ; }
function insert ( head , data ) {
let temp = new Node ( ) ;
temp . data = data ; temp . next = temp . prev = null ; if ( ( head ) == null ) ( head ) = temp ; else { temp . next = head ; ( head ) . prev = temp ; ( head ) = temp ; } return head ; }
let head = null ;
head = insert ( head , 9 ) ; head = insert ( head , 8 ) ; head = insert ( head , 6 ) ; head = insert ( head , 5 ) ; head = insert ( head , 4 ) ; head = insert ( head , 2 ) ; head = insert ( head , 1 ) ; let x = 17 ; document . write ( " " + countTriplets ( head , x ) ) ;
function deleteNode ( head_ref , del ) {
if ( head_ref == null del == null ) return head_ref ;
if ( head_ref == del ) head_ref = del . next ;
if ( del . next != null ) del . next . prev = del . prev ;
if ( del . prev != null ) del . prev . next = del . next ; return head_ref ; }
function removeDuplicates ( head_ref ) {
if ( ( head_ref ) == null || ( head_ref ) . next == null ) return head_ref ; var ptr1 , ptr2 ;
for ( ptr1 = head_ref ; ptr1 != null ; ptr1 = ptr1 . next ) { ptr2 = ptr1 . next ;
while ( ptr2 != null ) {
if ( ptr1 . data == ptr2 . data ) {
var next = ptr2 . next ;
head_ref = deleteNode ( head_ref , ptr2 ) ;
ptr2 = next ; }
else ptr2 = ptr2 . next ; } } return head_ref ; }
function push ( head_ref , new_data ) {
var new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . prev = null ;
new_node . next = ( head_ref ) ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
function printList ( head ) {
if ( head == null ) document . write ( " " ) ; while ( head != null ) { document . write ( head . data + " " ) ; head = head . next ; } }
var head = null ;
head = push ( head , 12 ) ; head = push ( head , 12 ) ; head = push ( head , 10 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 4 ) ; head = push ( head , 6 ) ; head = push ( head , 4 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; document . write ( " " ) ; printList ( head ) ;
head = removeDuplicates ( head ) ; document . write ( " " + " " ) ; printList ( head ) ;
class Node { constructor ( val ) { this . data = val ; this . prev = null ; this . next = null ; } }
function deleteNode ( head_ref , del ) {
if ( head_ref == null del == null ) return null ;
if ( head_ref == del ) head_ref = del . next ;
if ( del . next != null ) del . next . prev = del . prev ;
if ( del . prev != null ) del . prev . next = del . next ; return head_ref ; }
function removeDuplicates ( head_ref ) {
if ( ( head_ref ) == null ) return null ;
var us = new Set ( ) ; var current = head_ref , next ;
while ( current != null ) {
if ( us . has ( current . data ) ) {
next = current . next ;
head_ref = deleteNode ( head_ref , current ) ;
current = next ; } else {
us . add ( current . data ) ;
current = current . next ; } } return head_ref ; }
function push ( head_ref , new_data ) {
var new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . prev = null ;
new_node . next = ( head_ref ) ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
function printList ( head ) {
if ( head == null ) document . write ( " " ) ; while ( head != null ) { document . write ( head . data + " " ) ; head = head . next ; } }
var head = null ;
head = push ( head , 12 ) ; head = push ( head , 12 ) ; head = push ( head , 10 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 4 ) ; head = push ( head , 6 ) ; head = push ( head , 4 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; document . write ( " " ) ; printList ( head ) ;
head = removeDuplicates ( head ) ; document . write ( " " + " " ) ; printList ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . prev = null ; this . next = null ; } }
function reverse ( head_ref ) { var temp = null ; var current = head_ref ;
while ( current != null ) { temp = current . prev ; current . prev = current . next ; current . next = temp ; current = current . prev ; }
if ( temp != null ) head_ref = temp . prev ; return head_ref ; }
function merge ( first , second ) {
if ( first == null ) return second ;
if ( second == null ) return first ;
if ( first . data < second . data ) { first . next = merge ( first . next , second ) ; first . next . prev = first ; first . prev = null ; return first ; } else { second . next = merge ( first , second . next ) ; second . next . prev = second ; second . prev = null ; return second ; } }
function sort ( head ) {
if ( head == null head . next == null ) return head ; var current = head . next ; while ( current != null ) {
if ( current . data < current . prev . data ) break ;
current = current . next ; }
if ( current == null ) return head ;
current . prev . next = null ; current . prev = null ;
current = reverse ( current ) ;
return merge ( head , current ) ; }
function push ( head_ref , new_data ) {
var new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . prev = null ;
new_node . next = ( head_ref ) ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
function printList ( head ) {
if ( head == null ) document . write ( " " ) ; while ( head != null ) { document . write ( head . data + " " ) ; head = head . next ; } }
var head = null ;
head = push ( head , 1 ) ; head = push ( head , 4 ) ; head = push ( head , 6 ) ; head = push ( head , 10 ) ; head = push ( head , 12 ) ; head = push ( head , 7 ) ; head = push ( head , 5 ) ; head = push ( head , 2 ) ; document . write ( " " ) ; printList ( head ) ;
head = sort ( head ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( ) { this . info = 0 ; this . prev = null ; this . next = null ; } } var head , tail ;
function nodeInsetail ( key ) { p = new Node ( ) ; p . info = key ; p . next = null ;
if ( head == null ) { head = p ; tail = p ; head . prev = null ; return ; }
if ( p . info < head . info ) { p . prev = null ; head . prev = p ; p . next = head ; head = p ; return ; }
if ( p . info > tail . info ) { p . prev = tail ; tail . next = p ; tail = p ; return ; }
temp = head . next ; while ( temp . info < p . info ) temp = temp . next ;
( temp . prev ) . next = p ; p . prev = temp . prev ; temp . prev = p ; p . next = temp ; }
function printList ( temp ) { while ( temp != null ) { document . write ( temp . info + " " ) ; temp = temp . next ; } }
head = tail = null ; nodeInsetail ( 30 ) ; nodeInsetail ( 50 ) ; nodeInsetail ( 90 ) ; nodeInsetail ( 10 ) ; nodeInsetail ( 40 ) ; nodeInsetail ( 110 ) ; nodeInsetail ( 60 ) ; nodeInsetail ( 95 ) ; nodeInsetail ( 23 ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( item ) { this . data = item ; this . next = null ; } }
function findDepthRec ( tree , n , index ) { if ( index >= n tree [ index ] == ' ' ) return 0 ;
index ++ ; let left = findDepthRec ( tree , n , index ) ;
index ++ ; let right = findDepthRec ( tree , n , index ) ; return Math . max ( left , right ) + 1 ; }
function findDepth ( tree , n ) { let index = 0 ; return ( findDepthRec ( tree , n , index ) ) ; }
let tree = " " . split ( ' ' ) ; let n = tree . length ; document . write ( findDepth ( tree , n ) ) ;
class Node {
function printlist ( head ) { if ( head == null ) { document . write ( " " ) ; return ; } while ( head != null ) { document . write ( head . data + " " ) ; if ( head . next != null ) document . write ( " " ) ; head = head . next ; } document . write ( " " ) ; }
function isVowel ( x ) { return ( x == ' ' x == ' ' x == ' ' x == ' ' x == ' ' ) ; }
function arrange ( head ) { let newHead = head ;
let latestVowel ; let curr = head ;
if ( head == null ) return null ;
if ( isVowel ( head . data ) == true )
latestVowel = head ; else {
while ( curr . next != null && ! isVowel ( curr . next . data ) ) curr = curr . next ;
if ( curr . next == null ) return head ;
latestVowel = newHead = curr . next ; curr . next = curr . next . next ; latestVowel . next = head ; }
while ( curr != null && curr . next != null ) { if ( isVowel ( curr . next . data ) == true ) {
if ( curr == latestVowel ) {
latestVowel = curr = curr . next ; } else {
let temp = latestVowel . next ;
latestVowel . next = curr . next ;
latestVowel = latestVowel . next ;
curr . next = curr . next . next ;
latestVowel . next = temp ; } } else {
curr = curr . next ; } } return newHead ; }
let head = new Node ( ' ' ) ; head . next = new Node ( ' ' ) ; head . next . next = new Node ( ' ' ) ; head . next . next . next = new Node ( ' ' ) ; head . next . next . next . next = new Node ( ' ' ) ; head . next . next . next . next . next = new Node ( ' ' ) ; head . next . next . next . next . next . next = new Node ( ' ' ) ; head . next . next . next . next . next . next . next = new Node ( ' ' ) ; document . write ( " " ) ; printlist ( head ) ; head = arrange ( head ) ; document . write ( " " ) ; printlist ( head ) ;
class Node { constructor ( x ) { this . data = x ; this . left = null ; this . right = null ; } } let count = 0 ;
function insert ( root , x ) { if ( root == null ) return new Node ( x ) ; if ( x < root . data ) root . left = insert ( root . left , x ) ; else if ( x > root . data ) root . right = insert ( root . right , x ) ; return root ; }
function kthSmallest ( root , k ) {
if ( root == null ) return null ;
let left = kthSmallest ( root . left , k ) ;
if ( left != null ) return left ;
count ++ ; if ( count == k ) return root ;
return kthSmallest ( root . right , k ) ; }
function printKthSmallest ( root , k ) {
count = 0 ; let res = kthSmallest ( root , k ) ; if ( res == null ) document . write ( " " + " " ) ; else document . write ( " " + " " + res . data ) ; }
let root = null ; let key = [ 20 , 8 , 22 , 4 , 12 , 10 , 14 ] ; for ( let i = 0 ; i < key . length ; i ++ ) { root = insert ( root , key [ i ] ) ; } let k = 3 ; printKthSmallest ( root , k ) ;
class TreeNode { constructor ( x ) { this . val = x ; this . left = null ; this . right = null ; } } let set = new Set ( ) ; let stack = [ ] ;
function buildTree ( preorder , inorder ) { let root = null ; for ( let pre = 0 , In = 0 ; pre < preorder . length ; ) { let node = null ; do { node = new TreeNode ( preorder [ pre ] ) ; if ( root == null ) { root = node ; } if ( stack . length != 0 ) { if ( set . has ( stack [ stack . length - 1 ] ) ) { set . delete ( stack [ stack . length - 1 ] ) ; stack . pop ( ) . right = node ; } else { stack [ stack . length - 1 ] . left = node ; } } stack . push ( node ) ; } while ( preorder [ pre ++ ] != inorder [ In ] && pre < preorder . length ) ; node = null ; while ( stack . length != 0 && In < inorder . length && stack [ stack . length - 1 ] . val == inorder [ In ] ) { node = stack . pop ( ) ; In ++ ; } if ( node != null ) { set . add ( node ) ; stack . push ( node ) ; } } return root ; }
function printInorder ( node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
document . write ( node . val + " " ) ;
printInorder ( node . right ) ; }
let In = [ 9 , 8 , 4 , 2 , 10 , 5 , 10 , 1 , 6 , 3 , 13 , 12 , 7 ] ; let pre = [ 1 , 2 , 4 , 8 , 9 , 5 , 10 , 10 , 3 , 6 , 7 , 12 , 13 ] ; let len = In . length ; let root = buildTree ( pre , In ) ; printInorder ( root ) ;
function newNode ( data ) { var temp = new Node ( ) ; temp . data = data ; temp . right = null ; temp . left = null ; return temp ; } function KthLargestUsingMorrisTraversal ( root , k ) { var curr = root ; var Klargest = null ;
var count = 0 ; while ( curr != null ) {
if ( curr . right == null ) {
if ( ++ count == k ) Klargest = curr ;
curr = curr . left ; } else {
var succ = curr . right ; while ( succ . left != null && succ . left != curr ) succ = succ . left ; if ( succ . left == null ) {
succ . left = curr ;
curr = curr . right ; }
else { succ . left = null ; if ( ++ count == k ) Klargest = curr ;
curr = curr . left ; } } } return Klargest ; }
root = newNode ( 4 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 7 ) ; root . left . left = newNode ( 1 ) ; root . left . right = newNode ( 3 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 10 ) ; document . write ( " " + KthLargestUsingMorrisTraversal ( root , 2 ) . data ) ;
class Node { constructor ( ) { this . key = 0 ; this . left = null ; this . right = null ; } }
function KSmallestUsingMorris ( root , k ) {
var count = 0 ;
var ksmall = Number . MIN_VALUE ;
var curr = root ; while ( curr != null ) {
if ( curr . left == null ) { count ++ ;
if ( count == k ) ksmall = curr . key ;
curr = curr . right ; } else {
var pre = curr . left ; while ( pre . right != null && pre . right != curr ) pre = pre . right ;
if ( pre . right == null ) {
pre . right = curr ; curr = curr . left ; }
else {
pre . right = null ; count ++ ;
if ( count == k ) ksmall = curr . key ; curr = curr . right ; } } }
return ksmall ; }
function insert ( node , key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else if ( key > node . key ) node . right = insert ( node . right , key ) ;
return node ; }
var root = null ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ; for ( k = 1 ; k <= 7 ; k ++ ) document . write ( KSmallestUsingMorris ( root , k ) + " " ) ;
function isInorder ( arr , n ) {
if ( n == 0 n == 1 ) { return true ; }
for ( i = 1 ; i < n ; i ++ ) { if ( arr [ i - 1 ] > arr [ i ] ) { return false ; } }
return true ; }
var arr = [ 19 , 23 , 25 , 30 , 45 ] ; var n = arr . length ; if ( isInorder ( arr , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
class Node { constructor ( ) { this . data = 0 ; this . prev = null ; this . next = null ; } }
function newNode ( val ) { var temp = new Node ( ) ; temp . data = val ; temp . left = temp . right = null ; return temp ; }
function storeInorder ( root , v ) { if ( root == null ) return ; storeInorder ( root . left , v ) ; v . push ( root . data ) ; storeInorder ( root . right , v ) ; }
function checkBSTs ( root1 , root2 ) {
if ( root1 != null && root2 != null ) return true ; if ( ( root1 == null && root2 != null ) || ( root1 != null && root2 == null ) ) return false ;
var v1 = [ ] ; var v2 = [ ] ; storeInorder ( root1 , v1 ) ; storeInorder ( root2 , v2 ) ;
return ( v1 == v2 ) ; }
var root1 = newNode ( 15 ) ; root1 . left = newNode ( 10 ) ; root1 . right = newNode ( 20 ) ; root1 . left . left = newNode ( 5 ) ; root1 . left . right = newNode ( 12 ) ; root1 . right . right = newNode ( 25 ) ;
var root2 = newNode ( 15 ) ; root2 . left = newNode ( 12 ) ; root2 . right = newNode ( 20 ) ; root2 . left . left = newNode ( 5 ) ; root2 . left . left . right = newNode ( 10 ) ; root2 . right . right = newNode ( 25 ) ;
if ( checkBSTs ( root1 , root2 ) ) document . write ( " " ) ; else document . write ( " " ) ;
function newNode ( item ) { var temp = new Node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; return temp ; }
function insert ( node , key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else if ( key > node . key ) node . right = insert ( node . right , key ) ;
return node ; }
function findMaxforN ( root , N ) {
if ( root == null ) return - 1 ; if ( root . key == N ) return N ;
else if ( root . key < N ) { var k = findMaxforN ( root . right , N ) ; if ( k == - 1 ) return root . key ; else return k ; }
else if ( root . key > N ) return findMaxforN ( root . left , N ) ; return - 1 ; }
var N = 4 ;
var root = null ; root = insert ( root , 25 ) ; insert ( root , 2 ) ; insert ( root , 1 ) ; insert ( root , 3 ) ; insert ( root , 12 ) ; insert ( root , 9 ) ; insert ( root , 21 ) ; insert ( root , 19 ) ; insert ( root , 25 ) ; document . write ( findMaxforN ( root , N ) ) ;
class Node { constructor ( ) { this . key = 0 ; this . left = null ; this . right = null ; } } function newNode ( key ) { var ptr = new Node ( ) ; ptr . key = key ; ptr . left = null ; ptr . right = null ; return ptr ; }
function insert ( root , key ) { if ( root == null ) root = newNode ( key ) ; else if ( root . key > key ) root . left = insert ( root . left , key ) ; else if ( root . key < key ) root . right = insert ( root . right , key ) ; return root ; }
function distanceFromRoot ( root , x ) { if ( root . key == x ) return 0 ; else if ( root . key > x ) return 1 + distanceFromRoot ( root . left , x ) ; return 1 + distanceFromRoot ( root . right , x ) ; }
function distanceBetween2 ( root , a , b ) { if ( root == null ) return 0 ;
if ( root . key > a && root . key > b ) return distanceBetween2 ( root . left , a , b ) ;
if ( root . key < a && root . key < b ) return distanceBetween2 ( root . right , a , b ) ;
if ( root . key >= a && root . key <= b ) return distanceFromRoot ( root , a ) + distanceFromRoot ( root , b ) ; return 0 ; }
function findDistWrapper ( root , a , b ) { var temp = 0 ; if ( a > b ) { temp = a ; a = b ; b = temp ; } return distanceBetween2 ( root , a , b ) ; }
var root = null ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; document . write ( findDistWrapper ( root , 5 , 35 ) ) ;
class node { constructor ( ) { this . data = 0 ; this . left = null ; this . right = null ; } }
function RangeTraversal ( root , n1 , n2 ) { if ( root == null ) return ; var curr = root ; while ( curr != null ) { if ( curr . left == null ) {
if ( curr . data <= n2 && curr . data >= n1 ) { document . write ( curr . data + " " ) ; } curr = curr . right ; } else { var pre = curr . left ;
while ( pre . right != null && pre . right != curr ) pre = pre . right ; if ( pre . right == null ) { pre . right = curr ; curr = curr . left ; } else { pre . right = null ;
if ( curr . data <= n2 && curr . data >= n1 ) { document . write ( curr . data + " " ) ; } curr = curr . right ; } } } }
root = newNode ( 4 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 7 ) ; root . left . left = newNode ( 1 ) ; root . left . right = newNode ( 3 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 10 ) ; RangeTraversal ( root , 4 , 12 ) ;
function inRange ( root , low , high ) { return root . data >= low && root . data <= high ; }
function getCountUtil ( root , low , high , count ) {
if ( root == null ) return true ;
var l = getCountUtil ( root . left , low , high , count ) ; var r = getCountUtil ( root . right , low , high , count ) ;
if ( l && r && inRange ( root , low , high ) ) { ++ count . a ; return true ; } return false ; }
function getCount ( root , low , high ) { var count = new INT ( ) ; count . a = 0 ; getCountUtil ( root , low , high , count ) ; return count ; }
function newNode ( data ) { var temp = new node ( ) ; temp . data = data ; temp . left = temp . right = null ; return ( temp ) ; }
var root = newNode ( 10 ) ; root . left = newNode ( 5 ) ; root . right = newNode ( 50 ) ; root . left . left = newNode ( 1 ) ; root . right . left = newNode ( 40 ) ; root . right . right = newNode ( 100 ) ;
var l = 5 ; var h = 45 ; document . write ( " " + l + " " + h + " " + getCount ( root , l , h ) . a ) ;
class Node { constructor ( ) { this . data = 0 ; this . left = null ; this . right = null ; } }
function newNode ( data ) { var temp = new Node ( ) ; temp . data = data ; temp . left = null ; temp . right = null ; return temp ; }
function insert ( root , data ) { if ( root == null ) return newNode ( data ) ; if ( data < root . data ) root . left = insert ( root . left , data ) ; else if ( data > root . data ) root . right = insert ( root . right , data ) ; return root ; }
function inorder ( root ) { if ( root != null ) { inorder ( root . left ) ; document . write ( root . data + " " ) ; inorder ( root . right ) ; } }
function leafDelete ( root ) { if ( root == null ) { return null ; } if ( root . left == null && root . right == null ) { return null ; }
root . left = leafDelete ( root . left ) ; root . right = leafDelete ( root . right ) ; return root ; }
var root = null ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; document . write ( " " ) ; inorder ( root ) ; document . write ( " " ) ; leafDelete ( root ) ; document . write ( " " ) ; inorder ( root ) ;
function createNode ( data ) { var new_Node = new Node ( ) ; new_Node . left = null ; new_Node . right = null ; new_Node . data = data ; return new_Node ; }
function insert ( root , key ) {
if ( root == null ) return createNode ( key ) ;
if ( root . data > key ) root . left = insert ( root . left , key ) ; else if ( root . data < key ) root . right = insert ( root . right , key ) ;
return root ; } var count = 0 ;
function ksmallestElementSumRec ( root , k ) {
if ( root == null ) return 0 ; if ( count > k ) return 0 ;
var res = ksmallestElementSumRec ( root . left , k ) ; if ( count >= k ) return res ;
res += root . data ;
count ++ ; if ( count >= k ) return res ;
return res + ksmallestElementSumRec ( root . right , k ) ; }
function ksmallestElementSum ( root , k ) { var res = ksmallestElementSumRec ( root , k ) ; return res ; }
var root = null ; root = insert ( root , 20 ) ; root = insert ( root , 8 ) ; root = insert ( root , 4 ) ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 14 ) ; root = insert ( root , 22 ) ; var k = 3 ; var count = ksmallestElementSum ( root , k ) ; document . write ( count ) ;
class Node { constructor ( val ) { this . data = val ; this . left = null ; this . right = null ; this . parent = null ; } } var head ;
function insert ( node , data ) {
if ( node == null ) { return ( new Node ( data ) ) ; } else { var temp = null ;
if ( data <= node . data ) { temp = insert ( node . left , data ) ; node . left = temp ; temp . parent = node ; } else { temp = insert ( node . right , data ) ; node . right = temp ; temp . parent = node ; }
return node ; } } function inOrderSuccessor ( root , n ) {
if ( n . right != null ) { return minValue ( n . right ) ; }
var p = n . parent ; while ( p != null && n == p . right ) { n = p ; p = p . parent ; } return p ; }
function minValue ( node ) { var current = node ;
while ( current . left != null ) { current = current . left ; } return current ; }
var root = null , temp = null , suc = null , min = null ; root = insert ( root , 20 ) ; root = insert ( root , 8 ) ; root = insert ( root , 22 ) ; root = insert ( root , 4 ) ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 14 ) ; temp = root . left . right . right ; suc = inOrderSuccessor ( root , temp ) ; if ( suc != null ) { document . write ( " " + temp . data + " " + suc . data ) ; } else { document . write ( " " ) ; }
function findPreSuc ( root , key ) { if ( root == null ) return ;
while ( root != null ) {
if ( root . key == key ) {
if ( root . right != null ) { suc = root . right ; while ( suc . left != null ) suc = suc . left ; }
if ( root . left != null ) { pre = root . left ; while ( pre . right != null ) pre = pre . right ; } return ; }
else if ( root . key < key ) { pre = root ; root = root . right ; }
else { suc = root ; root = root . left ; } } }
function newNode ( item ) { var temp = new Node ( ) ; temp . key = item ; temp . left = temp . right = null ; return temp ; }
function insert ( node , key ) { if ( node == null ) return newNode ( key ) ; if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ; return node ; }
var key = 65 ;
var root = null ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ; findPreSuc ( root , key ) ; if ( pre != null ) document . write ( " " + pre . key + " " ) ; else document . write ( " " ) ; if ( suc != null ) document . write ( " " + suc . key ) ; else document . write ( " " ) ;
class Node { constructor ( val ) { this . data = val ; this . left = null ; this . right = null ; } }
function createNode ( x ) { var p = new Node ( ) ; p . data = x ; p . left = p . right = null ; return p ; }
function insertNode ( root , x ) { var p = root , q = null ; while ( p != null ) { q = p ; if ( p . data < x ) p = p . right ; else p = p . left ; } if ( q == null ) p = createNode ( x ) ; else { if ( q . data < x ) q . right = createNode ( x ) ; else q . left = createNode ( x ) ; } }
function maxelpath ( q , x ) { var p = q ; var mx = - 1 ;
while ( p . data != x ) { if ( p . data > x ) { mx = Math . max ( mx , p . data ) ; p = p . left ; } else { mx = Math . max ( mx , p . data ) ; p = p . right ; } } return Math . max ( mx , x ) ; }
function maximumElement ( root , x , y ) { var p = root ;
while ( ( x < p . data && y < p . data ) || ( x > p . data && y > p . data ) ) {
if ( x < p . data && y < p . data ) p = p . left ;
else if ( x > p . data && y > p . data ) p = p . right ; }
return Math . max ( maxelpath ( p , x ) , maxelpath ( p , y ) ) ; }
var arr = [ 18 , 36 , 9 , 6 , 12 , 10 , 1 , 8 ] ; var a = 1 , b = 10 ; var n = arr . length ;
var root = createNode ( arr [ 0 ] ) ;
for ( i = 1 ; i < n ; i ++ ) insertNode ( root , arr [ i ] ) ; document . write ( maximumElement ( root , a , b ) ) ;
class Node { constructor ( ) { this . left = null , this . right = null ; this . info = 0 ;
this . lthread = false ;
this . rthread = false ; } }
function insert ( root , ikey ) {
var ptr = root ;
var par = null ; while ( ptr != null ) {
if ( ikey == ( ptr . info ) ) { document . write ( " " ) ; return root ; }
par = ptr ;
if ( ikey < ptr . info ) { if ( ptr . lthread == false ) ptr = ptr . left ; else break ; }
else { if ( ptr . rthread == false ) ptr = ptr . right ; else break ; } }
var tmp = new Node ( ) ; tmp . info = ikey ; tmp . lthread = true ; tmp . rthread = true ; if ( par == null ) { root = tmp ; tmp . left = null ; tmp . right = null ; } else if ( ikey < ( par . info ) ) { tmp . left = par . left ; tmp . right = par ; par . lthread = false ; par . left = tmp ; } else { tmp . left = par ; tmp . right = par . right ; par . rthread = false ; par . right = tmp ; } return root ; }
function inorderSuccessor ( ptr ) {
if ( ptr . rthread == true ) return ptr . right ;
ptr = ptr . right ; while ( ptr . lthread == false ) ptr = ptr . left ; return ptr ; }
function inorder ( root ) { if ( root == null ) document . write ( " " ) ;
var ptr = root ; while ( ptr . lthread == false ) ptr = ptr . left ;
while ( ptr != null ) { document . write ( ptr . info + " " ) ; ptr = inorderSuccessor ( ptr ) ; } }
var root = null ; root = insert ( root , 20 ) ; root = insert ( root , 10 ) ; root = insert ( root , 30 ) ; root = insert ( root , 5 ) ; root = insert ( root , 16 ) ; root = insert ( root , 14 ) ; root = insert ( root , 17 ) ; root = insert ( root , 13 ) ; inorder ( root ) ;
function createThreaded ( root ) {
if ( root == null ) return null ; if ( root . left == null && root . right == null ) return root ;
if ( root . left != null ) {
var l = createThreaded ( root . left ) ;
l . right = root ; l . isThreaded = true ; }
if ( root . right == null ) return root ;
return createThreaded ( root . right ) ; }
function leftMost ( root ) { while ( root != null && root . left != null ) root = root . left ; return root ; }
function inOrder ( root ) { if ( root == null ) return ;
var cur = leftMost ( root ) ; while ( cur != null ) { document . write ( cur . key + " " ) ;
if ( cur . isThreaded ) cur = cur . right ;
else cur = leftMost ( cur . right ) ; } }
function newNode ( key ) { var temp = new Node ( ) ; temp . left = temp . right = null ; temp . key = key ; return temp ; }
var root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 7 ) ; createThreaded ( root ) ; document . write ( " " + " " ) ; inOrder ( root ) ;
class Node { constructor ( key ) { this . key = key ; this . left = this . right = this . parent = null ; } } var root = null ;
function insert ( node , key ) {
if ( node == null ) return new Node ( key ) ;
if ( key < node . key ) { node . left = insert ( node . left , key ) ; node . left . parent = node ; } else if ( key > node . key ) { node . right = insert ( node . right , key ) ; node . right . parent = node ; }
return node ; }
function inorder ( root ) { var leftdone = false ;
while ( root != null ) {
if ( ! leftdone ) { while ( root . left != null ) { root = root . left ; } }
document . write ( root . key + " " ) ;
leftdone = true ;
if ( root . right != null ) { leftdone = false ; root = root . right ; }
else if ( root . parent != null ) {
while ( root . parent != null && root == root . parent . right ) root = root . parent ; if ( root . parent == null ) break ; root = root . parent ; } else break ; } }
root = insert ( root , 24 ) ; root = insert ( root , 27 ) ; root = insert ( root , 29 ) ; root = insert ( root , 34 ) ; root = insert ( root , 14 ) ; root = insert ( root , 4 ) ; root = insert ( root , 10 ) ; root = insert ( root , 22 ) ; root = insert ( root , 13 ) ; root = insert ( root , 3 ) ; root = insert ( root , 2 ) ; root = insert ( root , 6 ) ; document . write ( " " ) ; inorder ( root ) ;
class Node { constructor ( x ) { this . data = x ; this . left = null ; this . right = null ; } } let root ;
function Ceil ( node , input ) {
if ( node == null ) { return - 1 ; }
if ( node . data == input ) { return node . data ; }
if ( node . data < input ) { return Ceil ( node . right , input ) ; }
let ceil = Ceil ( node . left , input ) ; return ( ceil >= input ) ? ceil : node . data ; }
root = new Node ( 8 ) root . left = new Node ( 4 ) root . right = new Node ( 12 ) root . left . left = new Node ( 2 ) root . left . right = new Node ( 6 ) root . right . left = new Node ( 10 ) root . right . right = new Node ( 14 ) for ( let i = 0 ; i < 16 ; i ++ ) { document . write ( i + " " + Ceil ( root , i ) + " " ) ; }
function newNode ( item ) { var temp = new node ( ) ; temp . key = item ; temp . left = temp . right = null ; temp . count = 1 ; return temp ; }
function inorder ( root ) { if ( root != null ) { inorder ( root . left ) ; document . write ( root . key + " " + root . count + " " ) ; inorder ( root . right ) ; } }
function insert ( node , key ) {
if ( node == null ) return newNode ( key ) ;
if ( key == node . key ) { ( node . count ) ++ ; return node ; }
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
return node ; }
function minValueNode ( node ) { var current = node ;
while ( current . left != null ) current = current . left ; return current ; }
function deleteNode ( root , key ) {
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . count > 1 ) { ( root . count ) -- ; return root ; }
if ( root . left == null ) { var temp = root . right ; root = null ; return temp ; } else if ( root . right == null ) { var temp = root . left ; root = null ; return temp ; }
var temp = minValueNode ( root . right ) ;
root . key = temp . key ;
root . right = deleteNode ( root . right , temp . key ) ; } return root ; }
var root = null ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 20 ) ; root = insert ( root , 9 ) ; root = insert ( root , 11 ) ; root = insert ( root , 10 ) ; root = insert ( root , 12 ) ; root = insert ( root , 12 ) ; document . write ( " " + " " + " " ) ; inorder ( root ) ; document . write ( " " ) ; root = deleteNode ( root , 20 ) ; document . write ( " " + " " ) ; inorder ( root ) ; document . write ( " " ) ; root = deleteNode ( root , 12 ) ; document . write ( " " + " " ) ; inorder ( root ) ; document . write ( " " ) ; root = deleteNode ( root , 9 ) ; document . write ( " " + " " ) ; inorder ( root ) ;
function newNode ( item ) { var temp = new node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; return temp ; }
function inorder ( root ) { if ( root != null ) { inorder ( root . left ) ; document . write ( root . key + " " ) ; inorder ( root . right ) ; } }
function insert ( node , key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
return node ; }
function minValueNode ( Node ) { var current = Node ;
while ( current . left != null ) current = current . left ; return current ; }
function deleteNode ( root , key ) {
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . left == null ) { temp = root . right ; return temp ; } else if ( root . right == null ) { temp = root . left ; return temp ; }
var temp = minValueNode ( root . right ) ;
root . key = temp . key ;
root . right = deleteNode ( root . right , temp . key ) ; } return root ; }
function changeKey ( root , oldVal , newVal ) {
root = deleteNode ( root , oldVal ) ;
root = insert ( root , newVal ) ;
return root ; }
root = insert ( root , 50 ) ; root = insert ( root , 30 ) ; root = insert ( root , 20 ) ; root = insert ( root , 40 ) ; root = insert ( root , 70 ) ; root = insert ( root , 60 ) ; root = insert ( root , 80 ) ; document . write ( " " ) ; inorder ( root ) ; root = changeKey ( root , 40 , 10 ) ;
document . write ( " " ) ; inorder ( root ) ;
function isLeaf ( pre , n , min , max ) { if ( i >= n ) { return false ; } if ( pre [ i ] > min && pre [ i ] < max ) { i ++ ; let left = isLeaf ( pre , n , min , pre [ i - 1 ] ) ; let right = isLeaf ( pre , n , pre [ i - 1 ] , max ) ; if ( ! left && ! right ) { document . write ( pre [ i - 1 ] + " " ) ; } return true ; } return false ; } function printLeaves ( preorder , n ) { isLeaf ( preorder , n , Number . MIN_VALUE , Number . MAX_VALUE ) ; }
let preorder = [ 890 , 325 , 290 , 530 , 965 ] ; let n = preorder . length ; printLeaves ( preorder , n ) ;
function newNode ( item ) { var temp = new Node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; temp . parent = null ; return temp ; }
function inorder ( root ) { if ( root != null ) { inorder ( root . left ) ; document . write ( " " + root . key + " " ) ; if ( root . parent == null ) document . write ( " " ) ; else document . write ( " " + root . parent . key + " " ) ; inorder ( root . right ) ; } }
function insert ( node , key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) { var lchild = insert ( node . left , key ) ; node . left = lchild ;
lchild . parent = node ; } else if ( key > node . key ) { var rchild = insert ( node . right , key ) ; node . right = rchild ;
rchild . parent = node ; }
return node ; }
var root = null ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ;
inorder ( root ) ;
function pairs ( arr , n , k ) {
var smallest = 1000000000 ; var count = 0 ;
for ( var i = 0 ; i < n ; i ++ ) for ( var j = i + 1 ; j < n ; j ++ ) {
if ( Math . abs ( arr [ i ] + arr [ j ] - k ) < smallest ) { smallest = Math . abs ( arr [ i ] + arr [ j ] - k ) ; count = 1 ; }
else if ( Math . abs ( arr [ i ] + arr [ j ] - k ) == smallest ) count ++ ; }
document . write ( " " + smallest + " " ) ; document . write ( " " + count + " " ) ; }
var arr = [ 3 , 5 , 7 , 5 , 1 , 9 , 9 ] ; var k = 12 ; var n = arr . length ; pairs ( arr , n , k ) ;
var a = [ 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 ] ; var key = 20 ; var arraySize = a . length ; var count = 0 ; for ( i = 0 ; i < arraySize ; i ++ ) { if ( a [ i ] <= key ) { count += 1 ; } } document . write ( " " + key + " " + ( count - 1 ) ) ;
class Node { constructor ( d ) { this . info = d ; this . left = this . right = null ; } } let head ; let count = 0 ;
function insert ( node , info ) {
if ( node == null ) { return ( new Node ( info ) ) ; } else {
if ( info <= node . info ) { node . left = insert ( node . left , info ) ; } else { node . right = insert ( node . right , info ) ; }
return node ; } }
function check ( num ) { let sum = 0 , i = num , sum_of_digits , prod_of_digits ;
if ( num < 10 num > 99 ) return 0 ; else { sum_of_digits = ( i % 10 ) + Math . floor ( i / 10 ) ; prod_of_digits = ( i % 10 ) * Math . floor ( i / 10 ) ; sum = sum_of_digits + prod_of_digits ; } if ( sum == num ) return 1 ; else return 0 ; }
function countSpecialDigit ( rt ) { let x ; if ( rt == null ) return ; else { x = check ( rt . info ) ; if ( x == 1 ) count = count + 1 ; countSpecialDigit ( rt . left ) ; countSpecialDigit ( rt . right ) ; } }
let root = null ; root = insert ( root , 50 ) ; root = insert ( root , 29 ) ; root = insert ( root , 59 ) ; root = insert ( root , 19 ) ; root = insert ( root , 53 ) ; root = insert ( root , 556 ) ; root = insert ( root , 56 ) ; root = insert ( root , 94 ) ; root = insert ( root , 13 ) ;
countSpecialDigit ( root ) ; document . write ( count ) ;
let MAX_SIZE = 10 ;
function sortByRow ( mat , n , ascending ) { for ( let i = 0 ; i < n ; i ++ ) { if ( ascending ) mat [ i ] . sort ( function ( a , b ) { return a - b ; } ) ; else mat [ i ] . sort ( function ( a , b ) { return b - a ; } ) ; } }
function transpose ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) {
let temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ j ] [ i ] ; mat [ j ] [ i ] = temp ; } }
function sortMatRowAndColWise ( mat , n ) {
sortByRow ( mat , n , true ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n , false ) ;
transpose ( mat , n ) ; }
function printMat ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) document . write ( mat [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let n = 3 ; let mat = [ [ 3 , 2 , 1 ] , [ 9 , 8 , 7 ] , [ 6 , 5 , 4 ] ] ; document . write ( " " ) ; printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; document . write ( " " ) ; printMat ( mat , n ) ;
var MAX = 100 ; function middlesum ( mat , n ) { var row_sum = 0 , col_sum = 0 ;
for ( i = 0 ; i < n ; i ++ ) row_sum += mat [ parseInt ( n / 2 ) ] [ i ] ; document . write ( " " + row_sum + " " ) ;
for ( i = 0 ; i < n ; i ++ ) col_sum += mat [ i ] [ parseInt ( n / 2 ) ] ; document . write ( " " + col_sum ) ; }
var mat = [ [ 2 , 5 , 7 ] , [ 3 , 7 , 2 ] , [ 5 , 6 , 9 ] ] ; middlesum ( mat , 3 ) ;
var M = 3 ; var N = 3 ;
function rotateMatrix ( matrix , k ) {
var temp = Array ( M ) . fill ( 0 ) ;
k = k % M ; for ( i = 0 ; i < N ; i ++ ) {
for ( t = 0 ; t < M - k ; t ++ ) temp [ t ] = matrix [ i ] [ t ] ;
for ( j = M - k ; j < M ; j ++ ) matrix [ i ] [ j - M + k ] = matrix [ i ] [ j ] ;
for ( j = k ; j < M ; j ++ ) matrix [ i ] [ j ] = temp [ j - k ] ; } }
function displayMatrix ( matrix ) { for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < M ; j ++ ) document . write ( matrix [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
var matrix = [ [ 12 , 23 , 34 ] , [ 45 , 56 , 67 ] , [ 78 , 89 , 91 ] ] ; var k = 2 ;
rotateMatrix ( matrix , k ) ;
displayMatrix ( matrix ) ;
function interchangeFirstLast ( m ) { let rows = m . length ;
for ( let i = 0 ; i < m [ 0 ] . length ; i ++ ) { let t = m [ 0 ] [ i ] ; m [ 0 ] [ i ] = m [ rows - 1 ] [ i ] ; m [ rows - 1 ] [ i ] = t ; } }
let m = [ [ 8 , 9 , 7 , 6 ] , [ 4 , 7 , 6 , 5 ] , [ 3 , 2 , 1 , 8 ] , [ 9 , 9 , 7 , 7 ] ] interchangeFirstLast ( m ) ;
for ( let i = 0 ; i < m . length ; i ++ ) { for ( let j = 0 ; j < m [ 0 ] . length ; j ++ ) document . write ( m [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
function buildUtil ( In , post , inStrt , inEnd , postStrt , postEnd ) {
if ( inStrt > inEnd ) return null ;
let node = new Node ( post [ postEnd ] ) ;
if ( inStrt == inEnd ) return node ;
let iIndex = search ( In , inStrt , inEnd , node . data ) ;
node . left = buildUtil ( In , post , inStrt , iIndex - 1 , postStrt , postStrt - inStrt + iIndex - 1 ) ; node . right = buildUtil ( In , post , iIndex + 1 , inEnd , postEnd - inEnd + iIndex , postEnd - 1 ) ; return node ; }
function search ( arr , strt , end , value ) { let i ; for ( i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) break ; } return i ; }
function preOrder ( node ) { if ( node == null ) return ; document . write ( node . data + " " ) ; preOrder ( node . left ) ; preOrder ( node . right ) ; }
let In = [ 4 , 8 , 2 , 5 , 1 , 6 , 3 , 7 ] ; let post = [ 8 , 4 , 5 , 2 , 6 , 7 , 3 , 1 ] ; let n = In . length ; let root = buildUtil ( In , post , 0 , n - 1 , 0 , n - 1 ) ; document . write ( " " ) ; preOrder ( root ) ;
function sortRowWise ( m ) {
for ( let i = 0 ; i < m . length ; i ++ ) {
for ( let j = 0 ; j < m [ i ] . length ; j ++ ) {
for ( let k = 0 ; k < m [ i ] . length - j - 1 ; k ++ ) { if ( m [ i ] [ k ] > m [ i ] [ k + 1 ] ) {
let t = m [ i ] [ k ] ; m [ i ] [ k ] = m [ i ] [ k + 1 ] ; m [ i ] [ k + 1 ] = t ; } } } }
for ( let i = 0 ; i < m . length ; i ++ ) { for ( let j = 0 ; j < m [ i ] . length ; j ++ ) document . write ( m [ i ] [ j ] + " " ) ; document . write ( " " ) ; } return 0 ; }
let m = [ [ 9 , 8 , 7 , 1 ] , [ 7 , 3 , 0 , 2 ] , [ 9 , 5 , 3 , 2 ] , [ 6 , 3 , 1 , 2 ] ] ; sortRowWise ( m ) ;
let n = 3 function checkMarkov ( m ) {
for ( let i = 0 ; i < n ; i ++ ) {
let sum = 0 ; for ( let j = 0 ; j < n ; j ++ ) sum = sum + m [ i ] [ j ] ; if ( sum != 1 ) return false ; } return true ; }
let m = [ [ 0 , 0 , 1 ] , [ 0.5 , 0 , 0.5 ] , [ 1 , 0 , 0 ] ] ;
if ( checkMarkov ( m ) ) document . write ( " " ) ; else document . write ( " " ) ;
let N = 4 ;
function isDiagonalMatrix ( mat ) { for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < N ; j ++ )
if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ; return true ; }
let mat = [ [ 4 , 0 , 0 , 0 ] , [ 0 , 7 , 0 , 0 ] , [ 0 , 0 , 5 , 0 ] , [ 0 , 0 , 0 , 1 ] ] ; if ( isDiagonalMatrix ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
let N = 4 ;
function isScalarMatrix ( mat ) {
for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ;
for ( let i = 0 ; i < N - 1 ; i ++ ) if ( mat [ i ] [ i ] != mat [ i + 1 ] [ i + 1 ] ) return false ; return true ; }
let mat = [ [ 2 , 0 , 0 , 0 ] , [ 0 , 2 , 0 , 0 ] , [ 0 , 0 , 2 , 0 ] , [ 0 , 0 , 0 , 2 ] ] ;
if ( isScalarMatrix ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
let MAX_SIZE = 10 ;
function sortByRow ( mat , n ) { for ( let i = 0 ; i < n ; i ++ )
mat [ i ] . sort ( function ( a , b ) { return a - b ; } ) ; }
function transpose ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) {
let temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ j ] [ i ] ; mat [ j ] [ i ] = temp ; } }
function sortMatRowAndColWise ( mat , n ) {
sortByRow ( mat , n ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n ) ;
transpose ( mat , n ) ; }
function printMat ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) document . write ( mat [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let mat = [ [ 4 , 1 , 3 ] , [ 9 , 6 , 8 ] , [ 5 , 2 , 7 ] ] ; let n = 3 ; document . write ( " " ) ; printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; document . write ( " " ) ; printMat ( mat , n ) ;
function doublyEven ( n ) { var arr = Array ( n ) . fill ( 0 ) . map ( x => Array ( n ) . fill ( 0 ) ) ; var i , j ;
for ( i = 0 ; i < n ; i ++ ) for ( j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * i ) + j + 1 ;
for ( i = 0 ; i < parseInt ( n / 4 ) ; i ++ ) for ( j = 0 ; j < parseInt ( n / 4 ) ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < parseInt ( n / 4 ) ; i ++ ) for ( j = 3 * ( parseInt ( n / 4 ) ) ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * parseInt ( n / 4 ) ; i < n ; i ++ ) for ( j = 0 ; j < parseInt ( n / 4 ) ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * parseInt ( n / 4 ) ; i < n ; i ++ ) for ( j = 3 * parseInt ( n / 4 ) ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = parseInt ( n / 4 ) ; i < 3 * parseInt ( n / 4 ) ; i ++ ) for ( j = parseInt ( n / 4 ) ; j < 3 * parseInt ( n / 4 ) ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) document . write ( arr [ i ] [ j ] + " " ) ; document . write ( ' ' ) ; } }
var n = 8 ;
doublyEven ( n ) ;
var N = 3
function isMagicSquare ( mat ) {
var sum = 0 , sum2 = 0 ; for ( var i = 0 ; i < N ; i ++ ) sum = sum + mat [ i ] [ i ] ;
for ( var i = 0 ; i < N ; i ++ ) sum2 = sum2 + mat [ i ] [ N - 1 - i ] ; if ( sum != sum2 ) return false ;
for ( var i = 0 ; i < N ; i ++ ) { var rowSum = 0 ; for ( var j = 0 ; j < N ; j ++ ) rowSum += mat [ i ] [ j ] ;
if ( rowSum != sum ) return false ; }
for ( var i = 0 ; i < N ; i ++ ) { var colSum = 0 ; for ( var j = 0 ; j < N ; j ++ ) colSum += mat [ j ] [ i ] ;
if ( sum != colSum ) return false ; } return true ; }
var mat = [ [ 2 , 7 , 6 ] , [ 9 , 5 , 1 ] , [ 4 , 3 , 8 ] ] ; if ( isMagicSquare ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
function subCount ( arr , n , k ) {
var mod = Array ( k ) . fill ( 0 ) ;
var cumSum = 0 ; for ( var i = 0 ; i < n ; i ++ ) { cumSum += arr [ i ] ;
mod [ ( ( cumSum % k ) + k ) % k ] ++ ; }
var result = 0 ;
for ( var i = 0 ; i < k ; i ++ )
if ( mod [ i ] > 1 ) result += ( mod [ i ] * ( mod [ i ] - 1 ) ) / 2 ;
result += mod [ 0 ] ; return result ; }
function countSubmatrix ( mat , n , k ) {
var tot_count = 0 ; var left , right , i ; var temp = Array ( n ) ;
for ( left = 0 ; left < n ; left ++ ) {
for ( right = left ; right < n ; right ++ ) {
for ( i = 0 ; i < n ; ++ i ) temp [ i ] += mat [ i ] [ right ] ;
tot_count += subCount ( temp , n , k ) ; } }
return tot_count ; }
var mat = [ [ 5 , - 1 , 6 ] , [ - 2 , 3 , 8 ] , [ 7 , 4 , - 9 ] ] ; var n = 3 , k = 4 ; document . write ( " " + countSubmatrix ( mat , n , k ) ) ;
function findMinOpeartion ( matrix , n ) {
let sumRow = new Array ( n ) ; let sumCol = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) { sumRow [ i ] = 0 ; sumCol [ i ] = 0 ; }
for ( let i = 0 ; i < n ; ++ i ) for ( let j = 0 ; j < n ; ++ j ) { sumRow [ i ] += matrix [ i ] [ j ] ; sumCol [ j ] += matrix [ i ] [ j ] ; }
let maxSum = 0 ; for ( let i = 0 ; i < n ; ++ i ) { maxSum = Math . max ( maxSum , sumRow [ i ] ) ; maxSum = Math . max ( maxSum , sumCol [ i ] ) ; } let count = 0 ; for ( let i = 0 , j = 0 ; i < n && j < n ; ) {
let diff = Math . min ( maxSum - sumRow [ i ] , maxSum - sumCol [ j ] ) ;
matrix [ i ] [ j ] += diff ; sumRow [ i ] += diff ; sumCol [ j ] += diff ;
count += diff ;
if ( sumRow [ i ] == maxSum ) ++ i ;
if ( sumCol [ j ] == maxSum ) ++ j ; } return count ; }
function printMatrix ( matrix , n ) { for ( let i = 0 ; i < n ; ++ i ) { for ( let j = 0 ; j < n ; ++ j ) document . write ( matrix [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let matrix = [ [ 1 , 2 ] , [ 3 , 4 ] ] ; document . write ( findMinOpeartion ( matrix , 2 ) + " " ) ; printMatrix ( matrix , 2 ) ;
function find ( n , k ) { if ( n + 1 >= k ) return ( k - 1 ) ; else return ( 2 * n + 1 - k ) ; }
var n = 4 , k = 7 ; var freq = find ( n , k ) ; if ( freq < 0 ) document . write ( " " ) ; else document . write ( " " + k + " " + freq + " " ) ;
function ZigZag ( rows , columns , numbers ) { let k = 0 ;
let arr = new Array ( rows ) ; for ( let i = 0 ; i < rows ; i ++ ) { arr [ i ] = new Array ( rows ) ; for ( let j = 0 ; j < columns ; j ++ ) { arr [ i ] [ j ] = 0 ; } } for ( let i = 0 ; i < rows ; i ++ ) {
if ( i % 2 == 0 ) {
for ( let j = 0 ; j < columns && numbers [ k ] > 0 ; j ++ ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } }
else {
for ( let j = columns - 1 ; j >= 0 && numbers [ k ] > 0 ; j -- ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } } }
for ( let i = 0 ; i < rows ; i ++ ) { for ( let j = 0 ; j < columns ; j ++ ) document . write ( arr [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let rows = 4 ; let columns = 5 ; let Numbers = [ 3 , 4 , 2 , 2 , 3 , 1 , 5 ] ; ZigZag ( rows , columns , Numbers ) ;
let n = 5 ;
function FindMaxProduct ( arr , n ) { let max = 0 , result ;
for ( let i = 0 ; i < n ; i ++ ) {
for ( let j = 0 ; j < n ; j ++ ) {
if ( ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i ] [ j - 1 ] * arr [ i ] [ j - 2 ] * arr [ i ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j ] * arr [ i - 2 ] [ j ] * arr [ i - 3 ] [ j ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j - 1 ] * arr [ i - 2 ] [ j - 2 ] * arr [ i - 3 ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 1 ) <= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j + 1 ] * arr [ i - 2 ] [ j + 2 ] * arr [ i - 3 ] [ j + 3 ] ; if ( max < result ) max = result ; } } } return max ; }
let arr = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 6 , 7 , 8 , 9 , 1 ] , [ 2 , 3 , 4 , 5 , 6 ] , [ 7 , 8 , 9 , 1 , 0 ] , [ 9 , 6 , 4 , 2 , 3 ] ] ; document . write ( FindMaxProduct ( arr , n ) ) ;
/ *JavaScript Program to find minimum flip required to make Binary Matrix symmetric along main diagonal
function minimumflip ( mat , n ) { let transpose = new Array ( n ) ; for ( var i = 0 ; i < transpose . length ; i ++ ) { transpose [ i ] = new Array ( 2 ) ; }
for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n ; j ++ ) transpose [ i ] [ j ] = mat [ j ] [ i ] ;
let flip = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n ; j ++ ) if ( transpose [ i ] [ j ] != mat [ i ] [ j ] ) flip ++ ; return flip / 2 ; }
let n = 3 ; let mat = [ [ 0 , 0 , 1 ] , [ 1 , 1 , 1 ] , [ 1 , 0 , 0 ] ] ; document . write ( minimumflip ( mat , n ) ) ;
function minimumflip ( mat , n ) {
let flip = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) flip ++ ; return flip ; }
let n = 3 ; let mat = [ [ 0 , 0 , 1 ] , [ 1 , 1 , 1 ] , [ 1 , 0 , 0 ] ] ; document . write ( minimumflip ( mat , n ) ) ;
function isLowerTriangularMatrix ( mat ) { for ( let i = 0 ; i < N ; i ++ ) for ( let j = i + 1 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
let mat = [ [ 1 , 0 , 0 , 0 ] , [ 1 , 4 , 0 , 0 ] , [ 4 , 6 , 2 , 0 ] , [ 0 , 4 , 7 , 6 ] ] ;
if ( isLowerTriangularMatrix ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
function isUpperTriangularMatrix ( mat ) { for ( let i = 1 ; i < N ; i ++ ) for ( let j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
let mat = [ [ 1 , 3 , 5 , 3 ] , [ 0 , 4 , 6 , 2 ] , [ 0 , 0 , 2 , 5 ] , [ 0 , 0 , 0 , 6 ] ] ; if ( isUpperTriangularMatrix ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
let MAX = 100 ;
function freq ( ar , m , n ) { let even = 0 , odd = 0 ; for ( let i = 0 ; i < m ; ++ i ) { for ( let j = 0 ; j < n ; ++ j ) {
if ( ( ar [ i ] [ j ] % 2 ) == 0 ) ++ even ; else ++ odd ; } }
document . write ( " " + odd + " " ) ; document . write ( " " + even + " " ) ; }
let m = 3 , n = 3 ; let array = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] ; freq ( array , m , n ) ;
const MAX = 100 ;
function HalfDiagonalSums ( mat , n ) {
let diag1_left = 0 , diag1_right = 0 ; let diag2_left = 0 , diag2_right = 0 ; for ( let i = 0 , j = n - 1 ; i < n ; i ++ , j -- ) { if ( i < parseInt ( n / 2 ) ) { diag1_left += mat [ i ] [ i ] ; diag2_left += mat [ j ] [ i ] ; } else if ( i > parseInt ( n / 2 ) ) { diag1_right += mat [ i ] [ i ] ; diag2_right += mat [ j ] [ i ] ; } } return ( diag1_left == diag2_right && diag2_right == diag2_left && diag1_right == diag2_left && diag2_right == mat [ parseInt ( n / 2 ) ] [ parseInt ( n / 2 ) ] ) ; }
let a = [ [ 2 , 9 , 1 , 4 , - 2 ] , [ 6 , 7 , 2 , 11 , 4 ] , [ 4 , 2 , 9 , 2 , 4 ] , [ 1 , 9 , 2 , 4 , 4 ] , [ 0 , 2 , 4 , 2 , 5 ] ] ; document . write ( HalfDiagonalSums ( a , 5 ) ? " " : " " ) ;
let MAX = 100 ; function isIdentity ( mat , N ) { for ( let row = 0 ; row < N ; row ++ ) { for ( let col = 0 ; col < N ; col ++ ) { if ( row == col && mat [ row ] [ col ] != 1 ) return false ; else if ( row != col && mat [ row ] [ col ] != 0 ) return false ; } } return true ; }
let N = 4 ; let mat = [ [ 1 , 0 , 0 , 0 ] , [ 0 , 1 , 0 , 0 ] , [ 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 1 ] ] ; if ( isIdentity ( mat , N ) ) document . write ( " " ) ; else document . write ( " " ) ;
function modPower ( a , t , mod ) { let now = a , ret = 1 ;
while ( t > 0 ) { if ( t % 2 == 1 ) ret = now * ( ret % mod ) ; now = now * ( now % mod ) ; t >>= 1 ; } return ret ; }
function countWays ( n , m , k ) {
if ( n == 1 m == 1 ) return 1 ;
else if ( ( n + m ) % 2 == 1 && k == - 1 ) return 0 ;
return ( modPower ( modPower ( 2 , n - 1 , mod ) , m - 1 , mod ) % mod ) ; }
let n = 2 , m = 7 , k = 1 ; document . write ( countWays ( n , m , k ) ) ;
let MAX = 100 ; function imageSwap ( mat , n ) {
let row = 0 ;
for ( let j = 0 ; j < n ; j ++ ) {
let s = [ ] ; let i = row , k = j ; while ( i < n && k >= 0 ) { s . push ( mat [ i ++ ] [ k -- ] ) ; }
i = row ; k = j ; while ( i < n && k >= 0 ) { mat [ i ++ ] [ k -- ] = s [ s . length - 1 ] ; s . pop ( ) ; } }
let column = n - 1 ; for ( let j = 1 ; j < n ; j ++ ) {
let s = [ ] ; let i = j , k = column ; while ( i < n && k >= 0 ) { s . push ( mat [ i ++ ] [ k -- ] ) ; }
i = j ; k = column ; while ( i < n && k >= 0 ) { mat [ i ++ ] [ k -- ] = s [ s . length - 1 ] ; s . pop ( ) ; } } }
function printMatrix ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) { document . write ( mat [ i ] [ j ] + " " ) ; } document . write ( " " ) ; } }
let mat = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 ] ] ; let n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ;
let MAX = 100 ; function imageSwap ( mat , n ) {
for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j <= i ; j ++ ) mat [ i ] [ j ] = mat [ i ] [ j ] + mat [ j ] [ i ] - ( mat [ j ] [ i ] = mat [ i ] [ j ] ) ; }
function printMatrix ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) document . write ( mat [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let mat = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 ] ] ; let n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ;
var m = 3 ;
var n = 2 ;
function countSets ( a ) {
var res = 0 ;
for ( i = 0 ; i < n ; i ++ ) { var u = 0 , v = 0 ; for ( j = 0 ; j < m ; j ++ ) { if ( a [ i ] [ j ] == 1 ) u ++ ; else v ++ ; } res += Math . pow ( 2 , u ) - 1 + Math . pow ( 2 , v ) - 1 ; }
for ( i = 0 ; i < m ; i ++ ) { var u = 0 , v = 0 ; for ( j = 0 ; j < n ; j ++ ) { if ( a [ j ] [ i ] == 1 ) u ++ ; else v ++ ; } res += Math . pow ( 2 , u ) - 1 + Math . pow ( 2 , v ) - 1 ; }
return res - ( n * m ) ; }
var a = [ [ 1 , 0 , 1 ] , [ 0 , 1 , 0 ] ] ; document . write ( countSets ( a ) ) ;
function search ( mat , n , x ) { if ( n == 0 ) return - 1 ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ )
if ( mat [ i ] [ j ] == x ) { document . write ( " " + i + " " + j + " " ) ; return 1 ; } } document . write ( " " ) ; return 0 ; }
let mat = [ [ 10 , 20 , 30 , 40 ] , [ 15 , 25 , 35 , 45 ] , [ 27 , 29 , 37 , 48 ] , [ 32 , 33 , 39 , 50 ] ] ; search ( mat , 4 , 29 ) ;
function fill0X ( m , n ) {
let i , k = 0 , l = 0 ;
let r = m , c = n ;
let a = new Array ( m ) ; for ( let i = 0 ; i < m ; i ++ ) { a [ i ] = new Array ( n ) ; }
let x = ' ' ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) { a [ k ] [ i ] = x ; } k ++ ;
for ( i = k ; i < m ; ++ i ) { a [ i ] [ n - 1 ] = x ; } n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = x ; m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) { a [ i ] [ l ] = x ; } l ++ ; }
x = ( x == ' ' ) ? ' ' : ' ' ; }
for ( i = 0 ; i < r ; i ++ ) { for ( let j = 0 ; j < c ; j ++ ) { document . write ( a [ i ] [ j ] + " " ) ; } document . write ( " " ) ; } }
document . write ( " " ) ; fill0X ( 5 , 6 ) ; document . write ( " " ) ; fill0X ( 4 , 4 ) ; document . write ( " " ) ; fill0X ( 3 , 4 ) ;
class NodeTemp { constructor ( data ) { this . data = data ; this . next = this . child = null ; } }
function addSibling ( node , data ) { if ( node == null ) return null ; while ( node . next != null ) node = node . next ; return ( node . next = new NodeTemp ( data ) ) ; }
function addChild ( node , data ) { if ( node == null ) return null ;
if ( node . child != null ) return ( addSibling ( node . child , data ) ) ; else return ( node . child = new NodeTemp ( data ) ) ; }
function traverseTree ( root ) { if ( root == null ) return ; while ( root != null ) { document . write ( root . data + " " ) ; if ( root . child != null ) traverseTree ( root . child ) ; root = root . next ; } }
let root = new NodeTemp ( 10 ) ; let n1 = addChild ( root , 2 ) ; let n2 = addChild ( root , 3 ) ; let n3 = addChild ( root , 4 ) ; let n4 = addChild ( n3 , 6 ) ; let n5 = addChild ( root , 5 ) ; let n6 = addChild ( n5 , 7 ) ; let n7 = addChild ( n5 , 8 ) ; let n8 = addChild ( n5 , 9 ) ; traverseTree ( root ) ;
let SIZE = 100 ;
function calculateEnergy ( mat , n ) { let i_des , j_des , q ; let tot_energy = 0 ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
q = Math . floor ( mat [ i ] [ j ] / n ) ;
i_des = q ; j_des = mat [ i ] [ j ] - ( n * q ) ;
tot_energy += Math . abs ( i_des - i ) + Math . abs ( j_des - j ) ; } }
return tot_energy ; }
let mat = [ [ 4 , 7 , 0 , 3 ] , [ 8 , 5 , 6 , 1 ] , [ 9 , 11 , 10 , 2 ] , [ 15 , 13 , 14 , 12 ] ] ; let n = 4 ; document . write ( " " + calculateEnergy ( mat , n ) + " " ) ;
let MAX = 100 ;
function isUnique ( mat , i , j , n , m ) {
let sumrow = 0 ; for ( let k = 0 ; k < m ; k ++ ) { sumrow += mat [ i ] [ k ] ; if ( sumrow > 1 ) return false ; }
let sumcol = 0 ; for ( let k = 0 ; k < n ; k ++ ) { sumcol += mat [ k ] [ j ] ; if ( sumcol > 1 ) return false ; } return true ; } function countUnique ( mat , n , m ) { let uniquecount = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] != 0 && isUnique ( mat , i , j , n , m ) ) uniquecount ++ ; return uniquecount ; }
let mat = [ [ 0 , 1 , 0 , 0 ] , [ 0 , 0 , 1 , 0 ] , [ 1 , 0 , 0 , 1 ] ] ; document . write ( countUnique ( mat , 3 , 4 ) ) ;
let MAX = 100 ; function countUnique ( mat , n , m ) { let rowsum = new Array ( n ) ; rowsum . fill ( 0 ) ; let colsum = new Array ( m ) ; colsum . fill ( 0 ) ;
for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] != 0 ) { rowsum [ i ] ++ ; colsum [ j ] ++ ; }
let uniquecount = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] != 0 && rowsum [ i ] == 1 && colsum [ j ] == 1 ) uniquecount ++ ; return uniquecount ; }
let mat = [ [ 0 , 1 , 0 , 0 ] , [ 0 , 0 , 1 , 0 ] , [ 1 , 0 , 0 , 1 ] ] ; document . write ( countUnique ( mat , 3 , 4 ) ) ;
for ( let i = 0 ; i < m ; ++ i ) for ( let j = 0 ; j < n ; ++ j ) if ( array [ i ] [ j ] == 0 ) ++ counter ; return ( counter > parseInt ( ( m * n ) / 2 ) , 10 ) ; }
let array = [ [ 1 , 0 , 3 ] , [ 0 , 0 , 4 ] , [ 6 , 0 , 0 ] ] ; let m = 3 , n = 3 ; if ( isSparse ( array , m , n ) ) document . write ( " " ) ; else document . write ( " " ) ;
let MAX = 100 ;
function countCommon ( mat , n ) { let res = 0 ; for ( let i = 0 ; i < n ; i ++ ) if ( mat [ i ] [ i ] == mat [ i ] [ n - i - 1 ] ) res ++ ; return res ; }
let mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] ; document . write ( countCommon ( mat , 3 ) ) ;
function areSumSame ( a , n , m ) { let sum1 = 0 , sum2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { sum1 = 0 ; sum2 = 0 ; for ( let j = 0 ; j < m ; j ++ ) { sum1 += a [ i ] [ j ] ; sum2 += a [ j ] [ i ] ; } if ( sum1 == sum2 ) return true ; } return false ; }
let n = 4 ;
let m = 4 ; let M = [ [ 1 , 2 , 3 , 4 ] , [ 9 , 5 , 3 , 1 ] , [ 0 , 3 , 5 , 6 ] , [ 0 , 4 , 5 , 6 ] ] ; if ( areSumSame ( M , n , m ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
class Node {
constructor ( data ) { this . data = data ; this . next = this . child = null ; } }
function addSibling ( n , data ) { if ( n == null ) return null ; while ( n . next != null ) n = n . next ; return ( n . next = new Node ( data ) ) ; }
function addChild ( n , data ) { if ( n == null ) return null ;
if ( n . child != null ) return addSibling ( n . child , data ) ; else return ( n . child = new Node ( data ) ) ; }
function traverseTree ( root ) {
if ( root == null ) return ; document . write ( root . data + " " ) ; if ( root . child == null ) return ;
let q = [ ] ; let curr = root . child ; q . push ( curr ) ; while ( q . length != 0 ) {
curr = q [ 0 ] ; q . shift ( ) ;
while ( curr != null ) { document . write ( curr . data + " " ) ; if ( curr . child != null ) { q . push ( curr . child ) ; } curr = curr . next ; } } }
let root = new Node ( 10 ) ; let n1 = addChild ( root , 2 ) ; let n2 = addChild ( root , 3 ) ; let n3 = addChild ( root , 4 ) ; let n4 = addChild ( n3 , 6 ) ; let n5 = addChild ( root , 5 ) ; let n6 = addChild ( n5 , 7 ) ; let n7 = addChild ( n5 , 8 ) ; let n8 = addChild ( n5 , 9 ) ; traverseTree ( root ) ;
var N = 4
function findMax ( arr ) { var row = 0 , i , j ; for ( i = 0 , j = N - 1 ; i < N ; i ++ ) {
while ( arr [ i ] [ j ] == 1 && j >= 0 ) { row = i ; j -- ; } } document . write ( " " + ( row + 1 ) ) ; document . write ( " " + ( N - 1 - j ) ) ; }
var arr = [ [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 0 ] , [ 0 , 1 , 1 , 1 ] ] ; findMax ( arr ) ;
function transpose ( mat , tr , N ) { for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) tr [ i ] [ j ] = mat [ j ] [ i ] ; }
function isSymmetric ( mat , N ) { let tr = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { tr [ i ] = new Array ( MAX ) ; } transpose ( mat , tr , N ) ; for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != tr [ i ] [ j ] ) return false ; return true ; }
let mat = [ [ 1 , 3 , 5 ] , [ 3 , 2 , 4 ] , [ 5 , 4 , 1 ] ] ; if ( isSymmetric ( mat , 3 ) ) document . write ( " " ) ; else document . write ( " " ) ;
function isSymmetric ( mat , N ) { for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) return false ; return true ; }
let mat = [ [ 1 , 3 , 5 ] , [ 3 , 2 , 4 ] , [ 5 , 4 , 1 ] ] ; if ( isSymmetric ( mat , 3 ) ) document . write ( " " ) ; else document . write ( " " ) ;
function isPalin ( str ) { let len = str . length / 2 ; for ( let i = 0 ; i < len ; i ++ ) { if ( str [ i ] != str [ str . length - i - 1 ] ) return false ; } return true ; }
function palindromicPath ( str , a , i , j , m , n ) {
if ( j < m - 1 i < n - 1 ) { if ( i < n - 1 ) palindromicPath ( str + a [ i ] [ j ] , a , i + 1 , j , m , n ) ; if ( j < m - 1 ) palindromicPath ( str + a [ i ] [ j ] , a , i , j + 1 , m , n ) ; }
else { str = str + a [ n - 1 ] [ m - 1 ] ; if ( isPalin ( str ) ) document . write ( str + " " ) ; } }
let arr = [ [ ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' ] ] let str = " " palindromicPath ( str , arr , 0 , 0 , 4 , 3 )
let n = 4 ; let m = 4 ;
function findPossibleMoves ( mat , p , q ) {
let X = [ 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 ] ; let Y = [ 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 ] ; let count = 0 ;
for ( let i = 0 ; i < 8 ; i ++ ) {
let x = p + X [ i ] ; let y = q + Y [ i ] ;
if ( x >= 0 && y >= 0 && x < n && y < m && mat [ x ] [ y ] == 0 ) count ++ ; }
return count ; }
let mat = [ [ 1 , 0 , 1 , 0 ] , [ 0 , 1 , 1 , 1 ] , [ 1 , 1 , 0 , 1 ] , [ 0 , 1 , 1 , 1 ] ] ; let p = 2 , q = 2 ; document . write ( findPossibleMoves ( mat , p , q ) ) ;
const MAX = 100 ; void printDiagonalSums ( mat , n ) { let principal = 0 , secondary = 0 ; for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( i == j ) principal += mat [ i ] [ j ] ;
if ( ( i + j ) == ( n - 1 ) ) secondary += mat [ i ] [ j ] ; } } document . write ( " " + principal + " " ) ; document . write ( " " + secondary + " " ) ; }
let a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] ; printDiagonalSums ( a , 4 ) ;
function printDiagonalSums ( mat , n ) { let principal = 0 , secondary = 0 ; for ( let i = 0 ; i < n ; i ++ ) { principal += mat [ i ] [ i ] ; secondary += mat [ i ] [ n - i - 1 ] ; } document . write ( " " + principal + " " ) ; document . write ( " " + secondary ) ; }
let a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] ; printDiagonalSums ( a , 4 ) ;
function getBoundarySum ( a , m , n ) { let sum = 0 ; for ( let i = 0 ; i < m ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) { if ( i == 0 ) sum += a [ i ] [ j ] ; else if ( i == m - 1 ) sum += a [ i ] [ j ] ; else if ( j == 0 ) sum += a [ i ] [ j ] ; else if ( j == n - 1 ) sum += a [ i ] [ j ] ; } } return sum ; }
let a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] ; let sum = getBoundarySum ( a , 4 , 4 ) ; document . write ( " " + " " + sum ) ;
const MAX = 100 ; function printSpiral ( mat , r , c ) { let i , a = 0 , b = 2 ; let low_row = ( 0 > a ) ? 0 : a ; let low_column = ( 0 > b ) ? 0 : b - 1 ; let high_row = ( ( a + 1 ) >= r ) ? r - 1 : a + 1 ; let high_column = ( ( b + 1 ) >= c ) ? c - 1 : b + 1 ; while ( ( low_row > 0 - r && low_column > 0 - c ) ) { for ( i = low_column + 1 ; i <= high_column && i < c && low_row >= 0 ; ++ i ) document . write ( mat [ low_row ] [ i ] + " " ) ; low_row -= 1 ; for ( i = low_row + 2 ; i <= high_row && i < r && high_column < c ; ++ i ) document . write ( mat [ i ] [ high_column ] + " " ) ; high_column += 1 ; for ( i = high_column - 2 ; i >= low_column && i >= 0 && high_row < r ; -- i ) document . write ( mat [ high_row ] [ i ] + " " ) ; high_row += 1 ; for ( i = high_row - 2 ; i > low_row && i >= 0 && low_column >= 0 ; -- i ) document . write ( mat [ i ] [ low_column ] + " " ) ; low_column -= 1 ; } document . write ( " " ) ; }
let mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] ; let r = 3 , c = 3 ;
printSpiral ( mat , r , c ) ;
let N = 3 ;
function interchangeDiagonals ( array ) {
for ( let i = 0 ; i < N ; ++ i ) if ( i != parseInt ( N / 2 ) ) { let temp = array [ i ] [ i ] ; array [ i ] [ i ] = array [ i ] [ N - i - 1 ] ; array [ i ] [ N - i - 1 ] = temp ; } for ( let i = 0 ; i < N ; ++ i ) { for ( let j = 0 ; j < N ; ++ j ) document . write ( " " + array [ i ] [ j ] ) ; document . write ( " " ) ; } }
let array = [ [ 4 , 5 , 6 ] , [ 1 , 2 , 3 ] , [ 7 , 8 , 9 ] ] ; interchangeDiagonals ( array ) ;
function difference ( arr , n ) {
let d1 = 0 , d2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( i == j ) d1 += arr [ i ] [ j ] ;
if ( i == n - j - 1 ) d2 += arr [ i ] [ j ] ; } }
return Math . abs ( d1 - d2 ) ; }
let n = 3 ; let arr = [ [ 11 , 2 , 4 ] , [ 4 , 5 , 6 ] , [ 10 , 8 , - 12 ] ] ; document . write ( difference ( arr , n ) ) ;
function difference ( arr , n ) {
let d1 = 0 , d2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { d1 += arr [ i ] [ i ] ; d2 += arr [ i ] [ n - i - 1 ] ; }
return Math . abs ( d1 - d2 ) ; }
let n = 3 ; let arr = [ [ 11 , 2 , 4 ] , [ 4 , 5 , 6 ] , [ 10 , 8 , - 12 ] ] ; document . write ( difference ( arr , n ) ) ;
function spiralFill ( m , n , a ) {
let val = 1 ;
let k = 0 , l = 0 ; while ( k < m && l < n ) {
for ( let i = l ; i < n ; ++ i ) a [ k ] [ i ] = val ++ ; k ++ ;
for ( let i = k ; i < m ; ++ i ) a [ i ] [ n - 1 ] = val ++ ; n -- ;
if ( k < m ) { for ( let i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = val ++ ; m -- ; }
if ( l < n ) { for ( let i = m - 1 ; i >= k ; -- i ) a [ i ] [ l ] = val ++ ; l ++ ; } } }
let m = 4 , n = 4 ; let a = Array . from ( Array ( MAX ) , ( ) => new Array ( MAX ) ) ; spiralFill ( m , n , a ) ; for ( let i = 0 ; i < m ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) document . write ( a [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
let MAX = 100 ;
function maxMin ( arr , n ) { let min = + 2147483647 ; let max = - 2147483648 ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j <= n / 2 ; j ++ ) {
if ( arr [ i ] [ j ] > arr [ i ] [ n - j - 1 ] ) { if ( min > arr [ i ] [ n - j - 1 ] ) min = arr [ i ] [ n - j - 1 ] ; if ( max < arr [ i ] [ j ] ) max = arr [ i ] [ j ] ; } else { if ( min > arr [ i ] [ j ] ) min = arr [ i ] [ j ] ; if ( max < arr [ i ] [ n - j - 1 ] ) max = arr [ i ] [ n - j - 1 ] ; } } } document . write ( " " + max + " " + min ) ; }
let arr = [ [ 5 , 9 , 11 ] , [ 25 , 0 , 14 ] , [ 21 , 6 , 4 ] ] ; maxMin ( arr , 3 ) ;
function antiSpiralTraversal ( m , n , a ) { let i , k = 0 , l = 0 ;
let stk = [ ] ; while ( k <= m && l <= n ) {
for ( i = l ; i <= n ; ++ i ) stk . push ( a [ k ] [ i ] ) ; k ++ ;
for ( i = k ; i <= m ; ++ i ) stk . push ( a [ i ] [ n ] ) ; n -- ;
if ( k <= m ) { for ( i = n ; i >= l ; -- i ) stk . push ( a [ m ] [ i ] ) ; m -- ; }
if ( l <= n ) { for ( i = m ; i >= k ; -- i ) stk . push ( a [ i ] [ l ] ) ; l ++ ; } } while ( stk . length != 0 ) { document . write ( stk [ stk . length - 1 ] + " " ) ; stk . pop ( ) ; } }
let mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 6 , 7 , 8 , 9 , 10 ] , [ 11 , 12 , 13 , 14 , 15 ] , [ 16 , 17 , 18 , 19 , 20 ] ] ; antiSpiralTraversal ( mat . length - 1 , mat [ 0 ] . length - 1 , mat ) ;
var MAX = 100 ;
function findNormal ( mat , n ) { var sum = 0 ; for ( var i = 0 ; i < n ; i ++ ) for ( var j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] * mat [ i ] [ j ] ; return parseInt ( Math . sqrt ( sum ) ) ; }
function findTrace ( mat , n ) { var sum = 0 ; for ( var i = 0 ; i < n ; i ++ ) sum += mat [ i ] [ i ] ; return sum ; }
var mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] ; document . write ( " " + findTrace ( mat , 5 ) + " " ) ; document . write ( " " + findNormal ( mat , 5 ) ) ;
function minOperation ( arr ) { let ans = 0 ; for ( let i = N - 1 ; i >= 0 ; i -- ) { for ( let j = M - 1 ; j >= 0 ; j -- ) {
if ( arr [ i ] [ j ] == false ) {
ans ++ ;
for ( let k = 0 ; k <= i ; k ++ ) { for ( let h = 0 ; h <= j ; h ++ ) {
if ( arr [ k ] [ h ] == true ) { arr [ k ] [ h ] = false ; } else { arr [ k ] [ h ] = true ; } } } } } } return ans ; }
let mat = [ [ 0 , 0 , 1 , 1 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] ] document . write ( minOperation ( mat ) )
function findSum ( n ) { let ans = 0 , temp = 0 , num ;
for ( let i = 1 ; i <= n && temp < n ; i ++ ) {
temp = i - 1 ;
num = 1 ; while ( temp < n ) { if ( temp + i <= n ) ans += ( i * num ) ; else ans += ( ( n - temp ) * num ) ; temp += i ; num ++ ; } } return ans ; }
let N = 2 ; document . write ( findSum ( N ) ) ;
function printCoils ( n ) {
let m = 8 * n * n ;
let coil1 = new Array ( m ) ; coil1 . fill ( 0 ) ;
coil1 [ 0 ] = 8 * n * n + 2 * n ; let curr = coil1 [ 0 ] ; let nflg = 1 , step = 2 ;
let index = 1 ; while ( index < m ) {
for ( let i = 0 ; i < step ; i ++ ) {
curr = coil1 [ index ++ ] = ( curr - 4 * n * nflg ) ; if ( index >= m ) break ; } if ( index >= m ) break ;
for ( let i = 0 ; i < step ; i ++ ) { curr = coil1 [ index ++ ] = curr + nflg ; if ( index >= m ) break ; } nflg = nflg * ( - 1 ) ; step += 2 ; }
let coil2 = new Array ( m ) ; coil2 . fill ( 0 ) ; for ( let i = 0 ; i < 8 * n * n ; i ++ ) coil2 [ i ] = 16 * n * n + 1 - coil1 [ i ] ;
document . write ( " " ) ; for ( let i = 0 ; i < 8 * n * n ; i ++ ) document . write ( coil1 [ i ] + " " ) ; document . write ( " " + " " ) ; for ( let i = 0 ; i < 8 * n * n ; i ++ ) document . write ( coil2 [ i ] + " " ) ; }
let n = 1 ; printCoils ( n ) ;
function findSum ( n ) {
let arr = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) { arr [ i ] = new Array ( n ) ; for ( let j = 0 ; j < n ; j ++ ) { arr [ i ] [ j ] = 0 ; } } for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = Math . abs ( i - j ) ;
let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n ; j ++ ) sum += arr [ i ] [ j ] ; return sum ; }
let n = 3 ; document . write ( findSum ( n ) ) ;
function findSum ( n ) { let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) sum += i * ( n - i ) ; return 2 * sum ; }
let n = 3 ; document . write ( findSum ( n ) ) ;
function findSum ( n ) { n -- ; let sum = 0 ; sum += ( n * ( n + 1 ) ) / 2 ; sum += ( n * ( n + 1 ) * ( 2 * n + 1 ) ) / 6 ; return sum ; }
let n = 3 ; document . write ( findSum ( n ) ) ;
function checkHV ( arr , N , M ) {
let horizontal = true ; let vertical = true ;
for ( let i = 0 , k = N - 1 ; i < parseInt ( N / 2 , 10 ) ; i ++ , k -- ) {
for ( let j = 0 ; j < M ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { horizontal = false ; break ; } } }
for ( let i = 0 , k = M - 1 ; i < parseInt ( M / 2 , 10 ) ; i ++ , k -- ) {
for ( let j = 0 ; j < N ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { horizontal = false ; break ; } } } if ( ! horizontal && ! vertical ) document . write ( " " ) ; else if ( horizontal && ! vertical ) document . write ( " " ) ; else if ( vertical && ! horizontal ) document . write ( " " ) ; else document . write ( " " ) ; }
let mat = [ [ 1 , 0 , 1 ] , [ 0 , 0 , 0 ] , [ 1 , 0 , 1 ] ] ; checkHV ( mat , 3 , 3 ) ;
function maxDet ( n ) { return ( 2 * n * n * n ) ; }
function resMatrix ( n ) { for ( let i = 0 ; i < 3 ; i ++ ) { for ( let j = 0 ; j < 3 ; j ++ ) {
if ( i == 0 && j == 2 ) document . write ( " " ) ; else if ( i == 1 && j == 0 ) document . write ( " " ) ; else if ( i == 2 && j == 1 ) document . write ( " " ) ;
else document . write ( n + " " ) ; } document . write ( " " ) ; } }
let n = 15 ; document . write ( " " + maxDet ( n ) + " " ) ; document . write ( " " ) ; resMatrix ( n ) ;
function spiralDiaSum ( n ) { if ( n == 1 ) return 1 ;
return ( 4 * n * n - 6 * n + 6 + spiralDiaSum ( n - 2 ) ) ; }
let n = 7 ; document . write ( spiralDiaSum ( n ) ) ;
let R = 3 ; let C = 5 ;
function numofneighbour ( mat , i , j ) { let count = 0 ;
if ( i > 0 && mat [ i - 1 ] [ j ] == 1 ) count ++ ;
if ( j > 0 && mat [ i ] [ j - 1 ] == 1 ) count ++ ;
if ( i < R - 1 && mat [ i + 1 ] [ j ] == 1 ) count ++ ;
if ( j < C - 1 && mat [ i ] [ j + 1 ] == 1 ) count ++ ; return count ; }
function findperimeter ( mat ) { let perimeter = 0 ;
for ( let i = 0 ; i < R ; i ++ ) for ( let j = 0 ; j < C ; j ++ ) if ( mat [ i ] [ j ] == 1 ) perimeter += ( 4 - numofneighbour ( mat , i , j ) ) ; return perimeter ; }
let mat = [ [ 0 , 1 , 0 , 0 , 0 ] , [ 1 , 1 , 1 , 0 , 0 ] , [ 1 , 0 , 0 , 0 , 0 ] ] ; document . write ( findperimeter ( mat ) ) ;
function printMatrixDiagonal ( arr , len ) {
let i = 0 , j = 0 ;
let isUp = true ;
for ( let k = 0 ; k < len * len ; ) {
if ( isUp ) { for ( ; i >= 0 && j < len ; i -- , j ++ ) { document . write ( arr [ i ] [ j ] + ' ' ) ; k ++ ; }
if ( i < 0 && j < len ) i = 0 ; if ( j === len ) i = i + 2 , j -- ; }
else { for ( ; j >= 0 && i < len ; i ++ , j -- ) { document . write ( arr [ i ] [ j ] + ' ' ) ; k ++ ; }
if ( j < 0 && i < len ) j = 0 ; if ( i === len ) j = j + 2 , i -- ; }
isUp = ! isUp } }
let arr = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] ; let arrLength = arr . length ; printMatrixDiagonal ( arr , arrLength ) ;
let arr = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 ] ] ;
let n = arr . length , mode = 0 , it = 0 , lower = 0 ;
for ( let t = 0 ; t < ( 2 * n - 1 ) ; t ++ ) { let t1 = t ; if ( t1 >= n ) { mode ++ ; t1 = n - 1 ; it -- ; lower ++ ; } else { lower = 0 ; it ++ ; } for ( let i = t1 ; i >= lower ; i -- ) { if ( ( t1 + mode ) % 2 === 0 ) { console . log ( arr [ i ] [ t1 + lower - i ] ) } else { console . log ( arr [ t1 + lower - i ] [ i ] ) } } } }
function maxRowDiff ( mat , m , n ) {
let rowSum = new Array ( m ) ;
for ( let i = 0 ; i < m ; i ++ ) { let sum = 0 ; for ( let j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] ; rowSum [ i ] = sum ; }
let max_diff = rowSum [ 1 ] - rowSum [ 0 ] ; let min_element = rowSum [ 0 ] ; for ( let i = 1 ; i < m ; i ++ ) {
if ( rowSum [ i ] - min_element > max_diff ) max_diff = rowSum [ i ] - min_element ;
if ( rowSum [ i ] < min_element ) min_element = rowSum [ i ] ; } return max_diff ; }
let m = 5 , n = 4 ; let mat = [ [ - 1 , 2 , 3 , 4 ] , [ 5 , 3 , - 2 , 1 ] , [ 6 , 7 , 2 , - 3 ] , [ 2 , 9 , 1 , 4 ] , [ 2 , 1 , - 2 , 0 ] ] ; document . write ( maxRowDiff ( mat , m , n ) ) ;
let R = 4 ; let C = 4 ;
function getTotalCoverageOfMatrix ( mat ) { let res = 0 ;
for ( let i = 0 ; i < R ; i ++ ) {
let isOne = false ;
for ( let j = 0 ; j < C ; j ++ ) {
if ( mat [ i ] [ j ] == 1 ) isOne = true ;
else if ( isOne ) res ++ ; }
isOne = false ; for ( let j = C - 1 ; j >= 0 ; j -- ) { if ( mat [ i ] [ j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } }
for ( let j = 0 ; j < C ; j ++ ) {
let isOne = false ; for ( let i = 0 ; i < R ; i ++ ) { if ( mat [ i ] [ j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } isOne = false ; for ( let i = R - 1 ; i >= 0 ; i -- ) { if ( mat [ i ] [ j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } } return res ; }
let mat = [ [ 0 , 0 , 0 , 0 ] , [ 1 , 0 , 0 , 1 ] , [ 0 , 1 , 1 , 0 ] , [ 0 , 1 , 0 , 0 ] ] ; document . write ( getTotalCoverageOfMatrix ( mat ) ) ;
let R = 3 ; let C = 4 ;
function gcd ( a , b ) { if ( b == 0 ) return a ; return gcd ( b , a % b ) ; }
function replacematrix ( mat , n , m ) { let rgcd = new Array ( R ) ; rgcd . fill ( 0 ) ; let cgcd = new Array ( C ) ; cgcd . fill ( 0 ) ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < m ; j ++ ) { rgcd [ i ] = gcd ( rgcd [ i ] , mat [ i ] [ j ] ) ; cgcd [ j ] = gcd ( cgcd [ j ] , mat [ i ] [ j ] ) ; } }
for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < m ; j ++ ) mat [ i ] [ j ] = Math . max ( rgcd [ i ] , cgcd [ j ] ) ; }
let m = [ [ 1 , 2 , 3 , 3 ] , [ 4 , 5 , 6 , 6 ] , [ 7 , 8 , 9 , 9 ] ] ; replacematrix ( m , R , C ) ; for ( let i = 0 ; i < R ; i ++ ) { for ( let j = 0 ; j < C ; j ++ ) document . write ( m [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
function sortedCount ( mat , r , c ) {
let result = 0 ;
for ( let i = 0 ; i < r ; i ++ ) {
let j ; for ( j = 0 ; j < c - 1 ; j ++ ) if ( mat [ i ] [ j + 1 ] <= mat [ i ] [ j ] ) break ;
if ( j == c - 1 ) result ++ ; }
for ( let i = 0 ; i < r ; i ++ ) {
let j ; for ( j = c - 1 ; j > 0 ; j -- ) if ( mat [ i ] [ j - 1 ] <= mat [ i ] [ j ] ) break ;
if ( c > 1 && j == 0 ) result ++ ; } return result ; }
let m = 4 , n = 5 ; let mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 4 , 3 , 1 , 2 , 6 ] , [ 8 , 7 , 6 , 5 , 4 ] , [ 5 , 7 , 8 , 9 , 10 ] ] document . write ( sortedCount ( mat , m , n ) )
const MAX = 1000 ;
function maxXOR ( mat , N ) {
let r_xor , c_xor ; let max_xor = 0 ;
for ( let i = 0 ; i < N ; i ++ ) { r_xor = 0 , c_xor = 0 ; for ( let j = 0 ; j < N ; j ++ ) {
r_xor = r_xor ^ mat [ i ] [ j ] ;
c_xor = c_xor ^ mat [ j ] [ i ] ; }
if ( max_xor < Math . max ( r_xor , c_xor ) ) max_xor = Math . max ( r_xor , c_xor ) ; }
return max_xor ; }
let N = 3 ; let mat = [ [ 1 , 5 , 4 ] , [ 3 , 7 , 2 ] , [ 5 , 9 , 10 ] ] ; document . write ( " " + maxXOR ( mat , N ) ) ;
function direction ( R , C ) { if ( R != C && R % 2 == 0 && C % 2 != 0 && R < C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R > C ) { document . write ( " " ) ; return ; } if ( R == C && R % 2 != 0 && C % 2 != 0 ) { document . write ( " " ) ; return ; } if ( R == C && R % 2 == 0 && C % 2 == 0 ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R < C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R > C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R < C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R > C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 != 0 && R > C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R < C ) { document . write ( " " ) ; return ; } }
let R = 3 , C = 1 ; direction ( R , C ) ;
let R = 3 ; let C = 6 ; function spiralPrint ( m , n , a , c ) { let i , k = 0 , l = 0 ; let count = 0 ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) { count ++ ; if ( count == c ) document . write ( a [ k ] [ i ] + " " ) ; } k ++ ;
for ( i = k ; i < m ; ++ i ) { count ++ ; if ( count == c ) document . write ( a [ i ] [ n - 1 ] + " " ) ; } n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) { count ++ ; if ( count == c ) document . write ( a [ m - 1 ] [ i ] + " " ) ; } m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) { count ++ ; if ( count == c ) document . write ( a [ i ] [ l ] + " " ) ; } l ++ ; } } }
let a = [ [ 1 , 2 , 3 , 4 , 5 , 6 ] , [ 7 , 8 , 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 , 17 , 18 ] ] , k = 17 ; spiralPrint ( R , C , a , k ) ;
let MAX = 100 ;
function findK ( A , i , j , n , m , k ) { if ( n < 1 m < 1 ) return - 1 ;
if ( k <= m ) return A [ i + 0 ] [ j + k - 1 ] ;
if ( k <= ( m + n - 1 ) ) return A [ i + ( k - m ) ] [ j + m - 1 ] ;
if ( k <= ( m + n - 1 + m - 1 ) ) return A [ i + n - 1 ] [ j + m - 1 - ( k - ( m + n - 1 ) ) ] ;
if ( k <= ( m + n - 1 + m - 1 + n - 2 ) ) return A [ i + n - 1 - ( k - ( m + n - 1 + m - 1 ) ) ] [ j + 0 ] ;
return findK ( A , i + 1 , j + 1 , n - 2 , m - 2 , k - ( 2 * n + 2 * m - 4 ) ) ; }
let a = [ [ 1 , 2 , 3 , 4 , 5 , 6 ] , [ 7 , 8 , 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 , 17 , 18 ] ] ; let k = 17 ; document . write ( findK ( a , 0 , 0 , 3 , 6 , k ) ) ;
let N = 5 ; let M = 4 ;
function checkDiagonal ( mat , i , j ) { let res = mat [ i ] [ j ] ; while ( ++ i < N && ++ j < M ) {
if ( mat [ i ] [ j ] != res ) return false ; }
return true ; }
function isToepliz ( mat ) {
for ( let i = 0 ; i < M ; i ++ ) {
if ( ! checkDiagonal ( mat , 0 , i ) ) return false ; }
for ( let i = 1 ; i < N ; i ++ ) {
if ( ! checkDiagonal ( mat , i , 0 ) ) return false ; }
return true ; }
let mat = [ [ 6 , 7 , 8 , 9 ] , [ 4 , 6 , 7 , 8 ] , [ 1 , 4 , 6 , 7 ] , [ 0 , 1 , 4 , 6 ] , [ 2 , 0 , 1 , 4 ] ] ;
if ( isToepliz ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
let N = 5 ;
function countZeroes ( mat ) {
let row = N - 1 , col = 0 ;
let count = 0 ; while ( col < N ) {
while ( mat [ row ] [ col ] > 0 )
if ( -- row < 0 ) return count ;
count += ( row + 1 ) ;
col ++ ; } return count ; }
let mat = [ [ 0 , 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 0 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] ] ; document . write ( countZeroes ( mat ) ) ;
function countNegative ( M , n , m ) { let count = 0 ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < m ; j ++ ) { if ( M [ i ] [ j ] < 0 ) count += 1 ;
else break ; } } return count ; }
let M = [ [ - 3 , - 2 , - 1 , 1 ] , [ - 2 , 2 , 3 , 4 ] , [ 4 , 5 , 7 , 8 ] ] ; document . write ( countNegative ( M , 3 , 4 ) ) ;
function countNegative ( M , n , m ) {
let count = 0 ;
let i = 0 ; let j = m - 1 ;
while ( j >= 0 && i < n ) { if ( M [ i ] [ j ] < 0 ) {
count += j + 1 ;
i += 1 ; }
else j -= 1 ; } return count ; } `
let M = [ [ - 3 , - 2 , - 1 , 1 ] , [ - 2 , 2 , 3 , 4 ] , [ 4 , 5 , 7 , 8 ] ] ; document . write ( countNegative ( M , 3 , 4 ) ) ;
class Node { constructor ( val ) { this . data = val ; this . left = null ; this . right = null ; } } var root ;
function bintree2listUtil ( node ) {
if ( node == null ) return node ;
if ( node . left != null ) {
var left = bintree2listUtil ( node . left ) ;
for ( ; left . right != null ; left = left . right )
left . right = node ;
node . left = left ; }
if ( node . right != null ) {
var right = bintree2listUtil ( node . right ) ;
for ( ; right . left != null ; right = right . left )
right . left = node ;
node . right = right ; } return node ; }
function bintree2list ( node ) {
if ( node == null ) return node ;
node = bintree2listUtil ( node ) ;
while ( node . left != null ) node = node . left ; return node ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . right ; } }
root = new Node ( 10 ) ; root . left = new Node ( 12 ) ; root . right = new Node ( 15 ) ; root . left . left = new Node ( 25 ) ; root . left . right = new Node ( 30 ) ; root . right . left = new Node ( 36 ) ;
var head = bintree2list ( root ) ;
printList ( head ) ;
let N = 10 ;
function findLargestPlus ( mat ) {
let left = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { left [ i ] = new Array ( N ) ; } let right = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { right [ i ] = new Array ( N ) ; } let top = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { top [ i ] = new Array ( N ) ; } let bottom = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { bottom [ i ] = new Array ( N ) ; } for ( let i = 0 ; i < N ; i ++ ) { for ( let j = 0 ; j < N ; j ++ ) { left [ i ] [ j ] = 0 ; right [ i ] [ j ] = 0 ; top [ i ] [ j ] = 0 ; bottom [ i ] [ j ] = 0 ; } }
for ( let i = 0 ; i < N ; i ++ ) {
top [ 0 ] [ i ] = mat [ 0 ] [ i ] ;
bottom [ N - 1 ] [ i ] = mat [ N - 1 ] [ i ] ;
left [ i ] [ 0 ] = mat [ i ] [ 0 ] ;
right [ i ] [ N - 1 ] = mat [ i ] [ N - 1 ] ; }
for ( let i = 0 ; i < N ; i ++ ) { for ( let j = 1 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] == 1 ) left [ i ] [ j ] = left [ i ] [ j - 1 ] + 1 ; else left [ i ] [ j ] = 0 ;
if ( mat [ j ] [ i ] == 1 ) top [ j ] [ i ] = top [ j - 1 ] [ i ] + 1 ; else top [ j ] [ i ] = 0 ;
j = N - 1 - j ;
if ( mat [ j ] [ i ] == 1 ) bottom [ j ] [ i ] = bottom [ j + 1 ] [ i ] + 1 ; else bottom [ j ] [ i ] = 0 ;
if ( mat [ i ] [ j ] == 1 ) right [ i ] [ j ] = right [ i ] [ j + 1 ] + 1 ; else right [ i ] [ j ] = 0 ;
j = N - 1 - j ; } }
let n = 0 ;
for ( let i = 0 ; i < N ; i ++ ) { for ( let j = 0 ; j < N ; j ++ ) {
let len = Math . min ( Math . min ( top [ i ] [ j ] , bottom [ i ] [ j ] ) , Math . min ( left [ i ] [ j ] , right [ i ] [ j ] ) ) ;
if ( len > n ) n = len ; } }
if ( n > 0 ) return 4 * ( n - 1 ) + 1 ;
return 0 ; }
let mat = [ [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 ] , [ 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 ] , [ 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 ] , [ 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 ] , [ 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 ] , [ 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 ] , [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 ] , [ 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 ] , [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 ] ] document . write ( findLargestPlus ( mat ) ) ;
function findLeft ( str ) { let n = str . length ;
while ( n > 0 ) { n -- ;
if ( str [ n ] == ' ' ) { str = str . replaceAt ( n , ' ' ) ; break ; } if ( str [ n ] == ' ' ) { str = str . replaceAt ( n , ' ' ) ; break ; }
if ( str [ n ] == ' ' ) str = str . replaceAt ( n , ' ' ) ; else if ( str [ n ] == ' ' ) str = str . replaceAt ( n , ' ' ) ; } return str ; }
let str = " " ; document . write ( " " + str + " " + findLeft ( str ) ) ;
function printSpiral ( n ) { for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
x = Math . min ( Math . min ( i , j ) , Math . min ( n - 1 - i , n - 1 - j ) ) ;
if ( i <= j ) document . write ( ` ${ ( n - 2 * x ) * ( n - 2 * x ) - ( i - x ) - ( j - x ) } ` ) ;
else document . write ( ` ${ ( n - 2 * x - 2 ) * ( n - 2 * x - 2 ) + ( i - x ) + ( j - x ) } ` ) ; } document . write ( " " ) ; } }
let n = 5 ;
printSpiral ( n ) ;
function findMaxValue ( N , mat ) {
let maxValue = Number . MIN_VALUE ;
for ( let a = 0 ; a < N - 1 ; a ++ ) for ( let b = 0 ; b < N - 1 ; b ++ ) for ( let d = a + 1 ; d < N ; d ++ ) for ( let e = b + 1 ; e < N ; e ++ ) if ( maxValue < ( mat [ d ] [ e ] - mat [ a ] [ b ] ) ) maxValue = mat [ d ] [ e ] - mat [ a ] [ b ] ; return maxValue ; }
let N = 5 ; let mat = [ [ 1 , 2 , - 1 , - 4 , - 20 ] , [ - 8 , - 3 , 4 , 2 , 1 ] , [ 3 , 8 , 6 , 1 , 3 ] , [ - 4 , - 1 , 1 , 7 , - 6 ] , [ 0 , - 4 , 10 , - 5 , 1 ] ] ; document . write ( " " + findMaxValue ( N , mat ) ) ;
function findMaxValue ( N , mat ) {
let maxValue = Number . MIN_VALUE ;
let maxArr = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { maxArr [ i ] = new Array ( N ) ; }
maxArr [ N - 1 ] [ N - 1 ] = mat [ N - 1 ] [ N - 1 ] ;
let maxv = mat [ N - 1 ] [ N - 1 ] ; for ( let j = N - 2 ; j >= 0 ; j -- ) { if ( mat [ N - 1 ] [ j ] > maxv ) maxv = mat [ N - 1 ] [ j ] ; maxArr [ N - 1 ] [ j ] = maxv ; }
maxv = mat [ N - 1 ] [ N - 1 ] ; for ( let i = N - 2 ; i >= 0 ; i -- ) { if ( mat [ i ] [ N - 1 ] > maxv ) maxv = mat [ i ] [ N - 1 ] ; maxArr [ i ] [ N - 1 ] = maxv ; }
for ( let i = N - 2 ; i >= 0 ; i -- ) { for ( let j = N - 2 ; j >= 0 ; j -- ) {
if ( maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] > maxValue ) maxValue = maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] ;
maxArr [ i ] [ j ] = Math . max ( mat [ i ] [ j ] , Math . max ( maxArr [ i ] [ j + 1 ] , maxArr [ i + 1 ] [ j ] ) ) ; } } return maxValue ; }
let N = 5 ; let mat = [ [ 1 , 2 , - 1 , - 4 , - 20 ] , [ - 8 , - 3 , 4 , 2 , 1 ] , [ 3 , 8 , 6 , 1 , 3 ] , [ - 4 , - 1 , 1 , 7 , - 6 ] , [ 0 , - 4 , 10 , - 5 , 1 ] ] ; document . write ( " " + findMaxValue ( N , mat ) ) ;
function modifyMatrix ( mat , R , C ) { let row = new Array ( R ) ; let col = new Array ( C ) ;
for ( i = 0 ; i < R ; i ++ ) { row [ i ] = 0 ; }
for ( i = 0 ; i < C ; i ++ ) { col [ i ] = 0 ; }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( mat [ i ] [ j ] == 1 ) { row [ i ] = 1 ; col [ j ] = 1 ; } } }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( row [ i ] == 1 col [ j ] == 1 ) { mat [ i ] [ j ] = 1 ; } } } }
function printMatrix ( mat , R , C ) { let i , j ; for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { document . write ( mat [ i ] [ j ] + " " ) ; } document . write ( " " ) ; } }
let mat = [ [ 1 , 0 , 0 , 1 ] , [ 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 0 ] ] ; document . write ( " " ) printMatrix ( mat , 3 , 4 ) ; modifyMatrix ( mat , 3 , 4 ) ; document . write ( " " ) ; printMatrix ( mat , 3 , 4 ) ;
let ROW = 4 ; let COL = 5 ;
function findUniqueRows ( M ) {
for ( let i = 0 ; i < ROW ; i ++ ) { let flag = 0 ;
for ( let j = 0 ; j < i ; j ++ ) { flag = 1 ; for ( let k = 0 ; k < COL ; k ++ ) if ( M [ i ] [ k ] != M [ j ] [ k ] ) flag = 0 ; if ( flag == 1 ) break ; }
if ( flag == 0 ) {
for ( let j = 0 ; j < COL ; j ++ ) document . write ( M [ i ] [ j ] + " " ) ; document . write ( " " ) ; } } }
let M = [ [ 0 , 1 , 0 , 0 , 1 ] , [ 1 , 0 , 1 , 1 , 0 ] , [ 0 , 1 , 0 , 0 , 1 ] , [ 1 , 0 , 1 , 0 , 0 ] ] findUniqueRows ( M )
class node { constructor ( val ) { this . data = val ; this . left = null ; this . right = null ; } } var prev ;
function inorder ( root ) { if ( root == null ) return ; inorder ( root . left ) ; document . write ( root . data + " " ) ; inorder ( root . right ) ; }
function fixPrevptr ( root ) { if ( root == null ) return ; fixPrevptr ( root . left ) ; root . left = prev ; prev = root ; fixPrevptr ( root . right ) ; }
function fixNextptr ( root ) {
while ( root . right != null ) root = root . right ;
while ( root != null && root . left != null ) { var left = root . left ; left . right = root ; root = root . left ; }
return root ; }
function BTTtoDLL ( root ) { prev = null ;
fixPrevptr ( root ) ;
return fixNextptr ( root ) ; }
function printlist ( root ) { while ( root != null ) { document . write ( root . data + " " ) ; root = root . right ; } }
var root = new node ( 10 ) ; root . left = new node ( 12 ) ; root . right = new node ( 15 ) ; root . left . left = new node ( 25 ) ; root . left . right = new node ( 30 ) ; root . right . left = new node ( 36 ) ; document . write ( " " ) ; inorder ( root ) ; var head = BTTtoDLL ( root ) ; document . write ( " " ) ; printlist ( head ) ;
var R = 3 ; var C = 3 ;
function swap ( mat , row1 , row2 , col ) { for ( i = 0 ; i < col ; i ++ ) { var temp = mat [ row1 ] [ i ] ; mat [ row1 ] [ i ] = mat [ row2 ] [ i ] ; mat [ row2 ] [ i ] = temp ; } }
function rankOfMatrix ( mat ) { var rank = C ; for ( row = 0 ; row < rank ; row ++ ) {
if ( mat [ row ] [ row ] != 0 ) { for ( col = 0 ; col < R ; col ++ ) { if ( col != row ) {
var mult = mat [ col ] [ row ] / mat [ row ] [ row ] ; for ( i = 0 ; i < rank ; i ++ ) mat [ col ] [ i ] -= mult * mat [ row ] [ i ] ; } } }
else { reduce = true ;
for ( var i = row + 1 ; i < R ; i ++ ) {
if ( mat [ i ] [ row ] != 0 ) { swap ( mat , row , i , rank ) ; reduce = false ; break ; } }
if ( reduce ) {
rank -- ;
for ( i = 0 ; i < R ; i ++ ) mat [ i ] [ row ] = mat [ i ] [ rank ] ; }
row -- ; }
} return rank ; }
function display ( mat , row , col ) { for ( i = 0 ; i < row ; i ++ ) { for ( j = 0 ; j < col ; j ++ ) document . write ( " " + mat [ i ] [ j ] ) ; document . write ( ' ' ) ; } }
var mat = [ [ 10 , 20 , 10 ] , [ - 20 , - 30 , 10 ] , [ 30 , 50 , 0 ] ] ; document . write ( " " + rankOfMatrix ( mat ) ) ;
class Cell {
function printSums ( mat , arr , n ) {
for ( i = 0 ; i < n ; i ++ ) { var sum = 0 , r = arr [ i ] . r , c = arr [ i ] . c ;
for ( j = 0 ; j < R ; j ++ ) { for ( k = 0 ; k < C ; k ++ ) { if ( j != r && k != c ) { sum += mat [ j ] [ k ] ; } } } document . write ( sum + " " ) ; } }
var mat = [ [ 1 , 1 , 2 ] , [ 3 , 4 , 6 ] , [ 5 , 3 , 2 ] ] ; var arr = [ new Cell ( 0 , 0 ) , new Cell ( 1 , 1 ) , new Cell ( 0 , 1 ) ] ; var n = arr . length ; printSums ( mat , arr , n ) ;
function countIslands ( mat , m , n ) {
let count = 0 ;
for ( let i = 0 ; i < m ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( mat [ i ] [ j ] == ' ' ) { if ( ( i == 0 mat [ i - 1 ] [ j ] == ' ' ) && ( j == 0 mat [ i ] [ j - 1 ] == ' ' ) ) count ++ ; } } } return count ; }
let m = 6 ; let n = 3 ; let mat = [ [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] ] ; document . write ( " " + countIslands ( mat , m , n ) ) ;
let M = 4 ; let N = 5 ;
function findCommon ( mat ) {
let column = new Array ( M ) ;
min_row = 0 ;
while ( column [ min_row ] >= 0 ) {
for ( i = 0 ; i < M ; i ++ ) { if ( mat [ i ] [ column [ i ] ] < mat [ min_row ] [ column [ min_row ] ] ) min_row = i ; }
let eq_count = 0 ;
for ( i = 0 ; i < M ; i ++ ) {
if ( mat [ i ] [ column [ i ] ] > mat [ min_row ] [ column [ min_row ] ] ) { if ( column [ i ] == 0 ) return - 1 ;
column [ i ] -= 1 ; } else eq_count ++ ; }
if ( eq_count == M ) return mat [ min_row ] [ column [ min_row ] ] ; } return - 1 ; }
let mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 2 , 4 , 5 , 8 , 10 ] , [ 3 , 5 , 7 , 9 , 11 ] , [ 1 , 3 , 5 , 7 , 9 ] ] ; let result = findCommon ( mat ) if ( result == - 1 ) { document . write ( " " ) ; } else { document . write ( " " , result ) ; }
let M = 4 ; let N = 5 ;
function findCommon ( mat ) {
let cnt = new Map ( ) ; let i , j ; for ( i = 0 ; i < M ; i ++ ) {
if ( cnt . has ( mat [ i ] [ 0 ] ) ) { cnt . set ( mat [ i ] [ 0 ] , cnt . get ( mat [ i ] [ 0 ] ) + 1 ) ; } else { cnt . set ( mat [ i ] [ 0 ] , 1 ) ; }
for ( j = 1 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] != mat [ i ] [ j - 1 ] ) { if ( cnt . has ( mat [ i ] [ j ] ) ) { cnt . set ( mat [ i ] [ j ] , cnt . get ( mat [ i ] [ j ] ) + 1 ) ; } else { cnt . set ( mat [ i ] [ j ] , 1 ) ; } } } }
for ( let [ key , value ] of cnt . entries ( ) ) { if ( value == M ) return key ; }
return - 1 ; }
let mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 2 , 4 , 5 , 8 , 10 ] , [ 3 , 5 , 7 , 9 , 11 ] , [ 1 , 3 , 5 , 7 , 9 ] , ] let result = findCommon ( mat ) ; if ( result == - 1 ) document . write ( " " ) ; else document . write ( " " + result ) ;
let M = 6 ; let N = 6 ;
function floodFillUtil ( mat , x , y , prevV , newV ) {
if ( x < 0 x >= M y < 0 y >= N ) return ; if ( mat [ x ] [ y ] != prevV ) return ;
mat [ x ] [ y ] = newV ;
floodFillUtil ( mat , x + 1 , y , prevV , newV ) ; floodFillUtil ( mat , x - 1 , y , prevV , newV ) ; floodFillUtil ( mat , x , y + 1 , prevV , newV ) ; floodFillUtil ( mat , x , y - 1 , prevV , newV ) ; }
function replaceSurrounded ( mat ) {
for ( let i = 0 ; i < M ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' ' ) mat [ i ] [ j ] = ' ' ;
for ( let i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ 0 ] == ' ' ) floodFillUtil ( mat , i , 0 , ' ' , ' ' ) ;
for ( let i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ N - 1 ] == ' ' ) floodFillUtil ( mat , i , N - 1 , ' ' , ' ' ) ;
for ( let i = 0 ; i < N ; i ++ ) if ( mat [ 0 ] [ i ] == ' ' ) floodFillUtil ( mat , 0 , i , ' ' , ' ' ) ;
for ( let i = 0 ; i < N ; i ++ ) if ( mat [ M - 1 ] [ i ] == ' ' ) floodFillUtil ( mat , M - 1 , i , ' ' , ' ' ) ;
for ( let i = 0 ; i < M ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' ' ) mat [ i ] [ j ] = ' ' ; }
let mat = [ [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] ] ; replaceSurrounded ( mat ) ; for ( let i = 0 ; i < M ; i ++ ) { for ( let j = 0 ; j < N ; j ++ ) document . write ( mat [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
let INF = Number . MAX_VALUE ; let N = 4 ;
function youngify ( mat , i , j ) {
let downVal = ( i + 1 < N ) ? mat [ i + 1 ] [ j ] : INF ; let rightVal = ( j + 1 < N ) ? mat [ i ] [ j + 1 ] : INF ;
if ( downVal == INF && rightVal == INF ) { return ; }
if ( downVal < rightVal ) { mat [ i ] [ j ] = downVal ; mat [ i + 1 ] [ j ] = INF ; youngify ( mat , i + 1 , j ) ; } else { mat [ i ] [ j ] = rightVal ; mat [ i ] [ j + 1 ] = INF ; youngify ( mat , i , j + 1 ) ; } }
function extractMin ( mat ) { let ret = mat [ 0 ] [ 0 ] ; mat [ 0 ] [ 0 ] = INF ; youngify ( mat , 0 , 0 ) ; return ret ; }
function printSorted ( mat ) { document . write ( " " ) ; for ( let i = 0 ; i < N * N ; i ++ ) { document . write ( extractMin ( mat ) + " " ) ; } } let mat = [ [ 10 , 20 , 30 , 40 ] , [ 15 , 25 , 35 , 45 ] , [ 27 , 29 , 37 , 48 ] , [ 32 , 33 , 39 , 50 ] ] ; printSorted ( mat ) ;
let n = 5 ;
function printSumSimple ( mat , k ) {
if ( k > n ) return ;
for ( let i = 0 ; i < n - k + 1 ; i ++ ) {
for ( let j = 0 ; j < n - k + 1 ; j ++ ) {
let sum = 0 ; for ( let p = i ; p < k + i ; p ++ ) for ( let q = j ; q < k + j ; q ++ ) sum += mat [ p ] [ q ] ; document . write ( sum + " " ) ; }
document . write ( " " ) ; } }
let mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] let k = 3 ; printSumSimple ( mat , k ) ;
let n = 5 ;
function printSumTricky ( mat , k ) {
if ( k > n ) return ;
let stripSum = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) { stripSum [ i ] = new Array ( n ) ; } for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) { stripSum [ i ] [ j ] = 0 ; } }
for ( let j = 0 ; j < n ; j ++ ) {
let sum = 0 ; for ( let i = 0 ; i < k ; i ++ ) sum += mat [ i ] [ j ] ; stripSum [ 0 ] [ j ] = sum ;
for ( let i = 1 ; i < n - k + 1 ; i ++ ) { sum += ( mat [ i + k - 1 ] [ j ] - mat [ i - 1 ] [ j ] ) ; stripSum [ i ] [ j ] = sum ; } }
for ( let i = 0 ; i < n - k + 1 ; i ++ ) {
let sum = 0 ; for ( let j = 0 ; j < k ; j ++ ) sum += stripSum [ i ] [ j ] ; document . write ( sum + " " ) ;
for ( let j = 1 ; j < n - k + 1 ; j ++ ) { sum += ( stripSum [ i ] [ j + k - 1 ] - stripSum [ i ] [ j - 1 ] ) ; document . write ( sum + " " ) ; } document . write ( " " ) ; } }
let mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] ; let k = 3 ; printSumTricky ( mat , k ) ;
var M = 3 ; var N = 4 ;
function transpose ( A , B ) { var i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < M ; j ++ ) B [ i ] [ j ] = A [ j ] [ i ] ; }
var A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] ] ; var B = Array ( N ) ; for ( i = 0 ; i < N ; i ++ ) B [ i ] = Array ( M ) . fill ( 0 ) ; transpose ( A , B ) ; document . write ( " " ) ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < M ; j ++ ) document . write ( B [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
var N = 4 ;
function transpose ( A ) { for ( i = 0 ; i < N ; i ++ ) for ( j = i + 1 ; j < N ; j ++ ) { var temp = A [ i ] [ j ] ; A [ i ] [ j ] = A [ j ] [ i ] ; A [ j ] [ i ] = temp ; } }
var A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] ; transpose ( A ) ; document . write ( " " ) ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < N ; j ++ ) document . write ( A [ i ] [ j ] + " " ) ; document . write ( " \< " ) ; }
var R = 5 ; var C = 4 ;
function isValid ( x , y1 , y2 ) { return ( x >= 0 && x < R && y1 >= 0 && y1 < C && y2 >= 0 && y2 < C ) ; }
function getMaxUtil ( arr , mem , x , y1 , y2 ) {
if ( ! isValid ( x , y1 , y2 ) ) return Number . MIN_VALUE ;
if ( x == R - 1 && y1 == 0 && y2 == C - 1 ) return ( y1 == y2 ) ? arr [ x ] [ y1 ] : arr [ x ] [ y1 ] + arr [ x ] [ y2 ] ;
if ( x == R - 1 ) return Number . MIN_VALUE ;
if ( mem [ x ] [ y1 ] [ y2 ] != - 1 ) return mem [ x ] [ y1 ] [ y2 ] ;
var ans = Number . MIN_VALUE ;
var temp = ( y1 == y2 ) ? arr [ x ] [ y1 ] : arr [ x ] [ y1 ] + arr [ x ] [ y2 ] ;
ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 - 1 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 + 1 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 - 1 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 + 1 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 - 1 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 + 1 ) ) ; return ( mem [ x ] [ y1 ] [ y2 ] = ans ) ; }
function geMaxCollection ( arr ) {
var mem = Array ( R ) . fill ( ) . map ( ( ) => Array ( C ) . fill ( ) . map ( ( ) => Array ( C ) . fill ( 0 ) ) ) ; for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { for ( l = 0 ; l < C ; l ++ ) mem [ i ] [ j ] [ l ] = - 1 ; } }
return getMaxUtil ( arr , mem , 0 , 0 , C - 1 ) ; }
var arr = [ [ 3 , 6 , 8 , 2 ] , [ 5 , 2 , 4 , 3 ] , [ 1 , 1 , 20 , 10 ] , [ 1 , 1 , 20 , 10 ] , [ 1 , 1 , 20 , 10 ] , ] ; document . write ( " " + geMaxCollection ( arr ) ) ;
let R = 3 ; let C = 3 ;
function pathCountRec ( mat , m , n , k ) {
if ( m < 0 n < 0 ) return 0 ; if ( m == 0 && n == 0 ) return ( k == mat [ m ] [ n ] ) ;
return pathCountRec ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountRec ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; }
function pathCount ( mat , k ) { return pathCountRec ( mat , R - 1 , C - 1 , k ) ; }
let k = 12 ; let mat = [ [ 1 , 2 , 3 ] , [ 4 , 6 , 5 ] , [ 3 , 2 , 1 ] ] ; document . write ( pathCount ( mat , k ) ) ;
var R = 3 ; var C = 3 ; var MAX_K = 100 ; var dp = Array ( R ) . fill ( ) . map ( ( ) => Array ( C ) . fill ( ) . map ( ( ) => Array ( MAX_K ) . fill ( 0 ) ) ) ; function pathCountDPRecDP ( mat , m , n , k ) {
if ( m < 0 n < 0 ) return 0 ; if ( m == 0 && n == 0 ) return ( k == mat [ m ] [ n ] ? 1 : 0 ) ;
if ( dp [ m ] [ n ] [ k ] != - 1 ) return dp [ m ] [ n ] [ k ] ;
dp [ m ] [ n ] [ k ] = pathCountDPRecDP ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountDPRecDP ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; return dp [ m ] [ n ] [ k ] ; }
function pathCountDP ( mat , k ) { for ( i = 0 ; i < R ; i ++ ) for ( j = 0 ; j < C ; j ++ ) for ( l = 0 ; l < MAX_K ; l ++ ) dp [ i ] [ j ] [ l ] = - 1 ; return pathCountDPRecDP ( mat , R - 1 , C - 1 , k ) ; }
var k = 12 ; var mat = [ [ 1 , 2 , 3 ] , [ 4 , 6 , 5 ] , [ 3 , 2 , 1 ] ] ; document . write ( pathCountDP ( mat , k ) ) ;
let x = [ 0 , 1 , 1 , - 1 , 1 , 0 , - 1 , - 1 ] ; let y = [ 1 , 0 , 1 , 1 , - 1 , - 1 , 0 , - 1 ] ; let R = 3 ; let C = 3 ;
let dp = new Array ( R ) ; for ( let i = 0 ; i < R ; i ++ ) { dp [ i ] = new Array ( C ) ; for ( let j = 0 ; j < C ; j ++ ) { dp [ i ] [ j ] = 0 ; } }
function isvalid ( i , j ) { if ( i < 0 j < 0 i >= R j >= C ) return false ; return true ; }
function isadjacent ( prev , curr ) { return ( ( curr . charCodeAt ( ) - prev . charCodeAt ( ) ) == 1 ) ; }
function getLenUtil ( mat , i , j , prev ) {
if ( ! isvalid ( i , j ) || ! isadjacent ( prev , mat [ i ] [ j ] ) ) return 0 ;
if ( dp [ i ] [ j ] != - 1 ) return dp [ i ] [ j ] ;
let ans = 0 ;
for ( let k = 0 ; k < 8 ; k ++ ) ans = Math . max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , mat [ i ] [ j ] ) ) ;
return dp [ i ] [ j ] = ans ; }
function getLen ( mat , s ) { for ( let i = 0 ; i < R ; ++ i ) for ( let j = 0 ; j < C ; ++ j ) dp [ i ] [ j ] = - 1 ; let ans = 0 ; for ( let i = 0 ; i < R ; i ++ ) { for ( let j = 0 ; j < C ; j ++ ) {
if ( mat [ i ] [ j ] == s ) {
for ( let k = 0 ; k < 8 ; k ++ ) ans = Math . max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , s ) ) ; } } } return ans ; }
let mat = [ [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] ] ; document . write ( getLen ( mat , ' ' ) + " " ) ; document . write ( getLen ( mat , ' ' ) + " " ) ; document . write ( getLen ( mat , ' ' ) + " " ) ; document . write ( getLen ( mat , ' ' ) ) ;
let n = 3 ;
function findLongestFromACell ( i , j , mat , dp ) {
if ( i < 0 i >= n j < 0 j >= n ) return 0 ;
if ( dp [ i ] [ j ] != - 1 ) return dp [ i ] [ j ] ;
let x , y , z , w ; x = - 1 ; y = - 1 ; z = - 1 w = - 1 ;
if ( j < n - 1 && ( ( mat [ i ] [ j ] + 1 ) == mat [ i ] [ j + 1 ] ) ) x = 1 + findLongestFromACell ( i , j + 1 , mat , dp ) ; if ( j > 0 && ( mat [ i ] [ j ] + 1 == mat [ i ] [ j - 1 ] ) ) y = 1 + findLongestFromACell ( i , j - 1 , mat , dp ) ; if ( i > 0 && ( mat [ i ] [ j ] + 1 == mat [ i - 1 ] [ j ] ) ) z = 1 + findLongestFromACell ( i - 1 , j , mat , dp ) ; if ( i < n - 1 && ( mat [ i ] [ j ] + 1 == mat [ i + 1 ] [ j ] ) ) w = 1 + findLongestFromACell ( i + 1 , j , mat , dp ) ;
dp [ i ] [ j ] = Math . max ( x , Math . max ( y , Math . max ( z , Math . max ( w , 1 ) ) ) ) ; return dp [ i ] [ j ] ; }
function finLongestOverAll ( mat ) {
let result = 1 ;
var dp = [ ] ; for ( var y = 0 ; y < n ; y ++ ) { dp [ y ] = [ ] ; for ( var x = 0 ; x < n ; x ++ ) { dp [ y ] [ x ] = - 1 ; } }
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) { if ( dp [ i ] [ j ] == - 1 ) findLongestFromACell ( i , j , mat , dp ) ;
result = Math . max ( result , dp [ i ] [ j ] ) ; } } return result ; }
let mat = [ [ 1 , 2 , 9 ] , [ 5 , 3 , 8 ] , [ 4 , 6 , 7 ] ] ; document . write ( " " ) ; document . write ( finLongestOverAll ( mat ) ) ;
