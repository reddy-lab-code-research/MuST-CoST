function calculateSpan ( price , n , S ) {
S [ 0 ] = 1 ;
for ( let i = 1 ; i < n ; i ++ ) {
S [ i ] = 1 ;
for ( let j = i - 1 ; ( j >= 0 ) && ( price [ i ] >= price [ j ] ) ; j -- ) S [ i ] ++ ; } }
function printArray ( arr ) { let result = arr . join ( " " ) ; document . write ( result ) ; }
let price = [ 10 , 4 , 5 , 90 , 120 , 80 ] ; let n = price . length ; let S = new Array ( n ) ; S . fill ( 0 ) ;
calculateSpan ( price , n , S ) ;
printArray ( S ) ;
function findSubArray ( arr , n ) { let sum = 0 ; let maxsize = - 1 , startindex = 0 ; let endindex = 0 ;
for ( let i = 0 ; i < n - 1 ; i ++ ) { sum = ( arr [ i ] == 0 ) ? - 1 : 1 ;
for ( let j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] == 0 ) sum += - 1 ; else sum += 1 ;
if ( sum == 0 && maxsize < j - i + 1 ) { maxsize = j - i + 1 ; startindex = i ; } } } endindex = startindex + maxsize - 1 ; if ( maxsize == - 1 ) document . write ( " " ) ; else document . write ( startindex + " " + endindex ) ; return maxsize ; }
let arr = [ 1 , 0 , 0 , 1 , 0 , 1 , 1 ] ; let size = arr . length ; findSubArray ( arr , size ) ;
function leftRotatebyOne ( arr , n ) { var i , temp ; temp = arr [ 0 ] ; for ( i = 0 ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; arr [ n - 1 ] = temp ; }
function leftRotate ( arr , d , n ) { for ( i = 0 ; i < d ; i ++ ) leftRotatebyOne ( arr , n ) ; }
function printArray ( arr , n ) { for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
var arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ; leftRotate ( arr , 2 , 7 ) ; printArray ( arr , 7 ) ;
function print2Smallest ( arr , arr_size ) { let i , first , second ;
if ( arr_size < 2 ) { document . write ( " " ) ; return ; } first = Number . MAX_VALUE ; second = Number . MAX_VALUE ; for ( i = 0 ; i < arr_size ; i ++ ) {
if ( arr [ i ] < first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] < second && arr [ i ] != first ) second = arr [ i ] ; } if ( second == Number . MAX_VALUE ) document . write ( " " ) ; else document . write ( " " + first + " " + " " + second + ' ' ) ; }
let arr = [ 12 , 13 , 1 , 10 , 34 , 1 ] ; let n = arr . length ; print2Smallest ( arr , n ) ;
function findFirstMissing ( array , start , end ) { if ( start > end ) return end + 1 ; if ( start != array [ start ] ) return start ; let mid = parseInt ( ( start + end ) / 2 , 10 ) ;
if ( array [ mid ] == mid ) return findFirstMissing ( array , mid + 1 , end ) ; return findFirstMissing ( array , start , mid ) ; }
let arr = [ 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 10 ] ; let n = arr . length ; document . write ( " " + findFirstMissing ( arr , 0 , n - 1 ) ) ;
function getInvCount ( arr ) { let inv_count = 0 ; for ( let i = 0 ; i < arr . length - 1 ; i ++ ) { for ( let j = i + 1 ; j < arr . length ; j ++ ) { if ( arr [ i ] > arr [ j ] ) inv_count ++ ; } } return inv_count ; }
arr = [ 1 , 20 , 6 , 4 , 5 ] ; document . write ( " " + getInvCount ( arr ) ) ;
function printUnsorted ( arr , n ) { let s = 0 , e = n - 1 , i , max , min ;
for ( s = 0 ; s < n - 1 ; s ++ ) { if ( arr [ s ] > arr [ s + 1 ] ) break ; } if ( s == n - 1 ) { document . write ( " " ) ; return ; }
for ( e = n - 1 ; e > 0 ; e -- ) { if ( arr [ e ] < arr [ e - 1 ] ) break ; }
max = arr [ s ] ; min = arr [ s ] ; for ( i = s + 1 ; i <= e ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; if ( arr [ i ] < min ) min = arr [ i ] ; }
for ( i = 0 ; i < s ; i ++ ) { if ( arr [ i ] > min ) { s = i ; break ; } }
for ( i = n - 1 ; i >= e + 1 ; i -- ) { if ( arr [ i ] < max ) { e = i ; break ; } }
document . write ( " " + " " + " " + s + " " + e ) ; return ; } let arr = [ 10 , 12 , 20 , 30 , 25 , 40 , 32 , 31 , 35 , 50 , 60 ] ; let arr_size = arr . length ; printUnsorted ( arr , arr_size ) ;
function findElement ( arr , n , key ) { let i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
let arr = [ 12 , 34 , 10 , 6 , 40 ] ; let n = arr . length ;
let key = 40 ; let position = findElement ( arr , n , key ) ; if ( position == - 1 ) document . write ( " " ) ; else document . write ( " " + ( position + 1 ) ) ;
function equilibrium ( arr , n ) {
for ( let i = 0 ; i < n ; ++ i ) sum += arr [ i ] ; for ( let i = 0 ; i < n ; ++ i ) {
sum -= arr [ i ] ; if ( leftsum == sum ) return i ; leftsum += arr [ i ] ; }
return - 1 ; }
arr = new Array ( - 7 , 1 , 5 , 2 , - 4 , 3 , 0 ) ; n = arr . length ; document . write ( " " + equilibrium ( arr , n ) ) ;
function ceilSearch ( arr , low , high , x ) { let i ;
if ( x <= arr [ low ] ) return low ;
for ( i = low ; i < high ; i ++ ) { if ( arr [ i ] == x ) return i ;
if ( arr [ i ] < x && arr [ i + 1 ] >= x ) return i + 1 ; }
return - 1 ; }
let arr = [ 1 , 2 , 8 , 10 , 10 , 12 , 19 ] ; let n = arr . length ; let x = 3 ; let index = ceilSearch ( arr , 0 , n - 1 , x ) ; if ( index == - 1 ) document . write ( " " + x + " " ) ; else document . write ( " " + x + " " + arr [ index ] ) ;
function isMajority ( arr , n , x ) { let i , last_index = 0 ;
last_index = ( n % 2 == 0 ) ? parseInt ( n / 2 , 10 ) : parseInt ( n / 2 , 10 ) + 1 ;
for ( i = 0 ; i < last_index ; i ++ ) {
if ( arr [ i ] == x && arr [ i + parseInt ( n / 2 , 10 ) ] == x ) return true ; } return false ; }
let arr = [ 1 , 2 , 3 , 4 , 4 , 4 , 4 ] ; let n = arr . length ; let x = 4 ; if ( isMajority ( arr , n , x ) == true ) document . write ( x + " " + parseInt ( n / 2 , 10 ) + " " ) ; else document . write ( x + " " + parseInt ( n / 2 , 10 ) + " " ) ;
function findPeakUtil ( arr , low , high , n ) {
var mid = low + parseInt ( ( high - low ) / 2 ) ;
if ( ( mid == 0 arr [ mid - 1 ] <= arr [ mid ] ) && ( mid == n - 1 arr [ mid + 1 ] <= arr [ mid ] ) ) return mid ;
else if ( mid > 0 && arr [ mid - 1 ] > arr [ mid ] ) return findPeakUtil ( arr , low , ( mid - 1 ) , n ) ;
else return findPeakUtil ( arr , ( mid + 1 ) , high , n ) ; }
function findPeak ( arr , n ) { return findPeakUtil ( arr , 0 , n - 1 , n ) ; }
var arr = [ 1 , 3 , 20 , 4 , 1 , 0 ] ; var n = arr . length ; document . write ( " " + findPeak ( arr , n ) ) ;
function printRepeating ( arr , size ) { let count = new Array ( size ) ; count . fill ( 0 ) ; let i ; document . write ( " " ) ; for ( i = 0 ; i < size ; i ++ ) { if ( count [ arr [ i ] ] == 1 ) document . write ( arr [ i ] + " " ) ; else count [ arr [ i ] ] ++ ; } }
let arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 1 ] ; let arr_size = arr . length ; printRepeating ( arr , arr_size ) ;
function linearSearch ( arr , n ) { let i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == i ) return i ; }
return - 1 ; }
let arr = [ - 10 , - 1 , 0 , 3 , 10 , 11 , 30 , 50 , 100 ] ; let n = arr . length ; document . write ( " " + linearSearch ( arr , n ) ) ;
function subArraySum ( arr , n , sum ) { let curr_sum = 0 ;
for ( let i = 0 ; i < n ; i ++ ) { curr_sum = arr [ i ] ;
for ( let j = i + 1 ; j <= n ; j ++ ) { if ( curr_sum == sum ) { document . write ( " " + i + " " + ( j - 1 ) ) ; return ; } if ( curr_sum > sum j == n ) break ; curr_sum = curr_sum + arr [ j ] ; } } document . write ( " " ) ; return ; }
let arr = [ 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 ] ; let n = arr . length ; let sum = 23 ; subArraySum ( arr , n , sum ) ;
function subArraySum ( arr , n , sum ) {
let curr_sum = arr [ 0 ] , start = 0 , i ;
for ( i = 1 ; i <= n ; i ++ ) {
while ( curr_sum > sum && start < i - 1 ) { curr_sum = curr_sum - arr [ start ] ; start ++ ; }
if ( curr_sum == sum ) { let p = i - 1 ; document . write ( " " + start + " " + p + " " ) ; return 1 ; }
if ( i < n ) curr_sum = curr_sum + arr [ i ] ; }
document . write ( " " ) ; return 0 ; }
let arr = [ 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 ] ; let n = arr . length ; let sum = 23 ; subArraySum ( arr , n , sum ) ;
function MatrixChainOrder ( p , i , j ) { if ( i == j ) return 0 ; var min = Number . MAX_VALUE ;
var k = 0 ; for ( k = i ; k < j ; k ++ ) { var count = MatrixChainOrder ( p , i , k ) + MatrixChainOrder ( p , k + 1 , j ) + p [ i - 1 ] * p [ k ] * p [ j ] ; if ( count < min ) min = count ; }
return min ; }
var arr = [ 1 , 2 , 3 , 4 , 3 ] ; var n = arr . length ; document . write ( " " + MatrixChainOrder ( arr , 1 , n - 1 ) ) ;
function MatrixChainOrder ( p , n ) {
var m = Array ( n ) . fill ( 0 ) . map ( x => Array ( n ) . fill ( 0 ) ) ; var i , j , k , L , q ;
for ( i = 1 ; i < n ; i ++ ) m [ i ] [ i ] = 0 ;
for ( L = 2 ; L < n ; L ++ ) { for ( i = 1 ; i < n - L + 1 ; i ++ ) { j = i + L - 1 ; if ( j == n ) continue ; m [ i ] [ j ] = Number . MAX_VALUE ; for ( k = i ; k <= j - 1 ; k ++ ) {
q = m [ i ] [ k ] + m [ k + 1 ] [ j ] + p [ i - 1 ] * p [ k ] * p [ j ] ; if ( q < m [ i ] [ j ] ) m [ i ] [ j ] = q ; } } } return m [ 1 ] [ n - 1 ] ; }
var arr = [ 1 , 2 , 3 , 4 ] ; var size = arr . length ; document . write ( " " + MatrixChainOrder ( arr , size ) ) ;
function knapSack ( W , wt , val , n ) {
if ( n == 0 W == 0 ) return 0 ;
if ( wt [ n - 1 ] > W ) return knapSack ( W , wt , val , n - 1 ) ;
else return max ( val [ n - 1 ] + knapSack ( W - wt [ n - 1 ] , wt , val , n - 1 ) , knapSack ( W , wt , val , n - 1 ) ) ; }
let val = [ 60 , 100 , 120 ] ; let wt = [ 10 , 20 , 30 ] ; let W = 50 ; let n = val . length ; document . write ( knapSack ( W , wt , val , n ) ) ;
function count ( n ) {
let table = new Array ( n + 1 ) , i ;
table [ 0 ] = 1 ;
for ( i = 3 ; i <= n ; i ++ ) table [ i ] += table [ i - 3 ] ; for ( i = 5 ; i <= n ; i ++ ) table [ i ] += table [ i - 5 ] ; for ( i = 10 ; i <= n ; i ++ ) table [ i ] += table [ i - 10 ] ; return table [ n ] ; }
let n = 20 ; document . write ( " " + n + " " + count ( n ) + " " ) ; n = 13 ; document . write ( " " + n + " " + count ( n ) + " " ) ;
function search ( txt , pat ) { let M = pat . length ; let N = txt . length ;
for ( let i = 0 ; i <= N - M ; i ++ ) { let j ;
for ( j = 0 ; j < M ; j ++ ) if ( txt [ i + j ] != pat [ j ] ) break ;
if ( j == M ) document . write ( " " + i + " " ) ; } }
let txt = " " ; let pat = " " ; search ( txt , pat ) ;
let d = 256 ;
function search ( pat , txt , q ) { let M = pat . length ; let N = txt . length ; let i , j ;
let p = 0 ;
let t = 0 ; let h = 1 ;
for ( i = 0 ; i < M - 1 ; i ++ ) h = ( h * d ) % q ;
for ( i = 0 ; i < M ; i ++ ) { p = ( d * p + pat [ i ] . charCodeAt ( ) ) % q ; t = ( d * t + txt [ i ] . charCodeAt ( ) ) % q ; }
for ( i = 0 ; i <= N - M ; i ++ ) {
if ( p == t ) {
for ( j = 0 ; j < M ; j ++ ) { if ( txt [ i + j ] != pat [ j ] ) break ; }
if ( j == M ) document . write ( " " + i + " " ) ; }
if ( i < N - M ) { t = ( d * ( t - txt [ i ] . charCodeAt ( ) * h ) + txt [ i + M ] . charCodeAt ( ) ) % q ;
if ( t < 0 ) t = ( t + q ) ; } } }
let txt = " " ; let pat = " " ;
let q = 101 ;
search ( pat , txt , q ) ;
function power ( x , y ) { if ( y == 0 ) return 1 ; else if ( y % 2 == 0 ) return power ( x , parseInt ( y / 2 , 10 ) ) * power ( x , parseInt ( y / 2 , 10 ) ) ; else return x * power ( x , parseInt ( y / 2 , 10 ) ) * power ( x , parseInt ( y / 2 , 10 ) ) ; }
let x = 2 ; let y = 3 ; document . write ( power ( x , y ) ) ;
function isLucky ( n ) { let counter = 2 ;
let next_position = n ; if ( counter > n ) return 1 ; if ( n % counter == 0 ) return 0 ;
next_position -= Math . floor ( next_position / counter ) ; counter ++ ; return isLucky ( next_position ) ; }
let x = 5 ; if ( isLucky ( x ) ) document . write ( x + " " ) ; else document . write ( x + " " ) ;
function squareRoot ( n ) {
let x = n ; let y = 1 ; let e = 0.000001 ;
while ( x - y > e ) { x = ( x + y ) / 2 ; y = n / x ; } return x ; }
let n = 50 ; document . write ( " " + n + " " + squareRoot ( n ) . toFixed ( 6 ) ) ;
function multiply ( x , y ) { if ( y > 0 ) return ( x + multiply ( x , y - 1 ) ) ; else return 0 ; }
function pow ( a , b ) { if ( b > 0 ) return multiply ( a , pow ( a , b - 1 ) ) ; else return 1 ; }
document . write ( pow ( 5 , 3 ) ) ;
function getAvg ( x ) { sum += x ; n ++ ; return ( sum / n ) ; }
function streamAvg ( arr , m ) { var avg = 0 ; for ( i = 0 ; i < m ; i ++ ) { avg = getAvg ( parseInt ( arr [ i ] ) ) ; document . write ( " " + ( i + 1 ) + " " + avg . toFixed ( 1 ) + " " ) ; } return ; }
var arr = [ 10 , 20 , 30 , 40 , 50 , 60 ] ; var m = arr . length ; streamAvg ( arr , m ) ;
function count ( n ) {
if ( n < 3 ) return n ; if ( n >= 3 && n < 10 ) return n - 1 ;
var po = 1 ; while ( parseInt ( n / po ) > 9 ) po = po * 10 ;
var msd = parseInt ( n / po ) ; if ( msd != 3 )
return count ( msd ) * count ( po - 1 ) + count ( msd ) + count ( n % po ) ; else
return count ( msd * po - 1 ) ; }
var n = 578 ; document . write ( count ( n ) ) ;
function printPascal ( n ) {
arr = a = Array ( n ) . fill ( 0 ) . map ( x => Array ( n ) . fill ( 0 ) ) ;
for ( line = 0 ; line < n ; line ++ ) {
for ( i = 0 ; i <= line ; i ++ ) {
if ( line == i i == 0 ) arr [ line ] [ i ] = 1 ; else
arr [ line ] [ i ] = arr [ line - 1 ] [ i - 1 ] + arr [ line - 1 ] [ i ] ; document . write ( arr [ line ] [ i ] ) ; } document . write ( " " ) ; } }
var n = 5 ; printPascal ( n ) ;
function primeFactors ( n ) {
while ( n % 2 == 0 ) { document . write ( 2 + " " ) ; n = Math . floor ( n / 2 ) ; }
for ( let i = 3 ; i <= Math . floor ( Math . sqrt ( n ) ) ; i = i + 2 ) {
while ( n % i == 0 ) { document . write ( i + " " ) ; n = Math . floor ( n / i ) ; } }
if ( n > 2 ) document . write ( n + " " ) ; }
let n = 315 ; primeFactors ( n ) ;
function printCombination ( arr , n , r ) {
let data = new Array ( r ) ;
combinationUtil ( arr , data , 0 , n - 1 , 0 , r ) ; }
function combinationUtil ( arr , data , start , end , index , r ) {
if ( index == r ) { for ( let j = 0 ; j < r ; j ++ ) { document . write ( data [ j ] + " " ) ; } document . write ( " " ) }
for ( let i = start ; i <= end && end - i + 1 >= r - index ; i ++ ) { data [ index ] = arr [ i ] ; combinationUtil ( arr , data , i + 1 , end , index + 1 , r ) ; } }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ; let r = 3 ; let n = arr . length ; printCombination ( arr , n , r ) ;
function findgroups ( arr , n ) {
let c = [ 0 , 0 , 0 ] ; let i ;
let res = 0 ;
for ( i = 0 ; i < n ; i ++ ) c [ arr [ i ] % 3 ] ++ ;
res += ( ( c [ 0 ] * ( c [ 0 ] - 1 ) ) >> 1 ) ;
res += c [ 1 ] * c [ 2 ] ;
res += ( c [ 0 ] * ( c [ 0 ] - 1 ) * Math . floor ( ( c [ 0 ] - 2 ) ) / 6 ) ;
res += ( c [ 1 ] * ( c [ 1 ] - 1 ) * Math . floor ( ( c [ 1 ] - 2 ) ) / 6 ) ;
res += ( Math . floor ( c [ 2 ] * ( c [ 2 ] - 1 ) * ( c [ 2 ] - 2 ) ) / 6 ) ;
res += c [ 0 ] * c [ 1 ] * c [ 2 ] ;
return res ; }
let arr = [ 3 , 6 , 7 , 2 , 9 ] ; let n = arr . length ; document . write ( " " + findgroups ( arr , n ) ) ;
function swapBits ( x , p1 , p2 , n ) {
let set1 = ( x >> p1 ) & ( ( 1 << n ) - 1 ) ;
let set2 = ( x >> p2 ) & ( ( 1 << n ) - 1 ) ;
let xor = ( set1 ^ set2 ) ;
xor = ( xor << p1 ) | ( xor << p2 ) ;
let result = x ^ xor ; return result ; }
let res = swapBits ( 28 , 0 , 3 , 2 ) ; document . write ( " " + res ) ;
function Add ( x , y ) {
while ( y != 0 ) {
let carry = x & y ;
x = x ^ y ;
y = carry << 1 ; } return x ; }
document . write ( Add ( 15 , 32 ) ) ;
function addOne ( x ) { let m = 1 ;
while ( x & m ) { x = x ^ m ; m <<= 1 ; }
x = x ^ m ; return x ; }
document . write ( addOne ( 13 ) ) ;
function fun ( n ) { return n & ( n - 1 ) ; }
let n = 7 ; document . write ( " " + " " + fun ( n ) ) ;
function isPowerOfFour ( n ) { if ( n == 0 ) return false ; while ( n != 1 ) { if ( n % 4 != 0 ) return false ; n = n / 4 ; } return true ; }
let test_no = 64 ; if ( isPowerOfFour ( test_no ) ) document . write ( test_no + " " ) ; else document . write ( test_no + " " ) ;
function nextPowerOf2 ( n ) { var count = 0 ;
if ( n && ! ( n & ( n - 1 ) ) ) return n ; while ( n != 0 ) { n >>= 1 ; count += 1 ; } return 1 << count ; }
var n = 0 ; document . write ( nextPowerOf2 ( n ) ) ;
function isPowerOfTwo ( n ) { if ( n == 0 ) return 0 ; while ( n != 1 ) { if ( n % 2 != 0 ) return 0 ; n = n / 2 ; } return 1 ; }
isPowerOfTwo ( 31 ) ? document . write ( " " + " " ) : document . write ( " " + " " ) ; isPowerOfTwo ( 64 ) ? document . write ( " " ) : document . write ( " " ) ;
function getFirstSetBitPos ( n ) { return Math . log2 ( n & - n ) + 1 ; }
let g ; let n = 12 ; document . write ( getFirstSetBitPos ( n ) ) ;
function isPowerOfTwo ( n ) { return ( n && ( ! ( n & ( n - 1 ) ) ) ) }
function findPosition ( n ) { if ( ! isPowerOfTwo ( n ) ) return - 1 var count = 0
while ( n ) { n = n >> 1
count += 1 } return count }
var n = 0 var pos = findPosition ( n ) if ( pos == - 1 ) document . write ( " " , n , " " ) else document . write ( " " , n , " " , pos ) document . write ( " " ) n = 12 pos = findPosition ( n ) if ( pos == - 1 ) document . write ( " " , n , " " ) else document . write ( " " , n , " " , pos ) document . write ( " " ) n = 128 pos = findPosition ( n ) if ( pos == - 1 ) document . write ( " " , n , " " ) else document . write ( " " , n , " " , pos ) document . write ( " " )
var x = 10 ; var y = 5 ;
x = x * y ;
y = x / y ;
x = x / y ; document . write ( " " + " " + x + " " + y ) ;
let x = 10 , y = 5 ;
x = x ^ y ;
y = x ^ y ;
x = x ^ y ; document . write ( " " + x + " " + y ) ;
function swap ( xp , yp ) { xp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] ; yp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] ; xp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] ; }
let x = [ 10 ] ; swap ( x , x ) ; document . write ( " " + x [ 0 ] ) ;
function maxIndexDiff ( arr , n ) { let maxDiff = - 1 ; let i , j ; for ( i = 0 ; i < n ; ++ i ) { for ( j = n - 1 ; j > i ; -- j ) { if ( arr [ j ] > arr [ i ] && maxDiff < ( j - i ) ) maxDiff = j - i ; } } return maxDiff ; }
let arr = [ 9 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 18 , 0 ] ; let n = arr . length ; let maxDiff = maxIndexDiff ( arr , n ) ; document . write ( maxDiff ) ;
function findMaximum ( arr , low , high ) { var max = arr [ low ] ; var i ; for ( i = low + 1 ; i <= high ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; else break ; } return max ; }
var arr = [ 1 , 30 , 40 , 50 , 60 , 70 , 23 , 20 ] ; var n = arr . length ; document . write ( " " + findMaximum ( arr , 0 , n - 1 ) ) ;
function printSorted ( arr , start , end ) { if ( start > end ) return ;
printSorted ( arr , start * 2 + 1 , end ) ;
document . write ( arr [ start ] + " " ) ;
printSorted ( arr , start * 2 + 2 , end ) ; }
var arr = [ 4 , 2 , 5 , 1 , 3 ] ; printSorted ( arr , 0 , arr . length - 1 ) ;
function search ( mat , n , x ) {
let i = 0 , j = n - 1 ; while ( i < n && j >= 0 ) { if ( mat [ i ] [ j ] == x ) { document . write ( " " + i + " " + j ) ; return ; } if ( mat [ i ] [ j ] > x ) j -- ;
else i ++ ; } document . write ( " " ) ;
return ; }
let mat = [ [ 10 , 20 , 30 , 40 ] , [ 15 , 25 , 35 , 45 ] , [ 27 , 29 , 37 , 48 ] , [ 32 , 33 , 39 , 50 ] ] ; search ( mat , 4 , 29 ) ;
let N = 4 ;
function add ( A , B , C ) { let i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < N ; j ++ ) C [ i ] [ j ] = A [ i ] [ j ] + B [ i ] [ j ] ; }
let A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] ; let B = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] ; let C = new Array ( N ) ; for ( let k = 0 ; k < N ; k ++ ) C [ k ] = new Array ( N ) ; let i , j ; add ( A , B , C ) ; document . write ( " " ) ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < N ; j ++ ) document . write ( C [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
