def printNGE ( arr ) : NEW_LINE INDENT for i in range ( 0 , len ( arr ) , 1 ) : NEW_LINE INDENT next = - 1 NEW_LINE for j in range ( i + 1 , len ( arr ) , 1 ) : NEW_LINE INDENT if arr [ i ] < arr [ j ] : NEW_LINE INDENT next = arr [ j ] NEW_LINE break NEW_LINE DEDENT DEDENT print ( str ( arr [ i ] ) + " ▁ - - ▁ " + str ( next ) ) NEW_LINE DEDENT DEDENT
arr = [ 11 , 13 , 21 , 3 ] NEW_LINE printNGE ( arr ) NEW_LINE
def findMin ( arr , low , high ) : NEW_LINE
if high < low : NEW_LINE INDENT return arr [ 0 ] NEW_LINE DEDENT
if high == low : NEW_LINE INDENT return arr [ low ] NEW_LINE DEDENT
mid = int ( ( low + high ) / 2 ) NEW_LINE
if mid < high and arr [ mid + 1 ] < arr [ mid ] : NEW_LINE INDENT return arr [ mid + 1 ] NEW_LINE DEDENT
if mid > low and arr [ mid ] < arr [ mid - 1 ] : NEW_LINE INDENT return arr [ mid ] NEW_LINE DEDENT
if arr [ high ] > arr [ mid ] : NEW_LINE INDENT return findMin ( arr , low , mid - 1 ) NEW_LINE DEDENT return findMin ( arr , mid + 1 , high ) NEW_LINE
arr1 = [ 5 , 6 , 1 , 2 , 3 , 4 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " + str ( findMin ( arr1 , 0 , n1 - 1 ) ) ) NEW_LINE arr2 = [ 1 , 2 , 3 , 4 ] NEW_LINE n2 = len ( arr2 ) NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " + str ( findMin ( arr2 , 0 , n2 - 1 ) ) ) NEW_LINE arr3 = [ 1 ] NEW_LINE n3 = len ( arr3 ) NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " + str ( findMin ( arr3 , 0 , n3 - 1 ) ) ) NEW_LINE arr4 = [ 1 , 2 ] NEW_LINE n4 = len ( arr4 ) NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " + str ( findMin ( arr4 , 0 , n4 - 1 ) ) ) NEW_LINE arr5 = [ 2 , 1 ] NEW_LINE n5 = len ( arr5 ) NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " + str ( findMin ( arr5 , 0 , n5 - 1 ) ) ) NEW_LINE arr6 = [ 5 , 6 , 7 , 1 , 2 , 3 , 4 ] NEW_LINE n6 = len ( arr6 ) NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " + str ( findMin ( arr6 , 0 , n6 - 1 ) ) ) NEW_LINE arr7 = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] NEW_LINE n7 = len ( arr7 ) NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " + str ( findMin ( arr7 , 0 , n7 - 1 ) ) ) NEW_LINE arr8 = [ 2 , 3 , 4 , 5 , 6 , 7 , 8 , 1 ] NEW_LINE n8 = len ( arr8 ) NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " + str ( findMin ( arr8 , 0 , n8 - 1 ) ) ) NEW_LINE arr9 = [ 3 , 4 , 5 , 1 , 2 ] NEW_LINE n9 = len ( arr9 ) NEW_LINE print ( " The ▁ minimum ▁ element ▁ is ▁ " + str ( findMin ( arr9 , 0 , n9 - 1 ) ) ) NEW_LINE
def print2largest ( arr , arr_size ) : NEW_LINE
if ( arr_size < 2 ) : NEW_LINE INDENT print ( " ▁ Invalid ▁ Input ▁ " ) NEW_LINE return NEW_LINE DEDENT first = second = - 2147483648 NEW_LINE for i in range ( arr_size ) : NEW_LINE
if ( arr [ i ] > first ) : NEW_LINE INDENT second = first NEW_LINE first = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > second and arr [ i ] != first ) : NEW_LINE INDENT second = arr [ i ] NEW_LINE DEDENT if ( second == - 2147483648 ) : NEW_LINE print ( " There ▁ is ▁ no ▁ second ▁ largest ▁ element " ) NEW_LINE else : NEW_LINE print ( " The ▁ second ▁ largest ▁ element ▁ is " , second ) NEW_LINE
arr = [ 12 , 35 , 1 , 10 , 34 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print2largest ( arr , n ) NEW_LINE
def find_max_sum ( arr ) : NEW_LINE INDENT incl = 0 NEW_LINE excl = 0 NEW_LINE for i in arr : NEW_LINE DEDENT
new_excl = excl if excl > incl else incl NEW_LINE
incl = excl + i NEW_LINE excl = new_excl NEW_LINE
return ( excl if excl > incl else incl ) NEW_LINE
arr = [ 5 , 5 , 10 , 100 , 10 , 5 ] NEW_LINE print find_max_sum ( arr ) NEW_LINE
def minJumps ( arr , l , h ) : NEW_LINE
if ( h == l ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
min = float ( ' inf ' ) NEW_LINE for i in range ( l + 1 , h + 1 ) : NEW_LINE INDENT if ( i < l + arr [ l ] + 1 ) : NEW_LINE INDENT jumps = minJumps ( arr , i , h ) NEW_LINE if ( jumps != float ( ' inf ' ) and jumps + 1 < min ) : NEW_LINE INDENT min = jumps + 1 NEW_LINE DEDENT DEDENT DEDENT return min NEW_LINE
arr = [ 1 , 3 , 6 , 3 , 2 , 3 , 6 , 8 , 9 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE print ( ' Minimum ▁ number ▁ of ▁ jumps ▁ to ▁ reach ' , ' end ▁ is ' , minJumps ( arr , 0 , n - 1 ) ) NEW_LINE
def maxSumIS ( arr , n ) : NEW_LINE INDENT max = 0 NEW_LINE msis = [ 0 for x in range ( n ) ] NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT msis [ i ] = arr [ i ] NEW_LINE DEDENT
for i in range ( 1 , n ) : NEW_LINE INDENT for j in range ( i ) : NEW_LINE INDENT if ( arr [ i ] > arr [ j ] and msis [ i ] < msis [ j ] + arr [ i ] ) : NEW_LINE INDENT msis [ i ] = msis [ j ] + arr [ i ] NEW_LINE DEDENT DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT if max < msis [ i ] : NEW_LINE INDENT max = msis [ i ] NEW_LINE DEDENT DEDENT return max NEW_LINE
arr = [ 1 , 101 , 2 , 3 , 100 , 4 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Sum ▁ of ▁ maximum ▁ sum ▁ increasing ▁ " + " subsequence ▁ is ▁ " + str ( maxSumIS ( arr , n ) ) ) NEW_LINE
def moveToEnd ( mPlusN , size ) : NEW_LINE INDENT i = 0 NEW_LINE j = size - 1 NEW_LINE for i in range ( size - 1 , - 1 , - 1 ) : NEW_LINE INDENT if ( mPlusN [ i ] != NA ) : NEW_LINE INDENT mPlusN [ j ] = mPlusN [ i ] NEW_LINE j -= 1 NEW_LINE DEDENT DEDENT DEDENT
def merge ( mPlusN , N , m , n ) : NEW_LINE INDENT i = n NEW_LINE DEDENT
j = 0 NEW_LINE
k = 0 NEW_LINE
while ( k < ( m + n ) ) : NEW_LINE
if ( ( j == n ) or ( i < ( m + n ) and mPlusN [ i ] <= N [ j ] ) ) : NEW_LINE INDENT mPlusN [ k ] = mPlusN [ i ] NEW_LINE k += 1 NEW_LINE i += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT mPlusN [ k ] = N [ j ] NEW_LINE k += 1 NEW_LINE j += 1 NEW_LINE DEDENT
def printArray ( arr , size ) : NEW_LINE INDENT for i in range ( size ) : NEW_LINE INDENT print ( arr [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
mPlusN = [ 2 , 8 , NA , NA , NA , 13 , NA , 15 , 20 ] NEW_LINE N = [ 5 , 7 , 9 , 25 ] NEW_LINE n = len ( N ) NEW_LINE m = len ( mPlusN ) - n NEW_LINE
moveToEnd ( mPlusN , m + n ) NEW_LINE
merge ( mPlusN , N , m , n ) NEW_LINE
printArray ( mPlusN , m + n ) NEW_LINE
def minAbsSumPair ( arr , arr_size ) : NEW_LINE INDENT inv_count = 0 NEW_LINE DEDENT
if arr_size < 2 : NEW_LINE INDENT print ( " Invalid ▁ Input " ) NEW_LINE return NEW_LINE DEDENT
min_l = 0 NEW_LINE min_r = 1 NEW_LINE min_sum = arr [ 0 ] + arr [ 1 ] NEW_LINE for l in range ( 0 , arr_size - 1 ) : NEW_LINE INDENT for r in range ( l + 1 , arr_size ) : NEW_LINE INDENT sum = arr [ l ] + arr [ r ] NEW_LINE if abs ( min_sum ) > abs ( sum ) : NEW_LINE INDENT min_sum = sum NEW_LINE min_l = l NEW_LINE min_r = r NEW_LINE DEDENT DEDENT DEDENT print ( " The ▁ two ▁ elements ▁ whose ▁ sum ▁ is ▁ minimum ▁ are " , arr [ min_l ] , " and ▁ " , arr [ min_r ] ) NEW_LINE
arr = [ 1 , 60 , - 10 , 70 , - 80 , 85 ] NEW_LINE minAbsSumPair ( arr , 6 ) ; NEW_LINE
def sort012 ( a , arr_size ) : NEW_LINE INDENT lo = 0 NEW_LINE hi = arr_size - 1 NEW_LINE mid = 0 NEW_LINE while mid <= hi : NEW_LINE INDENT if a [ mid ] == 0 : NEW_LINE INDENT a [ lo ] , a [ mid ] = a [ mid ] , a [ lo ] NEW_LINE lo = lo + 1 NEW_LINE mid = mid + 1 NEW_LINE DEDENT elif a [ mid ] == 1 : NEW_LINE INDENT mid = mid + 1 NEW_LINE DEDENT else : NEW_LINE INDENT a [ mid ] , a [ hi ] = a [ hi ] , a [ mid ] NEW_LINE hi = hi - 1 NEW_LINE DEDENT DEDENT return a NEW_LINE DEDENT
def printArray ( a ) : NEW_LINE INDENT for k in a : NEW_LINE INDENT print k , NEW_LINE DEDENT DEDENT
arr = [ 0 , 1 , 1 , 0 , 1 , 2 , 1 , 2 , 0 , 0 , 0 , 1 ] NEW_LINE arr_size = len ( arr ) NEW_LINE arr = sort012 ( arr , arr_size ) NEW_LINE print   " Array after segregation : NEW_LINE " , NEW_LINE printArray ( arr ) NEW_LINE
def findnumberofTriangles ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
count = 0 NEW_LINE
for i in range ( 0 , n - 2 ) : NEW_LINE
k = i + 2 NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE
while ( k < n and arr [ i ] + arr [ j ] > arr [ k ] ) : NEW_LINE INDENT k += 1 NEW_LINE DEDENT
if ( k > j ) : NEW_LINE INDENT count += k - j - 1 NEW_LINE DEDENT return count NEW_LINE
arr = [ 10 , 21 , 22 , 100 , 101 , 200 , 300 ] NEW_LINE print " Number ▁ of ▁ Triangles : " , findnumberofTriangles ( arr ) NEW_LINE
def binarySearch ( arr , low , high , key ) : NEW_LINE
mid = ( low + high ) / 2 NEW_LINE if ( key == arr [ int ( mid ) ] ) : NEW_LINE INDENT return mid NEW_LINE DEDENT if ( key > arr [ int ( mid ) ] ) : NEW_LINE INDENT return binarySearch ( arr , ( mid + 1 ) , high , key ) NEW_LINE DEDENT if ( key < arr [ int ( mid ) ] ) : NEW_LINE INDENT return binarySearch ( arr , low , ( mid - 1 ) , key ) NEW_LINE DEDENT return 0 NEW_LINE
arr = [ 5 , 6 , 7 , 8 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE key = 10 NEW_LINE print ( " Index : " , int ( binarySearch ( arr , 0 , n - 1 , key ) ) ) NEW_LINE
def equilibrium ( arr ) : NEW_LINE INDENT leftsum = 0 NEW_LINE rightsum = 0 NEW_LINE n = len ( arr ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT leftsum = 0 NEW_LINE rightsum = 0 NEW_LINE DEDENT
for j in range ( i ) : NEW_LINE INDENT leftsum += arr [ j ] NEW_LINE DEDENT
for j in range ( i + 1 , n ) : NEW_LINE INDENT rightsum += arr [ j ] NEW_LINE DEDENT
if leftsum == rightsum : NEW_LINE INDENT return i NEW_LINE DEDENT
return - 1 NEW_LINE
arr = [ - 7 , 1 , 5 , 2 , - 4 , 3 , 0 ] NEW_LINE print ( equilibrium ( arr ) ) NEW_LINE
def ceilSearch ( arr , low , high , x ) : NEW_LINE
if x <= arr [ low ] : NEW_LINE INDENT return low NEW_LINE DEDENT
if x > arr [ high ] : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
mid = ( low + high ) / 2 ; NEW_LINE
if arr [ mid ] == x : NEW_LINE INDENT return mid NEW_LINE DEDENT
elif arr [ mid ] < x : NEW_LINE INDENT if mid + 1 <= high and x <= arr [ mid + 1 ] : NEW_LINE INDENT return mid + 1 NEW_LINE DEDENT else : NEW_LINE INDENT return ceilSearch ( arr , mid + 1 , high , x ) NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT if mid - 1 >= low and x > arr [ mid - 1 ] : NEW_LINE INDENT return mid NEW_LINE DEDENT else : NEW_LINE INDENT return ceilSearch ( arr , low , mid - 1 , x ) NEW_LINE DEDENT DEDENT
arr = [ 1 , 2 , 8 , 10 , 10 , 12 , 19 ] NEW_LINE n = len ( arr ) NEW_LINE x = 20 NEW_LINE index = ceilSearch ( arr , 0 , n - 1 , x ) ; NEW_LINE if index == - 1 : NEW_LINE INDENT print ( " Ceiling ▁ of ▁ % d ▁ doesn ' t ▁ exist ▁ in ▁ array ▁ " % x ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " ceiling ▁ of ▁ % d ▁ is ▁ % d " % ( x , arr [ index ] ) ) NEW_LINE DEDENT
def findCandidate ( A ) : NEW_LINE INDENT maj_index = 0 NEW_LINE count = 1 NEW_LINE for i in range ( len ( A ) ) : NEW_LINE INDENT if A [ maj_index ] == A [ i ] : NEW_LINE INDENT count += 1 NEW_LINE DEDENT else : NEW_LINE INDENT count -= 1 NEW_LINE DEDENT if count == 0 : NEW_LINE INDENT maj_index = i NEW_LINE count = 1 NEW_LINE DEDENT DEDENT return A [ maj_index ] NEW_LINE DEDENT
def isMajority ( A , cand ) : NEW_LINE INDENT count = 0 NEW_LINE for i in range ( len ( A ) ) : NEW_LINE INDENT if A [ i ] == cand : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT if count > len ( A ) / 2 : NEW_LINE INDENT return True NEW_LINE DEDENT else : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
def printMajority ( A ) : NEW_LINE
cand = findCandidate ( A ) NEW_LINE
if isMajority ( A , cand ) == True : NEW_LINE INDENT print ( cand ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ Majority ▁ Element " ) NEW_LINE DEDENT
A = [ 1 , 3 , 3 , 1 , 2 ] NEW_LINE
printMajority ( A ) NEW_LINE
def printRepeating ( arr , size ) : NEW_LINE INDENT print ( " Repeating ▁ elements ▁ are ▁ " , end = ' ' ) NEW_LINE for i in range ( 0 , size ) : NEW_LINE INDENT for j in range ( i + 1 , size ) : NEW_LINE INDENT if arr [ i ] == arr [ j ] : NEW_LINE INDENT print ( arr [ i ] , end = ' ▁ ' ) NEW_LINE DEDENT DEDENT DEDENT DEDENT
arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 1 ] NEW_LINE arr_size = len ( arr ) NEW_LINE printRepeating ( arr , arr_size ) NEW_LINE
def printRepeating ( arr , size ) : NEW_LINE
S = 0 ; NEW_LINE
P = 1 ; NEW_LINE n = size - 2 NEW_LINE
for i in range ( 0 , size ) : NEW_LINE INDENT S = S + arr [ i ] NEW_LINE P = P * arr [ i ] NEW_LINE DEDENT
S = S - n * ( n + 1 ) // 2 NEW_LINE
P = P // fact ( n ) NEW_LINE
D = math . sqrt ( S * S - 4 * P ) NEW_LINE x = ( D + S ) // 2 NEW_LINE y = ( S - D ) // 2 NEW_LINE print ( " The ▁ two ▁ Repeating ▁ elements ▁ are ▁ " , ( int ) ( x ) , " ▁ & ▁ " , ( int ) ( y ) ) NEW_LINE
def fact ( n ) : NEW_LINE INDENT if ( n == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT else : NEW_LINE INDENT return ( n * fact ( n - 1 ) ) NEW_LINE DEDENT DEDENT
arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 1 ] NEW_LINE arr_size = len ( arr ) NEW_LINE printRepeating ( arr , arr_size ) NEW_LINE
def printRepeating ( arr , size ) : NEW_LINE
xor = arr [ 0 ] NEW_LINE
n = size - 2 NEW_LINE x = 0 NEW_LINE y = 0 NEW_LINE
for i in range ( 1 , size ) : NEW_LINE INDENT xor ^= arr [ i ] NEW_LINE DEDENT for i in range ( 1 , n + 1 ) : NEW_LINE INDENT xor ^= i NEW_LINE DEDENT
set_bit_no = xor & ~ ( xor - 1 ) NEW_LINE
for i in range ( 0 , size ) : NEW_LINE INDENT if ( arr [ i ] & set_bit_no ) : NEW_LINE INDENT x = x ^ arr [ i ] NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT y = y ^ arr [ i ] NEW_LINE DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT if ( i & set_bit_no ) : NEW_LINE INDENT x = x ^ i NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT y = y ^ i NEW_LINE DEDENT
print ( " The ▁ two ▁ repeating " , " elements ▁ are " , y , x ) NEW_LINE
arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 1 ] NEW_LINE arr_size = len ( arr ) NEW_LINE printRepeating ( arr , arr_size ) NEW_LINE
def printRepeating ( arr , size ) : NEW_LINE INDENT print ( " ▁ The ▁ repeating ▁ elements ▁ are " , end = " ▁ " ) NEW_LINE for i in range ( 0 , size ) : NEW_LINE INDENT if ( arr [ abs ( arr [ i ] ) ] > 0 ) : NEW_LINE INDENT arr [ abs ( arr [ i ] ) ] = ( - 1 ) * arr [ abs ( arr [ i ] ) ] NEW_LINE DEDENT else : NEW_LINE INDENT print ( abs ( arr [ i ] ) , end = " ▁ " ) NEW_LINE DEDENT DEDENT DEDENT
arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 1 ] NEW_LINE arr_size = len ( arr ) NEW_LINE printRepeating ( arr , arr_size ) NEW_LINE
def binarySearch ( arr , low , high ) : NEW_LINE INDENT if high >= low : NEW_LINE DEDENT
mid = ( low + high ) // 2 NEW_LINE if mid is arr [ mid ] : NEW_LINE return mid NEW_LINE if mid > arr [ mid ] : NEW_LINE return binarySearch ( arr , ( mid + 1 ) , high ) NEW_LINE else : NEW_LINE return binarySearch ( arr , low , ( mid - 1 ) ) NEW_LINE
return - 1 NEW_LINE
arr = [ - 10 , - 1 , 0 , 3 , 10 , 11 , 30 , 50 , 100 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Fixed ▁ Point ▁ is ▁ " + str ( binarySearch ( arr , 0 , n - 1 ) ) ) NEW_LINE
def find3Numbers ( A , arr_size , sum ) : NEW_LINE
for i in range ( 0 , arr_size - 2 ) : NEW_LINE
for j in range ( i + 1 , arr_size - 1 ) : NEW_LINE
for k in range ( j + 1 , arr_size ) : NEW_LINE INDENT if A [ i ] + A [ j ] + A [ k ] == sum : NEW_LINE INDENT print ( " Triplet ▁ is " , A [ i ] , " , ▁ " , A [ j ] , " , ▁ " , A [ k ] ) NEW_LINE return True NEW_LINE DEDENT DEDENT
return False NEW_LINE
A = [ 1 , 4 , 45 , 6 , 10 , 8 ] NEW_LINE sum = 22 NEW_LINE arr_size = len ( A ) NEW_LINE find3Numbers ( A , arr_size , sum ) NEW_LINE
def search ( arr , n , x ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] == x ) : NEW_LINE INDENT return i NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT
arr = [ 2 , 3 , 4 , 10 , 40 ] NEW_LINE x = 10 NEW_LINE n = len ( arr ) NEW_LINE
result = search ( arr , n , x ) NEW_LINE if ( result == - 1 ) : NEW_LINE INDENT print ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Element ▁ is ▁ present ▁ at ▁ index " , result ) NEW_LINE DEDENT
def binarySearch ( arr , l , r , x ) : NEW_LINE INDENT if r >= l : NEW_LINE INDENT mid = l + ( r - l ) // 2 NEW_LINE DEDENT DEDENT
if arr [ mid ] == x : NEW_LINE INDENT return mid NEW_LINE DEDENT
elif arr [ mid ] > x : NEW_LINE INDENT return binarySearch ( arr , l , mid - 1 , x ) NEW_LINE DEDENT
else : NEW_LINE INDENT return binarySearch ( arr , mid + 1 , r , x ) NEW_LINE DEDENT else : NEW_LINE
return - 1 NEW_LINE
arr = [ 2 , 3 , 4 , 10 , 40 ] NEW_LINE x = 10 NEW_LINE result = binarySearch ( arr , 0 , len ( arr ) - 1 , x ) NEW_LINE if result != - 1 : NEW_LINE INDENT print ( " Element ▁ is ▁ present ▁ at ▁ index ▁ % ▁ d " % result ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) NEW_LINE DEDENT
def countSort ( arr ) : NEW_LINE
output = [ 0 for i in range ( len ( arr ) ) ] NEW_LINE
count = [ 0 for i in range ( 256 ) ] NEW_LINE
for i in arr : NEW_LINE INDENT count [ ord ( i ) ] += 1 NEW_LINE DEDENT
for i in range ( 256 ) : NEW_LINE INDENT count [ i ] += count [ i - 1 ] NEW_LINE DEDENT
for i in range ( len ( arr ) ) : NEW_LINE INDENT output [ count [ ord ( arr [ i ] ) ] - 1 ] = arr [ i ] NEW_LINE count [ ord ( arr [ i ] ) ] -= 1 NEW_LINE DEDENT
ans = [ " " for _ in arr ] NEW_LINE for i in range ( len ( arr ) ) : NEW_LINE INDENT ans [ i ] = output [ i ] NEW_LINE DEDENT return ans NEW_LINE
arr = " geeksforgeeks " NEW_LINE ans = countSort ( arr ) NEW_LINE print ( " Sorted ▁ character ▁ array ▁ is ▁ % ▁ s " % ( " " . join ( ans ) ) ) NEW_LINE
def printMaxActivities ( s , f ) : NEW_LINE INDENT n = len ( f ) NEW_LINE print " The ▁ following ▁ activities ▁ are ▁ selected " NEW_LINE DEDENT
i = 0 NEW_LINE print i , NEW_LINE
for j in xrange ( n ) : NEW_LINE
if s [ j ] >= f [ i ] : NEW_LINE INDENT print j , NEW_LINE i = j NEW_LINE DEDENT
s = [ 1 , 3 , 0 , 5 , 8 , 5 ] NEW_LINE f = [ 2 , 4 , 6 , 7 , 9 , 9 ] NEW_LINE printMaxActivities ( s , f ) NEW_LINE
def min ( x , y , z ) : NEW_LINE INDENT if ( x < y ) : NEW_LINE INDENT return x if ( x < z ) else z NEW_LINE DEDENT else : NEW_LINE INDENT return y if ( y < z ) else z NEW_LINE DEDENT DEDENT
def minCost ( cost , m , n ) : NEW_LINE INDENT if ( n < 0 or m < 0 ) : NEW_LINE INDENT return sys . maxsize NEW_LINE DEDENT elif ( m == 0 and n == 0 ) : NEW_LINE INDENT return cost [ m ] [ n ] NEW_LINE DEDENT else : NEW_LINE INDENT return cost [ m ] [ n ] + min ( minCost ( cost , m - 1 , n - 1 ) , minCost ( cost , m - 1 , n ) , minCost ( cost , m , n - 1 ) ) NEW_LINE DEDENT DEDENT
cost = [ [ 1 , 2 , 3 ] , [ 4 , 8 , 2 ] , [ 1 , 5 , 3 ] ] NEW_LINE print ( minCost ( cost , 2 , 2 ) ) NEW_LINE
R = 3 NEW_LINE C = 3 NEW_LINE def minCost ( cost , m , n ) : NEW_LINE
tc = [ [ 0 for x in range ( C ) ] for x in range ( R ) ] NEW_LINE tc [ 0 ] [ 0 ] = cost [ 0 ] [ 0 ] NEW_LINE
for i in range ( 1 , m + 1 ) : NEW_LINE INDENT tc [ i ] [ 0 ] = tc [ i - 1 ] [ 0 ] + cost [ i ] [ 0 ] NEW_LINE DEDENT
for j in range ( 1 , n + 1 ) : NEW_LINE INDENT tc [ 0 ] [ j ] = tc [ 0 ] [ j - 1 ] + cost [ 0 ] [ j ] NEW_LINE DEDENT
for i in range ( 1 , m + 1 ) : NEW_LINE INDENT for j in range ( 1 , n + 1 ) : NEW_LINE INDENT tc [ i ] [ j ] = min ( tc [ i - 1 ] [ j - 1 ] , tc [ i - 1 ] [ j ] , tc [ i ] [ j - 1 ] ) + cost [ i ] [ j ] NEW_LINE DEDENT DEDENT return tc [ m ] [ n ] NEW_LINE
cost = [ [ 1 , 2 , 3 ] , [ 4 , 8 , 2 ] , [ 1 , 5 , 3 ] ] NEW_LINE print ( minCost ( cost , 2 , 2 ) ) NEW_LINE
def binomialCoeff ( n , k ) : NEW_LINE
if k > n : NEW_LINE INDENT return 0 NEW_LINE DEDENT if k == 0 or k == n : NEW_LINE INDENT return 1 NEW_LINE DEDENT
return binomialCoeff ( n - 1 , k - 1 ) + binomialCoeff ( n - 1 , k ) NEW_LINE
n = 5 NEW_LINE k = 2 NEW_LINE print " Value ▁ of ▁ C ( % d , % d ) ▁ is ▁ ( % d ) " % ( n , k , binomialCoeff ( n , k ) ) NEW_LINE
def knapSack ( W , wt , val , n ) : NEW_LINE INDENT K = [ [ 0 for x in range ( W + 1 ) ] for x in range ( n + 1 ) ] NEW_LINE DEDENT
for i in range ( n + 1 ) : NEW_LINE INDENT for w in range ( W + 1 ) : NEW_LINE INDENT if i == 0 or w == 0 : NEW_LINE INDENT K [ i ] [ w ] = 0 NEW_LINE DEDENT elif wt [ i - 1 ] <= w : NEW_LINE INDENT K [ i ] [ w ] = max ( val [ i - 1 ] + K [ i - 1 ] [ w - wt [ i - 1 ] ] , K [ i - 1 ] [ w ] ) NEW_LINE DEDENT else : NEW_LINE INDENT K [ i ] [ w ] = K [ i - 1 ] [ w ] NEW_LINE DEDENT DEDENT DEDENT return K [ n ] [ W ] NEW_LINE
val = [ 60 , 100 , 120 ] NEW_LINE wt = [ 10 , 20 , 30 ] NEW_LINE W = 50 NEW_LINE n = len ( val ) NEW_LINE print ( knapSack ( W , wt , val , n ) ) NEW_LINE
def max ( x , y ) : NEW_LINE INDENT if ( x > y ) : NEW_LINE INDENT return x NEW_LINE DEDENT return y NEW_LINE DEDENT
def lps ( seq , i , j ) : NEW_LINE
if ( i == j ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
if ( seq [ i ] == seq [ j ] and i + 1 == j ) : NEW_LINE INDENT return 2 NEW_LINE DEDENT
if ( seq [ i ] == seq [ j ] ) : NEW_LINE INDENT return lps ( seq , i + 1 , j - 1 ) + 2 NEW_LINE DEDENT
return max ( lps ( seq , i , j - 1 ) , lps ( seq , i + 1 , j ) ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT seq = " GEEKSFORGEEKS " NEW_LINE n = len ( seq ) NEW_LINE print ( " The ▁ length ▁ of ▁ the ▁ LPS ▁ is " , lps ( seq , 0 , n - 1 ) ) NEW_LINE DEDENT
def isSubsetSum ( arr , n , sum ) : NEW_LINE
if sum == 0 : NEW_LINE INDENT return True NEW_LINE DEDENT if n == 0 and sum != 0 : NEW_LINE INDENT return False NEW_LINE DEDENT
if arr [ n - 1 ] > sum : NEW_LINE INDENT return isSubsetSum ( arr , n - 1 , sum ) NEW_LINE DEDENT
return isSubsetSum ( arr , n - 1 , sum ) or isSubsetSum ( arr , n - 1 , sum - arr [ n - 1 ] ) NEW_LINE
def findPartion ( arr , n ) : NEW_LINE
sum = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT sum += arr [ i ] NEW_LINE DEDENT
if sum % 2 != 0 : NEW_LINE INDENT return false NEW_LINE DEDENT
return isSubsetSum ( arr , n , sum // 2 ) NEW_LINE
arr = [ 3 , 1 , 5 , 9 , 12 ] NEW_LINE n = len ( arr ) NEW_LINE
if findPartion ( arr , n ) == True : NEW_LINE INDENT print ( " Can ▁ be ▁ divided ▁ into ▁ two ▁ subsets ▁ of ▁ equal ▁ sum " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Can ▁ not ▁ be ▁ divided ▁ into ▁ two ▁ subsets ▁ of ▁ equal ▁ sum " ) NEW_LINE DEDENT
def findoptimal ( N ) : NEW_LINE
if N <= 6 : NEW_LINE INDENT return N NEW_LINE DEDENT
maxi = 0 NEW_LINE
for b in range ( N - 3 , 0 , - 1 ) : NEW_LINE
curr = ( N - b - 1 ) * findoptimal ( b ) NEW_LINE if curr > maxi : NEW_LINE INDENT maxi = curr NEW_LINE DEDENT return maxi NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE
for n in range ( 1 , 21 ) : NEW_LINE INDENT print ( ' Maximum ▁ Number ▁ of ▁ As ▁ with ▁ ' , n , ' keystrokes ▁ is ▁ ' , findoptimal ( n ) ) NEW_LINE DEDENT
def search ( pat , txt ) : NEW_LINE INDENT M = len ( pat ) NEW_LINE N = len ( txt ) NEW_LINE i = 0 NEW_LINE while i <= N - M : NEW_LINE DEDENT
for j in xrange ( M ) : NEW_LINE INDENT if txt [ i + j ] != pat [ j ] : NEW_LINE INDENT break NEW_LINE DEDENT j += 1 NEW_LINE DEDENT
if j == M : NEW_LINE INDENT print " Pattern ▁ found ▁ at ▁ index ▁ " + str ( i ) NEW_LINE i = i + M NEW_LINE DEDENT elif j == 0 : NEW_LINE INDENT i = i + 1 NEW_LINE DEDENT else : NEW_LINE
i = i + j NEW_LINE
txt = " ABCEABCDABCEABCD " NEW_LINE pat = " ABCD " NEW_LINE search ( pat , txt ) NEW_LINE
def power ( x , y ) : NEW_LINE INDENT if ( y == 0 ) : return 1 NEW_LINE temp = power ( x , int ( y / 2 ) ) NEW_LINE if ( y % 2 == 0 ) : NEW_LINE INDENT return temp * temp NEW_LINE DEDENT else : NEW_LINE INDENT if ( y > 0 ) : return x * temp * temp NEW_LINE else : return ( temp * temp ) / x NEW_LINE DEDENT DEDENT
x , y = 2 , - 3 NEW_LINE print ( ' % .6f ' % ( power ( x , y ) ) ) NEW_LINE
def getMedian ( ar1 , ar2 , n ) : NEW_LINE INDENT i = 0 NEW_LINE j = 0 NEW_LINE m1 = - 1 NEW_LINE m2 = - 1 NEW_LINE DEDENT
count = 0 NEW_LINE while count < n + 1 : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
if i == n : NEW_LINE INDENT m1 = m2 NEW_LINE m2 = ar2 [ 0 ] NEW_LINE break NEW_LINE DEDENT
elif j == n : NEW_LINE INDENT m1 = m2 NEW_LINE m2 = ar1 [ 0 ] NEW_LINE break NEW_LINE DEDENT
if ar1 [ i ] <= ar2 [ j ] : NEW_LINE
m1 = m2 NEW_LINE m2 = ar1 [ i ] NEW_LINE i += 1 NEW_LINE else : NEW_LINE
m1 = m2 NEW_LINE m2 = ar2 [ j ] NEW_LINE j += 1 NEW_LINE return ( m1 + m2 ) / 2 NEW_LINE
ar1 = [ 1 , 12 , 15 , 26 , 38 ] NEW_LINE ar2 = [ 2 , 13 , 17 , 30 , 45 ] NEW_LINE n1 = len ( ar1 ) NEW_LINE n2 = len ( ar2 ) NEW_LINE if n1 == n2 : NEW_LINE INDENT print ( " Median ▁ is ▁ " , getMedian ( ar1 , ar2 , n1 ) ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Doesn ' t ▁ work ▁ for ▁ arrays ▁ of ▁ unequal ▁ size " ) NEW_LINE DEDENT
def multiply ( x , y ) : NEW_LINE
if ( y == 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( y > 0 ) : NEW_LINE INDENT return ( x + multiply ( x , y - 1 ) ) NEW_LINE DEDENT
if ( y < 0 ) : NEW_LINE INDENT return - multiply ( x , - y ) NEW_LINE DEDENT
print ( multiply ( 5 , - 11 ) ) NEW_LINE
def pow ( a , b ) : NEW_LINE INDENT if ( b == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT answer = a NEW_LINE increment = a NEW_LINE for i in range ( 1 , b ) : NEW_LINE INDENT for j in range ( 1 , a ) : NEW_LINE INDENT answer += increment NEW_LINE DEDENT increment = answer NEW_LINE DEDENT return answer NEW_LINE DEDENT
print ( pow ( 5 , 3 ) ) NEW_LINE
def fact ( n ) : NEW_LINE INDENT f = 1 NEW_LINE while n >= 1 : NEW_LINE INDENT f = f * n NEW_LINE n = n - 1 NEW_LINE DEDENT return f NEW_LINE DEDENT
def findSmallerInRight ( st , low , high ) : NEW_LINE INDENT countRight = 0 NEW_LINE i = low + 1 NEW_LINE while i <= high : NEW_LINE INDENT if st [ i ] < st [ low ] : NEW_LINE INDENT countRight = countRight + 1 NEW_LINE DEDENT i = i + 1 NEW_LINE DEDENT return countRight NEW_LINE DEDENT
def findRank ( st ) : NEW_LINE INDENT ln = len ( st ) NEW_LINE mul = fact ( ln ) NEW_LINE rank = 1 NEW_LINE i = 0 NEW_LINE while i < ln : NEW_LINE INDENT mul = mul / ( ln - i ) NEW_LINE DEDENT DEDENT
countRight = findSmallerInRight ( st , i , ln - 1 ) NEW_LINE rank = rank + countRight * mul NEW_LINE i = i + 1 NEW_LINE return rank NEW_LINE
st = " string " NEW_LINE print ( findRank ( st ) ) NEW_LINE
def binomialCoefficient ( n , k ) : NEW_LINE INDENT res = 1 NEW_LINE DEDENT
if ( k > n - k ) : NEW_LINE INDENT k = n - k NEW_LINE DEDENT
for i in range ( k ) : NEW_LINE INDENT res = res * ( n - i ) NEW_LINE res = res / ( i + 1 ) NEW_LINE DEDENT return res NEW_LINE
n = 8 NEW_LINE k = 2 NEW_LINE res = binomialCoefficient ( n , k ) NEW_LINE print ( " Value ▁ of ▁ C ( % ▁ d , ▁ % ▁ d ) ▁ is ▁ % ▁ d " % ( n , k , res ) ) NEW_LINE
def printPascal ( n ) : NEW_LINE INDENT for line in range ( 1 , n + 1 ) : NEW_LINE DEDENT
C = 1 ; NEW_LINE for i in range ( 1 , line + 1 ) : NEW_LINE
print ( C , end = " ▁ " ) ; NEW_LINE C = int ( C * ( line - i ) / i ) ; NEW_LINE print ( " " ) ; NEW_LINE
n = 5 ; NEW_LINE printPascal ( n ) ; NEW_LINE
def exponential ( n , x ) : NEW_LINE
sum = 1.0 NEW_LINE for i in range ( n , 0 , - 1 ) : NEW_LINE INDENT sum = 1 + x * sum / i NEW_LINE DEDENT print ( " e ^ x ▁ = " , sum ) NEW_LINE
n = 10 NEW_LINE x = 1.0 NEW_LINE exponential ( n , x ) NEW_LINE
def printCombination ( arr , n , r ) : NEW_LINE
data = [ 0 ] * r NEW_LINE
combinationUtil ( arr , n , r , 0 , data , 0 ) NEW_LINE
def combinationUtil ( arr , n , r , index , data , i ) : NEW_LINE
if ( index == r ) : NEW_LINE INDENT for j in range ( r ) : NEW_LINE INDENT print ( data [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE return NEW_LINE DEDENT
if ( i >= n ) : NEW_LINE INDENT return NEW_LINE DEDENT
data [ index ] = arr [ i ] NEW_LINE combinationUtil ( arr , n , r , index + 1 , data , i + 1 ) NEW_LINE
combinationUtil ( arr , n , r , index , data , i + 1 ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE r = 3 NEW_LINE n = len ( arr ) NEW_LINE printCombination ( arr , n , r ) NEW_LINE DEDENT
def calcAngle ( h , m ) : NEW_LINE
if ( h < 0 or m < 0 or h > 12 or m > 60 ) : NEW_LINE INDENT print ( ' Wrong ▁ input ' ) NEW_LINE DEDENT if ( h == 12 ) : NEW_LINE INDENT h = 0 NEW_LINE DEDENT if ( m == 60 ) : NEW_LINE INDENT m = 0 NEW_LINE h += 1 ; NEW_LINE if ( h > 12 ) : NEW_LINE INDENT h = h - 12 ; NEW_LINE DEDENT DEDENT
hour_angle = 0.5 * ( h * 60 + m ) NEW_LINE minute_angle = 6 * m NEW_LINE
angle = abs ( hour_angle - minute_angle ) NEW_LINE
angle = min ( 360 - angle , angle ) NEW_LINE return angle NEW_LINE
h = 9 NEW_LINE m = 60 NEW_LINE print ( ' Angle ▁ ' , calcAngle ( h , m ) ) NEW_LINE
def getSingle ( arr , n ) : NEW_LINE INDENT ones = 0 NEW_LINE twos = 0 NEW_LINE for i in range ( n ) : NEW_LINE DEDENT
twos = twos | ( ones & arr [ i ] ) NEW_LINE
ones = ones ^ arr [ i ] NEW_LINE
common_bit_mask = ~ ( ones & twos ) NEW_LINE
ones &= common_bit_mask NEW_LINE
twos &= common_bit_mask NEW_LINE return ones NEW_LINE
arr = [ 3 , 3 , 2 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ element ▁ with ▁ single ▁ occurrence ▁ is ▁ " , getSingle ( arr , n ) ) NEW_LINE
INT_SIZE = 32 NEW_LINE def getSingle ( arr , n ) : NEW_LINE
result = 0 NEW_LINE
for i in range ( 0 , INT_SIZE ) : NEW_LINE
sm = 0 NEW_LINE x = ( 1 << i ) NEW_LINE for j in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ j ] & x ) : NEW_LINE INDENT sm = sm + 1 NEW_LINE DEDENT DEDENT
if ( ( sm % 3 ) != 0 ) : NEW_LINE INDENT result = result | x NEW_LINE DEDENT return result NEW_LINE
arr = [ 12 , 1 , 12 , 3 , 12 , 1 , 1 , 2 , 3 , 2 , 2 , 3 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ element ▁ with ▁ single ▁ occurrence ▁ is ▁ " , getSingle ( arr , n ) ) NEW_LINE
def smallest ( x , y , z ) : NEW_LINE INDENT c = 0 NEW_LINE while ( x and y and z ) : NEW_LINE INDENT x = x - 1 NEW_LINE y = y - 1 NEW_LINE z = z - 1 NEW_LINE c = c + 1 NEW_LINE DEDENT return c NEW_LINE DEDENT
x = 12 NEW_LINE y = 15 NEW_LINE z = 5 NEW_LINE print ( " Minimum ▁ of ▁ 3 ▁ numbers ▁ is " , smallest ( x , y , z ) ) NEW_LINE
def addOne ( x ) : NEW_LINE INDENT return ( - ( ~ x ) ) ; NEW_LINE DEDENT
print ( addOne ( 13 ) ) NEW_LINE
def isPowerOfFour ( n ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
if ( n and ( not ( n & ( n - 1 ) ) ) ) : NEW_LINE
while ( n > 1 ) : NEW_LINE INDENT n >>= 1 NEW_LINE count += 1 NEW_LINE DEDENT
if ( count % 2 == 0 ) : NEW_LINE INDENT return True NEW_LINE DEDENT else : NEW_LINE INDENT return False NEW_LINE DEDENT
test_no = 64 NEW_LINE if ( isPowerOfFour ( 64 ) ) : NEW_LINE INDENT print ( test_no , ' is ▁ a ▁ power ▁ of ▁ 4' ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( test_no , ' is ▁ not ▁ a ▁ power ▁ of ▁ 4' ) NEW_LINE DEDENT
def min ( x , y ) : NEW_LINE INDENT return y ^ ( ( x ^ y ) & - ( x < y ) ) NEW_LINE DEDENT
def max ( x , y ) : NEW_LINE INDENT return x ^ ( ( x ^ y ) & - ( x < y ) ) NEW_LINE DEDENT
x = 15 NEW_LINE y = 6 NEW_LINE print ( " Minimum ▁ of " , x , " and " , y , " is " , end = " ▁ " ) NEW_LINE print ( min ( x , y ) ) NEW_LINE print ( " Maximum ▁ of " , x , " and " , y , " is " , end = " ▁ " ) NEW_LINE print ( max ( x , y ) ) NEW_LINE
def countSetBits ( n ) : NEW_LINE INDENT count = 0 NEW_LINE while ( n ) : NEW_LINE INDENT count += n & 1 NEW_LINE n >>= 1 NEW_LINE DEDENT return count NEW_LINE DEDENT
i = 9 NEW_LINE print ( countSetBits ( i ) ) NEW_LINE
num_to_bits = [ 0 , 1 , 1 , 2 , 1 , 2 , 2 , 3 , 1 , 2 , 2 , 3 , 2 , 3 , 3 , 4 ] ; NEW_LINE
def countSetBitsRec ( num ) : NEW_LINE INDENT nibble = 0 ; NEW_LINE if ( 0 == num ) : NEW_LINE INDENT return num_to_bits [ 0 ] ; NEW_LINE DEDENT DEDENT
nibble = num & 0xf ; NEW_LINE
return num_to_bits [ nibble ] + countSetBitsRec ( num >> 4 ) ; NEW_LINE
num = 31 ; NEW_LINE print ( countSetBitsRec ( num ) ) ; NEW_LINE
def nextPowerOf2 ( n ) : NEW_LINE INDENT p = 1 NEW_LINE if ( n and not ( n & ( n - 1 ) ) ) : NEW_LINE INDENT return n NEW_LINE DEDENT while ( p < n ) : NEW_LINE INDENT p <<= 1 NEW_LINE DEDENT return p ; NEW_LINE DEDENT
n = 5 NEW_LINE print ( nextPowerOf2 ( n ) ) ; NEW_LINE
def nextPowerOf2 ( n ) : NEW_LINE INDENT n -= 1 NEW_LINE n |= n >> 1 NEW_LINE n |= n >> 2 NEW_LINE n |= n >> 4 NEW_LINE n |= n >> 8 NEW_LINE n |= n >> 16 NEW_LINE n += 1 NEW_LINE return n NEW_LINE DEDENT
n = 5 NEW_LINE print ( nextPowerOf2 ( n ) ) NEW_LINE
def getParity ( n ) : NEW_LINE INDENT parity = 0 NEW_LINE while n : NEW_LINE INDENT parity = ~ parity NEW_LINE n = n & ( n - 1 ) NEW_LINE DEDENT return parity NEW_LINE DEDENT
n = 7 NEW_LINE print ( " Parity ▁ of ▁ no ▁ " , n , " ▁ = ▁ " , ( " odd " if getParity ( n ) else " even " ) ) NEW_LINE
def isPowerOfTwo ( n ) : NEW_LINE INDENT return ( math . ceil ( Log2 ( n ) ) == math . floor ( Log2 ( n ) ) ) ; NEW_LINE DEDENT
if ( isPowerOfTwo ( 31 ) ) : NEW_LINE INDENT print ( " Yes " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) ; NEW_LINE DEDENT if ( isPowerOfTwo ( 64 ) ) : NEW_LINE INDENT print ( " Yes " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) ; NEW_LINE DEDENT
def isPowerOfTwo ( x ) : NEW_LINE
return ( x and ( not ( x & ( x - 1 ) ) ) ) NEW_LINE
if ( isPowerOfTwo ( 31 ) ) : NEW_LINE INDENT print ( ' Yes ' ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( ' No ' ) NEW_LINE DEDENT if ( isPowerOfTwo ( 64 ) ) : NEW_LINE INDENT print ( ' Yes ' ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( ' No ' ) NEW_LINE DEDENT
def swapBits ( x ) : NEW_LINE
even_bits = x & 0xAAAAAAAA NEW_LINE
odd_bits = x & 0x55555555 NEW_LINE
even_bits >>= 1 NEW_LINE
odd_bits <<= 1 NEW_LINE
return ( even_bits odd_bits ) NEW_LINE
x = 23 NEW_LINE
print ( swapBits ( x ) ) NEW_LINE
def isPowerOfTwo ( n ) : NEW_LINE INDENT return ( True if ( n > 0 and ( ( n & ( n - 1 ) ) > 0 ) ) else False ) ; NEW_LINE DEDENT
def findPosition ( n ) : NEW_LINE INDENT if ( isPowerOfTwo ( n ) == True ) : NEW_LINE INDENT return - 1 ; NEW_LINE DEDENT i = 1 ; NEW_LINE pos = 1 ; NEW_LINE DEDENT
while ( ( i & n ) == 0 ) : NEW_LINE
i = i << 1 ; NEW_LINE
pos += 1 ; NEW_LINE return pos ; NEW_LINE
n = 16 ; NEW_LINE pos = findPosition ( n ) ; NEW_LINE if ( pos == - 1 ) : NEW_LINE INDENT print ( " n ▁ = " , n , " , ▁ Invalid ▁ number " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " n ▁ = " , n , " , ▁ Position ▁ " , pos ) ; NEW_LINE DEDENT n = 12 ; NEW_LINE pos = findPosition ( n ) ; NEW_LINE if ( pos == - 1 ) : NEW_LINE INDENT print ( " n ▁ = " , n , " , ▁ Invalid ▁ number " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " n ▁ = " , n , " , ▁ Position ▁ " , pos ) ; NEW_LINE DEDENT n = 128 ; NEW_LINE pos = findPosition ( n ) ; NEW_LINE if ( pos == - 1 ) : NEW_LINE INDENT print ( " n ▁ = " , n , " , ▁ Invalid ▁ number " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " n ▁ = " , n , " , ▁ Position ▁ " , pos ) ; NEW_LINE DEDENT
def segregate0and1 ( arr , size ) : NEW_LINE
left , right = 0 , size - 1 NEW_LINE while left < right : NEW_LINE
while arr [ left ] == 0 and left < right : NEW_LINE INDENT left += 1 NEW_LINE DEDENT
while arr [ right ] == 1 and left < right : NEW_LINE INDENT right -= 1 NEW_LINE DEDENT
if left < right : NEW_LINE INDENT arr [ left ] = 0 NEW_LINE arr [ right ] = 1 NEW_LINE left += 1 NEW_LINE right -= 1 NEW_LINE DEDENT return arr NEW_LINE
arr = [ 0 , 1 , 0 , 1 , 1 , 1 ] NEW_LINE arr_size = len ( arr ) NEW_LINE print ( " Array ▁ after ▁ segregation " ) NEW_LINE print ( segregate0and1 ( arr , arr_size ) ) NEW_LINE
def nextGreatest ( arr ) : NEW_LINE INDENT size = len ( arr ) NEW_LINE DEDENT
max_from_right = arr [ size - 1 ] NEW_LINE
arr [ size - 1 ] = - 1 NEW_LINE
for i in range ( size - 2 , - 1 , - 1 ) : NEW_LINE
temp = arr [ i ] NEW_LINE
arr [ i ] = max_from_right NEW_LINE
if max_from_right < temp : NEW_LINE INDENT max_from_right = temp NEW_LINE DEDENT
def printArray ( arr ) : NEW_LINE INDENT for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT print arr [ i ] , NEW_LINE DEDENT DEDENT
arr = [ 16 , 17 , 4 , 3 , 5 , 2 ] NEW_LINE nextGreatest ( arr ) NEW_LINE print " Modified ▁ array ▁ is " NEW_LINE printArray ( arr ) NEW_LINE
def maxDiff ( arr , arr_size ) : NEW_LINE INDENT max_diff = arr [ 1 ] - arr [ 0 ] NEW_LINE for i in range ( 0 , arr_size ) : NEW_LINE INDENT for j in range ( i + 1 , arr_size ) : NEW_LINE INDENT if ( arr [ j ] - arr [ i ] > max_diff ) : NEW_LINE INDENT max_diff = arr [ j ] - arr [ i ] NEW_LINE DEDENT DEDENT DEDENT return max_diff NEW_LINE DEDENT
arr = [ 1 , 2 , 90 , 10 , 110 ] NEW_LINE size = len ( arr ) NEW_LINE
print ( " Maximum ▁ difference ▁ is " , maxDiff ( arr , size ) ) NEW_LINE
def findMaximum ( arr , low , high ) : NEW_LINE
if low == high : NEW_LINE INDENT return arr [ low ] NEW_LINE DEDENT
if high == low + 1 and arr [ low ] >= arr [ high ] : NEW_LINE INDENT return arr [ low ] ; NEW_LINE DEDENT
if high == low + 1 and arr [ low ] < arr [ high ] : NEW_LINE INDENT return arr [ high ] NEW_LINE DEDENT mid = ( low + high ) // 2 NEW_LINE
if arr [ mid ] > arr [ mid + 1 ] and arr [ mid ] > arr [ mid - 1 ] : NEW_LINE INDENT return arr [ mid ] NEW_LINE DEDENT
if arr [ mid ] > arr [ mid + 1 ] and arr [ mid ] < arr [ mid - 1 ] : NEW_LINE INDENT return findMaximum ( arr , low , mid - 1 ) NEW_LINE DEDENT
else : NEW_LINE INDENT return findMaximum ( arr , mid + 1 , high ) NEW_LINE DEDENT
arr = [ 1 , 3 , 50 , 10 , 9 , 7 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ maximum ▁ element ▁ is ▁ % d " % findMaximum ( arr , 0 , n - 1 ) ) NEW_LINE
def getMissingNo ( A ) : NEW_LINE INDENT n = len ( A ) NEW_LINE total = ( n + 1 ) * ( n + 2 ) / 2 NEW_LINE sum_of_A = sum ( A ) NEW_LINE return total - sum_of_A NEW_LINE DEDENT
A = [ 1 , 2 , 4 , 5 , 6 ] NEW_LINE miss = getMissingNo ( A ) NEW_LINE print ( miss ) NEW_LINE
def printTwoElements ( arr , size ) : NEW_LINE INDENT for i in range ( size ) : NEW_LINE INDENT if arr [ abs ( arr [ i ] ) - 1 ] > 0 : NEW_LINE INDENT arr [ abs ( arr [ i ] ) - 1 ] = - arr [ abs ( arr [ i ] ) - 1 ] NEW_LINE DEDENT else : NEW_LINE INDENT print ( " The ▁ repeating ▁ element ▁ is " , abs ( arr [ i ] ) ) NEW_LINE DEDENT DEDENT for i in range ( size ) : NEW_LINE INDENT if arr [ i ] > 0 : NEW_LINE INDENT print ( " and ▁ the ▁ missing ▁ element ▁ is " , i + 1 ) NEW_LINE DEDENT DEDENT DEDENT
arr = [ 7 , 3 , 4 , 5 , 5 , 6 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE printTwoElements ( arr , n ) NEW_LINE
def printTwoOdd ( arr , size ) : NEW_LINE
xor2 = arr [ 0 ] NEW_LINE
set_bit_no = 0 NEW_LINE n = size - 2 NEW_LINE x , y = 0 , 0 NEW_LINE
for i in range ( 1 , size ) : NEW_LINE INDENT xor2 = xor2 ^ arr [ i ] NEW_LINE DEDENT
set_bit_no = xor2 & ~ ( xor2 - 1 ) NEW_LINE
for i in range ( size ) : NEW_LINE
if ( arr [ i ] & set_bit_no ) : NEW_LINE INDENT x = x ^ arr [ i ] NEW_LINE DEDENT
else : NEW_LINE INDENT y = y ^ arr [ i ] NEW_LINE DEDENT print ( " The ▁ two ▁ ODD ▁ elements ▁ are " , x , " & " , y ) NEW_LINE
arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 3 , 1 ] NEW_LINE arr_size = len ( arr ) NEW_LINE printTwoOdd ( arr , arr_size ) NEW_LINE
def findPair ( arr , n ) : NEW_LINE INDENT size = len ( arr ) NEW_LINE DEDENT
i , j = 0 , 1 NEW_LINE
while i < size and j < size : NEW_LINE INDENT if i != j and arr [ j ] - arr [ i ] == n : NEW_LINE INDENT print " Pair ▁ found ▁ ( " , arr [ i ] , " , " , arr [ j ] , " ) " NEW_LINE return True NEW_LINE DEDENT elif arr [ j ] - arr [ i ] < n : NEW_LINE INDENT j += 1 NEW_LINE DEDENT else : NEW_LINE INDENT i += 1 NEW_LINE DEDENT DEDENT print " No ▁ pair ▁ found " NEW_LINE return False NEW_LINE
arr = [ 1 , 8 , 30 , 40 , 100 ] NEW_LINE n = 60 NEW_LINE findPair ( arr , n ) NEW_LINE
def findFourElements ( A , n , X ) : NEW_LINE
for i in range ( 0 , n - 3 ) : NEW_LINE
for j in range ( i + 1 , n - 2 ) : NEW_LINE
for k in range ( j + 1 , n - 1 ) : NEW_LINE
for l in range ( k + 1 , n ) : NEW_LINE INDENT if A [ i ] + A [ j ] + A [ k ] + A [ l ] == X : NEW_LINE INDENT print ( " % d , ▁ % d , ▁ % d , ▁ % d " % ( A [ i ] , A [ j ] , A [ k ] , A [ l ] ) ) NEW_LINE DEDENT DEDENT
A = [ 10 , 2 , 3 , 4 , 5 , 9 , 7 , 8 ] NEW_LINE n = len ( A ) NEW_LINE X = 23 NEW_LINE findFourElements ( A , n , X ) NEW_LINE
cola = 2 NEW_LINE rowa = 3 NEW_LINE colb = 3 NEW_LINE rowb = 2 NEW_LINE
def Kroneckerproduct ( A , B ) : NEW_LINE INDENT C = [ [ 0 for j in range ( cola * colb ) ] for i in range ( rowa * rowb ) ] NEW_LINE DEDENT
for i in range ( 0 , rowa ) : NEW_LINE
for k in range ( 0 , rowb ) : NEW_LINE
for j in range ( 0 , cola ) : NEW_LINE
for l in range ( 0 , colb ) : NEW_LINE
C [ i + l + 1 ] [ j + k + 1 ] = A [ i ] [ j ] * B [ k ] [ l ] NEW_LINE print ( C [ i + l + 1 ] [ j + k + 1 ] , end = ' ▁ ' ) NEW_LINE print ( " " ) NEW_LINE
A = [ [ 0 for j in range ( 2 ) ] for i in range ( 3 ) ] NEW_LINE B = [ [ 0 for j in range ( 3 ) ] for i in range ( 2 ) ] NEW_LINE A [ 0 ] [ 0 ] = 1 NEW_LINE A [ 0 ] [ 1 ] = 2 NEW_LINE A [ 1 ] [ 0 ] = 3 NEW_LINE A [ 1 ] [ 1 ] = 4 NEW_LINE A [ 2 ] [ 0 ] = 1 NEW_LINE A [ 2 ] [ 1 ] = 0 NEW_LINE B [ 0 ] [ 0 ] = 0 NEW_LINE B [ 0 ] [ 1 ] = 5 NEW_LINE B [ 0 ] [ 2 ] = 2 NEW_LINE B [ 1 ] [ 0 ] = 6 NEW_LINE B [ 1 ] [ 1 ] = 7 NEW_LINE B [ 1 ] [ 2 ] = 3 NEW_LINE Kroneckerproduct ( A , B ) NEW_LINE
def Identity ( size ) : NEW_LINE INDENT for row in range ( 0 , size ) : NEW_LINE INDENT for col in range ( 0 , size ) : NEW_LINE DEDENT DEDENT
if ( row == col ) : NEW_LINE INDENT print ( "1 ▁ " , end = " ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( "0 ▁ " , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE
size = 5 NEW_LINE Identity ( size ) NEW_LINE
N = 4 NEW_LINE
def subtract ( A , B , C ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT C [ i ] [ j ] = A [ i ] [ j ] - B [ i ] [ j ] NEW_LINE DEDENT DEDENT DEDENT
A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] NEW_LINE B = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] NEW_LINE C = A [ : ] [ : ] NEW_LINE subtract ( A , B , C ) NEW_LINE print ( " Result ▁ matrix ▁ is " ) NEW_LINE for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT print ( C [ i ] [ j ] , " ▁ " , end = ' ' ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
