function areElementsContiguous ( $ arr , $ n ) {
sort ( $ arr ) ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] - $ arr [ $ i - 1 ] > 1 ) return false ; return true ; }
$ arr = array ( 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ) ; $ n = sizeof ( $ arr ) ; if ( areElementsContiguous ( $ arr , $ n ) ) echo " Yes " ; else echo " No " ; ? >
function largest ( $ arr , $ n ) { $ i ;
$ max = $ arr [ 0 ] ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] > $ max ) $ max = $ arr [ $ i ] ; return $ max ; }
$ arr = array ( 10 , 324 , 45 , 90 , 9808 ) ; $ n = sizeof ( $ arr ) ; echo " Largest ▁ in ▁ given ▁ array ▁ is ▁ " , largest ( $ arr , $ n ) ; ? >
function smallestSubWithSum ( $ arr , $ n , $ x ) {
$ min_len = $ n + 1 ;
for ( $ start = 0 ; $ start < $ n ; $ start ++ ) {
$ curr_sum = $ arr [ $ start ] ;
if ( $ curr_sum > $ x ) return 1 ;
for ( $ end = $ start + 1 ; $ end < $ n ; $ end ++ ) {
$ curr_sum += $ arr [ $ end ] ;
if ( $ curr_sum > $ x && ( $ end - $ start + 1 ) < $ min_len ) $ min_len = ( $ end - $ start + 1 ) ; } } return $ min_len ; }
$ arr1 = array ( 1 , 4 , 45 , 6 , 10 , 19 ) ; $ x = 51 ; $ n1 = sizeof ( $ arr1 ) ; $ res1 = smallestSubWithSum ( $ arr1 , $ n1 , $ x ) ; if ( ( $ res1 == $ n1 + 1 ) == true ) echo " Not ▁ possible STRNEWLINE " ; else echo $ res1 , " STRNEWLINE " ; $ arr2 = array ( 1 , 10 , 5 , 2 , 7 ) ; $ n2 = sizeof ( $ arr2 ) ; $ x = 9 ; $ res2 = smallestSubWithSum ( $ arr2 , $ n2 , $ x ) ; if ( ( $ res2 == $ n2 + 1 ) == true ) echo " Not ▁ possible STRNEWLINE " ; else echo $ res2 , " STRNEWLINE " ; $ arr3 = array ( 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ) ; $ n3 = sizeof ( $ arr3 ) ; $ x = 280 ; $ res3 = smallestSubWithSum ( $ arr3 , $ n3 , $ x ) ; if ( ( $ res3 == $ n3 + 1 ) == true ) echo " Not ▁ possible STRNEWLINE " ; else echo $ res3 , " STRNEWLINE " ; ? >
function printUnion ( $ arr1 , $ arr2 , $ m , $ n ) { $ i = 0 ; $ j = 0 ; while ( $ i < $ m && $ j < $ n ) { if ( $ arr1 [ $ i ] < $ arr2 [ $ j ] ) echo ( $ arr1 [ $ i ++ ] . " ▁ " ) ; else if ( $ arr2 [ $ j ] < $ arr1 [ $ i ] ) echo ( $ arr2 [ $ j ++ ] . " ▁ " ) ; else { echo ( $ arr2 [ $ j ++ ] . " " ) ; $ i ++ ; } }
while ( $ i < $ m ) echo ( $ arr1 [ $ i ++ ] . " ▁ " ) ; while ( $ j < $ n ) echo ( $ arr2 [ $ j ++ ] . " ▁ " ) ; }
$ arr1 = array ( 1 , 2 , 4 , 5 , 6 ) ; $ arr2 = array ( 2 , 3 , 5 , 7 ) ; $ m = sizeof ( $ arr1 ) ; $ n = sizeof ( $ arr2 ) ; printUnion ( $ arr1 , $ arr2 , $ m , $ n ) ; ? >
function printIntersection ( $ arr1 , $ arr2 , $ m , $ n ) { $ i = 0 ; $ j = 0 ; while ( $ i < $ m && $ j < $ n ) { if ( $ arr1 [ $ i ] < $ arr2 [ $ j ] ) $ i ++ ; else if ( $ arr2 [ $ j ] < $ arr1 [ $ i ] ) $ j ++ ; else { echo $ arr2 [ $ j ] , " " ; $ i ++ ; $ j ++ ; } } }
$ arr1 = array ( 1 , 2 , 4 , 5 , 6 ) ; $ arr2 = array ( 2 , 3 , 5 , 7 ) ; $ m = count ( $ arr1 ) ; $ n = count ( $ arr2 ) ;
printIntersection ( $ arr1 , $ arr2 , $ m , $ n ) ; ? >
function insertSorted ( & $ arr , $ n , $ key , $ capacity ) {
if ( $ n >= $ capacity ) return $ n ; array_push ( $ arr , $ key ) ; return ( $ n + 1 ) ; }
$ arr = array ( 12 , 16 , 20 , 40 , 50 , 70 ) ; $ capacity = 20 ; $ n = 6 ; $ key = 26 ; echo " Before ▁ Insertion : ▁ " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ;
$ n = insertSorted ( $ arr , $ n , $ key , $ capacity ) ; echo " After Insertion : " for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function findElement ( & $ arr , $ n , $ key ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] == $ key ) return $ i ; return -1 ; }
function deleteElement ( & $ arr , $ n , $ key ) {
$ pos = findElement ( $ arr , $ n , $ key ) ; if ( $ pos == -1 ) { echo " Element ▁ not ▁ found " ; return $ n ; }
for ( $ i = $ pos ; $ i < $ n - 1 ; $ i ++ ) $ arr [ $ i ] = $ arr [ $ i + 1 ] ; return $ n - 1 ; }
$ arr = array ( 10 , 50 , 30 , 40 , 20 ) ; $ n = count ( $ arr ) ; $ key = 30 ; echo " Array ▁ before ▁ deletion STRNEWLINE " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; $ n = deleteElement ( $ arr , $ n , $ key ) ; echo " Array after deletion " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function search ( $ arr , $ n , $ x ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] == $ x ) return $ i ; } return -1 ; }
$ arr = array ( 1 , 10 , 30 , 15 ) ; $ x = 30 ; $ n = sizeof ( $ arr ) ; echo $ x . " ▁ is ▁ present ▁ at ▁ index ▁ " . search ( $ arr , $ n , $ x ) ;
function binarySearch ( $ arr , $ l , $ r , $ x ) { while ( $ l <= $ r ) { $ m = $ l + ( $ r - $ l ) / 2 ;
if ( $ arr [ $ m ] == $ x ) return floor ( $ m ) ;
if ( $ arr [ $ m ] < $ x ) $ l = $ m + 1 ;
else $ r = $ m - 1 ; }
return -1 ; }
$ arr = array ( 2 , 3 , 4 , 10 , 40 ) ; $ n = count ( $ arr ) ; $ x = 10 ; $ result = binarySearch ( $ arr , 0 , $ n - 1 , $ x ) ; if ( ( $ result == -1 ) ) echo " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ; else echo " Element ▁ is ▁ present ▁ at ▁ index ▁ " , $ result ; ? >
function selection_sort ( & $ arr , $ n ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ low = $ i ; for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) { if ( $ arr [ $ j ] < $ arr [ $ low ] ) { $ low = $ j ; } }
if ( $ arr [ $ i ] > $ arr [ $ low ] ) { $ tmp = $ arr [ $ i ] ; $ arr [ $ i ] = $ arr [ $ low ] ; $ arr [ $ low ] = $ tmp ; } } }
$ arr = array ( 64 , 25 , 12 , 22 , 11 ) ; $ len = count ( $ arr ) ; selection_sort ( $ arr , $ len ) ; echo " Sorted ▁ array ▁ : ▁ STRNEWLINE " ; for ( $ i = 0 ; $ i < $ len ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function swap ( & $ a , & $ b ) { $ t = $ a ; $ a = $ b ; $ b = $ t ; }
function partition ( & $ arr , $ l , $ h ) { $ x = $ arr [ $ h ] ; $ i = ( $ l - 1 ) ; for ( $ j = $ l ; $ j <= $ h - 1 ; $ j ++ ) { if ( $ arr [ $ j ] <= $ x ) { $ i ++ ; swap ( $ arr [ $ i ] , $ arr [ $ j ] ) ; } } swap ( $ arr [ $ i + 1 ] , $ arr [ $ h ] ) ; return ( $ i + 1 ) ; }
function quickSortIterative ( & $ arr , $ l , $ h ) {
$ stack = array_fill ( 0 , $ h - $ l + 1 , 0 ) ;
$ top = -1 ;
$ stack [ ++ $ top ] = $ l ; $ stack [ ++ $ top ] = $ h ;
while ( $ top >= 0 ) {
$ h = $ stack [ $ top -- ] ; $ l = $ stack [ $ top -- ] ;
$ p = partition ( $ arr , $ l , $ h ) ;
if ( $ p - 1 > $ l ) { $ stack [ ++ $ top ] = $ l ; $ stack [ ++ $ top ] = $ p - 1 ; }
if ( $ p + 1 < $ h ) { $ stack [ ++ $ top ] = $ p + 1 ; $ stack [ ++ $ top ] = $ h ; } } }
function printArr ( $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; ++ $ i ) echo $ arr [ $ i ] . " ▁ " ; }
$ arr = array ( 4 , 3 , 5 , 2 , 1 , 3 , 2 , 3 ) ; $ n = count ( $ arr ) ;
quickSortIterative ( $ arr , 0 , $ n - 1 ) ; printArr ( $ arr , $ n ) ; ? >
function lcs ( $ X , $ Y , $ m , $ n ) { if ( $ m == 0 $ n == 0 ) return 0 ; else if ( $ X [ $ m - 1 ] == $ Y [ $ n - 1 ] ) return 1 + lcs ( $ X , $ Y , $ m - 1 , $ n - 1 ) ; else return max ( lcs ( $ X , $ Y , $ m , $ n - 1 ) , lcs ( $ X , $ Y , $ m - 1 , $ n ) ) ; }
$ X = " AGGTAB " ; $ Y = " GXTXAYB " ; echo " Length ▁ of ▁ LCS ▁ is ▁ " ; echo lcs ( $ X , $ Y , strlen ( $ X ) , strlen ( $ Y ) ) ; ? >
function lcs ( $ X , $ Y ) {
$ m = strlen ( $ X ) ; $ n = strlen ( $ Y ) ;
for ( $ i = 0 ; $ i <= $ m ; $ i ++ ) { for ( $ j = 0 ; $ j <= $ n ; $ j ++ ) { if ( $ i == 0 $ j == 0 ) $ L [ $ i ] [ $ j ] = 0 ; else if ( $ X [ $ i - 1 ] == $ Y [ $ j - 1 ] ) $ L [ $ i ] [ $ j ] = $ L [ $ i - 1 ] [ $ j - 1 ] + 1 ; else $ L [ $ i ] [ $ j ] = max ( $ L [ $ i - 1 ] [ $ j ] , $ L [ $ i ] [ $ j - 1 ] ) ; } }
return $ L [ $ m ] [ $ n ] ; }
$ X = " AGGTAB " ; $ Y = " GXTXAYB " ; echo " Length ▁ of ▁ LCS ▁ is ▁ " ; echo lcs ( $ X , $ Y ) ; ? >
$ MAX_CHAR = 256 ;
$ count = array_fill ( 0 , $ MAX_CHAR + 1 , 0 ) ;
function fact ( $ n ) { return ( $ n <= 1 ) ? 1 : $ n * fact ( $ n - 1 ) ; }
function populateAndIncreaseCount ( & $ count , $ str ) { global $ MAX_CHAR ; for ( $ i = 0 ; $ i < strlen ( $ str ) ; ++ $ i ) ++ $ count [ ord ( $ str [ $ i ] ) ] ; for ( $ i = 1 ; $ i < $ MAX_CHAR ; ++ $ i ) $ count [ $ i ] += $ count [ $ i - 1 ] ; }
function updatecount ( & $ count , $ ch ) { global $ MAX_CHAR ; for ( $ i = ord ( $ ch ) ; $ i < $ MAX_CHAR ; ++ $ i ) -- $ count [ $ i ] ; }
function findRank ( $ str ) { global $ MAX_CHAR ; $ len = strlen ( $ str ) ; $ mul = fact ( $ len ) ; $ rank = 1 ;
populateAndIncreaseCount ( $ count , $ str ) ; for ( $ i = 0 ; $ i < $ len ; ++ $ i ) { $ mul = ( int ) ( $ mul / ( $ len - $ i ) ) ;
$ rank += $ count [ ord ( $ str [ $ i ] ) - 1 ] * $ mul ;
updatecount ( $ count , $ str [ $ i ] ) ; } return $ rank ; }
$ str = " string " ; echo findRank ( $ str ) ; ? >
function getTwoElements ( & $ arr , $ n ) {
$ xor1 ;
$ set_bit_no ; $ i ; $ x = 0 ; $ y = 0 ; $ xor1 = $ arr [ 0 ] ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) $ xor1 = $ xor1 ^ $ arr [ $ i ] ;
for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) $ xor1 = $ xor1 ^ $ i ;
$ set_bit_no = $ xor1 & ~ ( $ xor1 - 1 ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( ( $ arr [ $ i ] & $ set_bit_no ) != 0 )
$ x = $ x ^ $ arr [ $ i ] ; else
$ y = $ y ^ $ arr [ $ i ] ; } for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) { if ( ( $ i & $ set_bit_no ) != 0 )
$ x = $ x ^ $ i ; else
$ y = $ y ^ $ i ; }
}
$ arr = array ( 1 , 3 , 4 , 5 , 1 , 6 , 2 ) ; $ n = sizeof ( $ arr ) ; getTwoElements ( $ arr , $ n ) ;
function minDistance ( $ arr , $ n ) { $ maximum_element = $ arr [ 0 ] ; $ min_dis = $ n ; $ index = 0 ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) {
if ( $ maximum_element == $ arr [ $ i ] ) { $ min_dis = min ( $ min_dis , ( $ i - $ index ) ) ; $ index = $ i ; }
else if ( $ maximum_element < $ arr [ $ i ] ) { $ maximum_element = $ arr [ $ i ] ; $ min_dis = $ n ; $ index = $ i ; }
else continue ; } return $ min_dis ; }
$ arr = array ( 6 , 3 , 1 , 3 , 6 , 4 , 6 ) ; $ n = count ( $ arr ) ; echo " Minimum ▁ distance ▁ = ▁ " . minDistance ( $ arr , $ n ) ; ? >
function fill0X ( $ m , $ n ) {
$ k = 0 ; $ l = 0 ;
$ r = $ m ; $ c = $ n ;
$ x = ' X ' ;
while ( $ k < $ m && $ l < $ n ) {
for ( $ i = $ l ; $ i < $ n ; ++ $ i ) $ a [ $ k ] [ $ i ] = $ x ; $ k ++ ;
for ( $ i = $ k ; $ i < $ m ; ++ $ i ) $ a [ $ i ] [ $ n - 1 ] = $ x ; $ n -- ;
if ( $ k < $ m ) { for ( $ i = $ n - 1 ; $ i >= $ l ; -- $ i ) $ a [ $ m - 1 ] [ $ i ] = $ x ; $ m -- ; }
if ( $ l < $ n ) { for ( $ i = $ m - 1 ; $ i >= $ k ; -- $ i ) $ a [ $ i ] [ $ l ] = $ x ; $ l ++ ; }
$ x = ( $ x == '0' ) ? ' X ' : '0' ; }
for ( $ i = 0 ; $ i < $ r ; $ i ++ ) { for ( $ j = 0 ; $ j < $ c ; $ j ++ ) echo ( $ a [ $ i ] [ $ j ] . " ▁ " ) ; echo " STRNEWLINE " ; } }
echo " Output ▁ for ▁ m ▁ = ▁ 5 , ▁ n ▁ = ▁ 6 STRNEWLINE " ; fill0X ( 5 , 6 ) ; echo " Output for m = 4 , n = 4 " ; fill0X ( 4 , 4 ) ; echo " Output for m = 3 , n = 4 " ; fill0X ( 3 , 4 ) ; ? >
