import java . util . Arrays ; class GFG {
static void calculateSpan ( int price [ ] , int n , int S [ ] ) {
S [ 0 ] = 1 ;
for ( int i = 1 ; i < n ; i ++ ) {
S [ i ] = 1 ;
for ( int j = i - 1 ; ( j >= 0 ) && ( price [ i ] >= price [ j ] ) ; j -- ) S [ i ] ++ ; } }
static void printArray ( int arr [ ] ) { System . out . print ( Arrays . toString ( arr ) ) ; }
public static void main ( String [ ] args ) { int price [ ] = { 10 , 4 , 5 , 90 , 120 , 80 } ; int n = price . length ; int S [ ] = new int [ n ] ;
calculateSpan ( price , n , S ) ;
printArray ( S ) ; } }
class LargestSubArray {
int findSubArray ( int arr [ ] , int n ) { int sum = 0 ; int maxsize = - 1 , startindex = 0 ; int endindex = 0 ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { sum = ( arr [ i ] == 0 ) ? - 1 : 1 ;
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] == 0 ) sum += - 1 ; else sum += 1 ;
if ( sum == 0 && maxsize < j - i + 1 ) { maxsize = j - i + 1 ; startindex = i ; } } } endindex = startindex + maxsize - 1 ; if ( maxsize == - 1 ) System . out . println ( " No ▁ such ▁ subarray " ) ; else System . out . println ( startindex + " ▁ to ▁ " + endindex ) ; return maxsize ; }
public static void main ( String [ ] args ) { LargestSubArray sub ; sub = new LargestSubArray ( ) ; int arr [ ] = { 1 , 0 , 0 , 1 , 0 , 1 , 1 } ; int size = arr . length ; sub . findSubArray ( arr , size ) ; } }
class RotateArray {
void leftRotatebyOne ( int arr [ ] , int n ) { int i , temp ; temp = arr [ 0 ] ; for ( i = 0 ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; arr [ n - 1 ] = temp ; }
void leftRotate ( int arr [ ] , int d , int n ) { for ( int i = 0 ; i < d ; i ++ ) leftRotatebyOne ( arr , n ) ; }
void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { RotateArray rotate = new RotateArray ( ) ; int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; rotate . leftRotate ( arr , 2 , 7 ) ; rotate . printArray ( arr , 7 ) ; } }
import java . io . * ; class SecondSmallest {
static void print2Smallest ( int arr [ ] ) { int first , second , arr_size = arr . length ;
if ( arr_size < 2 ) { System . out . println ( " ▁ Invalid ▁ Input ▁ " ) ; return ; } first = second = Integer . MAX_VALUE ; for ( int i = 0 ; i < arr_size ; i ++ ) {
if ( arr [ i ] < first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] < second && arr [ i ] != first ) second = arr [ i ] ; } if ( second == Integer . MAX_VALUE ) System . out . println ( " There ▁ is ▁ no ▁ second " + " smallest ▁ element " ) ; else System . out . println ( " The ▁ smallest ▁ element ▁ is ▁ " + first + " ▁ and ▁ second ▁ Smallest " + " ▁ element ▁ is ▁ " + second ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 13 , 1 , 10 , 34 , 1 } ; print2Smallest ( arr ) ; } }
class SmallestMissing {
int findFirstMissing ( int array [ ] , int start , int end ) { if ( start > end ) return end + 1 ; if ( start != array [ start ] ) return start ; int mid = ( start + end ) / 2 ;
if ( array [ mid ] == mid ) return findFirstMissing ( array , mid + 1 , end ) ; return findFirstMissing ( array , start , mid ) ; }
public static void main ( String [ ] args ) { SmallestMissing small = new SmallestMissing ( ) ; int arr [ ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 10 } ; int n = arr . length ; System . out . println ( " First ▁ Missing ▁ element ▁ is ▁ : ▁ " + small . findFirstMissing ( arr , 0 , n - 1 ) ) ; } }
class Test { static int arr [ ] = new int [ ] { 1 , 20 , 6 , 4 , 5 } ; static int getInvCount ( int n ) { int inv_count = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) inv_count ++ ; return inv_count ; }
public static void main ( String [ ] args ) { System . out . println ( " Number ▁ of ▁ inversions ▁ are ▁ " + getInvCount ( arr . length ) ) ; } }
class Main { static void printUnsorted ( int arr [ ] , int n ) { int s = 0 , e = n - 1 , i , max , min ;
for ( s = 0 ; s < n - 1 ; s ++ ) { if ( arr [ s ] > arr [ s + 1 ] ) break ; } if ( s == n - 1 ) { System . out . println ( " The ▁ complete ▁ array ▁ is ▁ sorted " ) ; return ; }
for ( e = n - 1 ; e > 0 ; e -- ) { if ( arr [ e ] < arr [ e - 1 ] ) break ; }
max = arr [ s ] ; min = arr [ s ] ; for ( i = s + 1 ; i <= e ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; if ( arr [ i ] < min ) min = arr [ i ] ; }
for ( i = 0 ; i < s ; i ++ ) { if ( arr [ i ] > min ) { s = i ; break ; } }
for ( i = n - 1 ; i >= e + 1 ; i -- ) { if ( arr [ i ] < max ) { e = i ; break ; } }
System . out . println ( " ▁ The ▁ unsorted ▁ subarray ▁ which " + " ▁ makes ▁ the ▁ given ▁ array ▁ sorted ▁ lies " + " ▁ between ▁ the ▁ indices ▁ " + s + " ▁ and ▁ " + e ) ; return ; } public static void main ( String args [ ] ) { int arr [ ] = { 10 , 12 , 20 , 30 , 25 , 40 , 32 , 31 , 35 , 50 , 60 } ; int arr_size = arr . length ; printUnsorted ( arr , arr_size ) ; } }
class Main {
static int findElement ( int arr [ ] , int n , int key ) { for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
public static void main ( String args [ ] ) { int arr [ ] = { 12 , 34 , 10 , 6 , 40 } ; int n = arr . length ;
int key = 40 ; int position = findElement ( arr , n , key ) ; if ( position == - 1 ) System . out . println ( " Element ▁ not ▁ found " ) ; else System . out . println ( " Element ▁ Found ▁ at ▁ Position : ▁ " + ( position + 1 ) ) ; } }
class EquilibriumIndex {
int equilibrium ( int arr [ ] , int n ) {
int sum = 0 ;
int leftsum = 0 ;
for ( int i = 0 ; i < n ; ++ i ) sum += arr [ i ] ; for ( int i = 0 ; i < n ; ++ i ) {
sum -= arr [ i ] ; if ( leftsum == sum ) return i ; leftsum += arr [ i ] ; }
return - 1 ; }
public static void main ( String [ ] args ) { EquilibriumIndex equi = new EquilibriumIndex ( ) ; int arr [ ] = { - 7 , 1 , 5 , 2 , - 4 , 3 , 0 } ; int arr_size = arr . length ; System . out . println ( " First ▁ equilibrium ▁ index ▁ is ▁ " + equi . equilibrium ( arr , arr_size ) ) ; } }
class Main {
static int ceilSearch ( int arr [ ] , int low , int high , int x ) { int i ;
if ( x <= arr [ low ] ) return low ;
for ( i = low ; i < high ; i ++ ) { if ( arr [ i ] == x ) return i ;
if ( arr [ i ] < x && arr [ i + 1 ] >= x ) return i + 1 ; }
return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 8 , 10 , 10 , 12 , 19 } ; int n = arr . length ; int x = 3 ; int index = ceilSearch ( arr , 0 , n - 1 , x ) ; if ( index == - 1 ) System . out . println ( " Ceiling ▁ of ▁ " + x + " ▁ doesn ' t ▁ exist ▁ in ▁ array " ) ; else System . out . println ( " ceiling ▁ of ▁ " + x + " ▁ is ▁ " + arr [ index ] ) ; } }
import java . io . * ; class Majority { static boolean isMajority ( int arr [ ] , int n , int x ) { int i , last_index = 0 ;
last_index = ( n % 2 == 0 ) ? n / 2 : n / 2 + 1 ;
for ( i = 0 ; i < last_index ; i ++ ) {
if ( arr [ i ] == x && arr [ i + n / 2 ] == x ) return true ; } return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 4 , 4 , 4 } ; int n = arr . length ; int x = 4 ; if ( isMajority ( arr , n , x ) == true ) System . out . println ( x + " ▁ appears ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; else System . out . println ( x + " ▁ does ▁ not ▁ appear ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; } }
import java . util . * ; import java . lang . * ; import java . io . * ; class PeakElement {
static int findPeakUtil ( int arr [ ] , int low , int high , int n ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == 0 arr [ mid - 1 ] <= arr [ mid ] ) && ( mid == n - 1 arr [ mid + 1 ] <= arr [ mid ] ) ) return mid ;
else if ( mid > 0 && arr [ mid - 1 ] > arr [ mid ] ) return findPeakUtil ( arr , low , ( mid - 1 ) , n ) ;
else return findPeakUtil ( arr , ( mid + 1 ) , high , n ) ; }
static int findPeak ( int arr [ ] , int n ) { return findPeakUtil ( arr , 0 , n - 1 , n ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 20 , 4 , 1 , 0 } ; int n = arr . length ; System . out . println ( " Index ▁ of ▁ a ▁ peak ▁ point ▁ is ▁ " + findPeak ( arr , n ) ) ; } }
class RepeatElement {
void printRepeating ( int arr [ ] , int size ) { int count [ ] = new int [ size ] ; int i ; System . out . println ( " Repeated ▁ elements ▁ are ▁ : ▁ " ) ; for ( i = 0 ; i < size ; i ++ ) { if ( count [ arr [ i ] ] == 1 ) System . out . print ( arr [ i ] + " ▁ " ) ; else count [ arr [ i ] ] ++ ; } }
public static void main ( String [ ] args ) { RepeatElement repeat = new RepeatElement ( ) ; int arr [ ] = { 4 , 2 , 4 , 5 , 2 , 3 , 1 } ; int arr_size = arr . length ; repeat . printRepeating ( arr , arr_size ) ; } }
class Main { static int linearSearch ( int arr [ ] , int n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == i ) return i ; }
return - 1 ; }
public static void main ( String args [ ] ) { int arr [ ] = { - 10 , - 1 , 0 , 3 , 10 , 11 , 30 , 50 , 100 } ; int n = arr . length ; System . out . println ( " Fixed ▁ Point ▁ is ▁ " + linearSearch ( arr , n ) ) ; } }
class SubarraySum {
int subArraySum ( int arr [ ] , int n , int sum ) { int curr_sum , i , j ;
for ( i = 0 ; i < n ; i ++ ) { curr_sum = arr [ i ] ;
for ( j = i + 1 ; j <= n ; j ++ ) { if ( curr_sum == sum ) { int p = j - 1 ; System . out . println ( " Sum ▁ found ▁ between ▁ indexes ▁ " + i + " ▁ and ▁ " + p ) ; return 1 ; } if ( curr_sum > sum j == n ) break ; curr_sum = curr_sum + arr [ j ] ; } } System . out . println ( " No ▁ subarray ▁ found " ) ; return 0 ; }
public static void main ( String [ ] args ) { SubarraySum arraysum = new SubarraySum ( ) ; int arr [ ] = { 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 } ; int n = arr . length ; int sum = 23 ; arraysum . subArraySum ( arr , n , sum ) ; } }
class SubarraySum {
int subArraySum ( int arr [ ] , int n , int sum ) {
int curr_sum = arr [ 0 ] , start = 0 , i ;
for ( i = 1 ; i <= n ; i ++ ) {
while ( curr_sum > sum && start < i - 1 ) { curr_sum = curr_sum - arr [ start ] ; start ++ ; }
if ( curr_sum == sum ) { int p = i - 1 ; System . out . println ( " Sum ▁ found ▁ between ▁ indexes ▁ " + start + " ▁ and ▁ " + p ) ; return 1 ; }
if ( i < n ) curr_sum = curr_sum + arr [ i ] ; }
System . out . println ( " No ▁ subarray ▁ found " ) ; return 0 ; }
public static void main ( String [ ] args ) { SubarraySum arraysum = new SubarraySum ( ) ; int arr [ ] = { 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 } ; int n = arr . length ; int sum = 23 ; arraysum . subArraySum ( arr , n , sum ) ; } }
class MatrixChainMultiplication {
static int MatrixChainOrder ( int p [ ] , int i , int j ) { if ( i == j ) return 0 ; int min = Integer . MAX_VALUE ;
for ( int k = i ; k < j ; k ++ ) { int count = MatrixChainOrder ( p , i , k ) + MatrixChainOrder ( p , k + 1 , j ) + p [ i - 1 ] * p [ k ] * p [ j ] ; if ( count < min ) min = count ; }
return min ; }
public static void main ( String args [ ] ) { int arr [ ] = new int [ ] { 1 , 2 , 3 , 4 , 3 } ; int n = arr . length ; System . out . println ( " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " + MatrixChainOrder ( arr , 1 , n - 1 ) ) ; } }
class MatrixChainMultiplication {
static int MatrixChainOrder ( int p [ ] , int n ) {
int m [ ] [ ] = new int [ n ] [ n ] ; int i , j , k , L , q ;
for ( i = 1 ; i < n ; i ++ ) m [ i ] [ i ] = 0 ;
for ( L = 2 ; L < n ; L ++ ) { for ( i = 1 ; i < n - L + 1 ; i ++ ) { j = i + L - 1 ; if ( j == n ) continue ; m [ i ] [ j ] = Integer . MAX_VALUE ; for ( k = i ; k <= j - 1 ; k ++ ) {
q = m [ i ] [ k ] + m [ k + 1 ] [ j ] + p [ i - 1 ] * p [ k ] * p [ j ] ; if ( q < m [ i ] [ j ] ) m [ i ] [ j ] = q ; } } } return m [ 1 ] [ n - 1 ] ; }
public static void main ( String args [ ] ) { int arr [ ] = new int [ ] { 1 , 2 , 3 , 4 } ; int size = arr . length ; System . out . println ( " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " + MatrixChainOrder ( arr , size ) ) ; } }
class Knapsack {
static int max ( int a , int b ) { return ( a > b ) ? a : b ; }
static int knapSack ( int W , int wt [ ] , int val [ ] , int n ) {
if ( n == 0 W == 0 ) return 0 ;
if ( wt [ n - 1 ] > W ) return knapSack ( W , wt , val , n - 1 ) ;
else return max ( val [ n - 1 ] + knapSack ( W - wt [ n - 1 ] , wt , val , n - 1 ) , knapSack ( W , wt , val , n - 1 ) ) ; }
public static void main ( String args [ ] ) { int val [ ] = new int [ ] { 60 , 100 , 120 } ; int wt [ ] = new int [ ] { 10 , 20 , 30 } ; int W = 50 ; int n = val . length ; System . out . println ( knapSack ( W , wt , val , n ) ) ; } }
import java . util . Arrays ; class GFG {
static int count ( int n ) {
int table [ ] = new int [ n + 1 ] , i ;
Arrays . fill ( table , 0 ) ;
table [ 0 ] = 1 ;
for ( i = 3 ; i <= n ; i ++ ) table [ i ] += table [ i - 3 ] ; for ( i = 5 ; i <= n ; i ++ ) table [ i ] += table [ i - 5 ] ; for ( i = 10 ; i <= n ; i ++ ) table [ i ] += table [ i - 10 ] ; return table [ n ] ; }
public static void main ( String [ ] args ) { int n = 20 ; System . out . println ( " Count ▁ for ▁ " + n + " ▁ is ▁ " + count ( n ) ) ; n = 13 ; System . out . println ( " Count ▁ for ▁ " + n + " ▁ is ▁ " + count ( n ) ) ; } }
public class NaiveSearch { public static void search ( String txt , String pat ) { int M = pat . length ( ) ; int N = txt . length ( ) ;
for ( int i = 0 ; i <= N - M ; i ++ ) { int j ;
for ( j = 0 ; j < M ; j ++ ) if ( txt . charAt ( i + j ) != pat . charAt ( j ) ) break ;
if ( j == M ) System . out . println ( " Pattern ▁ found ▁ at ▁ index ▁ " + i ) ; } }
public static void main ( String [ ] args ) { String txt = " AABAACAADAABAAABAA " ; String pat = " AABA " ; search ( txt , pat ) ; } }
public class Main {
public final static int d = 256 ;
static void search ( String pat , String txt , int q ) { int M = pat . length ( ) ; int N = txt . length ( ) ; int i , j ;
int p = 0 ;
int t = 0 ; int h = 1 ;
for ( i = 0 ; i < M - 1 ; i ++ ) h = ( h * d ) % q ;
for ( i = 0 ; i < M ; i ++ ) { p = ( d * p + pat . charAt ( i ) ) % q ; t = ( d * t + txt . charAt ( i ) ) % q ; }
for ( i = 0 ; i <= N - M ; i ++ ) {
if ( p == t ) {
for ( j = 0 ; j < M ; j ++ ) { if ( txt . charAt ( i + j ) != pat . charAt ( j ) ) break ; }
if ( j == M ) System . out . println ( " Pattern ▁ found ▁ at ▁ index ▁ " + i ) ; }
if ( i < N - M ) { t = ( d * ( t - txt . charAt ( i ) * h ) + txt . charAt ( i + M ) ) % q ;
if ( t < 0 ) t = ( t + q ) ; } } }
public static void main ( String [ ] args ) { String txt = " GEEKS ▁ FOR ▁ GEEKS " ; String pat = " GEEK " ;
int q = 101 ;
search ( pat , txt , q ) ; } }
class GFG {
static int power ( int x , int y ) { if ( y == 0 ) return 1 ; else if ( y % 2 == 0 ) return power ( x , y / 2 ) * power ( x , y / 2 ) ; else return x * power ( x , y / 2 ) * power ( x , y / 2 ) ; }
public static void main ( String [ ] args ) { int x = 2 ; int y = 3 ; System . out . printf ( " % d " , power ( x , y ) ) ; } }
import java . io . * ; class GFG { public static int counter = 2 ;
static boolean isLucky ( int n ) {
int next_position = n ; if ( counter > n ) return true ; if ( n % counter == 0 ) return false ;
next_position -= next_position / counter ; counter ++ ; return isLucky ( next_position ) ; }
public static void main ( String [ ] args ) { int x = 5 ; if ( isLucky ( x ) ) System . out . println ( x + " ▁ is ▁ a ▁ lucky ▁ no . " ) ; else System . out . println ( x + " ▁ is ▁ not ▁ a ▁ lucky ▁ no . " ) ; } }
class GFG {
static float squareRoot ( float n ) {
float x = n ; float y = 1 ;
double e = 0.000001 ; while ( x - y > e ) { x = ( x + y ) / 2 ; y = n / x ; } return x ; }
public static void main ( String [ ] args ) { int n = 50 ; System . out . printf ( " Square ▁ root ▁ of ▁ " + n + " ▁ is ▁ " + squareRoot ( n ) ) ; } }
import java . io . * ; class GFG {
static int multiply ( int x , int y ) { if ( y > 0 ) return ( x + multiply ( x , y - 1 ) ) ; else return 0 ; }
static int pow ( int a , int b ) { if ( b > 0 ) return multiply ( a , pow ( a , b - 1 ) ) ; else return 1 ; }
public static void main ( String [ ] args ) { System . out . println ( pow ( 5 , 3 ) ) ; } }
class GFG { static int sum , n ;
static float getAvg ( int x ) { sum += x ; return ( ( ( float ) sum ) / ++ n ) ; }
static void streamAvg ( float [ ] arr , int n ) { float avg = 0 ; for ( int i = 0 ; i < n ; i ++ ) { avg = getAvg ( ( int ) arr [ i ] ) ; System . out . println ( " Average ▁ of ▁ " + ( i + 1 ) + " ▁ numbers ▁ is ▁ " + avg ) ; } return ; }
public static void main ( String [ ] args ) { float [ ] arr = new float [ ] { 10 , 20 , 30 , 40 , 50 , 60 } ; int n = arr . length ; streamAvg ( arr , n ) ; } }
import java . io . * ; class GFG {
static int count ( int n ) {
if ( n < 3 ) return n ; if ( n >= 3 && n < 10 ) return n - 1 ;
int po = 1 ; while ( n / po > 9 ) po = po * 10 ;
int msd = n / po ; if ( msd != 3 )
return count ( msd ) * count ( po - 1 ) + count ( msd ) + count ( n % po ) ; else
return count ( msd * po - 1 ) ; }
public static void main ( String [ ] args ) { int n = 578 ; System . out . println ( count ( n ) ) ; } }
public static void printPascal ( int n ) {
int [ ] [ ] arr = new int [ n ] [ n ] ;
for ( int line = 0 ; line < n ; line ++ ) {
for ( int i = 0 ; i <= line ; i ++ ) {
if ( line == i i == 0 ) arr [ line ] [ i ] = 1 ;
else arr [ line ] [ i ] = arr [ line - 1 ] [ i - 1 ] + arr [ line - 1 ] [ i ] ; System . out . print ( arr [ line ] [ i ] ) ; } System . out . println ( " " ) ; } } }
public static void main ( String [ ] args ) { int n = 5 ; printPascal ( n ) ; }
import java . io . * ; import java . lang . Math ; class GFG {
public static void primeFactors ( int n ) {
while ( n % 2 == 0 ) { System . out . print ( 2 + " ▁ " ) ; n /= 2 ; }
for ( int i = 3 ; i <= Math . sqrt ( n ) ; i += 2 ) {
while ( n % i == 0 ) { System . out . print ( i + " ▁ " ) ; n /= i ; } }
if ( n > 2 ) System . out . print ( n ) ; }
public static void main ( String [ ] args ) { int n = 315 ; primeFactors ( n ) ; } }
import java . io . * ; class Combination {
static void printCombination ( int arr [ ] , int n , int r ) {
int data [ ] = new int [ r ] ;
combinationUtil ( arr , data , 0 , n - 1 , 0 , r ) ; }
static void combinationUtil ( int arr [ ] , int data [ ] , int start , int end , int index , int r ) {
if ( index == r ) { for ( int j = 0 ; j < r ; j ++ ) System . out . print ( data [ j ] + " ▁ " ) ; System . out . println ( " " ) ; return ; }
for ( int i = start ; i <= end && end - i + 1 >= r - index ; i ++ ) { data [ index ] = arr [ i ] ; combinationUtil ( arr , data , i + 1 , end , index + 1 , r ) ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int r = 3 ; int n = arr . length ; printCombination ( arr , n , r ) ; } }
class FindGroups {
int findgroups ( int arr [ ] , int n ) {
int c [ ] = new int [ ] { 0 , 0 , 0 } ; int i ;
int res = 0 ;
for ( i = 0 ; i < n ; i ++ ) c [ arr [ i ] % 3 ] ++ ;
res += ( ( c [ 0 ] * ( c [ 0 ] - 1 ) ) >> 1 ) ;
res += c [ 1 ] * c [ 2 ] ;
res += ( c [ 0 ] * ( c [ 0 ] - 1 ) * ( c [ 0 ] - 2 ) ) / 6 ;
res += ( c [ 1 ] * ( c [ 1 ] - 1 ) * ( c [ 1 ] - 2 ) ) / 6 ;
res += ( ( c [ 2 ] * ( c [ 2 ] - 1 ) * ( c [ 2 ] - 2 ) ) / 6 ) ;
res += c [ 0 ] * c [ 1 ] * c [ 2 ] ;
return res ; }
public static void main ( String [ ] args ) { FindGroups groups = new FindGroups ( ) ; int arr [ ] = { 3 , 6 , 7 , 2 , 9 } ; int n = arr . length ; System . out . println ( " Required ▁ number ▁ of ▁ groups ▁ are ▁ " + groups . findgroups ( arr , n ) ) ; } }
class GFG { static int swapBits ( int x , int p1 , int p2 , int n ) {
int set1 = ( x >> p1 ) & ( ( 1 << n ) - 1 ) ;
int set2 = ( x >> p2 ) & ( ( 1 << n ) - 1 ) ;
int xor = ( set1 ^ set2 ) ;
xor = ( xor << p1 ) | ( xor << p2 ) ;
int result = x ^ xor ; return result ; }
public static void main ( String [ ] args ) { int res = swapBits ( 28 , 0 , 3 , 2 ) ; System . out . println ( " Result ▁ = ▁ " + res ) ; } }
import java . io . * ; class GFG { static int Add ( int x , int y ) {
while ( y != 0 ) {
int carry = x & y ;
x = x ^ y ;
y = carry << 1 ; } return x ; }
public static void main ( String arg [ ] ) { System . out . println ( Add ( 15 , 32 ) ) ; } }
class GFG { static int addOne ( int x ) { int m = 1 ;
while ( ( int ) ( x & m ) >= 1 ) { x = x ^ m ; m <<= 1 ; }
x = x ^ m ; return x ; }
public static void main ( String [ ] args ) { System . out . println ( addOne ( 13 ) ) ; } }
class GFG {
static int fun ( int n ) { return n & ( n - 1 ) ; }
public static void main ( String arg [ ] ) { int n = 7 ; System . out . print ( " The ▁ number ▁ after ▁ unsetting ▁ " + " the ▁ rightmost ▁ set ▁ bit ▁ " + fun ( n ) ) ; } }
class GFG {
static int isPowerOfFour ( int n ) { if ( n == 0 ) return 0 ; while ( n != 1 ) { if ( n % 4 != 0 ) return 0 ; n = n / 4 ; } return 1 ; }
public static void main ( String [ ] args ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) == 1 ) System . out . println ( test_no + " ▁ is ▁ a ▁ power ▁ of ▁ 4" ) ; else System . out . println ( test_no + " is ▁ not ▁ a ▁ power ▁ of ▁ 4" ) ; } }
import java . io . * ; class GFG { static int nextPowerOf2 ( int n ) { int count = 0 ;
if ( n > 0 && ( n & ( n - 1 ) ) == 0 ) return n ; while ( n != 0 ) { n >>= 1 ; count += 1 ; } return 1 << count ; }
public static void main ( String args [ ] ) { int n = 0 ; System . out . println ( nextPowerOf2 ( n ) ) ; } }
import java . io . * ; class GFG {
static boolean isPowerOfTwo ( int n ) { if ( n == 0 ) return false ; while ( n != 1 ) { if ( n % 2 != 0 ) return false ; n = n / 2 ; } return true ; }
public static void main ( String args [ ] ) { if ( isPowerOfTwo ( 31 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; if ( isPowerOfTwo ( 64 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
class GFG { public static int getFirstSetBitPos ( int n ) { return ( int ) ( ( Math . log10 ( n & - n ) ) / Math . log10 ( 2 ) ) + 1 ; }
public static void main ( String [ ] args ) { int n = 12 ; System . out . println ( getFirstSetBitPos ( n ) ) ; } }
class GFG {
static boolean isPowerOfTwo ( int n ) { return n > 0 && ( ( n & ( n - 1 ) ) == 0 ) ; }
static int findPosition ( int n ) { if ( ! isPowerOfTwo ( n ) ) return - 1 ; int count = 0 ;
while ( n > 0 ) { n = n >> 1 ;
++ count ; } return count ; }
public static void main ( String [ ] args ) { int n = 0 ; int pos = findPosition ( n ) ; if ( pos == - 1 ) System . out . println ( " n ▁ = ▁ " + n + " , ▁ Invalid ▁ number " ) ; else System . out . println ( " n ▁ = ▁ " + n + " , ▁ Position ▁ " + pos ) ; n = 12 ; pos = findPosition ( n ) ; if ( pos == - 1 ) System . out . println ( " n ▁ = ▁ " + n + " , ▁ Invalid ▁ number " ) ; else System . out . println ( " n ▁ = ▁ " + n + " , ▁ Position ▁ " + pos ) ; n = 128 ; pos = findPosition ( n ) ; if ( pos == - 1 ) System . out . println ( " n ▁ = ▁ " + n + " , ▁ Invalid ▁ number " ) ; else System . out . println ( " n ▁ = ▁ " + n + " , ▁ Position ▁ " + pos ) ; } }
import java . io . * ; class GFG { public static void main ( String [ ] args ) { int x = 10 ; int y = 5 ;
x = x * y ;
y = x / y ;
x = x / y ; System . out . println ( " After ▁ swaping : " + " ▁ x ▁ = ▁ " + x + " , ▁ y ▁ = ▁ " + y ) ; } }
import java . io . * ; public class GFG { public static void main ( String a [ ] ) { int x = 10 ; int y = 5 ;
x = x ^ y ;
y = x ^ y ;
x = x ^ y ; System . out . println ( " After ▁ swap : ▁ x ▁ = ▁ " + x + " , ▁ y ▁ = ▁ " + y ) ; } }
class GFG {
static void swap ( int [ ] xp , int [ ] yp ) { xp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] ; yp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] ; xp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] ; }
public static void main ( String [ ] args ) { int [ ] x = { 10 } ; swap ( x , x ) ; System . out . println ( " After ▁ swap ( & x , ▁ & x ) : ▁ x ▁ = ▁ " + x [ 0 ] ) ; } }
class FindMaximum {
int maxIndexDiff ( int arr [ ] , int n ) { int maxDiff = - 1 ; int i , j ; for ( i = 0 ; i < n ; ++ i ) { for ( j = n - 1 ; j > i ; -- j ) { if ( arr [ j ] > arr [ i ] && maxDiff < ( j - i ) ) maxDiff = j - i ; } } return maxDiff ; }
public static void main ( String [ ] args ) { FindMaximum max = new FindMaximum ( ) ; int arr [ ] = { 9 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 18 , 0 } ; int n = arr . length ; int maxDiff = max . maxIndexDiff ( arr , n ) ; System . out . println ( maxDiff ) ; } }
class Main {
static int findMaximum ( int arr [ ] , int low , int high ) { int max = arr [ low ] ; int i ; for ( i = low ; i <= high ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 30 , 40 , 50 , 60 , 70 , 23 , 20 } ; int n = arr . length ; System . out . println ( " The ▁ maximum ▁ element ▁ is ▁ " + findMaximum ( arr , 0 , n - 1 ) ) ; } }
class GFG { private static void printSorted ( int [ ] arr , int start , int end ) { if ( start > end ) return ;
printSorted ( arr , start * 2 + 1 , end ) ;
System . out . print ( arr [ start ] + " ▁ " ) ;
printSorted ( arr , start * 2 + 2 , end ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 4 , 2 , 5 , 1 , 3 } ; printSorted ( arr , 0 , arr . length - 1 ) ; } }
class GFG {
private static void search ( int [ ] [ ] mat , int n , int x ) {
int i = 0 , j = n - 1 ; while ( i < n && j >= 0 ) { if ( mat [ i ] [ j ] == x ) { System . out . print ( " n ▁ Found ▁ at ▁ " + i + " ▁ " + j ) ; return ; } if ( mat [ i ] [ j ] > x ) j -- ;
else i ++ ; } System . out . print ( " n ▁ Element ▁ not ▁ found " ) ;
return ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 10 , 20 , 30 , 40 } , { 15 , 25 , 35 , 45 } , { 27 , 29 , 37 , 48 } , { 32 , 33 , 39 , 50 } } ; search ( mat , 4 , 29 ) ; } }
class GFG { static final int N = 4 ;
static void add ( int A [ ] [ ] , int B [ ] [ ] , int C [ ] [ ] ) { int i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < N ; j ++ ) C [ i ] [ j ] = A [ i ] [ j ] + B [ i ] [ j ] ; }
public static void main ( String [ ] args ) { int A [ ] [ ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; int B [ ] [ ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; int C [ ] [ ] = new int [ N ] [ N ] ; int i , j ; add ( A , B , C ) ; System . out . print ( "Result matrix is NEW_LINE"); for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < N ; j ++ ) System . out . print ( C [ i ] [ j ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); } } }
