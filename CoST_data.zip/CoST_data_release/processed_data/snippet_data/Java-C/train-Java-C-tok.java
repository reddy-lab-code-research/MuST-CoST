class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
boolean IsFoldable ( Node node ) { if ( node == null ) return true ; return IsFoldableUtil ( node . left , node . right ) ; }
boolean IsFoldableUtil ( Node n1 , Node n2 ) {
if ( n1 == null && n2 == null ) return true ;
if ( n1 == null n2 == null ) return false ;
return IsFoldableUtil ( n1 . left , n2 . right ) && IsFoldableUtil ( n1 . right , n2 . left ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . right . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; if ( tree . IsFoldable ( tree . root ) ) System . out . println ( " tree ▁ is ▁ foldable " ) ; else System . out . println ( " Tree ▁ is ▁ not ▁ foldable " ) ; } }
class GfG {
static class node { int data ; node left , right ; }
static int updatetree ( node root ) {
if ( root == null ) return 0 ; if ( root . left == null && root . right == null ) return root . data ;
int leftsum = updatetree ( root . left ) ; int rightsum = updatetree ( root . right ) ;
root . data += leftsum ;
return root . data + rightsum ; }
static void inorder ( node node ) { if ( node == null ) return ; inorder ( node . left ) ; System . out . print ( node . data + " ▁ " ) ; inorder ( node . right ) ; }
static node newNode ( int data ) { node node = new node ( ) ; node . data = data ; node . left = null ; node . right = null ; return ( node ) ; }
public static void main ( String [ ] args ) {
node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . right = newNode ( 6 ) ; updatetree ( root ) ; System . out . println ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ is " ) ; inorder ( root ) ; } }
class Node { int data ; Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } }
class BinaryTree { Node root ; void mirror ( ) { root = mirror ( root ) ; } Node mirror ( Node node ) { if ( node == null ) return node ;
Node left = mirror ( node . left ) ; Node right = mirror ( node . right ) ;
node . left = right ; node . right = left ; return node ; } void inOrder ( ) { inOrder ( root ) ; }
void inOrder ( Node node ) { if ( node == null ) return ; inOrder ( node . left ) ; System . out . print ( node . data + " ▁ " ) ; inOrder ( node . right ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ;
System . out . println ( " Inorder ▁ traversal ▁ of ▁ input ▁ tree ▁ is ▁ : " ) ; tree . inOrder ( ) ; System . out . println ( " " ) ;
tree . mirror ( ) ;
System . out . println ( " Inorder ▁ traversal ▁ of ▁ binary ▁ tree ▁ is ▁ : ▁ " ) ; tree . inOrder ( ) ; } }
class Node { int data ; Node left , right ; public Node ( int d ) { data = d ; left = right = null ; } } class BinaryTree { Node root ;
int isSumProperty ( Node node ) {
int left_data = 0 , right_data = 0 ;
if ( node == null || ( node . left == null && node . right == null ) ) return 1 ; else {
if ( node . left != null ) left_data = node . left . data ;
if ( node . right != null ) right_data = node . right . data ;
if ( ( node . data == left_data + right_data ) && ( isSumProperty ( node . left ) != 0 ) && isSumProperty ( node . right ) != 0 ) return 1 ; else return 0 ; } }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 2 ) ; tree . root . left . left = new Node ( 3 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . right = new Node ( 2 ) ; if ( tree . isSumProperty ( tree . root ) != 0 ) System . out . println ( " The ▁ given ▁ tree ▁ satisfies ▁ children " + " ▁ sum ▁ property " ) ; else System . out . println ( " The ▁ given ▁ tree ▁ does ▁ not ▁ satisfy ▁ children " + " ▁ sum ▁ property " ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
boolean isSibling ( Node node , Node a , Node b ) {
if ( node == null ) return false ; return ( ( node . left == a && node . right == b ) || ( node . left == b && node . right == a ) || isSibling ( node . left , a , b ) || isSibling ( node . right , a , b ) ) ; }
int level ( Node node , Node ptr , int lev ) {
if ( node == null ) return 0 ; if ( node == ptr ) return lev ;
int l = level ( node . left , ptr , lev + 1 ) ; if ( l != 0 ) return l ;
return level ( node . right , ptr , lev + 1 ) ; }
boolean isCousin ( Node node , Node a , Node b ) {
return ( ( level ( node , a , 1 ) == level ( node , b , 1 ) ) && ( ! isSibling ( node , a , b ) ) ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . left . right . right = new Node ( 15 ) ; tree . root . right . left = new Node ( 6 ) ; tree . root . right . right = new Node ( 7 ) ; tree . root . right . left . right = new Node ( 8 ) ; Node Node1 , Node2 ; Node1 = tree . root . left . left ; Node2 = tree . root . right . right ; if ( tree . isCousin ( tree . root , Node1 , Node2 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class Leaf { int leaflevel = 0 ; } class BinaryTree { Node root ; Leaf mylevel = new Leaf ( ) ;
boolean checkUtil ( Node node , int level , Leaf leafLevel ) {
if ( node == null ) return true ;
if ( node . left == null && node . right == null ) {
if ( leafLevel . leaflevel == 0 ) {
leafLevel . leaflevel = level ; return true ; }
return ( level == leafLevel . leaflevel ) ; }
return checkUtil ( node . left , level + 1 , leafLevel ) && checkUtil ( node . right , level + 1 , leafLevel ) ; }
boolean check ( Node node ) { int level = 0 ; return checkUtil ( node , level , mylevel ) ; }
public static void main ( String args [ ] ) {
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 12 ) ; tree . root . left = new Node ( 5 ) ; tree . root . left . left = new Node ( 3 ) ; tree . root . left . right = new Node ( 9 ) ; tree . root . left . left . left = new Node ( 1 ) ; tree . root . left . right . left = new Node ( 1 ) ; if ( tree . check ( tree . root ) ) System . out . println ( " Leaves ▁ are ▁ at ▁ same ▁ level " ) ; else System . out . println ( " Leaves ▁ are ▁ not ▁ at ▁ same ▁ level " ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
boolean isFullTree ( Node node ) {
if ( node == null ) return true ;
if ( node . left == null && node . right == null ) return true ;
if ( ( node . left != null ) && ( node . right != null ) ) return ( isFullTree ( node . left ) && isFullTree ( node . right ) ) ;
return false ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 20 ) ; tree . root . right = new Node ( 30 ) ; tree . root . left . right = new Node ( 40 ) ; tree . root . left . left = new Node ( 50 ) ; tree . root . right . left = new Node ( 60 ) ; tree . root . left . left . left = new Node ( 80 ) ; tree . root . right . right = new Node ( 70 ) ; tree . root . left . left . right = new Node ( 90 ) ; tree . root . left . right . left = new Node ( 80 ) ; tree . root . left . right . right = new Node ( 90 ) ; tree . root . right . left . left = new Node ( 80 ) ; tree . root . right . left . right = new Node ( 90 ) ; tree . root . right . right . left = new Node ( 80 ) ; tree . root . right . right . right = new Node ( 90 ) ; if ( tree . isFullTree ( tree . root ) ) System . out . print ( " The ▁ binary ▁ tree ▁ is ▁ full " ) ; else System . out . print ( " The ▁ binary ▁ tree ▁ is ▁ not ▁ full " ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root1 , root2 ;
boolean identicalTrees ( Node a , Node b ) {
if ( a == null && b == null ) return true ;
if ( a != null && b != null ) return ( a . data == b . data && identicalTrees ( a . left , b . left ) && identicalTrees ( a . right , b . right ) ) ;
return false ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root1 = new Node ( 1 ) ; tree . root1 . left = new Node ( 2 ) ; tree . root1 . right = new Node ( 3 ) ; tree . root1 . left . left = new Node ( 4 ) ; tree . root1 . left . right = new Node ( 5 ) ; tree . root2 = new Node ( 1 ) ; tree . root2 . left = new Node ( 2 ) ; tree . root2 . right = new Node ( 3 ) ; tree . root2 . left . left = new Node ( 4 ) ; tree . root2 . left . right = new Node ( 5 ) ; if ( tree . identicalTrees ( tree . root1 , tree . root2 ) ) System . out . println ( " Both ▁ trees ▁ are ▁ identical " ) ; else System . out . println ( " Trees ▁ are ▁ not ▁ identical " ) ; } }
import java . util . * ; class GFG {
static boolean areElementsContiguous ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] > 1 ) return false ; return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = arr . length ; if ( areElementsContiguous ( arr , n ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
class GfG {
static class Node { int data ; Node left , right ; }
static Node newNode ( int item ) { Node temp = new Node ( ) ; temp . data = item ; temp . left = null ; temp . right = null ; return temp ; }
static int getLevel ( Node root , Node node , int level ) {
if ( root == null ) return 0 ; if ( root == node ) return level ;
int downlevel = getLevel ( root . left , node , level + 1 ) ; if ( downlevel != 0 ) return downlevel ;
return getLevel ( root . right , node , level + 1 ) ; }
static void printGivenLevel ( Node root , Node node , int level ) {
if ( root == null level < 2 ) return ;
if ( level == 2 ) { if ( root . left == node root . right == node ) return ; if ( root . left != null ) System . out . print ( root . left . data + " ▁ " ) ; if ( root . right != null ) System . out . print ( root . right . data + " ▁ " ) ; }
else if ( level > 2 ) { printGivenLevel ( root . left , node , level - 1 ) ; printGivenLevel ( root . right , node , level - 1 ) ; } }
static void printCousins ( Node root , Node node ) {
int level = getLevel ( root , node , 1 ) ;
printGivenLevel ( root , node , level ) ; }
public static void main ( String [ ] args ) { Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . left . right . right = newNode ( 15 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 7 ) ; root . right . left . right = newNode ( 8 ) ; printCousins ( root , root . left . right ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
void printPaths ( Node node ) { int path [ ] = new int [ 1000 ] ; printPathsRecur ( node , path , 0 ) ; }
void printPathsRecur ( Node node , int path [ ] , int pathLen ) { if ( node == null ) return ;
path [ pathLen ] = node . data ; pathLen ++ ;
if ( node . left == null && node . right == null ) printArray ( path , pathLen ) ; else {
printPathsRecur ( node . left , path , pathLen ) ; printPathsRecur ( node . right , path , pathLen ) ; } }
void printArray ( int ints [ ] , int len ) { int i ; for ( i = 0 ; i < len ; i ++ ) System . out . print ( ints [ i ] + " ▁ " ) ; System . out . println ( " " ) ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ;
tree . printPaths ( tree . root ) ; } }
import java . util . * ; class GFG {
public static void leftRotate ( int arr [ ] , int d , int n ) { leftRotateRec ( arr , 0 , d , n ) ; } public static void leftRotateRec ( int arr [ ] , int i , int d , int n ) {
if ( d == 0 d == n ) return ;
if ( n - d == d ) { swap ( arr , i , n - d + i , d ) ; return ; }
if ( d < n - d ) { swap ( arr , i , n - d + i , d ) ; leftRotateRec ( arr , i , d , n - d ) ; }
else { swap ( arr , i , d , n - d ) ; leftRotateRec ( arr , n - d + i , 2 * d - n , d ) ; } }
public static void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void swap ( int arr [ ] , int fi , int si , int d ) { int i , temp ; for ( i = 0 ; i < d ; i ++ ) { temp = arr [ fi + i ] ; arr [ fi + i ] = arr [ si + i ] ; arr [ si + i ] = temp ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; leftRotate ( arr , 2 , 7 ) ; printArray ( arr , 7 ) ; } }
static void leftRotate ( int arr [ ] , int d , int n ) { int i , j ; if ( d == 0 d == n ) return ; i = d ; j = n - d ; while ( i != j ) {
if ( i < j ) { swap ( arr , d - i , d + j - i , i ) ; j -= i ; }
else { swap ( arr , d - i , d , j ) ; i -= j ; } }
swap ( arr , d - i , d , i ) ; }
import java . util . Arrays ; public class Test { static int arr [ ] = new int [ ] { 1 , 2 , 3 , 4 , 5 } ;
static void rotate ( ) { int i = 0 , j = arr . length - 1 ; while ( i != j ) { int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; i ++ ; } }
public static void main ( String [ ] args ) { System . out . println ( " Given ▁ Array ▁ is " ) ; System . out . println ( Arrays . toString ( arr ) ) ; rotate ( ) ; System . out . println ( " Rotated ▁ Array ▁ is " ) ; System . out . println ( Arrays . toString ( arr ) ) ; } }
class RearrangeArray {
void rearrangeNaive ( int arr [ ] , int n ) {
int temp [ ] = new int [ n ] ; int i ;
for ( i = 0 ; i < n ; i ++ ) temp [ arr [ i ] ] = i ;
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
void printArray ( int arr [ ] , int n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } System . out . println ( " " ) ; }
public static void main ( String [ ] args ) { RearrangeArray arrange = new RearrangeArray ( ) ; int arr [ ] = { 1 , 3 , 0 , 2 } ; int n = arr . length ; System . out . println ( " Given ▁ array ▁ is ▁ " ) ; arrange . printArray ( arr , n ) ; arrange . rearrangeNaive ( arr , n ) ; System . out . println ( " Modified ▁ array ▁ is ▁ " ) ; arrange . printArray ( arr , n ) ; } }
class Node { int key ; Node left , right ; public Node ( int item ) { key = item ; left = right = null ; } } class BinaryTree {
void printPostorder ( Node node ) { if ( node == null ) return ;
printPostorder ( node . left ) ;
printPostorder ( node . right ) ;
System . out . print ( node . key + " ▁ " ) ; }
void printInorder ( Node node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
System . out . print ( node . key + " ▁ " ) ;
printInorder ( node . right ) ; }
void printPreorder ( Node node ) { if ( node == null ) return ;
System . out . print ( node . key + " ▁ " ) ;
printPreorder ( node . left ) ;
printPreorder ( node . right ) ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; System . out . println ( " Preorder ▁ traversal ▁ of ▁ binary ▁ tree ▁ is ▁ " ) ; tree . printPreorder ( ) ; System . out . println ( " Inorder traversal of binary tree is "); tree . printInorder ( ) ; System . out . println ( " Postorder traversal of binary tree is "); tree . printPostorder ( ) ; } }
class Test { static int arr [ ] = { 10 , 324 , 45 , 90 , 9808 } ;
static int largest ( ) { int i ;
int max = arr [ 0 ] ;
for ( i = 1 ; i < arr . length ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
public static void main ( String [ ] args ) { System . out . println ( " Largest ▁ in ▁ given ▁ array ▁ is ▁ " + largest ( ) ) ; } }
static class Pair { int min ; int max ; } static Pair getMinMax ( int arr [ ] , int n ) { Pair minmax = new Pair ( ) ; int i ;
if ( n == 1 ) { minmax . max = arr [ 0 ] ; minmax . min = arr [ 0 ] ; return minmax ; }
if ( arr [ 0 ] > arr [ 1 ] ) { minmax . max = arr [ 0 ] ; minmax . min = arr [ 1 ] ; } else { minmax . max = arr [ 1 ] ; minmax . min = arr [ 0 ] ; } for ( i = 2 ; i < n ; i ++ ) { if ( arr [ i ] > minmax . max ) { minmax . max = arr [ i ] ; } else if ( arr [ i ] < minmax . min ) { minmax . min = arr [ i ] ; } } return minmax ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1000 , 11 , 445 , 1 , 330 , 3000 } ; int arr_size = 6 ; Pair minmax = getMinMax ( arr , arr_size ) ; System . out . printf ( " Minimum element is % d ", minmax.min); System . out . printf ( " Maximum element is % d ", minmax.max); } }
public class GFG {
static class Pair { int min ; int max ; } static Pair getMinMax ( int arr [ ] , int n ) { Pair minmax = new Pair ( ) ; int i ;
if ( n % 2 == 0 ) { if ( arr [ 0 ] > arr [ 1 ] ) { minmax . max = arr [ 0 ] ; minmax . min = arr [ 1 ] ; } else { minmax . min = arr [ 0 ] ; minmax . max = arr [ 1 ] ; }
i = 2 ; }
else { minmax . min = arr [ 0 ] ; minmax . max = arr [ 0 ] ;
i = 1 ; }
while ( i < n - 1 ) { if ( arr [ i ] > arr [ i + 1 ] ) { if ( arr [ i ] > minmax . max ) { minmax . max = arr [ i ] ; } if ( arr [ i + 1 ] < minmax . min ) { minmax . min = arr [ i + 1 ] ; } } else { if ( arr [ i + 1 ] > minmax . max ) { minmax . max = arr [ i + 1 ] ; } if ( arr [ i ] < minmax . min ) { minmax . min = arr [ i ] ; } }
i += 2 ; } return minmax ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1000 , 11 , 445 , 1 , 330 , 3000 } ; int arr_size = 6 ; Pair minmax = getMinMax ( arr , arr_size ) ; System . out . printf ( " Minimum element is % d ", minmax.min); System . out . printf ( " Maximum element is % d ", minmax.max); } }
class SmallestSubArraySum {
static int smallestSubWithSum ( int arr [ ] , int n , int x ) {
int min_len = n + 1 ;
for ( int start = 0 ; start < n ; start ++ ) {
int curr_sum = arr [ start ] ;
if ( curr_sum > x ) return 1 ;
for ( int end = start + 1 ; end < n ; end ++ ) {
curr_sum += arr [ end ] ;
if ( curr_sum > x && ( end - start + 1 ) < min_len ) min_len = ( end - start + 1 ) ; } } return min_len ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = arr1 . length ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; if ( res1 == n1 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res1 ) ; int arr2 [ ] = { 1 , 10 , 5 , 2 , 7 } ; int n2 = arr2 . length ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; if ( res2 == n2 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res2 ) ; int arr3 [ ] = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = arr3 . length ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; if ( res3 == n3 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res3 ) ; } }
class Node { int data ; Node left ; Node right ; public Node ( int data ) { this . data = data ; left = null ; right = null ; } }
public void print ( Node root ) { if ( root == null ) return ; print ( root . left ) ; System . out . print ( root . data + " ▁ " ) ; print ( root . right ) ; } }
class BinaryTree { Node root ; public Node prune ( Node root , int sum ) {
if ( root == null ) return null ;
root . left = prune ( root . left , sum - root . data ) ; root . right = prune ( root . right , sum - root . data ) ;
if ( isLeaf ( root ) ) { if ( sum > root . data ) root = null ; } return root ; }
public class GFG { public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 6 ) ; tree . root . right . right = new Node ( 7 ) ; tree . root . left . left . left = new Node ( 8 ) ; tree . root . left . left . right = new Node ( 9 ) ; tree . root . left . right . left = new Node ( 12 ) ; tree . root . right . right . left = new Node ( 10 ) ; tree . root . right . right . left . right = new Node ( 11 ) ; tree . root . left . left . right . left = new Node ( 13 ) ; tree . root . left . left . right . right = new Node ( 14 ) ; tree . root . left . left . right . right . left = new Node ( 15 ) ; System . out . println ( " Tree ▁ before ▁ truncation " ) ; tree . print ( tree . root ) ; tree . prune ( tree . root , 45 ) ; System . out . println ( " Tree after truncation "); tree . print ( tree . root ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } }
boolean printPath ( Node node , Node target_leaf ) {
if ( node == null ) return false ;
if ( node == target_leaf || printPath ( node . left , target_leaf ) || printPath ( node . right , target_leaf ) ) { System . out . print ( node . data + " ▁ " ) ; return true ; } return false ; }
void getTargetLeaf ( Node node , Maximum max_sum_ref , int curr_sum ) { if ( node == null ) return ;
curr_sum = curr_sum + node . data ;
if ( node . left == null && node . right == null ) { if ( curr_sum > max_sum_ref . max_no ) { max_sum_ref . max_no = curr_sum ; target_leaf = node ; } }
getTargetLeaf ( node . left , max_sum_ref , curr_sum ) ; getTargetLeaf ( node . right , max_sum_ref , curr_sum ) ; }
int maxSumPath ( ) {
if ( root == null ) return 0 ;
getTargetLeaf ( root , max , 0 ) ;
printPath ( root , target_leaf ) ;
return max . max_no ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( - 2 ) ; tree . root . right = new Node ( 7 ) ; tree . root . left . left = new Node ( 8 ) ; tree . root . left . right = new Node ( - 4 ) ; System . out . println ( " Following ▁ are ▁ the ▁ nodes ▁ " + " on ▁ maximum ▁ sum ▁ path " ) ; int sum = tree . maxSumPath ( ) ; System . out . println ( " " ) ; System . out . println ( " Sum ▁ of ▁ nodes ▁ is ▁ : ▁ " + sum ) ; } }
class FindUnion {
static int printUnion ( int arr1 [ ] , int arr2 [ ] , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) System . out . print ( arr1 [ i ++ ] + " ▁ " ) ; else if ( arr2 [ j ] < arr1 [ i ] ) System . out . print ( arr2 [ j ++ ] + " ▁ " ) ; else { System . out . print ( arr2 [ j ++ ] + " ▁ " ) ; i ++ ; } }
while ( i < m ) System . out . print ( arr1 [ i ++ ] + " ▁ " ) ; while ( j < n ) System . out . print ( arr2 [ j ++ ] + " ▁ " ) ; return 0 ; }
public static void main ( String args [ ] ) { int arr1 [ ] = { 1 , 2 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 5 , 7 } ; int m = arr1 . length ; int n = arr2 . length ; printUnion ( arr1 , arr2 , m , n ) ; } }
class FindIntersection {
static void printIntersection ( int arr1 [ ] , int arr2 [ ] , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) i ++ ; else if ( arr2 [ j ] < arr1 [ i ] ) j ++ ; else { System . out . print ( arr2 [ j ++ ] + " ▁ " ) ; i ++ ; } } }
public static void main ( String args [ ] ) { int arr1 [ ] = { 1 , 2 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 5 , 7 } ; int m = arr1 . length ; int n = arr2 . length ;
printIntersection ( arr1 , arr2 , m , n ) ; } }
class Main {
static int insertSorted ( int arr [ ] , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; arr [ n ] = key ; return ( n + 1 ) ; }
public static void main ( String [ ] args ) { int [ ] arr = new int [ 20 ] ; arr [ 0 ] = 12 ; arr [ 1 ] = 16 ; arr [ 2 ] = 20 ; arr [ 3 ] = 40 ; arr [ 4 ] = 50 ; arr [ 5 ] = 70 ; int capacity = 20 ; int n = 6 ; int i , key = 26 ; System . out . print ( " Before ▁ Insertion : ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ;
n = insertSorted ( arr , n , key , capacity ) ; System . out . print ( " After Insertion : "); for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
class Main {
static int findElement ( int arr [ ] , int n , int key ) { int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
static int deleteElement ( int arr [ ] , int n , int key ) {
int pos = findElement ( arr , n , key ) ; if ( pos == - 1 ) { System . out . println ( " Element ▁ not ▁ found " ) ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
public static void main ( String args [ ] ) { int i ; int arr [ ] = { 10 , 50 , 30 , 40 , 20 } ; int n = arr . length ; int key = 30 ; System . out . println ( " Array ▁ before ▁ deletion " ) ; for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; n = deleteElement ( arr , n , key ) ; System . out . println ( " Array after deletion "); for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
class Main {
static int insertSorted ( int arr [ ] , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; int i ; for ( i = n - 1 ; ( i >= 0 && arr [ i ] > key ) ; i -- ) arr [ i + 1 ] = arr [ i ] ; arr [ i + 1 ] = key ; return ( n + 1 ) ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ 20 ] ; arr [ 0 ] = 12 ; arr [ 1 ] = 16 ; arr [ 2 ] = 20 ; arr [ 3 ] = 40 ; arr [ 4 ] = 50 ; arr [ 5 ] = 70 ; int capacity = arr . length ; int n = 6 ; int key = 26 ; System . out . print ( " Before Insertion : "); for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ;
n = insertSorted ( arr , n , key , capacity ) ; System . out . print ( " After Insertion : "); for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
class Main {
static int binarySearch ( int arr [ ] , int low , int high , int key ) { if ( high < low ) return - 1 ; int mid = ( low + high ) / 2 ; if ( key == arr [ mid ] ) return mid ; if ( key > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , key ) ; return binarySearch ( arr , low , ( mid - 1 ) , key ) ; }
static int deleteElement ( int arr [ ] , int n , int key ) {
int pos = binarySearch ( arr , 0 , n - 1 , key ) ; if ( pos == - 1 ) { System . out . println ( " Element ▁ not ▁ found " ) ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
public static void main ( String [ ] args ) { int i ; int arr [ ] = { 10 , 20 , 30 , 40 , 50 } ; int n = arr . length ; int key = 30 ; System . out . print ( "Array before deletion:NEW_LINE"); for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; n = deleteElement ( arr , n , key ) ; System . out . print ( " Array after deletion : "); for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
import java . io . * ; class Majority {
static int _binarySearch ( int arr [ ] , int low , int high , int x ) { if ( high >= low ) { int mid = ( low + high ) / 2 ;
if ( ( mid == 0 x > arr [ mid - 1 ] ) && ( arr [ mid ] == x ) ) return mid ; else if ( x > arr [ mid ] ) return _binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return _binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
static boolean isMajority ( int arr [ ] , int n , int x ) {
int i = _binarySearch ( arr , 0 , n - 1 , x ) ;
if ( i == - 1 ) return false ;
if ( ( ( i + n / 2 ) <= ( n - 1 ) ) && arr [ i + n / 2 ] == x ) return true ; else return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = arr . length ; int x = 3 ; if ( isMajority ( arr , n , x ) == true ) System . out . println ( x + " ▁ appears ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; else System . out . println ( x + " ▁ does ▁ not ▁ appear ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; } }
import java . util . * ; class GFG { static boolean isMajorityElement ( int arr [ ] , int n , int key ) { if ( arr [ n / 2 ] == key ) return true ; else return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = arr . length ; int x = 3 ; if ( isMajorityElement ( arr , n , x ) ) System . out . printf ( " % d ▁ appears ▁ more ▁ than ▁ % d ▁ " + " times ▁ in ▁ arr [ ] " , x , n / 2 ) ; else System . out . printf ( " % d ▁ does ▁ not ▁ appear ▁ more ▁ " + " than ▁ % d ▁ times ▁ in ▁ " + " arr [ ] " , x , n / 2 ) ; } }
import java . io . * ; class GFG { private static int isPairSum ( int A [ ] , int N , int X ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
if ( i == j ) continue ;
if ( A [ i ] + A [ j ] == X ) return true ;
if ( A [ i ] + A [ j ] > X ) break ; } }
return 0 ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 5 , 9 , 2 , 8 , 10 , 11 } ; int val = 17 ;
System . out . println ( isPairSum ( arr , arr . length , val ) ) ; }
import java . io . * ; class GFG {
public static int isPairSum ( int A [ ] , int N , int X ) {
int i = 0 ;
int j = N - 1 ; while ( i < j ) {
if ( A [ i ] + A [ j ] == X ) return 1 ;
else if ( A [ i ] + A [ j ] < X ) i ++ ;
else j -- ; } return 0 ; }
public static void main ( String [ ] args ) {
int arr [ ] = { 3 , 5 , 9 , 2 , 8 , 10 , 11 } ;
int val = 17 ;
int arrSize = arr . length ;
System . out . println ( isPairSum ( arr , arrSize , val ) ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right ; } } class BinaryTree {
Node root ; int getLevelDiff ( Node node ) {
if ( node == null ) return 0 ;
return node . data - getLevelDiff ( node . left ) - getLevelDiff ( node . right ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 5 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 6 ) ; tree . root . left . left = new Node ( 1 ) ; tree . root . left . right = new Node ( 4 ) ; tree . root . left . right . left = new Node ( 3 ) ; tree . root . right . right = new Node ( 8 ) ; tree . root . right . right . right = new Node ( 9 ) ; tree . root . right . right . left = new Node ( 7 ) ; System . out . println ( tree . getLevelDiff ( tree . root ) + " ▁ is ▁ the ▁ required ▁ difference " ) ; } }
public class GFG {
static int search ( int arr [ ] , int n , int x ) { int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == x ) { return i ; } } return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 10 , 30 , 15 } ; int x = 30 ; int n = arr . length ; System . out . printf ( " % d ▁ is ▁ present ▁ at ▁ index ▁ % d " , x , search ( arr , n , x ) ) ; } }
class BinarySearch {
int binarySearch ( int arr [ ] , int x ) { int l = 0 , r = arr . length - 1 ; while ( l <= r ) { int m = l + ( r - l ) / 2 ;
if ( arr [ m ] == x ) return m ;
if ( arr [ m ] < x ) l = m + 1 ;
else r = m - 1 ; }
return - 1 ; }
public static void main ( String args [ ] ) { BinarySearch ob = new BinarySearch ( ) ; int arr [ ] = { 2 , 3 , 4 , 10 , 40 } ; int n = arr . length ; int x = 10 ; int result = ob . binarySearch ( arr , x ) ; if ( result == - 1 ) System . out . println ( " Element ▁ not ▁ present " ) ; else System . out . println ( " Element ▁ found ▁ at ▁ " + " index ▁ " + result ) ; } }
import java . util . * ; class GFG {
public static int interpolationSearch ( int arr [ ] , int lo , int hi , int x ) { int pos ;
if ( lo <= hi && x >= arr [ lo ] && x <= arr [ hi ] ) {
pos = lo + ( ( ( hi - lo ) / ( arr [ hi ] - arr [ lo ] ) ) * ( x - arr [ lo ] ) ) ;
if ( arr [ pos ] == x ) return pos ;
if ( arr [ pos ] < x ) return interpolationSearch ( arr , pos + 1 , hi , x ) ;
if ( arr [ pos ] > x ) return interpolationSearch ( arr , lo , pos - 1 , x ) ; } return - 1 ; }
public static void main ( String [ ] args ) {
int arr [ ] = { 10 , 12 , 13 , 16 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 33 , 35 , 42 , 47 } ; int n = arr . length ;
int x = 18 ; int index = interpolationSearch ( arr , 0 , n - 1 , x ) ;
if ( index != - 1 ) System . out . println ( " Element ▁ found ▁ at ▁ index ▁ " + index ) ; else System . out . println ( " Element ▁ not ▁ found . " ) ; } }
class SelectionSort {
void sort ( int arr [ ] ) { int n = arr . length ;
for ( int i = 0 ; i < n - 1 ; i ++ ) {
int min_idx = i ; for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ j ] < arr [ min_idx ] ) min_idx = j ;
int temp = arr [ min_idx ] ; arr [ min_idx ] = arr [ i ] ; arr [ i ] = temp ; } }
void printArray ( int arr [ ] ) { int n = arr . length ; for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String args [ ] ) { SelectionSort ob = new SelectionSort ( ) ; int arr [ ] = { 64 , 25 , 12 , 22 , 11 } ; ob . sort ( arr ) ; System . out . println ( " Sorted ▁ array " ) ; ob . printArray ( arr ) ; } }
class MergeSort {
void merge ( int arr [ ] , int l , int m , int r ) {
int n1 = m - l + 1 ; int n2 = r - m ;
int L [ ] = new int [ n1 ] ; int R [ ] = new int [ n2 ] ;
for ( int i = 0 ; i < n1 ; ++ i ) L [ i ] = arr [ l + i ] ; for ( int j = 0 ; j < n2 ; ++ j ) R [ j ] = arr [ m + 1 + j ] ;
int i = 0 , j = 0 ;
int k = l ; while ( i < n1 && j < n2 ) { if ( L [ i ] <= R [ j ] ) { arr [ k ] = L [ i ] ; i ++ ; } else { arr [ k ] = R [ j ] ; j ++ ; } k ++ ; }
while ( i < n1 ) { arr [ k ] = L [ i ] ; i ++ ; k ++ ; }
while ( j < n2 ) { arr [ k ] = R [ j ] ; j ++ ; k ++ ; } }
void sort ( int arr [ ] , int l , int r ) { if ( l < r ) {
int m = l + ( r - l ) / 2 ;
sort ( arr , l , m ) ; sort ( arr , m + 1 , r ) ;
merge ( arr , l , m , r ) ; } }
static void printArray ( int arr [ ] ) { int n = arr . length ; for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 12 , 11 , 13 , 5 , 6 , 7 } ; System . out . println ( " Given ▁ Array " ) ; printArray ( arr ) ; MergeSort ob = new MergeSort ( ) ; ob . sort ( arr , 0 , arr . length - 1 ) ; System . out . println ( " Sorted array "); printArray ( arr ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
boolean hasPathSum ( Node node , int sum ) { if ( node == null ) return sum == 0 ; return hasPathSum ( node . left , sum - node . data ) || hasPathSum ( node . right , sum - node . data ) ; }
public static void main ( String args [ ] ) { int sum = 21 ;
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 2 ) ; tree . root . left . left = new Node ( 3 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 2 ) ; if ( tree . haspathSum ( tree . root , sum ) ) System . out . println ( " There ▁ is ▁ a ▁ root ▁ to ▁ leaf ▁ path ▁ with ▁ sum ▁ " + sum ) ; else System . out . println ( " There ▁ is ▁ no ▁ root ▁ to ▁ leaf ▁ path ▁ with ▁ sum ▁ " + sum ) ; } }
import java . util . * ; class QuickSort {
static int partition ( int arr [ ] , int low , int high ) { int pivot = arr [ high ] ; int i = ( low - 1 ) ; for ( int j = low ; j <= high - 1 ; j ++ ) { if ( arr [ j ] <= pivot ) { i ++ ; int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } } int temp = arr [ i + 1 ] ; arr [ i + 1 ] = arr [ high ] ; arr [ high ] = temp ; return i + 1 ; }
static void quickSortIterative ( int arr [ ] , int l , int h ) {
int [ ] stack = new int [ h - l + 1 ] ;
int top = - 1 ;
stack [ ++ top ] = l ; stack [ ++ top ] = h ;
while ( top >= 0 ) {
h = stack [ top -- ] ; l = stack [ top -- ] ;
int p = partition ( arr , l , h ) ;
if ( p - 1 > l ) { stack [ ++ top ] = l ; stack [ ++ top ] = p - 1 ; }
if ( p + 1 < h ) { stack [ ++ top ] = p + 1 ; stack [ ++ top ] = h ; } } }
public static void main ( String args [ ] ) { int arr [ ] = { 4 , 3 , 5 , 2 , 1 , 3 , 2 , 3 } ; int n = 8 ;
quickSortIterative ( arr , 0 , n - 1 ) ; for ( int i = 0 ; i < n ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
int treePathsSumUtil ( Node node , int val ) {
if ( node == null ) return 0 ;
val = ( val * 10 + node . data ) ;
if ( node . left == null && node . right == null ) return val ;
return treePathsSumUtil ( node . left , val ) + treePathsSumUtil ( node . right , val ) ; }
int treePathsSum ( Node node ) {
return treePathsSumUtil ( node , 0 ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 6 ) ; tree . root . left = new Node ( 3 ) ; tree . root . right = new Node ( 5 ) ; tree . root . right . right = new Node ( 4 ) ; tree . root . left . left = new Node ( 2 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . left . right . right = new Node ( 4 ) ; tree . root . left . right . left = new Node ( 7 ) ; System . out . print ( " Sum ▁ of ▁ all ▁ paths ▁ is ▁ " + tree . treePathsSum ( tree . root ) ) ; } }
public class LongestCommonSubsequence {
int lcs ( char [ ] X , char [ ] Y , int m , int n ) { if ( m == 0 n == 0 ) return 0 ; if ( X [ m - 1 ] == Y [ n - 1 ] ) return 1 + lcs ( X , Y , m - 1 , n - 1 ) ; else return max ( lcs ( X , Y , m , n - 1 ) , lcs ( X , Y , m - 1 , n ) ) ; }
int max ( int a , int b ) { return ( a > b ) ? a : b ; }
public static void main ( String [ ] args ) { LongestCommonSubsequence lcs = new LongestCommonSubsequence ( ) ; String s1 = " AGGTAB " ; String s2 = " GXTXAYB " ; char [ ] X = s1 . toCharArray ( ) ; char [ ] Y = s2 . toCharArray ( ) ; int m = X . length ; int n = Y . length ; System . out . println ( " Length ▁ of ▁ LCS ▁ is " + " ▁ " + lcs . lcs ( X , Y , m , n ) ) ; } }
public class LongestCommonSubsequence {
int lcs ( char [ ] X , char [ ] Y , int m , int n ) { int L [ ] [ ] = new int [ m + 1 ] [ n + 1 ] ;
for ( int i = 0 ; i <= m ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) { if ( i == 0 j == 0 ) L [ i ] [ j ] = 0 ; else if ( X [ i - 1 ] == Y [ j - 1 ] ) L [ i ] [ j ] = L [ i - 1 ] [ j - 1 ] + 1 ; else L [ i ] [ j ] = max ( L [ i - 1 ] [ j ] , L [ i ] [ j - 1 ] ) ; } }
return L [ m ] [ n ] ; }
int max ( int a , int b ) { return ( a > b ) ? a : b ; }
public static void main ( String [ ] args ) { LongestCommonSubsequence lcs = new LongestCommonSubsequence ( ) ; String s1 = " AGGTAB " ; String s2 = " GXTXAYB " ; char [ ] X = s1 . toCharArray ( ) ; char [ ] Y = s2 . toCharArray ( ) ; int m = X . length ; int n = Y . length ; System . out . println ( " Length ▁ of ▁ LCS ▁ is " + " ▁ " + lcs . lcs ( X , Y , m , n ) ) ; } }
public class GFG {
static int eggDrop ( int n , int k ) {
if ( k == 1 k == 0 ) return k ;
if ( n == 1 ) return k ; int min = Integer . MAX_VALUE ; int x , res ;
for ( x = 1 ; x <= k ; x ++ ) { res = Math . max ( eggDrop ( n - 1 , x - 1 ) , eggDrop ( n , k - x ) ) ; if ( res < min ) min = res ; } return min + 1 ; }
public static void main ( String args [ ] ) { int n = 2 , k = 10 ; System . out . print ( " Minimum ▁ number ▁ of ▁ " + " trials ▁ in ▁ worst ▁ case ▁ with ▁ " + n + " ▁ eggs ▁ and ▁ " + k + " ▁ floors ▁ is ▁ " + eggDrop ( n , k ) ) ; } }
public class WordWrap { final int MAX = Integer . MAX_VALUE ;
int printSolution ( int p [ ] , int n ) { int k ; if ( p [ n ] == 1 ) k = 1 ; else k = printSolution ( p , p [ n ] - 1 ) + 1 ; System . out . println ( " Line ▁ number " + " ▁ " + k + " : ▁ " + " From ▁ word ▁ no . " + " ▁ " + p [ n ] + " ▁ " + " to " + " ▁ " + n ) ; return k ; }
void solveWordWrap ( int l [ ] , int n , int M ) {
int extras [ ] [ ] = new int [ n + 1 ] [ n + 1 ] ;
int lc [ ] [ ] = new int [ n + 1 ] [ n + 1 ] ;
int c [ ] = new int [ n + 1 ] ;
int p [ ] = new int [ n + 1 ] ;
for ( int i = 1 ; i <= n ; i ++ ) { extras [ i ] [ i ] = M - l [ i - 1 ] ; for ( int j = i + 1 ; j <= n ; j ++ ) extras [ i ] [ j ] = extras [ i ] [ j - 1 ] - l [ j - 1 ] - 1 ; }
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = i ; j <= n ; j ++ ) { if ( extras [ i ] [ j ] < 0 ) lc [ i ] [ j ] = MAX ; else if ( j == n && extras [ i ] [ j ] >= 0 ) lc [ i ] [ j ] = 0 ; else lc [ i ] [ j ] = extras [ i ] [ j ] * extras [ i ] [ j ] ; } }
c [ 0 ] = 0 ; for ( int j = 1 ; j <= n ; j ++ ) { c [ j ] = MAX ; for ( int i = 1 ; i <= j ; i ++ ) { if ( c [ i - 1 ] != MAX && lc [ i ] [ j ] != MAX && ( c [ i - 1 ] + lc [ i ] [ j ] < c [ j ] ) ) { c [ j ] = c [ i - 1 ] + lc [ i ] [ j ] ; p [ j ] = i ; } } } printSolution ( p , n ) ; }
public static void main ( String args [ ] ) { WordWrap w = new WordWrap ( ) ; int l [ ] = { 3 , 2 , 2 , 5 } ; int n = l . length ; int M = 6 ; w . solveWordWrap ( l , n , M ) ; } }
public class GFG {
static int sum ( int freq [ ] , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
static int optCost ( int freq [ ] , int i , int j ) {
if ( j < i ) return 0 ;
if ( j == i ) return freq [ i ] ;
int fsum = sum ( freq , i , j ) ;
int min = Integer . MAX_VALUE ;
for ( int r = i ; r <= j ; ++ r ) { int cost = optCost ( freq , i , r - 1 ) + optCost ( freq , r + 1 , j ) ; if ( cost < min ) min = cost ; }
return min + fsum ; }
static int optimalSearchTree ( int keys [ ] , int freq [ ] , int n ) {
return optCost ( freq , 0 , n - 1 ) ; }
public static void main ( String [ ] args ) { int keys [ ] = { 10 , 12 , 20 } ; int freq [ ] = { 34 , 8 , 50 } ; int n = keys . length ; System . out . println ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ " + optimalSearchTree ( keys , freq , n ) ) ; } }
public class Optimal_BST2 {
static int sum ( int freq [ ] , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) { if ( k >= freq . length ) continue ; s += freq [ k ] ; } return s ; }
static int optimalSearchTree ( int keys [ ] , int freq [ ] , int n ) {
int cost [ ] [ ] = new int [ n + 1 ] [ n + 1 ] ;
for ( int i = 0 ; i < n ; i ++ ) cost [ i ] [ i ] = freq [ i ] ;
for ( int L = 2 ; L <= n ; L ++ ) {
for ( int i = 0 ; i <= n - L + 1 ; i ++ ) {
int j = i + L - 1 ; cost [ i ] [ j ] = Integer . MAX_VALUE ;
for ( int r = i ; r <= j ; r ++ ) {
int c = ( ( r > i ) ? cost [ i ] [ r - 1 ] : 0 ) + ( ( r < j ) ? cost [ r + 1 ] [ j ] : 0 ) + sum ( freq , i , j ) ; if ( c < cost [ i ] [ j ] ) cost [ i ] [ j ] = c ; } } } return cost [ 0 ] [ n - 1 ] ; }
public static void main ( String [ ] args ) { int keys [ ] = { 10 , 12 , 20 } ; int freq [ ] = { 34 , 8 , 50 } ; int n = keys . length ; System . out . println ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ " + optimalSearchTree ( keys , freq , n ) ) ; } }
class GFG {
static int max ( int x , int y ) { return ( x > y ) ? x : y ; }
static class Node { int data ; Node left , right ; } ;
static int LISS ( Node root ) { if ( root == null ) return 0 ;
int size_excl = LISS ( root . left ) + LISS ( root . right ) ;
int size_incl = 1 ; if ( root . left != null ) size_incl += LISS ( root . left . left ) + LISS ( root . left . right ) ; if ( root . right != null ) size_incl += LISS ( root . right . left ) + LISS ( root . right . right ) ;
return max ( size_incl , size_excl ) ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . left = temp . right = null ; return temp ; }
public static void main ( String args [ ] ) {
Node root = newNode ( 20 ) ; root . left = newNode ( 8 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 12 ) ; root . left . right . left = newNode ( 10 ) ; root . left . right . right = newNode ( 14 ) ; root . right = newNode ( 22 ) ; root . right . right = newNode ( 25 ) ; System . out . println ( " Size ▁ of ▁ the ▁ Largest " + " ▁ Independent ▁ Set ▁ is ▁ " + LISS ( root ) ) ; } }
class GFG {
static int getCount ( char keypad [ ] [ ] , int n ) { if ( keypad == null n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
int [ ] odd = new int [ 10 ] ; int [ ] even = new int [ 10 ] ; int i = 0 , j = 0 , useOdd = 0 , totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ )
odd [ i ] = 1 ;
for ( j = 2 ; j <= n ; j ++ ) { useOdd = 1 - useOdd ;
if ( useOdd == 1 ) { even [ 0 ] = odd [ 0 ] + odd [ 8 ] ; even [ 1 ] = odd [ 1 ] + odd [ 2 ] + odd [ 4 ] ; even [ 2 ] = odd [ 2 ] + odd [ 1 ] + odd [ 3 ] + odd [ 5 ] ; even [ 3 ] = odd [ 3 ] + odd [ 2 ] + odd [ 6 ] ; even [ 4 ] = odd [ 4 ] + odd [ 1 ] + odd [ 5 ] + odd [ 7 ] ; even [ 5 ] = odd [ 5 ] + odd [ 2 ] + odd [ 4 ] + odd [ 8 ] + odd [ 6 ] ; even [ 6 ] = odd [ 6 ] + odd [ 3 ] + odd [ 5 ] + odd [ 9 ] ; even [ 7 ] = odd [ 7 ] + odd [ 4 ] + odd [ 8 ] ; even [ 8 ] = odd [ 8 ] + odd [ 0 ] + odd [ 5 ] + odd [ 7 ] + odd [ 9 ] ; even [ 9 ] = odd [ 9 ] + odd [ 6 ] + odd [ 8 ] ; } else { odd [ 0 ] = even [ 0 ] + even [ 8 ] ; odd [ 1 ] = even [ 1 ] + even [ 2 ] + even [ 4 ] ; odd [ 2 ] = even [ 2 ] + even [ 1 ] + even [ 3 ] + even [ 5 ] ; odd [ 3 ] = even [ 3 ] + even [ 2 ] + even [ 6 ] ; odd [ 4 ] = even [ 4 ] + even [ 1 ] + even [ 5 ] + even [ 7 ] ; odd [ 5 ] = even [ 5 ] + even [ 2 ] + even [ 4 ] + even [ 8 ] + even [ 6 ] ; odd [ 6 ] = even [ 6 ] + even [ 3 ] + even [ 5 ] + even [ 9 ] ; odd [ 7 ] = even [ 7 ] + even [ 4 ] + even [ 8 ] ; odd [ 8 ] = even [ 8 ] + even [ 0 ] + even [ 5 ] + even [ 7 ] + even [ 9 ] ; odd [ 9 ] = even [ 9 ] + even [ 6 ] + even [ 8 ] ; } }
totalCount = 0 ; if ( useOdd == 1 ) { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += even [ i ] ; } else { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += odd [ i ] ; } return totalCount ; }
public static void main ( String [ ] args ) { char keypad [ ] [ ] = { { '1' , '2' , '3' } , { '4' , '5' , '6' } , { '7' , '8' , '9' } , { ' * ' , '0' , ' # ' } } ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 1, getCount ( keypad , 1 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 2, getCount ( keypad , 2 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 3, getCount ( keypad , 3 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 4, getCount ( keypad , 4 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 5, getCount ( keypad , 5 ) ) ; } }
import java . util . HashMap ; import java . util . Map ;
class Node { int key ; Node left , right , parent ; Node ( int key ) { this . key = key ; left = right = parent = null ; } } class BinaryTree { Node root , n1 , n2 , lca ;
Node insert ( Node node , int key ) {
if ( node == null ) return new Node ( key ) ;
if ( key < node . key ) { node . left = insert ( node . left , key ) ; node . left . parent = node ; } else if ( key > node . key ) { node . right = insert ( node . right , key ) ; node . right . parent = node ; }
return node ; }
Node LCA ( Node n1 , Node n2 ) {
Map < Node , Boolean > ancestors = new HashMap < Node , Boolean > ( ) ;
while ( n1 != null ) { ancestors . put ( n1 , Boolean . TRUE ) ; n1 = n1 . parent ; }
while ( n2 != null ) { if ( ancestors . containsKey ( n2 ) != ancestors . isEmpty ( ) ) return n2 ; n2 = n2 . parent ; } return null ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = tree . insert ( tree . root , 20 ) ; tree . root = tree . insert ( tree . root , 8 ) ; tree . root = tree . insert ( tree . root , 22 ) ; tree . root = tree . insert ( tree . root , 4 ) ; tree . root = tree . insert ( tree . root , 12 ) ; tree . root = tree . insert ( tree . root , 10 ) ; tree . root = tree . insert ( tree . root , 14 ) ; tree . n1 = tree . root . left . right . left ; tree . n2 = tree . root . left ; tree . lca = tree . LCA ( tree . n1 , tree . n2 ) ; System . out . println ( " LCA ▁ of ▁ " + tree . n1 . key + " ▁ and ▁ " + tree . n2 . key + " ▁ is ▁ " + tree . lca . key ) ; } }
import java . io . * ; class GFG {
static int findoptimal ( int N ) {
if ( N <= 6 ) return N ;
int screen [ ] = new int [ N ] ;
int b ;
int n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = 0 ;
for ( b = n - 3 ; b >= 1 ; b -- ) {
int curr = ( n - b - 1 ) * screen [ b - 1 ] ; if ( curr > screen [ n - 1 ] ) screen [ n - 1 ] = curr ; } } return screen [ N - 1 ] ; }
public static void main ( String [ ] args ) { int N ;
for ( N = 1 ; N <= 20 ; N ++ ) System . out . println ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with ▁ keystrokes ▁ is ▁ " + N + findoptimal ( N ) ) ; } }
class GFG {
static int min ( int x , int y ) { return ( x < y ) ? x : y ; }
static class node { int data ; int vc ; node left , right ; } ;
static int vCover ( node root ) {
if ( root == null ) return 0 ; if ( root . left == null && root . right == null ) return 0 ;
if ( root . vc != 0 ) return root . vc ;
int size_incl = 1 + vCover ( root . left ) + vCover ( root . right ) ;
int size_excl = 0 ; if ( root . left != null ) size_excl += 1 + vCover ( root . left . left ) + vCover ( root . left . right ) ; if ( root . right != null ) size_excl += 1 + vCover ( root . right . left ) + vCover ( root . right . right ) ;
root . vc = Math . min ( size_incl , size_excl ) ; return root . vc ; }
static node newNode ( int data ) { node temp = new node ( ) ; temp . data = data ; temp . left = temp . right = null ;
temp . vc = 0 ; return temp ; }
public static void main ( String [ ] args ) {
node root = newNode ( 20 ) ; root . left = newNode ( 8 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 12 ) ; root . left . right . left = newNode ( 10 ) ; root . left . right . right = newNode ( 14 ) ; root . right = newNode ( 22 ) ; root . right . right = newNode ( 25 ) ; System . out . printf ( " Size ▁ of ▁ the ▁ smallest ▁ vertex " + " cover ▁ is ▁ % d ▁ " , vCover ( root ) ) ; } }
class GFG { static int NO_OF_CHARS = 256 ; static int getNextState ( char [ ] pat , int M , int state , int x ) {
if ( state < M && x == pat [ state ] ) return state + 1 ;
int ns , i ;
for ( ns = state ; ns > 0 ; ns -- ) { if ( pat [ ns - 1 ] == x ) { for ( i = 0 ; i < ns - 1 ; i ++ ) if ( pat [ i ] != pat [ state - ns + 1 + i ] ) break ; if ( i == ns - 1 ) return ns ; } } return 0 ; }
static void computeTF ( char [ ] pat , int M , int TF [ ] [ ] ) { int state , x ; for ( state = 0 ; state <= M ; ++ state ) for ( x = 0 ; x < NO_OF_CHARS ; ++ x ) TF [ state ] [ x ] = getNextState ( pat , M , state , x ) ; }
static void search ( char [ ] pat , char [ ] txt ) { int M = pat . length ; int N = txt . length ; int [ ] [ ] TF = new int [ M + 1 ] [ NO_OF_CHARS ] ; computeTF ( pat , M , TF ) ;
int i , state = 0 ; for ( i = 0 ; i < N ; i ++ ) { state = TF [ state ] [ txt [ i ] ] ; if ( state == M ) System . out . println ( " Pattern ▁ found ▁ " + " at ▁ index ▁ " + ( i - M + 1 ) ) ; } }
public static void main ( String [ ] args ) { char [ ] pat = " AABAACAADAABAAABAA " . toCharArray ( ) ; char [ ] txt = " AABA " . toCharArray ( ) ; search ( txt , pat ) ; } }
class AWQ { static int NO_OF_CHARS = 256 ;
static int max ( int a , int b ) { return ( a > b ) ? a : b ; }
static void badCharHeuristic ( char [ ] str , int size , int badchar [ ] ) {
for ( int i = 0 ; i < NO_OF_CHARS ; i ++ ) badchar [ i ] = - 1 ;
for ( i = 0 ; i < size ; i ++ ) badchar [ ( int ) str [ i ] ] = i ; }
static void search ( char txt [ ] , char pat [ ] ) { int m = pat . length ; int n = txt . length ; int badchar [ ] = new int [ NO_OF_CHARS ] ;
badCharHeuristic ( pat , m , badchar ) ;
int s = 0 ;
while ( s <= ( n - m ) ) { int j = m - 1 ;
while ( j >= 0 && pat [ j ] == txt [ s + j ] ) j -- ;
if ( j < 0 ) { System . out . println ( " Patterns ▁ occur ▁ at ▁ shift ▁ = ▁ " + s ) ;
s += ( s + m < n ) ? m - badchar [ txt [ s + m ] ] : 1 ; } else
s += max ( 1 , j - badchar [ txt [ s + j ] ] ) ; } }
public static void main ( String [ ] args ) { char txt [ ] = " ABAAABCD " . toCharArray ( ) ; char pat [ ] = " ABC " . toCharArray ( ) ; search ( txt , pat ) ; } }
public class Suduko {
static int N = 9 ;
static void print ( int [ ] [ ] grid ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) System . out . print ( grid [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
static boolean isSafe ( int [ ] [ ] grid , int row , int col , int num ) {
for ( int x = 0 ; x <= 8 ; x ++ ) if ( grid [ row ] [ x ] == num ) return false ;
for ( int x = 0 ; x <= 8 ; x ++ ) if ( grid [ x ] [ col ] == num ) return false ;
int startRow = row - row % 3 , startCol = col - col % 3 ; for ( int i = 0 ; i < 3 ; i ++ ) for ( int j = 0 ; j < 3 ; j ++ ) if ( grid [ i + startRow ] [ j + startCol ] == num ) return false ; return true ; }
static boolean solveSuduko ( int grid [ ] [ ] , int row , int col ) {
if ( row == N - 1 && col == N ) return true ;
if ( col == N ) { row ++ ; col = 0 ; }
if ( grid [ row ] [ col ] != 0 ) return solveSuduko ( grid , row , col + 1 ) ; for ( int num = 1 ; num < 10 ; num ++ ) {
if ( isSafe ( grid , row , col , num ) ) {
grid [ row ] [ col ] = num ;
if ( solveSuduko ( grid , row , col + 1 ) ) return true ; }
grid [ row ] [ col ] = 0 ; } return false ; }
public static void main ( String [ ] args ) { int grid [ ] [ ] = { { 3 , 0 , 6 , 5 , 0 , 8 , 4 , 0 , 0 } , { 5 , 2 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } , { 0 , 8 , 7 , 0 , 0 , 0 , 0 , 3 , 1 } , { 0 , 0 , 3 , 0 , 1 , 0 , 0 , 8 , 0 } , { 9 , 0 , 0 , 8 , 6 , 3 , 0 , 0 , 5 } , { 0 , 5 , 0 , 0 , 9 , 0 , 6 , 0 , 0 } , { 1 , 3 , 0 , 0 , 0 , 0 , 2 , 5 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 7 , 4 } , { 0 , 0 , 5 , 2 , 0 , 6 , 3 , 0 , 0 } } ; if ( solveSuduko ( grid , 0 , 0 ) ) print ( grid ) ; else System . out . println ( " No ▁ Solution ▁ exists " ) ; } }
static int power ( int x , int y ) { int temp ; if ( y == 0 ) return 1 ; temp = power ( x , y / 2 ) ; if ( y % 2 == 0 ) return temp * temp ; else return x * temp * temp ; }
import java . util . * ; class GfG {
static int getMedian ( int [ ] a , int [ ] b , int startA , int startB , int endA , int endB ) { if ( endA - startA == 1 ) { return ( Math . max ( a [ startA ] , b [ startB ] ) + Math . min ( a [ endA ] , b [ endB ] ) ) / 2 ; }
int m1 = median ( a , startA , endA ) ;
int m2 = median ( b , startB , endB ) ;
if ( m1 == m2 ) { return m1 ; }
else if ( m1 < m2 ) { return getMedian ( a , b , ( endA + startA + 1 ) / 2 , startB , endA , ( endB + startB + 1 ) / 2 ) ; }
else { return getMedian ( a , b , startA , ( endB + startB + 1 ) / 2 , ( endA + startA + 1 ) / 2 , endB ) ; } }
static int median ( int [ ] arr , int start , int end ) { int n = end - start + 1 ; if ( n % 2 == 0 ) { return ( arr [ start + ( n / 2 ) ] + arr [ start + ( n / 2 - 1 ) ] ) / 2 ; } else { return arr [ start + n / 2 ] ; } }
public static void main ( String [ ] args ) { int ar1 [ ] = { 1 , 2 , 3 , 6 } ; int ar2 [ ] = { 4 , 6 , 8 , 10 } ; int n1 = ar1 . length ; int n2 = ar2 . length ; if ( n1 != n2 ) { System . out . println ( " Doesn ' t ▁ work ▁ for ▁ arrays ▁ " + " of ▁ unequal ▁ size " ) ; } else if ( n1 == 0 ) { System . out . println ( " Arrays ▁ are ▁ empty . " ) ; } else if ( n1 == 1 ) { System . out . println ( ( ar1 [ 0 ] + ar2 [ 0 ] ) / 2 ) ; } else { System . out . println ( " Median ▁ is ▁ " + getMedian ( ar1 , ar2 , 0 , 0 , ar1 . length - 1 , ar2 . length - 1 ) ) ; } } }
class Node { int key ; Node left , right ; public Node ( int item ) { key = item ; left = right = null ; } }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; } }
class GFG { static int MAX_CHAR = 256 ;
int count [ ] = new int [ MAX_CHAR ] ;
static int fact ( int n ) { return ( n <= 1 ) ? 1 : n * fact ( n - 1 ) ; }
static void populateAndIncreaseCount ( int [ ] count , char [ ] str ) { int i ; for ( i = 0 ; i < str . length ; ++ i ) ++ count [ str [ i ] ] ; for ( i = 1 ; i < MAX_CHAR ; ++ i ) count [ i ] += count [ i - 1 ] ; }
static void updatecount ( int [ ] count , char ch ) { int i ; for ( i = ch ; i < MAX_CHAR ; ++ i ) -- count [ i ] ; }
static int findRank ( char [ ] str ) { int len = str . length ; int mul = fact ( len ) ; int rank = 1 , i ;
populateAndIncreaseCount ( count , str ) ; for ( i = 0 ; i < len ; ++ i ) { mul /= len - i ;
rank += count [ str [ i ] - 1 ] * mul ;
updatecount ( count , str [ i ] ) ; } return rank ; }
public static void main ( String args [ ] ) { char str [ ] = " string " . toCharArray ( ) ; System . out . println ( findRank ( str ) ) ; } }
class GFG {
static int findCeil ( int arr [ ] , int r , int l , int h ) { int mid ; while ( l < h ) {
mid = l + ( ( h - l ) >> 1 ) ; if ( r > arr [ mid ] ) l = mid + 1 ; else h = mid ; } return ( arr [ l ] >= r ) ? l : - 1 ; }
static int myRand ( int arr [ ] , int freq [ ] , int n ) {
int prefix [ ] = new int [ n ] , i ; prefix [ 0 ] = freq [ 0 ] ; for ( i = 1 ; i < n ; ++ i ) prefix [ i ] = prefix [ i - 1 ] + freq [ i ] ;
int r = ( ( int ) ( Math . random ( ) * ( 323567 ) ) % prefix [ n - 1 ] ) + 1 ;
int indexc = findCeil ( prefix , r , 0 , n - 1 ) ; return arr [ indexc ] ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int freq [ ] = { 10 , 5 , 20 , 100 } ; int i , n = arr . length ;
for ( i = 0 ; i < 5 ; i ++ ) System . out . println ( myRand ( arr , freq , n ) ) ; } }
import java . io . * ; class GFG {
static int getLeftmostBit ( int n ) { int m = 0 ; while ( n > 1 ) { n = n >> 1 ; m ++ ; } return m ; }
static int getNextLeftmostBit ( int n , int m ) { int temp = 1 << m ; while ( n < temp ) { temp = temp >> 1 ; m -- ; } return m ; }
static int countSetBits ( int n ) {
int m = getLeftmostBit ( n ) ;
return countSetBits ( n , m ) ; } static int countSetBits ( int n , int m ) {
if ( n == 0 ) return 0 ;
m = getNextLeftmostBit ( n , m ) ;
if ( n == ( ( int ) 1 << ( m + 1 ) ) - 1 ) return ( int ) ( m + 1 ) * ( 1 << m ) ;
n = n - ( 1 << m ) ; return ( n + 1 ) + countSetBits ( n ) + m * ( 1 << ( m - 1 ) ) ; }
public static void main ( String [ ] args ) { int n = 17 ; System . out . println ( " Total ▁ set ▁ bit ▁ count ▁ is ▁ " + countSetBits ( n ) ) ; } }
static int Add ( int x , int y ) { if ( y == 0 ) return x ; else return Add ( x ^ y , ( x & y ) << 1 ) ; }
class GFG { static int CHAR_BIT = 8 ;
static int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( ( Integer . SIZE / 8 ) * CHAR_BIT - 1 ) ) ) ; }
static int smallest ( int x , int y , int z ) { return Math . min ( x , Math . min ( y , z ) ) ; }
public static void main ( String [ ] args ) { int x = 12 , y = 15 , z = 5 ; System . out . println ( " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ " + smallest ( x , y , z ) ) ; } }
class GfG {
static int smallest ( int x , int y , int z ) {
if ( ( y / x ) != 1 ) return ( ( y / z ) != 1 ) ? y : z ; return ( ( x / z ) != 1 ) ? x : z ; }
public static void main ( String [ ] args ) { int x = 78 , y = 88 , z = 68 ; System . out . printf ( " Minimum ▁ of ▁ 3 ▁ numbers " + " ▁ is ▁ % d " , smallest ( x , y , z ) ) ; } }
import java . io . * ; class GFG { public static void changeToZero ( int a [ ] ) { a [ a [ 1 ] ] = a [ 1 - a [ 1 ] ] ; }
public static void main ( String args [ ] ) { int [ ] arr ; arr = new int [ 2 ] ; arr [ 0 ] = 1 ; arr [ 1 ] = 0 ; changeToZero ( arr ) ; System . out . println ( " arr [ 0 ] = ▁ " + arr [ 0 ] ) ; System . out . println ( " arr [ 1 ] = ▁ " + arr [ 1 ] ) ; } }
import java . io . * ; class GFG { static boolean isPowerOfFour ( int n ) { return n != 0 && ( ( n & ( n - 1 ) ) == 0 ) && ( n & 0xAAAAAAAA ) == 0 ; }
public static void main ( String [ ] args ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) ) System . out . println ( test_no + " ▁ is ▁ a ▁ power ▁ of ▁ 4" ) ; else System . out . println ( test_no + " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ) ; } }
class GFG { static int CHAR_BIT = 4 ; static int INT_BIT = 8 ;
static int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( INT_BIT * CHAR_BIT - 1 ) ) ) ; }
static int max ( int x , int y ) { return x - ( ( x - y ) & ( ( x - y ) >> ( INT_BIT * CHAR_BIT - 1 ) ) ) ; }
public static void main ( String [ ] args ) { int x = 15 ; int y = 6 ; System . out . println ( " Minimum ▁ of ▁ " + x + " ▁ and ▁ " + y + " ▁ is ▁ " + min ( x , y ) ) ; System . out . println ( " Maximum ▁ of ▁ " + x + " ▁ and ▁ " + y + " ▁ is ▁ " + max ( x , y ) ) ; } }
public class GFG {
static int countSetBits ( int N ) { int count = 0 ;
for ( int i = 0 ; i < 4 * 8 ; i ++ ) { if ( ( N & ( 1 << i ) ) != 0 ) count ++ ; } return count ; }
public static void main ( String [ ] args ) { int N = 15 ; System . out . println ( countSetBits ( N ) ) ; } }
public class GFG {
static void bin ( long n ) { long i ; System . out . print ( "0" ) ; for ( i = 1 << 30 ; i > 0 ; i = i / 2 ) { if ( ( n & i ) != 0 ) { System . out . print ( "1" ) ; } else { System . out . print ( "0" ) ; } } }
public static void main ( String [ ] args ) { bin ( 7 ) ; System . out . println ( ) ; bin ( 4 ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
int maxDepth ( Node node ) { if ( node == null ) return 0 ; else {
int lDepth = maxDepth ( node . left ) ; int rDepth = maxDepth ( node . right ) ;
if ( lDepth > rDepth ) return ( lDepth + 1 ) ; else return ( rDepth + 1 ) ; } }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; System . out . println ( " Height ▁ of ▁ tree ▁ is ▁ : ▁ " + tree . maxDepth ( tree . root ) ) ; } }
class CountSmaller { void constructLowerArray ( int arr [ ] , int countSmaller [ ] , int n ) { int i , j ;
for ( i = 0 ; i < n ; i ++ ) countSmaller [ i ] = 0 ; for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < arr [ i ] ) countSmaller [ i ] ++ ; } } }
void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( " " ) ; }
public static void main ( String [ ] args ) { CountSmaller small = new CountSmaller ( ) ; int arr [ ] = { 12 , 10 , 5 , 4 , 2 , 20 , 6 , 1 , 0 , 2 } ; int n = arr . length ; int low [ ] = new int [ n ] ; small . constructLowerArray ( arr , low , n ) ; small . printArray ( low , n ) ; } }
import java . util . * ; class Main {
static int segregate ( int arr [ ] , int size ) { int j = 0 , i ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] <= 0 ) { int temp ; temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ;
j ++ ; } } return j ; }
static int findMissingPositive ( int arr [ ] , int size ) { int i ;
for ( i = 0 ; i < size ; i ++ ) { int x = Math . abs ( arr [ i ] ) ; if ( x - 1 < size && arr [ x - 1 ] > 0 ) arr [ x - 1 ] = - arr [ x - 1 ] ; }
for ( i = 0 ; i < size ; i ++ ) if ( arr [ i ] > 0 )
return i + 1 ; return size + 1 ; }
static int findMissing ( int arr [ ] , int size ) {
int shift = segregate ( arr , size ) ; int arr2 [ ] = new int [ size - shift ] ; int j = 0 ; for ( int i = shift ; i < size ; i ++ ) { arr2 [ j ] = arr [ i ] ; j ++ ; }
return findMissingPositive ( arr2 , j ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 10 , 2 , - 10 , - 20 } ; int arr_size = arr . length ; int missing = findMissing ( arr , arr_size ) ; System . out . println ( " The ▁ smallest ▁ positive ▁ missing ▁ number ▁ is ▁ " + missing ) ; } }
class Node { int data ; Node left , right ; Node ( int d ) { data = d ; left = right = null ; } } class BinaryTree { Node root ;
boolean isBalanced ( Node node ) {
int lh ;
int rh ;
if ( node == null ) return true ;
lh = height ( node . left ) ; rh = height ( node . right ) ; if ( Math . abs ( lh - rh ) <= 1 && isBalanced ( node . left ) && isBalanced ( node . right ) ) return true ;
return false ; }
int height ( Node node ) {
if ( node == null ) return 0 ;
return 1 + Math . max ( height ( node . left ) , height ( node . right ) ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . left . left . left = new Node ( 8 ) ; if ( tree . isBalanced ( tree . root ) ) System . out . println ( " Tree ▁ is ▁ balanced " ) ; else System . out . println ( " Tree ▁ is ▁ not ▁ balanced " ) ; } }
class Node { int data ; Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } }
static int height ( Node node ) {
if ( node == null ) return 0 ;
return ( 1 + Math . max ( height ( node . left ) , height ( node . right ) ) ) ; }
int diameter ( Node root ) {
if ( root == null ) return 0 ;
int lheight = height ( root . left ) ; int rheight = height ( root . right ) ;
int ldiameter = diameter ( root . left ) ; int rdiameter = diameter ( root . right ) ;
return Math . max ( lheight + rheight + 1 , Math . max ( ldiameter , rdiameter ) ) ; }
public static void main ( String args [ ] ) {
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ;
System . out . println ( " The ▁ diameter ▁ of ▁ given ▁ binary ▁ tree ▁ is ▁ : ▁ " + tree . diameter ( ) ) ; } }
import java . io . * ; class GFG { static int x , y ;
static void getTwoElements ( int arr [ ] , int n ) {
int xor1 ;
int set_bit_no ; int i ; x = 0 ; y = 0 ; xor1 = arr [ 0 ] ;
for ( i = 1 ; i < n ; i ++ ) xor1 = xor1 ^ arr [ i ] ;
for ( i = 1 ; i <= n ; i ++ ) xor1 = xor1 ^ i ;
set_bit_no = xor1 & ~ ( xor1 - 1 ) ;
for ( i = 0 ; i < n ; i ++ ) { if ( ( arr [ i ] & set_bit_no ) != 0 )
x = x ^ arr [ i ] ; else
y = y ^ arr [ i ] ; } for ( i = 1 ; i <= n ; i ++ ) { if ( ( i & set_bit_no ) != 0 )
x = x ^ i ; else
y = y ^ i ; }
}
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 4 , 5 , 1 , 6 , 2 } ; int n = arr . length ; getTwoElements ( arr , n ) ; System . out . println ( " ▁ The ▁ missing ▁ element ▁ is ▁ " + x + " and ▁ the ▁ " + " repeating ▁ number ▁ is ▁ " + y ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
int depthOfOddLeafUtil ( Node node , int level ) {
if ( node == null ) return 0 ;
if ( node . left == null && node . right == null && ( level & 1 ) != 0 ) return level ;
return Math . max ( depthOfOddLeafUtil ( node . left , level + 1 ) , depthOfOddLeafUtil ( node . right , level + 1 ) ) ; }
int depthOfOddLeaf ( Node node ) { int level = 1 , depth = 0 ; return depthOfOddLeafUtil ( node , level ) ; }
public static void main ( String args [ ] ) { int k = 45 ; BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . right . left = new Node ( 5 ) ; tree . root . right . right = new Node ( 6 ) ; tree . root . right . left . right = new Node ( 7 ) ; tree . root . right . right . right = new Node ( 8 ) ; tree . root . right . left . right . left = new Node ( 9 ) ; tree . root . right . right . right . right = new Node ( 10 ) ; tree . root . right . right . right . right . left = new Node ( 11 ) ; System . out . println ( tree . depthOfOddLeaf ( tree . root ) + " ▁ is ▁ the ▁ required ▁ depth " ) ; } }
class GFG {
static int minDistance ( int arr [ ] , int n ) { int maximum_element = arr [ 0 ] ; int min_dis = n ; int index = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( maximum_element == arr [ i ] ) { min_dis = Math . min ( min_dis , ( i - index ) ) ; index = i ; }
else if ( maximum_element < arr [ i ] ) { maximum_element = arr [ i ] ; min_dis = n ; index = i ; }
else continue ; } return min_dis ; }
public static void main ( String [ ] args ) { int arr [ ] = { 6 , 3 , 1 , 3 , 6 , 4 , 6 } ; int n = arr . length ; System . out . print ( " Minimum ▁ distance ▁ = ▁ " + minDistance ( arr , n ) ) ; } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public void insertAfter ( Node prev_node , int new_data ) {
if ( prev_node == null ) { System . out . println ( " The ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ null " ) ; return ; }
Node new_node = new Node ( new_data ) ;
new_node . next = prev_node . next ;
prev_node . next = new_node ; }
class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public boolean search ( Node head , int x ) {
if ( head == null ) return false ;
if ( head . data == x ) return true ;
return search ( head . next , x ) ; }
public static void main ( String args [ ] ) {
LinkedList llist = new LinkedList ( ) ;
llist . push ( 10 ) ; llist . push ( 30 ) ; llist . push ( 11 ) ; llist . push ( 21 ) ; llist . push ( 14 ) ; if ( llist . search ( llist . head , 21 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static Node deleteAlt ( Node head ) { if ( head == null ) return ; Node node = head . next ; if ( node == null ) return ;
head . next = node . next ;
head . next = deleteAlt ( head . next ) ; }
static void AlternatingSplit ( Node source , Node aRef , Node bRef ) { Node aDummy = new Node ( ) ; Node aTail = aDummy ;
Node bDummy = new Node ( ) ; Node bTail = bDummy ;
Node current = source ; aDummy . next = null ; bDummy . next = null ; while ( current != null ) { MoveNode ( ( aTail . next ) , current ) ;
aTail = aTail . next ;
if ( current != null ) { MoveNode ( ( bTail . next ) , current ) ; bTail = bTail . next ; } } aRef = aDummy . next ; bRef = bDummy . next ; }
class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } }
boolean areIdentical ( LinkedList listb ) { Node a = this . head , b = listb . head ; while ( a != null && b != null ) { if ( a . data != b . data ) return false ;
a = a . next ; b = b . next ; }
return ( a == null && b == null ) ; }
void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public static void main ( String args [ ] ) { LinkedList llist1 = new LinkedList ( ) ; LinkedList llist2 = new LinkedList ( ) ;
llist1 . push ( 1 ) ; llist1 . push ( 2 ) ; llist1 . push ( 3 ) ; llist2 . push ( 1 ) ; llist2 . push ( 2 ) ; llist2 . push ( 3 ) ; if ( llist1 . areIdentical ( llist2 ) == true ) System . out . println ( " Identical ▁ " ) ; else System . out . println ( " Not ▁ identical ▁ " ) ; } }
boolean areIdenticalRecur ( Node a , Node b ) {
if ( a == null && b == null ) return true ;
if ( a != null && b != null ) return ( a . data == b . data ) && areIdenticalRecur ( a . next , b . next ) ;
return false ; }
class LinkedList {
class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } } void sortList ( ) {
int count [ ] = { 0 , 0 , 0 } ; Node ptr = head ;
while ( ptr != null ) { count [ ptr . data ] ++ ; ptr = ptr . next ; } int i = 0 ; ptr = head ;
while ( ptr != null ) { if ( count [ i ] == 0 ) i ++ ; else { ptr . data = i ; -- count [ i ] ; ptr = ptr . next ; } } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
void printList ( ) { Node temp = head ; while ( temp != null ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } System . out . println ( ) ; }
public static void main ( String args [ ] ) { LinkedList llist = new LinkedList ( ) ;
llist . push ( 0 ) ; llist . push ( 1 ) ; llist . push ( 0 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; llist . push ( 1 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; llist . push ( 2 ) ; System . out . println ( " Linked ▁ List ▁ before ▁ sorting " ) ; llist . printList ( ) ; llist . sortList ( ) ; System . out . println ( " Linked ▁ List ▁ after ▁ sorting " ) ; llist . printList ( ) ; } }
static class List { public int data ; public List next ; public List child ; } ;
class GfG {
static class Node { int data ; Node next ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static Node rearrangeEvenOdd ( Node head ) {
if ( head == null ) return null ;
Node odd = head ; Node even = head . next ;
Node evenFirst = even ; while ( 1 == 1 ) {
if ( odd == null || even == null || ( even . next ) == null ) { odd . next = evenFirst ; break ; }
odd . next = even . next ; odd = even . next ;
if ( odd . next == null ) { even . next = null ; odd . next = evenFirst ; break ; }
even . next = odd . next ; even = odd . next ; } return head ; }
static void printlist ( Node node ) { while ( node != null ) { System . out . print ( node . data + " - > " ) ; node = node . next ; } System . out . println ( " NULL " ) ; }
public static void main ( String [ ] args ) { Node head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; System . out . println ( " Given ▁ Linked ▁ List " ) ; printlist ( head ) ; head = rearrangeEvenOdd ( head ) ; System . out . println ( " Modified ▁ Linked ▁ List " ) ; printlist ( head ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
int getMaxWidth ( Node node ) { int maxWidth = 0 ; int width ; int h = height ( node ) ; int i ;
for ( i = 1 ; i <= h ; i ++ ) { width = getWidth ( node , i ) ; if ( width > maxWidth ) maxWidth = width ; } return maxWidth ; }
int getWidth ( Node node , int level ) { if ( node == null ) return 0 ; if ( level == 1 ) return 1 ; else if ( level > 1 ) return getWidth ( node . left , level - 1 ) + getWidth ( node . right , level - 1 ) ; return 0 ; }
int height ( Node node ) { if ( node == null ) return 0 ; else {
int lHeight = height ( node . left ) ; int rHeight = height ( node . right ) ;
return ( lHeight > rHeight ) ? ( lHeight + 1 ) : ( rHeight + 1 ) ; } }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . right = new Node ( 8 ) ; tree . root . right . right . left = new Node ( 6 ) ; tree . root . right . right . right = new Node ( 7 ) ;
System . out . println ( " Maximum ▁ width ▁ is ▁ " + tree . getMaxWidth ( tree . root ) ) ; } }
class GFG {
static class Node { int data ; Node next ; } ;
static void deleteLast ( Node head , int x ) { Node temp = head , ptr = null ; while ( temp != null ) {
if ( temp . data == x ) ptr = temp ; temp = temp . next ; }
if ( ptr != null && ptr . next == null ) { temp = head ; while ( temp . next != ptr ) temp = temp . next ; temp . next = null ; }
if ( ptr != null && ptr . next != null ) { ptr . data = ptr . next . data ; temp = ptr . next ; ptr . next = ptr . next . next ; System . gc ( ) ; } }
static Node newNode ( int x ) { Node node = new Node ( ) ; node . data = x ; node . next = null ; return node ; }
static void display ( Node head ) { Node temp = head ; if ( head == null ) { System . out . print ( "nullNEW_LINE"); return ; } while ( temp != null ) { System . out . printf ( " % d ▁ - - > ▁ " , temp . data ) ; temp = temp . next ; } System . out . print ( "nullNEW_LINE"); }
public static void main ( String [ ] args ) { Node head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; head . next . next . next . next . next = newNode ( 4 ) ; head . next . next . next . next . next . next = newNode ( 4 ) ; System . out . print ( " Created ▁ Linked ▁ list : ▁ " ) ; display ( head ) ; deleteLast ( head , 4 ) ; System . out . print ( " List ▁ after ▁ deletion ▁ of ▁ 4 : ▁ " ) ; display ( head ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
int getMaxWidth ( Node node ) { int width ; int h = height ( node ) ;
int count [ ] = new int [ 10 ] ; int level = 0 ;
getMaxWidthRecur ( node , count , level ) ;
return getMax ( count , h ) ; }
void getMaxWidthRecur ( Node node , int count [ ] , int level ) { if ( node != null ) { count [ level ] ++ ; getMaxWidthRecur ( node . left , count , level + 1 ) ; getMaxWidthRecur ( node . right , count , level + 1 ) ; } }
int height ( Node node ) { if ( node == null ) return 0 ; else {
int lHeight = height ( node . left ) ; int rHeight = height ( node . right ) ;
return ( lHeight > rHeight ) ? ( lHeight + 1 ) : ( rHeight + 1 ) ; } }
int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . right = new Node ( 8 ) ; tree . root . right . right . left = new Node ( 6 ) ; tree . root . right . right . right = new Node ( 7 ) ; System . out . println ( " Maximum ▁ width ▁ is ▁ " + tree . getMaxWidth ( tree . root ) ) ; } }
import java . io . * ; class GfG {
static class Node { int data ; Node next ; }
static int LinkedListLength ( Node head ) { while ( head != null && head . next != null ) { head = head . next . next ; } if ( head == null ) return 0 ; return 1 ; }
static void push ( Node head , int info ) {
Node node = new Node ( ) ;
node . data = info ;
node . next = ( head ) ;
( head ) = node ; }
public static void main ( String [ ] args ) { Node head = null ;
push ( head , 4 ) ; push ( head , 5 ) ; push ( head , 7 ) ; push ( head , 2 ) ; push ( head , 9 ) ; push ( head , 6 ) ; push ( head , 1 ) ; push ( head , 2 ) ; push ( head , 0 ) ; push ( head , 5 ) ; push ( head , 5 ) ; int check = LinkedListLength ( head ) ;
if ( check == 0 ) { System . out . println ( " Odd " ) ; } else { System . out . println ( " Even " ) ; } } }
Node SortedMerge ( Node a , Node b ) { Node result = null ;
Node lastPtrRef = result ; while ( 1 ) { if ( a == null ) { lastPtrRef = b ; break ; } else if ( b == null ) { lastPtrRef = a ; break ; } if ( a . data <= b . data ) { MoveNode ( lastPtrRef , a ) ; } else { MoveNode ( lastPtrRef , b ) ; }
lastPtrRef = ( ( lastPtrRef ) . next ) ; } return ( result ) ; }
import java . util . * ; class GFG {
static class Node { int data ; Node next ; } ; static Node tail ;
static Node rotateHelper ( Node blockHead , Node blockTail , int d , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { Node temp = blockHead ; for ( int i = 1 ; temp . next . next != null && i < k - 1 ; i ++ ) temp = temp . next ; blockTail . next = blockHead ; tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , k ) ; }
if ( d < 0 ) { blockTail . next = blockHead ; tail = blockHead ; return rotateHelper ( blockHead . next , blockHead , d + 1 , k ) ; } return blockHead ; }
static Node rotateByBlocks ( Node head , int k , int d ) {
if ( head == null head . next == null ) return head ;
if ( d == 0 ) return head ; Node temp = head ; tail = null ;
int i ; for ( i = 1 ; temp . next != null && i < k ; i ++ ) temp = temp . next ;
Node nextBlock = temp . next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , i ) ; else head = rotateHelper ( head , temp , d % k , k ) ;
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
static Node push ( Node head_ref , int new_data ) { Node new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } }
public static void main ( String [ ] args ) {
Node head = null ;
for ( int i = 9 ; i > 0 ; i -= 1 ) head = push ( head , i ) ; System . out . print ( "Given linked list NEW_LINE"); printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; System . out . print ( " Rotated by blocks Linked list "); printList ( head ) ; } }
public class GFG {
static class Node { int data ; Node next ; Node ( int data ) { this . data = data ; next = null ; } } static Node head ;
static void setMiddleHead ( ) { if ( head == null ) return ;
Node one_node = head ;
Node two_node = head ;
Node prev = null ; while ( two_node != null && two_node . next != null ) {
prev = one_node ;
two_node = two_node . next . next ;
one_node = one_node . next ; }
prev . next = prev . next . next ; one_node . next = head ; head = one_node ; }
static void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
static void printList ( Node ptr ) { while ( ptr != null ) { System . out . print ( ptr . data + " ▁ " ) ; ptr = ptr . next ; } System . out . println ( ) ; }
public static void main ( String args [ ] ) {
head = null ; int i ; for ( i = 5 ; i > 0 ; i -- ) push ( i ) ; System . out . print ( " ▁ list ▁ before : ▁ " ) ; printList ( head ) ; setMiddleHead ( ) ; System . out . print ( " ▁ list ▁ After : ▁ " ) ; printList ( head ) ; } }
public void push ( int new_data ) {
Node new_Node = new Node ( new_data ) ;
new_Node . next = head ; new_Node . prev = null ;
if ( head != null ) head . prev = new_Node ;
head = new_Node ; }
public void InsertAfter ( Node prev_Node , int new_data ) {
if ( prev_Node == null ) { System . out . println ( " The ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL ▁ " ) ; return ; }
Node new_node = new Node ( new_data ) ;
new_node . next = prev_Node . next ;
prev_Node . next = new_node ;
new_node . prev = prev_Node ;
if ( new_node . next != null ) new_node . next . prev = new_node ; }
void append ( int new_data ) {
Node new_node = new Node ( new_data ) ; Node last = head ;
new_node . next = null ;
if ( head == null ) { new_node . prev = null ; head = new_node ; return ; }
while ( last . next != null ) last = last . next ;
last . next = new_node ;
new_node . prev = last ; }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ; void printKDistant ( Node node , int k ) { if ( node == null k < 0 ) return ; if ( k == 0 ) { System . out . print ( node . data + " ▁ " ) ; return ; } printKDistant ( node . left , k - 1 ) ; printKDistant ( node . right , k - 1 ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 8 ) ; tree . printKDistant ( tree . root , 2 ) ; } }
class GFG { static final int COUNT = 10 ;
static class Node { int data ; Node left , right ;
Node ( int data ) { this . data = data ; this . left = null ; this . right = null ; } } ;
static void print2DUtil ( Node root , int space ) {
if ( root == null ) return ;
space += COUNT ;
print2DUtil ( root . right , space ) ;
System . out . print ( "NEW_LINE"); for ( int i = COUNT ; i < space ; i ++ ) System . out . print ( " ▁ " ) ; System . out . print ( root . data + "NEW_LINE");
print2DUtil ( root . left , space ) ; }
static void print2D ( Node root ) {
print2DUtil ( root , 0 ) ; }
public static void main ( String args [ ] ) { Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; root . left . left . left = new Node ( 8 ) ; root . left . left . right = new Node ( 9 ) ; root . left . right . left = new Node ( 10 ) ; root . left . right . right = new Node ( 11 ) ; root . right . left . left = new Node ( 12 ) ; root . right . left . right = new Node ( 13 ) ; root . right . right . left = new Node ( 14 ) ; root . right . right . right = new Node ( 15 ) ; print2D ( root ) ; } }
class Node { int data ; Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } }
void leftViewUtil ( Node node , int level ) {
if ( node == null ) return ;
if ( max_level < level ) { System . out . print ( " ▁ " + node . data ) ; max_level = level ; }
leftViewUtil ( node . left , level + 1 ) ; leftViewUtil ( node . right , level + 1 ) ; }
void leftView ( ) { leftViewUtil ( root , 1 ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 12 ) ; tree . root . left = new Node ( 10 ) ; tree . root . right = new Node ( 30 ) ; tree . root . right . left = new Node ( 25 ) ; tree . root . right . right = new Node ( 40 ) ; tree . leftView ( ) ; } }
class Node { int data ; Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class BinaryTree {
int getLeafCount ( ) { return getLeafCount ( root ) ; } int getLeafCount ( Node node ) { if ( node == null ) return 0 ; if ( node . left == null && node . right == null ) return 1 ; else return getLeafCount ( node . left ) + getLeafCount ( node . right ) ; }
public static void main ( String args [ ] ) {
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ;
System . out . println ( " The ▁ leaf ▁ count ▁ of ▁ binary ▁ tree ▁ is ▁ : ▁ " + tree . getLeafCount ( ) ) ; } }
class GFG {
public static int cntRotations ( char s [ ] , int n ) { int lh = 0 , rh = 0 , i , ans = 0 ;
for ( i = 0 ; i < n / 2 ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { lh ++ ; }
for ( i = n / 2 ; i < n ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { rh ++ ; }
if ( lh > rh ) ans ++ ;
for ( i = 1 ; i < n ; ++ i ) { if ( s [ i - 1 ] == ' a ' s [ i - 1 ] == ' e ' s [ i - 1 ] == ' i ' s [ i - 1 ] == ' o ' s [ i - 1 ] == ' u ' ) { rh ++ ; lh -- ; } if ( s [ ( i - 1 + n / 2 ) % n ] == ' a ' || s [ ( i - 1 + n / 2 ) % n ] == ' e ' || s [ ( i - 1 + n / 2 ) % n ] == ' i ' || s [ ( i - 1 + n / 2 ) % n ] == ' o ' || s [ ( i - 1 + n / 2 ) % n ] == ' u ' ) { rh -- ; lh ++ ; } if ( lh > rh ) ans ++ ; }
return ans ; }
public static void main ( String [ ] args ) { char s [ ] = { ' a ' , ' b ' , ' e ' , ' c ' , ' i ' , ' d ' , ' f ' , ' t ' } ; int n = s . length ;
System . out . println ( cntRotations ( s , n ) ) ; } }
import java . util . * ; class GFG {
static class Node { int data ; Node next ; } ; static Node tail ;
static Node rotateHelper ( Node blockHead , Node blockTail , int d , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { Node temp = blockHead ; for ( int i = 1 ; temp . next . next != null && i < k - 1 ; i ++ ) temp = temp . next ; blockTail . next = blockHead ; tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , k ) ; }
if ( d < 0 ) { blockTail . next = blockHead ; tail = blockHead ; return rotateHelper ( blockHead . next , blockHead , d + 1 , k ) ; } return blockHead ; }
static Node rotateByBlocks ( Node head , int k , int d ) {
if ( head == null head . next == null ) return head ;
if ( d == 0 ) return head ; Node temp = head ; tail = null ;
int i ; for ( i = 1 ; temp . next != null && i < k ; i ++ ) temp = temp . next ;
Node nextBlock = temp . next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , i ) ; else head = rotateHelper ( head , temp , d % k , k ) ;
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
static Node push ( Node head_ref , int new_data ) { Node new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } }
public static void main ( String [ ] args ) {
Node head = null ;
for ( int i = 9 ; i > 0 ; i -= 1 ) head = push ( head , i ) ; System . out . print ( "Given linked list NEW_LINE"); printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; System . out . print ( " Rotated by blocks Linked list "); printList ( head ) ; } }
class Node { int data ; Node left , right , nextRight ; Node ( int item ) { data = item ; left = right = nextRight = null ; } } class BinaryTree { Node root ;
Node getNextRight ( Node p ) { Node temp = p . nextRight ;
while ( temp != null ) { if ( temp . left != null ) return temp . left ; if ( temp . right != null ) return temp . right ; temp = temp . nextRight ; }
return null ; }
void connect ( Node p ) { Node temp = null ; if ( p == null ) return ;
p . nextRight = null ;
while ( p != null ) { Node q = p ;
while ( q != null ) {
if ( q . left != null ) {
if ( q . right != null ) q . left . nextRight = q . right ; else q . left . nextRight = getNextRight ( q ) ; } if ( q . right != null ) q . right . nextRight = getNextRight ( q ) ;
q = q . nextRight ; }
if ( p . left != null ) p = p . left ; else if ( p . right != null ) p = p . right ; else p = getNextRight ( p ) ; } }
public static void main ( String args [ ] ) {
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 2 ) ; tree . root . left . left = new Node ( 3 ) ; tree . root . right . right = new Node ( 90 ) ;
tree . connect ( tree . root ) ;
int a = tree . root . nextRight != null ? tree . root . nextRight . data : - 1 ; int b = tree . root . left . nextRight != null ? tree . root . left . nextRight . data : - 1 ; int c = tree . root . right . nextRight != null ? tree . root . right . nextRight . data : - 1 ; int d = tree . root . left . left . nextRight != null ? tree . root . left . left . nextRight . data : - 1 ; int e = tree . root . right . right . nextRight != null ? tree . root . right . right . nextRight . data : - 1 ; System . out . println ( " Following ▁ are ▁ populated ▁ nextRight ▁ pointers ▁ in ▁ " + " ▁ the ▁ tree ( -1 ▁ is ▁ printed ▁ if ▁ there ▁ is ▁ no ▁ nextRight ) " ) ; System . out . println ( " nextRight ▁ of ▁ " + tree . root . data + " ▁ is ▁ " + a ) ; System . out . println ( " nextRight ▁ of ▁ " + tree . root . left . data + " ▁ is ▁ " + b ) ; System . out . println ( " nextRight ▁ of ▁ " + tree . root . right . data + " ▁ is ▁ " + c ) ; System . out . println ( " nextRight ▁ of ▁ " + tree . root . left . left . data + " ▁ is ▁ " + d ) ; System . out . println ( " nextRight ▁ of ▁ " + tree . root . right . right . data + " ▁ is ▁ " + e ) ; } }
class Node { int data ; Node left , right , nextRight ; Node ( int item ) { data = item ; left = right = nextRight = null ; } } class BinaryTree { Node root ;
void connect ( Node p ) {
p . nextRight = null ;
connectRecur ( p ) ; }
void connectRecur ( Node p ) {
if ( p == null ) return ;
if ( p . left != null ) p . left . nextRight = p . right ;
if ( p . right != null ) p . right . nextRight = ( p . nextRight != null ) ? p . nextRight . left : null ;
connectRecur ( p . left ) ; connectRecur ( p . right ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 2 ) ; tree . root . left . left = new Node ( 3 ) ;
tree . connect ( tree . root ) ;
System . out . println ( " Following ▁ are ▁ populated ▁ nextRight ▁ pointers ▁ in ▁ " + " the ▁ tree " + " ( -1 ▁ is ▁ printed ▁ if ▁ there ▁ is ▁ no ▁ nextRight ) " ) ; int a = tree . root . nextRight != null ? tree . root . nextRight . data : - 1 ; System . out . println ( " nextRight ▁ of ▁ " + tree . root . data + " ▁ is ▁ " + a ) ; int b = tree . root . left . nextRight != null ? tree . root . left . nextRight . data : - 1 ; System . out . println ( " nextRight ▁ of ▁ " + tree . root . left . data + " ▁ is ▁ " + b ) ; int c = tree . root . right . nextRight != null ? tree . root . right . nextRight . data : - 1 ; System . out . println ( " nextRight ▁ of ▁ " + tree . root . right . data + " ▁ is ▁ " + c ) ; int d = tree . root . left . left . nextRight != null ? tree . root . left . left . nextRight . data : - 1 ; System . out . println ( " nextRight ▁ of ▁ " + tree . root . left . left . data + " ▁ is ▁ " + d ) ; } }
static void DeleteFirst ( Node head ) { Node previous = head , firstNode = head ;
if ( head == null ) { System . out . printf ( " List is empty "); return ; }
if ( previous . next == previous ) { head = null ; return ; }
while ( previous . next != head ) { previous = previous . next ; }
previous . next = firstNode . next ;
head = previous . next ; System . gc ( ) ; return ; }
static Node DeleteLast ( Node head ) { Node current = head , temp = head , previous = null ;
if ( head == null ) { System . out . printf ( " List is empty "); return null ; }
if ( current . next == current ) { head = null ; return null ; }
while ( current . next != head ) { previous = current ; current = current . next ; } previous . next = current . next ; head = previous . next ; return head ; }
class Node { int data ; Node left , right , next ; Node ( int item ) { data = item ; left = right = next = null ; } }
void populateNext ( Node node ) {
populateNextRecur ( node , next ) ; }
void populateNextRecur ( Node p , Node next_ref ) { if ( p != null ) {
populateNextRecur ( p . right , next_ref ) ;
p . next = next_ref ;
next_ref = p ;
populateNextRecur ( p . left , next_ref ) ; } }
class Node { int data ; Node left , right ; public Node ( int d ) { data = d ; left = right = null ; } } class BinaryTree { Node root ;
int getLevelUtil ( Node node , int data , int level ) { if ( node == null ) return 0 ; if ( node . data == data ) return level ; int downlevel = getLevelUtil ( node . left , data , level + 1 ) ; if ( downlevel != 0 ) return downlevel ; downlevel = getLevelUtil ( node . right , data , level + 1 ) ; return downlevel ; }
int getLevel ( Node node , int data ) { return getLevelUtil ( node , data , 1 ) ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 3 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 5 ) ; tree . root . left . left = new Node ( 1 ) ; tree . root . left . right = new Node ( 4 ) ; for ( int x = 1 ; x <= 5 ; x ++ ) { int level = tree . getLevel ( tree . root , x ) ; if ( level != 0 ) System . out . println ( " Level ▁ of ▁ " + x + " ▁ is ▁ " + tree . getLevel ( tree . root , x ) ) ; else System . out . println ( x + " ▁ is ▁ not ▁ present ▁ in ▁ tree " ) ; } } }
class GfG {
static class Node { int key ; Node left , right ; }
static Node newNode ( int key ) { Node n = new Node ( ) ; n . key = key ; n . left = null ; n . right = null ; return n ; }
static int findMirrorRec ( int target , Node left , Node right ) {
if ( left == null right == null ) return 0 ;
if ( left . key == target ) return right . key ; if ( right . key == target ) return left . key ;
int mirror_val = findMirrorRec ( target , left . left , right . right ) ; if ( mirror_val != 0 ) return mirror_val ;
return findMirrorRec ( target , left . right , right . left ) ; }
static int findMirror ( Node root , int target ) { if ( root == null ) return 0 ; if ( root . key == target ) return target ; return findMirrorRec ( target , root . left , root . right ) ; }
public static void main ( String [ ] args ) { Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . left . left = newNode ( 4 ) ; root . left . left . right = newNode ( 7 ) ; root . right = newNode ( 3 ) ; root . right . left = newNode ( 5 ) ; root . right . right = newNode ( 6 ) ; root . right . left . left = newNode ( 8 ) ; root . right . left . right = newNode ( 9 ) ;
int target = root . left . left . key ; int mirror = findMirror ( root , target ) ; if ( mirror != 0 ) System . out . println ( " Mirror ▁ of ▁ Node ▁ " + target + " ▁ is ▁ Node ▁ " + mirror ) ; else System . out . println ( " Mirror ▁ of ▁ Node ▁ " + target + " ▁ is ▁ null ▁ " ) ; } }
import java . util . * ; class GFG {
static class node { int data ; node left ; node right ;
node ( int data ) { this . data = data ; this . left = null ; this . right = null ; } } ;
static boolean iterativeSearch ( node root , int x ) {
if ( root == null ) return false ;
Queue < node > q = new LinkedList ( ) ;
q . add ( root ) ;
while ( q . size ( ) > 0 ) {
node node = q . peek ( ) ; if ( node . data == x ) return true ;
q . remove ( ) ; if ( node . left != null ) q . add ( node . left ) ; if ( node . right != null ) q . add ( node . right ) ; } return false ; }
public static void main ( String ags [ ] ) { node NewRoot = null ; node root = new node ( 2 ) ; root . left = new node ( 7 ) ; root . right = new node ( 5 ) ; root . left . right = new node ( 6 ) ; root . left . right . left = new node ( 1 ) ; root . left . right . right = new node ( 11 ) ; root . right . right = new node ( 9 ) ; root . right . right . left = new node ( 4 ) ; System . out . print ( ( iterativeSearch ( root , 6 ) ? "Found " : ▁ " Not Found "));  System . out . print ( ( iterativeSearch ( root , 12 ) ? "Found " : ▁ " Not Found "));  } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } }
class BinaryTree { Node root ; void printInorder ( Node node ) { if ( node != null ) { printInorder ( node . left ) ; System . out . print ( node . data + " ▁ " ) ; printInorder ( node . right ) ; } }
Node RemoveHalfNodes ( Node node ) { if ( node == null ) return null ; node . left = RemoveHalfNodes ( node . left ) ; node . right = RemoveHalfNodes ( node . right ) ; if ( node . left == null && node . right == null ) return node ;
if ( node . left == null ) { Node new_root = node . right ; return new_root ; }
if ( node . right == null ) { Node new_root = node . left ; return new_root ; } return node ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; Node NewRoot = null ; tree . root = new Node ( 2 ) ; tree . root . left = new Node ( 7 ) ; tree . root . right = new Node ( 5 ) ; tree . root . left . right = new Node ( 6 ) ; tree . root . left . right . left = new Node ( 1 ) ; tree . root . left . right . right = new Node ( 11 ) ; tree . root . right . right = new Node ( 9 ) ; tree . root . right . right . left = new Node ( 4 ) ; System . out . println ( " the ▁ inorder ▁ traversal ▁ of ▁ tree ▁ is ▁ " ) ; tree . printInorder ( tree . root ) ; NewRoot = tree . RemoveHalfNodes ( tree . root ) ; System . out . print ( " Inorder traversal of the modified tree "); tree . printInorder ( NewRoot ) ; } }
class Node { int data ; Node left , right ;
public Node ( int data ) { this . data = data ; left = right = null ; } } class BinaryTree { Node root ;
static int findMax ( Node node ) {
if ( node == null ) return Integer . MIN_VALUE ;
int res = node . data ; int lres = findMax ( node . left ) ; int rres = findMax ( node . right ) ; if ( lres > res ) res = lres ; if ( rres > res ) res = rres ; return res ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 2 ) ; tree . root . left = new Node ( 7 ) ; tree . root . right = new Node ( 5 ) ; tree . root . left . right = new Node ( 6 ) ; tree . root . left . right . left = new Node ( 1 ) ; tree . root . left . right . right = new Node ( 11 ) ; tree . root . right . right = new Node ( 9 ) ; tree . root . right . right . left = new Node ( 4 ) ;
System . out . println ( " Maximum ▁ element ▁ is ▁ " + tree . findMax ( tree . root ) ) ; } }
static int findMin ( Node node ) { if ( node == null ) return Integer . MAX_VALUE ; int res = node . data ; int lres = findMin ( node . left ) ; int rres = findMin ( node . right ) ; if ( lres < res ) res = lres ; if ( rres < res ) res = rres ; return res ; }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; right = left = null ; } }
public Node extractLeafList ( Node root ) { if ( root == null ) return null ; if ( root . left == null && root . right == null ) { if ( head == null ) { head = root ; prev = root ; } else { prev . right = root ; root . left = prev ; prev = root ; } return null ; } root . left = extractLeafList ( root . left ) ; root . right = extractLeafList ( root . right ) ; return root ; }
void inorder ( Node node ) { if ( node == null ) return ; inorder ( node . left ) ; System . out . print ( node . data + " ▁ " ) ; inorder ( node . right ) ; }
public void printDLL ( Node head ) { Node last = null ; while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; last = head ; head = head . right ; } }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . right = new Node ( 6 ) ; tree . root . left . left . left = new Node ( 7 ) ; tree . root . left . left . right = new Node ( 8 ) ; tree . root . right . right . left = new Node ( 9 ) ; tree . root . right . right . right = new Node ( 10 ) ; System . out . println ( " Inorder ▁ traversal ▁ of ▁ given ▁ tree ▁ is ▁ : ▁ " ) ; tree . inorder ( tree . root ) ; tree . extractLeafList ( tree . root ) ; System . out . println ( " " ) ; System . out . println ( " Extracted ▁ double ▁ link ▁ list ▁ is ▁ : ▁ " ) ; tree . printDLL ( tree . head ) ; System . out . println ( " " ) ; System . out . println ( " Inorder ▁ traversal ▁ of ▁ modified ▁ tree ▁ is ▁ : ▁ " ) ; tree . inorder ( tree . root ) ; } }
import java . util . * ; class Solution { static int count = 0 ;
static class Node { int data ; Node left ; Node right ; }
static Node newNode ( int data ) { Node node = new Node ( ) ; node . data = data ; node . left = null ; node . right = null ; return ( node ) ; }
static void NthInorder ( Node node , int n ) { if ( node == null ) return ; if ( count <= n ) {
NthInorder ( node . left , n ) ; count ++ ;
if ( count == n ) System . out . printf ( " % d ▁ " , node . data ) ;
NthInorder ( node . right , n ) ; } }
public static void main ( String args [ ] ) { Node root = newNode ( 10 ) ; root . left = newNode ( 20 ) ; root . right = newNode ( 30 ) ; root . left . left = newNode ( 40 ) ; root . left . right = newNode ( 50 ) ; int n = 4 ; NthInorder ( root , n ) ; } }
class KnightTour { static int N = 8 ;
static boolean isSafe ( int x , int y , int sol [ ] [ ] ) { return ( x >= 0 && x < N && y >= 0 && y < N && sol [ x ] [ y ] == - 1 ) ; }
static void printSolution ( int sol [ ] [ ] ) { for ( int x = 0 ; x < N ; x ++ ) { for ( int y = 0 ; y < N ; y ++ ) System . out . print ( sol [ x ] [ y ] + " ▁ " ) ; System . out . println ( ) ; } }
static boolean solveKT ( ) { int sol [ ] [ ] = new int [ 8 ] [ 8 ] ;
for ( int x = 0 ; x < N ; x ++ ) for ( int y = 0 ; y < N ; y ++ ) sol [ x ] [ y ] = - 1 ;
int xMove [ ] = { 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 } ; int yMove [ ] = { 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 } ;
sol [ 0 ] [ 0 ] = 0 ;
if ( ! solveKTUtil ( 0 , 0 , 1 , sol , xMove , yMove ) ) { System . out . println ( " Solution ▁ does ▁ not ▁ exist " ) ; return false ; } else printSolution ( sol ) ; return true ; }
static boolean solveKTUtil ( int x , int y , int movei , int sol [ ] [ ] , int xMove [ ] , int yMove [ ] ) { int k , next_x , next_y ; if ( movei == N * N ) return true ;
for ( k = 0 ; k < 8 ; k ++ ) { next_x = x + xMove [ k ] ; next_y = y + yMove [ k ] ; if ( isSafe ( next_x , next_y , sol ) ) { sol [ next_x ] [ next_y ] = movei ; if ( solveKTUtil ( next_x , next_y , movei + 1 , sol , xMove , yMove ) ) return true ; else
sol [ next_x ] [ next_y ] = - 1 ; } } return false ; }
public static void main ( String args [ ] ) {
solveKT ( ) ; } }
public class GFG {
static int V = 4 ;
static void printSolution ( int [ ] color ) { System . out . println ( " Solution ▁ Exists : " + " ▁ Following ▁ are ▁ the ▁ assigned ▁ colors ▁ " ) ; for ( int i = 0 ; i < V ; i ++ ) System . out . print ( " ▁ " + color [ i ] ) ; System . out . println ( ) ; }
static boolean isSafe ( boolean [ ] [ ] graph , int [ ] color ) {
for ( int i = 0 ; i < V ; i ++ ) for ( int j = i + 1 ; j < V ; j ++ ) if ( graph [ i ] [ j ] && color [ j ] == color [ i ] ) return false ; return true ; }
static boolean graphColoring ( boolean [ ] [ ] graph , int m , int i , int [ ] color ) {
if ( i == V ) {
if ( isSafe ( graph , color ) ) {
printSolution ( color ) ; return true ; } return false ; }
for ( int j = 1 ; j <= m ; j ++ ) { color [ i ] = j ;
if ( graphColoring ( graph , m , i + 1 , color ) ) return true ; color [ i ] = 0 ; } return false ; }
public static void main ( String [ ] args ) {
boolean [ ] [ ] graph = { { false , true , true , true } , { true , false , true , false } , { true , true , false , true } , { true , false , true , false } , } ;
int m = 3 ;
int [ ] color = new int [ V ] ; for ( int i = 0 ; i < V ; i ++ ) color [ i ] = 0 ; if ( ! graphColoring ( graph , m , 0 , color ) ) System . out . println ( " Solution ▁ does ▁ not ▁ exist " ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right ; } } class BinaryTree { Node root ;
void reverseLevelOrder ( Node node ) { int h = height ( node ) ; int i ; for ( i = h ; i >= 1 ; i -- ) { printGivenLevel ( node , i ) ; } }
void printGivenLevel ( Node node , int level ) { if ( node == null ) return ; if ( level == 1 ) System . out . print ( node . data + " ▁ " ) ; else if ( level > 1 ) { printGivenLevel ( node . left , level - 1 ) ; printGivenLevel ( node . right , level - 1 ) ; } }
int height ( Node node ) { if ( node == null ) return 0 ; else {
int lheight = height ( node . left ) ; int rheight = height ( node . right ) ;
if ( lheight > rheight ) return ( lheight + 1 ) ; else return ( rheight + 1 ) ; } }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; System . out . println ( " Level ▁ Order ▁ traversal ▁ of ▁ binary ▁ tree ▁ is ▁ : ▁ " ) ; tree . reverseLevelOrder ( tree . root ) ; } }
import java . util . * ; class GFG { static int M = 3 ; static int N = 3 ;
static boolean bpm ( int table [ ] [ ] , int u , boolean seen [ ] , int matchR [ ] ) {
for ( int v = 0 ; v < N ; v ++ ) {
if ( table [ u ] [ v ] > 0 && ! seen [ v ] ) {
seen [ v ] = true ;
if ( matchR [ v ] < 0 || bpm ( table , matchR [ v ] , seen , matchR ) ) { matchR [ v ] = u ; return true ; } } } return false ; }
static int maxBPM ( int table [ ] [ ] ) {
int [ ] matchR = new int [ N ] ;
Arrays . fill ( matchR , - 1 ) ;
int result = 0 ; for ( int u = 0 ; u < M ; u ++ ) {
boolean [ ] seen = new boolean [ N ] ; Arrays . fill ( seen , false ) ;
if ( bpm ( table , u , seen , matchR ) ) result ++ ; } System . out . println ( " The ▁ number ▁ of ▁ maximum ▁ packets " + " ▁ sent ▁ in ▁ the ▁ time ▁ slot ▁ is ▁ " + result ) ; for ( int x = 0 ; x < N ; x ++ ) if ( matchR [ x ] + 1 != 0 ) System . out . println ( " T " + ( matchR [ x ] + 1 ) + " - > ▁ R " + ( x + 1 ) ) ; return result ; }
public static void main ( String [ ] args ) { int table [ ] [ ] = { { 0 , 2 , 0 } , { 3 , 0 , 1 } , { 2 , 4 , 0 } } ; maxBPM ( table ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ; void morrisTraversalPreorder ( ) { morrisTraversalPreorder ( root ) ; }
void morrisTraversalPreorder ( Node node ) { while ( node != null ) {
if ( node . left == null ) { System . out . print ( node . data + " ▁ " ) ; node = node . right ; } else {
Node current = node . left ; while ( current . right != null && current . right != node ) { current = current . right ; }
if ( current . right == node ) { current . right = null ; node = node . right ; }
else { System . out . print ( node . data + " ▁ " ) ; current . right = node ; node = node . left ; } } } } void preorder ( ) { preorder ( root ) ; }
void preorder ( Node node ) { if ( node != null ) { System . out . print ( node . data + " ▁ " ) ; preorder ( node . left ) ; preorder ( node . right ) ; } }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 6 ) ; tree . root . right . right = new Node ( 7 ) ; tree . root . left . left . left = new Node ( 8 ) ; tree . root . left . left . right = new Node ( 9 ) ; tree . root . left . right . left = new Node ( 10 ) ; tree . root . left . right . right = new Node ( 11 ) ; tree . morrisTraversalPreorder ( ) ; System . out . println ( " " ) ; tree . preorder ( ) ; } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public void insertAfter ( Node prev_node , int new_data ) {
if ( prev_node == null ) { System . out . println ( " The ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ null " ) ; return ; }
Node new_node = new Node ( new_data ) ;
new_node . next = prev_node . next ;
prev_node . next = new_node ; }
static void printNthFromLast ( Node head , int n ) { static int i = 0 ; if ( head == null ) return ; printNthFromLast ( head . next , n ) ; if ( ++ i == n ) System . out . print ( head . data ) ; }
class LinkedList {
class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; } void detectLoop ( ) { Node slow_p = head , fast_p = head ; int flag = 0 ; while ( slow_p != null && fast_p != null && fast_p . next != null ) { slow_p = slow_p . next ; fast_p = fast_p . next . next ; if ( slow_p == fast_p ) { flag = 1 ; break ; } } if ( flag == 1 ) System . out . println ( " Loop ▁ found " ) ; else System . out . println ( " Loop ▁ not ▁ found " ) ; }
public static void main ( String args [ ] ) {
LinkedList llist = new LinkedList ( ) ; llist . push ( 20 ) ; llist . push ( 4 ) ; llist . push ( 15 ) ; llist . push ( 10 ) ;
llist . head . next . next . next . next = llist . head ; llist . detectLoop ( ) ; } }
class LinkedList {
class Node { char data ; Node next ; Node ( char d ) { data = d ; next = null ; } }
boolean isPalindrome ( Node head ) { slow_ptr = head ; fast_ptr = head ; Node prev_of_slow_ptr = head ;
Node midnode = null ;
boolean res = true ; if ( head != null && head . next != null ) {
while ( fast_ptr != null && fast_ptr . next != null ) { fast_ptr = fast_ptr . next . next ;
prev_of_slow_ptr = slow_ptr ; slow_ptr = slow_ptr . next ; }
if ( fast_ptr != null ) { midnode = slow_ptr ; slow_ptr = slow_ptr . next ; }
second_half = slow_ptr ;
prev_of_slow_ptr . next = null ;
reverse ( ) ;
res = compareLists ( head , second_half ) ;
reverse ( ) ; if ( midnode != null ) {
prev_of_slow_ptr . next = midnode ; midnode . next = second_half ; } else prev_of_slow_ptr . next = second_half ; } return res ; }
void reverse ( ) { Node prev = null ; Node current = second_half ; Node next ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } second_half = prev ; }
boolean compareLists ( Node head1 , Node head2 ) { Node temp1 = head1 ; Node temp2 = head2 ; while ( temp1 != null && temp2 != null ) { if ( temp1 . data == temp2 . data ) { temp1 = temp1 . next ; temp2 = temp2 . next ; } else return false ; }
if ( temp1 == null && temp2 == null ) return true ;
return false ; }
public void push ( char new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
void printList ( Node ptr ) { while ( ptr != null ) { System . out . print ( ptr . data + " - > " ) ; ptr = ptr . next ; } System . out . println ( " NULL " ) ; }
public static void main ( String [ ] args ) {
LinkedList llist = new LinkedList ( ) ; char str [ ] = { ' a ' , ' b ' , ' a ' , ' c ' , ' a ' , ' b ' , ' a ' } ; String string = new String ( str ) ; for ( int i = 0 ; i < 7 ; i ++ ) { llist . push ( str [ i ] ) ; llist . printList ( llist . head ) ; if ( llist . isPalindrome ( llist . head ) != false ) { System . out . println ( " Is ▁ Palindrome " ) ; System . out . println ( " " ) ; } else { System . out . println ( " Not ▁ Palindrome " ) ; System . out . println ( " " ) ; } } } }
class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } } class LinkedList {
public void swapNodes ( int x , int y ) {
if ( x == y ) return ;
Node prevX = null , currX = head ; while ( currX != null && currX . data != x ) { prevX = currX ; currX = currX . next ; }
Node prevY = null , currY = head ; while ( currY != null && currY . data != y ) { prevY = currY ; currY = currY . next ; }
if ( currX == null currY == null ) return ;
if ( prevX != null ) prevX . next = currY ;
else head = currY ;
if ( prevY != null ) prevY . next = currX ;
else head = currX ;
Node temp = currX . next ; currX . next = currY . next ; currY . next = temp ; }
public void push ( int new_data ) {
Node new_Node = new Node ( new_data ) ;
new_Node . next = head ;
head = new_Node ; }
public void printList ( ) { Node tNode = head ; while ( tNode != null ) { System . out . print ( tNode . data + " ▁ " ) ; tNode = tNode . next ; } }
public static void main ( String [ ] args ) { LinkedList llist = new LinkedList ( ) ;
llist . push ( 7 ) ; llist . push ( 6 ) ; llist . push ( 5 ) ; llist . push ( 4 ) ; llist . push ( 3 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; System . out . print ( " Linked list before calling swapNodes ( ) "); llist . printList ( ) ; llist . swapNodes ( 4 , 3 ) ; System . out . print ( " Linked list after calling swapNodes ( ) "); llist . printList ( ) ; } }
static void pairWiseSwap ( node head ) {
if ( head != null && head . next != null ) {
swap ( head . data , head . next . data ) ;
pairWiseSwap ( head . next . next ) ; } }
else if ( current . data >= new_node . data ) {
Node tmp = current . data ; current . data = new_node . data ; new_node . data = tmp ; new_node . next = ( head_ref ) . next ; ( head_ref ) . next = new_node ; }
public void push ( int new_data ) {
Node new_Node = new Node ( new_data ) ;
new_Node . next = head ; new_Node . prev = null ;
if ( head != null ) head . prev = new_Node ;
head = new_Node ; }
public void InsertAfter ( Node prev_Node , int new_data ) {
if ( prev_Node == null ) { System . out . println ( " The ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL ▁ " ) ; return ; }
Node new_node = new Node ( new_data ) ;
new_node . next = prev_Node . next ;
prev_Node . next = new_node ;
new_node . prev = prev_Node ;
if ( new_node . next != null ) new_node . next . prev = new_node ; }
void append ( int new_data ) {
Node new_node = new Node ( new_data ) ; Node last = head ;
new_node . next = null ;
if ( head == null ) { new_node . prev = null ; head = new_node ; return ; }
while ( last . next != null ) last = last . next ;
last . next = new_node ;
new_node . prev = last ; }
import java . util . * ; class solution {
static class node { int key ; node left ; node right ; int height ; int count ; }
static int height ( node N ) { if ( N == null ) return 0 ; return N . height ; }
static int max ( int a , int b ) { return ( a > b ) ? a : b ; }
static node newNode ( int key ) { node node = new node ( ) ; node . key = key ; node . left = null ; node . right = null ;
node . height = 1 ; node . count = 1 ; return ( node ) ; }
static node rightRotate ( node y ) { node x = y . left ; node T2 = x . right ;
x . right = y ; y . left = T2 ;
y . height = max ( height ( y . left ) , height ( y . right ) ) + 1 ; x . height = max ( height ( x . left ) , height ( x . right ) ) + 1 ;
return x ; }
static node leftRotate ( node x ) { node y = x . right ; node T2 = y . left ;
y . left = x ; x . right = T2 ;
x . height = max ( height ( x . left ) , height ( x . right ) ) + 1 ; y . height = max ( height ( y . left ) , height ( y . right ) ) + 1 ;
return y ; }
static int getBalance ( node N ) { if ( N == null ) return 0 ; return height ( N . left ) - height ( N . right ) ; } static node insert ( node node , int key ) {
if ( node == null ) return ( newNode ( key ) ) ;
if ( key == node . key ) { ( node . count ) ++ ; return node ; }
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
node . height = max ( height ( node . left ) , height ( node . right ) ) + 1 ;
int balance = getBalance ( node ) ;
if ( balance > 1 && key < node . left . key ) return rightRotate ( node ) ;
if ( balance < - 1 && key > node . right . key ) return leftRotate ( node ) ;
if ( balance > 1 && key > node . left . key ) { node . left = leftRotate ( node . left ) ; return rightRotate ( node ) ; }
if ( balance < - 1 && key < node . right . key ) { node . right = rightRotate ( node . right ) ; return leftRotate ( node ) ; }
return node ; }
static node minValueNode ( node node ) { node current = node ;
while ( current . left != null ) current = current . left ; return current ; } static node deleteNode ( node root , int key ) {
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . count > 1 ) { ( root . count ) -- ; return null ; }
if ( ( root . left == null ) || ( root . right == null ) ) { node temp = root . left != null ? root . left : root . right ;
if ( temp == null ) { temp = root ; root = null ; }
else
root = temp ; } else {
node temp = minValueNode ( root . right ) ;
root . key = temp . key ; root . count = temp . count ; temp . count = 1 ;
root . right = deleteNode ( root . right , temp . key ) ; } }
if ( root == null ) return root ;
root . height = max ( height ( root . left ) , height ( root . right ) ) + 1 ;
int balance = getBalance ( root ) ;
if ( balance > 1 && getBalance ( root . left ) >= 0 ) return rightRotate ( root ) ;
if ( balance > 1 && getBalance ( root . left ) < 0 ) { root . left = leftRotate ( root . left ) ; return rightRotate ( root ) ; }
if ( balance < - 1 && getBalance ( root . right ) <= 0 ) return leftRotate ( root ) ;
if ( balance < - 1 && getBalance ( root . right ) > 0 ) { root . right = rightRotate ( root . right ) ; return leftRotate ( root ) ; } return root ; }
static void preOrder ( node root ) { if ( root != null ) { System . out . printf ( " % d ( % d ) ▁ " , root . key , root . count ) ; preOrder ( root . left ) ; preOrder ( root . right ) ; } }
public static void main ( String args [ ] ) { node root = null ;
root = insert ( root , 9 ) ; root = insert ( root , 5 ) ; root = insert ( root , 10 ) ; root = insert ( root , 5 ) ; root = insert ( root , 9 ) ; root = insert ( root , 7 ) ; root = insert ( root , 17 ) ; System . out . printf ( "Pre order traversal of the constructed AVL tree is NEW_LINE"); preOrder ( root ) ; deleteNode ( root , 9 ) ; System . out . printf ( " Pre order traversal after deletion of 9 "); preOrder ( root ) ; } }
import java . io . * ; import java . util . * ;
class Node { int info ; Node prev , next ; } class GFG { static Node head , tail ;
static void nodeInsetail ( int key ) { Node p = new Node ( ) ; p . info = key ; p . next = null ;
if ( head == null ) { head = p ; tail = p ; head . prev = null ; return ; }
if ( p . info < head . info ) { p . prev = null ; head . prev = p ; p . next = head ; head = p ; return ; }
if ( p . info > tail . info ) { p . prev = tail ; tail . next = p ; tail = p ; return ; }
Node temp = head . next ; while ( temp . info < p . info ) temp = temp . next ;
( temp . prev ) . next = p ; p . prev = temp . prev ; temp . prev = p ; p . next = temp ; }
static void printList ( Node temp ) { while ( temp != null ) { System . out . print ( temp . info + " ▁ " ) ; temp = temp . next ; } }
public static void main ( String args [ ] ) { head = tail = null ; nodeInsetail ( 30 ) ; nodeInsetail ( 50 ) ; nodeInsetail ( 90 ) ; nodeInsetail ( 10 ) ; nodeInsetail ( 40 ) ; nodeInsetail ( 110 ) ; nodeInsetail ( 60 ) ; nodeInsetail ( 95 ) ; nodeInsetail ( 23 ) ; System . out . println ( " Doubly ▁ linked ▁ list ▁ on ▁ printing ▁ from ▁ left ▁ to ▁ right " ) ; printList ( head ) ; } }
static class Node { int data ; Node next ; } ;
static void fun1 ( Node head ) { if ( head == null ) { return ; } fun1 ( head . next ) ; System . out . print ( head . data + " ▁ " ) ; }
static void fun2 ( Node head ) { if ( head == null ) { return ; } System . out . print ( head . data + " ▁ " ) ; if ( head . next != null ) { fun2 ( head . next . next ) ; } System . out . print ( head . data + " ▁ " ) ; }
class GFG {
static class Node { int data ; Node next ; } ;
static void fun1 ( Node head ) { if ( head == null ) { return ; } fun1 ( head . next ) ; System . out . print ( head . data + " ▁ " ) ; }
static void fun2 ( Node start ) { if ( start == null ) { return ; } System . out . print ( start . data + " ▁ " ) ; if ( start . next != null ) { fun2 ( start . next . next ) ; } System . out . print ( start . data + " ▁ " ) ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ;
( head_ref ) = new_node ; return head_ref ; }
public static void main ( String [ ] args ) {
Node head = null ;
head = push ( head , 5 ) ; head = push ( head , 4 ) ; head = push ( head , 3 ) ; head = push ( head , 2 ) ; head = push ( head , 1 ) ; System . out . print ( " Output ▁ of ▁ fun1 ( ) ▁ for ▁ " + "list 1->2->3->4->5 NEW_LINE"); fun1 ( head ) ; System . out . print ( " Output of fun2 ( ) for " ▁ + ▁ " list 1 -> 2 -> 3 -> 4 -> 5 "); fun2 ( head ) ; } }
class GfG {
static class Node { int data ; Node next ; } static Node head = null ;
static int printsqrtn ( Node head ) { Node sqrtn = null ; int i = 1 , j = 1 ;
while ( head != null ) {
if ( i == j * j ) {
if ( sqrtn == null ) sqrtn = head ; else sqrtn = sqrtn . next ;
j ++ ; } i ++ ; head = head . next ; }
return sqrtn . data ; } static void print ( Node head ) { while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; head = head . next ; } System . out . println ( ) ; }
static void push ( int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head ;
head = new_node ; }
public static void main ( String [ ] args ) {
push ( 40 ) ; push ( 30 ) ; push ( 20 ) ; push ( 10 ) ; System . out . print ( " Given ▁ linked ▁ list ▁ is : " ) ; print ( head ) ; System . out . print ( " sqrt ( n ) th ▁ node ▁ is ▁ " + printsqrtn ( head ) ) ; } }
class Node { char data ; Node left , right ; Node ( char item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ; static int preIndex = 0 ;
Node buildTree ( char in [ ] , char pre [ ] , int inStrt , int inEnd ) { if ( inStrt > inEnd ) return null ;
Node tNode = new Node ( pre [ preIndex ++ ] ) ;
if ( inStrt == inEnd ) return tNode ;
int inIndex = search ( in , inStrt , inEnd , tNode . data ) ;
tNode . left = buildTree ( in , pre , inStrt , inIndex - 1 ) ; tNode . right = buildTree ( in , pre , inIndex + 1 , inEnd ) ; return tNode ; }
int search ( char arr [ ] , int strt , int end , char value ) { int i ; for ( i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) return i ; } return i ; }
void printInorder ( Node node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
System . out . print ( node . data + " ▁ " ) ;
printInorder ( node . right ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; char in [ ] = new char [ ] { ' D ' , ' B ' , ' E ' , ' A ' , ' F ' , ' C ' } ; char pre [ ] = new char [ ] { ' A ' , ' B ' , ' D ' , ' E ' , ' C ' , ' F ' } ; int len = in . length ; Node root = tree . buildTree ( in , pre , 0 , len - 1 ) ;
System . out . println ( " Inorder ▁ traversal ▁ of ▁ constructed ▁ tree ▁ is ▁ : ▁ " ) ; tree . printInorder ( root ) ; } }
class Node { int data ; Node left , right ; Node ( int d ) { data = d ; left = right = null ; } } class BinaryTree { static Node head ;
Node insert ( Node node , int data ) {
if ( node == null ) { return ( new Node ( data ) ) ; } else {
if ( data <= node . data ) { node . left = insert ( node . left , data ) ; } else { node . right = insert ( node . right , data ) ; }
return node ; } }
int minvalue ( Node node ) { Node current = node ;
while ( current . left != null ) { current = current . left ; } return ( current . data ) ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; Node root = null ; root = tree . insert ( root , 4 ) ; tree . insert ( root , 2 ) ; tree . insert ( root , 1 ) ; tree . insert ( root , 3 ) ; tree . insert ( root , 6 ) ; tree . insert ( root , 5 ) ; System . out . println ( " Minimum ▁ value ▁ of ▁ BST ▁ is ▁ " + tree . minvalue ( root ) ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
Node lca ( Node node , int n1 , int n2 ) { if ( node == null ) return null ;
if ( node . data > n1 && node . data > n2 ) return lca ( node . left , n1 , n2 ) ;
if ( node . data < n1 && node . data < n2 ) return lca ( node . right , n1 , n2 ) ; return node ; }
public static void main ( String args [ ] ) {
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 20 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 22 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 12 ) ; tree . root . left . right . left = new Node ( 10 ) ; tree . root . left . right . right = new Node ( 14 ) ; int n1 = 10 , n2 = 14 ; Node t = tree . lca ( tree . root , n1 , n2 ) ; System . out . println ( " LCA ▁ of ▁ " + n1 + " ▁ and ▁ " + n2 + " ▁ is ▁ " + t . data ) ; n1 = 14 ; n2 = 8 ; t = tree . lca ( tree . root , n1 , n2 ) ; System . out . println ( " LCA ▁ of ▁ " + n1 + " ▁ and ▁ " + n2 + " ▁ is ▁ " + t . data ) ; n1 = 10 ; n2 = 22 ; t = tree . lca ( tree . root , n1 , n2 ) ; System . out . println ( " LCA ▁ of ▁ " + n1 + " ▁ and ▁ " + n2 + " ▁ is ▁ " + t . data ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
static Node lca ( Node root , int n1 , int n2 ) { while ( root != null ) {
if ( root . data > n1 && root . data > n2 ) root = root . left ;
else if ( root . data < n1 && root . data < n2 ) root = root . right ; else break ; } return root ; }
public static void main ( String args [ ] ) {
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 20 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 22 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 12 ) ; tree . root . left . right . left = new Node ( 10 ) ; tree . root . left . right . right = new Node ( 14 ) ; int n1 = 10 , n2 = 14 ; Node t = tree . lca ( tree . root , n1 , n2 ) ; System . out . println ( " LCA ▁ of ▁ " + n1 + " ▁ and ▁ " + n2 + " ▁ is ▁ " + t . data ) ; n1 = 14 ; n2 = 8 ; t = tree . lca ( tree . root , n1 , n2 ) ; System . out . println ( " LCA ▁ of ▁ " + n1 + " ▁ and ▁ " + n2 + " ▁ is ▁ " + t . data ) ; n1 = 10 ; n2 = 22 ; t = tree . lca ( tree . root , n1 , n2 ) ; System . out . println ( " LCA ▁ of ▁ " + n1 + " ▁ and ▁ " + n2 + " ▁ is ▁ " + t . data ) ; } }
class BinaryTree { boolean hasOnlyOneChild ( int pre [ ] , int size ) { int nextDiff , lastDiff ; for ( int i = 0 ; i < size - 1 ; i ++ ) { nextDiff = pre [ i ] - pre [ i + 1 ] ; lastDiff = pre [ i ] - pre [ size - 1 ] ; if ( nextDiff * lastDiff < 0 ) { return false ; } ; } return true ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; int pre [ ] = new int [ ] { 8 , 3 , 5 , 7 , 6 } ; int size = pre . length ; if ( tree . hasOnlyOneChild ( pre , size ) == true ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " No " ) ; } } }
class BinaryTree { boolean hasOnlyOneChild ( int pre [ ] , int size ) {
int min , max ; if ( pre [ size - 1 ] > pre [ size - 2 ] ) { max = pre [ size - 1 ] ; min = pre [ size - 2 ] ; } else { max = pre [ size - 2 ] ; min = pre [ size - 1 ] ; }
for ( int i = size - 3 ; i >= 0 ; i -- ) { if ( pre [ i ] < min ) { min = pre [ i ] ; } else if ( pre [ i ] > max ) { max = pre [ i ] ; } else { return false ; } } return true ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; int pre [ ] = new int [ ] { 8 , 3 , 5 , 7 , 6 } ; int size = pre . length ; if ( tree . hasOnlyOneChild ( pre , size ) == true ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " No " ) ; } } }
class Node { int data ; Node left , right , parent ; Node ( int d ) { data = d ; left = right = parent = null ; } } class BinaryTree { static Node head ;
Node insert ( Node node , int data ) {
if ( node == null ) { return ( new Node ( data ) ) ; } else { Node temp = null ;
if ( data <= node . data ) { temp = insert ( node . left , data ) ; node . left = temp ; temp . parent = node ; } else { temp = insert ( node . right , data ) ; node . right = temp ; temp . parent = node ; }
return node ; } } Node inOrderSuccessor ( Node root , Node n ) {
if ( n . right != null ) { return minValue ( n . right ) ; }
Node p = n . parent ; while ( p != null && n == p . right ) { n = p ; p = p . parent ; } return p ; }
Node minValue ( Node node ) { Node current = node ;
while ( current . left != null ) { current = current . left ; } return current ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; Node root = null , temp = null , suc = null , min = null ; root = tree . insert ( root , 20 ) ; root = tree . insert ( root , 8 ) ; root = tree . insert ( root , 22 ) ; root = tree . insert ( root , 4 ) ; root = tree . insert ( root , 12 ) ; root = tree . insert ( root , 10 ) ; root = tree . insert ( root , 14 ) ; temp = root . left . right . right ; suc = tree . inOrderSuccessor ( root , temp ) ; if ( suc != null ) { System . out . println ( " Inorder ▁ successor ▁ of ▁ " + temp . data + " ▁ is ▁ " + suc . data ) ; } else { System . out . println ( " Inorder ▁ successor ▁ does ▁ not ▁ exist " ) ; } } }
import java . util . * ; class GFG {
static class node { int key ; node left ; node right ; } ; static node head ; static node tail ;
static void convertBSTtoDLL ( node root ) {
if ( root == null ) return ;
if ( root . left != null ) convertBSTtoDLL ( root . left ) ;
root . left = tail ;
if ( tail != null ) ( tail ) . right = root ; else head = root ;
tail = root ;
if ( root . right != null ) convertBSTtoDLL ( root . right ) ; }
static boolean isPresentInDLL ( node head , node tail , int sum ) { while ( head != tail ) { int curr = head . key + tail . key ; if ( curr == sum ) return true ; else if ( curr > sum ) tail = tail . left ; else head = head . right ; } return false ; }
static boolean isTripletPresent ( node root ) {
if ( root == null ) return false ;
head = null ; tail = null ; convertBSTtoDLL ( root ) ;
while ( ( head . right != tail ) && ( head . key < 0 ) ) {
if ( isPresentInDLL ( head . right , tail , - 1 * head . key ) ) return true ; else head = head . right ; }
return false ; }
static node newNode ( int num ) { node temp = new node ( ) ; temp . key = num ; temp . left = temp . right = null ; return temp ; }
static node insert ( node root , int key ) { if ( root == null ) return newNode ( key ) ; if ( root . key > key ) root . left = insert ( root . left , key ) ; else root . right = insert ( root . right , key ) ; return root ; }
public static void main ( String [ ] args ) { node root = null ; root = insert ( root , 6 ) ; root = insert ( root , - 13 ) ; root = insert ( root , 14 ) ; root = insert ( root , - 8 ) ; root = insert ( root , 15 ) ; root = insert ( root , 13 ) ; root = insert ( root , 7 ) ; if ( isTripletPresent ( root ) ) System . out . print ( " Present " ) ; else System . out . print ( " Not ▁ Present " ) ; } }
import java . util . * ; class GFG { static final int MAX_SIZE = 100 ;
static class node { int val ; node left , right ; } ;
static class Stack { int size ; int top ; node [ ] array ; } ;
static Stack createStack ( int size ) { Stack stack = new Stack ( ) ; stack . size = size ; stack . top = - 1 ; stack . array = new node [ stack . size ] ; return stack ; }
static int isFull ( Stack stack ) { return ( stack . top - 1 == stack . size ) ? 1 : 0 ; } static int isEmpty ( Stack stack ) { return stack . top == - 1 ? 1 : 0 ; } static void push ( Stack stack , node node ) { if ( isFull ( stack ) == 1 ) return ; stack . array [ ++ stack . top ] = node ; } static node pop ( Stack stack ) { if ( isEmpty ( stack ) == 1 ) return null ; return stack . array [ stack . top -- ] ; }
static boolean isPairPresent ( node root , int target ) {
Stack s1 = createStack ( MAX_SIZE ) ; Stack s2 = createStack ( MAX_SIZE ) ;
boolean done1 = false , done2 = false ; int val1 = 0 , val2 = 0 ; node curr1 = root , curr2 = root ;
while ( true ) {
while ( done1 == false ) { if ( curr1 != null ) { push ( s1 , curr1 ) ; curr1 = curr1 . left ; } else { if ( isEmpty ( s1 ) == 1 ) done1 = true ; else { curr1 = pop ( s1 ) ; val1 = curr1 . val ; curr1 = curr1 . right ; done1 = true ; } } }
while ( done2 == false ) { if ( curr2 != null ) { push ( s2 , curr2 ) ; curr2 = curr2 . right ; } else { if ( isEmpty ( s2 ) == 1 ) done2 = true ; else { curr2 = pop ( s2 ) ; val2 = curr2 . val ; curr2 = curr2 . left ; done2 = true ; } } }
if ( ( val1 != val2 ) && ( val1 + val2 ) == target ) { System . out . print ( " Pair ▁ Found : ▁ " + val1 + " + ▁ " + val2 + " ▁ = ▁ " + target + "NEW_LINE"); return true ; }
else if ( ( val1 + val2 ) < target ) done1 = false ;
else if ( ( val1 + val2 ) > target ) done2 = false ;
if ( val1 >= val2 ) return false ; } }
static node NewNode ( int val ) { node tmp = new node ( ) ; tmp . val = val ; tmp . right = tmp . left = null ; return tmp ; }
public static void main ( String [ ] args ) {
node root = NewNode ( 15 ) ; root . left = NewNode ( 10 ) ; root . right = NewNode ( 20 ) ; root . left . left = NewNode ( 8 ) ; root . left . right = NewNode ( 12 ) ; root . right . left = NewNode ( 16 ) ; root . right . right = NewNode ( 25 ) ; int target = 33 ; if ( isPairPresent ( root , target ) == false ) System . out . print ( " No such values are found "); } }
public class fullbinarytreepostpre { static int preindex ;
static class node { int data ; node left , right ; public node ( int data ) { this . data = data ; } }
static node constructTreeUtil ( int pre [ ] , int post [ ] , int l , int h , int size ) {
if ( preindex >= size l > h ) return null ;
node root = new node ( pre [ preindex ] ) ; preindex ++ ;
if ( l == h preindex >= size ) return root ; int i ;
for ( i = l ; i <= h ; i ++ ) { if ( post [ i ] == pre [ preindex ] ) break ; }
if ( i <= h ) { root . left = constructTreeUtil ( pre , post , l , i , size ) ; root . right = constructTreeUtil ( pre , post , i + 1 , h , size ) ; } return root ; }
static node constructTree ( int pre [ ] , int post [ ] , int size ) { preindex = 0 ; return constructTreeUtil ( pre , post , 0 , size - 1 , size ) ; }
static void printInorder ( node root ) { if ( root == null ) return ; printInorder ( root . left ) ; System . out . print ( root . data + " ▁ " ) ; printInorder ( root . right ) ; }
public static void main ( String [ ] args ) { int pre [ ] = { 1 , 2 , 4 , 8 , 9 , 5 , 3 , 6 , 7 } ; int post [ ] = { 8 , 9 , 4 , 5 , 2 , 6 , 7 , 3 , 1 } ; int size = pre . length ; node root = constructTree ( pre , post , size ) ; System . out . println ( " Inorder ▁ traversal ▁ of ▁ the ▁ constructed ▁ tree : " ) ; printInorder ( root ) ; } }
class node { node left , right ; int data ;
boolean color ; node ( int data ) { this . data = data ; left = null ; right = null ;
color = true ; } } public class LLRBTREE { private static node root = null ;
node rotateLeft ( node myNode ) { System . out . printf ( "left rotation!!NEW_LINE"); node child = myNode . right ; node childLeft = child . left ; child . left = myNode ; myNode . right = childLeft ; return child ; }
node rotateRight ( node myNode ) { System . out . printf ( "right rotationNEW_LINE"); node child = myNode . left ; node childRight = child . right ; child . right = myNode ; myNode . left = childRight ; return child ; }
boolean isRed ( node myNode ) { if ( myNode == null ) return false ; return ( myNode . color == true ) ; }
void swapColors ( node node1 , node node2 ) { boolean temp = node1 . color ; node1 . color = node2 . color ; node2 . color = temp ; }
node insert ( node myNode , int data ) {
if ( myNode == null ) return new node ( data ) ; if ( data < myNode . data ) myNode . left = insert ( myNode . left , data ) ; else if ( data > myNode . data ) myNode . right = insert ( myNode . right , data ) ; else return myNode ;
if ( isRed ( myNode . right ) && ! isRed ( myNode . left ) ) {
myNode = rotateLeft ( myNode ) ;
swapColors ( myNode , myNode . left ) ; }
if ( isRed ( myNode . left ) && isRed ( myNode . left . left ) ) {
myNode = rotateRight ( myNode ) ; swapColors ( myNode , myNode . right ) ; }
if ( isRed ( myNode . left ) && isRed ( myNode . right ) ) {
myNode . color = ! myNode . color ;
myNode . left . color = false ; myNode . right . color = false ; } return myNode ; }
void inorder ( node node ) { if ( node != null ) { inorder ( node . left ) ; System . out . print ( node . data + " ▁ " ) ; inorder ( node . right ) ; } }
public static void main ( String [ ] args ) {
LLRBTREE node = new LLRBTREE ( ) ; root = node . insert ( root , 10 ) ;
root . color = false ; root = node . insert ( root , 20 ) ; root . color = false ; root = node . insert ( root , 30 ) ; root . color = false ; root = node . insert ( root , 40 ) ; root . color = false ; root = node . insert ( root , 50 ) ; root . color = false ; root = node . insert ( root , 25 ) ; root . color = false ;
node . inorder ( root ) ; } }
Node leftMost ( Node n ) { if ( n == null ) return null ; while ( n . left != null ) n = n . left ; return n ; }
static void inOrder ( Node root ) { Node cur = leftMost ( root ) ; while ( cur != null ) { System . out . printf ( " % d ▁ " , cur . data ) ;
if ( cur . rightThread ) cur = cur . right ;
else
cur = leftmost ( cur . right ) ; } }
class Node { int data ; Node left , right ; Node ( int d ) { data = d ; left = right = null ; } } class BinaryTree { Node root ;
int Ceil ( Node node , int input ) {
if ( node == null ) { return - 1 ; }
if ( node . data == input ) { return node . data ; }
if ( node . data < input ) { return Ceil ( node . right , input ) ; }
int ceil = Ceil ( node . left , input ) ; return ( ceil >= input ) ? ceil : node . data ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 8 ) ; tree . root . left = new Node ( 4 ) ; tree . root . right = new Node ( 12 ) ; tree . root . left . left = new Node ( 2 ) ; tree . root . left . right = new Node ( 6 ) ; tree . root . right . left = new Node ( 10 ) ; tree . root . right . right = new Node ( 14 ) ; for ( int i = 0 ; i < 16 ; i ++ ) { System . out . println ( i + " ▁ " + tree . Ceil ( tree . root , i ) ) ; } } }
class GFG { static class node { int key ; int count ; node left , right ; } ;
static node newNode ( int item ) { node temp = new node ( ) ; temp . key = item ; temp . left = temp . right = null ; temp . count = 1 ; return temp ; }
static void inorder ( node root ) { if ( root != null ) { inorder ( root . left ) ; System . out . print ( root . key + " ( " + root . count + " ) ▁ " ) ; inorder ( root . right ) ; } }
static node insert ( node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key == node . key ) { ( node . count ) ++ ; return node ; }
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
return node ; }
static node minValueNode ( node node ) { node current = node ;
while ( current . left != null ) current = current . left ; return current ; }
static node deleteNode ( node root , int key ) {
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . count > 1 ) { ( root . count ) -- ; return root ; }
if ( root . left == null ) { node temp = root . right ; root = null ; return temp ; } else if ( root . right == null ) { node temp = root . left ; root = null ; return temp ; }
node temp = minValueNode ( root . right ) ;
root . key = temp . key ;
root . right = deleteNode ( root . right , temp . key ) ; } return root ; }
public static void main ( String [ ] args ) {
node root = null ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 20 ) ; root = insert ( root , 9 ) ; root = insert ( root , 11 ) ; root = insert ( root , 10 ) ; root = insert ( root , 12 ) ; root = insert ( root , 12 ) ; System . out . print ( " Inorder ▁ traversal ▁ of ▁ " + " the ▁ given ▁ tree ▁ " + "NEW_LINE"); inorder ( root ) ; System . out . print ( " Delete 20 "); root = deleteNode ( root , 20 ) ; System . out . print ( " Inorder ▁ traversal ▁ of ▁ " + "the modified tree NEW_LINE"); inorder ( root ) ; System . out . print ( " Delete 12 "); root = deleteNode ( root , 12 ) ; System . out . print ( " Inorder ▁ traversal ▁ of ▁ " + "the modified tree NEW_LINE"); inorder ( root ) ; System . out . print ( " Delete 9 "); root = deleteNode ( root , 9 ) ; System . out . print ( " Inorder ▁ traversal ▁ of ▁ " + "the modified tree NEW_LINE"); inorder ( root ) ; } }
class GfG { static class node { int key ; node left , right ; } static node root = null ;
static node newNode ( int item ) { node temp = new node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; return temp ; }
static void inorder ( node root ) { if ( root != null ) { inorder ( root . left ) ; System . out . print ( root . key + " ▁ " ) ; inorder ( root . right ) ; } }
static node insert ( node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
return node ; }
static node minValueNode ( node Node ) { node current = Node ;
while ( current . left != null ) current = current . left ; return current ; }
static node deleteNode ( node root , int key ) {
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . left == null ) { node temp = root . right ; return temp ; } else if ( root . right == null ) { node temp = root . left ; return temp ; }
node temp = minValueNode ( root . right ) ;
root . key = temp . key ;
root . right = deleteNode ( root . right , temp . key ) ; } return root ; }
static node changeKey ( node root , int oldVal , int newVal ) {
root = deleteNode ( root , oldVal ) ;
root = insert ( root , newVal ) ;
return root ; }
public static void main ( String [ ] args ) {
root = insert ( root , 50 ) ; root = insert ( root , 30 ) ; root = insert ( root , 20 ) ; root = insert ( root , 40 ) ; root = insert ( root , 70 ) ; root = insert ( root , 60 ) ; root = insert ( root , 80 ) ; System . out . println ( " Inorder ▁ traversal ▁ of ▁ the ▁ given ▁ tree " ) ; inorder ( root ) ; root = changeKey ( root , 40 , 10 ) ;
System . out . println ( " Inorder traversal of the modified tree "); inorder ( root ) ; } }
class Node { int info ; Node left , right ; Node ( int d ) { info = d ; left = right = null ; } } class BinaryTree { static Node head ; static int count ;
Node insert ( Node node , int info ) {
if ( node == null ) { return ( new Node ( info ) ) ; } else {
if ( info <= node . info ) { node . left = insert ( node . left , info ) ; } else { node . right = insert ( node . right , info ) ; }
static int check ( int num ) { int sum = 0 , i = num , sum_of_digits , prod_of_digits ;
if ( num < 10 num > 99 ) return 0 ; else { sum_of_digits = ( i % 10 ) + ( i / 10 ) ; prod_of_digits = ( i % 10 ) * ( i / 10 ) ; sum = sum_of_digits + prod_of_digits ; } if ( sum == num ) return 1 ; else return 0 ; }
static void countSpecialDigit ( Node rt ) { int x ; if ( rt == null ) return ; else { x = check ( rt . info ) ; if ( x == 1 ) count = count + 1 ; countSpecialDigit ( rt . left ) ; countSpecialDigit ( rt . right ) ; } }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; Node root = null ; root = tree . insert ( root , 50 ) ; tree . insert ( root , 29 ) ; tree . insert ( root , 59 ) ; tree . insert ( root , 19 ) ; tree . insert ( root , 53 ) ; tree . insert ( root , 556 ) ; tree . insert ( root , 56 ) ; tree . insert ( root , 94 ) ; tree . insert ( root , 13 ) ;
countSpecialDigit ( root ) ; System . out . println ( count ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
Node buildTree ( int inorder [ ] , int start , int end , Node node ) { if ( start > end ) return null ;
int i = max ( inorder , start , end ) ;
node = new Node ( inorder [ i ] ) ;
if ( start == end ) return node ;
node . left = buildTree ( inorder , start , i - 1 , node . left ) ; node . right = buildTree ( inorder , i + 1 , end , node . right ) ; return node ; }
int max ( int arr [ ] , int strt , int end ) { int i , max = arr [ strt ] , maxind = strt ; for ( i = strt + 1 ; i <= end ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; maxind = i ; } } return maxind ; }
void printInorder ( Node node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
System . out . print ( node . data + " ▁ " ) ;
printInorder ( node . right ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ;
int inorder [ ] = new int [ ] { 5 , 10 , 40 , 30 , 28 } ; int len = inorder . length ; Node mynode = tree . buildTree ( inorder , 0 , len - 1 , tree . root ) ;
System . out . println ( " Inorder ▁ traversal ▁ of ▁ the ▁ constructed ▁ tree ▁ is ▁ " ) ; tree . printInorder ( mynode ) ; } }
import java . io . * ; class GFG {
static void fill0X ( int m , int n ) {
int i , k = 0 , l = 0 ;
int r = m , c = n ;
char a [ ] [ ] = new char [ m ] [ n ] ;
char x = ' X ' ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) a [ k ] [ i ] = x ; k ++ ;
for ( i = k ; i < m ; ++ i ) a [ i ] [ n - 1 ] = x ; n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = x ; m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) a [ i ] [ l ] = x ; l ++ ; }
x = ( x == '0' ) ? ' X ' : '0' ; }
for ( i = 0 ; i < r ; i ++ ) { for ( int j = 0 ; j < c ; j ++ ) System . out . print ( a [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { System . out . println ( " Output ▁ for ▁ m ▁ = ▁ 5 , ▁ n ▁ = ▁ 6" ) ; fill0X ( 5 , 6 ) ; System . out . println ( " Output ▁ for ▁ m ▁ = ▁ 4 , ▁ n ▁ = ▁ 4" ) ; fill0X ( 4 , 4 ) ; System . out . println ( " Output ▁ for ▁ m ▁ = ▁ 3 , ▁ n ▁ = ▁ 4" ) ; fill0X ( 3 , 4 ) ; } }
import java . io . * ; class GFG { public static int N = 3 ;
static void interchangeDiagonals ( int array [ ] [ ] ) {
for ( int i = 0 ; i < N ; ++ i ) if ( i != N / 2 ) { int temp = array [ i ] [ i ] ; array [ i ] [ i ] = array [ i ] [ N - i - 1 ] ; array [ i ] [ N - i - 1 ] = temp ; } for ( int i = 0 ; i < N ; ++ i ) { for ( int j = 0 ; j < N ; ++ j ) System . out . print ( array [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int array [ ] [ ] = { { 4 , 5 , 6 } , { 1 , 2 , 3 } , { 7 , 8 , 9 } } ; interchangeDiagonals ( array ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
Node bintree2listUtil ( Node node ) {
if ( node == null ) return node ;
if ( node . left != null ) {
Node left = bintree2listUtil ( node . left ) ;
for ( ; left . right != null ; left = left . right ) ;
left . right = node ;
node . left = left ; }
if ( node . right != null ) {
Node right = bintree2listUtil ( node . right ) ;
for ( ; right . left != null ; right = right . left ) ;
right . left = node ;
node . right = right ; } return node ; }
Node bintree2list ( Node node ) {
if ( node == null ) return node ;
node = bintree2listUtil ( node ) ;
while ( node . left != null ) node = node . left ; return node ; }
void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . right ; } }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 12 ) ; tree . root . right = new Node ( 15 ) ; tree . root . left . left = new Node ( 25 ) ; tree . root . left . right = new Node ( 30 ) ; tree . root . right . left = new Node ( 36 ) ;
Node head = tree . bintree2list ( tree . root ) ;
tree . printList ( head ) ; } }
public class BinaryTreeToDLL {
static class node { int data ; node left , right ; public node ( int data ) { this . data = data ; } } static node prev ;
static void inorder ( node root ) { if ( root == null ) return ; inorder ( root . left ) ; System . out . print ( root . data + " ▁ " ) ; inorder ( root . right ) ; }
static void fixPrevptr ( node root ) { if ( root == null ) return ; fixPrevptr ( root . left ) ; root . left = prev ; prev = root ; fixPrevptr ( root . right ) ; }
static node fixNextptr ( node root ) {
while ( root . right != null ) root = root . right ;
while ( root != null && root . left != null ) { node left = root . left ; left . right = root ; root = root . left ; }
return root ; }
static node BTTtoDLL ( node root ) { prev = null ;
fixPrevptr ( root ) ;
return fixNextptr ( root ) ; }
static void printlist ( node root ) { while ( root != null ) { System . out . print ( root . data + " ▁ " ) ; root = root . right ; } }
public static void main ( String [ ] args ) {
node root = new node ( 10 ) ; root . left = new node ( 12 ) ; root . right = new node ( 15 ) ; root . left . left = new node ( 25 ) ; root . left . right = new node ( 30 ) ; root . right . left = new node ( 36 ) ; System . out . println ( " Inorder ▁ Tree ▁ Traversal " ) ; inorder ( root ) ; node head = BTTtoDLL ( root ) ; System . out . println ( " DLL Traversal "); printlist ( head ) ; } }
class GFG {
static final int M = 4 ; static final int N = 5 ;
static int findCommon ( int mat [ ] [ ] ) {
int column [ ] = new int [ M ] ;
int min_row ;
int i ; for ( i = 0 ; i < M ; i ++ ) column [ i ] = N - 1 ;
min_row = 0 ;
while ( column [ min_row ] >= 0 ) {
for ( i = 0 ; i < M ; i ++ ) { if ( mat [ i ] [ column [ i ] ] < mat [ min_row ] [ column [ min_row ] ] ) min_row = i ; }
int eq_count = 0 ;
for ( i = 0 ; i < M ; i ++ ) {
if ( mat [ i ] [ column [ i ] ] > mat [ min_row ] [ column [ min_row ] ] ) { if ( column [ i ] == 0 ) return - 1 ;
column [ i ] -= 1 ; } else eq_count ++ ; }
if ( eq_count == M ) return mat [ min_row ] [ column [ min_row ] ] ; } return - 1 ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 , 4 , 5 } , { 2 , 4 , 5 , 8 , 10 } , { 3 , 5 , 7 , 9 , 11 } , { 1 , 3 , 5 , 7 , 9 } } ; int result = findCommon ( mat ) ; if ( result == - 1 ) System . out . print ( " No ▁ common ▁ element " ) ; else System . out . print ( " Common ▁ element ▁ is ▁ " + result ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
void convertTree ( Node node ) { int left_data = 0 , right_data = 0 , diff ;
if ( node == null || ( node . left == null && node . right == null ) ) return ; else {
convertTree ( node . left ) ; convertTree ( node . right ) ;
if ( node . left != null ) left_data = node . left . data ;
if ( node . right != null ) right_data = node . right . data ;
diff = left_data + right_data - node . data ;
if ( diff > 0 ) node . data = node . data + diff ;
if ( diff < 0 )
increment ( node , - diff ) ; } }
void increment ( Node node , int diff ) {
if ( node . left != null ) { node . left . data = node . left . data + diff ;
increment ( node . left , diff ) ; }
else if ( node . right != null ) { node . right . data = node . right . data + diff ;
increment ( node . right , diff ) ; } }
void printInorder ( Node node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
System . out . print ( node . data + " ▁ " ) ;
printInorder ( node . right ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 50 ) ; tree . root . left = new Node ( 7 ) ; tree . root . right = new Node ( 2 ) ; tree . root . left . left = new Node ( 3 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 1 ) ; tree . root . right . right = new Node ( 30 ) ; System . out . println ( " Inorder ▁ traversal ▁ before ▁ conversion ▁ is ▁ : " ) ; tree . printInorder ( tree . root ) ; tree . convertTree ( tree . root ) ; System . out . println ( " " ) ; System . out . println ( " Inorder ▁ traversal ▁ after ▁ conversion ▁ is ▁ : " ) ; tree . printInorder ( tree . root ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
int toSumTree ( Node node ) {
if ( node == null ) return 0 ;
int old_val = node . data ;
node . data = toSumTree ( node . left ) + toSumTree ( node . right ) ;
return node . data + old_val ; }
void printInorder ( Node node ) { if ( node == null ) return ; printInorder ( node . left ) ; System . out . print ( node . data + " ▁ " ) ; printInorder ( node . right ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 10 ) ; tree . root . left = new Node ( - 2 ) ; tree . root . right = new Node ( 6 ) ; tree . root . left . left = new Node ( 8 ) ; tree . root . left . right = new Node ( - 4 ) ; tree . root . right . left = new Node ( 7 ) ; tree . root . right . right = new Node ( 5 ) ; tree . toSumTree ( tree . root ) ;
System . out . println ( " Inorder ▁ Traversal ▁ of ▁ the ▁ resultant ▁ tree ▁ is : " ) ; tree . printInorder ( tree . root ) ; } }
