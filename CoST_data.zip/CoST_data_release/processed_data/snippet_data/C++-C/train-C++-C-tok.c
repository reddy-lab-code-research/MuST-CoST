#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #define bool  int NEW_LINE #define true  1 NEW_LINE #define false  0
struct node { int data ; struct node * left ; struct node * right ; } ;
bool IsFoldableUtil ( struct node * n1 , struct node * n2 ) ;
bool IsFoldable ( struct node * root ) { if ( root == NULL ) { return true ; } return IsFoldableUtil ( root -> left , root -> right ) ; }
bool IsFoldableUtil ( struct node * n1 , struct node * n2 ) {
if ( n1 == NULL && n2 == NULL ) { return true ; }
if ( n1 == NULL n2 == NULL ) { return false ; }
return IsFoldableUtil ( n1 -> left , n2 -> right ) && IsFoldableUtil ( n1 -> right , n2 -> left ) ; }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( void ) {
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> right = newNode ( 4 ) ; root -> right -> left = newNode ( 5 ) ; if ( IsFoldable ( root ) == true ) { printf ( " tree is foldable " } else { printf ( " tree is not foldable " } getchar ( ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
struct node { int data ; struct node * left , * right ; } ;
int updatetree ( node * root ) {
if ( ! root ) return 0 ; if ( root -> left == NULL && root -> right == NULL ) return root -> data ;
int leftsum = updatetree ( root -> left ) ; int rightsum = updatetree ( root -> right ) ;
root -> data += leftsum ;
return root -> data + rightsum ; }
void inorder ( struct node * node ) { if ( node == NULL ) return ; inorder ( node -> left ) ; printf ( " % d ▁ " , node -> data ) ; inorder ( node -> right ) ; }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( ) {
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; updatetree ( root ) ; cout << " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ is ▁ STRNEWLINE " ; inorder ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * left ; struct Node * right ; } ;
struct Node * newNode ( int data ) { struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
void mirror ( struct Node * node ) { if ( node == NULL ) return ; else { struct Node * temp ;
mirror ( node -> left ) ; mirror ( node -> right ) ;
temp = node -> left ; node -> left = node -> right ; node -> right = temp ; } }
void inOrder ( struct Node * node ) { if ( node == NULL ) return ; inOrder ( node -> left ) ; printf ( " % d ▁ " , node -> data ) ; inOrder ( node -> right ) ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ;
printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ constructed " " ▁ tree ▁ is ▁ STRNEWLINE " ) ; inOrder ( root ) ;
mirror ( root ) ;
printf ( " Inorder traversal of the mirror tree " ▁ " is " inOrder ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
int isSumProperty ( struct node * node ) {
int left_data = 0 , right_data = 0 ;
if ( node == NULL || ( node -> left == NULL && node -> right == NULL ) ) return 1 ; else {
if ( node -> left != NULL ) left_data = node -> left -> data ;
if ( node -> right != NULL ) right_data = node -> right -> data ;
if ( ( node -> data == left_data + right_data ) && isSumProperty ( node -> left ) && isSumProperty ( node -> right ) ) return 1 ; else return 0 ; } }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( ) { struct node * root = newNode ( 10 ) ; root -> left = newNode ( 8 ) ; root -> right = newNode ( 2 ) ; root -> left -> left = newNode ( 3 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 2 ) ; if ( isSumProperty ( root ) ) printf ( " The ▁ given ▁ tree ▁ satisfies ▁ the ▁ children ▁ sum ▁ property ▁ " ) ; else printf ( " The ▁ given ▁ tree ▁ does ▁ not ▁ satisfy ▁ the ▁ children ▁ sum ▁ property ▁ " ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * left , * right ; } ;
struct Node * newNode ( int data ) { struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return node ; }
bool checkUtil ( struct Node * root , int level , int * leafLevel ) {
if ( root == NULL ) return true ;
if ( root -> left == NULL && root -> right == NULL ) {
if ( * leafLevel == 0 ) {
* leafLevel = level ; return true ; }
return ( level == * leafLevel ) ; }
return checkUtil ( root -> left , level + 1 , leafLevel ) && checkUtil ( root -> right , level + 1 , leafLevel ) ; }
bool check ( struct Node * root ) { int level = 0 , leafLevel = 0 ; return checkUtil ( root , level , & leafLevel ) ; }
int main ( ) {
struct Node * root = newNode ( 12 ) ; root -> left = newNode ( 5 ) ; root -> left -> left = newNode ( 3 ) ; root -> left -> right = newNode ( 9 ) ; root -> left -> left -> left = newNode ( 1 ) ; root -> left -> right -> left = newNode ( 1 ) ; if ( check ( root ) ) printf ( " Leaves ▁ are ▁ at ▁ same ▁ level STRNEWLINE " ) ; else printf ( " Leaves ▁ are ▁ not ▁ at ▁ same ▁ level STRNEWLINE " ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #include <stdbool.h>
struct Node { int key ; struct Node * left , * right ; } ;
struct Node * newNode ( char k ) { struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; node -> key = k ; node -> right = node -> left = NULL ; return node ; }
bool isFullTree ( struct Node * root ) {
if ( root == NULL ) return true ;
if ( root -> left == NULL && root -> right == NULL ) return true ;
if ( ( root -> left ) && ( root -> right ) ) return ( isFullTree ( root -> left ) && isFullTree ( root -> right ) ) ;
return false ; }
int main ( ) { struct Node * root = NULL ; root = newNode ( 10 ) ; root -> left = newNode ( 20 ) ; root -> right = newNode ( 30 ) ; root -> left -> right = newNode ( 40 ) ; root -> left -> left = newNode ( 50 ) ; root -> right -> left = newNode ( 60 ) ; root -> right -> right = newNode ( 70 ) ; root -> left -> left -> left = newNode ( 80 ) ; root -> left -> left -> right = newNode ( 90 ) ; root -> left -> right -> left = newNode ( 80 ) ; root -> left -> right -> right = newNode ( 90 ) ; root -> right -> left -> left = newNode ( 80 ) ; root -> right -> left -> right = newNode ( 90 ) ; root -> right -> right -> left = newNode ( 80 ) ; root -> right -> right -> right = newNode ( 90 ) ; if ( isFullTree ( root ) ) printf ( " The ▁ Binary ▁ Tree ▁ is ▁ full STRNEWLINE " ) ; else printf ( " The ▁ Binary ▁ Tree ▁ is ▁ not ▁ full STRNEWLINE " ) ; return ( 0 ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int identicalTrees ( struct node * a , struct node * b ) {
if ( a == NULL && b == NULL ) return 1 ;
if ( a != NULL && b != NULL ) { return ( a -> data == b -> data && identicalTrees ( a -> left , b -> left ) && identicalTrees ( a -> right , b -> right ) ) ; }
return 0 ; }
int main ( ) { struct node * root1 = newNode ( 1 ) ; struct node * root2 = newNode ( 1 ) ; root1 -> left = newNode ( 2 ) ; root1 -> right = newNode ( 3 ) ; root1 -> left -> left = newNode ( 4 ) ; root1 -> left -> right = newNode ( 5 ) ; root2 -> left = newNode ( 2 ) ; root2 -> right = newNode ( 3 ) ; root2 -> left -> left = newNode ( 4 ) ; root2 -> left -> right = newNode ( 5 ) ; if ( identicalTrees ( root1 , root2 ) ) printf ( " Both ▁ tree ▁ are ▁ identical . " ) ; else printf ( " Trees ▁ are ▁ not ▁ identical . " ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; Node * left , * right ; } ;
Node * newNode ( int item ) { Node * temp = new Node ; temp -> data = item ; temp -> left = temp -> right = NULL ; return temp ; }
int getLevel ( Node * root , Node * node , int level ) {
if ( root == NULL ) return 0 ; if ( root == node ) return level ;
int downlevel = getLevel ( root -> left , node , level + 1 ) ; if ( downlevel != 0 ) return downlevel ;
return getLevel ( root -> right , node , level + 1 ) ; }
void printGivenLevel ( Node * root , Node * node , int level ) {
if ( root == NULL level < 2 ) return ;
if ( level == 2 ) { if ( root -> left == node root -> right == node ) return ; if ( root -> left ) printf ( " % d ▁ " , root -> left -> data ) ; if ( root -> right ) printf ( " % d ▁ " , root -> right -> data ) ; }
else if ( level > 2 ) { printGivenLevel ( root -> left , node , level - 1 ) ; printGivenLevel ( root -> right , node , level - 1 ) ; } }
void printCousins ( Node * root , Node * node ) {
int level = getLevel ( root , node , 1 ) ;
printGivenLevel ( root , node , level ) ; }
int main ( ) { Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> left -> right -> right = newNode ( 15 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> right -> left -> right = newNode ( 8 ) ; printCousins ( root , root -> left -> right ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
void printArray ( int [ ] , int ) ; void printPathsRecur ( struct node * , int [ ] , int ) ; struct node * newNode ( int ) ; void printPaths ( struct node * ) ;
void printPaths ( struct node * node ) { int path [ 1000 ] ; printPathsRecur ( node , path , 0 ) ; }
void printPathsRecur ( struct node * node , int path [ ] , int pathLen ) { if ( node == NULL ) return ;
path [ pathLen ] = node -> data ; pathLen ++ ;
if ( node -> left == NULL && node -> right == NULL ) { printArray ( path , pathLen ) ; } else {
printPathsRecur ( node -> left , path , pathLen ) ; printPathsRecur ( node -> right , path , pathLen ) ; } }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
void printArray ( int ints [ ] , int len ) { int i ; for ( i = 0 ; i < len ; i ++ ) { printf ( " % d ▁ " , ints [ i ] ) ; } printf ( " STRNEWLINE " ) ; }
int main ( ) { struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ;
printPaths ( root ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE int main ( ) {
int arr [ 10 ] ;
arr [ 0 ] = 5 ;
printf ( " % d " , arr [ 0 ] ) ; return 0 ; }
#include <stdio.h>
void printArray ( int arr [ ] , int size ) ; void swap ( int arr [ ] , int fi , int si , int d ) ; void leftRotate ( int arr [ ] , int d , int n ) {
if ( d == 0 d == n ) return ;
if ( n - d == d ) { swap ( arr , 0 , n - d , d ) ; return ; }
if ( d < n - d ) { swap ( arr , 0 , n - d , d ) ; leftRotate ( arr , d , n - d ) ; }
else { swap ( arr , 0 , d , n - d ) ; leftRotate ( arr + n - d , 2 * d - n , d ) ; } }
void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; printf ( " STRNEWLINE ▁ " ) ; }
void swap ( int arr [ ] , int fi , int si , int d ) { int i , temp ; for ( i = 0 ; i < d ; i ++ ) { temp = arr [ fi + i ] ; arr [ fi + i ] = arr [ si + i ] ; arr [ si + i ] = temp ; } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; leftRotate ( arr , 2 , 7 ) ; printArray ( arr , 7 ) ; getchar ( ) ; return 0 ; }
void leftRotate ( int arr [ ] , int d , int n ) { int i , j ; if ( d == 0 d == n ) return ; i = d ; j = n - d ; while ( i != j ) {
if ( i < j ) { swap ( arr , d - i , d + j - i , i ) ; j -= i ; }
else { swap ( arr , d - i , d , j ) ; i -= j ; } }
swap ( arr , d - i , d , i ) ; }
#include <stdio.h>
void rotate ( int arr [ ] , int n ) { int i = 0 , j = n - 1 ; while ( i != j ) { swap ( & arr [ i ] , & arr [ j ] ) ; i ++ ; } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } , i ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Given ▁ array ▁ is STRNEWLINE " ) ; for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; rotate ( arr , n ) ; printf ( " Rotated array is " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; return 0 ; }
#include <stdio.h>
void rearrangeNaive ( int arr [ ] , int n ) {
int temp [ n ] , i ;
for ( i = 0 ; i < n ; i ++ ) temp [ arr [ i ] ] = i ;
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
void printArray ( int arr [ ] , int n ) { int i ; for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; printf ( " STRNEWLINE " ) ; }
int main ( ) { int arr [ ] = { 1 , 3 , 0 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Given ▁ array ▁ is ▁ STRNEWLINE " ) ; printArray ( arr , n ) ; rearrangeNaive ( arr , n ) ; printf ( " Modified ▁ array ▁ is ▁ STRNEWLINE " ) ; printArray ( arr , n ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
void printPostorder ( struct node * node ) { if ( node == NULL ) return ;
printPostorder ( node -> left ) ;
printPostorder ( node -> right ) ;
printf ( " % d ▁ " , node -> data ) ; }
void printInorder ( struct node * node ) { if ( node == NULL ) return ;
printInorder ( node -> left ) ;
printf ( " % d ▁ " , node -> data ) ;
printInorder ( node -> right ) ; }
void printPreorder ( struct node * node ) { if ( node == NULL ) return ;
printf ( " % d ▁ " , node -> data ) ;
printPreorder ( node -> left ) ;
printPreorder ( node -> right ) ; }
int main ( ) { struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; printf ( " Preorder traversal of binary tree is " printPreorder ( root ) ; printf ( " Inorder traversal of binary tree is " printInorder ( root ) ; printf ( " Postorder traversal of binary tree is " printPostorder ( root ) ; getchar ( ) ; return 0 ; }
#include <stdio.h>
int largest ( int arr [ ] , int n ) { int i ;
int max = arr [ 0 ] ;
for ( i = 1 ; i < n ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
int main ( ) { int arr [ ] = { 10 , 324 , 45 , 90 , 9808 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Largest ▁ in ▁ given ▁ array ▁ is ▁ % d " , largest ( arr , n ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE struct pair { int min ; int max ; } ; struct pair getMinMax ( int arr [ ] , int n ) { struct pair minmax ; int i ;
if ( n == 1 ) { minmax . max = arr [ 0 ] ; minmax . min = arr [ 0 ] ; return minmax ; }
if ( arr [ 0 ] > arr [ 1 ] ) { minmax . max = arr [ 0 ] ; minmax . min = arr [ 1 ] ; } else { minmax . max = arr [ 1 ] ; minmax . min = arr [ 0 ] ; } for ( i = 2 ; i < n ; i ++ ) { if ( arr [ i ] > minmax . max ) minmax . max = arr [ i ] ; else if ( arr [ i ] < minmax . min ) minmax . min = arr [ i ] ; } return minmax ; }
int main ( ) { int arr [ ] = { 1000 , 11 , 445 , 1 , 330 , 3000 } ; int arr_size = 6 ; struct pair minmax = getMinMax ( arr , arr_size ) ; printf ( " nMinimum ▁ element ▁ is ▁ % d " , minmax . min ) ; printf ( " nMaximum ▁ element ▁ is ▁ % d " , minmax . max ) ; getchar ( ) ; }
#include <stdio.h>
struct pair { int min ; int max ; } ; struct pair getMinMax ( int arr [ ] , int n ) { struct pair minmax ; int i ;
if ( n % 2 == 0 ) { if ( arr [ 0 ] > arr [ 1 ] ) { minmax . max = arr [ 0 ] ; minmax . min = arr [ 1 ] ; } else { minmax . min = arr [ 0 ] ; minmax . max = arr [ 1 ] ; }
i = 2 ; }
else { minmax . min = arr [ 0 ] ; minmax . max = arr [ 0 ] ;
i = 1 ; }
while ( i < n - 1 ) { if ( arr [ i ] > arr [ i + 1 ] ) { if ( arr [ i ] > minmax . max ) minmax . max = arr [ i ] ; if ( arr [ i + 1 ] < minmax . min ) minmax . min = arr [ i + 1 ] ; } else { if ( arr [ i + 1 ] > minmax . max ) minmax . max = arr [ i + 1 ] ; if ( arr [ i ] < minmax . min ) minmax . min = arr [ i ] ; } i += 2 ;
} return minmax ; }
int main ( ) { int arr [ ] = { 1000 , 11 , 445 , 1 , 330 , 3000 } ; int arr_size = 6 ; struct pair minmax = getMinMax ( arr , arr_size ) ; printf ( " nMinimum ▁ element ▁ is ▁ % d " , minmax . min ) ; printf ( " nMaximum ▁ element ▁ is ▁ % d " , minmax . max ) ; getchar ( ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * left , * right ; } ;
struct Node * newNode ( int data ) { struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return node ; }
void print ( struct Node * root ) { if ( root != NULL ) { print ( root -> left ) ; printf ( " % d ▁ " , root -> data ) ; print ( root -> right ) ; } }
struct Node * prune ( struct Node * root , int sum ) {
if ( root == NULL ) return NULL ;
root -> left = prune ( root -> left , sum - root -> data ) ; root -> right = prune ( root -> right , sum - root -> data ) ;
if ( root -> left == NULL && root -> right == NULL ) { if ( root -> data < sum ) { free ( root ) ; return NULL ; } } return root ; }
int main ( ) { int k = 45 ; struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> left -> left -> left = newNode ( 8 ) ; root -> left -> left -> right = newNode ( 9 ) ; root -> left -> right -> left = newNode ( 12 ) ; root -> right -> right -> left = newNode ( 10 ) ; root -> right -> right -> left -> right = newNode ( 11 ) ; root -> left -> left -> right -> left = newNode ( 13 ) ; root -> left -> left -> right -> right = newNode ( 14 ) ; root -> left -> left -> right -> right -> left = newNode ( 15 ) ; printf ( " Tree ▁ before ▁ truncation STRNEWLINE " ) ; print ( root ) ;
#include <limits.h> NEW_LINE #include <stdbool.h> NEW_LINE #include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
bool printPath ( struct node * root , struct node * target_leaf ) {
if ( root == NULL ) return false ;
if ( root == target_leaf || printPath ( root -> left , target_leaf ) || printPath ( root -> right , target_leaf ) ) { printf ( " % d ▁ " , root -> data ) ; return true ; } return false ; }
void getTargetLeaf ( struct node * node , int * max_sum_ref , int curr_sum , struct node * * target_leaf_ref ) { if ( node == NULL ) return ;
curr_sum = curr_sum + node -> data ;
if ( node -> left == NULL && node -> right == NULL ) { if ( curr_sum > * max_sum_ref ) { * max_sum_ref = curr_sum ; * target_leaf_ref = node ; } }
getTargetLeaf ( node -> left , max_sum_ref , curr_sum , target_leaf_ref ) ; getTargetLeaf ( node -> right , max_sum_ref , curr_sum , target_leaf_ref ) ; }
int maxSumPath ( struct node * node ) {
if ( node == NULL ) return 0 ; struct node * target_leaf ; int max_sum = INT_MIN ;
getTargetLeaf ( node , & max_sum , 0 , & target_leaf ) ;
printPath ( node , target_leaf ) ;
return max_sum ; }
struct node * newNode ( int data ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = data ; temp -> left = NULL ; temp -> right = NULL ; return temp ; }
int main ( ) { struct node * root = NULL ; root = newNode ( 10 ) ; root -> left = newNode ( -2 ) ; root -> right = newNode ( 7 ) ; root -> left -> left = newNode ( 8 ) ; root -> left -> right = newNode ( -4 ) ; printf ( " Following ▁ are ▁ the ▁ nodes ▁ on ▁ the ▁ maximum ▁ " " sum ▁ path ▁ STRNEWLINE " ) ; int sum = maxSumPath ( root ) ; printf ( " Sum of the nodes is % d " , sum ) ; getchar ( ) ; return 0 ; }
#include <stdio.h>
void printUnion ( int arr1 [ ] , int arr2 [ ] , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) printf ( " ▁ % d ▁ " , arr1 [ i ++ ] ) ; else if ( arr2 [ j ] < arr1 [ i ] ) printf ( " ▁ % d ▁ " , arr2 [ j ++ ] ) ; else { printf ( " ▁ % d ▁ " , arr2 [ j ++ ] ) ; i ++ ; } }
while ( i < m ) printf ( " ▁ % d ▁ " , arr1 [ i ++ ] ) ; while ( j < n ) printf ( " ▁ % d ▁ " , arr2 [ j ++ ] ) ; }
int main ( ) { int arr1 [ ] = { 1 , 2 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 5 , 7 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; printUnion ( arr1 , arr2 , m , n ) ; getchar ( ) ; return 0 ; }
#include <stdio.h>
void printIntersection ( int arr1 [ ] , int arr2 [ ] , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) i ++ ; else if ( arr2 [ j ] < arr1 [ i ] ) j ++ ; else { printf ( " ▁ % d ▁ " , arr2 [ j ++ ] ) ; i ++ ; } } }
int main ( ) { int arr1 [ ] = { 1 , 2 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 5 , 7 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ;
printIntersection ( arr1 , arr2 , m , n ) ; getchar ( ) ; return 0 ; }
#include <stdio.h>
int insertSorted ( int arr [ ] , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; arr [ n ] = key ; return ( n + 1 ) ; }
int main ( ) { int arr [ 20 ] = { 12 , 16 , 20 , 40 , 50 , 70 } ; int capacity = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int n = 6 ; int i , key = 26 ; printf ( " Before Insertion : " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ;
n = insertSorted ( arr , n , key , capacity ) ; printf ( " After Insertion : " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; return 0 ; }
#include <stdio.h>
int findElement ( int arr [ ] , int n , int key ) { int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
int deleteElement ( int arr [ ] , int n , int key ) {
int pos = findElement ( arr , n , key ) ; if ( pos == - 1 ) { printf ( " Element ▁ not ▁ found " ) ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
int main ( ) { int i ; int arr [ ] = { 10 , 50 , 30 , 40 , 20 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int key = 30 ; printf ( " Array ▁ before ▁ deletion STRNEWLINE " ) ; for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; n = deleteElement ( arr , n , key ) ; printf ( " Array after deletion " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; return 0 ; }
#include <stdio.h>
int insertSorted ( int arr [ ] , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; int i ; for ( i = n - 1 ; ( i >= 0 && arr [ i ] > key ) ; i -- ) arr [ i + 1 ] = arr [ i ] ; arr [ i + 1 ] = key ; return ( n + 1 ) ; }
int main ( ) { int arr [ 20 ] = { 12 , 16 , 20 , 40 , 50 , 70 } ; int capacity = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int n = 6 ; int i , key = 26 ; printf ( " Before Insertion : " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ;
n = insertSorted ( arr , n , key , capacity ) ; printf ( " After Insertion : " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; return 0 ; }
#include <stdio.h>
int binarySearch ( int arr [ ] , int low , int high , int key ) ; int binarySearch ( int arr [ ] , int low , int high , int key ) { if ( high < low ) return -1 ; int mid = ( low + high ) / 2 ; if ( key == arr [ mid ] ) return mid ; if ( key > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , key ) ; return binarySearch ( arr , low , ( mid - 1 ) , key ) ; }
int deleteElement ( int arr [ ] , int n , int key ) {
int pos = binarySearch ( arr , 0 , n - 1 , key ) ; if ( pos == -1 ) { printf ( " Element ▁ not ▁ found " ) ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
int main ( ) { int i ; int arr [ ] = { 10 , 20 , 30 , 40 , 50 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int key = 30 ; printf ( " Array ▁ before ▁ deletion STRNEWLINE " ) ; for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; n = deleteElement ( arr , n , key ) ; printf ( " Array after deletion " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; }
# include <stdio.h> NEW_LINE # include <stdbool.h>
int _binarySearch ( int arr [ ] , int low , int high , int x ) { if ( high >= low ) { int mid = ( low + high ) / 2 ;
if ( ( mid == 0 x > arr [ mid - 1 ] ) && ( arr [ mid ] == x ) ) return mid ; else if ( x > arr [ mid ] ) return _binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return _binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return -1 ; }
bool isMajority ( int arr [ ] , int n , int x ) {
int i = _binarySearch ( arr , 0 , n - 1 , x ) ;
if ( i == -1 ) return false ;
if ( ( ( i + n / 2 ) <= ( n - 1 ) ) && arr [ i + n / 2 ] == x ) return true ; else return false ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 3 ; if ( isMajority ( arr , n , x ) ) printf ( " % d ▁ appears ▁ more ▁ than ▁ % d ▁ times ▁ in ▁ arr [ ] " , x , n / 2 ) ; else printf ( " % d ▁ does ▁ not ▁ appear ▁ more ▁ than ▁ % d ▁ times ▁ in ▁ arr [ ] " , x , n / 2 ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdbool.h> NEW_LINE bool isMajorityElement ( int arr [ ] , int n , int key ) { if ( arr [ n / 2 ] == key ) return true ; else return false ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 3 ; if ( isMajorityElement ( arr , n , x ) ) printf ( " % d ▁ appears ▁ more ▁ than ▁ % d ▁ times ▁ in ▁ arr [ ] " , x , n / 2 ) ; else printf ( " % d ▁ does ▁ not ▁ appear ▁ more ▁ than ▁ % d ▁ times ▁ in ▁ " " arr [ ] " , x , n / 2 ) ; return 0 ; }
#include <stdio.h> NEW_LINE int isPairSum ( int A [ ] , int N , int X ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
if ( i == j ) continue ;
if ( A [ i ] + A [ j ] == X ) return true ;
if ( A [ i ] + A [ j ] > X ) break ; } }
return 0 ; }
int main ( ) { int arr [ ] = { 3 , 5 , 9 , 2 , 8 , 10 , 11 } ; int val = 17 ; int arrSize = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
printf ( " % d " , isPairSum ( arr , arrSize , val ) ) ; return 0 ; }
#include <stdio.h>
int isPairSum ( int A [ ] , int N , int X ) {
int i = 0 ;
int j = N - 1 ; while ( i < j ) {
if ( A [ i ] + A [ j ] == X ) return 1 ;
else if ( A [ i ] + A [ j ] < X ) i ++ ;
else j -- ; } return 0 ; }
int main ( ) {
int arr [ ] = { 3 , 5 , 9 , 2 , 8 , 10 , 11 } ;
int val = 17 ;
int arrSize = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
printf ( " % d " , isPairSum ( arr , arrSize , val ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left , * right ; } ;
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
int getLevelDiff ( struct node * root ) {
if ( root == NULL ) return 0 ;
return root -> data - getLevelDiff ( root -> left ) - getLevelDiff ( root -> right ) ; }
int main ( ) { struct node * root = newNode ( 5 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 6 ) ; root -> left -> left = newNode ( 1 ) ; root -> left -> right = newNode ( 4 ) ; root -> left -> right -> left = newNode ( 3 ) ; root -> right -> right = newNode ( 8 ) ; root -> right -> right -> right = newNode ( 9 ) ; root -> right -> right -> left = newNode ( 7 ) ; printf ( " % d ▁ is ▁ the ▁ required ▁ difference STRNEWLINE " , getLevelDiff ( root ) ) ; getchar ( ) ; return 0 ; }
#include <stdio.h>
int search ( int arr [ ] , int n , int x ) { int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == x ) return i ; } return -1 ; }
int main ( ) { int arr [ ] = { 1 , 10 , 30 , 15 } ; int x = 30 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " % d ▁ is ▁ present ▁ at ▁ index ▁ % d " , x , search ( arr , n , x ) ) ; getchar ( ) ; return 0 ; }
#include <stdio.h>
int binarySearch ( int arr [ ] , int l , int r , int x ) { while ( l <= r ) { int m = l + ( r - l ) / 2 ;
if ( arr [ m ] == x ) return m ;
if ( arr [ m ] < x ) l = m + 1 ;
else r = m - 1 ; }
return -1 ; }
int main ( void ) { int arr [ ] = { 2 , 3 , 4 , 10 , 40 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 10 ; int result = binarySearch ( arr , 0 , n - 1 , x ) ; ( result == -1 ) ? printf ( " Element ▁ is ▁ not ▁ present " " ▁ in ▁ array " ) : printf ( " Element ▁ is ▁ present ▁ at ▁ " " index ▁ % d " , result ) ; return 0 ; }
#include <stdio.h>
int interpolationSearch ( int arr [ ] , int lo , int hi , int x ) { int pos ;
if ( lo <= hi && x >= arr [ lo ] && x <= arr [ hi ] ) {
pos = lo + ( ( ( double ) ( hi - lo ) / ( arr [ hi ] - arr [ lo ] ) ) * ( x - arr [ lo ] ) ) ;
if ( arr [ pos ] == x ) return pos ;
if ( arr [ pos ] < x ) return interpolationSearch ( arr , pos + 1 , hi , x ) ;
if ( arr [ pos ] > x ) return interpolationSearch ( arr , lo , pos - 1 , x ) ; } return -1 ; }
int main ( ) {
int arr [ ] = { 10 , 12 , 13 , 16 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 33 , 35 , 42 , 47 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
int x = 18 ; int index = interpolationSearch ( arr , 0 , n - 1 , x ) ;
if ( index != -1 ) printf ( " Element ▁ found ▁ at ▁ index ▁ % d " , index ) ; else printf ( " Element ▁ not ▁ found . " ) ; return 0 ; }
#include <stdio.h>
void swap ( int * xp , int * yp ) { int temp = * xp ; * xp = * yp ; * yp = temp ; }
void selectionSort ( int arr [ ] , int n ) { int i , j , min_idx ;
for ( i = 0 ; i < n - 1 ; i ++ ) {
min_idx = i ; for ( j = i + 1 ; j < n ; j ++ ) if ( arr [ j ] < arr [ min_idx ] ) min_idx = j ;
swap ( & arr [ min_idx ] , & arr [ i ] ) ; } }
void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; printf ( " STRNEWLINE " ) ; }
int main ( ) { int arr [ ] = { 64 , 25 , 12 , 22 , 11 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; selectionSort ( arr , n ) ; printf ( " Sorted ▁ array : ▁ STRNEWLINE " ) ; printArray ( arr , n ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
void merge ( int arr [ ] , int l , int m , int r ) { int i , j , k ;
int n1 = m - l + 1 ; int n2 = r - m ;
int L [ n1 ] , R [ n2 ] ;
for ( i = 0 ; i < n1 ; i ++ ) L [ i ] = arr [ l + i ] ; for ( j = 0 ; j < n2 ; j ++ ) R [ j ] = arr [ m + 1 + j ] ;
i = 0 ; j = 0 ;
k = l ; while ( i < n1 && j < n2 ) { if ( L [ i ] <= R [ j ] ) { arr [ k ] = L [ i ] ; i ++ ; } else { arr [ k ] = R [ j ] ; j ++ ; } k ++ ; }
while ( i < n1 ) { arr [ k ] = L [ i ] ; i ++ ; k ++ ; }
while ( j < n2 ) { arr [ k ] = R [ j ] ; j ++ ; k ++ ; } }
void mergeSort ( int arr [ ] , int l , int r ) { if ( l < r ) {
int m = l + ( r - l ) / 2 ;
mergeSort ( arr , l , m ) ; mergeSort ( arr , m + 1 , r ) ;
merge ( arr , l , m , r ) ; } }
void printArray ( int A [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) printf ( " % d ▁ " , A [ i ] ) ; printf ( " STRNEWLINE " ) ; }
int main ( ) { int arr [ ] = { 12 , 11 , 13 , 5 , 6 , 7 } ; int arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Given ▁ array ▁ is ▁ STRNEWLINE " ) ; printArray ( arr , arr_size ) ; mergeSort ( arr , 0 , arr_size - 1 ) ; printf ( " Sorted array is " printArray ( arr , arr_size ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #define bool  int
struct node { int data ; struct node * left ; struct node * right ; } ;
bool hasPathSum ( struct node * node , int sum ) { if ( node == NULL ) { return ( sum == 0 ) ; } else { bool ans = 0 ; int subSum = sum - node -> data ; if ( subSum == 0 && node -> left == NULL && node -> right == NULL ) return 1 ; if ( node -> left ) ans = ans || hasPathSum ( node -> left , subSum ) ; if ( node -> right ) ans = ans || hasPathSum ( node -> right , subSum ) ; return ans ; } }
struct node * newnode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( ) { int sum = 21 ;
struct node * root = newnode ( 10 ) ; root -> left = newnode ( 8 ) ; root -> right = newnode ( 2 ) ; root -> left -> left = newnode ( 3 ) ; root -> left -> right = newnode ( 5 ) ; root -> right -> left = newnode ( 2 ) ; if ( hasPathSum ( root , sum ) ) printf ( " There ▁ is ▁ a ▁ root - to - leaf ▁ path ▁ with ▁ sum ▁ % d " , sum ) ; else printf ( " There ▁ is ▁ no ▁ root - to - leaf ▁ path ▁ with ▁ sum ▁ % d " , sum ) ; getchar ( ) ; return 0 ; }
#include <stdio.h>
void swap ( int * a , int * b ) { int t = * a ; * a = * b ; * b = t ; }
int partition ( int arr [ ] , int l , int h ) { int x = arr [ h ] ; int i = ( l - 1 ) ; for ( int j = l ; j <= h - 1 ; j ++ ) { if ( arr [ j ] <= x ) { i ++ ; swap ( & arr [ i ] , & arr [ j ] ) ; } } swap ( & arr [ i + 1 ] , & arr [ h ] ) ; return ( i + 1 ) ; }
void quickSortIterative ( int arr [ ] , int l , int h ) {
int stack [ h - l + 1 ] ;
int top = -1 ;
stack [ ++ top ] = l ; stack [ ++ top ] = h ;
while ( top >= 0 ) {
h = stack [ top -- ] ; l = stack [ top -- ] ;
int p = partition ( arr , l , h ) ;
if ( p - 1 > l ) { stack [ ++ top ] = l ; stack [ ++ top ] = p - 1 ; }
if ( p + 1 < h ) { stack [ ++ top ] = p + 1 ; stack [ ++ top ] = h ; } } }
void printArr ( int arr [ ] , int n ) { int i ; for ( i = 0 ; i < n ; ++ i ) printf ( " % d ▁ " , arr [ i ] ) ; }
int main ( ) { int arr [ ] = { 4 , 3 , 5 , 2 , 1 , 3 , 2 , 3 } ; int n = sizeof ( arr ) / sizeof ( * arr ) ;
quickSortIterative ( arr , 0 , n - 1 ) ; printArr ( arr , n ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int data ; struct node * left , * right ; } ;
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
int treePathsSumUtil ( struct node * root , int val ) {
if ( root == NULL ) return 0 ;
val = ( val * 10 + root -> data ) ;
if ( root -> left == NULL && root -> right == NULL ) return val ;
return treePathsSumUtil ( root -> left , val ) + treePathsSumUtil ( root -> right , val ) ; }
int treePathsSum ( struct node * root ) {
return treePathsSumUtil ( root , 0 ) ; }
int main ( ) { struct node * root = newNode ( 6 ) ; root -> left = newNode ( 3 ) ; root -> right = newNode ( 5 ) ; root -> left -> left = newNode ( 2 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 4 ) ; root -> left -> right -> left = newNode ( 7 ) ; root -> left -> right -> right = newNode ( 4 ) ; printf ( " Sum ▁ of ▁ all ▁ paths ▁ is ▁ % d " , treePathsSum ( root ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
#define MAX_TREE_HT  100
struct QueueNode { char data ; unsigned freq ; struct QueueNode * left , * right ; } ;
struct Queue { int front , rear ; int capacity ; struct QueueNode * * array ; } ;
struct QueueNode * newNode ( char data , unsigned freq ) { struct QueueNode * temp = ( struct QueueNode * ) malloc ( sizeof ( struct QueueNode ) ) ; temp -> left = temp -> right = NULL ; temp -> data = data ; temp -> freq = freq ; return temp ; }
struct Queue * createQueue ( int capacity ) { struct Queue * queue = ( struct Queue * ) malloc ( sizeof ( struct Queue ) ) ; queue -> front = queue -> rear = -1 ; queue -> capacity = capacity ; queue -> array = ( struct QueueNode * * ) malloc ( queue -> capacity * sizeof ( struct QueueNode * ) ) ; return queue ; }
int isSizeOne ( struct Queue * queue ) { return queue -> front == queue -> rear && queue -> front != -1 ; }
int isEmpty ( struct Queue * queue ) { return queue -> front == -1 ; }
int isFull ( struct Queue * queue ) { return queue -> rear == queue -> capacity - 1 ; }
void enQueue ( struct Queue * queue , struct QueueNode * item ) { if ( isFull ( queue ) ) return ; queue -> array [ ++ queue -> rear ] = item ; if ( queue -> front == -1 ) ++ queue -> front ; }
struct QueueNode * deQueue ( struct Queue * queue ) { if ( isEmpty ( queue ) ) return NULL ; struct QueueNode * temp = queue -> array [ queue -> front ] ; if ( queue -> front == queue
- > rear ) queue -> front = queue -> rear = -1 ; else ++ queue -> front ; return temp ; }
struct QueueNode * getFront ( struct Queue * queue ) { if ( isEmpty ( queue ) ) return NULL ; return queue -> array [ queue -> front ] ; }
struct QueueNode * findMin ( struct Queue * firstQueue , struct Queue * secondQueue ) {
if ( isEmpty ( firstQueue ) ) return deQueue ( secondQueue ) ;
if ( isEmpty ( secondQueue ) ) return deQueue ( firstQueue ) ;
if ( getFront ( firstQueue ) -> freq < getFront ( secondQueue ) -> freq ) return deQueue ( firstQueue ) ; return deQueue ( secondQueue ) ; }
int isLeaf ( struct QueueNode * root ) { return ! ( root -> left ) && ! ( root -> right ) ; }
void printArr ( int arr [ ] , int n ) { int i ; for ( i = 0 ; i < n ; ++ i ) printf ( " % d " , arr [ i ] ) ; printf ( " STRNEWLINE " ) ; }
struct QueueNode * buildHuffmanTree ( char data [ ] , int freq [ ] , int size ) { struct QueueNode * left , * right , * top ;
struct Queue * firstQueue = createQueue ( size ) ; struct Queue * secondQueue = createQueue ( size ) ;
for ( int i = 0 ; i < size ; ++ i ) enQueue ( firstQueue , newNode ( data [ i ] , freq [ i ] ) ) ;
while ( ! ( isEmpty ( firstQueue ) && isSizeOne ( secondQueue ) ) ) {
left = findMin ( firstQueue , secondQueue ) ; right = findMin ( firstQueue , secondQueue ) ;
top = newNode ( ' $ ' , left -> freq + right -> freq ) ; top -> left = left ; top -> right = right ; enQueue ( secondQueue , top ) ; } return deQueue ( secondQueue ) ; }
void printCodes ( struct QueueNode * root , int arr [ ] , int top ) {
if ( root -> left ) { arr [ top ] = 0 ; printCodes ( root -> left , arr , top + 1 ) ; }
if ( root -> right ) { arr [ top ] = 1 ; printCodes ( root -> right , arr , top + 1 ) ; }
if ( isLeaf ( root ) ) { printf ( " % c : ▁ " , root -> data ) ; printArr ( arr , top ) ; } }
void HuffmanCodes ( char data [ ] , int freq [ ] , int size ) {
struct QueueNode * root = buildHuffmanTree ( data , freq , size ) ;
int arr [ MAX_TREE_HT ] , top = 0 ; printCodes ( root , arr , top ) ; }
int main ( ) { char arr [ ] = { ' a ' , ' b ' , ' c ' , ' d ' , ' e ' , ' f ' } ; int freq [ ] = { 5 , 9 , 12 , 13 , 16 , 45 } ; int size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; HuffmanCodes ( arr , freq , size ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE int max ( int a , int b ) ;
int lcs ( char * X , char * Y , int m , int n ) { if ( m == 0 n == 0 ) return 0 ; if ( X [ m - 1 ] == Y [ n - 1 ] ) return 1 + lcs ( X , Y , m - 1 , n - 1 ) ; else return max ( lcs ( X , Y , m , n - 1 ) , lcs ( X , Y , m - 1 , n ) ) ; }
int max ( int a , int b ) { return ( a > b ) ? a : b ; }
int main ( ) { char X [ ] = " AGGTAB " ; char Y [ ] = " GXTXAYB " ; int m = strlen ( X ) ; int n = strlen ( Y ) ; printf ( " Length ▁ of ▁ LCS ▁ is ▁ % d " , lcs ( X , Y , m , n ) ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE int max ( int a , int b ) ;
int lcs ( char * X , char * Y , int m , int n ) { int L [ m + 1 ] [ n + 1 ] ; int i , j ;
for ( i = 0 ; i <= m ; i ++ ) { for ( j = 0 ; j <= n ; j ++ ) { if ( i == 0 j == 0 ) L [ i ] [ j ] = 0 ; else if ( X [ i - 1 ] == Y [ j - 1 ] ) L [ i ] [ j ] = L [ i - 1 ] [ j - 1 ] + 1 ; else L [ i ] [ j ] = max ( L [ i - 1 ] [ j ] , L [ i ] [ j - 1 ] ) ; } }
return L [ m ] [ n ] ; }
int max ( int a , int b ) { return ( a > b ) ? a : b ; }
int main ( ) { char X [ ] = " AGGTAB " ; char Y [ ] = " GXTXAYB " ; int m = strlen ( X ) ; int n = strlen ( Y ) ; printf ( " Length ▁ of ▁ LCS ▁ is ▁ % d " , lcs ( X , Y , m , n ) ) ; return 0 ; }
#include <limits.h> NEW_LINE #include <stdio.h>
int max ( int a , int b ) { return ( a > b ) ? a : b ; }
int eggDrop ( int n , int k ) {
if ( k == 1 k == 0 ) return k ;
if ( n == 1 ) return k ; int min = INT_MAX , x , res ;
for ( x = 1 ; x <= k ; x ++ ) { res = max ( eggDrop ( n - 1 , x - 1 ) , eggDrop ( n , k - x ) ) ; if ( res < min ) min = res ; } return min + 1 ; }
int main ( ) { int n = 2 , k = 10 ; printf ( " nMinimum ▁ number ▁ of ▁ trials ▁ in ▁ " " worst ▁ case ▁ with ▁ % d ▁ eggs ▁ and ▁ " " % d ▁ floors ▁ is ▁ % d ▁ STRNEWLINE " , n , k , eggDrop ( n , k ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE int max ( int a , int b ) { return ( a > b ) ? a : b ; }
int t [ 9 ] [ 9 ] ;
int un_kp ( int price [ ] , int length [ ] , int Max_len , int n ) {
if ( n == 0 Max_len == 0 ) { return 0 ; }
if ( length [ n - 1 ] <= Max_len ) { t [ n ] [ Max_len ] = max ( price [ n - 1 ] + un_kp ( price , length , Max_len - length [ n - 1 ] , n ) , un_kp ( price , length , Max_len , n - 1 ) ) ; }
else { t [ n ] [ Max_len ] = un_kp ( price , length , Max_len , n - 1 ) ; }
return t [ n ] [ Max_len ] ; }
int main ( ) { int price [ ] = { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int n = sizeof ( price ) / sizeof ( price [ 0 ] ) ; int length [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { length [ i ] = i + 1 ; } int Max_len = n ;
printf ( " Maximum ▁ obtained ▁ value ▁ is ▁ % d ▁ STRNEWLINE " , un_kp ( price , length , n , Max_len ) ) ; }
#include <limits.h> NEW_LINE #include <stdio.h> NEW_LINE #define INF  INT_MAX
int printSolution ( int p [ ] , int n ) ; int printSolution ( int p [ ] , int n ) { int k ; if ( p [ n ] == 1 ) k = 1 ; else k = printSolution ( p , p [ n ] - 1 ) + 1 ; printf ( " Line ▁ number ▁ % d : ▁ From ▁ word ▁ no . ▁ % d ▁ to ▁ % d ▁ STRNEWLINE " , k , p [ n ] , n ) ; return k ; }
void solveWordWrap ( int l [ ] , int n , int M ) {
int extras [ n + 1 ] [ n + 1 ] ;
int lc [ n + 1 ] [ n + 1 ] ;
int c [ n + 1 ] ;
int p [ n + 1 ] ; int i , j ;
for ( i = 1 ; i <= n ; i ++ ) { extras [ i ] [ i ] = M - l [ i - 1 ] ; for ( j = i + 1 ; j <= n ; j ++ ) extras [ i ] [ j ] = extras [ i ] [ j - 1 ] - l [ j - 1 ] - 1 ; }
for ( i = 1 ; i <= n ; i ++ ) { for ( j = i ; j <= n ; j ++ ) { if ( extras [ i ] [ j ] < 0 ) lc [ i ] [ j ] = INF ; else if ( j == n && extras [ i ] [ j ] >= 0 ) lc [ i ] [ j ] = 0 ; else lc [ i ] [ j ] = extras [ i ] [ j ] * extras [ i ] [ j ] ; } }
c [ 0 ] = 0 ; for ( j = 1 ; j <= n ; j ++ ) { c [ j ] = INF ; for ( i = 1 ; i <= j ; i ++ ) { if ( c [ i - 1 ] != INF && lc [ i ] [ j ] != INF && ( c [ i - 1 ] + lc [ i ] [ j ] < c [ j ] ) ) { c [ j ] = c [ i - 1 ] + lc [ i ] [ j ] ; p [ j ] = i ; } } } printSolution ( p , n ) ; }
int main ( ) { int l [ ] = { 3 , 2 , 2 , 5 } ; int n = sizeof ( l ) / sizeof ( l [ 0 ] ) ; int M = 6 ; solveWordWrap ( l , n , M ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <limits.h>
int sum ( int freq [ ] , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
int optCost ( int freq [ ] , int i , int j ) {
if ( j < i ) return 0 ;
if ( j == i ) return freq [ i ] ;
int fsum = sum ( freq , i , j ) ;
int min = INT_MAX ;
for ( int r = i ; r <= j ; ++ r ) { int cost = optCost ( freq , i , r - 1 ) + optCost ( freq , r + 1 , j ) ; if ( cost < min ) min = cost ; }
return min + fsum ; }
int optimalSearchTree ( int keys [ ] , int freq [ ] , int n ) {
return optCost ( freq , 0 , n - 1 ) ; }
int main ( ) { int keys [ ] = { 10 , 12 , 20 } ; int freq [ ] = { 34 , 8 , 50 } ; int n = sizeof ( keys ) / sizeof ( keys [ 0 ] ) ; printf ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ % d ▁ " , optimalSearchTree ( keys , freq , n ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <limits.h>
int sum ( int freq [ ] , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
int optimalSearchTree ( int keys [ ] , int freq [ ] , int n ) {
int cost [ n ] [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) cost [ i ] [ i ] = freq [ i ] ;
for ( int L = 2 ; L <= n ; L ++ ) {
for ( int i = 0 ; i <= n - L + 1 ; i ++ ) {
int j = i + L - 1 ; cost [ i ] [ j ] = INT_MAX ;
for ( int r = i ; r <= j ; r ++ ) {
int c = ( ( r > i ) ? cost [ i ] [ r - 1 ] : 0 ) + ( ( r < j ) ? cost [ r + 1 ] [ j ] : 0 ) + sum ( freq , i , j ) ; if ( c < cost [ i ] [ j ] ) cost [ i ] [ j ] = c ; } } } return cost [ 0 ] [ n - 1 ] ; }
int main ( ) { int keys [ ] = { 10 , 12 , 20 } ; int freq [ ] = { 34 , 8 , 50 } ; int n = sizeof ( keys ) / sizeof ( keys [ 0 ] ) ; printf ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ % d ▁ " , optimalSearchTree ( keys , freq , n ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
int max ( int x , int y ) { return ( x > y ) ? x : y ; }
struct node { int data ; struct node * left , * right ; } ;
int LISS ( struct node * root ) { if ( root == NULL ) return 0 ;
int size_excl = LISS ( root -> left ) + LISS ( root -> right ) ;
int size_incl = 1 ; if ( root -> left ) size_incl += LISS ( root -> left -> left ) + LISS ( root -> left -> right ) ; if ( root -> right ) size_incl += LISS ( root -> right -> left ) + LISS ( root -> right -> right ) ;
return max ( size_incl , size_excl ) ; }
struct node * newNode ( int data ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
int main ( ) {
struct node * root = newNode ( 20 ) ; root -> left = newNode ( 8 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 12 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 14 ) ; root -> right = newNode ( 22 ) ; root -> right -> right = newNode ( 25 ) ; printf ( " Size ▁ of ▁ the ▁ Largest ▁ Independent ▁ Set ▁ is ▁ % d ▁ " , LISS ( root ) ) ; return 0 ; }
#include <stdio.h>
int getCount ( char keypad [ ] [ 3 ] , int n ) { if ( keypad == NULL n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
int odd [ 10 ] , even [ 10 ] ; int i = 0 , j = 0 , useOdd = 0 , totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ )
odd [ i ] = 1 ;
for ( j = 2 ; j <= n ; j ++ ) { useOdd = 1 - useOdd ;
if ( useOdd == 1 ) { even [ 0 ] = odd [ 0 ] + odd [ 8 ] ; even [ 1 ] = odd [ 1 ] + odd [ 2 ] + odd [ 4 ] ; even [ 2 ] = odd [ 2 ] + odd [ 1 ] + odd [ 3 ] + odd [ 5 ] ; even [ 3 ] = odd [ 3 ] + odd [ 2 ] + odd [ 6 ] ; even [ 4 ] = odd [ 4 ] + odd [ 1 ] + odd [ 5 ] + odd [ 7 ] ; even [ 5 ] = odd [ 5 ] + odd [ 2 ] + odd [ 4 ] + odd [ 8 ] + odd [ 6 ] ; even [ 6 ] = odd [ 6 ] + odd [ 3 ] + odd [ 5 ] + odd [ 9 ] ; even [ 7 ] = odd [ 7 ] + odd [ 4 ] + odd [ 8 ] ; even [ 8 ] = odd [ 8 ] + odd [ 0 ] + odd [ 5 ] + odd [ 7 ] + odd [ 9 ] ; even [ 9 ] = odd [ 9 ] + odd [ 6 ] + odd [ 8 ] ; } else { odd [ 0 ] = even [ 0 ] + even [ 8 ] ; odd [ 1 ] = even [ 1 ] + even [ 2 ] + even [ 4 ] ; odd [ 2 ] = even [ 2 ] + even [ 1 ] + even [ 3 ] + even [ 5 ] ; odd [ 3 ] = even [ 3 ] + even [ 2 ] + even [ 6 ] ; odd [ 4 ] = even [ 4 ] + even [ 1 ] + even [ 5 ] + even [ 7 ] ; odd [ 5 ] = even [ 5 ] + even [ 2 ] + even [ 4 ] + even [ 8 ] + even [ 6 ] ; odd [ 6 ] = even [ 6 ] + even [ 3 ] + even [ 5 ] + even [ 9 ] ; odd [ 7 ] = even [ 7 ] + even [ 4 ] + even [ 8 ] ; odd [ 8 ] = even [ 8 ] + even [ 0 ] + even [ 5 ] + even [ 7 ] + even [ 9 ] ; odd [ 9 ] = even [ 9 ] + even [ 6 ] + even [ 8 ] ; } }
totalCount = 0 ; if ( useOdd == 1 ) { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += even [ i ] ; } else { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += odd [ i ] ; } return totalCount ; }
int main ( ) { char keypad [ 4 ] [ 3 ] = { { '1' , '2' , '3' } , { '4' , '5' , '6' } , { '7' , '8' , '9' } , { ' * ' , '0' , ' # ' } } ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 1 , getCount ( keypad , 1 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 2 , getCount ( keypad , 2 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 3 , getCount ( keypad , 3 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 4 , getCount ( keypad , 4 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 5 , getCount ( keypad , 5 ) ) ; return 0 ; }
#include <stdio.h>
int findoptimal ( int N ) {
if ( N <= 6 ) return N ;
int screen [ N ] ;
int b ;
int n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = 0 ;
for ( b = n - 3 ; b >= 1 ; b -- ) {
int curr = ( n - b - 1 ) * screen [ b - 1 ] ; if ( curr > screen [ n - 1 ] ) screen [ n - 1 ] = curr ; } } return screen [ N - 1 ] ; }
int main ( ) { int N ;
for ( N = 1 ; N <= 20 ; N ++ ) printf ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with ▁ % d ▁ keystrokes ▁ is ▁ % d STRNEWLINE " , N , findoptimal ( N ) ) ; }
#include <stdio.h> NEW_LINE #include <string.h> NEW_LINE #define NO_OF_CHARS  256 NEW_LINE int getNextState ( char * pat , int M , int state , int x ) {
if ( state < M && x == pat [ state ] ) return state + 1 ;
int ns , i ;
for ( ns = state ; ns > 0 ; ns -- ) { if ( pat [ ns - 1 ] == x ) { for ( i = 0 ; i < ns - 1 ; i ++ ) if ( pat [ i ] != pat [ state - ns + 1 + i ] ) break ; if ( i == ns - 1 ) return ns ; } } return 0 ; }
void computeTF ( char * pat , int M , int TF [ ] [ NO_OF_CHARS ] ) { int state , x ; for ( state = 0 ; state <= M ; ++ state ) for ( x = 0 ; x < NO_OF_CHARS ; ++ x ) TF [ state ] [ x ] = getNextState ( pat , M , state , x ) ; }
void search ( char * pat , char * txt ) { int M = strlen ( pat ) ; int N = strlen ( txt ) ; int TF [ M + 1 ] [ NO_OF_CHARS ] ; computeTF ( pat , M , TF ) ;
int i , state = 0 ; for ( i = 0 ; i < N ; i ++ ) { state = TF [ state ] [ txt [ i ] ] ; if ( state == M ) printf ( " Pattern found at index % d " , i - M + 1 ) ; } }
int main ( ) { char * txt = " AABAACAADAABAAABAA " ; char * pat = " AABA " ; search ( pat , txt ) ; return 0 ; }
# include <limits.h> NEW_LINE # include <string.h> NEW_LINE # include <stdio.h> NEW_LINE # define NO_OF_CHARS  256
void badCharHeuristic ( char * str , int size , int badchar [ NO_OF_CHARS ] ) { int i ;
for ( i = 0 ; i < NO_OF_CHARS ; i ++ ) badchar [ i ] = -1 ;
for ( i = 0 ; i < size ; i ++ ) badchar [ ( int ) str [ i ] ] = i ; }
void search ( char * txt , char * pat ) { int m = strlen ( pat ) ; int n = strlen ( txt ) ; int badchar [ NO_OF_CHARS ] ;
badCharHeuristic ( pat , m , badchar ) ;
int s = 0 ;
while ( s <= ( n - m ) ) { int j = m - 1 ;
while ( j >= 0 && pat [ j ] == txt [ s + j ] ) j -- ;
if ( j < 0 ) { printf ( " pattern occurs at shift = % d "
s += ( s + m < n ) ? m - badchar [ txt [ s + m ] ] : 1 ; } else
s += max ( 1 , j - badchar [ txt [ s + j ] ] ) ; } }
int main ( ) { char txt [ ] = " ABAAABCD " ; char pat [ ] = " ABC " ; search ( txt , pat ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #define ARRAYSIZE ( a )  (sizeof(a))/(sizeof(a[0])) NEW_LINE static int total_nodes ;
void printSubset ( int A [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) { printf ( " % * d " , 5 , A [ i ] ) ; } printf ( " STRNEWLINE " ) ; }
void subset_sum ( int s [ ] , int t [ ] , int s_size , int t_size , int sum , int ite , int const target_sum ) { total_nodes ++ ; if ( target_sum == sum ) {
printSubset ( t , t_size ) ;
subset_sum ( s , t , s_size , t_size - 1 , sum - s [ ite ] , ite + 1 , target_sum ) ; return ; } else {
for ( int i = ite ; i < s_size ; i ++ ) { t [ t_size ] = s [ i ] ;
subset_sum ( s , t , s_size , t_size + 1 , sum + s [ i ] , i + 1 , target_sum ) ; } } }
void generateSubsets ( int s [ ] , int size , int target_sum ) { int * tuplet_vector = ( int * ) malloc ( size * sizeof ( int ) ) ; subset_sum ( s , tuplet_vector , size , 0 , 0 , 0 , target_sum ) ; free ( tuplet_vector ) ; }
int main ( ) { int weights [ ] = { 10 , 7 , 5 , 18 , 12 , 20 , 15 } ; int size = ARRAYSIZE ( weights ) ; generateSubsets ( weights , size , 35 ) ; printf ( " Nodes ▁ generated ▁ % d ▁ STRNEWLINE " , total_nodes ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #define ARRAYSIZE ( a )  (sizeof(a))/(sizeof(a[0])) NEW_LINE static int total_nodes ;
void printSubset ( int A [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) { printf ( " % * d " , 5 , A [ i ] ) ; } printf ( " STRNEWLINE " ) ; }
int comparator ( const void * pLhs , const void * pRhs ) { int * lhs = ( int * ) pLhs ; int * rhs = ( int * ) pRhs ; return * lhs > * rhs ; }
void subset_sum ( int s [ ] , int t [ ] , int s_size , int t_size , int sum , int ite , int const target_sum ) { total_nodes ++ ; if ( target_sum == sum ) {
printSubset ( t , t_size ) ;
if ( ite + 1 < s_size && sum - s [ ite ] + s [ ite + 1 ] <= target_sum ) {
subset_sum ( s , t , s_size , t_size - 1 , sum - s [ ite ] , ite + 1 , target_sum ) ; } return ; } else {
if ( ite < s_size && sum + s [ ite ] <= target_sum ) {
for ( int i = ite ; i < s_size ; i ++ ) { t [ t_size ] = s [ i ] ; if ( sum + s [ i ] <= target_sum ) {
subset_sum ( s , t , s_size , t_size + 1 , sum + s [ i ] , i + 1 , target_sum ) ; } } } } }
void generateSubsets ( int s [ ] , int size , int target_sum ) { int * tuplet_vector = ( int * ) malloc ( size * sizeof ( int ) ) ; int total = 0 ;
qsort ( s , size , sizeof ( int ) , & comparator ) ; for ( int i = 0 ; i < size ; i ++ ) { total += s [ i ] ; } if ( s [ 0 ] <= target_sum && total >= target_sum ) { subset_sum ( s , tuplet_vector , size , 0 , 0 , 0 , target_sum ) ; } free ( tuplet_vector ) ; }
int main ( ) { int weights [ ] = { 15 , 22 , 14 , 26 , 32 , 9 , 16 , 8 } ; int target = 53 ; int size = ARRAYSIZE ( weights ) ; generateSubsets ( weights , size , target ) ; printf ( " Nodes ▁ generated ▁ % d STRNEWLINE " , total_nodes ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
#define N  9
void print ( int arr [ N ] [ N ] ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) printf ( " % d ▁ " , arr [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } }
int isSafe ( int grid [ N ] [ N ] , int row , int col , int num ) {
for ( int x = 0 ; x <= 8 ; x ++ ) if ( grid [ row ] [ x ] == num ) return 0 ;
for ( int x = 0 ; x <= 8 ; x ++ ) if ( grid [ x ] [ col ] == num ) return 0 ;
int startRow = row - row % 3 , startCol = col - col % 3 ; for ( int i = 0 ; i < 3 ; i ++ ) for ( int j = 0 ; j < 3 ; j ++ ) if ( grid [ i + startRow ] [ j + startCol ] == num ) return 0 ; return 1 ; }
int solveSuduko ( int grid [ N ] [ N ] , int row , int col ) {
if ( row == N - 1 && col == N ) return 1 ;
if ( col == N ) { row ++ ; col = 0 ; }
if ( grid [ row ] [ col ] > 0 ) return solveSuduko ( grid , row , col + 1 ) ; for ( int num = 1 ; num <= N ; num ++ ) {
if ( isSafe ( grid , row , col , num ) == 1 ) {
grid [ row ] [ col ] = num ;
if ( solveSuduko ( grid , row , col + 1 ) == 1 ) return 1 ; }
grid [ row ] [ col ] = 0 ; } return 0 ; }
int main ( ) { int grid [ N ] [ N ] = { { 3 , 0 , 6 , 5 , 0 , 8 , 4 , 0 , 0 } , { 5 , 2 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } , { 0 , 8 , 7 , 0 , 0 , 0 , 0 , 3 , 1 } , { 0 , 0 , 3 , 0 , 1 , 0 , 0 , 8 , 0 } , { 9 , 0 , 0 , 8 , 6 , 3 , 0 , 0 , 5 } , { 0 , 5 , 0 , 0 , 9 , 0 , 6 , 0 , 0 } , { 1 , 3 , 0 , 0 , 0 , 0 , 2 , 5 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 7 , 4 } , { 0 , 0 , 5 , 2 , 0 , 6 , 3 , 0 , 0 } } ; if ( solveSuduko ( grid , 0 , 0 ) == 1 ) print ( grid ) ; else printf ( " No ▁ solution ▁ exists " ) ; return 0 ; }
int power ( int x , unsigned int y ) { int temp ; if ( y == 0 ) return 1 ; temp = power ( x , y / 2 ) ; if ( y % 2 == 0 ) return temp * temp ; else return x * temp * temp ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
int median ( int [ ] , int ) ;
int getMedian ( int ar1 [ ] , int ar2 [ ] , int n ) { if ( n <= 0 ) return -1 ; if ( n == 1 ) return ( ar1 [ 0 ] + ar2 [ 0 ] ) / 2 ; if ( n == 2 ) return ( max ( ar1 [ 0 ] , ar2 [ 0 ] ) + min ( ar1 [ 1 ] , ar2 [ 1 ] ) ) / 2 ;
int m1 = median ( ar1 , n ) ;
int m2 = median ( ar2 , n ) ;
if ( m1 == m2 ) return m1 ;
if ( m1 < m2 ) { if ( n % 2 == 0 ) return getMedian ( ar1 + n / 2 - 1 , ar2 , n - n / 2 + 1 ) ; return getMedian ( ar1 + n / 2 , ar2 , n - n / 2 ) ; }
if ( n % 2 == 0 ) return getMedian ( ar2 + n / 2 - 1 , ar1 , n - n / 2 + 1 ) ; return getMedian ( ar2 + n / 2 , ar1 , n - n / 2 ) ; }
int median ( int arr [ ] , int n ) { if ( n % 2 == 0 ) return ( arr [ n / 2 ] + arr [ n / 2 - 1 ] ) / 2 ; else return arr [ n / 2 ] ; }
int main ( ) { int ar1 [ ] = { 1 , 2 , 3 , 6 } ; int ar2 [ ] = { 4 , 6 , 8 , 10 } ; int n1 = sizeof ( ar1 ) / sizeof ( ar1 [ 0 ] ) ; int n2 = sizeof ( ar2 ) / sizeof ( ar2 [ 0 ] ) ; if ( n1 == n2 ) printf ( " Median ▁ is ▁ % d " , getMedian ( ar1 , ar2 , n1 ) ) ; else printf ( " Doesn ' t ▁ work ▁ for ▁ arrays ▁ of ▁ unequal ▁ size " ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <float.h> NEW_LINE #include <stdlib.h> NEW_LINE #include <math.h>
struct Point { int x , y ; } ;
int compareX ( const void * a , const void * b ) { Point * p1 = ( Point * ) a , * p2 = ( Point * ) b ; return ( p1 -> x - p2 -> x ) ; }
int compareY ( const void * a , const void * b ) { Point * p1 = ( Point * ) a , * p2 = ( Point * ) b ; return ( p1 -> y - p2 -> y ) ; }
float dist ( Point p1 , Point p2 ) { return sqrt ( ( p1 . x - p2 . x ) * ( p1 . x - p2 . x ) + ( p1 . y - p2 . y ) * ( p1 . y - p2 . y ) ) ; }
float bruteForce ( Point P [ ] , int n ) { float min = FLT_MAX ; for ( int i = 0 ; i < n ; ++ i ) for ( int j = i + 1 ; j < n ; ++ j ) if ( dist ( P [ i ] , P [ j ] ) < min ) min = dist ( P [ i ] , P [ j ] ) ; return min ; }
float min ( float x , float y ) { return ( x < y ) ? x : y ; }
float stripClosest ( Point strip [ ] , int size , float d ) {
float min = d ; qsort ( strip , size , sizeof ( Point ) , compareY ) ;
for ( int i = 0 ; i < size ; ++ i ) for ( int j = i + 1 ; j < size && ( strip [ j ] . y - strip [ i ] . y ) < min ; ++ j ) if ( dist ( strip [ i ] , strip [ j ] ) < min ) min = dist ( strip [ i ] , strip [ j ] ) ; return min ; }
float closestUtil ( Point P [ ] , int n ) {
if ( n <= 3 ) return bruteForce ( P , n ) ;
int mid = n / 2 ; Point midPoint = P [ mid ] ;
float dl = closestUtil ( P , mid ) ; float dr = closestUtil ( P + mid , n - mid ) ;
float d = min ( dl , dr ) ;
Point strip [ n ] ; int j = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( abs ( P [ i ] . x - midPoint . x ) < d ) strip [ j ] = P [ i ] , j ++ ;
return min ( d , stripClosest ( strip , j , d ) ) ; }
float closest ( Point P [ ] , int n ) { qsort ( P , n , sizeof ( Point ) , compareX ) ;
return closestUtil ( P , n ) ; }
int main ( ) { Point P [ ] = { { 2 , 3 } , { 12 , 30 } , { 40 , 50 } , { 5 , 1 } , { 12 , 10 } , { 3 , 4 } } ; int n = sizeof ( P ) / sizeof ( P [ 0 ] ) ; printf ( " The ▁ smallest ▁ distance ▁ is ▁ % f ▁ " , closest ( P , n ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
int main ( ) { struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <string.h> NEW_LINE #define MAX_CHAR  256
int count [ MAX_CHAR ] = { 0 } ;
int fact ( int n ) { return ( n <= 1 ) ? 1 : n * fact ( n - 1 ) ; }
void populateAndIncreaseCount ( int * count , char * str ) { int i ; for ( i = 0 ; str [ i ] ; ++ i ) ++ count [ str [ i ] ] ; for ( i = 1 ; i < MAX_CHAR ; ++ i ) count [ i ] += count [ i - 1 ] ; }
void updatecount ( int * count , char ch ) { int i ; for ( i = ch ; i < MAX_CHAR ; ++ i ) -- count [ i ] ; }
int findRank ( char * str ) { int len = strlen ( str ) ; int mul = fact ( len ) ; int rank = 1 , i ;
populateAndIncreaseCount ( count , str ) ; for ( i = 0 ; i < len ; ++ i ) { mul /= len - i ;
rank += count [ str [ i ] - 1 ] * mul ;
updatecount ( count , str [ i ] ) ; } return rank ; }
int main ( ) { char str [ ] = " string " ; printf ( " % d " , findRank ( str ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #include <string.h>
int compare ( const void * a , const void * b ) { return ( * ( char * ) a - * ( char * ) b ) ; }
void swap ( char * a , char * b ) { char t = * a ; * a = * b ; * b = t ; }
int findCeil ( char str [ ] , char first , int l , int h ) {
int ceilIndex = l ;
for ( int i = l + 1 ; i <= h ; i ++ ) if ( str [ i ] > first && str [ i ] < str [ ceilIndex ] ) ceilIndex = i ; return ceilIndex ; }
void sortedPermutations ( char str [ ] ) {
int size = strlen ( str ) ;
qsort ( str , size , sizeof ( str [ 0 ] ) , compare ) ;
bool isFinished = false ; while ( ! isFinished ) {
printf ( " % s ▁ STRNEWLINE " , str ) ;
int i ; for ( i = size - 2 ; i >= 0 ; -- i ) if ( str [ i ] < str [ i + 1 ] ) break ;
if ( i == -1 ) isFinished = true ; else {
int ceilIndex = findCeil ( str , str [ i ] , i + 1 , size - 1 ) ;
swap ( & str [ i ] , & str [ ceilIndex ] ) ;
qsort ( str + i + 1 , size - i - 1 , sizeof ( str [ 0 ] ) , compare ) ; } } }
int main ( ) { char str [ ] = " ABCD " ; sortedPermutations ( str ) ; return 0 ; }
void reverse ( char str [ ] , int l , int h ) { while ( l < h ) { swap ( & str [ l ] , & str [ h ] ) ; l ++ ; h -- ; } }
void swap ( char * a , char * b ) { char t = * a ; * a = * b ; * b = t ; } int compare ( const void * a , const void * b ) { return ( * ( char * ) a - * ( char * ) b ) ; }
int findCeil ( char str [ ] , char first , int l , int h ) { int ceilIndex = l ; for ( int i = l + 1 ; i <= h ; i ++ ) if ( str [ i ] > first && str [ i ] < str [ ceilIndex ] ) ceilIndex = i ; return ceilIndex ; }
void sortedPermutations ( char str [ ] ) {
int size = strlen ( str ) ;
qsort ( str , size , sizeof ( str [ 0 ] ) , compare ) ;
bool isFinished = false ; while ( ! isFinished ) {
printf ( " % s ▁ STRNEWLINE " , str ) ;
int i ; for ( i = size - 2 ; i >= 0 ; -- i ) if ( str [ i ] < str [ i + 1 ] ) break ;
if ( i == -1 ) isFinished = true ; else {
int ceilIndex = findCeil ( str , str [ i ] , i + 1 , size - 1 ) ;
swap ( & str [ i ] , & str [ ceilIndex ] ) ;
reverse ( str , i + 1 , size - 1 ) ; } } }
#include <stdio.h> NEW_LINE #include <stdlib.h>
int findCeil ( int arr [ ] , int r , int l , int h ) { int mid ; while ( l < h ) {
mid = l + ( ( h - l ) >> 1 ) ; ( r > arr [ mid ] ) ? ( l = mid + 1 ) : ( h = mid ) ; } return ( arr [ l ] >= r ) ? l : -1 ; }
int myRand ( int arr [ ] , int freq [ ] , int n ) {
int prefix [ n ] , i ; prefix [ 0 ] = freq [ 0 ] ; for ( i = 1 ; i < n ; ++ i ) prefix [ i ] = prefix [ i - 1 ] + freq [ i ] ;
int r = ( rand ( ) % prefix [ n - 1 ] ) + 1 ;
int indexc = findCeil ( prefix , r , 0 , n - 1 ) ; return arr [ indexc ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int freq [ ] = { 10 , 5 , 20 , 100 } ; int i , n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
srand ( time ( NULL ) ) ;
for ( i = 0 ; i < 5 ; i ++ ) printf ( " % d STRNEWLINE " , myRand ( arr , freq , n ) ) ; return 0 ; }
#include <stdio.h>
unsigned int getLeftmostBit ( int n ) { int m = 0 ; while ( n > 1 ) { n = n >> 1 ; m ++ ; } return m ; }
unsigned int getNextLeftmostBit ( int n , int m ) { unsigned int temp = 1 << m ; while ( n < temp ) { temp = temp >> 1 ; m -- ; } return m ; }
unsigned int _countSetBits ( unsigned int n , int m ) ; unsigned int countSetBits ( unsigned int n ) {
int m = getLeftmostBit ( n ) ;
return _countSetBits ( n , m ) ; } unsigned int _countSetBits ( unsigned int n , int m ) {
if ( n == 0 ) return 0 ;
m = getNextLeftmostBit ( n , m ) ;
if ( n == ( ( unsigned int ) 1 << ( m + 1 ) ) - 1 ) return ( unsigned int ) ( m + 1 ) * ( 1 << m ) ;
n = n - ( 1 << m ) ; return ( n + 1 ) + countSetBits ( n ) + m * ( 1 << ( m - 1 ) ) ; }
int main ( ) { int n = 17 ; printf ( " Total ▁ set ▁ bit ▁ count ▁ is ▁ % d " , countSetBits ( n ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #define CHAR_BIT  8
int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHAR_BIT - 1 ) ) ) ; }
int smallest ( int x , int y , int z ) { return min ( x , min ( y , z ) ) ; }
int main ( ) { int x = 12 , y = 15 , z = 5 ; printf ( " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ % d " , smallest ( x , y , z ) ) ; return 0 ; }
#include <stdio.h>
int smallest ( int x , int y , int z ) {
if ( ! ( y / x ) ) return ( ! ( y / z ) ) ? y : z ; return ( ! ( x / z ) ) ? x : z ; }
int main ( ) { int x = 78 , y = 88 , z = 68 ; printf ( " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ % d " , smallest ( x , y , z ) ) ; return 0 ; }
void changeToZero ( int a [ 2 ] ) { a [ a [ 1 ] ] = a [ ! a [ 1 ] ] ; }
int main ( ) { int a [ ] = { 1 , 0 } ; changeToZero ( a ) ; printf ( " ▁ arr [ 0 ] ▁ = ▁ % d ▁ STRNEWLINE " , a [ 0 ] ) ; printf ( " ▁ arr [ 1 ] ▁ = ▁ % d ▁ " , a [ 1 ] ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #include <time.h>
#define SIZE  (1 << 16)
#define GROUP_A ( x )  x, x + 1, x + 1, x + 2
#define GROUP_B ( x )  GROUP_A(x), GROUP_A(x+1), GROUP_A(x+1), GROUP_A(x+2)
#define GROUP_C ( x )  GROUP_B(x), GROUP_B(x+1), GROUP_B(x+1), GROUP_B(x+2)
#define META_LOOK_UP ( PARAMETER )  \NEW_LINE GROUP_##PARAMETER(0), \NEW_LINE GROUP_##PARAMETER(1), \NEW_LINE GROUP_##PARAMETER(1), \NEW_LINE GROUP_##PARAMETER(2) \NEW_LINEint countSetBits(int array[], size_t array_size) NEW_LINE { int count = 0 ;
static unsigned char const look_up [ ] = { META_LOOK_UP ( C ) } ;
unsigned char * pData = NULL ; for ( size_t index = 0 ; index < array_size ; index ++ ) {
pData = ( unsigned char * ) & array [ index ] ;
count += look_up [ pData [ 0 ] ] ; count += look_up [ pData [ 1 ] ] ; count += look_up [ pData [ 2 ] ] ; count += look_up [ pData [ 3 ] ] ; } return count ; }
int main ( ) { int index ; int random [ SIZE ] ;
srand ( ( unsigned ) time ( 0 ) ) ;
for ( index = 0 ; index < SIZE ; index ++ ) { random [ index ] = rand ( ) ; } printf ( " Total ▁ number ▁ of ▁ bits ▁ = ▁ % d STRNEWLINE " , countSetBits ( random , SIZE ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #define bool  int NEW_LINE bool isPowerOfFour ( unsigned int n ) { return n != 0 && ( ( n & ( n - 1 ) ) == 0 ) && ! ( n & 0xAAAAAAAA ) ; }
int main ( ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) ) printf ( " % d ▁ is ▁ a ▁ power ▁ of ▁ 4" , test_no ) ; else printf ( " % d ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" , test_no ) ; getchar ( ) ; }
#include <stdio.h> NEW_LINE #define CHAR_BIT  8
int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHAR_BIT - 1 ) ) ) ; }
int max ( int x , int y ) { return x - ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHAR_BIT - 1 ) ) ) ; }
int main ( ) { int x = 15 ; int y = 6 ; printf ( " Minimum ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ " , x , y ) ; printf ( " % d " , min ( x , y ) ) ; printf ( " Maximum of % d and % d is " printf ( " % d " , max ( x , y ) ) ; getchar ( ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
int addOvf ( int * result , int a , int b ) { * result = a + b ; if ( a > 0 && b > 0 && * result < 0 ) return -1 ; if ( a < 0 && b < 0 && * result > 0 ) return -1 ; return 0 ; }
int main ( ) { int * res = ( int * ) malloc ( sizeof ( int ) ) ; int x = 2147483640 ; int y = 10 ; printf ( " % d " , addOvf ( res , x , y ) ) ; printf ( " % d " , * res ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <limits.h> NEW_LINE #include <stdlib.h> NEW_LINE int addOvf ( int * result , int a , int b ) { if ( a > INT_MAX - b ) return -1 ; else { * result = a + b ; return 0 ; } } int main ( ) { int * res = ( int * ) malloc ( sizeof ( int ) ) ; int x = 2147483640 ; int y = 10 ; printf ( " % d " , addOvf ( res , x , y ) ) ; printf ( " % d " , * res ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE int main ( ) { unsigned int i = 1 ; char * c = ( char * ) & i ; if ( * c ) printf ( " Little ▁ endian " ) ; else printf ( " Big ▁ endian " ) ; getchar ( ) ; return 0 ; }
#include <stdio.h>
int countSetBits ( int N ) { int count = 0 ;
for ( int i = 0 ; i < sizeof ( int ) * 8 ; i ++ ) { if ( N & ( 1 << i ) ) count ++ ; } return count ; }
int main ( ) { int N = 15 ; printf ( " % d " , countSetBits ( N ) ) ; return 0 ; }
#include <stdio.h>
void bin ( unsigned n ) { unsigned i ; for ( i = 1 << 31 ; i > 0 ; i = i / 2 ) ( n & i ) ? printf ( "1" ) : printf ( "0" ) ; }
int main ( void ) { bin ( 7 ) ; printf ( " STRNEWLINE " ) ; bin ( 4 ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
int maxDepth ( struct node * node ) { if ( node == NULL ) return 0 ; else {
int lDepth = maxDepth ( node -> left ) ; int rDepth = maxDepth ( node -> right ) ;
if ( lDepth > rDepth ) return ( lDepth + 1 ) ; else return ( rDepth + 1 ) ; } }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( ) { struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; printf ( " Height ▁ of ▁ tree ▁ is ▁ % d " , maxDepth ( root ) ) ; getchar ( ) ; return 0 ; }
void constructLowerArray ( int * arr [ ] , int * countSmaller , int n ) { int i , j ;
for ( i = 0 ; i < n ; i ++ ) countSmaller [ i ] = 0 ; for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < arr [ i ] ) countSmaller [ i ] ++ ; } } }
void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; printf ( " STRNEWLINE " ) ; }
int main ( ) { int arr [ ] = { 12 , 10 , 5 , 4 , 2 , 20 , 6 , 1 , 0 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int * low = ( int * ) malloc ( sizeof ( int ) * n ) ; constructLowerArray ( arr , low , n ) ; printArray ( low , n ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int key ; struct node * left ; struct node * right ; int height ;
int size ; } ;
int max ( int a , int b ) ;
int height ( struct node * N ) { if ( N == NULL ) return 0 ; return N -> height ; }
int size ( struct node * N ) { if ( N == NULL ) return 0 ; return N -> size ; }
int max ( int a , int b ) { return ( a > b ) ? a : b ; }
struct node * newNode ( int key ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> key = key ; node -> left = NULL ; node -> right = NULL ;
node -> height = 1 ; node -> size = 1 ; return ( node ) ; }
struct node * rightRotate ( struct node * y ) { struct node * x = y -> left ; struct node * T2 = x -> right ;
x -> right = y ; y -> left = T2 ;
y -> height = max ( height ( y -> left ) , height ( y -> right ) ) + 1 ; x -> height = max ( height ( x -> left ) , height ( x -> right ) ) + 1 ;
y -> size = size ( y -> left ) + size ( y -> right ) + 1 ; x -> size = size ( x -> left ) + size ( x -> right ) + 1 ;
return x ; }
struct node * leftRotate ( struct node * x ) { struct node * y = x -> right ; struct node * T2 = y -> left ;
y -> left = x ; x -> right = T2 ;
x -> height = max ( height ( x -> left ) , height ( x -> right ) ) + 1 ; y -> height = max ( height ( y -> left ) , height ( y -> right ) ) + 1 ;
x -> size = size ( x -> left ) + size ( x -> right ) + 1 ; y -> size = size ( y -> left ) + size ( y -> right ) + 1 ;
return y ; }
int getBalance ( struct node * N ) { if ( N == NULL ) return 0 ; return height ( N -> left ) - height ( N -> right ) ; }
struct node * insert ( struct node * node , int key , int * count ) {
if ( node == NULL ) return ( newNode ( key ) ) ; if ( key < node -> key ) node -> left = insert ( node -> left , key , count ) ; else { node -> right = insert ( node -> right , key , count ) ;
* count = * count + size ( node -> left ) + 1 ; }
node -> height = max ( height ( node -> left ) , height ( node -> right ) ) + 1 ; node -> size = size ( node -> left ) + size ( node -> right ) + 1 ;
int balance = getBalance ( node ) ;
if ( balance > 1 && key < node -> left -> key ) return rightRotate ( node ) ;
if ( balance < -1 && key > node -> right -> key ) return leftRotate ( node ) ;
if ( balance > 1 && key > node -> left -> key ) { node -> left = leftRotate ( node -> left ) ; return rightRotate ( node ) ; }
if ( balance < -1 && key < node -> right -> key ) { node -> right = rightRotate ( node -> right ) ; return leftRotate ( node ) ; }
return node ; }
void constructLowerArray ( int arr [ ] , int countSmaller [ ] , int n ) { int i , j ; struct node * root = NULL ;
for ( i = 0 ; i < n ; i ++ ) countSmaller [ i ] = 0 ;
for ( i = n - 1 ; i >= 0 ; i -- ) { root = insert ( root , arr [ i ] , & countSmaller [ i ] ) ; } }
void printArray ( int arr [ ] , int size ) { int i ; printf ( " STRNEWLINE " ) ; for ( i = 0 ; i < size ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; }
int main ( ) { int arr [ ] = { 10 , 6 , 15 , 20 , 30 , 5 , 7 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int * low = ( int * ) malloc ( sizeof ( int ) * n ) ; constructLowerArray ( arr , low , n ) ; printf ( " Following ▁ is ▁ the ▁ constructed ▁ smaller ▁ count ▁ array " ) ; printArray ( low , n ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
void swap ( int * a , int * b ) { int temp ; temp = * a ; * a = * b ; * b = temp ; }
int segregate ( int arr [ ] , int size ) { int j = 0 , i ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] <= 0 ) { swap ( & arr [ i ] , & arr [ j ] ) ;
j ++ ; } } return j ; }
int findMissingPositive ( int arr [ ] , int size ) { int i ;
for ( i = 0 ; i < size ; i ++ ) { if ( abs ( arr [ i ] ) - 1 < size && arr [ abs ( arr [ i ] ) - 1 ] > 0 ) arr [ abs ( arr [ i ] ) - 1 ] = - arr [ abs ( arr [ i ] ) - 1 ] ; }
for ( i = 0 ; i < size ; i ++ ) if ( arr [ i ] > 0 )
return i + 1 ; return size + 1 ; }
int findMissing ( int arr [ ] , int size ) {
int shift = segregate ( arr , size ) ;
return findMissingPositive ( arr + shift , size - shift ) ; }
int main ( ) { int arr [ ] = { 0 , 10 , 2 , -10 , -20 } ; int arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int missing = findMissing ( arr , arr_size ) ; printf ( " The ▁ smallest ▁ positive ▁ missing ▁ number ▁ is ▁ % d ▁ " , missing ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #define bool  int
struct node { int data ; struct node * left ; struct node * right ; } ;
int height ( struct node * node ) ;
bool isBalanced ( struct node * root ) {
int lh ;
int rh ;
if ( root == NULL ) return 1 ;
lh = height ( root -> left ) ; rh = height ( root -> right ) ; if ( abs ( lh - rh ) <= 1 && isBalanced ( root -> left ) && isBalanced ( root -> right ) ) return 1 ;
return 0 ; }
int max ( int a , int b ) { return ( a >= b ) ? a : b ; }
int height ( struct node * node ) {
if ( node == NULL ) return 0 ;
return 1 + max ( height ( node -> left ) , height ( node -> right ) ) ; }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( ) { struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> left -> left -> left = newNode ( 8 ) ; if ( isBalanced ( root ) ) printf ( " Tree ▁ is ▁ balanced " ) ; else printf ( " Tree ▁ is ▁ not ▁ balanced " ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left , * right ; } ;
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int max ( int a , int b ) { return ( a > b ) ? a : b ; }
int height ( struct node * node ) {
if ( node == NULL ) return 0 ;
return 1 + max ( height ( node -> left ) , height ( node -> right ) ) ; }
int diameter ( struct node * tree ) {
if ( tree == NULL ) return 0 ;
int lheight = height ( tree -> left ) ; int rheight = height ( tree -> right ) ;
int ldiameter = diameter ( tree -> left ) ; int rdiameter = diameter ( tree -> right ) ;
return max ( lheight + rheight + 1 , max ( ldiameter , rdiameter ) ) ; }
int main ( ) {
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ;
printf ( " Diameter ▁ of ▁ the ▁ given ▁ binary ▁ tree ▁ is ▁ % d STRNEWLINE " , diameter ( root ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
void getTwoElements ( int arr [ ] , int n , int * x , int * y ) {
int xor1 ;
int set_bit_no ; int i ; * x = 0 ; * y = 0 ; xor1 = arr [ 0 ] ;
for ( i = 1 ; i < n ; i ++ ) xor1 = xor1 ^ arr [ i ] ;
for ( i = 1 ; i <= n ; i ++ ) xor1 = xor1 ^ i ;
set_bit_no = xor1 & ~ ( xor1 - 1 ) ;
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] & set_bit_no )
* x = * x ^ arr [ i ] ; else
* y = * y ^ arr [ i ] ; } for ( i = 1 ; i <= n ; i ++ ) { if ( i & set_bit_no )
* x = * x ^ i ; else
* y = * y ^ i ; }
}
int main ( ) { int arr [ ] = { 1 , 3 , 4 , 5 , 5 , 6 , 2 } ; int * x = ( int * ) malloc ( sizeof ( int ) ) ; int * y = ( int * ) malloc ( sizeof ( int ) ) ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; getTwoElements ( arr , n , x , y ) ; printf ( " ▁ The ▁ missing ▁ element ▁ is ▁ % d " " ▁ and ▁ the ▁ repeating ▁ number " " ▁ is ▁ % d " , * x , * y ) ; getchar ( ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct pairSum {
int first ;
int sec ;
int sum ; } ;
int compare ( const void * a , const void * b ) { return ( ( * ( pairSum * ) a ) . sum - ( * ( pairSum * ) b ) . sum ) ; }
bool noCommon ( struct pairSum a , struct pairSum b ) { if ( a . first == b . first a . first == b . sec a . sec == b . first a . sec == b . sec ) return false ; return true ; }
void findFourElements ( int arr [ ] , int n , int X ) { int i , j ;
int size = ( n * ( n - 1 ) ) / 2 ; struct pairSum aux [ size ] ;
int k = 0 ; for ( i = 0 ; i < n - 1 ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { aux [ k ] . sum = arr [ i ] + arr [ j ] ; aux [ k ] . first = i ; aux [ k ] . sec = j ; k ++ ; } }
qsort ( aux , size , sizeof ( aux [ 0 ] ) , compare ) ;
i = 0 ; j = size - 1 ; while ( i < size && j >= 0 ) { if ( ( aux [ i ] . sum + aux [ j ] . sum == X ) && noCommon ( aux [ i ] , aux [ j ] ) ) { printf ( " % d , ▁ % d , ▁ % d , ▁ % d STRNEWLINE " , arr [ aux [ i ] . first ] , arr [ aux [ i ] . sec ] , arr [ aux [ j ] . first ] , arr [ aux [ j ] . sec ] ) ; return ; } else if ( aux [ i ] . sum + aux [ j ] . sum < X ) i ++ ; else j -- ; } }
int main ( ) { int arr [ ] = { 10 , 20 , 30 , 40 , 1 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int X = 91 ;
findFourElements ( arr , n , X ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
int max ( int x , int y ) { return ( x > y ) ? x : y ; }
struct Node { int data ; struct Node * left , * right ; } ;
struct Node * newNode ( int data ) { struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return node ; }
int depthOfOddLeafUtil ( struct Node * root , int level ) {
if ( root == NULL ) return 0 ;
if ( root -> left == NULL && root -> right == NULL && level & 1 ) return level ;
return max ( depthOfOddLeafUtil ( root -> left , level + 1 ) , depthOfOddLeafUtil ( root -> right , level + 1 ) ) ; }
int depthOfOddLeaf ( struct Node * root ) { int level = 1 , depth = 0 ; return depthOfOddLeafUtil ( root , level ) ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> right -> left = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; root -> right -> left -> right = newNode ( 7 ) ; root -> right -> right -> right = newNode ( 8 ) ; root -> right -> left -> right -> left = newNode ( 9 ) ; root -> right -> right -> right -> right = newNode ( 10 ) ; root -> right -> right -> right -> right -> left = newNode ( 11 ) ; printf ( " % d ▁ is ▁ the ▁ required ▁ depth STRNEWLINE " , depthOfOddLeaf ( root ) ) ; getchar ( ) ; return 0 ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void insertAfter ( struct Node * prev_node , int new_data ) {
if ( prev_node == NULL ) { printf ( " the ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL " ) ; return ; }
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = prev_node -> next ;
prev_node -> next = new_node ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #include <stdbool.h>
struct Node { int key ; struct Node * next ; } ;
void push ( struct Node * * head_ref , int new_key ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> key = new_key ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
bool search ( struct Node * head , int x ) {
if ( head == NULL ) return false ;
if ( head -> key == x ) return true ;
return search ( head -> next , x ) ; }
int main ( ) {
struct Node * head = NULL ; int x = 21 ;
push ( & head , 10 ) ; push ( & head , 30 ) ; push ( & head , 11 ) ; push ( & head , 21 ) ; push ( & head , 14 ) ; search ( head , 21 ) ? printf ( " Yes " ) : printf ( " No " ) ; return 0 ; }
void deleteAlt ( struct Node * head ) { if ( head == NULL ) return ; struct Node * node = head -> next ; if ( node == NULL ) return ;
head -> next = node -> next ;
free ( node ) ;
deleteAlt ( head -> next ) ; }
void AlternatingSplit ( struct Node * source , struct Node * * aRef , struct Node * * bRef ) { struct Node aDummy ; struct Node * aTail = & aDummy ;
struct Node bDummy ; struct Node * bTail = & bDummy ;
struct Node * current = source ; aDummy . next = NULL ; bDummy . next = NULL ; while ( current != NULL ) { MoveNode ( & ( aTail -> next ) , t ) ;
aTail = aTail -> next ;
if ( current != NULL ) { MoveNode ( & ( bTail -> next ) , t ) ; bTail = bTail -> next ; } } * aRef = aDummy . next ; * bRef = bDummy . next ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #include <stdbool.h>
struct Node { int data ; struct Node * next ; } ;
bool areIdentical ( struct Node * a , struct Node * b ) { while ( a != NULL && b != NULL ) { if ( a -> data != b -> data ) return false ;
a = a -> next ; b = b -> next ; }
return ( a == NULL && b == NULL ) ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
int main ( ) {
struct Node * a = NULL ; struct Node * b = NULL ; push ( & a , 1 ) ; push ( & a , 2 ) ; push ( & a , 3 ) ; push ( & b , 1 ) ; push ( & b , 2 ) ; push ( & b , 3 ) ; areIdentical ( a , b ) ? printf ( " Identical " ) : printf ( " Not ▁ identical " ) ; return 0 ; }
bool areIdentical ( struct Node * a , struct Node * b ) {
if ( a == NULL && b == NULL ) return true ;
if ( a != NULL && b != NULL ) return ( a -> data == b -> data ) && areIdentical ( a -> next , b -> next ) ;
return false ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ;
void sortList ( struct Node * head ) {
int count [ 3 ] = { 0 , 0 , 0 } ; struct Node * ptr = head ;
while ( ptr != NULL ) { count [ ptr -> data ] += 1 ; ptr = ptr -> next ; } int i = 0 ; ptr = head ;
while ( ptr != NULL ) { if ( count [ i ] == 0 ) ++ i ; else { ptr -> data = i ; -- count [ i ] ; ptr = ptr -> next ; } } }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } printf ( " n " ) ; }
int main ( void ) {
struct Node * head = NULL ; push ( & head , 0 ) ; push ( & head , 1 ) ; push ( & head , 0 ) ; push ( & head , 2 ) ; push ( & head , 1 ) ; push ( & head , 1 ) ; push ( & head , 2 ) ; push ( & head , 1 ) ; push ( & head , 2 ) ; printf ( " Linked ▁ List ▁ Before ▁ Sorting STRNEWLINE " ) ; printList ( head ) ; sortList ( head ) ; printf ( " Linked ▁ List ▁ After ▁ Sorting STRNEWLINE " ) ; printList ( head ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
struct Node { int data ; struct Node * next ; } ;
Node * newNode ( int key ) { Node * temp = new Node ; temp -> data = key ; temp -> next = NULL ; return temp ; }
Node * rearrangeEvenOdd ( Node * head ) {
if ( head == NULL ) return NULL ;
Node * odd = head ; Node * even = head -> next ;
Node * evenFirst = even ; while ( 1 ) {
if ( ! odd || ! even || ! ( even -> next ) ) { odd -> next = evenFirst ; break ; }
odd -> next = even -> next ; odd = even -> next ;
if ( odd -> next == NULL ) { even -> next = NULL ; odd -> next = evenFirst ; break ; }
even -> next = odd -> next ; even = odd -> next ; } return head ; }
void printlist ( Node * node ) { while ( node != NULL ) { cout << node -> data << " - > " ; node = node -> next ; } cout << " NULL " << endl ; }
int main ( void ) { Node * head = newNode ( 1 ) ; head -> next = newNode ( 2 ) ; head -> next -> next = newNode ( 3 ) ; head -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next = newNode ( 5 ) ; cout << " Given ▁ Linked ▁ List STRNEWLINE " ; printlist ( head ) ; head = rearrangeEvenOdd ( head ) ; cout << " Modified Linked List " ; printlist ( head ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
int getWidth ( struct node * root , int level ) ; int height ( struct node * node ) ; struct node * newNode ( int data ) ;
int getMaxWidth ( struct node * root ) { int maxWidth = 0 ; int width ; int h = height ( root ) ; int i ;
for ( i = 1 ; i <= h ; i ++ ) { width = getWidth ( root , i ) ; if ( width > maxWidth ) maxWidth = width ; } return maxWidth ; }
int getWidth ( struct node * root , int level ) { if ( root == NULL ) return 0 ; if ( level == 1 ) return 1 ; else if ( level > 1 ) return getWidth ( root -> left , level - 1 ) + getWidth ( root -> right , level - 1 ) ; }
int height ( struct node * node ) { if ( node == NULL ) return 0 ; else {
int lHeight = height ( node -> left ) ; int rHeight = height ( node -> right ) ;
return ( lHeight > rHeight ) ? ( lHeight + 1 ) : ( rHeight + 1 ) ; } }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( ) {
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 8 ) ; root -> right -> right -> left = newNode ( 6 ) ; root -> right -> right -> right = newNode ( 7 ) ;
printf ( " Maximum ▁ width ▁ is ▁ % d ▁ STRNEWLINE " , getMaxWidth ( root ) ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ;
void deleteLast ( struct Node * head , int x ) { struct Node * temp = head , * ptr = NULL ; while ( temp ) {
if ( temp -> data == x ) ptr = temp ; temp = temp -> next ; }
if ( ptr != NULL && ptr -> next == NULL ) { temp = head ; while ( temp -> next != ptr ) temp = temp -> next ; temp -> next = NULL ; }
if ( ptr != NULL && ptr -> next != NULL ) { ptr -> data = ptr -> next -> data ; temp = ptr -> next ; ptr -> next = ptr -> next -> next ; free ( temp ) ; } }
struct Node * newNode ( int x ) { struct Node * node = malloc ( sizeof ( struct Node * ) ) ; node -> data = x ; node -> next = NULL ; return node ; }
void display ( struct Node * head ) { struct Node * temp = head ; if ( head == NULL ) { printf ( " NULL STRNEWLINE " ) ; return ; } while ( temp != NULL ) { printf ( " % d ▁ - - > ▁ " , temp -> data ) ; temp = temp -> next ; } printf ( " NULL STRNEWLINE " ) ; }
int main ( ) { struct Node * head = newNode ( 1 ) ; head -> next = newNode ( 2 ) ; head -> next -> next = newNode ( 3 ) ; head -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next = newNode ( 5 ) ; head -> next -> next -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next -> next -> next = newNode ( 4 ) ; printf ( " Created ▁ Linked ▁ list : ▁ " ) ; display ( head ) ; deleteLast ( head , 4 ) ; printf ( " List ▁ after ▁ deletion ▁ of ▁ 4 : ▁ " ) ; display ( head ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
int height ( struct node * node ) ; struct node * newNode ( int data ) ; int getMax ( int arr [ ] , int n ) ; void getMaxWidthRecur ( struct node * root , int count [ ] , int level ) ;
int getMaxWidth ( struct node * root ) { int width ; int h = height ( root ) ;
int * count = ( int * ) calloc ( sizeof ( int ) , h ) ; int level = 0 ;
getMaxWidthRecur ( root , count , level ) ;
return getMax ( count , h ) ; }
void getMaxWidthRecur ( struct node * root , int count [ ] , int level ) { if ( root ) { count [ level ] ++ ; getMaxWidthRecur ( root -> left , count , level + 1 ) ; getMaxWidthRecur ( root -> right , count , level + 1 ) ; } }
int height ( struct node * node ) { if ( node == NULL ) return 0 ; else {
int lHeight = height ( node -> left ) ; int rHeight = height ( node -> right ) ;
return ( lHeight > rHeight ) ? ( lHeight + 1 ) : ( rHeight + 1 ) ; } }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
int main ( ) {
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 8 ) ; root -> right -> right -> left = newNode ( 6 ) ; root -> right -> right -> right = newNode ( 7 ) ; printf ( " Maximum ▁ width ▁ is ▁ % d ▁ STRNEWLINE " , getMaxWidth ( root ) ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ;
int LinkedListLength ( struct Node * head ) { while ( head && head -> next ) { head = head -> next -> next ; } if ( ! head ) return 0 ; return 1 ; }
void push ( struct Node * * head , int info ) {
struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
node -> data = info ;
node -> next = ( * head ) ;
( * head ) = node ; }
int main ( void ) { struct Node * head = NULL ;
push ( & head , 4 ) ; push ( & head , 5 ) ; push ( & head , 7 ) ; push ( & head , 2 ) ; push ( & head , 9 ) ; push ( & head , 6 ) ; push ( & head , 1 ) ; push ( & head , 2 ) ; push ( & head , 0 ) ; push ( & head , 5 ) ; push ( & head , 5 ) ; int check = LinkedListLength ( head ) ;
if ( check == 0 ) { printf ( " Even STRNEWLINE " ) ; } else { printf ( " Odd STRNEWLINE " ) ; } return 0 ; }
struct Node * SortedMerge ( struct Node * a , struct Node * b ) { struct Node * result = NULL ;
struct Node * * lastPtrRef = & result ; while ( 1 ) { if ( a == NULL ) { * lastPtrRef = b ; break ; } else if ( b == NULL ) { * lastPtrRef = a ; break ; } if ( a -> data <= b -> data ) { MoveNode ( lastPtrRef , & a ) ; } else { MoveNode ( lastPtrRef , & b ) ; }
lastPtrRef = & ( ( * lastPtrRef ) -> next ) ; } return ( result ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ;
struct Node * rotateHelper ( struct Node * blockHead , struct Node * blockTail , int d , struct Node * * tail , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { struct Node * temp = blockHead ; for ( int i = 1 ; temp -> next -> next && i < k - 1 ; i ++ ) temp = temp -> next ; blockTail -> next = blockHead ; * tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , tail , k ) ; }
if ( d < 0 ) { blockTail -> next = blockHead ; * tail = blockHead ; return rotateHelper ( blockHead -> next , blockHead , d + 1 , tail , k ) ; } }
struct Node * rotateByBlocks ( struct Node * head , int k , int d ) {
if ( ! head ! head -> next ) return head ;
if ( d == 0 ) return head ; struct Node * temp = head , * tail = NULL ;
int i ; for ( i = 1 ; temp -> next && i < k ; i ++ ) temp = temp -> next ;
struct Node * nextBlock = temp -> next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , & tail , i ) ; else head = rotateHelper ( head , temp , d % k , & tail , k ) ;
tail -> next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
void push ( struct Node * * head_ref , int new_data ) { struct Node * new_node = new Node ; new_node -> data = new_data ; new_node -> next = ( * head_ref ) ; ( * head_ref ) = new_node ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
int main ( ) {
struct Node * head = NULL ;
for ( int i = 9 ; i > 0 ; i -= 1 ) push ( & head , i ) ; printf ( " Given ▁ linked ▁ list ▁ STRNEWLINE " ) ; printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; printf ( " Rotated by blocks Linked list " printList ( head ) ; return ( 0 ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ;
void setMiddleHead ( struct Node * * head ) { if ( * head == NULL ) return ;
struct Node * one_node = ( * head ) ;
struct Node * two_node = ( * head ) ;
struct Node * prev = NULL ; while ( two_node != NULL && two_node -> next != NULL ) {
prev = one_node ;
two_node = two_node -> next -> next ;
one_node = one_node -> next ; }
prev -> next = prev -> next -> next ; one_node -> next = ( * head ) ; ( * head ) = one_node ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( struct Node * ptr ) { while ( ptr != NULL ) { printf ( " % d ▁ " , ptr -> data ) ; ptr = ptr -> next ; } printf ( " STRNEWLINE " ) ; }
int main ( ) {
struct Node * head = NULL ; int i ; for ( i = 5 ; i > 0 ; i -- ) push ( & head , i ) ; printf ( " ▁ list ▁ before : ▁ " ) ; printList ( head ) ; setMiddleHead ( & head ) ; printf ( " ▁ list ▁ After : ▁ " ) ; printList ( head ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #include <inttypes.h>
struct Node { int data ; struct Node * npx ;
} ;
struct Node * XOR ( struct Node * a , struct Node * b ) { return ( struct Node * ) ( ( uintptr_t ) ( a ) ^ ( uintptr_t ) ( b ) ) ; }
void insert ( struct Node * * head_ref , int data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = data ;
new_node -> npx = * head_ref ;
if ( * head_ref != NULL ) {
( * head_ref ) -> npx = XOR ( new_node , ( * head_ref ) -> npx ) ; }
* head_ref = new_node ; }
void printList ( struct Node * head ) { struct Node * curr = head ; struct Node * prev = NULL ; struct Node * next ; printf ( " Following ▁ are ▁ the ▁ nodes ▁ of ▁ Linked ▁ List : ▁ STRNEWLINE " ) ; while ( curr != NULL ) {
printf ( " % d ▁ " , curr -> data ) ;
next = XOR ( prev , curr -> npx ) ;
prev = curr ; curr = next ; } }
int main ( ) {
struct Node * head = NULL ; insert ( & head , 10 ) ; insert ( & head , 20 ) ; insert ( & head , 30 ) ; insert ( & head , 40 ) ;
printList ( head ) ; return ( 0 ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ; void printKDistant ( struct node * root , int k ) { if ( root == NULL k < 0 ) return ; if ( k == 0 ) { printf ( " % d ▁ " , root -> data ) ; return ; } printKDistant ( root -> left , k - 1 ) ; printKDistant ( root -> right , k - 1 ) ; }
int main ( ) {
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 8 ) ; printKDistant ( root , 2 ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <malloc.h> NEW_LINE #define COUNT  10
struct Node { int data ; struct Node * left , * right ; } ;
struct Node * newNode ( int data ) { struct Node * node = malloc ( sizeof ( struct Node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return node ; }
void print2DUtil ( struct Node * root , int space ) {
if ( root == NULL ) return ;
space += COUNT ;
print2DUtil ( root -> right , space ) ;
printf ( " STRNEWLINE " ) ; for ( int i = COUNT ; i < space ; i ++ ) printf ( " ▁ " ) ; printf ( " % d STRNEWLINE " , root -> data ) ;
print2DUtil ( root -> left , space ) ; }
void print2D ( struct Node * root ) {
print2DUtil ( root , 0 ) ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> left -> left -> left = newNode ( 8 ) ; root -> left -> left -> right = newNode ( 9 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 11 ) ; root -> right -> left -> left = newNode ( 12 ) ; root -> right -> left -> right = newNode ( 13 ) ; root -> right -> right -> left = newNode ( 14 ) ; root -> right -> right -> right = newNode ( 15 ) ; print2D ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int data ; struct node * left , * right ; } ;
struct node * newNode ( int item ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = item ; temp -> left = temp -> right = NULL ; return temp ; }
void leftViewUtil ( struct node * root , int level , int * max_level ) {
if ( root == NULL ) return ;
if ( * max_level < level ) { printf ( " % d TABSYMBOL " , root -> data ) ; * max_level = level ; }
leftViewUtil ( root -> left , level + 1 , max_level ) ; leftViewUtil ( root -> right , level + 1 , max_level ) ; }
void leftView ( struct node * root ) { int max_level = 0 ; leftViewUtil ( root , 1 , & max_level ) ; }
int main ( ) { struct node * root = newNode ( 12 ) ; root -> left = newNode ( 10 ) ; root -> right = newNode ( 30 ) ; root -> right -> left = newNode ( 25 ) ; root -> right -> right = newNode ( 40 ) ; leftView ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
unsigned int getLeafCount ( struct node * node ) { if ( node == NULL ) return 0 ; if ( node -> left == NULL && node -> right == NULL ) return 1 ; else return getLeafCount ( node -> left ) + getLeafCount ( node -> right ) ; }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( ) {
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ;
printf ( " Leaf ▁ count ▁ of ▁ the ▁ tree ▁ is ▁ % d " , getLeafCount ( root ) ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <string.h>
int cntRotations ( char s [ ] , int n ) { int lh = 0 , rh = 0 , i , ans = 0 ;
for ( i = 0 ; i < n / 2 ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { lh ++ ; }
for ( i = n / 2 ; i < n ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { rh ++ ; }
if ( lh > rh ) ans ++ ;
for ( i = 1 ; i < n ; ++ i ) { if ( s [ i - 1 ] == ' a ' s [ i - 1 ] == ' e ' s [ i - 1 ] == ' i ' s [ i - 1 ] == ' o ' s [ i - 1 ] == ' u ' ) { rh ++ ; lh -- ; } if ( s [ ( i - 1 + n / 2 ) % n ] == ' a ' || s [ ( i - 1 + n / 2 ) % n ] == ' e ' || s [ ( i - 1 + n / 2 ) % n ] == ' i ' || s [ ( i - 1 + n / 2 ) % n ] == ' o ' || s [ ( i - 1 + n / 2 ) % n ] == ' u ' ) { rh -- ; lh ++ ; } if ( lh > rh ) ans ++ ; }
return ans ; }
int main ( ) { char s [ ] = " abecidft " ; int n = strlen ( s ) ;
printf ( " % d " , cntRotations ( s , n ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ;
struct Node * rotateHelper ( struct Node * blockHead , struct Node * blockTail , int d , struct Node * * tail , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { struct Node * temp = blockHead ; for ( int i = 1 ; temp -> next -> next && i < k - 1 ; i ++ ) temp = temp -> next ; blockTail -> next = blockHead ; * tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , tail , k ) ; }
if ( d < 0 ) { blockTail -> next = blockHead ; * tail = blockHead ; return rotateHelper ( blockHead -> next , blockHead , d + 1 , tail , k ) ; } }
struct Node * rotateByBlocks ( struct Node * head , int k , int d ) {
if ( ! head ! head -> next ) return head ;
if ( d == 0 ) return head ; struct Node * temp = head , * tail = NULL ;
int i ; for ( i = 1 ; temp -> next && i < k ; i ++ ) temp = temp -> next ;
struct Node * nextBlock = temp -> next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , & tail , i ) ; else head = rotateHelper ( head , temp , d % k , & tail , k ) ;
tail -> next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
void push ( struct Node * * head_ref , int new_data ) { struct Node * new_node = new Node ; new_node -> data = new_data ; new_node -> next = ( * head_ref ) ; ( * head_ref ) = new_node ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
int main ( ) {
struct Node * head = NULL ;
for ( int i = 9 ; i > 0 ; i -= 1 ) push ( & head , i ) ; printf ( " Given ▁ linked ▁ list ▁ STRNEWLINE " ) ; printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; printf ( " Rotated by blocks Linked list " printList ( head ) ; return ( 0 ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; struct node * nextRight ; } ; struct node * newnode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; node -> nextRight = NULL ; return ( node ) ; }
struct node * getNextRight ( struct node * p ) { struct node * temp = p -> nextRight ;
while ( temp != NULL ) { if ( temp -> left != NULL ) return temp -> left ; if ( temp -> right != NULL ) return temp -> right ; temp = temp -> nextRight ; }
return NULL ; }
void connect ( struct node * p ) { struct node * temp ; if ( ! p ) return ;
p -> nextRight = NULL ;
while ( p != NULL ) { struct node * q = p ;
while ( q != NULL ) {
if ( q -> left ) {
if ( q -> right ) q -> left -> nextRight = q -> right ; else q -> left -> nextRight = getNextRight ( q ) ; } if ( q -> right ) q -> right -> nextRight = getNextRight ( q ) ;
q = q -> nextRight ; }
if ( p -> left ) p = p -> left ; else if ( p -> right ) p = p -> right ; else p = getNextRight ( p ) ; } }
int main ( ) {
struct node * root = newnode ( 10 ) ; root -> left = newnode ( 8 ) ; root -> right = newnode ( 2 ) ; root -> left -> left = newnode ( 3 ) ; root -> right -> right = newnode ( 90 ) ;
connect ( root ) ;
printf ( " Following ▁ are ▁ populated ▁ nextRight ▁ pointers ▁ in ▁ the ▁ tree ▁ " " ( -1 ▁ is ▁ printed ▁ if ▁ there ▁ is ▁ no ▁ nextRight ) ▁ STRNEWLINE " ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> data , root -> nextRight ? root -> nextRight -> data : -1 ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> left -> data , root -> left -> nextRight ? root -> left -> nextRight -> data : -1 ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> right -> data , root -> right -> nextRight ? root -> right -> nextRight -> data : -1 ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> left -> left -> data , root -> left -> left -> nextRight ? root -> left -> left -> nextRight -> data : -1 ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> right -> right -> data , root -> right -> right -> nextRight ? root -> right -> right -> nextRight -> data : -1 ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE void connectRecur ( struct node * p ) ;
struct node { int data ; struct node * left ; struct node * right ; struct node * nextRight ; } ;
void connect ( struct node * p ) {
p -> nextRight = NULL ;
connectRecur ( p ) ; }
void connectRecur ( struct node * p ) {
if ( ! p ) return ;
if ( p -> left ) p -> left -> nextRight = p -> right ;
if ( p -> right ) p -> right -> nextRight = ( p -> nextRight ) ? p -> nextRight -> left : NULL ;
connectRecur ( p -> left ) ; connectRecur ( p -> right ) ; }
int main ( ) {
struct node * root = newnode ( 10 ) ; root -> left = newnode ( 8 ) ; root -> right = newnode ( 2 ) ; root -> left -> left = newnode ( 3 ) ;
connect ( root ) ;
printf ( " Following ▁ are ▁ populated ▁ nextRight ▁ pointers ▁ in ▁ the ▁ tree ▁ " " ( -1 ▁ is ▁ printed ▁ if ▁ there ▁ is ▁ no ▁ nextRight ) ▁ STRNEWLINE " ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> data , root -> nextRight ? root -> nextRight -> data : -1 ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> left -> data , root -> left -> nextRight ? root -> left -> nextRight -> data : -1 ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> right -> data , root -> right -> nextRight ? root -> right -> nextRight -> data : -1 ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> left -> left -> data , root -> left -> left -> nextRight ? root -> left -> left -> nextRight -> data : -1 ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; struct node * next ; }
void populateNext ( struct node * root ) {
struct node * next = NULL ; populateNextRecur ( root , & next ) ; }
void populateNextRecur ( struct node * p , struct node * * next_ref ) { if ( p ) {
populateNextRecur ( p -> right , next_ref ) ;
p -> next = * next_ref ;
* next_ref = p ;
populateNextRecur ( p -> left , next_ref ) ; } }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
int getLevelUtil ( struct node * node , int data , int level ) { if ( node == NULL ) return 0 ; if ( node -> data == data ) return level ; int downlevel = getLevelUtil ( node -> left , data , level + 1 ) ; if ( downlevel != 0 ) return downlevel ; downlevel = getLevelUtil ( node -> right , data , level + 1 ) ; return downlevel ; }
int getLevel ( struct node * node , int data ) { return getLevelUtil ( node , data , 1 ) ; }
struct node * newNode ( int data ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = data ; temp -> left = NULL ; temp -> right = NULL ; return temp ; }
int main ( ) { struct node * root ; int x ;
root = newNode ( 3 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 5 ) ; root -> left -> left = newNode ( 1 ) ; root -> left -> right = newNode ( 4 ) ; for ( x = 1 ; x <= 5 ; x ++ ) { int level = getLevel ( root , x ) ; if ( level ) printf ( " ▁ Level ▁ of ▁ % d ▁ is ▁ % d STRNEWLINE " , x , getLevel ( root , x ) ) ; else printf ( " ▁ % d ▁ is ▁ not ▁ present ▁ in ▁ tree ▁ STRNEWLINE " , x ) ; } getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int key ; struct Node * left , * right ; } ;
struct Node * newNode ( int key ) { struct Node * n = ( struct Node * ) malloc ( sizeof ( struct Node * ) ) ; if ( n != NULL ) { n -> key = key ; n -> left = NULL ; n -> right = NULL ; return n ; } else { printf ( " Memory ▁ allocation ▁ failed ! " ) ; exit ( 1 ) ; } }
int findMirrorRec ( int target , struct Node * left , struct Node * right ) {
if ( left == NULL right == NULL ) return 0 ;
if ( left -> key == target ) return right -> key ; if ( right -> key == target ) return left -> key ;
int mirror_val = findMirrorRec ( target , left -> left , right -> right ) ; if ( mirror_val ) return mirror_val ;
findMirrorRec ( target , left -> right , right -> left ) ; }
int findMirror ( struct Node * root , int target ) { if ( root == NULL ) return 0 ; if ( root -> key == target ) return target ; return findMirrorRec ( target , root -> left , root -> right ) ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> left -> right = newNode ( 7 ) ; root -> right = newNode ( 3 ) ; root -> right -> left = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; root -> right -> left -> left = newNode ( 8 ) ; root -> right -> left -> right = newNode ( 9 ) ;
int target = root -> left -> left -> key ; int mirror = findMirror ( root , target ) ; if ( mirror ) printf ( " Mirror ▁ of ▁ Node ▁ % d ▁ is ▁ Node ▁ % d STRNEWLINE " , target , mirror ) ; else printf ( " Mirror ▁ of ▁ Node ▁ % d ▁ is ▁ NULL ! STRNEWLINE " , target ) ; }
#include <iostream> NEW_LINE #include <queue> NEW_LINE using namespace std ;
struct node { int data ; struct node * left , * right ; } ;
struct node * newNode ( int data ) { struct node * node = new struct node ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
bool iterativeSearch ( node * root , int x ) {
if ( root == NULL ) return false ;
queue < node * > q ;
q . push ( root ) ;
while ( q . empty ( ) == false ) {
node * node = q . front ( ) ; if ( node -> data == x ) return true ;
q . pop ( ) ; if ( node -> left != NULL ) q . push ( node -> left ) ; if ( node -> right != NULL ) q . push ( node -> right ) ; } return false ; }
int main ( void ) { struct node * NewRoot = NULL ; struct node * root = newNode ( 2 ) ; root -> left = newNode ( 7 ) ; root -> right = newNode ( 5 ) ; root -> left -> right = newNode ( 6 ) ; root -> left -> right -> left = newNode ( 1 ) ; root -> left -> right -> right = newNode ( 11 ) ; root -> right -> right = newNode ( 9 ) ; root -> right -> right -> left = newNode ( 4 ) ; iterativeSearch ( root , 6 ) ? cout << " Found STRNEWLINE " : cout << " Not ▁ Found STRNEWLINE " ; iterativeSearch ( root , 12 ) ? cout << " Found STRNEWLINE " : cout << " Not ▁ Found STRNEWLINE " ; return 0 ; }
#include <limits.h> NEW_LINE #include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * left , * right ; } ;
struct Node * newNode ( int data ) { struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
int findMax ( struct Node * root ) {
if ( root == NULL ) return INT_MIN ;
int res = root -> data ; int lres = findMax ( root -> left ) ; int rres = findMax ( root -> right ) ; if ( lres > res ) res = lres ; if ( rres > res ) res = rres ; return res ; }
int main ( void ) { struct Node * NewRoot = NULL ; struct Node * root = newNode ( 2 ) ; root -> left = newNode ( 7 ) ; root -> right = newNode ( 5 ) ; root -> left -> right = newNode ( 6 ) ; root -> left -> right -> left = newNode ( 1 ) ; root -> left -> right -> right = newNode ( 11 ) ; root -> right -> right = newNode ( 9 ) ; root -> right -> right -> left = newNode ( 4 ) ;
printf ( " Maximum ▁ element ▁ is ▁ % d ▁ STRNEWLINE " , findMax ( root ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * left , * right ; } ;
struct Node * extractLeafList ( struct Node * root , struct Node * * head_ref ) { if ( root == NULL ) return NULL ; if ( root -> left == NULL && root -> right == NULL ) { root -> right = * head_ref ; if ( * head_ref != NULL ) ( * head_ref ) -> left = root ; return NULL ; } root -> right = extractLeafList ( root -> right , head_ref ) ; root -> left = extractLeafList ( root -> left , head_ref ) ; return root ; }
struct Node * newNode ( int data ) { struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return node ; }
void print ( struct Node * root ) { if ( root != NULL ) { print ( root -> left ) ; printf ( " % d ▁ " , root -> data ) ; print ( root -> right ) ; } }
void printList ( struct Node * head ) { while ( head ) { printf ( " % d ▁ " , head -> data ) ; head = head -> right ; } }
int main ( ) { struct Node * head = NULL ; struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; root -> left -> left -> left = newNode ( 7 ) ; root -> left -> left -> right = newNode ( 8 ) ; root -> right -> right -> left = newNode ( 9 ) ; root -> right -> right -> right = newNode ( 10 ) ; printf ( " Inorder ▁ Trvaersal ▁ of ▁ given ▁ Tree ▁ is : STRNEWLINE " ) ; print ( root ) ; root = extractLeafList ( root , & head ) ; printf ( " Extracted Double Linked list is : " printList ( head ) ; printf ( " Inorder traversal of modified tree is : " print ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #define N  8 NEW_LINE int solveKTUtil ( int x , int y , int movei , int sol [ N ] [ N ] , int xMove [ ] , int yMove [ ] ) ;
int isSafe ( int x , int y , int sol [ N ] [ N ] ) { return ( x >= 0 && x < N && y >= 0 && y < N && sol [ x ] [ y ] == -1 ) ; }
void printSolution ( int sol [ N ] [ N ] ) { for ( int x = 0 ; x < N ; x ++ ) { for ( int y = 0 ; y < N ; y ++ ) printf ( " ▁ % 2d ▁ " , sol [ x ] [ y ] ) ; printf ( " STRNEWLINE " ) ; } }
int solveKT ( ) { int sol [ N ] [ N ] ;
for ( int x = 0 ; x < N ; x ++ ) for ( int y = 0 ; y < N ; y ++ ) sol [ x ] [ y ] = -1 ;
int xMove [ 8 ] = { 2 , 1 , -1 , -2 , -2 , -1 , 1 , 2 } ; int yMove [ 8 ] = { 1 , 2 , 2 , 1 , -1 , -2 , -2 , -1 } ;
sol [ 0 ] [ 0 ] = 0 ;
if ( solveKTUtil ( 0 , 0 , 1 , sol , xMove , yMove ) == 0 ) { printf ( " Solution ▁ does ▁ not ▁ exist " ) ; return 0 ; } else printSolution ( sol ) ; return 1 ; }
int solveKTUtil ( int x , int y , int movei , int sol [ N ] [ N ] , int xMove [ N ] , int yMove [ N ] ) { int k , next_x , next_y ; if ( movei == N * N ) return 1 ;
for ( k = 0 ; k < 8 ; k ++ ) { next_x = x + xMove [ k ] ; next_y = y + yMove [ k ] ; if ( isSafe ( next_x , next_y , sol ) ) { sol [ next_x ] [ next_y ] = movei ; if ( solveKTUtil ( next_x , next_y , movei + 1 , sol , xMove , yMove ) == 1 ) return 1 ; else
sol [ next_x ] [ next_y ] = -1 ; } } return 0 ; }
int main ( ) {
solveKT ( ) ; return 0 ; }
#include <stdbool.h> NEW_LINE #include <stdio.h>
#define V  4 NEW_LINE void printSolution ( int color [ ] ) ;
void printSolution ( int color [ ] ) { printf ( " Solution ▁ Exists : " " ▁ Following ▁ are ▁ the ▁ assigned ▁ colors ▁ STRNEWLINE " ) ; for ( int i = 0 ; i < V ; i ++ ) printf ( " ▁ % d ▁ " , color [ i ] ) ; printf ( " STRNEWLINE " ) ; }
bool isSafe ( bool graph [ V ] [ V ] , int color [ ] ) {
for ( int i = 0 ; i < V ; i ++ ) for ( int j = i + 1 ; j < V ; j ++ ) if ( graph [ i ] [ j ] && color [ j ] == color [ i ] ) return false ; return true ; }
bool graphColoring ( bool graph [ V ] [ V ] , int m , int i , int color [ V ] ) {
if ( i == V ) {
if ( isSafe ( graph , color ) ) {
printSolution ( color ) ; return true ; } return false ; }
for ( int j = 1 ; j <= m ; j ++ ) { color [ i ] = j ;
if ( graphColoring ( graph , m , i + 1 , color ) ) return true ; color [ i ] = 0 ; } return false ; }
int main ( ) {
bool graph [ V ] [ V ] = { { 0 , 1 , 1 , 1 } , { 1 , 0 , 1 , 0 } , { 1 , 1 , 0 , 1 } , { 1 , 0 , 1 , 0 } , } ;
int m = 3 ;
int color [ V ] ; for ( int i = 0 ; i < V ; i ++ ) color [ i ] = 0 ; if ( ! graphColoring ( graph , m , 0 , color ) ) printf ( " Solution ▁ does ▁ not ▁ exist " ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
void printGivenLevel ( struct node * root , int level ) ; int height ( struct node * node ) ; struct node * newNode ( int data ) ;
void reverseLevelOrder ( struct node * root ) { int h = height ( root ) ; int i ; for ( i = h ; i >= 1 ; i -- ) printGivenLevel ( root , i ) ; }
void printGivenLevel ( struct node * root , int level ) { if ( root == NULL ) return ; if ( level == 1 ) printf ( " % d ▁ " , root -> data ) ; else if ( level > 1 ) { printGivenLevel ( root -> left , level - 1 ) ; printGivenLevel ( root -> right , level - 1 ) ; } }
int height ( struct node * node ) { if ( node == NULL ) return 0 ; else {
int lheight = height ( node -> left ) ; int rheight = height ( node -> right ) ;
if ( lheight > rheight ) return ( lheight + 1 ) ; else return ( rheight + 1 ) ; } }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( ) {
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; printf ( " Level ▁ Order ▁ traversal ▁ of ▁ binary ▁ tree ▁ is ▁ STRNEWLINE " ) ; reverseLevelOrder ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int data ; struct node * left , * right ; } ;
struct node * newNode ( int data ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
void morrisTraversalPreorder ( struct node * root ) { while ( root ) {
if ( root -> left == NULL ) { printf ( " % d ▁ " , root -> data ) ; root = root -> right ; } else {
struct node * current = root -> left ; while ( current -> right && current -> right != root ) current = current -> right ;
if ( current -> right == root ) { current -> right = NULL ; root = root -> right ; }
else { printf ( " % d ▁ " , root -> data ) ; current -> right = root ; root = root -> left ; } } } }
void preorder ( struct node * root ) { if ( root ) { printf ( " % d ▁ " , root -> data ) ; preorder ( root -> left ) ; preorder ( root -> right ) ; } }
int main ( ) { struct node * root = NULL ; root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> left -> left -> left = newNode ( 8 ) ; root -> left -> left -> right = newNode ( 9 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 11 ) ; morrisTraversalPreorder ( root ) ; printf ( " STRNEWLINE " ) ; preorder ( root ) ; return 0 ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void insertAfter ( struct Node * prev_node , int new_data ) {
if ( prev_node == NULL ) { printf ( " the ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL " ) ; return ; }
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = prev_node -> next ;
prev_node -> next = new_node ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ; void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; } int detectLoop ( struct Node * list ) { struct Node * slow_p = list , * fast_p = list ; while ( slow_p && fast_p && fast_p -> next ) { slow_p = slow_p -> next ; fast_p = fast_p -> next -> next ; if ( slow_p == fast_p ) { return 1 ; } } return 0 ; }
int main ( ) {
struct Node * head = NULL ; push ( & head , 20 ) ; push ( & head , 4 ) ; push ( & head , 15 ) ; push ( & head , 10 ) ;
head -> next -> next -> next -> next = head ; if ( detectLoop ( head ) ) printf ( " Loop ▁ found " ) ; else printf ( " No ▁ Loop " ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct Node { int data ; struct Node * next ; } ;
void swapNodes ( struct Node * * head_ref , int x , int y ) {
if ( x == y ) return ;
struct Node * prevX = NULL , * currX = * head_ref ; while ( currX && currX -> data != x ) { prevX = currX ; currX = currX -> next ; }
struct Node * prevY = NULL , * currY = * head_ref ; while ( currY && currY -> data != y ) { prevY = currY ; currY = currY -> next ; }
if ( currX == NULL currY == NULL ) return ;
if ( prevX != NULL ) prevX -> next = currY ;
else * head_ref = currY ;
if ( prevY != NULL ) prevY -> next = currX ;
else * head_ref = currX ;
struct Node * temp = currY -> next ; currY -> next = currX -> next ; currX -> next = temp ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
int main ( ) { struct Node * start = NULL ;
push ( & start , 7 ) ; push ( & start , 6 ) ; push ( & start , 5 ) ; push ( & start , 4 ) ; push ( & start , 3 ) ; push ( & start , 2 ) ; push ( & start , 1 ) ; printf ( " Linked list before calling swapNodes ( ) " printList ( start ) ; swapNodes ( & start , 4 , 3 ) ; printf ( " Linked list after calling swapNodes ( ) " printList ( start ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { struct Node * prev ; int info ; struct Node * next ; } ;
void nodeInsetail ( struct Node * * head , struct Node * * tail , int key ) { struct Node * p = new Node ; p -> info = key ; p -> next = NULL ;
if ( ( * head ) == NULL ) { ( * head ) = p ; ( * tail ) = p ; ( * head ) -> prev = NULL ; return ; }
if ( ( p -> info ) < ( ( * head ) -> info ) ) { p -> prev = NULL ; ( * head ) -> prev = p ; p -> next = ( * head ) ; ( * head ) = p ; return ; }
if ( ( p -> info ) > ( ( * tail ) -> info ) ) { p -> prev = ( * tail ) ; ( * tail ) -> next = p ; ( * tail ) = p ; return ; }
temp = ( * head ) -> next ; while ( ( temp -> info ) < ( p -> info ) ) temp = temp -> next ;
( temp -> prev ) -> next = p ; p -> prev = temp -> prev ; temp -> prev = p ; p -> next = temp ; }
void printList ( struct Node * temp ) { while ( temp != NULL ) { printf ( " % d ▁ " , temp -> info ) ; temp = temp -> next ; } }
int main ( ) { struct Node * left = NULL , * right = NULL ; nodeInsetail ( & left , & right , 30 ) ; nodeInsetail ( & left , & right , 50 ) ; nodeInsetail ( & left , & right , 90 ) ; nodeInsetail ( & left , & right , 10 ) ; nodeInsetail ( & left , & right , 40 ) ; nodeInsetail ( & left , & right , 110 ) ; nodeInsetail ( & left , & right , 60 ) ; nodeInsetail ( & left , & right , 95 ) ; nodeInsetail ( & left , & right , 23 ) ; printf ( " Doubly linked list on printing " ▁ " from left to right " printList ( left ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void fun1 ( struct Node * head ) { if ( head == NULL ) return ; fun1 ( head -> next ) ; printf ( " % d ▁ " , head -> data ) ; }
void fun2 ( struct Node * head ) { if ( head == NULL ) return ; printf ( " % d ▁ " , head -> data ) ; if ( head -> next != NULL ) fun2 ( head -> next -> next ) ; printf ( " % d ▁ " , head -> data ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ;
void fun1 ( struct Node * head ) { if ( head == NULL ) return ; fun1 ( head -> next ) ; printf ( " % d ▁ " , head -> data ) ; }
void fun2 ( struct Node * start ) { if ( start == NULL ) return ; printf ( " % d ▁ " , start -> data ) ; if ( start -> next != NULL ) fun2 ( start -> next -> next ) ; printf ( " % d ▁ " , start -> data ) ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
int main ( ) {
struct Node * head = NULL ;
push ( & head , 5 ) ; push ( & head , 4 ) ; push ( & head , 3 ) ; push ( & head , 2 ) ; push ( & head , 1 ) ; printf ( " Output ▁ of ▁ fun1 ( ) ▁ for ▁ list ▁ 1 - > 2 - > 3 - > 4 - > 5 ▁ STRNEWLINE " ) ; fun1 ( head ) ; printf ( " Output of fun2 ( ) for list 1 -> 2 -> 3 -> 4 -> 5 " fun2 ( head ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ;
int printsqrtn ( struct Node * head ) { struct Node * sqrtn = NULL ; int i = 1 , j = 1 ;
while ( head != NULL ) {
if ( i == j * j ) {
if ( sqrtn == NULL ) sqrtn = head ; else sqrtn = sqrtn -> next ;
j ++ ; } i ++ ; head = head -> next ; }
return sqrtn -> data ; } void print ( struct Node * head ) { while ( head != NULL ) { printf ( " % d ▁ " , head -> data ) ; head = head -> next ; } printf ( " STRNEWLINE " ) ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
int main ( ) {
struct Node * head = NULL ; push ( & head , 40 ) ; push ( & head , 30 ) ; push ( & head , 20 ) ; push ( & head , 10 ) ; printf ( " Given ▁ linked ▁ list ▁ is : " ) ; print ( head ) ; printf ( " sqrt ( n ) th ▁ node ▁ is ▁ % d ▁ " , printsqrtn ( head ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { char data ; struct node * left ; struct node * right ; } ;
int search ( char arr [ ] , int strt , int end , char value ) ; struct node * newNode ( char data ) ;
struct node * buildTree ( char in [ ] , char pre [ ] , int inStrt , int inEnd ) { static int preIndex = 0 ; if ( inStrt > inEnd ) return NULL ;
struct node * tNode = newNode ( pre [ preIndex ++ ] ) ;
if ( inStrt == inEnd ) return tNode ;
int inIndex = search ( in , inStrt , inEnd , tNode -> data ) ;
tNode -> left = buildTree ( in , pre , inStrt , inIndex - 1 ) ; tNode -> right = buildTree ( in , pre , inIndex + 1 , inEnd ) ; return tNode ; }
int search ( char arr [ ] , int strt , int end , char value ) { int i ; for ( i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) return i ; } }
struct node * newNode ( char data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
void printInorder ( struct node * node ) { if ( node == NULL ) return ;
printInorder ( node -> left ) ;
printf ( " % c ▁ " , node -> data ) ;
printInorder ( node -> right ) ; }
int main ( ) { char in [ ] = { ' D ' , ' B ' , ' E ' , ' A ' , ' F ' , ' C ' } ; char pre [ ] = { ' A ' , ' B ' , ' D ' , ' E ' , ' C ' , ' F ' } ; int len = sizeof ( in ) / sizeof ( in [ 0 ] ) ; struct node * root = buildTree ( in , pre , 0 , len - 1 ) ;
printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ constructed ▁ tree ▁ is ▁ STRNEWLINE " ) ; printInorder ( root ) ; getchar ( ) ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
struct node * insert ( struct node * node , int data ) {
if ( node == NULL ) return ( newNode ( data ) ) ; else {
if ( data <= node -> data ) node -> left = insert ( node -> left , data ) ; else node -> right = insert ( node -> right , data ) ;
return node ; } }
int minValue ( struct node * node ) { struct node * current = node ;
while ( current -> left != NULL ) { current = current -> left ; } return ( current -> data ) ; }
int main ( ) { struct node * root = NULL ; root = insert ( root , 4 ) ; insert ( root , 2 ) ; insert ( root , 1 ) ; insert ( root , 3 ) ; insert ( root , 6 ) ; insert ( root , 5 ) ; printf ( " Minimum value in BST is % d " , minValue ( root ) ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int data ; struct node * left , * right ; } ;
struct node * lca ( struct node * root , int n1 , int n2 ) { if ( root == NULL ) return NULL ;
if ( root -> data > n1 && root -> data > n2 ) return lca ( root -> left , n1 , n2 ) ;
if ( root -> data < n1 && root -> data < n2 ) return lca ( root -> right , n1 , n2 ) ; return root ; }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
int main ( ) {
struct node * root = newNode ( 20 ) ; root -> left = newNode ( 8 ) ; root -> right = newNode ( 22 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 12 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 14 ) ; int n1 = 10 , n2 = 14 ; struct node * t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; n1 = 14 , n2 = 8 ; t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; n1 = 10 , n2 = 22 ; t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int data ; struct node * left , * right ; } ;
struct node * lca ( struct node * root , int n1 , int n2 ) { while ( root != NULL ) {
if ( root -> data > n1 && root -> data > n2 ) root = root -> left ;
else if ( root -> data < n1 && root -> data < n2 ) root = root -> right ; else break ; } return root ; }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
int main ( ) {
struct node * root = newNode ( 20 ) ; root -> left = newNode ( 8 ) ; root -> right = newNode ( 22 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 12 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 14 ) ; int n1 = 10 , n2 = 14 ; struct node * t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; n1 = 14 , n2 = 8 ; t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; n1 = 10 , n2 = 22 ; t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; getchar ( ) ; return 0 ; }
int isBST ( struct node * node ) { if ( node == NULL ) return 1 ;
if ( node -> left != NULL && node -> left -> data > node -> data ) return 0 ;
if ( node -> right != NULL && node -> right -> data < node -> data ) return 0 ;
if ( ! isBST ( node -> left ) || ! isBST ( node -> right ) ) return 0 ;
return 1 ; }
int isBST ( struct node * node ) { if ( node == NULL ) return 1 ;
if ( node -> left != NULL && maxValue ( node -> left ) > node -> data ) return 0 ;
if ( node -> right != NULL && minValue ( node -> right ) < node -> data ) return 0 ;
if ( ! isBST ( node -> left ) || ! isBST ( node -> right ) ) return 0 ;
return 1 ; }
#include <stdio.h>
struct node { int key ; struct node * left ; struct node * right ; } ;
void convertBSTtoDLL ( node * root , node * * head , node * * tail ) {
if ( root == NULL ) return ;
if ( root -> left ) convertBSTtoDLL ( root -> left , head , tail ) ;
root -> left = * tail ;
if ( * tail ) ( * tail ) -> right = root ; else * head = root ;
* tail = root ;
if ( root -> right ) convertBSTtoDLL ( root -> right , head , tail ) ; }
bool isPresentInDLL ( node * head , node * tail , int sum ) { while ( head != tail ) { int curr = head -> key + tail -> key ; if ( curr == sum ) return true ; else if ( curr > sum ) tail = tail -> left ; else head = head -> right ; } return false ; }
bool isTripletPresent ( node * root ) {
if ( root == NULL ) return false ;
node * head = NULL ; node * tail = NULL ; convertBSTtoDLL ( root , & head , & tail ) ;
while ( ( head -> right != tail ) && ( head -> key < 0 ) ) {
if ( isPresentInDLL ( head -> right , tail , -1 * head -> key ) ) return true ; else head = head -> right ; }
return false ; }
node * newNode ( int num ) { node * temp = new node ; temp -> key = num ; temp -> left = temp -> right = NULL ; return temp ; }
node * insert ( node * root , int key ) { if ( root == NULL ) return newNode ( key ) ; if ( root -> key > key ) root -> left = insert ( root -> left , key ) ; else root -> right = insert ( root -> right , key ) ; return root ; }
int main ( ) { node * root = NULL ; root = insert ( root , 6 ) ; root = insert ( root , -13 ) ; root = insert ( root , 14 ) ; root = insert ( root , -8 ) ; root = insert ( root , 15 ) ; root = insert ( root , 13 ) ; root = insert ( root , 7 ) ; if ( isTripletPresent ( root ) ) printf ( " Present " ) ; else printf ( " Not ▁ Present " ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #define MAX_SIZE  100
struct node { int val ; struct node * left , * right ; } ;
struct Stack { int size ; int top ; struct node * * array ; } ;
struct Stack * createStack ( int size ) { struct Stack * stack = ( struct Stack * ) malloc ( sizeof ( struct Stack ) ) ; stack -> size = size ; stack -> top = -1 ; stack -> array = ( struct node * * ) malloc ( stack -> size * sizeof ( struct node * ) ) ; return stack ; }
int isFull ( struct Stack * stack ) { return stack -> top - 1 == stack -> size ; } int isEmpty ( struct Stack * stack ) { return stack -> top == -1 ; } void push ( struct Stack * stack , struct node * node ) { if ( isFull ( stack ) ) return ; stack -> array [ ++ stack -> top ] = node ; } struct node * pop ( struct Stack * stack ) { if ( isEmpty ( stack ) ) return NULL ; return stack -> array [ stack -> top -- ] ; }
bool isPairPresent ( struct node * root , int target ) {
struct Stack * s1 = createStack ( MAX_SIZE ) ; struct Stack * s2 = createStack ( MAX_SIZE ) ;
bool done1 = false , done2 = false ; int val1 = 0 , val2 = 0 ; struct node * curr1 = root , * curr2 = root ;
while ( 1 ) {
while ( done1 == false ) { if ( curr1 != NULL ) { push ( s1 , curr1 ) ; curr1 = curr1 -> left ; } else { if ( isEmpty ( s1 ) ) done1 = 1 ; else { curr1 = pop ( s1 ) ; val1 = curr1 -> val ; curr1 = curr1 -> right ; done1 = 1 ; } } }
while ( done2 == false ) { if ( curr2 != NULL ) { push ( s2 , curr2 ) ; curr2 = curr2 -> right ; } else { if ( isEmpty ( s2 ) ) done2 = 1 ; else { curr2 = pop ( s2 ) ; val2 = curr2 -> val ; curr2 = curr2 -> left ; done2 = 1 ; } } }
if ( ( val1 != val2 ) && ( val1 + val2 ) == target ) { printf ( " Pair Found : % d + % d = % d " , val1 , val2 , target ) ; return true ; }
else if ( ( val1 + val2 ) < target ) done1 = false ;
else if ( ( val1 + val2 ) > target ) done2 = false ;
if ( val1 >= val2 ) return false ; } }
struct node * NewNode ( int val ) { struct node * tmp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; tmp -> val = val ; tmp -> right = tmp -> left = NULL ; return tmp ; }
int main ( ) {
struct node * root = NewNode ( 15 ) ; root -> left = NewNode ( 10 ) ; root -> right = NewNode ( 20 ) ; root -> left -> left = NewNode ( 8 ) ; root -> left -> right = NewNode ( 12 ) ; root -> right -> left = NewNode ( 16 ) ; root -> right -> right = NewNode ( 25 ) ; int target = 33 ; if ( isPairPresent ( root , target ) == false ) printf ( " No such values are found " getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
struct node * newNode ( int data ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
struct node * constructTreeUtil ( int pre [ ] , int post [ ] , int * preIndex , int l , int h , int size ) {
if ( * preIndex >= size l > h ) return NULL ;
struct node * root = newNode ( pre [ * preIndex ] ) ; ++ * preIndex ;
if ( l == h ) return root ;
int i ; for ( i = l ; i <= h ; ++ i ) if ( pre [ * preIndex ] == post [ i ] ) break ;
if ( i <= h ) { root -> left = constructTreeUtil ( pre , post , preIndex , l , i , size ) ; root -> right = constructTreeUtil ( pre , post , preIndex , i + 1 , h , size ) ; } return root ; }
struct node * constructTree ( int pre [ ] , int post [ ] , int size ) { int preIndex = 0 ; return constructTreeUtil ( pre , post , & preIndex , 0 , size - 1 , size ) ; }
void printInorder ( struct node * node ) { if ( node == NULL ) return ; printInorder ( node -> left ) ; printf ( " % d ▁ " , node -> data ) ; printInorder ( node -> right ) ; }
int main ( ) { int pre [ ] = { 1 , 2 , 4 , 8 , 9 , 5 , 3 , 6 , 7 } ; int post [ ] = { 8 , 9 , 4 , 5 , 2 , 6 , 7 , 3 , 1 } ; int size = sizeof ( pre ) / sizeof ( pre [ 0 ] ) ; struct node * root = constructTree ( pre , post , size ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ constructed ▁ tree : ▁ STRNEWLINE " ) ; printInorder ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int key ; struct node * left ; struct node * right ; } ;
struct node * newNode ( int key ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> key = key ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int Ceil ( struct node * root , int input ) {
if ( root == NULL ) return -1 ;
if ( root -> key == input ) return root -> key ;
if ( root -> key < input ) return Ceil ( root -> right , input ) ;
int ceil = Ceil ( root -> left , input ) ; return ( ceil >= input ) ? ceil : root -> key ; }
int main ( ) { struct node * root = newNode ( 8 ) ; root -> left = newNode ( 4 ) ; root -> right = newNode ( 12 ) ; root -> left -> left = newNode ( 2 ) ; root -> left -> right = newNode ( 6 ) ; root -> right -> left = newNode ( 10 ) ; root -> right -> right = newNode ( 14 ) ; for ( int i = 0 ; i < 16 ; i ++ ) printf ( " % d ▁ % d STRNEWLINE " , i , Ceil ( root , i ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int key ; int count ; struct node * left , * right ; } ;
struct node * newNode ( int item ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> key = item ; temp -> left = temp -> right = NULL ; temp -> count = 1 ; return temp ; }
void inorder ( struct node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; printf ( " % d ( % d ) ▁ " , root -> key , root -> count ) ; inorder ( root -> right ) ; } }
struct node * insert ( struct node * node , int key ) {
if ( node == NULL ) return newNode ( key ) ;
if ( key == node -> key ) { ( node -> count ) ++ ; return node ; }
if ( key < node -> key ) node -> left = insert ( node -> left , key ) ; else node -> right = insert ( node -> right , key ) ;
return node ; }
struct node * minValueNode ( struct node * node ) { struct node * current = node ;
while ( current -> left != NULL ) current = current -> left ; return current ; }
struct node * deleteNode ( struct node * root , int key ) {
if ( root == NULL ) return root ;
if ( key < root -> key ) root -> left = deleteNode ( root -> left , key ) ;
else if ( key > root -> key ) root -> right = deleteNode ( root -> right , key ) ;
else {
if ( root -> count > 1 ) { ( root -> count ) -- ; return root ; }
if ( root -> left == NULL ) { struct node * temp = root -> right ; free ( root ) ; return temp ; } else if ( root -> right == NULL ) { struct node * temp = root -> left ; free ( root ) ; return temp ; }
struct node * temp = minValueNode ( root -> right ) ;
root -> key = temp -> key ;
root -> right = deleteNode ( root -> right , temp -> key ) ; } return root ; }
int main ( ) {
struct node * root = NULL ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 20 ) ; root = insert ( root , 9 ) ; root = insert ( root , 11 ) ; root = insert ( root , 10 ) ; root = insert ( root , 12 ) ; root = insert ( root , 12 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ given ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; printf ( " Delete 20 " root = deleteNode ( root , 20 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; printf ( " Delete 12 " root = deleteNode ( root , 12 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; printf ( " Delete 9 " root = deleteNode ( root , 9 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int key ; struct node * left , * right ; } ;
struct node * newNode ( int item ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> key = item ; temp -> left = temp -> right = NULL ; return temp ; }
void inorder ( struct node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; printf ( " % d ▁ " , root -> key ) ; inorder ( root -> right ) ; } }
struct node * insert ( struct node * node , int key ) {
if ( node == NULL ) return newNode ( key ) ;
if ( key < node -> key ) node -> left = insert ( node -> left , key ) ; else node -> right = insert ( node -> right , key ) ;
return node ; }
struct node * minValueNode ( struct node * node ) { struct node * current = node ;
while ( current -> left != NULL ) current = current -> left ; return current ; }
struct node * deleteNode ( struct node * root , int key ) {
if ( root == NULL ) return root ;
if ( key < root -> key ) root -> left = deleteNode ( root -> left , key ) ;
else if ( key > root -> key ) root -> right = deleteNode ( root -> right , key ) ;
else {
if ( root -> left == NULL ) { struct node * temp = root -> right ; free ( root ) ; return temp ; } else if ( root -> right == NULL ) { struct node * temp = root -> left ; free ( root ) ; return temp ; }
struct node * temp = minValueNode ( root -> right ) ;
root -> key = temp -> key ;
root -> right = deleteNode ( root -> right , temp -> key ) ; } return root ; }
struct node * changeKey ( struct node * root , int oldVal , int newVal ) {
root = deleteNode ( root , oldVal ) ;
root = insert ( root , newVal ) ;
return root ; }
int main ( ) {
struct node * root = NULL ; root = insert ( root , 50 ) ; root = insert ( root , 30 ) ; root = insert ( root , 20 ) ; root = insert ( root , 40 ) ; root = insert ( root , 70 ) ; root = insert ( root , 60 ) ; root = insert ( root , 80 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ given ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; root = changeKey ( root , 40 , 10 ) ;
printf ( " Inorder traversal of the modified tree " inorder ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
int max ( int inorder [ ] , int strt , int end ) ; struct node * newNode ( int data ) ;
struct node * buildTree ( int inorder [ ] , int start , int end ) { if ( start > end ) return NULL ;
int i = max ( inorder , start , end ) ;
struct node * root = newNode ( inorder [ i ] ) ;
if ( start == end ) return root ;
root -> left = buildTree ( inorder , start , i - 1 ) ; root -> right = buildTree ( inorder , i + 1 , end ) ; return root ; }
int max ( int arr [ ] , int strt , int end ) { int i , max = arr [ strt ] , maxind = strt ; for ( i = strt + 1 ; i <= end ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; maxind = i ; } } return maxind ; }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return node ; }
void printInorder ( struct node * node ) { if ( node == NULL ) return ;
printInorder ( node -> left ) ;
printf ( " % d ▁ " , node -> data ) ;
printInorder ( node -> right ) ; }
int main ( ) {
int inorder [ ] = { 5 , 10 , 40 , 30 , 28 } ; int len = sizeof ( inorder ) / sizeof ( inorder [ 0 ] ) ; struct node * root = buildTree ( inorder , 0 , len - 1 ) ;
printf ( " Inorder traversal of the constructed tree is " printInorder ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
#define SIZE  50
struct node { int data ; struct node * right , * left ; } ;
struct Queue { int front , rear ; int size ; struct node * * array ; } ;
struct node * newNode ( int data ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
struct Queue * createQueue ( int size ) { struct Queue * queue = ( struct Queue * ) malloc ( sizeof ( struct Queue ) ) ; queue -> front = queue -> rear = -1 ; queue -> size = size ; queue -> array = ( struct node * * ) malloc ( queue -> size * sizeof ( struct node * ) ) ; int i ; for ( i = 0 ; i < size ; ++ i ) queue -> array [ i ] = NULL ; return queue ; }
int isEmpty ( struct Queue * queue ) { return queue -> front == -1 ; } int isFull ( struct Queue * queue ) { return queue -> rear == queue -> size - 1 ; } int hasOnlyOneItem ( struct Queue * queue ) { return queue -> front == queue -> rear ; } void Enqueue ( struct node * root , struct Queue * queue ) { if ( isFull ( queue ) ) return ; queue -> array [ ++ queue -> rear ] = root ; if ( isEmpty ( queue ) ) ++ queue -> front ; } struct node * Dequeue ( struct Queue * queue ) { if ( isEmpty ( queue ) ) return NULL ; struct node * temp = queue -> array [ queue -> front ] ; if ( hasOnlyOneItem ( queue ) ) queue -> front = queue -> rear = -1 ; else ++ queue -> front ; return temp ; } struct node * getFront ( struct Queue * queue ) { return queue -> array [ queue -> front ] ; }
int hasBothChild ( struct node * temp ) { return temp && temp -> left && temp -> right ; }
void insert ( struct node * * root , int data , struct Queue * queue ) {
struct node * temp = newNode ( data ) ;
if ( ! * root ) * root = temp ; else {
struct node * front = getFront ( queue ) ;
if ( ! front -> left ) front -> left = temp ;
else if ( ! front -> right ) front -> right = temp ;
if ( hasBothChild ( front ) ) Dequeue ( queue ) ; }
Enqueue ( temp , queue ) ; }
void levelOrder ( struct node * root ) { struct Queue * queue = createQueue ( SIZE ) ; Enqueue ( root , queue ) ; while ( ! isEmpty ( queue ) ) { struct node * temp = Dequeue ( queue ) ; printf ( " % d ▁ " , temp -> data ) ; if ( temp -> left ) Enqueue ( temp -> left , queue ) ; if ( temp -> right ) Enqueue ( temp -> right , queue ) ; } }
int main ( ) { struct node * root = NULL ; struct Queue * queue = createQueue ( SIZE ) ; int i ; for ( i = 1 ; i <= 12 ; ++ i ) insert ( & root , i , queue ) ; levelOrder ( root ) ; return 0 ; }
#include <stdio.h>
struct node { int data ; node * left ; node * right ; } ;
node * bintree2listUtil ( node * root ) {
if ( root == NULL ) return root ;
if ( root -> left != NULL ) {
node * left = bintree2listUtil ( root -> left ) ;
for ( ; left -> right != NULL ; left = left -> right ) ;
left -> right = root ;
root -> left = left ; }
if ( root -> right != NULL ) {
node * right = bintree2listUtil ( root -> right ) ;
for ( ; right -> left != NULL ; right = right -> left ) ;
right -> left = root ;
root -> right = right ; } return root ; }
node * bintree2list ( node * root ) {
if ( root == NULL ) return root ;
root = bintree2listUtil ( root ) ;
while ( root -> left != NULL ) root = root -> left ; return ( root ) ; }
node * newNode ( int data ) { node * new_node = new node ; new_node -> data = data ; new_node -> left = new_node -> right = NULL ; return ( new_node ) ; }
void printList ( node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> right ; } }
int main ( ) {
node * root = newNode ( 10 ) ; root -> left = newNode ( 12 ) ; root -> right = newNode ( 15 ) ; root -> left -> left = newNode ( 25 ) ; root -> left -> right = newNode ( 30 ) ; root -> right -> left = newNode ( 36 ) ;
node * head = bintree2list ( root ) ;
printList ( head ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE #include <stdbool.h> NEW_LINE #define ROW  4 NEW_LINE #define COL  5
typedef struct Node { bool isEndOfCol ;
struct Node * child [ 2 ] ; } Node ;
Node * newNode ( ) { Node * temp = ( Node * ) malloc ( sizeof ( Node ) ) ; temp -> isEndOfCol = 0 ; temp -> child [ 0 ] = temp -> child [ 1 ] = NULL ; return temp ; }
bool insert ( Node * * root , int ( * M ) [ COL ] , int row , int col ) {
if ( * root == NULL ) * root = newNode ( ) ;
if ( col < COL ) return insert ( & ( ( * root ) -> child [ M [ row ] [ col ] ] ) , M , row , col + 1 ) ;
else {
if ( ! ( ( * root ) -> isEndOfCol ) ) return ( * root ) -> isEndOfCol = 1 ;
return 0 ; } }
void printRow ( int ( * M ) [ COL ] , int row ) { int i ; for ( i = 0 ; i < COL ; ++ i ) printf ( " % d ▁ " , M [ row ] [ i ] ) ; printf ( " STRNEWLINE " ) ; }
void findUniqueRows ( int ( * M ) [ COL ] ) {
Node * root = NULL ; int i ;
for ( i = 0 ; i < ROW ; ++ i )
if ( insert ( & root , M , i , 0 ) )
printRow ( M , i ) ; }
int main ( ) { int M [ ROW ] [ COL ] = { { 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 1 , 0 } , { 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 0 , 0 } } ; findUniqueRows ( M ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left , * right ; } ;
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
void inorder ( struct node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; printf ( " TABSYMBOL % d " , root -> data ) ; inorder ( root -> right ) ; } }
void fixPrevPtr ( struct node * root ) { static struct node * pre = NULL ; if ( root != NULL ) { fixPrevPtr ( root -> left ) ; root -> left = pre ; pre = root ; fixPrevPtr ( root -> right ) ; } }
struct node * fixNextPtr ( struct node * root ) { struct node * prev = NULL ;
while ( root && root -> right != NULL ) root = root -> right ;
while ( root && root -> left != NULL ) { prev = root ; root = root -> left ; root -> right = prev ; }
return ( root ) ; }
struct node * BTToDLL ( struct node * root ) {
fixPrevPtr ( root ) ;
return fixNextPtr ( root ) ; }
void printList ( struct node * root ) { while ( root != NULL ) { printf ( " TABSYMBOL % d " , root -> data ) ; root = root -> right ; } }
int main ( void ) {
struct node * root = newNode ( 10 ) ; root -> left = newNode ( 12 ) ; root -> right = newNode ( 15 ) ; root -> left -> left = newNode ( 25 ) ; root -> left -> right = newNode ( 30 ) ; root -> right -> left = newNode ( 36 ) ; printf ( " Inorder Tree Traversal " inorder ( root ) ; struct node * head = BTToDLL ( root ) ; printf ( " DLL Traversal " printList ( head ) ; return 0 ; }
#include <stdio.h>
#define M  4 NEW_LINE #define N  5
int findCommon ( int mat [ M ] [ N ] ) {
int column [ M ] ;
int min_row ;
int i ; for ( i = 0 ; i < M ; i ++ ) column [ i ] = N - 1 ;
min_row = 0 ;
while ( column [ min_row ] >= 0 ) {
for ( i = 0 ; i < M ; i ++ ) { if ( mat [ i ] [ column [ i ] ] < mat [ min_row ] [ column [ min_row ] ] ) min_row = i ; }
int eq_count = 0 ;
for ( i = 0 ; i < M ; i ++ ) {
if ( mat [ i ] [ column [ i ] ] > mat [ min_row ] [ column [ min_row ] ] ) { if ( column [ i ] == 0 ) return -1 ;
column [ i ] -= 1 ; } else eq_count ++ ; }
if ( eq_count == M ) return mat [ min_row ] [ column [ min_row ] ] ; } return -1 ; }
int main ( ) { int mat [ M ] [ N ] = { { 1 , 2 , 3 , 4 , 5 } , { 2 , 4 , 5 , 8 , 10 } , { 3 , 5 , 7 , 9 , 11 } , { 1 , 3 , 5 , 7 , 9 } , } ; int result = findCommon ( mat ) ; if ( result == -1 ) printf ( " No ▁ common ▁ element " ) ; else printf ( " Common ▁ element ▁ is ▁ % d " , result ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
void increment ( struct node * node , int diff ) ;
void convertTree ( struct node * node ) { int left_data = 0 , right_data = 0 , diff ;
if ( node == NULL || ( node -> left == NULL && node -> right == NULL ) ) return ; else {
convertTree ( node -> left ) ; convertTree ( node -> right ) ;
if ( node -> left != NULL ) left_data = node -> left -> data ;
if ( node -> right != NULL ) right_data = node -> right -> data ;
diff = left_data + right_data - node -> data ;
if ( diff > 0 ) node -> data = node -> data + diff ;
if ( diff < 0 )
increment ( node , - diff ) ; } }
void increment ( struct node * node , int diff ) {
if ( node -> left != NULL ) { node -> left -> data = node -> left -> data + diff ;
increment ( node -> left , diff ) ; }
else if ( node -> right != NULL ) { node -> right -> data = node -> right -> data + diff ;
increment ( node -> right , diff ) ; } }
void printInorder ( struct node * node ) { if ( node == NULL ) return ;
printInorder ( node -> left ) ;
printf ( " % d ▁ " , node -> data ) ;
printInorder ( node -> right ) ; }
int main ( ) { struct node * root = newNode ( 50 ) ; root -> left = newNode ( 7 ) ; root -> right = newNode ( 2 ) ; root -> left -> left = newNode ( 3 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 1 ) ; root -> right -> right = newNode ( 30 ) ; printf ( " Inorder traversal before conversion " printInorder ( root ) ; convertTree ( root ) ; printf ( " Inorder traversal after conversion " printInorder ( root ) ; getchar ( ) ; return 0 ; }
#include <stdio.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
int toSumTree ( struct node * node ) {
if ( node == NULL ) return 0 ;
int old_val = node -> data ;
node -> data = toSumTree ( node -> left ) + toSumTree ( node -> right ) ;
return node -> data + old_val ; }
void printInorder ( struct node * node ) { if ( node == NULL ) return ; printInorder ( node -> left ) ; printf ( " % d ▁ " , node -> data ) ; printInorder ( node -> right ) ; }
struct node * newNode ( int data ) { struct node * temp = new struct node ; temp -> data = data ; temp -> left = NULL ; temp -> right = NULL ; return temp ; }
int main ( ) { struct node * root = NULL ; int x ;
root = newNode ( 10 ) ; root -> left = newNode ( -2 ) ; root -> right = newNode ( 6 ) ; root -> left -> left = newNode ( 8 ) ; root -> left -> right = newNode ( -4 ) ; root -> right -> left = newNode ( 7 ) ; root -> right -> right = newNode ( 5 ) ; toSumTree ( root ) ;
printf ( " Inorder ▁ Traversal ▁ of ▁ the ▁ resultant ▁ tree ▁ is : ▁ STRNEWLINE " ) ; printInorder ( root ) ; getchar ( ) ; return 0 ; }
