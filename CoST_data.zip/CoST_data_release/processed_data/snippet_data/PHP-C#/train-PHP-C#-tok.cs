using System ; class GFG { static void towerOfHanoi ( int n , char from_rod , char to_rod , char aux_rod ) { if ( n == 1 ) { Console . WriteLine ( " Move ▁ disk ▁ 1 ▁ from ▁ rod ▁ " + from_rod + " ▁ to ▁ rod ▁ " + to_rod ) ; return ; } towerOfHanoi ( n - 1 , from_rod , aux_rod , to_rod ) ; Console . WriteLine ( " Move ▁ disk ▁ " + n + " ▁ from ▁ rod ▁ " + from_rod + " ▁ to ▁ rod ▁ " + to_rod ) ; towerOfHanoi ( n - 1 , aux_rod , to_rod , from_rod ) ; }
int n = 4 ;
towerOfHanoi ( n , ' A ' , ' C ' , ' B ' ) ; } }
using System ; class GFG { static int [ ] arr = { 10 , 20 , 30 , 50 , 10 , 70 , 30 } ; static void printMaxOfMin ( int n ) {
for ( int k = 1 ; k <= n ; k ++ ) {
int maxOfMin = int . MinValue ;
for ( int i = 0 ; i <= n - k ; i ++ ) {
int min = arr [ i ] ; for ( int j = 1 ; j < k ; j ++ ) { if ( arr [ i + j ] < min ) min = arr [ i + j ] ; }
if ( min > maxOfMin ) maxOfMin = min ; }
Console . Write ( maxOfMin + " ▁ " ) ; } }
public static void Main ( ) { printMaxOfMin ( arr . Length ) ; } }
static void PrintMinNumberForPattern ( String arr ) {
int curr_max = 0 ;
int last_entry = 0 ; int j ;
for ( int i = 0 ; i < arr . Length ; i ++ ) {
int noOfNextD = 0 ; switch ( arr [ i ] ) { case ' I ' :
j = i + 1 ; while ( j < arr . Length && arr [ j ] == ' D ' ) { noOfNextD ++ ; j ++ ; } if ( i == 0 ) { curr_max = noOfNextD + 2 ;
Console . Write ( " ▁ " + ++ last_entry ) ; Console . Write ( " ▁ " + curr_max ) ;
last_entry = curr_max ; } else {
curr_max = curr_max + noOfNextD + 1 ;
last_entry = curr_max ; Console . Write ( " ▁ " + last_entry ) ; }
for ( int k = 0 ; k < noOfNextD ; k ++ ) { Console . Write ( " ▁ " + -- last_entry ) ; i ++ ; } break ;
' D ' : if ( i == 0 ) {
j = i + 1 ; while ( j < arr . Length && arr [ j ] == ' D ' ) { noOfNextD ++ ; j ++ ; }
curr_max = noOfNextD + 2 ;
Console . Write ( " ▁ " + curr_max + " ▁ " + ( curr_max - 1 ) ) ;
last_entry = curr_max - 1 ; } else {
Console . Write ( " ▁ " + ( last_entry - 1 ) ) ; last_entry -- ; } break ; } } Console . WriteLine ( ) ; }
public static void Main ( String [ ] args ) { PrintMinNumberForPattern ( " IDID " ) ; PrintMinNumberForPattern ( " I " ) ; PrintMinNumberForPattern ( " DD " ) ; PrintMinNumberForPattern ( " II " ) ; PrintMinNumberForPattern ( " DIDI " ) ; PrintMinNumberForPattern ( " IIDDD " ) ; PrintMinNumberForPattern ( " DDIDDIID " ) ; } }
public static Stack < int > st = new Stack < int > ( ) ;
public static void push_digits ( int number ) { while ( number != 0 ) { st . Push ( number % 10 ) ; number = number / 10 ; } }
public static int reverse_number ( int number ) {
push_digits ( number ) ; int reverse = 0 ; int i = 1 ;
while ( st . Count > 0 ) { reverse = reverse + ( st . Peek ( ) * i ) ; st . Pop ( ) ; i = i * 10 ; }
return reverse ; }
public static void Main ( string [ ] args ) { int number = 39997 ;
Console . WriteLine ( reverse_number ( number ) ) ; } }
void heapify ( int [ ] arr , int n , int i ) {
int largest = i ;
int l = 2 * i + 1 ;
int r = 2 * i + 2 ;
if ( l < n && arr [ l ] > arr [ largest ] ) largest = l ;
if ( r < n && arr [ r ] > arr [ largest ] ) largest = r ;
if ( largest != i ) { int swap = arr [ i ] ; arr [ i ] = arr [ largest ] ; arr [ largest ] = swap ;
heapify ( arr , n , largest ) ; } }
public void sort ( int [ ] arr ) { int n = arr . Length ;
for ( int i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( int i = n - 1 ; i > 0 ; i -- ) {
int temp = arr [ 0 ] ; arr [ 0 ] = arr [ i ] ; arr [ i ] = temp ;
heapify ( arr , i , 0 ) ; } }
static void printArray ( int [ ] arr ) { int n = arr . Length ; for ( int i = 0 ; i < n ; ++ i ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . Read ( ) ; }
public static void Main ( ) { int [ ] arr = { 12 , 11 , 13 , 5 , 6 , 7 } ; int n = arr . Length ; HeapSort ob = new HeapSort ( ) ; ob . sort ( arr ) ; Console . WriteLine ( " Sorted ▁ array ▁ is " ) ; printArray ( arr ) ; } }
static bool isHeap ( int [ ] arr , int i , int n ) {
if ( i >= ( n - 2 ) / 2 ) { return true ; }
if ( arr [ i ] >= arr [ 2 * i + 1 ] && arr [ i ] >= arr [ 2 * i + 2 ] && isHeap ( arr , 2 * i + 1 , n ) && isHeap ( arr , 2 * i + 2 , n ) ) { return true ; } return false ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 } ; int n = arr . Length - 1 ; if ( isHeap ( arr , 0 , n ) ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " No " ) ; } } }
static bool isHeap ( int [ ] arr , int n ) {
for ( int i = 0 ; i <= ( n - 2 ) / 2 ; i ++ ) {
if ( arr [ 2 * i + 1 ] > arr [ i ] ) { return false ; }
if ( 2 * i + 2 < n && arr [ 2 * i + 2 ] > arr [ i ] ) { return false ; } } return true ; }
public static void Main ( ) { int [ ] arr = { 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 } ; int n = arr . Length ; if ( isHeap ( arr , n ) ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " No " ) ; } } }
using System ; class GFG { static void generate_derangement ( int N ) {
int [ ] S = new int [ N + 1 ] ; for ( int i = 1 ; i <= N ; i ++ ) S [ i ] = i ;
int [ ] D = new int [ N + 1 ] ; for ( int i = 1 ; i <= N ; i += 2 ) { if ( i == N ) {
D [ N ] = S [ N - 1 ] ; D [ N - 1 ] = S [ N ] ; } else { D [ i ] = i + 1 ; D [ i + 1 ] = i ; } }
for ( int i = 1 ; i <= N ; i ++ ) Console . Write ( D [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( ) { generate_derangement ( 10 ) ; } }
static int sumBetweenTwoKth ( int [ ] arr , int n , int k1 , int k2 ) {
Array . Sort ( arr ) ;
int result = 0 ; for ( int i = k1 ; i < k2 - 1 ; i ++ ) result += arr [ i ] ; return result ; }
public static void Main ( ) { int [ ] arr = { 20 , 8 , 22 , 4 , 12 , 10 , 14 } ; int k1 = 3 , k2 = 6 ; int n = arr . Length ; Console . Write ( sumBetweenTwoKth ( arr , n , k1 , k2 ) ) ; } }
static int minSum ( int [ ] a , int n ) {
Array . Sort ( a ) ; int num1 = 0 ; int num2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) num1 = num1 * 10 + a [ i ] ; else num2 = num2 * 10 + a [ i ] ; } return num2 + num1 ; }
static public void Main ( ) { int [ ] arr = { 5 , 3 , 0 , 7 , 4 } ; int n = arr . Length ; Console . WriteLine ( " The ▁ required ▁ sum ▁ is ▁ " + minSum ( arr , n ) ) ; } }
using System ; class GFG { static int N = 3 ; static int M = 4 ;
static void printDistance ( int [ , ] mat ) { int [ , ] ans = new int [ N , M ] ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) ans [ i , j ] = int . MaxValue ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) {
for ( int k = 0 ; k < N ; k ++ ) for ( int l = 0 ; l < M ; l ++ ) {
if ( mat [ k , l ] == 1 ) ans [ i , j ] = Math . Min ( ans [ i , j ] , Math . Abs ( i - k ) + Math . Abs ( j - l ) ) ; } }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) Console . Write ( ans [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] mat = { { 0 , 0 , 0 , 1 } , { 0 , 0 , 1 , 1 } , { 0 , 1 , 1 , 0 } } ; printDistance ( mat ) ; } }
public static bool isMinHeap ( int [ ] level ) { int n = level . Length - 1 ;
for ( int i = ( n / 2 - 1 ) ; i >= 0 ; i -- ) {
if ( level [ i ] > level [ 2 * i + 1 ] ) { return false ; } if ( 2 * i + 2 < n ) {
if ( level [ i ] > level [ 2 * i + 2 ] ) { return false ; } } } return true ; }
public static void Main ( string [ ] args ) { int [ ] level = new int [ ] { 10 , 15 , 14 , 25 , 30 } ; if ( isMinHeap ( level ) ) { Console . WriteLine ( " True " ) ; } else { Console . WriteLine ( " False " ) ; } } }
using System ; class GFG { static int mostFrequent ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
int max_count = 1 , res = arr [ 0 ] ; int curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 2 , 1 , 3 , 2 , 1 } ; int n = arr . Length ; Console . WriteLine ( mostFrequent ( arr , n ) ) ; } }
public virtual bool aredisjoint ( int [ ] set1 , int [ ] set2 ) {
for ( int i = 0 ; i < set1 . Length ; i ++ ) { for ( int j = 0 ; j < set2 . Length ; j ++ ) { if ( set1 [ i ] == set2 [ j ] ) { return false ; } } }
return true ; }
public static void Main ( string [ ] args ) { GFG dis = new GFG ( ) ; int [ ] set1 = new int [ ] { 12 , 34 , 11 , 9 , 3 } ; int [ ] set2 = new int [ ] { 7 , 2 , 1 , 5 } ; bool result = dis . aredisjoint ( set1 , set2 ) ; if ( result ) { Console . WriteLine ( " Yes " ) ; } else { Console . WriteLine ( " No " ) ; } } }
static void findMissing ( int [ ] a , int [ ] b , int n , int m ) { for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < m ; j ++ ) if ( a [ i ] == b [ j ] ) break ; if ( j == m ) Console . Write ( a [ i ] + " ▁ " ) ; } }
public static void Main ( ) { int [ ] a = { 1 , 2 , 6 , 3 , 4 , 5 } ; int [ ] b = { 2 , 4 , 3 , 1 , 0 } ; int n = a . Length ; int m = b . Length ; findMissing ( a , b , n , m ) ; } }
public static bool areEqual ( int [ ] arr1 , int [ ] arr2 ) { int n = arr1 . Length ; int m = arr2 . Length ;
if ( n != m ) return false ;
Array . Sort ( arr1 ) ; Array . Sort ( arr2 ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr1 [ i ] != arr2 [ i ] ) return false ;
return true ; }
public static void Main ( ) { int [ ] arr1 = { 3 , 5 , 2 , 5 , 2 } ; int [ ] arr2 = { 2 , 3 , 5 , 5 , 2 } ; if ( areEqual ( arr1 , arr2 ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
static bool isProduct ( int [ ] arr , int n , int x ) {
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] * arr [ j ] == x ) return true ; return false ; }
static void Main ( ) { int [ ] arr = { 10 , 20 , 9 , 40 } ; int x = 400 ; int n = arr . Length ; if ( isProduct ( arr , n , x ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; x = 190 ; if ( isProduct ( arr , n , x ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
static int findGreatest ( int [ ] arr , int n ) { int result = - 1 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ j ] * arr [ k ] == arr [ i ] ) result = Math . Max ( result , arr [ i ] ) ; return result ; }
static public void Main ( ) { int [ ] arr = { 30 , 10 , 9 , 3 , 35 } ; int n = arr . Length ; Console . WriteLine ( findGreatest ( arr , n ) ) ; } }
public static int subset ( int [ ] ar , int n ) {
int res = 0 ;
Array . Sort ( ar ) ;
for ( int i = 0 ; i < n ; i ++ ) { int count = 1 ;
for ( ; i < n - 1 ; i ++ ) { if ( ar [ i ] == ar [ i + 1 ] ) count ++ ; else break ; }
res = Math . Max ( res , count ) ; } return res ; }
public static void Main ( ) { int [ ] arr = { 5 , 6 , 9 , 3 , 4 , 3 , 4 } ; int n = 7 ; Console . WriteLine ( subset ( arr , n ) ) ; } }
public static void getPairsCount ( int [ ] arr , int sum ) {
int count = 0 ;
for ( int i = 0 ; i < arr . Length ; i ++ ) for ( int j = i + 1 ; j < arr . Length ; j ++ ) if ( ( arr [ i ] + arr [ j ] ) == sum ) count ++ ; Console . WriteLine ( " Count ▁ of ▁ pairs ▁ is ▁ " + count ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 5 , 7 , - 1 , 5 } ; int sum = 6 ; getPairsCount ( arr , sum ) ; } }
static int countPairs ( int [ ] arr1 , int [ ] arr2 , int m , int n , int x ) { int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ )
if ( ( arr1 [ i ] + arr2 [ j ] ) == x ) count ++ ;
return count ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 3 , 5 , 7 } ; int [ ] arr2 = { 2 , 3 , 5 , 8 } ; int m = arr1 . Length ; int n = arr2 . Length ; int x = 10 ; Console . WriteLine ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static bool isPresent ( int [ ] arr , int low , int high , int value ) { while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
static int countPairs ( int [ ] arr1 , int [ ] arr2 , int m , int n , int x ) { int count = 0 ; for ( int i = 0 ; i < m ; i ++ ) {
int value = x - arr1 [ i ] ;
if ( isPresent ( arr2 , 0 , n - 1 , value ) ) count ++ ; }
return count ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 3 , 5 , 7 } ; int [ ] arr2 = { 2 , 3 , 5 , 8 } ; int m = arr1 . Length ; int n = arr2 . Length ; int x = 10 ; Console . WriteLine ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static int countPairs ( int [ ] arr1 , int [ ] arr2 , int m , int n , int x ) { int count = 0 ; int l = 0 , r = n - 1 ;
while ( l < m && r >= 0 ) {
if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) { l ++ ; r -- ; count ++ ; }
else if ( ( arr1 [ l ] + arr2 [ r ] ) < x ) ++ ;
else r -- ; }
return count ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 3 , 5 , 7 } ; int [ ] arr2 = { 2 , 3 , 5 , 8 } ; int m = arr1 . Length ; int n = arr2 . Length ; int x = 10 ; Console . WriteLine ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static bool isPresent ( int [ ] arr , int low , int high , int value ) { while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
static int countQuadruples ( int [ ] arr1 , int [ ] arr2 , int [ ] arr3 , int [ ] arr4 , int n , int x ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) for ( int k = 0 ; k < n ; k ++ ) {
int T = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
if ( isPresent ( arr4 , 0 , n - 1 , x - T ) )
count ++ ; }
return count ; }
int [ ] arr1 = { 1 , 4 , 5 , 6 } ; int [ ] arr2 = { 2 , 3 , 7 , 8 } ; int [ ] arr3 = { 1 , 4 , 6 , 10 } ; int [ ] arr4 = { 2 , 4 , 7 , 8 } ; int n = 4 ; int x = 30 ; Console . WriteLine ( " Count ▁ = ▁ " + countQuadruples ( arr1 , arr2 , arr3 , arr4 , n , x ) ) ; } }
public static int countPairs ( int [ ] arr , int n ) { int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int product = arr [ i ] * arr [ j ] ;
for ( int k = 0 ; k < n ; k ++ ) {
if ( arr [ k ] == product ) { result ++ ; break ; } } } }
return result ; }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 6 , 2 , 4 , 12 , 5 , 3 } ; int n = arr . Length ; Console . WriteLine ( countPairs ( arr , n ) ) ; } }
static void findPairs ( int [ ] arr1 , int [ ] arr2 , int n , int m , int x ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( arr1 [ i ] + arr2 [ j ] == x ) Console . WriteLine ( arr1 [ i ] + " ▁ " + arr2 [ j ] ) ; }
static void Main ( ) { int [ ] arr1 = { 1 , 2 , 3 , 7 , 5 , 4 } ; int [ ] arr2 = { 0 , 7 , 4 , 3 , 2 , 1 } ; int x = 8 ; findPairs ( arr1 , arr2 , arr1 . Length , arr2 . Length , x ) ; } }
static void findPair ( int [ ] arr , int n ) { bool found = false ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { for ( int k = 0 ; k < n ; k ++ ) { if ( arr [ i ] + arr [ j ] == arr [ k ] ) { Console . WriteLine ( arr [ i ] + " ▁ " + arr [ j ] ) ; found = true ; } } } } if ( found == false ) Console . WriteLine ( " Not ▁ exist " ) ; }
static public void Main ( String [ ] args ) { int [ ] arr = { 10 , 4 , 8 , 13 , 5 } ; int n = arr . Length ; findPair ( arr , n ) ; } }
static bool printPairs ( int [ ] arr , int n , int k ) { bool isPairFound = true ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i != j && arr [ i ] % arr [ j ] == k ) { Console . Write ( " ( " + arr [ i ] + " , ▁ " + arr [ j ] + " ) " + " ▁ " ) ; isPairFound = true ; } } } return isPairFound ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 5 , 4 , 7 } ; int k = 3 ; if ( printPairs ( arr , arr . Length , k ) == false ) Console . WriteLine ( " No ▁ such ▁ pair ▁ exists " ) ; } }
using System ; class GFG { static int ASCII_SIZE = 256 ; static char getMaxOccuringChar ( String str ) {
int [ ] count = new int [ ASCII_SIZE ] ;
int len = str . Length ; for ( int i = 0 ; i < len ; i ++ ) count [ str [ i ] ] ++ ;
int max = - 1 ;
for ( int i = 0 ; i < len ; i ++ ) { if ( max < count [ str [ i ] ] ) { max = count [ str [ i ] ] ; result = str [ i ] ; } } return result ; }
public static void Main ( ) { String str = " sample ▁ string " ; Console . Write ( " Max ▁ occurring ▁ character ▁ is ▁ " + getMaxOccuringChar ( str ) ) ; } }
using System ; class GFG { static int firstNonRepeating ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ i ] == arr [ j ] ) break ; if ( j == n ) return arr [ i ] ; } return - 1 ; }
public static void Main ( ) { int [ ] arr = { 9 , 4 , 9 , 6 , 7 , 4 } ; int n = arr . Length ; Console . Write ( firstNonRepeating ( arr , n ) ) ; } }
static int printKDistinct ( int [ ] arr , int n , int k ) { int dist_count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ j ] == arr [ i ] ) break ;
if ( j == n ) dist_count ++ ; if ( dist_count == k ) return arr [ i ] ; } return - 1 ; }
public static void Main ( ) { int [ ] ar = { 1 , 2 , 1 , 3 , 4 , 2 } ; int n = ar . Length ; int k = 2 ; Console . Write ( printKDistinct ( ar , n , k ) ) ; } }
static void subarrayDivisibleByK ( int [ ] arr , int n , int k ) {
int [ ] mp = new int [ 1000 ] ;
int s = 0 , e = 0 , maxs = 0 , maxe = 0 ;
mp [ arr [ 0 ] % k ] ++ ; for ( int i = 1 ; i < n ; i ++ ) { int mod = arr [ i ] % k ;
while ( mp [ k - mod ] != 0 || ( mod == 0 && mp [ mod ] != 0 ) ) { mp [ arr [ s ] % k ] -- ; s ++ ; }
mp [ mod ] ++ ; e ++ ;
if ( ( e - s ) > ( maxe - maxs ) ) { maxe = e ; maxs = s ; } } Console . Write ( " The ▁ maximum ▁ size ▁ is ▁ " + ( maxe - maxs + 1 ) + " ▁ and ▁ the ▁ subarray ▁ is ▁ as ▁ follows STRNEWLINE " ) ; for ( int i = maxs ; i <= maxe ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int k = 3 ; int [ ] arr = { 5 , 10 , 15 , 20 , 25 } ; int n = arr . Length ; subarrayDivisibleByK ( arr , n , k ) ; } }
static bool findTriplet ( int [ ] a1 , int [ ] a2 , int [ ] a3 , int n1 , int n2 , int n3 , int sum ) { for ( int i = 0 ; i < n1 ; i ++ ) for ( int j = 0 ; j < n2 ; j ++ ) for ( int k = 0 ; k < n3 ; k ++ ) if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) return true ; return false ; }
static public void Main ( ) { int [ ] a1 = { 1 , 2 , 3 , 4 , 5 } ; int [ ] a2 = { 2 , 3 , 6 , 1 , 2 } ; int [ ] a3 = { 3 , 2 , 4 , 5 , 6 } ; int sum = 9 ; int n1 = a1 . Length ; int n2 = a2 . Length ; int n3 = a3 . Length ; if ( findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
static bool areElementsContiguous ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] > 1 ) return false ; return true ; }
public static void Main ( ) { int [ ] arr = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = arr . Length ; if ( areElementsContiguous ( arr , n ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
static int minInsertion ( String str ) {
int n = str . Length ;
int res = 0 ;
int [ ] count = new int [ 26 ] ;
for ( int i = 0 ; i < n ; i ++ ) count [ str [ i ] - ' a ' ] ++ ;
for ( int i = 0 ; i < 26 ; i ++ ) { if ( count [ i ] % 2 == 1 ) res ++ ; }
return ( res == 0 ) ? 0 : res - 1 ; }
public static void Main ( ) { string str = " geeksforgeeks " ; Console . WriteLine ( minInsertion ( str ) ) ; } }
using System ; class GFG { static int findDiff ( int [ ] arr , int n ) {
Array . Sort ( arr ) ; int count = 0 , max_count = 0 , min_count = n ; for ( int i = 0 ; i < ( n - 1 ) ; i ++ ) {
if ( arr [ i ] == arr [ i + 1 ] ) { count += 1 ; continue ; } else { max_count = Math . Max ( max_count , count ) ; min_count = Math . Min ( min_count , count ) ; count = 0 ; } } return ( max_count - min_count ) ; }
public static void Main ( ) { int [ ] arr = { 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 } ; int n = arr . Length ; Console . WriteLine ( findDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) { int SubsetSum_1 = 0 , SubsetSum_2 = 0 ; for ( int i = 0 ; i <= n - 1 ; i ++ ) { bool isSingleOccurance = true ; for ( int j = i + 1 ; j <= n - 1 ; j ++ ) {
if ( arr [ i ] == arr [ j ] ) { isSingleOccurance = false ; arr [ i ] = arr [ j ] = 0 ; break ; } } if ( isSingleOccurance ) { if ( arr [ i ] > 0 ) SubsetSum_1 += arr [ i ] ; else SubsetSum_2 += arr [ i ] ; } } return Math . Abs ( SubsetSum_1 - SubsetSum_2 ) ; }
static public void Main ( ) { int [ ] arr = { 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 } ; int n = arr . Length ; Console . WriteLine ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) { int result = 0 ;
Array . Sort ( arr ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) result += Math . Abs ( arr [ i ] ) ; else i ++ ; }
if ( arr [ n - 2 ] != arr [ n - 1 ] ) result += Math . Abs ( arr [ n - 1 ] ) ;
return result ; }
static public void Main ( ) { int [ ] arr = { 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 } ; int n = arr . Length ; Console . WriteLine ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n ) ) ; } }
static int calculate ( int [ ] a , int n ) {
Array . Sort ( a ) ; int count = 1 ; int answer = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == a [ i - 1 ] ) {
count += 1 ; } else {
answer = answer + ( count * ( count - 1 ) ) / 2 ; count = 1 ; } } answer = answer + ( count * ( count - 1 ) ) / 2 ; return answer ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 1 , 2 , 4 } ; int n = a . Length ;
Console . WriteLine ( calculate ( a , n ) ) ; } }
static int calculate ( int [ ] a , int n ) {
int maximum = a . Max ( ) ;
int [ ] frequency = new int [ maximum + 1 ] ;
for ( int i = 0 ; i < n ; i ++ ) {
frequency [ a [ i ] ] += 1 ; } int answer = 0 ;
for ( int i = 0 ; i < ( maximum ) + 1 ; i ++ ) {
answer = answer + frequency [ i ] * ( frequency [ i ] - 1 ) ; } return answer / 2 ; }
public static void Main ( String [ ] args ) { int [ ] a = { 1 , 2 , 1 , 2 , 4 } ; int n = a . Length ;
Console . WriteLine ( calculate ( a , n ) ) ; } }
static void printAllAPTriplets ( int [ ] arr , int n ) { List < int > s = new List < int > ( ) ; for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int diff = arr [ j ] - arr [ i ] ; bool exists = s . Exists ( element => element == ( arr [ i ] - diff ) ) ; if ( exists ) Console . WriteLine ( arr [ i ] - diff + " ▁ " + arr [ i ] + " ▁ " + arr [ j ] ) ; } s . Add ( arr [ i ] ) ; } }
static void Main ( ) { int [ ] arr = new int [ ] { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = arr . Length ; printAllAPTriplets ( arr , n ) ; } }
static void findAllTriplets ( int [ ] arr , int n ) { for ( int i = 1 ; i < n - 1 ; i ++ ) {
for ( int j = i - 1 , k = i + 1 ; j >= 0 && k < n ; ) {
if ( arr [ j ] + arr [ k ] == 2 * arr [ i ] ) { Console . WriteLine ( arr [ j ] + " ▁ " + arr [ i ] + " ▁ " + arr [ k ] ) ;
k ++ ; j -- ; }
else if ( arr [ j ] + arr [ k ] < 2 * arr [ i ] ) ++ ; else -- ; } } }
public static void Main ( ) { int [ ] arr = { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = arr . Length ; findAllTriplets ( arr , n ) ; } }
static int countTriplets ( int [ ] arr , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) for ( int j = i + 1 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] * arr [ j ] * arr [ k ] == m ) count ++ ; return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 4 , 6 , 2 , 3 , 8 } ; int m = 24 ; Console . WriteLine ( countTriplets ( arr , arr . Length , m ) ) ; } }
static int countPairs ( int [ ] arr , int n ) { int ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ )
if ( arr [ i ] == arr [ j ] ) ans ++ ; return ans ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 2 } ; int n = arr . Length ; Console . WriteLine ( countPairs ( arr , n ) ) ; } }
static int countNum ( int [ ] arr , int n ) { int count = 0 ;
Array . Sort ( arr ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) count += arr [ i + 1 ] - arr [ i ] - 1 ; return count ; }
static public void Main ( ) { int [ ] arr = { 3 , 5 , 8 , 6 } ; int n = arr . Length ; Console . WriteLine ( countNum ( arr , n ) ) ; } }
static int countSubarrays ( int [ ] arr , int n ) {
int difference = 0 ; int ans = 0 ;
Array . Clear ( hash_positive , 0 , n + 1 ) ; Array . Clear ( hash_negative , 0 , n + 1 ) ;
hash_positive [ 0 ] = 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ( arr [ i ] & 1 ) == 1 ) difference ++ ; else difference -- ;
if ( difference < 0 ) { ans += hash_negative [ - difference ] ; hash_negative [ - difference ] ++ ; }
else { ans += hash_positive [ difference ] ; hash_positive [ difference ] ++ ; } }
return ans ; }
static void Main ( ) { int [ ] arr = new int [ ] { 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 } ; int n = arr . Length ;
Console . Write ( " Total ▁ Number ▁ of ▁ Even - Odd " + " ▁ subarrays ▁ are ▁ " + countSubarrays ( arr , n ) ) ; } }
static int findLargestd ( int [ ] S , int n ) { bool found = false ;
Array . Sort ( S ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) continue ; for ( int k = j + 1 ; k < n ; k ++ ) { if ( i == k ) continue ; for ( int l = k + 1 ; l < n ; l ++ ) { if ( i == l ) continue ;
if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) { found = true ; return S [ i ] ; } } } } } if ( found == false ) return int . MaxValue ; return - 1 ; }
public static void Main ( ) { int [ ] S = new int [ ] { 2 , 3 , 5 , 7 , 12 } ; int n = S . Length ; int ans = findLargestd ( S , n ) ; if ( ans == int . MaxValue ) Console . WriteLine ( " No ▁ Solution " ) ; else Console . Write ( " Largest ▁ d ▁ such ▁ that ▁ a ▁ + ▁ " + " b ▁ + ▁ c ▁ = ▁ d ▁ is ▁ " + ans ) ; } }
static void recaman ( int n ) {
arr [ 0 ] = 0 ; Console . Write ( arr [ 0 ] + " ▁ , " ) ;
for ( int i = 1 ; i < n ; i ++ ) { int curr = arr [ i - 1 ] - i ; int j ; for ( j = 0 ; j < i ; j ++ ) {
if ( ( arr [ j ] == curr ) curr < 0 ) { curr = arr [ i - 1 ] + i ; break ; } } arr [ i ] = curr ; Console . Write ( arr [ i ] + " , ▁ " ) ; } }
public static void Main ( ) { int n = 17 ; recaman ( n ) ; } }
static void recaman ( int n ) { if ( n <= 0 ) return ;
Console . Write ( " { 0 } , ▁ " , 0 ) ; HashSet < int > s = new HashSet < int > ( ) ; s . Add ( 0 ) ;
int prev = 0 ; for ( int i = 1 ; i < n ; i ++ ) { int curr = prev - i ;
if ( curr < 0 || s . Contains ( curr ) ) curr = prev + i ; s . Add ( curr ) ; Console . Write ( " { 0 } , ▁ " , curr ) ; prev = curr ; } }
public static void Main ( String [ ] args ) { int n = 17 ; recaman ( n ) ; } }
static int findArea ( int [ ] arr , int n ) {
Array . Sort ( arr ) ; Array . Reverse ( arr ) ;
int [ ] dimension = { 0 , 0 } ;
for ( int i = 0 , j = 0 ; i < n - 1 && j < 2 ; i ++ )
if ( arr [ i ] == arr [ i + 1 ] ) dimension [ j ++ ] = arr [ i ++ ] ;
return ( dimension [ 0 ] * dimension [ 1 ] ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 } ; int n = arr . Length ; Console . Write ( findArea ( arr , n ) ) ; } }
static int search ( int [ ] arr , int l , int h , int key ) { if ( l > h ) return - 1 ; int mid = ( l + h ) / 2 ; if ( arr [ mid ] == key ) return mid ;
if ( arr [ l ] <= arr [ mid ] ) {
if ( key >= arr [ l ] && key <= arr [ mid ] ) return search ( arr , l , mid - 1 , key ) ;
return search ( arr , mid + 1 , h , key ) ; }
if ( key >= arr [ mid ] && key <= arr [ h ] ) return search ( arr , mid + 1 , h , key ) ; return search ( arr , l , mid - 1 , key ) ; }
public static void Main ( ) { int [ ] arr = { 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 } ; int n = arr . Length ; int key = 6 ; int i = search ( arr , 0 , n - 1 , key ) ; if ( i != - 1 ) Console . WriteLine ( " Index : ▁ " + i ) ; else Console . WriteLine ( " Key ▁ not ▁ found " ) ; } }
static bool pairInSortedRotated ( int [ ] arr , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) return true ;
if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return false ; }
public static void Main ( ) { int [ ] arr = { 11 , 15 , 6 , 8 , 9 , 10 } ; int sum = 16 ; int n = arr . Length ; if ( pairInSortedRotated ( arr , n , sum ) ) Console . WriteLine ( " Array ▁ has ▁ two ▁ elements " + " ▁ with ▁ sum ▁ 16" ) ; else Console . WriteLine ( " Array ▁ doesn ' t ▁ have ▁ two " + " ▁ elements ▁ with ▁ sum ▁ 16 ▁ " ) ; } }
static int pairsInSortedRotated ( int [ ] arr , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
int cnt = 0 ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) { cnt ++ ;
if ( l == ( r - 1 + n ) % n ) { return cnt ; } l = ( l + 1 ) % n ; r = ( r - 1 + n ) % n ; }
else if ( arr [ l ] + arr [ r ] < x ) = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return cnt ; }
static public void Main ( ) { int [ ] arr = { 11 , 15 , 6 , 7 , 9 , 10 } ; int sum = 16 ; int n = arr . Length ; Console . WriteLine ( pairsInSortedRotated ( arr , n , sum ) ) ; } }
static int maxSum ( ) {
int arrSum = 0 ;
int currVal = 0 ; for ( int i = 0 ; i < arr . Length ; i ++ ) { arrSum = arrSum + arr [ i ] ; currVal = currVal + ( i * arr [ i ] ) ; }
int maxVal = currVal ;
for ( int j = 1 ; j < arr . Length ; j ++ ) { currVal = currVal + arrSum - arr . Length * arr [ arr . Length - j ] ; if ( currVal > maxVal ) maxVal = currVal ; }
return maxVal ; }
public static void Main ( ) { Console . WriteLine ( " Max ▁ sum ▁ is ▁ " + maxSum ( ) ) ; } }
static int maxSum ( int [ ] arr , int n ) {
int res = int . MinValue ;
for ( int i = 0 ; i < n ; i ++ ) {
int curr_sum = 0 ;
for ( int j = 0 ; j < n ; j ++ ) { int index = ( i + j ) % n ; curr_sum += j * arr [ index ] ; }
res = Math . Max ( res , curr_sum ) ; } return res ; }
public static void Main ( ) { int [ ] arr = { 8 , 3 , 1 , 2 } ; int n = arr . Length ; Console . WriteLine ( maxSum ( arr , n ) ) ; } }
using System ; class GFG { static int maxSum ( int [ ] arr , int n ) {
int cum_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) cum_sum += arr [ i ] ;
int curr_val = 0 ; for ( int i = 0 ; i < n ; i ++ ) curr_val += i * arr [ i ] ;
int res = curr_val ;
for ( int i = 1 ; i < n ; i ++ ) {
int next_val = curr_val - ( cum_sum - arr [ i - 1 ] ) + arr [ i - 1 ] * ( n - 1 ) ;
curr_val = next_val ;
res = Math . Max ( res , next_val ) ; } return res ; }
public static void Main ( ) { int [ ] arr = { 8 , 3 , 1 , 2 } ; int n = arr . Length ; Console . Write ( maxSum ( arr , n ) ) ; } }
static int countRotations ( int [ ] arr , int n ) {
int min = arr [ 0 ] , min_index = - 1 ; for ( int i = 0 ; i < n ; i ++ ) { if ( min > arr [ i ] ) { min = arr [ i ] ; min_index = i ; } } return min_index ; }
public static void Main ( ) { int [ ] arr = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = arr . Length ; Console . WriteLine ( countRotations ( arr , n ) ) ; } }
static int countRotations ( int [ ] arr , int low , int high ) {
if ( high < low ) return 0 ;
if ( high == low ) return low ;
int mid = low + ( high - low ) / 2 ;
if ( mid < high && arr [ mid + 1 ] < arr [ mid ] ) return ( mid + 1 ) ;
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) return mid ;
if ( arr [ high ] > arr [ mid ] ) return countRotations ( arr , low , mid - 1 ) ; return countRotations ( arr , mid + 1 , high ) ; }
public static void Main ( ) { int [ ] arr = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = arr . Length ; Console . WriteLine ( countRotations ( arr , 0 , n - 1 ) ) ; } }
static void preprocess ( int [ ] arr , int n , int [ ] temp ) {
for ( int i = 0 ; i < n ; i ++ ) temp [ i ] = temp [ i + n ] = arr [ i ] ; }
static void leftRotate ( int [ ] arr , int n , int k , int [ ] temp ) {
int start = k % n ;
for ( int i = start ; i < start + n ; i ++ ) Console . Write ( temp [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . Length ; int [ ] temp = new int [ 2 * n ] ; preprocess ( arr , n , temp ) ; int k = 2 ; leftRotate ( arr , n , k , temp ) ; k = 3 ; leftRotate ( arr , n , k , temp ) ; k = 4 ; leftRotate ( arr , n , k , temp ) ; } }
static void leftRotate ( int [ ] arr , int n , int k ) {
for ( int i = k ; i < k + n ; i ++ ) Console . Write ( arr [ i % n ] + " ▁ " ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . Length ; int k = 2 ; leftRotate ( arr , n , k ) ; Console . WriteLine ( ) ; k = 3 ; leftRotate ( arr , n , k ) ; Console . WriteLine ( ) ; k = 4 ; leftRotate ( arr , n , k ) ; Console . WriteLine ( ) ; } }
static void reverseArray ( int [ ] arr , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
static void rightRotate ( int [ ] arr , int d , int n ) { reverseArray ( arr , 0 , n - 1 ) ; reverseArray ( arr , 0 , d - 1 ) ; reverseArray ( arr , d , n - 1 ) ; }
static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 } ; int n = arr . Length ; int k = 3 ; rightRotate ( arr , k , n ) ; printArray ( arr , n ) ; } }
static int maxHamming ( int [ ] arr , int n ) {
int [ ] brr = new int [ 2 * n + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ i ] = arr [ i ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ n + i ] = arr [ i ] ;
int maxHam = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { int currHam = 0 ; for ( int j = i , k = 0 ; j < ( i + n ) ; j ++ , k ++ ) if ( brr [ j ] != arr [ k ] ) currHam ++ ;
if ( currHam == n ) return n ; maxHam = Math . Max ( maxHam , currHam ) ; } return maxHam ; }
public static void Main ( ) { int [ ] arr = { 2 , 4 , 6 , 8 } ; int n = arr . Length ; Console . Write ( maxHamming ( arr , n ) ) ; } }
static void leftRotate ( int [ ] arr , int n , int k ) {
int mod = k % n ;
for ( int i = 0 ; i < n ; ++ i ) Console . Write ( arr [ ( i + mod ) % n ] + " ▁ " ) ; Console . WriteLine ( ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . Length ; int k = 2 ;
leftRotate ( arr , n , k ) ; k = 3 ;
leftRotate ( arr , n , k ) ; k = 4 ;
leftRotate ( arr , n , k ) ; } }
static int findElement ( int [ ] arr , int [ , ] ranges , int rotations , int index ) { for ( int i = rotations - 1 ; i >= 0 ; i -- ) {
int left = ranges [ i , 0 ] ; int right = ranges [ i , 1 ] ;
if ( left <= index && right >= index ) { if ( index == left ) index = right ; else index -- ; } }
return arr [ index ] ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ;
int rotations = 2 ;
int [ , ] ranges = { { 0 , 2 } , { 0 , 3 } } ; int index = 1 ; Console . Write ( findElement ( arr , ranges , rotations , index ) ) ; } }
using System ; class GFG { public static void splitArr ( int [ ] arr , int n , int k ) { for ( int i = 0 ; i < k ; i ++ ) {
int x = arr [ 0 ] ; for ( int j = 0 ; j < n - 1 ; ++ j ) arr [ j ] = arr [ j + 1 ] ; arr [ n - 1 ] = x ; } }
public static void Main ( ) { int [ ] arr = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = arr . Length ; int position = 2 ; splitArr ( arr , 6 , position ) ; for ( int i = 0 ; i < n ; ++ i ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void rearrangeArr ( int [ ] arr , int n ) {
int evenPos = n / 2 ;
int oddPos = n - evenPos ; int [ ] tempArr = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) tempArr [ i ] = arr [ i ] ;
Array . Sort ( tempArr ) ; int j = oddPos - 1 ;
for ( int i = 0 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j -- ; } j = oddPos ;
for ( int i = 1 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j ++ ; }
for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int size = 7 ; rearrangeArr ( arr , size ) ; } }
static void pushZerosToEnd ( int [ ] arr , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
public static void Main ( ) { int [ ] arr = { 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 } ; int n = arr . Length ; pushZerosToEnd ( arr , n ) ; Console . WriteLine ( " Array ▁ after ▁ pushing ▁ all ▁ zeros ▁ to ▁ the ▁ back : ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static int minSwap ( int [ ] arr , int n , int k ) {
int count = 0 ; for ( int i = 0 ; i < n ; ++ i ) if ( arr [ i ] <= k ) ++ count ;
int bad = 0 ; for ( int i = 0 ; i < count ; ++ i ) if ( arr [ i ] > k ) ++ bad ;
int ans = bad ; for ( int i = 0 , j = count ; j < n ; ++ i , ++ j ) {
if ( arr [ i ] > k ) -- bad ;
if ( arr [ j ] > k ) ++ bad ;
ans = Math . Min ( ans , bad ) ; } return ans ; }
public static void Main ( ) { int [ ] arr = { 2 , 1 , 5 , 6 , 3 } ; int n = arr . Length ; int k = 3 ; Console . WriteLine ( minSwap ( arr , n , k ) ) ; int [ ] arr1 = { 2 , 7 , 9 , 5 , 8 , 7 , 4 } ; n = arr1 . Length ; k = 5 ; Console . WriteLine ( minSwap ( arr1 , n , k ) ) ; } }
static void reorder ( ) { int [ ] temp = new int [ arr . Length ] ;
for ( int i = 0 ; i < arr . Length ; i ++ ) temp [ index [ i ] ] = arr [ i ] ;
for ( int i = 0 ; i < arr . Length ; i ++ ) { arr [ i ] = temp [ i ] ; index [ i ] = i ; } }
public static void Main ( ) { reorder ( ) ; Console . WriteLine ( " Reordered ▁ array ▁ is : ▁ " ) ; Console . WriteLine ( string . Join ( " , " , arr ) ) ; Console . WriteLine ( " Modified ▁ Index ▁ array ▁ is : " ) ; Console . WriteLine ( string . Join ( " , " , index ) ) ; } }
static void printArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
static void RearrangePosNeg ( int [ ] arr , int n ) { int key , j ; for ( int i = 1 ; i < n ; i ++ ) { key = arr [ i ] ;
if ( key > 0 ) continue ;
j = i - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { arr [ j + 1 ] = arr [ j ] ; j = j - 1 ; }
arr [ j + 1 ] = key ; } }
public static void Main ( ) { int [ ] arr = { - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 } ; int n = arr . Length ; RearrangePosNeg ( arr , n ) ; printArray ( arr , n ) ; } }
static void rearrage ( int [ ] arr , int n ) {
int [ ] temp = new int [ n ] ;
int small = 0 , large = n - 1 ;
bool flag = true ;
for ( int i = 0 ; i < n ; i ++ ) { if ( flag ) temp [ i ] = arr [ large -- ] ; else temp [ i ] = arr [ small ++ ] ; flag = ! flag ; }
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 } ; Console . WriteLine ( " Original ▁ Array " ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; rearrage ( arr , arr . Length ) ; Console . WriteLine ( " STRNEWLINE Modified ▁ Array " ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void rearrange ( int [ ] arr , int n ) {
int max_idx = n - 1 , min_idx = 0 ;
int max_elem = arr [ n - 1 ] + 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] += ( arr [ max_idx ] % max_elem ) * max_elem ; max_idx -- ; }
else { arr [ i ] += ( arr [ min_idx ] % max_elem ) * max_elem ; min_idx ++ ; } }
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = arr [ i ] / max_elem ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = arr . Length ; Console . WriteLine ( " Original ▁ Array " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; rearrange ( arr , n ) ; Console . WriteLine ( " Modified ▁ Array " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
using System ; class GFG { static void rearrange ( int [ ] arr , int n ) { int j = 0 , temp ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < 0 ) { temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; j ++ ; } } }
static void printArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { - 1 , 2 , - 3 , 4 , 5 , 6 , - 7 , 8 , 9 } ; int n = arr . Length ; rearrange ( arr , n ) ; printArray ( arr , n ) ; } }
static void segregateElements ( int [ ] arr , int n ) {
int [ ] temp = new int [ n ] ;
int j = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] >= 0 ) temp [ j ++ ] = arr [ i ] ;
if ( j == n j == 0 ) return ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < 0 ) temp [ j ++ ] = arr [ i ] ;
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
public static void Main ( ) { int [ ] arr = { 1 , - 1 , - 3 , - 2 , 7 , 5 , 11 , 6 } ; int n = arr . Length ; segregateElements ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static void rearrange ( int [ ] arr , int n ) { int temp ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( i % 2 == 0 && arr [ i ] > arr [ i + 1 ] ) { temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } if ( i % 2 != 0 && arr [ i ] < arr [ i + 1 ] ) { temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } } }
static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( ) { int [ ] arr = { 6 , 4 , 2 , 1 , 8 , 3 } ; int n = arr . Length ; Console . WriteLine ( " Before ▁ rearranging : ▁ " ) ; printArray ( arr , n ) ; rearrange ( arr , n ) ; Console . WriteLine ( " After ▁ rearranging : ▁ " ) ; printArray ( arr , n ) ; } }
using System ; class GFG { static void rearrange ( int [ ] a , int size ) { int positive = 0 , negative = 1 , temp ; while ( true ) {
while ( positive < size && a [ positive ] >= 0 ) positive += 2 ;
while ( negative < size && a [ negative ] <= 0 ) negative += 2 ;
if ( positive < size && negative < size ) { temp = a [ positive ] ; a [ positive ] = a [ negative ] ; a [ negative ] = temp ; }
else break ; } }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 } ; int n = arr . Length ; rearrange ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static void arrayEvenAndOdd ( int [ ] arr , int n ) { int i = - 1 , j = 0 ; while ( j != n ) { if ( arr [ j ] % 2 == 0 ) { i ++ ;
int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } j ++ ; }
for ( int k = 0 ; k < n ; k ++ ) Console . Write ( arr [ k ] + " ▁ " ) ; }
static void Main ( ) { int [ ] arr = { 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 } ; int n = arr . Length ; arrayEvenAndOdd ( arr , n ) ; } }
static int largest ( ) { int i ;
int max = arr [ 0 ] ;
for ( i = 1 ; i < arr . Length ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
public static void Main ( ) { Console . WriteLine ( " Largest ▁ in ▁ given ▁ " + " array ▁ is ▁ " + largest ( ) ) ; } }
static int largest ( int [ ] arr , int n ) { return arr . Max ( ) ; }
static public void Main ( ) { int [ ] arr = { 10 , 324 , 45 , 90 , 9808 } ; int n = arr . Length ; Console . WriteLine ( largest ( arr , n ) ) ; } }
using System ; class GFG { static void findElements ( int [ ] arr , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) if ( arr [ j ] > arr [ i ] ) count ++ ; if ( count >= 2 ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void Main ( String [ ] args ) { int [ ] arr = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . Length ; findElements ( arr , n ) ; } }
using System ; class GFG { static void findElements ( int [ ] arr , int n ) { Array . Sort ( arr ) ; for ( int i = 0 ; i < n - 2 ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . Length ; findElements ( arr , n ) ; } }
using System ; class GFG { static void findElements ( int [ ] arr , int n ) { int first = int . MinValue ; int second = int . MaxValue ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) second = arr [ i ] ; } for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < second ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . Length ; findElements ( arr , n ) ; } }
public static double findMean ( int [ ] a , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += a [ i ] ; return ( double ) sum / ( double ) n ; }
public static double findMedian ( int [ ] a , int n ) {
Array . Sort ( a ) ;
if ( n % 2 != 0 ) return ( double ) a [ n / 2 ] ; return ( double ) ( a [ ( n - 1 ) / 2 ] + a [ n / 2 ] ) / 2.0 ; }
public static void Main ( ) { int [ ] a = { 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 } ; int n = a . Length ;
Console . Write ( " Mean ▁ = ▁ " + findMean ( a , n ) + " STRNEWLINE " ) ; Console . Write ( " Median ▁ = ▁ " + findMedian ( a , n ) + " STRNEWLINE " ) ; } }
public static void printSmall ( int [ ] arr , int n , int k ) {
for ( int i = k ; i < n ; ++ i ) {
int max_var = arr [ k - 1 ] ; int pos = k - 1 ; for ( int j = k - 2 ; j >= 0 ; j -- ) { if ( arr [ j ] > max_var ) { max_var = arr [ j ] ; pos = j ; } }
if ( max_var > arr [ i ] ) { int j = pos ; while ( j < k - 1 ) { arr [ j ] = arr [ j + 1 ] ; j ++ ; }
arr [ k - 1 ] = arr [ i ] ; } }
for ( int i = 0 ; i < k ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 } ; int n = 10 ; int k = 5 ; printSmall ( arr , n , k ) ; } }
static double sumNodes ( int l ) {
double leafNodeCount = Math . Pow ( 2 , l - 1 ) ; double sumLastLevel = 0 ;
sumLastLevel = ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ;
double sum = sumLastLevel * l ; return sum ; }
public static void Main ( ) { int l = 3 ; Console . Write ( sumNodes ( l ) ) ; } }
static void add ( int [ ] arr , int N , int lo , int hi , int val ) { arr [ lo ] += val ; if ( hi != N - 1 ) arr [ hi + 1 ] -= val ; }
static void updateArray ( int [ ] arr , int N ) {
for ( int i = 1 ; i < N ; i ++ ) arr [ i ] += arr [ i - 1 ] ; }
static void printArr ( int [ ] arr , int N ) { updateArray ( arr , N ) ; for ( int i = 0 ; i < N ; i ++ ) Console . Write ( " " + arr [ i ] + " ▁ " ) ; Console . Write ( " STRNEWLINE " ) ; }
public static void Main ( ) { int N = 6 ; int [ ] arr = new int [ N ] ;
add ( arr , N , 0 , 2 , 100 ) ; add ( arr , N , 1 , 5 , 100 ) ; add ( arr , N , 2 , 3 , 100 ) ; printArr ( arr , N ) ; } }
static int GCD ( int a , int b ) { if ( b == 0 ) return a ; return GCD ( b , a % b ) ; }
static void FillPrefixSuffix ( int [ ] prefix , int [ ] arr , int [ ] suffix , int n ) {
prefix [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) prefix [ i ] = GCD ( prefix [ i - 1 ] , arr [ i ] ) ;
suffix [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) suffix [ i ] = GCD ( suffix [ i + 1 ] , arr [ i ] ) ; }
static int GCDoutsideRange ( int l , int r , int [ ] prefix , int [ ] suffix , int n ) {
if ( l == 0 ) return suffix [ r + 1 ] ;
if ( r == n - 1 ) return prefix [ l - 1 ] ; return GCD ( prefix [ l - 1 ] , suffix [ r + 1 ] ) ; }
public static void Main ( ) { int [ ] arr = { 2 , 6 , 9 } ; int n = arr . Length ; int [ ] prefix = new int [ n ] ; int [ ] suffix = new int [ n ] ; FillPrefixSuffix ( prefix , arr , suffix , n ) ; int l = 0 , r = 0 ; Console . WriteLine ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; l = 1 ; r = 1 ; Console . WriteLine ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; l = 1 ; r = 2 ; Console . Write ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; } }
static int countInRange ( int [ ] arr , int n , int x , int y ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] >= x && arr [ i ] <= y ) count ++ ; } return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 4 , 9 , 10 , 3 } ; int n = arr . Length ;
int i = 1 , j = 4 ; Console . WriteLine ( countInRange ( arr , n , i , j ) ) ; i = 9 ; j = 12 ; Console . WriteLine ( countInRange ( arr , n , i , j ) ) ; } }
static int lowerIndex ( int [ ] arr , int n , int x ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] >= x ) h = mid - 1 ; else l = mid + 1 ; } return l ; }
static int upperIndex ( int [ ] arr , int n , int y ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] <= y ) l = mid + 1 ; else h = mid - 1 ; } return h ; }
static int countInRange ( int [ ] arr , int n , int x , int y ) {
int count = 0 ; count = upperIndex ( arr , n , y ) - lowerIndex ( arr , n , x ) + 1 ; return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 4 , 4 , 9 , 10 , 3 } ; int n = arr . Length ;
Array . Sort ( arr ) ;
int i = 1 , j = 4 ; Console . WriteLine ( countInRange ( arr , n , i , j ) ) ; ; i = 9 ; j = 12 ; Console . WriteLine ( countInRange ( arr , n , i , j ) ) ; } }
static void precompute ( int [ ] arr , int n , int [ ] pre ) { for ( int i = 0 ; i < n ; i ++ ) pre [ i ] = 0 ; pre [ n - 1 ] = arr [ n - 1 ] * ( int ) ( Math . Pow ( 2 , 0 ) ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) pre [ i ] = pre [ i + 1 ] + arr [ i ] * ( 1 << ( n - 1 - i ) ) ; }
static int decimalOfSubarr ( int [ ] arr , int l , int r , int n , int [ ] pre ) {
if ( r != n - 1 ) return ( pre [ l ] - pre [ r + 1 ] ) / ( 1 << ( n - 1 - r ) ) ; return pre [ l ] / ( 1 << ( n - 1 - r ) ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 1 , 0 , 1 , 1 } ; int n = arr . Length ; int [ ] pre = new int [ n ] ; precompute ( arr , n , pre ) ; Console . WriteLine ( decimalOfSubarr ( arr , 2 , 4 , n , pre ) ) ; Console . WriteLine ( decimalOfSubarr ( arr , 4 , 5 , n , pre ) ) ; } }
static int answerQuery ( int [ ] a , int n , int l , int r ) {
int count = 0 ;
l = l - 1 ;
for ( int i = l ; i < r ; i ++ ) { int divisors = 0 ;
for ( int j = l ; j < r ; j ++ ) {
if ( a [ j ] % a [ i ] == 0 ) divisors ++ ; else break ; }
if ( divisors == ( r - l ) ) count ++ ; }
return count ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 3 , 5 } ; int n = a . Length ; int l = 1 , r = 4 ; Console . WriteLine ( answerQuery ( a , n , l , r ) ) ; l = 2 ; r = 4 ; Console . WriteLine ( answerQuery ( a , n , l , r ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static int MAX = 2147483647 ; static int [ , ] one = new int [ 100001 , 32 ] ;
static void make_prefix ( int [ ] A , int n ) { for ( int j = 0 ; j < 32 ; j ++ ) one [ 0 , j ] = 0 ;
for ( int i = 1 ; i <= n ; i ++ ) { int a = A [ i - 1 ] ; for ( int j = 0 ; j < 32 ; j ++ ) { int x = ( int ) Math . Pow ( 2 , j ) ;
if ( ( a & x ) != 0 ) one [ i , j ] = 1 + one [ i - 1 , j ] ; else one [ i , j ] = one [ i - 1 , j ] ; } } }
static int Solve ( int L , int R ) { int l = L , r = R ; int tot_bits = r - l + 1 ;
int X = MAX ;
for ( int i = 0 ; i < 31 ; i ++ ) {
int x = one [ r , i ] - one [ l - 1 , i ] ;
if ( x >= tot_bits - x ) { int ith_bit = ( int ) Math . Pow ( 2 , i ) ;
X = X ^ ith_bit ; } } return X ; }
public static void Main ( ) { int n = 5 , q = 3 ; int [ ] A = { 210 , 11 , 48 , 22 , 133 } ; int [ ] L = { 1 , 4 , 2 } ; int [ ] R = { 3 , 14 , 4 } ; make_prefix ( A , n ) ; for ( int j = 0 ; j < q ; j ++ ) Console . WriteLine ( Solve ( L [ j ] , R [ j ] ) ) ; } }
static int answer_query ( int [ ] a , int n , int l , int r ) {
int count = 0 ; for ( int i = l ; i < r ; i ++ ) if ( a [ i ] == a [ i + 1 ] ) count += 1 ; return count ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = a . Length ;
int L , R ; L = 1 ; R = 8 ; Console . WriteLine ( answer_query ( a , n , L , R ) ) ;
L = 0 ; R = 4 ; Console . WriteLine ( answer_query ( a , n , L , R ) ) ; } }
using System ; class GFG { static int N = 1000 ;
static int [ ] prefixans = new int [ N ] ;
static void countIndex ( int [ ] a , int n ) {
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( a [ i ] == a [ i + 1 ] ) prefixans [ i ] = 1 ; if ( i != 0 ) prefixans [ i ] += prefixans [ i - 1 ] ; } }
static int answer_query ( int l , int r ) { if ( l == 0 ) return prefixans [ r - 1 ] ; else return prefixans [ r - 1 ] - prefixans [ l - 1 ] ; }
static void Main ( ) { int [ ] a = new int [ ] { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = a . Length ;
countIndex ( a , n ) ; int L , R ;
L = 1 ; R = 8 ; Console . WriteLine ( answer_query ( L , R ) ) ;
L = 0 ; R = 4 ; Console . WriteLine ( answer_query ( L , R ) ) ; } }
static int repeated_digit ( int n ) { var s = new HashSet < int > ( ) ;
while ( n != 0 ) { int d = n % 10 ;
if ( s . Contains ( d ) ) {
return 0 ; } s . Add ( d ) ; n = n / 10 ; }
return 1 ; }
static int calculate ( int L , int R ) { int answer = 0 ;
for ( int i = L ; i < R + 1 ; ++ i ) {
answer = answer + repeated_digit ( i ) ; } return answer ; }
public static void Main ( String [ ] args ) { int L = 1 , R = 100 ;
Console . WriteLine ( calculate ( L , R ) ) ; } }
using System ; class GFG { static int maxSubArraySum ( int [ ] a ) { int size = a . Length ; int max_so_far = int . MinValue , max_ending_here = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here = max_ending_here + a [ i ] ; if ( max_so_far < max_ending_here ) max_so_far = max_ending_here ; if ( max_ending_here < 0 ) max_ending_here = 0 ; } return max_so_far ; }
public static void Main ( ) { int [ ] a = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; Console . Write ( " Maximum ▁ contiguous ▁ sum ▁ is ▁ " + maxSubArraySum ( a ) ) ; } }
static int maxSubArraySum ( int [ ] a , int size ) { int max_so_far = a [ 0 ] , max_ending_here = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here = max_ending_here + a [ i ] ; if ( max_ending_here < 0 ) max_ending_here = 0 ;
else if ( max_so_far < max_ending_here ) = ; } return ; }
using System ; class GFG { static int maxSubArraySum ( int [ ] a , int size ) { int max_so_far = a [ 0 ] ; int curr_max = a [ 0 ] ; for ( int i = 1 ; i < size ; i ++ ) { curr_max = Math . Max ( a [ i ] , curr_max + a [ i ] ) ; max_so_far = Math . Max ( max_so_far , curr_max ) ; } return max_so_far ; }
public static void Main ( ) { int [ ] a = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; int n = a . Length ; Console . Write ( " Maximum ▁ contiguous ▁ sum ▁ is ▁ " + maxSubArraySum ( a , n ) ) ; } }
using System ; class GFG { static void maxSubArraySum ( int [ ] a , int size ) { int max_so_far = int . MinValue , max_ending_here = 0 , start = 0 , end = 0 , s = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here += a [ i ] ; if ( max_so_far < max_ending_here ) { max_so_far = max_ending_here ; start = s ; end = i ; } if ( max_ending_here < 0 ) { max_ending_here = 0 ; s = i + 1 ; } } Console . WriteLine ( " Maximum ▁ contiguous ▁ " + " sum ▁ is ▁ " + max_so_far ) ; Console . WriteLine ( " Starting ▁ index ▁ " + start ) ; Console . WriteLine ( " Ending ▁ index ▁ " + end ) ; }
public static void Main ( ) { int [ ] a = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; int n = a . Length ; maxSubArraySum ( a , n ) ; } }
static void findMinAvgSubarray ( int n , int k ) {
if ( n < k ) return ;
int res_index = 0 ;
int curr_sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) curr_sum += arr [ i ] ;
int min_sum = curr_sum ;
for ( int i = k ; i < n ; i ++ ) {
curr_sum += arr [ i ] - arr [ i - k ] ;
if ( curr_sum < min_sum ) { min_sum = curr_sum ; res_index = ( i - k + 1 ) ; } } Console . Write ( " Subarray ▁ between ▁ [ " + res_index + " , ▁ " + ( res_index + k - 1 ) + " ] ▁ has ▁ minimum ▁ average " ) ; }
public static void Main ( ) {
int k = 3 ; findMinAvgSubarray ( arr . Length , k ) ; } }
public static int minJumps ( int [ ] arr , int n ) {
int [ ] jumps = new int [ n ] ; int min ;
jumps [ n - 1 ] = 0 ;
for ( int i = n - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] == 0 ) { jumps [ i ] = int . MaxValue ; }
else if ( arr [ i ] >= n - i - 1 ) { jumps [ i ] = 1 ; }
else {
min = int . MaxValue ;
for ( int j = i + 1 ; j < n && j <= arr [ i ] + i ; j ++ ) { if ( min > jumps [ j ] ) { min = jumps [ j ] ; } }
if ( min != int . MaxValue ) { jumps [ i ] = min + 1 ; } else {
jumps [ i ] = min ; } } } return jumps [ 0 ] ; }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 1 , 3 , 6 , 1 , 0 , 9 } ; int size = arr . Length ; Console . WriteLine ( " Minimum ▁ number ▁ of " + " ▁ jumps ▁ to ▁ reach ▁ end ▁ is ▁ " + minJumps ( arr , size ) ) ; } }
static int smallestSubWithSum ( int [ ] arr , int n , int x ) {
int min_len = n + 1 ;
for ( int start = 0 ; start < n ; start ++ ) {
int curr_sum = arr [ start ] ;
if ( curr_sum > x ) return 1 ;
for ( int end = start + 1 ; end < n ; end ++ ) {
curr_sum += arr [ end ] ;
if ( curr_sum > x && ( end - start + 1 ) < min_len ) min_len = ( end - start + 1 ) ; } } return min_len ; }
static public void Main ( ) { int [ ] arr1 = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = arr1 . Length ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; if ( res1 == n1 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res1 ) ; int [ ] arr2 = { 1 , 10 , 5 , 2 , 7 } ; int n2 = arr2 . Length ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; if ( res2 == n2 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res2 ) ; int [ ] arr3 = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = arr3 . Length ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; if ( res3 == n3 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res3 ) ; } }
static int smallestSubWithSum ( int [ ] arr , int n , int x ) {
int curr_sum = 0 , min_len = n + 1 ;
int start = 0 , end = 0 ; while ( end < n ) {
while ( curr_sum <= x && end < n ) curr_sum += arr [ end ++ ] ;
while ( curr_sum > x && start < n ) {
if ( end - start < min_len ) min_len = end - start ;
curr_sum -= arr [ start ++ ] ; } } return min_len ; }
static public void Main ( ) { int [ ] arr1 = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = arr1 . Length ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; if ( res1 == n1 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res1 ) ; int [ ] arr2 = { 1 , 10 , 5 , 2 , 7 } ; int n2 = arr2 . Length ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; if ( res2 == n2 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res2 ) ; int [ ] arr3 = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = arr3 . Length ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; if ( res3 == n3 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res3 ) ; } }
static int findMaxAverage ( int [ ] arr , int n , int k ) {
if ( k > n ) return - 1 ;
int [ ] csum = new int [ n ] ; csum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) csum [ i ] = csum [ i - 1 ] + arr [ i ] ;
int max_sum = csum [ k - 1 ] , max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { int curr_sum = csum [ i ] - csum [ i - k ] ; if ( curr_sum > max_sum ) { max_sum = curr_sum ; max_end = i ; } }
return max_end - k + 1 ; }
static public void Main ( ) { int [ ] arr = { 1 , 12 , - 5 , - 6 , 50 , 3 } ; int k = 4 ; int n = arr . Length ; Console . WriteLine ( " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ " + " length ▁ " + k + " ▁ begins ▁ at ▁ index ▁ " + findMaxAverage ( arr , n , k ) ) ; } }
static int findMaxAverage ( int [ ] arr , int n , int k ) {
if ( k > n ) return - 1 ;
int sum = arr [ 0 ] ; for ( int i = 1 ; i < k ; i ++ ) sum += arr [ i ] ; int max_sum = sum ; int max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { sum = sum + arr [ i ] - arr [ i - k ] ; if ( sum > max_sum ) { max_sum = sum ; max_end = i ; } }
return max_end - k + 1 ; }
public static void Main ( ) { int [ ] arr = { 1 , 12 , - 5 , - 6 , 50 , 3 } ; int k = 4 ; int n = arr . Length ; Console . WriteLine ( " The ▁ maximum ▁ " + " average ▁ subarray ▁ of ▁ length ▁ " + k + " ▁ begins ▁ at ▁ index ▁ " + findMaxAverage ( arr , n , k ) ) ; } }
static int countMinOperations ( int n ) {
int result = 0 ;
while ( true ) {
int zero_count = 0 ;
int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] % 2 == 1 ) break ;
else if ( arr [ i ] == 0 ) ++ ; }
if ( zero_count == n ) return result ;
if ( i == n ) {
for ( int j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] / 2 ; result ++ ; }
for ( int j = i ; j < n ; j ++ ) { if ( arr [ j ] % 2 == 1 ) { arr [ j ] -- ; result ++ ; } } } }
public static void Main ( ) { Console . Write ( " Minimum ▁ number ▁ of ▁ steps ▁ required ▁ to ▁ STRNEWLINE " + " get ▁ the ▁ given ▁ target ▁ array ▁ is ▁ " + countMinOperations ( arr . Length ) ) ; } }
static int findMinOps ( int [ ] arr , int n ) {
int ans = 0 ;
for ( int i = 0 , j = n - 1 ; i <= j ; ) {
if ( arr [ i ] == arr [ j ] ) { i ++ ; j -- ; }
else if ( arr [ i ] > arr [ j ] ) {
j -- ; arr [ j ] += arr [ j + 1 ] ; ans ++ ; }
else { i ++ ; arr [ i ] += arr [ i - 1 ] ; ans ++ ; } } return ans ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 4 , 5 , 9 , 1 } ; Console . Write ( " Count ▁ of ▁ minimum ▁ operations ▁ is ▁ " + findMinOps ( arr , arr . Length ) ) ; } }
static int findSmallest ( int [ ] arr , int n ) {
int res = 1 ;
for ( int i = 0 ; i < n && arr [ i ] <= res ; i ++ ) res = res + arr [ i ] ; return res ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 3 , 4 , 5 } ; int n1 = arr1 . Length ; Console . WriteLine ( findSmallest ( arr1 , n1 ) ) ; int [ ] arr2 = { 1 , 2 , 6 , 10 , 11 , 15 } ; int n2 = arr2 . Length ; Console . WriteLine ( findSmallest ( arr2 , n2 ) ) ; int [ ] arr3 = { 1 , 1 , 1 , 1 } ; int n3 = arr3 . Length ; Console . WriteLine ( findSmallest ( arr3 , n3 ) ) ; int [ ] arr4 = { 1 , 1 , 3 , 4 } ; int n4 = arr4 . Length ; Console . WriteLine ( findSmallest ( arr4 , n4 ) ) ; } }
static int findMinDiff ( int [ ] arr , int n ) {
int diff = int . MaxValue ;
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( Math . Abs ( ( arr [ i ] - arr [ j ] ) ) < diff ) diff = Math . Abs ( ( arr [ i ] - arr [ j ] ) ) ;
return diff ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 5 , 3 , 19 , 18 , 25 } ; Console . Write ( " Minimum ▁ difference ▁ is ▁ " + findMinDiff ( arr , arr . Length ) ) ; } }
static int findMinDiff ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
int diff = int . MaxValue ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i + 1 ] - arr [ i ] < diff ) diff = arr [ i + 1 ] - arr [ i ] ;
return diff ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 5 , 3 , 19 , 18 , 25 } ; Console . WriteLine ( " Minimum ▁ difference ▁ is ▁ " + findMinDiff ( arr , arr . Length ) ) ; } }
static public void Main ( ) { int a = 2 , b = 10 ; int size = Math . Abs ( b - a ) + 1 ; int [ ] array = new int [ size ] ;
for ( int i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) array [ i - a ] = 1 ; Console . WriteLine ( " MULTIPLES ▁ of ▁ 2" + " ▁ and ▁ 5 : " ) ; for ( int i = a ; i <= b ; i ++ ) if ( array [ i - a ] == 1 ) Console . Write ( i + " ▁ " ) ; } }
static int longestCommonSum ( int n ) {
int maxLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int sum1 = 0 , sum2 = 0 ;
for ( int j = i ; j < n ; j ++ ) {
sum1 += arr1 [ j ] ; sum2 += arr2 [ j ] ;
if ( sum1 == sum2 ) { int len = j - i + 1 ; if ( len > maxLen ) maxLen = len ; } } } return maxLen ; }
public static void Main ( ) { Console . Write ( " Length ▁ of ▁ the ▁ longest ▁ " + " common ▁ span ▁ with ▁ same ▁ sum ▁ is ▁ " ) ; Console . Write ( longestCommonSum ( arr1 . Length ) ) ; } }
static bool sortedAfterSwap ( int [ ] A , bool [ ] B , int n ) { int i , j ;
for ( i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] ) { j = i ; while ( B [ j ] ) { j ++ ; }
Array . Sort ( A , i , 1 + j ) ; i = j ; } }
for ( i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) { return false ; } } return true ; }
public static void Main ( ) { int [ ] A = { 1 , 2 , 5 , 3 , 4 , 6 } ; bool [ ] B = { false , true , true , true , false } ; int n = A . Length ; if ( sortedAfterSwap ( A , B , n ) ) { Console . WriteLine ( " A ▁ can ▁ be ▁ sorted " ) ; } else { Console . WriteLine ( " A ▁ can ▁ not ▁ be ▁ sorted " ) ; } } }
static int sortedAfterSwap ( int [ ] A , int [ ] B , int n ) { int t = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] != 0 ) { if ( A [ i ] != i + 1 ) t = A [ i ] ; A [ i ] = A [ i + 1 ] ; A [ i + 1 ] = t ; } }
for ( int i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) return 0 ; } return 1 ; }
public static void Main ( ) { int [ ] A = { 1 , 2 , 5 , 3 , 4 , 6 } ; int [ ] B = { 0 , 1 , 1 , 1 , 0 } ; int n = A . Length ; if ( sortedAfterSwap ( A , B , n ) == 0 ) Console . WriteLine ( " A ▁ can ▁ be ▁ sorted " ) ; else Console . WriteLine ( " A ▁ can ▁ not ▁ be ▁ sorted " ) ; } }
int type0 = 0 ; int type1 = n - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type0 ] = arr [ type0 ] + arr [ type1 ] ; arr [ type1 ] = arr [ type0 ] - arr [ type1 ] ; arr [ type0 ] = arr [ type0 ] - arr [ type1 ] ; type1 -- ; } else { type0 ++ ; } } }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 } ; segregate0and1 ( arr , arr . Length ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static bool increasing ( int [ ] a , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( a [ i ] >= a [ i + 1 ] ) return false ; return true ; }
public static bool decreasing ( int [ ] arr , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] < arr [ i + 1 ] ) return false ; return true ; } public static int shortestUnsorted ( int [ ] a , int n ) {
if ( increasing ( a , n ) == true || decreasing ( a , n ) == true ) return 0 ; else return 3 ; }
public static void Main ( ) { int [ ] ar = new int [ ] { 7 , 9 , 10 , 8 , 11 } ; int n = ar . Length ; Console . WriteLine ( shortestUnsorted ( ar , n ) ) ; } }
static int printUnion ( int [ ] arr1 , int [ ] arr2 , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) Console . Write ( arr1 [ i ++ ] + " ▁ " ) ; else if ( arr2 [ j ] < arr1 [ i ] ) Console . Write ( arr2 [ j ++ ] + " ▁ " ) ; else { Console . Write ( arr2 [ j ++ ] + " ▁ " ) ; i ++ ; } }
while ( i < m ) Console . Write ( arr1 [ i ++ ] + " ▁ " ) ; while ( j < n ) Console . Write ( arr2 [ j ++ ] + " ▁ " ) ; return 0 ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 2 , 4 , 5 , 6 } ; int [ ] arr2 = { 2 , 3 , 5 , 7 } ; int m = arr1 . Length ; int n = arr2 . Length ; printUnion ( arr1 , arr2 , m , n ) ; } }
static void printIntersection ( int [ ] arr1 , int [ ] arr2 , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) i ++ ; else if ( arr2 [ j ] < arr1 [ i ] ) j ++ ; else { Console . Write ( arr2 [ j ++ ] + " ▁ " ) ; i ++ ; } } }
public static void Main ( ) { int [ ] arr1 = { 1 , 2 , 4 , 5 , 6 } ; int [ ] arr2 = { 2 , 3 , 5 , 7 } ; int m = arr1 . Length ; int n = arr2 . Length ;
printIntersection ( arr1 , arr2 , m , n ) ; } }
static void printUnion ( int [ ] arr1 , int [ ] arr2 , int m , int n ) {
if ( m > n ) { int [ ] tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
Array . Sort ( arr1 ) ; for ( int i = 0 ; i < m ; i ++ ) Console . Write ( arr1 [ i ] + " ▁ " ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) == - 1 ) Console . Write ( arr2 [ i ] + " ▁ " ) ; } }
static void printIntersection ( int [ ] arr1 , int [ ] arr2 , int m , int n ) {
if ( m > n ) { int [ ] tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
Array . Sort ( arr1 ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) != - 1 ) Console . Write ( arr2 [ i ] + " ▁ " ) ; } }
static int binarySearch ( int [ ] arr , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
static public void Main ( ) { int [ ] arr1 = { 7 , 1 , 5 , 2 , 3 , 6 } ; int [ ] arr2 = { 3 , 8 , 6 , 20 , 7 } ; int m = arr1 . Length ; int n = arr2 . Length ;
Console . WriteLine ( " Union ▁ of ▁ two ▁ arrays ▁ is ▁ " ) ; printUnion ( arr1 , arr2 , m , n ) ; Console . WriteLine ( " " ) ; Console . WriteLine ( " Intersection ▁ of ▁ two ▁ arrays ▁ is ▁ " ) ; printIntersection ( arr1 , arr2 , m , n ) ; } }
static void intersection ( int [ ] a , int [ ] b , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) { if ( a [ i ] > b [ j ] ) { j ++ ; } else if ( b [ j ] > a [ i ] ) { i ++ ; } else {
Console . Write ( a [ i ] + " ▁ " ) ; i ++ ; j ++ ; } } }
public static void Main ( ) { int [ ] a = { 1 , 3 , 2 , 3 , 4 , 5 , 5 , 6 } ; int [ ] b = { 3 , 3 , 5 } ; int n = a . Length ; int m = b . Length ;
Array . Sort ( a ) ; Array . Sort ( b ) ;
intersection ( a , b , n , m ) ; } }
using System ; class GFG { static int countPairsWithDiffK ( int [ ] arr , int n , int k ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] - arr [ j ] == k arr [ j ] - arr [ i ] == k ) count ++ ; } return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . Length ; int k = 3 ; Console . WriteLine ( " Count ▁ of ▁ pairs ▁ with ▁ " + " ▁ given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static int binarySearch ( int [ ] arr , int low , int high , int x ) { if ( high >= low ) { int mid = low + ( high - low ) / 2 ; if ( x == arr [ mid ] ) return mid ; if ( x > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
static int countPairsWithDiffK ( int [ ] arr , int n , int k ) { int count = 0 , i ;
Array . Sort ( arr ) ;
for ( i = 0 ; i < n - 1 ; i ++ ) if ( binarySearch ( arr , i + 1 , n - 1 , arr [ i ] + k ) != - 1 ) count ++ ; return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . Length ; int k = 3 ; Console . WriteLine ( " Count ▁ of ▁ pairs ▁ with " + " ▁ given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static int countPairsWithDiffK ( int [ ] arr , int n , int k ) { int count = 0 ;
Array . Sort ( arr ) ; int l = 0 ; int r = 0 ; while ( r < n ) { if ( arr [ r ] - arr [ l ] == k ) { count ++ ; l ++ ; r ++ ; } else if ( arr [ r ] - arr [ l ] > k ) l ++ ;
else r ++ ; } return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . Length ; int k = 3 ; Console . Write ( " Count ▁ of ▁ pairs ▁ with ▁ " + " given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static void constructArr ( int [ ] arr , int [ ] pair , int n ) { arr [ 0 ] = ( pair [ 0 ] + pair [ 1 ] - pair [ n - 1 ] ) / 2 ; for ( int i = 1 ; i < n ; i ++ ) arr [ i ] = pair [ i - 1 ] - arr [ 0 ] ; }
public static void Main ( ) { int [ ] pair = { 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 } ; int n = 5 ; int [ ] arr = new int [ n ] ; constructArr ( arr , pair , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public class Test { static int [ ] arr1 = new int [ ] { 1 , 5 , 9 , 10 , 15 , 20 } ; static int [ ] arr2 = new int [ ] { 2 , 3 , 8 , 13 } ; static void merge ( int m , int n ) {
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int j , last = arr1 [ m - 1 ] ; for ( j = m - 2 ; j >= 0 && arr1 [ j ] > arr2 [ i ] ; j -- ) arr1 [ j + 1 ] = arr1 [ j ] ;
if ( j != m - 2 last > arr2 [ i ] ) { arr1 [ j + 1 ] = arr2 [ i ] ; arr2 [ i ] = last ; } } }
public static void Main ( ) { merge ( arr1 . Length , arr2 . Length ) ; Console . Write ( " After ▁ Merging ▁ STRNEWLINE First ▁ Array : ▁ " ) ; for ( int i = 0 ; i < arr1 . Length ; i ++ ) { Console . Write ( arr1 [ i ] + " ▁ " ) ; } Console . Write ( " STRNEWLINE Second ▁ Array : ▁ " ) ; for ( int i = 0 ; i < arr2 . Length ; i ++ ) { Console . Write ( arr2 [ i ] + " ▁ " ) ; } } }
public static int minMaxProduct ( int [ ] arr1 , int [ ] arr2 , int n1 , int n2 ) {
Array . Sort ( arr1 ) ; Array . Sort ( arr2 ) ;
return arr1 [ n1 - 1 ] * arr2 [ 0 ] ; }
public static void Main ( ) { int [ ] arr1 = new int [ ] { 10 , 2 , 3 , 6 , 4 , 1 } ; int [ ] arr2 = new int [ ] { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = 6 ; int n2 = 6 ; Console . WriteLine ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ; } }
public static int minMaxProduct ( int [ ] arr1 , int [ ] arr2 , int n1 , int n2 ) {
int max = arr1 [ 0 ] ;
int min = arr2 [ 0 ] ; int i ; for ( i = 1 ; i < n1 && i < n2 ; ++ i ) {
if ( arr1 [ i ] > max ) max = arr1 [ i ] ;
if ( arr2 [ i ] < min ) min = arr2 [ i ] ; }
while ( i < n1 ) { if ( arr1 [ i ] > max ) max = arr1 [ i ] ; i ++ ; } while ( i < n2 ) { if ( arr2 [ i ] < min ) min = arr2 [ i ] ; i ++ ; } return max * min ; }
public static void Main ( ) { int [ ] arr1 = new int [ ] { 10 , 2 , 3 , 6 , 4 , 1 } ; int [ ] arr2 = new int [ ] { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = 6 ; int n2 = 6 ; Console . WriteLine ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ; } }
static int insertSorted ( int [ ] arr , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; arr [ n ] = key ; return ( n + 1 ) ; }
public static void Main ( ) { int [ ] arr = new int [ 20 ] ; arr [ 0 ] = 12 ; arr [ 1 ] = 16 ; arr [ 2 ] = 20 ; arr [ 3 ] = 40 ; arr [ 4 ] = 50 ; arr [ 5 ] = 70 ; int capacity = 20 ; int n = 6 ; int i , key = 26 ; Console . Write ( " Before ▁ Insertion : ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ;
n = insertSorted ( arr , n , key , capacity ) ; Console . Write ( " After ▁ Insertion : ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static int findElement ( int [ ] arr , int n , int key ) { int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
static int deleteElement ( int [ ] arr , int n , int key ) {
int pos = findElement ( arr , n , key ) ; if ( pos == - 1 ) { Console . WriteLine ( " Element ▁ not ▁ found " ) ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
public static void Main ( ) { int i ; int [ ] arr = { 10 , 50 , 30 , 40 , 20 } ; int n = arr . Length ; int key = 30 ; Console . Write ( " Array ▁ before ▁ deletion ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; n = deleteElement ( arr , n , key ) ; Console . Write ( " Array ▁ after ▁ deletion ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static void findCommon ( int [ ] ar1 , int [ ] ar2 , int [ ] ar3 ) {
int i = 0 , j = 0 , k = 0 ;
while ( i < ar1 . Length && j < ar2 . Length && k < ar3 . Length ) {
if ( ar1 [ i ] == ar2 [ j ] && ar2 [ j ] == ar3 [ k ] ) { Console . Write ( ar1 [ i ] + " ▁ " ) ; i ++ ; j ++ ; k ++ ; }
else if ( ar1 [ i ] < ar2 [ j ] ) ++ ;
else if ( ar2 [ j ] < ar3 [ k ] ) ++ ;
else k ++ ; } }
public static void Main ( ) { int [ ] ar1 = { 1 , 5 , 10 , 20 , 40 , 80 } ; int [ ] ar2 = { 6 , 7 , 20 , 80 , 100 } ; int [ ] ar3 = { 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 } ; Console . Write ( " Common ▁ elements ▁ are ▁ " ) ; findCommon ( ar1 , ar2 , ar3 ) ; } }
static int binarySearch ( int [ ] arr , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ; if ( arr [ mid ] == x ) return mid ; if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ; return binarySearch ( arr , mid + 1 , r , x ) ; } return - 1 ; }
static int findPos ( int [ ] arr , int key ) { int l = 0 , h = 1 ; int val = arr [ 0 ] ;
while ( val < key ) {
l = h ;
h = 2 * h ;
val = arr [ h ] ; }
return binarySearch ( arr , l , h , key ) ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 } ; int ans = findPos ( arr , 10 ) ; if ( ans == - 1 ) Console . Write ( " Element ▁ not ▁ found " ) ; else Console . Write ( " Element ▁ found ▁ at ▁ " + " index ▁ " + ans ) ; } }
static int findSingle ( int [ ] ar , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
public static void Main ( ) { int [ ] ar = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = ar . Length ; Console . Write ( " Element ▁ occurring ▁ once ▁ is ▁ " + findSingle ( ar , n ) + " ▁ " ) ; } }
static bool isPresent ( int [ ] B , int m , int x ) { for ( int i = 0 ; i < m ; i ++ ) if ( B [ i ] == x ) return true ; return false ; }
static int findMaxSubarraySumUtil ( int [ ] A , int [ ] B , int n , int m ) {
int max_so_far = - 2147483648 , curr_max = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( isPresent ( B , m , A [ i ] ) ) { curr_max = 0 ; continue ; }
curr_max = Math . Max ( A [ i ] , curr_max + A [ i ] ) ; max_so_far = Math . Max ( max_so_far , curr_max ) ; } return max_so_far ; }
static void findMaxSubarraySum ( int [ ] A , int [ ] B , int n , int m ) { int maxSubarraySum = findMaxSubarraySumUtil ( A , B , n , m ) ;
if ( maxSubarraySum == - 2147483648 ) { Console . Write ( " Maximum ▁ Subarray ▁ Sum " + " ▁ " + " can ' t ▁ be ▁ found " ) ; } else { Console . Write ( " The ▁ Maximum ▁ Subarray ▁ Sum ▁ = ▁ " + maxSubarraySum ) ; } }
static public void Main ( ) { int [ ] A = { 3 , 4 , 5 , - 4 , 6 } ; int [ ] B = { 1 , 8 , 5 } ; int n = A . Length ; int m = B . Length ;
findMaxSubarraySum ( A , B , n , m ) ; } }
static int findMaxSum ( int [ ] arr , int n ) { int res = int . MinValue ; for ( int i = 0 ; i < n ; i ++ ) { int prefix_sum = arr [ i ] ; for ( int j = 0 ; j < i ; j ++ ) prefix_sum += arr [ j ] ; int suffix_sum = arr [ i ] ; for ( int j = n - 1 ; j > i ; j -- ) suffix_sum += arr [ j ] ; if ( prefix_sum == suffix_sum ) res = Math . Max ( res , prefix_sum ) ; } return res ; }
public static void Main ( ) { int [ ] arr = { - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( findMaxSum ( arr , n ) ) ; } }
static int findMaxSum ( int [ ] arr , int n ) {
int [ ] preSum = new int [ n ] ;
int [ ] suffSum = new int [ n ] ;
int ans = int . MinValue ;
preSum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) preSum [ i ] = preSum [ i - 1 ] + arr [ i ] ;
suffSum [ n - 1 ] = arr [ n - 1 ] ; if ( preSum [ n - 1 ] == suffSum [ n - 1 ] ) ans = Math . Max ( ans , preSum [ n - 1 ] ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) { suffSum [ i ] = suffSum [ i + 1 ] + arr [ i ] ; if ( suffSum [ i ] == preSum [ i ] ) ans = Math . Max ( ans , preSum [ i ] ) ; } return ans ; }
static public void Main ( ) { int [ ] arr = { - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( findMaxSum ( arr , n ) ) ; } }
using System ; class GFG { void printLeaders ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) { int j ; for ( j = i + 1 ; j < size ; j ++ ) { if ( arr [ i ] <= arr [ j ] ) break ; }
if ( j == size ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void Main ( ) { GFG lead = new GFG ( ) ; int [ ] arr = new int [ ] { 16 , 17 , 4 , 3 , 5 , 2 } ; int n = arr . Length ; lead . printLeaders ( arr , n ) ; } }
void printLeaders ( int [ ] arr , int size ) { int max_from_right = arr [ size - 1 ] ;
Console . Write ( max_from_right + " ▁ " ) ; for ( int i = size - 2 ; i >= 0 ; i -- ) { if ( max_from_right < arr [ i ] ) { max_from_right = arr [ i ] ; Console . Write ( max_from_right + " ▁ " ) ; } } }
public static void Main ( String [ ] args ) { LeadersInArray lead = new LeadersInArray ( ) ; int [ ] arr = new int [ ] { 16 , 17 , 4 , 3 , 5 , 2 } ; int n = arr . Length ; lead . printLeaders ( arr , n ) ; } }
static void findMajority ( int [ ] arr , int n ) { int maxCount = 0 ;
int index = - 1 ; for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; }
if ( count > maxCount ) { maxCount = count ; index = i ; } }
if ( maxCount > n / 2 ) Console . WriteLine ( arr [ index ] ) ; else Console . WriteLine ( " No ▁ Majority ▁ Element " ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 1 , 2 , 1 , 3 , 5 , 1 } ; int n = arr . Length ;
findMajority ( arr , n ) ; } }
using System ; class GFG { static int maxTripletSum ( int [ ] arr , int n ) {
int sum = - 1000000 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( sum < arr [ i ] + arr [ j ] + arr [ k ] ) sum = arr [ i ] + arr [ j ] + arr [ k ] ; return sum ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( maxTripletSum ( arr , n ) ) ; } }
static int maxTripletSum ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
return arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( maxTripletSum ( arr , n ) ) ; } }
static int maxTripletSum ( int [ ] arr , int n ) {
int maxA = - 100000000 , maxB = - 100000000 ; int maxC = - 100000000 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > maxA ) { maxC = maxB ; maxB = maxA ; maxA = arr [ i ] ; }
else if ( arr [ i ] > maxB ) { maxC = maxB ; maxB = arr [ i ] ; }
else if ( arr [ i ] > maxC ) maxC = arr [ i ] ; } return ( maxA + maxB + maxC ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( maxTripletSum ( arr , n ) ) ; } }
static int maximum ( int a , int b , int c ) { return Math . Max ( Math . Max ( a , b ) , c ) ; }
static int minimum ( int a , int b , int c ) { return Math . Min ( Math . Min ( a , b ) , c ) ; }
static void smallestDifferenceTriplet ( int [ ] arr1 , int [ ] arr2 , int [ ] arr3 , int n ) {
Array . Sort ( arr1 ) ; Array . Sort ( arr2 ) ; Array . Sort ( arr3 ) ;
int res_min = 0 , res_max = 0 , res_mid = 0 ;
int i = 0 , j = 0 , k = 0 ;
int diff = 2147483647 ; while ( i < n && j < n && k < n ) { int sum = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
int max = maximum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ;
int min = minimum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ; if ( min == arr1 [ i ] ) i ++ ; else if ( min == arr2 [ j ] ) j ++ ; else k ++ ;
if ( diff > ( max - min ) ) { diff = max - min ; res_max = max ; res_mid = sum - ( max + min ) ; res_min = min ; } }
Console . WriteLine ( res_max + " , ▁ " + res_mid + " , ▁ " + res_min ) ; }
static public void Main ( ) { int [ ] arr1 = { 5 , 2 , 8 } ; int [ ] arr2 = { 10 , 7 , 12 } ; int [ ] arr3 = { 9 , 14 , 6 } ; int n = arr1 . Length ; smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) ; } }
bool find3Numbers ( int [ ] A , int arr_size , int sum ) { int l , r ;
quickSort ( A , 0 , arr_size - 1 ) ;
for ( int i = 0 ; i < arr_size - 2 ; i ++ ) {
l = i + 1 ;
r = arr_size - 1 ; while ( l < r ) { if ( A [ i ] + A [ l ] + A [ r ] == sum ) { Console . Write ( " Triplet ▁ is ▁ " + A [ i ] + " , ▁ " + A [ l ] + " , ▁ " + A [ r ] ) ; return true ; } else if ( A [ i ] + A [ l ] + A [ r ] < sum ) l ++ ;
else r -- ; } }
return false ; }
static void Main ( ) { GFG triplet = new GFG ( ) ; int [ ] A = new int [ ] { 1 , 4 , 45 , 6 , 10 , 8 } ; int sum = 22 ; int arr_size = A . Length ; triplet . find3Numbers ( A , arr_size , sum ) ; } }
static void subArray ( int n ) {
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i ; j < n ; j ++ ) {
for ( int k = i ; k <= j ; k ++ ) Console . Write ( arr [ k ] + " ▁ " ) ; Console . WriteLine ( " " ) ; } } }
public static void Main ( ) { Console . WriteLine ( " All ▁ Non - empty ▁ Subarrays " ) ; subArray ( arr . Length ) ; } }
using System ; class GFG { static void printSubsequences ( int [ ] arr , int n ) {
int opsize = ( int ) Math . Pow ( 2 , n ) ;
for ( int counter = 1 ; counter < opsize ; counter ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( ( counter & ( 1 << j ) ) != 0 ) Console . Write ( arr [ j ] + " ▁ " ) ; } Console . WriteLine ( ) ; } }
static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 } ; int n = arr . Length ; Console . WriteLine ( " All ▁ Non - empty ▁ Subsequences " ) ; printSubsequences ( arr , n ) ; } }
static void productArray ( int [ ] arr , int n ) {
if ( n == 1 ) { Console . Write ( 0 ) ; return ; } int i , temp = 1 ;
int [ ] prod = new int [ n ] ;
for ( int j = 0 ; j < n ; j ++ ) prod [ j ] = 1 ;
for ( i = 0 ; i < n ; i ++ ) { prod [ i ] = temp ; temp *= arr [ i ] ; }
temp = 1 ;
for ( i = n - 1 ; i >= 0 ; i -- ) { prod [ i ] *= temp ; temp *= arr [ i ] ; }
for ( i = 0 ; i < n ; i ++ ) Console . Write ( prod [ i ] + " ▁ " ) ; return ; }
public static void Main ( ) { int [ ] arr = { 10 , 3 , 5 , 6 , 2 } ; int n = arr . Length ; Console . WriteLine ( " The ▁ product ▁ array ▁ is ▁ : ▁ " ) ; productArray ( arr , n ) ; } }
static bool areConsecutive ( int [ ] arr , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) {
bool [ ] visited = new bool [ n ] ; int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( visited [ arr [ i ] - min ] != false ) return false ;
visited [ arr [ i ] - min ] = true ; }
return true ; }
return false ; }
static int getMin ( int [ ] arr , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } static int getMax ( int [ ] arr , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void Main ( ) { int [ ] arr = { 5 , 4 , 2 , 3 , 1 , 6 } ; int n = arr . Length ; if ( areConsecutive ( arr , n ) == true ) Console . Write ( " Array ▁ elements ▁ are " + " ▁ consecutive " ) ; else Console . Write ( " Array ▁ elements ▁ are " + " ▁ not ▁ consecutive " ) ; } }
static bool areConsecutive ( int [ ] arr , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { int j ; if ( arr [ i ] < 0 ) j = - arr [ i ] - min ; else j = arr [ i ] - min ;
if ( arr [ j ] > 0 ) arr [ j ] = - arr [ j ] ; else return false ; }
return true ; }
return false ; }
static int getMin ( int [ ] arr , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } static int getMax ( int [ ] arr , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void Main ( ) { int [ ] arr = { 5 , 4 , 2 , 3 , 1 , 6 } ; int n = arr . Length ; if ( areConsecutive ( arr , n ) == true ) Console . Write ( " Array ▁ elements ▁ " + " are ▁ consecutive " ) ; else Console . Write ( " Array ▁ elements ▁ " + " are ▁ not ▁ consecutive " ) ; } }
using System ; namespace Complement { public class GFG { static void relativeComplement ( int [ ] arr1 , int [ ] arr2 , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) {
if ( arr1 [ i ] < arr2 [ j ] ) { Console . Write ( arr1 [ i ] + " ▁ " ) ; i ++ ;
} else if ( arr1 [ i ] > arr2 [ j ] ) { j ++ ;
} else if ( arr1 [ i ] == arr2 [ j ] ) { i ++ ; j ++ ; } }
while ( i < n ) Console . Write ( arr1 [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr1 = { 3 , 6 , 10 , 12 , 15 } ; int [ ] arr2 = { 1 , 3 , 5 , 10 , 16 } ; int n = arr1 . Length ; int m = arr2 . Length ; relativeComplement ( arr1 , arr2 , n , m ) ; } } }
static int minOps ( int [ ] arr , int n , int k ) {
Array . Sort ( arr ) ; int max = arr [ arr . Length - 1 ] ; int res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ( max - arr [ i ] ) % k != 0 ) return - 1 ;
else res += ( - arr [ i ] ) / k ; }
return res ; }
public static void Main ( ) { int [ ] arr = { 21 , 33 , 9 , 45 , 63 } ; int n = arr . Length ; int k = 6 ; Console . Write ( minOps ( arr , n , k ) ) ; } }
using System ; class GFG { static int solve ( int [ ] A , int [ ] B , int [ ] C ) { int i , j , k ;
min_diff = Math . Abs ( Math . Max ( A [ i ] , Math . Max ( B [ j ] , C [ k ] ) ) - Math . Min ( A [ i ] , Math . Min ( B [ j ] , C [ k ] ) ) ) ; while ( i != - 1 && j != - 1 && k != - 1 ) { current_diff = Math . Abs ( Math . Max ( A [ i ] , Math . Max ( B [ j ] , C [ k ] ) ) - Math . Min ( A [ i ] , Math . Min ( B [ j ] , C [ k ] ) ) ) ;
if ( current_diff < min_diff ) min_diff = current_diff ;
max_term = Math . Max ( A [ i ] , Math . Max ( B [ j ] , C [ k ] ) ) ;
if ( A [ i ] == max_term ) i -= 1 ; else if ( B [ j ] == max_term ) j -= 1 ; else k -= 1 ; } return min_diff ; }
public static void Main ( ) { int [ ] D = { 5 , 8 , 10 , 15 } ; int [ ] E = { 6 , 9 , 15 , 78 , 89 } ; int [ ] F = { 2 , 3 , 6 , 6 , 8 , 8 , 10 } ; Console . WriteLine ( solve ( D , E , F ) ) ; } }
static int search ( int [ ] arr , int n , int x ) { int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == x ) { return i ; } } return - 1 ; }
public static void Main ( ) { int [ ] arr = { 1 , 10 , 30 , 15 } ; int x = 30 ; int n = arr . Length ; Console . WriteLine ( x + " ▁ is ▁ present ▁ at ▁ index ▁ " + search ( arr , n , x ) ) ; } }
static int binarySearch ( int [ ] arr , int x ) { int l = 0 , r = arr . Length - 1 ; while ( l <= r ) { int m = l + ( r - l ) / 2 ;
if ( arr [ m ] == x ) return m ;
if ( arr [ m ] < x ) l = m + 1 ;
else r = m - 1 ; }
return - 1 ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 4 , 10 , 40 } ; int n = arr . Length ; int x = 10 ; int result = binarySearch ( arr , x ) ; if ( result == - 1 ) Console . WriteLine ( " Element ▁ not ▁ present " ) ; else Console . WriteLine ( " Element ▁ found ▁ at ▁ " + " index ▁ " + result ) ; } }
using System ; public class JumpSearch { public static int jumpSearch ( int [ ] arr , int x ) { int n = arr . Length ;
int step = ( int ) Math . Floor ( Math . Sqrt ( n ) ) ;
int prev = 0 ; while ( arr [ Math . Min ( step , n ) - 1 ] < x ) { prev = step ; step += ( int ) Math . Floor ( Math . Sqrt ( n ) ) ; if ( prev >= n ) return - 1 ; }
while ( arr [ prev ] < x ) { prev ++ ;
if ( prev == Math . Min ( step , n ) ) return - 1 ; }
if ( arr [ prev ] == x ) return prev ; return - 1 ; }
public static void Main ( ) { int [ ] arr = { 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 } ; int x = 55 ;
int index = jumpSearch ( arr , x ) ;
Console . Write ( " Number ▁ " + x + " ▁ is ▁ at ▁ index ▁ " + index ) ; } }
static int exponentialSearch ( int [ ] arr , int n , int x ) {
if ( arr [ 0 ] == x ) return 0 ;
int i = 1 ; while ( i < n && arr [ i ] <= x ) i = i * 2 ;
return binarySearch ( arr , i / 2 , Math . Min ( i , n - 1 ) , x ) ; }
static int binarySearch ( int [ ] arr , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 4 , 10 , 40 } ; int n = arr . Length ; int x = 10 ; int result = exponentialSearch ( arr , n , x ) ; if ( result == - 1 ) Console . Write ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) ; else Console . Write ( " Element ▁ is ▁ present ▁ at ▁ index ▁ " + result ) ; } }
static void sort ( int [ ] arr ) { int n = arr . Length ;
for ( int i = 0 ; i < n - 1 ; i ++ ) {
int min_idx = i ; for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ j ] < arr [ min_idx ] ) min_idx = j ;
int temp = arr [ min_idx ] ; arr [ min_idx ] = arr [ i ] ; arr [ i ] = temp ; } }
public static void Main ( ) { int [ ] arr = { 64 , 25 , 12 , 22 , 11 } ; sort ( arr ) ; Console . WriteLine ( " Sorted ▁ array " ) ; printArray ( arr ) ; } }
static void bubbleSort ( int [ ] arr , int n ) { int i , j , temp ; bool swapped ; for ( i = 0 ; i < n - 1 ; i ++ ) { swapped = false ; for ( j = 0 ; j < n - i - 1 ; j ++ ) { if ( arr [ j ] > arr [ j + 1 ] ) {
temp = arr [ j ] ; arr [ j ] = arr [ j + 1 ] ; arr [ j + 1 ] = temp ; swapped = true ; } }
if ( swapped == false ) break ; } }
public static void Main ( ) { int [ ] arr = { 64 , 34 , 25 , 12 , 22 , 11 , 90 } ; int n = arr . Length ; bubbleSort ( arr , n ) ; Console . WriteLine ( " Sorted ▁ array " ) ; printArray ( arr , n ) ; } }
public static void countSort ( int [ ] arr , int n , int exp ) {
int [ ] output = new int [ n ] ; int i ; int [ ] count = new int [ 10 ] ;
for ( i = 0 ; i < n ; i ++ ) count [ ( arr [ i ] / exp ) % 10 ] ++ ;
for ( i = 1 ; i < 10 ; i ++ ) count [ i ] += count [ i - 1 ] ;
for ( i = n - 1 ; i >= 0 ; i -- ) { output [ count [ ( arr [ i ] / exp ) % 10 ] - 1 ] = arr [ i ] ; count [ ( arr [ i ] / exp ) % 10 ] -- ; }
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = output [ i ] ; }
public static void radixsort ( int [ ] arr , int n ) {
int m = getMax ( arr , n ) ;
for ( int exp = 1 ; m / exp > 0 ; exp *= 10 ) countSort ( arr , n , exp ) ; }
public static void print ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 170 , 45 , 75 , 90 , 802 , 24 , 2 , 66 } ; int n = arr . Length ;
radixsort ( arr , n ) ; print ( arr , n ) ; } }
static int partition ( int [ ] arr , int low , int high ) { int temp ; int pivot = arr [ high ] ; int i = ( low - 1 ) ; for ( int j = low ; j <= high - 1 ; j ++ ) { if ( arr [ j ] <= pivot ) { i ++ ; temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } } temp = arr [ i + 1 ] ; arr [ i + 1 ] = arr [ high ] ; arr [ high ] = temp ; return i + 1 ; }
static void qSort ( int [ ] arr , int low , int high ) { if ( low < high ) {
int pi = partition ( arr , low , high ) ; qSort ( arr , low , pi - 1 ) ; qSort ( arr , pi + 1 , high ) ; } }
public static void Main ( ) { int n = 5 ; int [ ] arr = { 4 , 2 , 6 , 9 , 2 } ; qSort ( arr , 0 , n - 1 ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static int partition ( int [ ] arr , int low , int high ) { int temp ; int pivot = arr [ high ] ; int i = ( low - 1 ) ; for ( int j = low ; j <= high - 1 ; j ++ ) { if ( arr [ j ] <= pivot ) { i ++ ; temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } } temp = arr [ i + 1 ] ; arr [ i + 1 ] = arr [ high ] ; arr [ high ] = temp ; return i + 1 ; }
static void quickSortIterative ( int [ ] arr , int l , int h ) {
int [ ] stack = new int [ h - l + 1 ] ;
int top = - 1 ;
stack [ ++ top ] = l ; stack [ ++ top ] = h ;
while ( top >= 0 ) {
h = stack [ top -- ] ; l = stack [ top -- ] ;
int p = partition ( arr , l , h ) ;
if ( p - 1 > l ) { stack [ ++ top ] = l ; stack [ ++ top ] = p - 1 ; }
if ( p + 1 < h ) { stack [ ++ top ] = p + 1 ; stack [ ++ top ] = h ; } } }
public static void Main ( ) { int [ ] arr = { 4 , 3 , 5 , 2 , 1 , 3 , 2 , 3 } ; int n = 8 ;
quickSortIterative ( arr , 0 , n - 1 ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static int findCrossOver ( int [ ] arr , int low , int high , int x ) {
if ( arr [ high ] <= x ) return high ;
if ( arr [ low ] > x ) return low ;
int mid = ( low + high ) / 2 ;
if ( arr [ mid ] <= x && arr [ mid + 1 ] > x ) return mid ;
if ( arr [ mid ] < x ) return findCrossOver ( arr , mid + 1 , high , x ) ; return findCrossOver ( arr , low , mid - 1 , x ) ; }
static void printKclosest ( int [ ] arr , int x , int k , int n ) {
int l = findCrossOver ( arr , 0 , n - 1 , x ) ;
int r = l + 1 ;
int count = 0 ;
if ( arr [ l ] == x ) l -- ;
while ( l >= 0 && r < n && count < k ) { if ( x - arr [ l ] < arr [ r ] - x ) Console . Write ( arr [ l -- ] + " ▁ " ) ; else Console . Write ( arr [ r ++ ] + " ▁ " ) ; count ++ ; }
while ( count < k && l >= 0 ) { Console . Write ( arr [ l -- ] + " ▁ " ) ; count ++ ; }
while ( count < k && r < n ) { Console . Write ( arr [ r ++ ] + " ▁ " ) ; count ++ ; } }
public static void Main ( ) { int [ ] arr = { 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 } ; int n = arr . Length ; int x = 35 ; printKclosest ( arr , x , 4 , n ) ; } }
int binarySearch ( int [ ] arr , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ; if ( mid > l && arr [ mid - 1 ] == x ) return ( mid - 1 ) ; if ( mid < r && arr [ mid + 1 ] == x ) return ( mid + 1 ) ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 2 , x ) ;
return binarySearch ( arr , mid + 2 , r , x ) ; }
return - 1 ; }
public static void Main ( ) { GFG ob = new GFG ( ) ; int [ ] arr = { 3 , 2 , 10 , 4 , 40 } ; int n = arr . Length ; int x = 4 ; int result = ob . binarySearch ( arr , 0 , n - 1 , x ) ; if ( result == - 1 ) Console . Write ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) ; else Console . Write ( " Element ▁ is ▁ present ▁ at ▁ index ▁ " + result ) ; } }
static void printClosest ( int [ ] ar1 , int [ ] ar2 , int m , int n , int x ) {
int diff = int . MaxValue ;
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 ; while ( l < m && r >= 0 ) {
if ( Math . Abs ( ar1 [ l ] + ar2 [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . Abs ( ar1 [ l ] + ar2 [ r ] - x ) ; }
if ( ar1 [ l ] + ar2 [ r ] > x ) r -- ;
else l ++ ; }
Console . Write ( " The ▁ closest ▁ pair ▁ is ▁ [ " + ar1 [ res_l ] + " , ▁ " + ar2 [ res_r ] + " ] " ) ; }
public static void Main ( ) { int [ ] ar1 = { 1 , 4 , 5 , 7 } ; int [ ] ar2 = { 10 , 20 , 30 , 40 } ; int m = ar1 . Length ; int n = ar2 . Length ; int x = 38 ; printClosest ( ar1 , ar2 , m , n , x ) ; } }
static void printClosest ( int [ ] arr , int n , int x ) {
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 , diff = int . MaxValue ;
while ( r > l ) {
if ( Math . Abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . Abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } Console . Write ( " ▁ The ▁ closest ▁ pair ▁ is ▁ " + arr [ res_l ] + " ▁ and ▁ " + arr [ res_r ] ) ; }
public static void Main ( ) { int [ ] arr = { 10 , 22 , 28 , 29 , 30 , 40 } ; int x = 54 ; int n = arr . Length ; printClosest ( arr , n , x ) ; } }
static int countOnes ( int [ ] arr , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = arr . Length ; Console . WriteLine ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ " + " array ▁ is ▁ " + countOnes ( arr , 0 , n - 1 ) ) ; } }
public static void minimumSwaps ( int [ ] a , int n ) { int maxx = - 1 , l = 0 , minn = a [ 0 ] , r = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] > maxx ) { maxx = a [ i ] ; l = i ; }
if ( a [ i ] <= minn ) { minn = a [ i ] ; r = i ; } } if ( r < l ) Console . WriteLine ( l + ( n - r - 2 ) ) ; else Console . WriteLine ( l + ( n - r - 1 ) ) ; }
public static void Main ( ) { int [ ] a = { 5 , 6 , 1 , 3 } ; int n = a . Length ; minimumSwaps ( a , n ) ; } }
static int lcs ( char [ ] X , char [ ] Y , int m , int n ) { if ( m == 0 n == 0 ) return 0 ; if ( X [ m - 1 ] == Y [ n - 1 ] ) return 1 + lcs ( X , Y , m - 1 , n - 1 ) ; else return max ( lcs ( X , Y , m , n - 1 ) , lcs ( X , Y , m - 1 , n ) ) ; }
public static void Main ( ) { String s1 = " AGGTAB " ; String s2 = " GXTXAYB " ; char [ ] X = s1 . ToCharArray ( ) ; char [ ] Y = s2 . ToCharArray ( ) ; int m = X . Length ; int n = Y . Length ; Console . Write ( " Length ▁ of ▁ LCS ▁ is " + " ▁ " + lcs ( X , Y , m , n ) ) ; } }
using System ; class GFG {
static int lcs ( char [ ] X , char [ ] Y , int m , int n ) { int [ , ] L = new int [ m + 1 , n + 1 ] ;
for ( int i = 0 ; i <= m ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) { if ( i == 0 j == 0 ) L [ i , j ] = 0 ; else if ( X [ i - 1 ] == Y [ j - 1 ] ) L [ i , j ] = L [ i - 1 , j - 1 ] + 1 ; else L [ i , j ] = max ( L [ i - 1 , j ] , L [ i , j - 1 ] ) ; } }
return L [ m , n ] ; }
public static void Main ( ) { String s1 = " AGGTAB " ; String s2 = " GXTXAYB " ; char [ ] X = s1 . ToCharArray ( ) ; char [ ] Y = s2 . ToCharArray ( ) ; int m = X . Length ; int n = Y . Length ; Console . Write ( " Length ▁ of ▁ LCS ▁ is " + " ▁ " + lcs ( X , Y , m , n ) ) ; } }
static int count ( int [ ] S , int m , int n ) {
if ( n == 0 ) return 1 ;
if ( n < 0 ) return 0 ;
if ( m <= 0 && n >= 1 ) return 0 ;
return count ( S , m - 1 , n ) + count ( S , m , n - S [ m - 1 ] ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 } ; int m = arr . Length ; Console . Write ( count ( arr , m , 4 ) ) ; } }
using System ; class GFG { static int count ( int [ ] S , int m , int n ) {
int [ ] table = new int [ n + 1 ] ;
table [ 0 ] = 1 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = S [ i ] ; j <= n ; j ++ ) table [ j ] += table [ j - S [ i ] ] ; return table [ n ] ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 } ; int m = arr . Length ; int n = 4 ; Console . Write ( count ( arr , m , n ) ) ; } }
using System ; class GFG { static int binomialCoeff ( int n , int k ) { int [ ] C = new int [ k + 1 ] ;
C [ 0 ] = 1 ; for ( int i = 1 ; i <= n ; i ++ ) {
for ( int j = Math . Min ( i , k ) ; j > 0 ; j -- ) C [ j ] = C [ j ] + C [ j - 1 ] ; } return C [ k ] ; }
public static void Main ( ) { int n = 5 , k = 2 ; Console . WriteLine ( " Value ▁ of ▁ C ( " + n + " ▁ " + k + " ) ▁ is ▁ " + binomialCoeff ( n , k ) ) ; } }
static int eggDrop ( int n , int k ) {
int [ , ] eggFloor = new int [ n + 1 , k + 1 ] ; int res ; int i , j , x ;
for ( i = 1 ; i <= n ; i ++ ) { eggFloor [ i , 1 ] = 1 ; eggFloor [ i , 0 ] = 0 ; }
for ( j = 1 ; j <= k ; j ++ ) eggFloor [ 1 , j ] = j ;
for ( i = 2 ; i <= n ; i ++ ) { for ( j = 2 ; j <= k ; j ++ ) { eggFloor [ i , j ] = int . MaxValue ; for ( x = 1 ; x <= j ; x ++ ) { res = 1 + max ( eggFloor [ i - 1 , x - 1 ] , eggFloor [ i , j - x ] ) ; if ( res < eggFloor [ i , j ] ) eggFloor [ i , j ] = res ; } } }
return eggFloor [ n , k ] ; }
public static void Main ( ) { int n = 2 , k = 36 ; Console . WriteLine ( " Minimum ▁ number ▁ of ▁ trials ▁ " + " in ▁ worst ▁ case ▁ with ▁ " + n + " ▁ eggs ▁ and ▁ " + k + " floors ▁ is ▁ " + eggDrop ( n , k ) ) ; } }
static int max ( int x , int y ) { return ( x > y ) ? x : y ; }
static int lps ( string seq ) { int n = seq . Length ; int i , j , cl ;
int [ , ] L = new int [ n , n ] ;
for ( i = 0 ; i < n ; i ++ ) L [ i , i ] = 1 ;
for ( cl = 2 ; cl <= n ; cl ++ ) { for ( i = 0 ; i < n - cl + 1 ; i ++ ) { j = i + cl - 1 ; if ( seq [ i ] == seq [ j ] && cl == 2 ) L [ i , j ] = 2 ; else if ( seq [ i ] == seq [ j ] ) L [ i , j ] = L [ i + 1 , j - 1 ] + 2 ; else L [ i , j ] = max ( L [ i , j - 1 ] , L [ i + 1 , j ] ) ; } } return L [ 0 , n - 1 ] ; }
public static void Main ( ) { string seq = " GEEKS ▁ FOR ▁ GEEKS " ; int n = seq . Length ; Console . Write ( " The ▁ length ▁ of ▁ the ▁ " + " lps ▁ is ▁ " + lps ( seq ) ) ; } }
static int cutRod ( int [ ] price , int n ) { if ( n <= 0 ) return 0 ; int max_val = int . MinValue ;
for ( int i = 0 ; i < n ; i ++ ) max_val = Math . Max ( max_val , price [ i ] + cutRod ( price , n - i - 1 ) ) ; return max_val ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = arr . Length ; Console . WriteLine ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " + cutRod ( arr , size ) ) ; } }
static int cutRod ( int [ ] price , int n ) { int [ ] val = new int [ n + 1 ] ; val [ 0 ] = 0 ;
for ( int i = 1 ; i <= n ; i ++ ) { int max_val = int . MinValue ; for ( int j = 0 ; j < i ; j ++ ) max_val = Math . Max ( max_val , price [ j ] + val [ i - j - 1 ] ) ; val [ i ] = max_val ; } return val [ n ] ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = arr . Length ; Console . WriteLine ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " + cutRod ( arr , size ) ) ; } }
static int lbs ( int [ ] arr , int n ) { int i , j ;
int [ ] lis = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
int [ ] lds = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lds [ i ] = 1 ;
for ( i = n - 2 ; i >= 0 ; i -- ) for ( j = n - 1 ; j > i ; j -- ) if ( arr [ i ] > arr [ j ] && lds [ i ] < lds [ j ] + 1 ) lds [ i ] = lds [ j ] + 1 ;
int max = lis [ 0 ] + lds [ 0 ] - 1 ; for ( i = 1 ; i < n ; i ++ ) if ( lis [ i ] + lds [ i ] - 1 > max ) max = lis [ i ] + lds [ i ] - 1 ; return max ; }
public static void Main ( ) { int [ ] arr = { 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 } ; int n = arr . Length ; Console . WriteLine ( " Length ▁ of ▁ LBS ▁ is ▁ " + lbs ( arr , n ) ) ; } }
static int maxDivide ( int a , int b ) { while ( a % b == 0 ) a = a / b ; return a ; }
static int isUgly ( int no ) { no = maxDivide ( no , 2 ) ; no = maxDivide ( no , 3 ) ; no = maxDivide ( no , 5 ) ; return ( no == 1 ) ? 1 : 0 ; }
static int getNthUglyNo ( int n ) { int i = 1 ;
int count = 1 ;
while ( n > count ) { i ++ ; if ( isUgly ( i ) == 1 ) count ++ ; } return i ; }
public static void Main ( ) { int no = getNthUglyNo ( 150 ) ; Console . WriteLine ( "150th ▁ ugly " + " ▁ no . ▁ is ▁ " + no ) ; } }
static bool isSubsetSum ( int [ ] set , int n , int sum ) {
if ( sum == 0 ) return true ; if ( n == 0 ) return false ;
if ( set [ n - 1 ] > sum ) return isSubsetSum ( set , n - 1 , sum ) ;
return isSubsetSum ( set , n - 1 , sum ) || isSubsetSum ( set , n - 1 , sum - set [ n - 1 ] ) ; }
public static void Main ( ) { int [ ] set = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = set . Length ; if ( isSubsetSum ( set , n , sum ) == true ) Console . WriteLine ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) ; else Console . WriteLine ( " No ▁ subset ▁ with ▁ given ▁ sum " ) ; } }
static bool isSubsetSum ( int [ ] set , int n , int sum ) {
bool [ , ] subset = new bool [ sum + 1 , n + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) subset [ 0 , i ] = true ;
for ( int i = 1 ; i <= sum ; i ++ ) subset [ i , 0 ] = false ;
for ( int i = 1 ; i <= sum ; i ++ ) { for ( int j = 1 ; j <= n ; j ++ ) { subset [ i , j ] = subset [ i , j - 1 ] ; if ( i >= set [ j - 1 ] ) subset [ i , j ] = subset [ i , j ] || subset [ i - set [ j - 1 ] , j - 1 ] ; } } return subset [ sum , n ] ; }
public static void Main ( ) { int [ ] set = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = set . Length ; if ( isSubsetSum ( set , n , sum ) == true ) Console . WriteLine ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) ; else Console . WriteLine ( " No ▁ subset ▁ with ▁ given ▁ sum " ) ; } }
static int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ? 1 : 0 ; if ( sum == 0 ) return 1 ;
int ans = 0 ;
for ( int i = 0 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
static int finalCount ( int n , int sum ) {
int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
public static void Main ( ) { int n = 2 , sum = 5 ; Console . Write ( finalCount ( n , sum ) ) ; } }
static int [ , ] lookup = new int [ 101 , 501 ] ;
static int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ? 1 : 0 ;
if ( lookup [ n , sum ] != - 1 ) return lookup [ n , sum ] ;
int ans = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return lookup [ n , sum ] = ans ; }
static int finalCount ( int n , int sum ) {
int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
public static void Main ( ) { int n = 3 , sum = 5 ; Console . Write ( finalCount ( n , sum ) ) ; } }
using System ; class GFG { private static void findCount ( int n , int sum ) {
int start = ( int ) Math . Pow ( 10 , n - 1 ) ; int end = ( int ) Math . Pow ( 10 , n ) - 1 ; int count = 0 ; int i = start ; while ( i < end ) { int cur = 0 ; int temp = i ; while ( temp != 0 ) { cur += temp % 10 ; temp = temp / 10 ; } if ( cur == sum ) { count ++ ; i += 9 ; } else i ++ ; } Console . WriteLine ( count ) ; }
public static void Main ( ) { int n = 3 ; int sum = 5 ; findCount ( n , sum ) ; } }
using System ; class GFG { static int countNonDecreasing ( int n ) {
int [ , ] dp = new int [ 10 , n + 1 ] ;
for ( int i = 0 ; i < 10 ; i ++ ) dp [ i , 1 ] = 1 ;
for ( int digit = 0 ; digit <= 9 ; digit ++ ) {
for ( int len = 2 ; len <= n ; len ++ ) {
for ( int x = 0 ; x <= digit ; x ++ ) dp [ digit , len ] += dp [ x , len - 1 ] ; } } int count = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) count += dp [ i , n ] ; return count ; }
public static void Main ( ) { int n = 3 ; Console . WriteLine ( countNonDecreasing ( n ) ) ; } }
using System ; class GFG { static long countNonDecreasing ( int n ) { int N = 10 ;
long count = 1 ; for ( int i = 1 ; i <= n ; i ++ ) { count *= ( N + i - 1 ) ; count /= i ; } return count ; }
public static void Main ( ) { int n = 3 ; Console . WriteLine ( countNonDecreasing ( n ) ) ; } }
static int getMinSquares ( int n ) {
if ( n <= 3 ) return n ;
int res = n ;
for ( int x = 1 ; x <= n ; x ++ ) { int temp = x * x ; if ( temp > n ) break ; else res = Math . Min ( res , 1 + getMinSquares ( n - temp ) ) ; } return res ; }
public static void Main ( ) { Console . Write ( getMinSquares ( 6 ) ) ; } }
static int getMinSquares ( int n ) {
int [ ] dp = new int [ n + 1 ] ;
dp [ 0 ] = 0 ; dp [ 1 ] = 1 ; dp [ 2 ] = 2 ; dp [ 3 ] = 3 ;
for ( int i = 4 ; i <= n ; i ++ ) {
dp [ i ] = i ;
for ( int x = 1 ; x <= Math . Ceiling ( Math . Sqrt ( i ) ) ; x ++ ) { int temp = x * x ; if ( temp > i ) break ; else dp [ i ] = Math . Min ( dp [ i ] , 1 + dp [ i - temp ] ) ; } }
int res = dp [ n ] ; return res ; }
public static void Main ( String [ ] args ) { Console . Write ( getMinSquares ( 6 ) ) ; } }
static int minCoins ( int [ ] coins , int m , int V ) {
if ( V == 0 ) return 0 ;
int res = int . MaxValue ;
for ( int i = 0 ; i < m ; i ++ ) { if ( coins [ i ] <= V ) { int sub_res = minCoins ( coins , m , V - coins [ i ] ) ;
if ( sub_res != int . MaxValue && sub_res + 1 < res ) res = sub_res + 1 ; } } return res ; }
public static void Main ( ) { int [ ] coins = { 9 , 6 , 5 , 1 } ; int m = coins . Length ; int V = 11 ; Console . Write ( " Minimum ▁ coins ▁ required ▁ is ▁ " + minCoins ( coins , m , V ) ) ; } }
static int minCoins ( int [ ] coins , int m , int V ) {
int [ ] table = new int [ V + 1 ] ;
table [ 0 ] = 0 ;
for ( int i = 1 ; i <= V ; i ++ ) table [ i ] = int . MaxValue ;
for ( int i = 1 ; i <= V ; i ++ ) {
for ( int j = 0 ; j < m ; j ++ ) if ( coins [ j ] <= i ) { int sub_res = table [ i - coins [ j ] ] ; if ( sub_res != int . MaxValue && sub_res + 1 < table [ i ] ) table [ i ] = sub_res + 1 ; } } return table [ V ] ; }
static public void Main ( ) { int [ ] coins = { 9 , 6 , 5 , 1 } ; int m = coins . Length ; int V = 11 ; Console . WriteLine ( " Minimum ▁ coins ▁ required ▁ is ▁ " + minCoins ( coins , m , V ) ) ; } }
using System ; class GFG { static int superSeq ( String X , String Y , int m , int n ) { if ( m == 0 ) return n ; if ( n == 0 ) return m ; if ( X [ m - 1 ] == Y [ n - 1 ] ) return 1 + superSeq ( X , Y , m - 1 , n - 1 ) ; return 1 + Math . Min ( superSeq ( X , Y , m - 1 , n ) , superSeq ( X , Y , m , n - 1 ) ) ; }
public static void Main ( ) { String X = " AGGTAB " ; String Y = " GXTXAYB " ; Console . WriteLine ( " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is : ▁ " + superSeq ( X , Y , X . Length , Y . Length ) ) ; } }
static int superSeq ( String X , String Y , int m , int n ) { int [ , ] dp = new int [ m + 1 , n + 1 ] ;
for ( int i = 0 ; i <= m ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) {
if ( i == 0 ) dp [ i , j ] = j ; else if ( j == 0 ) dp [ i , j ] = i ; else if ( X [ i - 1 ] == Y [ j - 1 ] ) dp [ i , j ] = 1 + dp [ i - 1 , j - 1 ] ; else dp [ i , j ] = 1 + Math . Min ( dp [ i - 1 , j ] , dp [ i , j - 1 ] ) ; } } return dp [ m , n ] ; }
public static void Main ( ) { String X = " AGGTAB " ; String Y = " GXTXAYB " ; Console . WriteLine ( " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ " + superSeq ( X , Y , X . Length , Y . Length ) ) ; } }
static int sumOfDigitsFrom1ToN ( int n ) {
int result = 0 ;
for ( int x = 1 ; x <= n ; x ++ ) result += sumOfDigits ( x ) ; return result ; }
static int sumOfDigits ( int x ) { int sum = 0 ; while ( x != 0 ) { sum += x % 10 ; x = x / 10 ; } return sum ; }
public static void Main ( ) { int n = 328 ; Console . WriteLine ( " Sum ▁ of ▁ digits " + " ▁ in ▁ numbers ▁ from ▁ 1 ▁ to ▁ " + n + " ▁ is ▁ " + sumOfDigitsFrom1ToN ( n ) ) ; } }
static int sumOfDigitsFrom1ToN ( int n ) {
if ( n < 10 ) return ( n * ( n + 1 ) / 2 ) ;
int d = ( int ) ( Math . Log ( n ) / Math . Log ( 10 ) ) ;
int [ ] a = new int [ d + 1 ] ; a [ 0 ] = 0 ; a [ 1 ] = 45 ; for ( int i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * ( int ) ( Math . Ceiling ( Math . Pow ( 10 , i - 1 ) ) ) ;
int p = ( int ) ( Math . Ceiling ( Math . Pow ( 10 , d ) ) ) ;
int msd = n / p ;
return ( msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToN ( n % p ) ) ; }
public static void Main ( ) { int n = 328 ; Console . WriteLine ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ " + " from ▁ 1 ▁ to ▁ " + n + " ▁ is ▁ " + sumOfDigitsFrom1ToN ( n ) ) ; } }
static int countWays ( int N ) {
if ( N == 1 )
return 4 ;
int countB = 1 , countS = 1 , prev_countB , prev_countS ;
for ( int i = 2 ; i <= N ; i ++ ) { prev_countB = countB ; prev_countS = countS ; countS = prev_countB + prev_countS ; countB = prev_countS ; }
int result = countS + countB ;
return ( result * result ) ; }
public static void Main ( ) { int N = 3 ; Console . Write ( countWays ( N ) ) ; } }
static void printPatternUtil ( string str , char [ ] buf , int i , int j , int n ) { if ( i == n ) { buf [ j ] = ' \0' ; Console . WriteLine ( buf ) ; return ; }
buf [ j ] = str [ i ] ; printPatternUtil ( str , buf , i + 1 , j + 1 , n ) ;
buf [ j ] = ' ▁ ' ; buf [ j + 1 ] = str [ i ] ; printPatternUtil ( str , buf , i + 1 , j + 2 , n ) ; }
static void printPattern ( string str ) { int len = str . Length ;
char [ ] buf = new char [ 2 * len ] ;
buf [ 0 ] = str [ 0 ] ; printPatternUtil ( str , buf , 1 , 1 , len ) ; }
public static void Main ( ) { string str = " ABCD " ; printPattern ( str ) ; } }
static double area ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 ) { return Math . Abs ( ( x1 * ( y2 - y3 ) + x2 * ( y3 - y1 ) + x3 * ( y1 - y2 ) ) / 2.0 ) ; }
static bool isInside ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 , int x , int y ) {
double A = area ( x1 , y1 , x2 , y2 , x3 , y3 ) ;
double A1 = area ( x , y , x2 , y2 , x3 , y3 ) ;
double A2 = area ( x1 , y1 , x , y , x3 , y3 ) ;
double A3 = area ( x1 , y1 , x2 , y2 , x , y ) ;
return ( A == A1 + A2 + A3 ) ; }
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) Console . WriteLine ( " Inside " ) ; else Console . WriteLine ( " Not ▁ Inside " ) ; } }
static float getAvg ( float prev_avg , float x , int n ) { return ( prev_avg * n + x ) / ( n + 1 ) ; }
static void streamAvg ( float [ ] arr , int n ) { float avg = 0 ; for ( int i = 0 ; i < n ; i ++ ) { avg = getAvg ( avg , arr [ i ] , i ) ; Console . WriteLine ( " Average ▁ of ▁ { 0 } ▁ " + " numbers ▁ is ▁ { 1 } " , i + 1 , avg ) ; } return ; }
public static void Main ( String [ ] args ) { float [ ] arr = { 10 , 20 , 30 , 40 , 50 , 60 } ; int n = arr . Length ; streamAvg ( arr , n ) ; } }
using System ; namespace prime { public class GFG { public static void SieveOfEratosthenes ( int n ) {
bool [ ] prime = new bool [ n + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) prime [ i ] = true ; for ( int p = 2 ; p * p <= n ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * p ; i <= n ; i += p ) prime [ i ] = false ; } }
for ( int i = 2 ; i <= n ; i ++ ) { if ( prime [ i ] == true ) Console . Write ( i + " ▁ " ) ; } }
public static void Main ( ) { int n = 30 ; Console . WriteLine ( " Following ▁ are ▁ the ▁ prime ▁ numbers " ) ; Console . WriteLine ( " smaller ▁ than ▁ or ▁ equal ▁ to ▁ " + n ) ; SieveOfEratosthenes ( n ) ; } } }
static int maximumNumberDistinctPrimeRange ( int m , int n ) {
long [ ] factorCount = new long [ n + 1 ] ;
bool [ ] prime = new bool [ n + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) { factorCount [ i ] = 0 ;
prime [ i ] = true ; } for ( int i = 2 ; i <= n ; i ++ ) {
if ( prime [ i ] == true ) {
factorCount [ i ] = 1 ;
for ( int j = i * 2 ; j <= n ; j += i ) {
factorCount [ j ] ++ ;
prime [ j ] = false ; } } }
int max = ( int ) factorCount [ m ] ; int num = m ;
for ( int i = m ; i <= n ; i ++ ) {
if ( factorCount [ i ] > max ) { max = ( int ) factorCount [ i ] ; num = i ; } } return num ; }
public static void Main ( ) { int m = 4 , n = 6 ;
Console . WriteLine ( maximumNumberDistinctPrimeRange ( m , n ) ) ; } }
using System ; class GFG { static int MAX_CHAR = 256 ;
int [ ] count = new int [ MAX_CHAR ] ;
static int fact ( int n ) { return ( n <= 1 ) ? 1 : n * fact ( n - 1 ) ; }
static void populateAndIncreaseCount ( int [ ] count , char [ ] str ) { int i ; for ( i = 0 ; i < str . Length ; ++ i ) ++ count [ str [ i ] ] ; for ( i = 1 ; i < MAX_CHAR ; ++ i ) count [ i ] += count [ i - 1 ] ; }
static void updatecount ( int [ ] count , char ch ) { int i ; for ( i = ch ; i < MAX_CHAR ; ++ i ) -- count [ i ] ; }
static int findRank ( char [ ] str ) { int len = str . Length ; int mul = fact ( len ) ; int rank = 1 , i ;
populateAndIncreaseCount ( count , str ) ; for ( i = 0 ; i < len ; ++ i ) { mul /= len - i ;
rank += count [ str [ i ] - 1 ] * mul ;
updatecount ( count , str [ i ] ) ; } return rank ; }
public static void Main ( String [ ] args ) { char [ ] str = " string " . ToCharArray ( ) ; Console . WriteLine ( findRank ( str ) ) ; } }
static int binomialCoeff ( int n , int k ) { int res = 1 ; if ( k > n - k ) k = n - k ; for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
static void printPascal ( int n ) {
for ( int line = 0 ; line < n ; line ++ ) {
for ( int i = 0 ; i <= line ; i ++ ) Console . Write ( binomialCoeff ( line , i ) + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int n = 7 ; printPascal ( n ) ; } }
static bool isPerfectSquare ( int x ) { int s = ( int ) Math . Sqrt ( x ) ; return ( s * s == x ) ; }
static bool isFibonacci ( int n ) {
return isPerfectSquare ( 5 * n * n + 4 ) || isPerfectSquare ( 5 * n * n - 4 ) ; }
public static void Main ( ) { for ( int i = 1 ; i <= 10 ; i ++ ) Console . WriteLine ( isFibonacci ( i ) ? i + " ▁ is ▁ a ▁ Fibonacci ▁ Number " : i + " ▁ is ▁ a ▁ not ▁ Fibonacci ▁ Number " ) ; } }
static int findTrailingZeros ( int n ) {
int count = 0 ;
for ( int i = 5 ; n / i >= 1 ; i *= 5 ) count += n / i ; return count ; }
public static void Main ( ) { int n = 100 ; Console . WriteLine ( " Count ▁ of ▁ trailing ▁ 0s ▁ in ▁ " + n + " ! ▁ is ▁ " + findTrailingZeros ( n ) ) ; } }
static int catalan ( int n ) {
if ( n <= 1 ) { return 1 ; }
int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) { res += catalan ( i ) * catalan ( n - i - 1 ) ; } return res ; }
public static void Main ( ) { for ( int i = 0 ; i < 10 ; i ++ ) Console . Write ( catalan ( i ) + " ▁ " ) ; } }
using System ; class GFG { static uint catalanDP ( uint n ) {
uint [ ] catalan = new uint [ n + 2 ] ;
catalan [ 0 ] = catalan [ 1 ] = 1 ;
for ( uint i = 2 ; i <= n ; i ++ ) { catalan [ i ] = 0 ; for ( uint j = 0 ; j < i ; j ++ ) catalan [ i ] += catalan [ j ] * catalan [ i - j - 1 ] ; }
return catalan [ n ] ; }
static void Main ( ) { for ( uint i = 0 ; i < 10 ; i ++ ) Console . Write ( catalanDP ( i ) + " ▁ " ) ; } }
static long binomialCoeff ( int n , int k ) { long res = 1 ;
if ( k > n - k ) { k = n - k ; }
for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
static long catalan ( int n ) {
long c = binomialCoeff ( 2 * n , n ) ;
return c / ( n + 1 ) ; }
public static void Main ( ) { for ( int i = 0 ; i < 10 ; i ++ ) { Console . Write ( catalan ( i ) + " ▁ " ) ; } } }
static int getInvCount ( int [ , ] arr ) { int inv_count = 0 ; for ( int i = 0 ; i < 3 - 1 ; i ++ ) for ( int j = i + 1 ; j < 3 ; j ++ )
if ( arr [ j , i ] > 0 && arr [ j , i ] > arr [ i , j ] ) inv_count ++ ; return inv_count ; }
static bool isSolvable ( int [ , ] puzzle ) {
int invCount = getInvCount ( puzzle ) ;
return ( invCount % 2 == 0 ) ; }
static void Main ( ) { int [ , ] puzzle = new int [ 3 , 3 ] { { 1 , 8 , 2 } , { 0 , 4 , 3 } , { 7 , 6 , 5 } } ; if ( isSolvable ( puzzle ) ) Console . WriteLine ( " Solvable " ) ; else Console . WriteLine ( " Not ▁ Solvable " ) ; } }
static double find ( double p ) { return Math . Ceiling ( Math . Sqrt ( 2 * 365 * Math . Log ( 1 / ( 1 - p ) ) ) ) ; }
public static void Main ( ) { Console . Write ( find ( 0.70 ) ) ; } }
static int countSolutions ( int n ) { int res = 0 ; for ( int x = 0 ; x * x < n ; x ++ ) for ( int y = 0 ; x * x + y * y < n ; y ++ ) res ++ ; return res ; }
public static void Main ( ) { Console . WriteLine ( " Total ▁ Number ▁ of ▁ " + " distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " + countSolutions ( 6 ) ) ; } }
static int countSolutions ( int n ) { int x = 0 , yCount , res = 0 ;
for ( yCount = 0 ; yCount * yCount < n ; yCount ++ ) ;
while ( yCount != 0 ) {
res += yCount ;
x ++ ;
while ( yCount != 0 && ( x * x + ( yCount - 1 ) * ( yCount - 1 ) >= n ) ) yCount -- ; } return res ; }
public static void Main ( ) { Console . WriteLine ( " Total ▁ Number ▁ of ▁ " + " distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " + countSolutions ( 6 ) ) ; } }
using System ; class GFG { static double EPSILON = 0.001 ;
static double func ( double x ) { return x * x * x - x * x + 2 ; }
static double derivFunc ( double x ) { return 3 * x * x - 2 * x ; }
static void newtonRaphson ( double x ) { double h = func ( x ) / derivFunc ( x ) ; while ( Math . Abs ( h ) >= EPSILON ) { h = func ( x ) / derivFunc ( x ) ;
x = x - h ; } Console . Write ( " The ▁ value ▁ of ▁ the " + " ▁ root ▁ is ▁ : ▁ " + Math . Round ( x * 100.0 ) / 100.0 ) ; }
double x0 = - 20 ; newtonRaphson ( x0 ) ; } }
static bool oppositeSigns ( int x , int y ) { return ( ( x ^ y ) < 0 ) ; }
public static void Main ( ) { int x = 100 , y = - 100 ; if ( oppositeSigns ( x , y ) == true ) Console . Write ( " Signs ▁ are ▁ opposite " ) ; else Console . Write ( " Signs ▁ are ▁ not ▁ opposite " ) ; } }
static void update ( int [ ] arr , int l , int r , int val ) { arr [ l ] += val ; if ( r + 1 < arr . Length ) arr [ r + 1 ] -= val ; }
static int getElement ( int [ ] arr , int i ) {
int res = 0 ; for ( int j = 0 ; j <= i ; j ++ ) res += arr [ j ] ; return res ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 0 , 0 , 0 , 0 , 0 } ; int n = arr . Length ; int l = 2 , r = 4 , val = 2 ; update ( arr , l , r , val ) ;
int index = 4 ; Console . WriteLine ( " Element ▁ at ▁ index ▁ " + index + " ▁ is ▁ " + getElement ( arr , index ) ) ; l = 0 ; r = 3 ; val = 4 ; update ( arr , l , r , val ) ;
index = 3 ; Console . WriteLine ( " Element ▁ at ▁ index ▁ " + index + " ▁ is ▁ " + getElement ( arr , index ) ) ; } }
static int countSetBits ( int n ) {
int bitCount = 0 ; for ( int i = 1 ; i <= n ; i ++ ) bitCount += countSetBitsUtil ( i ) ; return bitCount ; }
static int countSetBitsUtil ( int x ) { if ( x <= 0 ) return 0 ; return ( x % 2 == 0 ? 0 : 1 ) + countSetBitsUtil ( x / 2 ) ; }
public static void Main ( ) { int n = 4 ; Console . Write ( " Total ▁ set ▁ bit ▁ count ▁ is ▁ " ) ; Console . Write ( countSetBits ( n ) ) ; } }
using System ; class GFG { static int countSetBits ( int n ) { int i = 0 ;
int ans = 0 ;
while ( ( 1 << i ) <= n ) {
bool k = false ;
int change = 1 << i ;
for ( int j = 0 ; j <= n ; j ++ ) { if ( k == true ) ans += 1 ; else ans += 0 ; if ( change == 1 ) {
k = ! k ;
change = 1 << i ; } else { change -- ; } }
i ++ ; } return ans ; }
static void Main ( ) { int n = 17 ; Console . Write ( countSetBits ( n ) ) ; } }
static int snoob ( int x ) { int rightOne , nextHigherOneBit , rightOnesPattern , next = 0 ; if ( x > 0 ) {
rightOne = x & - x ;
nextHigherOneBit = x + rightOne ;
rightOnesPattern = x ^ nextHigherOneBit ;
rightOnesPattern = ( rightOnesPattern ) / rightOne ;
rightOnesPattern >>= 2 ;
next = nextHigherOneBit | rightOnesPattern ; } return next ; }
static void Main ( ) { int x = 156 ; Console . WriteLine ( " Next ▁ higher ▁ number ▁ with ▁ same " + " number ▁ of ▁ set ▁ bits ▁ is ▁ " + snoob ( x ) ) ; } }
using System ; class GFG { static int multiplyWith3Point5 ( int x ) { return ( x << 1 ) + x + ( x >> 1 ) ; }
public static void Main ( ) { int x = 2 ; Console . Write ( multiplyWith3Point5 ( x ) ) ; } }
static uint getModulo ( uint n , uint d ) { return ( n & ( d - 1 ) ) ; }
static public void Main ( ) { uint n = 6 ;
uint d = 4 ; Console . WriteLine ( n + " ▁ moduo ▁ " + d + " ▁ is ▁ " + getModulo ( n , d ) ) ; } }
static int getOddOccurrence ( int [ ] arr , int arr_size ) { for ( int i = 0 ; i < arr_size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < arr_size ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; } if ( count % 2 != 0 ) return arr [ i ] ; } return - 1 ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 } ; int n = arr . Length ;
Console . Write ( getOddOccurrence ( arr , n ) ) ; } }
static int fastPow ( int N , int K ) { if ( K == 0 ) return 1 ; int temp = fastPow ( N , K / 2 ) ; if ( K % 2 == 0 ) return temp * temp ; else return N * temp * temp ; } static int countWays ( int N , int K ) { return K * fastPow ( K - 1 , N - 1 ) ; }
public static void Main ( ) { int N = 3 , K = 3 ; Console . WriteLine ( countWays ( N , K ) ) ; } }
public static int countSetBits ( int n ) {
if ( n == 0 ) return 0 ; else return 1 + countSetBits ( n & ( n - 1 ) ) ; }
int n = 9 ;
Console . WriteLine ( countSetBits ( n ) ) ; } }
public static void Main ( ) { Console . WriteLine ( Convert . ToString ( 4 , 2 ) . Count ( c = > c == '1' ) ) ; Console . WriteLine ( Convert . ToString ( 15 , 2 ) . Count ( c = > c == '1' ) ) ; } }
public static int countSetBits ( int n ) { int count = 0 ; while ( n != 0 ) { count ++ ; n &= ( n - 1 ) ; } return count ; }
public static int FlippedCount ( int a , int b ) {
return countSetBits ( a ^ b ) ; }
public static void Main ( ) { int a = 10 ; int b = 20 ; Console . WriteLine ( FlippedCount ( a , b ) ) ; } }
static int PositionRightmostSetbit ( int n ) {
int position = 1 ; int m = 1 ; while ( ( n & m ) == 0 ) {
m = m << 1 ; position ++ ; } return position ; }
static public void Main ( ) { int n = 16 ;
Console . WriteLine ( PositionRightmostSetbit ( n ) ) ; } }
using System ; class GFG { static int INT_SIZE = 32 ; static int Right_most_setbit ( int num ) { int pos = 1 ;
for ( int i = 0 ; i < INT_SIZE ; i ++ ) { if ( ( num & ( 1 << i ) ) == 0 ) pos ++ ; else break ; } return pos ; }
static public void Main ( ) { int num = 18 ; int pos = Right_most_setbit ( num ) ; Console . WriteLine ( pos ) ; } }
static void bin ( int n ) { if ( n > 1 ) bin ( n >> 1 ) ; Console . Write ( n & 1 ) ; }
public static void Main ( ) { bin ( 131 ) ; Console . WriteLine ( ) ; bin ( 3 ) ; } }
static int maxOnesIndex ( int [ ] arr , int n ) {
int max_count = 0 ;
int max_index = 0 ;
int prev_zero = - 1 ;
int prev_prev_zero = - 1 ;
for ( int curr = 0 ; curr < n ; ++ curr ) {
if ( arr [ curr ] == 0 ) {
if ( curr - prev_prev_zero > max_count ) { max_count = curr - prev_prev_zero ; max_index = prev_zero ; }
prev_prev_zero = prev_zero ; prev_zero = curr ; } }
if ( n - prev_prev_zero > max_count ) max_index = prev_zero ; return max_index ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } ; int n = arr . Length ; Console . Write ( " Index ▁ of ▁ 0 ▁ to ▁ be ▁ replaced ▁ is ▁ " + maxOnesIndex ( arr , n ) ) ; } }
static int findLength ( int [ ] arr , int n ) {
int max_len = 1 ; for ( int i = 0 ; i < n - 1 ; i ++ ) {
int mn = arr [ i ] , mx = arr [ i ] ;
for ( int j = i + 1 ; j < n ; j ++ ) {
mn = Math . Min ( mn , arr [ j ] ) ; mx = Math . Max ( mx , arr [ j ] ) ;
if ( ( mx - mn ) == j - i ) max_len = Math . Max ( max_len , mx - mn + 1 ) ; } }
return max_len ; }
public static void Main ( ) { int [ ] arr = { 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 } ; int n = arr . Length ; Console . WriteLine ( " Length ▁ of ▁ the ▁ longest " + " ▁ contiguous ▁ subarray ▁ is ▁ " + findLength ( arr , n ) ) ; } }
static void printArr ( int [ ] arr , int k ) { for ( int i = 0 ; i < k ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
static void printSeqUtil ( int n , int k , int len , int [ ] arr ) {
if ( len == k ) { printArr ( arr , k ) ; return ; }
int i = ( len == 0 ) ? 1 : arr [ len - 1 ] + 1 ;
len ++ ;
while ( i <= n ) { arr [ len - 1 ] = i ; printSeqUtil ( n , k , len , arr ) ; i ++ ; }
len -- ; }
static void printSeq ( int n , int k ) {
int [ ] arr = new int [ k ] ;
int len = 0 ; printSeqUtil ( n , k , len , arr ) ; }
static public void Main ( ) { int k = 3 , n = 7 ; printSeq ( n , k ) ; } }
static bool isSubSequence ( string str1 , string str2 , int m , int n ) {
if ( m == 0 ) return true ; if ( n == 0 ) return false ;
if ( str1 [ m - 1 ] == str2 [ n - 1 ] ) return isSubSequence ( str1 , str2 , m - 1 , n - 1 ) ;
return isSubSequence ( str1 , str2 , m , n - 1 ) ; }
public static void Main ( ) { string str1 = " gksrek " ; string str2 = " geeksforgeeks " ; int m = str1 . Length ; int n = str2 . Length ; bool res = isSubSequence ( str1 , str2 , m , n ) ; if ( res ) Console . Write ( " Yes " ) ; else Console . Write ( " No " ) ; } }
static void segregate0and1 ( int [ ] arr , int n ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 0 ) count ++ ; }
for ( int i = 0 ; i < count ; i ++ ) arr [ i ] = 0 ;
for ( int i = count ; i < n ; i ++ ) arr [ i ] = 1 ; }
static void print ( int [ ] arr , int n ) { Console . WriteLine ( " Array ▁ after ▁ segregation ▁ is ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 0 , 1 , 0 , 1 , 1 , 1 } ; int n = arr . Length ; segregate0and1 ( arr , n ) ; print ( arr , n ) ; } }
static void segregate0and1 ( int [ ] arr ) { int type0 = 0 ; int type1 = arr . Length - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type1 ] = arr [ type1 ] + arr [ type0 ] ; arr [ type0 ] = arr [ type1 ] - arr [ type0 ] ; arr [ type1 ] = arr [ type1 ] - arr [ type0 ] ; type1 -- ; } else { type0 ++ ; } } }
public static void Main ( string [ ] args ) { int [ ] array = new int [ ] { 0 , 1 , 0 , 1 , 1 , 1 } ; segregate0and1 ( array ) ; Console . Write ( " Array ▁ after ▁ segregation ▁ is ▁ " ) ; foreach ( int a in array ) { Console . Write ( a + " ▁ " ) ; } } }
static int GetCeilIndex ( int [ ] arr , int [ ] T , int l , int r , int key ) { while ( r - l > 1 ) { int m = l + ( r - l ) / 2 ; if ( arr [ T [ m ] ] >= key ) r = m ; else l = m ; } return r ; } static int LongestIncreasingSubsequence ( int [ ] arr , int n ) {
int [ ] tailIndices = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) tailIndices [ i ] = 0 ; int [ ] prevIndices = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) prevIndices [ i ] = - 1 ;
int len = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ tailIndices [ 0 ] ] )
tailIndices [ 0 ] = i ; else if ( arr [ i ] > arr [ tailIndices [ len - 1 ] ] ) {
prevIndices [ i ] = tailIndices [ len - 1 ] ; tailIndices [ len ++ ] = i ; } else {
int pos = GetCeilIndex ( arr , tailIndices , - 1 , len - 1 , arr [ i ] ) ; prevIndices [ i ] = tailIndices [ pos - 1 ] ; tailIndices [ pos ] = i ; } } Console . Write ( " LIS ▁ of ▁ given ▁ input " ) ; for ( int i = tailIndices [ len - 1 ] ; i >= 0 ; i = prevIndices [ i ] ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; return len ; }
public static void Main ( ) { int [ ] arr = { 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 } ; int n = arr . Length ; Console . Write ( " LIS ▁ size STRNEWLINE " + LongestIncreasingSubsequence ( arr , n ) ) ; } }
public virtual void generateUtil ( int [ ] A , int [ ] B , int [ ] C , int i , int j , int m , int n , int len , bool flag ) {
if ( flag ) {
if ( len != 0 ) { printArr ( C , len + 1 ) ; }
for ( int k = i ; k < m ; k ++ ) { if ( len == 0 ) {
C [ len ] = A [ k ] ;
generateUtil ( A , B , C , k + 1 , j , m , n , len , ! flag ) ; }
else if ( A [ k ] > C [ len ] ) { C [ len + 1 ] = A [ k ] ; generateUtil ( A , B , C , k + 1 , j , m , n , len + 1 , ! flag ) ; } } }
else { for ( int l = j ; l < n ; l ++ ) { if ( B [ l ] > C [ len ] ) { C [ len + 1 ] = B [ l ] ; generateUtil ( A , B , C , i , l + 1 , m , n , len + 1 , ! flag ) ; } } } }
public virtual void generate ( int [ ] A , int [ ] B , int m , int n ) { int [ ] C = new int [ m + n ] ;
generateUtil ( A , B , C , 0 , 0 , m , n , 0 , true ) ; }
public virtual void printArr ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) { Console . Write ( arr [ i ] + " ▁ " ) ; } Console . WriteLine ( " " ) ; }
public static void Main ( string [ ] args ) { GenerateArrays generate = new GenerateArrays ( ) ; int [ ] A = new int [ ] { 10 , 15 , 25 } ; int [ ] B = new int [ ] { 5 , 20 , 30 } ; int n = A . Length ; int m = B . Length ; generate . generate ( A , B , n , m ) ; } }
static void replace_elements ( int [ ] arr , int n ) {
int pos = 0 ; for ( int i = 0 ; i < n ; i ++ ) { arr [ pos ++ ] = arr [ i ] ; while ( pos > 1 && arr [ pos - 2 ] == arr [ pos - 1 ] ) { pos -- ; arr [ pos - 1 ] ++ ; } }
for ( int i = 0 ; i < pos ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
static void Main ( ) { int [ ] arr = { 6 , 4 , 3 , 4 , 3 , 3 , 5 } ; int n = arr . Length ; replace_elements ( arr , n ) ; } }
static void arrangeString ( string str , int x , int y ) { int count_0 = 0 ; int count_1 = 0 ; int len = str . Length ;
for ( int i = 0 ; i < len ; i ++ ) { if ( str [ i ] == '0' ) count_0 ++ ; else count_1 ++ ; }
while ( count_0 > 0 count_1 > 0 ) { for ( int j = 0 ; j < x && count_0 > 0 ; j ++ ) { if ( count_0 > 0 ) { Console . Write ( "0" ) ; count_0 -- ; } } for ( int j = 0 ; j < y && count_1 > 0 ; j ++ ) { if ( count_1 > 0 ) { Console . Write ( "1" ) ; count_1 -- ; } } } }
public static void Main ( ) { string str = "01101101101101101000000" ; int x = 1 ; int y = 2 ; arrangeString ( str , x , y ) ; } }
public static void rearrange ( int [ ] arr ) {
if ( arr == null arr . Length % 2 == 1 ) return ;
int currIdx = ( arr . Length - 1 ) / 2 ;
while ( currIdx > 0 ) { int count = currIdx , swapIdx = currIdx ; while ( count -- > 0 ) { int temp = arr [ swapIdx + 1 ] ; arr [ swapIdx + 1 ] = arr [ swapIdx ] ; arr [ swapIdx ] = temp ; swapIdx ++ ; } currIdx -- ; } }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 5 , 2 , 4 , 6 } ; rearrange ( arr ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) Console . Write ( " ▁ " + arr [ i ] ) ; } }
static int maxDiff ( int [ ] arr , int n ) {
int maxDiff = - 1 ;
int maxRight = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) { if ( arr [ i ] > maxRight ) maxRight = arr [ i ] ; else { int diff = maxRight - arr [ i ] ; if ( diff > maxDiff ) { maxDiff = diff ; } } } return maxDiff ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 90 , 10 , 110 } ; int n = arr . Length ;
Console . WriteLine ( " Maximum ▁ difference ▁ is ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) {
int diff = arr [ 1 ] - arr [ 0 ] ; int curr_sum = diff ; int max_sum = curr_sum ; for ( int i = 1 ; i < n - 1 ; i ++ ) {
diff = arr [ i + 1 ] - arr [ i ] ;
if ( curr_sum > 0 ) curr_sum += diff ; else curr_sum = diff ;
if ( curr_sum > max_sum ) max_sum = curr_sum ; } return max_sum ; }
public static void Main ( ) { int [ ] arr = { 80 , 2 , 6 , 3 , 100 } ; int n = arr . Length ;
Console . WriteLine ( " Maximum ▁ difference ▁ is ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxRepeating ( int [ ] arr , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) arr [ ( arr [ i ] % k ) ] += k ;
int max = arr [ 0 ] , result = 0 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; result = i ; } }
return result ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 } ; int n = arr . Length ; int k = 8 ; Console . Write ( " Maximum ▁ repeating ▁ " + " element ▁ is : ▁ " + maxRepeating ( arr , n , k ) ) ; } }
static int maxPathSum ( int [ ] ar1 , int [ ] ar2 , int m , int n ) {
int i = 0 , j = 0 ;
int result = 0 , sum1 = 0 , sum2 = 0 ;
while ( i < m && j < n ) {
if ( ar1 [ i ] < ar2 [ j ] ) sum1 += ar1 [ i ++ ] ;
else if ( ar1 [ i ] > ar2 [ j ] ) sum2 += ar2 [ j ++ ] ;
else {
result += max ( sum1 , sum2 ) + ar1 [ i ] ;
sum1 = 0 ; sum2 = 0 ;
i ++ ; j ++ ; } }
while ( i < m ) sum1 += ar1 [ i ++ ] ;
while ( j < n ) sum2 += ar2 [ j ++ ] ;
result += max ( sum1 , sum2 ) ; return result ; }
public static void Main ( ) { int [ ] ar1 = { 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 } ; int [ ] ar2 = { 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 } ; int m = ar1 . Length ; int n = ar2 . Length ;
Console . Write ( " Maximum ▁ sum ▁ path ▁ is ▁ : " + maxPathSum ( ar1 , ar2 , m , n ) ) ; } }
using System ; class GFG { static void smallestGreater ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) {
int diff = int . MaxValue ; int closest = - 1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] < arr [ j ] && arr [ j ] - arr [ i ] < diff ) { diff = arr [ j ] - arr [ i ] ; closest = j ; } }
if ( closest == - 1 ) Console . Write ( " _ ▁ " ) ; else Console . Write ( arr [ closest ] + " ▁ " ) ; } }
public static void Main ( ) { int [ ] ar = { 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 } ; int n = ar . Length ; smallestGreater ( ar , n ) ; } }
static void findZeroes ( int m ) {
int wL = 0 , wR = 0 ;
int bestL = 0 , bestWindow = 0 ;
int zeroCount = 0 ;
while ( wR < arr . Length ) {
if ( zeroCount <= m ) { if ( arr [ wR ] == 0 ) zeroCount ++ ; wR ++ ; }
if ( zeroCount > m ) { if ( arr [ wL ] == 0 ) zeroCount -- ; wL ++ ; }
if ( ( wR - wL > bestWindow ) && ( zeroCount <= m ) ) { bestWindow = wR - wL ; bestL = wL ; } }
for ( int i = 0 ; i < bestWindow ; i ++ ) { if ( arr [ bestL + i ] == 0 ) Console . Write ( bestL + i + " ▁ " ) ; } }
public static void Main ( String [ ] args ) { int m = 2 ; Console . Write ( " Indexes ▁ of ▁ zeroes ▁ to ▁ be ▁ flipped ▁ are ▁ " ) ; findZeroes ( m ) ; } }
using System ; class Test { static int [ ] arr = new int [ ] { 1 , 2 , 2 , 4 } ; static int countIncreasing ( int n ) {
int cnt = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] > arr [ j - 1 ] ) cnt ++ ;
else break ; } } return cnt ; }
public static void Main ( String [ ] args ) { Console . Write ( " Count ▁ of ▁ strictly ▁ increasing " + " subarrays ▁ is ▁ " + countIncreasing ( arr . Length ) ) ; } }
using System ; class GFG { static int [ ] arr = new int [ ] { 1 , 2 , 2 , 4 } ; static int countIncreasing ( int n ) {
int cnt = 0 ;
int len = 1 ;
for ( int i = 0 ; i < n - 1 ; ++ i ) {
if ( arr [ i + 1 ] > arr [ i ] ) len ++ ;
else { cnt += ( ( ( len - 1 ) * len ) / 2 ) ; len = 1 ; } }
if ( len > 1 ) cnt += ( ( ( len - 1 ) * len ) / 2 ) ; return cnt ; }
public static void Main ( ) { Console . WriteLine ( " Count ▁ of ▁ strictly ▁ " + " increasing ▁ subarrays ▁ is ▁ " + countIncreasing ( arr . Length ) ) ; } }
static long arraySum ( int [ ] arr , int n ) { long sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + arr [ i ] ; return sum ; }
static long maxDiff ( int [ ] arr , int n , int k ) {
Array . Sort ( arr ) ;
long arraysum = arraySum ( arr , n ) ;
long diff1 = Math . Abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
Array . Reverse ( arr ) ;
long diff2 = Math . Abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
return ( Math . Max ( diff1 , diff2 ) ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 7 , 4 , 8 , - 1 , 5 , 2 , 1 } ; int n = arr . Length ; int k = 3 ; Console . WriteLine ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n , k ) ) ; } }
static int minNumber ( int [ ] a , int n , int x ) {
Array . Sort ( a ) ; int k ; for ( k = 0 ; a [ ( n ) / 2 ] != x ; k ++ ) { a [ n ++ ] = x ; Array . Sort ( a ) ; } return k ; }
public static void Main ( String [ ] args ) { int x = 10 ; int [ ] a = { 10 , 20 , 30 } ; int n = 3 ; Console . WriteLine ( minNumber ( a , n - 1 , x ) ) ; } }
using System ; class GFG { public static int minNumber ( int [ ] a , int n , int x ) { int l = 0 , h = 0 , e = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == x ) e ++ ;
else if ( a [ i ] > x ) h ++ ;
else if ( a [ i ] < x ) l ++ ; } int ans = 0 ; if ( l > h ) ans = l - h ; else if ( l < h ) ans = h - l - 1 ;
return ans + 1 - e ; }
public static void Main ( ) { int x = 10 ; int [ ] a = { 10 , 20 , 30 } ; int n = a . Length ; Console . WriteLine ( minNumber ( a , n , x ) ) ; } }
static int fun ( int x ) { int y = ( x / 4 ) * 4 ;
int ans = 0 ; for ( int i = y ; i <= x ; i ++ ) ans ^= i ; return ans ; }
static int query ( int x ) {
if ( x == 0 ) return 0 ; int k = ( x + 1 ) / 2 ;
return ( ( x %= 2 ) != 0 ) ? 2 * fun ( k ) : ( ( fun ( k - 1 ) * 2 ) ^ ( k & 1 ) ) ; } static void allQueries ( int q , int [ ] l , int [ ] r ) { for ( int i = 0 ; i < q ; i ++ ) Console . WriteLine ( ( query ( r [ i ] ) ^ query ( l [ i ] - 1 ) ) ) ; }
public static void Main ( ) { int q = 3 ; int [ ] l = { 2 , 2 , 5 } ; int [ ] r = { 4 , 8 , 9 } ; allQueries ( q , l , r ) ; } }
static void checkEVENodd ( int [ ] arr , int n , int l , int r ) {
if ( arr [ r ] == 1 ) Console . WriteLine ( " odd " ) ;
else Console . ( " even " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 0 , 1 } ; int n = arr . Length ; checkEVENodd ( arr , n , 1 , 3 ) ; } }
static int findMean ( int [ ] arr , int l , int r ) {
int sum = 0 , count = 0 ;
for ( int i = l ; i <= r ; i ++ ) { sum += arr [ i ] ; count ++ ; }
int mean = ( int ) Math . Floor ( ( double ) sum / count ) ;
return mean ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; Console . WriteLine ( findMean ( arr , 0 , 2 ) ) ; Console . WriteLine ( findMean ( arr , 1 , 3 ) ) ; Console . WriteLine ( findMean ( arr , 0 , 4 ) ) ; } }
static int calculateProduct ( int [ ] A , int L , int R , int P ) {
L = L - 1 ; R = R - 1 ; int ans = 1 ; for ( int i = L ; i <= R ; i ++ ) { ans = ans * A [ i ] ; ans = ans % P ; } return ans ; }
static public void Main ( ) { int [ ] A = { 1 , 2 , 3 , 4 , 5 , 6 } ; int P = 229 ; int L = 2 , R = 5 ; Console . WriteLine ( calculateProduct ( A , L , R , P ) ) ; L = 1 ; R = 3 ; Console . WriteLine ( calculateProduct ( A , L , R , P ) ) ; } }
using System ; class GFG { static int MAX = 10000 ;
static int [ ] prefix = new int [ MAX + 1 ] ; static void buildPrefix ( ) {
bool [ ] prime = new bool [ MAX + 1 ] ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == false ) {
for ( int i = p * 2 ; i <= MAX ; i += p ) prime [ i ] = true ; } }
prefix [ 0 ] = prefix [ 1 ] = 0 ; for ( int p = 2 ; p <= MAX ; p ++ ) { prefix [ p ] = prefix [ p - 1 ] ; if ( prime [ p ] == false ) prefix [ p ] ++ ; } }
static int query ( int L , int R ) { return prefix [ R ] - prefix [ L - 1 ] ; }
public static void Main ( ) { buildPrefix ( ) ; int L = 5 , R = 10 ; Console . WriteLine ( query ( L , R ) ) ; L = 1 ; R = 10 ; Console . WriteLine ( query ( L , R ) ) ; } }
static void command ( bool [ ] arr , int a , int b ) { arr [ a ] ^= true ; arr [ b + 1 ] ^= true ; }
static void process ( bool [ ] arr , int n ) { for ( int k = 1 ; k <= n ; k ++ ) { arr [ k ] ^= arr [ k - 1 ] ; } }
static void result ( bool [ ] arr , int n ) { for ( int k = 1 ; k <= n ; k ++ ) { if ( arr [ k ] == true ) Console . Write ( "1" + " ▁ " ) ; else Console . Write ( "0" + " ▁ " ) ; } }
public static void Main ( ) { int n = 5 , m = 3 ; bool [ ] arr = new bool [ n + 2 ] ;
command ( arr , 1 , 5 ) ; command ( arr , 2 , 5 ) ; command ( arr , 3 , 5 ) ;
process ( arr , n ) ;
result ( arr , n ) ; } }
static float probability ( int [ ] a , int [ ] b , int size1 , int size2 ) {
int max1 = int . MinValue , count1 = 0 ; for ( int i = 0 ; i < size1 ; i ++ ) { if ( a [ i ] > max1 ) { max1 = a [ i ] ; count1 = 1 ; } else if ( a [ i ] == max1 ) { count1 ++ ; } }
int max2 = int . MinValue , count2 = 0 ; for ( int i = 0 ; i < size2 ; i ++ ) { if ( b [ i ] > max2 ) { max2 = b [ i ] ; count2 = 1 ; } else if ( b [ i ] == max2 ) { count2 ++ ; } }
return ( float ) ( count1 * count2 ) / ( size1 * size2 ) ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 3 } ; int [ ] b = { 1 , 3 , 3 } ; int size1 = a . Length ; int size2 = b . Length ; Console . WriteLine ( probability ( a , b , size1 , size2 ) ) ; } }
public static int countDe ( int [ ] arr , int n ) { int [ ] v = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) v [ i ] = arr [ i ] ;
Array . Sort ( arr ) ;
int count1 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count1 ++ ;
Array . Reverse ( arr ) ;
int count2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count2 ++ ;
return ( Math . Min ( count1 , count2 ) ) ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 5 , 9 , 21 , 17 , 13 } ; int n = 5 ; Console . WriteLine ( " Minimum ▁ Dearrangement ▁ = ▁ " + countDe ( arr , n ) ) ; } }
static int maxOfSegmentMins ( int [ ] a , int n , int k ) {
if ( k == 1 ) return a . Min ( ) ; if ( k == 2 ) return Math . Max ( a [ 0 ] , a [ n - 1 ] ) ;
return a . Max ( ) ; }
static public void Main ( ) { int [ ] a = { - 10 , - 9 , - 8 , 2 , 7 , - 6 , - 5 } ; int n = a . Length ; int k = 2 ; Console . WriteLine ( maxOfSegmentMins ( a , n , k ) ) ; } }
static int printMinimumProduct ( int [ ] arr , int n ) {
int first_min = Math . Min ( arr [ 0 ] , arr [ 1 ] ) ; int second_min = Math . Max ( arr [ 0 ] , arr [ 1 ] ) ;
for ( int i = 2 ; i < n ; i ++ ) { if ( arr [ i ] < first_min ) { second_min = first_min ; first_min = arr [ i ] ; } else if ( arr [ i ] < second_min ) second_min = arr [ i ] ; } return first_min * second_min ; }
public static void Main ( ) { int [ ] a = { 11 , 8 , 5 , 7 , 5 , 100 } ; int n = a . Length ; Console . WriteLine ( printMinimumProduct ( a , n ) ) ; } }
static long noOfTriples ( long [ ] arr , int n ) {
Array . Sort ( arr ) ;
long count = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] == arr [ 2 ] ) count ++ ;
if ( arr [ 0 ] == arr [ 2 ] ) return ( count - 2 ) * ( count - 1 ) * ( count ) / 6 ;
else if ( arr [ 1 ] == arr [ 2 ] ) return ( count - 1 ) * ( count ) / 2 ;
return count ; }
public static void Main ( ) { long [ ] arr = { 1 , 3 , 3 , 4 } ; int n = arr . Length ; Console . Write ( noOfTriples ( arr , n ) ) ; } }
static bool checkReverse ( int [ ] arr , int n ) {
int [ ] temp = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { temp [ i ] = arr [ i ] ; }
Array . Sort ( temp ) ;
int front ; for ( front = 0 ; front < n ; front ++ ) { if ( temp [ front ] != arr [ front ] ) { break ; } }
int back ; for ( back = n - 1 ; back >= 0 ; back -- ) { if ( temp [ back ] != arr [ back ] ) { break ; } }
if ( front >= back ) { return true ; }
do { front ++ ; if ( arr [ front - 1 ] < arr [ front ] ) { return false ; } } while ( front != back ) ; return true ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 5 , 4 , 3 } ; int n = arr . Length ; if ( checkReverse ( arr , n ) ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " No " ) ; } } }
static bool checkReverse ( int [ ] arr , int n ) { if ( n == 1 ) { return true ; }
int i ; for ( i = 1 ; arr [ i - 1 ] < arr [ i ] && i < n ; i ++ ) ; if ( i == n ) { return true ; }
int j = i ; while ( j < n && arr [ j ] < arr [ j - 1 ] ) { if ( i > 1 && arr [ j ] < arr [ i - 2 ] ) { return false ; } j ++ ; } if ( j == n ) { return true ; }
int k = j ;
if ( arr [ k ] < arr [ i - 1 ] ) { return false ; } while ( k > 1 && k < n ) { if ( arr [ k ] < arr [ k - 1 ] ) { return false ; } k ++ ; } return true ; }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 4 , 10 , 9 , 8 } ; int n = arr . Length ; if ( checkReverse ( arr , n ) ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " No " ) ; } } }
using System ; public class GFG { static int MinOperation ( int [ ] a , int [ ] b , int n ) {
Array . Sort ( a ) ; Array . Sort ( b ) ;
int result = 0 ;
for ( int i = 0 ; i < n ; ++ i ) { if ( a [ i ] > b [ i ] ) result = result + Math . Abs ( a [ i ] - b [ i ] ) ; else if ( a [ i ] < b [ i ] ) result = result + Math . Abs ( a [ i ] - b [ i ] ) ; } return result ; }
public static void Main ( ) { int [ ] a = { 3 , 1 , 1 } ; int [ ] b = { 1 , 2 , 2 } ; int n = a . Length ; Console . WriteLine ( MinOperation ( a , b , n ) ) ; } }
static void sortExceptUandL ( int [ ] a , int l , int u , int n ) {
int [ ] b = new int [ n - ( u - l + 1 ) ] ; for ( int i = 0 ; i < l ; i ++ ) b [ i ] = a [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) b [ l + ( i - ( u + 1 ) ) ] = a [ i ] ;
Array . Sort < int > ( b , 0 , n - ( u - l + 1 ) ) ;
for ( int i = 0 ; i < l ; i ++ ) a [ i ] = b [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) a [ i ] = b [ l + ( i - ( u + 1 ) ) ] ; }
public static void Main ( ) { int [ ] a = { 5 , 4 , 3 , 12 , 14 , 9 } ; int n = a . Length ; int l = 2 , u = 4 ; sortExceptUandL ( a , l , u , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( a [ i ] + " ▁ " ) ; } }
using System ; public class GFG { static int sortExceptK ( int [ ] arr , int k , int n ) {
int temp = arr [ k ] ; arr [ k ] = arr [ n - 1 ] ; arr [ n - 1 ] = temp ;
Array . Sort ( arr , 0 , n - 1 ) ;
int last = arr [ n - 1 ] ;
for ( int i = n - 1 ; i > k ; i -- ) arr [ i ] = arr [ i - 1 ] ;
arr [ k ] = last ; return 0 ; }
public static void Main ( ) { int [ ] a = { 10 , 4 , 11 , 7 , 6 , 20 } ; int k = 2 ; int n = a . Length ; sortExceptK ( a , k , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( a [ i ] + " ▁ " ) ; } }
static int findMinSwaps ( int [ ] arr , int n ) {
int [ ] noOfZeroes = new int [ n ] ; int i , count = 0 ;
noOfZeroes [ n - 1 ] = 1 - arr [ n - 1 ] ; for ( i = n - 2 ; i >= 0 ; i -- ) { noOfZeroes [ i ] = noOfZeroes [ i + 1 ] ; if ( arr [ i ] == 0 ) noOfZeroes [ i ] ++ ; }
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 1 ) count += noOfZeroes [ i ] ; } return count ; }
public static void Main ( ) { int [ ] ar = { 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 } ; Console . WriteLine ( findMinSwaps ( ar , ar . Length ) ) ; } }
static int maxPartitions ( int [ ] arr , int n ) { int ans = 0 , max_so_far = 0 ; for ( int i = 0 ; i < n ; ++ i ) {
max_so_far = Math . Max ( max_so_far , arr [ i ] ) ;
if ( max_so_far == i ) ans ++ ; } return ans ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 2 , 3 , 4 } ; int n = arr . Length ; Console . Write ( maxPartitions ( arr , n ) ) ; } }
public static void cuttringRopes ( int [ ] Ropes , int n ) {
Array . Sort ( Ropes ) ; int singleOperation = 0 ;
int cuttingLenght = Ropes [ 0 ] ;
for ( int i = 1 ; i < n ; i ++ ) {
if ( Ropes [ i ] - cuttingLenght > 0 ) { Console . Write ( n - i + " ▁ " ) ;
cuttingLenght = Ropes [ i ] ; singleOperation ++ ; } }
if ( singleOperation == 0 ) Console . Write ( "0" ) ; }
public static void Main ( ) { int [ ] Ropes = { 5 , 1 , 1 , 2 , 3 , 5 } ; int n = Ropes . Length ; cuttringRopes ( Ropes , n ) ; } }
public static void rankify ( int [ ] A , int n ) {
float [ ] R = new float [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) { int r = 1 , s = 1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( j != i && A [ j ] < A [ i ] ) r += 1 ; if ( j != i && A [ j ] == A [ i ] ) s += 1 ; }
R [ i ] = r + ( float ) ( s - 1 ) / ( float ) 2 ; } for ( int i = 0 ; i < n ; i ++ ) Console . Write ( R [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] A = { 1 , 2 , 5 , 2 , 1 , 25 , 2 } ; int n = A . Length ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( A [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; rankify ( A , n ) ; } }
public static int min_noOf_operation ( int [ ] arr , int n , int k ) { int noOfSubtraction ; int res = 0 ; for ( int i = 1 ; i < n ; i ++ ) { noOfSubtraction = 0 ; if ( arr [ i ] > arr [ i - 1 ] ) {
noOfSubtraction = ( arr [ i ] - arr [ i - 1 ] ) / k ;
if ( ( arr [ i ] - arr [ i - 1 ] ) % k != 0 ) noOfSubtraction ++ ;
arr [ i ] = arr [ i ] - k * noOfSubtraction ; }
res = res + noOfSubtraction ; } return res ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 2 , 3 } ; int N = 4 ; int k = 5 ; Console . WriteLine ( min_noOf_operation ( arr , N , k ) ) ; } }
using System ; class GFG { static int maxSum ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += ( arr [ i ] * i ) ; return sum ; }
static public void Main ( ) { int [ ] arr = { 3 , 5 , 6 , 1 } ; int n = arr . Length ; Console . WriteLine ( maxSum ( arr , n ) ) ; } }
static int countPairs ( int [ ] a , int n , int k ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( Math . Abs ( a [ j ] - a [ i ] ) < k ) res ++ ; return res ; }
public static void Main ( ) { int [ ] a = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = a . Length ; Console . WriteLine ( countPairs ( a , n , k ) ) ; } }
using System ; class GFG { static int countPairs ( int [ ] a , int n , int k ) {
Array . Sort ( a ) ; int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j = i + 1 ; while ( j < n && a [ j ] - a [ i ] < k ) { res ++ ; j ++ ; } } return res ; }
public static void Main ( ) { int [ ] a = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = a . Length ; Console . WriteLine ( countPairs ( a , n , k ) ) ; } }
static int sumOfMinAbsDifferences ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
int sum = 0 ;
sum += Math . Abs ( arr [ 0 ] - arr [ 1 ] ) ;
sum += Math . Abs ( arr [ n - 1 ] - arr [ n - 2 ] ) ;
for ( int i = 1 ; i < n - 1 ; i ++ ) sum += Math . Min ( Math . Abs ( arr [ i ] - arr [ i - 1 ] ) , Math . Abs ( arr [ i ] - arr [ i + 1 ] ) ) ;
return sum ; }
public static void Main ( ) { int [ ] arr = { 5 , 10 , 1 , 4 , 8 , 7 } ; int n = arr . Length ; Console . Write ( " Sum ▁ = ▁ " + sumOfMinAbsDifferences ( arr , n ) ) ; } }
static int findSmallestDifference ( int [ ] A , int [ ] B , int m , int n ) {
Array . Sort ( A ) ; Array . Sort ( B ) ; int a = 0 , b = 0 ;
int result = int . MaxValue ;
while ( a < m && b < n ) { if ( Math . Abs ( A [ a ] - B [ b ] ) < result ) result = Math . Abs ( A [ a ] - B [ b ] ) ;
if ( A [ a ] < B [ b ] ) a ++ ; else b ++ ; }
return result ; }
public static void Main ( ) {
int [ ] A = { 1 , 2 , 11 , 5 } ;
int [ ] B = { 4 , 12 , 19 , 23 , 127 , 235 } ;
int m = A . Length ; int n = B . Length ;
Console . Write ( findSmallestDifference ( A , B , m , n ) ) ; } }
static void findLarger ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
for ( int i = n - 1 ; i >= n / 2 ; i -- ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 6 , 1 , 0 , 9 } ; int n = arr . Length ; findLarger ( arr , n ) ; } }
static int findSingle ( int [ ] ar , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
public static void Main ( ) { int [ ] ar = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = ar . Length ; Console . Write ( " Element ▁ occurring ▁ once ▁ is ▁ " + findSingle ( ar , n ) + " ▁ " ) ; } }
static int countOccurrences ( int [ ] arr , int n , int x ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( x == arr [ i ] ) res ++ ; return res ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = arr . Length ; int x = 2 ; Console . Write ( countOccurrences ( arr , n , x ) ) ; } }
static int binarySearch ( int [ ] arr , int l , int r , int x ) { if ( r < l ) return - 1 ; int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
static int countOccurrences ( int [ ] arr , int n , int x ) { int ind = binarySearch ( arr , 0 , n - 1 , x ) ;
if ( ind == - 1 ) return 0 ;
int count = 1 ; int left = ind - 1 ; while ( left >= 0 && arr [ left ] == x ) { count ++ ; left -- ; }
int right = ind + 1 ; while ( right < n && arr [ right ] == x ) { count ++ ; right ++ ; } return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = arr . Length ; int x = 2 ; Console . Write ( countOccurrences ( arr , n , x ) ) ; } }
static void printClosest ( int [ ] arr , int n , int x ) {
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 , diff = int . MaxValue ;
while ( r > l ) {
if ( Math . Abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . Abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } Console . Write ( " ▁ The ▁ closest ▁ pair ▁ is ▁ " + arr [ res_l ] + " ▁ and ▁ " + arr [ res_r ] ) ; }
public static void Main ( ) { int [ ] arr = { 10 , 22 , 28 , 29 , 30 , 40 } ; int x = 54 ; int n = arr . Length ; printClosest ( arr , n , x ) ; } }
static int countOnes ( int [ ] arr , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = arr . Length ; Console . WriteLine ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ " + " array ▁ is ▁ " + countOnes ( arr , 0 , n - 1 ) ) ; } }
static int findMissingUtil ( int [ ] arr1 , int [ ] arr2 , int N ) {
if ( N == 1 ) return arr1 [ 0 ] ;
if ( arr1 [ 0 ] != arr2 [ 0 ] ) return arr1 [ 0 ] ;
int lo = 0 , hi = N - 1 ;
while ( lo < hi ) { int mid = ( lo + hi ) / 2 ;
if ( arr1 [ mid ] == arr2 [ mid ] ) lo = mid ; else hi = mid ;
if ( lo == hi - 1 ) break ; }
return arr1 [ hi ] ; }
static void findMissing ( int [ ] arr1 , int [ ] arr2 , int M , int N ) { if ( N == M - 1 ) Console . WriteLine ( " Missing ▁ Element ▁ is ▁ " + findMissingUtil ( arr1 , arr2 , M ) + " STRNEWLINE " ) ; else if ( M == N - 1 ) Console . WriteLine ( " Missing ▁ Element ▁ is ▁ " + findMissingUtil ( arr2 , arr1 , N ) + " STRNEWLINE " ) ; else Console . WriteLine ( " Invalid ▁ Input " ) ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 4 , 5 , 7 , 9 } ; int [ ] arr2 = { 4 , 5 , 7 , 9 } ; int M = arr1 . Length ; int N = arr2 . Length ; findMissing ( arr1 , arr2 , M , N ) ; } }
static void findMissing ( int [ ] arr1 , int [ ] arr2 , int M , int N ) { if ( M != N - 1 && N != M - 1 ) { Console . WriteLine ( " Invalid ▁ Input " ) ; return ; }
int res = 0 ; for ( int i = 0 ; i < M ; i ++ ) res = res ^ arr1 [ i ] ; for ( int i = 0 ; i < N ; i ++ ) res = res ^ arr2 [ i ] ; Console . WriteLine ( " Missing ▁ element ▁ is ▁ " + res ) ; }
public static void Main ( ) { int [ ] arr1 = { 4 , 1 , 5 , 9 , 7 } ; int [ ] arr2 = { 7 , 5 , 9 , 4 } ; int M = arr1 . Length ; int N = arr2 . Length ; findMissing ( arr1 , arr2 , M , N ) ; } }
static void getTwoElements ( int [ ] arr , int n ) {
int xor1 ;
int set_bit_no ; int i ; x = 0 ; y = 0 ; xor1 = arr [ 0 ] ;
for ( i = 1 ; i < n ; i ++ ) xor1 = xor1 ^ arr [ i ] ;
for ( i = 1 ; i <= n ; i ++ ) xor1 = xor1 ^ i ;
set_bit_no = xor1 & ~ ( xor1 - 1 ) ;
for ( i = 0 ; i < n ; i ++ ) { if ( ( arr [ i ] & set_bit_no ) != 0 )
x = x ^ arr [ i ] ; else
y = y ^ arr [ i ] ; } for ( i = 1 ; i <= n ; i ++ ) { if ( ( i & set_bit_no ) != 0 )
x = x ^ i ; else
y = y ^ i ; }
}
public static void Main ( ) { int [ ] arr = { 1 , 3 , 4 , 5 , 1 , 6 , 2 } ; int n = arr . Length ; getTwoElements ( arr , n ) ; Console . Write ( " ▁ The ▁ missing ▁ element ▁ is ▁ " + x + " and ▁ the ▁ " + " repeating ▁ number ▁ is ▁ " + y ) ; } }
static int search ( int [ ] arr , int n , int x ) {
int i = 0 ; while ( i < n ) {
if ( arr [ i ] == x ) return i ;
i = i + Math . Abs ( arr [ i ] - x ) ; } Console . WriteLine ( " number ▁ is ▁ not " + " ▁ present ! " ) ; return - 1 ; }
public static void Main ( ) { int [ ] arr = { 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 } ; int n = arr . Length ; int x = 3 ; Console . WriteLine ( " Element ▁ " + x + " ▁ is ▁ present ▁ at ▁ index ▁ " + search ( arr , n , 3 ) ) ; } }
using System ; class GFG { static void thirdLargest ( int [ ] arr , int arr_size ) {
if ( arr_size < 3 ) { Console . Write ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] ; for ( int i = 1 ; i < arr_size ; i ++ ) if ( arr [ i ] > first ) first = arr [ i ] ;
int second = - int . MaxValue ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > second && arr [ i ] < first ) second = arr [ i ] ;
int third = - int . MaxValue ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > third && arr [ i ] < second ) third = arr [ i ] ; Console . Write ( " The ▁ third ▁ Largest ▁ " + " element ▁ is ▁ " + third ) ; }
public static void Main ( ) { int [ ] arr = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = arr . Length ; thirdLargest ( arr , n ) ; } }
using System ; class GFG { static void thirdLargest ( int [ ] arr , int arr_size ) {
if ( arr_size < 3 ) { Console . Write ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] , second = int . MinValue , third = int . MinValue ;
for ( int i = 1 ; i < arr_size ; i ++ ) {
if ( arr [ i ] > first ) { third = second ; second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) { third = second ; second = arr [ i ] ; }
else if ( arr [ i ] > third ) { third = arr [ i ] ; } } Console . Write ( " The ▁ third ▁ Largest ▁ element ▁ is ▁ " + third ) ; }
public static void Main ( ) { int [ ] arr = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = arr . Length ; thirdLargest ( arr , n ) ; } }
static bool checkPair ( int [ ] arr , int n ) {
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum += arr [ i ] ; }
if ( sum % 2 != 0 ) { return false ; } sum = sum / 2 ;
HashSet < int > s = new HashSet < int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { int val = sum - arr [ i ] ;
if ( s . Contains ( val ) ) { Console . Write ( " Pair ▁ elements ▁ are ▁ { 0 } ▁ and ▁ { 1 } STRNEWLINE " , arr [ i ] , val ) ; return true ; } s . Add ( arr [ i ] ) ; } return false ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 2 , 11 , 5 , 1 , 4 , 7 } ; int n = arr . Length ; if ( checkPair ( arr , n ) == false ) { Console . Write ( " No ▁ pair ▁ found " ) ; } } }
static String search ( int [ ] arr , int n , int x ) {
if ( arr [ n - 1 ] == x ) return " Found " ; int backup = arr [ n - 1 ] ; arr [ n - 1 ] = x ;
for ( int i = 0 ; ; i ++ ) {
if ( arr [ i ] == x ) {
arr [ n - 1 ] = backup ;
if ( i < n - 1 ) return " Found " ;
return " Not ▁ Found " ; } } }
public static void Main ( ) { int [ ] arr = { 4 , 6 , 1 , 5 , 8 } ; int n = arr . Length ; int x = 1 ; Console . WriteLine ( search ( arr , n , x ) ) ; } }
using System ; public class GFG { public static int findMajority ( int [ ] arr , int n ) { return arr [ n / 2 ] ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 2 , 3 } ; int n = arr . Length ; Console . WriteLine ( findMajority ( arr , n ) ) ; } }
using System ; class GFG { static void minAdjDifference ( int [ ] arr , int n ) { if ( n < 2 ) return ;
int res = Math . Abs ( arr [ 1 ] - arr [ 0 ] ) ; for ( int i = 2 ; i < n ; i ++ ) res = Math . Min ( res , Math . Abs ( arr [ i ] - arr [ i - 1 ] ) ) ;
res = Math . Min ( res , Math . Abs ( arr [ n - 1 ] - arr [ 0 ] ) ) ; Console . Write ( " Min ▁ Difference ▁ = ▁ " + res ) ; }
public static void Main ( ) { int [ ] a = { 10 , 12 , 13 , 15 , 10 } ; int n = a . Length ; minAdjDifference ( a , n ) ; } }
using System ; class GFG { static void Print3Smallest ( int [ ] array , int n ) { int firstmin = int . MaxValue ; int secmin = int . MaxValue ; int thirdmin = int . MaxValue ; for ( int i = 0 ; i < n ; i ++ ) {
if ( array [ i ] < firstmin ) { thirdmin = secmin ; secmin = firstmin ; firstmin = array [ i ] ; }
else if ( array [ i ] < secmin ) { thirdmin = secmin ; secmin = array [ i ] ; }
else if ( array [ i ] < thirdmin ) thirdmin = array [ i ] ; } Console . WriteLine ( " First ▁ min ▁ = ▁ " + firstmin ) ; Console . WriteLine ( " Second ▁ min ▁ = ▁ " + secmin ) ; Console . WriteLine ( " Third ▁ min ▁ = ▁ " + thirdmin ) ; }
static void Main ( ) { int [ ] array = new int [ ] { 4 , 9 , 1 , 32 , 12 } ; int n = array . Length ; Print3Smallest ( array , n ) ; } }
static int getMin ( int [ ] arr , int n ) { return arr . Min ( ) ; } static int getMax ( int [ ] arr , int n ) { return arr . Max ( ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 12 , 1234 , 45 , 67 , 1 } ; int n = arr . Length ; Console . WriteLine ( " Minimum ▁ element ▁ of ▁ array : ▁ " + getMin ( arr , n ) ) ; Console . WriteLine ( " Maximum ▁ element ▁ of ▁ array : ▁ " + getMax ( arr , n ) ) ; } }
internal virtual void printfrequency ( int [ ] arr , int n ) {
for ( int j = 0 ; j < n ; j ++ ) { arr [ j ] = arr [ j ] - 1 ; }
for ( int i = 0 ; i < n ; i ++ ) { arr [ arr [ i ] % n ] = arr [ arr [ i ] % n ] + n ; }
for ( int i = 0 ; i < n ; i ++ ) { Console . WriteLine ( i + 1 + " - > " + arr [ i ] / n ) ; } }
public static void Main ( string [ ] args ) { CountFrequency count = new CountFrequency ( ) ; int [ ] arr = new int [ ] { 2 , 3 , 3 , 2 , 5 } ; int n = arr . Length ; count . printfrequency ( arr , n ) ; } }
static int getInvCount ( int [ ] arr , int n ) {
int invcount = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) {
int small = 0 ; for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) small ++ ;
int great = 0 ; for ( int j = i - 1 ; j >= 0 ; j -- ) if ( arr [ i ] < arr [ j ] ) great ++ ;
invcount += great * small ; } return invcount ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 8 , 4 , 2 , 1 } ; int n = arr . Length ; Console . WriteLine ( " Inversion ▁ count ▁ : ▁ " + getInvCount ( arr , n ) ) ; } }
static int findWater ( int n ) {
int water = 0 ;
left [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) left [ i ] = Math . Max ( left [ i - 1 ] , arr [ i ] ) ;
right [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) right [ i ] = Math . Max ( right [ i + 1 ] , arr [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) water += Math . Min ( left [ i ] , right [ i ] ) - arr [ i ] ; return water ; }
public static void Main ( ) { Console . WriteLine ( " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " + findWater ( arr . Length ) ) ; } }
using System ; class GFG { static int findWater ( int [ ] arr , int n ) {
int result = 0 ;
int left_max = 0 , right_max = 0 ;
int lo = 0 , hi = n - 1 ; while ( lo <= hi ) { if ( arr [ lo ] < arr [ hi ] ) { if ( arr [ lo ] > left_max )
left_max = arr [ lo ] ; else
result += left_max - arr [ lo ] ; lo ++ ; } else { if ( arr [ hi ] > right_max )
right_max = arr [ hi ] ; else result += - [ hi ] ; hi -- ; } } return result ; }
public static void Main ( ) { int [ ] arr = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int result = Trap . findWater ( arr , arr . length ) ; System . out . print ( " ▁ Total ▁ trapping ▁ water : ▁ " + result ) ; } }
static int missingK ( int [ ] a , int k , int n ) { int difference = 0 , ans = 0 , count = k ; bool flag = false ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { difference = 0 ;
if ( ( a [ i ] + 1 ) != a [ i + 1 ] ) {
difference += ( a [ i + 1 ] - a [ i ] ) - 1 ;
if ( difference >= count ) { ans = a [ i ] + count ; flag = true ; break ; } else count -= difference ; } }
if ( flag ) return ans ; else return - 1 ; }
int [ ] a = { 1 , 5 , 11 , 19 } ;
int k = 11 ; int n = a . Length ;
int missing = missingK ( a , k , n ) ; Console . Write ( missing ) ; } }
using System ; class GFG {
static int maximum ( int a , int b ) { return a > b ? a : b ; }
static int minimum ( int a , int b ) { return a < b ? a : b ; }
static double findMedianSortedArrays ( ref int [ ] a , int n , ref int [ ] b , int m ) { int min_index = 0 , max_index = n , i = 0 , j = 0 , median = 0 ; while ( min_index <= max_index ) { i = ( min_index + max_index ) / 2 ; j = ( ( n + m + 1 ) / 2 ) - i ;
if ( i < n && j > 0 && b [ j - 1 ] > a [ i ] ) min_index = i + 1 ;
else if ( i > 0 && j < m && b [ j ] < a [ i - 1 ] ) = i - 1 ;
else {
if ( i == 0 ) median = b [ j - 1 ] ;
else if ( j = = 0 ) median = a [ i - 1 ] ; else median = maximum ( a [ i - 1 ] , b [ j - 1 ] ) ; break ; } }
if ( ( n + m ) % 2 == 1 ) return ( double ) median ;
if ( i == n ) return ( median + b [ j ] ) / 2.0 ;
if ( j == m ) return ( median + a [ i ] ) / 2.0 ; return ( median + minimum ( a [ i ] , b [ j ] ) ) / 2.0 ; }
static void Main ( ) { int [ ] a = new int [ ] { 900 } ; int [ ] b = new int [ ] { 10 , 13 , 14 } ; int n = a . Length ; int m = b . Length ;
if ( n < m ) Console . Write ( " The ▁ median ▁ is ▁ : ▁ " + findMedianSortedArrays ( ref a , n , ref b , m ) ) ; else Console . Write ( " The ▁ median ▁ is ▁ : ▁ " + findMedianSortedArrays ( ref b , m , ref a , n ) ) ; } }
using System ; class GFG { static void printUncommon ( int [ ] arr1 , int [ ] arr2 , int n1 , int n2 ) { int i = 0 , j = 0 , k = 0 ; while ( i < n1 && j < n2 ) {
if ( arr1 [ i ] < arr2 [ j ] ) { Console . Write ( arr1 [ i ] + " ▁ " ) ; i ++ ; k ++ ; } else if ( arr2 [ j ] < arr1 [ i ] ) { Console . Write ( arr2 [ j ] + " ▁ " ) ; k ++ ; j ++ ; }
else { i ++ ; j ++ ; } }
while ( i < n1 ) { Console . Write ( arr1 [ i ] + " ▁ " ) ; i ++ ; k ++ ; } while ( j < n2 ) { Console . Write ( arr2 [ j ] + " ▁ " ) ; j ++ ; k ++ ; } }
public static void Main ( ) { int [ ] arr1 = { 10 , 20 , 30 } ; int [ ] arr2 = { 20 , 25 , 30 , 40 , 50 } ; int n1 = arr1 . Length ; int n2 = arr2 . Length ; printUncommon ( arr1 , arr2 , n1 , n2 ) ; } }
using System ; class GFG { static int leastFrequent ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
int min_count = n + 1 , res = - 1 ; int curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
static public void Main ( ) { int [ ] arr = { 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 } ; int n = arr . Length ; Console . Write ( leastFrequent ( arr , n ) ) ; } }
using System ; class GFG { static int M = 4 ; static void sort ( ref int [ , ] a , int row , int n ) { for ( int i = 0 ; i < M - 1 ; i ++ ) { if ( a [ row , i ] > a [ row , i + 1 ] ) { int temp = a [ row , i ] ; a [ row , i ] = a [ row , i + 1 ] ; a [ row , i + 1 ] = temp ; } } }
static int maximumSum ( int [ , ] a , int n ) { int i = 0 , j = 0 ;
for ( i = 0 ; i < n ; i ++ ) sort ( ref a , i , n ) ;
int sum = a [ n - 1 , M - 1 ] ; int prev = a [ n - 1 , M - 1 ] ;
for ( i = n - 2 ; i >= 0 ; i -- ) { for ( j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i , j ] < prev ) { prev = a [ i , j ] ; sum += prev ; break ; } }
if ( j == - 1 ) return 0 ; } return sum ; }
static void Main ( ) { int [ , ] arr = new int [ , ] { { 1 , 7 , 3 , 4 } , { 4 , 2 , 5 , 1 } , { 9 , 5 , 1 , 8 } } ; int n = arr . GetLength ( 0 ) ; Console . Write ( maximumSum ( arr , n ) ) ; } }
static int countPairs ( int [ ] A , int n , int k ) { int ans = 0 ;
Array . Sort ( A ) ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int x = 0 ;
while ( ( A [ i ] * Math . Pow ( k , x ) ) <= A [ j ] ) { if ( ( A [ i ] * Math . Pow ( k , x ) ) == A [ j ] ) { ans ++ ; break ; } x ++ ; } } } return ans ; }
public static void Main ( ) { int [ ] A = { 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 } ; int n = A . Length ; int k = 3 ; Console . WriteLine ( countPairs ( A , n , k ) ) ; } }
static int minDistance ( int [ ] arr , int n ) { int maximum_element = arr [ 0 ] ; int min_dis = n ; int index = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( maximum_element == arr [ i ] ) { min_dis = Math . Min ( min_dis , ( i - index ) ) ; index = i ; }
else if ( maximum_element < arr [ i ] ) { maximum_element = arr [ i ] ; min_dis = n ; index = i ; }
else continue ; } return min_dis ; }
public static void Main ( ) { int [ ] arr = { 6 , 3 , 1 , 3 , 6 , 4 , 6 } ; int n = arr . Length ; Console . WriteLine ( " Minimum ▁ distance ▁ = ▁ " + minDistance ( arr , n ) ) ; } }
static int findValue ( int [ ] arr , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] == k ) k *= 2 ; return k ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 4 , 10 , 8 , 1 } ; int k = 2 ; int n = arr . Length ; Console . WriteLine ( findValue ( arr , n , k ) ) ; } }
using System ; class GFG { static void dupLastIndex ( int [ ] arr , int n ) {
if ( arr == null n <= 0 ) return ;
for ( int i = n - 1 ; i > 0 ; i -- ) { if ( arr [ i ] == arr [ i - 1 ] ) { Console . WriteLine ( " Last ▁ index : " + i ) ; Console . WriteLine ( " Last ▁ duplicate ▁ item : ▁ " + arr [ i ] ) ; return ; } }
Console . WriteLine ( " no ▁ duplicate ▁ found " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 5 , 6 , 6 , 7 , 9 } ; int n = arr . Length ; dupLastIndex ( arr , n ) ; } }
static int findSmallest ( int [ ] a , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < n ; j ++ ) if ( a [ j ] % a [ i ] >= 1 ) break ;
if ( j == n ) return a [ i ] ; } return - 1 ; }
public static void Main ( ) { int [ ] a = { 25 , 20 , 5 , 10 , 100 } ; int n = a . Length ; Console . WriteLine ( findSmallest ( a , n ) ) ; } }
static int findSmallest ( int [ ] a , int n ) {
int smallest = min_element ( a ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( a [ i ] % smallest >= 1 ) return - 1 ; return smallest ; }
public static void Main ( ) { int [ ] a = { 25 , 20 , 5 , 10 , 100 } ; int n = a . Length ; Console . WriteLine ( findSmallest ( a , n ) ) ; } }
public static int findIndex ( int [ ] arr ) {
int maxIndex = 0 ; for ( int i = 0 ; i < arr . Length ; ++ i ) if ( arr [ i ] > arr [ maxIndex ] ) maxIndex = i ;
for ( int i = 0 ; i < arr . Length ; ++ i ) if ( maxIndex != i && arr [ maxIndex ] < 2 * arr [ i ] ) return - 1 ; return maxIndex ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 3 , 6 , 1 , 0 } ; Console . WriteLine ( findIndex ( arr ) ) ; } }
static int find_consecutive_steps ( int [ ] arr , int len ) { int count = 0 ; int maximum = 0 ; for ( int index = 1 ; index < len ; index ++ ) {
if ( arr [ index ] > arr [ index - 1 ] ) count ++ ; else { maximum = Math . Max ( maximum , count ) ; count = 0 ; } } return Math . Max ( maximum , count ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 } ; int len = arr . Length ; Console . WriteLine ( find_consecutive_steps ( arr , len ) ) ; } }
using System ; public class GFG { static int CalculateMax ( int [ ] arr , int n ) {
Array . Sort ( arr ) ; int min_sum = arr [ 0 ] + arr [ 1 ] ; int max_sum = arr [ n - 1 ] + arr [ n - 2 ] ; return ( Math . Abs ( max_sum - min_sum ) ) ; }
static public void Main ( ) { int [ ] arr = { 6 , 7 , 1 , 11 } ; int n = arr . Length ; Console . WriteLine ( CalculateMax ( arr , n ) ) ; } }
using System ; using System . Linq ; using System . Collections . Generic ; class GFG { static long calculate ( long [ ] a , int n ) {
Array . Sort ( a ) ; int i , j ;
List < long > s = new List < long > ( ) ; for ( i = 0 , j = n - 1 ; i < j ; i ++ , j -- ) s . Add ( ( a [ i ] + a [ j ] ) ) ; long mini = s . Min ( ) ; long maxi = s . Max ( ) ; return Math . Abs ( maxi - mini ) ; }
public static void Main ( ) { long [ ] a = { 2 , 6 , 4 , 3 } ; int n = a . Length ; Console . WriteLine ( calculate ( a , n ) ) ; } }
static void printMinDiffPairs ( int [ ] arr , int n ) { if ( n <= 1 ) return ;
Array . Sort ( arr ) ;
int minDiff = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) minDiff = Math . Min ( minDiff , arr [ i ] - arr [ i - 1 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) { if ( ( arr [ i ] - arr [ i - 1 ] ) == minDiff ) { Console . Write ( " ▁ ( " + arr [ i - 1 ] + " , ▁ " + arr [ i ] + " ) , ▁ " ) ; } } }
public static void Main ( ) { int [ ] arr = { 5 , 3 , 2 , 4 , 1 } ; int n = arr . Length ; printMinDiffPairs ( arr , n ) ; } }
using System ; public class MaximumAbsoluteDifference { private static int calculateDiff ( int i , int j , int [ ] array ) {
return Math . Abs ( array [ i ] - array [ j ] ) + Math . Abs ( i - j ) ; }
private static int maxDistance ( int [ ] array ) {
int result = 0 ;
for ( int i = 0 ; i < array . Length ; i ++ ) { for ( int j = i ; j < array . Length ; j ++ ) {
result = Math . Max ( result , calculateDiff ( i , j , array ) ) ; } } return result ; }
public static void Main ( ) { int [ ] array = { - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 } ; Console . WriteLine ( maxDistance ( array ) ) ; } }
private static int maxDistance ( int [ ] array ) {
int max1 = int . MinValue ; int min1 = int . MaxValue ; int max2 = int . MinValue ; int min2 = int . MaxValue ; for ( int i = 0 ; i < array . Length ; i ++ ) {
max1 = Math . Max ( max1 , array [ i ] + i ) ; min1 = Math . Min ( min1 , array [ i ] + i ) ; max2 = Math . Max ( max2 , array [ i ] - i ) ; min2 = Math . Min ( min2 , array [ i ] - i ) ; }
return Math . Max ( max1 - min1 , max2 - min2 ) ; }
public static void Main ( ) { int [ ] array = { - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 } ; Console . WriteLine ( maxDistance ( array ) ) ; } }
static int extrema ( int [ ] a , int n ) { int count = 0 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
if ( a [ i ] > a [ i - 1 ] && a [ i ] > a [ i + 1 ] ) count += 1 ;
if ( a [ i ] < a [ i - 1 ] && a [ i ] < a [ i + 1 ] ) count += 1 ; } return count ; }
public static void Main ( ) { int [ ] a = { 1 , 0 , 2 , 1 } ; int n = a . Length ; Console . WriteLine ( extrema ( a , n ) ) ; } }
public static int findClosest ( int [ ] arr , int target ) { int n = arr . Length ;
if ( target <= arr [ 0 ] ) return arr [ 0 ] ; if ( target >= arr [ n - 1 ] ) return arr [ n - 1 ] ;
int i = 0 , j = n , mid = 0 ; while ( i < j ) { mid = ( i + j ) / 2 ; if ( arr [ mid ] == target ) return arr [ mid ] ;
if ( target < arr [ mid ] ) {
if ( mid > 0 && target > arr [ mid - 1 ] ) return getClosest ( arr [ mid - 1 ] , arr [ mid ] , target ) ;
j = mid ; }
else { if ( mid < n - 1 && target < arr [ mid + 1 ] ) return getClosest ( arr [ mid ] , arr [ mid + 1 ] , target ) ;
i = mid + 1 ; } }
return arr [ mid ] ; }
public static int getClosest ( int val1 , int val2 , int target ) { if ( target - val1 >= val2 - target ) return val2 ; else return val1 ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 } ; int target = 11 ; Console . WriteLine ( findClosest ( arr , target ) ) ; } }
static int sum ( int [ ] a , int n ) {
int maxSum = int . MinValue ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) maxSum = Math . Max ( maxSum , a [ i ] + a [ j ] ) ;
int c = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( a [ i ] + a [ j ] == maxSum ) c ++ ; return c ; }
public static void Main ( ) { int [ ] array = { 1 , 1 , 1 , 2 , 2 , 2 } ; int n = array . Length ; Console . WriteLine ( sum ( array , n ) ) ; } }
static int sum ( int [ ] a , int n ) {
int maxVal = a [ 0 ] , maxCount = 1 ; int secondMax = int . MinValue ; int secondMaxCount = 0 ; for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == maxVal ) maxCount ++ ; else if ( a [ i ] > maxVal ) { secondMax = maxVal ; secondMaxCount = maxCount ; maxVal = a [ i ] ; maxCount = 1 ; } else if ( a [ i ] == secondMax ) { secondMax = a [ i ] ; secondMaxCount ++ ; } else if ( a [ i ] > secondMax ) { secondMax = a [ i ] ; secondMaxCount = 1 ; } }
if ( maxCount > 1 ) return maxCount * ( maxCount - 1 ) / 2 ;
return secondMaxCount ; }
public static void Main ( ) { int [ ] array = { 1 , 1 , 1 , 2 , 2 , 2 , 3 } ; int n = array . Length ; Console . WriteLine ( sum ( array , n ) ) ; } }
static void printKMissing ( int [ ] arr , int n , int k ) { Array . Sort ( arr ) ;
int i = 0 ; while ( i < n && arr [ i ] <= 0 ) i ++ ;
int count = 0 , curr = 1 ; while ( count < k && i < n ) { if ( arr [ i ] != curr ) { Console . Write ( curr + " ▁ " ) ; count ++ ; } else i ++ ; curr ++ ; }
while ( count < k ) { Console . Write ( curr + " ▁ " ) ; curr ++ ; count ++ ; } }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 4 } ; int n = arr . Length ; int k = 3 ; printKMissing ( arr , n , k ) ; } }
public static int nobleInteger ( int [ ] arr ) { int size = arr . Length ; for ( int i = 0 ; i < size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( arr [ i ] < arr [ j ] ) count ++ ;
if ( count == arr [ i ] ) return arr [ i ] ; } return - 1 ; }
public static void Main ( ) { int [ ] arr = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr ) ; if ( res != - 1 ) Console . Write ( " The ▁ noble ▁ integer " + " ▁ is ▁ " + res ) ; else Console . Write ( " No ▁ Noble ▁ Integer " + " ▁ Found " ) ; } }
public static int nobleInteger ( int [ ] arr ) { Array . Sort ( arr ) ;
int n = arr . Length ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] == arr [ i + 1 ] ) continue ;
if ( arr [ i ] == n - i - 1 ) return arr [ i ] ; } if ( arr [ n - 1 ] == 0 ) return arr [ n - 1 ] ; return - 1 ; }
static public void Main ( ) { int [ ] arr = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr ) ; if ( res != - 1 ) Console . Write ( " The ▁ noble ▁ integer ▁ is ▁ " + res ) ; else Console . Write ( " No ▁ Noble ▁ Integer ▁ " + " Found " ) ; } }
static long findMinSum ( long [ ] a , long [ ] b , long n ) {
Array . Sort ( a ) ; Array . Sort ( b ) ;
long sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + Math . Abs ( a [ i ] - b [ i ] ) ; return sum ; }
long [ ] a = { 4 , 1 , 8 , 7 } ; long [ ] b = { 2 , 3 , 6 , 5 } ; int n = a . Length ; Console . Write ( findMinSum ( a , b , n ) ) ; } }
static bool checkIsAP ( int [ ] arr , int n ) { if ( n == 1 ) return true ;
Array . Sort ( arr ) ;
int d = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] != d ) return false ; return true ; }
public static void Main ( ) { int [ ] arr = { 20 , 15 , 5 , 0 , 10 } ; int n = arr . Length ; if ( checkIsAP ( arr , n ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; public class GFG { static int minProductSubset ( int [ ] a , int n ) { if ( n == 1 ) return a [ 0 ] ;
int negmax = int . MinValue ; int posmin = int . MinValue ; int count_neg = 0 , count_zero = 0 ; int product = 1 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == 0 ) { count_zero ++ ; continue ; }
if ( a [ i ] < 0 ) { count_neg ++ ; negmax = Math . Max ( negmax , a [ i ] ) ; }
if ( a [ i ] > 0 && a [ i ] < posmin ) { posmin = a [ i ] ; } product *= a [ i ] ; }
if ( count_zero == n || ( count_neg == 0 && count_zero > 0 ) ) return 0 ;
if ( count_neg == 0 ) return posmin ;
if ( count_neg % 2 == 0 && count_neg != 0 ) {
product = product / negmax ; } return product ; }
public static void Main ( ) { int [ ] a = new int [ ] { - 1 , - 1 , - 2 , 4 , 3 } ; int n = 5 ; Console . WriteLine ( minProductSubset ( a , n ) ) ; } }
using System ; class GFG { static int countPairs ( int [ ] a , int n ) {
int mn = int . MaxValue ; int mx = int . MinValue ; for ( int i = 0 ; i < n ; i ++ ) { mn = Math . Min ( mn , a [ i ] ) ; mx = Math . Max ( mx , a [ i ] ) ; }
int c1 = 0 ;
int c2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] == mn ) c1 ++ ; if ( a [ i ] == mx ) c2 ++ ; }
if ( mn == mx ) return n * ( n - 1 ) / 2 ; else return c1 * c2 ; }
public static void Main ( ) { int [ ] a = { 3 , 2 , 1 , 1 , 3 } ; int n = a . Length ; Console . WriteLine ( countPairs ( a , n ) ) ; } }
using System ; public class GFG { static int findElement ( int [ ] a , int n , int b ) {
Array . Sort ( a ) ;
int max = a [ n - 1 ] ; while ( b < max ) {
if ( Array . BinarySearch ( a , b ) > - 1 ) b *= 2 ; else return b ; } return b ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 3 } ; int n = a . Length ; int b = 1 ; Console . WriteLine ( findElement ( a , n , b ) ) ; } }
using System ; class GFG { static int Mod = 1000000007 ;
static long findSum ( int [ ] arr , int n ) { long sum = 0 ;
Array . Sort ( arr ) ;
int i = 0 ; while ( i < n && arr [ i ] < 0 ) { if ( i != n - 1 && arr [ i + 1 ] <= 0 ) { sum = ( sum + ( arr [ i ] * arr [ i + 1 ] ) % Mod ) % Mod ; i += 2 ; } else break ; }
int j = n - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { if ( j != 0 && arr [ j - 1 ] > 0 ) { sum = ( sum + ( arr [ j ] * arr [ j - 1 ] ) % Mod ) % Mod ; j -= 2 ; } else break ; }
if ( j > i ) sum = ( sum + ( arr [ i ] * arr [ j ] ) % Mod ) % Mod ;
else if ( i = = j ) sum = ( sum + arr [ i ] ) % Mod ; return sum ; }
public static void Main ( ) { int [ ] arr = { - 1 , 9 , 4 , 5 , - 4 , 7 } ; int n = arr . Length ; Console . WriteLine ( findSum ( arr , n ) ) ; } }
static void countOddRotations ( int n ) { int odd_count = 0 , even_count = 0 ; do { int digit = n % 10 ; if ( digit % 2 == 1 ) odd_count ++ ; else even_count ++ ; n = n / 10 ; } while ( n != 0 ) ; Console . WriteLine ( " Odd ▁ = ▁ " + odd_count ) ; Console . WriteLine ( " Even ▁ = ▁ " + even_count ) ; }
public static void Main ( ) { int n = 1234 ; countOddRotations ( n ) ; } }
static int numberOfDigits ( int n ) { int cnt = 0 ; while ( n > 0 ) { cnt ++ ; n /= 10 ; } return cnt ; }
static void cal ( int num ) { int digits = numberOfDigits ( num ) ; int powTen = ( int ) Math . Pow ( 10 , digits - 1 ) ; for ( int i = 0 ; i < digits - 1 ; i ++ ) { int firstDigit = num / powTen ;
int left = ( ( num * 10 ) + firstDigit ) - ( firstDigit * powTen * 10 ) ; Console . Write ( left + " ▁ " ) ;
num = left ; } }
static public void Main ( ) { int num = 1445 ; cal ( num ) ; } }
using System ; class GFG { static void CheckKCycles ( int n , String s ) { bool ff = true ; int x = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
x = ( s . Substring ( i ) + s . Substring ( 0 , i ) ) . Length ;
if ( x >= s . Length ) { continue ; } ff = false ; break ; } if ( ff ) { Console . WriteLine ( " Yes " ) ; } else { Console . WriteLine ( " No " ) ; } }
public static void Main ( String [ ] args ) { int n = 3 ; String s = "123" ; CheckKCycles ( n , s ) ; } }
static bool rightRotationDivisor ( int N ) { int lastDigit = N % 10 ; int rightRotation = ( int ) ( lastDigit * Math . Pow ( 10 , ( int ) ( Math . Log10 ( N ) ) ) + Math . Floor ( ( double ) N / 10 ) ) ; return ( rightRotation % N == 0 ) ; }
static void generateNumbers ( int m ) { for ( int i = ( int ) Math . Pow ( 10 , ( m - 1 ) ) ; i < Math . Pow ( 10 , m ) ; i ++ ) if ( rightRotationDivisor ( i ) ) Console . WriteLine ( i ) ; }
public static void Main ( ) { int m = 3 ; generateNumbers ( m ) ; } }
static void checkIfSortRotated ( int [ ] arr , int n ) { int minEle = int . MaxValue ; int maxEle = int . MinValue ; int minIndex = - 1 ;
for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < minEle ) { minEle = arr [ i ] ; minIndex = i ; } } bool flag1 = true ;
for ( int i = 1 ; i < minIndex ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag1 = false ; break ; } } bool flag2 = true ;
for ( int i = minIndex + 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag2 = false ; break ; } }
if ( flag1 && flag2 && ( arr [ n - 1 ] < arr [ 0 ] ) ) Console . WriteLine ( " YES " ) ; else Console . WriteLine ( " NO " ) ; }
public static void Main ( ) { int [ ] arr = { 3 , 4 , 5 , 1 , 2 } ; int n = arr . Length ;
checkIfSortRotated ( arr , n ) ; } }
static void occurredOnce ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
if ( arr [ 0 ] != arr [ 1 ] ) Console . Write ( arr [ 0 ] + " ▁ " ) ;
for ( int i = 1 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i - 1 ] ) Console . Write ( arr [ i ] + " ▁ " ) ;
if ( arr [ n - 2 ] != arr [ n - 1 ] ) Console . Write ( arr [ n - 1 ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = arr . Length ; occurredOnce ( arr , n ) ; } }
static void occurredOnce ( int [ ] arr , int n ) { int i = 1 , len = n ;
if ( arr [ 0 ] == arr [ len - 1 ] ) { i = 2 ; len -- ; }
for ( ; i < n ; i ++ )
if ( arr [ i ] == arr [ i - 1 ] ) i ++ ;
else Console . ( arr [ i - 1 ] + " ▁ " ) ;
if ( arr [ n - 1 ] != arr [ 0 ] && arr [ n - 1 ] != arr [ n - 2 ] ) Console . Write ( arr [ n - 1 ] ) ; }
public static void Main ( ) { int [ ] arr = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = arr . Length ; occurredOnce ( arr , n ) ; } }
static void rvereseArray ( int [ ] arr , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
static void splitArr ( int [ ] arr , int k , int n ) { rvereseArray ( arr , 0 , n - 1 ) ; rvereseArray ( arr , 0 , n - k - 1 ) ; rvereseArray ( arr , n - k , n - 1 ) ; }
public static void Main ( ) { int [ ] arr = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = arr . Length ; int k = 2 ;
splitArr ( arr , k , n ) ; printArray ( arr , n ) ; } }
static int countRotationsDivBy8 ( String n ) { int len = n . Length ; int count = 0 ;
if ( len == 1 ) { int oneDigit = n [ 0 ] - '0' ; if ( oneDigit % 8 == 0 ) return 1 ; return 0 ; }
if ( len == 2 ) {
int first = ( n [ 0 ] - '0' ) * 10 + ( n [ 1 ] - '0' ) ;
int second = ( n [ 1 ] - '0' ) * 10 + ( n [ 0 ] - '0' ) ; if ( first % 8 == 0 ) count ++ ; if ( second % 8 == 0 ) count ++ ; return count ; }
int threeDigit ; for ( int i = 0 ; i < ( len - 2 ) ; i ++ ) { threeDigit = ( n [ i ] - '0' ) * 100 + ( n [ i + 1 ] - '0' ) * 10 + ( n [ i + 2 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ; }
threeDigit = ( n [ len - 1 ] - '0' ) * 100 + ( n [ 0 ] - '0' ) * 10 + ( n [ 1 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
threeDigit = ( n [ len - 2 ] - '0' ) * 100 + ( n [ len - 1 ] - '0' ) * 10 + ( n [ 0 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
return count ; }
public static void Main ( ) { String n = "43262488612" ; Console . Write ( " Rotations : ▁ " + countRotationsDivBy8 ( n ) ) ; } }
static int findRotations ( String str ) {
String tmp = str + str ; int n = str . Length ; for ( int i = 1 ; i <= n ; i ++ ) {
String substring = tmp . Substring ( i , str . Length ) ;
if ( str == substring ) return i ; } return n ; }
public static void Main ( ) { String str = " abc " ; Console . Write ( findRotations ( str ) ) ; } }
static bool isRotation ( long x , long y ) {
long x64 = x | ( x << 32 ) ; while ( x64 >= y ) {
if ( x64 == y ) { return true ; }
x64 >>= 1 ; } return false ; }
public static void Main ( ) { long x = 122 ; long y = 2147483678L ; if ( isRotation ( x , y ) == false ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " No " ) ; } } }
static int countRotations ( String n ) { int len = n . Length ;
if ( len == 1 ) { int oneDigit = n [ 0 ] - '0' ; if ( oneDigit % 4 == 0 ) return 1 ; return 0 ; }
int twoDigit , count = 0 ; for ( int i = 0 ; i < ( len - 1 ) ; i ++ ) { twoDigit = ( n [ i ] - '0' ) * 10 + ( n [ i + 1 ] - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; }
twoDigit = ( n [ len - 1 ] - '0' ) * 10 + ( n [ 0 ] - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; return count ; }
public static void Main ( ) { String n = "4834" ; Console . Write ( " Rotations : ▁ " + countRotations ( n ) ) ; } }
static int solve ( int [ ] A , int n ) { int i , cnt = 0 , j ;
int [ ] parent = new int [ n + 1 ] ;
int [ ] vis = new int [ n + 1 ] ;
for ( i = 0 ; i < n + 1 ; i ++ ) { parent [ i ] = - 1 ; vis [ i ] = 0 ; } for ( i = 0 ; i < n ; i ++ ) { j = i ;
if ( parent [ j ] == - 1 ) {
while ( parent [ j ] == - 1 ) { parent [ j ] = i ; j = ( j + A [ j ] + 1 ) % n ; }
if ( parent [ j ] == i ) {
while ( vis [ j ] == 0 ) { vis [ j ] = 1 ; cnt ++ ; j = ( j + A [ j ] + 1 ) % n ; } } } } return cnt ; }
public static void Main ( ) { int [ ] A = { 0 , 0 , 0 , 2 } ; int n = A . Length ; Console . WriteLine ( solve ( A , n ) ) ; } }
void TOWUtil ( int [ ] arr , int n , Boolean [ ] curr_elements , int no_of_selected_elements , Boolean [ ] soln , int sum , int curr_sum , int curr_position ) {
if ( curr_position == n ) return ;
if ( ( n / 2 - no_of_selected_elements ) > ( n - curr_position ) ) return ;
TOWUtil ( arr , n , curr_elements , no_of_selected_elements , soln , sum , curr_sum , curr_position + 1 ) ;
no_of_selected_elements ++ ; curr_sum = curr_sum + arr [ curr_position ] ; curr_elements [ curr_position ] = true ;
if ( no_of_selected_elements == n / 2 ) {
if ( Math . Abs ( sum / 2 - curr_sum ) < min_diff ) { min_diff = Math . Abs ( sum / 2 - curr_sum ) ; for ( int i = 0 ; i < n ; i ++ ) soln [ i ] = curr_elements [ i ] ; } } else {
TOWUtil ( arr , n , curr_elements , no_of_selected_elements , soln , sum , curr_sum , curr_position + 1 ) ; }
curr_elements [ curr_position ] = false ; }
void tugOfWar ( int [ ] arr ) { int n = arr . Length ;
Boolean [ ] curr_elements = new Boolean [ n ] ;
Boolean [ ] soln = new Boolean [ n ] ; min_diff = int . MaxValue ; int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum += arr [ i ] ; curr_elements [ i ] = soln [ i ] = false ; }
TOWUtil ( arr , n , curr_elements , 0 , soln , sum , 0 , 0 ) ;
Console . Write ( " The ▁ first ▁ subset ▁ is : ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( soln [ i ] == true ) Console . Write ( arr [ i ] + " ▁ " ) ; } Console . Write ( " STRNEWLINE The ▁ second ▁ subset ▁ is : ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( soln [ i ] == false ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void Main ( String [ ] args ) { int [ ] arr = { 23 , 45 , - 34 , 12 , 0 , 98 , - 99 , 4 , 189 , - 1 , 4 } ; GFG a = new GFG ( ) ; a . tugOfWar ( arr ) ; } }
using System ; class GFG { static int INF = int . MaxValue , N = 4 ;
static int minCost ( int [ , ] cost ) {
int [ ] dist = new int [ N ] ; for ( int i = 0 ; i < N ; i ++ ) dist [ i ] = INF ; dist [ 0 ] = 0 ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( dist [ j ] > dist [ i ] + cost [ i , j ] ) dist [ j ] = dist [ i ] + cost [ i , j ] ; return dist [ N - 1 ] ; }
public static void Main ( ) { int [ , ] cost = { { 0 , 15 , 80 , 90 } , { INF , 0 , 40 , 50 } , { INF , INF , 0 , 70 } , { INF , INF , INF , 0 } } ; Console . WriteLine ( " The ▁ Minimum ▁ cost ▁ to " + " ▁ reach ▁ station ▁ " + N + " ▁ is ▁ " + minCost ( cost ) ) ; } }
static int numOfways ( int n , int k ) { int p = 1 ; if ( k % 2 != 0 ) p = - 1 ; return ( int ) ( Math . Pow ( n - 1 , k ) + p * ( n - 1 ) ) / n ; }
static void Main ( ) { int n = 4 , k = 2 ; Console . Write ( numOfways ( n , k ) ) ; } }
using System ; class GfG {
static int power ( int n ) { if ( n == 1 ) return 2 ; return 2 * power ( n - 1 ) ; }
public static void Main ( ) { int n = 4 ; Console . WriteLine ( power ( n ) ) ; } }
static int size = 4 ;
static bool checkStar ( int [ , ] mat ) {
int vertexD1 = 0 , vertexDn_1 = 0 ;
if ( size == 1 ) return ( mat [ 0 , 0 ] == 0 ) ;
if ( size == 2 ) return ( mat [ 0 , 0 ] == 0 && mat [ 0 , 1 ] == 1 && mat [ 1 , 0 ] == 1 && mat [ 1 , 1 ] == 0 ) ;
for ( int i = 0 ; i < size ; i ++ ) { int degreeI = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( mat [ i , j ] == 1 ) degreeI ++ ; if ( degreeI == 1 ) vertexD1 ++ ; else if ( degreeI == size - 1 ) vertexDn_1 ++ ; } return ( vertexD1 == ( size - 1 ) && vertexDn_1 == 1 ) ; }
static void Main ( ) { int [ , ] mat = new int [ 4 , 4 ] { { 0 , 1 , 1 , 1 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } } ; if ( checkStar ( mat ) ) Console . Write ( " Star ▁ Graph " ) ; else Console . Write ( " Not ▁ a ▁ Star ▁ Graph " ) ; } }
static int fib ( int n ) { if ( n <= 1 ) return n ; return fib ( n - 1 ) + fib ( n - 2 ) ; }
static int findVertices ( int n ) {
return fib ( n + 2 ) ; }
static void Main ( ) { int n = 3 ; Console . Write ( findVertices ( n ) ) ; } }
static bool check ( int [ ] degree , int n ) {
int deg_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { deg_sum += degree [ i ] ; }
return ( 2 * ( n - 1 ) == deg_sum ) ; }
public static void Main ( ) { int n = 5 ; int [ ] degree = { 2 , 3 , 1 , 1 , 1 } ; if ( check ( degree , n ) ) { Console . WriteLine ( " Tree " ) ; } else { Console . WriteLine ( " Graph " ) ; } } }
static bool isInorder ( int [ ] arr , int n ) {
if ( n == 0 n == 1 ) { return true ; }
for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i - 1 ] > arr [ i ] ) { return false ; } }
return true ; }
public static void Main ( ) { int [ ] arr = { 19 , 23 , 25 , 30 , 45 } ; int n = arr . Length ; if ( isInorder ( arr , n ) ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " Non " ) ; } } }
static bool isLeaf ( int [ ] pre , int n , int min , int max ) { if ( i >= n ) { return false ; } if ( pre [ i ] > min && pre [ i ] < max ) { i ++ ; bool left = isLeaf ( pre , n , min , pre [ i - 1 ] ) ; bool right = isLeaf ( pre , n , pre [ i - 1 ] , max ) ; if ( ! left && ! right ) { Console . Write ( pre [ i - 1 ] + " ▁ " ) ; } return true ; } return false ; } static void printLeaves ( int [ ] preorder , int n ) { isLeaf ( preorder , n , int . MinValue , int . MaxValue ) ; }
public static void Main ( String [ ] args ) { int [ ] preorder = { 890 , 325 , 290 , 530 , 965 } ; int n = preorder . Length ; printLeaves ( preorder , n ) ; } }
static void pairs ( int [ ] arr , int n , int k ) {
int smallest = 0 ; int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
if ( Math . Abs ( arr [ i ] + arr [ j ] - k ) < smallest ) { smallest = Math . Abs ( arr [ i ] + arr [ j ] - k ) ; count = 1 ; }
else if ( Math . Abs ( arr [ i ] + arr [ j ] - k ) == smallest ) ++ ; }
Console . WriteLine ( " Minimal ▁ Value ▁ = ▁ " + smallest ) ; Console . WriteLine ( " Total ▁ Pairs ▁ = ▁ " + count ) ; }
public static void Main ( ) { int [ ] arr = { 3 , 5 , 7 , 5 , 1 , 9 , 9 } ; int k = 12 ; int n = arr . Length ; pairs ( arr , n , k ) ; } }
public static void Main ( ) { int [ ] a = { 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 } ; int key = 20 ; int arraySize = a . Length ; int count = 0 ; for ( int i = 0 ; i < arraySize ; i ++ ) { if ( a [ i ] <= key ) { count += 1 ; } } Console . WriteLine ( " Rank ▁ of ▁ " + key + " ▁ in ▁ stream ▁ is : ▁ " + ( count - 1 ) ) ; } }
using System ; class GFG { static int MAX = 100 ; static void middlesum ( int [ , ] mat , int n ) { int row_sum = 0 , col_sum = 0 ;
for ( int i = 0 ; i < n ; i ++ ) row_sum += mat [ n / 2 , i ] ; Console . WriteLine ( " Sum ▁ of ▁ middle ▁ row ▁ = ▁ " + row_sum ) ;
for ( int i = 0 ; i < n ; i ++ ) col_sum += mat [ i , n / 2 ] ; Console . WriteLine ( " Sum ▁ of ▁ middle ▁ column ▁ = ▁ " + col_sum ) ; }
public static void Main ( ) { int [ , ] mat = { { 2 , 5 , 7 } , { 3 , 7 , 2 } , { 5 , 6 , 9 } } ; middlesum ( mat , 3 ) ; } }
static int M = 3 ; static int N = 3 ;
static void rotateMatrix ( int [ , ] matrix , int k ) {
int [ ] temp = new int [ M ] ;
k = k % M ; for ( int i = 0 ; i < N ; i ++ ) {
for ( int t = 0 ; t < M - k ; t ++ ) temp [ t ] = matrix [ i , t ] ;
for ( int j = M - k ; j < M ; j ++ ) matrix [ i , j - M + k ] = matrix [ i , j ] ;
for ( int j = k ; j < M ; j ++ ) matrix [ i , j ] = temp [ j - k ] ; } }
static void displayMatrix ( int [ , ] matrix ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) Console . Write ( matrix [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] matrix = { { 12 , 23 , 34 } , { 45 , 56 , 67 } , { 78 , 89 , 91 } } ; int k = 2 ;
rotateMatrix ( matrix , k ) ;
displayMatrix ( matrix ) ; } }
using System ; class GFG { static int N = 3 ;
static void multiply ( int [ , ] mat , int [ , ] res ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) { res [ i , j ] = 0 ; for ( int k = 0 ; k < N ; k ++ ) res [ i , j ] += mat [ i , k ] * mat [ k , j ] ; } } }
static bool InvolutoryMatrix ( int [ , ] mat ) { int [ , ] res = new int [ N , N ] ;
multiply ( mat , res ) ; for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) { if ( i == j && res [ i , j ] != 1 ) return false ; if ( i != j && res [ i , j ] != 0 ) return false ; } } return true ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 0 , 0 } , { 0 , - 1 , 0 } , { 0 , 0 , - 1 } } ;
if ( InvolutoryMatrix ( mat ) ) Console . WriteLine ( " Involutory ▁ Matrix " ) ; else Console . WriteLine ( " Not ▁ Involutory ▁ Matrix " ) ; } }
using System ; class GFG { public static void interchangeFirstLast ( int [ ] [ ] m ) { int rows = m . Length ;
for ( int i = 0 ; i < m [ 0 ] . Length ; i ++ ) { int t = m [ 0 ] [ i ] ; m [ 0 ] [ i ] = m [ rows - 1 ] [ i ] ; m [ rows - 1 ] [ i ] = t ; } }
int [ ] [ ] m = new int [ ] [ ] { new int [ ] { 8 , 9 , 7 , 6 } , new int [ ] { 4 , 7 , 6 , 5 } , new int [ ] { 3 , 2 , 1 , 8 } , new int [ ] { 9 , 9 , 7 , 7 } } ; interchangeFirstLast ( m ) ;
for ( int i = 0 ; i < m . Length ; i ++ ) { for ( int j = 0 ; j < m [ 0 ] . Length ; j ++ ) { Console . Write ( m [ i ] [ j ] + " ▁ " ) ; } Console . WriteLine ( ) ; } } }
using System ; class GFG { static bool checkMarkov ( double [ , ] m ) {
for ( int i = 0 ; i < m . GetLength ( 0 ) ; i ++ ) {
double sum = 0 ; for ( int j = 0 ; j < m . GetLength ( 1 ) ; j ++ ) sum = sum + m [ i , j ] ; if ( sum != 1 ) return false ; } return true ; }
double [ , ] m = new double [ , ] { { 0 , 0 , 1 } , { 0.5 , 0 , 0.5 } , { 1 , 0 , 0 } } ;
if ( checkMarkov ( m ) ) Console . WriteLine ( " ▁ yes ▁ " ) ; else Console . WriteLine ( " ▁ no ▁ " ) ; } }
using System ; class GFG { static int N = 4 ;
static bool isDiagonalMatrix ( int [ , ] mat ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ )
if ( ( i != j ) && ( mat [ i , j ] != 0 ) ) return false ; return true ; }
public static void Main ( ) { int [ , ] mat = { { 4 , 0 , 0 , 0 } , { 0 , 7 , 0 , 0 } , { 0 , 0 , 5 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isDiagonalMatrix ( mat ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG { static int N = 4 ;
static bool isScalarMatrix ( int [ , ] mat ) {
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( ( i != j ) && ( mat [ i , j ] != 0 ) ) return false ;
for ( int i = 0 ; i < N - 1 ; i ++ ) if ( mat [ i , i ] != mat [ i + 1 , i + 1 ] ) return false ; return true ; }
public static void Main ( ) { int [ , ] mat = { { 2 , 0 , 0 , 0 } , { 0 , 2 , 0 , 0 } , { 0 , 0 , 2 , 0 } , { 0 , 0 , 0 , 2 } } ;
if ( isScalarMatrix ( mat ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG {
static void sortByRow ( int [ , ] mat , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n - 1 ; j ++ ) { if ( mat [ i , j ] > mat [ i , j + 1 ] ) { var temp = mat [ i , j ] ; mat [ i , j ] = mat [ i , j + 1 ] ; mat [ i , j + 1 ] = temp ; } } } }
static void transpose ( int [ , ] mat , int n ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
var temp = mat [ i , j ] ; mat [ i , j ] = mat [ j , i ] ; mat [ j , i ] = temp ; } }
static void sortMatRowAndColWise ( int [ , ] mat , int n ) {
sortByRow ( mat , n ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n ) ;
transpose ( mat , n ) ; }
static void printMat ( int [ , ] mat , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) Console . Write ( mat [ i , j ] + " ▁ " ) ; Console . Write ( " STRNEWLINE " ) ; } }
public static void Main ( ) { int [ , ] mat = { { 4 , 1 , 3 } , { 9 , 6 , 8 } , { 5 , 2 , 7 } } ; int n = 3 ; Console . Write ( " Original ▁ Matrix : STRNEWLINE " ) ; printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; Console . Write ( " STRNEWLINE Matrix ▁ After ▁ Sorting : STRNEWLINE " ) ; printMat ( mat , n ) ; } }
public static void doublyEven ( int n ) { int [ , ] arr = new int [ n , n ] ; int i , j ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) { arr [ i , j ] = ( n * i ) + j + 1 ; } }
for ( i = 0 ; i < n / 4 ; i ++ ) { for ( j = 0 ; j < n / 4 ; j ++ ) { arr [ i , j ] = ( n * n + 1 ) - arr [ i , j ] ; } }
for ( i = 0 ; i < n / 4 ; i ++ ) { for ( j = 3 * ( n / 4 ) ; j < n ; j ++ ) { arr [ i , j ] = ( n * n + 1 ) - arr [ i , j ] ; } }
for ( i = 3 * n / 4 ; i < n ; i ++ ) { for ( j = 0 ; j < n / 4 ; j ++ ) { arr [ i , j ] = ( n * n + 1 ) - arr [ i , j ] ; } }
for ( i = 3 * n / 4 ; i < n ; i ++ ) { for ( j = 3 * n / 4 ; j < n ; j ++ ) { arr [ i , j ] = ( n * n + 1 ) - arr [ i , j ] ; } }
for ( i = n / 4 ; i < 3 * n / 4 ; i ++ ) { for ( j = n / 4 ; j < 3 * n / 4 ; j ++ ) { arr [ i , j ] = ( n * n + 1 ) - arr [ i , j ] ; } }
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) { Console . Write ( arr [ i , j ] + " ▁ " + " ▁ " ) ; } Console . WriteLine ( ) ; } }
public static void Main ( string [ ] args ) { int n = 8 ;
doublyEven ( n ) ; } }
static bool isMagicSquare ( int [ , ] mat ) {
int sum = 0 , sum2 = 0 ; for ( int i = 0 ; i < N ; i ++ ) sum = sum + mat [ i , i ] ;
for ( int i = 0 ; i < N ; i ++ ) sum2 = sum2 + mat [ i , N - 1 - i ] ; if ( sum != sum2 ) return false ;
for ( int i = 0 ; i < N ; i ++ ) { int rowSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) rowSum += mat [ i , j ] ;
if ( rowSum != sum ) return false ; }
for ( int i = 0 ; i < N ; i ++ ) { int colSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) colSum += mat [ j , i ] ;
if ( sum != colSum ) return false ; } return true ; }
public static void Main ( ) { int [ , ] mat = new int [ , ] { { 2 , 7 , 6 } , { 9 , 5 , 1 } , { 4 , 3 , 8 } } ; if ( isMagicSquare ( mat ) ) Console . WriteLine ( " Magic ▁ Square " ) ; else Console . WriteLine ( " Not ▁ a ▁ magic " + " ▁ Square " ) ; } }
static int subCount ( int [ ] arr , int n , int k ) {
int [ ] mod = new int [ k ] ;
int cumSum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { cumSum += arr [ i ] ;
mod [ ( ( cumSum % k ) + k ) % k ] ++ ; }
int result = 0 ;
for ( int i = 0 ; i < k ; i ++ )
if ( mod [ i ] > 1 ) result += ( mod [ i ] * ( mod [ i ] - 1 ) ) / 2 ;
result += mod [ 0 ] ; return result ; }
static int countSubmatrix ( int [ , ] mat , int n , int k ) {
int tot_count = 0 ; int left , right , i ; int [ ] temp = new int [ n ] ;
for ( left = 0 ; left < n ; left ++ ) {
for ( right = left ; right < n ; right ++ ) {
for ( i = 0 ; i < n ; ++ i ) temp [ i ] += mat [ i , right ] ;
tot_count += subCount ( temp , n , k ) ; } }
return tot_count - 3 ; }
static void Main ( ) { int [ , ] mat = new int [ , ] { { 5 , - 1 , 6 } , { - 2 , 3 , 8 } , { 7 , 4 , - 9 } } ; int n = 3 , k = 4 ; Console . Write ( " Count = " countSubmatrix ( mat , n , k ) ) ; } }
using System ; public class GfG { public static int find ( int n , int k ) { if ( n + 1 >= k ) return ( k - 1 ) ; else return ( 2 * n + 1 - k ) ; }
public static void Main ( ) { int n = 4 , k = 7 ; int freq = find ( n , k ) ; if ( freq < 0 ) Console . WriteLine ( " ▁ element " + " ▁ not ▁ exist ▁ " ) ; else Console . WriteLine ( " ▁ Frequency " + " ▁ of ▁ " + k + " ▁ is ▁ " + freq ) ; } }
public static void ZigZag ( int rows , int columns , int [ ] numbers ) { int k = 0 ;
int [ , ] arr = new int [ rows , columns ] ; for ( int i = 0 ; i < rows ; i ++ ) {
if ( i % 2 == 0 ) {
for ( int j = 0 ; j < columns && numbers [ k ] > 0 ; j ++ ) {
arr [ i , j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } }
else {
for ( int j = columns - 1 ; j >= 0 && numbers [ k ] > 0 ; j -- ) {
arr [ i , j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } } }
for ( int i = 0 ; i < rows ; i ++ ) { for ( int j = 0 ; j < columns ; j ++ ) Console . Write ( arr [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int rows = 4 ; int columns = 5 ; int [ ] Numbers = new int [ ] { 3 , 4 , 2 , 2 , 3 , 1 , 5 } ; ZigZag ( rows , columns , Numbers ) ; } }
static int numberofPosition ( int n , int k , int x , int y , int [ ] obstPosx , int [ ] obstPosy ) {
int d11 , d12 , d21 , d22 , r1 , r2 , c1 , c2 ;
d11 = Math . Min ( x - 1 , y - 1 ) ; d12 = Math . Min ( n - x , n - y ) ; d21 = Math . Min ( n - x , y - 1 ) ; d22 = Math . Min ( x - 1 , n - y ) ; r1 = y - 1 ; r2 = n - y ; c1 = x - 1 ; c2 = n - x ;
for ( int i = 0 ; i < k ; i ++ ) { if ( x > obstPosx [ i ] && y > obstPosy [ i ] && x - obstPosx [ i ] == y - obstPosy [ i ] ) d11 = Math . Min ( d11 , x - obstPosx [ i ] - 1 ) ; if ( obstPosx [ i ] > x && obstPosy [ i ] > y && obstPosx [ i ] - x == obstPosy [ i ] - y ) d12 = Math . Min ( d12 , obstPosx [ i ] - x - 1 ) ; if ( obstPosx [ i ] > x && y > obstPosy [ i ] && obstPosx [ i ] - x == y - obstPosy [ i ] ) d21 = Math . Min ( d21 , obstPosx [ i ] - x - 1 ) ; if ( x > obstPosx [ i ] && obstPosy [ i ] > y && x - obstPosx [ i ] == obstPosy [ i ] - y ) d22 = Math . Min ( d22 , x - obstPosx [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] < y ) r1 = Math . Min ( r1 , y - obstPosy [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] > y ) r2 = Math . Min ( r2 , obstPosy [ i ] - y - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] < x ) c1 = Math . Min ( c1 , x - obstPosx [ i ] - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] > x ) c2 = Math . Min ( c2 , obstPosx [ i ] - x - 1 ) ; } return d11 + d12 + d21 + d22 + r1 + r2 + c1 + c2 ; }
int n = 8 ;
int k = 1 ;
int Qposx = 4 ;
int Qposy = 4 ;
int [ ] obstPosx = { 3 } ;
int [ ] obstPosy = { 5 } ; Console . WriteLine ( numberofPosition ( n , k , Qposx , Qposy , obstPosx , obstPosy ) ) ; } }
using System ; public class GFG { static int n = 5 ;
static int FindMaxProduct ( int [ , ] arr , int n ) { int max = 0 , result ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = 0 ; j < n ; j ++ ) {
if ( ( j - 3 ) >= 0 ) { result = arr [ i , j ] * arr [ i , j - 1 ] * arr [ i , j - 2 ] * arr [ i , j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 ) { result = arr [ i , j ] * arr [ i - 1 , j ] * arr [ i - 2 , j ] * arr [ i - 3 , j ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 3 ) >= 0 ) { result = arr [ i , j ] * arr [ i - 1 , j - 1 ] * arr [ i - 2 , j - 2 ] * arr [ i - 3 , j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 1 ) <= 0 ) { result = arr [ i , j ] * arr [ i - 1 , j + 1 ] * arr [ i - 2 , j + 2 ] * arr [ i - 3 , j + 3 ] ; if ( max < result ) max = result ; } } } return max ; }
static public void Main ( ) { int [ , ] arr = { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 1 } , { 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 1 , 0 } , { 9 , 6 , 4 , 2 , 3 } } ; Console . Write ( FindMaxProduct ( arr , n ) ) ; } }
using System ; class GFG {
static int minimumflip ( int [ , ] mat , int n ) { int [ , ] transpose = new int [ n , n ] ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) transpose [ i , j ] = mat [ j , i ] ;
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( transpose [ i , j ] != mat [ i , j ] ) flip ++ ; return flip / 2 ; }
public static void Main ( ) { int n = 3 ; int [ , ] mat = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; Console . WriteLine ( minimumflip ( mat , n ) ) ; } }
using System ; class GFG {
static int minimumflip ( int [ , ] mat , int n ) {
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i , j ] != mat [ j , i ] ) flip ++ ; return flip ; }
public static void Main ( ) { int n = 3 ; int [ , ] mat = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; Console . WriteLine ( minimumflip ( mat , n ) ) ; } }
using System ; class Lower_triangular { int N = 4 ;
bool isLowerTriangularMatrix ( int [ , ] mat ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( mat [ i , j ] != 0 ) return false ; return true ; }
public static void Main ( ) { Lower_triangular ob = new Lower_triangular ( ) ; int [ , ] mat = { { 1 , 0 , 0 , 0 } , { 1 , 4 , 0 , 0 } , { 4 , 6 , 2 , 0 } , { 0 , 4 , 7 , 6 } } ;
if ( ob . isLowerTriangularMatrix ( mat ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; public class GfG { private static int N = 4 ;
public static bool isUpperTriangularMatrix ( int [ , ] mat ) { for ( int i = 1 ; i < N ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i , j ] != 0 ) return false ; return true ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 3 , 5 , 3 } , { 0 , 4 , 6 , 2 } , { 0 , 0 , 2 , 5 } , { 0 , 0 , 0 , 6 } } ; if ( isUpperTriangularMatrix ( mat ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG { static int MAX = 100 ;
static void freq ( int [ , ] ar , int m , int n ) { int even = 0 , odd = 0 ; for ( int i = 0 ; i < m ; ++ i ) { for ( int j = 0 ; j < n ; ++ j ) {
if ( ( ar [ i , j ] % 2 ) == 0 ) ++ even ; else ++ odd ; } }
Console . WriteLine ( " ▁ Frequency ▁ of ▁ odd ▁ number ▁ = " + odd ) ; Console . WriteLine ( " ▁ Frequency ▁ of ▁ even ▁ number ▁ = ▁ " + even ) ; }
public static void Main ( ) { int m = 3 , n = 3 ; int [ , ] array = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; freq ( array , m , n ) ; } }
using System ; class GFG {
static bool HalfDiagonalSums ( int [ , ] mat , int n ) {
int diag1_left = 0 , diag1_right = 0 ; int diag2_left = 0 , diag2_right = 0 ; for ( int i = 0 , j = n - 1 ; i < n ; i ++ , j -- ) { if ( i < n / 2 ) { diag1_left += mat [ i , i ] ; diag2_left += mat [ j , i ] ; } else if ( i > n / 2 ) { diag1_right += mat [ i , i ] ; diag2_right += mat [ j , i ] ; } } return ( diag1_left == diag2_right && diag2_right == diag2_left && diag1_right == diag2_left && diag2_right == mat [ n / 2 , n / 2 ] ) ; }
static public void Main ( ) { int [ , ] a = { { 2 , 9 , 1 , 4 , - 2 } , { 6 , 7 , 2 , 11 , 4 } , { 4 , 2 , 9 , 2 , 4 } , { 1 , 9 , 2 , 4 , 4 } , { 0 , 2 , 4 , 2 , 5 } } ; Console . WriteLine ( HalfDiagonalSums ( a , 5 ) ? " Yes " : " No " ) ; } }
using System ; class GFG { int MAX = 100 ; static bool isIdentity ( int [ , ] mat , int N ) { for ( int row = 0 ; row < N ; row ++ ) { for ( int col = 0 ; col < N ; col ++ ) { if ( row == col && mat [ row , col ] != 1 ) return false ; else if ( row != col && mat [ row , col ] != 0 ) return false ; } } return true ; }
public static void Main ( ) { int N = 4 ; int [ , ] mat = { { 1 , 0 , 0 , 0 } , { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isIdentity ( mat , N ) ) Console . WriteLine ( " Yes ▁ " ) ; else Console . WriteLine ( " No ▁ " ) ; } }
using System ; class Example { static long mod = 100000007 ;
static long modPower ( long a , long t , long mod ) { long now = a , ret = 1 ;
while ( t > 0 ) { if ( t % 2 == 1 ) ret = now * ( ret % mod ) ; now = now * ( now % mod ) ; t >>= 1 ; } return ret ; }
static long countWays ( int n , int m , int k ) {
if ( n == 1 m == 1 ) return 1 ;
else if ( ( n + m ) % 2 == 1 && k == - 1 ) return 0 ;
return ( modPower ( modPower ( ( long ) 2 , n - 1 , mod ) , m - 1 , mod ) % mod ) ; }
public static void Main ( ) { int n = 2 , m = 7 , k = 1 ; Console . WriteLine ( countWays ( n , m , k ) ) ; } }
using System ; class GFG { static int MAX = 100 ; static void imageSwap ( int [ , ] mat , int n ) {
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j <= i ; j ++ ) mat [ i , j ] = mat [ i , j ] + mat [ j , i ] - ( mat [ j , i ] = mat [ i , j ] ) ; }
static void printMatrix ( int [ , ] mat , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) Console . Write ( mat [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] mat = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; int n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ; } }
static int m = 3 ;
static int n = 2 ;
static long countSets ( int [ , ] a ) {
long res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < m ; j ++ ) { if ( a [ i , j ] == 1 ) u ++ ; else v ++ ; } res += ( long ) ( Math . Pow ( 2 , u ) - 1 + Math . Pow ( 2 , v ) ) - 1 ; }
for ( int i = 0 ; i < m ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < n ; j ++ ) { if ( a [ j , i ] == 1 ) u ++ ; else v ++ ; } res += ( long ) ( Math . Pow ( 2 , u ) - 1 + Math . Pow ( 2 , v ) ) - 1 ; }
return res - ( n * m ) ; }
public static void Main ( ) { int [ , ] a = { { 1 , 0 , 1 } , { 0 , 1 , 0 } } ; Console . WriteLine ( countSets ( a ) ) ; } }
static void fill0X ( int m , int n ) {
int i , k = 0 , l = 0 ;
int r = m , c = n ;
char x = ' X ' ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) a [ k , i ] = x ; k ++ ;
for ( i = k ; i < m ; ++ i ) a [ i , n - 1 ] = x ; n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) a [ m - 1 , i ] = x ; m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) a [ i , l ] = x ; l ++ ; }
x = ( x == '0' ) ? ' X ' : '0' ; }
for ( i = 0 ; i < r ; i ++ ) { for ( int j = 0 ; j < c ; j ++ ) Console . Write ( a [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { Console . WriteLine ( " Output ▁ for " + " ▁ m ▁ = ▁ 5 , ▁ n ▁ = ▁ 6" ) ; fill0X ( 5 , 6 ) ; Console . WriteLine ( " Output ▁ for " + " ▁ m ▁ = ▁ 4 , ▁ n ▁ = ▁ 4" ) ; fill0X ( 4 , 4 ) ; Console . WriteLine ( " Output ▁ for " + " ▁ m ▁ = ▁ 3 , ▁ n ▁ = ▁ 4" ) ; fill0X ( 3 , 4 ) ; } }
public static int calculateEnergy ( int [ , ] mat , int n ) { int i_des , j_des , q ; int tot_energy = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
q = mat [ i , j ] / n ;
i_des = q ; j_des = mat [ i , j ] - ( n * q ) ;
tot_energy += Math . Abs ( i_des - i ) + Math . Abs ( j_des - j ) ; } }
return tot_energy ; }
public static void Main ( ) { int [ , ] mat = new int [ , ] { { 4 , 7 , 0 , 3 } , { 8 , 5 , 6 , 1 } , { 9 , 11 , 10 , 2 } , { 15 , 13 , 14 , 12 } } ; int n = 4 ; Console . Write ( " Total ▁ energy ▁ required ▁ = ▁ " + calculateEnergy ( mat , n ) + " ▁ units " ) ; } }
using System ; public class GFG { static readonly int MAX = 100 ;
static bool isUnique ( int [ , ] mat , int i , int j , int n , int m ) {
int sumrow = 0 ; for ( int k = 0 ; k < m ; k ++ ) { sumrow += mat [ i , k ] ; if ( sumrow > 1 ) return false ; }
int sumcol = 0 ; for ( int k = 0 ; k < n ; k ++ ) { sumcol += mat [ k , j ] ; if ( sumcol > 1 ) return false ; } return true ; } static int countUnique ( int [ , ] mat , int n , int m ) { int uniquecount = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i , j ] != 0 && isUnique ( mat , i , j , n , m ) ) uniquecount ++ ; return uniquecount ; }
static public void Main ( ) { int [ , ] mat = { { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 1 , 0 , 0 , 1 } } ; Console . Write ( countUnique ( mat , 3 , 4 ) ) ; } }
using System ; class GFG { static bool isSparse ( int [ , ] array , int m , int n ) { int counter = 0 ;
for ( int i = 0 ; i < m ; ++ i ) for ( int j = 0 ; j < n ; ++ j ) if ( array [ i , j ] == 0 ) ++ counter ; return ( counter > ( ( m * n ) / 2 ) ) ; }
public static void Main ( ) { int [ , ] array = { { 1 , 0 , 3 } , { 0 , 0 , 4 } , { 6 , 0 , 0 } } ; int m = 3 , n = 3 ; if ( isSparse ( array , m , n ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG {
static int countCommon ( int [ , ] mat , int n ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( mat [ i , i ] == mat [ i , n - i - 1 ] ) res ++ ; return res ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; Console . WriteLine ( countCommon ( mat , 3 ) ) ; } }
static bool areSumSame ( int [ , ] a , int n , int m ) { int sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum1 = 0 ; sum2 = 0 ; for ( int j = 0 ; j < m ; j ++ ) { sum1 += a [ i , j ] ; sum2 += a [ j , i ] ; } if ( sum1 == sum2 ) return true ; } return false ; }
int n = 4 ;
int m = 4 ; int [ , ] M = { { 1 , 2 , 3 , 4 } , { 9 , 5 , 3 , 1 } , { 0 , 3 , 5 , 6 } , { 0 , 4 , 5 , 6 } } ; if ( areSumSame ( M , n , m ) == true ) Console . Write ( "1 STRNEWLINE " ) ; else Console . Write ( "0 STRNEWLINE " ) ; } }
using System ; class GFG { static int N = 4 ;
static void findMax ( int [ , ] arr ) { int row = 0 , i , j ; for ( i = 0 , j = N - 1 ; i < N ; i ++ ) {
while ( arr [ i , j ] == 1 && j >= 0 ) { row = i ; j -- ; } } Console . Write ( " Row ▁ number ▁ = ▁ " + ( row + 1 ) ) ; Console . Write ( " , ▁ MaxCount ▁ = ▁ " + ( N - 1 - j ) ) ; }
public static void Main ( ) { int [ , ] arr = { { 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 0 } , { 0 , 1 , 1 , 1 } } ; findMax ( arr ) ; } }
static void transpose ( int [ , ] mat , int [ , ] tr , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) tr [ i , j ] = mat [ j , i ] ; }
static bool isSymmetric ( int [ , ] mat , int N ) { int [ , ] tr = new int [ N , MAX ] ; transpose ( mat , tr , N ) ; for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i , j ] != tr [ i , j ] ) return false ; return true ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG {
static bool isSymmetric ( int [ , ] mat , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i , j ] != mat [ j , i ] ) return false ; return true ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " NO " ) ; } }
using System ; class GFG { static int n = 4 ; static int m = 4 ;
static int findPossibleMoves ( int [ , ] mat , int p , int q ) {
int [ ] X = { 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 } ; int [ ] Y = { 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 } ; int count = 0 ;
for ( int i = 0 ; i < 8 ; i ++ ) {
int x = p + X [ i ] ; int y = q + Y [ i ] ;
if ( x >= 0 && y >= 0 && x < n && y < m && mat [ x , y ] == 0 ) count ++ ; }
return count ; }
static public void Main ( ) { int [ , ] mat = { { 1 , 0 , 1 , 0 } , { 0 , 1 , 1 , 1 } , { 1 , 1 , 0 , 1 } , { 0 , 1 , 1 , 1 } } ; int p = 2 , q = 2 ; Console . WriteLine ( findPossibleMoves ( mat , p , q ) ) ; } }
using System ; public class GFG { static void printDiagonalSums ( int [ , ] mat , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) principal += mat [ i , j ] ;
if ( ( i + j ) == ( n - 1 ) ) secondary += mat [ i , j ] ; } } Console . WriteLine ( " Principal ▁ Diagonal : " + principal ) ; Console . WriteLine ( " Secondary ▁ Diagonal : " + secondary ) ; }
static public void Main ( ) { int [ , ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; } }
using System ; public class GFG { static void printDiagonalSums ( int [ , ] mat , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { principal += mat [ i , i ] ; secondary += mat [ i , n - i - 1 ] ; } Console . WriteLine ( " Principal ▁ Diagonal : " + principal ) ; Console . WriteLine ( " Secondary ▁ Diagonal : " + secondary ) ; }
static public void Main ( ) { int [ , ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; } }
using System ; class GFG { public static void printBoundary ( int [ , ] a , int m , int n ) { for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( i == 0 ) Console . Write ( a [ i , j ] + " ▁ " ) ; else if ( i == m - 1 ) Console . Write ( a [ i , j ] + " ▁ " ) ; else if ( j == 0 ) Console . Write ( a [ i , j ] + " ▁ " ) ; else if ( j == n - 1 ) Console . Write ( a [ i , j ] + " ▁ " ) ; else Console . Write ( " ▁ " ) ; } Console . WriteLine ( " ▁ " ) ; } }
static public void Main ( ) { int [ , ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printBoundary ( a , 4 , 4 ) ; } }
using System ; class GFG { public static long getBoundarySum ( int [ , ] a , int m , int n ) { long sum = 0 ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( i == 0 ) sum += a [ i , j ] ; else if ( i == m - 1 ) sum += a [ i , j ] ; else if ( j == 0 ) sum += a [ i , j ] ; else if ( j == n - 1 ) sum += a [ i , j ] ; } } return sum ; }
static public void Main ( ) { int [ , ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; long sum = getBoundarySum ( a , 4 , 4 ) ; Console . WriteLine ( " Sum ▁ of ▁ boundary " + " ▁ elements ▁ is ▁ " + sum ) ; } }
using System ; class GFG { static void printSpiral ( int [ , ] mat , int r , int c ) { int i , a = 0 , b = 2 ; int low_row = ( 0 > a ) ? 0 : a ; int low_column = ( 0 > b ) ? 0 : b - 1 ; int high_row = ( ( a + 1 ) >= r ) ? r - 1 : a + 1 ; int high_column = ( ( b + 1 ) >= c ) ? c - 1 : b + 1 ; while ( ( low_row > 0 - r && low_column > 0 - c ) ) { for ( i = low_column + 1 ; i <= high_column && i < c && low_row >= 0 ; ++ i ) Console . Write ( mat [ low_row , i ] + " ▁ " ) ; low_row -= 1 ; for ( i = low_row + 2 ; i <= high_row && i < r && high_column < c ; ++ i ) Console . Write ( mat [ i , high_column ] + " ▁ " ) ; high_column += 1 ; for ( i = high_column - 2 ; i >= low_column && i >= 0 && high_row < r ; -- i ) Console . Write ( mat [ high_row , i ] + " ▁ " ) ; high_row += 1 ; for ( i = high_row - 2 ; i > low_row && i >= 0 && low_column >= 0 ; -- i ) Console . Write ( mat [ i , low_column ] + " ▁ " ) ; low_column -= 1 ; } Console . WriteLine ( ) ; }
static public void Main ( ) { int [ , ] mat = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int r = 3 , c = 3 ;
printSpiral ( mat , r , c ) ; } }
using System ; public class GFG { public static int difference ( int [ , ] arr , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) d1 += arr [ i , j ] ;
if ( i == n - j - 1 ) d2 += arr [ i , j ] ; } }
return Math . Abs ( d1 - d2 ) ; }
public static void Main ( ) { int n = 3 ; int [ , ] arr = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , - 12 } } ; Console . Write ( difference ( arr , n ) ) ; } }
using System ; public class GFG { public static int difference ( int [ , ] arr , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { d1 += arr [ i , i ] ; d2 += arr [ i , n - i - 1 ] ; }
return Math . Abs ( d1 - d2 ) ; }
public static void Main ( ) { int n = 3 ; int [ , ] arr = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , - 12 } } ; Console . Write ( difference ( arr , n ) ) ; } }
static void spiralFill ( int m , int n , int [ , ] a ) {
int val = 1 ;
int k = 0 , l = 0 ; while ( k < m && l < n ) {
for ( int i = l ; i < n ; ++ i ) { a [ k , i ] = val ++ ; } k ++ ;
for ( int i = k ; i < m ; ++ i ) { a [ i , n - 1 ] = val ++ ; } n -- ;
if ( k < m ) { for ( int i = n - 1 ; i >= l ; -- i ) { a [ m - 1 , i ] = val ++ ; } m -- ; }
if ( l < n ) { for ( int i = m - 1 ; i >= k ; -- i ) { a [ i , l ] = val ++ ; } l ++ ; } } }
public static void Main ( ) { int m = 4 , n = 4 ; int [ , ] a = new int [ MAX , MAX ] ; spiralFill ( m , n , a ) ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { Console . Write ( a [ i , j ] + " ▁ " ) ; } Console . Write ( " STRNEWLINE " ) ; } } }
using System ; public class GFG {
static void maxMin ( int [ , ] arr , int n ) { int min = + 2147483647 ; int max = - 2147483648 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j <= n / 2 ; j ++ ) {
if ( arr [ i , j ] > arr [ i , n - j - 1 ] ) { if ( min > arr [ i , n - j - 1 ] ) min = arr [ i , n - j - 1 ] ; if ( max < arr [ i , j ] ) max = arr [ i , j ] ; } else { if ( min > arr [ i , j ] ) min = arr [ i , j ] ; if ( max < arr [ i , n - j - 1 ] ) max = arr [ i , n - j - 1 ] ; } } } Console . Write ( " Maximum ▁ = ▁ " + max + " , ▁ Minimum ▁ = ▁ " + min ) ; }
static public void Main ( ) { int [ , ] arr = { { 5 , 9 , 11 } , { 25 , 0 , 14 } , { 21 , 6 , 4 } } ; maxMin ( arr , 3 ) ; } }
static int findNormal ( int [ , ] mat , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i , j ] * mat [ i , j ] ; return ( int ) Math . Sqrt ( sum ) ; }
static int findTrace ( int [ , ] mat , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += mat [ i , i ] ; return sum ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; Console . Write ( " Trace ▁ of ▁ Matrix ▁ = ▁ " + findTrace ( mat , 5 ) + " STRNEWLINE " ) ; Console . Write ( " Normal ▁ of ▁ Matrix ▁ = ▁ " + findNormal ( mat , 5 ) ) ; } }
using System ; public class GFG { public const int N = 5 ; public const int M = 5 ;
public static int minOperation ( bool [ ] [ ] arr ) { int ans = 0 ; for ( int i = N - 1 ; i >= 0 ; i -- ) { for ( int j = M - 1 ; j >= 0 ; j -- ) {
if ( arr [ i ] [ j ] == false ) {
ans ++ ;
for ( int k = 0 ; k <= i ; k ++ ) { for ( int h = 0 ; h <= j ; h ++ ) {
if ( arr [ k ] [ h ] == true ) { arr [ k ] [ h ] = false ; } else { arr [ k ] [ h ] = true ; } } } } } } return ans ; }
public static void Main ( string [ ] args ) { bool [ ] [ ] mat = new bool [ ] [ ] { new bool [ ] { false , false , true , true , true } , new bool [ ] { false , false , false , true , true } , new bool [ ] { false , false , false , true , true } , new bool [ ] { true , true , true , true , true } , new bool [ ] { true , true , true , true , true } } ; Console . WriteLine ( minOperation ( mat ) ) ; } }
static int findSum ( int n ) { int ans = 0 , temp = 0 , num ;
for ( int i = 1 ; i <= n && temp < n ; i ++ ) {
temp = i - 1 ;
num = 1 ; while ( temp < n ) { if ( temp + i <= n ) ans += ( i * num ) ; else ans += ( ( n - temp ) * num ) ; temp += i ; num ++ ; } } return ans ; }
public static void Main ( ) { int N = 2 ; Console . WriteLine ( findSum ( N ) ) ; } }
using System ; class GFG { static int countOps ( int [ , ] A , int [ , ] B , int m , int n ) {
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) A [ i , j ] -= B [ i , j ] ;
for ( int i = 1 ; i < n ; i ++ ) for ( int j = 1 ; j < m ; j ++ ) if ( A [ i , j ] - A [ i , 0 ] - A [ 0 , j ] + A [ 0 , 0 ] != 0 ) return - 1 ;
int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) result += Math . Abs ( A [ i , 0 ] ) ; for ( int j = 0 ; j < m ; j ++ ) result += Math . Abs ( A [ 0 , j ] - A [ 0 , 0 ] ) ; return ( result ) ; }
public static void Main ( ) { int [ , ] A = { { 1 , 1 , 1 } , { 1 , 1 , 1 } , { 1 , 1 , 1 } } ; int [ , ] B = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; Console . Write ( countOps ( A , B , 3 , 3 ) ) ; } }
static void printCoils ( int n ) {
int m = 8 * n * n ;
int [ ] coil1 = new int [ m ] ;
coil1 [ 0 ] = 8 * n * n + 2 * n ; int curr = coil1 [ 0 ] ; int nflg = 1 , step = 2 ;
int index = 1 ; while ( index < m ) {
for ( int i = 0 ; i < step ; i ++ ) {
curr = coil1 [ index ++ ] = ( curr - 4 * n * nflg ) ; if ( index >= m ) break ; } if ( index >= m ) break ;
for ( int i = 0 ; i < step ; i ++ ) { curr = coil1 [ index ++ ] = curr + nflg ; if ( index >= m ) break ; } nflg = nflg * ( - 1 ) ; step += 2 ; }
int [ ] coil2 = new int [ m ] ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) coil2 [ i ] = 16 * n * n + 1 - coil1 [ i ] ;
Console . Write ( " Coil ▁ 1 ▁ : ▁ " ) ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) Console . Write ( coil1 [ i ] + " ▁ " ) ; Console . Write ( " STRNEWLINE Coil ▁ 2 ▁ : ▁ " ) ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) Console . Write ( coil2 [ i ] + " ▁ " ) ; }
public static void Main ( ) { int n = 1 ; printCoils ( n ) ; } }
static int findSum ( int n ) {
int [ , ] arr = new int [ n , n ] ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) arr [ i , j ] = Math . Abs ( i - j ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += arr [ i , j ] ; return sum ; }
static public void Main ( String [ ] args ) { int n = 3 ; Console . WriteLine ( findSum ( n ) ) ; } }
static int findSum ( int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += i * ( n - i ) ; return 2 * sum ; }
static public void Main ( String [ ] args ) { int n = 3 ; Console . WriteLine ( findSum ( n ) ) ; } }
static int findSum ( int n ) { n -- ; int sum = 0 ; sum += ( n * ( n + 1 ) ) / 2 ; sum += ( n * ( n + 1 ) * ( 2 * n + 1 ) ) / 6 ; return sum ; }
static public void Main ( String [ ] args ) { int n = 3 ; Console . WriteLine ( findSum ( n ) ) ; } }
using System ; public class GFG { static void checkHV ( int [ , ] arr , int N , int M ) {
bool horizontal = true ; bool vertical = true ;
for ( int i = 0 , k = N - 1 ; i < N / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < M ; j ++ ) {
if ( arr [ i , j ] != arr [ k , j ] ) { horizontal = false ; break ; } } }
for ( int i = 0 , k = M - 1 ; i < M / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < N ; j ++ ) {
if ( arr [ i , j ] != arr [ k , j ] ) { horizontal = false ; break ; } } } if ( ! horizontal && ! vertical ) Console . WriteLine ( " NO " ) ; else if ( horizontal && ! vertical ) Console . WriteLine ( " HORIZONTAL " ) ; else if ( vertical && ! horizontal ) Console . WriteLine ( " VERTICAL " ) ; else Console . WriteLine ( " BOTH " ) ; }
static public void Main ( ) { int [ , ] mat = { { 1 , 0 , 1 } , { 0 , 0 , 0 } , { 1 , 0 , 1 } } ; checkHV ( mat , 3 , 3 ) ; } }
static int maxDet ( int n ) { return ( 2 * n * n * n ) ; }
void resMatrix ( int n ) { for ( int i = 0 ; i < 3 ; i ++ ) { for ( int j = 0 ; j < 3 ; j ++ ) {
if ( i == 0 && j == 2 ) Console . Write ( "0 ▁ " ) ; else if ( i == 1 && j == 0 ) Console . Write ( "0 ▁ " ) ; else if ( i == 2 && j == 1 ) Console . Write ( "0 ▁ " ) ;
else Console . ( n + " " ) ; } Console . WriteLine ( " " ) ; } }
static public void Main ( String [ ] args ) { int n = 15 ; GFG geeks = new GFG ( ) ; Console . WriteLine ( " Maximum ▁ Determinant ▁ = ▁ " + maxDet ( n ) ) ; Console . WriteLine ( " Resultant ▁ Matrix ▁ : " ) ; geeks . resMatrix ( n ) ; } }
static int spiralDiaSum ( int n ) { if ( n == 1 ) return 1 ;
return ( 4 * n * n - 6 * n + 6 + spiralDiaSum ( n - 2 ) ) ; }
public static void Main ( String [ ] args ) { int n = 7 ; Console . Write ( spiralDiaSum ( n ) ) ; } }
public class GFG { public const int R = 3 ; public const int C = 5 ;
public static int numofneighbour ( int [ ] [ ] mat , int i , int j ) { int count = 0 ;
if ( i > 0 && mat [ i - 1 ] [ j ] == 1 ) { count ++ ; }
if ( j > 0 && mat [ i ] [ j - 1 ] == 1 ) { count ++ ; }
if ( i < R - 1 && mat [ i + 1 ] [ j ] == 1 ) { count ++ ; }
if ( j < C - 1 && mat [ i ] [ j + 1 ] == 1 ) { count ++ ; } return count ; }
public static int findperimeter ( int [ ] [ ] mat ) { int perimeter = 0 ;
for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) { if ( mat [ i ] [ j ] == 1 ) { perimeter += ( 4 - numofneighbour ( mat , i , j ) ) ; } } } return perimeter ; }
public static void Main ( string [ ] args ) { int [ ] [ ] mat = new int [ ] [ ] { new int [ ] { 0 , 1 , 0 , 0 , 0 } , new int [ ] { 1 , 1 , 1 , 0 , 0 } , new int [ ] { 1 , 0 , 0 , 0 , 0 } } ; Console . WriteLine ( findperimeter ( mat ) ) ; } }
using System ; class GFG { static int MAX = 100 ; static void printMatrixDiagonal ( int [ , ] mat , int n ) {
int i = 0 , j = 0 ;
bool isUp = true ;
for ( int k = 0 ; k < n * n ; ) {
if ( isUp ) { for ( ; i >= 0 && j < n ; j ++ , i -- ) { Console . Write ( mat [ i , j ] + " ▁ " ) ; k ++ ; }
if ( i < 0 && j <= n - 1 ) i = 0 ; if ( j == n ) { i = i + 2 ; j -- ; } }
else { for ( ; j >= 0 && i < n ; i ++ , j -- ) { Console . Write ( mat [ i , j ] + " ▁ " ) ; k ++ ; }
if ( j < 0 && i <= n - 1 ) j = 0 ; if ( i == n ) { j = j + 2 ; i -- ; } }
isUp = ! isUp ; } }
public static void Main ( ) { int [ , ] mat = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int n = 3 ; printMatrixDiagonal ( mat , n ) ; } }
using System ; class GFG {
static int maxRowDiff ( int [ , ] mat , int m , int n ) {
int [ ] rowSum = new int [ m ] ;
for ( int i = 0 ; i < m ; i ++ ) { int sum = 0 ; for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i , j ] ; rowSum [ i ] = sum ; }
int max_diff = rowSum [ 1 ] - rowSum [ 0 ] ; int min_element = rowSum [ 0 ] ; for ( int i = 1 ; i < m ; i ++ ) {
if ( rowSum [ i ] - min_element > max_diff ) max_diff = rowSum [ i ] - min_element ;
if ( rowSum [ i ] < min_element ) min_element = rowSum [ i ] ; } return max_diff ; }
public static void Main ( ) { int m = 5 , n = 4 ; int [ , ] mat = { { - 1 , 2 , 3 , 4 } , { 5 , 3 , - 2 , 1 } , { 6 , 7 , 2 , - 3 } , { 2 , 9 , 1 , 4 } , { 2 , 1 , - 2 , 0 } } ; Console . Write ( maxRowDiff ( mat , m , n ) ) ; } }
using System ; class GFG {
static int sortedCount ( int [ , ] mat , int r , int c ) {
int result = 0 ;
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = 0 ; j < c - 1 ; j ++ ) if ( mat [ i , j + 1 ] <= mat [ i , j ] ) break ;
if ( j == c - 1 ) result ++ ; }
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = c - 1 ; j > 0 ; j -- ) if ( mat [ i , j - 1 ] <= mat [ i , j ] ) break ;
if ( c > 1 && j == 0 ) result ++ ; } return result ; }
public static void Main ( ) { int m = 4 , n = 5 ; int [ , ] mat = { { 1 , 2 , 3 , 4 , 5 } , { 4 , 3 , 1 , 2 , 6 } , { 8 , 7 , 6 , 5 , 4 } , { 5 , 7 , 8 , 9 , 10 } } ; Console . WriteLine ( sortedCount ( mat , m , n ) ) ; } }
using System ; class GFG {
static int maxXOR ( int [ , ] mat , int N ) {
int r_xor , c_xor ; int max_xor = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { r_xor = 0 ; c_xor = 0 ; for ( int j = 0 ; j < N ; j ++ ) {
r_xor = r_xor ^ mat [ i , j ] ;
c_xor = c_xor ^ mat [ j , i ] ; }
if ( max_xor < Math . Max ( r_xor , c_xor ) ) max_xor = Math . Max ( r_xor , c_xor ) ; }
return max_xor ; }
public static void Main ( ) { int N = 3 ; int [ , ] mat = { { 1 , 5 , 4 } , { 3 , 7 , 2 } , { 5 , 9 , 10 } } ; Console . Write ( " maximum ▁ XOR ▁ value ▁ : ▁ " + maxXOR ( mat , N ) ) ; } }
static void direction ( int R , int C ) { if ( R != C && R % 2 == 0 && C % 2 != 0 && R < C ) { Console . WriteLine ( " Left " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R > C ) { Console . WriteLine ( " Up " ) ; return ; } if ( R == C && R % 2 != 0 && C % 2 != 0 ) { Console . WriteLine ( " Right " ) ; return ; } if ( R == C && R % 2 == 0 && C % 2 == 0 ) { Console . WriteLine ( " Left " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R < C ) { Console . WriteLine ( " Right " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R > C ) { Console . WriteLine ( " Down " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R < C ) { Console . WriteLine ( " Left " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R > C ) { Console . WriteLine ( " Up " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 != 0 && R > C ) { Console . WriteLine ( " Down " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R < C ) { Console . WriteLine ( " Right " ) ; return ; } }
static public void Main ( ) { int R = 3 , C = 1 ; direction ( R , C ) ; } }
static bool checkDiagonal ( int [ , ] mat , int i , int j ) { int res = mat [ i , j ] ; while ( ++ i < N && ++ j < M ) {
if ( mat [ i , j ] != res ) return false ; }
return true ; }
static bool isToepliz ( int [ , ] mat ) {
for ( int i = 0 ; i < M ; i ++ ) {
if ( ! checkDiagonal ( mat , 0 , i ) ) return false ; }
for ( int i = 1 ; i < N ; i ++ ) {
if ( ! checkDiagonal ( mat , i , 0 ) ) return false ; }
return true ; }
public static void Main ( ) { int [ , ] mat = { { 6 , 7 , 8 , 9 } , { 4 , 6 , 7 , 8 } , { 1 , 4 , 6 , 7 } , { 0 , 1 , 4 , 6 } , { 2 , 0 , 1 , 4 } } ;
if ( isToepliz ( mat ) ) Console . WriteLine ( " Matrix ▁ is ▁ a ▁ Toepliz ▁ " ) ; else Console . WriteLine ( " Matrix ▁ is ▁ not ▁ a ▁ Toepliz ▁ " ) ; } }
using System ; class GFG { public static int N = 5 ;
static int countZeroes ( int [ , ] mat ) {
int row = N - 1 , col = 0 ;
int count = 0 ; while ( col < N ) {
while ( mat [ row , col ] > 0 )
if ( -- row < 0 ) return count ;
count += ( row + 1 ) ;
col ++ ; } return count ; }
public static void Main ( ) { int [ , ] mat = { { 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 1 , 1 } , { 0 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } } ; Console . WriteLine ( countZeroes ( mat ) ) ; } }
using System ; class GFG { static int countNegative ( int [ , ] M , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < m ; j ++ ) { if ( M [ i , j ] < 0 ) count += 1 ;
else break ; } } return count ; }
public static void Main ( ) { int [ , ] M = { { - 3 , - 2 , - 1 , 1 } , { - 2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; Console . WriteLine ( countNegative ( M , 3 , 4 ) ) ; } }
static int countNegative ( int [ , ] M , int n , int m ) {
int count = 0 ;
int i = 0 ; int j = m - 1 ;
while ( j >= 0 && i < n ) { if ( M [ i , j ] < 0 ) {
count += j + 1 ;
i += 1 ; }
else j -= 1 ; } return count ; }
public static void Main ( ) { int [ , ] M = { { - 3 , - 2 , - 1 , 1 } , { - 2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; Console . WriteLine ( countNegative ( M , 3 , 4 ) ) ; } }
static int N = 10 ;
static int findLargestPlus ( int [ , ] mat ) {
int [ , ] left = new int [ N , N ] ; int [ , ] right = new int [ N , N ] ; int [ , ] top = new int [ N , N ] ; int [ , ] bottom = new int [ N , N ] ;
for ( int i = 0 ; i < N ; i ++ ) {
top [ 0 , i ] = mat [ 0 , i ] ;
bottom [ N - 1 , i ] = mat [ N - 1 , i ] ;
left [ i , 0 ] = mat [ i , 0 ] ;
right [ i , N - 1 ] = mat [ i , N - 1 ] ; }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 1 ; j < N ; j ++ ) {
if ( mat [ i , j ] == 1 ) left [ i , j ] = left [ i , j - 1 ] + 1 ; else left [ i , j ] = 0 ;
if ( mat [ j , i ] == 1 ) top [ j , i ] = top [ j - 1 , i ] + 1 ; else top [ j , i ] = 0 ;
j = N - 1 - j ;
if ( mat [ j , i ] == 1 ) bottom [ j , i ] = bottom [ j + 1 , i ] + 1 ; else bottom [ j , i ] = 0 ;
if ( mat [ i , j ] == 1 ) right [ i , j ] = right [ i , j + 1 ] + 1 ; else right [ i , j ] = 0 ;
j = N - 1 - j ; } }
int n = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
int len = Math . Min ( Math . Min ( top [ i , j ] , bottom [ i , j ] ) , Math . Min ( left [ i , j ] , right [ i , j ] ) ) ;
if ( len > n ) n = len ; } }
if ( n > 0 ) return 4 * ( n - 1 ) + 1 ;
return 0 ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } , { 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 } , { 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 } , { 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 } , { 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 } , { 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 } , { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 } } ; Console . Write ( findLargestPlus ( mat ) ) ; } }
public static StringBuilder findLeft ( StringBuilder str ) { int n = str . Length ;
while ( n > 0 ) { n -- ;
if ( str [ n ] == ' d ' ) { str [ n ] = ' c ' ; break ; } if ( str [ n ] == ' b ' ) { str [ n ] = ' a ' ; break ; }
if ( str [ n ] == ' a ' ) { str [ n ] = ' b ' ; } else if ( str [ n ] == ' c ' ) { str [ n ] = ' d ' ; } } return str ; }
public static void Main ( string [ ] args ) { StringBuilder str = new StringBuilder ( " aacbddc " ) ; Console . Write ( " Left ▁ of ▁ " + str + " ▁ is ▁ " + findLeft ( str ) ) ; } }
static void printSpiral ( int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
int x ;
x = Math . Min ( Math . Min ( i , j ) , Math . Min ( n - 1 - i , n - 1 - j ) ) ;
if ( i <= j ) Console . Write ( ( n - 2 * x ) * ( n - 2 * x ) - ( i - x ) - ( j - x ) + " TABSYMBOL " ) ;
else Console . ( ( n - 2 * x - 2 ) * ( n - 2 * x - 2 ) + ( i - x ) + ( - ) + " " ) ; } Console . WriteLine ( ) ; } }
public static void Main ( ) { int n = 5 ;
printSpiral ( n ) ; } }
using System ; class GFG {
static int findMaxValue ( int N , int [ , ] mat ) {
int maxValue = int . MinValue ;
for ( int a = 0 ; a < N - 1 ; a ++ ) for ( int b = 0 ; b < N - 1 ; b ++ ) for ( int d = a + 1 ; d < N ; d ++ ) for ( int e = b + 1 ; e < N ; e ++ ) if ( maxValue < ( mat [ d , e ] - mat [ a , b ] ) ) maxValue = mat [ d , e ] - mat [ a , b ] ; return maxValue ; }
public static void Main ( ) { int N = 5 ; int [ , ] mat = { { 1 , 2 , - 1 , - 4 , - 20 } , { - 8 , - 3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { - 4 , - 1 , 1 , 7 , - 6 } , { 0 , - 4 , 10 , - 5 , 1 } } ; Console . Write ( " Maximum ▁ Value ▁ is ▁ " + findMaxValue ( N , mat ) ) ; } }
using System ; class GFG {
static int findMaxValue ( int N , int [ , ] mat ) {
int maxValue = int . MinValue ;
int [ , ] maxArr = new int [ N , N ] ;
maxArr [ N - 1 , N - 1 ] = mat [ N - 1 , N - 1 ] ;
int maxv = mat [ N - 1 , N - 1 ] ; for ( int j = N - 2 ; j >= 0 ; j -- ) { if ( mat [ N - 1 , j ] > maxv ) maxv = mat [ N - 1 , j ] ; maxArr [ N - 1 , j ] = maxv ; }
maxv = mat [ N - 1 , N - 1 ] ; for ( int i = N - 2 ; i >= 0 ; i -- ) { if ( mat [ i , N - 1 ] > maxv ) maxv = mat [ i , N - 1 ] ; maxArr [ i , N - 1 ] = maxv ; }
for ( int i = N - 2 ; i >= 0 ; i -- ) { for ( int j = N - 2 ; j >= 0 ; j -- ) {
if ( maxArr [ i + 1 , j + 1 ] - mat [ i , j ] > maxValue ) maxValue = maxArr [ i + 1 , j + 1 ] - mat [ i , j ] ;
maxArr [ i , j ] = Math . Max ( mat [ i , j ] , Math . Max ( maxArr [ i , j + 1 ] , maxArr [ i + 1 , j ] ) ) ; } } return maxValue ; }
public static void Main ( ) { int N = 5 ; int [ , ] mat = { { 1 , 2 , - 1 , - 4 , - 20 } , { - 8 , - 3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { - 4 , - 1 , 1 , 7 , - 6 } , { 0 , - 4 , 10 , - 5 , 1 } } ; Console . Write ( " Maximum ▁ Value ▁ is ▁ " + findMaxValue ( N , mat ) ) ; } }
using System ; class GFG { public static void modifyMatrix ( int [ , ] mat , int R , int C ) { int [ ] row = new int [ R ] ; int [ ] col = new int [ C ] ; int i , j ;
for ( i = 0 ; i < R ; i ++ ) { row [ i ] = 0 ; }
for ( i = 0 ; i < C ; i ++ ) { col [ i ] = 0 ; }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( mat [ i , j ] == 1 ) { row [ i ] = 1 ; col [ j ] = 1 ; } } }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( row [ i ] == 1 col [ j ] == 1 ) { mat [ i , j ] = 1 ; } } } }
public static void printMatrix ( int [ , ] mat , int R , int C ) { int i , j ; for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { Console . Write ( mat [ i , j ] + " ▁ " ) ; } Console . WriteLine ( ) ; } }
static public void Main ( ) { int [ , ] mat = { { 1 , 0 , 0 , 1 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 } } ; Console . WriteLine ( " Matrix ▁ Intially " ) ; printMatrix ( mat , 3 , 4 ) ; modifyMatrix ( mat , 3 , 4 ) ; Console . WriteLine ( " Matrix ▁ after ▁ " + " modification ▁ n " ) ; printMatrix ( mat , 3 , 4 ) ; } }
using System ; class GFG { public static void modifyMatrix ( int [ , ] mat ) {
bool row_flag = false ; bool col_flag = false ;
for ( int i = 0 ; i < mat . GetLength ( 0 ) ; i ++ ) { for ( int j = 0 ; j < mat . GetLength ( 1 ) ; j ++ ) { if ( i == 0 && mat [ i , j ] == 1 ) row_flag = true ; if ( j == 0 && mat [ i , j ] == 1 ) col_flag = true ; if ( mat [ i , j ] == 1 ) { mat [ 0 , j ] = 1 ; mat [ i , 0 ] = 1 ; } } }
for ( int i = 1 ; i < mat . GetLength ( 0 ) ; i ++ ) { for ( int j = 1 ; j < mat . GetLength ( 1 ) ; j ++ ) { if ( mat [ 0 , j ] == 1 mat [ i , 0 ] == 1 ) { mat [ i , j ] = 1 ; } } }
if ( row_flag == true ) { for ( int i = 0 ; i < mat . GetLength ( 1 ) ; i ++ ) { mat [ 0 , i ] = 1 ; } }
if ( col_flag == true ) { for ( int i = 0 ; i < mat . GetLength ( 0 ) ; i ++ ) { mat [ i , 0 ] = 1 ; } } }
public static void printMatrix ( int [ , ] mat ) { for ( int i = 0 ; i < mat . GetLength ( 0 ) ; i ++ ) { for ( int j = 0 ; j < mat . GetLength ( 1 ) ; j ++ ) { Console . Write ( mat [ i , j ] + " ▁ " ) ; } Console . Write ( " STRNEWLINE " ) ; } }
public static void Main ( ) { int [ , ] mat = { { 1 , 0 , 0 , 1 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 } } ; Console . Write ( " Input ▁ Matrix ▁ : STRNEWLINE " ) ; printMatrix ( mat ) ; modifyMatrix ( mat ) ; Console . Write ( " Matrix ▁ After ▁ " + " Modification ▁ : STRNEWLINE " ) ; printMatrix ( mat ) ; } }
using System ; public class GFG { static int n = 5 ; static int find ( bool [ , ] arr ) {
int i = 0 , j = n - 1 ;
int res = - 1 ;
while ( i < n && j >= 0 ) {
if ( arr [ i , j ] == false ) {
while ( j >= 0 && ( arr [ i , j ] == false i == j ) ) { j -- ; }
if ( j == - 1 ) { res = i ; break ;
} else { i ++ ; }
} else {
while ( i < n && ( arr [ i , j ] == true i == j ) ) { i ++ ; }
if ( i == n ) { res = j ; break ;
} else { j -- ; } } }
if ( res == - 1 ) { return res ; }
for ( int k = 0 ; k < n ; k ++ ) { if ( res != k && arr [ k , res ] != true ) { return - 1 ; } } for ( int l = 0 ; l < n ; l ++ ) { if ( res != l && arr [ res , l ] != false ) { return - 1 ; } } return res ; }
public static void Main ( ) { bool [ , ] mat = { { false , false , true , true , false } , { false , false , false , true , false } , { true , true , true , true , false } , { false , false , false , false , false } , { true , true , true , true , true } } ; Console . WriteLine ( find ( mat ) ) ; } }
static int preProcess ( int [ , ] mat , int [ , ] aux ) {
for ( int i = 0 ; i < N ; i ++ ) aux [ 0 , i ] = mat [ 0 , i ] ;
for ( int i = 1 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) aux [ i , j ] = mat [ i , j ] + aux [ i - 1 , j ] ;
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 1 ; j < N ; j ++ ) aux [ i , j ] += aux [ i , j - 1 ] ; return 0 ; }
static int sumQuery ( int [ , ] aux , int tli , int tlj , int rbi , int rbj ) {
int res = aux [ rbi , rbj ] ;
if ( tli > 0 ) res = res - aux [ tli - 1 , rbj ] ;
if ( tlj > 0 ) res = res - aux [ rbi , tlj - 1 ] ;
if ( tli > 0 && tlj > 0 ) res = res + aux [ tli - 1 , tlj - 1 ] ; return res ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 2 , 3 , 4 , 6 } , { 5 , 3 , 8 , 1 , 2 } , { 4 , 6 , 7 , 5 , 5 } , { 2 , 4 , 8 , 9 , 4 } } ; int [ , ] aux = new int [ M , N ] ; preProcess ( mat , aux ) ; int tli = 2 , tlj = 2 , rbi = 3 , rbj = 4 ; Console . Write ( " Query1 : " sumQuery ( aux , tli , tlj , rbi , rbj ) ) ; tli = 0 ; tlj = 0 ; rbi = 1 ; rbj = 1 ; Console . Write ( " Query2 : " sumQuery ( aux , tli , tlj , rbi , rbj ) ) ; tli = 1 ; tlj = 2 ; rbi = 3 ; rbj = 3 ; Console . Write ( " Query3 : " sumQuery ( aux , tli , tlj , rbi , rbj ) ) ; } }
using System ; class GFG { static int R = 3 ; static int C = 3 ;
static void swap ( int [ , ] mat , int row1 , int row2 , int col ) { for ( int i = 0 ; i < col ; i ++ ) { int temp = mat [ row1 , i ] ; mat [ row1 , i ] = mat [ row2 , i ] ; mat [ row2 , i ] = temp ; } }
static int rankOfMatrix ( int [ , ] mat ) { int rank = C ; for ( int row = 0 ; row < rank ; row ++ ) {
if ( mat [ row , row ] != 0 ) { for ( int col = 0 ; col < R ; col ++ ) { if ( col != row ) {
double mult = ( double ) mat [ col , row ] / mat [ row , row ] ; for ( int i = 0 ; i < rank ; i ++ ) mat [ col , i ] -= ( int ) mult * mat [ row , i ] ; } } }
else { bool reduce = true ;
for ( int i = row + 1 ; i < R ; i ++ ) {
if ( mat [ i , row ] != 0 ) { swap ( mat , row , i , rank ) ; reduce = false ; break ; } }
if ( reduce ) {
rank -- ;
for ( int i = 0 ; i < R ; i ++ ) mat [ i , row ] = mat [ i , rank ] ; }
row -- ; }
} return rank ; }
static void display ( int [ , ] mat , int row , int col ) { for ( int i = 0 ; i < row ; i ++ ) { for ( int j = 0 ; j < col ; j ++ ) Console . Write ( " ▁ " + mat [ i , j ] ) ; Console . Write ( " STRNEWLINE " ) ; } }
public static void Main ( ) { int [ , ] mat = { { 10 , 20 , 10 } , { - 20 , - 30 , 10 } , { 30 , 50 , 0 } } ; Console . Write ( " Rank ▁ of ▁ the ▁ matrix ▁ is ▁ : ▁ " + rankOfMatrix ( mat ) ) ; } }
static int countIslands ( int [ , ] mat , int m , int n ) {
int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( mat [ i , j ] == ' X ' ) { if ( ( i == 0 mat [ i - 1 , j ] == ' O ' ) && ( j == 0 mat [ i , j - 1 ] == ' O ' ) ) count ++ ; } } } return count ; }
public static void Main ( ) { int m = 6 ; int n = 3 ; int [ , ] mat = { { ' O ' , ' O ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' } , { ' O ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' O ' } } ; Console . WriteLine ( " Number ▁ of ▁ rectangular ▁ " + " islands ▁ is : ▁ " + countIslands ( mat , m , n ) ) ; } }
static int M = 6 ; static int N = 6 ;
static void floodFillUtil ( char [ , ] mat , int x , int y , char prevV , char newV ) {
if ( x < 0 x >= M y < 0 y >= N ) return ; if ( mat [ x , y ] != prevV ) return ;
mat [ x , y ] = newV ;
floodFillUtil ( mat , x + 1 , y , prevV , newV ) ; floodFillUtil ( mat , x - 1 , y , prevV , newV ) ; floodFillUtil ( mat , x , y + 1 , prevV , newV ) ; floodFillUtil ( mat , x , y - 1 , prevV , newV ) ; }
static void replaceSurrounded ( char [ , ] mat ) {
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i , j ] == ' O ' ) mat [ i , j ] = ' - ' ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i , 0 ] == ' - ' ) floodFillUtil ( mat , i , 0 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i , N - 1 ] == ' - ' ) floodFillUtil ( mat , i , N - 1 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ 0 , i ] == ' - ' ) floodFillUtil ( mat , 0 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ M - 1 , i ] == ' - ' ) floodFillUtil ( mat , M - 1 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i , j ] == ' - ' ) mat [ i , j ] = ' X ' ; }
public static void Main ( ) { char [ , ] mat = new char [ , ] { { ' X ' , ' O ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' X ' , ' O ' , ' X ' , ' X ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' O ' , ' X ' , ' X ' , ' X ' , ' X ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' , ' O ' , ' O ' , ' O ' } } ; replaceSurrounded ( mat ) ; for ( int i = 0 ; i < M ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) Console . Write ( mat [ i , j ] + " ▁ " ) ; Console . WriteLine ( " " ) ; } } }
static int n = 5 ;
static void printSumSimple ( int [ , ] mat , int k ) {
if ( k > n ) return ;
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
for ( int j = 0 ; j < n - k + 1 ; j ++ ) {
int sum = 0 ; for ( int p = i ; p < k + i ; p ++ ) for ( int q = j ; q < k + j ; q ++ ) sum += mat [ p , q ] ; Console . Write ( sum + " ▁ " ) ; }
Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] mat = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } } ; int k = 3 ; printSumSimple ( mat , k ) ; } }
static int n = 5 ;
static void printSumTricky ( int [ , ] mat , int k ) {
if ( k > n ) return ;
int [ , ] stripSum = new int [ n , n ] ;
for ( int j = 0 ; j < n ; j ++ ) {
int sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) sum += mat [ i , j ] ; stripSum [ 0 , j ] = sum ;
for ( int i = 1 ; i < n - k + 1 ; i ++ ) { sum += ( mat [ i + k - 1 , j ] - mat [ i - 1 , j ] ) ; stripSum [ i , j ] = sum ; } }
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
int sum = 0 ; for ( int j = 0 ; j < k ; j ++ ) sum += stripSum [ i , j ] ; Console . Write ( sum + " ▁ " ) ;
for ( int j = 1 ; j < n - k + 1 ; j ++ ) { sum += ( stripSum [ i , j + k - 1 ] - stripSum [ i , j - 1 ] ) ; Console . Write ( sum + " ▁ " ) ; } Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] mat = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; int k = 3 ; printSumTricky ( mat , k ) ; } }
using System ; class GFG { static int M = 3 ; static int N = 4 ;
static void transpose ( int [ , ] A , int [ , ] B ) { int i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < M ; j ++ ) B [ i , j ] = A [ j , i ] ; }
public static void Main ( ) { int [ , ] A = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } } ; int [ , ] B = new int [ N , M ] ; transpose ( A , B ) ; Console . WriteLine ( " Result ▁ matrix ▁ is ▁ STRNEWLINE " ) ; for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) Console . Write ( B [ i , j ] + " ▁ " ) ; Console . Write ( " STRNEWLINE " ) ; } } }
using System ; class GFG { static int N = 4 ;
static void transpose ( int [ , ] A ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) { int temp = A [ i , j ] ; A [ i , j ] = A [ j , i ] ; A [ j , i ] = temp ; } }
public static void Main ( ) { int [ , ] A = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; transpose ( A ) ; Console . WriteLine ( " Modified ▁ matrix ▁ is ▁ " ) ; for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) Console . Write ( A [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } } }
using System ; public class GFG { public const int R = 3 ; public const int C = 3 ;
public static int pathCountRec ( int [ ] [ ] mat , int m , int n , int k ) {
if ( m < 0 n < 0 ) { return 0 ; } if ( m == 0 && n == 0 && ( k == mat [ m ] [ n ] ) ) { return 1 ; }
return pathCountRec ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountRec ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; }
public static int pathCount ( int [ ] [ ] mat , int k ) { return pathCountRec ( mat , R - 1 , C - 1 , k ) ; }
public static void Main ( string [ ] args ) { int k = 12 ; int [ ] [ ] mat = new int [ ] [ ] { new int [ ] { 1 , 2 , 3 } , new int [ ] { 4 , 6 , 5 } , new int [ ] { 3 , 2 , 1 } } ; Console . WriteLine ( pathCount ( mat , k ) ) ; } }
using System ; class GFG {
static int [ ] x = { 0 , 1 , 1 , - 1 , 1 , 0 , - 1 , - 1 } ; static int [ ] y = { 1 , 0 , 1 , 1 , - 1 , - 1 , 0 , - 1 } ; static int R = 3 ; static int C = 3 ;
static int [ , ] dp = new int [ R , C ] ;
static bool isvalid ( int i , int j ) { if ( i < 0 j < 0 i >= R j >= C ) return false ; return true ; }
static bool isadjacent ( char prev , char curr ) { return ( ( curr - prev ) == 1 ) ; }
static int getLenUtil ( char [ , ] mat , int i , int j , char prev ) {
if ( ! isvalid ( i , j ) || ! isadjacent ( prev , mat [ i , j ] ) ) return 0 ;
if ( dp [ i , j ] != - 1 ) return dp [ i , j ] ;
int ans = 0 ;
for ( int k = 0 ; k < 8 ; k ++ ) ans = Math . Max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , mat [ i , j ] ) ) ;
return dp [ i , j ] = ans ; }
static int getLen ( char [ , ] mat , char s ) { for ( int i = 0 ; i < R ; ++ i ) for ( int j = 0 ; j < C ; ++ j ) dp [ i , j ] = - 1 ; int ans = 0 ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) {
if ( mat [ i , j ] == s ) {
for ( int k = 0 ; k < 8 ; k ++ ) ans = Math . Max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , s ) ) ; } } } return ans ; }
public static void Main ( ) { char [ , ] mat = { { ' a ' , ' c ' , ' d ' } , { ' h ' , ' b ' , ' a ' } , { ' i ' , ' g ' , ' f ' } } ; Console . WriteLine ( getLen ( mat , ' a ' ) ) ; Console . WriteLine ( getLen ( mat , ' e ' ) ) ; Console . WriteLine ( getLen ( mat , ' b ' ) ) ; Console . WriteLine ( getLen ( mat , ' f ' ) ) ; } }
using System ; class GFG { static int minInitialPoints ( int [ , ] points , int R , int C ) {
int [ , ] dp = new int [ R , C ] ; int m = R , n = C ;
dp [ m - 1 , n - 1 ] = points [ m - 1 , n - 1 ] > 0 ? 1 : Math . Abs ( points [ m - 1 , n - 1 ] ) + 1 ;
for ( int i = m - 2 ; i >= 0 ; i -- ) dp [ i , n - 1 ] = Math . Max ( dp [ i + 1 , n - 1 ] - points [ i , n - 1 ] , 1 ) ; for ( int j = n - 2 ; j >= 0 ; j -- ) dp [ m - 1 , j ] = Math . Max ( dp [ m - 1 , j + 1 ] - points [ m - 1 , j ] , 1 ) ;
for ( int i = m - 2 ; i >= 0 ; i -- ) { for ( int j = n - 2 ; j >= 0 ; j -- ) { int min_points_on_exit = Math . Min ( dp [ i + 1 , j ] , dp [ i , j + 1 ] ) ; dp [ i , j ] = Math . Max ( min_points_on_exit - points [ i , j ] , 1 ) ; } } return dp [ 0 , 0 ] ; }
public static void Main ( ) { int [ , ] points = { { - 2 , - 3 , 3 } , { - 5 , - 10 , 1 } , { 10 , 30 , - 5 } } ; int R = 3 , C = 3 ; Console . Write ( " Minimum ▁ Initial ▁ Points ▁ Required : ▁ " + minInitialPoints ( points , R , C ) ) ; } }
