static void calculateSpan ( int [ ] price , int n , int [ ] S ) {
S [ 0 ] = 1 ;
for ( int i = 1 ; i < n ; i ++ ) {
S [ i ] = 1 ;
for ( int j = i - 1 ; ( j >= 0 ) && ( price [ i ] >= price [ j ] ) ; j -- ) S [ i ] ++ ; } }
static void printArray ( int [ ] arr ) { string result = string . Join ( " ▁ " , arr ) ; Console . WriteLine ( result ) ; }
public static void Main ( ) { int [ ] price = { 10 , 4 , 5 , 90 , 120 , 80 } ; int n = price . Length ; int [ ] S = new int [ n ] ;
calculateSpan ( price , n , S ) ;
static int findSubArray ( int [ ] arr , int n ) { int sum = 0 ; int maxsize = - 1 , startindex = 0 ; int endindex = 0 ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { sum = ( arr [ i ] == 0 ) ? - 1 : 1 ;
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] == 0 ) sum += - 1 ; else sum += 1 ;
if ( sum == 0 && maxsize < j - i + 1 ) { maxsize = j - i + 1 ; startindex = i ; } } } endindex = startindex + maxsize - 1 ; if ( maxsize == - 1 ) Console . WriteLine ( " No ▁ such ▁ subarray " ) ; else Console . WriteLine ( startindex + " ▁ to ▁ " + endindex ) ; return maxsize ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 0 , 1 , 0 , 1 , 1 } ; int size = arr . Length ; findSubArray ( arr , size ) ; } }
static void leftRotatebyOne ( int [ ] arr , int n ) { int i , temp = arr [ 0 ] ; for ( i = 0 ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; arr [ n - 1 ] = temp ; }
static void leftRotate ( int [ ] arr , int d , int n ) { for ( int i = 0 ; i < d ; i ++ ) leftRotatebyOne ( arr , n ) ; }
static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; leftRotate ( arr , 2 , 7 ) ; printArray ( arr , 7 ) ; } }
static void print2Smallest ( int [ ] arr ) { int first , second , arr_size = arr . Length ;
if ( arr_size < 2 ) { Console . Write ( " ▁ Invalid ▁ Input ▁ " ) ; return ; } first = second = int . MaxValue ; for ( int i = 0 ; i < arr_size ; i ++ ) {
if ( arr [ i ] < first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] < second && arr [ i ] != first ) = arr [ i ] ; } if ( second == int . MaxValue ) Console . Write ( " There ▁ is ▁ no ▁ second " + " smallest ▁ element " ) ; else . Write ( " The ▁ smallest ▁ element ▁ is ▁ " + first + " ▁ and ▁ second ▁ Smallest " + " ▁ element ▁ is ▁ " + second ) ; }
public static void Main ( ) { int [ ] arr = { 12 , 13 , 1 , 10 , 34 , 1 } ; print2Smallest ( arr ) ; } }
static int findFirstMissing ( int [ ] array , int start , int end ) { if ( start > end ) return end + 1 ; if ( start != array [ start ] ) return start ; int mid = ( start + end ) / 2 ;
if ( array [ mid ] == mid ) return findFirstMissing ( array , mid + 1 , end ) ; return findFirstMissing ( array , start , mid ) ; }
public static void Main ( ) { int [ ] arr = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 10 } ; int n = arr . Length ; Console . Write ( " smallest ▁ Missing ▁ element ▁ is ▁ : ▁ " + findFirstMissing ( arr , 0 , n - 1 ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static int [ ] arr = new int [ ] { 1 , 20 , 6 , 4 , 5 } ; static int getInvCount ( int n ) { int inv_count = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) inv_count ++ ; return inv_count ; }
public static void Main ( ) { Console . WriteLine ( " Number ▁ of ▁ " + " inversions ▁ are ▁ " + getInvCount ( arr . Length ) ) ; } }
using System ; class GFG { static void printUnsorted ( int [ ] arr , int n ) { int s = 0 , e = n - 1 , i , max , min ;
for ( s = 0 ; s < n - 1 ; s ++ ) { if ( arr [ s ] > arr [ s + 1 ] ) break ; } if ( s == n - 1 ) { Console . Write ( " The ▁ complete ▁ " + " array ▁ is ▁ sorted " ) ; return ; }
for ( e = n - 1 ; e > 0 ; e -- ) { if ( arr [ e ] < arr [ e - 1 ] ) break ; }
max = arr [ s ] ; min = arr [ s ] ; for ( i = s + 1 ; i <= e ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; if ( arr [ i ] < min ) min = arr [ i ] ; }
for ( i = 0 ; i < s ; i ++ ) { if ( arr [ i ] > min ) { s = i ; break ; } }
for ( i = n - 1 ; i >= e + 1 ; i -- ) { if ( arr [ i ] < max ) { e = i ; break ; } }
Console . Write ( " ▁ The ▁ unsorted ▁ subarray ▁ which " + " ▁ makes ▁ the ▁ given ▁ array ▁ sorted ▁ lies ▁ STRNEWLINE " + " ▁ between ▁ the ▁ indices ▁ " + s + " ▁ and ▁ " + e ) ; return ; } public static void Main ( ) { int [ ] arr = { 10 , 12 , 20 , 30 , 25 , 40 , 32 , 31 , 35 , 50 , 60 } ; int arr_size = arr . Length ; printUnsorted ( arr , arr_size ) ; } }
static int findElement ( int [ ] arr , int n , int key ) { for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
public static void Main ( ) { int [ ] arr = { 12 , 34 , 10 , 6 , 40 } ; int n = arr . Length ;
int key = 40 ; int position = findElement ( arr , n , key ) ; if ( position == - 1 ) Console . WriteLine ( " Element ▁ not ▁ found " ) ; else Console . WriteLine ( " Element ▁ Found ▁ at ▁ Position : ▁ " + ( position + 1 ) ) ; } }
static int equilibrium ( int [ ] arr , int n ) {
int sum = 0 ;
int leftsum = 0 ;
for ( int i = 0 ; i < n ; ++ i ) sum += arr [ i ] ; for ( int i = 0 ; i < n ; ++ i ) {
sum -= arr [ i ] ; if ( leftsum == sum ) return i ; leftsum += arr [ i ] ; }
return - 1 ; }
public static void Main ( ) { int [ ] arr = { - 7 , 1 , 5 , 2 , - 4 , 3 , 0 } ; int arr_size = arr . Length ; Console . Write ( " First ▁ equilibrium ▁ index ▁ is ▁ " + equilibrium ( arr , arr_size ) ) ; } }
static int ceilSearch ( int [ ] arr , int low , int high , int x ) { int i ;
if ( x <= arr [ low ] ) return low ;
for ( i = low ; i < high ; i ++ ) { if ( arr [ i ] == x ) return i ;
if ( arr [ i ] < x && arr [ i + 1 ] >= x ) return i + 1 ; }
return - 1 ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 8 , 10 , 10 , 12 , 19 } ; int n = arr . Length ; int x = 3 ; int index = ceilSearch ( arr , 0 , n - 1 , x ) ; if ( index == - 1 ) Console . Write ( " Ceiling ▁ of ▁ " + x + " ▁ doesn ' t ▁ exist ▁ in ▁ array " ) ; else Console . Write ( " ceiling ▁ of ▁ " + x + " ▁ is ▁ " + arr [ index ] ) ; } }
using System ; class GFG { static bool isMajority ( int [ ] arr , int n , int x ) { int i , last_index = 0 ;
last_index = ( n % 2 == 0 ) ? n / 2 : n / 2 + 1 ;
for ( i = 0 ; i < last_index ; i ++ ) {
if ( arr [ i ] == x && arr [ i + n / 2 ] == x ) return true ; } return false ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 4 , 4 , 4 } ; int n = arr . Length ; int x = 4 ; if ( isMajority ( arr , n , x ) == true ) Console . Write ( x + " ▁ appears ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; else Console . Write ( x + " ▁ does ▁ not ▁ appear ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; } }
static int findPeakUtil ( int [ ] arr , int low , int high , int n ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == 0 arr [ mid - 1 ] <= arr [ mid ] ) && ( mid == n - 1 arr [ mid + 1 ] <= arr [ mid ] ) ) return mid ;
else if ( mid > 0 && arr [ mid - 1 ] > arr [ mid ] ) return findPeakUtil ( arr , low , ( mid - 1 ) , n ) ;
else return findPeakUtil ( arr , ( mid + 1 ) , high , n ) ; }
static int findPeak ( int [ ] arr , int n ) { return findPeakUtil ( arr , 0 , n - 1 , n ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 3 , 20 , 4 , 1 , 0 } ; int n = arr . Length ; Console . WriteLine ( " Index ▁ of ▁ a ▁ peak ▁ " + " point ▁ is ▁ " + findPeak ( arr , n ) ) ; } }
static void printRepeating ( int [ ] arr , int size ) { int [ ] count = new int [ size ] ; int i ; Console . Write ( " Repeated ▁ elements ▁ are : ▁ " ) ; for ( i = 0 ; i < size ; i ++ ) { if ( count [ arr [ i ] ] == 1 ) Console . Write ( arr [ i ] + " ▁ " ) ; else count [ arr [ i ] ] ++ ; } }
public static void Main ( ) { int [ ] arr = { 4 , 2 , 4 , 5 , 2 , 3 , 1 } ; int arr_size = arr . Length ; printRepeating ( arr , arr_size ) ; } }
using System ; class GFG { static int linearSearch ( int [ ] arr , int n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == i ) return i ; }
return - 1 ; }
public static void Main ( ) { int [ ] arr = { - 10 , - 1 , 0 , 3 , 10 , 11 , 30 , 50 , 100 } ; int n = arr . Length ; Console . Write ( " Fixed ▁ Point ▁ is ▁ " + linearSearch ( arr , n ) ) ; } }
int subArraySum ( int [ ] arr , int n , int sum ) { int curr_sum , i , j ;
for ( i = 0 ; i < n ; i ++ ) { curr_sum = arr [ i ] ;
for ( j = i + 1 ; j <= n ; j ++ ) { if ( curr_sum == sum ) { int p = j - 1 ; Console . Write ( " Sum ▁ found ▁ between ▁ " + " indexes ▁ " + i + " ▁ and ▁ " + p ) ; return 1 ; } if ( curr_sum > sum j == n ) break ; curr_sum = curr_sum + arr [ j ] ; } } Console . Write ( " No ▁ subarray ▁ found " ) ; return 0 ; }
public static void Main ( ) { GFG arraysum = new GFG ( ) ; int [ ] arr = { 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 } ; int n = arr . Length ; int sum = 23 ; arraysum . subArraySum ( arr , n , sum ) ; } }
int subArraySum ( int [ ] arr , int n , int sum ) {
int curr_sum = arr [ 0 ] , start = 0 , i ;
for ( i = 1 ; i <= n ; i ++ ) {
while ( curr_sum > sum && start < i - 1 ) { curr_sum = curr_sum - arr [ start ] ; start ++ ; }
if ( curr_sum == sum ) { int p = i - 1 ; Console . WriteLine ( " Sum ▁ found ▁ between ▁ " + " indexes ▁ " + start + " ▁ and ▁ " + p ) ; return 1 ; }
if ( i < n ) curr_sum = curr_sum + arr [ i ] ; }
Console . WriteLine ( " No ▁ subarray ▁ found " ) ; return 0 ; }
public static void Main ( ) { GFG arraysum = new GFG ( ) ; int [ ] arr = new int [ ] { 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 } ; int n = arr . Length ; int sum = 23 ; arraysum . subArraySum ( arr , n , sum ) ; } }
static int MatrixChainOrder ( int [ ] p , int i , int j ) { if ( i == j ) return 0 ; int min = int . MaxValue ;
for ( int k = i ; k < j ; k ++ ) { int count = MatrixChainOrder ( p , i , k ) + MatrixChainOrder ( p , k + 1 , j ) + p [ i - 1 ] * p [ k ] * p [ j ] ; if ( count < min ) min = count ; }
return min ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 2 , 3 , 4 , 3 } ; int n = arr . Length ; Console . Write ( " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " + MatrixChainOrder ( arr , 1 , n - 1 ) ) ; } }
static int MatrixChainOrder ( int [ ] p , int n ) {
int [ , ] m = new int [ n , n ] ; int i , j , k , L , q ;
for ( i = 1 ; i < n ; i ++ ) m [ i , i ] = 0 ;
for ( L = 2 ; L < n ; L ++ ) { for ( i = 1 ; i < n - L + 1 ; i ++ ) { j = i + L - 1 ; if ( j == n ) continue ; m [ i , j ] = int . MaxValue ; for ( k = i ; k <= j - 1 ; k ++ ) {
q = m [ i , k ] + m [ k + 1 , j ] + p [ i - 1 ] * p [ k ] * p [ j ] ; if ( q < m [ i , j ] ) m [ i , j ] = q ; } } } return m [ 1 , n - 1 ] ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 2 , 3 , 4 } ; int size = arr . Length ; Console . Write ( " Minimum ▁ number ▁ of ▁ " + " multiplications ▁ is ▁ " + MatrixChainOrder ( arr , size ) ) ; } }
static int knapSack ( int W , int [ ] wt , int [ ] val , int n ) {
if ( n == 0 W == 0 ) return 0 ;
if ( wt [ n - 1 ] > W ) return knapSack ( W , wt , val , n - 1 ) ;
else return max ( val [ n - 1 ] + knapSack ( W - wt [ n - 1 ] , wt , val , n - 1 ) , knapSack ( W , wt , val , n - 1 ) ) ; }
public static void Main ( ) { int [ ] val = new int [ ] { 60 , 100 , 120 } ; int [ ] wt = new int [ ] { 10 , 20 , 30 } ; int W = 50 ; int n = val . Length ; Console . WriteLine ( knapSack ( W , wt , val , n ) ) ; } }
static int count ( int n ) {
int [ ] table = new int [ n + 1 ] ;
table [ 0 ] = 1 ;
for ( int i = 3 ; i <= n ; i ++ ) table [ i ] += table [ i - 3 ] ; for ( int i = 5 ; i <= n ; i ++ ) table [ i ] += table [ i - 5 ] ; for ( int i = 10 ; i <= n ; i ++ ) table [ i ] += table [ i - 10 ] ; return table [ n ] ; }
public static void Main ( ) { int n = 20 ; Console . WriteLine ( " Count ▁ for ▁ " + n + " ▁ is ▁ " + count ( n ) ) ; n = 13 ; Console . Write ( " Count ▁ for ▁ " + n + " ▁ is ▁ " + count ( n ) ) ; } }
using System ; class GFG { public static void search ( String txt , String pat ) { int M = pat . Length ; int N = txt . Length ;
for ( int i = 0 ; i <= N - M ; i ++ ) { int j ;
for ( j = 0 ; j < M ; j ++ ) if ( txt [ i + j ] != pat [ j ] ) break ;
if ( j == M ) Console . WriteLine ( " Pattern ▁ found ▁ at ▁ index ▁ " + i ) ; } }
public static void Main ( ) { String txt = " AABAACAADAABAAABAA " ; String pat = " AABA " ; search ( txt , pat ) ; } }
public readonly static int d = 256 ;
static void search ( String pat , String txt , int q ) { int M = pat . Length ; int N = txt . Length ; int i , j ;
int p = 0 ;
int t = 0 ; int h = 1 ;
for ( i = 0 ; i < M - 1 ; i ++ ) h = ( h * d ) % q ;
for ( i = 0 ; i < M ; i ++ ) { p = ( d * p + pat [ i ] ) % q ; t = ( d * t + txt [ i ] ) % q ; }
for ( i = 0 ; i <= N - M ; i ++ ) {
if ( p == t ) {
for ( j = 0 ; j < M ; j ++ ) { if ( txt [ i + j ] != pat [ j ] ) break ; }
if ( j == M ) Console . WriteLine ( " Pattern ▁ found ▁ at ▁ index ▁ " + i ) ; }
if ( i < N - M ) { t = ( d * ( t - txt [ i ] * h ) + txt [ i + M ] ) % q ;
if ( t < 0 ) t = ( t + q ) ; } } }
public static void Main ( ) { String txt = " GEEKS ▁ FOR ▁ GEEKS " ; String pat = " GEEK " ;
int q = 101 ;
search ( pat , txt , q ) ; } }
static int power ( int x , int y ) { if ( y == 0 ) return 1 ; else if ( y % 2 == 0 ) return power ( x , y / 2 ) * power ( x , y / 2 ) ; else return x * power ( x , y / 2 ) * power ( x , y / 2 ) ; }
public static void Main ( ) { int x = 2 ; int y = 3 ; Console . Write ( power ( x , y ) ) ; } }
static bool isLucky ( int n ) {
int next_position = n ; if ( counter > n ) return true ; if ( n % counter == 0 ) return false ;
next_position -= next_position / counter ; counter ++ ; return isLucky ( next_position ) ; }
public static void Main ( ) { int x = 5 ; if ( isLucky ( x ) ) Console . Write ( x + " ▁ is ▁ a ▁ " + " lucky ▁ no . " ) ; else Console . Write ( x + " ▁ is ▁ not " + " ▁ a ▁ lucky ▁ no . " ) ; } }
static float squareRoot ( float n ) {
float x = n ; float y = 1 ;
double e = 0.000001 ; while ( x - y > e ) { x = ( x + y ) / 2 ; y = n / x ; } return x ; }
public static void Main ( ) { int n = 50 ; Console . Write ( " Square ▁ root ▁ of ▁ " + n + " ▁ is ▁ " + squareRoot ( n ) ) ; } }
static int multiply ( int x , int y ) { if ( y > 0 ) return ( x + multiply ( x , y - 1 ) ) ; else return 0 ; }
static int pow ( int a , int b ) { if ( b > 0 ) return multiply ( a , pow ( a , b - 1 ) ) ; else return 1 ; }
public static void Main ( ) { Console . Write ( pow ( 5 , 3 ) ) ; } }
static float getAvg ( int x ) { sum += x ; return ( ( ( float ) sum ) / ++ n ) ; }
static void streamAvg ( float [ ] arr , int n ) { float avg = 0 ; for ( int i = 0 ; i < n ; i ++ ) { avg = getAvg ( ( int ) arr [ i ] ) ; Console . WriteLine ( " Average ▁ of ▁ { 0 } ▁ numbers ▁ " + " is ▁ { 1 } " , ( i + 1 ) , avg ) ; } return ; }
static int Main ( ) { float [ ] arr = new float [ ] { 10 , 20 , 30 , 40 , 50 , 60 } ; int n = arr . Length ; streamAvg ( arr , n ) ; return 0 ; } }
static int count ( int n ) {
if ( n < 3 ) return n ; if ( n >= 3 && n < 10 ) return n - 1 ;
int po = 1 ; while ( n / po > 9 ) po = po * 10 ;
int msd = n / po ; if ( msd != 3 )
return count ( msd ) * count ( po - 1 ) + count ( msd ) + count ( n % po ) ; else
return count ( msd * po - 1 ) ; }
public static void Main ( ) { int n = 578 ; Console . Write ( count ( n ) ) ; } }
public static void printPascal ( int n ) {
int [ , ] arr = new int [ n , n ] ;
for ( int line = 0 ; line < n ; line ++ ) {
for ( int i = 0 ; i <= line ; i ++ ) {
if ( line == i i == 0 ) arr [ line , i ] = 1 ;
else arr [ line , i ] = arr [ line - 1 , i - 1 ] + arr [ line - 1 , i ] ; Console . Write ( arr [ line , i ] ) ; } Console . WriteLine ( " " ) ; } }
public static void Main ( ) { int n = 5 ; printPascal ( n ) ; } }
public static void primeFactors ( int n ) {
while ( n % 2 == 0 ) { Console . Write ( 2 + " ▁ " ) ; n /= 2 ; }
for ( int i = 3 ; i <= Math . Sqrt ( n ) ; i += 2 ) {
while ( n % i == 0 ) { Console . Write ( i + " ▁ " ) ; n /= i ; } }
if ( n > 2 ) Console . Write ( n ) ; }
public static void Main ( ) { int n = 315 ; primeFactors ( n ) ; } } }
static void printCombination ( int [ ] arr , int n , int r ) {
int [ ] data = new int [ r ] ;
combinationUtil ( arr , data , 0 , n - 1 , 0 , r ) ; }
static void combinationUtil ( int [ ] arr , int [ ] data , int start , int end , int index , int r ) {
if ( index == r ) { for ( int j = 0 ; j < r ; j ++ ) Console . Write ( data [ j ] + " ▁ " ) ; Console . WriteLine ( " " ) ; return ; }
for ( int i = start ; i <= end && end - i + 1 >= r - index ; i ++ ) { data [ index ] = arr [ i ] ; combinationUtil ( arr , data , i + 1 , end , index + 1 , r ) ; } }
static public void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; int r = 3 ; int n = arr . Length ; printCombination ( arr , n , r ) ; } }
int findgroups ( int [ ] arr , int n ) {
int [ ] c = new int [ ] { 0 , 0 , 0 } ; int i ;
int res = 0 ;
for ( i = 0 ; i < n ; i ++ ) c [ arr [ i ] % 3 ] ++ ;
res += ( ( c [ 0 ] * ( c [ 0 ] - 1 ) ) >> 1 ) ;
res += c [ 1 ] * c [ 2 ] ;
res += ( c [ 0 ] * ( c [ 0 ] - 1 ) * ( c [ 0 ] - 2 ) ) / 6 ;
res += ( c [ 1 ] * ( c [ 1 ] - 1 ) * ( c [ 1 ] - 2 ) ) / 6 ;
res += ( ( c [ 2 ] * ( c [ 2 ] - 1 ) * ( c [ 2 ] - 2 ) ) / 6 ) ;
res += c [ 0 ] * c [ 1 ] * c [ 2 ] ;
return res ; }
public static void Main ( ) { FindGroups groups = new FindGroups ( ) ; int [ ] arr = { 3 , 6 , 7 , 2 , 9 } ; int n = arr . Length ; Console . Write ( " Required ▁ number ▁ of ▁ groups ▁ are ▁ " + groups . findgroups ( arr , n ) ) ; } }
using System ; class GFG { static int swapBits ( int x , int p1 , int p2 , int n ) {
int set1 = ( x >> p1 ) & ( ( 1 << n ) - 1 ) ;
int set2 = ( x >> p2 ) & ( ( 1 << n ) - 1 ) ;
int xor = ( set1 ^ set2 ) ;
xor = ( xor << p1 ) | ( xor << p2 ) ;
int result = x ^ xor ; return result ; }
public static void Main ( ) { int res = swapBits ( 28 , 0 , 3 , 2 ) ; Console . WriteLine ( " Result ▁ = ▁ " + res ) ; } }
using System ; class GFG { static int Add ( int x , int y ) {
while ( y != 0 ) {
int carry = x & y ;
x = x ^ y ;
y = carry << 1 ; } return x ; }
public static void Main ( ) { Console . WriteLine ( Add ( 15 , 32 ) ) ; } }
using System ; class GFG { static int addOne ( int x ) { int m = 1 ;
while ( ( int ) ( x & m ) == 1 ) { x = x ^ m ; m <<= 1 ; }
x = x ^ m ; return x ; }
public static void Main ( ) { Console . WriteLine ( addOne ( 13 ) ) ; } }
static int fun ( int n ) { return n & ( n - 1 ) ; }
public static void Main ( ) { int n = 7 ; Console . Write ( " The ▁ number ▁ after ▁ unsetting ▁ " + " the ▁ rightmost ▁ set ▁ bit ▁ " + fun ( n ) ) ; } }
static int isPowerOfFour ( int n ) { if ( n == 0 ) return 0 ; while ( n != 1 ) { if ( n % 4 != 0 ) return 0 ; n = n / 4 ; } return 1 ; }
public static void Main ( ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) == 1 ) Console . Write ( test_no + " ▁ is ▁ a ▁ power ▁ of ▁ 4" ) ; else Console . Write ( test_no + " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ) ; } }
using System ; class GFG { static int nextPowerOf2 ( int n ) { int count = 0 ;
if ( n > 0 && ( n & ( n - 1 ) ) == 0 ) return n ; while ( n != 0 ) { n >>= 1 ; count += 1 ; } return 1 << count ; }
public static void Main ( ) { int n = 0 ; Console . WriteLine ( nextPowerOf2 ( n ) ) ; } }
static bool isPowerOfTwo ( int n ) { if ( n == 0 ) return false ; while ( n != 1 ) { if ( n % 2 != 0 ) return false ; n = n / 2 ; } return true ; }
public static void Main ( ) { Console . WriteLine ( isPowerOfTwo ( 31 ) ? " Yes " : " No " ) ; Console . WriteLine ( isPowerOfTwo ( 64 ) ? " Yes " : " No " ) ; } }
using System ; class GFG { public static int getFirstSetBitPos ( int n ) { return ( int ) ( ( Math . Log10 ( n & - n ) ) / Math . Log10 ( 2 ) ) + 1 ; }
public static void Main ( ) { int n = 12 ; Console . WriteLine ( getFirstSetBitPos ( n ) ) ; } }
static bool isPowerOfTwo ( int n ) { return n > 0 && ( ( n & ( n - 1 ) ) == 0 ) ; }
static int findPosition ( int n ) { if ( ! isPowerOfTwo ( n ) ) return - 1 ; int count = 0 ;
while ( n > 0 ) { n = n >> 1 ;
++ count ; } return count ; }
static void Main ( ) { int n = 0 ; int pos = findPosition ( n ) ; if ( pos == - 1 ) Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Invalid ▁ number " ) ; else Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Position ▁ " + pos ) ; n = 12 ; pos = findPosition ( n ) ; if ( pos == - 1 ) Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Invalid ▁ number " ) ; else Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Position ▁ " + pos ) ; n = 128 ; pos = findPosition ( n ) ; if ( pos == - 1 ) Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Invalid ▁ number " ) ; else Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Position ▁ " + pos ) ; } }
using System ; class GFG { static public void Main ( ) { int x = 10 ; int y = 5 ;
x = x * y ;
y = x / y ;
x = x / y ; Console . WriteLine ( " After ▁ swaping : " + " ▁ x ▁ = ▁ " + x + " , ▁ y ▁ = ▁ " + y ) ; } }
using System ; class GFG { public static void Main ( ) { int x = 10 ; int y = 5 ;
x = x ^ y ;
y = x ^ y ;
x = x ^ y ; Console . WriteLine ( " After ▁ swap : ▁ x ▁ = ▁ " + x + " , ▁ y ▁ = ▁ " + y ) ; } }
static void swap ( int [ ] xp , int [ ] yp ) { xp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] ; yp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] ; xp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] ; }
static void Main ( ) { int [ ] x = { 10 } ; swap ( x , x ) ; Console . WriteLine ( " After ▁ swap ( & x , " + " & x ) : ▁ x ▁ = ▁ " + x [ 0 ] ) ; } }
static int maxIndexDiff ( int [ ] arr , int n ) { int maxDiff = - 1 ; int i , j ; for ( i = 0 ; i < n ; ++ i ) { for ( j = n - 1 ; j > i ; -- j ) { if ( arr [ j ] > arr [ i ] && maxDiff < ( j - i ) ) maxDiff = j - i ; } } return maxDiff ; }
public static void Main ( ) { int [ ] arr = { 9 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 18 , 0 } ; int n = arr . Length ; int maxDiff = maxIndexDiff ( arr , n ) ; Console . Write ( maxDiff ) ; } }
static int findMaximum ( int [ ] arr , int low , int high ) { int max = arr [ low ] ; int i ; for ( i = low ; i <= high ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void Main ( ) { int [ ] arr = { 1 , 30 , 40 , 50 , 60 , 70 , 23 , 20 } ; int n = arr . Length ; Console . Write ( " The ▁ maximum ▁ element ▁ is ▁ " + findMaximum ( arr , 0 , n - 1 ) ) ; } }
using System ; class GFG { static private void printSorted ( int [ ] arr , int start , int end ) { if ( start > end ) return ;
printSorted ( arr , start * 2 + 1 , end ) ;
Console . Write ( arr [ start ] + " ▁ " ) ;
printSorted ( arr , start * 2 + 2 , end ) ; }
static public void Main ( String [ ] args ) { int [ ] arr = { 4 , 2 , 5 , 1 , 3 } ; printSorted ( arr , 0 , arr . Length - 1 ) ; } }
private static void search ( int [ , ] mat , int n , int x ) {
int i = 0 , j = n - 1 ; while ( i < n && j >= 0 ) { if ( mat [ i , j ] == x ) { Console . Write ( " n ▁ Found ▁ at ▁ " + i + " , ▁ " + j ) ; return ; } if ( mat [ i , j ] > x ) j -- ;
else i ++ ; } Console . Write ( " n ▁ Element ▁ not ▁ found " ) ;
return ; }
public static void Main ( ) { int [ , ] mat = { { 10 , 20 , 30 , 40 } , { 15 , 25 , 35 , 45 } , { 27 , 29 , 37 , 48 } , { 32 , 33 , 39 , 50 } } ; search ( mat , 4 , 29 ) ; } }
using System ; class GFG { static int N = 4 ;
static void add ( int [ , ] A , int [ , ] B , int [ , ] C ) { int i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < N ; j ++ ) C [ i , j ] = A [ i , j ] + B [ i , j ] ; }
public static void Main ( ) { int [ , ] A = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; int [ , ] B = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; int [ , ] C = new int [ N , N ] ; int i , j ; add ( A , B , C ) ; Console . WriteLine ( " Result ▁ matrix ▁ is ▁ " ) ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < N ; j ++ ) Console . Write ( C [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } } }
