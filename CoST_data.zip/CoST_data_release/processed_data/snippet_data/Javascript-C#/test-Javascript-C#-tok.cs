static void printNGE ( int [ ] arr , int n ) { int next , i , j ; for ( i = 0 ; i < n ; i ++ ) { next = - 1 ; for ( j = i + 1 ; j < n ; j ++ ) { if ( arr [ i ] < arr [ j ] ) { next = arr [ j ] ; break ; } } Console . WriteLine ( arr [ i ] + " ▁ - - ▁ " + next ) ; } }
public static void Main ( ) { int [ ] arr = { 11 , 13 , 21 , 3 } ; int n = arr . Length ; printNGE ( arr , n ) ; } }
using System ; class Minimum { static int findMin ( int [ ] arr , int low , int high ) {
if ( high < low ) return arr [ 0 ] ;
if ( high == low ) return arr [ low ] ;
int mid = low + ( high - low ) / 2 ;
if ( mid < high && arr [ mid + 1 ] < arr [ mid ] ) return arr [ mid + 1 ] ;
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) return arr [ mid ] ;
if ( arr [ high ] > arr [ mid ] ) return findMin ( arr , low , mid - 1 ) ; return findMin ( arr , mid + 1 , high ) ; }
public static void Main ( ) { int [ ] arr1 = { 5 , 6 , 1 , 2 , 3 , 4 } ; int n1 = arr1 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr1 , 0 , n1 - 1 ) ) ; int [ ] arr2 = { 1 , 2 , 3 , 4 } ; int n2 = arr2 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr2 , 0 , n2 - 1 ) ) ; int [ ] arr3 = { 1 } ; int n3 = arr3 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr3 , 0 , n3 - 1 ) ) ; int [ ] arr4 = { 1 , 2 } ; int n4 = arr4 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr4 , 0 , n4 - 1 ) ) ; int [ ] arr5 = { 2 , 1 } ; int n5 = arr5 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr5 , 0 , n5 - 1 ) ) ; int [ ] arr6 = { 5 , 6 , 7 , 1 , 2 , 3 , 4 } ; int n6 = arr6 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr6 , 0 , n1 - 1 ) ) ; int [ ] arr7 = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int n7 = arr7 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr7 , 0 , n7 - 1 ) ) ; int [ ] arr8 = { 2 , 3 , 4 , 5 , 6 , 7 , 8 , 1 } ; int n8 = arr8 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr8 , 0 , n8 - 1 ) ) ; int [ ] arr9 = { 3 , 4 , 5 , 1 , 2 } ; int n9 = arr9 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr9 , 0 , n9 - 1 ) ) ; } }
public static void print2largest ( int [ ] arr , int arr_size ) { int i , first , second ;
if ( arr_size < 2 ) { Console . WriteLine ( " ▁ Invalid ▁ Input ▁ " ) ; return ; } first = second = int . MinValue ; for ( i = 0 ; i < arr_size ; i ++ ) {
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second && arr [ i ] != first ) = arr [ i ] ; } if ( second == int . MinValue ) Console . Write ( " There ▁ is ▁ no ▁ second ▁ largest " + " ▁ element STRNEWLINE " ) ; else . Write ( " The ▁ second ▁ largest ▁ element " + " ▁ is ▁ " + second ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 12 , 35 , 1 , 10 , 34 , 1 } ; int n = arr . Length ; print2largest ( arr , n ) ; } }
static int FindMaxSum ( int [ ] arr , int n ) { int incl = arr [ 0 ] ; int excl = 0 ; int excl_new ; int i ; for ( i = 1 ; i < n ; i ++ ) {
excl_new = ( incl > excl ) ? incl : excl ;
incl = excl + arr [ i ] ; excl = excl_new ; }
return ( ( incl > excl ) ? incl : excl ) ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 5 , 5 , 10 , 100 , 10 , 5 } ; Console . Write ( FindMaxSum ( arr , arr . Length ) ) ; } }
static int minJumps ( int [ ] arr , int l , int h ) {
if ( h == l ) return 0 ;
int min = int . MaxValue ; for ( int i = l + 1 ; i <= h && i <= l + arr [ l ] ; i ++ ) { int jumps = minJumps ( arr , i , h ) ; if ( jumps != int . MaxValue && jumps + 1 < min ) min = jumps + 1 ; } return min ; }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 6 , 3 , 2 , 3 , 6 , 8 , 9 , 5 } ; int n = arr . Length ; Console . Write ( " Minimum ▁ number ▁ of ▁ jumps ▁ to ▁ reach ▁ end ▁ is ▁ " + minJumps ( arr , 0 , n - 1 ) ) ; } }
static int maxSumIS ( int [ ] arr , int n ) { int i , j , max = 0 ; int [ ] msis = new int [ n ] ;
for ( i = 0 ; i < n ; i ++ ) msis [ i ] = arr [ i ] ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && msis [ i ] < msis [ j ] + arr [ i ] ) msis [ i ] = msis [ j ] + arr [ i ] ;
for ( i = 0 ; i < n ; i ++ ) if ( max < msis [ i ] ) max = msis [ i ] ; return max ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 101 , 2 , 3 , 100 , 4 , 5 } ; int n = arr . Length ; Console . WriteLine ( " Sum ▁ of ▁ maximum ▁ sum ▁ increasing ▁ " + " ▁ subsequence ▁ is ▁ " + maxSumIS ( arr , n ) ) ; } }
public virtual void moveToEnd ( int [ ] mPlusN , int size ) { int i , j = size - 1 ; for ( i = size - 1 ; i >= 0 ; i -- ) { if ( mPlusN [ i ] != - 1 ) { mPlusN [ j ] = mPlusN [ i ] ; j -- ; } } }
public virtual void merge ( int [ ] mPlusN , int [ ] N , int m , int n ) { int i = n ;
int j = 0 ;
int k = 0 ;
while ( k < ( m + n ) ) {
if ( ( j == n ) ( i < ( m + n ) && mPlusN [ i ] <= N [ j ] ) ) { mPlusN [ k ] = mPlusN [ i ] ; k ++ ; i ++ ; }
else { mPlusN [ k ] = N [ j ] ; k ++ ; j ++ ; } } }
public virtual void printArray ( int [ ] arr , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) { Console . Write ( arr [ i ] + " ▁ " ) ; } Console . WriteLine ( " " ) ; }
int [ ] mPlusN = new int [ ] { 2 , 8 , - 1 , - 1 , - 1 , 13 , - 1 , 15 , 20 } ; int [ ] N = new int [ ] { 5 , 7 , 9 , 25 } ; int n = N . Length ; int m = mPlusN . Length - n ;
mergearray . moveToEnd ( mPlusN , m + n ) ;
mergearray . merge ( mPlusN , N , m , n ) ;
mergearray . printArray ( mPlusN , m + n ) ; } }
using System ; class GFG { static void minAbsSumPair ( int [ ] arr , int arr_size ) { int l , r , min_sum , sum , min_l , min_r ;
if ( arr_size < 2 ) { Console . Write ( " Invalid ▁ Input " ) ; return ; }
min_l = 0 ; min_r = 1 ; min_sum = arr [ 0 ] + arr [ 1 ] ; for ( l = 0 ; l < arr_size - 1 ; l ++ ) { for ( r = l + 1 ; r < arr_size ; r ++ ) { sum = arr [ l ] + arr [ r ] ; if ( Math . Abs ( min_sum ) > Math . Abs ( sum ) ) { min_sum = sum ; min_l = l ; min_r = r ; } } } Console . Write ( " ▁ The ▁ two ▁ elements ▁ whose ▁ " + " sum ▁ is ▁ minimum ▁ are ▁ " + arr [ min_l ] + " ▁ and ▁ " + arr [ min_r ] ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 60 , - 10 , 70 , - 80 , 85 } ; minAbsSumPair ( arr , 6 ) ; } }
static void sort012 ( int [ ] a , int arr_size ) { int lo = 0 ; int hi = arr_size - 1 ; int mid = 0 , temp = 0 ; while ( mid <= hi ) { switch ( a [ mid ] ) { case 0 : { temp = a [ lo ] ; a [ lo ] = a [ mid ] ; a [ mid ] = temp ; lo ++ ; mid ++ ; break ; } case 1 : mid ++ ; break ; case 2 : { temp = a [ mid ] ; a [ mid ] = a [ hi ] ; a [ hi ] = temp ; hi -- ; break ; } } } }
static void printArray ( int [ ] arr , int arr_size ) { int i ; for ( i = 0 ; i < arr_size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( " " ) ; }
public static void Main ( ) { int [ ] arr = { 0 , 1 , 1 , 0 , 1 , 2 , 1 , 2 , 0 , 0 , 0 , 1 } ; int arr_size = arr . Length ; sort012 ( arr , arr_size ) ; Console . Write ( " Array ▁ after ▁ seggregation ▁ " ) ; printArray ( arr , arr_size ) ; } }
static int findNumberOfTriangles ( int [ ] arr ) { int n = arr . Length ;
Array . Sort ( arr ) ;
int count = 0 ;
for ( int i = 0 ; i < n - 2 ; ++ i ) {
int k = i + 2 ;
for ( int j = i + 1 ; j < n ; ++ j ) {
while ( k < n && arr [ i ] + arr [ j ] > arr [ k ] ) ++ k ;
if ( k > j ) count += k - j - 1 ; } } return count ; }
public static void Main ( ) { int [ ] arr = { 10 , 21 , 22 , 100 , 101 , 200 , 300 } ; Console . WriteLine ( " Total ▁ number ▁ of ▁ triangles ▁ is ▁ " + findNumberOfTriangles ( arr ) ) ; } }
public static int binarySearch ( int [ ] arr , int low , int high , int key ) { if ( high < low ) { return - 1 ; }
int mid = ( low + high ) / 2 ; if ( key == arr [ mid ] ) { return mid ; } if ( key > arr [ mid ] ) { return binarySearch ( arr , ( mid + 1 ) , high , key ) ; } return binarySearch ( arr , low , ( mid - 1 ) , key ) ; }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 5 , 6 , 7 , 8 , 9 , 10 } ; int n , key ; n = arr . Length ; key = 10 ; Console . WriteLine ( " Index : ▁ " + binarySearch ( arr , 0 , n - 1 , key ) ) ; } }
static int equilibrium ( int [ ] arr , int n ) { int i , j ; int leftsum , rightsum ;
for ( i = 0 ; i < n ; ++ i ) { leftsum = 0 ; rightsum = 0 ;
for ( j = 0 ; j < i ; j ++ ) leftsum += arr [ j ] ;
for ( j = i + 1 ; j < n ; j ++ ) rightsum += arr [ j ] ;
if ( leftsum == rightsum ) return i ; }
return - 1 ; }
public static void Main ( ) { int [ ] arr = { - 7 , 1 , 5 , 2 , - 4 , 3 , 0 } ; int arr_size = arr . Length ; Console . Write ( equilibrium ( arr , arr_size ) ) ; } }
static int ceilSearch ( int [ ] arr , int low , int high , int x ) { int mid ;
if ( x <= arr [ low ] ) return low ;
if ( x > arr [ high ] ) return - 1 ;
mid = ( low + high ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
else if ( arr [ mid ] < x ) { if ( mid + 1 <= high && x <= arr [ mid + 1 ] ) return mid + 1 ; else return ceilSearch ( arr , mid + 1 , high , x ) ; }
else { if ( mid - 1 >= low && x > arr [ mid - 1 ] ) return mid ; else return ceilSearch ( arr , low , mid - 1 , x ) ; } }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 8 , 10 , 10 , 12 , 19 } ; int n = arr . Length ; int x = 8 ; int index = ceilSearch ( arr , 0 , n - 1 , x ) ; if ( index == - 1 ) Console . Write ( " Ceiling ▁ of ▁ " + x + " ▁ doesn ' t ▁ exist ▁ in ▁ array " ) ; else Console . Write ( " ceiling ▁ of ▁ " + x + " ▁ is ▁ " + arr [ index ] ) ; } }
static int findCandidate ( int [ ] a , int size ) { int maj_index = 0 , count = 1 ; int i ; for ( i = 1 ; i < size ; i ++ ) { if ( a [ maj_index ] == a [ i ] ) count ++ ; else count -- ; if ( count == 0 ) { maj_index = i ; count = 1 ; } } return a [ maj_index ] ; }
static bool isMajority ( int [ ] a , int size , int cand ) { int i , count = 0 ; for ( i = 0 ; i < size ; i ++ ) { if ( a [ i ] == cand ) count ++ ; } if ( count > size / 2 ) return true ; else return false ; }
static void printMajority ( int [ ] a , int size ) {
int cand = findCandidate ( a , size ) ;
if ( isMajority ( a , size , cand ) ) Console . Write ( " ▁ " + cand + " ▁ " ) ; else Console . Write ( " No ▁ Majority ▁ Element " ) ; }
public static void Main ( ) { int [ ] a = { 1 , 3 , 3 , 1 , 2 } ; int size = a . Length ;
printMajority ( a , size ) ; } }
static void printRepeating ( int [ ] arr , int size ) { int i , j ; Console . Write ( " Repeated ▁ Elements ▁ are ▁ : " ) ; for ( i = 0 ; i < size ; i ++ ) { for ( j = i + 1 ; j < size ; j ++ ) { if ( arr [ i ] == arr [ j ] ) Console . Write ( arr [ i ] + " ▁ " ) ; } } }
public static void Main ( ) { int [ ] arr = { 4 , 2 , 4 , 5 , 2 , 3 , 1 } ; int arr_size = arr . Length ; printRepeating ( arr , arr_size ) ; } }
static void printRepeating ( int [ ] arr , int size ) {
int S = 0 ;
int P = 1 ;
int x , y ;
int D ; int n = size - 2 , i ;
for ( i = 0 ; i < size ; i ++ ) { S = S + arr [ i ] ; P = P * arr [ i ] ; }
S = S - n * ( n + 1 ) / 2 ;
P = P / fact ( n ) ;
D = ( int ) Math . Sqrt ( S * S - 4 * P ) ; x = ( D + S ) / 2 ; y = ( S - D ) / 2 ; Console . WriteLine ( " The ▁ two " + " ▁ repeating ▁ elements ▁ are ▁ : " ) ; Console . Write ( x + " ▁ " + y ) ; }
static int fact ( int n ) { return ( n == 0 ) ? 1 : n * fact ( n - 1 ) ; }
public static void Main ( ) { int [ ] arr = { 4 , 2 , 4 , 5 , 2 , 3 , 1 } ; int arr_size = arr . Length ; printRepeating ( arr , arr_size ) ; } }
using System ; class GFG { static void printRepeating ( int [ ] arr , int size ) {
int xor = arr [ 0 ] ;
int set_bit_no ; int i ; int n = size - 2 ; int x = 0 , y = 0 ;
for ( i = 1 ; i < size ; i ++ ) xor ^= arr [ i ] ; for ( i = 1 ; i <= n ; i ++ ) xor ^= i ;
set_bit_no = ( xor & ~ ( xor - 1 ) ) ;
for ( i = 0 ; i < size ; i ++ ) { int a = arr [ i ] & set_bit_no ; if ( a != 0 ) x = x ^ arr [ i ] ;
else y = y ^ arr [ i ] ; }
for ( i = 1 ; i <= n ; i ++ ) { int a = i & set_bit_no ; if ( a != 0 ) x = x ^ i ;
else y = y ^ i ; }
Console . WriteLine ( " The ▁ two " + " ▁ reppeated ▁ elements ▁ are ▁ : " ) ; Console . Write ( x + " ▁ " + y ) ; }
public static void Main ( ) { int [ ] arr = { 4 , 2 , 4 , 5 , 2 , 3 , 1 } ; int arr_size = arr . Length ; printRepeating ( arr , arr_size ) ; } }
static void printRepeating ( int [ ] arr , int size ) { int i ; Console . Write ( " The ▁ repeating ▁ elements ▁ are ▁ : ▁ " ) ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ Math . Abs ( arr [ i ] ) ] > 0 ) arr [ Math . Abs ( arr [ i ] ) ] = - arr [ Math . Abs ( arr [ i ] ) ] ; else Console . Write ( Math . Abs ( arr [ i ] ) + " ▁ " ) ; } }
public static void Main ( ) { int [ ] arr = { 4 , 2 , 4 , 5 , 2 , 3 , 1 } ; int arr_size = arr . Length ; printRepeating ( arr , arr_size ) ; } }
using System ; class GFG { static int binarySearch ( int [ ] arr , int low , int high ) { if ( high >= low ) {
int mid = ( low + high ) / 2 ; if ( mid == arr [ mid ] ) return mid ; if ( mid > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high ) ; else return binarySearch ( arr , low , ( mid - 1 ) ) ; }
return - 1 ; }
public static void Main ( ) { int [ ] arr = { - 10 , - 1 , 0 , 3 , 10 , 11 , 30 , 50 , 100 } ; int n = arr . Length ; Console . Write ( " Fixed ▁ Point ▁ is ▁ " + binarySearch ( arr , 0 , n - 1 ) ) ; } }
static bool find3Numbers ( int [ ] A , int arr_size , int sum ) {
for ( int i = 0 ; i < arr_size - 2 ; i ++ ) {
for ( int j = i + 1 ; j < arr_size - 1 ; j ++ ) {
for ( int k = j + 1 ; k < arr_size ; k ++ ) { if ( A [ i ] + A [ j ] + A [ k ] == sum ) { Console . WriteLine ( " Triplet ▁ is ▁ " + A [ i ] + " , ▁ " + A [ j ] + " , ▁ " + A [ k ] ) ; return true ; } } } }
return false ; }
static public void Main ( ) { int [ ] A = { 1 , 4 , 45 , 6 , 10 , 8 } ; int sum = 22 ; int arr_size = A . Length ; find3Numbers ( A , arr_size , sum ) ; } }
using System ; class GFG { public static int search ( int [ ] arr , int x ) { int n = arr . Length ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == x ) return i ; } return - 1 ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 4 , 10 , 40 } ; int x = 10 ;
int result = search ( arr , x ) ; if ( result == - 1 ) Console . WriteLine ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) ; else Console . WriteLine ( " Element ▁ is ▁ present ▁ at ▁ index ▁ " + result ) ; } }
static int binarySearch ( int [ ] arr , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 4 , 10 , 40 } ; int n = arr . Length ; int x = 10 ; int result = binarySearch ( arr , 0 , n - 1 , x ) ; if ( result == - 1 ) Console . WriteLine ( " Element ▁ not ▁ present " ) ; else Console . WriteLine ( " Element ▁ found ▁ at ▁ index ▁ " + result ) ; } }
static void countsort ( char [ ] arr ) { int n = arr . Length ;
char [ ] output = new char [ n ] ;
int [ ] count = new int [ 256 ] ; for ( int i = 0 ; i < 256 ; ++ i ) count [ i ] = 0 ;
for ( int i = 0 ; i < n ; ++ i ) ++ count [ arr [ i ] ] ;
for ( int i = 1 ; i <= 255 ; ++ i ) count [ i ] += count [ i - 1 ] ;
for ( int i = n - 1 ; i >= 0 ; i -- ) { output [ count [ arr [ i ] ] - 1 ] = arr [ i ] ; -- count [ arr [ i ] ] ; }
for ( int i = 0 ; i < n ; ++ i ) arr [ i ] = output [ i ] ; }
public static void Main ( ) { char [ ] arr = { ' g ' , ' e ' , ' e ' , ' k ' , ' s ' , ' f ' , ' o ' , ' r ' , ' g ' , ' e ' , ' e ' , ' k ' , ' s ' } ; countsort ( arr ) ; Console . Write ( " Sorted ▁ character ▁ array ▁ is ▁ " ) ; for ( int i = 0 ; i < arr . Length ; ++ i ) Console . Write ( arr [ i ] ) ; } }
public static void printMaxActivities ( int [ ] s , int [ ] f , int n ) { int i , j ; Console . Write ( " Following ▁ activities ▁ are ▁ selected ▁ : ▁ " ) ;
i = 0 ; Console . Write ( i + " ▁ " ) ;
for ( j = 1 ; j < n ; j ++ ) {
if ( s [ j ] >= f [ i ] ) { Console . Write ( j + " ▁ " ) ; i = j ; } } }
public static void Main ( ) { int [ ] s = { 1 , 3 , 0 , 5 , 8 , 5 } ; int [ ] f = { 2 , 4 , 6 , 7 , 9 , 9 } ; int n = s . Length ; printMaxActivities ( s , f , n ) ; } }
static int min ( int x , int y , int z ) { if ( x < y ) return ( ( x < z ) ? x : z ) ; else return ( ( y < z ) ? y : z ) ; }
static int minCost ( int [ , ] cost , int m , int n ) { if ( n < 0 m < 0 ) return int . MaxValue ; else if ( m == 0 && n == 0 ) return cost [ m , n ] ; else return cost [ m , n ] + min ( minCost ( cost , m - 1 , n - 1 ) , minCost ( cost , m - 1 , n ) , minCost ( cost , m , n - 1 ) ) ; }
public static void Main ( ) { int [ , ] cost = { { 1 , 2 , 3 } , { 4 , 8 , 2 } , { 1 , 5 , 3 } } ; Console . Write ( minCost ( cost , 2 , 2 ) ) ; } }
using System ; class GFG { private static int minCost ( int [ , ] cost , int m , int n ) { int i , j ;
int [ , ] tc = new int [ m + 1 , n + 1 ] ; tc [ 0 , 0 ] = cost [ 0 , 0 ] ;
for ( i = 1 ; i <= m ; i ++ ) tc [ i , 0 ] = tc [ i - 1 , 0 ] + cost [ i , 0 ] ;
for ( j = 1 ; j <= n ; j ++ ) tc [ 0 , j ] = tc [ 0 , j - 1 ] + cost [ 0 , j ] ;
for ( i = 1 ; i <= m ; i ++ ) for ( j = 1 ; j <= n ; j ++ ) tc [ i , j ] = min ( tc [ i - 1 , j - 1 ] , tc [ i - 1 , j ] , tc [ i , j - 1 ] ) + cost [ i , j ] ; return tc [ m , n ] ; }
private static int min ( int x , int y , int z ) { if ( x < y ) return ( x < z ) ? x : z ; else return ( y < z ) ? y : z ; }
public static void Main ( ) { int [ , ] cost = { { 1 , 2 , 3 } , { 4 , 8 , 2 } , { 1 , 5 , 3 } } ; Console . Write ( minCost ( cost , 2 , 2 ) ) ; } }
static int binomialCoeff ( int n , int k ) {
if ( k > n ) return 0 ; if ( k == 0 k == n ) return 1 ;
return binomialCoeff ( n - 1 , k - 1 ) + binomialCoeff ( n - 1 , k ) ; }
public static void Main ( ) { int n = 5 , k = 2 ; Console . Write ( " Value ▁ of ▁ C ( " + n + " , " + k + " ) ▁ is ▁ " + binomialCoeff ( n , k ) ) ; } }
static int max ( int a , int b ) { return ( a > b ) ? a : b ; }
static int knapSack ( int W , int [ ] wt , int [ ] val , int n ) { int i , w ; int [ , ] K = new int [ n + 1 , W + 1 ] ;
for ( i = 0 ; i <= n ; i ++ ) { for ( w = 0 ; w <= W ; w ++ ) { if ( i == 0 w == 0 ) K [ i , w ] = 0 ; else if ( wt [ i - 1 ] <= w ) K [ i , w ] = Math . Max ( val [ i - 1 ] + K [ i - 1 , w - wt [ i - 1 ] ] , K [ i - 1 , w ] ) ; else K [ i , w ] = K [ i - 1 , w ] ; } } return K [ n , W ] ; }
static void Main ( ) { int [ ] val = new int [ ] { 60 , 100 , 120 } ; int [ ] wt = new int [ ] { 10 , 20 , 30 } ; int W = 50 ; int n = val . Length ; Console . WriteLine ( knapSack ( W , wt , val , n ) ) ; } }
static int max ( int x , int y ) { return ( x > y ) ? x : y ; }
static int lps ( char [ ] seq , int i , int j ) {
if ( i == j ) { return 1 ; }
if ( seq [ i ] == seq [ j ] && i + 1 == j ) { return 2 ; }
if ( seq [ i ] == seq [ j ] ) { return lps ( seq , i + 1 , j - 1 ) + 2 ; }
return max ( lps ( seq , i , j - 1 ) , lps ( seq , i + 1 , j ) ) ; }
public static void Main ( ) { String seq = " GEEKSFORGEEKS " ; int n = seq . Length ; Console . Write ( " The ▁ length ▁ of ▁ the ▁ LPS ▁ is ▁ " + lps ( seq . ToCharArray ( ) , 0 , n - 1 ) ) ; } }
static bool isSubsetSum ( int [ ] arr , int n , int sum ) {
if ( sum == 0 ) return true ; if ( n == 0 && sum != 0 ) return false ;
if ( arr [ n - 1 ] > sum ) return isSubsetSum ( arr , n - 1 , sum ) ;
return isSubsetSum ( arr , n - 1 , sum ) || isSubsetSum ( arr , n - 1 , sum - arr [ n - 1 ] ) ; }
static bool findPartition ( int [ ] arr , int n ) {
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += arr [ i ] ;
if ( sum % 2 != 0 ) return false ;
return isSubsetSum ( arr , n , sum / 2 ) ; }
public static void Main ( ) { int [ ] arr = { 3 , 1 , 5 , 9 , 12 } ; int n = arr . Length ;
if ( findPartition ( arr , n ) == true ) Console . Write ( " Can ▁ be ▁ divided ▁ into ▁ two ▁ " + " subsets ▁ of ▁ equal ▁ sum " ) ; else Console . Write ( " Can ▁ not ▁ be ▁ divided ▁ into ▁ " + " two ▁ subsets ▁ of ▁ equal ▁ sum " ) ; } }
static int findoptimal ( int N ) {
if ( N <= 6 ) return N ;
int max = 0 ;
int b ; for ( b = N - 3 ; b >= 1 ; b -- ) {
int curr = ( N - b - 1 ) * findoptimal ( b ) ; if ( curr > max ) max = curr ; } return max ; }
static void Main ( ) { int N ;
for ( N = 1 ; N <= 20 ; N ++ ) Console . WriteLine ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with ▁ " + N + " ▁ keystrokes ▁ is ▁ " + findoptimal ( N ) ) ; } }
static void search ( string pat , string txt ) { int M = pat . Length ; int N = txt . Length ; int i = 0 ; while ( i <= N - M ) { int j ;
for ( j = 0 ; j < M ; j ++ ) if ( txt [ i + j ] != pat [ j ] ) break ;
if ( j == M ) { Console . WriteLine ( " Pattern ▁ found ▁ at ▁ index ▁ " + i ) ; i = i + M ; } else if ( j == 0 ) i = i + 1 ; else
i = i + j ; } }
static void Main ( ) { string txt = " ABCEABCDABCEABCD " ; string pat = " ABCD " ; search ( pat , txt ) ; } }
using System ; public class GFG { static float power ( float x , int y ) { float temp ; if ( y == 0 ) return 1 ; temp = power ( x , y / 2 ) ; if ( y % 2 == 0 ) return temp * temp ; else { if ( y > 0 ) return x * temp * temp ; else return ( temp * temp ) / x ; } }
public static void Main ( ) { float x = 2 ; int y = - 3 ; Console . Write ( power ( x , y ) ) ; } }
static int getMedian ( int [ ] ar1 , int [ ] ar2 , int n ) { int i = 0 ; int j = 0 ; int count ; int m1 = - 1 , m2 = - 1 ;
for ( count = 0 ; count <= n ; count ++ ) {
if ( i == n ) { m1 = m2 ; m2 = ar2 [ 0 ] ; break ; }
else if ( j = = n ) { m1 = m2 ; m2 = ar1 [ 0 ] ; break ; }
if ( ar1 [ i ] <= ar2 [ j ] ) {
m1 = m2 ; m2 = ar1 [ i ] ; i ++ ; } else {
m1 = m2 ; m2 = ar2 [ j ] ; j ++ ; } } return ( m1 + m2 ) / 2 ; }
public static void Main ( ) { int [ ] ar1 = { 1 , 12 , 15 , 26 , 38 } ; int [ ] ar2 = { 2 , 13 , 17 , 30 , 45 } ; int n1 = ar1 . Length ; int n2 = ar2 . Length ; if ( n1 == n2 ) Console . Write ( " Median ▁ is ▁ " + getMedian ( ar1 , ar2 , n1 ) ) ; else Console . Write ( " arrays ▁ are ▁ of ▁ unequal ▁ size " ) ; } }
static int multiply ( int x , int y ) {
if ( y == 0 ) return 0 ;
if ( y > 0 ) return ( x + multiply ( x , y - 1 ) ) ;
if ( y < 0 ) return - multiply ( x , - y ) ; return - 1 ; }
public static void Main ( ) { Console . WriteLine ( multiply ( 5 , - 11 ) ) ; } }
static int pow ( int a , int b ) { if ( b == 0 ) return 1 ; int answer = a ; int increment = a ; int i , j ; for ( i = 1 ; i < b ; i ++ ) { for ( j = 1 ; j < a ; j ++ ) { answer += increment ; } increment = answer ; } return answer ; }
public static void Main ( ) { Console . Write ( pow ( 5 , 3 ) ) ; } }
static int fact ( int n ) { return ( n <= 1 ) ? 1 : n * fact ( n - 1 ) ; }
static int findSmallerInRight ( string str , int low , int high ) { int countRight = 0 , i ; for ( i = low + 1 ; i <= high ; ++ i ) if ( str [ i ] < str [ low ] ) ++ countRight ; return countRight ; }
static int findRank ( string str ) { int len = str . Length ; int mul = fact ( len ) ; int rank = 1 ; int countRight ; for ( int i = 0 ; i < len ; ++ i ) { mul /= len - i ;
countRight = findSmallerInRight ( str , i , len - 1 ) ; rank += countRight * mul ; } return rank ; }
public static void Main ( ) { string str = " string " ; Console . Write ( findRank ( str ) ) ; } }
static int binomialCoeff ( int n , int k ) { int res = 1 ;
if ( k > n - k ) k = n - k ;
for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
public static void Main ( ) { int n = 8 ; int k = 2 ; Console . Write ( " Value ▁ of ▁ C ( " + n + " , ▁ " + k + " ) ▁ " + " is " + " ▁ " + binomialCoeff ( n , k ) ) ; } }
using System ; class GFG { public static void printPascal ( int n ) { for ( int line = 1 ; line <= n ; line ++ ) {
int C = 1 ; for ( int i = 1 ; i <= line ; i ++ ) {
Console . Write ( C + " ▁ " ) ; C = C * ( line - i ) / i ; } Console . Write ( " STRNEWLINE " ) ; } }
public static void Main ( ) { int n = 5 ; printPascal ( n ) ; } }
static float exponential ( int n , float x ) {
float sum = 1 ; for ( int i = n - 1 ; i > 0 ; -- i ) sum = 1 + x * sum / i ; return sum ; }
public static void Main ( ) { int n = 10 ; float x = 1 ; Console . Write ( " e ^ x ▁ = ▁ " + exponential ( n , x ) ) ; } }
static void printCombination ( int [ ] arr , int n , int r ) {
int [ ] data = new int [ r ] ;
combinationUtil ( arr , n , r , 0 , data , 0 ) ; }
static void combinationUtil ( int [ ] arr , int n , int r , int index , int [ ] data , int i ) {
if ( index == r ) { for ( int j = 0 ; j < r ; j ++ ) Console . Write ( data [ j ] + " ▁ " ) ; Console . WriteLine ( " " ) ; return ; }
if ( i >= n ) return ;
data [ index ] = arr [ i ] ; combinationUtil ( arr , n , r , index + 1 , data , i + 1 ) ;
combinationUtil ( arr , n , r , index , data , i + 1 ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; int r = 3 ; int n = arr . Length ; printCombination ( arr , n , r ) ; } }
static int calcAngle ( double h , double m ) {
if ( h < 0 m < 0 h > 12 m > 60 ) Console . Write ( " Wrong ▁ input " ) ; if ( h == 12 ) h = 0 ; if ( m == 60 ) { m = 0 ; h += 1 ; if ( h > 12 ) h = h - 12 ; }
int hour_angle = ( int ) ( 0.5 * ( h * 60 + m ) ) ; int minute_angle = ( int ) ( 6 * m ) ;
int angle = Math . Abs ( hour_angle - minute_angle ) ;
angle = Math . Min ( 360 - angle , angle ) ; return angle ; }
public static void Main ( ) { Console . WriteLine ( calcAngle ( 9 , 60 ) ) ; Console . Write ( calcAngle ( 3 , 30 ) ) ; } }
static int getSingle ( int [ ] arr , int n ) { int ones = 0 , twos = 0 ; int common_bit_mask ; for ( int i = 0 ; i < n ; i ++ ) {
twos = twos | ( ones & arr [ i ] ) ;
ones = ones ^ arr [ i ] ;
common_bit_mask = ~ ( ones & twos ) ;
ones &= common_bit_mask ;
twos &= common_bit_mask ; } return ones ; }
public static void Main ( ) { int [ ] arr = { 3 , 3 , 2 , 3 } ; int n = arr . Length ; Console . WriteLine ( " The ▁ element ▁ with ▁ single " + " occurrence ▁ is ▁ " + getSingle ( arr , n ) ) ; } }
using System ; class GFG { static int INT_SIZE = 32 ; static int getSingle ( int [ ] arr , int n ) {
int result = 0 ; int x , sum ;
for ( int i = 0 ; i < INT_SIZE ; i ++ ) {
sum = 0 ; x = ( 1 << i ) ; for ( int j = 0 ; j < n ; j ++ ) { if ( ( arr [ j ] & x ) == 0 ) sum ++ ; }
if ( ( sum % 3 ) != 0 ) result |= x ; } return result ; }
public static void Main ( ) { int [ ] arr = { 12 , 1 , 12 , 3 , 12 , 1 , 1 , 2 , 3 , 2 , 2 , 3 , 7 } ; int n = arr . Length ; Console . WriteLine ( " The ▁ element ▁ with ▁ single ▁ " + " occurrence ▁ is ▁ " + getSingle ( arr , n ) ) ; } }
using System ; class GFG { static int smallest ( int x , int y , int z ) { int c = 0 ; while ( x != 0 && y != 0 && z != 0 ) { x -- ; y -- ; z -- ; c ++ ; } return c ; }
public static void Main ( ) { int x = 12 , y = 15 , z = 5 ; Console . Write ( " Minimum ▁ of ▁ 3" + " ▁ numbers ▁ is ▁ " + smallest ( x , y , z ) ) ; } }
using System ; class GFG { static int addOne ( int x ) { return ( - ( ~ x ) ) ; }
public static void Main ( ) { Console . WriteLine ( addOne ( 13 ) ) ; } }
static int isPowerOfFour ( int n ) { int count = 0 ;
int x = n & ( n - 1 ) ; if ( n > 0 && x == 0 ) {
while ( n > 1 ) { n >>= 1 ; count += 1 ; }
return ( count % 2 == 0 ) ? 1 : 0 ; }
return 0 ; }
static void Main ( ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) > 0 ) Console . WriteLine ( " { 0 } ▁ is ▁ a ▁ power ▁ of ▁ 4" , test_no ) ; else Console . WriteLine ( " { 0 } ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" , test_no ) ; } }
public static int min ( int x , int y ) { return y ^ ( ( x ^ y ) & - ( x << y ) ) ; }
public static int max ( int x , int y ) { return x ^ ( ( x ^ y ) & - ( x << y ) ) ; }
public static void Main ( string [ ] args ) { int x = 15 ; int y = 6 ; Console . Write ( " Minimum ▁ of ▁ " + x + " ▁ and ▁ " + y + " ▁ is ▁ " ) ; Console . WriteLine ( min ( x , y ) ) ; Console . Write ( " Maximum ▁ of ▁ " + x + " ▁ and ▁ " + y + " ▁ is ▁ " ) ; Console . WriteLine ( max ( x , y ) ) ; } }
static int countSetBits ( int n ) { int count = 0 ; while ( n > 0 ) { count += n & 1 ; n >>= 1 ; } return count ; }
public static void Main ( ) { int i = 9 ; Console . Write ( countSetBits ( i ) ) ; } }
class GFG { static int [ ] num_to_bits = new int [ 16 ] { 0 , 1 , 1 , 2 , 1 , 2 , 2 , 3 , 1 , 2 , 2 , 3 , 2 , 3 , 3 , 4 } ;
static int countSetBitsRec ( int num ) { int nibble = 0 ; if ( 0 == num ) return num_to_bits [ 0 ] ;
nibble = num & 0xf ;
return num_to_bits [ nibble ] + countSetBitsRec ( num >> 4 ) ; }
static void Main ( ) { int num = 31 ; System . Console . WriteLine ( countSetBitsRec ( num ) ) ; } }
using System ; class GFG { static int nextPowerOf2 ( int n ) { int p = 1 ; if ( n > 0 && ( n & ( n - 1 ) ) == 0 ) return n ; while ( p < n ) p <<= 1 ; return p ; }
public static void Main ( ) { int n = 5 ; Console . Write ( nextPowerOf2 ( n ) ) ; } }
static int nextPowerOf2 ( int n ) { n -- ; n |= n >> 1 ; n |= n >> 2 ; n |= n >> 4 ; n |= n >> 8 ; n |= n >> 16 ; n ++ ; return n ; }
public static void Main ( ) { int n = 5 ; Console . WriteLine ( nextPowerOf2 ( n ) ) ; } }
static bool getParity ( int n ) { bool parity = false ; while ( n != 0 ) { parity = ! parity ; n = n & ( n - 1 ) ; } return parity ; }
public static void Main ( ) { int n = 7 ; Console . Write ( " Parity ▁ of ▁ no ▁ " + n + " ▁ = ▁ " + ( getParity ( n ) ? " odd " : " even " ) ) ; } }
static bool isPowerOfTwo ( int n ) { if ( n == 0 ) return false ; return ( int ) ( Math . Ceiling ( ( Math . Log ( n ) / Math . Log ( 2 ) ) ) ) == ( int ) ( Math . Floor ( ( ( Math . Log ( n ) / Math . Log ( 2 ) ) ) ) ) ; }
public static void Main ( ) { if ( isPowerOfTwo ( 31 ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; if ( isPowerOfTwo ( 64 ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
static bool isPowerOfTwo ( int x ) {
return x != 0 && ( ( x & ( x - 1 ) ) == 0 ) ; }
public static void Main ( ) { Console . WriteLine ( isPowerOfTwo ( 31 ) ? " Yes " : " No " ) ; Console . WriteLine ( isPowerOfTwo ( 64 ) ? " Yes " : " No " ) ; } }
static long swapBits ( int x ) {
long even_bits = x & 0xAAAAAAAA ;
long odd_bits = x & 0x55555555 ;
even_bits >>= 1 ;
odd_bits <<= 1 ;
return ( even_bits odd_bits ) ; }
int x = 23 ;
Console . Write ( swapBits ( x ) ) ; } }
static bool isPowerOfTwo ( int n ) { return ( n > 0 && ( ( n & ( n - 1 ) ) == 0 ) ) ? true : false ; }
static int findPosition ( int n ) { if ( ! isPowerOfTwo ( n ) ) return - 1 ; int i = 1 , pos = 1 ;
while ( ( i & n ) == 0 ) {
i = i << 1 ;
++ pos ; } return pos ; }
static void Main ( ) { int n = 16 ; int pos = findPosition ( n ) ; if ( pos == - 1 ) Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Invalid ▁ number " ) ; else Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Position ▁ " + pos ) ; n = 12 ; pos = findPosition ( n ) ; if ( pos == - 1 ) Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Invalid ▁ number " ) ; else Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Position ▁ " + pos ) ; n = 128 ; pos = findPosition ( n ) ; if ( pos == - 1 ) Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Invalid ▁ number " ) ; else Console . WriteLine ( " n ▁ = ▁ " + n + " , ▁ Position ▁ " + pos ) ; } }
void segregate0and1 ( int [ ] arr , int size ) {
int left = 0 , right = size - 1 ; while ( left < right ) {
while ( arr [ left ] == 0 && left < right ) left ++ ;
while ( arr [ right ] == 1 && left < right ) right -- ;
if ( left < right ) { arr [ left ] = 0 ; arr [ right ] = 1 ; left ++ ; right -- ; } } }
public static void Main ( ) { Segregate seg = new Segregate ( ) ; int [ ] arr = new int [ ] { 0 , 1 , 0 , 1 , 1 , 1 } ; int i , arr_size = arr . Length ; seg . segregate0and1 ( arr , arr_size ) ; Console . WriteLine ( " Array ▁ after ▁ segregation ▁ is ▁ " ) ; for ( i = 0 ; i < 6 ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static void nextGreatest ( int [ ] arr ) { int size = arr . Length ;
int max_from_right = arr [ size - 1 ] ;
arr [ size - 1 ] = - 1 ;
for ( int i = size - 2 ; i >= 0 ; i -- ) {
int temp = arr [ i ] ;
arr [ i ] = max_from_right ;
if ( max_from_right < temp ) max_from_right = temp ; } }
static void printArray ( int [ ] arr ) { for ( int i = 0 ; i < arr . Length ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 16 , 17 , 4 , 3 , 5 , 2 } ; nextGreatest ( arr ) ; Console . WriteLine ( " The ▁ modified ▁ array : " ) ; printArray ( arr ) ; } }
static int maxDiff ( int [ ] arr , int arr_size ) { int max_diff = arr [ 1 ] - arr [ 0 ] ; int i , j ; for ( i = 0 ; i < arr_size ; i ++ ) { for ( j = i + 1 ; j < arr_size ; j ++ ) { if ( arr [ j ] - arr [ i ] > max_diff ) max_diff = arr [ j ] - arr [ i ] ; } } return max_diff ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 90 , 10 , 110 } ;
Console . Write ( " Maximum ▁ difference ▁ is ▁ " + maxDiff ( arr , 5 ) ) ; } }
using System ; class GFG { static int findMaximum ( int [ ] arr , int low , int high ) {
if ( low == high ) return arr [ low ] ;
if ( ( high == low + 1 ) && arr [ low ] >= arr [ high ] ) return arr [ low ] ;
if ( ( high == low + 1 ) && arr [ low ] < arr [ high ] ) return arr [ high ] ; int mid = ( low + high ) / 2 ;
if ( arr [ mid ] > arr [ mid + 1 ] && arr [ mid ] > arr [ mid - 1 ] ) return arr [ mid ] ;
if ( arr [ mid ] > arr [ mid + 1 ] && arr [ mid ] < arr [ mid - 1 ] ) return findMaximum ( arr , low , mid - 1 ) ;
else return findMaximum ( arr , mid + 1 , high ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 50 , 10 , 9 , 7 , 6 } ; int n = arr . Length ; Console . Write ( " The ▁ maximum ▁ element ▁ is ▁ " + findMaximum ( arr , 0 , n - 1 ) ) ; } }
static int getMissingNo ( int [ ] a , int n ) { int total = ( n + 1 ) * ( n + 2 ) / 2 ; for ( int i = 0 ; i < n ; i ++ ) total -= a [ i ] ; return total ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 4 , 5 , 6 } ; int miss = getMissingNo ( a , 5 ) ; Console . Write ( miss ) ; } }
using System ; class GFG { static void printTwoElements ( int [ ] arr , int size ) { int i ; Console . Write ( " The ▁ repeating ▁ element ▁ is ▁ " ) ; for ( i = 0 ; i < size ; i ++ ) { int abs_val = Math . Abs ( arr [ i ] ) ; if ( arr [ abs_val - 1 ] > 0 ) arr [ abs_val - 1 ] = - arr [ abs_val - 1 ] ; else Console . WriteLine ( abs_val ) ; } Console . Write ( " And ▁ the ▁ missing ▁ element ▁ is ▁ " ) ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] > 0 ) Console . WriteLine ( i + 1 ) ; } }
public static void Main ( ) { int [ ] arr = { 7 , 3 , 4 , 5 , 5 , 6 , 2 } ; int n = arr . Length ; printTwoElements ( arr , n ) ; } }
static void printTwoOdd ( int [ ] arr , int size ) {
int xor2 = arr [ 0 ] ;
int set_bit_no ; int i ; int n = size - 2 ; int x = 0 , y = 0 ;
for ( i = 1 ; i < size ; i ++ ) xor2 = xor2 ^ arr [ i ] ;
set_bit_no = xor2 & ~ ( xor2 - 1 ) ;
for ( i = 0 ; i < size ; i ++ ) {
if ( ( arr [ i ] & set_bit_no ) > 0 ) x = x ^ arr [ i ] ;
else y = y ^ arr [ i ] ; } Console . WriteLine ( " The ▁ two ▁ ODD ▁ elements ▁ are ▁ " + x + " ▁ & ▁ " + y ) ; }
public static void Main ( ) { int [ ] arr = { 4 , 2 , 4 , 5 , 2 , 3 , 3 , 1 } ; int arr_size = arr . Length ; printTwoOdd ( arr , arr_size ) ; } }
static bool findPair ( int [ ] arr , int n ) { int size = arr . Length ;
int i = 0 , j = 1 ;
while ( i < size && j < size ) { if ( i != j && arr [ j ] - arr [ i ] == n ) { Console . Write ( " Pair ▁ Found : ▁ " + " ( ▁ " + arr [ i ] + " , ▁ " + arr [ j ] + " ▁ ) " ) ; return true ; } else if ( arr [ j ] - arr [ i ] < n ) j ++ ; else i ++ ; } Console . Write ( " No ▁ such ▁ pair " ) ; return false ; }
public static void Main ( ) { int [ ] arr = { 1 , 8 , 30 , 40 , 100 } ; int n = 60 ; findPair ( arr , n ) ; } }
void findFourElements ( int [ ] A , int n , int X ) {
for ( int i = 0 ; i < n - 3 ; i ++ ) {
for ( int j = i + 1 ; j < n - 2 ; j ++ ) {
for ( int k = j + 1 ; k < n - 1 ; k ++ ) {
for ( int l = k + 1 ; l < n ; l ++ ) { if ( A [ i ] + A [ j ] + A [ k ] + A [ l ] == X ) Console . Write ( A [ i ] + " ▁ " + A [ j ] + " ▁ " + A [ k ] + " ▁ " + A [ l ] ) ; } } } } }
public static void Main ( ) { FindFourElements findfour = new FindFourElements ( ) ; int [ ] A = { 10 , 20 , 30 , 40 , 1 , 2 } ; int n = A . Length ; int X = 91 ; findfour . findFourElements ( A , n , X ) ; } }
static int cola = 2 , rowa = 3 ; static int colb = 3 , rowb = 2 ;
static void Kroneckerproduct ( int [ , ] A , int [ , ] B ) { int [ , ] C = new int [ rowa * rowb , cola * colb ] ;
for ( int i = 0 ; i < rowa ; i ++ ) {
for ( int k = 0 ; k < rowb ; k ++ ) {
for ( int j = 0 ; j < cola ; j ++ ) {
for ( int l = 0 ; l < colb ; l ++ ) {
C [ i + l + 1 , j + k + 1 ] = A [ i , j ] * B [ k , l ] ; Console . Write ( C [ i + l + 1 , j + k + 1 ] + " ▁ " ) ; } } Console . WriteLine ( ) ; } } }
public static void Main ( ) { int [ , ] A = { { 1 , 2 } , { 3 , 4 } , { 1 , 0 } } ; int [ , ] B = { { 0 , 5 , 2 } , { 6 , 7 , 3 } } ; Kroneckerproduct ( A , B ) ; } }
using System ; class GFG { static int identity ( int num ) { int row , col ; for ( row = 0 ; row < num ; row ++ ) { for ( col = 0 ; col < num ; col ++ ) {
if ( row == col ) Console . Write ( 1 + " ▁ " ) ; else Console . Write ( 0 + " ▁ " ) ; } Console . WriteLine ( ) ; } return 0 ; }
public static void Main ( ) { int size = 5 ; identity ( size ) ; } }
using System ; class GFG { static int N = 4 ;
public static void subtract ( int [ ] [ ] A , int [ ] [ ] B , int [ , ] C ) { int i , j ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < N ; j ++ ) { C [ i , j ] = A [ i ] [ j ] - B [ i ] [ j ] ; } } }
public static void Main ( string [ ] args ) { int [ ] [ ] A = new int [ ] [ ] { new int [ ] { 1 , 1 , 1 , 1 } , new int [ ] { 2 , 2 , 2 , 2 } , new int [ ] { 3 , 3 , 3 , 3 } , new int [ ] { 4 , 4 , 4 , 4 } } ; int [ ] [ ] B = new int [ ] [ ] { new int [ ] { 1 , 1 , 1 , 1 } , new int [ ] { 2 , 2 , 2 , 2 } , new int [ ] { 3 , 3 , 3 , 3 } , new int [ ] { 4 , 4 , 4 , 4 } } ; int [ , ] C = new int [ N , N ] ; int i , j ; subtract ( A , B , C ) ; Console . Write ( " Result ▁ matrix ▁ is ▁ STRNEWLINE " ) ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < N ; j ++ ) { Console . Write ( C [ i , j ] + " ▁ " ) ; } Console . Write ( " STRNEWLINE " ) ; } } }
