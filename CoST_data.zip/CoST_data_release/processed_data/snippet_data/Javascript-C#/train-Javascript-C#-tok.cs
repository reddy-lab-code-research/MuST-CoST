class Node { int key ; Node left , right ; public Node ( int item ) { key = item ; left = right = null ; } }
using System ; using System . Collections . Generic ; public class GFG { static List < int > no_NGN ( int [ ] arr , int n ) { List < int > nxt = new List < int > ( ) ;
Stack < int > s = new Stack < int > ( ) ; nxt . Add ( 0 ) ;
s . Push ( n - 1 ) ;
for ( int i = n - 2 ; i >= 0 ; i -- ) { while ( s . Count != 0 && arr [ i ] >= arr [ s . Peek ( ) ] ) s . Pop ( ) ;
if ( s . Count == 0 ) nxt . Add ( 0 ) ; else
nxt . Add ( nxt [ n - s . Peek ( ) - 1 ] + 1 ) ; s . Push ( i ) ; }
nxt . Reverse ( ) ;
return nxt ; }
public static void Main ( String [ ] args ) { int n = 8 ; int [ ] arr = { 3 , 4 , 2 , 7 , 5 , 8 , 10 , 6 } ; List < int > nxt = no_NGN ( arr , n ) ;
Console . Write ( nxt [ 3 ] + " STRNEWLINE " ) ;
Console . Write ( nxt [ 6 ] + " STRNEWLINE " ) ;
Console . Write ( nxt [ 1 ] + " STRNEWLINE " ) ; } }
static Stack < int > sortStack ( Stack < int > input ) { Stack < int > tmpStack = new Stack < int > ( ) ; while ( input . Count != 0 ) {
int tmp = input . Peek ( ) ; input . Pop ( ) ;
while ( tmpStack . Count != 0 && tmpStack . Peek ( ) < tmp ) {
input . Push ( tmpStack . Peek ( ) ) ; tmpStack . Pop ( ) ; }
tmpStack . Push ( tmp ) ; } return tmpStack ; } static void sortArrayUsingStacks ( int [ ] arr , int n ) {
Stack < int > input = new Stack < int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) input . Push ( arr [ i ] ) ;
Stack < int > tmpStack = sortStack ( input ) ;
for ( int i = 0 ; i < n ; i ++ ) { arr [ i ] = tmpStack . Peek ( ) ; tmpStack . Pop ( ) ; } }
static void Main ( ) { int [ ] arr = new int [ ] { 10 , 5 , 15 , 45 } ; int n = arr . Length ; sortArrayUsingStacks ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
using System ; class GFG { static void towerOfHanoi ( int n , char from_rod , char to_rod , char aux_rod ) { if ( n == 1 ) { Console . WriteLine ( " Move ▁ disk ▁ 1 ▁ from ▁ rod ▁ " + from_rod + " ▁ to ▁ rod ▁ " + to_rod ) ; return ; } towerOfHanoi ( n - 1 , from_rod , aux_rod , to_rod ) ; Console . WriteLine ( " Move ▁ disk ▁ " + n + " ▁ from ▁ rod ▁ " + from_rod + " ▁ to ▁ rod ▁ " + to_rod ) ; towerOfHanoi ( n - 1 , aux_rod , to_rod , from_rod ) ; }
int n = 4 ;
towerOfHanoi ( n , ' A ' , ' C ' , ' B ' ) ; } }
using System ; class GFG { static int [ ] arr = { 10 , 20 , 30 , 50 , 10 , 70 , 30 } ; static void printMaxOfMin ( int n ) {
for ( int k = 1 ; k <= n ; k ++ ) {
int maxOfMin = int . MinValue ;
for ( int i = 0 ; i <= n - k ; i ++ ) {
int min = arr [ i ] ; for ( int j = 1 ; j < k ; j ++ ) { if ( arr [ i + j ] < min ) min = arr [ i + j ] ; }
if ( min > maxOfMin ) maxOfMin = min ; }
Console . Write ( maxOfMin + " ▁ " ) ; } }
public static void Main ( ) { printMaxOfMin ( arr . Length ) ; } }
using System ; using System . Collections . Generic ; class GFG { public static int [ ] arr = new int [ ] { 10 , 20 , 30 , 50 , 10 , 70 , 30 } ; public static void printMaxOfMin ( int n ) {
Stack < int > s = new Stack < int > ( ) ;
int [ ] left = new int [ n + 1 ] ; int [ ] right = new int [ n + 1 ] ;
for ( int i = 0 ; i < n ; i ++ ) { left [ i ] = - 1 ; right [ i ] = n ; }
for ( int i = 0 ; i < n ; i ++ ) { while ( s . Count > 0 && arr [ s . Peek ( ) ] >= arr [ i ] ) { s . Pop ( ) ; } if ( s . Count > 0 ) { left [ i ] = s . Peek ( ) ; } s . Push ( i ) ; }
while ( s . Count > 0 ) { s . Pop ( ) ; }
for ( int i = n - 1 ; i >= 0 ; i -- ) { while ( s . Count > 0 && arr [ s . Peek ( ) ] >= arr [ i ] ) { s . Pop ( ) ; } if ( s . Count > 0 ) { right [ i ] = s . Peek ( ) ; } s . Push ( i ) ; }
int [ ] ans = new int [ n + 1 ] ; for ( int i = 0 ; i <= n ; i ++ ) { ans [ i ] = 0 ; }
for ( int i = 0 ; i < n ; i ++ ) {
int len = right [ i ] - left [ i ] - 1 ;
ans [ len ] = Math . Max ( ans [ len ] , arr [ i ] ) ; }
for ( int i = n - 1 ; i >= 1 ; i -- ) { ans [ i ] = Math . Max ( ans [ i ] , ans [ i + 1 ] ) ; }
for ( int i = 1 ; i <= n ; i ++ ) { Console . Write ( ans [ i ] + " ▁ " ) ; } }
public static int solve ( String s , int n ) {
int left = 0 , right = 0 ; int maxlength = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( s [ i ] == ' ( ' ) left ++ ; else right ++ ;
if ( left == right ) maxlength = Math . Max ( maxlength , 2 * right ) ;
else if ( right > left ) left = right = 0 ; } left = right = 0 ;
for ( int i = n - 1 ; i >= 0 ; i -- ) {
if ( s [ i ] == ' ( ' ) left ++ ; else right ++ ;
if ( left == right ) maxlength = Math . Max ( maxlength , 2 * left ) ;
else if ( left > right ) left = right = 0 ; } return maxlength ; }
Console . Write ( solve ( " ( ( ( ) ( ) ( ) ( ) ( ( ( ( ) ) " , 16 ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static void printLeast ( String arr ) {
int min_avail = 1 , pos_of_I = 0 ;
List < int > al = new List < int > ( ) ;
if ( arr [ 0 ] == ' I ' ) { al . Add ( 1 ) ; al . Add ( 2 ) ; min_avail = 3 ; pos_of_I = 1 ; } else { al . Add ( 2 ) ; al . Add ( 1 ) ; min_avail = 3 ; pos_of_I = 0 ; }
for ( int i = 1 ; i < arr . Length ; i ++ ) { if ( arr [ i ] == ' I ' ) { al . Add ( min_avail ) ; min_avail ++ ; pos_of_I = i + 1 ; } else { al . Add ( al [ i ] ) ; for ( int j = pos_of_I ; j <= i ; j ++ ) al [ j ] = al [ j ] + 1 ; min_avail ++ ; } }
for ( int i = 0 ; i < al . Count ; i ++ ) Console . Write ( al [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( String [ ] args ) { printLeast ( " IDID " ) ; printLeast ( " I " ) ; printLeast ( " DD " ) ; printLeast ( " II " ) ; printLeast ( " DIDI " ) ; printLeast ( " IIDDD " ) ; printLeast ( " DDIDDIID " ) ; } }
static void PrintMinNumberForPattern ( String seq ) {
String result = " " ;
Stack stk = new Stack ( ) ;
for ( int i = 0 ; i <= seq . Length ; i ++ ) {
stk . Push ( i + 1 ) ;
if ( i == seq . Length seq [ i ] == ' I ' ) {
while ( stk . Count != 0 ) {
result += String . Join ( " " , stk . Peek ( ) ) ; result += " ▁ " ; stk . Pop ( ) ; } } } Console . WriteLine ( result ) ; }
public static void Main ( ) { PrintMinNumberForPattern ( " IDID " ) ; PrintMinNumberForPattern ( " I " ) ; PrintMinNumberForPattern ( " DD " ) ; PrintMinNumberForPattern ( " II " ) ; PrintMinNumberForPattern ( " DIDI " ) ; PrintMinNumberForPattern ( " IIDDD " ) ; PrintMinNumberForPattern ( " DDIDDIID " ) ; } }
static String getMinNumberForPattern ( String seq ) { int n = seq . Length ; if ( n >= 9 ) return " - 1" ; char [ ] result = new char [ n + 1 ] ; int count = 1 ;
for ( int i = 0 ; i <= n ; i ++ ) { if ( i == n seq [ i ] == ' I ' ) { for ( int j = i - 1 ; j >= - 1 ; j -- ) { result [ j + 1 ] = ( char ) ( ( int ) '0' + count ++ ) ; if ( j >= 0 && seq [ j ] == ' I ' ) break ; } } } return new String ( result ) ; }
public static void Main ( ) { String [ ] inputs = { " IDID " , " I " , " DD " , " II " , " DIDI " , " IIDDD " , " DDIDDIID " } ; foreach ( String input in inputs ) { Console . WriteLine ( getMinNumberForPattern ( input ) ) ; } } }
public static void nextGreater ( int [ ] arr , int [ ] next , char order ) {
Stack < int > stack = new Stack < int > ( ) ;
for ( int i = arr . Length - 1 ; i >= 0 ; i -- ) {
while ( stack . Count != 0 && ( ( order == ' G ' ) ? arr [ stack . Peek ( ) ] <= arr [ i ] : arr [ stack . Peek ( ) ] >= arr [ i ] ) ) stack . Pop ( ) ;
if ( stack . Count != 0 ) next [ i ] = stack . Peek ( ) ;
else next [ i ] = - 1 ;
stack . Push ( i ) ; } }
public static void nextSmallerOfNextGreater ( int [ ] arr ) {
int [ ] NG = new int [ arr . Length ] ;
int [ ] RS = new int [ arr . Length ] ;
nextGreater ( arr , NG , ' G ' ) ;
nextGreater ( arr , RS , ' S ' ) ;
for ( int i = 0 ; i < arr . Length ; i ++ ) { if ( NG [ i ] != - 1 && RS [ NG [ i ] ] != - 1 ) Console . Write ( arr [ RS [ NG [ i ] ] ] + " ▁ " ) ; else Console . Write ( " - 1 ▁ " ) ; } }
public static void Main ( ) { int [ ] arr = { 5 , 1 , 9 , 2 , 5 , 1 , 7 } ; nextSmallerOfNextGreater ( arr ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int data ) { this . data = data ; } } ;
public static Node flipBinaryTree ( Node root ) { if ( root == null ) return root ; if ( root . left == null && root . right == null ) return root ;
Node flippedRoot = flipBinaryTree ( root . left ) ;
root . left . left = root . right ; root . left . right = root ; root . left = root . right = null ; return flippedRoot ; }
public static void printLevelOrder ( Node root ) {
if ( root == null ) return ;
Queue < Node > q = new Queue < Node > ( ) ;
q . Enqueue ( root ) ; while ( true ) {
int nodeCount = q . Count ; if ( nodeCount == 0 ) break ;
while ( nodeCount > 0 ) { Node node = q . Dequeue ( ) ; Console . Write ( node . data + " ▁ " ) ; if ( node . left != null ) q . Enqueue ( node . left ) ; if ( node . right != null ) q . Enqueue ( node . right ) ; nodeCount -- ; } Console . WriteLine ( ) ; } }
public static void Main ( String [ ] args ) { Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 1 ) ; root . right . left = new Node ( 4 ) ; root . right . right = new Node ( 5 ) ; Console . WriteLine ( " Level ▁ order ▁ traversal ▁ of ▁ given ▁ tree " ) ; printLevelOrder ( root ) ; root = flipBinaryTree ( root ) ; Console . WriteLine ( " Level ▁ order ▁ traversal ▁ of ▁ flipped ▁ tree " ) ; printLevelOrder ( root ) ; } }
void heapify ( int [ ] arr , int n , int i ) {
int largest = i ;
int l = 2 * i + 1 ;
int r = 2 * i + 2 ;
if ( l < n && arr [ l ] > arr [ largest ] ) largest = l ;
if ( r < n && arr [ r ] > arr [ largest ] ) largest = r ;
if ( largest != i ) { int swap = arr [ i ] ; arr [ i ] = arr [ largest ] ; arr [ largest ] = swap ;
heapify ( arr , n , largest ) ; } }
public void sort ( int [ ] arr ) { int n = arr . Length ;
for ( int i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( int i = n - 1 ; i > 0 ; i -- ) {
int temp = arr [ 0 ] ; arr [ 0 ] = arr [ i ] ; arr [ i ] = temp ;
heapify ( arr , i , 0 ) ; } }
static void printArray ( int [ ] arr ) { int n = arr . Length ; for ( int i = 0 ; i < n ; ++ i ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . Read ( ) ; }
public static void Main ( ) { int [ ] arr = { 12 , 11 , 13 , 5 , 6 , 7 } ; int n = arr . Length ; HeapSort ob = new HeapSort ( ) ; ob . sort ( arr ) ; Console . WriteLine ( " Sorted ▁ array ▁ is " ) ; printArray ( arr ) ; } }
static bool isHeap ( int [ ] arr , int n ) {
for ( int i = 0 ; i <= ( n - 2 ) / 2 ; i ++ ) {
if ( arr [ 2 * i + 1 ] > arr [ i ] ) { return false ; }
if ( 2 * i + 2 < n && arr [ 2 * i + 2 ] > arr [ i ] ) { return false ; } } return true ; }
public static void Main ( ) { int [ ] arr = { 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 } ; int n = arr . Length ; if ( isHeap ( arr , n ) ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " No " ) ; } } }
public static void mergeKArrays ( int [ , ] arr , int a , int [ ] output ) { int c = 0 ;
for ( int i = 0 ; i < a ; i ++ ) { for ( int j = 0 ; j < 4 ; j ++ ) output [ c ++ ] = arr [ i , j ] ; }
Array . Sort ( output ) ; }
public static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ , ] arr = { { 2 , 6 , 12 , 34 } , { 1 , 9 , 20 , 1000 } , { 23 , 34 , 90 , 2000 } } ; int k = 4 ; int n = 3 ; int [ ] output = new int [ n * k ] ; mergeKArrays ( arr , n , output ) ; Console . WriteLine ( " Merged ▁ array ▁ is ▁ " ) ; printArray ( output , n * k ) ; } }
using System ; class GFG { static void generate_derangement ( int N ) {
int [ ] S = new int [ N + 1 ] ; for ( int i = 1 ; i <= N ; i ++ ) S [ i ] = i ;
int [ ] D = new int [ N + 1 ] ; for ( int i = 1 ; i <= N ; i += 2 ) { if ( i == N ) {
D [ N ] = S [ N - 1 ] ; D [ N - 1 ] = S [ N ] ; } else { D [ i ] = i + 1 ; D [ i + 1 ] = i ; } }
for ( int i = 1 ; i <= N ; i ++ ) Console . Write ( D [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( ) { generate_derangement ( 10 ) ; } }
static void heapify ( int [ ] arr , int n , int i ) {
int smallest = i ;
int l = 2 * i + 1 ;
int r = 2 * i + 2 ;
if ( l < n && arr [ l ] < arr [ smallest ] ) smallest = l ;
if ( r < n && arr [ r ] < arr [ smallest ] ) smallest = r ;
if ( smallest != i ) { int temp = arr [ i ] ; arr [ i ] = arr [ smallest ] ; arr [ smallest ] = temp ;
heapify ( arr , n , smallest ) ; } }
static void heapSort ( int [ ] arr , int n ) {
for ( int i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int temp = arr [ 0 ] ; arr [ 0 ] = arr [ i ] ; arr [ i ] = temp ;
heapify ( arr , i , 0 ) ; } }
static void printArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; ++ i ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( ) { int [ ] arr = { 4 , 6 , 3 , 2 , 9 } ; int n = arr . Length ; heapSort ( arr , n ) ; Console . WriteLine ( " Sorted ▁ array ▁ is ▁ " ) ; printArray ( arr , n ) ; } }
static int sumBetweenTwoKth ( int [ ] arr , int n , int k1 , int k2 ) {
Array . Sort ( arr ) ;
int result = 0 ; for ( int i = k1 ; i < k2 - 1 ; i ++ ) result += arr [ i ] ; return result ; }
public static void Main ( ) { int [ ] arr = { 20 , 8 , 22 , 4 , 12 , 10 , 14 } ; int k1 = 3 , k2 = 6 ; int n = arr . Length ; Console . Write ( sumBetweenTwoKth ( arr , n , k1 , k2 ) ) ; } }
static int minSum ( int [ ] a , int n ) {
Array . Sort ( a ) ; int num1 = 0 ; int num2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) num1 = num1 * 10 + a [ i ] ; else num2 = num2 * 10 + a [ i ] ; } return num2 + num1 ; }
static public void Main ( ) { int [ ] arr = { 5 , 3 , 0 , 7 , 4 } ; int n = arr . Length ; Console . WriteLine ( " The ▁ required ▁ sum ▁ is ▁ " + minSum ( arr , n ) ) ; } }
using System ; public class Node { public int key ; public Node left , right ; public Node ( int key ) { this . key = key ; left = right = null ; } } class GFG { public Node root ;
public virtual int count ( Node node ) { if ( node == null ) { return 0 ; } return count ( node . left ) + count ( node . right ) + 1 ; }
public virtual bool checkRec ( Node node , int n ) {
if ( node == null ) { return false ; }
if ( count ( node ) == n - count ( node ) ) { return true ; }
return checkRec ( node . left , n ) || checkRec ( node . right , n ) ; }
public virtual bool check ( Node node ) {
int n = count ( node ) ;
return checkRec ( node , n ) ; }
public static void Main ( string [ ] args ) { GFG tree = new GFG ( ) ; tree . root = new Node ( 5 ) ; tree . root . left = new Node ( 1 ) ; tree . root . right = new Node ( 6 ) ; tree . root . left . left = new Node ( 3 ) ; tree . root . right . left = new Node ( 7 ) ; tree . root . right . right = new Node ( 4 ) ; if ( tree . check ( tree . root ) == true ) { Console . WriteLine ( " YES " ) ; } else { Console . WriteLine ( " NO " ) ; } } }
static void stack_push ( Stack < int > stack ) { for ( int i = 0 ; i < 5 ; i ++ ) { stack . Push ( i ) ; } }
static void stack_pop ( Stack < int > stack ) { Console . WriteLine ( " Pop ▁ : " ) ; for ( int i = 0 ; i < 5 ; i ++ ) { int y = ( int ) stack . Pop ( ) ; Console . WriteLine ( y ) ; } }
static void stack_peek ( Stack < int > stack ) { int element = ( int ) stack . Peek ( ) ; Console . WriteLine ( " Element ▁ on ▁ stack ▁ top ▁ : ▁ " + element ) ; }
static void stack_search ( Stack < int > stack , int element ) { bool pos = stack . Contains ( element ) ; if ( pos == false ) Console . WriteLine ( " Element ▁ not ▁ found " ) ; else Console . WriteLine ( " Element ▁ is ▁ found ▁ at ▁ position ▁ " + pos ) ; }
public static void Main ( String [ ] args ) { Stack < int > stack = new Stack < int > ( ) ; stack_push ( stack ) ; stack_pop ( stack ) ; stack_push ( stack ) ; stack_peek ( stack ) ; stack_search ( stack , 2 ) ; stack_search ( stack , 6 ) ; } }
using System ; public class Node { public int key ; public Node left , right ; public Node ( int key ) { this . key = key ; left = right = null ; } } public class Res { public bool res = false ; } public class BinaryTree { public Node root ;
public virtual int count ( Node node ) { if ( node == null ) { return 0 ; } return count ( node . left ) + count ( node . right ) + 1 ; }
public virtual int checkRec ( Node root , int n , Res res ) {
if ( root == null ) { return 0 ; }
int c = checkRec ( root . left , n , res ) + 1 + checkRec ( root . right , n , res ) ;
if ( c == n - c ) { res . res = true ; }
return c ; }
public virtual bool check ( Node root ) {
int n = count ( root ) ;
Res res = new Res ( ) ; checkRec ( root , n , res ) ; return res . res ; }
public static void Main ( string [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 5 ) ; tree . root . left = new Node ( 1 ) ; tree . root . right = new Node ( 6 ) ; tree . root . left . left = new Node ( 3 ) ; tree . root . right . left = new Node ( 7 ) ; tree . root . right . right = new Node ( 4 ) ; if ( tree . check ( tree . root ) == true ) { Console . WriteLine ( " YES " ) ; } else { Console . WriteLine ( " NO " ) ; } } }
using System ; public class GfG { static int preIndex = 0 ;
class Node { public int data ; public Node left , right ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . left = null ; temp . right = null ; return temp ; }
static int search ( int [ ] arr , int strt , int end , int value ) { for ( int i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) return i ; } return - 1 ; }
static Node buildTree ( int [ ] In , int [ ] pre , int inStrt , int inEnd ) { if ( inStrt > inEnd ) return null ;
Node tNode = newNode ( pre [ preIndex ++ ] ) ;
if ( inStrt == inEnd ) return tNode ;
int inIndex = search ( In , inStrt , inEnd , tNode . data ) ;
tNode . left = buildTree ( In , pre , inStrt , inIndex - 1 ) ; tNode . right = buildTree ( In , pre , inIndex + 1 , inEnd ) ; return tNode ; }
static int checkPostorder ( Node node , int [ ] postOrder , int index ) { if ( node == null ) return index ;
index = checkPostorder ( node . left , postOrder , index ) ;
index = checkPostorder ( node . right , postOrder , index ) ;
if ( node . data == postOrder [ index ] ) index ++ ; else return - 1 ; return index ; }
public static void Main ( ) { int [ ] inOrder = { 4 , 2 , 5 , 1 , 3 } ; int [ ] preOrder = { 1 , 2 , 4 , 5 , 3 } ; int [ ] postOrder = { 4 , 5 , 2 , 3 , 1 } ; int len = inOrder . Length ;
Node root = buildTree ( inOrder , preOrder , 0 , len - 1 ) ;
int index = checkPostorder ( root , postOrder , 0 ) ;
if ( index == len ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG { static int N = 3 ; static int M = 4 ;
static void printDistance ( int [ , ] mat ) { int [ , ] ans = new int [ N , M ] ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) ans [ i , j ] = int . MaxValue ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) {
for ( int k = 0 ; k < N ; k ++ ) for ( int l = 0 ; l < M ; l ++ ) {
if ( mat [ k , l ] == 1 ) ans [ i , j ] = Math . Min ( ans [ i , j ] , Math . Abs ( i - k ) + Math . Abs ( j - l ) ) ; } }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) Console . Write ( ans [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] mat = { { 0 , 0 , 0 , 1 } , { 0 , 0 , 1 , 1 } , { 0 , 1 , 1 , 0 } } ; printDistance ( mat ) ; } }
static int isChangeable ( int [ ] notes , int n ) {
int fiveCount = 0 ; int tenCount = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( notes [ i ] == 5 ) fiveCount ++ ; else if ( notes [ i ] == 10 ) {
if ( fiveCount > 0 ) { fiveCount -- ; tenCount ++ ; } else return 0 ; } else {
if ( fiveCount > 0 && tenCount > 0 ) { fiveCount -- ; tenCount -- ; }
else if ( fiveCount >= 3 ) { fiveCount -= 3 ; } else return 0 ; } } return 1 ; }
int [ ] a = { 5 , 5 , 5 , 10 , 20 } ; int n = a . Length ;
if ( isChangeable ( a , n ) > 0 ) Console . WriteLine ( " YES " ) ; else Console . WriteLine ( " NO " ) ; } }
static int maxDistance ( int [ ] arr , int n ) {
Dictionary < int , int > map = new Dictionary < int , int > ( ) ;
int max_dist = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( ! map . ContainsKey ( arr [ i ] ) ) map . Add ( arr [ i ] , i ) ;
else max_dist = Math . Max ( max_dist , i - map [ arr [ i ] ] ) ; } return max_dist ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 3 , 2 , 1 , 2 , 1 , 4 , 5 , 8 , 6 , 7 , 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( maxDistance ( arr , n ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static bool checkDuplicatesWithinK ( int [ ] arr , int k ) {
HashSet < int > set = new HashSet < int > ( ) ;
for ( int i = 0 ; i < arr . Length ; i ++ ) {
if ( set . Contains ( arr [ i ] ) ) return true ;
set . Add ( arr [ i ] ) ;
if ( i >= k ) set . Remove ( arr [ i - k ] ) ; } return false ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 10 , 5 , 3 , 4 , 3 , 5 , 6 } ; if ( checkDuplicatesWithinK ( arr , 3 ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG { static int mostFrequent ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
int max_count = 1 , res = arr [ 0 ] ; int curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 2 , 1 , 3 , 2 , 1 } ; int n = arr . Length ; Console . WriteLine ( mostFrequent ( arr , n ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static int mostFrequent ( int [ ] arr , int n ) {
Dictionary < int , int > hp = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { int key = arr [ i ] ; if ( hp . ContainsKey ( key ) ) { int freq = hp [ key ] ; freq ++ ; hp [ key ] = freq ; } else hp . Add ( key , 1 ) ; }
int min_count = 0 , res = - 1 ; foreach ( KeyValuePair < int , int > pair in hp ) { if ( min_count < pair . Value ) { res = pair . Key ; min_count = pair . Value ; } } return res ; }
static void Main ( ) { int [ ] arr = new int [ ] { 1 , 5 , 2 , 1 , 3 , 2 , 1 } ; int n = arr . Length ; Console . Write ( mostFrequent ( arr , n ) ) ; } }
using System ; using System . Collections . Generic ; class GfG { static void smallestSubsegment ( int [ ] a , int n ) {
Dictionary < int , int > left = new Dictionary < int , int > ( ) ;
Dictionary < int , int > count = new Dictionary < int , int > ( ) ;
int mx = 0 ;
int mn = - 1 , strindex = - 1 ; for ( int i = 0 ; i < n ; i ++ ) { int x = a [ i ] ;
if ( ! count . ContainsKey ( x ) ) { left . Add ( x , i ) ; count . Add ( x , 1 ) ; }
else count [ x ] = count [ x ] + 1 ;
if ( count [ x ] > mx ) { mx = count [ x ] ;
mn = i - left [ x ] + 1 ; strindex = left [ x ] ; }
else if ( ( count [ x ] == mx ) && ( i - left [ x ] + 1 < mn ) ) { mn = i - left [ x ] + 1 ; = left [ x ] ; } }
for ( int i = strindex ; i < strindex + mn ; i ++ ) Console . Write ( a [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ ] A = { 1 , 2 , 2 , 2 , 1 } ; int n = A . Length ; smallestSubsegment ( A , n ) ; } }
static void findSymPairs ( int [ , ] arr ) {
Dictionary < int , int > hM = new Dictionary < int , int > ( ) ; int val = 0 ;
for ( int i = 0 ; i < arr . GetLength ( 0 ) ; i ++ ) {
int first = arr [ i , 0 ] ; int sec = arr [ i , 1 ] ;
if ( hM . ContainsKey ( sec ) ) val = hM [ sec ] ;
if ( val != 0 && val == first ) Console . WriteLine ( " ( " + sec + " , ▁ " + first + " ) " ) ;
else hM . ( first , sec ) ; } }
public static void Main ( String [ ] arg ) { int [ , ] arr = new int [ 5 , 2 ] ; arr [ 0 , 0 ] = 11 ; arr [ 0 , 1 ] = 20 ; arr [ 1 , 0 ] = 30 ; arr [ 1 , 1 ] = 40 ; arr [ 2 , 0 ] = 5 ; arr [ 2 , 1 ] = 10 ; arr [ 3 , 0 ] = 40 ; arr [ 3 , 1 ] = 30 ; arr [ 4 , 0 ] = 10 ; arr [ 4 , 1 ] = 5 ; findSymPairs ( arr ) ; } }
static void groupElements ( int [ ] arr , int n ) {
bool [ ] visited = new bool [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { visited [ i ] = false ; }
for ( int i = 0 ; i < n ; i ++ ) {
if ( ! visited [ i ] ) {
Console . Write ( arr [ i ] + " ▁ " ) ; for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) { Console . Write ( arr [ i ] + " ▁ " ) ; visited [ j ] = true ; } } } } }
public static void Main ( String [ ] args ) { int [ ] arr = { 4 , 6 , 9 , 2 , 3 , 4 , 9 , 6 , 10 , 4 } ; int n = arr . Length ; groupElements ( arr , n ) ; } }
public virtual bool aredisjoint ( int [ ] set1 , int [ ] set2 ) {
for ( int i = 0 ; i < set1 . Length ; i ++ ) { for ( int j = 0 ; j < set2 . Length ; j ++ ) { if ( set1 [ i ] == set2 [ j ] ) { return false ; } } }
return true ; }
public static void Main ( string [ ] args ) { GFG dis = new GFG ( ) ; int [ ] set1 = new int [ ] { 12 , 34 , 11 , 9 , 3 } ; int [ ] set2 = new int [ ] { 7 , 2 , 1 , 5 } ; bool result = dis . aredisjoint ( set1 , set2 ) ; if ( result ) { Console . WriteLine ( " Yes " ) ; } else { Console . WriteLine ( " No " ) ; } } }
Boolean aredisjoint ( int [ ] set1 , int [ ] set2 ) { int i = 0 , j = 0 ;
Array . Sort ( set1 ) ; Array . Sort ( set2 ) ;
while ( i < set1 . Length && j < set2 . Length ) { if ( set1 [ i ] < set2 [ j ] ) i ++ ; else if ( set1 [ i ] > set2 [ j ] ) j ++ ;
else return false ; } return true ; }
public static void Main ( String [ ] args ) { disjoint1 dis = new disjoint1 ( ) ; int [ ] set1 = { 12 , 34 , 11 , 9 , 3 } ; int [ ] set2 = { 7 , 2 , 1 , 5 } ; Boolean result = dis . aredisjoint ( set1 , set2 ) ; if ( result ) Console . WriteLine ( " YES " ) ; else Console . WriteLine ( " NO " ) ; } }
static void findMissing ( int [ ] a , int [ ] b , int n , int m ) { for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < m ; j ++ ) if ( a [ i ] == b [ j ] ) break ; if ( j == m ) Console . Write ( a [ i ] + " ▁ " ) ; } }
public static void Main ( ) { int [ ] a = { 1 , 2 , 6 , 3 , 4 , 5 } ; int [ ] b = { 2 , 4 , 3 , 1 , 0 } ; int n = a . Length ; int m = b . Length ; findMissing ( a , b , n , m ) ; } }
static void findMissing ( int [ ] a , int [ ] b , int n , int m ) {
HashSet < int > s = new HashSet < int > ( ) ; for ( int i = 0 ; i < m ; i ++ ) s . Add ( b [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( ! s . Contains ( a [ i ] ) ) Console . Write ( a [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ ] a = { 1 , 2 , 6 , 3 , 4 , 5 } ; int [ ] b = { 2 , 4 , 3 , 1 , 0 } ; int n = a . Length ; int m = b . Length ; findMissing ( a , b , n , m ) ; } }
public static bool areEqual ( int [ ] arr1 , int [ ] arr2 ) { int n = arr1 . Length ; int m = arr2 . Length ;
if ( n != m ) return false ;
Array . Sort ( arr1 ) ; Array . Sort ( arr2 ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr1 [ i ] != arr2 [ i ] ) return false ;
return true ; }
public static void Main ( ) { int [ ] arr1 = { 3 , 5 , 2 , 5 , 2 } ; int [ ] arr2 = { 2 , 3 , 5 , 5 , 2 } ; if ( areEqual ( arr1 , arr2 ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; using System . Collections . Generic ; class GFG { static void makePermutation ( int [ ] a , int n ) {
Dictionary < int , int > count = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( count . ContainsKey ( a [ i ] ) ) { count [ a [ i ] ] = count [ a [ i ] ] + 1 ; } else { count . Add ( a [ i ] , 1 ) ; } } }
static int find_maximum ( int [ ] a , int n , int k ) {
Dictionary < int , int > b = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { int x = a [ i ] ;
int d = Math . Min ( 1 + i , n - i ) ; if ( ! b . ContainsKey ( x ) ) b . Add ( x , d ) ; else {
b [ x ] = Math . Min ( d , b [ x ] ) ; } } int ans = int . MaxValue ; for ( int i = 0 ; i < n ; i ++ ) { int x = a [ i ] ;
if ( x != k - x && b . ContainsKey ( k - x ) ) ans = Math . Min ( Math . Max ( b [ x ] , b [ k - x ] ) , ans ) ; } return ans ; }
public static void Main ( String [ ] args ) { int [ ] a = { 3 , 5 , 8 , 6 , 7 } ; int K = 11 ; int n = a . Length ; Console . WriteLine ( find_maximum ( a , n , K ) ) ; } }
static bool isProduct ( int [ ] arr , int n , int x ) {
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] * arr [ j ] == x ) return true ; return false ; }
static void Main ( ) { int [ ] arr = { 10 , 20 , 9 , 40 } ; int x = 400 ; int n = arr . Length ; if ( isProduct ( arr , n , x ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; x = 190 ; if ( isProduct ( arr , n , x ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
public static bool isProduct ( int [ ] arr , int n , int x ) {
HashSet < int > hset = new HashSet < int > ( ) ; if ( n < 2 ) { return false ; }
for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] == 0 ) { if ( x == 0 ) { return true ; } else { continue ; } }
if ( x % arr [ i ] == 0 ) { if ( hset . Contains ( x / arr [ i ] ) ) { return true ; }
hset . Add ( arr [ i ] ) ; } } return false ; }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 10 , 20 , 9 , 40 } ; int x = 400 ; int n = arr . Length ; if ( isProduct ( arr , arr . Length , x ) ) { Console . WriteLine ( " Yes " ) ; } else { Console . WriteLine ( " No " ) ; } x = 190 ; if ( isProduct ( arr , arr . Length , x ) ) { Console . WriteLine ( " Yes " ) ; } else { Console . WriteLine ( " No " ) ; } } }
static void printMissing ( int [ ] arr , int n , int low , int high ) {
bool [ ] points_of_range = new bool [ high - low + 1 ] ; for ( int i = 0 ; i < high - low + 1 ; i ++ ) points_of_range [ i ] = false ; for ( int i = 0 ; i < n ; i ++ ) {
if ( low <= arr [ i ] && arr [ i ] <= high ) points_of_range [ arr [ i ] - low ] = true ; }
for ( int x = 0 ; x <= high - low ; x ++ ) { if ( points_of_range [ x ] == false ) Console . Write ( " { 0 } ▁ " , low + x ) ; } }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 5 , 4 } ; int n = arr . Length ; int low = 1 , high = 10 ; printMissing ( arr , n , low , high ) ; } }
static int find ( int [ ] a , int [ ] b , int k , int n1 , int n2 ) {
HashSet < int > s = new HashSet < int > ( ) ; for ( int i = 0 ; i < n2 ; i ++ ) s . Add ( b [ i ] ) ;
int missing = 0 ; for ( int i = 0 ; i < n1 ; i ++ ) { if ( ! s . Contains ( a [ i ] ) ) missing ++ ; if ( missing == k ) return a [ i ] ; } return - 1 ; }
public static void Main ( String [ ] args ) { int [ ] a = { 0 , 2 , 4 , 6 , 8 , 10 , 12 , 14 , 15 } ; int [ ] b = { 4 , 10 , 6 , 8 , 12 } ; int n1 = a . Length ; int n2 = b . Length ; int k = 3 ; Console . WriteLine ( find ( a , b , k , n1 , n2 ) ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } class GFG { public Node root ;
public virtual bool isFullTree ( Node node ) {
if ( node == null ) { return true ; }
if ( node . left == null && node . right == null ) { return true ; }
if ( ( node . left != null ) && ( node . right != null ) ) { return ( isFullTree ( node . left ) && isFullTree ( node . right ) ) ; }
return false ; }
public static void Main ( string [ ] args ) { GFG tree = new GFG ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 20 ) ; tree . root . right = new Node ( 30 ) ; tree . root . left . right = new Node ( 40 ) ; tree . root . left . left = new Node ( 50 ) ; tree . root . right . left = new Node ( 60 ) ; tree . root . left . left . left = new Node ( 80 ) ; tree . root . right . right = new Node ( 70 ) ; tree . root . left . left . right = new Node ( 90 ) ; tree . root . left . right . left = new Node ( 80 ) ; tree . root . left . right . right = new Node ( 90 ) ; tree . root . right . left . left = new Node ( 80 ) ; tree . root . right . left . right = new Node ( 90 ) ; tree . root . right . right . left = new Node ( 80 ) ; tree . root . right . right . right = new Node ( 90 ) ; if ( tree . isFullTree ( tree . root ) ) { Console . Write ( " The ▁ binary ▁ tree ▁ is ▁ full " ) ; } else { Console . Write ( " The ▁ binary ▁ tree ▁ is ▁ not ▁ full " ) ; } } }
static int findGreatest ( int [ ] arr , int n ) { int result = - 1 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ j ] * arr [ k ] == arr [ i ] ) result = Math . Max ( result , arr [ i ] ) ; return result ; }
static public void Main ( ) { int [ ] arr = { 30 , 10 , 9 , 3 , 35 } ; int n = arr . Length ; Console . WriteLine ( findGreatest ( arr , n ) ) ; } }
static int findGreatest ( int [ ] arr , int n ) {
Dictionary < int , int > m = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( m . ContainsKey ( arr [ i ] ) ) { var a = m [ arr [ i ] ] + 1 ; m . Add ( arr [ i ] , a ) ; } else { m . Add ( arr [ i ] , arr [ i ] ) ; } }
Array . Sort ( arr ) ; for ( int i = n - 1 ; i > 1 ; i -- ) {
for ( int j = 0 ; j < i && arr [ j ] <= Math . Sqrt ( arr [ i ] ) ; j ++ ) { if ( arr [ i ] % arr [ j ] == 0 ) { int result = arr [ i ] / arr [ j ] ;
if ( result != arr [ j ] && m [ result ] == null m [ result ] > 0 ) { return arr [ i ] ; }
else if ( result = = arr [ j ] && m [ result ] > 1 ) { return arr [ i ] ; } } } } return - 1 ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 17 , 2 , 1 , 15 , 30 } ; int n = arr . Length ; Console . WriteLine ( findGreatest ( arr , n ) ) ; } }
public static int subset ( int [ ] ar , int n ) {
int res = 0 ;
Array . Sort ( ar ) ;
for ( int i = 0 ; i < n ; i ++ ) { int count = 1 ;
for ( ; i < n - 1 ; i ++ ) { if ( ar [ i ] == ar [ i + 1 ] ) count ++ ; else break ; }
res = Math . Max ( res , count ) ; } return res ; }
public static void Main ( ) { int [ ] arr = { 5 , 6 , 9 , 3 , 4 , 3 , 4 } ; int n = 7 ; Console . WriteLine ( subset ( arr , n ) ) ; } }
public static int minRemove ( int [ ] a , int [ ] b , int n , int m ) {
Dictionary < int , int > countA = new Dictionary < int , int > ( ) ; Dictionary < int , int > countB = new Dictionary < int , int > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( countA . ContainsKey ( a [ i ] ) ) { var v = countA [ a [ i ] ] ; countA . Remove ( countA [ a [ i ] ] ) ; countA . Add ( a [ i ] , v + 1 ) ; } else countA . Add ( a [ i ] , 1 ) ; }
for ( int i = 0 ; i < m ; i ++ ) { if ( countB . ContainsKey ( b [ i ] ) ) { var v = countB [ b [ i ] ] ; countB . Remove ( countB [ b [ i ] ] ) ; countB . Add ( b [ i ] , v + 1 ) ; } else countB . Add ( b [ i ] , 1 ) ; }
int res = 0 ; foreach ( int x in countA . Keys ) if ( countB . ContainsKey ( x ) ) res += Math . Min ( countB [ x ] , countA [ x ] ) ;
return res ; }
public static void Main ( String [ ] args ) { int [ ] a = { 1 , 2 , 3 , 4 } ; int [ ] b = { 2 , 3 , 4 , 5 , 8 } ; int n = a . Length ; int m = b . Length ; Console . WriteLine ( minRemove ( a , b , n , m ) ) ; } }
static int countItems ( item [ ] list1 , int m , item [ ] list2 , int n ) { int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( ( list1 [ i ] . name . CompareTo ( list2 [ j ] . name ) == 0 ) && ( list1 [ i ] . price != list2 [ j ] . price ) ) count ++ ;
return count ; }
public static void Main ( String [ ] args ) { item [ ] list1 = { new item ( " apple " , 60 ) , new item ( " bread " , 20 ) , new item ( " wheat " , 50 ) , new item ( " oil " , 30 ) } ; item [ ] list2 = { new item ( " milk " , 20 ) , new item ( " bread " , 15 ) , new item ( " wheat " , 40 ) , new item ( " apple " , 60 ) } ; int m = list1 . Length ; int n = list2 . Length ; Console . Write ( " Count ▁ = ▁ " + countItems ( list1 , m , list2 , n ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static void makePermutation ( int [ ] a , int n ) {
Dictionary < int , int > count = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( count . ContainsKey ( a [ i ] ) ) { count [ a [ i ] ] = count [ a [ i ] ] + 1 ; } else { count . Add ( a [ i ] , 1 ) ; } } int next_missing = 1 ; for ( int i = 0 ; i < n ; i ++ ) { if ( count . ContainsKey ( a [ i ] ) && count [ a [ i ] ] != 1 a [ i ] > n a [ i ] < 1 ) { count [ a [ i ] ] = count [ a [ i ] ] - 1 ;
while ( count . ContainsKey ( next_missing ) ) next_missing ++ ;
a [ i ] = next_missing ; count . Add ( next_missing , 1 ) ; } } }
public static void Main ( String [ ] args ) { int [ ] A = { 2 , 2 , 3 , 3 } ; int n = A . Length ; makePermutation ( A , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( A [ i ] + " ▁ " ) ; } }
public static void getPairsCount ( int [ ] arr , int sum ) {
int count = 0 ;
for ( int i = 0 ; i < arr . Length ; i ++ ) for ( int j = i + 1 ; j < arr . Length ; j ++ ) if ( ( arr [ i ] + arr [ j ] ) == sum ) count ++ ; Console . WriteLine ( " Count ▁ of ▁ pairs ▁ is ▁ " + count ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 5 , 7 , - 1 , 5 } ; int sum = 6 ; getPairsCount ( arr , sum ) ; } }
static int countPairs ( int [ ] arr1 , int [ ] arr2 , int m , int n , int x ) { int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ )
if ( ( arr1 [ i ] + arr2 [ j ] ) == x ) count ++ ;
return count ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 3 , 5 , 7 } ; int [ ] arr2 = { 2 , 3 , 5 , 8 } ; int m = arr1 . Length ; int n = arr2 . Length ; int x = 10 ; Console . WriteLine ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static bool isPresent ( int [ ] arr , int low , int high , int value ) { while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
static int countPairs ( int [ ] arr1 , int [ ] arr2 , int m , int n , int x ) { int count = 0 ; for ( int i = 0 ; i < m ; i ++ ) {
int value = x - arr1 [ i ] ;
if ( isPresent ( arr2 , 0 , n - 1 , value ) ) count ++ ; }
return count ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 3 , 5 , 7 } ; int [ ] arr2 = { 2 , 3 , 5 , 8 } ; int m = arr1 . Length ; int n = arr2 . Length ; int x = 10 ; Console . WriteLine ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static int countPairs ( int [ ] arr1 , int [ ] arr2 , int m , int n , int x ) { int count = 0 ; HashSet < int > us = new HashSet < int > ( ) ;
for ( int i = 0 ; i < m ; i ++ ) us . Add ( arr1 [ i ] ) ;
for ( int j = 0 ; j < n ; j ++ )
if ( us . Contains ( x - arr2 [ j ] ) ) count ++ ;
return count ; }
public static void Main ( String [ ] args ) { int [ ] arr1 = { 1 , 3 , 5 , 7 } ; int [ ] arr2 = { 2 , 3 , 5 , 8 } ; int m = arr1 . Length ; int n = arr2 . Length ; int x = 10 ; Console . Write ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static int countPairs ( int [ ] arr1 , int [ ] arr2 , int m , int n , int x ) { int count = 0 ; int l = 0 , r = n - 1 ;
while ( l < m && r >= 0 ) {
if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) { l ++ ; r -- ; count ++ ; }
else if ( ( arr1 [ l ] + arr2 [ r ] ) < x ) ++ ;
else r -- ; }
return count ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 3 , 5 , 7 } ; int [ ] arr2 = { 2 , 3 , 5 , 8 } ; int m = arr1 . Length ; int n = arr2 . Length ; int x = 10 ; Console . WriteLine ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static void Main ( ) { int [ ] arr = { 10 , 2 , - 2 , - 20 , 10 } ; int k = - 10 ; int n = arr . Length ; int res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { int sum = 0 ; for ( int j = i ; j < n ; j ++ ) {
sum += arr [ j ] ;
if ( sum == k ) res ++ ; } } Console . WriteLine ( res ) ; } }
public static int findSubarraySum ( int [ ] arr , int n , int sum ) {
Dictionary < int , int > prevSum = new Dictionary < int , int > ( ) ; int res = 0 ;
int currsum = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
currsum += arr [ i ] ;
if ( currsum == sum ) res ++ ;
if ( prevSum . ContainsKey ( currsum - sum ) ) res += prevSum [ currsum - sum ] ;
if ( ! prevSum . ContainsKey ( currsum ) ) prevSum . Add ( currsum , 1 ) ; else { int count = prevSum [ currsum ] ; prevSum [ currsum ] = count + 1 ; } } return res ; }
public static void Main ( ) { int [ ] arr = { 10 , 2 , - 2 , - 20 , 10 } ; int sum = - 10 ; int n = arr . Length ; Console . Write ( findSubarraySum ( arr , n , sum ) ) ; } }
public static int countPairs ( int [ ] arr , int n ) { int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int product = arr [ i ] * arr [ j ] ;
for ( int k = 0 ; k < n ; k ++ ) {
if ( arr [ k ] == product ) { result ++ ; break ; } } } }
return result ; }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 6 , 2 , 4 , 12 , 5 , 3 } ; int n = arr . Length ; Console . WriteLine ( countPairs ( arr , n ) ) ; } }
static int countPairs ( int [ ] arr , int n ) { int result = 0 ;
HashSet < int > Hash = new HashSet < int > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { Hash . Add ( arr [ i ] ) ; }
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int product = arr [ i ] * arr [ j ] ;
if ( Hash . Contains ( product ) ) { result ++ ; } } }
return result ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 6 , 2 , 4 , 12 , 5 , 3 } ; int n = arr . Length ; Console . WriteLine ( countPairs ( arr , n ) ) ; } }
static void findPairs ( int [ ] arr1 , int [ ] arr2 , int n , int m , int x ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( arr1 [ i ] + arr2 [ j ] == x ) Console . WriteLine ( arr1 [ i ] + " ▁ " + arr2 [ j ] ) ; }
static void Main ( ) { int [ ] arr1 = { 1 , 2 , 3 , 7 , 5 , 4 } ; int [ ] arr2 = { 0 , 7 , 4 , 3 , 2 , 1 } ; int x = 8 ; findPairs ( arr1 , arr2 , arr1 . Length , arr2 . Length , x ) ; } }
public static void findPairs ( int [ ] arr1 , int [ ] arr2 , int n , int m , int x ) {
Dictionary < int , int > s = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { s [ arr1 [ i ] ] = 0 ; }
for ( int j = 0 ; j < m ; j ++ ) { if ( s . ContainsKey ( x - arr2 [ j ] ) ) { Console . WriteLine ( x - arr2 [ j ] + " ▁ " + arr2 [ j ] ) ; } } }
public static void Main ( string [ ] args ) { int [ ] arr1 = new int [ ] { 1 , 0 , - 4 , 7 , 6 , 4 } ; int [ ] arr2 = new int [ ] { 0 , 2 , 4 , - 3 , 2 , 1 } ; int x = 8 ; findPairs ( arr1 , arr2 , arr1 . Length , arr2 . Length , x ) ; } }
static void countFreq ( int [ ] a , int n ) {
int [ ] hm = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) hm [ a [ i ] ] ++ ; int cumul = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
cumul += hm [ a [ i ] ] ;
if ( hm [ a [ i ] ] != 0 ) { Console . WriteLine ( a [ i ] + " - > " + cumul ) ; }
hm [ a [ i ] ] = 0 ; } }
public static void Main ( String [ ] args ) { int [ ] a = { 1 , 3 , 2 , 4 , 2 , 1 } ; int n = a . Length ; countFreq ( a , n ) ; } }
static void findPair ( int [ ] arr , int n ) { bool found = false ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { for ( int k = 0 ; k < n ; k ++ ) { if ( arr [ i ] + arr [ j ] == arr [ k ] ) { Console . WriteLine ( arr [ i ] + " ▁ " + arr [ j ] ) ; found = true ; } } } } if ( found == false ) Console . WriteLine ( " Not ▁ exist " ) ; }
static public void Main ( String [ ] args ) { int [ ] arr = { 10 , 4 , 8 , 13 , 5 } ; int n = arr . Length ; findPair ( arr , n ) ; } }
static bool printPairs ( int [ ] arr , int n , int k ) { bool isPairFound = true ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i != j && arr [ i ] % arr [ j ] == k ) { Console . Write ( " ( " + arr [ i ] + " , ▁ " + arr [ j ] + " ) " + " ▁ " ) ; isPairFound = true ; } } } return isPairFound ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 5 , 4 , 7 } ; int k = 3 ; if ( printPairs ( arr , arr . Length , k ) == false ) Console . WriteLine ( " No ▁ such ▁ pair ▁ exists " ) ; } }
public static List < int > findDivisors ( int n ) { List < int > v = new List < int > ( ) ;
for ( int i = 1 ; i <= Math . Sqrt ( n ) ; i ++ ) { if ( n % i == 0 ) {
if ( n / i == i ) { v . Add ( i ) ; } else { v . Add ( i ) ; v . Add ( n / i ) ; } } } return v ; }
public static bool printPairs ( int [ ] arr , int n , int k ) {
Dictionary < int , bool > occ = new Dictionary < int , bool > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { occ [ arr [ i ] ] = true ; } bool isPairFound = false ; for ( int i = 0 ; i < n ; i ++ ) {
if ( occ [ k ] && k < arr [ i ] ) { Console . Write ( " ( " + k + " , ▁ " + arr [ i ] + " ) ▁ " ) ; isPairFound = true ; }
if ( arr [ i ] >= k ) {
List < int > v = findDivisors ( arr [ i ] - k ) ;
for ( int j = 0 ; j < v . Count ; j ++ ) { if ( arr [ i ] % v [ j ] == k && arr [ i ] != v [ j ] && occ [ v [ j ] ] ) { Console . Write ( " ( " + arr [ i ] + " , ▁ " + v [ j ] + " ) ▁ " ) ; isPairFound = true ; } }
v . Clear ( ) ; } } return isPairFound ; }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 3 , 1 , 2 , 5 , 4 } ; int k = 2 ; if ( printPairs ( arr , arr . Length , k ) == false ) { Console . WriteLine ( " No ▁ such ▁ pair ▁ exists " ) ; } } }
using System ; using System . Collections . Generic ; using System . Linq ; class GFG { public static void convert ( int [ ] arr , int n ) {
int [ ] temp = new int [ arr . Length ] ; Array . Copy ( arr , 0 , temp , 0 , arr . Length ) ;
Array . Sort ( temp ) ;
Dictionary < int , int > umap = new Dictionary < int , int > ( ) ;
int val = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( umap . ContainsKey ( temp [ i ] ) ) umap [ temp [ i ] ] = val ++ ; else umap . Add ( temp [ i ] , val ++ ) ;
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = umap [ arr [ i ] ] ; } public static void printArr ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 10 , 20 , 15 , 12 , 11 , 50 } ; int n = arr . Length ; Console . WriteLine ( " Given ▁ Array ▁ is ▁ " ) ; printArr ( arr , n ) ; convert ( arr , n ) ; Console . WriteLine ( " STRNEWLINE STRNEWLINE Converted ▁ Array ▁ is ▁ " ) ; printArr ( arr , n ) ; } }
using System ; class GFG { static int ASCII_SIZE = 256 ; static char getMaxOccuringChar ( String str ) {
int [ ] count = new int [ ASCII_SIZE ] ;
int len = str . Length ; for ( int i = 0 ; i < len ; i ++ ) count [ str [ i ] ] ++ ;
int max = - 1 ;
char result = ' ▁ ' ;
for ( int i = 0 ; i < len ; i ++ ) { if ( max < count [ str [ i ] ] ) { max = count [ str [ i ] ] ; result = str [ i ] ; } } return result ; }
public static void Main ( ) { String str = " sample ▁ string " ; Console . Write ( " Max ▁ occurring ▁ character ▁ is ▁ " + getMaxOccuringChar ( str ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static char MARKER = ' $ ' ;
public class Node { public int data ; public Node left , right ; public Node ( int data ) { this . data = data ; } } ;
public static String dupSubUtil ( Node root , HashSet < String > subtrees ) { String s = " " ;
if ( root == null ) return s + MARKER ;
String lStr = dupSubUtil ( root . left , subtrees ) ; if ( lStr . Equals ( s ) ) return s ;
String rStr = dupSubUtil ( root . right , subtrees ) ; if ( rStr . Equals ( s ) ) return s ;
s = s + root . data + lStr + rStr ;
if ( s . Length > 3 && subtrees . Contains ( s ) ) return " " ; subtrees . Add ( s ) ; return s ; }
public static String dupSub ( Node root ) { HashSet < String > subtrees = new HashSet < String > ( ) ; return dupSubUtil ( root , subtrees ) ; }
public static void Main ( String [ ] args ) { Node root = new Node ( ' A ' ) ; root . left = new Node ( ' B ' ) ; root . right = new Node ( ' C ' ) ; root . left . left = new Node ( ' D ' ) ; root . left . right = new Node ( ' E ' ) ; root . right . right = new Node ( ' B ' ) ; root . right . right . right = new Node ( ' E ' ) ; root . right . right . left = new Node ( ' D ' ) ; String str = dupSub ( root ) ; if ( str . Equals ( " " ) ) Console . Write ( " ▁ Yes ▁ " ) ; else Console . Write ( " ▁ No ▁ " ) ; } }
public static void printFirstRepeating ( int [ ] arr ) {
int min = - 1 ;
HashSet < int > set = new HashSet < int > ( ) ;
for ( int i = arr . Length - 1 ; i >= 0 ; i -- ) {
if ( set . Contains ( arr [ i ] ) ) { min = i ; }
else { set . Add ( arr [ i ] ) ; } }
if ( min != - 1 ) { Console . WriteLine ( " The ▁ first ▁ repeating ▁ element ▁ is ▁ " + arr [ min ] ) ; } else { Console . WriteLine ( " There ▁ are ▁ no ▁ repeating ▁ elements " ) ; } }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 10 , 5 , 3 , 4 , 3 , 5 , 6 } ; printFirstRepeating ( arr ) ; } }
static void printFirstRepeating ( int [ ] arr , int n ) {
int k = 0 ;
int max = n ; for ( int i = 0 ; i < n ; i ++ ) if ( max < arr [ i ] ) max = arr [ i ] ;
int [ ] a = new int [ max + 1 ] ;
int [ ] b = new int [ max + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ arr [ i ] ] != 0 ) { b [ arr [ i ] ] = 1 ; k = 1 ; continue ; } else
a [ arr [ i ] ] = i ; } if ( k == 0 ) Console . WriteLine ( " No ▁ repeating ▁ element ▁ found " ) ; else { int min = max + 1 ;
for ( int i = 0 ; i < max + 1 ; i ++ ) if ( ( a [ i ] != 0 ) && min > a [ i ] && ( b [ i ] != 0 ) ) min = a [ i ] ; Console . Write ( arr [ min ] ) ; } Console . WriteLine ( ) ; }
static void Main ( ) { int [ ] arr = { 10 , 5 , 3 , 4 , 3 , 5 , 6 } ; int n = arr . Length ; printFirstRepeating ( arr , n ) ; } }
static int findSum ( int [ ] arr , int n ) {
Array . Sort ( arr ) ; int sum = arr [ 0 ] ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) { sum = sum + arr [ i + 1 ] ; } } return sum ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 1 , 1 , 4 , 5 , 6 } ; int n = arr . Length ; Console . WriteLine ( findSum ( arr , n ) ) ; } }
static int findSum ( int [ ] arr , int n ) { int sum = 0 ;
HashSet < int > s = new HashSet < int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( ! s . Contains ( arr [ i ] ) ) { sum += arr [ i ] ; s . Add ( arr [ i ] ) ; } } return sum ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 3 , 1 , 1 , 4 , 5 , 6 } ; int n = arr . Length ; Console . WriteLine ( findSum ( arr , n ) ) ; } }
static int printKDistinct ( int [ ] arr , int n , int k ) { int dist_count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ j ] == arr [ i ] ) break ;
if ( j == n ) dist_count ++ ; if ( dist_count == k ) return arr [ i ] ; } return - 1 ; }
public static void Main ( ) { int [ ] ar = { 1 , 2 , 1 , 3 , 4 , 2 } ; int n = ar . Length ; int k = 2 ; Console . Write ( printKDistinct ( ar , n , k ) ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int data ) { this . data = data ; left = right = null ; } } public class BinaryTree { public Node a , b ;
public virtual bool areMirror ( Node a , Node b ) {
if ( a == null && b == null ) { return true ; }
if ( a == null b == null ) { return false ; }
return a . data == b . data && areMirror ( a . left , b . right ) && areMirror ( a . right , b . left ) ; }
public static void Main ( string [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; Node a = new Node ( 1 ) ; Node b = new Node ( 1 ) ; a . left = new Node ( 2 ) ; a . right = new Node ( 3 ) ; a . left . left = new Node ( 4 ) ; a . left . right = new Node ( 5 ) ; b . left = new Node ( 3 ) ; b . right = new Node ( 2 ) ; b . right . left = new Node ( 5 ) ; b . right . right = new Node ( 4 ) ; if ( tree . areMirror ( a , b ) == true ) { Console . WriteLine ( " Yes " ) ; } else { Console . WriteLine ( " No " ) ; } } }
public static void printPairs ( int [ ] arr , int n ) { List < int > v = new List < int > ( ) ;
for ( int i = 0 ; i < n ; i ++ )
for ( int j = i + 1 ; j < n ; j ++ )
if ( Math . Abs ( arr [ i ] ) == Math . Abs ( arr [ j ] ) ) v . Add ( Math . Abs ( arr [ i ] ) ) ;
if ( v . Count == 0 ) return ;
v . Sort ( ) ;
for ( int i = 0 ; i < v . Count ; i ++ ) Console . Write ( - v [ i ] + " ▁ " + v [ i ] ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 4 , 8 , 9 , - 4 , 1 , - 1 , - 8 , - 9 } ; int n = arr . Length ; printPairs ( arr , n ) ; } }
static bool canPairs ( int [ ] ar , int k ) {
if ( ar . Length % 2 == 1 ) return false ;
Dictionary < Double , int > hm = new Dictionary < Double , int > ( ) ;
for ( int i = 0 ; i < ar . Length ; i ++ ) { int rem = ( ( ar [ i ] % k ) + k ) % k ; if ( ! hm . ContainsKey ( rem ) ) { hm [ rem ] = 0 ; } hm [ rem ] ++ ; }
for ( int i = 0 ; i < ar . Length ; i ++ ) {
int rem = ( ( ar [ i ] % k ) + k ) % k ;
if ( 2 * rem == k ) {
if ( hm [ rem ] % 2 == 1 ) return false ; }
else if ( rem = = 0 ) {
if ( hm [ rem ] % 2 == 1 ) return false ; }
else { if ( hm [ k - rem ] != hm [ rem ] ) return false ; } } return true ; }
public static void Main ( ) { int [ ] arr = { 92 , 75 , 65 , 48 , 45 , 35 } ; int k = 10 ;
bool ans = canPairs ( arr , k ) ; if ( ans ) Console . WriteLine ( " True " ) ; else Console . WriteLine ( " False " ) ; } }
static bool findTriplet ( int [ ] a1 , int [ ] a2 , int [ ] a3 , int n1 , int n2 , int n3 , int sum ) { for ( int i = 0 ; i < n1 ; i ++ ) for ( int j = 0 ; j < n2 ; j ++ ) for ( int k = 0 ; k < n3 ; k ++ ) if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) return true ; return false ; }
static public void Main ( ) { int [ ] a1 = { 1 , 2 , 3 , 4 , 5 } ; int [ ] a2 = { 2 , 3 , 6 , 1 , 2 } ; int [ ] a3 = { 3 , 2 , 4 , 5 , 6 } ; int sum = 9 ; int n1 = a1 . Length ; int n2 = a2 . Length ; int n3 = a3 . Length ; if ( findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
static int maxLen ( int [ ] arr ) {
Dictionary < int , int > hM = new Dictionary < int , int > ( ) ;
int sum = 0 ;
int max_len = 0 ;
for ( int i = 0 ; i < arr . GetLength ( 0 ) ; i ++ ) {
sum += arr [ i ] ; if ( arr [ i ] == 0 && max_len == 0 ) max_len = 1 ; if ( sum == 0 ) max_len = i + 1 ;
int prev_i = 0 ; if ( hM . ContainsKey ( sum ) ) { prev_i = hM [ sum ] ; } if ( hM . ContainsKey ( sum ) ) max_len = Math . Max ( max_len , i - prev_i ) ;
else { if ( hM . ContainsKey ( sum ) ) hM . Remove ( sum ) ; hM . Add ( sum , i ) ; } } return max_len ; }
public static void Main ( ) { int [ ] arr = { 15 , - 2 , 2 , - 8 , 1 , 7 , 10 , 23 } ; Console . WriteLine ( " Length ▁ of ▁ the ▁ longest ▁ 0 ▁ sum ▁ subarray ▁ is ▁ " + maxLen ( arr ) ) ; } }
static int longIncrConseqSubseq ( int [ ] arr , int n ) {
Dictionary < int , int > map = new Dictionary < int , int > ( ) ;
map . Add ( arr [ 0 ] , 1 ) ;
for ( int i = 1 ; i < n ; i ++ ) {
if ( map . ContainsKey ( arr [ i ] - 1 ) ) {
map . Add ( arr [ i ] , map [ arr [ i ] - 1 ] + 1 ) ; map . Remove ( arr [ i ] - 1 ) ; } else { if ( ! map . ContainsKey ( arr [ i ] ) ) map . Add ( arr [ i ] , 1 ) ; } } int max = int . MinValue ; foreach ( KeyValuePair < int , int > entry in map ) { if ( entry . Value > max ) { max = entry . Value ; } } return max ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 3 , 10 , 3 , 11 , 4 , 5 , 6 , 7 , 8 , 12 } ; int n = arr . Length ; Console . WriteLine ( longIncrConseqSubseq ( arr , n ) ) ; } }
static int longLenSub ( int [ ] arr , int n ) {
Dictionary < int , int > um = new Dictionary < int , int > ( ) ;
int longLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int len = 0 ;
if ( um . ContainsKey ( arr [ i ] - 1 ) && len < um [ arr [ i ] - 1 ] ) len = um [ arr [ i ] - 1 ] ;
if ( um . ContainsKey ( arr [ i ] + 1 ) && len < um [ arr [ i ] + 1 ] ) len = um [ arr [ i ] + 1 ] ;
um [ arr [ i ] ] = len + 1 ;
if ( longLen < um [ arr [ i ] ] ) longLen = um [ arr [ i ] ] ; }
return longLen ; }
static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 3 , 2 } ; int n = arr . Length ; Console . Write ( " Longest ▁ length ▁ subsequence ▁ = ▁ " + longLenSub ( arr , n ) ) ; } }
static int countWindowDistinct ( int [ ] win , int k ) { int dist_count = 0 ;
for ( int i = 0 ; i < k ; i ++ ) {
int j ; for ( j = 0 ; j < i ; j ++ ) if ( win [ i ] == win [ j ] ) break ; if ( j == i ) dist_count ++ ; } return dist_count ; }
static void countDistinct ( int [ ] arr , int n , int k ) {
for ( int i = 0 ; i <= n - k ; i ++ ) { int [ ] newArr = new int [ k ] ; Array . Copy ( arr , i , newArr , 0 , k ) ; Console . WriteLine ( countWindowDistinct ( newArr , k ) ) ; } }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 1 , 3 , 4 , 2 , 3 } ; int k = 4 ; countDistinct ( arr , arr . Length , k ) ; } }
static bool areElementsContiguous ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] > 1 ) return false ; return true ; }
public static void Main ( ) { int [ ] arr = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = arr . Length ; if ( areElementsContiguous ( arr , n ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
static bool areElementsContiguous ( int [ ] arr , int n ) {
int max = int . MinValue ; int min = int . MaxValue ; for ( int i = 0 ; i < n ; i ++ ) { max = Math . Max ( max , arr [ i ] ) ; min = Math . Min ( min , arr [ i ] ) ; } int m = max - min + 1 ;
if ( m > n ) return false ;
bool [ ] visited = new bool [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) visited [ arr [ i ] - min ] = true ;
for ( int i = 0 ; i < m ; i ++ ) if ( visited [ i ] == false ) return false ; return true ; }
public static void Main ( ) { int [ ] arr = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = arr . Length ; if ( areElementsContiguous ( arr , n ) ) Console . Write ( " Yes " ) ; else Console . Write ( " No " ) ; } }
public static bool ? areElementsContiguous ( int [ ] arr , int n ) {
HashSet < int > us = new HashSet < int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { us . Add ( arr [ i ] ) ; }
int count = 1 ;
int curr_ele = arr [ 0 ] - 1 ;
while ( us . Contains ( curr_ele ) == true ) {
count ++ ;
curr_ele -- ; }
curr_ele = arr [ 0 ] + 1 ;
while ( us . Contains ( curr_ele ) == true ) {
count ++ ;
curr_ele ++ ; }
return ( count == ( us . Count ) ) ; }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = arr . Length ; if ( areElementsContiguous ( arr , n ) . Value ) { Console . WriteLine ( " Yes " ) ; } else { Console . WriteLine ( " No " ) ; } } }
public static void subArraySum ( int [ ] arr , int n , int sum ) {
int cur_sum = 0 ; int start = 0 ; int end = - 1 ; Dictionary < int , int > hashMap = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { cur_sum = cur_sum + arr [ i ] ;
if ( cur_sum - sum == 0 ) { start = 0 ; end = i ; break ; }
if ( hashMap . ContainsKey ( cur_sum - sum ) ) { start = hashMap [ cur_sum - sum ] + 1 ; end = i ; break ; }
hashMap [ cur_sum ] = i ; }
if ( end == - 1 ) { Console . WriteLine ( " No ▁ subarray ▁ with ▁ given ▁ sum ▁ exists " ) ; } else { Console . WriteLine ( " Sum ▁ found ▁ between ▁ indexes ▁ " + start + " ▁ to ▁ " + end ) ; } }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 10 , 2 , - 2 , - 20 , 10 } ; int n = arr . Length ; int sum = - 10 ; subArraySum ( arr , n , sum ) ; } }
static int minInsertion ( String str ) {
int n = str . Length ;
int res = 0 ;
int [ ] count = new int [ 26 ] ;
for ( int i = 0 ; i < n ; i ++ ) count [ str [ i ] - ' a ' ] ++ ;
for ( int i = 0 ; i < 26 ; i ++ ) { if ( count [ i ] % 2 == 1 ) res ++ ; }
return ( res == 0 ) ? 0 : res - 1 ; }
public static void Main ( ) { string str = " geeksforgeeks " ; Console . WriteLine ( minInsertion ( str ) ) ; } }
static int maxdiff ( int [ ] arr , int n ) { Dictionary < int , int > freq = new Dictionary < int , int > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( freq . ContainsKey ( arr [ i ] ) ) freq [ arr [ i ] ] ++ ; else freq . Add ( arr [ i ] , 1 ) ; } int ans = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( freq [ arr [ i ] ] > freq [ arr [ j ] ] && arr [ i ] > arr [ j ] ) ans = Math . Max ( ans , freq [ arr [ i ] ] - freq [ arr [ i ] ] ) ; else if ( freq [ arr [ i ] ] < freq [ arr [ j ] ] && arr [ i ] < arr [ j ] ) ans = Math . Max ( ans , freq [ arr [ j ] ] - freq [ arr [ i ] ] ) ; } } return ans ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 3 , 1 , 3 , 2 , 3 , 2 } ; int n = arr . Length ; Console . WriteLine ( maxdiff ( arr , n ) ) ; } }
using System ; class GFG { static int findDiff ( int [ ] arr , int n ) {
Array . Sort ( arr ) ; int count = 0 , max_count = 0 , min_count = n ; for ( int i = 0 ; i < ( n - 1 ) ; i ++ ) {
if ( arr [ i ] == arr [ i + 1 ] ) { count += 1 ; continue ; } else { max_count = Math . Max ( max_count , count ) ; min_count = Math . Min ( min_count , count ) ; count = 0 ; } } return ( max_count - min_count ) ; }
public static void Main ( ) { int [ ] arr = { 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 } ; int n = arr . Length ; Console . WriteLine ( findDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) { int SubsetSum_1 = 0 , SubsetSum_2 = 0 ; for ( int i = 0 ; i <= n - 1 ; i ++ ) { bool isSingleOccurance = true ; for ( int j = i + 1 ; j <= n - 1 ; j ++ ) {
if ( arr [ i ] == arr [ j ] ) { isSingleOccurance = false ; arr [ i ] = arr [ j ] = 0 ; break ; } } if ( isSingleOccurance ) { if ( arr [ i ] > 0 ) SubsetSum_1 += arr [ i ] ; else SubsetSum_2 += arr [ i ] ; } } return Math . Abs ( SubsetSum_1 - SubsetSum_2 ) ; }
static public void Main ( ) { int [ ] arr = { 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 } ; int n = arr . Length ; Console . WriteLine ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) { int result = 0 ;
Array . Sort ( arr ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) result += Math . Abs ( arr [ i ] ) ; else i ++ ; }
if ( arr [ n - 2 ] != arr [ n - 1 ] ) result += Math . Abs ( arr [ n - 1 ] ) ;
return result ; }
static public void Main ( ) { int [ ] arr = { 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 } ; int n = arr . Length ; Console . WriteLine ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) { Dictionary < int , int > hashPositive = new Dictionary < int , int > ( ) ; Dictionary < int , int > hashNegative = new Dictionary < int , int > ( ) ; int SubsetSum_1 = 0 , SubsetSum_2 = 0 ;
for ( int i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] > 0 ) { if ( hashPositive . ContainsKey ( arr [ i ] ) ) { hashPositive [ arr [ i ] ] += 1 ; } else { hashPositive . Add ( arr [ i ] , 1 ) ; } } }
for ( int i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] > 0 && hashPositive . ContainsKey ( arr [ i ] ) ) { if ( hashPositive [ arr [ i ] ] == 1 ) { SubsetSum_1 += arr [ i ] ; } } }
for ( int i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] < 0 ) { if ( hashNegative . ContainsKey ( Math . Abs ( arr [ i ] ) ) ) { hashNegative [ Math . Abs ( arr [ i ] ) ] += 1 ; } else { hashNegative . Add ( Math . Abs ( arr [ i ] ) , 1 ) ; } } }
for ( int i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] < 0 && hashNegative . ContainsKey ( Math . Abs ( arr [ i ] ) ) ) { if ( hashNegative [ Math . Abs ( arr [ i ] ) ] == 1 ) { SubsetSum_2 += arr [ i ] ; } } } return Math . Abs ( SubsetSum_1 - SubsetSum_2 ) ; }
static void Main ( ) { int [ ] arr = { 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 } ; int n = arr . Length ; Console . WriteLine ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n ) ) ; } }
public static void minRange ( int [ ] arr , int n , int k ) { int l = 0 , r = n ;
for ( int i = 0 ; i < n ; i ++ ) {
ISet < int > s = new HashSet < int > ( ) ; int j ; for ( j = i ; j < n ; j ++ ) { s . Add ( arr [ j ] ) ; if ( s . Count == k ) { if ( ( j - i ) < ( r - l ) ) { r = j ; l = i ; } break ; } }
if ( j == n ) { break ; } }
if ( l == 0 && r == n ) { Console . WriteLine ( " Invalid ▁ k " ) ; } else { Console . WriteLine ( l + " ▁ " + r ) ; } }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 1 , 2 , 3 , 4 , 5 } ; int n = arr . Length ; int k = 3 ; minRange ( arr , n , k ) ; } }
static void minRange ( int [ ] arr , int n , int k ) {
int l = 0 , r = n ;
int j = - 1 ; Dictionary < int , int > hm = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { while ( j < n ) {
j ++ ;
if ( j < n && hm . Count < k ) if ( hm . ContainsKey ( arr [ j ] ) ) hm [ arr [ j ] ] = hm [ arr [ j ] ] + 1 ; else hm . Add ( arr [ j ] , 1 ) ;
if ( hm . Count == k && ( ( r - l ) >= ( j - i ) ) ) { l = i ; r = j ; break ; } }
if ( hm . Count < k ) break ;
while ( hm . Count == k ) { if ( hm . ContainsKey ( arr [ i ] ) && hm [ arr [ i ] ] == 1 ) hm . Remove ( arr [ i ] ) ; else { if ( hm . ContainsKey ( arr [ i ] ) ) hm [ arr [ i ] ] = hm [ arr [ i ] ] - 1 ; }
i ++ ;
if ( hm . Count == k && ( r - l ) >= ( j - i ) ) { l = i ; r = j ; } } if ( hm . ContainsKey ( arr [ i ] ) && hm [ arr [ i ] ] == 1 ) hm . Remove ( arr [ i ] ) ; else if ( hm . ContainsKey ( arr [ i ] ) ) hm [ arr [ i ] ] = hm [ arr [ i ] ] - 1 ; } if ( l == 0 && r == n ) Console . WriteLine ( " Invalid ▁ k " ) ; else Console . WriteLine ( l + " ▁ " + r ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 1 , 2 , 2 , 3 , 3 , 4 , 5 } ; int n = arr . Length ; int k = 3 ; minRange ( arr , n , k ) ; } }
static void longest ( int [ ] a , int n , int k ) { int [ ] freq = new int [ 7 ] ; int start = 0 , end = 0 , now = 0 , l = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
freq [ a [ i ] ] ++ ;
if ( freq [ a [ i ] ] == 1 ) now ++ ;
while ( now > k ) {
freq [ a [ l ] ] -- ;
if ( freq [ a [ l ] ] == 0 ) now -- ;
l ++ ; }
if ( i - l + 1 >= end - start + 1 ) { end = i ; start = l ; } }
for ( int i = start ; i <= end ; i ++ ) Console . Write ( a [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ ] a = { 6 , 5 , 1 , 2 , 3 , 2 , 1 , 4 , 5 } ; int n = a . Length ; int k = 3 ; longest ( a , n , k ) ; } }
public static int sum ( int [ ] a , int n ) {
IDictionary < int , int > cnt = new Dictionary < int , int > ( ) ;
int ans = 0 , pre_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { ans += ( i * a [ i ] ) - pre_sum ; pre_sum += a [ i ] ;
if ( cnt . ContainsKey ( a [ i ] - 1 ) ) { ans -= cnt [ a [ i ] - 1 ] ; }
if ( cnt . ContainsKey ( a [ i ] + 1 ) ) { ans += cnt [ a [ i ] + 1 ] ; }
if ( cnt . ContainsKey ( a [ i ] ) ) { cnt [ a [ i ] ] = cnt [ a [ i ] ] + 1 ; } else { cnt [ a [ i ] ] = 1 ; } } return ans ; }
public static void Main ( string [ ] args ) { int [ ] a = new int [ ] { 1 , 2 , 3 , 1 , 3 } ; int n = a . Length ; Console . WriteLine ( sum ( a , n ) ) ; } }
static int calculate ( int [ ] a , int n ) {
Array . Sort ( a ) ; int count = 1 ; int answer = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == a [ i - 1 ] ) {
count += 1 ; } else {
answer = answer + ( count * ( count - 1 ) ) / 2 ; count = 1 ; } } answer = answer + ( count * ( count - 1 ) ) / 2 ; return answer ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 1 , 2 , 4 } ; int n = a . Length ;
Console . WriteLine ( calculate ( a , n ) ) ; } }
static int calculate ( int [ ] a , int n ) {
int maximum = a . Max ( ) ;
int [ ] frequency = new int [ maximum + 1 ] ;
for ( int i = 0 ; i < n ; i ++ ) {
frequency [ a [ i ] ] += 1 ; } int answer = 0 ;
for ( int i = 0 ; i < ( maximum ) + 1 ; i ++ ) {
answer = answer + frequency [ i ] * ( frequency [ i ] - 1 ) ; } return answer / 2 ; }
public static void Main ( String [ ] args ) { int [ ] a = { 1 , 2 , 1 , 2 , 4 } ; int n = a . Length ;
Console . WriteLine ( calculate ( a , n ) ) ; } }
static int countSubarrWithEqualZeroAndOne ( int [ ] arr , int n ) {
Dictionary < int , int > mp = new Dictionary < int , int > ( ) ; int curr_sum = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { curr_sum += ( arr [ i ] == 0 ) ? - 1 : arr [ i ] ; if ( mp . ContainsKey ( curr_sum ) ) { var v = mp [ curr_sum ] ; mp . Remove ( curr_sum ) ; mp . Add ( curr_sum , ++ v ) ; } else mp . Add ( curr_sum , 1 ) ; } int count = 0 ;
foreach ( KeyValuePair < int , int > itr in mp ) {
if ( itr . Value > 1 ) count += ( ( itr . Value * ( itr . Value - 1 ) ) / 2 ) ; }
if ( mp . ContainsKey ( 0 ) ) count += mp [ 0 ] ;
return count ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 0 , 0 , 1 , 0 , 1 , 1 } ; int n = arr . Length ; Console . WriteLine ( " Count ▁ = ▁ " + countSubarrWithEqualZeroAndOne ( arr , n ) ) ; } }
static int lenOfLongSubarr ( int [ ] arr , int n ) {
Dictionary < int , int > um = new Dictionary < int , int > ( ) ; int sum = 0 , maxLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
sum += arr [ i ] == 0 ? - 1 : 1 ;
if ( sum == 1 ) maxLen = i + 1 ;
else if ( ! um . ContainsKey ( sum ) ) um . Add ( sum , i ) ;
if ( um . ContainsKey ( sum - 1 ) ) {
if ( maxLen < ( i - um [ sum - 1 ] ) ) maxLen = i - um [ sum - 1 ] ; } }
return maxLen ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 0 , 1 , 1 , 0 , 0 , 1 } ; int n = arr . Length ; Console . WriteLine ( " Length ▁ = ▁ " + lenOfLongSubarr ( arr , n ) ) ; } }
static void printAllAPTriplets ( int [ ] arr , int n ) { List < int > s = new List < int > ( ) ; for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int diff = arr [ j ] - arr [ i ] ; bool exists = s . Exists ( element => element == ( arr [ i ] - diff ) ) ; if ( exists ) Console . WriteLine ( arr [ i ] - diff + " ▁ " + arr [ i ] + " ▁ " + arr [ j ] ) ; } s . Add ( arr [ i ] ) ; } }
static void Main ( ) { int [ ] arr = new int [ ] { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = arr . Length ; printAllAPTriplets ( arr , n ) ; } }
static void findAllTriplets ( int [ ] arr , int n ) { for ( int i = 1 ; i < n - 1 ; i ++ ) {
for ( int j = i - 1 , k = i + 1 ; j >= 0 && k < n ; ) {
if ( arr [ j ] + arr [ k ] == 2 * arr [ i ] ) { Console . WriteLine ( arr [ j ] + " ▁ " + arr [ i ] + " ▁ " + arr [ k ] ) ;
k ++ ; j -- ; }
else if ( arr [ j ] + arr [ k ] < 2 * arr [ i ] ) ++ ; else -- ; } } }
public static void Main ( ) { int [ ] arr = { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = arr . Length ; findAllTriplets ( arr , n ) ; } }
static void findTriplets ( int [ ] a , int n , int sum ) { int i ;
Array . Sort ( a ) ;
bool flag = false ;
for ( i = 0 ; i < n - 2 ; i ++ ) { if ( i == 0 a [ i ] > a [ i - 1 ] ) {
int start = i + 1 ;
int end = n - 1 ;
int target = sum - a [ i ] ; while ( start < end ) {
if ( start > i + 1 && a [ start ] == a [ start - 1 ] ) { start ++ ; continue ; }
if ( end < n - 1 && a [ end ] == a [ end + 1 ] ) { end -- ; continue ; }
if ( target == a [ start ] + a [ end ] ) { Console . Write ( " [ " + a [ i ] + " , " + a [ start ] + " , " + a [ end ] + " ] ▁ " ) ; flag = true ; start ++ ; end -- ; }
else if ( target > ( a [ start ] + a [ end ] ) ) { start ++ ; }
else { end -- ; } } } }
if ( flag == false ) { Console . WriteLine ( " No ▁ Such ▁ Triplets ▁ Exist " ) ; } }
static void Main ( ) { int [ ] a = { 12 , 3 , 6 , 1 , 6 , 9 } ; int n = a . Length ; int sum = 24 ;
findTriplets ( a , n , sum ) ; } }
static int countTriplets ( int [ ] arr , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) for ( int j = i + 1 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] * arr [ j ] * arr [ k ] == m ) count ++ ; return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 4 , 6 , 2 , 3 , 8 } ; int m = 24 ; Console . WriteLine ( countTriplets ( arr , arr . Length , m ) ) ; } }
static int countPairs ( int [ ] arr , int n ) { int ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ )
if ( arr [ i ] == arr [ j ] ) ans ++ ; return ans ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 2 } ; int n = arr . Length ; Console . WriteLine ( countPairs ( arr , n ) ) ; } }
public static int countPairs ( int [ ] arr , int n ) { Dictionary < int , int > hm = new Dictionary < int , int > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( hm . ContainsKey ( arr [ i ] ) ) { int a = hm [ arr [ i ] ] ; hm . Remove ( arr [ i ] ) ; hm . Add ( arr [ i ] , a + 1 ) ; } else hm . Add ( arr [ i ] , 1 ) ; } int ans = 0 ;
foreach ( var it in hm ) { int count = it . Value ; ans += ( count * ( count - 1 ) ) / 2 ; } return ans ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 2 , 3 , 1 } ; Console . WriteLine ( countPairs ( arr , arr . Length ) ) ; } }
using System ; class GFG { static int N = 5 ;
static int [ ] ptr = new int [ 501 ] ;
static void findSmallestRange ( int [ , ] arr , int n , int k ) { int i , minval , maxval , minrange , minel = 0 , maxel = 0 , flag , minind ;
for ( i = 0 ; i <= k ; i ++ ) { ptr [ i ] = 0 ; } minrange = int . MaxValue ; while ( true ) {
minind = - 1 ; minval = int . MaxValue ; maxval = int . MinValue ; flag = 0 ;
for ( i = 0 ; i < k ; i ++ ) {
if ( ptr [ i ] == n ) { flag = 1 ; break ; }
if ( ptr [ i ] < n && arr [ i , ptr [ i ] ] < minval ) {
minind = i ; minval = arr [ i , ptr [ i ] ] ; }
if ( ptr [ i ] < n && arr [ i , ptr [ i ] ] > maxval ) { maxval = arr [ i , ptr [ i ] ] ; } }
if ( flag == 1 ) { break ; } ptr [ minind ] ++ ;
if ( ( maxval - minval ) < minrange ) { minel = minval ; maxel = maxval ; minrange = maxel - minel ; } } Console . WriteLine ( " The ▁ smallest ▁ range ▁ is " + " [ { 0 } , ▁ { 1 } ] STRNEWLINE " , minel , maxel ) ; }
public static void Main ( String [ ] args ) { int [ , ] arr = { { 4 , 7 , 9 , 12 , 15 } , { 0 , 8 , 10 , 14 , 20 } , { 6 , 12 , 16 , 30 , 50 } } ; int k = arr . GetLength ( 0 ) ; findSmallestRange ( arr , N , k ) ; } }
static int countNum ( int [ ] arr , int n ) { int count = 0 ;
Array . Sort ( arr ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) count += arr [ i + 1 ] - arr [ i ] - 1 ; return count ; }
static public void Main ( ) { int [ ] arr = { 3 , 5 , 8 , 6 } ; int n = arr . Length ; Console . WriteLine ( countNum ( arr , n ) ) ; } }
static int countNum ( int [ ] arr , int n ) { HashSet < int > s = new HashSet < int > ( ) ; int count = 0 , maxm = int . MinValue , minm = int . MaxValue ;
for ( int i = 0 ; i < n ; i ++ ) { s . Add ( arr [ i ] ) ; if ( arr [ i ] < minm ) minm = arr [ i ] ; if ( arr [ i ] > maxm ) maxm = arr [ i ] ; }
for ( int i = minm ; i <= maxm ; i ++ ) if ( ! s . Contains ( i ) ) count ++ ; return count ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 3 , 5 , 8 , 6 } ; int n = arr . Length ; Console . WriteLine ( countNum ( arr , n ) ) ; } }
static int MAXN = 11 ;
static int ver = 2 ;
static int [ , ] hashtable = new int [ ver , MAXN ] ;
static int [ ] pos = new int [ ver ] ;
static void initTable ( ) { for ( int j = 0 ; j < MAXN ; j ++ ) for ( int i = 0 ; i < ver ; i ++ ) hashtable [ i , j ] = int . MinValue ; }
static int hash ( int function , int key ) { switch ( function ) { case 1 : return key % MAXN ; case 2 : return ( key / MAXN ) % MAXN ; } return int . MinValue ; }
static void place ( int key , int tableID , int cnt , int n ) {
if ( cnt == n ) { Console . Write ( " { 0 } ▁ unpositioned STRNEWLINE " , key ) ; Console . Write ( " Cycle ▁ present . ▁ REHASH . STRNEWLINE " ) ; return ; }
for ( int i = 0 ; i < ver ; i ++ ) { pos [ i ] = hash ( i + 1 , key ) ; if ( hashtable [ i , pos [ i ] ] == key ) return ; }
if ( hashtable [ tableID , pos [ tableID ] ] != int . MinValue ) { int dis = hashtable [ tableID , pos [ tableID ] ] ; hashtable [ tableID , pos [ tableID ] ] = key ; place ( dis , ( tableID + 1 ) % ver , cnt + 1 , n ) ; }
else hashtable [ tableID , pos [ tableID ] ] = key ; }
static void printTable ( ) { Console . Write ( " Final ▁ hash ▁ tables : STRNEWLINE " ) ; for ( int i = 0 ; i < ver ; i ++ , Console . Write ( " STRNEWLINE " ) ) for ( int j = 0 ; j < MAXN ; j ++ ) if ( hashtable [ i , j ] == int . MinValue ) Console . Write ( " - ▁ " ) ; else Console . Write ( " { 0 } ▁ " , hashtable [ i , j ] ) ; Console . Write ( " STRNEWLINE " ) ; }
static void cuckoo ( int [ ] keys , int n ) {
initTable ( ) ;
for ( int i = 0 , cnt = 0 ; i < n ; i ++ , cnt = 0 ) place ( keys [ i ] , 0 , cnt , n ) ;
printTable ( ) ; }
int [ ] keys_1 = { 20 , 50 , 53 , 75 , 100 , 67 , 105 , 3 , 36 , 39 } ; int n = keys_1 . Length ; cuckoo ( keys_1 , n ) ;
int [ ] keys_2 = { 20 , 50 , 53 , 75 , 100 , 67 , 105 , 3 , 36 , 39 , 6 } ; int m = keys_2 . Length ; cuckoo ( keys_2 , m ) ; } }
public static int sumoflength ( int [ ] arr , int n ) {
HashSet < int > s = new HashSet < int > ( ) ;
int j = 0 , ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { while ( j < n && ! s . Contains ( arr [ j ] ) ) { s . Add ( arr [ i ] ) ; j ++ ; }
ans += ( ( j - i ) * ( j - i + 1 ) ) / 2 ;
s . Remove ( arr [ i ] ) ; } return ans ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 3 , 4 } ; int n = arr . Length ; Console . WriteLine ( sumoflength ( arr , n ) ) ; } }
static int countDistictSubarray ( int [ ] arr , int n ) {
Dictionary < int , int > vis = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; ++ i ) if ( ! vis . ContainsKey ( arr [ i ] ) ) vis . Add ( arr [ i ] , 1 ) ; int k = vis . Count ;
vis . Clear ( ) ;
int ans = 0 , right = 0 , window = 0 ; for ( int left = 0 ; left < n ; ++ left ) { while ( right < n && window < k ) { if ( vis . ContainsKey ( arr [ right ] ) ) vis [ arr [ right ] ] = vis [ arr [ right ] ] + 1 ; else vis . Add ( arr [ right ] , 1 ) ; if ( vis [ arr [ right ] ] == 1 ) ++ window ; ++ right ; }
if ( window == k ) ans += ( n - right + 1 ) ;
if ( vis . ContainsKey ( arr [ left ] ) ) vis [ arr [ left ] ] = vis [ arr [ left ] ] - 1 ;
if ( vis [ arr [ left ] ] == 0 ) -- window ; } return ans ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 2 , 1 , 3 , 2 , 3 } ; Console . WriteLine ( countDistictSubarray ( arr , arr . Length ) ) ; } }
static int countSubarrays ( int [ ] arr , int n ) {
int difference = 0 ; int ans = 0 ;
int [ ] hash_positive = new int [ n + 1 ] ; int [ ] hash_negative = new int [ n + 1 ] ;
Array . Clear ( hash_positive , 0 , n + 1 ) ; Array . Clear ( hash_negative , 0 , n + 1 ) ;
hash_positive [ 0 ] = 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ( arr [ i ] & 1 ) == 1 ) difference ++ ; else difference -- ;
if ( difference < 0 ) { ans += hash_negative [ - difference ] ; hash_negative [ - difference ] ++ ; }
else { ans += hash_positive [ difference ] ; hash_positive [ difference ] ++ ; } }
return ans ; }
static void Main ( ) { int [ ] arr = new int [ ] { 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 } ; int n = arr . Length ;
Console . Write ( " Total ▁ Number ▁ of ▁ Even - Odd " + " ▁ subarrays ▁ are ▁ " + countSubarrays ( arr , n ) ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int val ) { data = val ; left = right = null ; } } public class GFG { static int ans , lh , rh , f ; static Node k ; public static Node Root ;
static int height ( Node root ) { if ( root == null ) return 0 ; int left_height = height ( root . left ) ; int right_height = height ( root . right ) ;
if ( ans < 1 + left_height + right_height ) { ans = 1 + left_height + right_height ;
k = root ;
lh = left_height ; rh = right_height ; } return 1 + Math . Max ( left_height , right_height ) ; }
static void printArray ( int [ ] ints , int len ) { int i ;
if ( f == 0 ) { for ( i = len - 1 ; i >= 0 ; i -- ) { Console . Write ( ints [ i ] + " ▁ " ) ; } } else if ( f == 1 ) { for ( i = 0 ; i < len ; i ++ ) { Console . Write ( ints [ i ] + " ▁ " ) ; } } }
static void printPathsRecur ( Node node , int [ ] path , int pathLen , int max ) { if ( node == null ) return ;
path [ pathLen ] = node . data ; pathLen ++ ;
if ( node . left == null && node . right == null ) {
if ( pathLen == max && ( f == 0 f == 1 ) ) { printArray ( path , pathLen ) ; f = 2 ; } } else {
printPathsRecur ( node . left , path , pathLen , max ) ; printPathsRecur ( node . right , path , pathLen , max ) ; } }
static void diameter ( Node root ) { if ( root == null ) return ;
ans = Int32 . MinValue ; lh = 0 ; rh = 0 ;
f = 0 ; int height_of_tree = height ( root ) ; int [ ] lPath = new int [ 100 ] ; int pathlen = 0 * height_of_tree ;
printPathsRecur ( k . left , lPath , pathlen , lh ) ; Console . Write ( k . data + " ▁ " ) ; int [ ] rPath = new int [ 100 ] ; f = 1 ;
printPathsRecur ( k . right , rPath , pathlen , rh ) ; }
GFG . Root = new Node ( 1 ) ; GFG . Root . left = new Node ( 2 ) ; GFG . Root . right = new Node ( 3 ) ; GFG . Root . left . left = new Node ( 4 ) ; GFG . Root . left . right = new Node ( 5 ) ; GFG . Root . left . right . left = new Node ( 6 ) ; GFG . Root . left . right . right = new Node ( 7 ) ; GFG . Root . left . left . right = new Node ( 8 ) ; GFG . Root . left . left . right . left = new Node ( 9 ) ; diameter ( Root ) ; } }
static int findLargestd ( int [ ] S , int n ) { bool found = false ;
Array . Sort ( S ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) continue ; for ( int k = j + 1 ; k < n ; k ++ ) { if ( i == k ) continue ; for ( int l = k + 1 ; l < n ; l ++ ) { if ( i == l ) continue ;
if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) { found = true ; return S [ i ] ; } } } } } if ( found == false ) return int . MaxValue ; return - 1 ; }
public static void Main ( ) { int [ ] S = new int [ ] { 2 , 3 , 5 , 7 , 12 } ; int n = S . Length ; int ans = findLargestd ( S , n ) ; if ( ans == int . MaxValue ) Console . WriteLine ( " No ▁ Solution " ) ; else Console . Write ( " Largest ▁ d ▁ such ▁ that ▁ a ▁ + ▁ " + " b ▁ + ▁ c ▁ = ▁ d ▁ is ▁ " + ans ) ; } }
public class Indexes { int i , j ; public Indexes ( int i , int j ) { this . i = i ; this . j = j ; } public int getI ( ) { return i ; } public int getJ ( ) { return j ; } } public class GFG {
static int findFourElements ( int [ ] arr , int n ) { Dictionary < int , Indexes > map = new Dictionary < int , Indexes > ( ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { map . Add ( arr [ i ] + arr [ j ] , new Indexes ( i , j ) ) ; } } int d = int . MinValue ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int abs_diff = Math . Abs ( arr [ i ] - arr [ j ] ) ;
if ( map . ContainsKey ( abs_diff ) ) { Indexes indexes = map [ abs_diff ] ;
if ( indexes . getI ( ) != i && indexes . getI ( ) != j && indexes . getJ ( ) != i && indexes . getJ ( ) != j ) { d = Math . Max ( d , Math . Max ( arr [ i ] , arr [ j ] ) ) ; } } } } return d ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 2 , 3 , 5 , 7 , 12 } ; int n = arr . Length ; int res = findFourElements ( arr , n ) ; if ( res == int . MinValue ) Console . WriteLine ( " No ▁ Solution " ) ; else Console . WriteLine ( res ) ; } }
static void recaman ( int n ) {
int [ ] arr = new int [ n ] ;
arr [ 0 ] = 0 ; Console . Write ( arr [ 0 ] + " ▁ , " ) ;
for ( int i = 1 ; i < n ; i ++ ) { int curr = arr [ i - 1 ] - i ; int j ; for ( j = 0 ; j < i ; j ++ ) {
if ( ( arr [ j ] == curr ) curr < 0 ) { curr = arr [ i - 1 ] + i ; break ; } } arr [ i ] = curr ; Console . Write ( arr [ i ] + " , ▁ " ) ; } }
public static void Main ( ) { int n = 17 ; recaman ( n ) ; } }
static void recaman ( int n ) { if ( n <= 0 ) return ;
Console . Write ( " { 0 } , ▁ " , 0 ) ; HashSet < int > s = new HashSet < int > ( ) ; s . Add ( 0 ) ;
int prev = 0 ; for ( int i = 1 ; i < n ; i ++ ) { int curr = prev - i ;
if ( curr < 0 || s . Contains ( curr ) ) curr = prev + i ; s . Add ( curr ) ; Console . Write ( " { 0 } , ▁ " , curr ) ; prev = curr ; } }
public static void Main ( String [ ] args ) { int n = 17 ; recaman ( n ) ; } }
static int sumOfDiv ( int x ) {
int sum = 1 ; for ( int i = 2 ; i <= Math . Sqrt ( x ) ; i ++ ) { if ( x % i == 0 ) { sum += i ;
if ( x / i != i ) sum += x / i ; } } return sum ; }
static Boolean isAmicable ( int a , int b ) { return ( sumOfDiv ( a ) == b && sumOfDiv ( b ) == a ) ; }
static int countPairs ( int [ ] arr , int n ) {
HashSet < int > s = new HashSet < int > ( ) ; int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) s . Add ( arr [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( s . Contains ( sumOfDiv ( arr [ i ] ) ) ) {
int sum = sumOfDiv ( arr [ i ] ) ; if ( isAmicable ( arr [ i ] , sum ) ) count ++ ; } }
return count / 2 ; }
public static void Main ( String [ ] args ) { int [ ] arr1 = { 220 , 284 , 1184 , 1210 , 2 , 5 } ; int n1 = arr1 . Length ; Console . WriteLine ( countPairs ( arr1 , n1 ) ) ; int [ ] arr2 = { 2620 , 2924 , 5020 , 5564 , 6232 , 6368 } ; int n2 = arr2 . Length ; Console . WriteLine ( countPairs ( arr2 , n2 ) ) ; } }
static int findArea ( int [ ] arr , int n ) {
Array . Sort ( arr ) ; Array . Reverse ( arr ) ;
int [ ] dimension = { 0 , 0 } ;
for ( int i = 0 , j = 0 ; i < n - 1 && j < 2 ; i ++ )
if ( arr [ i ] == arr [ i + 1 ] ) dimension [ j ++ ] = arr [ i ++ ] ;
return ( dimension [ 0 ] * dimension [ 1 ] ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 } ; int n = arr . Length ; Console . Write ( findArea ( arr , n ) ) ; } }
public static int findArea ( int [ ] arr , int n ) { ISet < int > s = new HashSet < int > ( ) ;
int first = 0 , second = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( ! s . Contains ( arr [ i ] ) ) { s . Add ( arr [ i ] ) ; continue ; }
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; } else if ( arr [ i ] > second ) { second = arr [ i ] ; } }
return ( first * second ) ; }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 } ; int n = arr . Length ; Console . WriteLine ( findArea ( arr , n ) ) ; } }
using System ; using System . Collections . Generic ; public class Graph { static readonly int MAX_PATH_SIZE = 1000 ;
public class Node { public char data ; public Node left , right ; } ;
static Node newNode ( char data ) { Node temp = new Node ( ) ; temp . data = data ; temp . left = temp . right = null ; return temp ; }
public class PATH { public int Hd ; public char key ; public PATH ( int Hd , char key ) { this . Hd = Hd ; this . key = key ; } public PATH ( ) { } } ;
static void printPath ( List < PATH > path , int size ) {
int minimum_Hd = int . MaxValue ; PATH p ;
for ( int it = 0 ; it < size ; it ++ ) { p = path [ it ] ; minimum_Hd = Math . Min ( minimum_Hd , p . Hd ) ; }
for ( int it = 0 ; it < size ; it ++ ) {
p = path [ it ] ; int noOfUnderScores = Math . Abs ( p . Hd - minimum_Hd ) ;
for ( int i = 0 ; i < noOfUnderScores ; i ++ ) Console . Write ( " _ " ) ;
Console . WriteLine ( p . key ) ; } Console . WriteLine ( " = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " ) ; }
static void printAllPathsUtil ( Node root , List < PATH > AllPath , int HD , int order ) {
if ( root == null ) return ;
if ( root . left == null && root . right == null ) {
AllPath [ order ] = new PATH ( HD , root . data ) ; printPath ( AllPath , order + 1 ) ; return ; }
AllPath [ order ] = new PATH ( HD , root . data ) ;
printAllPathsUtil ( root . left , AllPath , HD - 1 , order + 1 ) ;
printAllPathsUtil ( root . right , AllPath , HD + 1 , order + 1 ) ; } static void printAllPaths ( Node root ) {
if ( root == null ) return ; List < PATH > Allpaths = new List < PATH > ( ) ; for ( int i = 0 ; i < MAX_PATH_SIZE ; i ++ ) { Allpaths . Add ( new PATH ( ) ) ; } printAllPathsUtil ( root , Allpaths , 0 , 0 ) ; }
public static void Main ( String [ ] args ) { Node root = newNode ( ' A ' ) ; root . left = newNode ( ' B ' ) ; root . right = newNode ( ' C ' ) ; root . left . left = newNode ( ' D ' ) ; root . left . right = newNode ( ' E ' ) ; root . right . left = newNode ( ' F ' ) ; root . right . right = newNode ( ' G ' ) ; printAllPaths ( root ) ; } }
static int longLenStrictBitonicSub ( int [ ] arr , int n ) {
Dictionary < int , int > inc = new Dictionary < int , int > ( ) ; Dictionary < int , int > dcr = new Dictionary < int , int > ( ) ;
int [ ] len_inc = new int [ n ] ; int [ ] len_dcr = new int [ n ] ;
int longLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int len = 0 ;
if ( inc . ContainsKey ( arr [ i ] - 1 ) ) len = inc [ arr [ i ] - 1 ] ;
len_inc [ i ] = len + 1 ; if ( inc . ContainsKey ( arr [ i ] ) ) { inc . Remove ( arr [ i ] ) ; inc . Add ( arr [ i ] , len_inc [ i ] ) ; } else inc . Add ( arr [ i ] , len_inc [ i ] ) ; }
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int len = 0 ;
if ( dcr . ContainsKey ( arr [ i ] - 1 ) ) len = dcr [ arr [ i ] - 1 ] ;
len_dcr [ i ] = len + 1 ; if ( dcr . ContainsKey ( arr [ i ] ) ) { dcr . Remove ( arr [ i ] ) ; dcr . Add ( arr [ i ] , len_dcr [ i ] ) ; } else dcr . Add ( arr [ i ] , len_dcr [ i ] ) ; }
for ( int i = 0 ; i < n ; i ++ ) if ( longLen < ( len_inc [ i ] + len_dcr [ i ] - 1 ) ) longLen = len_inc [ i ] + len_dcr [ i ] - 1 ;
return longLen ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 5 , 2 , 3 , 4 , 5 , 3 , 2 } ; int n = arr . Length ; Console . WriteLine ( " Longest ▁ length ▁ strict ▁ " + " bitonic ▁ subsequence ▁ = ▁ " + longLenStrictBitonicSub ( arr , n ) ) ; } }
public static void leftRotate ( int [ ] arr , int d , int n ) { leftRotateRec ( arr , 0 , d , n ) ; } public static void leftRotateRec ( int [ ] arr , int i , int d , int n ) {
if ( d == 0 d == n ) return ;
if ( n - d == d ) { swap ( arr , i , n - d + i , d ) ; return ; }
if ( d < n - d ) { swap ( arr , i , n - d + i , d ) ; leftRotateRec ( arr , i , d , n - d ) ; }
else { swap ( arr , i , d , n - d ) ; leftRotateRec ( arr , n - d + i , 2 * d - n , d ) ; } }
public static void printArray ( int [ ] arr , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void swap ( int [ ] arr , int fi , int si , int d ) { int i , temp ; for ( i = 0 ; i < d ; i ++ ) { temp = arr [ fi + i ] ; arr [ fi + i ] = arr [ si + i ] ; arr [ si + i ] = temp ; } }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; leftRotate ( arr , 2 , 7 ) ; printArray ( arr , 7 ) ; } }
static void leftRotate ( int [ ] arr , int d , int n ) { int i , j ; if ( d == 0 d == n ) return ; i = d ; j = n - d ; while ( i != j ) {
if ( i < j ) { swap ( arr , d - i , d + j - i , i ) ; j -= i ; }
else { swap ( arr , d - i , d , j ) ; i -= j ; } }
swap ( arr , d - i , d , i ) ; }
static int search ( int [ ] arr , int l , int h , int key ) { if ( l > h ) return - 1 ; int mid = ( l + h ) / 2 ; if ( arr [ mid ] == key ) return mid ;
if ( arr [ l ] <= arr [ mid ] ) {
if ( key >= arr [ l ] && key <= arr [ mid ] ) return search ( arr , l , mid - 1 , key ) ;
return search ( arr , mid + 1 , h , key ) ; }
if ( key >= arr [ mid ] && key <= arr [ h ] ) return search ( arr , mid + 1 , h , key ) ; return search ( arr , l , mid - 1 , key ) ; }
public static void Main ( ) { int [ ] arr = { 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 } ; int n = arr . Length ; int key = 6 ; int i = search ( arr , 0 , n - 1 , key ) ; if ( i != - 1 ) Console . WriteLine ( " Index : ▁ " + i ) ; else Console . WriteLine ( " Key ▁ not ▁ found " ) ; } }
static bool pairInSortedRotated ( int [ ] arr , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) return true ;
if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return false ; }
public static void Main ( ) { int [ ] arr = { 11 , 15 , 6 , 8 , 9 , 10 } ; int sum = 16 ; int n = arr . Length ; if ( pairInSortedRotated ( arr , n , sum ) ) Console . WriteLine ( " Array ▁ has ▁ two ▁ elements " + " ▁ with ▁ sum ▁ 16" ) ; else Console . WriteLine ( " Array ▁ doesn ' t ▁ have ▁ two " + " ▁ elements ▁ with ▁ sum ▁ 16 ▁ " ) ; } }
static int pairsInSortedRotated ( int [ ] arr , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
int cnt = 0 ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) { cnt ++ ;
if ( l == ( r - 1 + n ) % n ) { return cnt ; } l = ( l + 1 ) % n ; r = ( r - 1 + n ) % n ; }
else if ( arr [ l ] + arr [ r ] < x ) = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return cnt ; }
static public void Main ( ) { int [ ] arr = { 11 , 15 , 6 , 7 , 9 , 10 } ; int sum = 16 ; int n = arr . Length ; Console . WriteLine ( pairsInSortedRotated ( arr , n , sum ) ) ; } }
static int maxSum ( ) {
int arrSum = 0 ;
int currVal = 0 ; for ( int i = 0 ; i < arr . Length ; i ++ ) { arrSum = arrSum + arr [ i ] ; currVal = currVal + ( i * arr [ i ] ) ; }
int maxVal = currVal ;
for ( int j = 1 ; j < arr . Length ; j ++ ) { currVal = currVal + arrSum - arr . Length * arr [ arr . Length - j ] ; if ( currVal > maxVal ) maxVal = currVal ; }
return maxVal ; }
public static void Main ( ) { Console . WriteLine ( " Max ▁ sum ▁ is ▁ " + maxSum ( ) ) ; } }
static int maxSum ( int [ ] arr , int n ) {
int res = int . MinValue ;
for ( int i = 0 ; i < n ; i ++ ) {
int curr_sum = 0 ;
for ( int j = 0 ; j < n ; j ++ ) { int index = ( i + j ) % n ; curr_sum += j * arr [ index ] ; }
res = Math . Max ( res , curr_sum ) ; } return res ; }
public static void Main ( ) { int [ ] arr = { 8 , 3 , 1 , 2 } ; int n = arr . Length ; Console . WriteLine ( maxSum ( arr , n ) ) ; } }
using System ; class GFG { static int maxSum ( int [ ] arr , int n ) {
int cum_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) cum_sum += arr [ i ] ;
int curr_val = 0 ; for ( int i = 0 ; i < n ; i ++ ) curr_val += i * arr [ i ] ;
int res = curr_val ;
for ( int i = 1 ; i < n ; i ++ ) {
int next_val = curr_val - ( cum_sum - arr [ i - 1 ] ) + arr [ i - 1 ] * ( n - 1 ) ;
curr_val = next_val ;
res = Math . Max ( res , next_val ) ; } return res ; }
public static void Main ( ) { int [ ] arr = { 8 , 3 , 1 , 2 } ; int n = arr . Length ; Console . Write ( maxSum ( arr , n ) ) ; } }
static int countRotations ( int [ ] arr , int n ) {
int min = arr [ 0 ] , min_index = - 1 ; for ( int i = 0 ; i < n ; i ++ ) { if ( min > arr [ i ] ) { min = arr [ i ] ; min_index = i ; } } return min_index ; }
public static void Main ( ) { int [ ] arr = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = arr . Length ; Console . WriteLine ( countRotations ( arr , n ) ) ; } }
static int countRotations ( int [ ] arr , int low , int high ) {
if ( high < low ) return 0 ;
if ( high == low ) return low ;
int mid = low + ( high - low ) / 2 ;
if ( mid < high && arr [ mid + 1 ] < arr [ mid ] ) return ( mid + 1 ) ;
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) return mid ;
if ( arr [ high ] > arr [ mid ] ) return countRotations ( arr , low , mid - 1 ) ; return countRotations ( arr , mid + 1 , high ) ; }
public static void Main ( ) { int [ ] arr = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = arr . Length ; Console . WriteLine ( countRotations ( arr , 0 , n - 1 ) ) ; } }
static void preprocess ( int [ ] arr , int n , int [ ] temp ) {
for ( int i = 0 ; i < n ; i ++ ) temp [ i ] = temp [ i + n ] = arr [ i ] ; }
static void leftRotate ( int [ ] arr , int n , int k , int [ ] temp ) {
int start = k % n ;
for ( int i = start ; i < start + n ; i ++ ) Console . Write ( temp [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . Length ; int [ ] temp = new int [ 2 * n ] ; preprocess ( arr , n , temp ) ; int k = 2 ; leftRotate ( arr , n , k , temp ) ; k = 3 ; leftRotate ( arr , n , k , temp ) ; k = 4 ; leftRotate ( arr , n , k , temp ) ; } }
static void leftRotate ( int [ ] arr , int n , int k ) {
for ( int i = k ; i < k + n ; i ++ ) Console . Write ( arr [ i % n ] + " ▁ " ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . Length ; int k = 2 ; leftRotate ( arr , n , k ) ; Console . WriteLine ( ) ; k = 3 ; leftRotate ( arr , n , k ) ; Console . WriteLine ( ) ; k = 4 ; leftRotate ( arr , n , k ) ; Console . WriteLine ( ) ; } }
public static int findMin ( int [ ] arr , int low , int high ) { while ( low < high ) { int mid = low + ( high - low ) / 2 ; if ( arr [ mid ] == arr [ high ] ) high -- ; else if ( arr [ mid ] > arr [ high ] ) low = mid + 1 ; else high = mid ; } return arr [ high ] ; }
public static void Main ( String [ ] args ) { int [ ] arr1 = { 5 , 6 , 1 , 2 , 3 , 4 } ; int n1 = arr1 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr1 , 0 , n1 - 1 ) ) ; int [ ] arr2 = { 1 , 2 , 3 , 4 } ; int n2 = arr2 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr2 , 0 , n2 - 1 ) ) ; int [ ] arr3 = { 1 } ; int n3 = arr3 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr3 , 0 , n3 - 1 ) ) ; int [ ] arr4 = { 1 , 2 } ; int n4 = arr4 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr4 , 0 , n4 - 1 ) ) ; int [ ] arr5 = { 2 , 1 } ; int n5 = arr5 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr5 , 0 , n5 - 1 ) ) ; int [ ] arr6 = { 5 , 6 , 7 , 1 , 2 , 3 , 4 } ; int n6 = arr6 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr6 , 0 , n6 - 1 ) ) ; int [ ] arr7 = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int n7 = arr7 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr7 , 0 , n7 - 1 ) ) ; int [ ] arr8 = { 2 , 3 , 4 , 5 , 6 , 7 , 8 , 1 } ; int n8 = arr8 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr8 , 0 , n8 - 1 ) ) ; int [ ] arr9 = { 3 , 4 , 5 , 1 , 2 } ; int n9 = arr9 . Length ; Console . WriteLine ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr9 , 0 , n9 - 1 ) ) ; } }
static void reverseArray ( int [ ] arr , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
static void rightRotate ( int [ ] arr , int d , int n ) { reverseArray ( arr , 0 , n - 1 ) ; reverseArray ( arr , 0 , d - 1 ) ; reverseArray ( arr , d , n - 1 ) ; }
static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 } ; int n = arr . Length ; int k = 3 ; rightRotate ( arr , k , n ) ; printArray ( arr , n ) ; } }
static int maxHamming ( int [ ] arr , int n ) {
int [ ] brr = new int [ 2 * n + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ i ] = arr [ i ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ n + i ] = arr [ i ] ;
int maxHam = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { int currHam = 0 ; for ( int j = i , k = 0 ; j < ( i + n ) ; j ++ , k ++ ) if ( brr [ j ] != arr [ k ] ) currHam ++ ;
if ( currHam == n ) return n ; maxHam = Math . Max ( maxHam , currHam ) ; } return maxHam ; }
public static void Main ( ) { int [ ] arr = { 2 , 4 , 6 , 8 } ; int n = arr . Length ; Console . Write ( maxHamming ( arr , n ) ) ; } }
static void leftRotate ( int [ ] arr , int n , int k ) {
int mod = k % n ;
for ( int i = 0 ; i < n ; ++ i ) Console . Write ( arr [ ( i + mod ) % n ] + " ▁ " ) ; Console . WriteLine ( ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . Length ; int k = 2 ;
leftRotate ( arr , n , k ) ; k = 3 ;
leftRotate ( arr , n , k ) ; k = 4 ;
leftRotate ( arr , n , k ) ; } }
static int findElement ( int [ ] arr , int [ , ] ranges , int rotations , int index ) { for ( int i = rotations - 1 ; i >= 0 ; i -- ) {
int left = ranges [ i , 0 ] ; int right = ranges [ i , 1 ] ;
if ( left <= index && right >= index ) { if ( index == left ) index = right ; else index -- ; } }
return arr [ index ] ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ;
int rotations = 2 ;
int [ , ] ranges = { { 0 , 2 } , { 0 , 3 } } ; int index = 1 ; Console . Write ( findElement ( arr , ranges , rotations , index ) ) ; } }
using System ; class GFG { public static void splitArr ( int [ ] arr , int n , int k ) { for ( int i = 0 ; i < k ; i ++ ) {
int x = arr [ 0 ] ; for ( int j = 0 ; j < n - 1 ; ++ j ) arr [ j ] = arr [ j + 1 ] ; arr [ n - 1 ] = x ; } }
public static void Main ( ) { int [ ] arr = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = arr . Length ; int position = 2 ; splitArr ( arr , 6 , position ) ; for ( int i = 0 ; i < n ; ++ i ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void SplitAndAdd ( int [ ] A , int length , int rotation ) {
int [ ] tmp = new int [ length * 2 ] ;
Array . Copy ( A , 0 , tmp , 0 , length ) ; Array . Copy ( A , 0 , tmp , length , length ) ; for ( int i = rotation ; i < rotation + length ; i ++ ) { A [ i - rotation ] = tmp [ i ] ; } }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = arr . Length ; int position = 2 ; SplitAndAdd ( arr , n , position ) ; for ( int i = 0 ; i < n ; ++ i ) { Console . Write ( arr [ i ] + " ▁ " ) ; } } }
static void fixArray ( int [ ] ar , int n ) { int i , j , temp ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) {
if ( ar [ j ] == i ) { temp = ar [ j ] ; ar [ j ] = ar [ i ] ; ar [ i ] = temp ; break ; } } }
for ( i = 0 ; i < n ; i ++ ) {
if ( ar [ i ] != i ) { ar [ i ] = - 1 ; } }
Console . WriteLine ( " Array ▁ after ▁ Rearranging " ) ; for ( i = 0 ; i < n ; i ++ ) { Console . Write ( ar [ i ] + " ▁ " ) ; } }
static void Main ( ) { int [ ] ar = { - 1 , - 1 , 6 , 1 , 9 , 3 , 2 , - 1 , 4 , - 1 } ; int n = ar . Length ;
fixArray ( ar , n ) ; } }
public static void rearrangeArr ( int [ ] arr , int n ) {
int evenPos = n / 2 ;
int oddPos = n - evenPos ; int [ ] tempArr = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) tempArr [ i ] = arr [ i ] ;
Array . Sort ( tempArr ) ; int j = oddPos - 1 ;
for ( int i = 0 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j -- ; } j = oddPos ;
for ( int i = 1 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j ++ ; }
for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int size = 7 ; rearrangeArr ( arr , size ) ; } }
static void pushZerosToEnd ( int [ ] arr , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
public static void Main ( ) { int [ ] arr = { 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 } ; int n = arr . Length ; pushZerosToEnd ( arr , n ) ; Console . WriteLine ( " Array ▁ after ▁ pushing ▁ all ▁ zeros ▁ to ▁ the ▁ back : ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static void moveZerosToEnd ( int [ ] arr , int n ) {
int count = 0 ; int temp ;
for ( int i = 0 ; i < n ; i ++ ) { if ( ( arr [ i ] != 0 ) ) { temp = arr [ count ] ; arr [ count ] = arr [ i ] ; arr [ i ] = temp ; count = count + 1 ; } } }
static void printArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 0 , 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 } ; int n = arr . Length ; Console . Write ( " Original ▁ array : ▁ " ) ; printArray ( arr , n ) ; moveZerosToEnd ( arr , n ) ; Console . Write ( " STRNEWLINE Modified ▁ array : ▁ " ) ; printArray ( arr , n ) ; } }
using System ; class GFG { static void printArray ( int [ ] array , int length ) { Console . Write ( " [ " ) ; for ( int i = 0 ; i < length ; i ++ ) { Console . Write ( array [ i ] ) ; if ( i < ( length - 1 ) ) Console . Write ( " , " ) ; else Console . Write ( " ] STRNEWLINE " ) ; } } static void reverse ( int [ ] array , int start , int end ) { while ( start < end ) { int temp = array [ start ] ; array [ start ] = array [ end ] ; array [ end ] = temp ; start ++ ; end -- ; } }
static void rearrange ( int [ ] array , int start , int end ) {
if ( start == end ) return ;
rearrange ( array , ( start + 1 ) , end ) ;
if ( array [ start ] >= 0 ) { reverse ( array , ( start + 1 ) , end ) ; reverse ( array , start , end ) ; } }
public static void Main ( string [ ] args ) { int [ ] array = { - 12 , - 11 , - 13 , - 5 , - 6 , 7 , 5 , 3 , 6 } ; int length = array . Length ; int countNegative = 0 ; for ( int i = 0 ; i < length ; i ++ ) { if ( array [ i ] < 0 ) countNegative ++ ; } Console . Write ( " array : ▁ " ) ; printArray ( array , length ) ; rearrange ( array , 0 , ( length - 1 ) ) ; reverse ( array , countNegative , ( length - 1 ) ) ; Console . Write ( " rearranged ▁ array : ▁ " ) ; printArray ( array , length ) ; } }
static void pushZerosToEnd ( int [ ] arr , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
static void modifyAndRearrangeArr ( int [ ] arr , int n ) {
if ( n == 1 ) return ;
for ( int i = 0 ; i < n - 1 ; i ++ ) {
if ( ( arr [ i ] != 0 ) && ( arr [ i ] == arr [ i + 1 ] ) ) {
arr [ i ] = 2 * arr [ i ] ;
arr [ i + 1 ] = 0 ;
i ++ ; } }
pushZerosToEnd ( arr , n ) ; }
static void printArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( ) { int [ ] arr = { 0 , 2 , 2 , 2 , 0 , 6 , 6 , 0 , 0 , 8 } ; int n = arr . Length ; Console . Write ( " Original ▁ array : ▁ " ) ; printArray ( arr , n ) ; modifyAndRearrangeArr ( arr , n ) ; Console . Write ( " Modified ▁ array : ▁ " ) ; printArray ( arr , n ) ; } }
static void reorder ( ) { int [ ] temp = new int [ arr . Length ] ;
for ( int i = 0 ; i < arr . Length ; i ++ ) temp [ index [ i ] ] = arr [ i ] ;
for ( int i = 0 ; i < arr . Length ; i ++ ) { arr [ i ] = temp [ i ] ; index [ i ] = i ; } }
public static void Main ( ) { reorder ( ) ; Console . WriteLine ( " Reordered ▁ array ▁ is : ▁ " ) ; Console . WriteLine ( string . Join ( " , " , arr ) ) ; Console . WriteLine ( " Modified ▁ Index ▁ array ▁ is : " ) ; Console . WriteLine ( string . Join ( " , " , index ) ) ; } }
static void reorder ( ) {
for ( int i = 0 ; i < arr . Length ; i ++ ) {
while ( index [ i ] != i ) {
int oldTargetI = index [ index [ i ] ] ; char oldTargetE = ( char ) arr [ index [ i ] ] ;
arr [ index [ i ] ] = arr [ i ] ; index [ index [ i ] ] = index [ i ] ;
index [ i ] = oldTargetI ; arr [ i ] = oldTargetE ; } } }
public static void Main ( ) { reorder ( ) ; Console . WriteLine ( " Reordered ▁ array ▁ is : ▁ " ) ; Console . WriteLine ( String . Join ( " ▁ " , arr ) ) ; Console . WriteLine ( " Modified ▁ Index ▁ array ▁ is : " ) ; Console . WriteLine ( String . Join ( " ▁ " , index ) ) ; } }
static void printArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
static void RearrangePosNeg ( int [ ] arr , int n ) { int key , j ; for ( int i = 1 ; i < n ; i ++ ) { key = arr [ i ] ;
if ( key > 0 ) continue ;
j = i - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { arr [ j + 1 ] = arr [ j ] ; j = j - 1 ; }
arr [ j + 1 ] = key ; } }
public static void Main ( ) { int [ ] arr = { - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 } ; int n = arr . Length ; RearrangePosNeg ( arr , n ) ; printArray ( arr , n ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class BinaryTree { public Node root ;
public virtual bool isLeaf ( Node node ) { if ( node == null ) { return false ; } if ( node . left == null && node . right == null ) { return true ; } return false ; }
public virtual int leftLeavesSum ( Node node ) {
int res = 0 ;
if ( node != null ) {
if ( isLeaf ( node . left ) ) { res += node . left . data ; }
else { res += leftLeavesSum ( node . left ) ; }
res += leftLeavesSum ( node . right ) ; }
return res ; }
public static void Main ( string [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 20 ) ; tree . root . left = new Node ( 9 ) ; tree . root . right = new Node ( 49 ) ; tree . root . left . right = new Node ( 12 ) ; tree . root . left . left = new Node ( 5 ) ; tree . root . right . left = new Node ( 23 ) ; tree . root . right . right = new Node ( 52 ) ; tree . root . left . right . right = new Node ( 12 ) ; tree . root . right . right . left = new Node ( 50 ) ; Console . WriteLine ( " The ▁ sum ▁ of ▁ leaves ▁ is ▁ " + tree . leftLeavesSum ( tree . root ) ) ; } }
static void printArray ( int [ ] A , int size ) { for ( int i = 0 ; i < size ; i ++ ) Console . Write ( A [ i ] + " ▁ " ) ; Console . WriteLine ( " " ) ; ; }
static void reverse ( int [ ] arr , int l , int r ) { if ( l < r ) { arr = swap ( arr , l , r ) ; reverse ( arr , ++ l , -- r ) ; } }
static void merge ( int [ ] arr , int l , int m , int r ) {
int i = l ;
int j = m + 1 ; while ( i <= m && arr [ i ] < 0 ) i ++ ;
while ( j <= r && arr [ j ] < 0 ) j ++ ;
reverse ( arr , i , m ) ;
reverse ( arr , m + 1 , j - 1 ) ;
reverse ( arr , i , j - 1 ) ; }
static void RearrangePosNeg ( int [ ] arr , int l , int r ) { if ( l < r ) {
int m = l + ( r - l ) / 2 ;
RearrangePosNeg ( arr , l , m ) ; RearrangePosNeg ( arr , m + 1 , r ) ; merge ( arr , l , m , r ) ; } } static int [ ] swap ( int [ ] arr , int i , int j ) { int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; return arr ; }
public static void Main ( ) { int [ ] arr = { - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 } ; int arr_size = arr . Length ; RearrangePosNeg ( arr , 0 , arr_size - 1 ) ; printArray ( arr , arr_size ) ; } }
using System ; public class GFG { public static void RearrangePosNeg ( int [ ] arr ) { int i = 0 ; int j = arr . Length - 1 ; while ( true ) {
while ( arr [ i ] < 0 && i < arr . Length ) i ++ ;
while ( arr [ j ] > 0 && j >= 0 ) j -- ;
if ( i < j ) { int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } else break ; } }
static public void Main ( ) { int [ ] arr = { - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 } ; RearrangePosNeg ( arr ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
void rearrangeNaive ( int [ ] arr , int n ) {
int [ ] temp = new int [ n ] ; int i ;
for ( i = 0 ; i < n ; i ++ ) temp [ arr [ i ] ] = i ;
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
void printArray ( int [ ] arr , int n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { Console . Write ( arr [ i ] + " ▁ " ) ; } Console . WriteLine ( " " ) ; }
public static void Main ( ) { RearrangeArray arrange = new RearrangeArray ( ) ; int [ ] arr = { 1 , 3 , 0 , 2 } ; int n = arr . Length ; Console . WriteLine ( " Given ▁ array ▁ is ▁ " ) ; arrange . printArray ( arr , n ) ; arrange . rearrangeNaive ( arr , n ) ; Console . WriteLine ( " Modified ▁ array ▁ is ▁ " ) ; arrange . printArray ( arr , n ) ; } }
static void rearrange ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) {
arr [ arr [ i ] % n ] += i * n ; } for ( int i = 0 ; i < n ; i ++ ) {
arr [ i ] /= n ; } }
static void printArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
static public void Main ( ) { int [ ] arr = { 2 , 0 , 1 , 4 , 5 , 3 } ; int n = arr . Length ; Console . WriteLine ( " Given ▁ array ▁ is ▁ : ▁ " ) ; printArray ( arr , n ) ; rearrange ( arr , n ) ; Console . WriteLine ( " Modified ▁ array ▁ is ▁ : " ) ; printArray ( arr , n ) ; } }
static void rearrage ( int [ ] arr , int n ) {
int [ ] temp = new int [ n ] ;
int small = 0 , large = n - 1 ;
bool flag = true ;
for ( int i = 0 ; i < n ; i ++ ) { if ( flag ) temp [ i ] = arr [ large -- ] ; else temp [ i ] = arr [ small ++ ] ; flag = ! flag ; }
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 } ; Console . WriteLine ( " Original ▁ Array " ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; rearrage ( arr , arr . Length ) ; Console . WriteLine ( " STRNEWLINE Modified ▁ Array " ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void rearrange ( int [ ] arr , int n ) {
int max_idx = n - 1 , min_idx = 0 ;
int max_elem = arr [ n - 1 ] + 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] += ( arr [ max_idx ] % max_elem ) * max_elem ; max_idx -- ; }
else { arr [ i ] += ( arr [ min_idx ] % max_elem ) * max_elem ; min_idx ++ ; } }
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = arr [ i ] / max_elem ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = arr . Length ; Console . WriteLine ( " Original ▁ Array " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; rearrange ( arr , n ) ; Console . WriteLine ( " Modified ▁ Array " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void rearrange ( int [ ] arr , int n ) {
int max_ele = arr [ n - 1 ] ; int min_ele = arr [ 0 ] ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] = max_ele ; max_ele -= 1 ; }
else { arr [ i ] = min_ele ; min_ele += 1 ; } } }
static public void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = arr . Length ; Console . WriteLine ( " Original ▁ Array " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; rearrange ( arr , n ) ; Console . Write ( " STRNEWLINE Modified ▁ Array STRNEWLINE " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } }
public class Sum { public int sum = 0 ; } public class BinaryTree { public Node root ;
public virtual void leftLeavesSumRec ( Node node , bool isleft , Sum summ ) { if ( node == null ) { return ; }
if ( node . left == null && node . right == null && isleft ) { summ . sum = summ . sum + node . data ; }
leftLeavesSumRec ( node . left , true , summ ) ; leftLeavesSumRec ( node . right , false , summ ) ; }
public virtual int leftLeavesSum ( Node node ) { Sum suum = new Sum ( ) ;
leftLeavesSumRec ( node , false , suum ) ; return suum . sum ; }
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 20 ) ; tree . root . left = new Node ( 9 ) ; tree . root . right = new Node ( 49 ) ; tree . root . left . right = new Node ( 12 ) ; tree . root . left . left = new Node ( 5 ) ; tree . root . right . left = new Node ( 23 ) ; tree . root . right . right = new Node ( 52 ) ; tree . root . left . right . right = new Node ( 12 ) ; tree . root . right . right . left = new Node ( 50 ) ; Console . WriteLine ( " The ▁ sum ▁ of ▁ leaves ▁ is ▁ " + tree . leftLeavesSum ( tree . root ) ) ; } }
using System ; class GFG { static void rearrange ( int [ ] arr , int n ) { int j = 0 , temp ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < 0 ) { temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; j ++ ; } } }
static void printArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { - 1 , 2 , - 3 , 4 , 5 , 6 , - 7 , 8 , 9 } ; int n = arr . Length ; rearrange ( arr , n ) ; printArray ( arr , n ) ; } }
static void segregateElements ( int [ ] arr , int n ) {
int [ ] temp = new int [ n ] ;
int j = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] >= 0 ) temp [ j ++ ] = arr [ i ] ;
if ( j == n j == 0 ) return ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < 0 ) temp [ j ++ ] = arr [ i ] ;
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
public static void Main ( ) { int [ ] arr = { 1 , - 1 , - 3 , - 2 , 7 , 5 , 11 , 6 } ; int n = arr . Length ; segregateElements ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static void rearrange ( int [ ] arr , int n ) { int temp ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( i % 2 == 0 && arr [ i ] > arr [ i + 1 ] ) { temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } if ( i % 2 != 0 && arr [ i ] < arr [ i + 1 ] ) { temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } } }
static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( ) { int [ ] arr = { 6 , 4 , 2 , 1 , 8 , 3 } ; int n = arr . Length ; Console . WriteLine ( " Before ▁ rearranging : ▁ " ) ; printArray ( arr , n ) ; rearrange ( arr , n ) ; Console . WriteLine ( " After ▁ rearranging : ▁ " ) ; printArray ( arr , n ) ; } }
using System ; class GFG { static void rearrange ( int [ ] a , int size ) { int positive = 0 , negative = 1 , temp ; while ( true ) {
while ( positive < size && a [ positive ] >= 0 ) positive += 2 ;
while ( negative < size && a [ negative ] <= 0 ) negative += 2 ;
if ( positive < size && negative < size ) { temp = a [ positive ] ; a [ positive ] = a [ negative ] ; a [ negative ] = temp ; }
else break ; } }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 } ; int n = arr . Length ; rearrange ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static void swap ( int [ ] a , int i , int j ) { int temp = a [ i ] ; a [ i ] = a [ j ] ; a [ j ] = temp ; }
static void printArray ( int [ ] a , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( a [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( ) { int [ ] arr = { 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 } ; int n = arr . Length ;
printArray ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] >= 0 && i % 2 == 1 ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < 0 && j % 2 == 0 ) {
swap ( arr , i , j ) ; break ; } } } else if ( arr [ i ] < 0 && i % 2 == 0 ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] >= 0 && j % 2 == 1 ) {
swap ( arr , i , j ) ; break ; } } } }
printArray ( arr , n ) ; } }
static void arrayEvenAndOdd ( int [ ] arr , int n ) { int i = - 1 , j = 0 ; while ( j != n ) { if ( arr [ j ] % 2 == 0 ) { i ++ ;
int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } j ++ ; }
for ( int k = 0 ; k < n ; k ++ ) Console . Write ( arr [ k ] + " ▁ " ) ; }
static void Main ( ) { int [ ] arr = { 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 } ; int n = arr . Length ; arrayEvenAndOdd ( arr , n ) ; } }
class Node { public int key ; public Node left , right ; public Node ( int item ) { key = item ; left = right = null ; } } class BinaryTree {
Node root ; BinaryTree ( ) { root = null ; }
void printPostorder ( Node node ) { if ( node == null ) return ;
printPostorder ( node . left ) ;
printPostorder ( node . right ) ;
Console . Write ( node . key + " ▁ " ) ; }
void printInorder ( Node node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
Console . Write ( node . key + " ▁ " ) ;
printInorder ( node . right ) ; }
void printPreorder ( Node node ) { if ( node == null ) return ;
Console . Write ( node . key + " ▁ " ) ;
printPreorder ( node . left ) ;
printPreorder ( node . right ) ; }
static public void Main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; Console . WriteLine ( " Preorder ▁ traversal ▁ " + " of ▁ binary ▁ tree ▁ is ▁ " ) ; tree . printPreorder ( ) ; Console . WriteLine ( " STRNEWLINE Inorder ▁ traversal ▁ " + " of ▁ binary ▁ tree ▁ is ▁ " ) ; tree . printInorder ( ) ; Console . WriteLine ( " STRNEWLINE Postorder ▁ traversal ▁ " + " of ▁ binary ▁ tree ▁ is ▁ " ) ; tree . printPostorder ( ) ; } }
static int largest ( ) { int i ;
int max = arr [ 0 ] ;
for ( i = 1 ; i < arr . Length ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
public static void Main ( ) { Console . WriteLine ( " Largest ▁ in ▁ given ▁ " + " array ▁ is ▁ " + largest ( ) ) ; } }
static int largest ( int [ ] arr , int n ) { return arr . Max ( ) ; }
static public void Main ( ) { int [ ] arr = { 10 , 324 , 45 , 90 , 9808 } ; int n = arr . Length ; Console . WriteLine ( largest ( arr , n ) ) ; } }
using System ; class GFG { void find3largest ( int [ ] arr ) {
Array . Sort ( arr ) ;
int n = arr . Length ; int check = 0 , count = 1 ; for ( int i = 1 ; i <= n ; i ++ ) { if ( count < 4 ) { if ( check != arr [ n - i ] ) {
Console . Write ( arr [ n - i ] + " ▁ " ) ; check = arr [ n - i ] ; count ++ ; } } else break ; } }
public static void Main ( ) { GFG obj = new GFG ( ) ; int [ ] arr = { 12 , 45 , 1 , - 1 , 45 , 54 , 23 , 5 , 0 , - 10 } ; obj . find3largest ( arr ) ; } }
using System ; class GFG { static void findElements ( int [ ] arr , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) if ( arr [ j ] > arr [ i ] ) count ++ ; if ( count >= 2 ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void Main ( String [ ] args ) { int [ ] arr = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . Length ; findElements ( arr , n ) ; } }
using System ; class GFG { static void findElements ( int [ ] arr , int n ) { Array . Sort ( arr ) ; for ( int i = 0 ; i < n - 2 ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . Length ; findElements ( arr , n ) ; } }
using System ; class GFG { static void findElements ( int [ ] arr , int n ) { int first = int . MinValue ; int second = int . MaxValue ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) second = arr [ i ] ; } for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < second ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . Length ; findElements ( arr , n ) ; } }
public static double findMean ( int [ ] a , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += a [ i ] ; return ( double ) sum / ( double ) n ; }
public static double findMedian ( int [ ] a , int n ) {
Array . Sort ( a ) ;
if ( n % 2 != 0 ) return ( double ) a [ n / 2 ] ; return ( double ) ( a [ ( n - 1 ) / 2 ] + a [ n / 2 ] ) / 2.0 ; }
public static void Main ( ) { int [ ] a = { 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 } ; int n = a . Length ;
Console . Write ( " Mean ▁ = ▁ " + findMean ( a , n ) + " STRNEWLINE " ) ; Console . Write ( " Median ▁ = ▁ " + findMedian ( a , n ) + " STRNEWLINE " ) ; } }
public static void printSmall ( int [ ] arr , int n , int k ) {
for ( int i = k ; i < n ; ++ i ) {
int max_var = arr [ k - 1 ] ; int pos = k - 1 ; for ( int j = k - 2 ; j >= 0 ; j -- ) { if ( arr [ j ] > max_var ) { max_var = arr [ j ] ; pos = j ; } }
if ( max_var > arr [ i ] ) { int j = pos ; while ( j < k - 1 ) { arr [ j ] = arr [ j + 1 ] ; j ++ ; }
arr [ k - 1 ] = arr [ i ] ; } }
for ( int i = 0 ; i < k ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 } ; int n = 10 ; int k = 5 ; printSmall ( arr , n , k ) ; } }
static void kSmallestPair ( int [ ] arr1 , int n1 , int [ ] arr2 , int n2 , int k ) { if ( k > n1 * n2 ) { Console . Write ( " k ▁ pairs ▁ don ' t ▁ exist " ) ; return ; }
int [ ] index2 = new int [ n1 ] ; while ( k > 0 ) {
int min_sum = int . MaxValue ; int min_index = 0 ;
for ( int i1 = 0 ; i1 < n1 ; i1 ++ ) {
if ( index2 [ i1 ] < n2 && arr1 [ i1 ] + arr2 [ index2 [ i1 ] ] < min_sum ) {
min_index = i1 ;
min_sum = arr1 [ i1 ] + arr2 [ index2 [ i1 ] ] ; } } Console . Write ( " ( " + arr1 [ min_index ] + " , ▁ " + arr2 [ index2 [ min_index ] ] + " ) ▁ " ) ; index2 [ min_index ] ++ ; k -- ; } }
public static void Main ( String [ ] args ) { int [ ] arr1 = { 1 , 3 , 11 } ; int n1 = arr1 . Length ; int [ ] arr2 = { 2 , 4 , 8 } ; int n2 = arr2 . Length ; int k = 4 ; kSmallestPair ( arr1 , n1 , arr2 , n2 , k ) ; } }
static void print2largest ( int [ ] arr , int arr_size ) { int i ;
if ( arr_size < 2 ) { Console . Write ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
Array . Sort ( arr ) ;
for ( i = arr_size - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] != arr [ arr_size - 1 ] ) { Console . Write ( " The ▁ second ▁ largest ▁ " + " element ▁ is ▁ { 0 } STRNEWLINE " , arr [ i ] ) ; return ; } } Console . Write ( " There ▁ is ▁ no ▁ second ▁ " + " largest ▁ element STRNEWLINE " ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 12 , 35 , 1 , 10 , 34 , 1 } ; int n = arr . Length ; print2largest ( arr , n ) ; } }
public static int sumNodes ( int l ) {
int leafNodeCount = ( int ) Math . Pow ( 2 , l - 1 ) ;
List < List < int > > vec = new List < List < int > > ( ) ;
for ( int i = 1 ; i <= l ; i ++ ) { vec . Add ( new List < int > ( ) ) ; }
for ( int i = 1 ; i <= leafNodeCount ; i ++ ) { vec [ l - 1 ] . Add ( i ) ; }
for ( int i = l - 2 ; i >= 0 ; i -- ) { int k = 0 ;
while ( k < vec [ i + 1 ] . Count - 1 ) {
vec [ i ] . Add ( vec [ i + 1 ] [ k ] + vec [ i + 1 ] [ k + 1 ] ) ; k += 2 ; } } int sum = 0 ;
for ( int i = 0 ; i < l ; i ++ ) { for ( int j = 0 ; j < vec [ i ] . Count ; j ++ ) { sum += vec [ i ] [ j ] ; } } return sum ; }
public static void Main ( string [ ] args ) { int l = 3 ; Console . WriteLine ( sumNodes ( l ) ) ; } }
static void print2largest ( int [ ] arr , int arr_size ) { int i , second ;
if ( arr_size < 2 ) { Console . Write ( " ▁ Invalid ▁ Input ▁ " ) ; return ; } int largest = second = int . MinValue ;
for ( i = 0 ; i < arr_size ; i ++ ) { largest = Math . Max ( largest , arr [ i ] ) ; }
for ( i = 0 ; i < arr_size ; i ++ ) { if ( arr [ i ] != largest ) second = Math . Max ( second , arr [ i ] ) ; } if ( second == int . MinValue ) Console . Write ( " There ▁ is ▁ no ▁ second ▁ " + " largest ▁ element STRNEWLINE " ) ; else Console . Write ( " The ▁ second ▁ largest ▁ " + " element ▁ is ▁ { 0 } STRNEWLINE " , second ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 12 , 35 , 1 , 10 , 34 , 1 } ; int n = arr . Length ; print2largest ( arr , n ) ; } }
int findFirstMissing ( int [ ] arr , int start , int end , int first ) { if ( start < end ) { int mid = ( start + end ) / 2 ;
if ( arr [ mid ] != mid + first ) return findFirstMissing ( arr , start , mid , first ) ; else return findFirstMissing ( arr , mid + 1 , end , first ) ; } return start + first ; }
int findSmallestMissinginSortedArray ( int [ ] arr ) {
if ( arr [ 0 ] != 0 ) return 0 ;
if ( arr [ arr . Length - 1 ] == arr . Length - 1 ) return arr . Length ; int first = arr [ 0 ] ; return findFirstMissing ( arr , 0 , arr . Length - 1 , first ) ; }
static public void Main ( ) { GFG small = new GFG ( ) ; int [ ] arr = { 0 , 1 , 2 , 3 , 4 , 5 , 7 } ; int n = arr . Length ;
Console . WriteLine ( " First ▁ Missing ▁ element ▁ is ▁ : ▁ " + small . findSmallestMissinginSortedArray ( arr ) ) ; } }
static double sumNodes ( int l ) {
double leafNodeCount = Math . Pow ( 2 , l - 1 ) ; double sumLastLevel = 0 ;
sumLastLevel = ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ;
double sum = sumLastLevel * l ; return sum ; }
public static void Main ( ) { int l = 3 ; Console . Write ( sumNodes ( l ) ) ; } }
using System ; public class GFG { static int MAX = 500 ;
static int [ , ] lookup = new int [ MAX , MAX ] ;
static void buildSparseTable ( int [ ] arr , int n ) {
for ( int i = 0 ; i < n ; i ++ ) lookup [ i , 0 ] = arr [ i ] ;
for ( int j = 1 ; ( 1 << j ) <= n ; j ++ ) {
for ( int i = 0 ; ( i + ( 1 << j ) - 1 ) < n ; i ++ ) {
if ( lookup [ i , j - 1 ] < lookup [ i + ( 1 << ( j - 1 ) ) , j - 1 ] ) lookup [ i , j ] = lookup [ i , j - 1 ] ; else lookup [ i , j ] = lookup [ i + ( 1 << ( j - 1 ) ) , j - 1 ] ; } } }
static int query ( int L , int R ) {
int j = ( int ) Math . Log ( R - L + 1 ) ;
if ( lookup [ L , j ] <= lookup [ R - ( 1 << j ) + 1 , j ] ) return lookup [ L , j ] ; else return lookup [ R - ( 1 << j ) + 1 , j ] ; }
static public void Main ( ) { int [ ] a = { 7 , 2 , 3 , 0 , 5 , 10 , 3 , 12 , 18 } ; int n = a . Length ; buildSparseTable ( a , n ) ; Console . WriteLine ( query ( 0 , 4 ) ) ; Console . WriteLine ( query ( 4 , 7 ) ) ; Console . WriteLine ( query ( 7 , 8 ) ) ; } }
static void add ( int [ ] arr , int N , int lo , int hi , int val ) { arr [ lo ] += val ; if ( hi != N - 1 ) arr [ hi + 1 ] -= val ; }
static void updateArray ( int [ ] arr , int N ) {
for ( int i = 1 ; i < N ; i ++ ) arr [ i ] += arr [ i - 1 ] ; }
static void printArr ( int [ ] arr , int N ) { updateArray ( arr , N ) ; for ( int i = 0 ; i < N ; i ++ ) Console . Write ( " " + arr [ i ] + " ▁ " ) ; Console . Write ( " STRNEWLINE " ) ; }
public static void Main ( ) { int N = 6 ; int [ ] arr = new int [ N ] ;
add ( arr , N , 0 , 2 , 100 ) ; add ( arr , N , 1 , 5 , 100 ) ; add ( arr , N , 2 , 3 , 100 ) ; printArr ( arr , N ) ; } }
using System ; using System . Collections . Generic ; class GFG { static readonly int MAX = 1000 ;
static int [ ] tree = new int [ 4 * MAX ] ;
static int [ ] arr = new int [ MAX ] ;
static int gcd ( int a , int b ) { if ( a == 0 ) { return b ; } return gcd ( b % a , a ) ; }
static int lcm ( int a , int b ) { return a * b / gcd ( a , b ) ; }
static void build ( int node , int start , int end ) {
if ( start == end ) { tree [ node ] = arr [ start ] ; return ; } int mid = ( start + end ) / 2 ;
build ( 2 * node , start , mid ) ; build ( 2 * node + 1 , mid + 1 , end ) ;
int left_lcm = tree [ 2 * node ] ; int right_lcm = tree [ 2 * node + 1 ] ; tree [ node ] = lcm ( left_lcm , right_lcm ) ; }
static int query ( int node , int start , int end , int l , int r ) {
if ( end < l start > r ) { return 1 ; }
if ( l <= start && r >= end ) { return tree [ node ] ; }
int mid = ( start + end ) / 2 ; int left_lcm = query ( 2 * node , start , mid , l , r ) ; int right_lcm = query ( 2 * node + 1 , mid + 1 , end , l , r ) ; return lcm ( left_lcm , right_lcm ) ; }
arr [ 0 ] = 5 ; arr [ 1 ] = 7 ; arr [ 2 ] = 5 ; arr [ 3 ] = 2 ; arr [ 4 ] = 10 ; arr [ 5 ] = 12 ; arr [ 6 ] = 11 ; arr [ 7 ] = 17 ; arr [ 8 ] = 14 ; arr [ 9 ] = 1 ; arr [ 10 ] = 44 ;
build ( 1 , 0 , 10 ) ;
Console . WriteLine ( query ( 1 , 0 , 10 , 2 , 5 ) ) ;
Console . WriteLine ( query ( 1 , 0 , 10 , 5 , 10 ) ) ;
Console . WriteLine ( query ( 1 , 0 , 10 , 0 , 10 ) ) ; } }
static int GCD ( int a , int b ) { if ( b == 0 ) return a ; return GCD ( b , a % b ) ; }
static void FillPrefixSuffix ( int [ ] prefix , int [ ] arr , int [ ] suffix , int n ) {
prefix [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) prefix [ i ] = GCD ( prefix [ i - 1 ] , arr [ i ] ) ;
suffix [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) suffix [ i ] = GCD ( suffix [ i + 1 ] , arr [ i ] ) ; }
static int GCDoutsideRange ( int l , int r , int [ ] prefix , int [ ] suffix , int n ) {
if ( l == 0 ) return suffix [ r + 1 ] ;
if ( r == n - 1 ) return prefix [ l - 1 ] ; return GCD ( prefix [ l - 1 ] , suffix [ r + 1 ] ) ; }
public static void Main ( ) { int [ ] arr = { 2 , 6 , 9 } ; int n = arr . Length ; int [ ] prefix = new int [ n ] ; int [ ] suffix = new int [ n ] ; FillPrefixSuffix ( prefix , arr , suffix , n ) ; int l = 0 , r = 0 ; Console . WriteLine ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; l = 1 ; r = 1 ; Console . WriteLine ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; l = 1 ; r = 2 ; Console . Write ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; } }
static int countInRange ( int [ ] arr , int n , int x , int y ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] >= x && arr [ i ] <= y ) count ++ ; } return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 4 , 9 , 10 , 3 } ; int n = arr . Length ;
int i = 1 , j = 4 ; Console . WriteLine ( countInRange ( arr , n , i , j ) ) ; i = 9 ; j = 12 ; Console . WriteLine ( countInRange ( arr , n , i , j ) ) ; } }
static int lowerIndex ( int [ ] arr , int n , int x ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] >= x ) h = mid - 1 ; else l = mid + 1 ; } return l ; }
static int upperIndex ( int [ ] arr , int n , int y ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] <= y ) l = mid + 1 ; else h = mid - 1 ; } return h ; }
static int countInRange ( int [ ] arr , int n , int x , int y ) {
int count = 0 ; count = upperIndex ( arr , n , y ) - lowerIndex ( arr , n , x ) + 1 ; return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 4 , 4 , 9 , 10 , 3 } ; int n = arr . Length ;
Array . Sort ( arr ) ;
int i = 1 , j = 4 ; Console . WriteLine ( countInRange ( arr , n , i , j ) ) ; ; i = 9 ; j = 12 ; Console . WriteLine ( countInRange ( arr , n , i , j ) ) ; } }
static void precompute ( int [ ] arr , int n , int [ ] pre ) { for ( int i = 0 ; i < n ; i ++ ) pre [ i ] = 0 ; pre [ n - 1 ] = arr [ n - 1 ] * ( int ) ( Math . Pow ( 2 , 0 ) ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) pre [ i ] = pre [ i + 1 ] + arr [ i ] * ( 1 << ( n - 1 - i ) ) ; }
static int decimalOfSubarr ( int [ ] arr , int l , int r , int n , int [ ] pre ) {
if ( r != n - 1 ) return ( pre [ l ] - pre [ r + 1 ] ) / ( 1 << ( n - 1 - r ) ) ; return pre [ l ] / ( 1 << ( n - 1 - r ) ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 1 , 0 , 1 , 1 } ; int n = arr . Length ; int [ ] pre = new int [ n ] ; precompute ( arr , n , pre ) ; Console . WriteLine ( decimalOfSubarr ( arr , 2 , 4 , n , pre ) ) ; Console . WriteLine ( decimalOfSubarr ( arr , 4 , 5 , n , pre ) ) ; } }
static int answerQuery ( int [ ] a , int n , int l , int r ) {
int count = 0 ;
l = l - 1 ;
for ( int i = l ; i < r ; i ++ ) { int divisors = 0 ;
for ( int j = l ; j < r ; j ++ ) {
if ( a [ j ] % a [ i ] == 0 ) divisors ++ ; else break ; }
if ( divisors == ( r - l ) ) count ++ ; }
return count ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 3 , 5 } ; int n = a . Length ; int l = 1 , r = 4 ; Console . WriteLine ( answerQuery ( a , n , l , r ) ) ; l = 2 ; r = 4 ; Console . WriteLine ( answerQuery ( a , n , l , r ) ) ; } }
public class Node { public int data ; public Node left , right ; } ;
static Dictionary < int , int > grid = new Dictionary < int , int > ( ) ;
static void addConsideringGrid ( Node root , int level , int index ) {
if ( root == null ) return ;
if ( grid . ContainsKey ( level - index ) ) grid [ level - index ] = grid [ level - index ] + ( root . data ) ; else grid . Add ( level - index , root . data ) ;
addConsideringGrid ( root . left , level + 1 , index - 1 ) ;
addConsideringGrid ( root . right , level + 1 , index + 1 ) ; } static List < int > diagonalSum ( Node root ) { grid . Clear ( ) ;
addConsideringGrid ( root , 0 , 0 ) ; List < int > ans = new List < int > ( ) ;
foreach ( KeyValuePair < int , int > x in grid ) { ans . Add ( x . Value ) ; } return ans ; }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 9 ) ; root . left . right = newNode ( 6 ) ; root . right . left = newNode ( 4 ) ; root . right . right = newNode ( 5 ) ; root . right . left . right = newNode ( 7 ) ; root . right . left . left = newNode ( 12 ) ; root . left . right . left = newNode ( 11 ) ; root . left . left . right = newNode ( 10 ) ;
List < int > v = diagonalSum ( root ) ;
for ( int i = 0 ; i < v . Count ; i ++ ) Console . Write ( v [ i ] + " ▁ " ) ; } }
using System ; using System . Collections . Generic ; class GFG { static int MAX = 2147483647 ; static int [ , ] one = new int [ 100001 , 32 ] ;
static void make_prefix ( int [ ] A , int n ) { for ( int j = 0 ; j < 32 ; j ++ ) one [ 0 , j ] = 0 ;
for ( int i = 1 ; i <= n ; i ++ ) { int a = A [ i - 1 ] ; for ( int j = 0 ; j < 32 ; j ++ ) { int x = ( int ) Math . Pow ( 2 , j ) ;
if ( ( a & x ) != 0 ) one [ i , j ] = 1 + one [ i - 1 , j ] ; else one [ i , j ] = one [ i - 1 , j ] ; } } }
static int Solve ( int L , int R ) { int l = L , r = R ; int tot_bits = r - l + 1 ;
int X = MAX ;
for ( int i = 0 ; i < 31 ; i ++ ) {
int x = one [ r , i ] - one [ l - 1 , i ] ;
if ( x >= tot_bits - x ) { int ith_bit = ( int ) Math . Pow ( 2 , i ) ;
X = X ^ ith_bit ; } } return X ; }
public static void Main ( ) { int n = 5 , q = 3 ; int [ ] A = { 210 , 11 , 48 , 22 , 133 } ; int [ ] L = { 1 , 4 , 2 } ; int [ ] R = { 3 , 14 , 4 } ; make_prefix ( A , n ) ; for ( int j = 0 ; j < q ; j ++ ) Console . WriteLine ( Solve ( L [ j ] , R [ j ] ) ) ; } }
static void type1 ( int [ ] arr , int start , int limit ) {
for ( int i = start ; i <= limit ; i ++ ) arr [ i ] ++ ; }
static void type2 ( int [ ] arr , int [ , ] query , int start , int limit ) { for ( int i = start ; i <= limit ; i ++ ) {
if ( query [ i , 0 ] == 1 ) type1 ( arr , query [ i , 1 ] , query [ i , 2 ] ) ;
else if ( query [ i , 0 ] == 2 ) type2 ( arr , query , query [ i , 1 ] , query [ i , 2 ] ) ; } }
int n = 5 , m = 5 ; int [ ] arr = new int [ n + 1 ] ;
int [ ] temp = { 1 , 1 , 2 , 1 , 4 , 5 , 2 , 1 , 2 , 2 , 1 , 3 , 2 , 3 , 4 } ; int [ , ] query = new int [ 6 , 4 ] ; int j = 0 ; for ( int i = 1 ; i <= m ; i ++ ) { query [ i , 0 ] = temp [ j ++ ] ; query [ i , 1 ] = temp [ j ++ ] ; query [ i , 2 ] = temp [ j ++ ] ; }
for ( int i = 1 ; i <= m ; i ++ ) if ( query [ i , 0 ] == 1 ) type1 ( arr , query [ i , 1 ] , query [ i , 2 ] ) ; else if ( query [ i , 0 ] == 2 ) type2 ( arr , query , query [ i , 1 ] , query [ i , 2 ] ) ;
for ( int i = 1 ; i <= n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
static void record_sum ( int [ ] record , int l , int r , int n , int adder ) { for ( int i = l ; i <= r ; i ++ ) { record [ i ] += adder ; } }
public static void Main ( String [ ] args ) { int n = 5 , m = 5 ; int [ ] arr = new int [ n ] ;
int [ , ] query = { { 1 , 1 , 2 } , { 1 , 4 , 5 } , { 2 , 1 , 2 } , { 2 , 1 , 3 } , { 2 , 3 , 4 } } ; int [ ] record = new int [ m ] ; for ( int i = m - 1 ; i >= 0 ; i -- ) {
if ( query [ i , 0 ] == 2 ) { record_sum ( record , query [ i , 1 ] - 1 , query [ i , 2 ] - 1 , m , record [ i ] + 1 ) ; }
else { record_sum ( record , i , i , m , 1 ) ; } }
for ( int i = 0 ; i < m ; i ++ ) { if ( query [ i , 0 ] == 1 ) { record_sum ( arr , query [ i , 1 ] - 1 , query [ i , 2 ] - 1 , n , record [ i ] ) ; } }
for ( int i = 0 ; i < n ; i ++ ) { Console . Write ( arr [ i ] + " ▁ " ) ; } } }
public static int solveQuery ( int start , int end , int [ ] arr ) {
Dictionary < int , int > mp = new Dictionary < int , int > ( ) ;
for ( int i = start ; i <= end ; i ++ ) { if ( mp . ContainsKey ( arr [ i ] ) ) mp [ arr [ i ] ] ++ ; else mp . Add ( arr [ i ] , 1 ) ; }
int count = 0 ; foreach ( KeyValuePair < int , int > entry in mp ) { if ( entry . Key == entry . Value ) count ++ ; } return count ; }
public static void Main ( String [ ] args ) { int [ ] A = { 1 , 2 , 2 , 3 , 3 , 3 } ; int n = A . Length ;
int [ , ] queries = { { 0 , 1 } , { 1 , 1 } , { 0 , 2 } , { 1 , 3 } , { 3 , 5 } , { 0 , 5 } } ;
int q = queries . Length ; for ( int i = 0 ; i < q ; i ++ ) { int start = queries [ i , 0 ] ; int end = queries [ i , 1 ] ; Console . WriteLine ( " Answer ▁ for ▁ Query ▁ " + ( i + 1 ) + " ▁ = ▁ " + solveQuery ( start , end , A ) ) ; } } }
static int answer_query ( int [ ] a , int n , int l , int r ) {
int count = 0 ; for ( int i = l ; i < r ; i ++ ) if ( a [ i ] == a [ i + 1 ] ) count += 1 ; return count ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = a . Length ;
int L , R ; L = 1 ; R = 8 ; Console . WriteLine ( answer_query ( a , n , L , R ) ) ;
L = 0 ; R = 4 ; Console . WriteLine ( answer_query ( a , n , L , R ) ) ; } }
using System ; class GFG { static int N = 1000 ;
static int [ ] prefixans = new int [ N ] ;
static void countIndex ( int [ ] a , int n ) {
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( a [ i ] == a [ i + 1 ] ) prefixans [ i ] = 1 ; if ( i != 0 ) prefixans [ i ] += prefixans [ i - 1 ] ; } }
static int answer_query ( int l , int r ) { if ( l == 0 ) return prefixans [ r - 1 ] ; else return prefixans [ r - 1 ] - prefixans [ l - 1 ] ; }
static void Main ( ) { int [ ] a = new int [ ] { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = a . Length ;
countIndex ( a , n ) ; int L , R ;
L = 1 ; R = 8 ; Console . WriteLine ( answer_query ( L , R ) ) ;
L = 0 ; R = 4 ; Console . WriteLine ( answer_query ( L , R ) ) ; } }
static void initializeDiffArray ( int [ ] A , int [ ] D ) { int n = A . Length ;
D [ 0 ] = A [ 0 ] ; D [ n ] = 0 ; for ( int i = 1 ; i < n ; i ++ ) D [ i ] = A [ i ] - A [ i - 1 ] ; }
static void update ( int [ ] D , int l , int r , int x ) { D [ l ] += x ; D [ r + 1 ] -= x ; }
static int printArray ( int [ ] A , int [ ] D ) { for ( int i = 0 ; i < A . Length ; i ++ ) { if ( i == 0 ) A [ i ] = D [ i ] ;
else A [ i ] = D [ i ] + A [ i - 1 ] ; Console . Write ( A [ i ] + " ▁ " ) ; } Console . WriteLine ( ) ; return 0 ; }
int [ ] A = { 10 , 5 , 20 , 40 } ; int n = A . Length ;
int [ ] D = new int [ n + 1 ] ; initializeDiffArray ( A , D ) ;
update ( D , 0 , 1 , 10 ) ; printArray ( A , D ) ;
update ( D , 1 , 3 , 20 ) ; update ( D , 2 , 2 , 30 ) ; printArray ( A , D ) ; } }
using System ; class GFG { static int maxSubArraySum ( int [ ] a ) { int size = a . Length ; int max_so_far = int . MinValue , max_ending_here = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here = max_ending_here + a [ i ] ; if ( max_so_far < max_ending_here ) max_so_far = max_ending_here ; if ( max_ending_here < 0 ) max_ending_here = 0 ; } return max_so_far ; }
public static void Main ( ) { int [ ] a = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; Console . Write ( " Maximum ▁ contiguous ▁ sum ▁ is ▁ " + maxSubArraySum ( a ) ) ; } }
using System ; class GFG { static int maxSubArraySum ( int [ ] a , int size ) { int max_so_far = a [ 0 ] ; int curr_max = a [ 0 ] ; for ( int i = 1 ; i < size ; i ++ ) { curr_max = Math . Max ( a [ i ] , curr_max + a [ i ] ) ; max_so_far = Math . Max ( max_so_far , curr_max ) ; } return max_so_far ; }
public static void Main ( ) { int [ ] a = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; int n = a . Length ; Console . Write ( " Maximum ▁ contiguous ▁ sum ▁ is ▁ " + maxSubArraySum ( a , n ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static void Main ( ) { int [ ] price = { 2 , 30 , 15 , 10 , 8 , 25 , 80 } ;
int profit = 0 ;
for ( int i = 1 ; i < price . Length ; i ++ ) {
int sub = price [ i ] - price [ i - 1 ] ; if ( sub > 0 ) profit += sub ; } Console . WriteLine ( " Maximum ▁ Profit = " + profit ) ; } }
static void findMinAvgSubarray ( int n , int k ) {
if ( n < k ) return ;
int res_index = 0 ;
int curr_sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) curr_sum += arr [ i ] ;
int min_sum = curr_sum ;
for ( int i = k ; i < n ; i ++ ) {
curr_sum += arr [ i ] - arr [ i - k ] ;
if ( curr_sum < min_sum ) { min_sum = curr_sum ; res_index = ( i - k + 1 ) ; } } Console . Write ( " Subarray ▁ between ▁ [ " + res_index + " , ▁ " + ( res_index + k - 1 ) + " ] ▁ has ▁ minimum ▁ average " ) ; }
public static void Main ( ) {
int k = 3 ; findMinAvgSubarray ( arr . Length , k ) ; } }
public static int minJumps ( int [ ] arr , int n ) {
int [ ] jumps = new int [ n ] ; int min ;
jumps [ n - 1 ] = 0 ;
for ( int i = n - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] == 0 ) { jumps [ i ] = int . MaxValue ; }
else if ( arr [ i ] >= n - i - 1 ) { jumps [ i ] = 1 ; }
else {
min = int . MaxValue ;
for ( int j = i + 1 ; j < n && j <= arr [ i ] + i ; j ++ ) { if ( min > jumps [ j ] ) { min = jumps [ j ] ; } }
if ( min != int . MaxValue ) { jumps [ i ] = min + 1 ; } else {
jumps [ i ] = min ; } } } return jumps [ 0 ] ; }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 1 , 3 , 6 , 1 , 0 , 9 } ; int size = arr . Length ; Console . WriteLine ( " Minimum ▁ number ▁ of " + " ▁ jumps ▁ to ▁ reach ▁ end ▁ is ▁ " + minJumps ( arr , size ) ) ; } }
static int smallestSubWithSum ( int [ ] arr , int n , int x ) {
int min_len = n + 1 ;
for ( int start = 0 ; start < n ; start ++ ) {
int curr_sum = arr [ start ] ;
if ( curr_sum > x ) return 1 ;
for ( int end = start + 1 ; end < n ; end ++ ) {
curr_sum += arr [ end ] ;
if ( curr_sum > x && ( end - start + 1 ) < min_len ) min_len = ( end - start + 1 ) ; } } return min_len ; }
static public void Main ( ) { int [ ] arr1 = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = arr1 . Length ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; if ( res1 == n1 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res1 ) ; int [ ] arr2 = { 1 , 10 , 5 , 2 , 7 } ; int n2 = arr2 . Length ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; if ( res2 == n2 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res2 ) ; int [ ] arr3 = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = arr3 . Length ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; if ( res3 == n3 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res3 ) ; } }
static int smallestSubWithSum ( int [ ] arr , int n , int x ) {
int curr_sum = 0 , min_len = n + 1 ;
int start = 0 , end = 0 ; while ( end < n ) {
while ( curr_sum <= x && end < n ) curr_sum += arr [ end ++ ] ;
while ( curr_sum > x && start < n ) {
if ( end - start < min_len ) min_len = end - start ;
curr_sum -= arr [ start ++ ] ; } } return min_len ; }
static public void Main ( ) { int [ ] arr1 = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = arr1 . Length ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; if ( res1 == n1 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res1 ) ; int [ ] arr2 = { 1 , 10 , 5 , 2 , 7 } ; int n2 = arr2 . Length ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; if ( res2 == n2 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res2 ) ; int [ ] arr3 = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = arr3 . Length ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; if ( res3 == n3 + 1 ) Console . WriteLine ( " Not ▁ Possible " ) ; else Console . WriteLine ( res3 ) ; } }
static int findMaxAverage ( int [ ] arr , int n , int k ) {
if ( k > n ) return - 1 ;
int [ ] csum = new int [ n ] ; csum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) csum [ i ] = csum [ i - 1 ] + arr [ i ] ;
int max_sum = csum [ k - 1 ] , max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { int curr_sum = csum [ i ] - csum [ i - k ] ; if ( curr_sum > max_sum ) { max_sum = curr_sum ; max_end = i ; } }
return max_end - k + 1 ; }
static public void Main ( ) { int [ ] arr = { 1 , 12 , - 5 , - 6 , 50 , 3 } ; int k = 4 ; int n = arr . Length ; Console . WriteLine ( " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ " + " length ▁ " + k + " ▁ begins ▁ at ▁ index ▁ " + findMaxAverage ( arr , n , k ) ) ; } }
static int findMaxAverage ( int [ ] arr , int n , int k ) {
if ( k > n ) return - 1 ;
int sum = arr [ 0 ] ; for ( int i = 1 ; i < k ; i ++ ) sum += arr [ i ] ; int max_sum = sum ; int max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { sum = sum + arr [ i ] - arr [ i - k ] ; if ( sum > max_sum ) { max_sum = sum ; max_end = i ; } }
return max_end - k + 1 ; }
public static void Main ( ) { int [ ] arr = { 1 , 12 , - 5 , - 6 , 50 , 3 } ; int k = 4 ; int n = arr . Length ; Console . WriteLine ( " The ▁ maximum ▁ " + " average ▁ subarray ▁ of ▁ length ▁ " + k + " ▁ begins ▁ at ▁ index ▁ " + findMaxAverage ( arr , n , k ) ) ; } }
using System ; class GFG { static int [ ] arr = new int [ ] { 16 , 16 , 16 } ;
static int countMinOperations ( int n ) {
int result = 0 ;
while ( true ) {
int zero_count = 0 ;
int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] % 2 == 1 ) break ;
else if ( arr [ i ] == 0 ) ++ ; }
if ( zero_count == n ) return result ;
if ( i == n ) {
for ( int j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] / 2 ; result ++ ; }
for ( int j = i ; j < n ; j ++ ) { if ( arr [ j ] % 2 == 1 ) { arr [ j ] -- ; result ++ ; } } } }
public static void Main ( ) { Console . Write ( " Minimum ▁ number ▁ of ▁ steps ▁ required ▁ to ▁ STRNEWLINE " + " get ▁ the ▁ given ▁ target ▁ array ▁ is ▁ " + countMinOperations ( arr . Length ) ) ; } }
static int findMinOps ( int [ ] arr , int n ) {
int ans = 0 ;
for ( int i = 0 , j = n - 1 ; i <= j ; ) {
if ( arr [ i ] == arr [ j ] ) { i ++ ; j -- ; }
else if ( arr [ i ] > arr [ j ] ) {
j -- ; arr [ j ] += arr [ j + 1 ] ; ans ++ ; }
else { i ++ ; arr [ i ] += arr [ i - 1 ] ; ans ++ ; } } return ans ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 4 , 5 , 9 , 1 } ; Console . Write ( " Count ▁ of ▁ minimum ▁ operations ▁ is ▁ " + findMinOps ( arr , arr . Length ) ) ; } }
static int findSmallest ( int [ ] arr , int n ) {
int res = 1 ;
for ( int i = 0 ; i < n && arr [ i ] <= res ; i ++ ) res = res + arr [ i ] ; return res ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 3 , 4 , 5 } ; int n1 = arr1 . Length ; Console . WriteLine ( findSmallest ( arr1 , n1 ) ) ; int [ ] arr2 = { 1 , 2 , 6 , 10 , 11 , 15 } ; int n2 = arr2 . Length ; Console . WriteLine ( findSmallest ( arr2 , n2 ) ) ; int [ ] arr3 = { 1 , 1 , 1 , 1 } ; int n3 = arr3 . Length ; Console . WriteLine ( findSmallest ( arr3 , n3 ) ) ; int [ ] arr4 = { 1 , 1 , 3 , 4 } ; int n4 = arr4 . Length ; Console . WriteLine ( findSmallest ( arr4 , n4 ) ) ; } }
static int maxSubArraySum ( int [ ] a , int size ) { int max_so_far = int . MinValue , max_ending_here = 0 , start = 0 , end = 0 , s = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here += a [ i ] ; if ( max_so_far < max_ending_here ) { max_so_far = max_ending_here ; start = s ; end = i ; } if ( max_ending_here < 0 ) { max_ending_here = 0 ; s = i + 1 ; } } return ( end - start + 1 ) ; }
public static void Main ( String [ ] args ) { int [ ] a = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; int n = a . Length ; Console . Write ( maxSubArraySum ( a , n ) ) ; } }
static int findMinDiff ( int [ ] arr , int n ) {
int diff = int . MaxValue ;
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( Math . Abs ( ( arr [ i ] - arr [ j ] ) ) < diff ) diff = Math . Abs ( ( arr [ i ] - arr [ j ] ) ) ;
return diff ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 5 , 3 , 19 , 18 , 25 } ; Console . Write ( " Minimum ▁ difference ▁ is ▁ " + findMinDiff ( arr , arr . Length ) ) ; } }
static int findMinDiff ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
int diff = int . MaxValue ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i + 1 ] - arr [ i ] < diff ) diff = arr [ i + 1 ] - arr [ i ] ;
return diff ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 5 , 3 , 19 , 18 , 25 } ; Console . WriteLine ( " Minimum ▁ difference ▁ is ▁ " + findMinDiff ( arr , arr . Length ) ) ; } }
static public void Main ( ) { int a = 2 , b = 10 ; int size = Math . Abs ( b - a ) + 1 ; int [ ] array = new int [ size ] ;
for ( int i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) array [ i - a ] = 1 ; Console . WriteLine ( " MULTIPLES ▁ of ▁ 2" + " ▁ and ▁ 5 : " ) ; for ( int i = a ; i <= b ; i ++ ) if ( array [ i - a ] == 1 ) Console . Write ( i + " ▁ " ) ; } }
static bool checkbit ( int [ ] array , int index ) { int val = array [ index >> 5 ] & ( 1 << ( index & 31 ) ) ; if ( val == 0 ) return false ; return true ; }
static void setbit ( int [ ] array , int index ) { array [ index >> 5 ] |= ( 1 << ( index & 31 ) ) ; }
public static void Main ( String [ ] args ) { int a = 2 , b = 10 ; int size = Math . Abs ( b - a ) ;
size = ( int ) Math . Ceiling ( ( double ) size / 32 ) ;
int [ ] array = new int [ size ] ;
for ( int i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) setbit ( array , i - a ) ; Console . WriteLine ( " MULTIPLES ▁ of ▁ 2 ▁ and ▁ 5 : " ) ; for ( int i = a ; i <= b ; i ++ ) if ( checkbit ( array , i - a ) ) Console . Write ( i + " ▁ " ) ; } }
using System ; class GFG { static int [ ] arr1 = new int [ ] { 0 , 1 , 0 , 1 , 1 , 1 , 1 } ; static int [ ] arr2 = new int [ ] { 1 , 1 , 1 , 1 , 1 , 0 , 1 } ;
static int longestCommonSum ( int n ) {
int maxLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int sum1 = 0 , sum2 = 0 ;
for ( int j = i ; j < n ; j ++ ) {
sum1 += arr1 [ j ] ; sum2 += arr2 [ j ] ;
if ( sum1 == sum2 ) { int len = j - i + 1 ; if ( len > maxLen ) maxLen = len ; } } } return maxLen ; }
public static void Main ( ) { Console . Write ( " Length ▁ of ▁ the ▁ longest ▁ " + " common ▁ span ▁ with ▁ same ▁ sum ▁ is ▁ " ) ; Console . Write ( longestCommonSum ( arr1 . Length ) ) ; } }
void swap ( int [ ] arr , int a , int b ) { int temp = arr [ a ] ; arr [ a ] = arr [ b ] ; arr [ b ] = temp ; }
void sortInWave ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
for ( int i = 0 ; i < n - 1 ; i += 2 ) swap ( arr , i , i + 1 ) ; }
public static void Main ( ) { SortWave ob = new SortWave ( ) ; int [ ] arr = { 10 , 90 , 49 , 2 , 1 , 5 , 23 } ; int n = arr . Length ; ob . sortInWave ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
void swap ( int [ ] arr , int a , int b ) { int temp = arr [ a ] ; arr [ a ] = arr [ b ] ; arr [ b ] = temp ; }
void sortInWave ( int [ ] arr , int n ) {
for ( int i = 0 ; i < n ; i += 2 ) {
if ( i > 0 && arr [ i - 1 ] > arr [ i ] ) swap ( arr , i - 1 , i ) ;
if ( i < n - 1 && arr [ i ] < arr [ i + 1 ] ) swap ( arr , i , i + 1 ) ; } }
public static void Main ( ) { SortWave ob = new SortWave ( ) ; int [ ] arr = { 10 , 90 , 49 , 2 , 1 , 5 , 23 } ; int n = arr . Length ; ob . sortInWave ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static bool sortedAfterSwap ( int [ ] A , bool [ ] B , int n ) { int i , j ;
for ( i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] ) { j = i ; while ( B [ j ] ) { j ++ ; }
Array . Sort ( A , i , 1 + j ) ; i = j ; } }
for ( i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) { return false ; } } return true ; }
public static void Main ( ) { int [ ] A = { 1 , 2 , 5 , 3 , 4 , 6 } ; bool [ ] B = { false , true , true , true , false } ; int n = A . Length ; if ( sortedAfterSwap ( A , B , n ) ) { Console . WriteLine ( " A ▁ can ▁ be ▁ sorted " ) ; } else { Console . WriteLine ( " A ▁ can ▁ not ▁ be ▁ sorted " ) ; } } }
static int sortedAfterSwap ( int [ ] A , int [ ] B , int n ) { int t = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] != 0 ) { if ( A [ i ] != i + 1 ) t = A [ i ] ; A [ i ] = A [ i + 1 ] ; A [ i + 1 ] = t ; } }
for ( int i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) return 0 ; } return 1 ; }
public static void Main ( ) { int [ ] A = { 1 , 2 , 5 , 3 , 4 , 6 } ; int [ ] B = { 0 , 1 , 1 , 1 , 0 } ; int n = A . Length ; if ( sortedAfterSwap ( A , B , n ) == 0 ) Console . WriteLine ( " A ▁ can ▁ be ▁ sorted " ) ; else Console . WriteLine ( " A ▁ can ▁ not ▁ be ▁ sorted " ) ; } }
using System ; class GFG { static void segregate0and1 ( int [ ] arr , int n ) {
int type0 = 0 ; int type1 = n - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type0 ] = arr [ type0 ] + arr [ type1 ] ; arr [ type1 ] = arr [ type0 ] - arr [ type1 ] ; arr [ type0 ] = arr [ type0 ] - arr [ type1 ] ; type1 -- ; } else { type0 ++ ; } } }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 } ; segregate0and1 ( arr , arr . Length ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static void findMinSum ( int [ ] arr , int n ) { for ( int i = 1 ; i < n ; i ++ ) { if ( ! ( Math . Abs ( arr [ i - 1 ] ) < Math . Abs ( arr [ i ] ) ) ) { int temp = arr [ i - 1 ] ; arr [ i - 1 ] = arr [ i ] ; arr [ i ] = temp ; } } int min = Int32 . MaxValue ; int x = 0 , y = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( Math . Abs ( arr [ i - 1 ] + arr [ i ] ) <= min ) {
min = Math . Abs ( arr [ i - 1 ] + arr [ i ] ) ; x = i - 1 ; y = i ; } } Console . WriteLine ( " The ▁ two ▁ elements ▁ whose ▁ " + " sum ▁ is ▁ minimum ▁ are ▁ " + arr [ x ] + " ▁ and ▁ " + arr [ y ] ) ; }
static void Main ( ) { int [ ] arr = { 1 , 60 , - 10 , 70 , - 80 , 85 } ; int n = arr . Length ; findMinSum ( arr , n ) ; } }
public static bool increasing ( int [ ] a , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( a [ i ] >= a [ i + 1 ] ) return false ; return true ; }
public static bool decreasing ( int [ ] arr , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] < arr [ i + 1 ] ) return false ; return true ; } public static int shortestUnsorted ( int [ ] a , int n ) {
if ( increasing ( a , n ) == true || decreasing ( a , n ) == true ) return 0 ; else return 3 ; }
public static void Main ( ) { int [ ] ar = new int [ ] { 7 , 9 , 10 , 8 , 11 } ; int n = ar . Length ; Console . WriteLine ( shortestUnsorted ( ar , n ) ) ; } }
static void swap ( int [ ] arr , int i , int j ) { int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; }
static int indexOf ( int [ ] arr , int ele ) { for ( int i = 0 ; i < arr . Length ; i ++ ) { if ( arr [ i ] == ele ) { return i ; } } return - 1 ; }
static int minSwaps ( int [ ] arr , int N ) { int ans = 0 ; int [ ] temp = new int [ N ] ; Array . Copy ( arr , temp , N ) ; Array . Sort ( temp ) ; for ( int i = 0 ; i < N ; i ++ ) {
if ( arr [ i ] != temp [ i ] ) { ans ++ ;
swap ( arr , i , indexOf ( arr , temp [ i ] ) ) ; } } return ans ; }
static public void Main ( ) { int [ ] a = { 101 , 758 , 315 , 730 , 472 , 619 , 460 , 479 } ; int n = a . Length ;
Console . WriteLine ( minSwaps ( a , n ) ) ; } }
static void printUnion ( int [ ] arr1 , int [ ] arr2 , int m , int n ) {
if ( m > n ) { int [ ] tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
Array . Sort ( arr1 ) ; for ( int i = 0 ; i < m ; i ++ ) Console . Write ( arr1 [ i ] + " ▁ " ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) == - 1 ) Console . Write ( arr2 [ i ] + " ▁ " ) ; } }
static void printIntersection ( int [ ] arr1 , int [ ] arr2 , int m , int n ) {
if ( m > n ) { int [ ] tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
Array . Sort ( arr1 ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) != - 1 ) Console . Write ( arr2 [ i ] + " ▁ " ) ; } }
static int binarySearch ( int [ ] arr , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
static public void Main ( ) { int [ ] arr1 = { 7 , 1 , 5 , 2 , 3 , 6 } ; int [ ] arr2 = { 3 , 8 , 6 , 20 , 7 } ; int m = arr1 . Length ; int n = arr2 . Length ;
Console . WriteLine ( " Union ▁ of ▁ two ▁ arrays ▁ is ▁ " ) ; printUnion ( arr1 , arr2 , m , n ) ; Console . WriteLine ( " " ) ; Console . WriteLine ( " Intersection ▁ of ▁ two ▁ arrays ▁ is ▁ " ) ; printIntersection ( arr1 , arr2 , m , n ) ; } }
static void intersection ( int [ ] a , int [ ] b , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) { if ( a [ i ] > b [ j ] ) { j ++ ; } else if ( b [ j ] > a [ i ] ) { i ++ ; } else {
Console . Write ( a [ i ] + " ▁ " ) ; i ++ ; j ++ ; } } }
public static void Main ( ) { int [ ] a = { 1 , 3 , 2 , 3 , 4 , 5 , 5 , 6 } ; int [ ] b = { 3 , 3 , 5 } ; int n = a . Length ; int m = b . Length ;
Array . Sort ( a ) ; Array . Sort ( b ) ;
intersection ( a , b , n , m ) ; } }
static void printArr ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
static void sortArr ( int [ ] arr , int n ) { int i , cnt0 = 0 , cnt1 = 0 , cnt2 = 0 ;
for ( i = 0 ; i < n ; i ++ ) { switch ( arr [ i ] ) { case 0 : cnt0 ++ ; break ; case 1 : cnt1 ++ ; break ; case 2 : cnt2 ++ ; break ; } }
i = 0 ;
while ( cnt0 > 0 ) { arr [ i ++ ] = 0 ; cnt0 -- ; }
while ( cnt1 > 0 ) { arr [ i ++ ] = 1 ; cnt1 -- ; }
while ( cnt2 > 0 ) { arr [ i ++ ] = 2 ; cnt2 -- ; }
printArr ( arr , n ) ; }
public static void Main ( ) { int [ ] arr = { 0 , 1 , 1 , 0 , 1 , 2 , 1 , 2 , 0 , 0 , 0 , 1 } ; int n = arr . Length ; sortArr ( arr , n ) ; } }
static int findNumberOfTriangles ( int [ ] arr , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
for ( int k = j + 1 ; k < n ; k ++ )
if ( arr [ i ] + arr [ j ] > arr [ k ] && arr [ i ] + arr [ k ] > arr [ j ] && arr [ k ] + arr [ j ] > arr [ i ] ) count ++ ; } } return count ; }
static public void Main ( ) { int [ ] arr = { 10 , 21 , 22 , 100 , 101 , 200 , 300 } ; int size = arr . Length ; Console . WriteLine ( " Total ▁ number ▁ of ▁ triangles ▁ possible ▁ is ▁ " + findNumberOfTriangles ( arr , size ) ) ; } }
static void CountTriangles ( int [ ] A ) { int n = A . Length ; Array . Sort ( A ) ; int count = 0 ; for ( int i = n - 1 ; i >= 1 ; i -- ) { int l = 0 , r = i - 1 ; while ( l < r ) { if ( A [ l ] + A [ r ] > A [ i ] ) {
count += r - l ;
r -- ; }
else { l ++ ; } } } Console . Write ( " No ▁ of ▁ possible ▁ solutions : ▁ " + count ) ; }
public static void Main ( String [ ] args ) { int [ ] A = { 4 , 3 , 5 , 7 , 6 } ; CountTriangles ( A ) ; } }
public static int countPairsBruteForce ( int [ ] X , int [ ] Y , int m , int n ) { int ans = 0 ; for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( Math . Pow ( X [ i ] , Y [ j ] ) > Math . Pow ( Y [ j ] , X [ i ] ) ) ans ++ ; return ans ; }
using System ; class GFG { static int countPairsWithDiffK ( int [ ] arr , int n , int k ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] - arr [ j ] == k arr [ j ] - arr [ i ] == k ) count ++ ; } return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . Length ; int k = 3 ; Console . WriteLine ( " Count ▁ of ▁ pairs ▁ with ▁ " + " ▁ given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static int binarySearch ( int [ ] arr , int low , int high , int x ) { if ( high >= low ) { int mid = low + ( high - low ) / 2 ; if ( x == arr [ mid ] ) return mid ; if ( x > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
static int countPairsWithDiffK ( int [ ] arr , int n , int k ) { int count = 0 , i ;
Array . Sort ( arr ) ;
for ( i = 0 ; i < n - 1 ; i ++ ) if ( binarySearch ( arr , i + 1 , n - 1 , arr [ i ] + k ) != - 1 ) count ++ ; return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . Length ; int k = 3 ; Console . WriteLine ( " Count ▁ of ▁ pairs ▁ with " + " ▁ given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static int countPairsWithDiffK ( int [ ] arr , int n , int k ) { int count = 0 ;
Array . Sort ( arr ) ; int l = 0 ; int r = 0 ; while ( r < n ) { if ( arr [ r ] - arr [ l ] == k ) { count ++ ; l ++ ; r ++ ; } else if ( arr [ r ] - arr [ l ] > k ) l ++ ;
else r ++ ; } return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . Length ; int k = 3 ; Console . Write ( " Count ▁ of ▁ pairs ▁ with ▁ " + " given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } }
public static int getSumAlternate ( Node root ) { if ( root == null ) return 0 ; int sum = root . data ; if ( root . left != null ) { sum += getSum ( root . left . left ) ; sum += getSum ( root . left . right ) ; } if ( root . right != null ) { sum += getSum ( root . right . left ) ; sum += getSum ( root . right . right ) ; } return sum ; }
public static int getSum ( Node root ) { if ( root == null ) return 0 ;
return Math . Max ( getSumAlternate ( root ) , ( getSumAlternate ( root . left ) + getSumAlternate ( root . right ) ) ) ; }
public static void Main ( ) { Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . right . left = new Node ( 4 ) ; root . right . left . right = new Node ( 5 ) ; root . right . left . right . left = new Node ( 6 ) ; Console . WriteLine ( getSum ( root ) ) ; } }
static void constructArr ( int [ ] arr , int [ ] pair , int n ) { arr [ 0 ] = ( pair [ 0 ] + pair [ 1 ] - pair [ n - 1 ] ) / 2 ; for ( int i = 1 ; i < n ; i ++ ) arr [ i ] = pair [ i - 1 ] - arr [ 0 ] ; }
public static void Main ( ) { int [ ] pair = { 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 } ; int n = 5 ; int [ ] arr = new int [ n ] ; constructArr ( arr , pair , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public class Test { static int [ ] arr1 = new int [ ] { 1 , 5 , 9 , 10 , 15 , 20 } ; static int [ ] arr2 = new int [ ] { 2 , 3 , 8 , 13 } ; static void merge ( int m , int n ) {
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int j , last = arr1 [ m - 1 ] ; for ( j = m - 2 ; j >= 0 && arr1 [ j ] > arr2 [ i ] ; j -- ) arr1 [ j + 1 ] = arr1 [ j ] ;
if ( j != m - 2 last > arr2 [ i ] ) { arr1 [ j + 1 ] = arr2 [ i ] ; arr2 [ i ] = last ; } } }
public static void Main ( ) { merge ( arr1 . Length , arr2 . Length ) ; Console . Write ( " After ▁ Merging ▁ STRNEWLINE First ▁ Array : ▁ " ) ; for ( int i = 0 ; i < arr1 . Length ; i ++ ) { Console . Write ( arr1 [ i ] + " ▁ " ) ; } Console . Write ( " STRNEWLINE Second ▁ Array : ▁ " ) ; for ( int i = 0 ; i < arr2 . Length ; i ++ ) { Console . Write ( arr2 [ i ] + " ▁ " ) ; } } }
public static int minMaxProduct ( int [ ] arr1 , int [ ] arr2 , int n1 , int n2 ) {
Array . Sort ( arr1 ) ; Array . Sort ( arr2 ) ;
return arr1 [ n1 - 1 ] * arr2 [ 0 ] ; }
public static void Main ( ) { int [ ] arr1 = new int [ ] { 10 , 2 , 3 , 6 , 4 , 1 } ; int [ ] arr2 = new int [ ] { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = 6 ; int n2 = 6 ; Console . WriteLine ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ; } }
public static int minMaxProduct ( int [ ] arr1 , int [ ] arr2 , int n1 , int n2 ) {
int max = arr1 [ 0 ] ;
int min = arr2 [ 0 ] ; int i ; for ( i = 1 ; i < n1 && i < n2 ; ++ i ) {
if ( arr1 [ i ] > max ) max = arr1 [ i ] ;
if ( arr2 [ i ] < min ) min = arr2 [ i ] ; }
while ( i < n1 ) { if ( arr1 [ i ] > max ) max = arr1 [ i ] ; i ++ ; } while ( i < n2 ) { if ( arr2 [ i ] < min ) min = arr2 [ i ] ; i ++ ; } return max * min ; }
public static void Main ( ) { int [ ] arr1 = new int [ ] { 10 , 2 , 3 , 6 , 4 , 1 } ; int [ ] arr2 = new int [ ] { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = 6 ; int n2 = 6 ; Console . WriteLine ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ; } }
static int insertSorted ( int [ ] arr , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; arr [ n ] = key ; return ( n + 1 ) ; }
public static void Main ( ) { int [ ] arr = new int [ 20 ] ; arr [ 0 ] = 12 ; arr [ 1 ] = 16 ; arr [ 2 ] = 20 ; arr [ 3 ] = 40 ; arr [ 4 ] = 50 ; arr [ 5 ] = 70 ; int capacity = 20 ; int n = 6 ; int i , key = 26 ; Console . Write ( " Before ▁ Insertion : ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ;
n = insertSorted ( arr , n , key , capacity ) ; Console . Write ( " After ▁ Insertion : ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static int findElement ( int [ ] arr , int n , int key ) { int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
static int deleteElement ( int [ ] arr , int n , int key ) {
int pos = findElement ( arr , n , key ) ; if ( pos == - 1 ) { Console . WriteLine ( " Element ▁ not ▁ found " ) ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
public static void Main ( ) { int i ; int [ ] arr = { 10 , 50 , 30 , 40 , 20 } ; int n = arr . Length ; int key = 30 ; Console . Write ( " Array ▁ before ▁ deletion ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; n = deleteElement ( arr , n , key ) ; Console . Write ( " Array ▁ after ▁ deletion ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static void findCommon ( int [ ] ar1 , int [ ] ar2 , int [ ] ar3 ) {
int i = 0 , j = 0 , k = 0 ;
while ( i < ar1 . Length && j < ar2 . Length && k < ar3 . Length ) {
if ( ar1 [ i ] == ar2 [ j ] && ar2 [ j ] == ar3 [ k ] ) { Console . Write ( ar1 [ i ] + " ▁ " ) ; i ++ ; j ++ ; k ++ ; }
else if ( ar1 [ i ] < ar2 [ j ] ) ++ ;
else if ( ar2 [ j ] < ar3 [ k ] ) ++ ;
else k ++ ; } }
public static void Main ( ) { int [ ] ar1 = { 1 , 5 , 10 , 20 , 40 , 80 } ; int [ ] ar2 = { 6 , 7 , 20 , 80 , 100 } ; int [ ] ar3 = { 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 } ; Console . Write ( " Common ▁ elements ▁ are ▁ " ) ; findCommon ( ar1 , ar2 , ar3 ) ; } }
static int binarySearch ( int [ ] arr , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ; if ( arr [ mid ] == x ) return mid ; if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ; return binarySearch ( arr , mid + 1 , r , x ) ; } return - 1 ; }
static int findPos ( int [ ] arr , int key ) { int l = 0 , h = 1 ; int val = arr [ 0 ] ;
while ( val < key ) {
l = h ;
h = 2 * h ;
val = arr [ h ] ; }
return binarySearch ( arr , l , h , key ) ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 } ; int ans = findPos ( arr , 10 ) ; if ( ans == - 1 ) Console . Write ( " Element ▁ not ▁ found " ) ; else Console . Write ( " Element ▁ found ▁ at ▁ " + " index ▁ " + ans ) ; } }
static int findSingle ( int [ ] ar , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
public static void Main ( ) { int [ ] ar = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = ar . Length ; Console . Write ( " Element ▁ occurring ▁ once ▁ is ▁ " + findSingle ( ar , n ) + " ▁ " ) ; } }
static int singleNumber ( int [ ] nums , int n ) { Dictionary < int , int > m = new Dictionary < int , int > ( ) ; long sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( ! m . ContainsKey ( nums [ i ] ) ) { sum1 += nums [ i ] ; m . Add ( nums [ i ] , 1 ) ; } sum2 += nums [ i ] ; }
return ( int ) ( 2 * ( sum1 ) - sum2 ) ; }
public static void Main ( String [ ] args ) { int [ ] a = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = 7 ; Console . WriteLine ( singleNumber ( a , n ) ) ; int [ ] b = { 15 , 18 , 16 , 18 , 16 , 15 , 89 } ; Console . WriteLine ( singleNumber ( b , n ) ) ; } }
static bool isPresent ( int [ ] B , int m , int x ) { for ( int i = 0 ; i < m ; i ++ ) if ( B [ i ] == x ) return true ; return false ; }
static int findMaxSubarraySumUtil ( int [ ] A , int [ ] B , int n , int m ) {
int max_so_far = - 2147483648 , curr_max = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( isPresent ( B , m , A [ i ] ) ) { curr_max = 0 ; continue ; }
curr_max = Math . Max ( A [ i ] , curr_max + A [ i ] ) ; max_so_far = Math . Max ( max_so_far , curr_max ) ; } return max_so_far ; }
static void findMaxSubarraySum ( int [ ] A , int [ ] B , int n , int m ) { int maxSubarraySum = findMaxSubarraySumUtil ( A , B , n , m ) ;
if ( maxSubarraySum == - 2147483648 ) { Console . Write ( " Maximum ▁ Subarray ▁ Sum " + " ▁ " + " can ' t ▁ be ▁ found " ) ; } else { Console . Write ( " The ▁ Maximum ▁ Subarray ▁ Sum ▁ = ▁ " + maxSubarraySum ) ; } }
static public void Main ( ) { int [ ] A = { 3 , 4 , 5 , - 4 , 6 } ; int [ ] B = { 1 , 8 , 5 } ; int n = A . Length ; int m = B . Length ;
findMaxSubarraySum ( A , B , n , m ) ; } }
static int findMaxSum ( int [ ] arr , int n ) { int res = int . MinValue ; for ( int i = 0 ; i < n ; i ++ ) { int prefix_sum = arr [ i ] ; for ( int j = 0 ; j < i ; j ++ ) prefix_sum += arr [ j ] ; int suffix_sum = arr [ i ] ; for ( int j = n - 1 ; j > i ; j -- ) suffix_sum += arr [ j ] ; if ( prefix_sum == suffix_sum ) res = Math . Max ( res , prefix_sum ) ; } return res ; }
public static void Main ( ) { int [ ] arr = { - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( findMaxSum ( arr , n ) ) ; } }
public class Node { public int data ; public Node left ; public Node right ; }
static int getHeight ( Node Node ) { if ( Node == null ) return 0 ; else {
int lHeight = getHeight ( Node . left ) ; int rHeight = getHeight ( Node . right ) ;
if ( lHeight > rHeight ) return ( lHeight + 1 ) ; else return ( rHeight + 1 ) ; } }
static int getTotalHeight ( Node root ) { if ( root == null ) return 0 ; return getTotalHeight ( root . left ) + getHeight ( root ) + getTotalHeight ( root . right ) ; }
public static void Main ( String [ ] args ) { Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; Console . Write ( " Sum ▁ of ▁ heights ▁ of ▁ all ▁ Nodes ▁ = ▁ " + getTotalHeight ( root ) ) ; } }
static int findMaxSum ( int [ ] arr , int n ) {
int [ ] preSum = new int [ n ] ;
int [ ] suffSum = new int [ n ] ;
int ans = int . MinValue ;
preSum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) preSum [ i ] = preSum [ i - 1 ] + arr [ i ] ;
suffSum [ n - 1 ] = arr [ n - 1 ] ; if ( preSum [ n - 1 ] == suffSum [ n - 1 ] ) ans = Math . Max ( ans , preSum [ n - 1 ] ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) { suffSum [ i ] = suffSum [ i + 1 ] + arr [ i ] ; if ( suffSum [ i ] == preSum [ i ] ) ans = Math . Max ( ans , preSum [ i ] ) ; } return ans ; }
static public void Main ( ) { int [ ] arr = { - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( findMaxSum ( arr , n ) ) ; } }
using System ; class GFG { static int equilibrium ( int [ ] a , int n ) { if ( n == 1 ) return ( 0 ) ; int [ ] front = new int [ n ] ; int [ ] back = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) { if ( i != 0 ) { front [ i ] = front [ i - 1 ] + a [ i ] ; } else { front [ i ] = a [ i ] ; } }
for ( int i = n - 1 ; i > 0 ; i -- ) { if ( i <= n - 2 ) { back [ i ] = back [ i + 1 ] + a [ i ] ; } else { back [ i ] = a [ i ] ; } }
for ( int i = 0 ; i < n ; i ++ ) { if ( front [ i ] == back [ i ] ) { return i ; } }
return - 1 ; }
public static void Main ( string [ ] args ) { int [ ] arr = { - 7 , 1 , 5 , 2 , - 4 , 3 , 0 } ; int arr_size = arr . Length ; Console . WriteLine ( " First ▁ Point ▁ of ▁ equilibrium ▁ " + " is ▁ at ▁ index ▁ " + equilibrium ( arr , arr_size ) ) ; } }
using System ; class GFG { void printLeaders ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) { int j ; for ( j = i + 1 ; j < size ; j ++ ) { if ( arr [ i ] <= arr [ j ] ) break ; }
if ( j == size ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void Main ( ) { GFG lead = new GFG ( ) ; int [ ] arr = new int [ ] { 16 , 17 , 4 , 3 , 5 , 2 } ; int n = arr . Length ; lead . printLeaders ( arr , n ) ; } }
static void findMajority ( int [ ] arr , int n ) { int maxCount = 0 ;
int index = - 1 ; for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; }
if ( count > maxCount ) { maxCount = count ; index = i ; } }
if ( maxCount > n / 2 ) Console . WriteLine ( arr [ index ] ) ; else Console . WriteLine ( " No ▁ Majority ▁ Element " ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 1 , 2 , 1 , 3 , 5 , 1 } ; int n = arr . Length ;
findMajority ( arr , n ) ; } }
class Node { public int data ; public Node left ; public Node right ; } ; static int ;
static int getTotalHeightUtil ( Node root ) { if ( root == null ) { return 0 ; } int lh = getTotalHeightUtil ( root . left ) ; int rh = getTotalHeightUtil ( root . right ) ; int h = Math . Max ( lh , rh ) + 1 ; sum = sum + h ; return h ; } static int getTotalHeight ( Node root ) { sum = 0 ; getTotalHeightUtil ( root ) ; return sum ; }
public static void Main ( String [ ] args ) { Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; Console . Write ( " Sum ▁ of ▁ heights ▁ of ▁ all ▁ Nodes ▁ = ▁ { 0 } " , getTotalHeight ( root ) ) ; } }
public static int majorityElement ( int [ ] arr , int n ) {
Array . Sort ( arr ) ; int count = 1 , max_ele = - 1 , temp = arr [ 0 ] , ele = 0 , f = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( temp == arr [ i ] ) { count ++ ; } else { count = 1 ; temp = arr [ i ] ; }
if ( max_ele < count ) { max_ele = count ; ele = arr [ i ] ; if ( max_ele > ( n / 2 ) ) { f = 1 ; break ; } } }
return ( f == 1 ? ele : - 1 ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 1 , 2 , 1 , 3 , 5 , 1 } ; int n = 7 ;
Console . WriteLine ( majorityElement ( arr , n ) ) ; } }
static int _binarySearch ( int [ ] arr , int low , int high , int x ) { if ( high >= low ) { int mid = ( low + high ) / 2 ;
if ( ( mid == 0 x > arr [ mid - 1 ] ) && ( arr [ mid ] == x ) ) return mid ; else if ( x > arr [ mid ] ) return _binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return _binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
static bool isMajority ( int [ ] arr , int n , int x ) {
int i = _binarySearch ( arr , 0 , n - 1 , x ) ;
if ( i == - 1 ) return false ;
if ( ( ( i + n / 2 ) <= ( n - 1 ) ) && arr [ i + n / 2 ] == x ) return true ; else return false ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = arr . Length ; int x = 3 ; if ( isMajority ( arr , n , x ) == true ) Console . Write ( x + " ▁ appears ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; else Console . Write ( x + " ▁ does ▁ not ▁ appear ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; } }
using System ; class GFG { static bool isMajorityElement ( int [ ] arr , int n , int key ) { if ( arr [ n / 2 ] == key ) return true ; else return false ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = arr . Length ; int x = 3 ; if ( isMajorityElement ( arr , n , x ) ) Console . Write ( x + " ▁ appears ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ [ ] arr " ) ; else Console . Write ( x + " ▁ does ▁ not ▁ appear ▁ more ▁ " + " than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; } }
static int findPeak ( int [ ] arr , int n ) {
if ( n == 1 ) return 0 ; if ( arr [ 0 ] >= arr [ 1 ] ) return 0 ; if ( arr [ n - 1 ] >= arr [ n - 2 ] ) return n - 1 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
if ( arr [ i ] >= arr [ i - 1 ] && arr [ i ] >= arr [ i + 1 ] ) return i ; } return 0 ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 3 , 20 , 4 , 1 , 0 } ; int n = arr . Length ; Console . Write ( " Index ▁ of ▁ a ▁ peak ▁ point ▁ is ▁ " + findPeak ( arr , n ) ) ; } }
using System ; class GFG { static int maxTripletSum ( int [ ] arr , int n ) {
int sum = - 1000000 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( sum < arr [ i ] + arr [ j ] + arr [ k ] ) sum = arr [ i ] + arr [ j ] + arr [ k ] ; return sum ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( maxTripletSum ( arr , n ) ) ; } }
static int maxTripletSum ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
return arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( maxTripletSum ( arr , n ) ) ; } }
static int maxTripletSum ( int [ ] arr , int n ) {
int maxA = - 100000000 , maxB = - 100000000 ; int maxC = - 100000000 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > maxA ) { maxC = maxB ; maxB = maxA ; maxA = arr [ i ] ; }
else if ( arr [ i ] > maxB ) { maxC = maxB ; maxB = arr [ i ] ; }
else if ( arr [ i ] > maxC ) maxC = arr [ i ] ; } return ( maxA + maxB + maxC ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( maxTripletSum ( arr , n ) ) ; } }
static int maximum ( int a , int b , int c ) { return Math . Max ( Math . Max ( a , b ) , c ) ; }
static int minimum ( int a , int b , int c ) { return Math . Min ( Math . Min ( a , b ) , c ) ; }
static void smallestDifferenceTriplet ( int [ ] arr1 , int [ ] arr2 , int [ ] arr3 , int n ) {
Array . Sort ( arr1 ) ; Array . Sort ( arr2 ) ; Array . Sort ( arr3 ) ;
int res_min = 0 , res_max = 0 , res_mid = 0 ;
int i = 0 , j = 0 , k = 0 ;
int diff = 2147483647 ; while ( i < n && j < n && k < n ) { int sum = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
int max = maximum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ;
int min = minimum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ; if ( min == arr1 [ i ] ) i ++ ; else if ( min == arr2 [ j ] ) j ++ ; else k ++ ;
if ( diff > ( max - min ) ) { diff = max - min ; res_max = max ; res_mid = sum - ( max + min ) ; res_min = min ; } }
Console . WriteLine ( res_max + " , ▁ " + res_mid + " , ▁ " + res_min ) ; }
static public void Main ( ) { int [ ] arr1 = { 5 , 2 , 8 } ; int [ ] arr2 = { 10 , 7 , 12 } ; int [ ] arr3 = { 9 , 14 , 6 } ; int n = arr1 . Length ; smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) ; } }
bool find3Numbers ( int [ ] A , int arr_size , int sum ) { int l , r ;
quickSort ( A , 0 , arr_size - 1 ) ;
for ( int i = 0 ; i < arr_size - 2 ; i ++ ) {
l = i + 1 ;
r = arr_size - 1 ; while ( l < r ) { if ( A [ i ] + A [ l ] + A [ r ] == sum ) { Console . Write ( " Triplet ▁ is ▁ " + A [ i ] + " , ▁ " + A [ l ] + " , ▁ " + A [ r ] ) ; return true ; } else if ( A [ i ] + A [ l ] + A [ r ] < sum ) l ++ ;
else r -- ; } }
return false ; }
static void Main ( ) { GFG triplet = new GFG ( ) ; int [ ] A = new int [ ] { 1 , 4 , 45 , 6 , 10 , 8 } ; int sum = 22 ; int arr_size = A . Length ; triplet . find3Numbers ( A , arr_size , sum ) ; } }
using System ; class GFG { static int SIZE = 10 ;
static void sortMat ( int [ , ] mat , int n ) {
int [ ] temp = new int [ n * n ] ; int k = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) temp [ k ++ ] = mat [ i , j ] ;
Array . Sort ( temp ) ;
k = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) mat [ i , j ] = temp [ k ++ ] ; }
static void printMat ( int [ , ] mat , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) Console . Write ( mat [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] mat = { { 5 , 4 , 7 } , { 1 , 3 , 8 } , { 2 , 9 , 6 } } ; int n = 3 ; Console . WriteLine ( " Original ▁ Matrix : " ) ; printMat ( mat , n ) ; sortMat ( mat , n ) ; Console . WriteLine ( " Matrix ▁ After ▁ Sorting : " ) ; printMat ( mat , n ) ; } }
using System ; class GFG { static int [ ] arr = new int [ ] { 1 , 2 , 3 , 4 } ;
static void subArray ( int n ) {
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i ; j < n ; j ++ ) {
for ( int k = i ; k <= j ; k ++ ) Console . Write ( arr [ k ] + " ▁ " ) ; Console . WriteLine ( " " ) ; } } }
public static void Main ( ) { Console . WriteLine ( " All ▁ Non - empty ▁ Subarrays " ) ; subArray ( arr . Length ) ; } }
using System ; class GFG { static void printSubsequences ( int [ ] arr , int n ) {
int opsize = ( int ) Math . Pow ( 2 , n ) ;
for ( int counter = 1 ; counter < opsize ; counter ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( ( counter & ( 1 << j ) ) != 0 ) Console . Write ( arr [ j ] + " ▁ " ) ; } Console . WriteLine ( ) ; } }
static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 } ; int n = arr . Length ; Console . WriteLine ( " All ▁ Non - empty ▁ Subsequences " ) ; printSubsequences ( arr , n ) ; } }
static void productArray ( int [ ] arr , int n ) {
if ( n == 1 ) { Console . Write ( 0 ) ; return ; } int i , temp = 1 ;
int [ ] prod = new int [ n ] ;
for ( int j = 0 ; j < n ; j ++ ) prod [ j ] = 1 ;
for ( i = 0 ; i < n ; i ++ ) { prod [ i ] = temp ; temp *= arr [ i ] ; }
temp = 1 ;
for ( i = n - 1 ; i >= 0 ; i -- ) { prod [ i ] *= temp ; temp *= arr [ i ] ; }
for ( i = 0 ; i < n ; i ++ ) Console . Write ( prod [ i ] + " ▁ " ) ; return ; }
public static void Main ( ) { int [ ] arr = { 10 , 3 , 5 , 6 , 2 } ; int n = arr . Length ; Console . WriteLine ( " The ▁ product ▁ array ▁ is ▁ : ▁ " ) ; productArray ( arr , n ) ; } }
static bool areConsecutive ( int [ ] arr , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) {
bool [ ] visited = new bool [ n ] ; int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( visited [ arr [ i ] - min ] != false ) return false ;
visited [ arr [ i ] - min ] = true ; }
return true ; }
return false ; }
static int getMin ( int [ ] arr , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } static int getMax ( int [ ] arr , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void Main ( ) { int [ ] arr = { 5 , 4 , 2 , 3 , 1 , 6 } ; int n = arr . Length ; if ( areConsecutive ( arr , n ) == true ) Console . Write ( " Array ▁ elements ▁ are " + " ▁ consecutive " ) ; else Console . Write ( " Array ▁ elements ▁ are " + " ▁ not ▁ consecutive " ) ; } }
static bool areConsecutive ( int [ ] arr , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { int j ; if ( arr [ i ] < 0 ) j = - arr [ i ] - min ; else j = arr [ i ] - min ;
if ( arr [ j ] > 0 ) arr [ j ] = - arr [ j ] ; else return false ; }
return true ; }
return false ; }
static int getMin ( int [ ] arr , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } static int getMax ( int [ ] arr , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void Main ( ) { int [ ] arr = { 5 , 4 , 2 , 3 , 1 , 6 } ; int n = arr . Length ; if ( areConsecutive ( arr , n ) == true ) Console . Write ( " Array ▁ elements ▁ " + " are ▁ consecutive " ) ; else Console . Write ( " Array ▁ elements ▁ " + " are ▁ not ▁ consecutive " ) ; } }
using System ; namespace Complement { public class GFG { static void relativeComplement ( int [ ] arr1 , int [ ] arr2 , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) {
if ( arr1 [ i ] < arr2 [ j ] ) { Console . Write ( arr1 [ i ] + " ▁ " ) ; i ++ ;
} else if ( arr1 [ i ] > arr2 [ j ] ) { j ++ ;
} else if ( arr1 [ i ] == arr2 [ j ] ) { i ++ ; j ++ ; } }
while ( i < n ) Console . Write ( arr1 [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr1 = { 3 , 6 , 10 , 12 , 15 } ; int [ ] arr2 = { 1 , 3 , 5 , 10 , 16 } ; int n = arr1 . Length ; int m = arr2 . Length ; relativeComplement ( arr1 , arr2 , n , m ) ; } } }
static int minOps ( int [ ] arr , int n , int k ) {
Array . Sort ( arr ) ; int max = arr [ arr . Length - 1 ] ; int res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ( max - arr [ i ] ) % k != 0 ) return - 1 ;
else res += ( - arr [ i ] ) / k ; }
return res ; }
public static void Main ( ) { int [ ] arr = { 21 , 33 , 9 , 45 , 63 } ; int n = arr . Length ; int k = 6 ; Console . Write ( minOps ( arr , n , k ) ) ; } }
using System ; class GFG { static int solve ( int [ ] A , int [ ] B , int [ ] C ) { int i , j , k ;
i = A . Length - 1 ; j = B . Length - 1 ; k = C . Length - 1 ; int min_diff , current_diff , max_term ;
min_diff = Math . Abs ( Math . Max ( A [ i ] , Math . Max ( B [ j ] , C [ k ] ) ) - Math . Min ( A [ i ] , Math . Min ( B [ j ] , C [ k ] ) ) ) ; while ( i != - 1 && j != - 1 && k != - 1 ) { current_diff = Math . Abs ( Math . Max ( A [ i ] , Math . Max ( B [ j ] , C [ k ] ) ) - Math . Min ( A [ i ] , Math . Min ( B [ j ] , C [ k ] ) ) ) ;
if ( current_diff < min_diff ) min_diff = current_diff ;
max_term = Math . Max ( A [ i ] , Math . Max ( B [ j ] , C [ k ] ) ) ;
if ( A [ i ] == max_term ) i -= 1 ; else if ( B [ j ] == max_term ) j -= 1 ; else k -= 1 ; } return min_diff ; }
public static void Main ( ) { int [ ] D = { 5 , 8 , 10 , 15 } ; int [ ] E = { 6 , 9 , 15 , 78 , 89 } ; int [ ] F = { 2 , 3 , 6 , 6 , 8 , 8 , 10 } ; Console . WriteLine ( solve ( D , E , F ) ) ; } }
using System ; class GFG { public static void search ( int [ ] arr , int search_Element ) { int left = 0 ; int length = arr . Length ; int right = length - 1 ; int position = - 1 ;
for ( left = 0 ; left <= right ; ) {
if ( arr [ left ] == search_Element ) { position = left ; Console . WriteLine ( " Element ▁ found ▁ in ▁ Array ▁ at ▁ " + ( position + 1 ) + " ▁ Position ▁ with ▁ " + ( left + 1 ) + " ▁ Attempt " ) ; break ; }
if ( arr [ right ] == search_Element ) { position = right ; Console . WriteLine ( " Element ▁ found ▁ in ▁ Array ▁ at ▁ " + ( position + 1 ) + " ▁ Position ▁ with ▁ " + ( length - right ) + " ▁ Attempt " ) ; break ; } left ++ ; right -- ; }
if ( position == - 1 ) Console . WriteLine ( " Not ▁ found ▁ in ▁ Array ▁ with ▁ " + left + " ▁ Attempt " ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; int search_element = 5 ;
search ( arr , search_element ) ; } }
using System ; public class JumpSearch { public static int jumpSearch ( int [ ] arr , int x ) { int n = arr . Length ;
int step = ( int ) Math . Floor ( Math . Sqrt ( n ) ) ;
int prev = 0 ; while ( arr [ Math . Min ( step , n ) - 1 ] < x ) { prev = step ; step += ( int ) Math . Floor ( Math . Sqrt ( n ) ) ; if ( prev >= n ) return - 1 ; }
while ( arr [ prev ] < x ) { prev ++ ;
if ( prev == Math . Min ( step , n ) ) return - 1 ; }
if ( arr [ prev ] == x ) return prev ; return - 1 ; }
public static void Main ( ) { int [ ] arr = { 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 } ; int x = 55 ;
int index = jumpSearch ( arr , x ) ;
Console . Write ( " Number ▁ " + x + " ▁ is ▁ at ▁ index ▁ " + index ) ; } }
static int interpolationSearch ( int [ ] arr , int lo , int hi , int x ) { int pos ;
if ( lo <= hi && x >= arr [ lo ] && x <= arr [ hi ] ) {
pos = lo + ( ( ( hi - lo ) / ( arr [ hi ] - arr [ lo ] ) ) * ( x - arr [ lo ] ) ) ;
if ( arr [ pos ] == x ) return pos ;
if ( arr [ pos ] < x ) return interpolationSearch ( arr , pos + 1 , hi , x ) ;
if ( arr [ pos ] > x ) return interpolationSearch ( arr , lo , pos - 1 , x ) ; } return - 1 ; }
int [ ] arr = new int [ ] { 10 , 12 , 13 , 16 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 33 , 35 , 42 , 47 } ; int n = arr . Length ;
int x = 18 ; int index = interpolationSearch ( arr , 0 , n - 1 , x ) ;
if ( index != - 1 ) Console . WriteLine ( " Element ▁ found ▁ at ▁ index ▁ " + index ) ; else Console . WriteLine ( " Element ▁ not ▁ found . " ) ; } }
static int exponentialSearch ( int [ ] arr , int n , int x ) {
if ( arr [ 0 ] == x ) return 0 ;
int i = 1 ; while ( i < n && arr [ i ] <= x ) i = i * 2 ;
return binarySearch ( arr , i / 2 , Math . Min ( i , n - 1 ) , x ) ; }
static int binarySearch ( int [ ] arr , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 4 , 10 , 40 } ; int n = arr . Length ; int x = 10 ; int result = exponentialSearch ( arr , n , x ) ; if ( result == - 1 ) Console . Write ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) ; else Console . Write ( " Element ▁ is ▁ present ▁ at ▁ index ▁ " + result ) ; } }
void merge ( int [ ] arr , int l , int m , int r ) {
int n1 = m - l + 1 ; int n2 = r - m ;
int [ ] L = new int [ n1 ] ; int [ ] R = new int [ n2 ] ; int i , j ;
for ( i = 0 ; i < n1 ; ++ i ) L [ i ] = arr [ l + i ] ; for ( j = 0 ; j < n2 ; ++ j ) R [ j ] = arr [ m + 1 + j ] ;
i = 0 ; j = 0 ;
int k = l ; while ( i < n1 && j < n2 ) { if ( L [ i ] <= R [ j ] ) { arr [ k ] = L [ i ] ; i ++ ; } else { arr [ k ] = R [ j ] ; j ++ ; } k ++ ; }
while ( i < n1 ) { arr [ k ] = L [ i ] ; i ++ ; k ++ ; }
while ( j < n2 ) { arr [ k ] = R [ j ] ; j ++ ; k ++ ; } }
void sort ( int [ ] arr , int l , int r ) { if ( l < r ) {
int m = l + ( r - l ) / 2 ;
sort ( arr , l , m ) ; sort ( arr , m + 1 , r ) ;
merge ( arr , l , m , r ) ; } }
static void printArray ( int [ ] arr ) { int n = arr . Length ; for ( int i = 0 ; i < n ; ++ i ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 12 , 11 , 13 , 5 , 6 , 7 } ; Console . WriteLine ( " Given ▁ Array " ) ; printArray ( arr ) ; MergeSort ob = new MergeSort ( ) ; ob . sort ( arr , 0 , arr . Length - 1 ) ; Console . WriteLine ( " STRNEWLINE Sorted ▁ array " ) ; printArray ( arr ) ; } }
static void countSort ( int [ ] arr ) { int max = arr . Max ( ) ; int min = arr . Min ( ) ; int range = max - min + 1 ; int [ ] count = new int [ range ] ; int [ ] output = new int [ arr . Length ] ; for ( int i = 0 ; i < arr . Length ; i ++ ) { count [ arr [ i ] - min ] ++ ; } for ( int i = 1 ; i < count . Length ; i ++ ) { count [ i ] += count [ i - 1 ] ; } for ( int i = arr . Length - 1 ; i >= 0 ; i -- ) { output [ count [ arr [ i ] - min ] - 1 ] = arr [ i ] ; count [ arr [ i ] - min ] -- ; } for ( int i = 0 ; i < arr . Length ; i ++ ) { arr [ i ] = output [ i ] ; } }
static void printArray ( int [ ] arr ) { for ( int i = 0 ; i < arr . Length ; i ++ ) { Console . Write ( arr [ i ] + " ▁ " ) ; } Console . WriteLine ( " " ) ; }
public static void Main ( string [ ] args ) { int [ ] arr = { - 5 , - 10 , 0 , - 3 , 8 , 5 , - 1 , 10 } ; countSort ( arr ) ; printArray ( arr ) ; } }
static int getNextGap ( int gap ) {
gap = ( gap * 10 ) / 13 ; if ( gap < 1 ) return 1 ; return gap ; }
static void sort ( int [ ] arr ) { int n = arr . Length ;
int gap = n ;
bool swapped = true ;
while ( gap != 1 swapped == true ) {
gap = getNextGap ( gap ) ;
swapped = false ;
for ( int i = 0 ; i < n - gap ; i ++ ) { if ( arr [ i ] > arr [ i + gap ] ) {
int temp = arr [ i ] ; arr [ i ] = arr [ i + gap ] ; arr [ i + gap ] = temp ;
swapped = true ; } } } }
public static void Main ( ) { int [ ] arr = { 8 , 4 , 1 , 56 , 3 , - 44 , 23 , - 6 , 28 , 0 } ; sort ( arr ) ; Console . WriteLine ( " sorted ▁ array " ) ; for ( int i = 0 ; i < arr . Length ; ++ i ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void cycleSort ( int [ ] arr , int n ) {
int writes = 0 ;
for ( int cycle_start = 0 ; cycle_start <= n - 2 ; cycle_start ++ ) {
int item = arr [ cycle_start ] ;
int pos = cycle_start ; for ( int i = cycle_start + 1 ; i < n ; i ++ ) if ( arr [ i ] < item ) pos ++ ;
if ( pos == cycle_start ) continue ;
while ( item == arr [ pos ] ) pos += 1 ;
if ( pos != cycle_start ) { int temp = item ; item = arr [ pos ] ; arr [ pos ] = temp ; writes ++ ; }
while ( pos != cycle_start ) { pos = cycle_start ;
for ( int i = cycle_start + 1 ; i < n ; i ++ ) if ( arr [ i ] < item ) pos += 1 ;
while ( item == arr [ pos ] ) pos += 1 ;
if ( item != arr [ pos ] ) { int temp = item ; item = arr [ pos ] ; arr [ pos ] = temp ; writes ++ ; } } } }
public static void Main ( ) { int [ ] arr = { 1 , 8 , 3 , 9 , 10 , 10 , 2 , 4 } ; int n = arr . Length ; cycleSort ( arr , n ) ; Console . Write ( " After ▁ sort ▁ : ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public class Node { public int data ; public Node next ; public Node ( int key ) { this . data = key ; next = null ; } } class GFG {
static Node mergeSort ( Node head ) { if ( head . next == null ) return head ; Node mid = findMid ( head ) ; Node head2 = mid . next ; mid . next = null ; Node newHead1 = mergeSort ( head ) ; Node newHead2 = mergeSort ( head2 ) ; Node finalHead = merge ( newHead1 , newHead2 ) ; return finalHead ; }
static Node merge ( Node head1 , Node head2 ) { Node merged = new Node ( - 1 ) ; Node temp = merged ;
while ( head1 != null && head2 != null ) { if ( head1 . data < head2 . data ) { temp . next = head1 ; head1 = head1 . next ; } else { temp . next = head2 ; head2 = head2 . next ; } temp = temp . next ; }
while ( head1 != null ) { temp . next = head1 ; head1 = head1 . next ; temp = temp . next ; }
while ( head2 != null ) { temp . next = head2 ; head2 = head2 . next ; temp = temp . next ; } return merged . next ; }
static Node findMid ( Node head ) { Node slow = head , fast = head . next ; while ( fast != null && fast . next != null ) { slow = slow . next ; fast = fast . next . next ; } return slow ; }
static void printList ( Node head ) { while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; head = head . next ; } }
public static void Main ( String [ ] args ) { Node head = new Node ( 7 ) ; Node temp = head ; temp . next = new Node ( 10 ) ; temp = temp . next ; temp . next = new Node ( 5 ) ; temp = temp . next ; temp . next = new Node ( 20 ) ; temp = temp . next ; temp . next = new Node ( 3 ) ; temp = temp . next ; temp . next = new Node ( 2 ) ; temp = temp . next ;
head = mergeSort ( head ) ; Console . Write ( " STRNEWLINE Sorted ▁ Linked ▁ List ▁ is : ▁ STRNEWLINE " ) ; printList ( head ) ; } }
static int findCrossOver ( int [ ] arr , int low , int high , int x ) {
if ( arr [ high ] <= x ) return high ;
if ( arr [ low ] > x ) return low ;
int mid = ( low + high ) / 2 ;
if ( arr [ mid ] <= x && arr [ mid + 1 ] > x ) return mid ;
if ( arr [ mid ] < x ) return findCrossOver ( arr , mid + 1 , high , x ) ; return findCrossOver ( arr , low , mid - 1 , x ) ; }
static void printKclosest ( int [ ] arr , int x , int k , int n ) {
int l = findCrossOver ( arr , 0 , n - 1 , x ) ;
int r = l + 1 ;
int count = 0 ;
if ( arr [ l ] == x ) l -- ;
while ( l >= 0 && r < n && count < k ) { if ( x - arr [ l ] < arr [ r ] - x ) Console . Write ( arr [ l -- ] + " ▁ " ) ; else Console . Write ( arr [ r ++ ] + " ▁ " ) ; count ++ ; }
while ( count < k && l >= 0 ) { Console . Write ( arr [ l -- ] + " ▁ " ) ; count ++ ; }
while ( count < k && r < n ) { Console . Write ( arr [ r ++ ] + " ▁ " ) ; count ++ ; } }
public static void Main ( ) { int [ ] arr = { 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 } ; int n = arr . Length ; int x = 35 ; printKclosest ( arr , x , 4 , n ) ; } }
static void countSort ( int [ ] arr , int n , int exp ) {
int [ ] output = new int [ n ] ; int [ ] count = new int [ n ] ; int i ; for ( i = 0 ; i < n ; i ++ ) count [ i ] = 0 ;
for ( i = 0 ; i < n ; i ++ ) count [ ( arr [ i ] / exp ) % n ] ++ ;
for ( i = 1 ; i < n ; i ++ ) count [ i ] += count [ i - 1 ] ;
for ( i = n - 1 ; i >= 0 ; i -- ) { output [ count [ ( arr [ i ] / exp ) % n ] - 1 ] = arr [ i ] ; count [ ( arr [ i ] / exp ) % n ] -- ; }
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = output [ i ] ; }
static void sort ( int [ ] arr , int n ) {
countSort ( arr , n , 1 ) ;
countSort ( arr , n , n ) ; }
static void printArr ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
int [ ] arr = { 40 , 12 , 45 , 32 , 33 , 1 , 22 } ; int n = arr . Length ; Console . WriteLine ( " Given ▁ array " ) ; printArr ( arr , n ) ; sort ( arr , n ) ; Console . WriteLine ( " STRNEWLINE Sorted ▁ array " ) ; printArr ( arr , n ) ; } }
static void printClosest ( int [ ] ar1 , int [ ] ar2 , int m , int n , int x ) {
int diff = int . MaxValue ;
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 ; while ( l < m && r >= 0 ) {
if ( Math . Abs ( ar1 [ l ] + ar2 [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . Abs ( ar1 [ l ] + ar2 [ r ] - x ) ; }
if ( ar1 [ l ] + ar2 [ r ] > x ) r -- ;
else l ++ ; }
Console . Write ( " The ▁ closest ▁ pair ▁ is ▁ [ " + ar1 [ res_l ] + " , ▁ " + ar2 [ res_r ] + " ] " ) ; }
public static void Main ( ) { int [ ] ar1 = { 1 , 4 , 5 , 7 } ; int [ ] ar2 = { 10 , 20 , 30 , 40 } ; int m = ar1 . Length ; int n = ar2 . Length ; int x = 38 ; printClosest ( ar1 , ar2 , m , n , x ) ; } }
static void printClosest ( int [ ] arr , int n , int x ) {
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 , diff = int . MaxValue ;
while ( r > l ) {
if ( Math . Abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . Abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } Console . Write ( " ▁ The ▁ closest ▁ pair ▁ is ▁ " + arr [ res_l ] + " ▁ and ▁ " + arr [ res_r ] ) ; }
public static void Main ( ) { int [ ] arr = { 10 , 22 , 28 , 29 , 30 , 40 } ; int x = 54 ; int n = arr . Length ; printClosest ( arr , n , x ) ; } }
static int countOnes ( int [ ] arr , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = arr . Length ; Console . WriteLine ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ " + " array ▁ is ▁ " + countOnes ( arr , 0 , n - 1 ) ) ; } }
using System ; public class LinkedlistIS { public node head ; public node sorted ; public class node { public int val ; public node next ; public node ( int val ) { this . val = val ; } }
void push ( int val ) {
node newnode = new node ( val ) ;
newnode . next = head ;
head = newnode ; }
void insertionSort ( node headref ) {
sorted = null ; node current = headref ;
while ( current != null ) {
node next = current . next ;
sortedInsert ( current ) ;
current = next ; }
head = sorted ; }
void sortedInsert ( node newnode ) {
if ( sorted == null sorted . val >= newnode . val ) { newnode . next = sorted ; sorted = newnode ; } else { node current = sorted ;
while ( current . next != null && current . next . val < newnode . val ) { current = current . next ; } newnode . next = current . next ; current . next = newnode ; } }
void printlist ( node head ) { while ( head != null ) { Console . Write ( head . val + " ▁ " ) ; head = head . next ; } }
public static void Main ( String [ ] args ) { LinkedlistIS list = new LinkedlistIS ( ) ; list . push ( 5 ) ; list . push ( 20 ) ; list . push ( 4 ) ; list . push ( 3 ) ; list . push ( 30 ) ; Console . WriteLine ( " Linked ▁ List ▁ before ▁ Sorting . . " ) ; list . printlist ( list . head ) ; list . insertionSort ( list . head ) ; Console . WriteLine ( " STRNEWLINE LinkedList ▁ After ▁ sorting " ) ; list . printlist ( list . head ) ; } }
public static void minimumSwaps ( int [ ] a , int n ) { int maxx = - 1 , l = 0 , minn = a [ 0 ] , r = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] > maxx ) { maxx = a [ i ] ; l = i ; }
if ( a [ i ] <= minn ) { minn = a [ i ] ; r = i ; } } if ( r < l ) Console . WriteLine ( l + ( n - r - 2 ) ) ; else Console . WriteLine ( l + ( n - r - 1 ) ) ; }
public static void Main ( ) { int [ ] a = { 5 , 6 , 1 , 3 } ; int n = a . Length ; minimumSwaps ( a , n ) ; } }
static int max_ref ;
static int _lis ( int [ ] arr , int n ) {
if ( n == 1 ) return 1 ;
int res , max_ending_here = 1 ;
for ( int i = 1 ; i < n ; i ++ ) { res = _lis ( arr , i ) ; if ( arr [ i - 1 ] < arr [ n - 1 ] && res + 1 > max_ending_here ) max_ending_here = res + 1 ; }
if ( max_ref < max_ending_here ) max_ref = max_ending_here ;
return max_ending_here ; }
static int lis ( int [ ] arr , int n ) {
max_ref = 1 ;
_lis ( arr , n ) ;
return max_ref ; }
public static void Main ( ) { int [ ] arr = { 10 , 22 , 9 , 33 , 21 , 50 , 41 , 60 } ; int n = arr . Length ; Console . Write ( " Length ▁ of ▁ lis ▁ is ▁ " + lis ( arr , n ) + " STRNEWLINE " ) ; } }
static int lis ( int [ ] arr , int n ) { int [ ] lis = new int [ n ] ; int i , j , max = 0 ;
for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
for ( i = 0 ; i < n ; i ++ ) if ( max < lis [ i ] ) max = lis [ i ] ; return max ; }
public static void Main ( ) { int [ ] arr = { 10 , 22 , 9 , 33 , 21 , 50 , 41 , 60 } ; int n = arr . Length ; Console . WriteLine ( " Length ▁ of ▁ lis ▁ is ▁ " + lis ( arr , n ) + " STRNEWLINE " ) ; } }
using System ; class GFG { static int row = 3 ; static int col = 3 ; static int minCost ( int [ , ] cost ) {
for ( int i = 1 ; i < row ; i ++ ) { cost [ i , 0 ] += cost [ i - 1 , 0 ] ; }
for ( int j = 1 ; j < col ; j ++ ) { cost [ 0 , j ] += cost [ 0 , j - 1 ] ; }
for ( int i = 1 ; i < row ; i ++ ) { for ( int j = 1 ; j < col ; j ++ ) { cost [ i , j ] += Math . Min ( cost [ i - 1 , j - 1 ] , Math . Min ( cost [ i - 1 , j ] , cost [ i , j - 1 ] ) ) ; } }
return cost [ row - 1 , col - 1 ] ; }
public static void Main ( String [ ] args ) { int [ , ] cost = { { 1 , 2 , 3 } , { 4 , 8 , 2 } , { 1 , 5 , 3 } } ; Console . Write ( minCost ( cost ) + " STRNEWLINE " ) ; } }
static int count ( int [ ] S , int m , int n ) {
if ( n == 0 ) return 1 ;
if ( n < 0 ) return 0 ;
if ( m <= 0 && n >= 1 ) return 0 ;
return count ( S , m - 1 , n ) + count ( S , m , n - S [ m - 1 ] ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 } ; int m = arr . Length ; Console . Write ( count ( arr , m , 4 ) ) ; } }
using System ; class GFG { static int count ( int [ ] S , int m , int n ) {
int [ ] table = new int [ n + 1 ] ;
table [ 0 ] = 1 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = S [ i ] ; j <= n ; j ++ ) table [ j ] += table [ j - S [ i ] ] ; return table [ n ] ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 } ; int m = arr . Length ; int n = 4 ; Console . Write ( count ( arr , m , n ) ) ; } }
using System ; class GFG { static int [ , ] dp = new int [ 100 , 100 ] ;
static int matrixChainMemoised ( int [ ] p , int i , int j ) { if ( i == j ) { return 0 ; } if ( dp [ i , j ] != - 1 ) { return dp [ i , j ] ; } dp [ i , j ] = Int32 . MaxValue ; for ( int k = i ; k < j ; k ++ ) { dp [ i , j ] = Math . Min ( dp [ i , j ] , matrixChainMemoised ( p , i , k ) + matrixChainMemoised ( p , k + 1 , j ) + p [ i - 1 ] * p [ k ] * p [ j ] ) ; } return dp [ i , j ] ; } static int MatrixChainOrder ( int [ ] p , int n ) { int i = 1 , j = n - 1 ; return matrixChainMemoised ( p , i , j ) ; }
static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 } ; int n = arr . Length ; for ( int i = 0 ; i < 100 ; i ++ ) { for ( int j = 0 ; j < 100 ; j ++ ) { dp [ i , j ] = - 1 ; } } Console . WriteLine ( " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " + MatrixChainOrder ( arr , n ) ) ; } }
using System ; class GFG { static int binomialCoeff ( int n , int k ) { int [ ] C = new int [ k + 1 ] ;
C [ 0 ] = 1 ; for ( int i = 1 ; i <= n ; i ++ ) {
for ( int j = Math . Min ( i , k ) ; j > 0 ; j -- ) C [ j ] = C [ j ] + C [ j - 1 ] ; } return C [ k ] ; }
public static void Main ( ) { int n = 5 , k = 2 ; Console . WriteLine ( " Value ▁ of ▁ C ( " + n + " ▁ " + k + " ) ▁ is ▁ " + binomialCoeff ( n , k ) ) ; } }
static int eggDrop ( int n , int k ) {
if ( k == 1 k == 0 ) return k ;
if ( n == 1 ) return k ; int min = int . MaxValue ; int x , res ;
for ( x = 1 ; x <= k ; x ++ ) { res = Math . Max ( eggDrop ( n - 1 , x - 1 ) , eggDrop ( n , k - x ) ) ; if ( res < min ) min = res ; } return min + 1 ; }
static void Main ( ) { int n = 2 , k = 10 ; Console . Write ( " Minimum ▁ number ▁ of ▁ " + " trials ▁ in ▁ worst ▁ case ▁ with ▁ " + n + " ▁ eggs ▁ and ▁ " + k + " ▁ floors ▁ is ▁ " + eggDrop ( n , k ) ) ; } }
static int cutRod ( int [ ] price , int n ) { if ( n <= 0 ) return 0 ; int max_val = int . MinValue ;
for ( int i = 0 ; i < n ; i ++ ) max_val = Math . Max ( max_val , price [ i ] + cutRod ( price , n - i - 1 ) ) ; return max_val ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = arr . Length ; Console . WriteLine ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " + cutRod ( arr , size ) ) ; } }
using System ; class GFG { public class pair { public int first , second ; public pair ( int first , int second ) { this . first = first ; this . second = second ; } } static int findRoot ( pair [ ] arr , int n ) {
int root = 0 ; for ( int i = 0 ; i < n ; i ++ ) { root += ( arr [ i ] . first - arr [ i ] . second ) ; } return root ; }
public static void Main ( String [ ] args ) { pair [ ] arr = { new pair ( 1 , 5 ) , new pair ( 2 , 0 ) , new pair ( 3 , 0 ) , new pair ( 4 , 0 ) , new pair ( 5 , 5 ) , new pair ( 6 , 5 ) } ; int n = arr . Length ; Console . Write ( " { 0 } STRNEWLINE " , findRoot ( arr , n ) ) ; } }
static int cutRod ( int [ ] price , int n ) { int [ ] val = new int [ n + 1 ] ; val [ 0 ] = 0 ;
for ( int i = 1 ; i <= n ; i ++ ) { int max_val = int . MinValue ; for ( int j = 0 ; j < i ; j ++ ) max_val = Math . Max ( max_val , price [ j ] + val [ i - j - 1 ] ) ; val [ i ] = max_val ; } return val [ n ] ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = arr . Length ; Console . WriteLine ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " + cutRod ( arr , size ) ) ; } }
static int lbs ( int [ ] arr , int n ) { int i , j ;
int [ ] lis = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
int [ ] lds = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lds [ i ] = 1 ;
for ( i = n - 2 ; i >= 0 ; i -- ) for ( j = n - 1 ; j > i ; j -- ) if ( arr [ i ] > arr [ j ] && lds [ i ] < lds [ j ] + 1 ) lds [ i ] = lds [ j ] + 1 ;
int max = lis [ 0 ] + lds [ 0 ] - 1 ; for ( i = 1 ; i < n ; i ++ ) if ( lis [ i ] + lds [ i ] - 1 > max ) max = lis [ i ] + lds [ i ] - 1 ; return max ; }
public static void Main ( ) { int [ ] arr = { 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 } ; int n = arr . Length ; Console . WriteLine ( " Length ▁ of ▁ LBS ▁ is ▁ " + lbs ( arr , n ) ) ; } }
using System ; public class GFG { static bool isPalindrome ( string String , int i , int j ) { while ( i < j ) { if ( String [ i ] != String [ j ] ) return false ; i ++ ; j -- ; } return true ; } static int minPalPartion ( string String , int i , int j ) { if ( i >= j || isPalindrome ( String , i , j ) ) return 0 ; int ans = Int32 . MaxValue , count ; for ( int k = i ; k < j ; k ++ ) { count = minPalPartion ( String , i , k ) + minPalPartion ( String , k + 1 , j ) + 1 ; ans = Math . Min ( ans , count ) ; } return ans ; }
static public void Main ( ) { string str = " ababbbabbababa " ; Console . WriteLine ( " Min ▁ cuts ▁ needed ▁ for ▁ " + " Palindrome ▁ Partitioning ▁ is ▁ " + minPalPartion ( str , 0 , str . Length - 1 ) ) ; } }
static bool findPartiion ( int [ ] arr , int n ) { int sum = 0 ; int i , j ;
for ( i = 0 ; i < n ; i ++ ) sum += arr [ i ] ; if ( sum % 2 != 0 ) return false ; bool [ ] part = new bool [ sum / 2 + 1 ] ;
for ( i = 0 ; i <= sum / 2 ; i ++ ) { part [ i ] = false ; }
for ( i = 0 ; i < n ; i ++ ) {
for ( j = sum / 2 ; j >= arr [ i ] ; j -- ) {
if ( part [ j - arr [ i ] ] == true j == arr [ i ] ) part [ j ] = true ; } } return part [ sum / 2 ] ; }
static void Main ( ) { int [ ] arr = { 1 , 3 , 3 , 2 , 3 , 2 } ; int n = 6 ;
if ( findPartiion ( arr , n ) == true ) Console . WriteLine ( " Can ▁ be ▁ divided ▁ into ▁ two ▁ " + " subsets ▁ of ▁ equal ▁ sum " ) ; else Console . WriteLine ( " Can ▁ not ▁ be ▁ divided ▁ into ▁ " + " two ▁ subsets ▁ of ▁ equal ▁ sum " ) ; } }
using System ; public class GFG { static int MAX = int . MaxValue ;
static int printSolution ( int [ ] p , int n ) { int k ; if ( p [ n ] == 1 ) k = 1 ; else k = printSolution ( p , p [ n ] - 1 ) + 1 ; Console . WriteLine ( " Line ▁ number " + " ▁ " + k + " : ▁ From ▁ word ▁ no . " + " ▁ " + p [ n ] + " ▁ " + " to " + " ▁ " + n ) ; return k ; }
static void solveWordWrap ( int [ ] l , int n , int M ) {
int [ , ] extras = new int [ n + 1 , n + 1 ] ;
int [ , ] lc = new int [ n + 1 , n + 1 ] ;
int [ ] c = new int [ n + 1 ] ;
int [ ] p = new int [ n + 1 ] ;
for ( int i = 1 ; i <= n ; i ++ ) { extras [ i , i ] = M - l [ i - 1 ] ; for ( int j = i + 1 ; j <= n ; j ++ ) extras [ i , j ] = extras [ i , j - 1 ] - l [ j - 1 ] - 1 ; }
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = i ; j <= n ; j ++ ) { if ( extras [ i , j ] < 0 ) lc [ i , j ] = MAX ; else if ( j == n && extras [ i , j ] >= 0 ) lc [ i , j ] = 0 ; else lc [ i , j ] = extras [ i , j ] * extras [ i , j ] ; } }
c [ 0 ] = 0 ; for ( int j = 1 ; j <= n ; j ++ ) { c [ j ] = MAX ; for ( int i = 1 ; i <= j ; i ++ ) { if ( c [ i - 1 ] != MAX && lc [ i , j ] != MAX && ( c [ i - 1 ] + lc [ i , j ] < c [ j ] ) ) { c [ j ] = c [ i - 1 ] + lc [ i , j ] ; p [ j ] = i ; } } } printSolution ( p , n ) ; }
public static void Main ( ) { int [ ] l = { 3 , 2 , 2 , 5 } ; int n = l . Length ; int M = 6 ; solveWordWrap ( l , n , M ) ; } }
static int maxDivide ( int a , int b ) { while ( a % b == 0 ) a = a / b ; return a ; }
static int isUgly ( int no ) { no = maxDivide ( no , 2 ) ; no = maxDivide ( no , 3 ) ; no = maxDivide ( no , 5 ) ; return ( no == 1 ) ? 1 : 0 ; }
static int getNthUglyNo ( int n ) { int i = 1 ;
int count = 1 ;
while ( n > count ) { i ++ ; if ( isUgly ( i ) == 1 ) count ++ ; } return i ; }
public static void Main ( ) { int no = getNthUglyNo ( 150 ) ; Console . WriteLine ( "150th ▁ ugly " + " ▁ no . ▁ is ▁ " + no ) ; } }
static int sum ( int [ ] freq , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
static int optCost ( int [ ] freq , int i , int j ) {
if ( j < i ) return 0 ;
if ( j == i ) return freq [ i ] ;
int fsum = sum ( freq , i , j ) ;
int min = int . MaxValue ;
for ( int r = i ; r <= j ; ++ r ) { int cost = optCost ( freq , i , r - 1 ) + optCost ( freq , r + 1 , j ) ; if ( cost < min ) min = cost ; }
return min + fsum ; }
static int optimalSearchTree ( int [ ] keys , int [ ] freq , int n ) {
return optCost ( freq , 0 , n - 1 ) ; }
public static void Main ( ) { int [ ] keys = { 10 , 12 , 20 } ; int [ ] freq = { 34 , 8 , 50 } ; int n = keys . Length ; Console . Write ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ " + optimalSearchTree ( keys , freq , n ) ) ; } }
static int sum ( int [ ] freq , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) { if ( k >= freq . Length ) continue ; s += freq [ k ] ; } return s ; }
static int optimalSearchTree ( int [ ] keys , int [ ] freq , int n ) {
int [ , ] cost = new int [ n + 1 , n + 1 ] ;
for ( int i = 0 ; i < n ; i ++ ) cost [ i , i ] = freq [ i ] ;
for ( int L = 2 ; L <= n ; L ++ ) {
for ( int i = 0 ; i <= n - L + 1 ; i ++ ) {
int j = i + L - 1 ; cost [ i , j ] = int . MaxValue ;
for ( int r = i ; r <= j ; r ++ ) {
int c = ( ( r > i ) ? cost [ i , r - 1 ] : 0 ) + ( ( r < j ) ? cost [ r + 1 , j ] : 0 ) + sum ( freq , i , j ) ; if ( c < cost [ i , j ] ) cost [ i , j ] = c ; } } } return cost [ 0 , n - 1 ] ; }
public static void Main ( ) { int [ ] keys = { 10 , 12 , 20 } ; int [ ] freq = { 34 , 8 , 50 } ; int n = keys . Length ; Console . Write ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ " + optimalSearchTree ( keys , freq , n ) ) ; } }
static bool isSubsetSum ( int [ ] set , int n , int sum ) {
if ( sum == 0 ) return true ; if ( n == 0 ) return false ;
if ( set [ n - 1 ] > sum ) return isSubsetSum ( set , n - 1 , sum ) ;
return isSubsetSum ( set , n - 1 , sum ) || isSubsetSum ( set , n - 1 , sum - set [ n - 1 ] ) ; }
public static void Main ( ) { int [ ] set = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = set . Length ; if ( isSubsetSum ( set , n , sum ) == true ) Console . WriteLine ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) ; else Console . WriteLine ( " No ▁ subset ▁ with ▁ given ▁ sum " ) ; } }
static bool isSubsetSum ( int [ ] set , int n , int sum ) {
bool [ , ] subset = new bool [ sum + 1 , n + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) subset [ 0 , i ] = true ;
for ( int i = 1 ; i <= sum ; i ++ ) subset [ i , 0 ] = false ;
for ( int i = 1 ; i <= sum ; i ++ ) { for ( int j = 1 ; j <= n ; j ++ ) { subset [ i , j ] = subset [ i , j - 1 ] ; if ( i >= set [ j - 1 ] ) subset [ i , j ] = subset [ i , j ] || subset [ i - set [ j - 1 ] , j - 1 ] ; } } return subset [ sum , n ] ; }
public static void Main ( ) { int [ ] set = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = set . Length ; if ( isSubsetSum ( set , n , sum ) == true ) Console . WriteLine ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) ; else Console . WriteLine ( " No ▁ subset ▁ with ▁ given ▁ sum " ) ; } }
static int countParenth ( char [ ] symb , char [ ] oper , int n ) { int [ , ] F = new int [ n , n ] ; int [ , ] T = new int [ n , n ] ;
for ( int i = 0 ; i < n ; i ++ ) { F [ i , i ] = ( symb [ i ] == ' F ' ) ? 1 : 0 ; T [ i , i ] = ( symb [ i ] == ' T ' ) ? 1 : 0 ; }
for ( int gap = 1 ; gap < n ; ++ gap ) { for ( int i = 0 , j = gap ; j < n ; ++ i , ++ j ) { T [ i , j ] = F [ i , j ] = 0 ; for ( int g = 0 ; g < gap ; g ++ ) {
int k = i + g ;
int tik = T [ i , k ] + F [ i , k ] ; int tkj = T [ k + 1 , j ] + F [ k + 1 , j ] ;
if ( oper [ k ] == ' & ' ) { T [ i , j ] += T [ i , k ] * T [ k + 1 , j ] ; F [ i , j ] += ( tik * tkj - T [ i , k ] * T [ k + 1 , j ] ) ; } if ( oper [ k ] == ' ▁ ' ) { F [ i , j ] += F [ i , k ] * F [ k + 1 , j ] ; T [ i , j ] += ( tik * tkj - F [ i , k ] * F [ k + 1 , j ] ) ; } if ( oper [ k ] == ' ^ ' ) { T [ i , j ] += F [ i , k ] * T [ k + 1 , j ] + T [ i , k ] * F [ k + 1 , j ] ; F [ i , j ] += T [ i , k ] * T [ k + 1 , j ] + F [ i , k ] * F [ k + 1 , j ] ; } } } } return T [ 0 , n - 1 ] ; }
public static void Main ( ) { char [ ] symbols = " TTFT " . ToCharArray ( ) ; char [ ] operators = " | & ^ " . ToCharArray ( ) ; int n = symbols . Length ;
Console . WriteLine ( countParenth ( symbols , operators , n ) ) ; } }
static int getCount ( char [ , ] keypad , int n ) { if ( keypad == null n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
int [ ] row = { 0 , 0 , - 1 , 0 , 1 } ; int [ ] col = { 0 , - 1 , 0 , 1 , 0 } ;
int [ , ] count = new int [ 10 , n + 1 ] ; int i = 0 , j = 0 , k = 0 , move = 0 , ro = 0 , co = 0 , num = 0 ; int nextNum = 0 , totalCount = 0 ;
for ( i = 0 ; i <= 9 ; i ++ ) { count [ i , 0 ] = 0 ; count [ i , 1 ] = 1 ; }
for ( k = 2 ; k <= n ; k ++ ) {
for ( i = 0 ; i < 4 ; i ++ ) {
for ( j = 0 ; j < 3 ; j ++ ) {
if ( keypad [ i , j ] != ' * ' && keypad [ i , j ] != ' # ' ) {
num = keypad [ i , j ] - '0' ; count [ num , k ] = 0 ;
for ( move = 0 ; move < 5 ; move ++ ) { ro = i + row [ move ] ; co = j + col [ move ] ; if ( ro >= 0 && ro <= 3 && co >= 0 && co <= 2 && keypad [ ro , co ] != ' * ' && keypad [ ro , co ] != ' # ' ) { nextNum = keypad [ ro , co ] - '0' ; count [ num , k ] += count [ nextNum , k - 1 ] ; } } } } } }
totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ ) totalCount += count [ i , n ] ; return totalCount ; }
public static void Main ( String [ ] args ) { char [ , ] keypad = { { '1' , '2' , '3' } , { '4' , '5' , '6' } , { '7' , '8' , '9' } , { ' * ' , '0' , ' # ' } } ; Console . Write ( " Count ▁ for ▁ numbers ▁ of . Length ▁ { 0 } : ▁ { 1 } STRNEWLINE " , 1 , getCount ( keypad , 1 ) ) ; Console . Write ( " Count ▁ for ▁ numbers ▁ of . Length ▁ { 0 } : ▁ { 1 } STRNEWLINE " , 2 , getCount ( keypad , 2 ) ) ; Console . Write ( " Count ▁ for ▁ numbers ▁ of . Length ▁ { 0 } : ▁ { 1 } STRNEWLINE " , 3 , getCount ( keypad , 3 ) ) ; Console . Write ( " Count ▁ for ▁ numbers ▁ of . Length ▁ { 0 } : ▁ { 1 } STRNEWLINE " , 4 , getCount ( keypad , 4 ) ) ; Console . Write ( " Count ▁ for ▁ numbers ▁ of . Length ▁ { 0 } : ▁ { 1 } STRNEWLINE " , 5 , getCount ( keypad , 5 ) ) ; } }
static int getCount ( char [ , ] keypad , int n ) { if ( keypad == null n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
int [ ] odd = new int [ 10 ] ; int [ ] even = new int [ 10 ] ; int i = 0 , j = 0 , useOdd = 0 , totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ )
odd [ i ] = 1 ;
for ( j = 2 ; j <= n ; j ++ ) { useOdd = 1 - useOdd ;
if ( useOdd == 1 ) { even [ 0 ] = odd [ 0 ] + odd [ 8 ] ; even [ 1 ] = odd [ 1 ] + odd [ 2 ] + odd [ 4 ] ; even [ 2 ] = odd [ 2 ] + odd [ 1 ] + odd [ 3 ] + odd [ 5 ] ; even [ 3 ] = odd [ 3 ] + odd [ 2 ] + odd [ 6 ] ; even [ 4 ] = odd [ 4 ] + odd [ 1 ] + odd [ 5 ] + odd [ 7 ] ; even [ 5 ] = odd [ 5 ] + odd [ 2 ] + odd [ 4 ] + odd [ 8 ] + odd [ 6 ] ; even [ 6 ] = odd [ 6 ] + odd [ 3 ] + odd [ 5 ] + odd [ 9 ] ; even [ 7 ] = odd [ 7 ] + odd [ 4 ] + odd [ 8 ] ; even [ 8 ] = odd [ 8 ] + odd [ 0 ] + odd [ 5 ] + odd [ 7 ] + odd [ 9 ] ; even [ 9 ] = odd [ 9 ] + odd [ 6 ] + odd [ 8 ] ; } else { odd [ 0 ] = even [ 0 ] + even [ 8 ] ; odd [ 1 ] = even [ 1 ] + even [ 2 ] + even [ 4 ] ; odd [ 2 ] = even [ 2 ] + even [ 1 ] + even [ 3 ] + even [ 5 ] ; odd [ 3 ] = even [ 3 ] + even [ 2 ] + even [ 6 ] ; odd [ 4 ] = even [ 4 ] + even [ 1 ] + even [ 5 ] + even [ 7 ] ; odd [ 5 ] = even [ 5 ] + even [ 2 ] + even [ 4 ] + even [ 8 ] + even [ 6 ] ; odd [ 6 ] = even [ 6 ] + even [ 3 ] + even [ 5 ] + even [ 9 ] ; odd [ 7 ] = even [ 7 ] + even [ 4 ] + even [ 8 ] ; odd [ 8 ] = even [ 8 ] + even [ 0 ] + even [ 5 ] + even [ 7 ] + even [ 9 ] ; odd [ 9 ] = even [ 9 ] + even [ 6 ] + even [ 8 ] ; } }
totalCount = 0 ; if ( useOdd == 1 ) { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += even [ i ] ; } else { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += odd [ i ] ; } return totalCount ; }
public static void Main ( String [ ] args ) { char [ , ] keypad = { { '1' , '2' , '3' } , { '4' , '5' , '6' } , { '7' , '8' , '9' } , { ' * ' , '0' , ' # ' } } ; Console . Write ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ { 0 } : ▁ { 1 } STRNEWLINE " , 1 , getCount ( keypad , 1 ) ) ; Console . Write ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ { 0 } : ▁ { 1 } STRNEWLINE " , 2 , getCount ( keypad , 2 ) ) ; Console . Write ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ { 0 } : ▁ { 1 } STRNEWLINE " , 3 , getCount ( keypad , 3 ) ) ; Console . Write ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ { 0 } : ▁ { 1 } STRNEWLINE " , 4 , getCount ( keypad , 4 ) ) ; Console . Write ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ { 0 } : ▁ { 1 } STRNEWLINE " , 5 , getCount ( keypad , 5 ) ) ; } }
static int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ? 1 : 0 ; if ( sum == 0 ) return 1 ;
int ans = 0 ;
for ( int i = 0 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
static int finalCount ( int n , int sum ) {
int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
public static void Main ( ) { int n = 2 , sum = 5 ; Console . Write ( finalCount ( n , sum ) ) ; } }
static int [ , ] lookup = new int [ 101 , 501 ] ;
static int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ? 1 : 0 ;
if ( lookup [ n , sum ] != - 1 ) return lookup [ n , sum ] ;
int ans = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return lookup [ n , sum ] = ans ; }
static int finalCount ( int n , int sum ) {
for ( int i = 0 ; i <= 100 ; ++ i ) { for ( int j = 0 ; j <= 500 ; ++ j ) { lookup [ i , j ] = - 1 ; } }
int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
public static void Main ( ) { int n = 3 , sum = 5 ; Console . Write ( finalCount ( n , sum ) ) ; } }
using System ; class GFG { private static void findCount ( int n , int sum ) {
int start = ( int ) Math . Pow ( 10 , n - 1 ) ; int end = ( int ) Math . Pow ( 10 , n ) - 1 ; int count = 0 ; int i = start ; while ( i < end ) { int cur = 0 ; int temp = i ; while ( temp != 0 ) { cur += temp % 10 ; temp = temp / 10 ; } if ( cur == sum ) { count ++ ; i += 9 ; } else i ++ ; } Console . WriteLine ( count ) ; }
public static void Main ( ) { int n = 3 ; int sum = 5 ; findCount ( n , sum ) ; } }
using System ; class GFG { static int countNonDecreasing ( int n ) {
int [ , ] dp = new int [ 10 , n + 1 ] ;
for ( int i = 0 ; i < 10 ; i ++ ) dp [ i , 1 ] = 1 ;
for ( int digit = 0 ; digit <= 9 ; digit ++ ) {
for ( int len = 2 ; len <= n ; len ++ ) {
for ( int x = 0 ; x <= digit ; x ++ ) dp [ digit , len ] += dp [ x , len - 1 ] ; } } int count = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) count += dp [ i , n ] ; return count ; }
public static void Main ( ) { int n = 3 ; Console . WriteLine ( countNonDecreasing ( n ) ) ; } }
using System ; class GFG { static long countNonDecreasing ( int n ) { int N = 10 ;
long count = 1 ; for ( int i = 1 ; i <= n ; i ++ ) { count *= ( N + i - 1 ) ; count /= i ; } return count ; }
public static void Main ( ) { int n = 3 ; Console . WriteLine ( countNonDecreasing ( n ) ) ; } }
static int getMinSquares ( int n ) {
if ( n <= 3 ) return n ;
int res = n ;
for ( int x = 1 ; x <= n ; x ++ ) { int temp = x * x ; if ( temp > n ) break ; else res = Math . Min ( res , 1 + getMinSquares ( n - temp ) ) ; } return res ; }
public static void Main ( ) { Console . Write ( getMinSquares ( 6 ) ) ; } }
static int getMinSquares ( int n ) {
if ( n <= 3 ) return n ;
int [ ] dp = new int [ n + 1 ] ;
dp [ 0 ] = 0 ; dp [ 1 ] = 1 ; dp [ 2 ] = 2 ; dp [ 3 ] = 3 ;
for ( int i = 4 ; i <= n ; i ++ ) {
dp [ i ] = i ;
for ( int x = 1 ; x <= Math . Ceiling ( Math . Sqrt ( i ) ) ; x ++ ) { int temp = x * x ; if ( temp > i ) break ; else dp [ i ] = Math . Min ( dp [ i ] , 1 + dp [ i - temp ] ) ; } }
int res = dp [ n ] ; return res ; }
public static void Main ( String [ ] args ) { Console . Write ( getMinSquares ( 6 ) ) ; } }
static int minCoins ( int [ ] coins , int m , int V ) {
if ( V == 0 ) return 0 ;
int res = int . MaxValue ;
for ( int i = 0 ; i < m ; i ++ ) { if ( coins [ i ] <= V ) { int sub_res = minCoins ( coins , m , V - coins [ i ] ) ;
if ( sub_res != int . MaxValue && sub_res + 1 < res ) res = sub_res + 1 ; } } return res ; }
public static void Main ( ) { int [ ] coins = { 9 , 6 , 5 , 1 } ; int m = coins . Length ; int V = 11 ; Console . Write ( " Minimum ▁ coins ▁ required ▁ is ▁ " + minCoins ( coins , m , V ) ) ; } }
static int minCoins ( int [ ] coins , int m , int V ) {
int [ ] table = new int [ V + 1 ] ;
table [ 0 ] = 0 ;
for ( int i = 1 ; i <= V ; i ++ ) table [ i ] = int . MaxValue ;
for ( int i = 1 ; i <= V ; i ++ ) {
for ( int j = 0 ; j < m ; j ++ ) if ( coins [ j ] <= i ) { int sub_res = table [ i - coins [ j ] ] ; if ( sub_res != int . MaxValue && sub_res + 1 < table [ i ] ) table [ i ] = sub_res + 1 ; } } return table [ V ] ; }
static public void Main ( ) { int [ ] coins = { 9 , 6 , 5 , 1 } ; int m = coins . Length ; int V = 11 ; Console . WriteLine ( " Minimum ▁ coins ▁ required ▁ is ▁ " + minCoins ( coins , m , V ) ) ; } }
using System ; class GFG { static int superSeq ( String X , String Y , int m , int n ) { if ( m == 0 ) return n ; if ( n == 0 ) return m ; if ( X [ m - 1 ] == Y [ n - 1 ] ) return 1 + superSeq ( X , Y , m - 1 , n - 1 ) ; return 1 + Math . Min ( superSeq ( X , Y , m - 1 , n ) , superSeq ( X , Y , m , n - 1 ) ) ; }
public static void Main ( ) { String X = " AGGTAB " ; String Y = " GXTXAYB " ; Console . WriteLine ( " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is : ▁ " + superSeq ( X , Y , X . Length , Y . Length ) ) ; } }
static int superSeq ( String X , String Y , int m , int n ) { int [ , ] dp = new int [ m + 1 , n + 1 ] ;
for ( int i = 0 ; i <= m ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) {
if ( i == 0 ) dp [ i , j ] = j ; else if ( j == 0 ) dp [ i , j ] = i ; else if ( X [ i - 1 ] == Y [ j - 1 ] ) dp [ i , j ] = 1 + dp [ i - 1 , j - 1 ] ; else dp [ i , j ] = 1 + Math . Min ( dp [ i - 1 , j ] , dp [ i , j - 1 ] ) ; } } return dp [ m , n ] ; }
public static void Main ( ) { String X = " AGGTAB " ; String Y = " GXTXAYB " ; Console . WriteLine ( " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ " + superSeq ( X , Y , X . Length , Y . Length ) ) ; } }
static int sumOfDigitsFrom1ToN ( int n ) {
int result = 0 ;
for ( int x = 1 ; x <= n ; x ++ ) result += sumOfDigits ( x ) ; return result ; }
static int sumOfDigits ( int x ) { int sum = 0 ; while ( x != 0 ) { sum += x % 10 ; x = x / 10 ; } return sum ; }
public static void Main ( ) { int n = 328 ; Console . WriteLine ( " Sum ▁ of ▁ digits " + " ▁ in ▁ numbers ▁ from ▁ 1 ▁ to ▁ " + n + " ▁ is ▁ " + sumOfDigitsFrom1ToN ( n ) ) ; } }
static int sumOfDigitsFrom1ToN ( int n ) {
if ( n < 10 ) return ( n * ( n + 1 ) / 2 ) ;
int d = ( int ) ( Math . Log ( n ) / Math . Log ( 10 ) ) ;
int [ ] a = new int [ d + 1 ] ; a [ 0 ] = 0 ; a [ 1 ] = 45 ; for ( int i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * ( int ) ( Math . Ceiling ( Math . Pow ( 10 , i - 1 ) ) ) ;
int p = ( int ) ( Math . Ceiling ( Math . Pow ( 10 , d ) ) ) ;
int msd = n / p ;
return ( msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToN ( n % p ) ) ; }
public static void Main ( ) { int n = 328 ; Console . WriteLine ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ " + " from ▁ 1 ▁ to ▁ " + n + " ▁ is ▁ " + sumOfDigitsFrom1ToN ( n ) ) ; } }
static int sumOfDigitsFrom1ToNUtil ( int n , int [ ] a ) { if ( n < 10 ) return ( n * ( n + 1 ) / 2 ) ; int d = ( int ) ( Math . Log10 ( n ) ) ; int p = ( int ) ( Math . Ceiling ( Math . Pow ( 10 , d ) ) ) ; int msd = n / p ; return ( msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToNUtil ( n % p , a ) ) ; } static int sumOfDigitsFrom1ToN ( int n ) { int d = ( int ) ( Math . Log10 ( n ) ) ; int [ ] a = new int [ d + 1 ] ; a [ 0 ] = 0 ; a [ 1 ] = 45 ; for ( int i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * ( int ) ( Math . Ceiling ( Math . Pow ( 10 , i - 1 ) ) ) ; return sumOfDigitsFrom1ToNUtil ( n , a ) ; }
public static void Main ( String [ ] args ) { int n = 328 ; Console . WriteLine ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ " + " from ▁ 1 ▁ to ▁ " + n + " ▁ is ▁ " + sumOfDigitsFrom1ToN ( n ) ) ; } }
static int countWays ( int N ) {
if ( N == 1 )
return 4 ;
int countB = 1 , countS = 1 , prev_countB , prev_countS ;
for ( int i = 2 ; i <= N ; i ++ ) { prev_countB = countB ; prev_countS = countS ; countS = prev_countB + prev_countS ; countB = prev_countS ; }
int result = countS + countB ;
return ( result * result ) ; }
public static void Main ( ) { int N = 3 ; Console . Write ( countWays ( N ) ) ; } }
static int findoptimal ( int N ) {
if ( N <= 6 ) return N ;
int [ ] screen = new int [ N ] ;
int b ;
int n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = 0 ;
for ( b = n - 3 ; b >= 1 ; b -- ) {
int curr = ( n - b - 1 ) * screen [ b - 1 ] ; if ( curr > screen [ n - 1 ] ) screen [ n - 1 ] = curr ; } } return screen [ N - 1 ] ; }
public static void Main ( String [ ] args ) { int N ;
for ( N = 1 ; N <= 20 ; N ++ ) Console . WriteLine ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with ▁ { 0 } ▁ keystrokes ▁ is ▁ { 1 } STRNEWLINE " , N , findoptimal ( N ) ) ; } }
static int findoptimal ( int N ) {
if ( N <= 6 ) return N ;
int [ ] screen = new int [ N ] ;
int n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = Math . Max ( 2 * screen [ n - 4 ] , Math . Max ( 3 * screen [ n - 5 ] , 4 * screen [ n - 6 ] ) ) ; } return screen [ N - 1 ] ; }
public static void Main ( String [ ] args ) { int N ;
for ( N = 1 ; N <= 20 ; N ++ ) Console . Write ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with " + " ▁ { 0 } ▁ keystrokes ▁ is ▁ { 1 } STRNEWLINE " , N , findoptimal ( N ) ) ; } }
static int power ( int x , int y ) { int temp ; if ( y == 0 ) return 1 ; temp = power ( x , y / 2 ) ; if ( y % 2 == 0 ) return temp * temp ; else return x * temp * temp ; }
using System ; class GFG { public static int power ( int x , int y ) {
if ( y == 0 ) return 1 ;
if ( x == 0 ) return 0 ;
return x * power ( x , y - 1 ) ; }
public static void Main ( String [ ] args ) { int x = 2 ; int y = 3 ; Console . WriteLine ( power ( x , y ) ) ; } }
using System ; public class GFG { public static int power ( int x , int y ) {
return ( int ) Math . Pow ( x , y ) ; }
static public void Main ( ) { int x = 2 ; int y = 3 ; Console . WriteLine ( power ( x , y ) ) ; } }
static double area ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 ) { return Math . Abs ( ( x1 * ( y2 - y3 ) + x2 * ( y3 - y1 ) + x3 * ( y1 - y2 ) ) / 2.0 ) ; }
static bool isInside ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 , int x , int y ) {
double A = area ( x1 , y1 , x2 , y2 , x3 , y3 ) ;
double A1 = area ( x , y , x2 , y2 , x3 , y3 ) ;
double A2 = area ( x1 , y1 , x , y , x3 , y3 ) ;
double A3 = area ( x1 , y1 , x2 , y2 , x , y ) ;
return ( A == A1 + A2 + A3 ) ; }
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) Console . WriteLine ( " Inside " ) ; else Console . WriteLine ( " Not ▁ Inside " ) ; } }
using System ; class GFG { public static int preIndex = 0 ; public virtual void printPost ( int [ ] arr , int [ ] pre , int inStrt , int inEnd ) { if ( inStrt > inEnd ) { return ; }
int inIndex = search ( arr , inStrt , inEnd , pre [ preIndex ++ ] ) ;
printPost ( arr , pre , inStrt , inIndex - 1 ) ;
printPost ( arr , pre , inIndex + 1 , inEnd ) ;
Console . Write ( arr [ inIndex ] + " ▁ " ) ; } public virtual int search ( int [ ] arr , int startIn , int endIn , int data ) { int i = 0 ; for ( i = startIn ; i < endIn ; i ++ ) { if ( arr [ i ] == data ) { return i ; } } return i ; }
public static void Main ( string [ ] ars ) { int [ ] arr = new int [ ] { 4 , 2 , 5 , 1 , 3 , 6 } ; int [ ] pre = new int [ ] { 1 , 2 , 4 , 5 , 3 , 6 } ; int len = arr . Length ; GFG tree = new GFG ( ) ; tree . printPost ( arr , pre , 0 , len - 1 ) ; } }
public class Node { public int key ; public Node left , right ; public Node ( int key ) { this . key = key ; left = right = null ; } }
public class Res { public int r = int . MinValue ; } public class BinaryTree { public Node root ;
public virtual int maxDiffUtil ( Node t , Res res ) {
if ( t == null ) { return int . MaxValue ; }
if ( t . left == null && t . right == null ) { return t . key ; }
int val = Math . Min ( maxDiffUtil ( t . left , res ) , maxDiffUtil ( t . right , res ) ) ;
res . r = Math . Max ( res . r , t . key - val ) ;
return Math . Min ( val , t . key ) ; }
public virtual int maxDiff ( Node root ) {
Res res = new Res ( ) ; maxDiffUtil ( root , res ) ; return res . r ; }
public virtual void inorder ( Node root ) { if ( root != null ) { inorder ( root . left ) ; Console . Write ( root . key + " " ) ; inorder ( root . right ) ; } }
tree . root = new Node ( 8 ) ; tree . root . left = new Node ( 3 ) ; tree . root . left . left = new Node ( 1 ) ; tree . root . left . right = new Node ( 6 ) ; tree . root . left . right . left = new Node ( 4 ) ; tree . root . left . right . right = new Node ( 7 ) ; tree . root . right = new Node ( 10 ) ; tree . root . right . right = new Node ( 14 ) ; tree . root . right . right . left = new Node ( 13 ) ; Console . WriteLine ( " Maximum ▁ difference ▁ between ▁ a ▁ node ▁ and " + " ▁ its ▁ ancestor ▁ is ▁ : ▁ " + tree . maxDiff ( tree . root ) ) ; } }
static float getAvg ( float prev_avg , float x , int n ) { return ( prev_avg * n + x ) / ( n + 1 ) ; }
static void streamAvg ( float [ ] arr , int n ) { float avg = 0 ; for ( int i = 0 ; i < n ; i ++ ) { avg = getAvg ( avg , arr [ i ] , i ) ; Console . WriteLine ( " Average ▁ of ▁ { 0 } ▁ " + " numbers ▁ is ▁ { 1 } " , i + 1 , avg ) ; } return ; }
public static void Main ( String [ ] args ) { float [ ] arr = { 10 , 20 , 30 , 40 , 50 , 60 } ; int n = arr . Length ; streamAvg ( arr , n ) ; } }
using System ; namespace prime { public class GFG { public static void SieveOfEratosthenes ( int n ) {
bool [ ] prime = new bool [ n + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) prime [ i ] = true ; for ( int p = 2 ; p * p <= n ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * p ; i <= n ; i += p ) prime [ i ] = false ; } }
for ( int i = 2 ; i <= n ; i ++ ) { if ( prime [ i ] == true ) Console . Write ( i + " ▁ " ) ; } }
public static void Main ( ) { int n = 30 ; Console . WriteLine ( " Following ▁ are ▁ the ▁ prime ▁ numbers " ) ; Console . WriteLine ( " smaller ▁ than ▁ or ▁ equal ▁ to ▁ " + n ) ; SieveOfEratosthenes ( n ) ; } } }
static int maximumNumberDistinctPrimeRange ( int m , int n ) {
long [ ] factorCount = new long [ n + 1 ] ;
bool [ ] prime = new bool [ n + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) { factorCount [ i ] = 0 ;
prime [ i ] = true ; } for ( int i = 2 ; i <= n ; i ++ ) {
if ( prime [ i ] == true ) {
factorCount [ i ] = 1 ;
for ( int j = i * 2 ; j <= n ; j += i ) {
factorCount [ j ] ++ ;
prime [ j ] = false ; } } }
int max = ( int ) factorCount [ m ] ; int num = m ;
for ( int i = m ; i <= n ; i ++ ) {
if ( factorCount [ i ] > max ) { max = ( int ) factorCount [ i ] ; num = i ; } } return num ; }
public static void Main ( ) { int m = 4 , n = 6 ;
Console . WriteLine ( maximumNumberDistinctPrimeRange ( m , n ) ) ; } }
static int binomialCoeff ( int n , int k ) { int res = 1 ; if ( k > n - k ) k = n - k ; for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
static void printPascal ( int n ) {
for ( int line = 0 ; line < n ; line ++ ) {
for ( int i = 0 ; i <= line ; i ++ ) Console . Write ( binomialCoeff ( line , i ) + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int n = 7 ; printPascal ( n ) ; } }
static int findCeil ( int [ ] arr , int r , int l , int h ) { int mid ; while ( l < h ) {
mid = l + ( ( h - l ) >> 1 ) ; if ( r > arr [ mid ] ) l = mid + 1 ; else h = mid ; } return ( arr [ l ] >= r ) ? l : - 1 ; }
static int myRand ( int [ ] arr , int [ ] freq , int n ) {
int [ ] prefix = new int [ n ] ; int i ; prefix [ 0 ] = freq [ 0 ] ; for ( i = 1 ; i < n ; ++ i ) prefix [ i ] = prefix [ i - 1 ] + freq [ i ] ;
Random rand = new Random ( ) ; int r = ( ( int ) ( rand . Next ( ) * ( 323567 ) ) % prefix [ n - 1 ] ) + 1 ;
int indexc = findCeil ( prefix , r , 0 , n - 1 ) ; return arr [ indexc ] ; }
static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 } ; int [ ] freq = { 10 , 5 , 20 , 100 } ; int i , n = arr . Length ;
for ( i = 0 ; i < 5 ; i ++ ) Console . WriteLine ( myRand ( arr , freq , n ) ) ; } }
static bool isPerfectSquare ( int x ) { int s = ( int ) Math . Sqrt ( x ) ; return ( s * s == x ) ; }
static bool isFibonacci ( int n ) {
return isPerfectSquare ( 5 * n * n + 4 ) || isPerfectSquare ( 5 * n * n - 4 ) ; }
public static void Main ( ) { for ( int i = 1 ; i <= 10 ; i ++ ) Console . WriteLine ( isFibonacci ( i ) ? i + " ▁ is ▁ a ▁ Fibonacci ▁ Number " : i + " ▁ is ▁ a ▁ not ▁ Fibonacci ▁ Number " ) ; } }
static int findTrailingZeros ( int n ) {
int count = 0 ;
for ( int i = 5 ; n / i >= 1 ; i *= 5 ) count += n / i ; return count ; }
public static void Main ( ) { int n = 100 ; Console . WriteLine ( " Count ▁ of ▁ trailing ▁ 0s ▁ in ▁ " + n + " ! ▁ is ▁ " + findTrailingZeros ( n ) ) ; } }
static int catalan ( int n ) {
if ( n <= 1 ) { return 1 ; }
int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) { res += catalan ( i ) * catalan ( n - i - 1 ) ; } return res ; }
public static void Main ( ) { for ( int i = 0 ; i < 10 ; i ++ ) Console . Write ( catalan ( i ) + " ▁ " ) ; } }
using System ; class GFG { static uint catalanDP ( uint n ) {
uint [ ] catalan = new uint [ n + 2 ] ;
catalan [ 0 ] = catalan [ 1 ] = 1 ;
for ( uint i = 2 ; i <= n ; i ++ ) { catalan [ i ] = 0 ; for ( uint j = 0 ; j < i ; j ++ ) catalan [ i ] += catalan [ j ] * catalan [ i - j - 1 ] ; }
return catalan [ n ] ; }
static void Main ( ) { for ( uint i = 0 ; i < 10 ; i ++ ) Console . Write ( catalanDP ( i ) + " ▁ " ) ; } }
static long binomialCoeff ( int n , int k ) { long res = 1 ;
if ( k > n - k ) { k = n - k ; }
for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
static long catalan ( int n ) {
long c = binomialCoeff ( 2 * n , n ) ;
return c / ( n + 1 ) ; }
public static void Main ( ) { for ( int i = 0 ; i < 10 ; i ++ ) { Console . Write ( catalan ( i ) + " ▁ " ) ; } } }
static void catalan ( int n ) { int cat_ = 1 ;
Console . Write ( cat_ + " ▁ " ) ;
for ( int i = 1 ; i < n ; i ++ ) {
cat_ *= ( 4 * i - 2 ) ; cat_ /= ( i + 1 ) ; Console . Write ( cat_ + " ▁ " ) ; } }
public static void Main ( String [ ] args ) { int n = 5 ;
catalan ( n ) ; } }
using System ; class GFG { static void printString ( int n ) { int [ ] arr = new int [ 10000 ] ; int i = 0 ;
while ( n > 0 ) { arr [ i ] = n % 26 ; n = n / 26 ; i ++ ; }
for ( int j = 0 ; j < i - 1 ; j ++ ) { if ( arr [ j ] <= 0 ) { arr [ j ] += 26 ; arr [ j + 1 ] = arr [ j + 1 ] - 1 ; } } for ( int j = i ; j >= 0 ; j -- ) { if ( arr [ j ] > 0 ) Console . Write ( ( char ) ( ' A ' + arr [ j ] - 1 ) ) ; } Console . WriteLine ( ) ; }
public static void Main ( String [ ] args ) { printString ( 26 ) ; printString ( 51 ) ; printString ( 52 ) ; printString ( 80 ) ; printString ( 676 ) ; printString ( 702 ) ; printString ( 705 ) ; } }
static int getInvCount ( int [ , ] arr ) { int inv_count = 0 ; for ( int i = 0 ; i < 3 - 1 ; i ++ ) for ( int j = i + 1 ; j < 3 ; j ++ )
if ( arr [ j , i ] > 0 && arr [ j , i ] > arr [ i , j ] ) inv_count ++ ; return inv_count ; }
static bool isSolvable ( int [ , ] puzzle ) {
int invCount = getInvCount ( puzzle ) ;
return ( invCount % 2 == 0 ) ; }
static void Main ( ) { int [ , ] puzzle = new int [ 3 , 3 ] { { 1 , 8 , 2 } , { 0 , 4 , 3 } , { 7 , 6 , 5 } } ; if ( isSolvable ( puzzle ) ) Console . WriteLine ( " Solvable " ) ; else Console . WriteLine ( " Not ▁ Solvable " ) ; } }
static double find ( double p ) { return Math . Ceiling ( Math . Sqrt ( 2 * 365 * Math . Log ( 1 / ( 1 - p ) ) ) ) ; }
public static void Main ( ) { Console . Write ( find ( 0.70 ) ) ; } }
static int countSolutions ( int n ) { int res = 0 ; for ( int x = 0 ; x * x < n ; x ++ ) for ( int y = 0 ; x * x + y * y < n ; y ++ ) res ++ ; return res ; }
public static void Main ( ) { Console . WriteLine ( " Total ▁ Number ▁ of ▁ " + " distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " + countSolutions ( 6 ) ) ; } }
static int countSolutions ( int n ) { int x = 0 , yCount , res = 0 ;
for ( yCount = 0 ; yCount * yCount < n ; yCount ++ ) ;
while ( yCount != 0 ) {
res += yCount ;
x ++ ;
while ( yCount != 0 && ( x * x + ( yCount - 1 ) * ( yCount - 1 ) >= n ) ) yCount -- ; } return res ; }
public static void Main ( ) { Console . WriteLine ( " Total ▁ Number ▁ of ▁ " + " distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " + countSolutions ( 6 ) ) ; } }
using System ; class GFG { static int MAX_ITER = 1000000 ;
static double func ( double x ) { return ( x * x * x - x * x + 2 ) ; }
static void regulaFalsi ( double a , double b ) { if ( func ( a ) * func ( b ) >= 0 ) { Console . WriteLine ( " You ▁ have ▁ not ▁ assumed ▁ right ▁ a ▁ and ▁ b " ) ; }
double c = a ; for ( int i = 0 ; i < MAX_ITER ; i ++ ) {
c = ( a * func ( b ) - b * func ( a ) ) / ( func ( b ) - func ( a ) ) ;
if ( func ( c ) == 0 ) break ;
else if ( func ( c ) * func ( a ) < 0 ) = c ; else a = c ; } Console . WriteLine ( " The ▁ value ▁ of ▁ root ▁ is ▁ : ▁ " + ( int ) c ) ; }
double a = - 200 , b = 300 ; regulaFalsi ( a , b ) ; } }
using System ; class GFG { static double EPSILON = 0.001 ;
static double func ( double x ) { return x * x * x - x * x + 2 ; }
static double derivFunc ( double x ) { return 3 * x * x - 2 * x ; }
static void newtonRaphson ( double x ) { double h = func ( x ) / derivFunc ( x ) ; while ( Math . Abs ( h ) >= EPSILON ) { h = func ( x ) / derivFunc ( x ) ;
x = x - h ; } Console . Write ( " The ▁ value ▁ of ▁ the " + " ▁ root ▁ is ▁ : ▁ " + Math . Round ( x * 100.0 ) / 100.0 ) ; }
double x0 = - 20 ; newtonRaphson ( x0 ) ; } }
static bool oppositeSigns ( int x , int y ) { return ( ( x ^ y ) < 0 ) ; }
public static void Main ( ) { int x = 100 , y = - 100 ; if ( oppositeSigns ( x , y ) == true ) Console . Write ( " Signs ▁ are ▁ opposite " ) ; else Console . Write ( " Signs ▁ are ▁ not ▁ opposite " ) ; } }
static int countSetBits ( int n ) {
int bitCount = 0 ; for ( int i = 1 ; i <= n ; i ++ ) bitCount += countSetBitsUtil ( i ) ; return bitCount ; }
static int countSetBitsUtil ( int x ) { if ( x <= 0 ) return 0 ; return ( x % 2 == 0 ? 0 : 1 ) + countSetBitsUtil ( x / 2 ) ; }
public static void Main ( ) { int n = 4 ; Console . Write ( " Total ▁ set ▁ bit ▁ count ▁ is ▁ " ) ; Console . Write ( countSetBits ( n ) ) ; } }
using System ; class GFG { static int countSetBits ( int n ) { int i = 0 ;
int ans = 0 ;
while ( ( 1 << i ) <= n ) {
bool k = false ;
int change = 1 << i ;
for ( int j = 0 ; j <= n ; j ++ ) { if ( k == true ) ans += 1 ; else ans += 0 ; if ( change == 1 ) {
k = ! k ;
change = 1 << i ; } else { change -- ; } }
i ++ ; } return ans ; }
static void Main ( ) { int n = 17 ; Console . Write ( countSetBits ( n ) ) ; } }
static int getSetBitsFromOneToN ( int N ) { int two = 2 , ans = 0 ; int n = N ; while ( n != 0 ) { ans += ( N / two ) * ( two >> 1 ) ; if ( ( N & ( two - 1 ) ) > ( two >> 1 ) - 1 ) ans += ( N & ( two - 1 ) ) - ( two >> 1 ) + 1 ; two <<= 1 ; n >>= 1 ; } return ans ; }
using System ; class GFG { static int swapBits ( int num , int p1 , int p2 , int n ) { int shift1 , shift2 , value1 , value2 ; while ( n -- > 0 ) {
shift1 = 1 << p1 ;
shift2 = 1 << p2 ;
value1 = ( ( num & shift1 ) ) ; value2 = ( ( num & shift2 ) ) ;
if ( ( value1 == 0 && value2 != 0 ) || ( value2 == 0 && value1 != 0 ) ) {
if ( value1 != 0 ) {
num = num & ( ~ shift1 ) ;
num = num | shift2 ; }
else {
num = num & ( ~ shift2 ) ;
num = num | shift1 ; } } p1 ++ ; p2 ++ ; }
return num ; }
static void Main ( ) { int res = swapBits ( 28 , 0 , 3 , 2 ) ; Console . WriteLine ( " Result ▁ = ▁ " + res ) ; } }
static int Add ( int x , int y ) { if ( y == 0 ) return x ; else return Add ( x ^ y , ( x & y ) << 1 ) ; }
using System ; class GFG { static int CHAR_BIT = 8 ;
static int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHAR_BIT - 1 ) ) ) ; }
static int smallest ( int x , int y , int z ) { return Math . Min ( x , Math . Min ( y , z ) ) ; }
static void Main ( ) { int x = 12 , y = 15 , z = 5 ; Console . WriteLine ( " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ " + smallest ( x , y , z ) ) ; } }
static int smallest ( int x , int y , int z ) {
if ( ( y / x ) != 1 ) return ( ( y / z ) != 1 ) ? y : z ; return ( ( x / z ) != 1 ) ? x : z ; }
public static void Main ( ) { int x = 78 , y = 88 , z = 68 ; Console . Write ( " Minimum ▁ of ▁ 3 ▁ numbers " + " ▁ is ▁ { 0 } " , smallest ( x , y , z ) ) ; } }
static int snoob ( int x ) { int rightOne , nextHigherOneBit , rightOnesPattern , next = 0 ; if ( x > 0 ) {
rightOne = x & - x ;
nextHigherOneBit = x + rightOne ;
rightOnesPattern = x ^ nextHigherOneBit ;
rightOnesPattern = ( rightOnesPattern ) / rightOne ;
rightOnesPattern >>= 2 ;
next = nextHigherOneBit | rightOnesPattern ; } return next ; }
static void Main ( ) { int x = 156 ; Console . WriteLine ( " Next ▁ higher ▁ number ▁ with ▁ same " + " number ▁ of ▁ set ▁ bits ▁ is ▁ " + snoob ( x ) ) ; } }
using System ; class GFG { static int multiplyWith3Point5 ( int x ) { return ( x << 1 ) + x + ( x >> 1 ) ; }
public static void Main ( ) { int x = 2 ; Console . Write ( multiplyWith3Point5 ( x ) ) ; } }
static int multiplyWith3Point5 ( int x ) { int r = 0 ;
int x1Shift = x << 1 ; int x2Shifts = x << 2 ; r = ( x ^ x1Shift ) ^ x2Shifts ; int c = ( x & x1Shift ) | ( x & x2Shifts ) | ( x1Shift & x2Shifts ) ; while ( c > 0 ) { c <<= 1 ; int t = r ; r ^= c ; c &= t ; }
r = r >> 1 ; return r ; }
public static void Main ( string [ ] args ) { Console . WriteLine ( multiplyWith3Point5 ( 5 ) ) ; } }
using System ; class GFG { static bool isPowerOfFour ( int n ) { return n != 0 && ( ( n & ( n - 1 ) ) == 0 ) && ( n & 0xAAAAAAAA ) == 0 ; }
static void Main ( ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) ) Console . WriteLine ( " { 0 } ▁ is ▁ a ▁ power ▁ of ▁ 4" , test_no ) ; else Console . WriteLine ( " { 0 } ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" , test_no ) ; } }
using System ; class GFG { static double logn ( int n , int r ) { return Math . Log ( n ) / Math . Log ( r ) ; } static bool isPowerOfFour ( int n ) {
if ( n == 0 ) return false ; return Math . Floor ( logn ( n , 4 ) ) == Math . Ceiling ( logn ( n , 4 ) ) ; }
public static void Main ( String [ ] args ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) ) Console . Write ( test_no + " ▁ is ▁ a ▁ power ▁ of ▁ 4" ) ; else Console . Write ( test_no + " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ) ; } }
using System ; class GFG { public class INT { public int data ; public INT ( int d ) { data = d ; } }
public static void findPostOrderUtil ( int [ ] pre , int n , int minval , int maxval , INT preIndex ) {
if ( preIndex . data == n ) { return ; }
if ( pre [ preIndex . data ] < minval pre [ preIndex . data ] > maxval ) { return ; }
int val = pre [ preIndex . data ] ; preIndex . data ++ ;
findPostOrderUtil ( pre , n , minval , val , preIndex ) ;
findPostOrderUtil ( pre , n , val , maxval , preIndex ) ; Console . Write ( val + " ▁ " ) ; }
public static void findPostOrder ( int [ ] pre , int n ) {
INT preIndex = new INT ( 0 ) ; findPostOrderUtil ( pre , n , int . MinValue , int . MaxValue , preIndex ) ; }
public static void Main ( string [ ] args ) { int [ ] pre = new int [ ] { 40 , 30 , 35 , 80 , 100 } ; int n = pre . Length ;
findPostOrder ( pre , n ) ; } }
static uint getModulo ( uint n , uint d ) { return ( n & ( d - 1 ) ) ; }
static public void Main ( ) { uint n = 6 ;
uint d = 4 ; Console . WriteLine ( n + " ▁ moduo ▁ " + d + " ▁ is ▁ " + getModulo ( n , d ) ) ; } }
using System ; class GFG { static int CHAR_BIT = 8 ;
static int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHAR_BIT - 1 ) ) ) ; }
static int max ( int x , int y ) { return x - ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHAR_BIT - 1 ) ) ) ; }
static void Main ( ) { int x = 15 ; int y = 6 ; Console . WriteLine ( " Minimum ▁ of ▁ " + x + " ▁ and ▁ " + y + " ▁ is ▁ " + min ( x , y ) ) ; Console . WriteLine ( " Maximum ▁ of ▁ " + x + " ▁ and ▁ " + y + " ▁ is ▁ " + max ( x , y ) ) ; } }
public static int absbit32 ( int x , int y ) { int sub = x - y ; int mask = ( sub >> 31 ) ; return ( sub ^ mask ) - mask ; }
public static int max ( int x , int y ) { int abs = absbit32 ( x , y ) ; return ( x + y + abs ) / 2 ; }
public static int min ( int x , int y ) { int abs = absbit32 ( x , y ) ; return ( x + y - abs ) / 2 ; }
public static void Main ( String [ ] args ) { Console . WriteLine ( max ( 2 , 3 ) ) ; Console . WriteLine ( max ( 2 , - 3 ) ) ; Console . WriteLine ( max ( - 2 , - 3 ) ) ; Console . WriteLine ( min ( 2 , 3 ) ) ; Console . WriteLine ( min ( 2 , - 3 ) ) ; Console . WriteLine ( min ( - 2 , - 3 ) ) ; } }
static void UniqueNumbers2 ( int [ ] arr , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
sum = ( sum ^ arr [ i ] ) ; }
sum = ( sum & - sum ) ;
int sum1 = 0 ; int sum2 = 0 ;
for ( int i = 0 ; i < arr . Length ; i ++ ) {
if ( ( arr [ i ] & sum ) > 0 ) {
sum1 = ( sum1 ^ arr [ i ] ) ; } else {
sum2 = ( sum2 ^ arr [ i ] ) ; } }
Console . WriteLine ( " The ▁ non - repeating ▁ " + " elements ▁ are ▁ " + sum1 + " ▁ and ▁ " + sum2 ) ; }
static public void Main ( ) { int [ ] arr = { 2 , 3 , 7 , 9 , 11 , 2 , 3 , 11 } ; int n = arr . Length ; UniqueNumbers2 ( arr , n ) ; } }
static int getOddOccurrence ( int [ ] arr , int arr_size ) { for ( int i = 0 ; i < arr_size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < arr_size ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; } if ( count % 2 != 0 ) return arr [ i ] ; } return - 1 ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 } ; int n = arr . Length ;
Console . Write ( getOddOccurrence ( arr , n ) ) ; } }
static int getOddOccurrence ( int [ ] arr , int n ) { Dictionary < int , int > hmap = new Dictionary < int , int > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( hmap . ContainsKey ( arr [ i ] ) ) { int val = hmap [ arr [ i ] ] ;
hmap . Remove ( arr [ i ] ) ; hmap . Add ( arr [ i ] , val + 1 ) ; }
hmap . Add ( arr [ i ] , 1 ) ; }
foreach ( KeyValuePair < int , int > entry in hmap ) { if ( entry . Value % 2 != 0 ) { return entry . Key ; } } return - 1 ; }
public static void Main ( String [ ] args ) { int [ ] arr = new int [ ] { 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 } ; int n = arr . Length ; Console . WriteLine ( getOddOccurrence ( arr , n ) ) ; } }
static int fastPow ( int N , int K ) { if ( K == 0 ) return 1 ; int temp = fastPow ( N , K / 2 ) ; if ( K % 2 == 0 ) return temp * temp ; else return N * temp * temp ; } static int countWays ( int N , int K ) { return K * fastPow ( K - 1 , N - 1 ) ; }
public static void Main ( ) { int N = 3 , K = 3 ; Console . WriteLine ( countWays ( N , K ) ) ; } }
public static int countSetBits ( int n ) {
if ( n == 0 ) return 0 ; else return 1 + countSetBits ( n & ( n - 1 ) ) ; }
int n = 9 ;
Console . WriteLine ( countSetBits ( n ) ) ; } }
static int [ ] BitsSetTable256 = new int [ 256 ] ;
public static void initialize ( ) {
BitsSetTable256 [ 0 ] = 0 ; for ( int i = 0 ; i < 256 ; i ++ ) { BitsSetTable256 [ i ] = ( i & 1 ) + BitsSetTable256 [ i / 2 ] ; } }
public static int countSetBits ( int n ) { return ( BitsSetTable256 [ n & 0xff ] + BitsSetTable256 [ ( n >> 8 ) & 0xff ] + BitsSetTable256 [ ( n >> 16 ) & 0xff ] + BitsSetTable256 [ n >> 24 ] ) ; }
initialize ( ) ; int n = 9 ; Console . Write ( countSetBits ( n ) ) ; } }
public static void Main ( ) { Console . WriteLine ( Convert . ToString ( 4 , 2 ) . Count ( c = > c == '1' ) ) ; Console . WriteLine ( Convert . ToString ( 15 , 2 ) . Count ( c = > c == '1' ) ) ; } }
static int countSetBits ( int N ) { int count = 0 ;
for ( int i = 0 ; i < 4 * 8 ; i ++ ) { if ( ( N & ( 1 << i ) ) != 0 ) count ++ ; } return count ; }
static void Main ( ) { int N = 15 ; Console . WriteLine ( countSetBits ( N ) ) ; } }
public static int countSetBits ( int n ) { int count = 0 ; while ( n != 0 ) { count ++ ; n &= ( n - 1 ) ; } return count ; }
public static int FlippedCount ( int a , int b ) {
return countSetBits ( a ^ b ) ; }
public static void Main ( ) { int a = 10 ; int b = 20 ; Console . WriteLine ( FlippedCount ( a , b ) ) ; } }
static bool powerOf2 ( int n ) {
if ( n == 1 ) return true ;
else if ( n % 2 != 0 n == 0 ) return false ;
return powerOf2 ( n / 2 ) ; }
int n = 64 ;
int m = 12 ; if ( powerOf2 ( n ) ) { Console . Write ( " True " + " STRNEWLINE " ) ; } else { Console . Write ( " False " + " STRNEWLINE " ) ; } if ( powerOf2 ( m ) ) { Console . Write ( " True " ) ; } else { Console . Write ( " False " ) ; } } }
static int PositionRightmostSetbit ( int n ) {
int position = 1 ; int m = 1 ; while ( ( n & m ) == 0 ) {
m = m << 1 ; position ++ ; } return position ; }
static public void Main ( ) { int n = 16 ;
Console . WriteLine ( PositionRightmostSetbit ( n ) ) ; } }
using System ; class GFG { static int INT_SIZE = 32 ; static int Right_most_setbit ( int num ) { int pos = 1 ;
for ( int i = 0 ; i < INT_SIZE ; i ++ ) { if ( ( num & ( 1 << i ) ) == 0 ) pos ++ ; else break ; } return pos ; }
static public void Main ( ) { int num = 18 ; int pos = Right_most_setbit ( num ) ; Console . WriteLine ( pos ) ; } }
public static int Last_set_bit ( int n ) { int p = 1 ;
while ( n > 0 ) {
if ( ( n & 1 ) > 0 ) { return p ; }
p ++ ; n = n >> 1 ; }
return - 1 ; }
public static void Main ( string [ ] args ) { int n = 18 ;
int pos = Last_set_bit ( n ) ; if ( pos != - 1 ) Console . WriteLine ( pos ) ; else Console . WriteLine ( "0" ) ; } }
static void bin ( long n ) { long i ; Console . Write ( "0" ) ; for ( i = 1 << 30 ; i > 0 ; i = i / 2 ) { if ( ( n & i ) != 0 ) { Console . Write ( "1" ) ; } else { Console . Write ( "0" ) ; } } }
static public void Main ( ) { bin ( 7 ) ; Console . WriteLine ( ) ; bin ( 4 ) ; } }
static void bin ( int n ) { if ( n > 1 ) bin ( n >> 1 ) ; Console . Write ( n & 1 ) ; }
public static void Main ( ) { bin ( 131 ) ; Console . WriteLine ( ) ; bin ( 3 ) ; } }
static void swap ( int a , int b ) {
a = ( a & b ) + ( a b ) ;
b = a + ( ~ b ) + 1 ;
a = a + ( ~ b ) + 1 ; Console . Write ( " After ▁ swapping : ▁ a ▁ = ▁ " + a + " , ▁ b ▁ = ▁ " + b ) ; }
static void Main ( ) { int a = 5 , b = 10 ;
swap ( a , b ) ; } }
static bool checkSentence ( char [ ] str ) {
int len = str . Length ;
if ( str [ 0 ] < ' A ' str [ 0 ] > ' Z ' ) return false ;
if ( str [ len - 1 ] != ' . ' ) return false ;
int prev_state = 0 , curr_state = 0 ;
int index = 1 ;
while ( index <= str . Length ) {
if ( str [ index ] >= ' A ' && str [ index ] <= ' Z ' ) curr_state = 0 ;
else if ( str [ index ] == ' ▁ ' ) = 1 ;
else if ( str [ index ] >= ' a ' && [ ] <= ' z ' ) curr_state = 2 ;
else if ( str [ index ] == ' . ' ) = 3 ;
if ( prev_state == curr_state && curr_state != 2 ) return false ; if ( prev_state == 2 && curr_state == 0 ) return false ;
if ( curr_state == 3 && prev_state != 1 ) return ( index + 1 == str . Length ) ; index ++ ;
prev_state = curr_state ; } return false ; }
public static void Main ( String [ ] args ) { String [ ] str = { " I ▁ love ▁ cinema . " , " The ▁ vertex ▁ is ▁ S . " , " I ▁ am ▁ single . " , " My ▁ name ▁ is ▁ KG . " , " I ▁ lovE ▁ cinema . " , " GeeksQuiz . ▁ is ▁ a ▁ quiz ▁ site . " , " I ▁ love ▁ Geeksquiz ▁ and ▁ Geeksforgeeks . " , " ▁ You ▁ are ▁ my ▁ friend . " , " I ▁ love ▁ cinema " } ; int str_size = str . Length ; int i = 0 ; for ( i = 0 ; i < str_size ; i ++ ) { if ( checkSentence ( str [ i ] . ToCharArray ( ) ) ) Console . WriteLine ( " \" " + str [ i ] + " \" " + " ▁ is ▁ correct " ) ; else Console . WriteLine ( " \" " + str [ i ] + " \" " + " ▁ is ▁ incorrect " ) ; } } }
static int maxOnesIndex ( int [ ] arr , int n ) {
int max_count = 0 ;
int max_index = 0 ;
int prev_zero = - 1 ;
int prev_prev_zero = - 1 ;
for ( int curr = 0 ; curr < n ; ++ curr ) {
if ( arr [ curr ] == 0 ) {
if ( curr - prev_prev_zero > max_count ) { max_count = curr - prev_prev_zero ; max_index = prev_zero ; }
prev_prev_zero = prev_zero ; prev_zero = curr ; } }
if ( n - prev_prev_zero > max_count ) max_index = prev_zero ; return max_index ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } ; int n = arr . Length ; Console . Write ( " Index ▁ of ▁ 0 ▁ to ▁ be ▁ replaced ▁ is ▁ " + maxOnesIndex ( arr , n ) ) ; } }
static int findLength ( int [ ] arr , int n ) {
int max_len = 1 ; for ( int i = 0 ; i < n - 1 ; i ++ ) {
int mn = arr [ i ] , mx = arr [ i ] ;
for ( int j = i + 1 ; j < n ; j ++ ) {
mn = Math . Min ( mn , arr [ j ] ) ; mx = Math . Max ( mx , arr [ j ] ) ;
if ( ( mx - mn ) == j - i ) max_len = Math . Max ( max_len , mx - mn + 1 ) ; } }
return max_len ; }
public static void Main ( ) { int [ ] arr = { 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 } ; int n = arr . Length ; Console . WriteLine ( " Length ▁ of ▁ the ▁ longest " + " ▁ contiguous ▁ subarray ▁ is ▁ " + findLength ( arr , n ) ) ; } }
static void printArr ( int [ ] arr , int k ) { for ( int i = 0 ; i < k ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; }
static void printSeqUtil ( int n , int k , int len , int [ ] arr ) {
if ( len == k ) { printArr ( arr , k ) ; return ; }
int i = ( len == 0 ) ? 1 : arr [ len - 1 ] + 1 ;
len ++ ;
while ( i <= n ) { arr [ len - 1 ] = i ; printSeqUtil ( n , k , len , arr ) ; i ++ ; }
len -- ; }
static void printSeq ( int n , int k ) {
int [ ] arr = new int [ k ] ;
int len = 0 ; printSeqUtil ( n , k , len , arr ) ; }
static public void Main ( ) { int k = 3 , n = 7 ; printSeq ( n , k ) ; } }
static bool isSubSequence ( string str1 , string str2 , int m , int n ) {
if ( m == 0 ) return true ; if ( n == 0 ) return false ;
if ( str1 [ m - 1 ] == str2 [ n - 1 ] ) return isSubSequence ( str1 , str2 , m - 1 , n - 1 ) ;
return isSubSequence ( str1 , str2 , m , n - 1 ) ; }
public static void Main ( ) { string str1 = " gksrek " ; string str2 = " geeksforgeeks " ; int m = str1 . Length ; int n = str2 . Length ; bool res = isSubSequence ( str1 , str2 , m , n ) ; if ( res ) Console . Write ( " Yes " ) ; else Console . Write ( " No " ) ; } }
static void segregate0and1 ( int [ ] arr , int n ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 0 ) count ++ ; }
for ( int i = 0 ; i < count ; i ++ ) arr [ i ] = 0 ;
for ( int i = count ; i < n ; i ++ ) arr [ i ] = 1 ; }
static void print ( int [ ] arr , int n ) { Console . WriteLine ( " Array ▁ after ▁ segregation ▁ is ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 0 , 1 , 0 , 1 , 1 , 1 } ; int n = arr . Length ; segregate0and1 ( arr , n ) ; print ( arr , n ) ; } }
static void segregate0and1 ( int [ ] arr ) { int type0 = 0 ; int type1 = arr . Length - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type1 ] = arr [ type1 ] + arr [ type0 ] ; arr [ type0 ] = arr [ type1 ] - arr [ type0 ] ; arr [ type1 ] = arr [ type1 ] - arr [ type0 ] ; type1 -- ; } else { type0 ++ ; } } }
public static void Main ( string [ ] args ) { int [ ] array = new int [ ] { 0 , 1 , 0 , 1 , 1 , 1 } ; segregate0and1 ( array ) ; Console . Write ( " Array ▁ after ▁ segregation ▁ is ▁ " ) ; foreach ( int a in array ) { Console . Write ( a + " ▁ " ) ; } } }
static void find3Numbers ( int [ ] nums ) {
if ( nums . Length < 3 ) { Console . Write ( " No ▁ such ▁ triplet ▁ found " ) ; return ; }
int seq = 1 ;
int min_num = nums [ 0 ] ;
int max_seq = Int32 . MinValue ;
int store_min = min_num ;
for ( int i = 1 ; i < nums . Length ; i ++ ) { if ( nums [ i ] == min_num ) continue ; else if ( nums [ i ] < min_num ) { min_num = nums [ i ] ; continue ; }
else if ( nums [ i ] < max_seq ) {
max_seq = nums [ i ] ;
store_min = min_num ; }
else if ( nums [ i ] > max_seq ) { seq ++ ;
if ( seq == 3 ) { Console . WriteLine ( " Triplet : ▁ " + store_min + " , ▁ " + max_seq + " , ▁ " + nums [ i ] ) ; return ; } max_seq = nums [ i ] ; } }
Console . Write ( " No ▁ such ▁ triplet ▁ found " ) ; }
static void Main ( ) { int [ ] nums = { 1 , 2 , - 1 , 7 , 5 } ;
find3Numbers ( nums ) ; } }
static int maxSubarrayProduct ( int [ ] arr ) {
int result = arr [ 0 ] ; int n = arr . Length ; for ( int i = 0 ; i < n ; i ++ ) { int mul = arr [ i ] ;
for ( int j = i + 1 ; j < n ; j ++ ) {
result = Math . Max ( result , mul ) ; mul *= arr [ j ] ; }
result = Math . Max ( result , mul ) ; } return result ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , - 2 , - 3 , 0 , 7 , - 8 , - 2 } ; Console . Write ( " Maximum ▁ Sub ▁ array ▁ product ▁ is ▁ " + maxSubarrayProduct ( arr ) ) ; } }
public static int maxCircularSum ( int [ ] a , int n ) {
if ( n == 1 ) return a [ 0 ] ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum += a [ i ] ; }
int curr_max = a [ 0 ] , max_so_far = a [ 0 ] , curr_min = a [ 0 ] , min_so_far = a [ 0 ] ;
for ( int i = 1 ; i < n ; i ++ ) {
curr_max = Math . Max ( curr_max + a [ i ] , a [ i ] ) ; max_so_far = Math . Max ( max_so_far , curr_max ) ;
curr_min = Math . Min ( curr_min + a [ i ] , a [ i ] ) ; min_so_far = Math . Min ( min_so_far , curr_min ) ; } if ( min_so_far == sum ) { return max_so_far ; }
return Math . Max ( max_so_far , sum - min_so_far ) ; }
public static void Main ( ) { int [ ] a = { 11 , 10 , - 20 , 5 , - 3 , - 5 , 8 , - 13 , 10 } ; int n = 9 ; Console . WriteLine ( " Maximum ▁ circular ▁ sum ▁ is ▁ " + maxCircularSum ( a , n ) ) ; } }
static int GetCeilIndex ( int [ ] arr , int [ ] T , int l , int r , int key ) { while ( r - l > 1 ) { int m = l + ( r - l ) / 2 ; if ( arr [ T [ m ] ] >= key ) r = m ; else l = m ; } return r ; } static int LongestIncreasingSubsequence ( int [ ] arr , int n ) {
int [ ] tailIndices = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) tailIndices [ i ] = 0 ; int [ ] prevIndices = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) prevIndices [ i ] = - 1 ;
int len = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ tailIndices [ 0 ] ] )
tailIndices [ 0 ] = i ; else if ( arr [ i ] > arr [ tailIndices [ len - 1 ] ] ) {
prevIndices [ i ] = tailIndices [ len - 1 ] ; tailIndices [ len ++ ] = i ; } else {
int pos = GetCeilIndex ( arr , tailIndices , - 1 , len - 1 , arr [ i ] ) ; prevIndices [ i ] = tailIndices [ pos - 1 ] ; tailIndices [ pos ] = i ; } } Console . Write ( " LIS ▁ of ▁ given ▁ input " ) ; for ( int i = tailIndices [ len - 1 ] ; i >= 0 ; i = prevIndices [ i ] ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; return len ; }
public static void Main ( ) { int [ ] arr = { 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 } ; int n = arr . Length ; Console . Write ( " LIS ▁ size STRNEWLINE " + LongestIncreasingSubsequence ( arr , n ) ) ; } }
static int maxSum ( int [ ] arr , int n ) { int sum = 0 ;
Array . Sort ( arr ) ;
for ( int i = 0 ; i < n / 2 ; i ++ ) { sum -= ( 2 * arr [ i ] ) ; sum += ( 2 * arr [ n - i - 1 ] ) ; } return sum ; }
public static void Main ( ) { int [ ] arr = { 4 , 2 , 1 , 8 } ; int n = arr . Length ; Console . WriteLine ( maxSum ( arr , n ) ) ; } }
public static void threeWayPartition ( int [ ] arr , int lowVal , int highVal ) { int n = arr . Length ;
int start = 0 , end = n - 1 ;
for ( int i = 0 ; i <= end ; ) {
if ( arr [ i ] < lowVal ) { int temp = arr [ start ] ; arr [ start ] = arr [ i ] ; arr [ i ] = temp ; start ++ ; i ++ ; }
else if ( arr [ i ] > highVal ) { int temp = arr [ end ] ; arr [ end ] = arr [ i ] ; arr [ i ] = temp ; end -- ; } else i ++ ; } }
public static void Main ( ) { int [ ] arr = { 1 , 14 , 5 , 20 , 4 , 2 , 54 , 20 , 87 , 98 , 3 , 1 , 32 } ; threeWayPartition ( arr , 10 , 20 ) ; Console . WriteLine ( " Modified ▁ array ▁ " ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) { Console . Write ( arr [ i ] + " ▁ " ) ; } } }
public virtual void generateUtil ( int [ ] A , int [ ] B , int [ ] C , int i , int j , int m , int n , int len , bool flag ) {
if ( flag ) {
if ( len != 0 ) { printArr ( C , len + 1 ) ; }
for ( int k = i ; k < m ; k ++ ) { if ( len == 0 ) {
C [ len ] = A [ k ] ;
generateUtil ( A , B , C , k + 1 , j , m , n , len , ! flag ) ; }
else if ( A [ k ] > C [ len ] ) { C [ len + 1 ] = A [ k ] ; generateUtil ( A , B , C , k + 1 , j , m , n , len + 1 , ! flag ) ; } } }
else { for ( int l = j ; l < n ; l ++ ) { if ( B [ l ] > C [ len ] ) { C [ len + 1 ] = B [ l ] ; generateUtil ( A , B , C , i , l + 1 , m , n , len + 1 , ! flag ) ; } } } }
public virtual void generate ( int [ ] A , int [ ] B , int m , int n ) { int [ ] C = new int [ m + n ] ;
generateUtil ( A , B , C , 0 , 0 , m , n , 0 , true ) ; }
public virtual void printArr ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) { Console . Write ( arr [ i ] + " ▁ " ) ; } Console . WriteLine ( " " ) ; }
public static void Main ( string [ ] args ) { GenerateArrays generate = new GenerateArrays ( ) ; int [ ] A = new int [ ] { 10 , 15 , 25 } ; int [ ] B = new int [ ] { 5 , 20 , 30 } ; int n = A . Length ; int m = B . Length ; generate . generate ( A , B , n , m ) ; } }
public static void updateindex ( int [ ] index , int a , int ai , int b , int bi ) { index [ a ] = ai ; index [ b ] = bi ; }
public static int minSwapsUtil ( int [ ] arr , int [ ] pairs , int [ ] index , int i , int n ) {
if ( i > n ) { return 0 ; }
if ( pairs [ arr [ i ] ] == arr [ i + 1 ] ) { return minSwapsUtil ( arr , pairs , index , i + 2 , n ) ; }
int one = arr [ i + 1 ] ; int indextwo = i + 1 ; int indexone = index [ pairs [ arr [ i ] ] ] ; int two = arr [ index [ pairs [ arr [ i ] ] ] ] ; arr [ i + 1 ] = arr [ i + 1 ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i + 1 ] ) ; updateindex ( index , one , indexone , two , indextwo ) ; int a = minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
arr [ i + 1 ] = arr [ i + 1 ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i + 1 ] ) ; updateindex ( index , one , indextwo , two , indexone ) ; one = arr [ i ] ; indexone = index [ pairs [ arr [ i + 1 ] ] ] ;
two = arr [ index [ pairs [ arr [ i + 1 ] ] ] ] ; indextwo = i ; arr [ i ] = arr [ i ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i ] ) ; updateindex ( index , one , indexone , two , indextwo ) ; int b = minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
arr [ i ] = arr [ i ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i ] ) ; updateindex ( index , one , indextwo , two , indexone ) ;
return 1 + Math . Min ( a , b ) ; }
public static int minSwaps ( int n , int [ ] pairs , int [ ] arr ) {
int [ ] index = new int [ 2 * n + 1 ] ;
for ( int i = 1 ; i <= 2 * n ; i ++ ) { index [ arr [ i ] ] = i ; }
return minSwapsUtil ( arr , pairs , index , 1 , 2 * n ) ; }
int [ ] arr = new int [ ] { 0 , 3 , 5 , 6 , 4 , 1 , 2 } ;
int [ ] pairs = new int [ ] { 0 , 3 , 6 , 1 , 5 , 4 , 2 } ; int m = pairs . Length ;
int n = m / 2 ;
Console . Write ( " Min ▁ swaps ▁ required ▁ is ▁ " + minSwaps ( n , pairs , arr ) ) ; } }
static void replace_elements ( int [ ] arr , int n ) {
int pos = 0 ; for ( int i = 0 ; i < n ; i ++ ) { arr [ pos ++ ] = arr [ i ] ; while ( pos > 1 && arr [ pos - 2 ] == arr [ pos - 1 ] ) { pos -- ; arr [ pos - 1 ] ++ ; } }
for ( int i = 0 ; i < pos ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
static void Main ( ) { int [ ] arr = { 6 , 4 , 3 , 4 , 3 , 3 , 5 } ; int n = arr . Length ; replace_elements ( arr , n ) ; } }
static void arrangeString ( string str , int x , int y ) { int count_0 = 0 ; int count_1 = 0 ; int len = str . Length ;
for ( int i = 0 ; i < len ; i ++ ) { if ( str [ i ] == '0' ) count_0 ++ ; else count_1 ++ ; }
while ( count_0 > 0 count_1 > 0 ) { for ( int j = 0 ; j < x && count_0 > 0 ; j ++ ) { if ( count_0 > 0 ) { Console . Write ( "0" ) ; count_0 -- ; } } for ( int j = 0 ; j < y && count_1 > 0 ; j ++ ) { if ( count_1 > 0 ) { Console . Write ( "1" ) ; count_1 -- ; } } } }
public static void Main ( ) { string str = "01101101101101101000000" ; int x = 1 ; int y = 2 ; arrangeString ( str , x , y ) ; } }
using System ; using System . Collections . Generic ; class GFG { public static void distinctAdjacentElement ( int [ ] a , int n ) {
Dictionary < int , int > m = new Dictionary < int , int > ( ) ;
for ( int i = 0 ; i < n ; ++ i ) { if ( m . ContainsKey ( a [ i ] ) ) { int x = m [ a [ i ] ] + 1 ; m [ a [ i ] ] = x ; } else { m [ a [ i ] ] = 1 ; } }
int mx = 0 ;
for ( int i = 0 ; i < n ; ++ i ) { if ( mx < m [ a [ i ] ] ) { mx = m [ a [ i ] ] ; } }
if ( mx > ( n + 1 ) / 2 ) { Console . WriteLine ( " NO " ) ; } else { Console . WriteLine ( " YES " ) ; } }
public static void Main ( string [ ] args ) { int [ ] a = new int [ ] { 7 , 7 , 7 , 7 } ; int n = 4 ; distinctAdjacentElement ( a , n ) ; } }
public static void rearrange ( int [ ] arr ) {
if ( arr == null arr . Length % 2 == 1 ) return ;
int currIdx = ( arr . Length - 1 ) / 2 ;
while ( currIdx > 0 ) { int count = currIdx , swapIdx = currIdx ; while ( count -- > 0 ) { int temp = arr [ swapIdx + 1 ] ; arr [ swapIdx + 1 ] = arr [ swapIdx ] ; arr [ swapIdx ] = temp ; swapIdx ++ ; } currIdx -- ; } }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 5 , 2 , 4 , 6 } ; rearrange ( arr ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) Console . Write ( " ▁ " + arr [ i ] ) ; } }
static int maxDiff ( int [ ] arr , int n ) {
int maxDiff = - 1 ;
int maxRight = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) { if ( arr [ i ] > maxRight ) maxRight = arr [ i ] ; else { int diff = maxRight - arr [ i ] ; if ( diff > maxDiff ) { maxDiff = diff ; } } } return maxDiff ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 90 , 10 , 110 } ; int n = arr . Length ;
Console . WriteLine ( " Maximum ▁ difference ▁ is ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) {
int diff = arr [ 1 ] - arr [ 0 ] ; int curr_sum = diff ; int max_sum = curr_sum ; for ( int i = 1 ; i < n - 1 ; i ++ ) {
diff = arr [ i + 1 ] - arr [ i ] ;
if ( curr_sum > 0 ) curr_sum += diff ; else curr_sum = diff ;
if ( curr_sum > max_sum ) max_sum = curr_sum ; } return max_sum ; }
public static void Main ( ) { int [ ] arr = { 80 , 2 , 6 , 3 , 100 } ; int n = arr . Length ;
Console . WriteLine ( " Maximum ▁ difference ▁ is ▁ " + maxDiff ( arr , n ) ) ; } }
using System ; class GFG { public static void Main ( String [ ] args ) { int [ ] v = { 34 , 8 , 10 , 3 , 2 , 80 , 30 , 33 , 1 } ; int n = v . Length ; int [ ] maxFromEnd = new int [ n + 1 ] ; for ( int i = 0 ; i < maxFromEnd . Length ; i ++ ) maxFromEnd [ i ] = int . MinValue ;
for ( int i = v . Length - 1 ; i >= 0 ; i -- ) { maxFromEnd [ i ] = Math . Max ( maxFromEnd [ i + 1 ] , v [ i ] ) ; } int result = 0 ; for ( int i = 0 ; i < v . Length ; i ++ ) { int low = i + 1 , high = v . Length - 1 , ans = i ; while ( low <= high ) { int mid = ( low + high ) / 2 ; if ( v [ i ] <= maxFromEnd [ mid ] ) {
ans = Math . Max ( ans , mid ) ; low = mid + 1 ; } else { high = mid - 1 ; } }
result = Math . Max ( result , ans - i ) ; } Console . Write ( result + " STRNEWLINE " ) ; } }
using System ; class GFG { public void getPostOrderBST ( int [ ] pre ) { int pivotPoint = 0 ;
for ( int i = 1 ; i < pre . Length ; i ++ ) { if ( pre [ 0 ] <= pre [ i ] ) { pivotPoint = i ; break ; } }
for ( int i = pivotPoint - 1 ; i > 0 ; i -- ) { Console . Write ( pre [ i ] + " ▁ " ) ; }
for ( int i = pre . Length - 1 ; i >= pivotPoint ; i -- ) { Console . Write ( pre [ i ] + " ▁ " ) ; } Console . Write ( pre [ 0 ] ) ; }
using System ; class GFG { static void constructLowerArray ( int [ ] arr , int [ ] countSmaller , int n ) { int i , j ;
for ( i = 0 ; i < n ; i ++ ) countSmaller [ i ] = 0 ; for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < arr [ i ] ) countSmaller [ i ] ++ ; } } }
static void printArray ( int [ ] arr , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; Console . WriteLine ( " " ) ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 12 , 10 , 5 , 4 , 2 , 20 , 6 , 1 , 0 , 2 } ; int n = arr . Length ; int [ ] low = new int [ n ] ; constructLowerArray ( arr , low , n ) ; printArray ( low , n ) ; } }
static int segregate ( int [ ] arr , int size ) { int j = 0 , i ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] <= 0 ) { int temp ; temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ;
j ++ ; } } return j ; }
static int findMissingPositive ( int [ ] arr , int size ) { int i ;
for ( i = 0 ; i < size ; i ++ ) { if ( Math . Abs ( arr [ i ] ) - 1 < size && arr [ Math . Abs ( arr [ i ] ) - 1 ] > 0 ) arr [ Math . Abs ( arr [ i ] ) - 1 ] = - arr [ Math . Abs ( arr [ i ] ) - 1 ] ; }
for ( i = 0 ; i < size ; i ++ ) if ( arr [ i ] > 0 ) return i + 1 ;
return size + 1 ; }
static int findMissing ( int [ ] arr , int size ) {
int shift = segregate ( arr , size ) ; int [ ] arr2 = new int [ size - shift ] ; int j = 0 ; for ( int i = shift ; i < size ; i ++ ) { arr2 [ j ] = arr [ i ] ; j ++ ; }
return findMissingPositive ( arr2 , j ) ; }
public static void Main ( ) { int [ ] arr = { 0 , 10 , 2 , - 10 , - 20 } ; int arr_size = arr . Length ; int missing = findMissing ( arr , arr_size ) ; Console . WriteLine ( " The ▁ smallest ▁ positive ▁ missing ▁ number ▁ is ▁ " + missing ) ; } }
static int firstMissingPositive ( int [ ] arr , int n ) {
for ( int i = 0 ; i < n ; i ++ ) {
while ( arr [ i ] >= 1 && arr [ i ] <= n && arr [ i ] != arr [ arr [ i ] - 1 ] ) { int temp = arr [ arr [ i ] - 1 ] ; arr [ arr [ i ] - 1 ] = arr [ i ] ; arr [ i ] = temp ; } }
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != i + 1 ) return ( i + 1 ) ;
return ( n + 1 ) ; }
static public void Main ( ) { int [ ] arr = { 2 , 3 , - 7 , 6 , 8 , 1 , - 10 , 15 } ; int n = arr . Length ; int ans = firstMissingPositive ( arr , n ) ; Console . WriteLine ( ans ) ; } }
public virtual void fillDepth ( int [ ] parent , int i , int [ ] depth ) {
if ( depth [ i ] != 0 ) { return ; }
if ( parent [ i ] == - 1 ) { depth [ i ] = 1 ; return ; }
if ( depth [ parent [ i ] ] == 0 ) { fillDepth ( parent , parent [ i ] , depth ) ; }
depth [ i ] = depth [ parent [ i ] ] + 1 ; }
public virtual int findHeight ( int [ ] parent , int n ) {
int [ ] depth = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { depth [ i ] = 0 ; }
for ( int i = 0 ; i < n ; i ++ ) { fillDepth ( parent , i , depth ) ; }
int ht = depth [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( ht < depth [ i ] ) { ht = depth [ i ] ; } } return ht ; }
int [ ] parent = new int [ ] { - 1 , 0 , 0 , 1 , 1 , 3 , 5 } ; int n = parent . Length ; Console . WriteLine ( " Height ▁ is ▁ " + tree . findHeight ( parent , n ) ) ; } }
static int maxRepeating ( int [ ] arr , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) arr [ ( arr [ i ] % k ) ] += k ;
int max = arr [ 0 ] , result = 0 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; result = i ; } }
return result ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 } ; int n = arr . Length ; int k = 8 ; Console . Write ( " Maximum ▁ repeating ▁ " + " element ▁ is : ▁ " + maxRepeating ( arr , n , k ) ) ; } }
static int max ( int x , int y ) { return ( x > y ) ? x : y ; }
static int maxPathSum ( int [ ] ar1 , int [ ] ar2 , int m , int n ) {
int i = 0 , j = 0 ;
int result = 0 , sum1 = 0 , sum2 = 0 ;
while ( i < m && j < n ) {
if ( ar1 [ i ] < ar2 [ j ] ) sum1 += ar1 [ i ++ ] ;
else if ( ar1 [ i ] > ar2 [ j ] ) sum2 += ar2 [ j ++ ] ;
else {
result += max ( sum1 , sum2 ) + ar1 [ i ] ;
sum1 = 0 ; sum2 = 0 ;
i ++ ; j ++ ; } }
while ( i < m ) sum1 += ar1 [ i ++ ] ;
while ( j < n ) sum2 += ar2 [ j ++ ] ;
result += max ( sum1 , sum2 ) ; return result ; }
public static void Main ( ) { int [ ] ar1 = { 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 } ; int [ ] ar2 = { 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 } ; int m = ar1 . Length ; int n = ar2 . Length ;
Console . Write ( " Maximum ▁ sum ▁ path ▁ is ▁ : " + maxPathSum ( ar1 , ar2 , m , n ) ) ; } }
using System ; class GFG { static void smallestGreater ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) {
int diff = int . MaxValue ; int closest = - 1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] < arr [ j ] && arr [ j ] - arr [ i ] < diff ) { diff = arr [ j ] - arr [ i ] ; closest = j ; } }
if ( closest == - 1 ) Console . Write ( " _ ▁ " ) ; else Console . Write ( arr [ closest ] + " ▁ " ) ; } }
public static void Main ( ) { int [ ] ar = { 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 } ; int n = ar . Length ; smallestGreater ( ar , n ) ; } }
using System ; using System . Collections . Generic ; class GFG { static void smallestGreater ( int [ ] arr , int n ) { HashSet < int > s = new HashSet < int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { s . Add ( arr [ i ] ) ; } int [ ] newAr = new int [ s . Count ] ; int j = 0 ; foreach ( int p in s ) { newAr [ j ] = p ; j ++ ; } Array . Sort ( newAr ) ; for ( int i = 0 ; i < n ; i ++ ) { int temp = lowerBound ( newAr , 0 , newAr . GetLength ( 0 ) , arr [ i ] ) ; if ( temp < n ) Console . Write ( newAr [ temp ] + " ▁ " ) ; else Console . Write ( " _ ▁ " ) ; } }
static int lowerBound ( int [ ] array , int low , int high , int element ) { while ( low < high ) { int middle = low + ( high - low ) / 2 ; if ( element > array [ middle ] ) { low = middle + 1 ; } else { high = middle ; } } return low + 1 ; }
public static void Main ( String [ ] args ) { int [ ] ar = { 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 } ; int n = ar . Length ; smallestGreater ( ar , n ) ; } }
static void findZeroes ( int m ) {
int wL = 0 , wR = 0 ;
int bestL = 0 , bestWindow = 0 ;
int zeroCount = 0 ;
while ( wR < arr . Length ) {
if ( zeroCount <= m ) { if ( arr [ wR ] == 0 ) zeroCount ++ ; wR ++ ; }
if ( zeroCount > m ) { if ( arr [ wL ] == 0 ) zeroCount -- ; wL ++ ; }
if ( ( wR - wL > bestWindow ) && ( zeroCount <= m ) ) { bestWindow = wR - wL ; bestL = wL ; } }
for ( int i = 0 ; i < bestWindow ; i ++ ) { if ( arr [ bestL + i ] == 0 ) Console . Write ( bestL + i + " ▁ " ) ; } }
public static void Main ( String [ ] args ) { int m = 2 ; Console . Write ( " Indexes ▁ of ▁ zeroes ▁ to ▁ be ▁ flipped ▁ are ▁ " ) ; findZeroes ( m ) ; } }
using System ; class Test { static int [ ] arr = new int [ ] { 1 , 2 , 2 , 4 } ; static int countIncreasing ( int n ) {
int cnt = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] > arr [ j - 1 ] ) cnt ++ ;
else break ; } } return cnt ; }
public static void Main ( String [ ] args ) { Console . Write ( " Count ▁ of ▁ strictly ▁ increasing " + " subarrays ▁ is ▁ " + countIncreasing ( arr . Length ) ) ; } }
using System ; class GFG { static int [ ] arr = new int [ ] { 1 , 2 , 2 , 4 } ; static int countIncreasing ( int n ) {
int cnt = 0 ;
int len = 1 ;
for ( int i = 0 ; i < n - 1 ; ++ i ) {
if ( arr [ i + 1 ] > arr [ i ] ) len ++ ;
else { cnt += ( ( ( len - 1 ) * len ) / 2 ) ; len = 1 ; } }
if ( len > 1 ) cnt += ( ( ( len - 1 ) * len ) / 2 ) ; return cnt ; }
public static void Main ( ) { Console . WriteLine ( " Count ▁ of ▁ strictly ▁ " + " increasing ▁ subarrays ▁ is ▁ " + countIncreasing ( arr . Length ) ) ; } }
static long arraySum ( int [ ] arr , int n ) { long sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + arr [ i ] ; return sum ; }
static long maxDiff ( int [ ] arr , int n , int k ) {
Array . Sort ( arr ) ;
long arraysum = arraySum ( arr , n ) ;
long diff1 = Math . Abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
Array . Reverse ( arr ) ;
long diff2 = Math . Abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
return ( Math . Max ( diff1 , diff2 ) ) ; }
static public void Main ( ) { int [ ] arr = { 1 , 7 , 4 , 8 , - 1 , 5 , 2 , 1 } ; int n = arr . Length ; int k = 3 ; Console . WriteLine ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n , k ) ) ; } }
static int minNumber ( int [ ] a , int n , int x ) {
Array . Sort ( a ) ; int k ; for ( k = 0 ; a [ ( n ) / 2 ] != x ; k ++ ) { a [ n ++ ] = x ; Array . Sort ( a ) ; } return k ; }
public static void Main ( String [ ] args ) { int x = 10 ; int [ ] a = { 10 , 20 , 30 } ; int n = 3 ; Console . WriteLine ( minNumber ( a , n - 1 , x ) ) ; } }
using System ; class GFG { public static int minNumber ( int [ ] a , int n , int x ) { int l = 0 , h = 0 , e = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == x ) e ++ ;
else if ( a [ i ] > x ) h ++ ;
else if ( a [ i ] < x ) l ++ ; } int ans = 0 ; if ( l > h ) ans = l - h ; else if ( l < h ) ans = h - l - 1 ;
return ans + 1 - e ; }
public static void Main ( ) { int x = 10 ; int [ ] a = { 10 , 20 , 30 } ; int n = a . Length ; Console . WriteLine ( minNumber ( a , n , x ) ) ; } }
static int fun ( int x ) { int y = ( x / 4 ) * 4 ;
int ans = 0 ; for ( int i = y ; i <= x ; i ++ ) ans ^= i ; return ans ; }
static int query ( int x ) {
if ( x == 0 ) return 0 ; int k = ( x + 1 ) / 2 ;
return ( ( x %= 2 ) != 0 ) ? 2 * fun ( k ) : ( ( fun ( k - 1 ) * 2 ) ^ ( k & 1 ) ) ; } static void allQueries ( int q , int [ ] l , int [ ] r ) { for ( int i = 0 ; i < q ; i ++ ) Console . WriteLine ( ( query ( r [ i ] ) ^ query ( l [ i ] - 1 ) ) ) ; }
public static void Main ( ) { int q = 3 ; int [ ] l = { 2 , 2 , 5 } ; int [ ] r = { 4 , 8 , 9 } ; allQueries ( q , l , r ) ; } }
static void preprocess ( int [ ] arr , int N , int [ ] left , int [ ] right ) {
left [ 0 ] = 0 ; int lastIncr = 0 ; for ( int i = 1 ; i < N ; i ++ ) {
if ( arr [ i ] > arr [ i - 1 ] ) lastIncr = i ; left [ i ] = lastIncr ; }
right [ N - 1 ] = N - 1 ; int firstDecr = N - 1 ; for ( int i = N - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] > arr [ i + 1 ] ) firstDecr = i ; right [ i ] = firstDecr ; } }
static bool isSubarrayMountainForm ( int [ ] arr , int [ ] left , int [ ] right , int L , int R ) {
return ( right [ L ] >= left [ R ] ) ; }
static public void Main ( ) { int [ ] arr = { 2 , 3 , 2 , 4 , 4 , 6 , 3 , 2 } ; int N = arr . Length ; int [ ] left = new int [ N ] ; int [ ] right = new int [ N ] ; preprocess ( arr , N , left , right ) ; int L = 0 ; int R = 2 ; if ( isSubarrayMountainForm ( arr , left , right , L , R ) ) Console . WriteLine ( " Subarray ▁ is ▁ in ▁ " + " mountain ▁ form " ) ; else Console . WriteLine ( " Subarray ▁ is ▁ not ▁ " + " in ▁ mountain ▁ form " ) ; L = 1 ; R = 3 ; if ( isSubarrayMountainForm ( arr , left , right , L , R ) ) Console . WriteLine ( " Subarray ▁ is ▁ in ▁ " + " mountain ▁ form " ) ; else Console . WriteLine ( " Subarray ▁ is ▁ not ▁ " + " in ▁ mountain ▁ form " ) ; } }
using System ; class GFG { public static void preCompute ( int [ ] arr , int n , int [ ] pre ) { pre [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) pre [ i ] = arr [ i ] + pre [ i - 1 ] ; }
public static int rangeSum ( int i , int j , int [ ] pre ) { if ( i == 0 ) return pre [ j ] ; return pre [ j ] - pre [ i - 1 ] ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; int n = arr . Length ; int [ ] pre = new int [ n ] ;
preCompute ( arr , n , pre ) ; Console . WriteLine ( rangeSum ( 1 , 3 , pre ) ) ; Console . WriteLine ( rangeSum ( 2 , 4 , pre ) ) ; } }
using System ; public class GFG { static int MAX = 1000 ; static void sieveOfEratosthenes ( bool [ ] isPrime ) { isPrime [ 1 ] = false ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( isPrime [ p ] == true ) {
for ( int i = p * 2 ; i <= MAX ; i += p ) isPrime [ i ] = false ; } } }
static int getMid ( int s , int e ) { return s + ( e - s ) / 2 ; }
static int queryPrimesUtil ( int [ ] st , int ss , int se , int qs , int qe , int index ) {
if ( qs <= ss && qe >= se ) return st [ index ] ;
if ( se < qs ss > qe ) return 0 ;
int mid = getMid ( ss , se ) ; return queryPrimesUtil ( st , ss , mid , qs , qe , 2 * index + 1 ) + queryPrimesUtil ( st , mid + 1 , se , qs , qe , 2 * index + 2 ) ; }
static void updateValueUtil ( int [ ] st , int ss , int se , int i , int diff , int si ) {
if ( i < ss i > se ) return ;
st [ si ] = st [ si ] + diff ; if ( se != ss ) { int mid = getMid ( ss , se ) ; updateValueUtil ( st , ss , mid , i , diff , 2 * si + 1 ) ; updateValueUtil ( st , mid + 1 , se , i , diff , 2 * si + 2 ) ; } }
static void updateValue ( int [ ] arr , int [ ] st , int n , int i , int new_val , bool [ ] isPrime ) {
if ( i < 0 i > n - 1 ) { Console . WriteLine ( " Invalid ▁ Input " ) ; return ; } int diff = 0 ; int oldValue ; oldValue = arr [ i ] ;
arr [ i ] = new_val ;
if ( isPrime [ oldValue ] && isPrime [ new_val ] ) return ;
if ( ( ! isPrime [ oldValue ] ) && ( ! isPrime [ new_val ] ) ) return ;
if ( isPrime [ oldValue ] && ! isPrime [ new_val ] ) { diff = - 1 ; }
if ( ! isPrime [ oldValue ] && isPrime [ new_val ] ) { diff = 1 ; }
updateValueUtil ( st , 0 , n - 1 , i , diff , 0 ) ; }
static void queryPrimes ( int [ ] st , int n , int qs , int qe ) { int primesInRange = queryPrimesUtil ( st , 0 , n - 1 , qs , qe , 0 ) ; Console . WriteLine ( " Number ▁ of ▁ Primes ▁ in ▁ subarray ▁ from ▁ " + qs + " ▁ to ▁ " + qe + " ▁ = ▁ " + primesInRange ) ; }
static int constructSTUtil ( int [ ] arr , int ss , int se , int [ ] st , int si , bool [ ] isPrime ) {
if ( ss == se ) {
if ( isPrime [ arr [ ss ] ] ) st [ si ] = 1 ; else st [ si ] = 0 ; return st [ si ] ; }
int mid = getMid ( ss , se ) ; st [ si ] = constructSTUtil ( arr , ss , mid , st , si * 2 + 1 , isPrime ) + constructSTUtil ( arr , mid + 1 , se , st , si * 2 + 2 , isPrime ) ; return st [ si ] ; }
static int [ ] constructST ( int [ ] arr , int n , bool [ ] isPrime ) {
int x = ( int ) ( Math . Ceiling ( Math . Log ( n ) / Math . Log ( 2 ) ) ) ;
int max_size = 2 * ( int ) Math . Pow ( 2 , x ) - 1 ; int [ ] st = new int [ max_size ] ;
constructSTUtil ( arr , 0 , n - 1 , st , 0 , isPrime ) ;
return st ; }
static public void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 5 , 7 , 9 } ; int n = arr . Length ;
bool [ ] isPrime = new bool [ MAX + 1 ] ; Array . Fill ( isPrime , true ) ; sieveOfEratosthenes ( isPrime ) ;
int [ ] st = constructST ( arr , n , isPrime ) ;
int start = 0 ; int end = 4 ; queryPrimes ( st , n , start , end ) ;
int i = 3 ; int x = 6 ; updateValue ( arr , st , n , i , x , isPrime ) ;
start = 0 ; end = 4 ; queryPrimes ( st , n , start , end ) ; } }
static void checkEVENodd ( int [ ] arr , int n , int l , int r ) {
if ( arr [ r ] == 1 ) Console . WriteLine ( " odd " ) ;
else Console . ( " even " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 0 , 1 } ; int n = arr . Length ; checkEVENodd ( arr , n , 1 , 3 ) ; } }
static int findMean ( int [ ] arr , int l , int r ) {
int sum = 0 , count = 0 ;
for ( int i = l ; i <= r ; i ++ ) { sum += arr [ i ] ; count ++ ; }
int mean = ( int ) Math . Floor ( ( double ) sum / count ) ;
return mean ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; Console . WriteLine ( findMean ( arr , 0 , 2 ) ) ; Console . WriteLine ( findMean ( arr , 1 , 3 ) ) ; Console . WriteLine ( findMean ( arr , 0 , 4 ) ) ; } }
using System ; public class GFG { public static readonly int MAX = 1000005 ; static int [ ] prefixSum = new int [ MAX ] ;
static void calculatePrefixSum ( int [ ] arr , int n ) {
prefixSum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) prefixSum [ i ] = prefixSum [ i - 1 ] + arr [ i ] ; }
static int findMean ( int l , int r ) { if ( l == 0 ) return ( int ) Math . Floor ( ( double ) ( prefixSum [ r ] / ( r + 1 ) ) ) ;
return ( int ) Math . Floor ( ( double ) ( prefixSum [ r ] - prefixSum [ l - 1 ] ) / ( r - l + 1 ) ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; int n = arr . Length ; calculatePrefixSum ( arr , n ) ; Console . WriteLine ( findMean ( 1 , 2 ) ) ; Console . WriteLine ( findMean ( 1 , 3 ) ) ; Console . WriteLine ( findMean ( 1 , 4 ) ) ; } }
static void updateQuery ( int [ ] arr , int n , int q , int l , int r , int k ) {
if ( q == 0 ) { arr [ l - 1 ] += k ; arr [ r ] += - k ; }
else { arr [ l - 1 ] += - k ; arr [ r ] += k ; } return ; }
static void generateArray ( int [ ] arr , int n ) {
for ( int i = 1 ; i < n ; ++ i ) arr [ i ] += arr [ i - 1 ] ; }
public static void Main ( ) { int n = 5 ; int [ ] arr = new int [ n + 1 ] ; for ( int i = 0 ; i < arr . Length ; i ++ ) arr [ i ] = 0 ; int q = 0 , l = 1 , r = 3 , k = 2 ; updateQuery ( arr , n , q , l , r , k ) ; q = 1 ; l = 3 ; r = 5 ; k = 3 ; updateQuery ( arr , n , q , l , r , k ) ; q = 0 ; l = 2 ; r = 5 ; k = 1 ; updateQuery ( arr , n , q , l , r , k ) ;
generateArray ( arr , n ) ;
for ( int i = 0 ; i < n ; ++ i ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static int calculateProduct ( int [ ] A , int L , int R , int P ) {
L = L - 1 ; R = R - 1 ; int ans = 1 ; for ( int i = L ; i <= R ; i ++ ) { ans = ans * A [ i ] ; ans = ans % P ; } return ans ; }
static public void Main ( ) { int [ ] A = { 1 , 2 , 3 , 4 , 5 , 6 } ; int P = 229 ; int L = 2 , R = 5 ; Console . WriteLine ( calculateProduct ( A , L , R , P ) ) ; L = 1 ; R = 3 ; Console . WriteLine ( calculateProduct ( A , L , R , P ) ) ; } }
using System ; class GFG { static int MAX = 100 ; int [ ] pre_product = new int [ MAX ] ; int [ ] inverse_product = new int [ MAX ] ;
int modInverse ( int a , int m ) { int m0 = m , t , q ; int x0 = 0 , x1 = 1 ; if ( m == 1 ) return 0 ; while ( a > 1 ) {
q = a / m ; t = m ;
m = a % m ; a = t ; t = x0 ; x0 = x1 - q * x0 ; x1 = t ; }
if ( x1 < 0 ) x1 += m0 ; return x1 ; }
void calculate_Pre_Product ( int [ ] A , int N , int P ) { pre_product [ 0 ] = A [ 0 ] ; for ( int i = 1 ; i < N ; i ++ ) { pre_product [ i ] = pre_product [ i - 1 ] * A [ i ] ; pre_product [ i ] = pre_product [ i ] % P ; } }
void calculate_inverse_product ( int [ ] A , int N , int P ) { inverse_product [ 0 ] = modInverse ( pre_product [ 0 ] , P ) ; for ( int i = 1 ; i < N ; i ++ ) inverse_product [ i ] = modInverse ( pre_product [ i ] , P ) ; }
int calculateProduct ( int [ ] A , int L , int R , int P ) {
L = L - 1 ; R = R - 1 ; int ans ; if ( L == 0 ) ans = pre_product [ R ] ; else ans = pre_product [ R ] * inverse_product [ L - 1 ] ; return ans ; }
int [ ] A = { 1 , 2 , 3 , 4 , 5 , 6 } ;
int P = 113 ;
d . calculate_Pre_Product ( A , A . Length , P ) ; d . calculate_inverse_product ( A , A . Length , P ) ;
int L = 2 , R = 5 ; Console . WriteLine ( d . calculateProduct ( A , L , R , P ) ) ; L = 1 ; R = 3 ; Console . WriteLine ( d . calculateProduct ( A , L , R , P ) ) ; } }
using System ; class GFG { static int MAX = 10000 ;
static int [ ] prefix = new int [ MAX + 1 ] ; static void buildPrefix ( ) {
bool [ ] prime = new bool [ MAX + 1 ] ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == false ) {
for ( int i = p * 2 ; i <= MAX ; i += p ) prime [ i ] = true ; } }
prefix [ 0 ] = prefix [ 1 ] = 0 ; for ( int p = 2 ; p <= MAX ; p ++ ) { prefix [ p ] = prefix [ p - 1 ] ; if ( prime [ p ] == false ) prefix [ p ] ++ ; } }
static int query ( int L , int R ) { return prefix [ R ] - prefix [ L - 1 ] ; }
public static void Main ( ) { buildPrefix ( ) ; int L = 5 , R = 10 ; Console . WriteLine ( query ( L , R ) ) ; L = 1 ; R = 10 ; Console . WriteLine ( query ( L , R ) ) ; } }
static void command ( bool [ ] arr , int a , int b ) { arr [ a ] ^= true ; arr [ b + 1 ] ^= true ; }
static void process ( bool [ ] arr , int n ) { for ( int k = 1 ; k <= n ; k ++ ) { arr [ k ] ^= arr [ k - 1 ] ; } }
static void result ( bool [ ] arr , int n ) { for ( int k = 1 ; k <= n ; k ++ ) { if ( arr [ k ] == true ) Console . Write ( "1" + " ▁ " ) ; else Console . Write ( "0" + " ▁ " ) ; } }
public static void Main ( ) { int n = 5 , m = 3 ; bool [ ] arr = new bool [ n + 2 ] ;
command ( arr , 1 , 5 ) ; command ( arr , 2 , 5 ) ; command ( arr , 3 , 5 ) ;
process ( arr , n ) ;
result ( arr , n ) ; } }
class Interval { public int start ; public int end ; public Interval ( int start , int end ) { this . start = start ; this . end = end ; } } ;
static bool isIntersect ( Interval [ ] arr , int n ) { int max_ele = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { if ( max_ele < arr [ i ] . end ) max_ele = arr [ i ] . end ; }
int [ ] aux = new int [ max_ele + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) {
int x = arr [ i ] . start ;
int y = arr [ i ] . end ; aux [ x ] ++ ; aux [ y ] -- ; } for ( int i = 1 ; i <= max_ele ; i ++ ) {
aux [ i ] += aux [ i - 1 ] ;
if ( aux [ i ] > 1 ) return true ; }
return false ; }
public static void Main ( String [ ] args ) { Interval [ ] arr1 = { new Interval ( 1 , 3 ) , new Interval ( 7 , 9 ) , new Interval ( 4 , 6 ) , new Interval ( 10 , 13 ) } ; int n1 = arr1 . Length ; if ( isIntersect ( arr1 , n1 ) ) Console . Write ( " Yes STRNEWLINE " ) ; else Console . Write ( " No STRNEWLINE " ) ; Interval [ ] arr2 = { new Interval ( 6 , 8 ) , new Interval ( 1 , 3 ) , new Interval ( 2 , 4 ) , new Interval ( 4 , 7 ) } ; int n2 = arr2 . Length ; if ( isIntersect ( arr2 , n2 ) ) Console . Write ( " Yes STRNEWLINE " ) ; else Console . Write ( " No STRNEWLINE " ) ; } }
public class query { public int start , end ; public query ( int start , int end ) { this . start = start ; this . end = end ; } }
public static void incrementByD ( int [ ] arr , query [ ] q_arr , int n , int m , int d ) { int [ ] sum = new int [ n ] ;
for ( int i = 0 ; i < m ; i ++ ) {
sum [ q_arr [ i ] . start ] += d ;
if ( ( q_arr [ i ] . end + 1 ) < n ) sum [ q_arr [ i ] . end + 1 ] -= d ; }
arr [ 0 ] += sum [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { sum [ i ] += sum [ i - 1 ] ; arr [ i ] += sum [ i ] ; } }
public static void printArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 3 , 5 , 4 , 8 , 6 , 1 } ; query [ ] q_arr = new query [ 5 ] ; q_arr [ 0 ] = new query ( 0 , 3 ) ; q_arr [ 1 ] = new query ( 4 , 5 ) ; q_arr [ 2 ] = new query ( 1 , 4 ) ; q_arr [ 3 ] = new query ( 0 , 1 ) ; q_arr [ 4 ] = new query ( 2 , 5 ) ; int n = arr . Length ; int m = q_arr . Length ; int d = 2 ; Console . WriteLine ( " Original ▁ Array : " ) ; printArray ( arr , n ) ;
incrementByD ( arr , q_arr , n , m , d ) ; Console . WriteLine ( " STRNEWLINE Modified ▁ Array : " ) ; printArray ( arr , n ) ; } }
static void prefixXOR ( int [ ] arr , int [ ] preXOR , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { while ( arr [ i ] % 2 != 1 ) arr [ i ] /= 2 ; preXOR [ i ] = arr [ i ] ; }
for ( int i = 1 ; i < n ; i ++ ) preXOR [ i ] = preXOR [ i - 1 ] ^ preXOR [ i ] ; }
static int query ( int [ ] preXOR , int l , int r ) { if ( l == 0 ) return preXOR [ r ] ; else return preXOR [ r ] ^ preXOR [ l - 1 ] ; }
public static void Main ( ) { int [ ] arr = { 3 , 4 , 5 } ; int n = arr . Length ; int [ ] preXOR = new int [ n ] ; prefixXOR ( arr , preXOR , n ) ; Console . WriteLine ( query ( preXOR , 0 , 2 ) ) ; Console . WriteLine ( query ( preXOR , 1 , 2 ) ) ; } }
using System ; public class GFG { static readonly int MAX = 100000 ;
static int [ ] tree = new int [ MAX ] ;
static bool [ ] lazy = new bool [ MAX ] ;
static void toggle ( int node , int st , int en , int us , int ue ) {
if ( lazy [ node ] ) {
lazy [ node ] = false ; tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ 1 + ( node << 1 ) ] = ! lazy [ 1 + ( node << 1 ) ] ; } }
if ( st > en us > en ue < st ) { return ; }
if ( us <= st && en <= ue ) {
tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ 1 + ( node << 1 ) ] = ! lazy [ 1 + ( node << 1 ) ] ; } return ; }
int mid = ( st + en ) / 2 ; toggle ( ( node << 1 ) , st , mid , us , ue ) ; toggle ( ( node << 1 ) + 1 , mid + 1 , en , us , ue ) ;
if ( st < en ) { tree [ node ] = tree [ node << 1 ] + tree [ ( node << 1 ) + 1 ] ; } }
static int countQuery ( int node , int st , int en , int qs , int qe ) {
if ( st > en qs > en qe < st ) { return 0 ; }
if ( lazy [ node ] ) {
lazy [ node ] = false ; tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ ( node << 1 ) + 1 ] = ! lazy [ ( node << 1 ) + 1 ] ; } }
if ( qs <= st && en <= qe ) { return tree [ node ] ; }
int mid = ( st + en ) / 2 ; return countQuery ( ( node << 1 ) , st , mid , qs , qe ) + countQuery ( ( node << 1 ) + 1 , mid + 1 , en , qs , qe ) ; }
public static void Main ( ) { int n = 5 ;
toggle ( 1 , 0 , n - 1 , 1 , 2 ) ;
toggle ( 1 , 0 , n - 1 , 2 , 4 ) ;
Console . WriteLine ( countQuery ( 1 , 0 , n - 1 , 2 , 3 ) ) ;
toggle ( 1 , 0 , n - 1 , 2 , 4 ) ;
Console . WriteLine ( countQuery ( 1 , 0 , n - 1 , 1 , 4 ) ) ; } }
static float probability ( int [ ] a , int [ ] b , int size1 , int size2 ) {
int max1 = int . MinValue , count1 = 0 ; for ( int i = 0 ; i < size1 ; i ++ ) { if ( a [ i ] > max1 ) { max1 = a [ i ] ; count1 = 1 ; } else if ( a [ i ] == max1 ) { count1 ++ ; } }
int max2 = int . MinValue , count2 = 0 ; for ( int i = 0 ; i < size2 ; i ++ ) { if ( b [ i ] > max2 ) { max2 = b [ i ] ; count2 = 1 ; } else if ( b [ i ] == max2 ) { count2 ++ ; } }
return ( float ) ( count1 * count2 ) / ( size1 * size2 ) ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 3 } ; int [ ] b = { 1 , 3 , 3 } ; int size1 = a . Length ; int size2 = b . Length ; Console . WriteLine ( probability ( a , b , size1 , size2 ) ) ; } }
public static int countDe ( int [ ] arr , int n ) { int [ ] v = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) v [ i ] = arr [ i ] ;
Array . Sort ( arr ) ;
int count1 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count1 ++ ;
Array . Reverse ( arr ) ;
int count2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count2 ++ ;
return ( Math . Min ( count1 , count2 ) ) ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 5 , 9 , 21 , 17 , 13 } ; int n = 5 ; Console . WriteLine ( " Minimum ▁ Dearrangement ▁ = ▁ " + countDe ( arr , n ) ) ; } }
static int maxOfSegmentMins ( int [ ] a , int n , int k ) {
if ( k == 1 ) return a . Min ( ) ; if ( k == 2 ) return Math . Max ( a [ 0 ] , a [ n - 1 ] ) ;
return a . Max ( ) ; }
static public void Main ( ) { int [ ] a = { - 10 , - 9 , - 8 , 2 , 7 , - 6 , - 5 } ; int n = a . Length ; int k = 2 ; Console . WriteLine ( maxOfSegmentMins ( a , n , k ) ) ; } }
static int printMinimumProduct ( int [ ] arr , int n ) {
int first_min = Math . Min ( arr [ 0 ] , arr [ 1 ] ) ; int second_min = Math . Max ( arr [ 0 ] , arr [ 1 ] ) ;
for ( int i = 2 ; i < n ; i ++ ) { if ( arr [ i ] < first_min ) { second_min = first_min ; first_min = arr [ i ] ; } else if ( arr [ i ] < second_min ) second_min = arr [ i ] ; } return first_min * second_min ; }
public static void Main ( ) { int [ ] a = { 11 , 8 , 5 , 7 , 5 , 100 } ; int n = a . Length ; Console . WriteLine ( printMinimumProduct ( a , n ) ) ; } }
static long noOfTriples ( long [ ] arr , int n ) {
Array . Sort ( arr ) ;
long count = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] == arr [ 2 ] ) count ++ ;
if ( arr [ 0 ] == arr [ 2 ] ) return ( count - 2 ) * ( count - 1 ) * ( count ) / 6 ;
else if ( arr [ 1 ] == arr [ 2 ] ) return ( count - 1 ) * ( count ) / 2 ;
return count ; }
public static void Main ( ) { long [ ] arr = { 1 , 3 , 3 , 4 } ; int n = arr . Length ; Console . Write ( noOfTriples ( arr , n ) ) ; } }
static bool checkReverse ( int [ ] arr , int n ) {
int [ ] temp = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { temp [ i ] = arr [ i ] ; }
Array . Sort ( temp ) ;
int front ; for ( front = 0 ; front < n ; front ++ ) { if ( temp [ front ] != arr [ front ] ) { break ; } }
int back ; for ( back = n - 1 ; back >= 0 ; back -- ) { if ( temp [ back ] != arr [ back ] ) { break ; } }
if ( front >= back ) { return true ; }
do { front ++ ; if ( arr [ front - 1 ] < arr [ front ] ) { return false ; } } while ( front != back ) ; return true ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 5 , 4 , 3 } ; int n = arr . Length ; if ( checkReverse ( arr , n ) ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " No " ) ; } } }
static bool checkReverse ( int [ ] arr , int n ) { if ( n == 1 ) { return true ; }
int i ; for ( i = 1 ; arr [ i - 1 ] < arr [ i ] && i < n ; i ++ ) ; if ( i == n ) { return true ; }
int j = i ; while ( j < n && arr [ j ] < arr [ j - 1 ] ) { if ( i > 1 && arr [ j ] < arr [ i - 2 ] ) { return false ; } j ++ ; } if ( j == n ) { return true ; }
int k = j ;
if ( arr [ k ] < arr [ i - 1 ] ) { return false ; } while ( k > 1 && k < n ) { if ( arr [ k ] < arr [ k - 1 ] ) { return false ; } k ++ ; } return true ; }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 4 , 10 , 9 , 8 } ; int n = arr . Length ; if ( checkReverse ( arr , n ) ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " No " ) ; } } }
using System ; public class GFG { static int MinOperation ( int [ ] a , int [ ] b , int n ) {
Array . Sort ( a ) ; Array . Sort ( b ) ;
int result = 0 ;
for ( int i = 0 ; i < n ; ++ i ) { if ( a [ i ] > b [ i ] ) result = result + Math . Abs ( a [ i ] - b [ i ] ) ; else if ( a [ i ] < b [ i ] ) result = result + Math . Abs ( a [ i ] - b [ i ] ) ; } return result ; }
public static void Main ( ) { int [ ] a = { 3 , 1 , 1 } ; int [ ] b = { 1 , 2 , 2 } ; int n = a . Length ; Console . WriteLine ( MinOperation ( a , b , n ) ) ; } }
static void sortExceptUandL ( int [ ] a , int l , int u , int n ) {
int [ ] b = new int [ n - ( u - l + 1 ) ] ; for ( int i = 0 ; i < l ; i ++ ) b [ i ] = a [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) b [ l + ( i - ( u + 1 ) ) ] = a [ i ] ;
Array . Sort < int > ( b , 0 , n - ( u - l + 1 ) ) ;
for ( int i = 0 ; i < l ; i ++ ) a [ i ] = b [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) a [ i ] = b [ l + ( i - ( u + 1 ) ) ] ; }
public static void Main ( ) { int [ ] a = { 5 , 4 , 3 , 12 , 14 , 9 } ; int n = a . Length ; int l = 2 , u = 4 ; sortExceptUandL ( a , l , u , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( a [ i ] + " ▁ " ) ; } }
using System ; public class GFG { static int sortExceptK ( int [ ] arr , int k , int n ) {
int temp = arr [ k ] ; arr [ k ] = arr [ n - 1 ] ; arr [ n - 1 ] = temp ;
Array . Sort ( arr , 0 , n - 1 ) ;
int last = arr [ n - 1 ] ;
for ( int i = n - 1 ; i > k ; i -- ) arr [ i ] = arr [ i - 1 ] ;
arr [ k ] = last ; return 0 ; }
public static void Main ( ) { int [ ] a = { 10 , 4 , 11 , 7 , 6 , 20 } ; int k = 2 ; int n = a . Length ; sortExceptK ( a , k , n ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( a [ i ] + " ▁ " ) ; } }
static int findMinSwaps ( int [ ] arr , int n ) {
int [ ] noOfZeroes = new int [ n ] ; int i , count = 0 ;
noOfZeroes [ n - 1 ] = 1 - arr [ n - 1 ] ; for ( i = n - 2 ; i >= 0 ; i -- ) { noOfZeroes [ i ] = noOfZeroes [ i + 1 ] ; if ( arr [ i ] == 0 ) noOfZeroes [ i ] ++ ; }
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 1 ) count += noOfZeroes [ i ] ; } return count ; }
public static void Main ( ) { int [ ] ar = { 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 } ; Console . WriteLine ( findMinSwaps ( ar , ar . Length ) ) ; } }
using System ; class GFG { static int minswaps ( int [ ] arr , int n ) { int count = 0 ; int num_unplaced_zeros = 0 ; for ( int index = n - 2 ; index >= 0 ; index -- ) { if ( arr [ index ] == 0 ) num_unplaced_zeros += 1 ; else count += num_unplaced_zeros ; } return count ; }
static void Main ( ) { int [ ] arr = { 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 } ; Console . WriteLine ( minswaps ( arr , 9 ) ) ; } }
public class Node { public int data ; public Node next ; } ;
static Node push ( Node head_ref , int new_data ) { Node new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
static void printList ( Node head ) { while ( head != null ) { Console . Write ( head . data + " - > " ) ; head = head . next ; } }
static void sortlist ( int [ ] arr , int N , Node head ) {
Dictionary < int , int > hash = new Dictionary < int , int > ( ) ; Node temp = head ; while ( temp != null ) { if ( hash . ContainsKey ( temp . data ) ) hash [ temp . data ] = hash [ temp . data ] + 1 ; else hash . Add ( temp . data , 1 ) ; temp = temp . next ; } temp = head ;
for ( int i = 0 ; i < N ; i ++ ) {
int frequency = hash [ arr [ i ] ] ; while ( frequency -- > 0 ) {
temp . data = arr [ i ] ; temp = temp . next ; } } }
public static void Main ( String [ ] args ) { Node head = null ; int [ ] arr = { 5 , 1 , 3 , 2 , 8 } ; int N = arr . Length ;
head = push ( head , 3 ) ; head = push ( head , 2 ) ; head = push ( head , 5 ) ; head = push ( head , 8 ) ; head = push ( head , 5 ) ; head = push ( head , 2 ) ; head = push ( head , 1 ) ;
sortlist ( arr , N , head ) ;
Console . Write ( " Sorted ▁ List : " + " STRNEWLINE " ) ; printList ( head ) ; } }
using System ; using System . Collections . Generic ; using System . Linq ; class GFG { static void printRepeating ( int [ ] arr , int size ) {
SortedSet < int > s = new SortedSet < int > ( arr ) ;
foreach ( var n in s ) { Console . Write ( n + " ▁ " ) ; } }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 2 , 2 , 1 } ; int n = arr . Length ; printRepeating ( arr , n ) ; } }
static int maxPartitions ( int [ ] arr , int n ) { int ans = 0 , max_so_far = 0 ; for ( int i = 0 ; i < n ; ++ i ) {
max_so_far = Math . Max ( max_so_far , arr [ i ] ) ;
if ( max_so_far == i ) ans ++ ; } return ans ; }
public static void Main ( ) { int [ ] arr = { 1 , 0 , 2 , 3 , 4 } ; int n = arr . Length ; Console . Write ( maxPartitions ( arr , n ) ) ; } }
public static void cuttringRopes ( int [ ] Ropes , int n ) {
Array . Sort ( Ropes ) ; int singleOperation = 0 ;
int cuttingLenght = Ropes [ 0 ] ;
for ( int i = 1 ; i < n ; i ++ ) {
if ( Ropes [ i ] - cuttingLenght > 0 ) { Console . Write ( n - i + " ▁ " ) ;
cuttingLenght = Ropes [ i ] ; singleOperation ++ ; } }
if ( singleOperation == 0 ) Console . Write ( "0" ) ; }
public static void Main ( ) { int [ ] Ropes = { 5 , 1 , 1 , 2 , 3 , 5 } ; int n = Ropes . Length ; cuttringRopes ( Ropes , n ) ; } }
public static void rankify ( int [ ] A , int n ) {
float [ ] R = new float [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) { int r = 1 , s = 1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( j != i && A [ j ] < A [ i ] ) r += 1 ; if ( j != i && A [ j ] == A [ i ] ) s += 1 ; }
R [ i ] = r + ( float ) ( s - 1 ) / ( float ) 2 ; } for ( int i = 0 ; i < n ; i ++ ) Console . Write ( R [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] A = { 1 , 2 , 5 , 2 , 1 , 25 , 2 } ; int n = A . Length ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( A [ i ] + " ▁ " ) ; Console . WriteLine ( ) ; rankify ( A , n ) ; } }
public static int min_noOf_operation ( int [ ] arr , int n , int k ) { int noOfSubtraction ; int res = 0 ; for ( int i = 1 ; i < n ; i ++ ) { noOfSubtraction = 0 ; if ( arr [ i ] > arr [ i - 1 ] ) {
noOfSubtraction = ( arr [ i ] - arr [ i - 1 ] ) / k ;
if ( ( arr [ i ] - arr [ i - 1 ] ) % k != 0 ) noOfSubtraction ++ ;
arr [ i ] = arr [ i ] - k * noOfSubtraction ; }
res = res + noOfSubtraction ; } return res ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 2 , 3 } ; int N = 4 ; int k = 5 ; Console . WriteLine ( min_noOf_operation ( arr , N , k ) ) ; } }
using System ; class GFG { static int maxSum ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += ( arr [ i ] * i ) ; return sum ; }
static public void Main ( ) { int [ ] arr = { 3 , 5 , 6 , 1 } ; int n = arr . Length ; Console . WriteLine ( maxSum ( arr , n ) ) ; } }
static int countPairs ( int [ ] a , int n , int k ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( Math . Abs ( a [ j ] - a [ i ] ) < k ) res ++ ; return res ; }
public static void Main ( ) { int [ ] a = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = a . Length ; Console . WriteLine ( countPairs ( a , n , k ) ) ; } }
using System ; class GFG { static int countPairs ( int [ ] a , int n , int k ) {
Array . Sort ( a ) ; int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j = i + 1 ; while ( j < n && a [ j ] - a [ i ] < k ) { res ++ ; j ++ ; } } return res ; }
public static void Main ( ) { int [ ] a = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = a . Length ; Console . WriteLine ( countPairs ( a , n , k ) ) ; } }
static void sortedMerge ( int [ ] a , int [ ] b , int [ ] res , int n , int m ) {
Array . Sort ( a ) ; Array . Sort ( b ) ;
int i = 0 , j = 0 , k = 0 ; while ( i < n && j < m ) { if ( a [ i ] <= b [ j ] ) { res [ k ] = a [ i ] ; i += 1 ; k += 1 ; } else { res [ k ] = b [ j ] ; j += 1 ; k += 1 ; } } while ( i < n ) {
res [ k ] = a [ i ] ; i += 1 ; k += 1 ; } while ( j < m ) {
res [ k ] = b [ j ] ; j += 1 ; k += 1 ; } }
public static void Main ( ) { int [ ] a = { 10 , 5 , 15 } ; int [ ] b = { 20 , 3 , 2 , 12 } ; int n = a . Length ; int m = b . Length ;
int [ ] res = new int [ n + m ] ; sortedMerge ( a , b , res , n , m ) ; Console . Write ( " Sorted ▁ merged ▁ list ▁ : " ) ; for ( int i = 0 ; i < n + m ; i ++ ) Console . Write ( " ▁ " + res [ i ] ) ; } }
static int findMaxPairs ( int [ ] a , int [ ] b , int n , int k ) {
Array . Sort ( a ) ;
Array . Sort ( b ) ;
bool [ ] flag = new bool [ n ] ;
int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( Math . Abs ( a [ i ] - b [ j ] ) <= k && flag [ j ] == false ) {
result ++ ;
flag [ j ] = true ;
break ; } } } return result ; }
public static void Main ( ) { int [ ] a = { 10 , 15 , 20 } ; int [ ] b = { 17 , 12 , 24 } ; int n = a . Length ; int k = 3 ; Console . WriteLine ( findMaxPairs ( a , b , n , k ) ) ; } }
static int findMaxPairs ( int [ ] a , int [ ] b , int n , int k ) {
Array . Sort ( a ) ;
Array . Sort ( b ) ; int result = 0 ; for ( int i = 0 , j = 0 ; i < n && j < n ; ) { if ( Math . Abs ( a [ i ] - b [ j ] ) <= k ) { result ++ ;
i ++ ; j ++ ; }
else if ( a [ i ] > b [ j ] ) j ++ ;
else i ++ ; } return result ; }
public static void Main ( String [ ] args ) { int [ ] a = { 10 , 15 , 20 } ; int [ ] b = { 17 , 12 , 24 } ; int n = a . Length ; int k = 3 ; Console . WriteLine ( findMaxPairs ( a , b , n , k ) ) ; } }
static int sumOfMinAbsDifferences ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
int sum = 0 ;
sum += Math . Abs ( arr [ 0 ] - arr [ 1 ] ) ;
sum += Math . Abs ( arr [ n - 1 ] - arr [ n - 2 ] ) ;
for ( int i = 1 ; i < n - 1 ; i ++ ) sum += Math . Min ( Math . Abs ( arr [ i ] - arr [ i - 1 ] ) , Math . Abs ( arr [ i ] - arr [ i + 1 ] ) ) ;
return sum ; }
public static void Main ( ) { int [ ] arr = { 5 , 10 , 1 , 4 , 8 , 7 } ; int n = arr . Length ; Console . Write ( " Sum ▁ = ▁ " + sumOfMinAbsDifferences ( arr , n ) ) ; } }
static int findSmallestDifference ( int [ ] A , int [ ] B , int m , int n ) {
Array . Sort ( A ) ; Array . Sort ( B ) ; int a = 0 , b = 0 ;
int result = int . MaxValue ;
while ( a < m && b < n ) { if ( Math . Abs ( A [ a ] - B [ b ] ) < result ) result = Math . Abs ( A [ a ] - B [ b ] ) ;
if ( A [ a ] < B [ b ] ) a ++ ; else b ++ ; }
return result ; }
int [ ] A = { 1 , 2 , 11 , 5 } ;
int [ ] B = { 4 , 12 , 19 , 23 , 127 , 235 } ;
int m = A . Length ; int n = B . Length ;
Console . Write ( findSmallestDifference ( A , B , m , n ) ) ; } }
static int arraySortedOrNot ( int [ ] arr , int n ) {
if ( n == 1 n == 0 ) return 1 ;
if ( arr [ n - 1 ] < arr [ n - 2 ] ) return 0 ;
return arraySortedOrNot ( arr , n - 1 ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 20 , 23 , 23 , 45 , 78 , 88 } ; int n = arr . Length ; if ( arraySortedOrNot ( arr , n ) != 0 ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
static bool arraySortedOrNot ( int [ ] a , int n ) {
if ( n == 1 n == 0 ) { return true ; }
return a [ n - 1 ] >= a [ n - 2 ] && arraySortedOrNot ( a , n - 1 ) ; }
static public void Main ( ) { int [ ] arr = { 20 , 23 , 23 , 45 , 78 , 88 } ; int n = arr . Length ;
if ( arraySortedOrNot ( arr , n ) ) { Console . WriteLine ( " Yes " ) ; } else { Console . WriteLine ( " No " ) ; } } }
static bool arraySortedOrNot ( int [ ] arr , int n ) {
if ( n == 0 n == 1 ) return true ; for ( int i = 1 ; i < n ; i ++ )
if ( arr [ i - 1 ] > arr [ i ] ) return false ;
return true ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 20 , 23 , 23 , 45 , 78 , 88 } ; int n = arr . Length ; if ( arraySortedOrNot ( arr , n ) ) Console . Write ( " Yes STRNEWLINE " ) ; else Console . Write ( " No STRNEWLINE " ) ; } }
static void findLarger ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
for ( int i = n - 1 ; i >= n / 2 ; i -- ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 3 , 6 , 1 , 0 , 9 } ; int n = arr . Length ; findLarger ( arr , n ) ; } }
public class GFG { static int minSwapsToSort ( int [ ] arr , int n ) {
List < List < int > > arrPos = new List < List < int > > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { arrPos . Add ( new List < int > ( ) { arr [ i ] , i } ) ; }
arrPos = arrPos . OrderBy ( x => x [ 0 ] ) . ToList ( ) ;
bool [ ] vis = new bool [ n ] ; Array . Fill ( vis , false ) ;
int ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( vis [ i ] arrPos [ i ] [ 1 ] == i ) continue ;
int cycle_size = 0 ; int j = i ; while ( ! vis [ j ] ) { vis [ j ] = true ;
j = arrPos [ j ] [ 1 ] ; cycle_size ++ ; }
ans += ( cycle_size - 1 ) ; }
return ans ; }
static int minSwapToMakeArraySame ( int [ ] a , int [ ] b , int n ) {
Dictionary < int , int > mp = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { mp . Add ( b [ i ] , i ) ; }
for ( int i = 0 ; i < n ; i ++ ) { b [ i ] = mp [ a [ i ] ] ; }
return minSwapsToSort ( b , n ) ; }
static public void Main ( ) { int [ ] a = { 3 , 6 , 4 , 8 } ; int [ ] b = { 4 , 6 , 8 , 3 } ; int n = a . Length ; Console . WriteLine ( minSwapToMakeArraySame ( a , b , n ) ) ; } }
static int findSingle ( int [ ] ar , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
public static void Main ( ) { int [ ] ar = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = ar . Length ; Console . Write ( " Element ▁ occurring ▁ once ▁ is ▁ " + findSingle ( ar , n ) + " ▁ " ) ; } }
static int singleNumber ( int [ ] nums , int n ) { Dictionary < int , int > m = new Dictionary < int , int > ( ) ; long sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( ! m . ContainsKey ( nums [ i ] ) ) { sum1 += nums [ i ] ; m . Add ( nums [ i ] , 1 ) ; } sum2 += nums [ i ] ; }
return ( int ) ( 2 * ( sum1 ) - sum2 ) ; }
public static void Main ( String [ ] args ) { int [ ] a = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = 7 ; Console . WriteLine ( singleNumber ( a , n ) ) ; int [ ] b = { 15 , 18 , 16 , 18 , 16 , 15 , 89 } ; Console . WriteLine ( singleNumber ( b , n ) ) ; } }
static int singleelement ( int [ ] arr , int n ) { int low = 0 , high = n - 2 ; int mid ; while ( low <= high ) { mid = ( low + high ) / 2 ; if ( arr [ mid ] == arr [ mid ^ 1 ] ) { low = mid + 1 ; } else { high = mid - 1 ; } } return arr [ low ] ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int size = 7 ; Array . Sort ( arr ) ; Console . WriteLine ( singleelement ( arr , size ) ) ; } }
using System ; class Test { static int [ ] arr = new int [ ] { 5 , 1 , 3 , 4 , 7 } ; static int countTriplets ( int n , int sum ) {
int ans = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) {
for ( int j = i + 1 ; j < n - 1 ; j ++ ) {
for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] + arr [ j ] + arr [ k ] < sum ) ans ++ ; } } return ans ; }
public static void Main ( ) { int sum = 12 ; Console . Write ( countTriplets ( arr . Length , sum ) ) ; } }
using System ; class GFG { static int [ ] arr = new int [ ] { 5 , 1 , 3 , 4 , 7 } ; static int countTriplets ( int n , int sum ) {
Array . Sort ( arr ) ;
int ans = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) {
int j = i + 1 , k = n - 1 ;
while ( j < k ) {
if ( arr [ i ] + arr [ j ] + arr [ k ] >= sum ) k -- ;
else {
ans += ( k - j ) ; j ++ ; } } } return ans ; }
public static void Main ( ) { int sum = 12 ; Console . Write ( countTriplets ( arr . Length , sum ) ) ; } }
static int countTriplets ( int [ ] a , int n ) {
List < int > s = new List < int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) s . Add ( a [ i ] ) ;
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int xr = a [ i ] ^ a [ j ] ;
if ( s . Exists ( item => item == xr ) && xr != a [ i ] && xr != a [ j ] ) count ++ ; } }
return count / 3 ; }
static void Main ( ) { int [ ] a = new int [ ] { 1 , 3 , 5 , 10 , 14 , 15 } ; int n = a . Length ; Console . Write ( countTriplets ( a , n ) ) ; } }
static int getMissingNo ( int [ ] a , int n ) { int i , total = 1 ; for ( i = 2 ; i <= ( n + 1 ) ; i ++ ) { total += i ; total -= a [ i - 2 ] ; } return total ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 5 } ; Console . Write ( getMissingNo ( arr , ( arr . Length ) ) ) ; } }
static int getMissingNo ( int [ ] a , int n ) { int n_elements_sum = ( n * ( n + 1 ) / 2 ) ; int sum = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) sum = sum + a [ i ] ; return ( n_elements_sum - sum ) ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 4 , 5 , 6 } ; int miss = getMissingNo ( a , 5 ) ; Console . Write ( miss ) ; } }
static int countOccurrences ( int [ ] arr , int n , int x ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( x == arr [ i ] ) res ++ ; return res ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = arr . Length ; int x = 2 ; Console . Write ( countOccurrences ( arr , n , x ) ) ; } }
static int binarySearch ( int [ ] arr , int l , int r , int x ) { if ( r < l ) return - 1 ; int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
static int countOccurrences ( int [ ] arr , int n , int x ) { int ind = binarySearch ( arr , 0 , n - 1 , x ) ;
if ( ind == - 1 ) return 0 ;
int count = 1 ; int left = ind - 1 ; while ( left >= 0 && arr [ left ] == x ) { count ++ ; left -- ; }
int right = ind + 1 ; while ( right < n && arr [ right ] == x ) { count ++ ; right ++ ; } return count ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = arr . Length ; int x = 2 ; Console . Write ( countOccurrences ( arr , n , x ) ) ; } }
static void printClosest ( int [ ] arr , int n , int x ) {
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 , diff = int . MaxValue ;
while ( r > l ) {
if ( Math . Abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . Abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } Console . Write ( " ▁ The ▁ closest ▁ pair ▁ is ▁ " + arr [ res_l ] + " ▁ and ▁ " + arr [ res_r ] ) ; }
public static void Main ( ) { int [ ] arr = { 10 , 22 , 28 , 29 , 30 , 40 } ; int x = 54 ; int n = arr . Length ; printClosest ( arr , n , x ) ; } }
static void constructTree ( int n , int d , int h ) { if ( d == 1 ) {
if ( n == 2 && h == 1 ) { Console . WriteLine ( "1 ▁ 2" ) ; return ; }
Console . WriteLine ( " - 1" ) ; return ; } if ( d > 2 * h ) { Console . WriteLine ( " - 1" ) ; return ; }
for ( int i = 1 ; i <= h ; i ++ ) Console . WriteLine ( i + " ▁ " + ( i + 1 ) ) ; if ( d > h ) {
Console . WriteLine ( "1" + " ▁ " + ( h + 2 ) ) ; for ( int i = h + 2 ; i <= d ; i ++ ) { Console . WriteLine ( i + " ▁ " + ( i + 1 ) ) ; } }
for ( int i = d + 1 ; i < n ; i ++ ) { int k = 1 ; if ( d == h ) k = 2 ; Console . WriteLine ( k + " ▁ " + ( i + 1 ) ) ; } }
public static void Main ( String [ ] args ) { int n = 5 , d = 3 , h = 2 ; constructTree ( n , d , h ) ; } }
static int countOnes ( int [ ] arr , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
public static void Main ( ) { int [ ] arr = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = arr . Length ; Console . WriteLine ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ " + " array ▁ is ▁ " + countOnes ( arr , 0 , n - 1 ) ) ; } }
static int findMissingUtil ( int [ ] arr1 , int [ ] arr2 , int N ) {
if ( N == 1 ) return arr1 [ 0 ] ;
if ( arr1 [ 0 ] != arr2 [ 0 ] ) return arr1 [ 0 ] ;
int lo = 0 , hi = N - 1 ;
while ( lo < hi ) { int mid = ( lo + hi ) / 2 ;
if ( arr1 [ mid ] == arr2 [ mid ] ) lo = mid ; else hi = mid ;
if ( lo == hi - 1 ) break ; }
return arr1 [ hi ] ; }
static void findMissing ( int [ ] arr1 , int [ ] arr2 , int M , int N ) { if ( N == M - 1 ) Console . WriteLine ( " Missing ▁ Element ▁ is ▁ " + findMissingUtil ( arr1 , arr2 , M ) + " STRNEWLINE " ) ; else if ( M == N - 1 ) Console . WriteLine ( " Missing ▁ Element ▁ is ▁ " + findMissingUtil ( arr2 , arr1 , N ) + " STRNEWLINE " ) ; else Console . WriteLine ( " Invalid ▁ Input " ) ; }
public static void Main ( ) { int [ ] arr1 = { 1 , 4 , 5 , 7 , 9 } ; int [ ] arr2 = { 4 , 5 , 7 , 9 } ; int M = arr1 . Length ; int N = arr2 . Length ; findMissing ( arr1 , arr2 , M , N ) ; } }
static void findMissing ( int [ ] arr1 , int [ ] arr2 , int M , int N ) { if ( M != N - 1 && N != M - 1 ) { Console . WriteLine ( " Invalid ▁ Input " ) ; return ; }
int res = 0 ; for ( int i = 0 ; i < M ; i ++ ) res = res ^ arr1 [ i ] ; for ( int i = 0 ; i < N ; i ++ ) res = res ^ arr2 [ i ] ; Console . WriteLine ( " Missing ▁ element ▁ is ▁ " + res ) ; }
public static void Main ( ) { int [ ] arr1 = { 4 , 1 , 5 , 9 , 7 } ; int [ ] arr2 = { 7 , 5 , 9 , 4 } ; int M = arr1 . Length ; int N = arr2 . Length ; findMissing ( arr1 , arr2 , M , N ) ; } }
static void findFourElements ( int [ ] arr , int n , int X ) {
Dictionary < int , pair > mp = new Dictionary < int , pair > ( ) ; for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( mp . ContainsKey ( arr [ i ] + arr [ j ] ) ) mp [ arr [ i ] + arr [ j ] ] = new pair ( i , j ) ; else mp . Add ( arr [ i ] + arr [ j ] , new pair ( i , j ) ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int sum = arr [ i ] + arr [ j ] ;
if ( mp . ContainsKey ( X - sum ) ) {
pair p = mp [ X - sum ] ; if ( p . first != i && p . first != j && p . second != i && p . second != j ) { Console . Write ( arr [ i ] + " , ▁ " + arr [ j ] + " , ▁ " + arr [ p . first ] + " , ▁ " + arr [ p . second ] ) ; return ; } } } } }
public static void Main ( String [ ] args ) { int [ ] arr = { 10 , 20 , 30 , 40 , 1 , 2 } ; int n = arr . Length ; int X = 91 ;
findFourElements ( arr , n , X ) ; } }
using System ; using System . Collections . Generic ; class GFG {
static void fourSum ( int X , int [ ] arr , Dictionary < int , Tuple < int , int > > Map , int N ) { int [ ] temp = new int [ N ] ;
for ( int i = 0 ; i < N ; i ++ ) temp [ i ] = 0 ;
for ( int i = 0 ; i < N - 1 ; i ++ ) {
for ( int j = i + 1 ; j < N ; j ++ ) {
int curr_sum = arr [ i ] + arr [ j ] ;
if ( Map . ContainsKey ( X - curr_sum ) ) {
Tuple < int , int > p = Map [ X - curr_sum ] ; if ( p . Item1 != i && p . Item2 != i && p . Item1 != j && p . Item2 != j && temp [ p . Item1 ] == 0 && temp [ p . Item2 ] == 0 && temp [ i ] == 0 && temp [ j ] == 0 ) {
Console . Write ( arr [ i ] + " , " + arr [ j ] + " , " + arr [ p . Item1 ] + " , " + arr [ p . Item2 ] ) ; temp [ p . Item2 ] = 1 ; temp [ i ] = 1 ; temp [ j ] = 1 ; break ; } } } } }
static Dictionary < int , Tuple < int , int > > twoSum ( int [ ] nums , int N ) { Dictionary < int , Tuple < int , int > > Map = new Dictionary < int , Tuple < int , int > > ( ) ; for ( int i = 0 ; i < N - 1 ; i ++ ) { for ( int j = i + 1 ; j < N ; j ++ ) { Map [ nums [ i ] + nums [ j ] ] = new Tuple < int , int > ( i , j ) ; } } return Map ; }
static void Main ( ) { int [ ] arr = { 10 , 20 , 30 , 40 , 1 , 2 } ; int n = arr . Length ; int X = 91 ; Dictionary < int , Tuple < int , int > > Map = twoSum ( arr , n ) ;
fourSum ( X , arr , Map , n ) ; } }
static int search ( int [ ] arr , int n , int x ) {
int i = 0 ; while ( i < n ) {
if ( arr [ i ] == x ) return i ;
i = i + Math . Abs ( arr [ i ] - x ) ; } Console . WriteLine ( " number ▁ is ▁ not " + " ▁ present ! " ) ; return - 1 ; }
public static void Main ( ) { int [ ] arr = { 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 } ; int n = arr . Length ; int x = 3 ; Console . WriteLine ( " Element ▁ " + x + " ▁ is ▁ present ▁ at ▁ index ▁ " + search ( arr , n , 3 ) ) ; } }
using System ; class GFG { static void thirdLargest ( int [ ] arr , int arr_size ) {
if ( arr_size < 3 ) { Console . Write ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] ; for ( int i = 1 ; i < arr_size ; i ++ ) if ( arr [ i ] > first ) first = arr [ i ] ;
int second = - int . MaxValue ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > second && arr [ i ] < first ) second = arr [ i ] ;
int third = - int . MaxValue ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > third && arr [ i ] < second ) third = arr [ i ] ; Console . Write ( " The ▁ third ▁ Largest ▁ " + " element ▁ is ▁ " + third ) ; }
public static void Main ( ) { int [ ] arr = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = arr . Length ; thirdLargest ( arr , n ) ; } }
using System ; class GFG { static void thirdLargest ( int [ ] arr , int arr_size ) {
if ( arr_size < 3 ) { Console . Write ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] , second = int . MinValue , third = int . MinValue ;
for ( int i = 1 ; i < arr_size ; i ++ ) {
if ( arr [ i ] > first ) { third = second ; second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) { third = second ; second = arr [ i ] ; }
else if ( arr [ i ] > third ) { third = arr [ i ] ; } } Console . Write ( " The ▁ third ▁ Largest ▁ element ▁ is ▁ " + third ) ; }
public static void Main ( ) { int [ ] arr = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = arr . Length ; thirdLargest ( arr , n ) ; } }
static bool checkPair ( int [ ] arr , int n ) {
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum += arr [ i ] ; }
if ( sum % 2 != 0 ) { return false ; } sum = sum / 2 ;
HashSet < int > s = new HashSet < int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { int val = sum - arr [ i ] ;
if ( s . Contains ( val ) ) { Console . Write ( " Pair ▁ elements ▁ are ▁ { 0 } ▁ and ▁ { 1 } STRNEWLINE " , arr [ i ] , val ) ; return true ; } s . Add ( arr [ i ] ) ; } return false ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 2 , 11 , 5 , 1 , 4 , 7 } ; int n = arr . Length ; if ( checkPair ( arr , n ) == false ) { Console . Write ( " No ▁ pair ▁ found " ) ; } } }
static String search ( int [ ] arr , int n , int x ) {
if ( arr [ n - 1 ] == x ) return " Found " ; int backup = arr [ n - 1 ] ; arr [ n - 1 ] = x ;
for ( int i = 0 ; ; i ++ ) {
if ( arr [ i ] == x ) {
arr [ n - 1 ] = backup ;
if ( i < n - 1 ) return " Found " ;
return " Not ▁ Found " ; } } }
public static void Main ( ) { int [ ] arr = { 4 , 6 , 1 , 5 , 8 } ; int n = arr . Length ; int x = 1 ; Console . WriteLine ( search ( arr , n , x ) ) ; } }
static Point sequence ( List < int > a ) { if ( a . Count == 0 ) return new Point ( 0 , 0 ) ; int s = 0 ; int e = a . Count - 1 ; while ( s < e ) { int m = ( s + e ) / 2 ;
if ( a [ m ] >= m + a [ 0 ] ) s = m + 1 ;
else e = m ; } return new Point ( a [ s ] , a . Count - ( a [ a . Count - 1 ] - a [ 0 ] ) ) ; }
public static void Main ( String [ ] args ) { int [ ] array = new int [ ] { 1 , 2 , 3 , 4 , 4 , 4 , 5 , 6 } ; Point p = sequence ( new List < int > ( array ) ) ; Console . WriteLine ( " Repeated ▁ element ▁ is ▁ " + p . first + " , ▁ it ▁ appears ▁ " + p . second + " ▁ times " ) ; } }
using System ; public class GFG { public static int findMajority ( int [ ] arr , int n ) { return arr [ n / 2 ] ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 2 , 3 } ; int n = arr . Length ; Console . WriteLine ( findMajority ( arr , n ) ) ; } }
using System ; class GFG { static void minAdjDifference ( int [ ] arr , int n ) { if ( n < 2 ) return ;
int res = Math . Abs ( arr [ 1 ] - arr [ 0 ] ) ; for ( int i = 2 ; i < n ; i ++ ) res = Math . Min ( res , Math . Abs ( arr [ i ] - arr [ i - 1 ] ) ) ;
res = Math . Min ( res , Math . Abs ( arr [ n - 1 ] - arr [ 0 ] ) ) ; Console . Write ( " Min ▁ Difference ▁ = ▁ " + res ) ; }
public static void Main ( ) { int [ ] a = { 10 , 12 , 13 , 15 , 10 } ; int n = a . Length ; minAdjDifference ( a , n ) ; } }
using System ; class GFG { static void Print3Smallest ( int [ ] array , int n ) { int firstmin = int . MaxValue ; int secmin = int . MaxValue ; int thirdmin = int . MaxValue ; for ( int i = 0 ; i < n ; i ++ ) {
if ( array [ i ] < firstmin ) { thirdmin = secmin ; secmin = firstmin ; firstmin = array [ i ] ; }
else if ( array [ i ] < secmin ) { thirdmin = secmin ; secmin = array [ i ] ; }
else if ( array [ i ] < thirdmin ) thirdmin = array [ i ] ; } Console . WriteLine ( " First ▁ min ▁ = ▁ " + firstmin ) ; Console . WriteLine ( " Second ▁ min ▁ = ▁ " + secmin ) ; Console . WriteLine ( " Third ▁ min ▁ = ▁ " + thirdmin ) ; }
static void Main ( ) { int [ ] array = new int [ ] { 4 , 9 , 1 , 32 , 12 } ; int n = array . Length ; Print3Smallest ( array , n ) ; } }
using System ; class GFG { static int getMin ( int [ ] arr , int i , int n ) {
return ( n == 1 ) ? arr [ i ] : Math . Min ( arr [ i ] , getMin ( arr , i + 1 , n - 1 ) ) ; } static int getMax ( int [ ] arr , int i , int n ) {
return ( n == 1 ) ? arr [ i ] : Math . Max ( arr [ i ] , getMax ( arr , i + 1 , n - 1 ) ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 12 , 1234 , 45 , 67 , 1 } ; int n = arr . Length ; Console . WriteLine ( " Minimum ▁ element ▁ of ▁ array : ▁ " + getMin ( arr , 0 , n ) ) ; Console . WriteLine ( " Maximum ▁ element ▁ of ▁ array : ▁ " + getMax ( arr , 0 , n ) ) ; } }
static int getMin ( int [ ] arr , int n ) { return arr . Min ( ) ; } static int getMax ( int [ ] arr , int n ) { return arr . Max ( ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 12 , 1234 , 45 , 67 , 1 } ; int n = arr . Length ; Console . WriteLine ( " Minimum ▁ element ▁ of ▁ array : ▁ " + getMin ( arr , n ) ) ; Console . WriteLine ( " Maximum ▁ element ▁ of ▁ array : ▁ " + getMax ( arr , n ) ) ; } }
public static void findCounts ( int [ ] arr , int n ) {
int [ ] hash = new int [ n ] ;
int i = 0 ; while ( i < n ) {
hash [ arr [ i ] - 1 ] ++ ;
i ++ ; } Console . WriteLine ( " STRNEWLINE Below ▁ are ▁ counts ▁ " + " of ▁ all ▁ elements " ) ; for ( i = 0 ; i < n ; i ++ ) { Console . WriteLine ( ( i + 1 ) + " ▁ - > ▁ " + hash [ i ] ) ; } }
static public void Main ( ) { int [ ] arr = new int [ ] { 2 , 3 , 3 , 2 , 5 } ; findCounts ( arr , arr . Length ) ; int [ ] arr1 = new int [ ] { 1 } ; findCounts ( arr1 , arr1 . Length ) ; int [ ] arr3 = new int [ ] { 4 , 4 , 4 , 4 } ; findCounts ( arr3 , arr3 . Length ) ; int [ ] arr2 = new int [ ] { 1 , 3 , 5 , 7 , 9 , 1 , 3 , 5 , 7 , 9 , 1 } ; findCounts ( arr2 , arr2 . Length ) ; int [ ] arr4 = new int [ ] { 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 } ; findCounts ( arr4 , arr4 . Length ) ; int [ ] arr5 = new int [ ] { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 } ; findCounts ( arr5 , arr5 . Length ) ; int [ ] arr6 = new int [ ] { 11 , 10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 } ; findCounts ( arr6 , arr6 . Length ) ; } }
void findCounts ( int [ ] arr , int n ) {
int i = 0 ; while ( i < n ) {
if ( arr [ i ] <= 0 ) { i ++ ; continue ; }
int elementIndex = arr [ i ] - 1 ;
if ( arr [ elementIndex ] > 0 ) { arr [ i ] = arr [ elementIndex ] ;
arr [ elementIndex ] = - 1 ; } else {
arr [ elementIndex ] -- ;
arr [ i ] = 0 ; i ++ ; } } Console . Write ( " STRNEWLINE Below ▁ are ▁ counts ▁ of ▁ " + " all ▁ elements " + " STRNEWLINE " ) ; for ( int j = 0 ; j < n ; j ++ ) Console . Write ( j + 1 + " - > " + Math . Abs ( arr [ j ] ) + " STRNEWLINE " ) ; }
public static void Main ( ) { GFG count = new GFG ( ) ; int [ ] arr = { 2 , 3 , 3 , 2 , 5 } ; count . findCounts ( arr , arr . Length ) ; int [ ] arr1 = { 1 } ; count . findCounts ( arr1 , arr1 . Length ) ; int [ ] arr3 = { 4 , 4 , 4 , 4 } ; count . findCounts ( arr3 , arr3 . Length ) ; int [ ] arr2 = { 1 , 3 , 5 , 7 , 9 , 1 , 3 , 5 , 7 , 9 , 1 } ; count . findCounts ( arr2 , arr2 . Length ) ; int [ ] arr4 = { 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 } ; count . findCounts ( arr4 , arr4 . Length ) ; int [ ] arr5 = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 } ; count . findCounts ( arr5 , arr5 . Length ) ; int [ ] arr6 = { 11 , 10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 } ; count . findCounts ( arr6 , arr6 . Length ) ; } }
internal virtual void printfrequency ( int [ ] arr , int n ) {
for ( int j = 0 ; j < n ; j ++ ) { arr [ j ] = arr [ j ] - 1 ; }
for ( int i = 0 ; i < n ; i ++ ) { arr [ arr [ i ] % n ] = arr [ arr [ i ] % n ] + n ; }
for ( int i = 0 ; i < n ; i ++ ) { Console . WriteLine ( i + 1 + " - > " + arr [ i ] / n ) ; } }
public static void Main ( string [ ] args ) { CountFrequency count = new CountFrequency ( ) ; int [ ] arr = new int [ ] { 2 , 3 , 3 , 2 , 5 } ; int n = arr . Length ; count . printfrequency ( arr , n ) ; } }
static int deleteElement ( int [ ] arr , int n , int x ) {
int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == x ) break ;
if ( i < n ) {
n = n - 1 ; for ( int j = i ; j < n ; j ++ ) arr [ j ] = arr [ j + 1 ] ; } return n ; }
public static void Main ( ) { int [ ] arr = { 11 , 15 , 6 , 8 , 9 , 10 } ; int n = arr . Length ; int x = 6 ;
n = deleteElement ( arr , n , x ) ; Console . WriteLine ( " Modified ▁ array ▁ is " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static int deleteElement ( int [ ] arr , int n , int x ) {
if ( arr [ n - 1 ] == x ) return ( n - 1 ) ;
int prev = arr [ n - 1 ] , i ; for ( i = n - 2 ; i >= 0 && arr [ i ] != x ; i -- ) { int curr = arr [ i ] ; arr [ i ] = prev ; prev = curr ; }
if ( i < 0 ) return 0 ;
arr [ i ] = prev ; return ( n - 1 ) ; }
public static void Main ( ) { int [ ] arr = { 11 , 15 , 6 , 8 , 9 , 10 } ; int n = arr . Length ; int x = 6 ;
n = deleteElement ( arr , n , x ) ; Console . WriteLine ( " Modified ▁ array ▁ is " ) ; for ( int i = 0 ; i < n ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
static int getInvCount ( int [ ] arr , int n ) {
int invcount = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) {
int small = 0 ; for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) small ++ ;
int great = 0 ; for ( int j = i - 1 ; j >= 0 ; j -- ) if ( arr [ i ] < arr [ j ] ) great ++ ;
invcount += great * small ; } return invcount ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 8 , 4 , 2 , 1 } ; int n = arr . Length ; Console . WriteLine ( " Inversion ▁ count ▁ : ▁ " + getInvCount ( arr , n ) ) ; } }
public static int maxWater ( int [ ] arr , int n ) {
int res = 0 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
int left = arr [ i ] ; for ( int j = 0 ; j < i ; j ++ ) { left = Math . Max ( left , arr [ j ] ) ; }
int right = arr [ i ] ; for ( int j = i + 1 ; j < n ; j ++ ) { right = Math . Max ( right , arr [ j ] ) ; }
res += Math . Min ( left , right ) - arr [ i ] ; } return res ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = arr . Length ; Console . Write ( maxWater ( arr , n ) ) ; } }
using System ; class Test { static int [ ] arr = new int [ ] { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ;
static int findWater ( int n ) {
int [ ] left = new int [ n ] ;
int [ ] right = new int [ n ] ;
int water = 0 ;
left [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) left [ i ] = Math . Max ( left [ i - 1 ] , arr [ i ] ) ;
right [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) right [ i ] = Math . Max ( right [ i + 1 ] , arr [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) water += Math . Min ( left [ i ] , right [ i ] ) - arr [ i ] ; return water ; }
public static void Main ( ) { Console . WriteLine ( " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " + findWater ( arr . Length ) ) ; } }
using System ; class GFG { static int findWater ( int [ ] arr , int n ) {
int result = 0 ;
int left_max = 0 , right_max = 0 ;
int lo = 0 , hi = n - 1 ; while ( lo <= hi ) { if ( arr [ lo ] < arr [ hi ] ) { if ( arr [ lo ] > left_max )
left_max = arr [ lo ] ; else
result += left_max - arr [ lo ] ; lo ++ ; } else { if ( arr [ hi ] > right_max )
right_max = arr [ hi ] ; else result += - [ hi ] ; hi -- ; } } return result ; }
public static void Main ( ) { int [ ] arr = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int result = Trap . findWater ( arr , arr . length ) ; System . out . print ( " ▁ Total ▁ trapping ▁ water : ▁ " + result ) ; } }
static int maxWater ( int [ ] arr , int n ) { int size = n - 1 ;
int prev = arr [ 0 ] ;
int prev_index = 0 ; int water = 0 ;
int temp = 0 ; for ( int i = 1 ; i <= size ; i ++ ) {
if ( arr [ i ] >= prev ) { prev = arr [ i ] ; prev_index = i ;
temp = 0 ; } else {
water += prev - arr [ i ] ;
temp += prev - arr [ i ] ; } }
if ( prev_index < size ) {
water -= temp ;
prev = arr [ size ] ;
for ( int i = size ; i >= prev_index ; i -- ) {
if ( arr [ i ] >= prev ) { prev = arr [ i ] ; } else { water += prev - arr [ i ] ; } } }
return water ; }
static void Main ( ) { int [ ] arr = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = arr . Length ; Console . WriteLine ( maxWater ( arr , n ) ) ; } }
using System ; class GFG { static int maxWater ( int [ ] arr , int n ) {
int left = 0 ; int right = n - 1 ;
int l_max = 0 ; int r_max = 0 ;
int result = 0 ; while ( left <= right ) {
if ( r_max <= l_max ) {
result += Math . Max ( 0 , r_max - arr [ right ] ) ;
r_max = Math . Max ( r_max , arr [ right ] ) ;
right -= 1 ; } else {
result += Math . Max ( 0 , l_max - arr [ left ] ) ;
l_max = Math . Max ( l_max , arr [ left ] ) ;
left += 1 ; } } return result ; }
static void Main ( ) { int [ ] arr = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = arr . Length ; Console . WriteLine ( maxWater ( arr , n ) ) ; } }
static int missingK ( int [ ] a , int k , int n ) { int difference = 0 , ans = 0 , count = k ; bool flag = false ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { difference = 0 ;
if ( ( a [ i ] + 1 ) != a [ i + 1 ] ) {
difference += ( a [ i + 1 ] - a [ i ] ) - 1 ;
if ( difference >= count ) { ans = a [ i ] + count ; flag = true ; break ; } else count -= difference ; } }
if ( flag ) return ans ; else return - 1 ; }
int [ ] a = { 1 , 5 , 11 , 19 } ;
int k = 11 ; int n = a . Length ;
int missing = missingK ( a , k , n ) ; Console . Write ( missing ) ; } }
using System ; class GFG {
static int maximum ( int a , int b ) { return a > b ? a : b ; }
static int minimum ( int a , int b ) { return a < b ? a : b ; }
static double findMedianSortedArrays ( ref int [ ] a , int n , ref int [ ] b , int m ) { int min_index = 0 , max_index = n , i = 0 , j = 0 , median = 0 ; while ( min_index <= max_index ) { i = ( min_index + max_index ) / 2 ; j = ( ( n + m + 1 ) / 2 ) - i ;
if ( i < n && j > 0 && b [ j - 1 ] > a [ i ] ) min_index = i + 1 ;
else if ( i > 0 && j < m && b [ j ] < a [ i - 1 ] ) = i - 1 ;
else {
if ( i == 0 ) median = b [ j - 1 ] ;
else if ( j = = 0 ) median = a [ i - 1 ] ; else median = maximum ( a [ i - 1 ] , b [ j - 1 ] ) ; break ; } }
if ( ( n + m ) % 2 == 1 ) return ( double ) median ;
if ( i == n ) return ( median + b [ j ] ) / 2.0 ;
if ( j == m ) return ( median + a [ i ] ) / 2.0 ; return ( median + minimum ( a [ i ] , b [ j ] ) ) / 2.0 ; }
static void Main ( ) { int [ ] a = new int [ ] { 900 } ; int [ ] b = new int [ ] { 10 , 13 , 14 } ; int n = a . Length ; int m = b . Length ;
if ( n < m ) Console . Write ( " The ▁ median ▁ is ▁ : ▁ " + findMedianSortedArrays ( ref a , n , ref b , m ) ) ; else Console . Write ( " The ▁ median ▁ is ▁ : ▁ " + findMedianSortedArrays ( ref b , m , ref a , n ) ) ; } }
using System ; class GFG { static void printUncommon ( int [ ] arr1 , int [ ] arr2 , int n1 , int n2 ) { int i = 0 , j = 0 , k = 0 ; while ( i < n1 && j < n2 ) {
if ( arr1 [ i ] < arr2 [ j ] ) { Console . Write ( arr1 [ i ] + " ▁ " ) ; i ++ ; k ++ ; } else if ( arr2 [ j ] < arr1 [ i ] ) { Console . Write ( arr2 [ j ] + " ▁ " ) ; k ++ ; j ++ ; }
else { i ++ ; j ++ ; } }
while ( i < n1 ) { Console . Write ( arr1 [ i ] + " ▁ " ) ; i ++ ; k ++ ; } while ( j < n2 ) { Console . Write ( arr2 [ j ] + " ▁ " ) ; j ++ ; k ++ ; } }
public static void Main ( ) { int [ ] arr1 = { 10 , 20 , 30 } ; int [ ] arr2 = { 20 , 25 , 30 , 40 , 50 } ; int n1 = arr1 . Length ; int n2 = arr2 . Length ; printUncommon ( arr1 , arr2 , n1 , n2 ) ; } }
using System ; class GFG { static int leastFrequent ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
int min_count = n + 1 , res = - 1 ; int curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
static public void Main ( ) { int [ ] arr = { 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 } ; int n = arr . Length ; Console . Write ( leastFrequent ( arr , n ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static int leastFrequent ( int [ ] arr , int n ) {
Dictionary < int , int > count = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { int key = arr [ i ] ; if ( count . ContainsKey ( key ) ) { int freq = count [ key ] ; freq ++ ; count [ key ] = freq ; } else count . Add ( key , 1 ) ; }
int min_count = n + 1 , res = - 1 ; foreach ( KeyValuePair < int , int > pair in count ) { if ( min_count >= pair . Value ) { res = pair . Key ; min_count = pair . Value ; } } return res ; }
static void Main ( ) { int [ ] arr = new int [ ] { 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 } ; int n = arr . Length ; Console . Write ( leastFrequent ( arr , n ) ) ; } }
using System ; class GFG { static int M = 4 ; static void sort ( ref int [ , ] a , int row , int n ) { for ( int i = 0 ; i < M - 1 ; i ++ ) { if ( a [ row , i ] > a [ row , i + 1 ] ) { int temp = a [ row , i ] ; a [ row , i ] = a [ row , i + 1 ] ; a [ row , i + 1 ] = temp ; } } }
static int maximumSum ( int [ , ] a , int n ) { int i = 0 , j = 0 ;
int sum = a [ n - 1 , M - 1 ] ; int prev = a [ n - 1 , M - 1 ] ;
for ( i = n - 2 ; i >= 0 ; i -- ) { for ( j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i , j ] < prev ) { prev = a [ i , j ] ; sum += prev ; break ; } }
if ( j == - 1 ) return 0 ; } return sum ; }
static void Main ( ) { int [ , ] arr = new int [ , ] { { 1 , 7 , 3 , 4 } , { 4 , 2 , 5 , 1 } , { 9 , 5 , 1 , 8 } } ; int n = arr . GetLength ( 0 ) ; Console . Write ( maximumSum ( arr , n ) ) ; } }
using System ; class GFG { static int M = 4 ;
static int maximumSum ( int [ , ] a , int n ) {
int prev = Math . Max ( a [ n - 1 , 0 ] , a [ n - 1 , M - 1 ] + 1 ) ;
int sum = prev ; for ( int i = n - 2 ; i >= 0 ; i -- ) { int max_smaller = Int32 . MinValue ; for ( int j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i , j ] < prev && a [ i , j ] > max_smaller ) { max_smaller = a [ i , j ] ; } }
if ( max_smaller == Int32 . MinValue ) { return 0 ; } prev = max_smaller ; sum += max_smaller ; } return sum ; }
static public void Main ( ) { int [ , ] arr = { { 1 , 7 , 3 , 4 } , { 4 , 2 , 5 , 1 } , { 9 , 5 , 1 , 8 } } ; int n = arr . GetLength ( 0 ) ; Console . Write ( maximumSum ( arr , n ) ) ; } }
static int countPairs ( int [ ] A , int n , int k ) { int ans = 0 ;
Array . Sort ( A ) ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int x = 0 ;
while ( ( A [ i ] * Math . Pow ( k , x ) ) <= A [ j ] ) { if ( ( A [ i ] * Math . Pow ( k , x ) ) == A [ j ] ) { ans ++ ; break ; } x ++ ; } } } return ans ; }
public static void Main ( ) { int [ ] A = { 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 } ; int n = A . Length ; int k = 3 ; Console . WriteLine ( countPairs ( A , n , k ) ) ; } }
static int minDistance ( int [ ] arr , int n ) { int maximum_element = arr [ 0 ] ; int min_dis = n ; int index = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( maximum_element == arr [ i ] ) { min_dis = Math . Min ( min_dis , ( i - index ) ) ; index = i ; }
else if ( maximum_element < arr [ i ] ) { maximum_element = arr [ i ] ; min_dis = n ; index = i ; }
else continue ; } return min_dis ; }
public static void Main ( ) { int [ ] arr = { 6 , 3 , 1 , 3 , 6 , 4 , 6 } ; int n = arr . Length ; Console . WriteLine ( " Minimum ▁ distance ▁ = ▁ " + minDistance ( arr , n ) ) ; } }
static int findValue ( int [ ] arr , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] == k ) k *= 2 ; return k ; }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 4 , 10 , 8 , 1 } ; int k = 2 ; int n = arr . Length ; Console . WriteLine ( findValue ( arr , n , k ) ) ; } }
using System ; class GFG { static void dupLastIndex ( int [ ] arr , int n ) {
if ( arr == null n <= 0 ) return ;
for ( int i = n - 1 ; i > 0 ; i -- ) { if ( arr [ i ] == arr [ i - 1 ] ) { Console . WriteLine ( " Last ▁ index : " + i ) ; Console . WriteLine ( " Last ▁ duplicate ▁ item : ▁ " + arr [ i ] ) ; return ; } }
Console . WriteLine ( " no ▁ duplicate ▁ found " ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 5 , 5 , 6 , 6 , 7 , 9 } ; int n = arr . Length ; dupLastIndex ( arr , n ) ; } }
static int findSmallest ( int [ ] a , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < n ; j ++ ) if ( a [ j ] % a [ i ] >= 1 ) break ;
if ( j == n ) return a [ i ] ; } return - 1 ; }
public static void Main ( ) { int [ ] a = { 25 , 20 , 5 , 10 , 100 } ; int n = a . Length ; Console . WriteLine ( findSmallest ( a , n ) ) ; } }
static int min_element ( int [ ] a ) { int min = int . MaxValue ; int i ; for ( i = 0 ; i < a . Length ; i ++ ) { if ( a [ i ] < min ) min = a [ i ] ; } return min ; }
static int findSmallest ( int [ ] a , int n ) {
int smallest = min_element ( a ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( a [ i ] % smallest >= 1 ) return - 1 ; return smallest ; }
public static void Main ( ) { int [ ] a = { 25 , 20 , 5 , 10 , 100 } ; int n = a . Length ; Console . WriteLine ( findSmallest ( a , n ) ) ; } }
public static void printMax ( int [ ] arr , int k , int n ) {
int [ ] brr = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ i ] = arr [ i ] ;
Array . Sort ( brr ) ; Array . Reverse ( brr ) ; int [ ] crr = new int [ k ] ; for ( int i = 0 ; i < k ; i ++ ) { crr [ i ] = brr [ i ] ; }
for ( int i = 0 ; i < n ; ++ i ) { if ( crr . Contains ( arr [ i ] ) ) { Console . Write ( arr [ i ] + " ▁ " ) ; } } }
public static void Main ( ) { int [ ] arr = { 50 , 8 , 45 , 12 , 25 , 40 , 84 } ; int n = arr . Length ; int k = 3 ; printMax ( arr , k , n ) ; } }
public static int findIndex ( int [ ] arr ) {
int maxIndex = 0 ; for ( int i = 0 ; i < arr . Length ; ++ i ) if ( arr [ i ] > arr [ maxIndex ] ) maxIndex = i ;
for ( int i = 0 ; i < arr . Length ; ++ i ) if ( maxIndex != i && arr [ maxIndex ] < 2 * arr [ i ] ) return - 1 ; return maxIndex ; }
public static void Main ( ) { int [ ] arr = new int [ ] { 3 , 6 , 1 , 0 } ; Console . WriteLine ( findIndex ( arr ) ) ; } }
static int find_consecutive_steps ( int [ ] arr , int len ) { int count = 0 ; int maximum = 0 ; for ( int index = 1 ; index < len ; index ++ ) {
if ( arr [ index ] > arr [ index - 1 ] ) count ++ ; else { maximum = Math . Max ( maximum , count ) ; count = 0 ; } } return Math . Max ( maximum , count ) ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 } ; int len = arr . Length ; Console . WriteLine ( find_consecutive_steps ( arr , len ) ) ; } }
using System ; public class GFG { static int CalculateMax ( int [ ] arr , int n ) {
Array . Sort ( arr ) ; int min_sum = arr [ 0 ] + arr [ 1 ] ; int max_sum = arr [ n - 1 ] + arr [ n - 2 ] ; return ( Math . Abs ( max_sum - min_sum ) ) ; }
static public void Main ( ) { int [ ] arr = { 6 , 7 , 1 , 11 } ; int n = arr . Length ; Console . WriteLine ( CalculateMax ( arr , n ) ) ; } }
using System ; using System . Linq ; using System . Collections . Generic ; class GFG { static long calculate ( long [ ] a , int n ) {
Array . Sort ( a ) ; int i , j ;
List < long > s = new List < long > ( ) ; for ( i = 0 , j = n - 1 ; i < j ; i ++ , j -- ) s . Add ( ( a [ i ] + a [ j ] ) ) ; long mini = s . Min ( ) ; long maxi = s . Max ( ) ; return Math . Abs ( maxi - mini ) ; }
public static void Main ( ) { long [ ] a = { 2 , 6 , 4 , 3 } ; int n = a . Length ; Console . WriteLine ( calculate ( a , n ) ) ; } }
static void printMinDiffPairs ( int [ ] arr , int n ) { if ( n <= 1 ) return ;
Array . Sort ( arr ) ;
int minDiff = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) minDiff = Math . Min ( minDiff , arr [ i ] - arr [ i - 1 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) { if ( ( arr [ i ] - arr [ i - 1 ] ) == minDiff ) { Console . Write ( " ▁ ( " + arr [ i - 1 ] + " , ▁ " + arr [ i ] + " ) , ▁ " ) ; } } }
public static void Main ( ) { int [ ] arr = { 5 , 3 , 2 , 4 , 1 } ; int n = arr . Length ; printMinDiffPairs ( arr , n ) ; } }
using System ; public class MaximumAbsoluteDifference { private static int calculateDiff ( int i , int j , int [ ] array ) {
return Math . Abs ( array [ i ] - array [ j ] ) + Math . Abs ( i - j ) ; }
private static int maxDistance ( int [ ] array ) {
int result = 0 ;
for ( int i = 0 ; i < array . Length ; i ++ ) { for ( int j = i ; j < array . Length ; j ++ ) {
result = Math . Max ( result , calculateDiff ( i , j , array ) ) ; } } return result ; }
public static void Main ( ) { int [ ] array = { - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 } ; Console . WriteLine ( maxDistance ( array ) ) ; } }
private static int maxDistance ( int [ ] array ) {
int max1 = int . MinValue ; int min1 = int . MaxValue ; int max2 = int . MinValue ; int min2 = int . MaxValue ; for ( int i = 0 ; i < array . Length ; i ++ ) {
max1 = Math . Max ( max1 , array [ i ] + i ) ; min1 = Math . Min ( min1 , array [ i ] + i ) ; max2 = Math . Max ( max2 , array [ i ] - i ) ; min2 = Math . Min ( min2 , array [ i ] - i ) ; }
return Math . Max ( max1 - min1 , max2 - min2 ) ; }
public static void Main ( ) { int [ ] array = { - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 } ; Console . WriteLine ( maxDistance ( array ) ) ; } }
static int extrema ( int [ ] a , int n ) { int count = 0 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
if ( a [ i ] > a [ i - 1 ] && a [ i ] > a [ i + 1 ] ) count += 1 ;
if ( a [ i ] < a [ i - 1 ] && a [ i ] < a [ i + 1 ] ) count += 1 ; } return count ; }
public static void Main ( ) { int [ ] a = { 1 , 0 , 2 , 1 } ; int n = a . Length ; Console . WriteLine ( extrema ( a , n ) ) ; } }
public static int findClosest ( int [ ] arr , int target ) { int n = arr . Length ;
if ( target <= arr [ 0 ] ) return arr [ 0 ] ; if ( target >= arr [ n - 1 ] ) return arr [ n - 1 ] ;
int i = 0 , j = n , mid = 0 ; while ( i < j ) { mid = ( i + j ) / 2 ; if ( arr [ mid ] == target ) return arr [ mid ] ;
if ( target < arr [ mid ] ) {
if ( mid > 0 && target > arr [ mid - 1 ] ) return getClosest ( arr [ mid - 1 ] , arr [ mid ] , target ) ;
j = mid ; }
else { if ( mid < n - 1 && target < arr [ mid + 1 ] ) return getClosest ( arr [ mid ] , arr [ mid + 1 ] , target ) ;
i = mid + 1 ; } }
return arr [ mid ] ; }
public static int getClosest ( int val1 , int val2 , int target ) { if ( target - val1 >= val2 - target ) return val2 ; else return val1 ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 } ; int target = 11 ; Console . WriteLine ( findClosest ( arr , target ) ) ; } }
static int sum ( int [ ] a , int n ) {
int maxSum = int . MinValue ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) maxSum = Math . Max ( maxSum , a [ i ] + a [ j ] ) ;
int c = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( a [ i ] + a [ j ] == maxSum ) c ++ ; return c ; }
public static void Main ( ) { int [ ] array = { 1 , 1 , 1 , 2 , 2 , 2 } ; int n = array . Length ; Console . WriteLine ( sum ( array , n ) ) ; } }
static int sum ( int [ ] a , int n ) {
int maxVal = a [ 0 ] , maxCount = 1 ; int secondMax = int . MinValue ; int secondMaxCount = 0 ; for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == maxVal ) maxCount ++ ; else if ( a [ i ] > maxVal ) { secondMax = maxVal ; secondMaxCount = maxCount ; maxVal = a [ i ] ; maxCount = 1 ; } else if ( a [ i ] == secondMax ) { secondMax = a [ i ] ; secondMaxCount ++ ; } else if ( a [ i ] > secondMax ) { secondMax = a [ i ] ; secondMaxCount = 1 ; } }
if ( maxCount > 1 ) return maxCount * ( maxCount - 1 ) / 2 ;
return secondMaxCount ; }
public static void Main ( ) { int [ ] array = { 1 , 1 , 1 , 2 , 2 , 2 , 3 } ; int n = array . Length ; Console . WriteLine ( sum ( array , n ) ) ; } }
static void printSmall ( int [ ] arr , int asize , int n ) {
int [ ] copy_arr = new int [ asize ] ; Array . Copy ( arr , copy_arr , asize ) ;
Array . Sort ( copy_arr ) ;
for ( int i = 0 ; i < asize ; ++ i ) { if ( Array . BinarySearch ( copy_arr , 0 , n , arr [ i ] ) > - 1 ) Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void Main ( String [ ] args ) { int [ ] arr = { 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 } ; int asize = arr . Length ; int n = 5 ; printSmall ( arr , asize , n ) ; } }
static void printKMissing ( int [ ] arr , int n , int k ) { Array . Sort ( arr ) ;
int i = 0 ; while ( i < n && arr [ i ] <= 0 ) i ++ ;
int count = 0 , curr = 1 ; while ( count < k && i < n ) { if ( arr [ i ] != curr ) { Console . Write ( curr + " ▁ " ) ; count ++ ; } else i ++ ; curr ++ ; }
while ( count < k ) { Console . Write ( curr + " ▁ " ) ; curr ++ ; count ++ ; } }
public static void Main ( ) { int [ ] arr = { 2 , 3 , 4 } ; int n = arr . Length ; int k = 3 ; printKMissing ( arr , n , k ) ; } }
static void printmissingk ( int [ ] arr , int n , int k ) {
Dictionary < int , int > d = new Dictionary < int , int > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { d . Add ( arr [ i ] , arr [ i ] ) ; } int cnt = 1 ; int fl = 0 ;
for ( int i = 0 ; i < ( n + k ) ; i ++ ) { if ( ! d . ContainsKey ( cnt ) ) { fl += 1 ; Console . Write ( cnt + " ▁ " ) ; if ( fl == k ) break ; } cnt += 1 ; } }
static public void Main ( ) { int [ ] arr = { 1 , 4 , 3 } ; int n = arr . Length ; int k = 3 ; printmissingk ( arr , n , k ) ; } }
public static int nobleInteger ( int [ ] arr ) { int size = arr . Length ; for ( int i = 0 ; i < size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( arr [ i ] < arr [ j ] ) count ++ ;
if ( count == arr [ i ] ) return arr [ i ] ; } return - 1 ; }
public static void Main ( ) { int [ ] arr = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr ) ; if ( res != - 1 ) Console . Write ( " The ▁ noble ▁ integer " + " ▁ is ▁ " + res ) ; else Console . Write ( " No ▁ Noble ▁ Integer " + " ▁ Found " ) ; } }
public static int nobleInteger ( int [ ] arr ) { Array . Sort ( arr ) ;
int n = arr . Length ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] == arr [ i + 1 ] ) continue ;
if ( arr [ i ] == n - i - 1 ) return arr [ i ] ; } if ( arr [ n - 1 ] == 0 ) return arr [ n - 1 ] ; return - 1 ; }
static public void Main ( ) { int [ ] arr = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr ) ; if ( res != - 1 ) Console . Write ( " The ▁ noble ▁ integer ▁ is ▁ " + res ) ; else Console . Write ( " No ▁ Noble ▁ Integer ▁ " + " Found " ) ; } }
static long findMinSum ( long [ ] a , long [ ] b , long n ) {
Array . Sort ( a ) ; Array . Sort ( b ) ;
long sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + Math . Abs ( a [ i ] - b [ i ] ) ; return sum ; }
long [ ] a = { 4 , 1 , 8 , 7 } ; long [ ] b = { 2 , 3 , 6 , 5 } ; int n = a . Length ; Console . Write ( findMinSum ( a , b , n ) ) ; } }
static bool checkIsAP ( int [ ] arr , int n ) { if ( n == 1 ) return true ;
Array . Sort ( arr ) ;
int d = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] != d ) return false ; return true ; }
public static void Main ( ) { int [ ] arr = { 20 , 15 , 5 , 0 , 10 } ; int n = arr . Length ; if ( checkIsAP ( arr , n ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; public class GFG { static int minProductSubset ( int [ ] a , int n ) { if ( n == 1 ) return a [ 0 ] ;
int negmax = int . MinValue ; int posmin = int . MinValue ; int count_neg = 0 , count_zero = 0 ; int product = 1 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == 0 ) { count_zero ++ ; continue ; }
if ( a [ i ] < 0 ) { count_neg ++ ; negmax = Math . Max ( negmax , a [ i ] ) ; }
if ( a [ i ] > 0 && a [ i ] < posmin ) { posmin = a [ i ] ; } product *= a [ i ] ; }
if ( count_zero == n || ( count_neg == 0 && count_zero > 0 ) ) return 0 ;
if ( count_neg == 0 ) return posmin ;
if ( count_neg % 2 == 0 && count_neg != 0 ) {
product = product / negmax ; } return product ; }
public static void Main ( ) { int [ ] a = new int [ ] { - 1 , - 1 , - 2 , 4 , 3 } ; int n = 5 ; Console . WriteLine ( minProductSubset ( a , n ) ) ; } }
using System ; class GFG { static int countPairs ( int [ ] a , int n ) {
int mn = int . MaxValue ; int mx = int . MinValue ; for ( int i = 0 ; i < n ; i ++ ) { mn = Math . Min ( mn , a [ i ] ) ; mx = Math . Max ( mx , a [ i ] ) ; }
int c1 = 0 ;
int c2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] == mn ) c1 ++ ; if ( a [ i ] == mx ) c2 ++ ; }
if ( mn == mx ) return n * ( n - 1 ) / 2 ; else return c1 * c2 ; }
public static void Main ( ) { int [ ] a = { 3 , 2 , 1 , 1 , 3 } ; int n = a . Length ; Console . WriteLine ( countPairs ( a , n ) ) ; } }
using System ; public class GFG { static int findElement ( int [ ] a , int n , int b ) {
Array . Sort ( a ) ;
int max = a [ n - 1 ] ; while ( b < max ) {
if ( Array . BinarySearch ( a , b ) > - 1 ) b *= 2 ; else return b ; } return b ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 3 } ; int n = a . Length ; int b = 1 ; Console . WriteLine ( findElement ( a , n , b ) ) ; } }
using System ; class GFG { static int Mod = 1000000007 ;
static long findSum ( int [ ] arr , int n ) { long sum = 0 ;
Array . Sort ( arr ) ;
int i = 0 ; while ( i < n && arr [ i ] < 0 ) { if ( i != n - 1 && arr [ i + 1 ] <= 0 ) { sum = ( sum + ( arr [ i ] * arr [ i + 1 ] ) % Mod ) % Mod ; i += 2 ; } else break ; }
int j = n - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { if ( j != 0 && arr [ j - 1 ] > 0 ) { sum = ( sum + ( arr [ j ] * arr [ j - 1 ] ) % Mod ) % Mod ; j -= 2 ; } else break ; }
if ( j > i ) sum = ( sum + ( arr [ i ] * arr [ j ] ) % Mod ) % Mod ;
else if ( i = = j ) sum = ( sum + arr [ i ] ) % Mod ; return sum ; }
public static void Main ( ) { int [ ] arr = { - 1 , 9 , 4 , 5 , - 4 , 7 } ; int n = arr . Length ; Console . WriteLine ( findSum ( arr , n ) ) ; } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public void insertAfter ( Node prev_node , int new_data ) {
if ( prev_node == null ) { Console . WriteLine ( " The ▁ given ▁ previous ▁ node " + " ▁ cannot ▁ be ▁ null " ) ; return ; }
Node new_node = new Node ( new_data ) ;
new_node . next = prev_node . next ;
prev_node . next = new_node ; }
public class Node { public int data ; public Node next ; public Node ( int d ) { data = d ; next = null ; } }
Node head ;
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public bool search ( Node head , int x ) {
if ( head == null ) return false ;
if ( head . data == x ) return true ;
return search ( head . next , x ) ; }
llist . push ( 10 ) ; llist . push ( 30 ) ; llist . push ( 11 ) ; llist . push ( 21 ) ; llist . push ( 14 ) ; if ( llist . search ( llist . head , 21 ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
class Node { public int data ; public Node next ; } ; static Node head_ref = null ;
static void reverse ( ) { Node prev = null ; Node current = head_ref ;
while ( current != null ) {
Node next = current . next ; current . next = prev ; prev = current ; current = next ; } head_ref = prev ; }
static void push ( int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ;
( head_ref ) = new_node ; }
static void printList ( ) { Node temp = head_ref ; while ( temp != null ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } }
public static void Main ( string [ ] args ) { push ( 20 ) ; push ( 4 ) ; push ( 15 ) ; push ( 85 ) ; Console . Write ( " Given ▁ linked ▁ list STRNEWLINE " ) ; printList ( ) ; reverse ( ) ; Console . Write ( " STRNEWLINE Reversed ▁ Linked ▁ list ▁ STRNEWLINE " ) ; printList ( ) ; } }
public class Node { public int data ; public Node next ; }
static void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . next ; } Console . WriteLine ( ) ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static Node insertBeg ( Node head , int val ) { Node temp = newNode ( val ) ; temp . next = head ; head = temp ; return head ; }
static void rearrangeOddEven ( Node head ) { Stack < Node > odd = new Stack < Node > ( ) ; Stack < Node > even = new Stack < Node > ( ) ; int i = 1 ; while ( head != null ) { if ( head . data % 2 != 0 && i % 2 == 0 ) {
odd . Push ( head ) ; } else if ( head . data % 2 == 0 && i % 2 != 0 ) {
even . Push ( head ) ; } head = head . next ; i ++ ; } while ( odd . Count > 0 && even . Count > 0 ) {
int k = odd . Peek ( ) . data ; odd . Peek ( ) . data = even . Peek ( ) . data ; even . Peek ( ) . data = k ; odd . Pop ( ) ; even . Pop ( ) ; } }
public static void Main ( String [ ] args ) { Node head = newNode ( 8 ) ; head = insertBeg ( head , 7 ) ; head = insertBeg ( head , 6 ) ; head = insertBeg ( head , 5 ) ; head = insertBeg ( head , 3 ) ; head = insertBeg ( head , 2 ) ; head = insertBeg ( head , 1 ) ; Console . WriteLine ( " Linked ▁ List : " ) ; printList ( head ) ; rearrangeOddEven ( head ) ; Console . WriteLine ( " Linked ▁ List ▁ after ▁ " + " Rearranging : " ) ; printList ( head ) ; } }
public class Node { public int data ; public Node next ; } ;
static void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . next ; } Console . WriteLine ( ) ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static Node insertBeg ( Node head , int val ) { Node temp = newNode ( val ) ; temp . next = head ; head = temp ; return head ; }
static Node rearrange ( Node head ) {
Node even ; Node temp , prev_temp ; Node i , j , k , l , ptr = null ;
temp = ( head ) . next ; prev_temp = head ; while ( temp != null ) {
Node x = temp . next ;
if ( temp . data % 2 != 0 ) { prev_temp . next = x ; temp . next = ( head ) ; ( head ) = temp ; } else { prev_temp = temp ; }
temp = x ; }
temp = ( head ) . next ; prev_temp = ( head ) ; while ( temp != null && temp . data % 2 != 0 ) { prev_temp = temp ; temp = temp . next ; } even = temp ;
prev_temp . next = null ;
i = head ; j = even ; while ( j != null && i != null ) {
k = i . next ; l = j . next ; i . next = j ; j . next = k ;
ptr = j ;
i = k ; j = l ; } if ( i == null ) {
ptr . next = j ; }
return head ; }
public static void Main ( String [ ] args ) { Node head = newNode ( 8 ) ; head = insertBeg ( head , 7 ) ; head = insertBeg ( head , 6 ) ; head = insertBeg ( head , 3 ) ; head = insertBeg ( head , 5 ) ; head = insertBeg ( head , 1 ) ; head = insertBeg ( head , 2 ) ; head = insertBeg ( head , 10 ) ; Console . WriteLine ( " Linked ▁ List : " ) ; printList ( head ) ; Console . WriteLine ( " Rearranged ▁ List " ) ; head = rearrange ( head ) ; printList ( head ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class BinaryTree {
public Node root ; public virtual int minimumDepth ( ) { return minimumDepth ( root ) ; }
public virtual int minimumDepth ( Node root ) {
if ( root == null ) { return 0 ; }
if ( root . left == null && root . right == null ) { return 1 ; }
if ( root . left == null ) { return minimumDepth ( root . right ) + 1 ; }
if ( root . right == null ) { return minimumDepth ( root . left ) + 1 ; } return Math . Min ( minimumDepth ( root . left ) , minimumDepth ( root . right ) ) + 1 ; }
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; Console . WriteLine ( " The ▁ minimum ▁ depth ▁ of ▁ binary ▁ tree ▁ is ▁ : ▁ " + tree . minimumDepth ( ) ) ; } }
static Node deleteAlt ( Node head ) { if ( head == null ) return ; Node node = head . next ; if ( node == null ) return ;
head . next = node . next ;
head . next = deleteAlt ( head . next ) ; }
static void AlternatingSplit ( Node source , Node aRef , Node bRef ) { Node aDummy = new Node ( ) ; Node aTail = aDummy ;
Node bDummy = new Node ( ) ; Node bTail = bDummy ;
Node current = source ; aDummy . next = null ; bDummy . next = null ; while ( current != null ) { MoveNode ( ( aTail . next ) , current ) ;
aTail = aTail . next ;
if ( current != null ) { MoveNode ( ( bTail . next ) , current ) ; bTail = bTail . next ; } } aRef = aDummy . next ; bRef = bDummy . next ; }
bool areIdenticalRecur ( Node a , Node b ) {
if ( a == null && b == null ) return true ;
if ( a != null && b != null ) return ( a . data == b . data ) && areIdenticalRecur ( a . next , b . next ) ;
return false ; }
bool areIdentical ( LinkedList listb ) { return areIdenticalRecur ( this . head , listb . head ) ; } }
public class Node { public int data ; public Node next ; } ; static Node head = null ;
static void rotate ( int k ) { if ( k == 0 ) return ;
Node current = head ;
while ( current . next != null ) current = current . next ; current . next = head ; current = head ;
for ( int i = 0 ; i < k - 1 ; i ++ ) current = current . next ;
head = current . next ; current . next = null ; }
static void push ( int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head ;
head = new_node ; }
static void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . next ; } }
for ( int i = 60 ; i > 0 ; i -= 10 ) push ( i ) ; Console . Write ( " Given ▁ linked ▁ list ▁ STRNEWLINE " ) ; printList ( head ) ; rotate ( 4 ) ; Console . Write ( " STRNEWLINE Rotated ▁ Linked ▁ list ▁ STRNEWLINE " ) ; printList ( head ) ; } }
Node head ;
public class Node { public int data ; public Node right , down ; public Node ( int data ) { this . data = data ; right = null ; down = null ; } }
Node merge ( Node a , Node b ) {
if ( a == null ) return b ;
if ( b == null ) return a ;
Node result ; if ( a . data < b . data ) { result = a ; result . down = merge ( a . down , b ) ; } else { result = b ; result . down = merge ( a , b . down ) ; } result . right = null ; return result ; } Node flatten ( Node root ) {
if ( root == null root . right == null ) return root ;
root . right = flatten ( root . right ) ;
root = merge ( root , root . right ) ;
return root ; }
Node Push ( Node head_ref , int data ) {
Node new_node = new Node ( data ) ;
new_node . down = head_ref ;
head_ref = new_node ;
return head_ref ; } void printList ( ) { Node temp = head ; while ( temp != null ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . down ; } Console . WriteLine ( ) ; }
L . head = L . Push ( L . head , 30 ) ; L . head = L . Push ( L . head , 8 ) ; L . head = L . Push ( L . head , 7 ) ; L . head = L . Push ( L . head , 5 ) ; L . head . right = L . Push ( L . head . right , 20 ) ; L . head . right = L . Push ( L . head . right , 10 ) ; L . head . right . right = L . Push ( L . head . right . right , 50 ) ; L . head . right . right = L . Push ( L . head . right . right , 22 ) ; L . head . right . right = L . Push ( L . head . right . right , 19 ) ; L . head . right . right . right = L . Push ( L . head . right . right . right , 45 ) ; L . head . right . right . right = L . Push ( L . head . right . right . right , 40 ) ; L . head . right . right . right = L . Push ( L . head . right . right . right , 35 ) ; L . head . right . right . right = L . Push ( L . head . right . right . right , 20 ) ;
L . head = L . flatten ( L . head ) ; L . printList ( ) ; } }
Node head ;
class Node { public int data ; public Node next ; public Node ( int d ) { data = d ; next = null ; } } void sortList ( ) {
int [ ] count = { 0 , 0 , 0 } ; Node ptr = head ;
while ( ptr != null ) { count [ ptr . data ] ++ ; ptr = ptr . next ; } int i = 0 ; ptr = head ;
while ( ptr != null ) { if ( count [ i ] == 0 ) i ++ ; else { ptr . data = i ; -- count [ i ] ; ptr = ptr . next ; } } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
void printList ( ) { Node temp = head ; while ( temp != null ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } Console . WriteLine ( ) ; }
llist . push ( 0 ) ; llist . push ( 1 ) ; llist . push ( 0 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; llist . push ( 1 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; llist . push ( 2 ) ; Console . WriteLine ( " Linked ▁ List ▁ before ▁ sorting " ) ; llist . printList ( ) ; llist . sortList ( ) ; Console . WriteLine ( " Linked ▁ List ▁ after ▁ sorting " ) ; llist . printList ( ) ; } }
static class List { public int data ; public List next ; public List child ; } ;
using System ; class GFG { class Node { public int data ; public Node next ; }
static Node rearrange ( Node head ) {
if ( head == null ) return null ;
Node prev = head , curr = head . next ; while ( curr != null ) {
if ( prev . data > curr . data ) { int t = prev . data ; prev . data = curr . data ; curr . data = t ; }
if ( curr . next != null && curr . next . data > curr . data ) { int t = curr . next . data ; curr . next . data = curr . data ; curr . data = t ; } prev = curr . next ; if ( curr . next == null ) break ; curr = curr . next . next ; } return head ; }
static Node push ( Node head , int k ) { Node tem = new Node ( ) ; tem . data = k ; tem . next = head ; head = tem ; return head ; }
static void display ( Node head ) { Node curr = head ; while ( curr != null ) { Console . Write ( curr . data + " ▁ " ) ; curr = curr . next ; } }
head = push ( head , 7 ) ; head = push ( head , 3 ) ; head = push ( head , 8 ) ; head = push ( head , 6 ) ; head = push ( head , 9 ) ; head = rearrange ( head ) ; display ( head ) ; } }
public class Node { public int data ; public Node next ; public Node ( int key ) { data = key ; next = null ; } }
class GFG { Node left = null ;
void printlist ( Node head ) { while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; if ( head . next != null ) { Console . Write ( " - > " ) ; } head = head . next ; } Console . WriteLine ( ) ; }
void rearrange ( Node head ) { if ( head != null ) { left = head ; reorderListUtil ( left ) ; } } void reorderListUtil ( Node right ) { if ( right == null ) { return ; } reorderListUtil ( right . next ) ;
if ( left == null ) { return ; }
if ( left != right && left . next != right ) { Node temp = left . next ; left . next = right ; right . next = temp ; left = temp ; } else {
if ( left . next == right ) {
left . next . next = null ; left = null ; } else {
left . next = null ; left = null ; } } }
static public void Main ( ) { Node head = new Node ( 1 ) ; head . next = new Node ( 2 ) ; head . next . next = new Node ( 3 ) ; head . next . next . next = new Node ( 4 ) ; head . next . next . next . next = new Node ( 5 ) ; GFG gfg = new GFG ( ) ;
gfg . printlist ( head ) ;
gfg . rearrange ( head ) ;
gfg . printlist ( head ) ; } }
class Node { public int data ; public Node next ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static Node rearrangeEvenOdd ( Node head ) {
if ( head == null ) return null ;
Node odd = head ; Node even = head . next ;
Node evenFirst = even ; while ( 1 == 1 ) {
if ( odd == null || even == null || ( even . next ) == null ) { odd . next = evenFirst ; break ; }
odd . next = even . next ; odd = even . next ;
if ( odd . next == null ) { even . next = null ; odd . next = evenFirst ; break ; }
even . next = odd . next ; even = odd . next ; } return head ; }
static void printlist ( Node node ) { while ( node != null ) { Console . Write ( node . data + " - > " ) ; node = node . next ; } Console . WriteLine ( " NULL " ) ; }
public static void Main ( ) { Node head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; Console . WriteLine ( " Given ▁ Linked ▁ List " ) ; printlist ( head ) ; head = rearrangeEvenOdd ( head ) ; Console . WriteLine ( " Modified ▁ Linked ▁ List " ) ; printlist ( head ) ; } }
public class Node { public int data ; public Node next ; public Node ( int data ) { this . data = data ; } } public class GFG { private Node head ;
public void printLL ( ) { Node t = head ; while ( t != null ) { Console . Write ( t . data + " ▁ - > " ) ; t = t . next ; } Console . WriteLine ( ) ; }
public void swap ( Node a , Node b ) { if ( a == null b == null ) return ; int temp = a . data ; a . data = b . data ; b . data = temp ; }
public Node zigZag ( Node node , int flag ) { if ( node == null node . next == null ) { return node ; } if ( flag == 0 ) { if ( node . data > node . next . data ) { swap ( node , node . next ) ; } return zigZag ( node . next , 1 ) ; } else { if ( node . data < node . next . data ) { swap ( node , node . next ) ; } return zigZag ( node . next , 0 ) ; } }
public static void Main ( String [ ] args ) { GFG lobj = new GFG ( ) ; lobj . head = new Node ( 11 ) ; lobj . head . next = new Node ( 15 ) ; lobj . head . next . next = new Node ( 20 ) ; lobj . head . next . next . next = new Node ( 5 ) ; lobj . head . next . next . next . next = new Node ( 10 ) ; lobj . printLL ( ) ;
int flag = 0 ; lobj . zigZag ( lobj . head , flag ) ; Console . WriteLine ( " LL ▁ in ▁ zig ▁ zag ▁ fashion ▁ : ▁ " ) ; lobj . printLL ( ) ; } }
public class Node { public int data ; public Node next ; }
public static Node newNode ( int data ) { Node new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
public static int addWithCarry ( Node head ) {
if ( head == null ) return 1 ;
int res = head . data + addWithCarry ( head . next ) ;
head . data = ( res ) % 10 ; return ( res ) / 10 ; }
public static Node addOne ( Node head ) {
int carry = addWithCarry ( head ) ; Node newNodes = null ;
if ( carry > 0 ) { newNodes = newNode ( carry ) ; newNodes . next = head ;
return newNodes ; } return head ; }
public static void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data ) ; node = node . next ; } Console . WriteLine ( ) ; }
public static void Main ( String [ ] args ) { Node head = newNode ( 1 ) ; head . next = newNode ( 9 ) ; head . next . next = newNode ( 9 ) ; head . next . next . next = newNode ( 9 ) ; Console . Write ( " List ▁ is ▁ " ) ; printList ( head ) ; head = addOne ( head ) ; Console . WriteLine ( ) ; Console . Write ( " Resultant ▁ list ▁ is ▁ " ) ; printList ( head ) ; } }
class Node { public int data ; public Node next , arbit ; }
static Node reverse ( Node head ) { Node prev = null , current = head , next = null ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } return prev ; }
static Node populateArbit ( Node head ) {
head = reverse ( head ) ;
Node max = head ;
Node temp = head . next ; while ( temp != null ) {
temp . arbit = max ;
if ( max . data < temp . data ) max = temp ;
temp = temp . next ; }
return reverse ( head ) ; }
static void printNextArbitPointers ( Node node ) { Console . WriteLine ( " Node TABSYMBOL Next ▁ Pointer TABSYMBOL Arbit ▁ Pointer " ) ; while ( node != null ) { Console . Write ( node . data + " TABSYMBOL TABSYMBOL " ) ; if ( node . next != null ) Console . Write ( node . next . data + " TABSYMBOL TABSYMBOL " ) ; else Console . Write ( " NULL " + " TABSYMBOL TABSYMBOL " ) ; if ( node . arbit != null ) Console . Write ( node . arbit . data ) ; else Console . Write ( " NULL " ) ; Console . WriteLine ( ) ; node = node . next ; } }
static Node newNode ( int data ) { Node new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
public static void Main ( String [ ] args ) { Node head = newNode ( 5 ) ; head . next = newNode ( 10 ) ; head . next . next = newNode ( 2 ) ; head . next . next . next = newNode ( 3 ) ; head = populateArbit ( head ) ; Console . WriteLine ( " Resultant ▁ Linked ▁ List ▁ is : ▁ " ) ; printNextArbitPointers ( head ) ; } }
public class Node { public int data ; public Node next , arbit ; } static ;
static void populateArbit ( Node head ) {
if ( head == null ) return ;
if ( head . next == null ) { maxNode = head ; return ; }
populateArbit ( head . next ) ;
head . arbit = maxNode ;
if ( head . data > maxNode . data ) maxNode = head ; return ; }
static void printNextArbitPointers ( Node node ) { Console . WriteLine ( " Node TABSYMBOL Next ▁ Pointer TABSYMBOL Arbit ▁ Pointer " ) ; while ( node != null ) { Console . Write ( node . data + " TABSYMBOL TABSYMBOL TABSYMBOL " ) ; if ( node . next != null ) Console . Write ( node . next . data + " TABSYMBOL TABSYMBOL TABSYMBOL TABSYMBOL " ) ; else Console . Write ( " NULL " + " TABSYMBOL TABSYMBOL TABSYMBOL " ) ; if ( node . arbit != null ) Console . Write ( node . arbit . data ) ; else Console . Write ( " NULL " ) ; Console . WriteLine ( ) ; node = node . next ; } }
static Node newNode ( int data ) { Node new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
public static void Main ( String [ ] args ) { Node head = newNode ( 5 ) ; head . next = newNode ( 10 ) ; head . next . next = newNode ( 2 ) ; head . next . next . next = newNode ( 3 ) ; populateArbit ( head ) ; Console . WriteLine ( " Resultant ▁ Linked ▁ List ▁ is : ▁ " ) ; printNextArbitPointers ( head ) ; } }
public class Node { public int data ; public Node next ; } ;
static void deleteLast ( Node head , int x ) { Node temp = head , ptr = null ; while ( temp != null ) {
if ( temp . data == x ) ptr = temp ; temp = temp . next ; }
if ( ptr != null && ptr . next == null ) { temp = head ; while ( temp . next != ptr ) temp = temp . next ; temp . next = null ; }
if ( ptr != null && ptr . next != null ) { ptr . data = ptr . next . data ; temp = ptr . next ; ptr . next = ptr . next . next ; } }
static Node newNode ( int x ) { Node node = new Node ( ) ; node . data = x ; node . next = null ; return node ; }
static void display ( Node head ) { Node temp = head ; if ( head == null ) { Console . Write ( " null STRNEWLINE " ) ; return ; } while ( temp != null ) { Console . Write ( " { 0 } ▁ - - > ▁ " , temp . data ) ; temp = temp . next ; } Console . Write ( " null STRNEWLINE " ) ; }
public static void Main ( String [ ] args ) { Node head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; head . next . next . next . next . next = newNode ( 4 ) ; head . next . next . next . next . next . next = newNode ( 4 ) ; Console . Write ( " Created ▁ Linked ▁ list : ▁ " ) ; display ( head ) ; deleteLast ( head , 4 ) ; Console . Write ( " List ▁ after ▁ deletion ▁ of ▁ 4 : ▁ " ) ; display ( head ) ; } }
Node flattenList2 ( Node head ) { Node headcop = head ; Stack < Node > save = new Stack < Node > ( ) ; save . Push ( head ) ; Node prev = null ; while ( ! save . Count != 0 ) { Node temp = save . Peek ( ) ; save . Pop ( ) ; if ( temp . next ) save . Push ( temp . next ) ; if ( temp . down ) save . Push ( temp . down ) ; if ( prev != null ) prev . next = temp ; prev = temp ; } return headcop ; }
static Node head ; bool borrow ;
public class Node { public int data ; public Node next ; public Node ( int d ) { data = d ; next = null ; } }
int getLength ( Node node ) { int size = 0 ; while ( node != null ) { node = node . next ; size ++ ; } return size ; }
Node paddZeros ( Node sNode , int diff ) { if ( sNode == null ) return null ; Node zHead = new Node ( 0 ) ; diff -- ; Node temp = zHead ; while ( ( diff -- ) != 0 ) { temp . next = new Node ( 0 ) ; temp = temp . next ; } temp . next = sNode ; return zHead ; }
Node subtractLinkedListHelper ( Node l1 , Node l2 ) { if ( l1 == null && l2 == null && borrow == false ) return null ; Node previous = subtractLinkedListHelper ( ( l1 != null ) ? l1 . next : null , ( l2 != null ) ? l2 . next : null ) ; int d1 = l1 . data ; int d2 = l2 . data ; int sub = 0 ;
if ( borrow ) { d1 -- ; borrow = false ; }
if ( d1 < d2 ) { borrow = true ; d1 = d1 + 10 ; }
sub = d1 - d2 ;
Node current = new Node ( sub ) ;
current . next = previous ; return current ; }
Node subtractLinkedList ( Node l1 , Node l2 ) {
if ( l1 == null && l2 == null ) return null ;
int len1 = getLength ( l1 ) ; int len2 = getLength ( l2 ) ; Node lNode = null , sNode = null ; Node temp1 = l1 ; Node temp2 = l2 ;
if ( len1 != len2 ) { lNode = len1 > len2 ? l1 : l2 ; sNode = len1 > len2 ? l2 : l1 ; sNode = paddZeros ( sNode , Math . Abs ( len1 - len2 ) ) ; } else {
while ( l1 != null && l2 != null ) { if ( l1 . data != l2 . data ) { lNode = l1 . data > l2 . data ? temp1 : temp2 ; sNode = l1 . data > l2 . data ? temp2 : temp1 ; break ; } l1 = l1 . next ; l2 = l2 . next ; } }
borrow = false ; return subtractLinkedListHelper ( lNode , sNode ) ; }
static void printList ( Node head ) { Node temp = head ; while ( temp != null ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } }
public static void Main ( String [ ] args ) { Node head = new Node ( 1 ) ; head . next = new Node ( 0 ) ; head . next . next = new Node ( 0 ) ; Node head2 = new Node ( 1 ) ; LinkedList ob = new LinkedList ( ) ; Node result = ob . subtractLinkedList ( head , head2 ) ; printList ( result ) ; } }
public class Node { public int data ; public Node next ; }
static Node newNode ( int data ) { Node new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
static Node partition ( Node head , int x ) {
Node smallerHead = null , smallerLast = null ; Node greaterLast = null , greaterHead = null ; Node equalHead = null , equalLast = null ;
while ( head != null ) {
if ( head . data == x ) { if ( equalHead == null ) equalHead = equalLast = head ; else { equalLast . next = head ; equalLast = equalLast . next ; } }
else if ( head . data < x ) { if ( smallerHead == null ) smallerLast = smallerHead = head ; else { smallerLast . next = head ; smallerLast = head ; } }
else { if ( greaterHead == null ) greaterLast = greaterHead = head ; else { greaterLast . next = head ; greaterLast = head ; } } head = head . next ; }
if ( greaterLast != null ) greaterLast . next = null ;
if ( smallerHead == null ) { if ( equalHead == null ) return greaterHead ; equalLast . next = greaterHead ; return equalHead ; }
if ( equalHead == null ) { smallerLast . next = greaterHead ; return smallerHead ; }
smallerLast . next = equalHead ; equalLast . next = greaterHead ; return smallerHead ; }
static void printList ( Node head ) { Node temp = head ; while ( temp != null ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } }
Node head = newNode ( 10 ) ; head . next = newNode ( 4 ) ; head . next . next = newNode ( 5 ) ; head . next . next . next = newNode ( 30 ) ; head . next . next . next . next = newNode ( 2 ) ; head . next . next . next . next . next = newNode ( 50 ) ; int x = 3 ; head = partition ( head , x ) ; printList ( head ) ; } }
class Node { public int data ; public Node next ; }
static Node getLoopstart ( Node loop_node , Node head ) { Node ptr1 = loop_node ; Node ptr2 = loop_node ;
int k = 1 , i ; while ( ptr1 . next != ptr2 ) { ptr1 = ptr1 . next ; k ++ ; }
ptr1 = head ;
ptr2 = head ; for ( i = 0 ; i < k ; i ++ ) ptr2 = ptr2 . next ;
while ( ptr2 != ptr1 ) { ptr1 = ptr1 . next ; ptr2 = ptr2 . next ; } return ptr1 ; }
static Node detectAndgetLoopstarting ( Node head ) { Node slow_p = head , fast_p = head , loop_start = null ;
while ( slow_p != null && fast_p != null && fast_p . next != null ) { slow_p = slow_p . next ; fast_p = fast_p . next . next ;
if ( slow_p == fast_p ) { loop_start = getLoopstart ( slow_p , head ) ; break ; } }
return loop_start ; }
static bool isPalindromeUtil ( Node head , Node loop_start ) { Node ptr = head ; Stack < int > s = new Stack < int > ( ) ;
int count = 0 ; while ( ptr != loop_start count != 1 ) { s . Push ( ptr . data ) ; if ( ptr == loop_start ) count = 1 ; ptr = ptr . next ; } ptr = head ; count = 0 ;
while ( ptr != loop_start count != 1 ) {
if ( ptr . data == s . Peek ( ) ) s . Pop ( ) ;
else return false ; if ( ptr == loop_start ) count = 1 ; ptr = ptr . next ; }
return true ; }
static bool isPalindrome ( Node head ) {
Node loop_start = detectAndgetLoopstarting ( head ) ;
return isPalindromeUtil ( head , loop_start ) ; } static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
public static void Main ( String [ ] args ) { Node head = newNode ( 50 ) ; head . next = newNode ( 20 ) ; head . next . next = newNode ( 15 ) ; head . next . next . next = newNode ( 20 ) ; head . next . next . next . next = newNode ( 50 ) ;
head . next . next . next . next . next = head . next . next ; if ( isPalindrome ( head ) == true ) Console . WriteLine ( " Palindrome " ) ; else Console . WriteLine ( " Not ▁ Palindrome " ) ; } }
public class Node { public int data ; public Node next ; }
static int countCommon ( Node a , Node b ) { int count = 0 ;
for ( ; a != null && b != null ; a = a . next , b = b . next )
if ( a . data == b . data ) ++ count ; else break ; return count ; }
static int maxPalindrome ( Node head ) { int result = 0 ; Node prev = null , curr = head ;
while ( curr != null ) {
Node next = curr . next ; curr . next = prev ;
result = Math . Max ( result , 2 * countCommon ( prev , next ) + 1 ) ;
result = Math . Max ( result , 2 * countCommon ( curr , next ) ) ;
prev = curr ; curr = next ; } return result ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
Node head = newNode ( 2 ) ; head . next = newNode ( 4 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 2 ) ; head . next . next . next . next . next = newNode ( 15 ) ; Console . WriteLine ( maxPalindrome ( head ) ) ; } }
List < int > list = new List < int > ( ) ;
list . Add ( 1 ) ; list . Add ( 2 ) ; list . Add ( 3 ) ;
foreach ( int it in list ) { Console . Write ( it + " ▁ " ) ; } } }
public class Node { public int data ; public Node next ; }
static Node newNode ( int x ) { Node temp = new Node ( ) ; temp . data = x ; temp . next = null ; return temp ; }
static void printList ( Node head ) { Node temp = head ; while ( temp != null ) { Console . Write ( " { 0 } ▁ " , temp . data ) ; temp = temp . next ; } Console . Write ( " STRNEWLINE " ) ; }
static void moveToEnd ( Node head , int key ) {
Node pKey = head ;
Node pCrawl = head ; while ( pCrawl != null ) {
if ( pCrawl != pKey && pCrawl . data != key ) { pKey . data = pCrawl . data ; pCrawl . data = key ; pKey = pKey . next ; }
if ( pKey . data != key ) pKey = pKey . next ;
pCrawl = pCrawl . next ; } }
public static void Main ( String [ ] args ) { Node head = newNode ( 10 ) ; head . next = newNode ( 20 ) ; head . next . next = newNode ( 10 ) ; head . next . next . next = newNode ( 30 ) ; head . next . next . next . next = newNode ( 40 ) ; head . next . next . next . next . next = newNode ( 10 ) ; head . next . next . next . next . next . next = newNode ( 60 ) ; Console . Write ( " Before ▁ moveToEnd ( ) , ▁ the ▁ Linked ▁ list ▁ is STRNEWLINE " ) ; printList ( head ) ; int key = 10 ; moveToEnd ( head , key ) ; Console . Write ( " moveToEnd ( ) , the Linked is " printList ( head ) ; } }
public class Node { public int data ; public Node next ; public Node ( int data ) { this . data = data ; this . next = null ; } } class GFG { static Node root ;
public static Node keyToEnd ( Node head , int key ) {
Node tail = head ; if ( head == null ) { return null ; } while ( tail . next != null ) { tail = tail . next ; }
Node last = tail ; Node current = head ; Node prev = null ;
Node prev2 = null ;
while ( current != tail ) { if ( current . data == key && prev2 == null ) { prev = current ; current = current . next ; head = current ; last . next = prev ; last = last . next ; last . next = null ; prev = null ; } else { if ( current . data == key && prev2 != null ) { prev = current ; current = current . next ; prev2 . next = current ; last . next = prev ; last = last . next ; last . next = null ; } else if ( current != tail ) { prev2 = current ; current = current . next ; } } } return head ; }
public static void display ( Node root ) { while ( root != null ) { Console . Write ( root . data + " ▁ " ) ; root = root . next ; } }
public static void Main ( ) { root = new Node ( 5 ) ; root . next = new Node ( 2 ) ; root . next . next = new Node ( 2 ) ; root . next . next . next = new Node ( 7 ) ; root . next . next . next . next = new Node ( 2 ) ; root . next . next . next . next . next = new Node ( 2 ) ; root . next . next . next . next . next . next = new Node ( 2 ) ; int key = 2 ; Console . WriteLine ( " Linked ▁ List ▁ before ▁ operations ▁ : " ) ; display ( root ) ; Console . WriteLine ( " operations : " root = keyToEnd ( root , key ) ; display ( root ) ; } }
public class LinkedList { Node head = null ; class Node { public int val ; public Node next ; public Node ( int v ) { val = v ; next = null ; } }
public void insert ( int data ) { Node new_node = new Node ( data ) ; new_node . next = head ; head = new_node ; }
public void removeAllDuplicates ( ) {
Node dummy = new Node ( 0 ) ;
dummy . next = head ; Node prev = dummy ; Node current = head ; while ( current != null ) {
while ( current . next != null && prev . next . val == current . next . val ) current = current . next ;
if ( prev . next == current ) prev = prev . next ;
else prev . = current . next ; current = current . next ; }
head = dummy . next ; }
public void printList ( ) { Node trav = head ; if ( head == null ) Console . Write ( " ▁ List ▁ is ▁ empty " ) ; while ( trav != null ) { Console . Write ( trav . val + " ▁ " ) ; trav = trav . next ; } }
public static void Main ( String [ ] args ) { LinkedList ll = new LinkedList ( ) ; ll . insert ( 53 ) ; ll . insert ( 53 ) ; ll . insert ( 49 ) ; ll . insert ( 49 ) ; ll . insert ( 35 ) ; ll . insert ( 28 ) ; ll . insert ( 28 ) ; ll . insert ( 23 ) ; Console . WriteLine ( " Before ▁ removal ▁ of ▁ duplicates " ) ; ll . printList ( ) ; ll . removeAllDuplicates ( ) ; Console . WriteLine ( " STRNEWLINE After ▁ removal ▁ of ▁ duplicates " ) ; ll . printList ( ) ; } }
public class Node { public int data ; public Node next ; }
static Node freeList ( Node node ) { while ( node != null ) { Node next = node . next ; node = next ; } return node ; }
static Node deleteKthNode ( Node head , int k ) {
if ( head == null ) return null ; if ( k == 1 ) { head = freeList ( head ) ; return null ; }
Node ptr = head , prev = null ;
int count = 0 ; while ( ptr != null ) {
count ++ ;
if ( k == count ) {
prev . next = ptr . next ;
count = 0 ; }
if ( count != 0 ) prev = ptr ; ptr = prev . next ; } return head ; }
static void displayList ( Node head ) { Node temp = head ; while ( temp != null ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } }
static Node newNode ( int x ) { Node temp = new Node ( ) ; temp . data = x ; temp . next = null ; return temp ; }
Node head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; head . next . next . next . next . next = newNode ( 6 ) ; head . next . next . next . next . next . next = newNode ( 7 ) ; head . next . next . next . next . next . next . next = newNode ( 8 ) ; int k = 3 ; head = deleteKthNode ( head , k ) ; displayList ( head ) ; } }
class Node { public int data ; public Node next ; }
static int LinkedListLength ( Node head ) { while ( head != null && head . next != null ) { head = head . next . next ; } if ( head == null ) return 0 ; return 1 ; }
static void push ( Node head , int info ) {
Node node = new Node ( ) ;
node . data = info ;
node . next = ( head ) ;
( head ) = node ; }
public static void Main ( ) { Node head = null ;
push ( head , 4 ) ; push ( head , 5 ) ; push ( head , 7 ) ; push ( head , 2 ) ; push ( head , 9 ) ; push ( head , 6 ) ; push ( head , 1 ) ; push ( head , 2 ) ; push ( head , 0 ) ; push ( head , 5 ) ; push ( head , 5 ) ; int check = LinkedListLength ( head ) ;
if ( check == 0 ) { Console . WriteLine ( " Odd " ) ; } else { Console . WriteLine ( " Even " ) ; } } }
public class Node { public int data ; public Node next ; } ; static ; static int n , sum ;
static void push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; head = head_ref ; }
static void sumOfLastN_Nodes ( Node head ) {
if ( head == null ) return ;
sumOfLastN_Nodes ( head . next ) ;
if ( n > 0 ) {
sum = sum + head . data ;
-- n ; } }
static int sumOfLastN_NodesUtil ( Node head , int n ) {
if ( n <= 0 ) return 0 ; sum = 0 ;
sumOfLastN_Nodes ( head ) ;
return sum ; }
public static void Main ( String [ ] args ) { head = null ;
push ( head , 12 ) ; push ( head , 4 ) ; push ( head , 8 ) ; push ( head , 6 ) ; push ( head , 10 ) ; n = 2 ; Console . Write ( " Sum ▁ of ▁ last ▁ " + n + " ▁ nodes ▁ = ▁ " + sumOfLastN_NodesUtil ( head , n ) ) ; } }
class Node { public int data ; public Node next ; } ;
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; return head_ref ; }
static int sumOfLastN_NodesUtil ( Node head , int n ) {
if ( n <= 0 ) return 0 ; Stack < int > st = new Stack < int > ( ) ; int sum = 0 ;
while ( head != null ) {
st . Push ( head . data ) ;
head = head . next ; }
while ( n -- > 0 ) { sum += st . Peek ( ) ; st . Pop ( ) ; }
return sum ; }
public static void Main ( String [ ] args ) { Node head = null ;
head = push ( head , 12 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 6 ) ; head = push ( head , 10 ) ; int n = 2 ; Console . Write ( " Sum ▁ of ▁ last ▁ " + n + " ▁ nodes ▁ = ▁ " + sumOfLastN_NodesUtil ( head , n ) ) ; } }
public class Node { public int data ; public Node next ; } ; static ;
static void push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; head = head_ref ; } static void reverseList ( Node head_ref ) { Node current , prev , next ; current = head_ref ; prev = null ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } head_ref = prev ; head = head_ref ; }
static int sumOfLastN_NodesUtil ( int n ) {
if ( n <= 0 ) return 0 ;
reverseList ( head ) ; int sum = 0 ; Node current = head ;
while ( current != null && n -- > 0 ) {
sum += current . data ;
current = current . next ; }
reverseList ( head ) ;
return sum ; }
push ( head , 12 ) ; push ( head , 4 ) ; push ( head , 8 ) ; push ( head , 6 ) ; push ( head , 10 ) ; int n = 2 ; Console . WriteLine ( " Sum ▁ of ▁ last ▁ " + n + " ▁ nodes ▁ = ▁ " + sumOfLastN_NodesUtil ( n ) ) ; } }
public class Node { public int data ; public Node next ; } ; static ;
static void push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; head = head_ref ; }
static int sumOfLastN_NodesUtil ( Node head , int n ) {
if ( n <= 0 ) return 0 ; int sum = 0 , len = 0 ; Node temp = head ;
while ( temp != null ) { len ++ ; temp = temp . next ; }
int c = len - n ; temp = head ;
while ( temp != null && c -- > 0 ) {
temp = temp . next ; }
while ( temp != null ) {
sum += temp . data ;
temp = temp . next ; }
return sum ; }
push ( head , 12 ) ; push ( head , 4 ) ; push ( head , 8 ) ; push ( head , 6 ) ; push ( head , 10 ) ; int n = 2 ; Console . WriteLine ( " Sum ▁ of ▁ last ▁ " + n + " ▁ nodes ▁ = ▁ " + sumOfLastN_NodesUtil ( head , n ) ) ; } }
Node SortedMerge ( Node a , Node b ) { Node result = null ;
Node lastPtrRef = result ; while ( 1 ) { if ( a == null ) { lastPtrRef = b ; break ; } else if ( b == null ) { lastPtrRef = a ; break ; } if ( a . data <= b . data ) { MoveNode ( lastPtrRef , a ) ; } else { MoveNode ( lastPtrRef , b ) ; }
lastPtrRef = ( ( lastPtrRef ) . next ) ; } return ( result ) ; }
public class Node { public int data ; public Node next ;
public Node ( int key ) { data = key ; next = null ; } } public class GFG { static Node head ;
static void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . next ; } Console . WriteLine ( ) ; }
static Node mergeKLists ( Node [ ] arr , int last ) {
for ( int i = 1 ; i <= last ; i ++ ) { while ( true ) {
Node head_0 = arr [ 0 ] ; Node head_i = arr [ i ] ;
if ( head_i == null ) break ;
if ( head_0 . data >= head_i . data ) { arr [ i ] = head_i . next ; head_i . next = head_0 ; arr [ 0 ] = head_i ; } else {
while ( head_0 . next != null ) {
if ( head_0 . next . data >= head_i . data ) { arr [ i ] = head_i . next ; head_i . next = head_0 . next ; head_0 . next = head_i ; break ; }
head_0 = head_0 . next ;
if ( head_0 . next == null ) { arr [ i ] = head_i . next ; head_i . next = null ; head_0 . next = head_i ; head_0 . next . next = null ; break ; } } } } } return arr [ 0 ] ; }
int k = 3 ;
Node [ ] arr = new Node [ k ] ; arr [ 0 ] = new Node ( 1 ) ; arr [ 0 ] . next = new Node ( 3 ) ; arr [ 0 ] . next . next = new Node ( 5 ) ; arr [ 0 ] . next . next . next = new Node ( 7 ) ; arr [ 1 ] = new Node ( 2 ) ; arr [ 1 ] . next = new Node ( 4 ) ; arr [ 1 ] . next . next = new Node ( 6 ) ; arr [ 1 ] . next . next . next = new Node ( 8 ) ; arr [ 2 ] = new Node ( 0 ) ; arr [ 2 ] . next = new Node ( 9 ) ; arr [ 2 ] . next . next = new Node ( 10 ) ; arr [ 2 ] . next . next . next = new Node ( 11 ) ;
head = mergeKLists ( arr , k - 1 ) ; printList ( head ) ; } }
using System ; class GFG { public class Node { public int data ; public Node next ; } ;
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static void printList ( Node node ) { while ( node != null ) { Console . Write ( " { 0 } ▁ " , node . data ) ; node = node . next ; } }
static Node merge ( Node h1 , Node h2 ) { if ( h1 == null ) return h2 ; if ( h2 == null ) return h1 ;
if ( h1 . data < h2 . data ) { h1 . next = merge ( h1 . next , h2 ) ; return h1 ; } else { h2 . next = merge ( h1 , h2 . next ) ; return h2 ; } }
public static void Main ( String [ ] args ) { Node head1 = newNode ( 1 ) ; head1 . next = newNode ( 3 ) ; head1 . next . next = newNode ( 5 ) ;
Node head2 = newNode ( 0 ) ; head2 . next = newNode ( 2 ) ; head2 . next . next = newNode ( 4 ) ;
Node mergedhead = merge ( head1 , head2 ) ; printList ( mergedhead ) ; } }
public class Node { public int data ; public Node next ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . next ; } }
static Node mergeUtil ( Node h1 , Node h2 ) {
if ( h1 . next == null ) { h1 . next = h2 ; return h1 ; }
Node curr1 = h1 , next1 = h1 . next ; Node curr2 = h2 , next2 = h2 . next ; while ( next1 != null && curr2 != null ) {
if ( ( curr2 . data ) >= ( curr1 . data ) & & ( curr2 . data ) <= ( next1 . data ) ) { next2 = curr2 . next ; curr1 . next = curr2 ; curr2 . next = next1 ;
curr1 = curr2 ; curr2 = next2 ; } else {
if ( next1 . next != null ) { next1 = next1 . next ; curr1 = curr1 . next ; }
else { next1 . next = curr2 ; return h1 ; } } } return h1 ; }
static Node merge ( Node h1 , Node h2 ) { if ( h1 == null ) return h2 ; if ( h2 == null ) return h1 ;
if ( h1 . data < h2 . data ) return mergeUtil ( h1 , h2 ) ; else return mergeUtil ( h2 , h1 ) ; }
public static void Main ( String [ ] args ) { Node head1 = newNode ( 1 ) ; head1 . next = newNode ( 3 ) ; head1 . next . next = newNode ( 5 ) ;
Node head2 = newNode ( 0 ) ; head2 . next = newNode ( 2 ) ; head2 . next . next = newNode ( 4 ) ;
Node mergedhead = merge ( head1 , head2 ) ; printList ( mergedhead ) ; } }
public class Node { public int data ; public Node next ; } ;
static Node swapNodes ( Node head_ref , Node currX , Node currY , Node prevY ) {
head_ref = currY ;
prevY . next = currX ;
Node temp = currY . next ; currY . next = currX . next ; currX . next = temp ; return head_ref ; }
static Node recurSelectionSort ( Node head ) {
if ( head . next == null ) return head ;
Node min = head ;
Node beforeMin = null ; Node ptr ;
for ( ptr = head ; ptr . next != null ; ptr = ptr . next ) {
if ( ptr . next . data < min . data ) { min = ptr . next ; beforeMin = ptr ; } }
if ( min != head ) head = swapNodes ( head , head , min , beforeMin ) ;
head . next = recurSelectionSort ( head . next ) ; return head ; }
static Node sort ( Node head_ref ) {
if ( ( head_ref ) == null ) return null ;
head_ref = recurSelectionSort ( head_ref ) ; return head_ref ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ;
( head_ref ) = new_node ; return head_ref ; }
static void printList ( Node head ) { while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; head = head . next ; } }
public static void Main ( String [ ] args ) { Node head = null ;
head = push ( head , 6 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 12 ) ; head = push ( head , 10 ) ; Console . WriteLine ( " Linked ▁ list ▁ before ▁ sorting : " ) ; printList ( head ) ;
head = sort ( head ) ; Console . Write ( " sorting : " printList ( head ) ; } }
static Node head ;
public class Node { public int data ; public Node next ;
public Node ( int d ) { data = d ; next = null ; } }
static void insertAtMid ( int x ) {
if ( head == null ) head = new Node ( x ) ; else {
Node newNode = new Node ( x ) ; Node ptr = head ; int len = 0 ;
while ( ptr != null ) { len ++ ; ptr = ptr . next ; }
int count = ( ( len % 2 ) == 0 ) ? ( len / 2 ) : ( len + 1 ) / 2 ; ptr = head ;
while ( count -- > 1 ) ptr = ptr . next ;
newNode . next = ptr . next ; ptr . next = newNode ; } }
static void display ( ) { Node temp = head ; while ( temp != null ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } }
head = null ; head = new Node ( 1 ) ; head . next = new Node ( 2 ) ; head . next . next = new Node ( 4 ) ; head . next . next . next = new Node ( 5 ) ; Console . WriteLine ( " Linked ▁ list ▁ before ▁ " + " insertion : ▁ " ) ; display ( ) ; int x = 3 ; insertAtMid ( x ) ; Console . WriteLine ( " STRNEWLINE Linked ▁ list ▁ after " + " ▁ insertion : ▁ " ) ; display ( ) ; } }
static Node head ;
class Node { public int data ; public Node next ; public Node ( int d ) { data = d ; next = null ; } }
static void insertAtMid ( int x ) {
if ( head == null ) head = new Node ( x ) ; else {
Node newNode = new Node ( x ) ;
Node slow = head ; Node fast = head . next ; while ( fast != null && fast . next != null ) {
slow = slow . next ;
fast = fast . next . next ; }
newNode . next = slow . next ; slow . next = newNode ; } }
static void display ( ) { Node temp = head ; while ( temp != null ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } }
head = null ; head = new Node ( 1 ) ; head . next = new Node ( 2 ) ; head . next . next = new Node ( 4 ) ; head . next . next . next = new Node ( 5 ) ; Console . WriteLine ( " Linked ▁ list ▁ before " + " ▁ insertion : ▁ " ) ; display ( ) ; int x = 3 ; insertAtMid ( x ) ; Console . WriteLine ( " STRNEWLINE Linked ▁ list ▁ after " + " ▁ insertion : ▁ " ) ; display ( ) ; } }
public class Node { public int data ; public Node next ; }
static Node getNode ( int data ) {
Node newNode = new Node ( ) ;
newNode . data = data ; newNode . next = null ; return newNode ; }
static void insertAfterNthNode ( Node head , int n , int x ) {
if ( head == null ) return ;
Node newNode = getNode ( x ) ; Node ptr = head ; int len = 0 , i ;
while ( ptr != null ) { len ++ ; ptr = ptr . next ; }
ptr = head ; for ( i = 1 ; i <= ( len - n ) ; i ++ ) ptr = ptr . next ;
newNode . next = ptr . next ; ptr . next = newNode ; }
static void printList ( Node head ) { while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; head = head . next ; } }
Node head = getNode ( 1 ) ; head . next = getNode ( 3 ) ; head . next . next = getNode ( 4 ) ; head . next . next . next = getNode ( 5 ) ; int n = 4 , x = 2 ; Console . Write ( " Original ▁ Linked ▁ List : ▁ " ) ; printList ( head ) ; insertAfterNthNode ( head , n , x ) ; Console . WriteLine ( ) ; Console . Write ( " Linked ▁ List ▁ After ▁ Insertion : ▁ " ) ; printList ( head ) ; } }
public class Node { public int data ; public Node next ; }
static Node getNode ( int data ) {
Node newNode = new Node ( ) ;
newNode . data = data ; newNode . next = null ; return newNode ; }
static void insertAfterNthNode ( Node head , int n , int x ) {
if ( head == null ) return ;
Node newNode = getNode ( x ) ;
Node slow_ptr = head ; Node fast_ptr = head ;
for ( int i = 1 ; i <= n - 1 ; i ++ ) fast_ptr = fast_ptr . next ;
while ( fast_ptr . next != null ) {
slow_ptr = slow_ptr . next ; fast_ptr = fast_ptr . next ; }
newNode . next = slow_ptr . next ; slow_ptr . next = newNode ; }
static void printList ( Node head ) { while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; head = head . next ; } }
Node head = getNode ( 1 ) ; head . next = getNode ( 3 ) ; head . next . next = getNode ( 4 ) ; head . next . next . next = getNode ( 5 ) ; int n = 4 , x = 2 ; Console . WriteLine ( " Original ▁ Linked ▁ List : ▁ " ) ; printList ( head ) ; insertAfterNthNode ( head , n , x ) ; Console . WriteLine ( ) ; Console . WriteLine ( " Linked ▁ List ▁ After ▁ Insertion : ▁ " ) ; printList ( head ) ; } }
public class Node { public int data ; public Node next ; } ; static ;
static Node rotateHelper ( Node blockHead , Node blockTail , int d , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { Node temp = blockHead ; for ( int i = 1 ; temp . next . next != null && i < k - 1 ; i ++ ) temp = temp . next ; blockTail . next = blockHead ; tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , k ) ; }
if ( d < 0 ) { blockTail . next = blockHead ; tail = blockHead ; return rotateHelper ( blockHead . next , blockHead , d + 1 , k ) ; } return blockHead ; }
static Node rotateByBlocks ( Node head , int k , int d ) {
if ( head == null head . next == null ) return head ;
if ( d == 0 ) return head ; Node temp = head ; tail = null ;
int i ; for ( i = 1 ; temp . next != null && i < k ; i ++ ) temp = temp . next ;
Node nextBlock = temp . next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , i ) ; else head = rotateHelper ( head , temp , d % k , k ) ;
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
static Node push ( Node head_ref , int new_data ) { Node new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
static void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . next ; } }
Node head = null ;
for ( int i = 9 ; i > 0 ; i -= 1 ) head = push ( head , i ) ; Console . Write ( " Given ▁ linked ▁ list ▁ STRNEWLINE " ) ; printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; Console . Write ( " by blocks " printList ( head ) ; } }
class Node { public int data ; public Node next ; public Node ( int data ) { this . data = data ; next = null ; } } static ;
static void setMiddleHead ( ) { if ( head == null ) return ;
Node one_node = head ;
Node two_node = head ;
Node prev = null ; while ( two_node != null && two_node . next != null ) {
prev = one_node ;
two_node = two_node . next . next ;
one_node = one_node . next ; }
prev . next = prev . next . next ; one_node . next = head ; head = one_node ; }
static void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
static void printList ( Node ptr ) { while ( ptr != null ) { Console . Write ( ptr . data + " ▁ " ) ; ptr = ptr . next ; } Console . WriteLine ( ) ; }
head = null ; int i ; for ( i = 5 ; i > 0 ; i -- ) push ( i ) ; Console . Write ( " ▁ list ▁ before : ▁ " ) ; printList ( head ) ; setMiddleHead ( ) ; Console . Write ( " ▁ list ▁ After : ▁ " ) ; printList ( head ) ; } }
public void InsertAfter ( Node prev_Node , int new_data ) {
if ( prev_Node == null ) { Console . WriteLine ( " The ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL ▁ " ) ; return ; }
Node new_node = new Node ( new_data ) ;
new_node . next = prev_Node . next ;
prev_Node . next = new_node ;
new_node . prev = prev_Node ;
if ( new_node . next != null ) new_node . next . prev = new_node ; }
using System ; class GFG { public class Node { public int data ; public Node next , prev ; } ;
static Node insert ( Node head_ref , int data ) {
Node new_node = new Node ( ) ;
new_node . data = data ;
if ( head_ref == null ) { new_node . next = new_node ; new_node . prev = new_node ; } else {
Node last = ( head_ref ) . prev ;
new_node . next = head_ref ; new_node . prev = last ;
last . next = ( head_ref ) . prev = new_node ; }
head_ref = new_node ; return head_ref ; }
static Node merge ( Node first , Node second ) {
if ( first == null ) return second ;
if ( second == null ) return first ;
if ( first . data < second . data ) { first . next = merge ( first . next , second ) ; first . next . prev = first ; first . prev = null ; return first ; } else { second . next = merge ( first , second . next ) ; second . next . prev = second ; second . prev = null ; return second ; } }
static Node mergeUtil ( Node head1 , Node head2 ) {
if ( head1 == null ) return head2 ;
if ( head2 == null ) return head1 ;
Node last_node ; if ( head1 . prev . data < head2 . prev . data ) last_node = head2 . prev ; else last_node = head1 . prev ;
head1 . prev . next = head2 . prev . next = null ;
Node finalHead = merge ( head1 , head2 ) ;
finalHead . prev = last_node ; last_node . next = finalHead ; return finalHead ; }
static void printList ( Node head ) { Node temp = head ; while ( temp . next != head ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } Console . Write ( temp . data + " ▁ " ) ; }
public static void Main ( ) { Node head1 = null , head2 = null ;
head1 = insert ( head1 , 8 ) ; head1 = insert ( head1 , 5 ) ; head1 = insert ( head1 , 3 ) ; head1 = insert ( head1 , 1 ) ;
head2 = insert ( head2 , 11 ) ; head2 = insert ( head2 , 9 ) ; head2 = insert ( head2 , 7 ) ; head2 = insert ( head2 , 2 ) ; Node newHead = mergeUtil ( head1 , head2 ) ; Console . Write ( " Final ▁ Sorted ▁ List : ▁ " ) ; printList ( newHead ) ; } }
using System ; class GFG { public class Node { public int data ; public Node prev , next ; } ; static Node newNode ( int val ) { Node temp = new Node ( ) ; temp . data = val ; temp . prev = temp . next = null ; return temp ; } static void printList ( Node head ) { while ( head . next != null ) { Console . Write ( head . data + " ▁ < - > ▁ " ) ; head = head . next ; } Console . WriteLine ( head . data ) ; }
static Node insert ( Node head , int val ) { Node temp = newNode ( val ) ; temp . next = head ; ( head ) . prev = temp ; ( head ) = temp ; return head ; }
static Node reverseList ( Node head ) { Node left = head , right = head ;
while ( right . next != null ) right = right . next ;
while ( left != right && left . prev != right ) {
int t = left . data ; left . data = right . data ; right . data = t ;
left = left . next ;
right = right . prev ; } return head ; }
public static void Main ( String [ ] args ) { Node head = newNode ( 5 ) ; head = insert ( head , 4 ) ; head = insert ( head , 3 ) ; head = insert ( head , 2 ) ; head = insert ( head , 1 ) ; printList ( head ) ; Console . WriteLine ( " List ▁ After ▁ Reversing " ) ; head = reverseList ( head ) ; printList ( head ) ; } }
public class Node { public int data ; public Node prev , next ; } ;
static Node getNode ( int data ) {
Node newNode = new Node ( ) ;
newNode . data = data ; newNode . prev = newNode . next = null ; return newNode ; }
static Node sortedInsert ( Node head_ref , Node newNode ) { Node current ;
if ( head_ref == null ) head_ref = newNode ;
else if ( ( head_ref ) . >= newNode . data ) { newNode . next = head_ref ; newNode . next . prev = newNode ; head_ref = newNode ; } else { current = head_ref ;
while ( current . next != null && current . next . data < newNode . data ) current = current . next ;
newNode . next = current . next ;
if ( current . next != null ) newNode . next . prev = newNode ; current . next = newNode ; newNode . prev = current ; } return head_ref ; }
static Node insertionSort ( Node head_ref ) {
Node sorted = null ;
Node current = head_ref ; while ( current != null ) {
Node next = current . next ;
current . prev = current . next = null ;
sorted = sortedInsert ( sorted , current ) ;
current = next ; }
head_ref = sorted ; return head_ref ; }
static void printList ( Node head ) { while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; head = head . next ; } }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ; new_node . prev = null ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
Node head = null ;
head = push ( head , 9 ) ; head = push ( head , 3 ) ; head = push ( head , 5 ) ; head = push ( head , 10 ) ; head = push ( head , 12 ) ; head = push ( head , 8 ) ; Console . WriteLine ( " Doubly ▁ Linked ▁ List ▁ Before ▁ Sorting " ) ; printList ( head ) ; head = insertionSort ( head ) ; Console . WriteLine ( " STRNEWLINE Doubly ▁ Linked ▁ List ▁ After ▁ Sorting " ) ; printList ( head ) ; } }
public class Node { public char data ; public Node next ; public Node prev ; } ;
static Node push ( Node head_ref , char new_data ) { Node new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; new_node . prev = null ; if ( head_ref != null ) head_ref . prev = new_node ; head_ref = new_node ; return head_ref ; }
static bool isPalindrome ( Node left ) { if ( left == null ) return true ;
Node right = left ; while ( right . next != null ) right = right . next ; while ( left != right ) { if ( left . data != right . data ) return false ; left = left . next ; right = right . prev ; } return true ; }
public static void Main ( String [ ] args ) { Node head = null ; head = push ( head , ' l ' ) ; head = push ( head , ' e ' ) ; head = push ( head , ' v ' ) ; head = push ( head , ' e ' ) ; head = push ( head , ' l ' ) ; if ( isPalindrome ( head ) ) Console . Write ( " It ▁ is ▁ Palindrome " ) ; else Console . Write ( " Not ▁ Palindrome " ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class BinaryTree { public Node root ;
public virtual void printLevels ( Node node , int low , int high ) { LinkedList < Node > Q = new LinkedList < Node > ( ) ;
Node marker = new Node ( 4 ) ;
int level = 1 ;
Q . AddLast ( node ) ; Q . AddLast ( marker ) ;
while ( Q . Count > 0 ) {
Node n = Q . First . Value ; Q . RemoveFirst ( ) ;
if ( n == marker ) {
Console . WriteLine ( " " ) ; level ++ ;
if ( Q . Count == 0 level > high ) { break ; }
Q . AddLast ( marker ) ;
continue ; }
if ( level >= low ) { Console . Write ( n . data + " ▁ " ) ; }
if ( n . left != null ) { Q . AddLast ( n . left ) ; } if ( n . right != null ) { Q . AddLast ( n . right ) ; } } }
public static void Main ( string [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 20 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 22 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 12 ) ; tree . root . left . right . left = new Node ( 10 ) ; tree . root . left . right . right = new Node ( 14 ) ; Console . Write ( " Level ▁ Order ▁ traversal ▁ between ▁ given ▁ two ▁ levels ▁ is ▁ " ) ; tree . printLevels ( tree . root , 2 , 3 ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class BinaryTree { public Node root ; public virtual void printKDistant ( Node node , int k ) { if ( node == null k < 0 ) { return ; } if ( k == 0 ) { Console . Write ( node . data + " ▁ " ) ; return ; } printKDistant ( node . left , k - 1 ) ; printKDistant ( node . right , k - 1 ) ; }
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 8 ) ; tree . printKDistant ( tree . root , 2 ) ; } }
public class Node { public int data ; public Node left , right ; }
static Node newNode ( int data ) { Node newnode = new Node ( ) ; newnode . data = data ; newnode . left = newnode . right = null ; return newnode ; }
static Boolean printKDistant ( Node root , int klevel ) { Queue < Node > q = new Queue < Node > ( ) ; int level = 1 ; Boolean flag = false ; q . Enqueue ( root ) ;
q . Enqueue ( null ) ; while ( q . Count > 0 ) { Node temp = q . Peek ( ) ;
if ( level == klevel && temp != null ) { flag = true ; Console . Write ( temp . data + " ▁ " ) ; } q . Dequeue ( ) ; if ( temp == null ) { if ( q . Count > 0 && q . Peek ( ) != null ) q . Enqueue ( null ) ; level += 1 ;
if ( level > klevel ) break ; } else { if ( temp . left != null ) q . Enqueue ( temp . left ) ; if ( temp . right != null ) q . Enqueue ( temp . right ) ; } } Console . Write ( " STRNEWLINE " ) ; return flag ; }
Node root = newNode ( 20 ) ; root . left = newNode ( 10 ) ; root . right = newNode ( 30 ) ; root . left . left = newNode ( 5 ) ; root . left . right = newNode ( 15 ) ; root . left . right . left = newNode ( 12 ) ; root . right . left = newNode ( 25 ) ; root . right . right = newNode ( 40 ) ; Console . Write ( " data ▁ at ▁ level ▁ 1 ▁ : ▁ " ) ; Boolean ret = printKDistant ( root , 1 ) ; if ( ret == false ) Console . Write ( " Number ▁ exceeds ▁ total ▁ " + " number ▁ of ▁ levels STRNEWLINE " ) ; Console . Write ( " data ▁ at ▁ level ▁ 2 ▁ : ▁ " ) ; ret = printKDistant ( root , 2 ) ; if ( ret == false ) Console . Write ( " Number ▁ exceeds ▁ total ▁ " + " number ▁ of ▁ levels STRNEWLINE " ) ; Console . Write ( " data ▁ at ▁ level ▁ 3 ▁ : ▁ " ) ; ret = printKDistant ( root , 3 ) ; if ( ret == false ) Console . Write ( " Number ▁ exceeds ▁ total ▁ " + " number ▁ of ▁ levels STRNEWLINE " ) ; Console . Write ( " data ▁ at ▁ level ▁ 6 ▁ : ▁ " ) ; ret = printKDistant ( root , 6 ) ; if ( ret == false ) Console . Write ( " Number ▁ exceeds ▁ total " + " number ▁ of ▁ levels STRNEWLINE " ) ; } }
class Node { public int data ; public Node left , right ; } ;
static void printLeafNodes ( Node root ) {
if ( root == null ) return ;
if ( root . left == null && root . right == null ) { Console . Write ( root . data + " ▁ " ) ; return ; }
if ( root . left != null ) printLeafNodes ( root . left ) ;
if ( root . right != null ) printLeafNodes ( root . right ) ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . left = null ; temp . right = null ; return temp ; }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . right . left = newNode ( 5 ) ; root . right . right = newNode ( 8 ) ; root . right . left . left = newNode ( 6 ) ; root . right . left . right = newNode ( 7 ) ; root . right . right . left = newNode ( 9 ) ; root . right . right . right = newNode ( 10 ) ;
printLeafNodes ( root ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class BinaryTree { public Node root ;
public virtual void printkdistanceNodeDown ( Node node , int k ) {
if ( node == null k < 0 ) { return ; }
if ( k == 0 ) { Console . Write ( node . data ) ; Console . WriteLine ( " " ) ; return ; }
printkdistanceNodeDown ( node . left , k - 1 ) ; printkdistanceNodeDown ( node . right , k - 1 ) ; }
public virtual int printkdistanceNode ( Node node , Node target , int k ) {
if ( node == null ) { return - 1 ; }
if ( node == target ) { printkdistanceNodeDown ( node , k ) ; return 0 ; }
int dl = printkdistanceNode ( node . left , target , k ) ;
if ( dl != - 1 ) {
if ( dl + 1 == k ) { Console . Write ( node . data ) ; Console . WriteLine ( " " ) ; }
else { printkdistanceNodeDown ( node . right , k - dl - 2 ) ; }
return 1 + dl ; }
int dr = printkdistanceNode ( node . right , target , k ) ; if ( dr != - 1 ) { if ( dr + 1 == k ) { Console . Write ( node . data ) ; Console . WriteLine ( " " ) ; } else { printkdistanceNodeDown ( node . left , k - dr - 2 ) ; } return 1 + dr ; }
return - 1 ; }
tree . root = new Node ( 20 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 22 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 12 ) ; tree . root . left . right . left = new Node ( 10 ) ; tree . root . left . right . right = new Node ( 14 ) ; Node target = tree . root . left . right ; tree . printkdistanceNode ( tree . root , target , 2 ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class BinaryTree { public Node root ;
public virtual void printSingles ( Node node ) {
if ( node == null ) { return ; }
if ( node . left != null && node . right != null ) { printSingles ( node . left ) ; printSingles ( node . right ) ; }
else if ( node . right != null ) { Console . Write ( node . right . data + " " ) ; printSingles ( node . right ) ; }
else if ( node . left != null ) { Console . Write ( node . left . data + " " ) ; printSingles ( node . left ) ; } }
public static void Main ( string [ ] args ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . right = new Node ( 4 ) ; tree . root . right . left = new Node ( 5 ) ; tree . root . right . left . right = new Node ( 6 ) ; tree . printSingles ( tree . root ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class BinaryTree { public Node root ;
public virtual void kDistantFromLeafUtil ( Node node , int [ ] path , bool [ ] visited , int pathLen , int k ) {
if ( node == null ) { return ; }
path [ pathLen ] = node . data ; visited [ pathLen ] = false ; pathLen ++ ;
if ( node . left == null && node . right == null && pathLen - k - 1 >= 0 && visited [ pathLen - k - 1 ] == false ) { Console . Write ( path [ pathLen - k - 1 ] + " ▁ " ) ; visited [ pathLen - k - 1 ] = true ; return ; }
kDistantFromLeafUtil ( node . left , path , visited , pathLen , k ) ; kDistantFromLeafUtil ( node . right , path , visited , pathLen , k ) ; }
public virtual void printKDistantfromLeaf ( Node node , int k ) { int [ ] path = new int [ 1000 ] ; bool [ ] visited = new bool [ 1000 ] ; kDistantFromLeafUtil ( node , path , visited , 0 , k ) ; }
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 6 ) ; tree . root . right . right = new Node ( 7 ) ; tree . root . right . left . right = new Node ( 8 ) ; Console . WriteLine ( " ▁ Nodes ▁ at ▁ distance ▁ 2 ▁ are ▁ : " ) ; tree . printKDistantfromLeaf ( tree . root , 2 ) ; } }
using System ; class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
int printKDistantfromLeaf ( Node node , int k ) { if ( node == null ) return - 1 ; int lk = printKDistantfromLeaf ( node . left , k ) ; int rk = printKDistantfromLeaf ( node . right , k ) ; bool isLeaf = lk == - 1 && lk == rk ; if ( lk == 0 || rk == 0 || ( isLeaf && k == 0 ) ) Console . Write ( " ▁ " + node . data ) ; if ( isLeaf && k > 0 )
return k - 1 ; if ( lk > 0 && lk < k )
return lk - 1 ; if ( rk > 0 && rk < k )
return rk - 1 ; return - 2 ; }
public static void Main ( string [ ] args ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 6 ) ; tree . root . right . right = new Node ( 7 ) ; tree . root . right . left . right = new Node ( 8 ) ; Console . Write ( " Nodes ▁ at ▁ distance ▁ 2 ▁ are ▁ : " ) ; tree . printKDistantfromLeaf ( tree . root , 2 ) ; } }
using System ; class GFG { static readonly int COUNT = 10 ;
public class Node { public int data ; public Node left , right ;
public Node ( int data ) { this . data = data ; this . left = null ; this . right = null ; } } ;
static void print2DUtil ( Node root , int space ) {
if ( root == null ) return ;
space += COUNT ;
print2DUtil ( root . right , space ) ;
Console . Write ( " STRNEWLINE " ) ; for ( int i = COUNT ; i < space ; i ++ ) Console . Write ( " ▁ " ) ; Console . Write ( root . data + " STRNEWLINE " ) ;
print2DUtil ( root . left , space ) ; }
static void print2D ( Node root ) {
print2DUtil ( root , 0 ) ; }
public static void Main ( String [ ] args ) { Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; root . left . left . left = new Node ( 8 ) ; root . left . left . right = new Node ( 9 ) ; root . left . right . left = new Node ( 10 ) ; root . left . right . right = new Node ( 11 ) ; root . right . left . left = new Node ( 12 ) ; root . right . left . right = new Node ( 13 ) ; root . right . right . left = new Node ( 14 ) ; root . right . right . right = new Node ( 15 ) ; print2D ( root ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } }
public class BinaryTree { public Node root ; public static int max_level = 0 ;
public virtual void leftViewUtil ( Node node , int level ) {
if ( node == null ) { return ; }
if ( max_level < level ) { Console . Write ( " ▁ " + node . data ) ; max_level = level ; }
leftViewUtil ( node . left , level + 1 ) ; leftViewUtil ( node . right , level + 1 ) ; }
public virtual void leftView ( ) { leftViewUtil ( root , 1 ) ; }
public static void Main ( string [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 12 ) ; tree . root . left = new Node ( 10 ) ; tree . root . right = new Node ( 30 ) ; tree . root . right . left = new Node ( 25 ) ; tree . root . right . right = new Node ( 40 ) ; tree . leftView ( ) ; } }
static int rotate ( int [ ] arr , int N , int X ) {
int nextPower = 1 ;
while ( nextPower <= N ) nextPower *= 2 ;
if ( X == 1 ) return nextPower - N ;
int prevPower = nextPower / 2 ;
return 2 * ( N - prevPower ) + 1 ; }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; int X = 1 ; int N = arr . Length ; Console . Write ( rotate ( arr , N , X ) ) ; } }
static void print ( int [ , ] mat ) {
for ( int i = 0 ; i < mat . GetLength ( 0 ) ; i ++ ) {
for ( int j = 0 ; j < mat . GetLength ( 1 ) ; j ++ )
Console . Write ( mat [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
static void performSwap ( int [ , ] mat , int i , int j ) { int N = mat . GetLength ( 0 ) ;
int ei = N - 1 - i ;
int ej = N - 1 - j ;
int temp = mat [ i , j ] ; mat [ i , j ] = mat [ ej , i ] ; mat [ ej , i ] = mat [ ei , ej ] ; mat [ ei , ej ] = mat [ j , ei ] ; mat [ j , ei ] = temp ; }
static void rotate ( int [ , ] mat , int N , int K ) {
K = K % 4 ;
while ( K -- > 0 ) {
for ( int i = 0 ; i < N / 2 ; i ++ ) {
for ( int j = i ; j < N - i - 1 ; j ++ ) {
if ( i != j && ( i + j ) != N - 1 ) {
performSwap ( mat , i , j ) ; } } } }
print ( mat ) ; }
public static void Main ( string [ ] args ) { int K = 5 ; int [ , ] mat = { { 1 , 2 , 3 , 4 } , { 6 , 7 , 8 , 9 } , { 11 , 12 , 13 , 14 } , { 16 , 17 , 18 , 19 } , } ; int N = mat . GetLength ( 0 ) ; rotate ( mat , N , K ) ; } }
static void findMaximumZeros ( string str , int n ) {
int c0 = 0 ;
for ( int i = 0 ; i < n ; ++ i ) { if ( str [ i ] == '0' ) c0 ++ ; }
if ( c0 == n ) {
Console . Write ( n ) ; return ; }
string s = str + str ;
int mx = 0 ;
for ( int i = 0 ; i < n ; ++ i ) {
int cs = 0 ; int ce = 0 ;
for ( int j = i ; j < i + n ; ++ j ) { if ( s [ j ] == '0' ) cs ++ ; else break ; }
for ( int j = i + n - 1 ; j >= i ; -- j ) { if ( s [ j ] == '0' ) ce ++ ; else break ; }
int val = cs + ce ;
mx = Math . Max ( val , mx ) ; }
Console . Write ( mx ) ; }
string s = "1001" ;
int n = s . Length ; findMaximumZeros ( s , n ) ; } }
static void findMaximumZeros ( string str , int n ) {
int c0 = 0 ; for ( int i = 0 ; i < n ; ++ i ) { if ( str [ i ] == '0' ) c0 ++ ; }
if ( c0 == n ) {
Console . Write ( n ) ; return ; }
int mx = 0 ;
int cnt = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( str [ i ] == '0' ) cnt ++ ; else { mx = Math . Max ( mx , cnt ) ; cnt = 0 ; } }
mx = Math . Max ( mx , cnt ) ;
int start = 0 , end = n - 1 ; cnt = 0 ;
while ( str [ start ] != '1' && start < n ) { cnt ++ ; start ++ ; }
while ( str [ end ] != '1' && end >= 0 ) { cnt ++ ; end -- ; }
mx = Math . Max ( mx , cnt ) ;
Console . Write ( mx ) ; }
string s = "1001" ;
int n = s . Length ; findMaximumZeros ( s , n ) ; } }
public class Node { public int data ; public Node left , right ; }
static int getLeafCount ( Node node ) {
if ( node == null ) { return 0 ; }
Queue < Node > q = new Queue < Node > ( ) ;
int count = 0 ; q . Enqueue ( node ) ; while ( q . Count != 0 ) { Node temp = q . Peek ( ) ; q . Dequeue ( ) ; if ( temp . left != null ) { q . Enqueue ( temp . left ) ; } if ( temp . right != null ) { q . Enqueue ( temp . right ) ; } if ( temp . left == null && temp . right == null ) { count ++ ; } } return count ; }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ;
Console . WriteLine ( getLeafCount ( root ) ) ; } } }
static void stringShift ( String s , int [ , ] shift ) { int val = 0 ; for ( int i = 0 ; i < shift . GetLength ( 0 ) ; ++ i )
if ( shift [ i , 0 ] == 0 ) val -= shift [ i , 1 ] ; else val += shift [ i , 1 ] ;
int len = s . Length ;
val = val % len ;
String result = " " ;
if ( val > 0 ) result = s . Substring ( len - val , val ) + s . Substring ( 0 , len - val ) ;
else result = s . Substring ( - val , len ) + s . Substring ( 0 , - val ) ; Console . WriteLine ( result ) ; }
public static void Main ( String [ ] args ) { String s = " abc " ; int [ , ] shift = new int [ , ] { { 0 , 1 } , { 1 , 2 } } ; stringShift ( s , shift ) ; } }
static void rotateArray ( int [ ] arr , int N ) {
int [ ] v = arr ;
Array . Sort ( v ) ;
for ( int i = 1 ; i <= N ; ++ i ) {
int x = arr [ N - 1 ] ; i = N - 1 ; while ( i > 0 ) { arr [ i ] = arr [ i - 1 ] ; arr [ 0 ] = x ; i -= 1 ; }
if ( arr == v ) { Console . Write ( " YES " ) ; return ; } }
Console . Write ( " NO " ) ; }
int [ ] arr = { 3 , 4 , 5 , 1 , 2 } ;
int N = arr . Length ;
rotateArray ( arr , N ) ; } }
static void findLargestRotation ( int num ) {
int ans = num ;
double lg = ( double ) ( Math . Log10 ( num ) + 1 ) ; int len = ( int ) ( Math . Floor ( lg ) ) ; int x = ( int ) Math . Pow ( 10 , len - 1 ) ;
for ( int i = 1 ; i < len ; i ++ ) {
int lastDigit = num % 10 ;
num = num / 10 ;
num += ( lastDigit * x ) ;
if ( num > ans ) { ans = num ; } }
Console . Write ( ans ) ; }
public static void Main ( string [ ] args ) { int N = 657 ; findLargestRotation ( N ) ; } }
static int numberOfDigit ( int N ) {
int digit = 0 ;
while ( N > 0 ) {
digit ++ ;
N /= 10 ; } return digit ; }
static void rotateNumberByK ( int N , int K ) {
int X = numberOfDigit ( N ) ;
K = ( ( K % X ) + X ) % X ;
int left_no = N / ( int ) ( Math . Pow ( 10 , X - K ) ) ;
N = N % ( int ) ( Math . Pow ( 10 , X - K ) ) ;
int left_digit = numberOfDigit ( left_no ) ;
N = ( N * ( int ) ( Math . Pow ( 10 , left_digit ) ) ) + left_no ; Console . WriteLine ( N ) ; }
public static void Main ( string [ ] args ) { int N = 12345 , K = 7 ;
rotateNumberByK ( N , K ) ; } }
static void minMovesToSort ( int [ ] arr , int N ) {
int count = 0 ;
int index = 0 ;
for ( int i = 0 ; i < N - 1 ; i ++ ) {
if ( arr [ i ] < arr [ i + 1 ] ) {
count ++ ;
index = i ; } }
if ( count == 0 ) { Console . Write ( "0" ) ; } else if ( count == N - 1 ) { Console . Write ( N - 1 ) ; } else if ( count == 1 && arr [ 0 ] <= arr [ N - 1 ] ) { Console . Write ( index + 1 ) ; }
else { Console . Write ( " - 1" ) ; } }
int [ ] arr = { 2 , 1 , 5 , 4 , 2 } ; int N = arr . Length ;
minMovesToSort ( arr , N ) ; } }
using System ; class GFG { static int N = 3 ;
static int findMaximumDiagonalSumOMatrixf ( int [ , ] A ) {
int maxDiagonalSum = Int32 . MinValue ;
for ( int i = 0 ; i < N ; i ++ ) {
int curr = 0 ;
for ( int j = 0 ; j < N ; j ++ ) {
curr += A [ j , ( i + j ) % N ] ; }
maxDiagonalSum = Math . Max ( maxDiagonalSum , curr ) ; }
for ( int i = 0 ; i < N ; i ++ ) {
int curr = 0 ;
for ( int j = 0 ; j < N ; j ++ ) {
curr += A [ ( i + j ) % N , j ] ; }
maxDiagonalSum = Math . Max ( maxDiagonalSum , curr ) ; } return maxDiagonalSum ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 1 , 2 } , { 2 , 1 , 2 } , { 1 , 2 , 2 } } ; Console . Write ( findMaximumDiagonalSumOMatrixf ( mat ) ) ; } }
static void diagonalSumPerfectSquare ( int [ ] arr , int N ) {
for ( int i = 0 ; i < N ; i ++ ) {
for ( int j = 0 ; j < N ; j ++ ) { Console . Write ( arr [ ( j + i ) % 7 ] + " ▁ " ) ; } Console . WriteLine ( ) ; } }
int N = 7 ; int [ ] arr = new int [ N ] ;
for ( int i = 0 ; i < N ; i ++ ) { arr [ i ] = i + 1 ; }
diagonalSumPerfectSquare ( arr , N ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int d ) { data = d ; left = right = null ; } } public class BinaryTree { public static Node root ;
static int countLeaves ( Node node ) {
if ( node == null ) { return 0 ; }
if ( node . left == null && node . right == null ) { return 1 ; }
return countLeaves ( node . left ) + countLeaves ( node . right ) ; }
static public void Main ( ) { BinaryTree . root = new Node ( 1 ) ; BinaryTree . root . left = new Node ( 2 ) ; BinaryTree . root . right = new Node ( 3 ) ; BinaryTree . root . left . left = new Node ( 4 ) ; BinaryTree . root . left . right = new Node ( 5 ) ;
Console . WriteLine ( countLeaves ( root ) ) ; } }
static int MaxSum ( int [ ] arr , int n , int k ) { int i , max_sum = 0 , sum = 0 ;
for ( i = 0 ; i < k ; i ++ ) { sum += arr [ i ] ; } max_sum = sum ;
while ( i < n ) {
sum = sum - arr [ i - k ] + arr [ i ] ; if ( max_sum < sum ) { max_sum = sum ; } i ++ ; }
return max_sum ; }
static int gcd ( int n1 , int n2 ) {
if ( n2 == 0 ) { return n1 ; }
else { return gcd ( n2 , n1 % n2 ) ; } }
static int [ ] RotateArr ( int [ ] arr , int n , int d ) {
int i = 0 , j = 0 ; d = d % n ;
int no_of_sets = gcd ( d , n ) ; for ( i = 0 ; i < no_of_sets ; i ++ ) { int temp = arr [ i ] ; j = i ;
while ( true ) { int k = j + d ; if ( k >= n ) k = k - n ; if ( k == i ) break ; arr [ j ] = arr [ k ] ; j = k ; }
arr [ j ] = temp ; }
return arr ; }
static void performQuery ( int [ ] arr , int [ , ] Q , int q ) { int N = arr . Length ;
for ( int i = 0 ; i < q ; i ++ ) {
if ( Q [ i , 0 ] == 1 ) { arr = RotateArr ( arr , N , Q [ i , 1 ] ) ;
for ( int t = 0 ; t < arr . Length ; t ++ ) { Console . Write ( arr [ t ] + " ▁ " ) ; } Console . WriteLine ( ) ; }
else { Console . WriteLine ( MaxSum ( arr , N , Q [ i , 1 ] ) ) ; } } }
int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; int q = 5 ;
int [ , ] Q = { { 1 , 2 } , { 2 , 3 } , { 1 , 3 } , { 1 , 1 } , { 2 , 4 } } ;
performQuery ( arr , Q , q ) ; } }
public static int getMinimumRemoval ( String str ) { int n = str . Length ;
int ans = n ;
if ( n % 2 == 0 ) {
int [ ] freqEven = new int [ 128 ] ; int [ ] freqOdd = new int [ 128 ] ;
for ( int i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) { freqEven [ str [ i ] ] ++ ; } else { freqOdd [ str [ i ] ] ++ ; } }
int evenMax = 0 , oddMax = 0 ; for ( char chr = ' a ' ; chr <= ' z ' ; chr ++ ) { evenMax = Math . Max ( evenMax , freqEven [ chr ] ) ; oddMax = Math . Max ( oddMax , freqOdd [ chr ] ) ; }
ans = ans - evenMax - oddMax ; }
else {
int [ ] freq = new int [ 128 ] ; for ( int i = 0 ; i < n ; i ++ ) { freq [ str [ i ] ] ++ ; }
int strMax = 0 ; for ( char chr = ' a ' ; chr <= ' z ' ; chr ++ ) { strMax = Math . Max ( strMax , freq [ chr ] ) ; }
ans = ans - strMax ; } return ans ; }
public static void Main ( String [ ] args ) { String str = " geeksgeeks " ; Console . Write ( getMinimumRemoval ( str ) ) ; } }
static int findAltSubSeq ( String s ) {
int n = s . Length , ans = int . MinValue ;
for ( int i = 0 ; i < 10 ; i ++ ) { for ( int j = 0 ; j < 10 ; j ++ ) { int cur = 0 , f = 0 ;
for ( int k = 0 ; k < n ; k ++ ) { if ( f == 0 && s [ k ] - '0' == i ) { f = 1 ;
cur ++ ; } else if ( f = = 1 && s [ k ] - '0' == j ) { f = 0 ;
cur ++ ; } }
if ( i != j && cur % 2 == 1 )
cur -- ;
ans = Math . Max ( cur , ans ) ; } }
return ans ; }
public static void Main ( String [ ] args ) { String s = "100210601" ; Console . Write ( findAltSubSeq ( s ) ) ; } }
static int getFirstElement ( int [ ] a , int N , int K , int M ) {
K %= N ; int index ;
if ( K >= M )
index = ( N - K ) + ( M - 1 ) ;
else
index = ( M - K - 1 ) ; int result = a [ index ] ;
return result ; }
public static void Main ( ) { int [ ] a = { 1 , 2 , 3 , 4 , 5 } ; int N = 5 ; int K = 3 , M = 2 ; Console . Write ( getFirstElement ( a , N , K , M ) ) ; } }
public static int getFirstElement ( int [ ] a , int N , int K , int M ) {
K %= N ;
int index = ( K + M - 1 ) % N ; int result = a [ index ] ;
return result ; }
int [ ] a = { 3 , 4 , 5 , 23 } ;
int N = a . Length ;
int K = 2 , M = 1 ;
Console . Write ( getFirstElement ( a , N , K , M ) ) ; } }
static void left_rotate ( int [ ] arr ) { int last = arr [ 1 ] ; for ( int i = 3 ; i < arr . Length ; i = i + 2 ) { arr [ i - 2 ] = arr [ i ] ; } arr [ arr . Length - 1 ] = last ; }
static void right_rotate ( int [ ] arr ) { int start = arr [ arr . Length - 2 ] ; for ( int i = arr . Length - 4 ; i >= 0 ; i = i - 2 ) { arr [ i + 2 ] = arr [ i ] ; } arr [ 0 ] = start ; }
public static void rotate ( int [ ] arr ) { left_rotate ( arr ) ; right_rotate ( arr ) ; for ( int i = 0 ; i < arr . Length ; i ++ ) { Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 } ; rotate ( arr ) ; } }
static int maximumMatchingPairs ( int [ ] perm1 , int [ ] perm2 , int n ) {
int [ ] left = new int [ n ] ; int [ ] right = new int [ n ] ;
Dictionary < int , int > mp1 = new Dictionary < int , int > ( ) ; Dictionary < int , int > mp2 = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { mp1 [ perm1 [ i ] ] = i ; } for ( int j = 0 ; j < n ; j ++ ) { mp2 [ perm2 [ j ] ] = j ; } for ( int i = 0 ; i < n ; i ++ ) {
int idx2 = mp2 [ perm1 [ i ] ] ; int idx1 = i ; if ( idx1 == idx2 ) {
left [ i ] = 0 ; right [ i ] = 0 ; } else if ( idx1 < idx2 ) {
left [ i ] = ( n - ( idx2 - idx1 ) ) ; right [ i ] = ( idx2 - idx1 ) ; } else {
left [ i ] = ( idx1 - idx2 ) ; right [ i ] = ( n - ( idx1 - idx2 ) ) ; } }
Dictionary < int , int > freq1 = new Dictionary < int , int > ( ) ; Dictionary < int , int > freq2 = new Dictionary < int , int > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( freq1 . ContainsKey ( left [ i ] ) ) freq1 [ left [ i ] ] ++ ; else freq1 [ left [ i ] ] = 1 ; if ( freq2 . ContainsKey ( right [ i ] ) ) freq2 [ right [ i ] ] ++ ; else freq2 [ right [ i ] ] = 1 ; } int ans = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
ans = Math . Max ( ans , Math . Max ( freq1 [ left [ i ] ] , freq2 [ right [ i ] ] ) ) ; }
return ans ; }
int [ ] P1 = { 5 , 4 , 3 , 2 , 1 } ; int [ ] P2 = { 1 , 2 , 3 , 4 , 5 } ; int n = P1 . Length ;
Console . Write ( maximumMatchingPairs ( P1 , P2 , n ) ) ; } }
static int [ ] arr = new int [ 10000 ] ;
public static void reverse ( int [ ] arr , int s , int e ) { while ( s < e ) { int tem = arr [ s ] ; arr [ s ] = arr [ e ] ; arr [ e ] = tem ; s = s + 1 ; e = e - 1 ; } }
public static void fun ( int [ ] arr , int k ) { int n = 4 - 1 ; int v = n - k ; if ( v >= 0 ) { reverse ( arr , 0 , v ) ; reverse ( arr , v + 1 , n ) ; reverse ( arr , 0 , n ) ; } }
public static void Main ( String [ ] args ) { arr [ 0 ] = 1 ; arr [ 1 ] = 2 ; arr [ 2 ] = 3 ; arr [ 3 ] = 4 ; for ( int i = 0 ; i < 4 ; i ++ ) { fun ( arr , i ) ; Console . Write ( " [ " ) ; for ( int j = 0 ; j < 4 ; j ++ ) { Console . Write ( arr [ j ] + " , ▁ " ) ; } Console . Write ( " ] " ) ; } } }
public static int countRotation ( int [ ] arr , int n ) { for ( int i = 1 ; i < n ; i ++ ) {
if ( arr [ i ] < arr [ i - 1 ] ) {
return i ; } }
return 0 ; }
public static void Main ( String [ ] args ) { int [ ] arr1 = { 4 , 5 , 1 , 2 , 3 } ; Console . WriteLine ( countRotation ( arr1 , arr1 . Length ) ) ; } }
public static int countRotation ( int [ ] arr , int low , int high ) {
if ( low > high ) { return 0 ; } int mid = low + ( high - low ) / 2 ;
if ( mid < high && arr [ mid ] > arr [ mid + 1 ] ) {
return mid + 1 ; }
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) {
return mid ; }
if ( arr [ mid ] > arr [ low ] ) {
return countRotation ( arr , mid + 1 , high ) ; } if ( arr [ mid ] < arr [ high ] ) {
return countRotation ( arr , low , mid - 1 ) ; } else {
int rightIndex = countRotation ( arr , mid + 1 , high ) ; int leftIndex = countRotation ( arr , low , mid - 1 ) ; if ( rightIndex == 0 ) { return leftIndex ; } return rightIndex ; } }
public static void Main ( String [ ] args ) { int [ ] arr1 = { 4 , 5 , 1 , 2 , 3 } ; Console . WriteLine ( countRotation ( arr1 , 0 , arr1 . Length - 1 ) ) ; } }
using System ; class GFG { static int MAX = 100005 ;
static int [ ] seg = new int [ 4 * MAX ] ;
static void build ( int node , int l , int r , int [ ] a ) { if ( l == r ) seg [ node ] = a [ l ] ; else { int mid = ( l + r ) / 2 ; build ( 2 * node , l , mid , a ) ; build ( 2 * node + 1 , mid + 1 , r , a ) ; seg [ node ] = ( seg [ 2 * node ] seg [ 2 * node + 1 ] ) ; } }
static int query ( int node , int l , int r , int start , int end , int [ ] a ) {
if ( l > end r < start ) return 0 ; if ( start <= l && r <= end ) return seg [ node ] ;
int mid = ( l + r ) / 2 ;
return ( ( query ( 2 * node , l , mid , start , end , a ) ) | ( query ( 2 * node + 1 , mid + 1 , r , start , end , a ) ) ) ; }
static void orsum ( int [ ] a , int n , int q , int [ ] k ) {
build ( 1 , 0 , n - 1 , a ) ;
for ( int j = 0 ; j < q ; j ++ ) {
int i = k [ j ] % ( n / 2 ) ;
int sec = query ( 1 , 0 , n - 1 , n / 2 - i , n - i - 1 , a ) ;
int first = ( query ( 1 , 0 , n - 1 , 0 , n / 2 - 1 - i , a ) | query ( 1 , 0 , n - 1 , n - i , n - 1 , a ) ) ; int temp = sec + first ;
Console . Write ( temp + " STRNEWLINE " ) ; } }
public static void Main ( String [ ] args ) { int [ ] a = { 7 , 44 , 19 , 86 , 65 , 39 , 75 , 101 } ; int n = a . Length ; int q = 2 ; int [ ] k = { 4 , 2 } ; orsum ( a , n , q , k ) ; } }
static void maximumEqual ( int [ ] a , int [ ] b , int n ) {
int [ ] store = new int [ ( int ) 1e5 ] ;
for ( int i = 0 ; i < n ; i ++ ) { store [ b [ i ] ] = i + 1 ; }
int [ ] ans = new int [ ( int ) 1e5 ] ;
for ( int i = 0 ; i < n ; i ++ ) {
int d = Math . Abs ( store [ a [ i ] ] - ( i + 1 ) ) ;
if ( store [ a [ i ] ] < i + 1 ) { d = n - d ; }
ans [ d ] ++ ; } int finalans = 0 ;
for ( int i = 0 ; i < 1e5 ; i ++ ) finalans = Math . Max ( finalans , ans [ i ] ) ;
Console . Write ( finalans + " STRNEWLINE " ) ; }
int [ ] A = { 6 , 7 , 3 , 9 , 5 } ; int [ ] B = { 7 , 3 , 9 , 5 , 6 } ; int size = A . Length ;
maximumEqual ( A , B , size ) ; } }
static void rotatedSumQuery ( int [ ] arr , int n , int [ , ] query , int Q ) {
int [ ] prefix = new int [ 2 * n ] ;
for ( int i = 0 ; i < n ; i ++ ) { prefix [ i ] = arr [ i ] ; prefix [ i + n ] = arr [ i ] ; }
for ( int i = 1 ; i < 2 * n ; i ++ ) prefix [ i ] += prefix [ i - 1 ] ;
int start = 0 ; for ( int q = 0 ; q < Q ; q ++ ) {
if ( query [ q , 0 ] == 1 ) { int k = query [ q , 1 ] ; start = ( start + k ) % n ; }
else if ( query [ q , 0 ] == 2 ) { int L , R ; L = query [ q , 1 ] ; R = query [ q , 2 ] ;
if ( start + L == 0 )
Console . Write ( prefix [ start + R ] + " STRNEWLINE " ) ; else
Console . Write ( prefix [ start + R ] - prefix [ start + L - 1 ] + " STRNEWLINE " ) ; } } }
public static void Main ( ) { int [ ] arr = new int [ ] { 1 , 2 , 3 , 4 , 5 , 6 } ;
int Q = 5 ;
int [ , ] query = new int [ , ] { { 2 , 1 , 3 } , { 1 , 3 , 0 } , { 2 , 0 , 3 } , { 1 , 4 , 0 } , { 2 , 3 , 5 } } ; int n = arr . Length ; rotatedSumQuery ( arr , n , query , Q ) ; } }
static void isConversionPossible ( String s1 , String s2 , int x ) { int diff = 0 , n ; n = s1 . Length ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( s1 [ i ] == s2 [ i ] ) continue ;
diff = ( ( int ) ( s2 [ i ] - s1 [ i ] ) + 26 ) % 26 ;
if ( diff > x ) { Console . Write ( " NO " ) ; return ; } } Console . Write ( " YES " ) ; }
public static void Main ( ) { String s1 = " you " ; String s2 = " ara " ; int x = 6 ;
isConversionPossible ( s1 , s2 , x ) ; } }
static void RightRotate ( int [ ] a , int n , int k ) {
k = k % n ; for ( int i = 0 ; i < n ; i ++ ) { if ( i < k ) {
Console . Write ( a [ n + i - k ] + " ▁ " ) ; } else {
Console . Write ( a [ i - k ] + " ▁ " ) ; } } Console . WriteLine ( ) ; }
public static void Main ( String [ ] args ) { int [ ] Array = { 1 , 2 , 3 , 4 , 5 } ; int N = Array . Length ; int K = 2 ; RightRotate ( Array , N , K ) ; } }
static int countRotation ( int n ) { int count = 0 ;
do { int digit = n % 10 ;
if ( digit % 2 == 0 ) count ++ ; n = n / 10 ; } while ( n != 0 ) ; return count ; }
public static void Main ( ) { int n = 10203 ; Console . Write ( countRotation ( n ) ) ; } }
public class Node { public int data ; public Node next ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ;
( head_ref ) = new_node ; return head_ref ; }
static void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ - > ▁ " ) ; node = node . next ; } Console . Write ( " null " ) ; }
static Node rightRotate ( Node head , int k ) {
if ( head == null ) return head ;
Node tmp = head ; int len = 1 ; while ( tmp . next != null ) { tmp = tmp . next ; len ++ ; }
if ( k > len ) k = k % len ;
k = len - k ;
if ( k == 0 k == len ) return head ;
Node current = head ; int cnt = 1 ; while ( cnt < k && current != null ) { current = current . next ; cnt ++ ; }
if ( current == null ) return head ;
Node kthnode = current ;
tmp . next = head ;
head = kthnode . next ;
kthnode . next = null ;
return head ; }
Node head = null ; head = push ( head , 5 ) ; head = push ( head , 4 ) ; head = push ( head , 3 ) ; head = push ( head , 2 ) ; head = push ( head , 1 ) ; int k = 2 ;
Node updated_head = rightRotate ( head , k ) ;
printList ( updated_head ) ; } }
static bool isPossible ( int [ ] a , int n ) {
if ( n <= 2 ) return true ; int flag = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) { if ( ! ( a [ i ] > a [ i + 1 ] && a [ i + 1 ] > a [ i + 2 ] ) ) { flag = 1 ; break ; } }
if ( flag == 0 ) return true ; flag = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) { if ( ! ( a [ i ] < a [ i + 1 ] && a [ i + 1 ] < a [ i + 2 ] ) ) { flag = 1 ; break ; } }
if ( flag == 0 ) return true ;
int val1 = int . MaxValue , mini = - 1 , val2 = int . MinValue , maxi = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] < val1 ) { mini = i ; val1 = a [ i ] ; } if ( a [ i ] > val2 ) { maxi = i ; val2 = a [ i ] ; } } flag = 1 ;
for ( int i = 0 ; i < maxi ; i ++ ) { if ( a [ i ] > a [ i + 1 ] ) { flag = 0 ; break ; } }
if ( flag == 1 && maxi + 1 == mini ) { flag = 1 ;
for ( int i = mini ; i < n - 1 ; i ++ ) { if ( a [ i ] > a [ i + 1 ] ) { flag = 0 ; break ; } } if ( flag == 1 ) return true ; } flag = 1 ;
for ( int i = 0 ; i < mini ; i ++ ) { if ( a [ i ] < a [ i + 1 ] ) { flag = 0 ; break ; } }
if ( flag == 1 && maxi - 1 == mini ) { flag = 1 ;
for ( int i = maxi ; i < n - 1 ; i ++ ) { if ( a [ i ] < a [ i + 1 ] ) { flag = 0 ; break ; } } if ( flag == 1 ) return true ; }
return false ; }
public static void Main ( ) { int [ ] a = { 4 , 5 , 6 , 2 , 3 } ; int n = a . Length ; if ( isPossible ( a , n ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
static int cntRotations ( string s , int n ) {
string str = s + s ;
int [ ] pre = new int [ 2 * n ] ;
for ( int i = 0 ; i < 2 * n ; i ++ ) { if ( i != 0 ) pre [ i ] += pre [ i - 1 ] ; if ( str [ i ] == ' a ' str [ i ] == ' e ' str [ i ] == ' i ' str [ i ] == ' o ' str [ i ] == ' u ' ) { pre [ i ] ++ ; } }
int ans = 0 ;
for ( int i = n - 1 ; i < 2 * n - 1 ; i ++ ) {
int r = i , l = i - n ;
int x1 = pre [ r ] ; if ( l >= 0 ) x1 -= pre [ l ] ; r = i - n / 2 ;
int left = pre [ r ] ; if ( l >= 0 ) left -= pre [ l ] ;
int right = x1 - left ;
if ( left > right ) { ans ++ ; } }
return ans ; }
public static void Main ( ) { String s = " abecidft " ; int n = s . Length ; Console . WriteLine ( cntRotations ( s , n ) ) ; } }
static int cntRotations ( char [ ] s , int n ) { int lh = 0 , rh = 0 , i , ans = 0 ;
for ( i = 0 ; i < n / 2 ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { lh ++ ; }
for ( i = n / 2 ; i < n ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { rh ++ ; }
if ( lh > rh ) ans ++ ;
for ( i = 1 ; i < n ; ++ i ) { if ( s [ i - 1 ] == ' a ' s [ i - 1 ] == ' e ' s [ i - 1 ] == ' i ' s [ i - 1 ] == ' o ' s [ i - 1 ] == ' u ' ) { rh ++ ; lh -- ; } if ( s [ ( i - 1 + n / 2 ) % n ] == ' a ' || s [ ( i - 1 + n / 2 ) % n ] == ' e ' || s [ ( i - 1 + n / 2 ) % n ] == ' i ' || s [ ( i - 1 + n / 2 ) % n ] == ' o ' || s [ ( i - 1 + n / 2 ) % n ] == ' u ' ) { rh -- ; lh ++ ; } if ( lh > rh ) ans ++ ; }
return ans ; }
static void Main ( ) { char [ ] s = { ' a ' , ' b ' , ' e ' , ' c ' , ' i ' , ' d ' , ' f ' , ' t ' } ; int n = s . Length ;
Console . WriteLine ( cntRotations ( s , n ) ) ; } }
using System ; class GFG { static int size = 2 ;
static void performQueries ( String str , int n , int [ , ] queries , int q ) {
int ptr = 0 ;
for ( int i = 0 ; i < q ; i ++ ) {
if ( queries [ i , 0 ] == 1 ) {
ptr = ( ptr + queries [ i , 1 ] ) % n ; } else { int k = queries [ i , 1 ] ;
int index = ( ptr + k - 1 ) % n ;
Console . WriteLine ( str [ index ] ) ; } } }
public static void Main ( String [ ] args ) { String str = " abcdefgh " ; int n = str . Length ; int [ , ] queries = { { 1 , 2 } , { 2 , 2 } , { 1 , 4 } , { 2 , 7 } } ; int q = queries . GetLength ( 0 ) ; performQueries ( str , n , queries , q ) ; } }
static void countOddRotations ( int n ) { int odd_count = 0 , even_count = 0 ; do { int digit = n % 10 ; if ( digit % 2 == 1 ) odd_count ++ ; else even_count ++ ; n = n / 10 ; } while ( n != 0 ) ; Console . WriteLine ( " Odd ▁ = ▁ " + odd_count ) ; Console . WriteLine ( " Even ▁ = ▁ " + even_count ) ; }
public static void Main ( ) { int n = 1234 ; countOddRotations ( n ) ; } }
static int numberOfDigits ( int n ) { int cnt = 0 ; while ( n > 0 ) { cnt ++ ; n /= 10 ; } return cnt ; }
static void cal ( int num ) { int digits = numberOfDigits ( num ) ; int powTen = ( int ) Math . Pow ( 10 , digits - 1 ) ; for ( int i = 0 ; i < digits - 1 ; i ++ ) { int firstDigit = num / powTen ;
int left = ( ( num * 10 ) + firstDigit ) - ( firstDigit * powTen * 10 ) ; Console . Write ( left + " ▁ " ) ;
num = left ; } }
static public void Main ( ) { int num = 1445 ; cal ( num ) ; } }
using System ; class GFG { static void CheckKCycles ( int n , String s ) { bool ff = true ; int x = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
x = ( s . Substring ( i ) + s . Substring ( 0 , i ) ) . Length ;
if ( x >= s . Length ) { continue ; } ff = false ; break ; } if ( ff ) { Console . WriteLine ( " Yes " ) ; } else { Console . WriteLine ( " No " ) ; } }
public static void Main ( String [ ] args ) { int n = 3 ; String s = "123" ; CheckKCycles ( n , s ) ; } }
public class ListNode { public int data ; public ListNode next ; }
public static void rotateSubList ( ListNode A , int m , int n , int k ) { int size = n - m + 1 ;
if ( k > size ) { k = k % size ; }
if ( k == 0 k == size ) { ListNode head = A ; while ( head != null ) { Console . Write ( head . data ) ; head = head . next ; } return ; }
ListNode link = null ; if ( m == 1 ) { link = A ; }
ListNode c = A ;
int count = 0 ; ListNode end = null ;
ListNode pre = null ; while ( c != null ) { count ++ ;
if ( count == m - 1 ) { pre = c ; link = c . next ; } if ( count == n - k ) { if ( m == 1 ) { end = c ; A = c . next ; } else { end = c ;
pre . next = c . next ; } }
if ( count == n ) { ListNode d = c . next ; c . next = link ; end . next = d ; ListNode head = A ; while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; head = head . next ; } return ; } c = c . next ; } }
public static ListNode push ( ListNode head , int val ) { ListNode new_node = new ListNode ( ) ; new_node . data = val ; new_node . next = ( head ) ; ( head ) = new_node ; return head ; }
public static void Main ( string [ ] args ) { ListNode head = null ; head = push ( head , 70 ) ; head = push ( head , 60 ) ; head = push ( head , 50 ) ; head = push ( head , 40 ) ; head = push ( head , 30 ) ; head = push ( head , 20 ) ; head = push ( head , 10 ) ; ListNode tmp = head ; Console . Write ( " Given ▁ List : ▁ " ) ; while ( tmp != null ) { Console . Write ( tmp . data + " ▁ " ) ; tmp = tmp . next ; } Console . WriteLine ( ) ; int m = 3 , n = 6 , k = 2 ; Console . Write ( " After ▁ rotation ▁ of ▁ sublist : ▁ " ) ; rotateSubList ( head , m , n , k ) ; } }
static bool rightRotationDivisor ( int N ) { int lastDigit = N % 10 ; int rightRotation = ( int ) ( lastDigit * Math . Pow ( 10 , ( int ) ( Math . Log10 ( N ) ) ) + Math . Floor ( ( double ) N / 10 ) ) ; return ( rightRotation % N == 0 ) ; }
static void generateNumbers ( int m ) { for ( int i = ( int ) Math . Pow ( 10 , ( m - 1 ) ) ; i < Math . Pow ( 10 , m ) ; i ++ ) if ( rightRotationDivisor ( i ) ) Console . WriteLine ( i ) ; }
public static void Main ( ) { int m = 3 ; generateNumbers ( m ) ; } }
class Node { public int data ; public Node left , right , next ; public Node ( int item ) { data = item ; left = right = next = null ; } } Node root ; static Node next = null ;
void populateNext ( Node node ) {
if ( node != null ) {
populateNext ( node . right ) ;
node . next = next ;
next = node ;
populateNext ( node . left ) ; } }
static public void Main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 12 ) ; tree . root . left . left = new Node ( 3 ) ;
tree . populateNext ( tree . root ) ;
Node ptr = tree . root . left . left ; while ( ptr != null ) {
int print = ptr . next != null ? ptr . next . data : - 1 ; Console . WriteLine ( " Next ▁ of ▁ " + ptr . data + " ▁ is : ▁ " + print ) ; ptr = ptr . next ; } } }
static void generateNumbers ( int m ) { List < int > numbers = new List < int > ( ) ; int k_max , x ; for ( int y = 0 ; y < 10 ; y ++ ) { k_max = ( int ) ( Math . Pow ( 10 , m - 2 ) * ( 10 * y + 1 ) ) / ( int ) ( Math . Pow ( 10 , m - 1 ) + y ) ; for ( int k = 1 ; k <= k_max ; k ++ ) { x = ( int ) ( y * ( Math . Pow ( 10 , m - 1 ) - k ) ) / ( 10 * k - 1 ) ; if ( ( int ) ( y * ( Math . Pow ( 10 , m - 1 ) - k ) ) % ( 10 * k - 1 ) == 0 ) numbers . Add ( 10 * x + y ) ; } } numbers . Sort ( ) ; for ( int i = 0 ; i < numbers . Count ; i ++ ) Console . WriteLine ( numbers [ i ] ) ; }
public static void Main ( String [ ] args ) { int m = 3 ; generateNumbers ( m ) ; } }
static void checkIfSortRotated ( int [ ] arr , int n ) { int minEle = int . MaxValue ; int maxEle = int . MinValue ; int minIndex = - 1 ;
for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < minEle ) { minEle = arr [ i ] ; minIndex = i ; } } bool flag1 = true ;
for ( int i = 1 ; i < minIndex ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag1 = false ; break ; } } bool flag2 = true ;
for ( int i = minIndex + 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag2 = false ; break ; } }
if ( flag1 && flag2 && ( arr [ n - 1 ] < arr [ 0 ] ) ) Console . WriteLine ( " YES " ) ; else Console . WriteLine ( " NO " ) ; }
public static void Main ( ) { int [ ] arr = { 3 , 4 , 5 , 1 , 2 } ; int n = arr . Length ;
checkIfSortRotated ( arr , n ) ; } }
using System ; class GFG { static int N = 4 ;
static void rotate90Clockwise ( int [ , ] arr ) {
for ( int j = 0 ; j < N ; j ++ ) { for ( int i = N - 1 ; i >= 0 ; i -- ) Console . Write ( arr [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
static void Main ( ) { int [ , ] arr = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; rotate90Clockwise ( arr ) ; } }
using System ; using System . Collections . Generic ; public class GFG {
static void rotate ( int [ , ] arr ) { int n = arr . GetLength ( 0 ) ;
for ( int i = 0 ; i < n ; ++ i ) { for ( int j = 0 ; j < i ; ++ j ) { int temp = arr [ i , j ] ; arr [ i , j ] = arr [ j , i ] ; arr [ j , i ] = temp ; } }
for ( int i = 0 ; i < n ; ++ i ) { for ( int j = 0 ; j < n / 2 ; ++ j ) { int temp = arr [ i , j ] ; arr [ i , j ] = arr [ i , n - j - 1 ] ; arr [ i , n - j - 1 ] = temp ; } } }
static void printMatrix ( int [ , ] arr ) { int n = arr . GetLength ( 0 ) ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) Console . Write ( arr [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( String [ ] args ) { int [ , ] arr = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; rotate ( arr ) ; printMatrix ( arr ) ; } }
static void occurredOnce ( int [ ] arr , int n ) {
Array . Sort ( arr ) ;
if ( arr [ 0 ] != arr [ 1 ] ) Console . Write ( arr [ 0 ] + " ▁ " ) ;
for ( int i = 1 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i - 1 ] ) Console . Write ( arr [ i ] + " ▁ " ) ;
if ( arr [ n - 2 ] != arr [ n - 1 ] ) Console . Write ( arr [ n - 1 ] + " ▁ " ) ; }
public static void Main ( ) { int [ ] arr = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = arr . Length ; occurredOnce ( arr , n ) ; } }
static void occurredOnce ( int [ ] arr , int n ) { Dictionary < int , int > mp = new Dictionary < int , int > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( mp . ContainsKey ( arr [ i ] ) ) mp [ arr [ i ] ] = 1 + mp [ arr [ i ] ] ; else mp . Add ( arr [ i ] , 1 ) ; }
foreach ( KeyValuePair < int , int > entry in mp ) { if ( Int32 . Parse ( String . Join ( " " , entry . Value ) ) == 1 ) Console . Write ( entry . Key + " ▁ " ) ; } }
public static void Main ( String [ ] args ) { int [ ] arr = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = arr . Length ; occurredOnce ( arr , n ) ; } }
static void occurredOnce ( int [ ] arr , int n ) { int i = 1 , len = n ;
if ( arr [ 0 ] == arr [ len - 1 ] ) { i = 2 ; len -- ; }
for ( ; i < n ; i ++ )
if ( arr [ i ] == arr [ i - 1 ] ) i ++ ;
else Console . ( arr [ i - 1 ] + " ▁ " ) ;
if ( arr [ n - 1 ] != arr [ 0 ] && arr [ n - 1 ] != arr [ n - 2 ] ) Console . Write ( arr [ n - 1 ] ) ; }
public static void Main ( ) { int [ ] arr = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = arr . Length ; occurredOnce ( arr , n ) ; } }
static void rvereseArray ( int [ ] arr , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
static void splitArr ( int [ ] arr , int k , int n ) { rvereseArray ( arr , 0 , n - 1 ) ; rvereseArray ( arr , 0 , n - k - 1 ) ; rvereseArray ( arr , n - k , n - 1 ) ; }
public static void Main ( ) { int [ ] arr = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = arr . Length ; int k = 2 ;
splitArr ( arr , k , n ) ; printArray ( arr , n ) ; } }
using System ; class GFG { public static bool isRotation ( string a , string b ) { int n = a . Length ; int m = b . Length ; if ( n != m ) return false ;
int [ ] lps = new int [ n ] ;
int len = 0 ; int i = 1 ;
lps [ 0 ] = 0 ;
while ( i < n ) { if ( a [ i ] == b [ len ] ) { lps [ i ] = ++ len ; ++ i ; } else { if ( len == 0 ) { lps [ i ] = 0 ; ++ i ; } else { len = lps [ len - 1 ] ; } } } i = 0 ;
for ( int k = lps [ n - 1 ] ; k < m ; ++ k ) { if ( b [ k ] != a [ i ++ ] ) return false ; } return true ; }
public static void Main ( ) { string s1 = " ABACD " ; string s2 = " CDABA " ; Console . WriteLine ( isRotation ( s1 , s2 ) ? "1" : "0" ) ; } }
static int countRotationsDivBy8 ( String n ) { int len = n . Length ; int count = 0 ;
if ( len == 1 ) { int oneDigit = n [ 0 ] - '0' ; if ( oneDigit % 8 == 0 ) return 1 ; return 0 ; }
if ( len == 2 ) {
int first = ( n [ 0 ] - '0' ) * 10 + ( n [ 1 ] - '0' ) ;
int second = ( n [ 1 ] - '0' ) * 10 + ( n [ 0 ] - '0' ) ; if ( first % 8 == 0 ) count ++ ; if ( second % 8 == 0 ) count ++ ; return count ; }
int threeDigit ; for ( int i = 0 ; i < ( len - 2 ) ; i ++ ) { threeDigit = ( n [ i ] - '0' ) * 100 + ( n [ i + 1 ] - '0' ) * 10 + ( n [ i + 2 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ; }
threeDigit = ( n [ len - 1 ] - '0' ) * 100 + ( n [ 0 ] - '0' ) * 10 + ( n [ 1 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
threeDigit = ( n [ len - 2 ] - '0' ) * 100 + ( n [ len - 1 ] - '0' ) * 10 + ( n [ 0 ] - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
return count ; }
public static void Main ( ) { String n = "43262488612" ; Console . Write ( " Rotations : ▁ " + countRotationsDivBy8 ( n ) ) ; } }
public static int minimunMoves ( string [ ] arr , int n ) { int ans = int . MaxValue ; for ( int i = 0 ; i < n ; i ++ ) { int curr_count = 0 ;
string tmp = " " ; for ( int j = 0 ; j < n ; j ++ ) { tmp = arr [ j ] + arr [ j ] ;
int index = tmp . IndexOf ( arr [ i ] , StringComparison . Ordinal ) ;
if ( index == arr [ i ] . Length ) { return - 1 ; } curr_count += index ; } ans = Math . Min ( curr_count , ans ) ; } return ans ; }
public static void Main ( string [ ] args ) { string [ ] arr = new string [ ] { " xzzwo " , " zwoxz " , " zzwox " , " xzzwo " } ; int n = arr . Length ; Console . WriteLine ( minimunMoves ( arr , n ) ) ; } }
static void restoreSortedArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] > arr [ i + 1 ] ) {
reverse ( arr , 0 , i ) ; reverse ( arr , i + 1 , n ) ; reverse ( arr , 0 , n ) ; } } } static void reverse ( int [ ] arr , int i , int j ) { int temp ; while ( i < j ) { temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; i ++ ; j -- ; } }
static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) Console . Write ( arr [ i ] + " ▁ " ) ; }
public static void Main ( String [ ] args ) { int [ ] arr = { 3 , 4 , 5 , 1 , 2 } ; int n = arr . Length ; restoreSortedArray ( arr , n - 1 ) ; printArray ( arr , n ) ; } }
static int findStartIndexOfArray ( int [ ] arr , int low , int high ) { if ( low > high ) { return - 1 ; } if ( low == high ) { return low ; } int mid = low + ( high - low ) / 2 ; if ( arr [ mid ] > arr [ mid + 1 ] ) { return mid + 1 ; } if ( arr [ mid - 1 ] > arr [ mid ] ) { return mid ; } if ( arr [ low ] > arr [ mid ] ) { return findStartIndexOfArray ( arr , low , mid - 1 ) ; } else { return findStartIndexOfArray ( arr , mid + 1 , high ) ; } }
static void restoreSortedArray ( int [ ] arr , int n ) {
if ( arr [ 0 ] < arr [ n - 1 ] ) { return ; } int start = findStartIndexOfArray ( arr , 0 , n - 1 ) ;
Array . Sort ( arr , 0 , start ) ; Array . Sort ( arr , start , n ) ; Array . Sort ( arr ) ; }
static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) { Console . Write ( arr [ i ] + " ▁ " ) ; } }
public static void Main ( ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; int n = arr . Length ; restoreSortedArray ( arr , n ) ; printArray ( arr , n ) ; } }
public class Node { public int data ; public Node next ; } ; static ;
static Node rotateHelper ( Node blockHead , Node blockTail , int d , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { Node temp = blockHead ; for ( int i = 1 ; temp . next . next != null && i < k - 1 ; i ++ ) temp = temp . next ; blockTail . next = blockHead ; tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , k ) ; }
if ( d < 0 ) { blockTail . next = blockHead ; tail = blockHead ; return rotateHelper ( blockHead . next , blockHead , d + 1 , k ) ; } return blockHead ; }
static Node rotateByBlocks ( Node head , int k , int d ) {
if ( head == null head . next == null ) return head ;
if ( d == 0 ) return head ; Node temp = head ; tail = null ;
int i ; for ( i = 1 ; temp . next != null && i < k ; i ++ ) temp = temp . next ;
Node nextBlock = temp . next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , i ) ; else head = rotateHelper ( head , temp , d % k , k ) ;
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
static Node push ( Node head_ref , int new_data ) { Node new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
static void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . next ; } }
Node head = null ;
for ( int i = 9 ; i > 0 ; i -= 1 ) head = push ( head , i ) ; Console . Write ( " Given ▁ linked ▁ list ▁ STRNEWLINE " ) ; printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; Console . Write ( " by blocks " printList ( head ) ; } }
static bool isRotation ( long x , long y ) {
long x64 = x | ( x << 32 ) ; while ( x64 >= y ) {
if ( x64 == y ) { return true ; }
x64 >>= 1 ; } return false ; }
public static void Main ( ) { long x = 122 ; long y = 2147483678L ; if ( isRotation ( x , y ) == false ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " No " ) ; } } }
static String leftrotate ( String str , int d ) { String ans = str . Substring ( d , str . Length - d ) + str . Substring ( 0 , d ) ; return ans ; }
static String rightrotate ( String str , int d ) { return leftrotate ( str , str . Length - d ) ; }
public static void Main ( String [ ] args ) { String str1 = " GeeksforGeeks " ; Console . WriteLine ( leftrotate ( str1 , 2 ) ) ; String str2 = " GeeksforGeeks " ; Console . WriteLine ( rightrotate ( str2 , 2 ) ) ; } }
static int countRotations ( String n ) { int len = n . Length ;
if ( len == 1 ) { int oneDigit = n [ 0 ] - '0' ; if ( oneDigit % 4 == 0 ) return 1 ; return 0 ; }
int twoDigit , count = 0 ; for ( int i = 0 ; i < ( len - 1 ) ; i ++ ) { twoDigit = ( n [ i ] - '0' ) * 10 + ( n [ i + 1 ] - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; }
twoDigit = ( n [ len - 1 ] - '0' ) * 10 + ( n [ 0 ] - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; return count ; }
public static void Main ( ) { String n = "4834" ; Console . Write ( " Rotations : ▁ " + countRotations ( n ) ) ; } }
public static bool isRotated ( string str1 , string str2 ) { if ( str1 . Length != str2 . Length ) { return false ; } if ( str1 . Length < 2 ) { return str1 . Equals ( str2 ) ; } string clock_rot = " " ; string anticlock_rot = " " ; int len = str2 . Length ;
anticlock_rot = anticlock_rot + str2 . Substring ( len - 2 , len - ( len - 2 ) ) + str2 . Substring ( 0 , len - 2 ) ;
clock_rot = clock_rot + str2 . Substring ( 2 ) + str2 . Substring ( 0 , 2 ) ;
return ( str1 . Equals ( clock_rot ) || str1 . Equals ( anticlock_rot ) ) ; }
public static void Main ( string [ ] args ) { string str1 = " geeks " ; string str2 = " eksge " ; Console . WriteLine ( isRotated ( str1 , str2 ) ? " Yes " : " No " ) ; } }
static String minLexRotation ( String str ) {
int n = str . Length ;
String [ ] arr = new String [ n ] ;
String concat = str + str ;
for ( int i = 0 ; i < n ; i ++ ) { arr [ i ] = concat . Substring ( i , n ) ; }
Array . Sort ( arr ) ;
return arr [ 0 ] ; }
public static void Main ( String [ ] args ) { Console . WriteLine ( minLexRotation ( " GEEKSFORGEEKS " ) ) ; Console . WriteLine ( minLexRotation ( " GEEKSQUIZ " ) ) ; Console . WriteLine ( minLexRotation ( " BCABDADAB " ) ) ; } }
public class Node { public int data ; public Node next ; } ; static Node head = null ;
static void rotate ( int k ) { if ( k == 0 ) return ;
Node current = head ;
while ( current . next != null ) current = current . next ; current . next = head ; current = head ;
for ( int i = 0 ; i < k - 1 ; i ++ ) current = current . next ;
head = current . next ; current . next = null ; }
static void push ( int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head ;
head = new_node ; }
static void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . next ; } }
for ( int i = 60 ; i > 0 ; i -= 10 ) push ( i ) ; Console . Write ( " Given ▁ linked ▁ list ▁ STRNEWLINE " ) ; printList ( head ) ; rotate ( 4 ) ; Console . Write ( " STRNEWLINE Rotated ▁ Linked ▁ list ▁ STRNEWLINE " ) ; printList ( head ) ; } }
using System ;
class Node { public int data ; public Node next ;
public Node ( int data ) { this . data = data ; this . next = null ; } } class GFG { static Node head ;
static void print ( Node head ) { Node temp = head ;
while ( temp != null ) {
Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } }
static void NextGreaterElement ( Node head ) {
Node H = head ;
Node res = null ;
Node tempList = null ;
do {
Node curr = head ;
int Val = - 1 ;
do {
if ( head . data < curr . data ) {
Val = curr . data ; break ; }
curr = curr . next ; } while ( curr != head ) ;
if ( res == null ) {
res = new Node ( Val ) ;
tempList = res ; } else {
tempList . next = new Node ( Val ) ;
tempList = tempList . next ; }
head = head . next ; } while ( head != H ) ;
print ( res ) ; }
static public void Main ( ) { head = new Node ( 1 ) ; head . next = new Node ( 5 ) ; head . next . next = new Node ( 12 ) ; head . next . next . next = new Node ( 10 ) ; head . next . next . next . next = new Node ( 0 ) ; head . next . next . next . next . next = head ; NextGreaterElement ( head ) ; } }
public class Node { public int data ; public Node next ; } ;
public class Node { public int data ; public Node next ; } ;
static void printList ( Node n ) {
while ( n != null ) {
Console . Write ( n . data + " ▁ " ) ; n = n . next ; } }
public static void Main ( String [ ] args ) { Node head = null ; Node second = null ; Node third = null ;
head = new Node ( ) ; second = new Node ( ) ; third = new Node ( ) ;
head . data = 1 ;
head . next = second ;
second . data = 2 ; second . next = third ;
third . data = 3 ; third . next = null ; printList ( head ) ; } }
public class Node { public int data ; public Node next ; } ;
static Node push ( Node head_ref , int data ) {
Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) {
while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; }
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static void deleteNode ( Node head_ref , Node del ) {
if ( head_ref == del ) head_ref = del . next ; Node temp = head_ref ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ; return ; }
static bool isEvenParity ( int x ) {
int parity = 0 ; while ( x != 0 ) { if ( ( x & 1 ) != 0 ) parity ++ ; x = x >> 1 ; } if ( parity % 2 == 0 ) return true ; else return false ; }
static void deleteEvenParityNodes ( Node head ) { if ( head == null ) return ; if ( head == head . next ) { if ( isEvenParity ( head . data ) ) head = null ; return ; } Node ptr = head ; Node next ;
do { next = ptr . next ;
if ( isEvenParity ( ptr . data ) ) deleteNode ( head , ptr ) ;
ptr = next ; } while ( ptr != head ) ; if ( head == head . next ) { if ( isEvenParity ( head . data ) ) head = null ; return ; } }
static void printList ( Node head ) { if ( head == null ) { Console . Write ( " Empty ▁ List STRNEWLINE " ) ; return ; } Node temp = head ; if ( head != null ) { do { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } while ( temp != head ) ; } }
Node head = null ;
head = push ( head , 21 ) ; head = push ( head , 13 ) ; head = push ( head , 6 ) ; head = push ( head , 34 ) ; head = push ( head , 9 ) ; head = push ( head , 11 ) ; deleteEvenParityNodes ( head ) ; printList ( head ) ; } }
class Node { public int data ; public Node next ; } ;
static Node push ( Node head_ref , int data ) {
Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) {
while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; }
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static void deleteNode ( Node head_ref , Node del ) { Node temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ;
del = null ; return ; }
static int digitSum ( int num ) { int sum = 0 ; while ( num > 0 ) { sum += ( num % 10 ) ; num /= 10 ; } return sum ; }
static void deleteEvenDigitSumNodes ( Node head ) { Node ptr = head ; Node next ;
do {
if ( ! ( digitSum ( ptr . data ) % 2 == 1 ) ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; }
static void printList ( Node head ) { Node temp = head ; if ( head != null ) { do { Console . Write ( " { 0 } ▁ " , temp . data ) ; temp = temp . next ; } while ( temp != head ) ; } }
Node head = null ;
head = push ( head , 21 ) ; head = push ( head , 13 ) ; head = push ( head , 6 ) ; head = push ( head , 34 ) ; head = push ( head , 11 ) ; head = push ( head , 9 ) ; deleteEvenDigitSumNodes ( head ) ; printList ( head ) ; } }
class Node { public int data ; public Node next ; } ;
static Node push ( Node head_ref , int data ) {
Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) {
while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; }
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static void deleteNode ( Node head_ref , Node del ) { Node temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ;
del = null ; return ; }
static int largestElement ( Node head_ref ) {
Node current ;
current = head_ref ;
int maxEle = int . MinValue ;
do {
if ( current . data > maxEle ) { maxEle = current . data ; } current = current . next ; } while ( current != head_ref ) ; return maxEle ; }
static void createHash ( HashSet < int > hash , int maxElement ) { int prev = 0 , curr = 1 ;
hash . Add ( prev ) ; hash . Add ( curr ) ;
while ( curr <= maxElement ) { int temp = curr + prev ; hash . Add ( temp ) ; prev = curr ; curr = temp ; } }
static void deleteFibonacciNodes ( Node head ) {
int maxEle = largestElement ( head ) ;
HashSet < int > hash = new HashSet < int > ( ) ; createHash ( hash , maxEle ) ; Node ptr = head ; Node next ;
do {
if ( hash . Contains ( ptr . data ) ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; }
static void printList ( Node head ) { Node temp = head ; if ( head != null ) { do { Console . Write ( " { 0 } ▁ " , temp . data ) ; temp = temp . next ; } while ( temp != head ) ; } }
Node head = null ;
head = push ( head , 20 ) ; head = push ( head , 13 ) ; head = push ( head , 6 ) ; head = push ( head , 34 ) ; head = push ( head , 11 ) ; head = push ( head , 9 ) ; deleteFibonacciNodes ( head ) ; printList ( head ) ; } }
public class Node { public int data ; public Node next ; } ;
static Node push ( Node head_ref , int data ) { Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) { while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; return head_ref ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static Node deleteNode ( Node head_ref , Node del ) { Node temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ; return head_ref ; }
static Node deleteoddNodes ( Node head ) { Node ptr = head ; Node next ;
do {
if ( ptr . data % 2 == 1 ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; return head ; }
static void printList ( Node head ) { Node temp = head ; if ( head != null ) { do { Console . Write ( " { 0 } ▁ " , temp . data ) ; temp = temp . next ; } while ( temp != head ) ; } }
Node head = null ;
head = push ( head , 2 ) ; head = push ( head , 12 ) ; head = push ( head , 11 ) ; head = push ( head , 57 ) ; head = push ( head , 61 ) ; head = push ( head , 56 ) ; Console . WriteLine ( " STRNEWLINE List ▁ after ▁ deletion ▁ : ▁ " ) ; head = deleteoddNodes ( head ) ; printList ( head ) ; } }
public class Node { public Node next ; public int data ; } ;
static Node create ( ) { Node new_node = new Node ( ) ; new_node . next = null ; return new_node ; }
static Node find_head ( Node random ) {
if ( random == null ) return null ; Node var = random ;
while ( ! ( var . data > var . next . data var . next == random ) ) { var = var . ; }
return var . next ; }
static Node sortedInsert ( Node head_ref , Node new_node ) { Node current = head_ref ;
if ( current == null ) { new_node . next = new_node ; head_ref = new_node ; }
else if ( current . data >= new_node . data ) {
while ( current . next != head_ref ) current = current . next ; current . next = new_node ; new_node . next = head_ref ; head_ref = new_node ; } else {
while ( current . next != head_ref && current . next . data < new_node . data ) { current = current . next ; } new_node . next = current . next ; current . next = new_node ; }
return head_ref ; }
static void printList ( Node start ) { Node temp ; if ( start != null ) { temp = start ; do { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } while ( temp != start ) ; } }
public static void Main ( String [ ] args ) { int [ ] arr = { 12 , 56 , 2 , 11 , 1 , 90 } ; int i ;
Node start = null ; Node temp ;
for ( i = 0 ; i < 6 ; i ++ ) {
if ( start != null ) for ( int j = 0 ; j < ( new Random ( ) . Next ( ) * 10 ) ; j ++ ) start = start . next ; temp = create ( ) ; temp . data = arr [ i ] ; start = sortedInsert ( find_head ( start ) , temp ) ; }
printList ( find_head ( start ) ) ; } }
using System ; public class CircularLinkedList { public Node last ; public class Node { public int data ; public Node next ; } ;
public Node addToEmpty ( int data ) {
if ( this . last != null ) return this . last ;
Node temp = new Node ( ) ;
temp . data = data ; this . last = temp ;
this . last . next = this . last ; return last ; }
public Node addBegin ( int data ) {
if ( last == null ) return addToEmpty ( data ) ;
Node temp = new Node ( ) ;
temp . data = data ; temp . next = this . last . next ; this . last . next = temp ; return this . last ; }
public void traverse ( ) { Node p ;
if ( this . last == null ) { Console . WriteLine ( " List ▁ is ▁ empty . " ) ; return ; }
p = this . last . next ;
do { Console . Write ( p . data + " ▁ " ) ; p = p . next ; } while ( p != this . last . next ) ; Console . WriteLine ( " " ) ; }
public int length ( ) {
int x = 0 ;
if ( this . last == null ) return x ;
Node itr = this . last . next ; while ( itr . next != this . last . next ) { x ++ ; itr = itr . next ; }
return ( x + 1 ) ; }
public Node split ( int k ) {
Node pass = new Node ( ) ;
if ( this . last == null ) return this . last ;
Node newLast , itr = this . last ; for ( int i = 0 ; i < k ; i ++ ) { itr = itr . next ; }
newLast = itr ; pass . next = itr . next ; newLast . next = this . last . next ; this . last . next = pass . next ;
return newLast ; }
public static void Main ( String [ ] args ) { CircularLinkedList clist = new CircularLinkedList ( ) ; clist . last = null ; clist . addToEmpty ( 12 ) ; clist . addBegin ( 10 ) ; clist . addBegin ( 8 ) ; clist . addBegin ( 6 ) ; clist . addBegin ( 4 ) ; clist . addBegin ( 2 ) ; Console . WriteLine ( " Original ▁ list : " ) ; clist . traverse ( ) ; int k = 4 ;
clist2 . last = clist . split ( k ) ;
Console . WriteLine ( " The ▁ new ▁ lists ▁ are : " ) ; clist2 . traverse ( ) ; clist . traverse ( ) ; } }
public class Node { public int data ; public Node left ; public Node right ; public Node ( int x ) { data = x ; left = right = null ; } } ;
static void inorder ( Node root , List < int > v ) { if ( root == null ) return ;
inorder ( root . left , v ) ;
v . Add ( root . data ) ;
inorder ( root . right , v ) ; }
static Node bTreeToCList ( Node root ) {
if ( root == null ) return null ;
List < int > v = new List < int > ( ) ;
inorder ( root , v ) ;
Node head_ref = new Node ( v [ 0 ] ) ;
Node curr = head_ref ;
for ( int i = 1 ; i < v . Count ; i ++ ) {
Node temp = curr ;
curr . right = new Node ( v [ i ] ) ;
curr = curr . right ;
curr . left = temp ; }
curr . right = head_ref ;
head_ref . left = curr ;
return head_ref ; }
static void displayCList ( Node head ) { Console . WriteLine ( " Circular ▁ Doubly ▁ " + " Linked ▁ List ▁ is ▁ : " ) ; Node itr = head ; do { Console . Write ( itr . data + " ▁ " ) ; itr = itr . right ; } while ( head != itr ) ; Console . WriteLine ( ) ; }
public static void Main ( String [ ] args ) { Node root = new Node ( 10 ) ; root . left = new Node ( 12 ) ; root . right = new Node ( 15 ) ; root . left . left = new Node ( 25 ) ; root . left . right = new Node ( 30 ) ; root . right . left = new Node ( 36 ) ; Node head = bTreeToCList ( root ) ; displayCList ( head ) ; } }
static Node DeleteAllEvenNode ( Node head ) {
int len = Length ( head ) ; int count = 1 ; Node previous = head , next = head ;
if ( head == null ) { Console . Write ( " List is " return null ; }
if ( len < 2 ) { return null ; }
previous = head ;
next = previous . next ; while ( len > 0 ) {
if ( count % 2 == 0 ) { previous . next = next . next ; previous = next . next ; next = previous . next ; } len -- ; count ++ ; } return head ; }
class Node { public int data ; public Node next ; } ;
static int Length ( Node head ) { Node current = head ; int count = 0 ;
if ( head == null ) { return 0 ; }
else { do { current = current . next ; count ++ ; } while ( current != head ) ; } return count ; }
static void Display ( Node head ) { Node current = head ;
if ( head == null ) { Console . Write ( " STRNEWLINE Display ▁ List ▁ is ▁ empty STRNEWLINE " ) ; return ; }
else { do { Console . Write ( " { 0 } ▁ " , current . data ) ; current = current . next ; } while ( current != head ) ; } }
static Node Insert ( Node head , int data ) { Node current = head ;
Node newNode = new Node ( ) ;
if ( newNode == null ) { Console . Write ( " STRNEWLINE Memory ▁ Error STRNEWLINE " ) ; return null ; }
newNode . data = data ;
if ( head == null ) { newNode . next = newNode ; head = newNode ; return head ; }
else {
while ( current . next != head ) { current = current . next ; }
newNode . next = head ;
current . next = newNode ; } return head ; }
static Node deleteNode ( Node head_ref , Node del ) { Node temp = head_ref ;
if ( head_ref == del ) { head_ref = del . next ; }
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ; return head_ref ; }
static Node DeleteFirst ( Node head ) { Node previous = head , next = head ;
if ( head == null ) { Console . Write ( " List is " return head ; }
if ( previous . next == previous ) { head = null ; return head ; }
while ( previous . next != head ) { previous = previous . next ; next = previous . next ; }
previous . next = next . next ;
head = previous . next ; return head ; }
static Node DeleteAllOddNode ( Node head ) { int len = Length ( head ) ; int count = 0 ; Node previous = head , next = head ;
if ( head == null ) { Console . Write ( " STRNEWLINE Delete ▁ Last ▁ List ▁ is ▁ empty STRNEWLINE " ) ; return null ; }
if ( len == 1 ) { head = DeleteFirst ( head ) ; return head ; }
while ( len > 0 ) {
if ( count == 0 ) {
head = DeleteFirst ( head ) ; }
if ( count % 2 == 0 && count != 0 ) { head = deleteNode ( head , previous ) ; } previous = previous . next ; next = previous . next ; len -- ; count ++ ; } return head ; }
static Node DeleteAllEvenNode ( Node head ) {
int len = Length ( head ) ; int count = 1 ; Node previous = head , next = head ;
if ( head == null ) { Console . Write ( " List is " return null ; }
if ( len < 2 ) { return null ; }
previous = head ;
next = previous . next ; while ( len > 0 ) {
if ( count % 2 == 0 ) { previous . next = next . next ; previous = next . next ; next = previous . next ; } len -- ; count ++ ; } return head ; }
public static void Main ( String [ ] args ) { Node head = null ; head = Insert ( head , 99 ) ; head = Insert ( head , 11 ) ; head = Insert ( head , 22 ) ; head = Insert ( head , 33 ) ; head = Insert ( head , 44 ) ; head = Insert ( head , 55 ) ; head = Insert ( head , 66 ) ;
Console . Write ( " Initial ▁ List : ▁ " ) ; Display ( head ) ; Console . Write ( " STRNEWLINE After ▁ deleting ▁ Odd ▁ position ▁ nodes : ▁ " ) ; head = DeleteAllOddNode ( head ) ; Display ( head ) ;
Console . Write ( " STRNEWLINE STRNEWLINE Initial ▁ List : ▁ " ) ; Display ( head ) ; Console . Write ( " nodes : " head = DeleteAllEvenNode ( head ) ; Display ( head ) ; } }
public class Node { public int data ; public Node next ; } ;
static void printMinMax ( Node head ) {
if ( head == null ) { return ; }
Node current ;
current = head ;
int min = int . MaxValue , max = int . MinValue ;
while ( current . next != head ) {
if ( current . data < min ) { min = current . data ; }
if ( current . data > max ) { max = current . data ; } current = current . next ; } Console . WriteLine ( " Minimum = " ▁ + ▁ min ▁ + ▁ " , Maximum = " }
static Node insertNode ( Node head , int data ) { Node current = head ;
Node newNode = new Node ( ) ;
if ( newNode == null ) { Console . Write ( " STRNEWLINE Memory ▁ Error STRNEWLINE " ) ; return null ; }
newNode . data = data ;
if ( head == null ) { newNode . next = newNode ; head = newNode ; return head ; }
else {
while ( current . next != head ) { current = current . next ; }
newNode . next = head ;
current . next = newNode ; } return head ; }
static void displayList ( Node head ) { Node current = head ;
if ( head == null ) { Console . Write ( " STRNEWLINE Display ▁ List ▁ is ▁ empty STRNEWLINE " ) ; return ; }
else { do { Console . Write ( " { 0 } ▁ " , current . data ) ; current = current . next ; } while ( current != head ) ; } }
public static void Main ( ) { Node Head = null ; Head = insertNode ( Head , 99 ) ; Head = insertNode ( Head , 11 ) ; Head = insertNode ( Head , 22 ) ; Head = insertNode ( Head , 33 ) ; Head = insertNode ( Head , 44 ) ; Head = insertNode ( Head , 55 ) ; Head = insertNode ( Head , 66 ) ; Console . WriteLine ( " Initial ▁ List : ▁ " ) ; displayList ( Head ) ; printMinMax ( Head ) ; } }
public class Node { public int data ; public Node next ; } ;
static Node push ( Node head_ref , int data ) { Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) { while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; return head_ref ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static Node deleteNode ( Node head_ref , Node del ) { Node temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ; return head_ref ; }
static Node deleteEvenNodes ( Node head ) { Node ptr = head ; Node next ;
do {
if ( ptr . data % 2 == 0 ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; return head ; }
static void printList ( Node head ) { Node temp = head ; if ( head != null ) { do { Console . Write ( " { 0 } ▁ " , temp . data ) ; temp = temp . next ; } while ( temp != head ) ; } }
Node head = null ;
head = push ( head , 61 ) ; head = push ( head , 12 ) ; head = push ( head , 56 ) ; head = push ( head , 2 ) ; head = push ( head , 11 ) ; head = push ( head , 57 ) ; Console . WriteLine ( " STRNEWLINE List ▁ after ▁ deletion ▁ : ▁ " ) ; head = deleteEvenNodes ( head ) ; printList ( head ) ; } }
class Node { public int data ; public Node next ; } ;
static Node push ( Node head_ref , int data ) { Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) { while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static int sumOfList ( Node head ) { Node temp = head ; int sum = 0 ; if ( head != null ) { do { temp = temp . next ; sum += temp . data ; } while ( temp != head ) ; } return sum ; }
Node head = null ;
head = push ( head , 12 ) ; head = push ( head , 56 ) ; head = push ( head , 2 ) ; head = push ( head , 11 ) ; Console . WriteLine ( " Sum ▁ of ▁ Circular ▁ linked " + " ▁ list ▁ is ▁ = ▁ " + sumOfList ( head ) ) ; } }
public class Node { public int data ; public Node next ; public Node ( int x ) { data = x ; next = null ; } } ;
static void printList ( Node head ) { if ( head == null ) return ; Node temp = head ; do { Console . Write ( temp . data + " - > " ) ; temp = temp . next ; } while ( temp != head ) ; Console . WriteLine ( head . data ) ; }
static Node deleteK ( Node head_ref , int k ) { Node head = head_ref ;
if ( head == null ) return null ;
Node curr = head , prev = null ; while ( true ) {
if ( curr . next == head && curr == head ) break ;
printList ( head ) ;
for ( int i = 0 ; i < k ; i ++ ) { prev = curr ; curr = curr . next ; }
if ( curr == head ) { prev = head ; while ( prev . next != head ) prev = prev . next ; head = curr . next ; prev . next = head ; head_ref = head ; }
else if ( curr . next == head ) { prev . next = head ; } else { prev . next = curr . next ; } } return head ; }
static Node insertNode ( Node head_ref , int x ) {
Node head = head_ref ; Node temp = new Node ( x ) ;
if ( head == null ) { temp . next = temp ; head_ref = temp ; return head_ref ; }
else { Node temp1 = head ; while ( temp1 . next != head ) temp1 = temp1 . next ; temp1 . next = temp ; temp . next = head ; } return head ; }
Node head = null ; head = insertNode ( head , 1 ) ; head = insertNode ( head , 2 ) ; head = insertNode ( head , 3 ) ; head = insertNode ( head , 4 ) ; head = insertNode ( head , 5 ) ; head = insertNode ( head , 6 ) ; head = insertNode ( head , 7 ) ; head = insertNode ( head , 8 ) ; head = insertNode ( head , 9 ) ; int k = 4 ;
head = deleteK ( head , k ) ; } }
public class Node { public int data ; public Node next ; public Node prev ; } ;
static Node insertNode ( Node start , int value ) {
Node new_node = new Node ( ) ; if ( start == null ) { new_node . data = value ; new_node . next = new_node . prev = new_node ; start = new_node ; return new_node ; }
Node last = ( start ) . prev ;
new_node = new Node ( ) ; new_node . data = value ;
new_node . next = start ;
( start ) . prev = new_node ;
new_node . prev = last ;
last . next = new_node ; return start ; }
static void displayList ( Node start ) { Node temp = start ; while ( temp . next != start ) { Console . Write ( " { 0 } ▁ " , temp . data ) ; temp = temp . next ; } Console . Write ( " { 0 } ▁ " , temp . data ) ; }
static int searchList ( Node start , int search ) {
Node temp = start ;
int count = 0 , flag = 0 , value ;
if ( temp == null ) return - 1 ; else {
while ( temp . next != start ) {
count ++ ;
if ( temp . data == search ) { flag = 1 ; count -- ; break ; }
temp = temp . next ; }
if ( temp . data == search ) { count ++ ; flag = 1 ; }
if ( flag == 1 ) Console . WriteLine ( " STRNEWLINE " + search + " ▁ found ▁ at ▁ location ▁ " + count ) ; else Console . WriteLine ( " STRNEWLINE " + search + " ▁ not ▁ found " ) ; } return - 1 ; }
Node start = null ;
start = insertNode ( start , 4 ) ;
start = insertNode ( start , 5 ) ;
start = insertNode ( start , 7 ) ;
start = insertNode ( start , 8 ) ;
start = insertNode ( start , 6 ) ; Console . Write ( " Created ▁ circular ▁ doubly ▁ linked ▁ list ▁ is : ▁ " ) ; displayList ( start ) ; searchList ( start , 5 ) ; } }
public class node { public int data ; public node next ; public node prev ; } ;
static node getNode ( ) { return new node ( ) ; }
static int displayList ( node temp ) { node t = temp ; if ( temp == null ) return 0 ; else { Console . WriteLine ( " The ▁ list ▁ is : ▁ " ) ; while ( temp . next != t ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } Console . WriteLine ( temp . data ) ; return 1 ; } }
static int countList ( node start ) {
node temp = start ;
int count = 0 ;
while ( temp . next != start ) { temp = temp . next ; count ++ ; }
count ++ ; return count ; }
static node insertAtLocation ( node start , int data , int loc ) {
node temp , newNode ; int i , count ;
newNode = getNode ( ) ;
temp = start ;
count = countList ( start ) ;
if ( temp == null count < loc ) return start ; else {
newNode . data = data ;
for ( i = 1 ; i < loc - 1 ; i ++ ) { temp = temp . next ; }
newNode . next = temp . next ;
( temp . next ) . prev = newNode ;
temp . next = newNode ;
newNode . prev = temp ; return start ; } }
static node createList ( int [ ] arr , int n , node start ) {
node newNode , temp ; int i ;
for ( i = 0 ; i < n ; i ++ ) {
newNode = getNode ( ) ;
newNode . data = arr [ i ] ;
if ( i == 0 ) { start = newNode ; newNode . prev = start ; newNode . next = start ; } else {
temp = ( start ) . prev ;
temp . next = newNode ; newNode . next = start ; newNode . prev = temp ; temp = start ; temp . prev = newNode ; } } return start ; }
int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 6 } ; int n = arr . Length ;
node start = null ;
start = createList ( arr , n , start ) ;
displayList ( start ) ;
start = insertAtLocation ( start , 8 , 3 ) ;
displayList ( start ) ; } }
public class Node { public int data ; public Node next , prev ; } ;
static Node getNode ( int data ) { Node newNode = new Node ( ) ; newNode . data = data ; return newNode ; }
static Node insertEnd ( Node head , Node new_node ) {
if ( head == null ) { new_node . next = new_node . prev = new_node ; head = new_node ; return head ; }
Node last = ( head ) . prev ;
new_node . next = head ;
( head ) . prev = new_node ;
new_node . prev = last ;
last . next = new_node ; return head ; }
static Node reverse ( Node head ) { if ( head == null ) return null ;
Node new_head = null ;
Node last = head . prev ;
Node curr = last , prev ;
while ( curr . prev != last ) { prev = curr . prev ;
new_head = insertEnd ( new_head , curr ) ; curr = prev ; } new_head = insertEnd ( new_head , curr ) ;
return new_head ; }
static void display ( Node head ) { if ( head == null ) return ; Node temp = head ; Console . Write ( " Forward ▁ direction : ▁ " ) ; while ( temp . next != head ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } Console . Write ( temp . data + " ▁ " ) ; Node last = head . prev ; temp = last ; Console . Write ( " STRNEWLINE Backward ▁ direction : ▁ " ) ; while ( temp . prev != last ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . prev ; } Console . Write ( temp . data + " ▁ " ) ; }
public static void Main ( String [ ] args ) { Node head = null ; head = insertEnd ( head , getNode ( 1 ) ) ; head = insertEnd ( head , getNode ( 2 ) ) ; head = insertEnd ( head , getNode ( 3 ) ) ; head = insertEnd ( head , getNode ( 4 ) ) ; head = insertEnd ( head , getNode ( 5 ) ) ; Console . Write ( " Current ▁ list : STRNEWLINE " ) ; display ( head ) ; head = reverse ( head ) ; Console . Write ( " STRNEWLINE STRNEWLINE Reversed ▁ list : STRNEWLINE " ) ; display ( head ) ; } }
public class node { public int data ; public node next ; public node prev ; } ;
static node getNode ( ) { return new node ( ) ; }
static int displayList ( node temp ) { node t = temp ; if ( temp == null ) return 0 ; else { Console . Write ( " The ▁ list ▁ is : ▁ " ) ; while ( temp . next != t ) { Console . Write ( temp . data + " ▁ " ) ; temp = temp . next ; } Console . Write ( temp . data ) ; return 1 ; } }
static node createList ( int [ ] arr , int n , node start ) {
node newNode , temp ; int i ;
for ( i = 0 ; i < n ; i ++ ) {
newNode = getNode ( ) ;
newNode . data = arr [ i ] ;
if ( i == 0 ) { start = newNode ; newNode . prev = start ; newNode . next = start ; } else {
temp = ( start ) . prev ;
temp . next = newNode ; newNode . next = start ; newNode . prev = temp ; temp = start ; temp . prev = newNode ; } } return start ; }
int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; int n = arr . Length ;
node start = null ;
start = createList ( arr , n , start ) ;
displayList ( start ) ; } }
public class Node { public int data ; public Node next ; } ; static Node newNode ( int data ) { Node node = new Node ( ) ; node . data = data ; node . next = null ; return node ; }
static int alivesol ( int Num ) { if ( Num == 1 ) return 1 ;
Node last = newNode ( 1 ) ; last . next = last ; for ( int i = 2 ; i <= Num ; i ++ ) { Node tem = newNode ( i ) ; tem . next = last . next ; last . next = tem ; last = tem ; }
Node curr = last . next ;
Node tem1 = new Node ( ) ; while ( curr . next != curr ) { tem1 = curr ; curr = curr . next ; tem1 . next = curr . next ;
tem1 = tem1 . next ; curr = tem1 ; }
int res = tem1 . data ; return res ; }
public static void Main ( String [ ] args ) { int N = 100 ; Console . WriteLine ( alivesol ( N ) ) ; } }
class Node { public Node left = null ; public Node right = null ; public int data ; public Node ( int data ) { this . data = data ; } } public class GFG {
static int findDepth ( Node root ) {
if ( root == null ) return 0 ;
int left = findDepth ( root . left ) ;
int right = findDepth ( root . right ) ;
return 1 + Math . Max ( left , right ) ; }
static Node DFS ( Node root , int curr , int depth ) {
if ( root == null ) return null ;
if ( curr == depth ) return root ;
Node left = DFS ( root . left , curr + 1 , depth ) ;
Node right = DFS ( root . right , curr + 1 , depth ) ;
if ( left != null && right != null ) return root ;
return ( left != null ) ? left : right ; }
static Node lcaOfDeepestLeaves ( Node root ) {
if ( root == null ) return null ;
int depth = findDepth ( root ) - 1 ;
return DFS ( root , 0 , depth ) ; }
Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; root . right . left . left = new Node ( 8 ) ; root . right . left . right = new Node ( 9 ) ; Console . WriteLine ( lcaOfDeepestLeaves ( root ) . data ) ; } }
static int filter ( int x , int y , int z ) { if ( x != - 1 && y != - 1 ) { return z ; } return x == - 1 ? y : x ; }
static int samePathUtil ( int [ , ] mtrx , int vrtx , int v1 , int v2 , int i ) { int ans = - 1 ;
if ( i == v1 i == v2 ) return i ; for ( int j = 0 ; j < vrtx ; j ++ ) {
if ( mtrx [ i , j ] == 1 ) {
ans = filter ( ans , samePathUtil ( mtrx , vrtx , v1 , v2 , j ) , i ) ; } }
return ans ; }
static bool isVertexAtSamePath ( int [ , ] mtrx , int vrtx , int v1 , int v2 , int i ) { int lca = samePathUtil ( mtrx , vrtx , v1 - 1 , v2 - 1 , i ) ; if ( lca == v1 - 1 lca == v2 - 1 ) return true ; return false ; }
public static void Main ( String [ ] args ) { int vrtx = 7 ; int [ , ] mtrx = { { 0 , 1 , 1 , 1 , 0 , 0 , 0 } , { 0 , 0 , 0 , 0 , 1 , 0 , 0 } , { 0 , 0 , 0 , 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 } } ; int v1 = 1 , v2 = 5 ; if ( isVertexAtSamePath ( mtrx , vrtx , v1 , v2 , 0 ) ) Console . Write ( " Yes " ) ; else Console . Write ( " No " ) ; } }
using System ; using System . Collections . Generic ; class GFG { static readonly int MAX = 1000 ;
static readonly int log = 10 ;
static int [ ] level = new int [ MAX ] ; static int [ , ] lca = new int [ MAX , log ] ; static int [ , ] dist = new int [ MAX , log ] ;
static List < List < int [ ] > > graph = new List < List < int [ ] > > ( ) ; static void addEdge ( int u , int v , int cost ) { graph [ u ] . Add ( new int [ ] { v , cost } ) ; graph [ v ] . Add ( new int [ ] { u , cost } ) ; }
static void dfs ( int node , int parent , int h , int cost ) {
lca [ node , 0 ] = parent ;
level [ node ] = h ; if ( parent != - 1 ) { dist [ node , 0 ] = cost ; } for ( int i = 1 ; i < log ; i ++ ) { if ( lca [ node , i - 1 ] != - 1 ) {
lca [ node , i ] = lca [ lca [ node , i - 1 ] , i - 1 ] ; dist [ node , i ] = dist [ node , i - 1 ] + dist [ lca [ node , i - 1 ] , i - 1 ] ; } } foreach ( int [ ] i in graph [ node ] ) { if ( i [ 0 ] == parent ) continue ; dfs ( i [ 0 ] , node , h + 1 , i [ 1 ] ) ; } }
static void findDistance ( int u , int v ) { int ans = 0 ;
if ( level [ u ] > level [ v ] ) { int temp = u ; u = v ; v = temp ; }
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v , i ] != - 1 && level [ lca [ v , i ] ] >= level [ u ] ) {
ans += dist [ v , i ] ; v = lca [ v , i ] ; } }
if ( v == u ) { Console . WriteLine ( ans ) ; } else {
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v , i ] != lca [ u , i ] ) {
ans += dist [ u , i ] + dist [ v , i ] ; v = lca [ v , i ] ; u = lca [ u , i ] ; } }
ans += dist [ u , 0 ] + dist [ v , 0 ] ; Console . WriteLine ( ans ) ; } }
int n = 5 ; for ( int i = 0 ; i < MAX ; i ++ ) { graph . Add ( new List < int [ ] > ( ) ) ; }
addEdge ( 1 , 2 , 2 ) ; addEdge ( 1 , 3 , 3 ) ; addEdge ( 2 , 4 , 5 ) ; addEdge ( 2 , 5 , 7 ) ;
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = 0 ; j < log ; j ++ ) { lca [ i , j ] = - 1 ; dist [ i , j ] = 0 ; } }
dfs ( 1 , - 1 , 0 , 0 ) ;
findDistance ( 1 , 3 ) ;
findDistance ( 2 , 3 ) ;
findDistance ( 3 , 5 ) ; } }
using System ; using System . Collections . Generic ; class GFG { static readonly int MAX = 1000 ; static int [ ] weight = new int [ MAX ] ; static int [ ] level = new int [ MAX ] ; static int [ ] par = new int [ MAX ] ; static bool [ ] prime = new bool [ MAX + 1 ] ; static List < int > [ ] graph = new List < int > [ MAX ] ;
static void SieveOfEratosthenes ( ) {
for ( int i = 0 ; i < prime . Length ; i ++ ) prime [ i ] = true ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * p ; i <= MAX ; i += p ) prime [ i ] = false ; } } }
static void dfs ( int node , int parent , int h ) {
par [ node ] = parent ;
level [ node ] = h ; foreach ( int child in graph [ node ] ) { if ( child == parent ) continue ; dfs ( child , node , h + 1 ) ; } }
static int findPrimeOnPath ( int u , int v ) { int count = 0 ;
if ( level [ u ] > level [ v ] ) { int temp = v ; v = u ; u = temp ; } int d = level [ v ] - level [ u ] ;
while ( d -- > 0 ) {
if ( prime [ weight [ v ] ] ) count ++ ; v = par [ v ] ; }
if ( v == u ) { if ( prime [ weight [ v ] ] ) count ++ ; return count ; }
while ( v != u ) { if ( prime [ weight [ v ] ] ) count ++ ; if ( prime [ weight [ u ] ] ) count ++ ; u = par [ u ] ; v = par [ v ] ; }
if ( prime [ weight [ v ] ] ) count ++ ; return count ; }
SieveOfEratosthenes ( ) ;
weight [ 1 ] = 5 ; weight [ 2 ] = 10 ; weight [ 3 ] = 11 ; weight [ 4 ] = 8 ; weight [ 5 ] = 6 ;
graph [ 1 ] . Add ( 2 ) ; graph [ 2 ] . Add ( 3 ) ; graph [ 2 ] . Add ( 4 ) ; graph [ 1 ] . Add ( 5 ) ; dfs ( 1 , - 1 , 0 ) ; int u = 3 , v = 5 ; Console . Write ( findPrimeOnPath ( u , v ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static readonly int MAX = 1000 ;
static readonly int log = 10 ;
static int [ ] level = new int [ MAX ] ; static int [ , ] lca = new int [ MAX , log ] ; static int [ , ] minWeight = new int [ MAX , log ] ; static int [ , ] maxWeight = new int [ MAX , log ] ;
static List < int > [ ] graph = new List < int > [ MAX ] ;
static int [ ] weight = new int [ MAX ] ; private static void swap ( int x , int y ) { int temp = x ; x = y ; y = temp ; } static void addEdge ( int u , int v ) { graph [ u ] . Add ( v ) ; graph [ v ] . Add ( u ) ; }
static void dfs ( int node , int parent , int h ) {
lca [ node , 0 ] = parent ;
level [ node ] = h ; if ( parent != - 1 ) { minWeight [ node , 0 ] = Math . Min ( weight [ node ] , weight [ parent ] ) ; maxWeight [ node , 0 ] = Math . Max ( weight [ node ] , weight [ parent ] ) ; } for ( int i = 1 ; i < log ; i ++ ) { if ( lca [ node , i - 1 ] != - 1 ) {
lca [ node , i ] = lca [ lca [ node , i - 1 ] , i - 1 ] ; minWeight [ node , i ] = Math . Min ( minWeight [ node , i - 1 ] , minWeight [ lca [ node , i - 1 ] , i - 1 ] ) ; maxWeight [ node , i ] = Math . Max ( maxWeight [ node , i - 1 ] , maxWeight [ lca [ node , i - 1 ] , i - 1 ] ) ; } } foreach ( int i in graph [ node ] ) { if ( i == parent ) continue ; dfs ( i , node , h + 1 ) ; } }
static void findMinMaxWeight ( int u , int v ) { int minWei = int . MaxValue ; int maxWei = int . MinValue ;
if ( level [ u ] > level [ v ] ) swap ( u , v ) ;
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v , i ] != - 1 && level [ lca [ v , i ] ] >= level [ u ] ) {
minWei = Math . Min ( minWei , minWeight [ v , i ] ) ; maxWei = Math . Max ( maxWei , maxWeight [ v , i ] ) ; v = lca [ v , i ] ; } }
if ( v == u ) { Console . Write ( minWei + " ▁ " + maxWei + " STRNEWLINE " ) ; } else {
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( v == - 1 ) v ++ ; if ( lca [ v , i ] != lca [ u , i ] ) {
minWei = Math . Min ( minWei , Math . Min ( minWeight [ v , i ] , minWeight [ u , i ] ) ) ;
maxWei = Math . Max ( maxWei , Math . Max ( maxWeight [ v , i ] , maxWeight [ u , i ] ) ) ; v = lca [ v , i ] ; u = lca [ u , i ] ; } }
if ( u == - 1 ) u ++ ; minWei = Math . Min ( minWei , Math . Min ( minWeight [ v , 0 ] , minWeight [ u , 0 ] ) ) ;
maxWei = Math . Max ( maxWei , Math . Max ( maxWeight [ v , 0 ] , maxWeight [ u , 0 ] ) ) ; Console . Write ( minWei + " ▁ " + maxWei + " STRNEWLINE " ) ; } }
int n = 5 ; for ( int i = 0 ; i < graph . Length ; i ++ ) graph [ i ] = new List < int > ( ) ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 5 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 3 ) ; weight [ 1 ] = - 1 ; weight [ 2 ] = 5 ; weight [ 3 ] = - 1 ; weight [ 4 ] = 3 ; weight [ 5 ] = - 2 ;
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = 0 ; j < log ; j ++ ) { lca [ i , j ] = - 1 ; minWeight [ i , j ] = int . MaxValue ; maxWeight [ i , j ] = int . MinValue ; } }
dfs ( 1 , - 1 , 0 ) ;
findMinMaxWeight ( 1 , 3 ) ;
findMinMaxWeight ( 2 , 4 ) ;
findMinMaxWeight ( 3 , 5 ) ; } }
static int T = 1 ; static void dfs ( int node , int parent , List < int > [ ] g , int [ ] level , int [ ] t_in , int [ ] t_out ) {
if ( parent == - 1 ) { level [ node ] = 1 ; } else { level [ node ] = level [ parent ] + 1 ; }
t_in [ node ] = T ; foreach ( int i in g [ node ] ) { if ( i != parent ) { T ++ ; dfs ( i , node , g , level , t_in , t_out ) ; } } T ++ ;
t_out [ node ] = T ; } static int findLCA ( int n , List < int > [ ] g , List < int > v ) {
int [ ] level = new int [ n + 1 ] ;
int [ ] t_in = new int [ n + 1 ] ;
int [ ] t_out = new int [ n + 1 ] ;
dfs ( 1 , - 1 , g , level , t_in , t_out ) ; int mint = int . MaxValue , maxt = int . MinValue ; int minv = - 1 , maxv = - 1 ; for ( int i = 0 ; i < v . Count ; i ++ ) {
if ( t_in [ v [ i ] ] < mint ) { mint = t_in [ v [ i ] ] ; minv = v [ i ] ; }
if ( t_out [ v [ i ] ] > maxt ) { maxt = t_out [ v [ i ] ] ; maxv = v [ i ] ; } }
if ( minv == maxv ) { return minv ; }
int lev = Math . Min ( level [ minv ] , level [ maxv ] ) ; int node = 0 , l = int . MinValue ; for ( int i = 1 ; i <= n ; i ++ ) {
if ( level [ i ] > lev ) continue ;
if ( t_in [ i ] <= mint && t_out [ i ] >= maxt && level [ i ] > l ) { node = i ; l = level [ i ] ; } } return node ; }
public static void Main ( String [ ] args ) { int n = 10 ; List < int > [ ] g = new List < int > [ n + 1 ] ; for ( int i = 0 ; i < g . Length ; i ++ ) g [ i ] = new List < int > ( ) ; g [ 1 ] . Add ( 2 ) ; g [ 2 ] . Add ( 1 ) ; g [ 1 ] . Add ( 3 ) ; g [ 3 ] . Add ( 1 ) ; g [ 1 ] . Add ( 4 ) ; g [ 4 ] . Add ( 1 ) ; g [ 2 ] . Add ( 5 ) ; g [ 5 ] . Add ( 2 ) ; g [ 2 ] . Add ( 6 ) ; g [ 6 ] . Add ( 2 ) ; g [ 3 ] . Add ( 7 ) ; g [ 7 ] . Add ( 3 ) ; g [ 4 ] . Add ( 10 ) ; g [ 10 ] . Add ( 4 ) ; g [ 8 ] . Add ( 7 ) ; g [ 7 ] . Add ( 8 ) ; g [ 9 ] . Add ( 7 ) ; g [ 7 ] . Add ( 9 ) ; List < int > v = new List < int > ( ) ; v . Add ( 7 ) ; v . Add ( 3 ) ; v . Add ( 8 ) ; Console . Write ( findLCA ( n , g , v ) + " STRNEWLINE " ) ; } }
using System ; using System . Collections . Generic ; class GFG { static int MAX_SIZE = 100005 , MAX_CHAR = 26 ; static int [ , ] nodecharsCount = new int [ MAX_SIZE , MAX_CHAR ] ; static List < int > [ ] tree = new List < int > [ MAX_SIZE ] ;
static bool canFormPalindrome ( int [ ] charArray ) {
int oddCount = 0 ; for ( int i = 0 ; i < MAX_CHAR ; i ++ ) { if ( charArray [ i ] % 2 == 1 ) oddCount ++ ; }
if ( oddCount >= 2 ) return false ; else return true ; }
static int LCA ( int currentNode , int x , int y ) {
if ( currentNode == x ) return x ;
if ( currentNode == y ) return y ; int xLca , yLca ;
xLca = yLca = - 1 ;
int gotLca = - 1 ;
for ( int l = 0 ; l < tree [ currentNode ] . Count ; l ++ ) {
int nextNode = tree [ currentNode ] [ l ] ;
int out_ = LCA ( nextNode , x , y ) ; if ( out_ == x ) xLca = out_ ; if ( out_ == y ) yLca = out_ ;
if ( xLca != - 1 && yLca != - 1 ) return currentNode ;
if ( out_ != - 1 ) gotLca = out_ ; } return gotLca ; }
static void buildTree ( int i ) { for ( int l = 0 ; l < tree [ i ] . Count ; l ++ ) { int nextNode = tree [ i ] [ l ] ; for ( int j = 0 ; j < MAX_CHAR ; j ++ ) {
nodecharsCount [ nextNode , j ] += nodecharsCount [ i , j ] ; }
buildTree ( nextNode ) ; } }
static bool canFormPalindromicPath ( int x , int y ) { int lcaNode ;
if ( x == y ) lcaNode = x ;
else lcaNode = LCA ( 1 , x , y ) ; int [ ] charactersCountFromXtoY = new int [ MAX_CHAR ] ;
for ( int i = 0 ; i < MAX_CHAR ; i ++ ) { charactersCountFromXtoY [ i ] = nodecharsCount [ x , i ] + nodecharsCount [ y , i ] - 2 * nodecharsCount [ lcaNode , i ] ; }
if ( canFormPalindrome ( charactersCountFromXtoY ) ) return true ; return false ; }
static void updateNodecharsCount ( String str , int v ) {
for ( int i = 0 ; i < str . Length ; i ++ ) nodecharsCount [ v , str [ i ] - ' a ' ] ++ ; }
static void performQueries ( int [ , ] queries , int q ) { int i = 0 ; while ( i < q ) { int x = queries [ i , 0 ] ; int y = queries [ i , 1 ] ;
if ( canFormPalindromicPath ( x , y ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; i ++ ; } }
for ( int i = 0 ; i < MAX_SIZE ; i ++ ) { for ( int j = 0 ; j < MAX_CHAR ; j ++ ) { nodecharsCount [ i , j ] = 0 ; } } for ( int i = 0 ; i < MAX_SIZE ; i ++ ) { tree [ i ] = new List < int > ( ) ; }
tree [ 1 ] . Add ( 2 ) ; updateNodecharsCount ( " bbc " , 2 ) ;
tree [ 1 ] . Add ( 3 ) ; updateNodecharsCount ( " ac " , 3 ) ;
buildTree ( 1 ) ; int [ , ] queries = { { 1 , 2 } , { 2 , 3 } , { 3 , 1 } , { 3 , 3 } } ; int q = queries . GetLength ( 0 ) ;
performQueries ( queries , q ) ; } }
class Node { public Node left ; public Node right ; public int data ; } ;
static Node newNode ( int key ) { Node node = new Node ( ) ; node . left = node . right = null ; node . data = key ; return node ; } static ArrayList path ;
static bool FindPath ( Node root , int key ) { if ( root == null ) return false ; path . Add ( root . data ) ; if ( root . data == key ) return true ; if ( FindPath ( root . left , key ) || FindPath ( root . right , key ) ) return true ; path . Remove ( ( int ) path [ path . Count - 1 ] ) ; return false ; }
static int minMaxNodeInPath ( Node root , int a , int b ) {
path = new ArrayList ( ) ; bool flag = true ;
ArrayList Path2 = new ArrayList ( ) ; ArrayList Path1 = new ArrayList ( ) ;
int min1 = Int32 . MaxValue ; int max1 = Int32 . MinValue ;
int min2 = Int32 . MaxValue ; int max2 = Int32 . MinValue ; int i = 0 ; int j = 0 ; flag = FindPath ( root , a ) ; Path1 = path ; path = new ArrayList ( ) ; flag &= FindPath ( root , b ) ; Path2 = path ;
if ( flag ) {
for ( i = 0 ; i < Path1 . Count && i < Path2 . Count ; i ++ ) if ( ( int ) Path1 [ i ] != ( int ) Path2 [ i ] ) break ; i -- ; j = i ;
for ( ; i < Path1 . Count ; i ++ ) { if ( min1 > ( int ) Path1 [ i ] ) min1 = ( int ) Path1 [ i ] ; if ( max1 < ( int ) Path1 [ i ] ) max1 = ( int ) Path1 [ i ] ; }
for ( ; j < Path2 . Count ; j ++ ) { if ( min2 > ( int ) Path2 [ j ] ) min2 = ( int ) Path2 [ j ] ; if ( max2 < ( int ) Path2 [ j ] ) max2 = ( int ) Path2 [ j ] ; }
Console . Write ( " Min ▁ = ▁ " + Math . Min ( min1 , min2 ) + " STRNEWLINE " ) ;
Console . Write ( " Max ▁ = ▁ " + Math . Max ( max1 , max2 ) + " STRNEWLINE " ) ; }
else Console . ( " = - 1 Max = - 1 " ) ; return 0 ; }
public static void Main ( string [ ] arg ) { Node root = newNode ( 20 ) ; root . left = newNode ( 8 ) ; root . right = newNode ( 22 ) ; root . left . left = newNode ( 5 ) ; root . left . right = newNode ( 3 ) ; root . right . left = newNode ( 4 ) ; root . right . right = newNode ( 25 ) ; root . left . right . left = newNode ( 10 ) ; root . left . right . right = newNode ( 14 ) ; int a = 5 ; int b = 14 ; minMaxNodeInPath ( root , a , b ) ; } }
public class Node { public int data ; public Node left ; public Node right ; }
static Node newNode ( int data ) { Node node = new Node ( ) ; node . data = data ; node . left = null ; node . right = null ; return node ; }
static Boolean getPath ( Node root , List < int > arr , int x ) {
if ( root == null ) return false ;
arr . Add ( root . data ) ;
if ( root . data == x ) return true ;
if ( getPath ( root . left , arr , x ) || getPath ( root . right , arr , x ) ) return true ;
arr . RemoveAt ( arr . Count - 1 ) ; return false ; }
static int sumOddNodes ( Node root , int n1 , int n2 ) {
List < int > path1 = new List < int > ( ) ;
List < int > path2 = new List < int > ( ) ; getPath ( root , path1 , n1 ) ; getPath ( root , path2 , n2 ) ; int intersection = - 1 ;
int i = 0 , j = 0 ; while ( i < path1 . Count < path2 . Count ) {
if ( i == j && path1 [ i ] == path2 [ j ] ) { i ++ ; j ++ ; } else { intersection = j - 1 ; break ; } } int sum = 0 ;
for ( i = path1 . Count - 1 ; i > intersection ; i -- ) if ( path1 [ i ] % 2 != 0 ) sum += path1 [ i ] ; for ( i = intersection ; i < path2 . Count ; i ++ ) if ( path2 [ i ] % 2 != 0 ) sum += path2 [ i ] ; return sum ; }
public static void Main ( String [ ] args ) { Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . right = newNode ( 6 ) ; int node1 = 5 ; int node2 = 6 ; Console . Write ( sumOddNodes ( root , node1 , node2 ) ) ; } }
static int MAX = 1000 ;
static int findLCA ( int n1 , int n2 , int [ ] parent ) {
Boolean [ ] visited = new Boolean [ MAX ] ; visited [ n1 ] = true ;
while ( parent [ n1 ] != - 1 ) { visited [ n1 ] = true ;
n1 = parent [ n1 ] ; } visited [ n1 ] = true ;
while ( ! visited [ n2 ] ) n2 = parent [ n2 ] ; return n2 ; }
static void insertAdj ( int [ ] parent , int i , int j ) { parent [ i ] = j ; }
int [ ] parent = new int [ MAX ] ;
parent [ 20 ] = - 1 ; insertAdj ( parent , 8 , 20 ) ; insertAdj ( parent , 22 , 20 ) ; insertAdj ( parent , 4 , 8 ) ; insertAdj ( parent , 12 , 8 ) ; insertAdj ( parent , 10 , 12 ) ; insertAdj ( parent , 14 , 12 ) ; Console . WriteLine ( findLCA ( 10 , 14 , parent ) ) ; } }
using System ; class GfG { public class Node { public Node left , right ; public int key ; } static Node newNode ( int key ) { Node ptr = new Node ( ) ; ptr . key = key ; ptr . left = null ; ptr . right = null ; return ptr ; }
static Node insert ( Node root , int key ) { if ( root == null ) root = newNode ( key ) ; else if ( root . key > key ) root . left = insert ( root . left , key ) ; else if ( root . key < key ) root . right = insert ( root . right , key ) ; return root ; }
static int distanceFromRoot ( Node root , int x ) { if ( root . key == x ) return 0 ; else if ( root . key > x ) return 1 + distanceFromRoot ( root . left , x ) ; return 1 + distanceFromRoot ( root . right , x ) ; }
static int distanceBetween2 ( Node root , int a , int b ) { if ( root == null ) return 0 ;
if ( root . key > a && root . key > b ) return distanceBetween2 ( root . left , a , b ) ;
if ( root . key < a && root . key < b ) return distanceBetween2 ( root . right , a , b ) ;
if ( root . key >= a && root . key <= b ) return distanceFromRoot ( root , a ) + distanceFromRoot ( root , b ) ; return 0 ; }
static int findDistWrapper ( Node root , int a , int b ) { int temp = 0 ; if ( a > b ) { temp = a ; a = b ; b = temp ; } return distanceBetween2 ( root , a , b ) ; }
public static void Main ( String [ ] args ) { Node root = null ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; Console . WriteLine ( findDistWrapper ( root , 5 , 35 ) ) ; } }
using System ; using System . Collections ; class GFG { static int MAXN = 1001 ;
static int [ ] depth = new int [ MAXN ] ;
static int [ ] parent = new int [ MAXN ] ; static ArrayList [ ] adj = new ArrayList [ MAXN ] ; static void addEdge ( int u , int v ) { adj [ u ] . Add ( v ) ; adj [ v ] . Add ( u ) ; } static void dfs ( int cur , int prev ) {
parent [ cur ] = prev ;
depth [ cur ] = depth [ prev ] + 1 ;
for ( int i = 0 ; i < adj [ cur ] . Count ; i ++ ) if ( ( int ) adj [ cur ] [ i ] != prev ) dfs ( ( int ) adj [ cur ] [ i ] , cur ) ; } static void preprocess ( ) {
depth [ 0 ] = - 1 ;
dfs ( 1 , 0 ) ; }
static int LCANaive ( int u , int v ) { if ( u == v ) return u ; if ( depth [ u ] > depth [ v ] ) { int temp = u ; u = v ; v = temp ; } v = parent [ v ] ; return LCANaive ( u , v ) ; }
public static void Main ( string [ ] args ) { for ( int i = 0 ; i < MAXN ; i ++ ) adj [ i ] = new ArrayList ( ) ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 1 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 4 , 8 ) ; addEdge ( 4 , 9 ) ; addEdge ( 9 , 10 ) ; addEdge ( 9 , 11 ) ; addEdge ( 7 , 12 ) ; addEdge ( 7 , 13 ) ; preprocess ( ) ; Console . WriteLine ( " LCA ( 11 , ▁ 8 ) ▁ : ▁ " + LCANaive ( 11 , 8 ) ) ; Console . WriteLine ( " LCA ( 3 , ▁ 13 ) ▁ : ▁ " + LCANaive ( 3 , 13 ) ) ; } }
using System ; using System . Collections . Generic ; public class GFG { static readonly int MAXN = 1001 ;
static int block_sz ;
static int [ ] depth = new int [ MAXN ] ;
static int [ ] parent = new int [ MAXN ] ;
static int [ ] jump_parent = new int [ MAXN ] ; static List < int > [ ] adj = new List < int > [ MAXN ] ; static void addEdge ( int u , int v ) { adj [ u ] . Add ( v ) ; adj [ v ] . Add ( u ) ; } static int LCANaive ( int u , int v ) { if ( u == v ) return u ; if ( depth [ u ] > depth [ v ] ) { int t = u ; u = v ; v = t ; } v = parent [ v ] ; return LCANaive ( u , v ) ; }
static void dfs ( int cur , int prev ) {
depth [ cur ] = depth [ prev ] + 1 ;
parent [ cur ] = prev ;
if ( depth [ cur ] % block_sz == 0 )
jump_parent [ cur ] = parent [ cur ] ; else
jump_parent [ cur ] = jump_parent [ prev ] ;
for ( int i = 0 ; i < adj [ cur ] . Count ; ++ i ) if ( adj [ cur ] [ i ] != prev ) dfs ( adj [ cur ] [ i ] , cur ) ; }
static int LCASQRT ( int u , int v ) { while ( jump_parent [ u ] != jump_parent [ v ] ) { if ( depth [ u ] > depth [ v ] ) {
int t = u ; u = v ; v = t ; }
v = jump_parent [ v ] ; }
return LCANaive ( u , v ) ; } static void preprocess ( int height ) { block_sz = ( int ) Math . Sqrt ( height ) ; depth [ 0 ] = - 1 ;
dfs ( 1 , 0 ) ; }
public static void Main ( String [ ] args ) { for ( int i = 0 ; i < adj . Length ; i ++ ) adj [ i ] = new List < int > ( ) ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 1 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 4 , 8 ) ; addEdge ( 4 , 9 ) ; addEdge ( 9 , 10 ) ; addEdge ( 9 , 11 ) ; addEdge ( 7 , 12 ) ; addEdge ( 7 , 13 ) ;
int height = 4 ; preprocess ( height ) ; Console . Write ( " LCA ( 11,8 ) ▁ : ▁ " + LCASQRT ( 11 , 8 ) + " STRNEWLINE " ) ; Console . Write ( " LCA ( 3,13 ) ▁ : ▁ " + LCASQRT ( 3 , 13 ) + " STRNEWLINE " ) ; } }
static readonly int MAXN = 100001 ; static List < int > [ ] tree = new List < int > [ MAXN ] ;
static void dfs ( int cur , int prev , int pathNumber , int ptr , int node ) { for ( int i = 0 ; i < tree [ cur ] . Count ; i ++ ) { if ( tree [ cur ] [ i ] != prev && ! flag ) {
path [ pathNumber , ptr ] = tree [ cur ] [ i ] ; if ( tree [ cur ] [ i ] == node ) {
flag = true ;
path [ pathNumber , ptr + 1 ] = - 1 ; return ; } dfs ( tree [ cur ] [ i ] , cur , pathNumber , ptr + 1 , node ) ; } } }
static int LCA ( int a , int b ) {
if ( a == b ) return a ;
path [ 1 , 0 ] = path [ 2 , 0 ] = 1 ;
flag = false ; dfs ( 1 , 0 , 1 , 1 , a ) ;
flag = false ; dfs ( 1 , 0 , 2 , 1 , b ) ;
int i = 0 ; while ( i < MAXN && path [ 1 , i ] == path [ 2 , i ] ) i ++ ;
return path [ 1 , i - 1 ] ; } static void addEdge ( int a , int b ) { tree [ a ] . Add ( b ) ; tree [ b ] . Add ( a ) ; }
public static void Main ( String [ ] args ) { for ( int i = 0 ; i < MAXN ; i ++ ) tree [ i ] = new List < int > ( ) ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 3 , 8 ) ; Console . Write ( " LCA ( 4 , ▁ 7 ) ▁ = ▁ " + LCA ( 4 , 7 ) + " STRNEWLINE " ) ; Console . Write ( " LCA ( 4 , ▁ 6 ) ▁ = ▁ " + LCA ( 4 , 6 ) + " STRNEWLINE " ) ; } }
using System ; using System . Collections . Generic ; class GFG { static readonly int MAXN = 100000 ; static readonly int level = 18 ; static List < int > [ ] tree = new List < int > [ MAXN ] ; static int [ ] depth = new int [ MAXN ] ; static int [ , ] parent = new int [ MAXN , level ] ;
static void dfs ( int cur , int prev ) { depth [ cur ] = depth [ prev ] + 1 ; parent [ cur , 0 ] = prev ; for ( int i = 0 ; i < tree [ cur ] . Count ; i ++ ) { if ( tree [ cur ] [ i ] != prev ) dfs ( tree [ cur ] [ i ] , cur ) ; } }
static void precomputeSparseMatrix ( int n ) { for ( int i = 1 ; i < level ; i ++ ) { for ( int node = 1 ; node <= n ; node ++ ) { if ( parent [ node , i - 1 ] != - 1 ) parent [ node , i ] = parent [ parent [ node , i - 1 ] , i - 1 ] ; } } }
static int lca ( int u , int v ) { if ( depth [ v ] < depth [ u ] ) { u = u + v ; v = u - v ; u = u - v ; } int diff = depth [ v ] - depth [ u ] ;
for ( int i = 0 ; i < level ; i ++ ) if ( ( ( diff >> i ) & 1 ) == 1 ) v = parent [ v , i ] ;
if ( u == v ) return u ;
for ( int i = level - 1 ; i >= 0 ; i -- ) if ( parent [ u , i ] != parent [ v , i ] ) { u = parent [ u , i ] ; v = parent [ v , i ] ; } return parent [ u , 0 ] ; } static void addEdge ( int u , int v ) { tree [ u ] . Add ( v ) ; tree [ v ] . Add ( u ) ; } static void memset ( int value ) { for ( int i = 0 ; i < MAXN ; i ++ ) { for ( int j = 0 ; j < level ; j ++ ) { parent [ i , j ] = - 1 ; } } }
public static void Main ( String [ ] args ) { memset ( - 1 ) ; for ( int i = 0 ; i < MAXN ; i ++ ) tree [ i ] = new List < int > ( ) ; int n = 8 ; addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 3 , 8 ) ; depth [ 0 ] = 0 ;
dfs ( 1 , 0 ) ;
precomputeSparseMatrix ( n ) ;
Console . Write ( " LCA ( 4 , ▁ 7 ) ▁ = ▁ " + lca ( 4 , 7 ) + " STRNEWLINE " ) ; Console . Write ( " LCA ( 4 , ▁ 6 ) ▁ = ▁ " + lca ( 4 , 6 ) + " STRNEWLINE " ) ; } }
public class Query { public int L , R ; public Query ( int L , int R ) { this . L = L ; this . R = R ; } } ;
static int LCE ( String str , int n , int L , int R ) { int length = 0 ; while ( R + length < n && str [ L + length ] == str [ R + length ] ) length ++ ; return ( length ) ; }
static void LCEQueries ( String str , int n , Query [ ] q , int m ) { for ( int i = 0 ; i < m ; i ++ ) { int L = q [ i ] . L ; int R = q [ i ] . R ; Console . WriteLine ( " LCE ▁ ( " + L + " , ▁ " + R + " ) ▁ = ▁ " + LCE ( str , n , L , R ) ) ; } return ; }
public static void Main ( String [ ] args ) { String str = " abbababba " ; int n = str . Length ;
Query [ ] q = new Query [ 3 ] ; q [ 0 ] = new Query ( 1 , 2 ) ; q [ 1 ] = new Query ( 1 , 6 ) ; q [ 2 ] = new Query ( 0 , 5 ) ; int m = q . Length ; LCEQueries ( str , n , q , m ) ; } }
static readonly int V = 5 ;
static readonly int WHITE = 1 ;
static readonly int BLACK = 2 ;
public class Node { public int data ; public Node left , right ; } ;
public class subset { public int parent ; public int rank ; public int ancestor ; public int child ; public int sibling ; public int color ; } ;
public class Query { public int L , R ; public Query ( int L , int R ) { this . L = L ; this . R = R ; } } ;
static Node newNode ( int data ) { Node node = new Node ( ) ; node . data = data ; node . left = node . right = null ; return ( node ) ; }
static void makeSet ( subset [ ] subsets , int i ) { if ( i < 1 i > V ) return ; subsets [ i ] . color = WHITE ; subsets [ i ] . parent = i ; subsets [ i ] . rank = 0 ; return ; }
static int findSet ( subset [ ] subsets , int i ) {
if ( subsets [ i ] . parent != i ) subsets [ i ] . parent = findSet ( subsets , subsets [ i ] . parent ) ; return subsets [ i ] . parent ; }
static void unionSet ( subset [ ] subsets , int x , int y ) { int xroot = findSet ( subsets , x ) ; int yroot = findSet ( subsets , y ) ;
if ( subsets [ xroot ] . rank < subsets [ yroot ] . rank ) subsets [ xroot ] . parent = yroot ; else if ( subsets [ xroot ] . rank > subsets [ yroot ] . rank ) subsets [ yroot ] . parent = xroot ;
else { subsets [ yroot ] . parent = xroot ; ( subsets [ xroot ] . rank ) ++ ; } }
static void lcaWalk ( int u , Query [ ] q , int m , subset [ ] subsets ) {
makeSet ( subsets , u ) ;
subsets [ findSet ( subsets , u ) ] . ancestor = u ; int child = subsets [ u ] . child ;
while ( child != 0 ) { lcaWalk ( child , q , m , subsets ) ; unionSet ( subsets , u , child ) ; subsets [ findSet ( subsets , u ) ] . ancestor = u ; child = subsets [ child ] . sibling ; } subsets [ u ] . color = BLACK ; for ( int i = 0 ; i < m ; i ++ ) { if ( q [ i ] . L == u ) { if ( subsets [ q [ i ] . R ] . color == BLACK ) { Console . WriteLine ( " LCA ( " + q [ i ] . L + " ▁ " + q [ i ] . R + " ) ▁ - > ▁ " + subsets [ findSet ( subsets , q [ i ] . R ) ] . ancestor ) ; } } else if ( q [ i ] . R == u ) { if ( subsets [ q [ i ] . L ] . color == BLACK ) { Console . WriteLine ( " LCA ( " + q [ i ] . L + " ▁ " + q [ i ] . R + " ) ▁ - > ▁ " + subsets [ findSet ( subsets , q [ i ] . L ) ] . ancestor ) ; } } } return ; }
static void preprocess ( Node node , subset [ ] subsets ) { if ( node == null ) return ;
preprocess ( node . left , subsets ) ; if ( node . left != null && node . right != null ) {
subsets [ node . data ] . child = node . left . data ; subsets [ node . left . data ] . sibling = node . right . data ; } else if ( ( node . left != null && node . right == null ) || ( node . left == null && node . right != null ) ) { if ( node . left != null && node . right == null ) subsets [ node . data ] . child = node . left . data ; else subsets [ node . data ] . child = node . right . data ; }
preprocess ( node . right , subsets ) ; }
static void initialise ( subset [ ] subsets ) {
for ( int i = 1 ; i < subsets . Length ; i ++ ) { subsets [ i ] = new subset ( ) ; subsets [ i ] . color = WHITE ; } return ; }
static void printLCAs ( Node root , Query [ ] q , int m ) {
subset [ ] subsets = new subset [ V + 1 ] ;
initialise ( subsets ) ;
preprocess ( root , subsets ) ;
lcaWalk ( root . data , q , m , subsets ) ; }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ;
Query [ ] q = new Query [ 3 ] ; q [ 0 ] = new Query ( 5 , 4 ) ; q [ 1 ] = new Query ( 1 , 3 ) ; q [ 2 ] = new Query ( 2 , 3 ) ; int m = q . Length ; printLCAs ( root , q , m ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class Count { public int count = 0 ; } public class BinaryTree { public Node root ; public Count ct = new Count ( ) ;
public virtual bool countSingleRec ( Node node , Count c ) {
if ( node == null ) { return true ; }
bool left = countSingleRec ( node . left , c ) ; bool right = countSingleRec ( node . right , c ) ;
if ( left == false right == false ) { return false ; }
if ( node . left != null && node . data != node . left . data ) { return false ; }
if ( node . right != null && node . data != node . right . data ) { return false ; }
c . count ++ ; return true ; }
public virtual int countSingle ( ) { return countSingle ( root ) ; } public virtual int countSingle ( Node node ) {
countSingleRec ( node , ct ) ; return ct . count ; }
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 5 ) ; tree . root . left = new Node ( 4 ) ; tree . root . right = new Node ( 5 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 4 ) ; tree . root . right . right = new Node ( 5 ) ; Console . WriteLine ( " The ▁ count ▁ of ▁ single ▁ valued ▁ sub ▁ trees ▁ is ▁ : ▁ " + tree . countSingle ( ) ) ; } }
public class Node { public int key ; public Node left , right ; public Node ( int key ) { this . key = key ; left = right = null ; } }
public class Distance { public int minDis = int . MaxValue ; } public class BinaryTree { public Node root ;
public virtual void findLeafDown ( Node root , int lev , Distance minDist ) {
if ( root == null ) { return ; }
if ( root . left == null && root . right == null ) { if ( lev < ( minDist . minDis ) ) { minDist . minDis = lev ; } return ; }
findLeafDown ( root . left , lev + 1 , minDist ) ; findLeafDown ( root . right , lev + 1 , minDist ) ; }
public virtual int findThroughParent ( Node root , Node x , Distance minDist ) {
if ( root == null ) { return - 1 ; } if ( root == x ) { return 0 ; }
int l = findThroughParent ( root . left , x , minDist ) ;
if ( l != - 1 ) {
findLeafDown ( root . right , l + 2 , minDist ) ; return l + 1 ; }
int r = findThroughParent ( root . right , x , minDist ) ;
if ( r != - 1 ) {
findLeafDown ( root . left , r + 2 , minDist ) ; return r + 1 ; } return - 1 ; }
public virtual int minimumDistance ( Node root , Node x ) {
Distance d = new Distance ( ) ;
findLeafDown ( x , 0 , d ) ;
findThroughParent ( root , x , d ) ; return d . minDis ; }
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 12 ) ; tree . root . right = new Node ( 13 ) ; tree . root . right . left = new Node ( 14 ) ; tree . root . right . right = new Node ( 15 ) ; tree . root . right . left . left = new Node ( 21 ) ; tree . root . right . left . right = new Node ( 22 ) ; tree . root . right . right . left = new Node ( 23 ) ; tree . root . right . right . right = new Node ( 24 ) ; tree . root . right . left . left . left = new Node ( 1 ) ; tree . root . right . left . left . right = new Node ( 2 ) ; tree . root . right . left . right . left = new Node ( 3 ) ; tree . root . right . left . right . right = new Node ( 4 ) ; tree . root . right . right . left . left = new Node ( 5 ) ; tree . root . right . right . left . right = new Node ( 6 ) ; tree . root . right . right . right . left = new Node ( 7 ) ; tree . root . right . right . right . right = new Node ( 8 ) ; Node x = tree . root . right ; Console . WriteLine ( " The ▁ closest ▁ leaf ▁ to ▁ node ▁ with ▁ value ▁ " + x . key + " ▁ is ▁ at ▁ a ▁ distance ▁ of ▁ " + tree . minimumDistance ( tree . root , x ) ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } }
public class BinaryTree { public Node root ; public virtual void printInorder ( Node node ) { if ( node != null ) { printInorder ( node . left ) ; Console . Write ( node . data + " ▁ " ) ; printInorder ( node . right ) ; } }
public virtual Node RemoveHalfNodes ( Node node ) { if ( node == null ) { return null ; } node . left = RemoveHalfNodes ( node . left ) ; node . right = RemoveHalfNodes ( node . right ) ; if ( node . left == null && node . right == null ) { return node ; }
if ( node . left == null ) { Node new_root = node . right ; return new_root ; }
if ( node . right == null ) { Node new_root = node . left ; return new_root ; } return node ; }
public static void Main ( string [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; Node NewRoot = null ; tree . root = new Node ( 2 ) ; tree . root . left = new Node ( 7 ) ; tree . root . right = new Node ( 5 ) ; tree . root . left . right = new Node ( 6 ) ; tree . root . left . right . left = new Node ( 1 ) ; tree . root . left . right . right = new Node ( 11 ) ; tree . root . right . right = new Node ( 9 ) ; tree . root . right . right . left = new Node ( 4 ) ; Console . WriteLine ( " the ▁ inorder ▁ traversal ▁ of ▁ tree ▁ is ▁ " ) ; tree . printInorder ( tree . root ) ; NewRoot = tree . RemoveHalfNodes ( tree . root ) ; Console . Write ( " STRNEWLINE Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ STRNEWLINE " ) ; tree . printInorder ( NewRoot ) ; } }
static Node newNode ( int data ) { Node node = new Node ( ) ; node . data = data ; node . left = node . right = node . abtr = null ; return node ; } static List < Node > even_ptrs = new List < Node > ( ) ; static List < Node > odd_ptrs = new List < Node > ( ) ;
static void preorderTraversal ( Node root ) { if ( root == null ) return ;
if ( root . data % 2 == 0 ) ( even_ptrs ) . Add ( root ) ;
else ( odd_ptrs ) . Add ( root ) ; preorderTraversal ( root . left ) ; preorderTraversal ( root . right ) ; }
static void createLoops ( Node root ) { preorderTraversal ( root ) ; int i ;
for ( i = 1 ; i < even_ptrs . Count ; i ++ ) even_ptrs [ i - 1 ] . abtr = even_ptrs [ i ] ;
even_ptrs [ i - 1 ] . abtr = even_ptrs [ 0 ] ;
for ( i = 1 ; i < odd_ptrs . Count ; i ++ ) odd_ptrs [ i - 1 ] . abtr = odd_ptrs [ i ] ; odd_ptrs [ i - 1 ] . abtr = odd_ptrs [ 0 ] ; }
static void traverseLoop ( Node start ) { Node curr = start ; do { Console . Write ( curr . data + " ▁ " ) ; curr = curr . abtr ; } while ( curr != start ) ; }
Node root = null ; root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 7 ) ; createLoops ( root ) ;
Console . Write ( " Odd ▁ nodes : ▁ " ) ; traverseLoop ( root . right ) ; Console . Write ( " STRNEWLINE Even ▁ nodes : ▁ " ) ;
traverseLoop ( root . left ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; right = left = null ; } }
public class BinaryTree { Node root ; Node head ; Node prev ;
public Node extractLeafList ( Node root ) { if ( root == null ) return null ; if ( root . left == null && root . right == null ) { if ( head == null ) { head = root ; prev = root ; } else { prev . right = root ; root . left = prev ; prev = root ; } return null ; } root . left = extractLeafList ( root . left ) ; root . right = extractLeafList ( root . right ) ; return root ; }
void inorder ( Node node ) { if ( node == null ) return ; inorder ( node . left ) ; Console . Write ( node . data + " ▁ " ) ; inorder ( node . right ) ; }
public void printDLL ( Node head ) { Node last = null ; while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; last = head ; head = head . right ; } }
public static void Main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . right = new Node ( 6 ) ; tree . root . left . left . left = new Node ( 7 ) ; tree . root . left . left . right = new Node ( 8 ) ; tree . root . right . right . left = new Node ( 9 ) ; tree . root . right . right . right = new Node ( 10 ) ; Console . WriteLine ( " Inorder ▁ traversal ▁ of ▁ given ▁ tree ▁ is ▁ : ▁ " ) ; tree . inorder ( tree . root ) ; tree . extractLeafList ( tree . root ) ; Console . WriteLine ( " " ) ; Console . WriteLine ( " Extracted ▁ double ▁ link ▁ list ▁ is ▁ : ▁ " ) ; tree . printDLL ( tree . head ) ; Console . WriteLine ( " " ) ; Console . WriteLine ( " Inorder ▁ traversal ▁ of ▁ modified ▁ tree ▁ is ▁ : ▁ " ) ; tree . inorder ( tree . root ) ; } }
public static bool isStepNum ( int n ) {
int prevDigit = - 1 ;
while ( n > 0 ) {
int curDigit = n % 10 ;
if ( prevDigit != - 1 ) {
if ( Math . Abs ( curDigit - prevDigit ) != 1 ) return false ; } n /= 10 ; prevDigit = curDigit ; } return true ; }
public static void displaySteppingNumbers ( int n , int m ) {
for ( int i = n ; i <= m ; i ++ ) if ( isStepNum ( i ) ) Console . Write ( i + " ▁ " ) ; }
public static void Main ( ) { int n = 0 , m = 21 ;
displaySteppingNumbers ( n , m ) ; } }
static void bfs ( int n , int m , int num ) {
Queue < int > q = new Queue < int > ( ) ; q . Enqueue ( num ) ; while ( q . Count != 0 ) {
int stepNum = q . Dequeue ( ) ;
if ( stepNum <= m && stepNum >= n ) { Console . Write ( stepNum + " ▁ " ) ; }
if ( stepNum == 0 stepNum > m ) continue ;
int lastDigit = stepNum % 10 ;
int stepNumA = stepNum * 10 + ( lastDigit - 1 ) ; int stepNumB = stepNum * 10 + ( lastDigit + 1 ) ;
if ( lastDigit == 0 ) q . Enqueue ( stepNumB ) ;
else if ( lastDigit = = 9 ) q . Enqueue ( stepNumA ) ; else { q . Enqueue ( stepNumA ) ; q . Enqueue ( stepNumB ) ; } } }
static void displaySteppingNumbers ( int n , int m ) {
for ( int i = 0 ; i <= 9 ; i ++ ) bfs ( n , m , i ) ; }
static public void Main ( ) { int n = 0 , m = 21 ;
displaySteppingNumbers ( n , m ) ; } }
public class Node { public int data ; public Node left ; public Node right ; public Node ( int data ) { this . data = data ; left = null ; right = null ; } }
static void levelOrder ( Node root ) { if ( root == null ) return ;
Queue q = new Queue ( ) ;
q . Enqueue ( root ) ;
q . Enqueue ( null ) ;
while ( q . Count > 0 ) { Node curr = ( Node ) q . Peek ( ) ; q . Dequeue ( ) ;
if ( curr == null ) { if ( q . Count > 0 ) { q . Enqueue ( null ) ; Console . WriteLine ( ) ; } } else {
if ( curr . left != null ) q . Enqueue ( curr . left ) ;
if ( curr . right != null ) q . Enqueue ( curr . right ) ; Console . Write ( curr . data + " ▁ " ) ; } } }
Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . right = new Node ( 6 ) ; levelOrder ( root ) ; } }
public class Node { public Node left ; public int data ; public Node right ; } ;
static void modifiedLevelOrder ( Node node ) {
if ( node == null ) return ; if ( node . left == null && node . right == null ) { Console . Write ( node . data ) ; return ; }
Queue < Node > myQueue = new Queue < Node > ( ) ;
Stack < Node > myStack = new Stack < Node > ( ) ; Node temp = null ;
int sz ;
int ct = 0 ;
bool rightToLeft = false ;
myQueue . Enqueue ( node ) ;
while ( myQueue . Count != 0 ) { ct ++ ; sz = myQueue . Count ;
for ( int i = 0 ; i < sz ; i ++ ) { temp = myQueue . Peek ( ) ; myQueue . Dequeue ( ) ;
if ( rightToLeft == false ) Console . Write ( temp . data + " ▁ " ) ;
else myStack . ( temp ) ; if ( temp . left != null ) myQueue . Enqueue ( temp . left ) ; if ( temp . right != null ) myQueue . Enqueue ( temp . right ) ; } if ( rightToLeft == true ) {
while ( myStack . Count != 0 ) { temp = myStack . Peek ( ) ; myStack . Pop ( ) ; Console . Write ( temp . data + " ▁ " ) ; } }
if ( ct == 2 ) { rightToLeft = ! rightToLeft ; ct = 0 ; } Console . Write ( " STRNEWLINE " ) ; } }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 7 ) ; root . left . left . left = newNode ( 8 ) ; root . left . left . right = newNode ( 9 ) ; root . left . right . left = newNode ( 3 ) ; root . left . right . right = newNode ( 1 ) ; root . right . left . left = newNode ( 4 ) ; root . right . left . right = newNode ( 2 ) ; root . right . right . left = newNode ( 7 ) ; root . right . right . right = newNode ( 2 ) ; root . left . right . left . left = newNode ( 16 ) ; root . left . right . left . right = newNode ( 17 ) ; root . right . left . right . left = newNode ( 18 ) ; root . right . right . left . right = newNode ( 19 ) ; modifiedLevelOrder ( root ) ; } }
static int find ( int [ ] parent , int i ) { if ( parent [ i ] == - 1 ) return i ; return find ( parent , parent [ i ] ) ; }
static void Union ( int [ ] parent , int x , int y ) { int xset = find ( parent , x ) ; int yset = find ( parent , y ) ; parent [ xset ] = yset ; }
using System ; using System . Collections . Generic ; public class GFG { static readonly int LEFT = 0 ; static readonly int RIGHT = 1 ; static int ChangeDirection ( int Dir ) { Dir = 1 - Dir ; return Dir ; }
public class node { public int data ; public node left , right ; } ;
static node newNode ( int data ) { node temp = new node ( ) ; temp . data = data ; temp . left = temp . right = null ; return temp ; }
static void modifiedLevelOrder ( node root ) { if ( root == null ) return ; int dir = LEFT ; node temp ; Queue < node > Q = new Queue < node > ( ) ; Stack < node > S = new Stack < node > ( ) ; S . Push ( root ) ;
while ( Q . Count != 0 S . Count != 0 ) { while ( S . Count != 0 ) { temp = S . Peek ( ) ; S . Pop ( ) ; Console . Write ( temp . data + " ▁ " ) ; if ( dir == LEFT ) { if ( temp . left != null ) Q . Enqueue ( temp . left ) ; if ( temp . right != null ) Q . Enqueue ( temp . right ) ; }
else { if ( temp . right != null ) Q . Enqueue ( temp . right ) ; if ( temp . left != null ) Q . Enqueue ( temp . left ) ; } } Console . WriteLine ( ) ;
while ( Q . Count != 0 ) { temp = Q . Peek ( ) ; Q . Dequeue ( ) ; Console . Write ( temp . data + " ▁ " ) ; if ( dir == LEFT ) { if ( temp . left != null ) S . Push ( temp . left ) ; if ( temp . right != null ) S . Push ( temp . right ) ; } else { if ( temp . right != null ) S . Push ( temp . right ) ; if ( temp . left != null ) S . Push ( temp . left ) ; } } Console . WriteLine ( ) ;
dir = ChangeDirection ( dir ) ; } }
node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 7 ) ; root . left . left . left = newNode ( 8 ) ; root . left . left . right = newNode ( 9 ) ; root . left . right . left = newNode ( 3 ) ; root . left . right . right = newNode ( 1 ) ; root . right . left . left = newNode ( 4 ) ; root . right . left . right = newNode ( 2 ) ; root . right . right . left = newNode ( 7 ) ; root . right . right . right = newNode ( 2 ) ; root . left . right . left . left = newNode ( 16 ) ; root . left . right . left . right = newNode ( 17 ) ; root . right . left . right . left = newNode ( 18 ) ; root . right . right . left . right = newNode ( 19 ) ; modifiedLevelOrder ( root ) ; } }
using System ; class GFG { static int N = 8 ;
static bool isSafe ( int x , int y , int [ , ] sol ) { return ( x >= 0 && x < N && y >= 0 && y < N && sol [ x , y ] == - 1 ) ; }
static void printSolution ( int [ , ] sol ) { for ( int x = 0 ; x < N ; x ++ ) { for ( int y = 0 ; y < N ; y ++ ) Console . Write ( sol [ x , y ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
static bool solveKT ( ) { int [ , ] sol = new int [ 8 , 8 ] ;
for ( int x = 0 ; x < N ; x ++ ) for ( int y = 0 ; y < N ; y ++ ) sol [ x , y ] = - 1 ;
int [ ] xMove = { 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 } ; int [ ] yMove = { 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 } ;
sol [ 0 , 0 ] = 0 ;
if ( ! solveKTUtil ( 0 , 0 , 1 , sol , xMove , yMove ) ) { Console . WriteLine ( " Solution ▁ does ▁ " + " not ▁ exist " ) ; return false ; } else printSolution ( sol ) ; return true ; }
static bool solveKTUtil ( int x , int y , int movei , int [ , ] sol , int [ ] xMove , int [ ] yMove ) { int k , next_x , next_y ; if ( movei == N * N ) return true ;
for ( k = 0 ; k < 8 ; k ++ ) { next_x = x + xMove [ k ] ; next_y = y + yMove [ k ] ; if ( isSafe ( next_x , next_y , sol ) ) { sol [ next_x , next_y ] = movei ; if ( solveKTUtil ( next_x , next_y , movei + 1 , sol , xMove , yMove ) ) return true ; else
sol [ next_x , next_y ] = - 1 ; } } return false ; }
solveKT ( ) ; } }
static int V = 4 ;
static void printSolution ( int [ ] color ) { Console . WriteLine ( " Solution ▁ Exists : " + " ▁ Following ▁ are ▁ the ▁ assigned ▁ colors ▁ " ) ; for ( int i = 0 ; i < V ; i ++ ) Console . Write ( " ▁ " + color [ i ] ) ; Console . WriteLine ( ) ; }
static bool isSafe ( bool [ , ] graph , int [ ] color ) {
for ( int i = 0 ; i < V ; i ++ ) for ( int j = i + 1 ; j < V ; j ++ ) if ( graph [ i , j ] && color [ j ] == color [ i ] ) return false ; return true ; }
static bool graphColoring ( bool [ , ] graph , int m , int i , int [ ] color ) {
if ( i == V ) {
if ( isSafe ( graph , color ) ) {
printSolution ( color ) ; return true ; } return false ; }
for ( int j = 1 ; j <= m ; j ++ ) { color [ i ] = j ;
if ( graphColoring ( graph , m , i + 1 , color ) ) return true ; color [ i ] = 0 ; } return false ; }
bool [ , ] graph = { { false , true , true , true } , { true , false , true , false } , { true , true , false , true } , { true , false , true , false } , } ;
int m = 3 ;
int [ ] color = new int [ V ] ; for ( int i = 0 ; i < V ; i ++ ) color [ i ] = 0 ; if ( ! graphColoring ( graph , m , 0 , color ) ) Console . WriteLine ( " Solution ▁ does ▁ not ▁ exist " ) ; } }
static int shortestChainLen ( String start , String target , HashSet < String > D ) { if ( start == target ) return 0 ;
if ( ! D . Contains ( target ) ) return 0 ;
int level = 0 , wordlength = start . Length ;
List < String > Q = new List < String > ( ) ; Q . Add ( start ) ;
while ( Q . Count != 0 ) {
++ level ;
int sizeofQ = Q . Count ;
for ( int i = 0 ; i < sizeofQ ; ++ i ) {
char [ ] word = Q [ 0 ] . ToCharArray ( ) ; Q . RemoveAt ( 0 ) ;
for ( int pos = 0 ; pos < wordlength ; ++ pos ) {
char orig_char = word [ pos ] ;
for ( char c = ' a ' ; c <= ' z ' ; ++ c ) { word [ pos ] = c ;
if ( String . Join ( " " , word ) . Equals ( target ) ) return level + 1 ;
if ( ! D . Contains ( String . Join ( " " , word ) ) ) continue ; D . Remove ( String . Join ( " " , word ) ) ;
Q . Add ( String . Join ( " " , word ) ) ; }
word [ pos ] = orig_char ; } } } return 0 ; }
HashSet < String > D = new HashSet < String > ( ) ; D . Add ( " poon " ) ; D . Add ( " plee " ) ; D . Add ( " same " ) ; D . Add ( " poie " ) ; D . Add ( " plie " ) ; D . Add ( " poin " ) ; D . Add ( " plea " ) ; String start = " toon " ; String target = " plea " ; Console . Write ( " Length ▁ of ▁ shortest ▁ chain ▁ is : ▁ " + shortestChainLen ( start , target , D ) ) ; } }
using System ; class GFG { static int INF = int . MaxValue , N = 4 ;
static int minCost ( int [ , ] cost ) {
int [ ] dist = new int [ N ] ; for ( int i = 0 ; i < N ; i ++ ) dist [ i ] = INF ; dist [ 0 ] = 0 ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( dist [ j ] > dist [ i ] + cost [ i , j ] ) dist [ j ] = dist [ i ] + cost [ i , j ] ; return dist [ N - 1 ] ; }
public static void Main ( ) { int [ , ] cost = { { 0 , 15 , 80 , 90 } , { INF , 0 , 40 , 50 } , { INF , INF , 0 , 70 } , { INF , INF , INF , 0 } } ; Console . WriteLine ( " The ▁ Minimum ▁ cost ▁ to " + " ▁ reach ▁ station ▁ " + N + " ▁ is ▁ " + minCost ( cost ) ) ; } }
static int numOfways ( int n , int k ) { int p = 1 ; if ( k % 2 != 0 ) p = - 1 ; return ( int ) ( Math . Pow ( n - 1 , k ) + p * ( n - 1 ) ) / n ; }
static void Main ( ) { int n = 4 , k = 2 ; Console . Write ( numOfways ( n , k ) ) ; } }
if ( inMST [ v ] == false && key [ v ] > weight ) {
key [ v ] = weight ; pq . Add ( new Tuple < int , int > ( key [ v ] , v ) ) ; parent [ v ] = u ; }
int V = 4 ;
void multiply ( int [ , ] A , int [ , ] B , int [ , ] C ) { for ( int i = 0 ; i < V ; i ++ ) { for ( int j = 0 ; j < V ; j ++ ) { C [ i , j ] = 0 ; for ( int k = 0 ; k < V ; k ++ ) { C [ i , j ] += A [ i , k ] * B [ k , j ] ; } } } }
int getTrace ( int [ , ] graph ) { int trace = 0 ; for ( int i = 0 ; i < V ; i ++ ) { trace += graph [ i , i ] ; } return trace ; }
int triangleInGraph ( int [ , ] graph ) {
int [ , ] aux2 = new int [ V , V ] ;
int [ , ] aux3 = new int [ V , V ] ;
for ( int i = 0 ; i < V ; ++ i ) { for ( int j = 0 ; j < V ; ++ j ) { aux2 [ i , j ] = aux3 [ i , j ] = 0 ; } }
multiply ( graph , graph , aux2 ) ;
multiply ( graph , aux2 , aux3 ) ; int trace = getTrace ( aux3 ) ; return trace / 6 ; }
public static void Main ( ) { GFG obj = new GFG ( ) ; int [ , ] graph = { { 0 , 1 , 1 , 0 } , { 1 , 0 , 1 , 1 } , { 1 , 1 , 0 , 1 } , { 0 , 1 , 1 , 0 } } ; Console . WriteLine ( " Total ▁ number ▁ of ▁ " + " Triangle ▁ in ▁ Graph ▁ : ▁ " + obj . triangleInGraph ( graph ) ) ; } }
static int power ( int n ) { if ( n == 1 ) return 2 ; return 2 * power ( n - 1 ) ; }
public static void Main ( ) { int n = 4 ; Console . WriteLine ( power ( n ) ) ; } }
static int size = 4 ;
static bool checkStar ( int [ , ] mat ) {
int vertexD1 = 0 , vertexDn_1 = 0 ;
if ( size == 1 ) return ( mat [ 0 , 0 ] == 0 ) ;
if ( size == 2 ) return ( mat [ 0 , 0 ] == 0 && mat [ 0 , 1 ] == 1 && mat [ 1 , 0 ] == 1 && mat [ 1 , 1 ] == 0 ) ;
for ( int i = 0 ; i < size ; i ++ ) { int degreeI = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( mat [ i , j ] == 1 ) degreeI ++ ; if ( degreeI == 1 ) vertexD1 ++ ; else if ( degreeI == size - 1 ) vertexDn_1 ++ ; } return ( vertexD1 == ( size - 1 ) && vertexDn_1 == 1 ) ; }
static void Main ( ) { int [ , ] mat = new int [ 4 , 4 ] { { 0 , 1 , 1 , 1 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } } ; if ( checkStar ( mat ) ) Console . Write ( " Star ▁ Graph " ) ; else Console . Write ( " Not ▁ a ▁ Star ▁ Graph " ) ; } }
static int fib ( int n ) { if ( n <= 1 ) return n ; return fib ( n - 1 ) + fib ( n - 2 ) ; }
static int findVertices ( int n ) {
return fib ( n + 2 ) ; }
static void Main ( ) { int n = 3 ; Console . Write ( findVertices ( n ) ) ; } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public void insertAfter ( Node prev_node , int new_data ) {
if ( prev_node == null ) { Console . WriteLine ( " The ▁ given ▁ previous ▁ node " + " ▁ cannot ▁ be ▁ null " ) ; return ; }
Node new_node = new Node ( new_data ) ;
new_node . next = prev_node . next ;
prev_node . next = new_node ; }
public class Node { public int data ; public Node next ; public Node ( int d ) { data = d ; next = null ; } }
Node head ;
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public int getCountRec ( Node node ) {
if ( node == null ) return 0 ;
return 1 + getCountRec ( node . next ) ; }
public int getCount ( ) { return getCountRec ( head ) ; }
LinkedList llist = new LinkedList ( ) ; llist . push ( 1 ) ; llist . push ( 3 ) ; llist . push ( 1 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; Console . WriteLine ( " Count ▁ of ▁ nodes ▁ is ▁ " + llist . getCount ( ) ) ; } }
static int count ( Node head , int key ) { if ( head == null ) return 0 ; if ( head . data == key ) return 1 + count ( head . next , key ) ; return count ( head . next , key ) ; }
public class Node { public char data ; public Node next ; public Node ( char d ) { data = d ; next = null ; } }
Node head ; Node slow_ptr , fast_ptr , second_half ;
Boolean isPalindrome ( Node head ) { slow_ptr = head ; fast_ptr = head ; Node prev_of_slow_ptr = head ;
Node midnode = null ;
Boolean res = true ; if ( head != null && head . next != null ) {
while ( fast_ptr != null && fast_ptr . next != null ) { fast_ptr = fast_ptr . next . next ;
prev_of_slow_ptr = slow_ptr ; slow_ptr = slow_ptr . next ; }
if ( fast_ptr != null ) { midnode = slow_ptr ; slow_ptr = slow_ptr . next ; }
second_half = slow_ptr ;
prev_of_slow_ptr . next = null ;
reverse ( ) ;
res = compareLists ( head , second_half ) ;
reverse ( ) ; if ( midnode != null ) {
prev_of_slow_ptr . next = midnode ; midnode . next = second_half ; } else prev_of_slow_ptr . = second_half ; } return res ; }
void reverse ( ) { Node prev = null ; Node current = second_half ; Node next ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } second_half = prev ; }
Boolean compareLists ( Node head1 , Node head2 ) { Node temp1 = head1 ; Node temp2 = head2 ; while ( temp1 != null && temp2 != null ) { if ( temp1 . data == temp2 . data ) { temp1 = temp1 . next ; temp2 = temp2 . next ; } else return false ; }
if ( temp1 == null && temp2 == null ) return true ;
return false ; }
public void push ( char new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
void printList ( Node ptr ) { while ( ptr != null ) { Console . Write ( ptr . data + " - > " ) ; ptr = ptr . next ; } Console . WriteLine ( " NULL " ) ; }
LinkedList llist = new LinkedList ( ) ; char [ ] str = { ' a ' , ' b ' , ' a ' , ' c ' , ' a ' , ' b ' , ' a ' } ; for ( int i = 0 ; i < 7 ; i ++ ) { llist . push ( str [ i ] ) ; llist . printList ( llist . head ) ; if ( llist . isPalindrome ( llist . head ) != false ) { Console . WriteLine ( " Is ▁ Palindrome " ) ; Console . WriteLine ( " " ) ; } else { Console . WriteLine ( " Not ▁ Palindrome " ) ; Console . WriteLine ( " " ) ; } } } }
using System ; class Node { public int data ; public Node next ; public Node ( int d ) { data = d ; next = null ; } } public class LinkedList {
Node head ;
public void swapNodes ( int x , int y ) {
if ( x == y ) return ;
Node prevX = null , currX = head ; while ( currX != null && currX . data != x ) { prevX = currX ; currX = currX . next ; }
Node prevY = null , currY = head ; while ( currY != null && currY . data != y ) { prevY = currY ; currY = currY . next ; }
if ( currX == null currY == null ) return ;
if ( prevX != null ) prevX . next = currY ;
else head = currY ;
if ( prevY != null ) prevY . next = currX ;
else head = currX ;
Node temp = currX . next ; currX . next = currY . next ; currY . next = temp ; }
public void push ( int new_data ) {
Node new_Node = new Node ( new_data ) ;
new_Node . next = head ;
head = new_Node ; }
public void printList ( ) { Node tNode = head ; while ( tNode != null ) { Console . Write ( tNode . data + " ▁ " ) ; tNode = tNode . next ; } }
llist . push ( 7 ) ; llist . push ( 6 ) ; llist . push ( 5 ) ; llist . push ( 4 ) ; llist . push ( 3 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; Console . Write ( " swapNodes ( ) " llist . printList ( ) ; llist . swapNodes ( 4 , 3 ) ; Console . Write ( " swapNodes ( ) " llist . printList ( ) ; } }
public class Node { public int data ; public Node next ; }
static bool isCircular ( Node head ) {
if ( head == null ) return true ;
Node node = head . next ;
while ( node != null && node != head ) node = node . next ;
return ( node == head ) ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . next = null ; return temp ; }
Node head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; Console . Write ( isCircular ( head ) ? " Yes STRNEWLINE " : " No STRNEWLINE " ) ;
head . next . next . next . next = head ; Console . Write ( isCircular ( head ) ? " Yes STRNEWLINE " : " No STRNEWLINE " ) ; } }
static Node addToEmpty ( Node last , int data ) {
if ( last != null ) return last ;
Node temp = new Node ( ) ;
temp . data = data ; last = temp ;
temp . next = last ; return last ; }
static Node addBegin ( Node last , int data ) { if ( last == null ) return addToEmpty ( last , data ) ;
Node temp = new Node ( ) ;
temp . data = data ;
temp . next = last . next ; last . next = temp ; return last ; }
class Node { public int data ; public Node next ; public Node ( int data ) { this . data = data ; } }
static void getJosephusPosition ( int m , int n ) {
Node head = new Node ( 1 ) ; Node prev = head ; for ( int i = 2 ; i <= n ; i ++ ) { prev . next = new Node ( i ) ; prev = prev . next ; }
prev . next = head ;
Node ptr1 = head , ptr2 = head ; while ( ptr1 . next != ptr1 ) {
int count = 1 ; while ( count != m ) { ptr2 = ptr1 ; ptr1 = ptr1 . next ; count ++ ; }
ptr2 . next = ptr1 . next ; ptr1 = ptr2 . next ; } Console . WriteLine ( " Last ▁ person ▁ left ▁ standing ▁ " + " ( Josephus ▁ Position ) ▁ is ▁ " + ptr1 . data ) ; }
static public void Main ( String [ ] args ) { int n = 14 , m = 2 ; getJosephusPosition ( m , n ) ; } }
using System ; public class Node { public int data ; public Node next ; public Node ( int d ) { data = d ; next = null ; } } public class LinkedList { Node head ;
void push ( int new_data ) { Node new_node = new Node ( new_data ) ; new_node . next = head ; head = new_node ; }
void printList ( ) { Node node = head ; while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . next ; } Console . WriteLine ( " " ) ; }
int countNodes ( ) { int count = 0 ; Node s = head ; while ( s != null ) { count ++ ; s = s . next ; } return count ; }
void swapKth ( int k ) {
int n = countNodes ( ) ;
if ( n < k ) return ;
if ( 2 * k - 1 == n ) return ;
Node x = head ; Node x_prev = null ; for ( int i = 1 ; i < k ; i ++ ) { x_prev = x ; x = x . next ; }
Node y = head ; Node y_prev = null ; for ( int i = 1 ; i < n - k + 1 ; i ++ ) { y_prev = y ; y = y . next ; }
if ( x_prev != null ) x_prev . next = y ;
if ( y_prev != null ) y_prev . next = x ;
Node temp = x . next ; x . next = y . next ; y . next = temp ;
if ( k == 1 ) head = y ; if ( k == n ) head = x ; }
public static void Main ( String [ ] args ) { LinkedList llist = new LinkedList ( ) ; for ( int i = 8 ; i >= 1 ; i -- ) llist . push ( i ) ; Console . Write ( " Original ▁ linked ▁ list : ▁ " ) ; llist . printList ( ) ; Console . WriteLine ( " " ) ; for ( int i = 1 ; i < 9 ; i ++ ) { llist . swapKth ( i ) ; Console . WriteLine ( " Modified ▁ List ▁ for ▁ k ▁ = ▁ " + i ) ; llist . printList ( ) ; Console . WriteLine ( " " ) ; } } }
class Node { public int data ; public Node next , prev ; } ;
static int countPairs ( Node first , Node second , int value ) { int count = 0 ;
while ( first != null && second != null && first != second && second . next != first ) {
if ( ( first . data + second . data ) == value ) {
count ++ ;
first = first . next ;
second = second . prev ; }
else if ( ( first . data + second . data ) > ) = second . prev ;
else first = first . next ; }
return count ; }
static int countTriplets ( Node head , int x ) {
if ( head == null ) return 0 ; Node current , first , last ; int count = 0 ;
last = head ; while ( last . next != null ) last = last . next ;
for ( current = head ; current != null ; current = current . next ) {
first = current . next ;
count += countPairs ( first , last , x - current . data ) ; }
return count ; }
static Node insert ( Node head , int data ) {
Node temp = new Node ( ) ;
temp . data = data ; temp . next = temp . prev = null ; if ( ( head ) == null ) ( head ) = temp ; else { temp . next = head ; ( head ) . prev = temp ; ( head ) = temp ; } return head ; }
Node head = null ;
head = insert ( head , 9 ) ; head = insert ( head , 8 ) ; head = insert ( head , 6 ) ; head = insert ( head , 5 ) ; head = insert ( head , 4 ) ; head = insert ( head , 2 ) ; head = insert ( head , 1 ) ; int x = 17 ; Console . Write ( " Count ▁ = ▁ " + countTriplets ( head , x ) ) ; } }
using System ; class GFG {
static Node deleteNode ( Node head_ref , Node del ) {
if ( head_ref == null del == null ) return head_ref ;
if ( head_ref == del ) head_ref = del . next ;
if ( del . next != null ) del . next . prev = del . prev ;
if ( del . prev != null ) del . prev . next = del . next ; return head_ref ; }
static Node removeDuplicates ( Node head_ref ) {
if ( ( head_ref ) == null || ( head_ref ) . next == null ) return head_ref ; ; Node ptr1 , ptr2 ;
for ( ptr1 = head_ref ; ptr1 != null ; ptr1 = ptr1 . next ) { ptr2 = ptr1 . next ;
while ( ptr2 != null ) {
if ( ptr1 . data == ptr2 . data ) {
Node next = ptr2 . next ;
head_ref = deleteNode ( head_ref , ptr2 ) ;
ptr2 = next ; }
else ptr2 = ptr2 . next ; } } return head_ref ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . prev = null ;
new_node . next = ( head_ref ) ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
static void printList ( Node head ) {
if ( head == null ) Console . Write ( " Doubly ▁ Linked ▁ list ▁ empty " ) ; while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; head = head . next ; } }
public static void Main ( String [ ] args ) { Node head = null ;
head = push ( head , 12 ) ; head = push ( head , 12 ) ; head = push ( head , 10 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 4 ) ; head = push ( head , 6 ) ; head = push ( head , 4 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; Console . Write ( " Original ▁ Doubly ▁ linked ▁ list : STRNEWLINE " ) ; printList ( head ) ;
head = removeDuplicates ( head ) ; Console . Write ( " STRNEWLINE Doubly ▁ linked ▁ list ▁ after " + " ▁ removing ▁ duplicates : STRNEWLINE " ) ; printList ( head ) ; } }
using System ; using System . Collections . Generic ; class GFG {
public class Node { public int data ; public Node next ; public Node prev ; } ;
static Node deleteNode ( Node head_ref , Node del ) {
if ( head_ref == null del == null ) return null ;
if ( head_ref == del ) head_ref = del . next ;
if ( del . next != null ) del . next . prev = del . prev ;
if ( del . prev != null ) del . prev . next = del . next ; return head_ref ; }
static Node removeDuplicates ( Node head_ref ) {
if ( ( head_ref ) == null ) return null ;
HashSet < int > us = new HashSet < int > ( ) ; Node current = head_ref , next ;
while ( current != null ) {
if ( us . Contains ( current . data ) ) {
next = current . next ;
head_ref = deleteNode ( head_ref , current ) ;
current = next ; } else {
us . Add ( current . data ) ;
current = current . next ; } } return head_ref ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . prev = null ;
new_node . next = ( head_ref ) ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
static void printList ( Node head ) {
if ( head == null ) Console . Write ( " Doubly ▁ Linked ▁ list ▁ empty " ) ; while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; head = head . next ; } }
public static void Main ( String [ ] args ) { Node head = null ;
head = push ( head , 12 ) ; head = push ( head , 12 ) ; head = push ( head , 10 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 4 ) ; head = push ( head , 6 ) ; head = push ( head , 4 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; Console . WriteLine ( " Original ▁ Doubly ▁ linked ▁ list : " ) ; printList ( head ) ;
head = removeDuplicates ( head ) ; Console . WriteLine ( " STRNEWLINE Doubly ▁ linked ▁ list ▁ after ▁ " + " removing ▁ duplicates : " ) ; printList ( head ) ; } }
public class Node { public int data ; public Node next ; public Node prev ; }
static Node reverse ( Node head_ref ) { Node temp = null ; Node current = head_ref ;
while ( current != null ) { temp = current . prev ; current . prev = current . next ; current . next = temp ; current = current . prev ; }
if ( temp != null ) head_ref = temp . prev ; return head_ref ; }
static Node merge ( Node first , Node second ) {
if ( first == null ) return second ;
if ( second == null ) return first ;
if ( first . data < second . data ) { first . next = merge ( first . next , second ) ; first . next . prev = first ; first . prev = null ; return first ; } else { second . next = merge ( first , second . next ) ; second . next . prev = second ; second . prev = null ; return second ; } }
static Node sort ( Node head ) {
if ( head == null head . next == null ) return head ; Node current = head . next ; while ( current != null ) {
if ( current . data < current . prev . data ) break ;
current = current . next ; }
if ( current == null ) return head ;
current . prev . next = null ; current . prev = null ;
current = reverse ( current ) ;
return merge ( head , current ) ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . prev = null ;
new_node . next = ( head_ref ) ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
static void printList ( Node head ) {
if ( head == null ) Console . WriteLine ( " Doubly ▁ Linked ▁ list ▁ empty " ) ; while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; head = head . next ; } }
public static void Main ( String [ ] args ) { Node head = null ;
head = push ( head , 1 ) ; head = push ( head , 4 ) ; head = push ( head , 6 ) ; head = push ( head , 10 ) ; head = push ( head , 12 ) ; head = push ( head , 7 ) ; head = push ( head , 5 ) ; head = push ( head , 2 ) ; Console . WriteLine ( " Original ▁ Doubly ▁ linked ▁ list : n " ) ; printList ( head ) ;
head = sort ( head ) ; Console . WriteLine ( " STRNEWLINE Doubly ▁ linked ▁ list ▁ after ▁ sorting : n " ) ; printList ( head ) ; } }
public class Node { public int info ; public Node prev , next ; } class GFG { static Node head , tail ;
static void nodeInsetail ( int key ) { Node p = new Node ( ) ; p . info = key ; p . next = null ;
if ( head == null ) { head = p ; tail = p ; head . prev = null ; return ; }
if ( p . info < head . info ) { p . prev = null ; head . prev = p ; p . next = head ; head = p ; return ; }
if ( p . info > tail . info ) { p . prev = tail ; tail . next = p ; tail = p ; return ; }
Node temp = head . next ; while ( temp . info < p . info ) temp = temp . next ;
( temp . prev ) . next = p ; p . prev = temp . prev ; temp . prev = p ; p . next = temp ; }
static void printList ( Node temp ) { while ( temp != null ) { Console . Write ( temp . info + " ▁ " ) ; temp = temp . next ; } }
public static void Main ( String [ ] args ) { head = tail = null ; nodeInsetail ( 30 ) ; nodeInsetail ( 50 ) ; nodeInsetail ( 90 ) ; nodeInsetail ( 10 ) ; nodeInsetail ( 40 ) ; nodeInsetail ( 110 ) ; nodeInsetail ( 60 ) ; nodeInsetail ( 95 ) ; nodeInsetail ( 23 ) ; Console . WriteLine ( " Doubly ▁ linked ▁ list ▁ on ▁ printing ▁ from ▁ left ▁ to ▁ right " ) ; printList ( head ) ; } }
static void insertEnd ( int value ) { Node new_node ;
if ( start == null ) { new_node = new Node ( ) ; new_node . data = value ; new_node . next = new_node . prev = new_node ; start = new_node ; return ; }
Node last = ( start ) . prev ;
new_node = new Node ( ) ; new_node . data = value ;
new_node . next = start ;
( start ) . prev = new_node ;
new_node . prev = last ;
last . next = new_node ; }
public class Node { public int data ; public Node next ; } ;
static int findDepthRec ( char [ ] tree , int n , int index ) { if ( index >= n tree [ index ] == ' l ' ) return 0 ;
index ++ ; int left = findDepthRec ( tree , n , index ) ;
index ++ ; int right = findDepthRec ( tree , n , index ) ; return Math . Max ( left , right ) + 1 ; }
static int findDepth ( char [ ] tree , int n ) { int index = 0 ; return ( findDepthRec ( tree , n , index ) ) ; }
static public void Main ( ) { char [ ] tree = " nlnnlll " . ToCharArray ( ) ; int n = tree . Length ; Console . WriteLine ( findDepth ( tree , n ) ) ; } }
public class Node { public char data ; public Node next ; }
static Node newNode ( char key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static void printlist ( Node head ) { if ( head == null ) { Console . WriteLine ( " Empty ▁ List " ) ; return ; } while ( head != null ) { Console . Write ( head . data + " ▁ " ) ; if ( head . next != null ) Console . Write ( " - > ▁ " ) ; head = head . next ; } Console . WriteLine ( ) ; }
static bool isVowel ( char x ) { return ( x == ' a ' x == ' e ' x == ' i ' x == ' o ' x == ' u ' ) ; }
static Node arrange ( Node head ) { Node newHead = head ;
Node latestVowel ; Node curr = head ;
if ( head == null ) return null ;
if ( isVowel ( head . data ) == true )
latestVowel = head ; else {
while ( curr . next != null && ! isVowel ( curr . next . data ) ) curr = curr . next ;
if ( curr . next == null ) return head ;
latestVowel = newHead = curr . next ; curr . next = curr . next . next ; latestVowel . next = head ; }
while ( curr != null && curr . next != null ) { if ( isVowel ( curr . next . data ) == true ) {
if ( curr == latestVowel ) {
latestVowel = curr = curr . next ; } else {
Node temp = latestVowel . next ;
latestVowel . next = curr . next ;
latestVowel = latestVowel . next ;
curr . next = curr . next . next ;
latestVowel . next = temp ; } } else {
curr = curr . next ; } } return newHead ; }
public static void Main ( String [ ] args ) { Node head = newNode ( ' a ' ) ; head . next = newNode ( ' b ' ) ; head . next . next = newNode ( ' c ' ) ; head . next . next . next = newNode ( ' e ' ) ; head . next . next . next . next = newNode ( ' d ' ) ; head . next . next . next . next . next = newNode ( ' o ' ) ; head . next . next . next . next . next . next = newNode ( ' x ' ) ; head . next . next . next . next . next . next . next = newNode ( ' i ' ) ; Console . WriteLine ( " Linked ▁ list ▁ before ▁ : ▁ " ) ; printlist ( head ) ; head = arrange ( head ) ; Console . WriteLine ( " Linked ▁ list ▁ after ▁ : " ) ; printlist ( head ) ; } }
class Node { public int data ; public Node left , right ; public Node ( int x ) { data = x ; left = right = null ; } } class GFG { static int count = 0 ;
public static Node insert ( Node root , int x ) { if ( root == null ) return new Node ( x ) ; if ( x < root . data ) root . left = insert ( root . left , x ) ; else if ( x > root . data ) root . right = insert ( root . right , x ) ; return root ; }
public static Node kthSmallest ( Node root , int k ) {
if ( root == null ) return null ;
Node left = kthSmallest ( root . left , k ) ;
if ( left != null ) return left ;
count ++ ; if ( count == k ) return root ;
return kthSmallest ( root . right , k ) ; }
public static void printKthSmallest ( Node root , int k ) {
count = 0 ; Node res = kthSmallest ( root , k ) ; if ( res == null ) Console . WriteLine ( " There ▁ are ▁ less ▁ " + " than ▁ k ▁ nodes ▁ in ▁ the ▁ BST " ) ; else Console . WriteLine ( " K - th ▁ Smallest " + " ▁ Element ▁ is ▁ " + res . data ) ; }
public static void Main ( String [ ] args ) { Node root = null ; int [ ] keys = { 20 , 8 , 22 , 4 , 12 , 10 , 14 } ; foreach ( int x in keys ) root = insert ( root , x ) ; int k = 3 ; printKthSmallest ( root , k ) ; } }
using System ; using System . Collections . Generic ; public class TreeNode { public int val ; public TreeNode left ; public TreeNode right ; public TreeNode ( int x ) { val = x ; } } class GFG { static HashSet < TreeNode > set = new HashSet < TreeNode > ( ) ; static Stack < TreeNode > stack = new Stack < TreeNode > ( ) ;
public TreeNode buildTree ( int [ ] preorder , int [ ] inorder ) { TreeNode root = null ; for ( int pre = 0 , iN = 0 ; pre < preorder . Length ; ) { TreeNode node = null ; do { node = new TreeNode ( preorder [ pre ] ) ; if ( root == null ) { root = node ; } if ( stack . Count != 0 ) { if ( set . Contains ( stack . Peek ( ) ) ) { set . Remove ( stack . Peek ( ) ) ; stack . Pop ( ) . right = node ; } else { stack . Peek ( ) . left = node ; } } stack . Push ( node ) ; } while ( preorder [ pre ++ ] != inorder [ iN ] && pre < preorder . Length ) ; node = null ; while ( stack . Count != 0 && iN < inorder . Length && stack . Peek ( ) . val == inorder [ iN ] ) { node = stack . Pop ( ) ; iN ++ ; } if ( node != null ) { set . Add ( node ) ; stack . Push ( node ) ; } } return root ; }
void printInorder ( TreeNode node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
Console . Write ( node . val + " ▁ " ) ;
printInorder ( node . right ) ; }
public static void Main ( String [ ] args ) { GFG tree = new GFG ( ) ; int [ ] iN = new int [ ] { 9 , 8 , 4 , 2 , 10 , 5 , 10 , 1 , 6 , 3 , 13 , 12 , 7 } ; int [ ] pre = new int [ ] { 1 , 2 , 4 , 8 , 9 , 5 , 10 , 10 , 3 , 6 , 7 , 12 , 13 } ; int len = iN . Length ; TreeNode root = tree . buildTree ( pre , iN ) ; tree . printInorder ( root ) ; } }
public class Node { public int data ; public Node left , right ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . right = null ; temp . left = null ; return temp ; } static Node KthLargestUsingMorrisTraversal ( Node root , int k ) { Node curr = root ; Node Klargest = null ;
int count = 0 ; while ( curr != null ) {
if ( curr . right == null ) {
if ( ++ count == k ) Klargest = curr ;
curr = curr . left ; } else {
Node succ = curr . right ; while ( succ . left != null && succ . left != curr ) succ = succ . left ; if ( succ . left == null ) {
succ . left = curr ;
curr = curr . right ; }
else { succ . left = null ; if ( ++ count == k ) Klargest = curr ;
curr = curr . left ; } } } return Klargest ; }
Node root = newNode ( 4 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 7 ) ; root . left . left = newNode ( 1 ) ; root . left . right = newNode ( 3 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 10 ) ; Console . Write ( " Finding ▁ K - th ▁ largest ▁ Node ▁ in ▁ BST ▁ : ▁ " + KthLargestUsingMorrisTraversal ( root , 2 ) . data ) ; } }
public class Node { public int key ; public Node left , right ; }
static int KSmallestUsingMorris ( Node root , int k ) {
int count = 0 ;
int ksmall = int . MinValue ;
Node curr = root ; while ( curr != null ) {
if ( curr . left == null ) { count ++ ;
if ( count == k ) ksmall = curr . key ;
curr = curr . right ; } else {
Node pre = curr . left ; while ( pre . right != null && pre . right != curr ) pre = pre . right ;
if ( pre . right == null ) {
pre . right = curr ; curr = curr . left ; }
else {
pre . right = null ; count ++ ;
if ( count == k ) ksmall = curr . key ; curr = curr . right ; } } }
return ksmall ; }
static Node newNode ( int item ) { Node temp = new Node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; return temp ; }
static Node insert ( Node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else if ( key > node . key ) node . right = insert ( node . right , key ) ;
return node ; }
Node root = null ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ; for ( int k = 1 ; k <= 7 ; k ++ ) Console . Write ( KSmallestUsingMorris ( root , k ) + " ▁ " ) ; } }
static bool isInorder ( int [ ] arr , int n ) {
if ( n == 0 n == 1 ) { return true ; }
for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i - 1 ] > arr [ i ] ) { return false ; } }
return true ; }
public static void Main ( ) { int [ ] arr = { 19 , 23 , 25 , 30 , 45 } ; int n = arr . Length ; if ( isInorder ( arr , n ) ) { Console . Write ( " Yes " ) ; } else { Console . Write ( " Non " ) ; } } }
class Node { public int data ; public Node left ; public Node right ; } ;
static Node newNode ( int val ) { Node temp = new Node ( ) ; temp . data = val ; temp . left = temp . right = null ; return temp ; }
static void storeInorder ( Node root , List < int > v ) { if ( root == null ) return ; storeInorder ( root . left , v ) ; v . Add ( root . data ) ; storeInorder ( root . right , v ) ; }
static bool checkBSTs ( Node root1 , Node root2 ) {
if ( root1 != null && root2 != null ) return true ; if ( ( root1 == null && root2 != null ) || ( root1 != null && root2 == null ) ) return false ;
List < int > v1 = new List < int > ( ) ; List < int > v2 = new List < int > ( ) ; storeInorder ( root1 , v1 ) ; storeInorder ( root2 , v2 ) ;
return ( v1 == v2 ) ; }
Node root1 = newNode ( 15 ) ; root1 . left = newNode ( 10 ) ; root1 . right = newNode ( 20 ) ; root1 . left . left = newNode ( 5 ) ; root1 . left . right = newNode ( 12 ) ; root1 . right . right = newNode ( 25 ) ;
Node root2 = newNode ( 15 ) ; root2 . left = newNode ( 12 ) ; root2 . right = newNode ( 20 ) ; root2 . left . left = newNode ( 5 ) ; root2 . left . left . right = newNode ( 10 ) ; root2 . right . right = newNode ( 25 ) ;
if ( checkBSTs ( root1 , root2 ) ) Console . Write ( " YES " ) ; else Console . Write ( " NO " ) ; } }
class Node { public int key ; public Node left , right ; }
static Node newNode ( int item ) { Node temp = new Node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; return temp ; }
static Node insert ( Node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else if ( key > node . key ) node . right = insert ( node . right , key ) ;
return node ; }
static int findMaxforN ( Node root , int N ) {
if ( root == null ) return - 1 ; if ( root . key == N ) return N ;
else if ( root . key < N ) { int k = findMaxforN ( root . right , N ) ; if ( k == - 1 ) return root . key ; else return k ; }
else if ( root . key > N ) return findMaxforN ( root . left , N ) ; return - 1 ; }
public static void Main ( String [ ] args ) { int N = 4 ;
Node root = null ; root = insert ( root , 25 ) ; insert ( root , 2 ) ; insert ( root , 1 ) ; insert ( root , 3 ) ; insert ( root , 12 ) ; insert ( root , 9 ) ; insert ( root , 21 ) ; insert ( root , 19 ) ; insert ( root , 25 ) ; Console . WriteLine ( findMaxforN ( root , N ) ) ; } }
using System ; class GfG { public class Node { public Node left , right ; public int key ; } static Node newNode ( int key ) { Node ptr = new Node ( ) ; ptr . key = key ; ptr . left = null ; ptr . right = null ; return ptr ; }
static Node insert ( Node root , int key ) { if ( root == null ) root = newNode ( key ) ; else if ( root . key > key ) root . left = insert ( root . left , key ) ; else if ( root . key < key ) root . right = insert ( root . right , key ) ; return root ; }
static int distanceFromRoot ( Node root , int x ) { if ( root . key == x ) return 0 ; else if ( root . key > x ) return 1 + distanceFromRoot ( root . left , x ) ; return 1 + distanceFromRoot ( root . right , x ) ; }
static int distanceBetween2 ( Node root , int a , int b ) { if ( root == null ) return 0 ;
if ( root . key > a && root . key > b ) return distanceBetween2 ( root . left , a , b ) ;
if ( root . key < a && root . key < b ) return distanceBetween2 ( root . right , a , b ) ;
if ( root . key >= a && root . key <= b ) return distanceFromRoot ( root , a ) + distanceFromRoot ( root , b ) ; return 0 ; }
static int findDistWrapper ( Node root , int a , int b ) { int temp = 0 ; if ( a > b ) { temp = a ; a = b ; b = temp ; } return distanceBetween2 ( root , a , b ) ; }
public static void Main ( String [ ] args ) { Node root = null ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; Console . WriteLine ( findDistWrapper ( root , 5 , 35 ) ) ; } }
using System ; public class GfG { public class node { public int data ; public node left , right ; }
static void RangeTraversal ( node root , int n1 , int n2 ) { if ( root == null ) return ; node curr = root ; while ( curr != null ) { if ( curr . left == null ) {
if ( curr . data <= n2 && curr . data >= n1 ) { Console . Write ( curr . data + " ▁ " ) ; } curr = curr . right ; } else { node pre = curr . left ;
while ( pre . right != null && pre . right != curr ) pre = pre . right ; if ( pre . right == null ) { pre . right = curr ; curr = curr . left ; } else { pre . right = null ;
if ( curr . data <= n2 && curr . data >= n1 ) { Console . Write ( curr . data + " ▁ " ) ; } curr = curr . right ; } } } }
static node newNode ( int data ) { node temp = new node ( ) ; temp . data = data ; temp . right = null ; temp . left = null ; return temp ; }
node root = newNode ( 4 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 7 ) ; root . left . left = newNode ( 1 ) ; root . left . right = newNode ( 3 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 10 ) ; RangeTraversal ( root , 4 , 12 ) ; } }
public class node { public int data ; public node left , right ; } ;
public class INT { public int a ; }
static bool inRange ( node root , int low , int high ) { return root . data >= low && root . data <= high ; }
static bool getCountUtil ( node root , int low , int high , INT count ) {
if ( root == null ) return true ;
bool l = getCountUtil ( root . left , low , high , count ) ; bool r = getCountUtil ( root . right , low , high , count ) ;
if ( l && r && inRange ( root , low , high ) ) { ++ count . a ; return true ; } return false ; }
static INT getCount ( node root , int low , int high ) { INT count = new INT ( ) ; count . a = 0 ; getCountUtil ( root , low , high , count ) ; return count ; }
static node newNode ( int data ) { node temp = new node ( ) ; temp . data = data ; temp . left = temp . right = null ; return ( temp ) ; }
node root = newNode ( 10 ) ; root . left = newNode ( 5 ) ; root . right = newNode ( 50 ) ; root . left . left = newNode ( 1 ) ; root . right . left = newNode ( 40 ) ; root . right . right = newNode ( 100 ) ;
int l = 5 ; int h = 45 ; Console . WriteLine ( " Count ▁ of ▁ subtrees ▁ in ▁ [ " + l + " , ▁ " + h + " ] ▁ is ▁ " + getCount ( root , l , h ) . a ) ; } }
using System ; class GfG { class Node { public int data ; public Node left ; public Node right ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . left = null ; temp . right = null ; return temp ; }
static Node insert ( Node root , int data ) { if ( root == null ) return newNode ( data ) ; if ( data < root . data ) root . left = insert ( root . left , data ) ; else if ( data > root . data ) root . right = insert ( root . right , data ) ; return root ; }
static void inorder ( Node root ) { if ( root != null ) { inorder ( root . left ) ; Console . Write ( root . data + " ▁ " ) ; inorder ( root . right ) ; } }
static Node leafDelete ( Node root ) { if ( root == null ) { return null ; } if ( root . left == null && root . right == null ) { return null ; }
root . left = leafDelete ( root . left ) ; root . right = leafDelete ( root . right ) ; return root ; }
public static void Main ( String [ ] args ) { Node root = null ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; Console . WriteLine ( " Inorder ▁ before ▁ Deleting " + " the ▁ leaf ▁ Node . ▁ " ) ; inorder ( root ) ; Console . WriteLine ( ) ; leafDelete ( root ) ; Console . WriteLine ( " INorder ▁ after ▁ Deleting " + " the ▁ leaf ▁ Node . ▁ " ) ; inorder ( root ) ; } }
public class Node { public int data ; public Node left , right ; } ;
static Node createNode ( int data ) { Node new_Node = new Node ( ) ; new_Node . left = null ; new_Node . right = null ; new_Node . data = data ; return new_Node ; }
static Node insert ( Node root , int key ) {
if ( root == null ) return createNode ( key ) ;
if ( root . data > key ) root . left = insert ( root . left , key ) ; else if ( root . data < key ) root . right = insert ( root . right , key ) ;
return root ; } static int count = 0 ;
static int ksmallestElementSumRec ( Node root , int k ) {
if ( root == null ) return 0 ; if ( count > k ) return 0 ;
int res = ksmallestElementSumRec ( root . left , k ) ; if ( count >= k ) return res ;
res += root . data ;
count ++ ; if ( count >= k ) return res ;
return res + ksmallestElementSumRec ( root . right , k ) ; }
static int ksmallestElementSum ( Node root , int k ) { int res = ksmallestElementSumRec ( root , k ) ; return res ; }
Node root = null ; root = insert ( root , 20 ) ; root = insert ( root , 8 ) ; root = insert ( root , 4 ) ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 14 ) ; root = insert ( root , 22 ) ; int k = 3 ; int count = ksmallestElementSum ( root , k ) ; Console . WriteLine ( count ) ; } }
public class Node { public int data ; public Node left , right , parent ; public Node ( int d ) { data = d ; left = right = parent = null ; } } public class BinaryTree { static Node head ;
Node insert ( Node node , int data ) {
if ( node == null ) { return ( new Node ( data ) ) ; } else { Node temp = null ;
if ( data <= node . data ) { temp = insert ( node . left , data ) ; node . left = temp ; temp . parent = node ; } else { temp = insert ( node . right , data ) ; node . right = temp ; temp . parent = node ; }
return node ; } } Node inOrderSuccessor ( Node root , Node n ) {
if ( n . right != null ) { return minValue ( n . right ) ; }
Node p = n . parent ; while ( p != null && n == p . right ) { n = p ; p = p . parent ; } return p ; }
Node minValue ( Node node ) { Node current = node ;
while ( current . left != null ) { current = current . left ; } return current ; }
public static void Main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; Node root = null , temp = null , suc = null , min = null ; root = tree . insert ( root , 20 ) ; root = tree . insert ( root , 8 ) ; root = tree . insert ( root , 22 ) ; root = tree . insert ( root , 4 ) ; root = tree . insert ( root , 12 ) ; root = tree . insert ( root , 10 ) ; root = tree . insert ( root , 14 ) ; temp = root . left . right . right ; suc = tree . inOrderSuccessor ( root , temp ) ; if ( suc != null ) { Console . WriteLine ( " Inorder ▁ successor ▁ of ▁ " + temp . data + " ▁ is ▁ " + suc . data ) ; } else { Console . WriteLine ( " Inorder ▁ successor ▁ does ▁ not ▁ exist " ) ; } } }
class Node { public int key ; public Node left , right ; } ; static ; static ;
static void findPreSuc ( Node root , int key ) { if ( root == null ) return ;
while ( root != null ) {
if ( root . key == key ) {
if ( root . right != null ) { suc = root . right ; while ( suc . left != null ) suc = suc . left ; }
if ( root . left != null ) { pre = root . left ; while ( pre . right != null ) pre = pre . right ; } return ; }
else if ( root . key < key ) { = ; = root . right ; }
else { suc = root ; root = root . left ; } } }
static Node newNode ( int item ) { Node temp = new Node ( ) ; temp . key = item ; temp . left = temp . right = null ; return temp ; }
static Node insert ( Node node , int key ) { if ( node == null ) return newNode ( key ) ; if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ; return node ; }
int key = 65 ;
Node root = null ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ; findPreSuc ( root , key ) ; if ( pre != null ) Console . WriteLine ( " Predecessor ▁ is ▁ " + pre . key ) ; else Console . Write ( " - 1" ) ; if ( suc != null ) Console . Write ( " Successor ▁ is ▁ " + suc . key ) ; else Console . Write ( " - 1" ) ; } }
public class node { public int key ; public node left ; public node right ; } ; static ; static ;
static void convertBSTtoDLL ( node root ) {
if ( root == null ) return ;
if ( root . left != null ) convertBSTtoDLL ( root . left ) ;
root . left = tail ;
if ( tail != null ) ( tail ) . right = root ; else head = root ;
tail = root ;
if ( root . right != null ) convertBSTtoDLL ( root . right ) ; }
static bool isPresentInDLL ( node head , node tail , int sum ) { while ( head != tail ) { int curr = head . key + tail . key ; if ( curr == sum ) return true ; else if ( curr > sum ) tail = tail . left ; else head = head . right ; } return false ; }
static bool isTripletPresent ( node root ) {
if ( root == null ) return false ;
head = null ; tail = null ; convertBSTtoDLL ( root ) ;
while ( ( head . right != tail ) && ( head . key < 0 ) ) {
if ( isPresentInDLL ( head . right , tail , - 1 * head . key ) ) return true ; else head = head . right ; }
return false ; }
static node newNode ( int num ) { node temp = new node ( ) ; temp . key = num ; temp . left = temp . right = null ; return temp ; }
static node insert ( node root , int key ) { if ( root == null ) return newNode ( key ) ; if ( root . key > key ) root . left = insert ( root . left , key ) ; else root . right = insert ( root . right , key ) ; return root ; }
public static void Main ( String [ ] args ) { node root = null ; root = insert ( root , 6 ) ; root = insert ( root , - 13 ) ; root = insert ( root , 14 ) ; root = insert ( root , - 8 ) ; root = insert ( root , 15 ) ; root = insert ( root , 13 ) ; root = insert ( root , 7 ) ; if ( isTripletPresent ( root ) ) Console . Write ( " Present " ) ; else Console . Write ( " Not ▁ Present " ) ; } }
public class Solution { public class Node { public Node left , right ; public int data ; }
public static Node createNode ( int x ) { Node p = new Node ( ) ; p . data = x ; p . left = p . right = null ; return p ; }
public static void insertNode ( Node root , int x ) { Node p = root , q = null ; while ( p != null ) { q = p ; if ( p . data < x ) { p = p . right ; } else { p = p . left ; } } if ( q == null ) { p = createNode ( x ) ; } else { if ( q . data < x ) { q . right = createNode ( x ) ; } else { q . left = createNode ( x ) ; } } }
public static int maxelpath ( Node q , int x ) { Node p = q ; int mx = - 1 ;
while ( p . data != x ) { if ( p . data > x ) { mx = Math . Max ( mx , p . data ) ; p = p . left ; } else { mx = Math . Max ( mx , p . data ) ; p = p . right ; } } return Math . Max ( mx , x ) ; }
public static int maximumElement ( Node root , int x , int y ) { Node p = root ;
while ( ( x < p . data && y < p . data ) || ( x > p . data && y > p . data ) ) {
if ( x < p . data && y < p . data ) { p = p . left ; }
else if ( x > p . data && y > p . data ) { p = p . right ; } }
return Math . Max ( maxelpath ( p , x ) , maxelpath ( p , y ) ) ; }
public static void Main ( string [ ] args ) { int [ ] arr = new int [ ] { 18 , 36 , 9 , 6 , 12 , 10 , 1 , 8 } ; int a = 1 , b = 10 ; int n = arr . Length ;
Node root = createNode ( arr [ 0 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) { insertNode ( root , arr [ i ] ) ; } Console . WriteLine ( maximumElement ( root , a , b ) ) ; } }
public class Node { public int data ; public Node left , right ; public bool rightThread ; }
public class solution { public class Node { public Node left , right ; public int info ;
public bool lthread ;
public bool rthread ; }
public static Node insert ( Node root , int ikey ) {
Node ptr = root ;
Node par = null ; while ( ptr != null ) {
if ( ikey == ( ptr . info ) ) { Console . Write ( " Duplicate ▁ Key ▁ ! STRNEWLINE " ) ; return root ; }
par = ptr ;
if ( ikey < ptr . info ) { if ( ptr . lthread == false ) { ptr = ptr . left ; } else { break ; } }
else { if ( ptr . rthread == false ) { ptr = ptr . right ; } else { break ; } } }
Node tmp = new Node ( ) ; tmp . info = ikey ; tmp . lthread = true ; tmp . rthread = true ; if ( par == null ) { root = tmp ; tmp . left = null ; tmp . right = null ; } else if ( ikey < ( par . info ) ) { tmp . left = par . left ; tmp . right = par ; par . lthread = false ; par . left = tmp ; } else { tmp . left = par ; tmp . right = par . right ; par . rthread = false ; par . right = tmp ; } return root ; }
public static Node inorderSuccessor ( Node ptr ) {
if ( ptr . rthread == true ) { return ptr . right ; }
ptr = ptr . right ; while ( ptr . lthread == false ) { ptr = ptr . left ; } return ptr ; }
public static void inorder ( Node root ) { if ( root == null ) { Console . Write ( " Tree ▁ is ▁ empty " ) ; }
Node ptr = root ; while ( ptr . lthread == false ) { ptr = ptr . left ; }
while ( ptr != null ) { Console . Write ( " { 0 : D } ▁ " , ptr . info ) ; ptr = inorderSuccessor ( ptr ) ; } }
public static void Main ( string [ ] args ) { Node root = null ; root = insert ( root , 20 ) ; root = insert ( root , 10 ) ; root = insert ( root , 30 ) ; root = insert ( root , 5 ) ; root = insert ( root , 16 ) ; root = insert ( root , 14 ) ; root = insert ( root , 17 ) ; root = insert ( root , 13 ) ; inorder ( root ) ; } }
public class Node { public Node left , right ; public int info ;
public bool lthread ;
public bool rthread ; } ;
public class Node { public int key ; public Node left , right ;
public bool isThreaded ; }
public static Node createThreaded ( Node root ) {
if ( root == null ) { return null ; } if ( root . left == null && root . right == null ) { return root ; }
if ( root . left != null ) {
Node l = createThreaded ( root . left ) ;
l . right = root ; l . isThreaded = true ; }
if ( root . right == null ) { return root ; }
return createThreaded ( root . right ) ; }
public static Node leftMost ( Node root ) { while ( root != null && root . left != null ) { root = root . left ; } return root ; }
public static void inOrder ( Node root ) { if ( root == null ) { return ; }
Node cur = leftMost ( root ) ; while ( cur != null ) { Console . Write ( cur . key + " ▁ " ) ;
if ( cur . isThreaded ) { cur = cur . right ; }
else { cur = leftMost ( cur . right ) ; } } }
public static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . left = temp . right = null ; temp . key = key ; return temp ; }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 7 ) ; createThreaded ( root ) ; Console . WriteLine ( " Inorder ▁ traversal ▁ of ▁ created ▁ " + " threaded ▁ tree ▁ is STRNEWLINE " ) ; inOrder ( root ) ; } }
class Node { public int key ; public Node left , right , parent ; public Node ( int key ) { this . key = key ; left = right = parent = null ; } } class BinaryTree { Node root ;
Node insert ( Node node , int key ) {
if ( node == null ) return new Node ( key ) ;
if ( key < node . key ) { node . left = insert ( node . left , key ) ; node . left . parent = node ; } else if ( key > node . key ) { node . right = insert ( node . right , key ) ; node . right . parent = node ; }
return node ; }
void inorder ( Node root ) { Boolean leftdone = false ;
while ( root != null ) {
if ( ! leftdone ) { while ( root . left != null ) { root = root . left ; } }
Console . Write ( root . key + " ▁ " ) ;
leftdone = true ;
if ( root . right != null ) { leftdone = false ; root = root . right ; }
else if ( root . parent != null ) {
while ( root . parent != null && root == root . parent . right ) root = root . parent ; if ( root . parent == null ) break ; root = root . parent ; } else break ; } }
static public void Main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = tree . insert ( tree . root , 24 ) ; tree . root = tree . insert ( tree . root , 27 ) ; tree . root = tree . insert ( tree . root , 29 ) ; tree . root = tree . insert ( tree . root , 34 ) ; tree . root = tree . insert ( tree . root , 14 ) ; tree . root = tree . insert ( tree . root , 4 ) ; tree . root = tree . insert ( tree . root , 10 ) ; tree . root = tree . insert ( tree . root , 22 ) ; tree . root = tree . insert ( tree . root , 13 ) ; tree . root = tree . insert ( tree . root , 3 ) ; tree . root = tree . insert ( tree . root , 2 ) ; tree . root = tree . insert ( tree . root , 6 ) ; Console . WriteLine ( " Inorder ▁ traversal ▁ is ▁ " ) ; tree . inorder ( tree . root ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int d ) { data = d ; left = right = null ; } } public class BinaryTree { public static Node root ;
public virtual int Ceil ( Node node , int input ) {
if ( node == null ) { return - 1 ; }
if ( node . data == input ) { return node . data ; }
if ( node . data < input ) { return Ceil ( node . right , input ) ; }
int ceil = Ceil ( node . left , input ) ; return ( ceil >= input ) ? ceil : node . data ; }
public static void Main ( string [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; BinaryTree . root = new Node ( 8 ) ; BinaryTree . root . left = new Node ( 4 ) ; BinaryTree . root . right = new Node ( 12 ) ; BinaryTree . root . left . left = new Node ( 2 ) ; BinaryTree . root . left . right = new Node ( 6 ) ; BinaryTree . root . right . left = new Node ( 10 ) ; BinaryTree . root . right . right = new Node ( 14 ) ; for ( int i = 0 ; i < 16 ; i ++ ) { Console . WriteLine ( i + " ▁ " + tree . Ceil ( root , i ) ) ; } } }
using System ; class GFG { public class node { public int key ; public int count ; public node left , right ; } ;
static node newNode ( int item ) { node temp = new node ( ) ; temp . key = item ; temp . left = temp . right = null ; temp . count = 1 ; return temp ; }
static void inorder ( node root ) { if ( root != null ) { inorder ( root . left ) ; Console . Write ( root . key + " ( " + root . count + " ) ▁ " ) ; inorder ( root . right ) ; } }
static node insert ( node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key == node . key ) { ( node . count ) ++ ; return node ; }
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
return node ; }
static node minValueNode ( node node ) { node current = node ;
while ( current . left != null ) current = current . left ; return current ; }
static node deleteNode ( node root , int key ) {
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . count > 1 ) { ( root . count ) -- ; return root ; }
node temp = null ; if ( root . left == null ) { temp = root . right ; root = null ; return temp ; } else if ( root . right == null ) { temp = root . left ; root = null ; return temp ; }
temp = minValueNode ( root . right ) ;
root . key = temp . key ;
root . right = deleteNode ( root . right , temp . key ) ; } return root ; }
node root = null ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 20 ) ; root = insert ( root , 9 ) ; root = insert ( root , 11 ) ; root = insert ( root , 10 ) ; root = insert ( root , 12 ) ; root = insert ( root , 12 ) ; Console . Write ( " Inorder ▁ traversal ▁ of ▁ " + " the ▁ given ▁ tree ▁ " + " STRNEWLINE " ) ; inorder ( root ) ; Console . Write ( " STRNEWLINE Delete ▁ 20 STRNEWLINE " ) ; root = deleteNode ( root , 20 ) ; Console . Write ( " Inorder ▁ traversal ▁ of ▁ " + " the ▁ modified ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; Console . Write ( " STRNEWLINE Delete ▁ 12 STRNEWLINE " ) ; root = deleteNode ( root , 12 ) ; Console . Write ( " Inorder ▁ traversal ▁ of ▁ " + " the ▁ modified ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; Console . Write ( " STRNEWLINE Delete ▁ 9 STRNEWLINE " ) ; root = deleteNode ( root , 9 ) ; Console . Write ( " Inorder ▁ traversal ▁ of ▁ " + " the ▁ modified ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; } }
using System ; class GFG { public class node { public int key ; public node left , right ; } static node root = null ;
static node newNode ( int item ) { node temp = new node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; return temp ; }
static void inorder ( node root ) { if ( root != null ) { inorder ( root . left ) ; Console . Write ( root . key + " ▁ " ) ; inorder ( root . right ) ; } }
static node insert ( node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
return node ; }
static node minValueNode ( node Node ) { node current = Node ;
while ( current . left != null ) current = current . left ; return current ; }
static node deleteNode ( node root , int key ) { node temp = null ;
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . left == null ) { temp = root . right ; return temp ; } else if ( root . right == null ) { temp = root . left ; return temp ; }
temp = minValueNode ( root . right ) ;
root . key = temp . key ;
root . right = deleteNode ( root . right , temp . key ) ; } return root ; }
static node changeKey ( node root , int oldVal , int newVal ) {
root = deleteNode ( root , oldVal ) ;
root = insert ( root , newVal ) ;
return root ; }
root = insert ( root , 50 ) ; root = insert ( root , 30 ) ; root = insert ( root , 20 ) ; root = insert ( root , 40 ) ; root = insert ( root , 70 ) ; root = insert ( root , 60 ) ; root = insert ( root , 80 ) ; Console . WriteLine ( " Inorder ▁ traversal ▁ " + " of ▁ the ▁ given ▁ tree ▁ " ) ; inorder ( root ) ; root = changeKey ( root , 40 , 10 ) ;
Console . WriteLine ( " STRNEWLINE Inorder ▁ traversal ▁ " + " of ▁ the ▁ modified ▁ tree " ) ; inorder ( root ) ; } }
using System ; class GFG { static int i = 0 ;
static bool isLeaf ( int [ ] pre , int n , int min , int max ) { if ( i >= n ) { return false ; } if ( pre [ i ] > min && pre [ i ] < max ) { i ++ ; bool left = isLeaf ( pre , n , min , pre [ i - 1 ] ) ; bool right = isLeaf ( pre , n , pre [ i - 1 ] , max ) ; if ( ! left && ! right ) { Console . Write ( pre [ i - 1 ] + " ▁ " ) ; } return true ; } return false ; } static void printLeaves ( int [ ] preorder , int n ) { isLeaf ( preorder , n , int . MinValue , int . MaxValue ) ; }
public static void Main ( String [ ] args ) { int [ ] preorder = { 890 , 325 , 290 , 530 , 965 } ; int n = preorder . Length ; printLeaves ( preorder , n ) ; } }
class Node { public int key ; public Node left , right , parent ; }
static Node newNode ( int item ) { Node temp = new Node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; temp . parent = null ; return temp ; }
static void inorder ( Node root ) { if ( root != null ) { inorder ( root . left ) ; Console . Write ( " Node ▁ : ▁ " + root . key + " ▁ , ▁ " ) ; if ( root . parent == null ) Console . WriteLine ( " Parent ▁ : ▁ NULL " ) ; else Console . WriteLine ( " Parent ▁ : ▁ " + root . parent . key ) ; inorder ( root . right ) ; } }
static Node insert ( Node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) { Node lchild = insert ( node . left , key ) ; node . left = lchild ;
lchild . parent = node ; } else if ( key > node . key ) { Node rchild = insert ( node . right , key ) ; node . right = rchild ;
rchild . parent = node ; }
return node ; }
Node root = null ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ;
inorder ( root ) ; } }
static void pairs ( int [ ] arr , int n , int k ) {
int smallest = 0 ; int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
if ( Math . Abs ( arr [ i ] + arr [ j ] - k ) < smallest ) { smallest = Math . Abs ( arr [ i ] + arr [ j ] - k ) ; count = 1 ; }
else if ( Math . Abs ( arr [ i ] + arr [ j ] - k ) == smallest ) ++ ; }
Console . WriteLine ( " Minimal ▁ Value ▁ = ▁ " + smallest ) ; Console . WriteLine ( " Total ▁ Pairs ▁ = ▁ " + count ) ; }
public static void Main ( ) { int [ ] arr = { 3 , 5 , 7 , 5 , 1 , 9 , 9 } ; int k = 12 ; int n = arr . Length ; pairs ( arr , n , k ) ; } }
public static void Main ( ) { int [ ] a = { 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 } ; int key = 20 ; int arraySize = a . Length ; int count = 0 ; for ( int i = 0 ; i < arraySize ; i ++ ) { if ( a [ i ] <= key ) { count += 1 ; } } Console . WriteLine ( " Rank ▁ of ▁ " + key + " ▁ in ▁ stream ▁ is : ▁ " + ( count - 1 ) ) ; } }
using System ; public class Node { public int info ; public Node left , right ; public Node ( int d ) { info = d ; left = right = null ; } } public class BinaryTree { public static Node head ; public static int count ;
public Node insert ( Node node , int info ) {
if ( node == null ) { return ( new Node ( info ) ) ; } else {
if ( info <= node . info ) { node . left = insert ( node . left , info ) ; } else { node . right = insert ( node . right , info ) ; } }
return node ; }
static int check ( int num ) { int sum = 0 , i = num , sum_of_digits , prod_of_digits ;
if ( num < 10 num > 99 ) { return 0 ; } else { sum_of_digits = ( i % 10 ) + ( i / 10 ) ; prod_of_digits = ( i % 10 ) * ( i / 10 ) ; sum = sum_of_digits + prod_of_digits ; } if ( sum == num ) { return 1 ; } else { return 0 ; } }
static void countSpecialDigit ( Node rt ) { int x ; if ( rt == null ) { return ; } else { x = check ( rt . info ) ; if ( x == 1 ) { count = count + 1 ; } countSpecialDigit ( rt . left ) ; countSpecialDigit ( rt . right ) ; } }
static public void Main ( ) { BinaryTree tree = new BinaryTree ( ) ; Node root = null ; root = tree . insert ( root , 50 ) ; tree . insert ( root , 29 ) ; tree . insert ( root , 59 ) ; tree . insert ( root , 19 ) ; tree . insert ( root , 53 ) ; tree . insert ( root , 556 ) ; tree . insert ( root , 56 ) ; tree . insert ( root , 94 ) ; tree . insert ( root , 13 ) ;
countSpecialDigit ( root ) ; Console . WriteLine ( count ) ; } }
using System ; class GFG { static int MAX = 100 ; static void middlesum ( int [ , ] mat , int n ) { int row_sum = 0 , col_sum = 0 ;
for ( int i = 0 ; i < n ; i ++ ) row_sum += mat [ n / 2 , i ] ; Console . WriteLine ( " Sum ▁ of ▁ middle ▁ row ▁ = ▁ " + row_sum ) ;
for ( int i = 0 ; i < n ; i ++ ) col_sum += mat [ i , n / 2 ] ; Console . WriteLine ( " Sum ▁ of ▁ middle ▁ column ▁ = ▁ " + col_sum ) ; }
public static void Main ( ) { int [ , ] mat = { { 2 , 5 , 7 } , { 3 , 7 , 2 } , { 5 , 6 , 9 } } ; middlesum ( mat , 3 ) ; } }
static int M = 3 ; static int N = 3 ;
static void rotateMatrix ( int [ , ] matrix , int k ) {
int [ ] temp = new int [ M ] ;
k = k % M ; for ( int i = 0 ; i < N ; i ++ ) {
for ( int t = 0 ; t < M - k ; t ++ ) temp [ t ] = matrix [ i , t ] ;
for ( int j = M - k ; j < M ; j ++ ) matrix [ i , j - M + k ] = matrix [ i , j ] ;
for ( int j = k ; j < M ; j ++ ) matrix [ i , j ] = temp [ j - k ] ; } }
static void displayMatrix ( int [ , ] matrix ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) Console . Write ( matrix [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] matrix = { { 12 , 23 , 34 } , { 45 , 56 , 67 } , { 78 , 89 , 91 } } ; int k = 2 ;
rotateMatrix ( matrix , k ) ;
displayMatrix ( matrix ) ; } }
using System ; class GFG { public static void interchangeFirstLast ( int [ ] [ ] m ) { int rows = m . Length ;
for ( int i = 0 ; i < m [ 0 ] . Length ; i ++ ) { int t = m [ 0 ] [ i ] ; m [ 0 ] [ i ] = m [ rows - 1 ] [ i ] ; m [ rows - 1 ] [ i ] = t ; } }
int [ ] [ ] m = new int [ ] [ ] { new int [ ] { 8 , 9 , 7 , 6 } , new int [ ] { 4 , 7 , 6 , 5 } , new int [ ] { 3 , 2 , 1 , 8 } , new int [ ] { 9 , 9 , 7 , 7 } } ; interchangeFirstLast ( m ) ;
for ( int i = 0 ; i < m . Length ; i ++ ) { for ( int j = 0 ; j < m [ 0 ] . Length ; j ++ ) { Console . Write ( m [ i ] [ j ] + " ▁ " ) ; } Console . WriteLine ( ) ; } } }
public class Node { public int data ; public Node left , right ; public Node ( int data ) { this . data = data ; left = right = null ; } }
public virtual Node buildUtil ( int [ ] @in , int [ ] post , int inStrt , int inEnd , Index pIndex ) {
if ( inStrt > inEnd ) { return null ; }
Node node = new Node ( post [ pIndex . index ] ) ; ( pIndex . index ) -- ;
if ( inStrt == inEnd ) { return node ; }
int iIndex = search ( @in , inStrt , inEnd , node . data ) ;
node . right = buildUtil ( @in , post , iIndex + 1 , inEnd , pIndex ) ; node . left = buildUtil ( @in , post , inStrt , iIndex - 1 , pIndex ) ; return node ; }
public virtual int search ( int [ ] arr , int strt , int end , int value ) { int i ; for ( i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) { break ; } } return i ; }
public virtual void preOrder ( Node node ) { if ( node == null ) { return ; } Console . Write ( node . data + " ▁ " ) ; preOrder ( node . left ) ; preOrder ( node . right ) ; }
public static void Main ( string [ ] args ) { GFG tree = new GFG ( ) ; int [ ] @in = new int [ ] { 4 , 8 , 2 , 5 , 1 , 6 , 3 , 7 } ; int [ ] post = new int [ ] { 8 , 4 , 5 , 2 , 6 , 7 , 3 , 1 } ; int n = @in . Length ; Node root = tree . buildTree ( @in , post , n ) ; Console . WriteLine ( " Preorder ▁ of ▁ the ▁ constructed ▁ tree ▁ : ▁ " ) ; tree . preOrder ( root ) ; } }
using System ; class GFG { static int sortRowWise ( int [ , ] m ) {
for ( int i = 0 ; i < m . GetLength ( 0 ) ; i ++ ) {
for ( int j = 0 ; j < m . GetLength ( 1 ) ; j ++ ) {
for ( int k = 0 ; k < m . GetLength ( 1 ) - j - 1 ; k ++ ) { if ( m [ i , k ] > m [ i , k + 1 ] ) {
int t = m [ i , k ] ; m [ i , k ] = m [ i , k + 1 ] ; m [ i , k + 1 ] = t ; } } } }
for ( int i = 0 ; i < m . GetLength ( 0 ) ; i ++ ) { for ( int j = 0 ; j < m . GetLength ( 1 ) ; j ++ ) Console . Write ( m [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } return 0 ; }
public static void Main ( String [ ] args ) { int [ , ] m = { { 9 , 8 , 7 , 1 } , { 7 , 3 , 0 , 2 } , { 9 , 5 , 3 , 2 } , { 6 , 3 , 1 , 2 } } ; sortRowWise ( m ) ; } }
using System ; class GFG { static bool checkMarkov ( double [ , ] m ) {
for ( int i = 0 ; i < m . GetLength ( 0 ) ; i ++ ) {
double sum = 0 ; for ( int j = 0 ; j < m . GetLength ( 1 ) ; j ++ ) sum = sum + m [ i , j ] ; if ( sum != 1 ) return false ; } return true ; }
double [ , ] m = new double [ , ] { { 0 , 0 , 1 } , { 0.5 , 0 , 0.5 } , { 1 , 0 , 0 } } ;
if ( checkMarkov ( m ) ) Console . WriteLine ( " ▁ yes ▁ " ) ; else Console . WriteLine ( " ▁ no ▁ " ) ; } }
using System ; class GFG { static int N = 4 ;
static bool isDiagonalMatrix ( int [ , ] mat ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ )
if ( ( i != j ) && ( mat [ i , j ] != 0 ) ) return false ; return true ; }
public static void Main ( ) { int [ , ] mat = { { 4 , 0 , 0 , 0 } , { 0 , 7 , 0 , 0 } , { 0 , 0 , 5 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isDiagonalMatrix ( mat ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG { static int N = 4 ;
static bool isScalarMatrix ( int [ , ] mat ) {
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( ( i != j ) && ( mat [ i , j ] != 0 ) ) return false ;
for ( int i = 0 ; i < N - 1 ; i ++ ) if ( mat [ i , i ] != mat [ i + 1 , i + 1 ] ) return false ; return true ; }
public static void Main ( ) { int [ , ] mat = { { 2 , 0 , 0 , 0 } , { 0 , 2 , 0 , 0 } , { 0 , 0 , 2 , 0 } , { 0 , 0 , 0 , 2 } } ;
if ( isScalarMatrix ( mat ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG {
static void sortByRow ( int [ , ] mat , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n - 1 ; j ++ ) { if ( mat [ i , j ] > mat [ i , j + 1 ] ) { var temp = mat [ i , j ] ; mat [ i , j ] = mat [ i , j + 1 ] ; mat [ i , j + 1 ] = temp ; } } } }
static void transpose ( int [ , ] mat , int n ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
var temp = mat [ i , j ] ; mat [ i , j ] = mat [ j , i ] ; mat [ j , i ] = temp ; } }
static void sortMatRowAndColWise ( int [ , ] mat , int n ) {
sortByRow ( mat , n ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n ) ;
transpose ( mat , n ) ; }
static void printMat ( int [ , ] mat , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) Console . Write ( mat [ i , j ] + " ▁ " ) ; Console . Write ( " STRNEWLINE " ) ; } }
public static void Main ( ) { int [ , ] mat = { { 4 , 1 , 3 } , { 9 , 6 , 8 } , { 5 , 2 , 7 } } ; int n = 3 ; Console . Write ( " Original ▁ Matrix : STRNEWLINE " ) ; printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; Console . Write ( " STRNEWLINE Matrix ▁ After ▁ Sorting : STRNEWLINE " ) ; printMat ( mat , n ) ; } }
public static void doublyEven ( int n ) { int [ , ] arr = new int [ n , n ] ; int i , j ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) { arr [ i , j ] = ( n * i ) + j + 1 ; } }
for ( i = 0 ; i < n / 4 ; i ++ ) { for ( j = 0 ; j < n / 4 ; j ++ ) { arr [ i , j ] = ( n * n + 1 ) - arr [ i , j ] ; } }
for ( i = 0 ; i < n / 4 ; i ++ ) { for ( j = 3 * ( n / 4 ) ; j < n ; j ++ ) { arr [ i , j ] = ( n * n + 1 ) - arr [ i , j ] ; } }
for ( i = 3 * n / 4 ; i < n ; i ++ ) { for ( j = 0 ; j < n / 4 ; j ++ ) { arr [ i , j ] = ( n * n + 1 ) - arr [ i , j ] ; } }
for ( i = 3 * n / 4 ; i < n ; i ++ ) { for ( j = 3 * n / 4 ; j < n ; j ++ ) { arr [ i , j ] = ( n * n + 1 ) - arr [ i , j ] ; } }
for ( i = n / 4 ; i < 3 * n / 4 ; i ++ ) { for ( j = n / 4 ; j < 3 * n / 4 ; j ++ ) { arr [ i , j ] = ( n * n + 1 ) - arr [ i , j ] ; } }
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) { Console . Write ( arr [ i , j ] + " ▁ " + " ▁ " ) ; } Console . WriteLine ( ) ; } }
public static void Main ( string [ ] args ) { int n = 8 ;
doublyEven ( n ) ; } }
using System ; class GFG { static int N = 3 ;
static bool isMagicSquare ( int [ , ] mat ) {
int sum = 0 , sum2 = 0 ; for ( int i = 0 ; i < N ; i ++ ) sum = sum + mat [ i , i ] ;
for ( int i = 0 ; i < N ; i ++ ) sum2 = sum2 + mat [ i , N - 1 - i ] ; if ( sum != sum2 ) return false ;
for ( int i = 0 ; i < N ; i ++ ) { int rowSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) rowSum += mat [ i , j ] ;
if ( rowSum != sum ) return false ; }
for ( int i = 0 ; i < N ; i ++ ) { int colSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) colSum += mat [ j , i ] ;
if ( sum != colSum ) return false ; } return true ; }
public static void Main ( ) { int [ , ] mat = new int [ , ] { { 2 , 7 , 6 } , { 9 , 5 , 1 } , { 4 , 3 , 8 } } ; if ( isMagicSquare ( mat ) ) Console . WriteLine ( " Magic ▁ Square " ) ; else Console . WriteLine ( " Not ▁ a ▁ magic " + " ▁ Square " ) ; } }
using System ; class GFG {
static int subCount ( int [ ] arr , int n , int k ) {
int [ ] mod = new int [ k ] ;
int cumSum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { cumSum += arr [ i ] ;
mod [ ( ( cumSum % k ) + k ) % k ] ++ ; }
int result = 0 ;
for ( int i = 0 ; i < k ; i ++ )
if ( mod [ i ] > 1 ) result += ( mod [ i ] * ( mod [ i ] - 1 ) ) / 2 ;
result += mod [ 0 ] ; return result ; }
static int countSubmatrix ( int [ , ] mat , int n , int k ) {
int tot_count = 0 ; int left , right , i ; int [ ] temp = new int [ n ] ;
for ( left = 0 ; left < n ; left ++ ) {
for ( right = left ; right < n ; right ++ ) {
for ( i = 0 ; i < n ; ++ i ) temp [ i ] += mat [ i , right ] ;
tot_count += subCount ( temp , n , k ) ; } }
return tot_count - 3 ; }
static void Main ( ) { int [ , ] mat = new int [ , ] { { 5 , - 1 , 6 } , { - 2 , 3 , 8 } , { 7 , 4 , - 9 } } ; int n = 3 , k = 4 ; Console . Write ( " Count = " countSubmatrix ( mat , n , k ) ) ; } }
static int findMinOpeartion ( int [ , ] matrix , int n ) {
int [ ] sumRow = new int [ n ] ; int [ ] sumCol = new int [ n ] ;
for ( int i = 0 ; i < n ; ++ i ) for ( int j = 0 ; j < n ; ++ j ) { sumRow [ i ] += matrix [ i , j ] ; sumCol [ j ] += matrix [ i , j ] ; }
int maxSum = 0 ; for ( int i = 0 ; i < n ; ++ i ) { maxSum = Math . Max ( maxSum , sumRow [ i ] ) ; maxSum = Math . Max ( maxSum , sumCol [ i ] ) ; } int count = 0 ; for ( int i = 0 , j = 0 ; i < n && j < n ; ) {
int diff = Math . Min ( maxSum - sumRow [ i ] , maxSum - sumCol [ j ] ) ;
matrix [ i , j ] += diff ; sumRow [ i ] += diff ; sumCol [ j ] += diff ;
count += diff ;
if ( sumRow [ i ] == maxSum ) ++ i ;
if ( sumCol [ j ] == maxSum ) ++ j ; } return count ; }
static void printMatrix ( int [ , ] matrix , int n ) { for ( int i = 0 ; i < n ; ++ i ) { for ( int j = 0 ; j < n ; ++ j ) Console . Write ( matrix [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] matrix = { { 1 , 2 } , { 3 , 4 } } ; Console . WriteLine ( findMinOpeartion ( matrix , 2 ) ) ; printMatrix ( matrix , 2 ) ; } }
using System ; public class GfG { public static int find ( int n , int k ) { if ( n + 1 >= k ) return ( k - 1 ) ; else return ( 2 * n + 1 - k ) ; }
public static void Main ( ) { int n = 4 , k = 7 ; int freq = find ( n , k ) ; if ( freq < 0 ) Console . WriteLine ( " ▁ element " + " ▁ not ▁ exist ▁ " ) ; else Console . WriteLine ( " ▁ Frequency " + " ▁ of ▁ " + k + " ▁ is ▁ " + freq ) ; } }
public static void ZigZag ( int rows , int columns , int [ ] numbers ) { int k = 0 ;
int [ , ] arr = new int [ rows , columns ] ; for ( int i = 0 ; i < rows ; i ++ ) {
if ( i % 2 == 0 ) {
for ( int j = 0 ; j < columns && numbers [ k ] > 0 ; j ++ ) {
arr [ i , j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } }
else {
for ( int j = columns - 1 ; j >= 0 && numbers [ k ] > 0 ; j -- ) {
arr [ i , j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } } }
for ( int i = 0 ; i < rows ; i ++ ) { for ( int j = 0 ; j < columns ; j ++ ) Console . Write ( arr [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int rows = 4 ; int columns = 5 ; int [ ] Numbers = new int [ ] { 3 , 4 , 2 , 2 , 3 , 1 , 5 } ; ZigZag ( rows , columns , Numbers ) ; } }
static int numberofPosition ( int n , int k , int x , int y , int [ ] obstPosx , int [ ] obstPosy ) {
int d11 , d12 , d21 , d22 , r1 , r2 , c1 , c2 ;
d11 = Math . Min ( x - 1 , y - 1 ) ; d12 = Math . Min ( n - x , n - y ) ; d21 = Math . Min ( n - x , y - 1 ) ; d22 = Math . Min ( x - 1 , n - y ) ; r1 = y - 1 ; r2 = n - y ; c1 = x - 1 ; c2 = n - x ;
for ( int i = 0 ; i < k ; i ++ ) { if ( x > obstPosx [ i ] && y > obstPosy [ i ] && x - obstPosx [ i ] == y - obstPosy [ i ] ) d11 = Math . Min ( d11 , x - obstPosx [ i ] - 1 ) ; if ( obstPosx [ i ] > x && obstPosy [ i ] > y && obstPosx [ i ] - x == obstPosy [ i ] - y ) d12 = Math . Min ( d12 , obstPosx [ i ] - x - 1 ) ; if ( obstPosx [ i ] > x && y > obstPosy [ i ] && obstPosx [ i ] - x == y - obstPosy [ i ] ) d21 = Math . Min ( d21 , obstPosx [ i ] - x - 1 ) ; if ( x > obstPosx [ i ] && obstPosy [ i ] > y && x - obstPosx [ i ] == obstPosy [ i ] - y ) d22 = Math . Min ( d22 , x - obstPosx [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] < y ) r1 = Math . Min ( r1 , y - obstPosy [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] > y ) r2 = Math . Min ( r2 , obstPosy [ i ] - y - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] < x ) c1 = Math . Min ( c1 , x - obstPosx [ i ] - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] > x ) c2 = Math . Min ( c2 , obstPosx [ i ] - x - 1 ) ; } return d11 + d12 + d21 + d22 + r1 + r2 + c1 + c2 ; }
int n = 8 ;
int k = 1 ;
int Qposx = 4 ;
int Qposy = 4 ;
int [ ] obstPosx = { 3 } ;
int [ ] obstPosy = { 5 } ; Console . WriteLine ( numberofPosition ( n , k , Qposx , Qposy , obstPosx , obstPosy ) ) ; } }
using System ; public class GFG { static int n = 5 ;
static int FindMaxProduct ( int [ , ] arr , int n ) { int max = 0 , result ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = 0 ; j < n ; j ++ ) {
if ( ( j - 3 ) >= 0 ) { result = arr [ i , j ] * arr [ i , j - 1 ] * arr [ i , j - 2 ] * arr [ i , j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 ) { result = arr [ i , j ] * arr [ i - 1 , j ] * arr [ i - 2 , j ] * arr [ i - 3 , j ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 3 ) >= 0 ) { result = arr [ i , j ] * arr [ i - 1 , j - 1 ] * arr [ i - 2 , j - 2 ] * arr [ i - 3 , j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 1 ) <= 0 ) { result = arr [ i , j ] * arr [ i - 1 , j + 1 ] * arr [ i - 2 , j + 2 ] * arr [ i - 3 , j + 3 ] ; if ( max < result ) max = result ; } } } return max ; }
static public void Main ( ) { int [ , ] arr = { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 1 } , { 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 1 , 0 } , { 9 , 6 , 4 , 2 , 3 } } ; Console . Write ( FindMaxProduct ( arr , n ) ) ; } }
using System ; class GFG { public static int maxPro ( int [ , ] a , int n , int m , int k ) { int maxi = 1 , mp = 1 ; for ( int i = 0 ; i < n ; ++ i ) {
int wp = 1 ; for ( int l = 0 ; l < k ; ++ l ) { wp *= a [ i , l ] ; }
mp = wp ; for ( int j = k ; j < m ; ++ j ) { wp = wp * a [ i , j ] / a [ i , j - k ] ;
maxi = Math . Max ( maxi , Math . Max ( mp , wp ) ) ; } } return maxi ; }
static public void Main ( ) { int n = 6 , m = 5 , k = 4 ; int [ , ] a = { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 1 } , { 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 1 , 0 } , { 9 , 6 , 4 , 2 , 3 } , { 1 , 1 , 2 , 1 , 1 } } ;
int maxpro = maxPro ( a , n , m , k ) ; Console . WriteLine ( maxpro ) ; } }
using System ; class GFG {
static int minimumflip ( int [ , ] mat , int n ) { int [ , ] transpose = new int [ n , n ] ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) transpose [ i , j ] = mat [ j , i ] ;
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( transpose [ i , j ] != mat [ i , j ] ) flip ++ ; return flip / 2 ; }
public static void Main ( ) { int n = 3 ; int [ , ] mat = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; Console . WriteLine ( minimumflip ( mat , n ) ) ; } }
static int minimumflip ( int [ , ] mat , int n ) {
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i , j ] != mat [ j , i ] ) flip ++ ; return flip ; }
public static void Main ( ) { int n = 3 ; int [ , ] mat = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; Console . WriteLine ( minimumflip ( mat , n ) ) ; } }
using System ; class Lower_triangular { int N = 4 ;
bool isLowerTriangularMatrix ( int [ , ] mat ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( mat [ i , j ] != 0 ) return false ; return true ; }
public static void Main ( ) { Lower_triangular ob = new Lower_triangular ( ) ; int [ , ] mat = { { 1 , 0 , 0 , 0 } , { 1 , 4 , 0 , 0 } , { 4 , 6 , 2 , 0 } , { 0 , 4 , 7 , 6 } } ;
if ( ob . isLowerTriangularMatrix ( mat ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; public class GfG { private static int N = 4 ;
public static bool isUpperTriangularMatrix ( int [ , ] mat ) { for ( int i = 1 ; i < N ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i , j ] != 0 ) return false ; return true ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 3 , 5 , 3 } , { 0 , 4 , 6 , 2 } , { 0 , 0 , 2 , 5 } , { 0 , 0 , 0 , 6 } } ; if ( isUpperTriangularMatrix ( mat ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG { static int MAX = 100 ;
static void freq ( int [ , ] ar , int m , int n ) { int even = 0 , odd = 0 ; for ( int i = 0 ; i < m ; ++ i ) { for ( int j = 0 ; j < n ; ++ j ) {
if ( ( ar [ i , j ] % 2 ) == 0 ) ++ even ; else ++ odd ; } }
Console . WriteLine ( " ▁ Frequency ▁ of ▁ odd ▁ number ▁ = " + odd ) ; Console . WriteLine ( " ▁ Frequency ▁ of ▁ even ▁ number ▁ = ▁ " + even ) ; }
public static void Main ( ) { int m = 3 , n = 3 ; int [ , ] array = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; freq ( array , m , n ) ; } }
using System ; class GFG {
static bool HalfDiagonalSums ( int [ , ] mat , int n ) {
int diag1_left = 0 , diag1_right = 0 ; int diag2_left = 0 , diag2_right = 0 ; for ( int i = 0 , j = n - 1 ; i < n ; i ++ , j -- ) { if ( i < n / 2 ) { diag1_left += mat [ i , i ] ; diag2_left += mat [ j , i ] ; } else if ( i > n / 2 ) { diag1_right += mat [ i , i ] ; diag2_right += mat [ j , i ] ; } } return ( diag1_left == diag2_right && diag2_right == diag2_left && diag1_right == diag2_left && diag2_right == mat [ n / 2 , n / 2 ] ) ; }
static public void Main ( ) { int [ , ] a = { { 2 , 9 , 1 , 4 , - 2 } , { 6 , 7 , 2 , 11 , 4 } , { 4 , 2 , 9 , 2 , 4 } , { 1 , 9 , 2 , 4 , 4 } , { 0 , 2 , 4 , 2 , 5 } } ; Console . WriteLine ( HalfDiagonalSums ( a , 5 ) ? " Yes " : " No " ) ; } }
using System ; class GFG { int MAX = 100 ; static bool isIdentity ( int [ , ] mat , int N ) { for ( int row = 0 ; row < N ; row ++ ) { for ( int col = 0 ; col < N ; col ++ ) { if ( row == col && mat [ row , col ] != 1 ) return false ; else if ( row != col && mat [ row , col ] != 0 ) return false ; } } return true ; }
public static void Main ( ) { int N = 4 ; int [ , ] mat = { { 1 , 0 , 0 , 0 } , { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isIdentity ( mat , N ) ) Console . WriteLine ( " Yes ▁ " ) ; else Console . WriteLine ( " No ▁ " ) ; } }
using System ; class Example { static long mod = 100000007 ;
static long modPower ( long a , long t , long mod ) { long now = a , ret = 1 ;
while ( t > 0 ) { if ( t % 2 == 1 ) ret = now * ( ret % mod ) ; now = now * ( now % mod ) ; t >>= 1 ; } return ret ; }
static long countWays ( int n , int m , int k ) {
if ( n == 1 m == 1 ) return 1 ;
else if ( ( n + m ) % 2 == 1 && k == - 1 ) return 0 ;
return ( modPower ( modPower ( ( long ) 2 , n - 1 , mod ) , m - 1 , mod ) % mod ) ; }
public static void Main ( ) { int n = 2 , m = 7 , k = 1 ; Console . WriteLine ( countWays ( n , m , k ) ) ; } }
using System ; using System . Collections . Generic ; class GFG { static int MAX = 100 ; static void imageSwap ( int [ , ] mat , int n ) {
int row = 0 ;
for ( int j = 0 ; j < n ; j ++ ) {
Stack < int > s = new Stack < int > ( ) ; int i = row , k = j ; while ( i < n && k >= 0 ) { s . Push ( mat [ i ++ , k -- ] ) ; }
i = row ; k = j ; while ( i < n && k >= 0 ) { mat [ i ++ , k -- ] = s . Peek ( ) ; s . Pop ( ) ; } }
int column = n - 1 ; for ( int j = 1 ; j < n ; j ++ ) {
Stack < int > s = new Stack < int > ( ) ; int i = j , k = column ; while ( i < n && k >= 0 ) { s . Push ( mat [ i ++ , k -- ] ) ; }
i = j ; k = column ; while ( i < n && k >= 0 ) { mat [ i ++ , k -- ] = s . Peek ( ) ; s . Pop ( ) ; } } }
static void printMatrix ( int [ , ] mat , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { Console . Write ( mat [ i , j ] + " ▁ " ) ; } Console . WriteLine ( " " ) ; } }
public static void Main ( String [ ] args ) { int [ , ] mat = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; int n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ; } }
using System ; class GFG { static int MAX = 100 ; static void imageSwap ( int [ , ] mat , int n ) {
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j <= i ; j ++ ) mat [ i , j ] = mat [ i , j ] + mat [ j , i ] - ( mat [ j , i ] = mat [ i , j ] ) ; }
static void printMatrix ( int [ , ] mat , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) Console . Write ( mat [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] mat = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; int n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ; } }
static int m = 3 ;
static int n = 2 ;
static long countSets ( int [ , ] a ) {
long res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < m ; j ++ ) { if ( a [ i , j ] == 1 ) u ++ ; else v ++ ; } res += ( long ) ( Math . Pow ( 2 , u ) - 1 + Math . Pow ( 2 , v ) ) - 1 ; }
for ( int i = 0 ; i < m ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < n ; j ++ ) { if ( a [ j , i ] == 1 ) u ++ ; else v ++ ; } res += ( long ) ( Math . Pow ( 2 , u ) - 1 + Math . Pow ( 2 , v ) ) - 1 ; }
return res - ( n * m ) ; }
public static void Main ( ) { int [ , ] a = { { 1 , 0 , 1 } , { 0 , 1 , 0 } } ; Console . WriteLine ( countSets ( a ) ) ; } }
static int search ( int [ , ] mat , int n , int x ) { if ( n == 0 ) return - 1 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ )
if ( mat [ i , j ] == x ) { Console . Write ( " Element ▁ found ▁ at ▁ ( " + i + " , ▁ " + j + " ) STRNEWLINE " ) ; return 1 ; } } Console . Write ( " ▁ Element ▁ not ▁ found " ) ; return 0 ; }
static public void Main ( ) { int [ , ] mat = { { 10 , 20 , 30 , 40 } , { 15 , 25 , 35 , 45 } , { 27 , 29 , 37 , 48 } , { 32 , 33 , 39 , 50 } } ; search ( mat , 4 , 29 ) ; } }
static void fill0X ( int m , int n ) {
int i , k = 0 , l = 0 ;
int r = m , c = n ;
char [ , ] a = new char [ m , n ] ;
char x = ' X ' ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) a [ k , i ] = x ; k ++ ;
for ( i = k ; i < m ; ++ i ) a [ i , n - 1 ] = x ; n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) a [ m - 1 , i ] = x ; m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) a [ i , l ] = x ; l ++ ; }
x = ( x == '0' ) ? ' X ' : '0' ; }
for ( i = 0 ; i < r ; i ++ ) { for ( int j = 0 ; j < c ; j ++ ) Console . Write ( a [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { Console . WriteLine ( " Output ▁ for " + " ▁ m ▁ = ▁ 5 , ▁ n ▁ = ▁ 6" ) ; fill0X ( 5 , 6 ) ; Console . WriteLine ( " Output ▁ for " + " ▁ m ▁ = ▁ 4 , ▁ n ▁ = ▁ 4" ) ; fill0X ( 4 , 4 ) ; Console . WriteLine ( " Output ▁ for " + " ▁ m ▁ = ▁ 3 , ▁ n ▁ = ▁ 4" ) ; fill0X ( 3 , 4 ) ; } }
public class NodeTemp { public int data ; public NodeTemp next , child ; public NodeTemp ( int data ) { this . data = data ; next = child = null ; } }
public static NodeTemp addSibling ( NodeTemp node , int data ) { if ( node == null ) { return null ; } while ( node . next != null ) { node = node . next ; } return ( node . next = new NodeTemp ( data ) ) ; }
public static NodeTemp addChild ( NodeTemp node , int data ) { if ( node == null ) { return null ; }
if ( node . child != null ) { return ( addSibling ( node . child , data ) ) ; } else { return ( node . child = new NodeTemp ( data ) ) ; } }
public static void traverseTree ( NodeTemp root ) { if ( root == null ) { return ; } while ( root != null ) { Console . Write ( root . data + " ▁ " ) ; if ( root . child != null ) { traverseTree ( root . child ) ; } root = root . next ; } }
public static void Main ( string [ ] args ) { NodeTemp root = new NodeTemp ( 10 ) ; NodeTemp n1 = addChild ( root , 2 ) ; NodeTemp n2 = addChild ( root , 3 ) ; NodeTemp n3 = addChild ( root , 4 ) ; NodeTemp n4 = addChild ( n3 , 6 ) ; NodeTemp n5 = addChild ( root , 5 ) ; NodeTemp n6 = addChild ( n5 , 7 ) ; NodeTemp n7 = addChild ( n5 , 8 ) ; NodeTemp n8 = addChild ( n5 , 9 ) ; traverseTree ( root ) ; } }
using System ; class GFG {
public static int calculateEnergy ( int [ , ] mat , int n ) { int i_des , j_des , q ; int tot_energy = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
q = mat [ i , j ] / n ;
i_des = q ; j_des = mat [ i , j ] - ( n * q ) ;
tot_energy += Math . Abs ( i_des - i ) + Math . Abs ( j_des - j ) ; } }
return tot_energy ; }
public static void Main ( ) { int [ , ] mat = new int [ , ] { { 4 , 7 , 0 , 3 } , { 8 , 5 , 6 , 1 } , { 9 , 11 , 10 , 2 } , { 15 , 13 , 14 , 12 } } ; int n = 4 ; Console . Write ( " Total ▁ energy ▁ required ▁ = ▁ " + calculateEnergy ( mat , n ) + " ▁ units " ) ; } }
using System ; public class GFG { static readonly int MAX = 100 ;
static bool isUnique ( int [ , ] mat , int i , int j , int n , int m ) {
int sumrow = 0 ; for ( int k = 0 ; k < m ; k ++ ) { sumrow += mat [ i , k ] ; if ( sumrow > 1 ) return false ; }
int sumcol = 0 ; for ( int k = 0 ; k < n ; k ++ ) { sumcol += mat [ k , j ] ; if ( sumcol > 1 ) return false ; } return true ; } static int countUnique ( int [ , ] mat , int n , int m ) { int uniquecount = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i , j ] != 0 && isUnique ( mat , i , j , n , m ) ) uniquecount ++ ; return uniquecount ; }
static public void Main ( ) { int [ , ] mat = { { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 1 , 0 , 0 , 1 } } ; Console . Write ( countUnique ( mat , 3 , 4 ) ) ; } }
using System ; class GFG { static int MAX = 100 ; static int countUnique ( int [ , ] mat , int n , int m ) { int [ ] rowsum = new int [ n ] ; int [ ] colsum = new int [ m ] ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i , j ] != 0 ) { rowsum [ i ] ++ ; colsum [ j ] ++ ; }
int uniquecount = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i , j ] != 0 && rowsum [ i ] == 1 && colsum [ j ] == 1 ) uniquecount ++ ; return uniquecount ; }
public static void Main ( String [ ] args ) { int [ , ] mat = { { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 1 , 0 , 0 , 1 } } ; Console . Write ( countUnique ( mat , 3 , 4 ) ) ; } }
for ( int i = 0 ; i < m ; ++ i ) for ( int j = 0 ; j < n ; ++ j ) if ( array [ i , j ] == 0 ) ++ counter ; return ( counter > ( ( m * n ) / 2 ) ) ; }
public static void Main ( ) { int [ , ] array = { { 1 , 0 , 3 } , { 0 , 0 , 4 } , { 6 , 0 , 0 } } ; int m = 3 , n = 3 ; if ( isSparse ( array , m , n ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG {
static int countCommon ( int [ , ] mat , int n ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( mat [ i , i ] == mat [ i , n - i - 1 ] ) res ++ ; return res ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; Console . WriteLine ( countCommon ( mat , 3 ) ) ; } }
static bool areSumSame ( int [ , ] a , int n , int m ) { int sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum1 = 0 ; sum2 = 0 ; for ( int j = 0 ; j < m ; j ++ ) { sum1 += a [ i , j ] ; sum2 += a [ j , i ] ; } if ( sum1 == sum2 ) return true ; } return false ; }
int n = 4 ;
int m = 4 ; int [ , ] M = { { 1 , 2 , 3 , 4 } , { 9 , 5 , 3 , 1 } , { 0 , 3 , 5 , 6 } , { 0 , 4 , 5 , 6 } } ; if ( areSumSame ( M , n , m ) == true ) Console . Write ( "1 STRNEWLINE " ) ; else Console . Write ( "0 STRNEWLINE " ) ; } }
using System ; using System . Collections . Generic ; class GFG { public class Node { public int data ; public Node next ; public Node child ; } ;
static Node newNode ( int data ) { Node newNode = new Node ( ) ; newNode . next = newNode . child = null ; newNode . data = data ; return newNode ; }
static Node addSibling ( Node n , int data ) { if ( n == null ) return null ; while ( n . next != null ) n = n . next ; return ( n . next = newNode ( data ) ) ; }
static Node addChild ( Node n , int data ) { if ( n == null ) return null ;
if ( n . child != null ) return addSibling ( n . child , data ) ; else return ( n . child = newNode ( data ) ) ; }
static void traverseTree ( Node root ) {
if ( root == null ) return ; Console . Write ( root . data + " ▁ " ) ; if ( root . child == null ) return ;
Queue < Node > q = new Queue < Node > ( ) ; Node curr = root . child ; q . Enqueue ( curr ) ; while ( q . Count != 0 ) {
curr = q . Peek ( ) ; q . Dequeue ( ) ;
while ( curr != null ) { Console . Write ( curr . data + " ▁ " ) ; if ( curr . child != null ) { q . Enqueue ( curr . child ) ; } curr = curr . next ; } } }
public static void Main ( String [ ] args ) { Node root = newNode ( 10 ) ; Node n1 = addChild ( root , 2 ) ; Node n2 = addChild ( root , 3 ) ; Node n3 = addChild ( root , 4 ) ; Node n4 = addChild ( n3 , 6 ) ; Node n5 = addChild ( root , 5 ) ; Node n6 = addChild ( n5 , 7 ) ; Node n7 = addChild ( n5 , 8 ) ; Node n8 = addChild ( n5 , 9 ) ; traverseTree ( root ) ; } }
using System ; class GFG { static int N = 4 ;
static void findMax ( int [ , ] arr ) { int row = 0 , i , j ; for ( i = 0 , j = N - 1 ; i < N ; i ++ ) {
while ( arr [ i , j ] == 1 && j >= 0 ) { row = i ; j -- ; } } Console . Write ( " Row ▁ number ▁ = ▁ " + ( row + 1 ) ) ; Console . Write ( " , ▁ MaxCount ▁ = ▁ " + ( N - 1 - j ) ) ; }
public static void Main ( ) { int [ , ] arr = { { 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 0 } , { 0 , 1 , 1 , 1 } } ; findMax ( arr ) ; } }
using System ; class GFG { static int MAX = 100 ;
static void transpose ( int [ , ] mat , int [ , ] tr , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) tr [ i , j ] = mat [ j , i ] ; }
static bool isSymmetric ( int [ , ] mat , int N ) { int [ , ] tr = new int [ N , MAX ] ; transpose ( mat , tr , N ) ; for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i , j ] != tr [ i , j ] ) return false ; return true ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " No " ) ; } }
using System ; class GFG {
static bool isSymmetric ( int [ , ] mat , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i , j ] != mat [ j , i ] ) return false ; return true ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) Console . WriteLine ( " Yes " ) ; else Console . WriteLine ( " NO " ) ; } }
using System ; public class Cell { public int x ; public int y ;
public Cell ( int x , int y ) { this . x = x ; this . y = y ; } } public class MoveCellPerCellValue {
public Boolean isAllCellTraversed ( Cell [ , ] grid ) { Boolean [ , ] visited = new Boolean [ grid . GetLength ( 0 ) , grid . GetLength ( 1 ) ] ; int total = grid . GetLength ( 0 ) * grid . GetLength ( 1 ) ;
int startx = grid [ 0 , 0 ] . x ; int starty = grid [ 0 , 0 ] . y ; for ( int i = 0 ; i < total - 2 ; i ++ ) {
if ( grid [ startx , starty ] == null ) return false ;
if ( visited [ startx , starty ] == true ) return false ; visited [ startx , starty ] = true ; int x = grid [ startx , starty ] . x ; int y = grid [ startx , starty ] . y ;
startx = x ; starty = y ; }
if ( grid [ startx , starty ] == null ) return true ; return false ; }
public static void Main ( String [ ] args ) { Cell [ , ] cell = new Cell [ 3 , 2 ] ; cell [ 0 , 0 ] = new Cell ( 0 , 1 ) ; cell [ 0 , 1 ] = new Cell ( 2 , 0 ) ; cell [ 1 , 0 ] = null ; cell [ 1 , 1 ] = new Cell ( 1 , 0 ) ; cell [ 2 , 0 ] = new Cell ( 2 , 1 ) ; cell [ 2 , 1 ] = new Cell ( 1 , 1 ) ; MoveCellPerCellValue mcp = new MoveCellPerCellValue ( ) ; Console . WriteLine ( mcp . isAllCellTraversed ( cell ) ) ; } }
using System ; class GFG { public static bool isPalin ( string str ) { int len = str . Length / 2 ; for ( int i = 0 ; i < len ; i ++ ) { if ( str [ i ] != str [ str . Length - i - 1 ] ) { return false ; } } return true ; }
public static void palindromicPath ( string str , char [ ] [ ] a , int i , int j , int m , int n ) {
if ( j < m - 1 i < n - 1 ) { if ( i < n - 1 ) { palindromicPath ( str + a [ i ] [ j ] , a , i + 1 , j , m , n ) ; } if ( j < m - 1 ) { palindromicPath ( str + a [ i ] [ j ] , a , i , j + 1 , m , n ) ; } }
else { str = str + a [ n - 1 ] [ m - 1 ] ; if ( isPalin ( str ) ) { Console . WriteLine ( str ) ; } } }
public static void Main ( string [ ] args ) { char [ ] [ ] arr = new char [ ] [ ] { new char [ ] { ' a ' , ' a ' , ' a ' , ' b ' } , new char [ ] { ' b ' , ' a ' , ' a ' , ' a ' } , new char [ ] { ' a ' , ' b ' , ' b ' , ' a ' } } ; string str = " " ; palindromicPath ( str , arr , 0 , 0 , 4 , 3 ) ; } }
using System ; class GFG { static int n = 4 ; static int m = 4 ;
static int findPossibleMoves ( int [ , ] mat , int p , int q ) {
int [ ] X = { 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 } ; int [ ] Y = { 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 } ; int count = 0 ;
for ( int i = 0 ; i < 8 ; i ++ ) {
int x = p + X [ i ] ; int y = q + Y [ i ] ;
if ( x >= 0 && y >= 0 && x < n && y < m && mat [ x , y ] == 0 ) count ++ ; }
return count ; }
static public void Main ( ) { int [ , ] mat = { { 1 , 0 , 1 , 0 } , { 0 , 1 , 1 , 1 } , { 1 , 1 , 0 , 1 } , { 0 , 1 , 1 , 1 } } ; int p = 2 , q = 2 ; Console . WriteLine ( findPossibleMoves ( mat , p , q ) ) ; } }
using System ; public class GFG { static void printDiagonalSums ( int [ , ] mat , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) principal += mat [ i , j ] ;
if ( ( i + j ) == ( n - 1 ) ) secondary += mat [ i , j ] ; } } Console . WriteLine ( " Principal ▁ Diagonal : " + principal ) ; Console . WriteLine ( " Secondary ▁ Diagonal : " + secondary ) ; }
static public void Main ( ) { int [ , ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; } }
using System ; public class GFG { static void printDiagonalSums ( int [ , ] mat , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { principal += mat [ i , i ] ; secondary += mat [ i , n - i - 1 ] ; } Console . WriteLine ( " Principal ▁ Diagonal : " + principal ) ; Console . WriteLine ( " Secondary ▁ Diagonal : " + secondary ) ; }
static public void Main ( ) { int [ , ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; } }
using System ; class GFG { public static long getBoundarySum ( int [ , ] a , int m , int n ) { long sum = 0 ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( i == 0 ) sum += a [ i , j ] ; else if ( i == m - 1 ) sum += a [ i , j ] ; else if ( j == 0 ) sum += a [ i , j ] ; else if ( j == n - 1 ) sum += a [ i , j ] ; } } return sum ; }
static public void Main ( ) { int [ , ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; long sum = getBoundarySum ( a , 4 , 4 ) ; Console . WriteLine ( " Sum ▁ of ▁ boundary " + " ▁ elements ▁ is ▁ " + sum ) ; } }
using System ; class GFG { static void printSpiral ( int [ , ] mat , int r , int c ) { int i , a = 0 , b = 2 ; int low_row = ( 0 > a ) ? 0 : a ; int low_column = ( 0 > b ) ? 0 : b - 1 ; int high_row = ( ( a + 1 ) >= r ) ? r - 1 : a + 1 ; int high_column = ( ( b + 1 ) >= c ) ? c - 1 : b + 1 ; while ( ( low_row > 0 - r && low_column > 0 - c ) ) { for ( i = low_column + 1 ; i <= high_column && i < c && low_row >= 0 ; ++ i ) Console . Write ( mat [ low_row , i ] + " ▁ " ) ; low_row -= 1 ; for ( i = low_row + 2 ; i <= high_row && i < r && high_column < c ; ++ i ) Console . Write ( mat [ i , high_column ] + " ▁ " ) ; high_column += 1 ; for ( i = high_column - 2 ; i >= low_column && i >= 0 && high_row < r ; -- i ) Console . Write ( mat [ high_row , i ] + " ▁ " ) ; high_row += 1 ; for ( i = high_row - 2 ; i > low_row && i >= 0 && low_column >= 0 ; -- i ) Console . Write ( mat [ i , low_column ] + " ▁ " ) ; low_column -= 1 ; } Console . WriteLine ( ) ; }
static public void Main ( ) { int [ , ] mat = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int r = 3 , c = 3 ;
printSpiral ( mat , r , c ) ; } }
using System ; class GFG { public static int N = 3 ;
static void interchangeDiagonals ( int [ , ] array ) {
for ( int i = 0 ; i < N ; ++ i ) if ( i != N / 2 ) { int temp = array [ i , i ] ; array [ i , i ] = array [ i , N - i - 1 ] ; array [ i , N - i - 1 ] = temp ; } for ( int i = 0 ; i < N ; ++ i ) { for ( int j = 0 ; j < N ; ++ j ) Console . Write ( array [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] array = { { 4 , 5 , 6 } , { 1 , 2 , 3 } , { 7 , 8 , 9 } } ; interchangeDiagonals ( array ) ; } }
using System ; public class GFG { public static int difference ( int [ , ] arr , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) d1 += arr [ i , j ] ;
if ( i == n - j - 1 ) d2 += arr [ i , j ] ; } }
return Math . Abs ( d1 - d2 ) ; }
public static void Main ( ) { int n = 3 ; int [ , ] arr = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , - 12 } } ; Console . Write ( difference ( arr , n ) ) ; } }
using System ; public class GFG { public static int difference ( int [ , ] arr , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { d1 += arr [ i , i ] ; d2 += arr [ i , n - i - 1 ] ; }
return Math . Abs ( d1 - d2 ) ; }
public static void Main ( ) { int n = 3 ; int [ , ] arr = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , - 12 } } ; Console . Write ( difference ( arr , n ) ) ; } }
using System ; class GFG { static int MAX = 100 ;
static void spiralFill ( int m , int n , int [ , ] a ) {
int val = 1 ;
int k = 0 , l = 0 ; while ( k < m && l < n ) {
for ( int i = l ; i < n ; ++ i ) { a [ k , i ] = val ++ ; } k ++ ;
for ( int i = k ; i < m ; ++ i ) { a [ i , n - 1 ] = val ++ ; } n -- ;
if ( k < m ) { for ( int i = n - 1 ; i >= l ; -- i ) { a [ m - 1 , i ] = val ++ ; } m -- ; }
if ( l < n ) { for ( int i = m - 1 ; i >= k ; -- i ) { a [ i , l ] = val ++ ; } l ++ ; } } }
public static void Main ( ) { int m = 4 , n = 4 ; int [ , ] a = new int [ MAX , MAX ] ; spiralFill ( m , n , a ) ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { Console . Write ( a [ i , j ] + " ▁ " ) ; } Console . Write ( " STRNEWLINE " ) ; } } }
using System ; public class GFG {
static void maxMin ( int [ , ] arr , int n ) { int min = + 2147483647 ; int max = - 2147483648 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j <= n / 2 ; j ++ ) {
if ( arr [ i , j ] > arr [ i , n - j - 1 ] ) { if ( min > arr [ i , n - j - 1 ] ) min = arr [ i , n - j - 1 ] ; if ( max < arr [ i , j ] ) max = arr [ i , j ] ; } else { if ( min > arr [ i , j ] ) min = arr [ i , j ] ; if ( max < arr [ i , n - j - 1 ] ) max = arr [ i , n - j - 1 ] ; } } } Console . Write ( " Maximum ▁ = ▁ " + max + " , ▁ Minimum ▁ = ▁ " + min ) ; }
static public void Main ( ) { int [ , ] arr = { { 5 , 9 , 11 } , { 25 , 0 , 14 } , { 21 , 6 , 4 } } ; maxMin ( arr , 3 ) ; } }
using System ; using System . Collections . Generic ; public class GFG { public static void antiSpiralTraversal ( int m , int n , int [ ] [ ] a ) { int i , k = 0 , l = 0 ;
Stack < int > stk = new Stack < int > ( ) ; while ( k <= m && l <= n ) {
for ( i = l ; i <= n ; ++ i ) { stk . Push ( a [ k ] [ i ] ) ; } k ++ ;
for ( i = k ; i <= m ; ++ i ) { stk . Push ( a [ i ] [ n ] ) ; } n -- ;
if ( k <= m ) { for ( i = n ; i >= l ; -- i ) { stk . Push ( a [ m ] [ i ] ) ; } m -- ; }
if ( l <= n ) { for ( i = m ; i >= k ; -- i ) { stk . Push ( a [ i ] [ l ] ) ; } l ++ ; } } while ( stk . Count > 0 ) { Console . Write ( stk . Peek ( ) + " ▁ " ) ; stk . Pop ( ) ; } }
public static void Main ( string [ ] args ) { int [ ] [ ] mat = new int [ ] [ ] { new int [ ] { 1 , 2 , 3 , 4 , 5 } , new int [ ] { 6 , 7 , 8 , 9 , 10 } , new int [ ] { 11 , 12 , 13 , 14 , 15 } , new int [ ] { 16 , 17 , 18 , 19 , 20 } } ; antiSpiralTraversal ( mat . Length - 1 , mat [ 0 ] . Length - 1 , mat ) ; } }
static int findNormal ( int [ , ] mat , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i , j ] * mat [ i , j ] ; return ( int ) Math . Sqrt ( sum ) ; }
static int findTrace ( int [ , ] mat , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += mat [ i , i ] ; return sum ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; Console . Write ( " Trace ▁ of ▁ Matrix ▁ = ▁ " + findTrace ( mat , 5 ) + " STRNEWLINE " ) ; Console . Write ( " Normal ▁ of ▁ Matrix ▁ = ▁ " + findNormal ( mat , 5 ) ) ; } }
using System ; public class GFG { public const int N = 5 ; public const int M = 5 ;
public static int minOperation ( bool [ ] [ ] arr ) { int ans = 0 ; for ( int i = N - 1 ; i >= 0 ; i -- ) { for ( int j = M - 1 ; j >= 0 ; j -- ) {
if ( arr [ i ] [ j ] == false ) {
ans ++ ;
for ( int k = 0 ; k <= i ; k ++ ) { for ( int h = 0 ; h <= j ; h ++ ) {
if ( arr [ k ] [ h ] == true ) { arr [ k ] [ h ] = false ; } else { arr [ k ] [ h ] = true ; } } } } } } return ans ; }
public static void Main ( string [ ] args ) { bool [ ] [ ] mat = new bool [ ] [ ] { new bool [ ] { false , false , true , true , true } , new bool [ ] { false , false , false , true , true } , new bool [ ] { false , false , false , true , true } , new bool [ ] { true , true , true , true , true } , new bool [ ] { true , true , true , true , true } } ; Console . WriteLine ( minOperation ( mat ) ) ; } }
static int findSum ( int n ) { int ans = 0 , temp = 0 , num ;
for ( int i = 1 ; i <= n && temp < n ; i ++ ) {
temp = i - 1 ;
num = 1 ; while ( temp < n ) { if ( temp + i <= n ) ans += ( i * num ) ; else ans += ( ( n - temp ) * num ) ; temp += i ; num ++ ; } } return ans ; }
public static void Main ( ) { int N = 2 ; Console . WriteLine ( findSum ( N ) ) ; } }
static void printCoils ( int n ) {
int m = 8 * n * n ;
int [ ] coil1 = new int [ m ] ;
coil1 [ 0 ] = 8 * n * n + 2 * n ; int curr = coil1 [ 0 ] ; int nflg = 1 , step = 2 ;
int index = 1 ; while ( index < m ) {
for ( int i = 0 ; i < step ; i ++ ) {
curr = coil1 [ index ++ ] = ( curr - 4 * n * nflg ) ; if ( index >= m ) break ; } if ( index >= m ) break ;
for ( int i = 0 ; i < step ; i ++ ) { curr = coil1 [ index ++ ] = curr + nflg ; if ( index >= m ) break ; } nflg = nflg * ( - 1 ) ; step += 2 ; }
int [ ] coil2 = new int [ m ] ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) coil2 [ i ] = 16 * n * n + 1 - coil1 [ i ] ;
Console . Write ( " Coil ▁ 1 ▁ : ▁ " ) ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) Console . Write ( coil1 [ i ] + " ▁ " ) ; Console . Write ( " STRNEWLINE Coil ▁ 2 ▁ : ▁ " ) ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) Console . Write ( coil2 [ i ] + " ▁ " ) ; }
public static void Main ( ) { int n = 1 ; printCoils ( n ) ; } }
static int findSum ( int n ) {
int [ , ] arr = new int [ n , n ] ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) arr [ i , j ] = Math . Abs ( i - j ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += arr [ i , j ] ; return sum ; }
static public void Main ( String [ ] args ) { int n = 3 ; Console . WriteLine ( findSum ( n ) ) ; } }
static int findSum ( int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += i * ( n - i ) ; return 2 * sum ; }
static public void Main ( String [ ] args ) { int n = 3 ; Console . WriteLine ( findSum ( n ) ) ; } }
static int findSum ( int n ) { n -- ; int sum = 0 ; sum += ( n * ( n + 1 ) ) / 2 ; sum += ( n * ( n + 1 ) * ( 2 * n + 1 ) ) / 6 ; return sum ; }
static public void Main ( String [ ] args ) { int n = 3 ; Console . WriteLine ( findSum ( n ) ) ; } }
using System ; public class GFG { static void checkHV ( int [ , ] arr , int N , int M ) {
bool horizontal = true ; bool vertical = true ;
for ( int i = 0 , k = N - 1 ; i < N / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < M ; j ++ ) {
if ( arr [ i , j ] != arr [ k , j ] ) { horizontal = false ; break ; } } }
for ( int i = 0 , k = M - 1 ; i < M / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < N ; j ++ ) {
if ( arr [ i , j ] != arr [ k , j ] ) { horizontal = false ; break ; } } } if ( ! horizontal && ! vertical ) Console . WriteLine ( " NO " ) ; else if ( horizontal && ! vertical ) Console . WriteLine ( " HORIZONTAL " ) ; else if ( vertical && ! horizontal ) Console . WriteLine ( " VERTICAL " ) ; else Console . WriteLine ( " BOTH " ) ; }
static public void Main ( ) { int [ , ] mat = { { 1 , 0 , 1 } , { 0 , 0 , 0 } , { 1 , 0 , 1 } } ; checkHV ( mat , 3 , 3 ) ; } }
static int maxDet ( int n ) { return ( 2 * n * n * n ) ; }
void resMatrix ( int n ) { for ( int i = 0 ; i < 3 ; i ++ ) { for ( int j = 0 ; j < 3 ; j ++ ) {
if ( i == 0 && j == 2 ) Console . Write ( "0 ▁ " ) ; else if ( i == 1 && j == 0 ) Console . Write ( "0 ▁ " ) ; else if ( i == 2 && j == 1 ) Console . Write ( "0 ▁ " ) ;
else Console . ( n + " " ) ; } Console . WriteLine ( " " ) ; } }
static public void Main ( String [ ] args ) { int n = 15 ; GFG geeks = new GFG ( ) ; Console . WriteLine ( " Maximum ▁ Determinant ▁ = ▁ " + maxDet ( n ) ) ; Console . WriteLine ( " Resultant ▁ Matrix ▁ : " ) ; geeks . resMatrix ( n ) ; } }
static int spiralDiaSum ( int n ) { if ( n == 1 ) return 1 ;
return ( 4 * n * n - 6 * n + 6 + spiralDiaSum ( n - 2 ) ) ; }
public static void Main ( String [ ] args ) { int n = 7 ; Console . Write ( spiralDiaSum ( n ) ) ; } }
public class GFG { public const int R = 3 ; public const int C = 5 ;
public static int numofneighbour ( int [ ] [ ] mat , int i , int j ) { int count = 0 ;
if ( i > 0 && mat [ i - 1 ] [ j ] == 1 ) { count ++ ; }
if ( j > 0 && mat [ i ] [ j - 1 ] == 1 ) { count ++ ; }
if ( i < R - 1 && mat [ i + 1 ] [ j ] == 1 ) { count ++ ; }
if ( j < C - 1 && mat [ i ] [ j + 1 ] == 1 ) { count ++ ; } return count ; }
public static int findperimeter ( int [ ] [ ] mat ) { int perimeter = 0 ;
for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) { if ( mat [ i ] [ j ] == 1 ) { perimeter += ( 4 - numofneighbour ( mat , i , j ) ) ; } } } return perimeter ; }
public static void Main ( string [ ] args ) { int [ ] [ ] mat = new int [ ] [ ] { new int [ ] { 0 , 1 , 0 , 0 , 0 } , new int [ ] { 1 , 1 , 1 , 0 , 0 } , new int [ ] { 1 , 0 , 0 , 0 , 0 } } ; Console . WriteLine ( findperimeter ( mat ) ) ; } }
using System ; class GFG { static int MAX = 100 ; static void printMatrixDiagonal ( int [ , ] mat , int n ) {
int i = 0 , j = 0 ;
bool isUp = true ;
for ( int k = 0 ; k < n * n ; ) {
if ( isUp ) { for ( ; i >= 0 && j < n ; j ++ , i -- ) { Console . Write ( mat [ i , j ] + " ▁ " ) ; k ++ ; }
if ( i < 0 && j <= n - 1 ) i = 0 ; if ( j == n ) { i = i + 2 ; j -- ; } }
else { for ( ; j >= 0 && i < n ; i ++ , j -- ) { Console . Write ( mat [ i , j ] + " ▁ " ) ; k ++ ; }
if ( j < 0 && i <= n - 1 ) j = 0 ; if ( i == n ) { j = j + 2 ; i -- ; } }
isUp = ! isUp ; } }
public static void Main ( ) { int [ , ] mat = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int n = 3 ; printMatrixDiagonal ( mat , n ) ; } }
using System ; public class MatrixDiag {
int [ , ] mat = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ;
int n = 4 , mode = 0 , it = 0 , lower = 0 ;
for ( int t = 0 ; t < ( 2 * n - 1 ) ; t ++ ) { int t1 = t ; if ( t1 >= n ) { mode ++ ; t1 = n - 1 ; it -- ; lower ++ ; } else { lower = 0 ; it ++ ; } for ( int i = t1 ; i >= lower ; i -- ) { if ( ( t1 + mode ) % 2 == 0 ) { Console . WriteLine ( mat [ i , t1 + lower - i ] ) ; } else { Console . WriteLine ( mat [ t1 + lower - i , i ] ) ; } } } } }
static int maxRowDiff ( int [ , ] mat , int m , int n ) {
int [ ] rowSum = new int [ m ] ;
for ( int i = 0 ; i < m ; i ++ ) { int sum = 0 ; for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i , j ] ; rowSum [ i ] = sum ; }
int max_diff = rowSum [ 1 ] - rowSum [ 0 ] ; int min_element = rowSum [ 0 ] ; for ( int i = 1 ; i < m ; i ++ ) {
if ( rowSum [ i ] - min_element > max_diff ) max_diff = rowSum [ i ] - min_element ;
if ( rowSum [ i ] < min_element ) min_element = rowSum [ i ] ; } return max_diff ; }
public static void Main ( ) { int m = 5 , n = 4 ; int [ , ] mat = { { - 1 , 2 , 3 , 4 } , { 5 , 3 , - 2 , 1 } , { 6 , 7 , 2 , - 3 } , { 2 , 9 , 1 , 4 } , { 2 , 1 , - 2 , 0 } } ; Console . Write ( maxRowDiff ( mat , m , n ) ) ; } }
using System ; class GFG { static int R = 4 ; static int C = 4 ;
static int getTotalCoverageOfMatrix ( int [ , ] mat ) { int res = 0 ;
for ( int i = 0 ; i < R ; i ++ ) {
bool isOne = false ;
for ( int j = 0 ; j < C ; j ++ ) {
if ( mat [ i , j ] == 1 ) isOne = true ;
else if ( isOne ) res ++ ; }
isOne = false ; for ( int j = C - 1 ; j >= 0 ; j -- ) { if ( mat [ i , j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } }
for ( int j = 0 ; j < C ; j ++ ) {
bool isOne = false ; for ( int i = 0 ; i < R ; i ++ ) { if ( mat [ i , j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } isOne = false ; for ( int i = R - 1 ; i >= 0 ; i -- ) { if ( mat [ i , j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } } return res ; }
static public void Main ( ) { int [ , ] mat = { { 0 , 0 , 0 , 0 } , { 1 , 0 , 0 , 1 } , { 0 , 1 , 1 , 0 } , { 0 , 1 , 0 , 0 } } ; Console . WriteLine ( getTotalCoverageOfMatrix ( mat ) ) ; } }
using System ; class GFG { static int R = 3 ; static int C = 4 ;
static int gcd ( int a , int b ) { if ( b == 0 ) return a ; return gcd ( b , a % b ) ; }
static void replacematrix ( int [ , ] mat , int n , int m ) { int [ ] rgcd = new int [ R ] ; int [ ] cgcd = new int [ C ] ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < m ; j ++ ) { rgcd [ i ] = gcd ( rgcd [ i ] , mat [ i , j ] ) ; cgcd [ j ] = gcd ( cgcd [ j ] , mat [ i , j ] ) ; } }
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) mat [ i , j ] = Math . Max ( rgcd [ i ] , cgcd [ j ] ) ; }
static public void Main ( ) { int [ , ] m = { { 1 , 2 , 3 , 3 } , { 4 , 5 , 6 , 6 } , { 7 , 8 , 9 , 9 } , } ; replacematrix ( m , R , C ) ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) Console . Write ( m [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } } }
using System ; class GFG {
static int sortedCount ( int [ , ] mat , int r , int c ) {
int result = 0 ;
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = 0 ; j < c - 1 ; j ++ ) if ( mat [ i , j + 1 ] <= mat [ i , j ] ) break ;
if ( j == c - 1 ) result ++ ; }
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = c - 1 ; j > 0 ; j -- ) if ( mat [ i , j - 1 ] <= mat [ i , j ] ) break ;
if ( c > 1 && j == 0 ) result ++ ; } return result ; }
public static void Main ( ) { int m = 4 , n = 5 ; int [ , ] mat = { { 1 , 2 , 3 , 4 , 5 } , { 4 , 3 , 1 , 2 , 6 } , { 8 , 7 , 6 , 5 , 4 } , { 5 , 7 , 8 , 9 , 10 } } ; Console . WriteLine ( sortedCount ( mat , m , n ) ) ; } }
using System ; class GFG {
static int maxXOR ( int [ , ] mat , int N ) {
int r_xor , c_xor ; int max_xor = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { r_xor = 0 ; c_xor = 0 ; for ( int j = 0 ; j < N ; j ++ ) {
r_xor = r_xor ^ mat [ i , j ] ;
c_xor = c_xor ^ mat [ j , i ] ; }
if ( max_xor < Math . Max ( r_xor , c_xor ) ) max_xor = Math . Max ( r_xor , c_xor ) ; }
return max_xor ; }
public static void Main ( ) { int N = 3 ; int [ , ] mat = { { 1 , 5 , 4 } , { 3 , 7 , 2 } , { 5 , 9 , 10 } } ; Console . Write ( " maximum ▁ XOR ▁ value ▁ : ▁ " + maxXOR ( mat , N ) ) ; } }
static void direction ( int R , int C ) { if ( R != C && R % 2 == 0 && C % 2 != 0 && R < C ) { Console . WriteLine ( " Left " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R > C ) { Console . WriteLine ( " Up " ) ; return ; } if ( R == C && R % 2 != 0 && C % 2 != 0 ) { Console . WriteLine ( " Right " ) ; return ; } if ( R == C && R % 2 == 0 && C % 2 == 0 ) { Console . WriteLine ( " Left " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R < C ) { Console . WriteLine ( " Right " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R > C ) { Console . WriteLine ( " Down " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R < C ) { Console . WriteLine ( " Left " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R > C ) { Console . WriteLine ( " Up " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 != 0 && R > C ) { Console . WriteLine ( " Down " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R < C ) { Console . WriteLine ( " Right " ) ; return ; } }
static public void Main ( ) { int R = 3 , C = 1 ; direction ( R , C ) ; } }
using System ; class GFG { static int R = 3 ; static int C = 6 ; static void spiralPrint ( int m , int n , int [ , ] a , int c ) { int i , k = 0 , l = 0 ; int count = 0 ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) { count ++ ; if ( count == c ) Console . WriteLine ( a [ k , i ] + " ▁ " ) ; } k ++ ;
for ( i = k ; i < m ; ++ i ) { count ++ ; if ( count == c ) Console . WriteLine ( a [ i , n - 1 ] + " ▁ " ) ; } n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) { count ++ ; if ( count == c ) Console . WriteLine ( a [ m - 1 , i ] + " ▁ " ) ; } m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) { count ++ ; if ( count == c ) Console . WriteLine ( a [ i , l ] + " ▁ " ) ; } l ++ ; } } }
static void Main ( ) { int [ , ] a = { { 1 , 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 , 17 , 18 } } ; int k = 17 ; spiralPrint ( R , C , a , k ) ; } }
using System ; class GFG {
static int findK ( int [ , ] A , int i , int j , int n , int m , int k ) { if ( n < 1 m < 1 ) return - 1 ;
if ( k <= m ) return A [ i + 0 , j + k - 1 ] ;
if ( k <= ( m + n - 1 ) ) return A [ i + ( k - m ) , j + m - 1 ] ;
if ( k <= ( m + n - 1 + m - 1 ) ) return A [ i + n - 1 , j + m - 1 - ( k - ( m + n - 1 ) ) ] ;
if ( k <= ( m + n - 1 + m - 1 + n - 2 ) ) return A [ i + n - 1 - ( k - ( m + n - 1 + m - 1 ) ) , j + 0 ] ;
return findK ( A , i + 1 , j + 1 , n - 2 , m - 2 , k - ( 2 * n + 2 * m - 4 ) ) ; }
static void Main ( ) { int [ , ] a = { { 1 , 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 , 17 , 18 } } ; int k = 17 ; Console . WriteLine ( findK ( a , 0 , 0 , 3 , 6 , k ) ) ; } }
using System ; class GFG { public static int N = 5 ; public static int M = 4 ;
static bool checkDiagonal ( int [ , ] mat , int i , int j ) { int res = mat [ i , j ] ; while ( ++ i < N && ++ j < M ) {
if ( mat [ i , j ] != res ) return false ; }
return true ; }
static bool isToepliz ( int [ , ] mat ) {
for ( int i = 0 ; i < M ; i ++ ) {
if ( ! checkDiagonal ( mat , 0 , i ) ) return false ; }
for ( int i = 1 ; i < N ; i ++ ) {
if ( ! checkDiagonal ( mat , i , 0 ) ) return false ; }
return true ; }
public static void Main ( ) { int [ , ] mat = { { 6 , 7 , 8 , 9 } , { 4 , 6 , 7 , 8 } , { 1 , 4 , 6 , 7 } , { 0 , 1 , 4 , 6 } , { 2 , 0 , 1 , 4 } } ;
if ( isToepliz ( mat ) ) Console . WriteLine ( " Matrix ▁ is ▁ a ▁ Toepliz ▁ " ) ; else Console . WriteLine ( " Matrix ▁ is ▁ not ▁ a ▁ Toepliz ▁ " ) ; } }
using System ; class GFG { public static int N = 5 ;
static int countZeroes ( int [ , ] mat ) {
int row = N - 1 , col = 0 ;
int count = 0 ; while ( col < N ) {
while ( mat [ row , col ] > 0 )
if ( -- row < 0 ) return count ;
count += ( row + 1 ) ;
col ++ ; } return count ; }
public static void Main ( ) { int [ , ] mat = { { 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 1 , 1 } , { 0 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } } ; Console . WriteLine ( countZeroes ( mat ) ) ; } }
using System ; class GFG { static int countNegative ( int [ , ] M , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < m ; j ++ ) { if ( M [ i , j ] < 0 ) count += 1 ;
else break ; } } return count ; }
public static void Main ( ) { int [ , ] M = { { - 3 , - 2 , - 1 , 1 } , { - 2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; Console . WriteLine ( countNegative ( M , 3 , 4 ) ) ; } }
static int countNegative ( int [ , ] M , int n , int m ) {
int count = 0 ;
int i = 0 ; int j = m - 1 ;
while ( j >= 0 && i < n ) { if ( M [ i , j ] < 0 ) {
count += j + 1 ;
i += 1 ; }
else j -= 1 ; } return count ; }
public static void Main ( ) { int [ , ] M = { { - 3 , - 2 , - 1 , 1 } , { - 2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; Console . WriteLine ( countNegative ( M , 3 , 4 ) ) ; } }
public class Node { public int data ; public Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class BinaryTree { public Node root ;
public virtual Node bintree2listUtil ( Node node ) {
if ( node == null ) { return node ; }
if ( node . left != null ) {
Node left = bintree2listUtil ( node . left ) ;
for ( ; left . right != null ; left = left . right ) { ; }
left . right = node ;
node . left = left ; }
if ( node . right != null ) {
Node right = bintree2listUtil ( node . right ) ;
for ( ; right . left != null ; right = right . left ) { ; }
right . left = node ;
node . right = right ; } return node ; }
public virtual Node bintree2list ( Node node ) {
if ( node == null ) { return node ; }
node = bintree2listUtil ( node ) ;
while ( node . left != null ) { node = node . left ; } return node ; }
public virtual void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . right ; } }
tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 12 ) ; tree . root . right = new Node ( 15 ) ; tree . root . left . left = new Node ( 25 ) ; tree . root . left . right = new Node ( 30 ) ; tree . root . right . left = new Node ( 36 ) ;
Node head = tree . bintree2list ( tree . root ) ;
tree . printList ( head ) ; } }
static int N = 10 ;
static int findLargestPlus ( int [ , ] mat ) {
int [ , ] left = new int [ N , N ] ; int [ , ] right = new int [ N , N ] ; int [ , ] top = new int [ N , N ] ; int [ , ] bottom = new int [ N , N ] ;
for ( int i = 0 ; i < N ; i ++ ) {
top [ 0 , i ] = mat [ 0 , i ] ;
bottom [ N - 1 , i ] = mat [ N - 1 , i ] ;
left [ i , 0 ] = mat [ i , 0 ] ;
right [ i , N - 1 ] = mat [ i , N - 1 ] ; }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 1 ; j < N ; j ++ ) {
if ( mat [ i , j ] == 1 ) left [ i , j ] = left [ i , j - 1 ] + 1 ; else left [ i , j ] = 0 ;
if ( mat [ j , i ] == 1 ) top [ j , i ] = top [ j - 1 , i ] + 1 ; else top [ j , i ] = 0 ;
j = N - 1 - j ;
if ( mat [ j , i ] == 1 ) bottom [ j , i ] = bottom [ j + 1 , i ] + 1 ; else bottom [ j , i ] = 0 ;
if ( mat [ i , j ] == 1 ) right [ i , j ] = right [ i , j + 1 ] + 1 ; else right [ i , j ] = 0 ;
j = N - 1 - j ; } }
int n = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
int len = Math . Min ( Math . Min ( top [ i , j ] , bottom [ i , j ] ) , Math . Min ( left [ i , j ] , right [ i , j ] ) ) ;
if ( len > n ) n = len ; } }
if ( n > 0 ) return 4 * ( n - 1 ) + 1 ;
return 0 ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } , { 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 } , { 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 } , { 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 } , { 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 } , { 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 } , { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 } } ; Console . Write ( findLargestPlus ( mat ) ) ; } }
using System ; using System . Text ; public class GFG {
public static StringBuilder findLeft ( StringBuilder str ) { int n = str . Length ;
while ( n > 0 ) { n -- ;
if ( str [ n ] == ' d ' ) { str [ n ] = ' c ' ; break ; } if ( str [ n ] == ' b ' ) { str [ n ] = ' a ' ; break ; }
if ( str [ n ] == ' a ' ) { str [ n ] = ' b ' ; } else if ( str [ n ] == ' c ' ) { str [ n ] = ' d ' ; } } return str ; }
public static void Main ( string [ ] args ) { StringBuilder str = new StringBuilder ( " aacbddc " ) ; Console . Write ( " Left ▁ of ▁ " + str + " ▁ is ▁ " + findLeft ( str ) ) ; } }
static void printSpiral ( int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
int x ;
x = Math . Min ( Math . Min ( i , j ) , Math . Min ( n - 1 - i , n - 1 - j ) ) ;
if ( i <= j ) Console . Write ( ( n - 2 * x ) * ( n - 2 * x ) - ( i - x ) - ( j - x ) + " TABSYMBOL " ) ;
else Console . ( ( n - 2 * x - 2 ) * ( n - 2 * x - 2 ) + ( i - x ) + ( - ) + " " ) ; } Console . WriteLine ( ) ; } }
public static void Main ( ) { int n = 5 ;
printSpiral ( n ) ; } }
static int findMaxValue ( int N , int [ , ] mat ) {
int maxValue = int . MinValue ;
for ( int a = 0 ; a < N - 1 ; a ++ ) for ( int b = 0 ; b < N - 1 ; b ++ ) for ( int d = a + 1 ; d < N ; d ++ ) for ( int e = b + 1 ; e < N ; e ++ ) if ( maxValue < ( mat [ d , e ] - mat [ a , b ] ) ) maxValue = mat [ d , e ] - mat [ a , b ] ; return maxValue ; }
public static void Main ( ) { int N = 5 ; int [ , ] mat = { { 1 , 2 , - 1 , - 4 , - 20 } , { - 8 , - 3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { - 4 , - 1 , 1 , 7 , - 6 } , { 0 , - 4 , 10 , - 5 , 1 } } ; Console . Write ( " Maximum ▁ Value ▁ is ▁ " + findMaxValue ( N , mat ) ) ; } }
static int findMaxValue ( int N , int [ , ] mat ) {
int maxValue = int . MinValue ;
int [ , ] maxArr = new int [ N , N ] ;
maxArr [ N - 1 , N - 1 ] = mat [ N - 1 , N - 1 ] ;
int maxv = mat [ N - 1 , N - 1 ] ; for ( int j = N - 2 ; j >= 0 ; j -- ) { if ( mat [ N - 1 , j ] > maxv ) maxv = mat [ N - 1 , j ] ; maxArr [ N - 1 , j ] = maxv ; }
maxv = mat [ N - 1 , N - 1 ] ; for ( int i = N - 2 ; i >= 0 ; i -- ) { if ( mat [ i , N - 1 ] > maxv ) maxv = mat [ i , N - 1 ] ; maxArr [ i , N - 1 ] = maxv ; }
for ( int i = N - 2 ; i >= 0 ; i -- ) { for ( int j = N - 2 ; j >= 0 ; j -- ) {
if ( maxArr [ i + 1 , j + 1 ] - mat [ i , j ] > maxValue ) maxValue = maxArr [ i + 1 , j + 1 ] - mat [ i , j ] ;
maxArr [ i , j ] = Math . Max ( mat [ i , j ] , Math . Max ( maxArr [ i , j + 1 ] , maxArr [ i + 1 , j ] ) ) ; } } return maxValue ; }
public static void Main ( ) { int N = 5 ; int [ , ] mat = { { 1 , 2 , - 1 , - 4 , - 20 } , { - 8 , - 3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { - 4 , - 1 , 1 , 7 , - 6 } , { 0 , - 4 , 10 , - 5 , 1 } } ; Console . Write ( " Maximum ▁ Value ▁ is ▁ " + findMaxValue ( N , mat ) ) ; } }
using System ; class GFG { public static void modifyMatrix ( int [ , ] mat , int R , int C ) { int [ ] row = new int [ R ] ; int [ ] col = new int [ C ] ; int i , j ;
for ( i = 0 ; i < R ; i ++ ) { row [ i ] = 0 ; }
for ( i = 0 ; i < C ; i ++ ) { col [ i ] = 0 ; }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( mat [ i , j ] == 1 ) { row [ i ] = 1 ; col [ j ] = 1 ; } } }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( row [ i ] == 1 col [ j ] == 1 ) { mat [ i , j ] = 1 ; } } } }
public static void printMatrix ( int [ , ] mat , int R , int C ) { int i , j ; for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { Console . Write ( mat [ i , j ] + " ▁ " ) ; } Console . WriteLine ( ) ; } }
static public void Main ( ) { int [ , ] mat = { { 1 , 0 , 0 , 1 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 } } ; Console . WriteLine ( " Matrix ▁ Intially " ) ; printMatrix ( mat , 3 , 4 ) ; modifyMatrix ( mat , 3 , 4 ) ; Console . WriteLine ( " Matrix ▁ after ▁ " + " modification ▁ n " ) ; printMatrix ( mat , 3 , 4 ) ; } }
using System ; class GFG { static int ROW = 4 ; static int COL = 5 ;
static void findUniqueRows ( int [ , ] M ) {
for ( int i = 0 ; i < ROW ; i ++ ) { int flag = 0 ;
for ( int j = 0 ; j < i ; j ++ ) { flag = 1 ; for ( int k = 0 ; k < COL ; k ++ ) if ( M [ i , k ] != M [ j , k ] ) flag = 0 ; if ( flag == 1 ) break ; }
if ( flag == 0 ) {
for ( int j = 0 ; j < COL ; j ++ ) Console . Write ( M [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } } }
static void Main ( ) { int [ , ] M = { { 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 1 , 0 } , { 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 0 , 0 } } ; findUniqueRows ( M ) ; } }
public class node { public int data ; public node left , right ; public node ( int data ) { this . data = data ; } } public static ;
public static void inorder ( node root ) { if ( root == null ) { return ; } inorder ( root . left ) ; Console . Write ( root . data + " ▁ " ) ; inorder ( root . right ) ; }
public static void fixPrevptr ( node root ) { if ( root == null ) { return ; } fixPrevptr ( root . left ) ; root . left = prev ; prev = root ; fixPrevptr ( root . right ) ; }
public static node fixNextptr ( node root ) {
while ( root . right != null ) { root = root . right ; }
while ( root != null && root . left != null ) { node left = root . left ; left . right = root ; root = root . left ; }
return root ; }
public static node BTTtoDLL ( node root ) { prev = null ;
fixPrevptr ( root ) ;
return fixNextptr ( root ) ; }
public static void printlist ( node root ) { while ( root != null ) { Console . Write ( root . data + " ▁ " ) ; root = root . right ; } }
node root = new node ( 10 ) ; root . left = new node ( 12 ) ; root . right = new node ( 15 ) ; root . left . left = new node ( 25 ) ; root . left . right = new node ( 30 ) ; root . right . left = new node ( 36 ) ; Console . WriteLine ( " Inorder ▁ Tree ▁ Traversal " ) ; inorder ( root ) ; node head = BTTtoDLL ( root ) ; Console . WriteLine ( " STRNEWLINE DLL ▁ Traversal " ) ; printlist ( head ) ; } }
using System ; class GFG { static int R = 3 ; static int C = 3 ;
static void swap ( int [ , ] mat , int row1 , int row2 , int col ) { for ( int i = 0 ; i < col ; i ++ ) { int temp = mat [ row1 , i ] ; mat [ row1 , i ] = mat [ row2 , i ] ; mat [ row2 , i ] = temp ; } }
static int rankOfMatrix ( int [ , ] mat ) { int rank = C ; for ( int row = 0 ; row < rank ; row ++ ) {
if ( mat [ row , row ] != 0 ) { for ( int col = 0 ; col < R ; col ++ ) { if ( col != row ) {
double mult = ( double ) mat [ col , row ] / mat [ row , row ] ; for ( int i = 0 ; i < rank ; i ++ ) mat [ col , i ] -= ( int ) mult * mat [ row , i ] ; } } }
else { bool reduce = true ;
for ( int i = row + 1 ; i < R ; i ++ ) {
if ( mat [ i , row ] != 0 ) { swap ( mat , row , i , rank ) ; reduce = false ; break ; } }
if ( reduce ) {
rank -- ;
for ( int i = 0 ; i < R ; i ++ ) mat [ i , row ] = mat [ i , rank ] ; }
row -- ; }
} return rank ; }
static void display ( int [ , ] mat , int row , int col ) { for ( int i = 0 ; i < row ; i ++ ) { for ( int j = 0 ; j < col ; j ++ ) Console . Write ( " ▁ " + mat [ i , j ] ) ; Console . Write ( " STRNEWLINE " ) ; } }
public static void Main ( ) { int [ , ] mat = { { 10 , 20 , 10 } , { - 20 , - 30 , 10 } , { 30 , 50 , 0 } } ; Console . Write ( " Rank ▁ of ▁ the ▁ matrix ▁ is ▁ : ▁ " + rankOfMatrix ( mat ) ) ; } }
using System ; class GFG { static int R = 3 ; static int C = 3 ;
public class Cell {
public Cell ( int r , int c ) { this . r = r ; this . c = c ; } } ;
static void printSums ( int [ , ] mat , Cell [ ] arr , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int sum = 0 , r = arr [ i ] . r , c = arr [ i ] . c ;
for ( int j = 0 ; j < R ; j ++ ) { for ( int k = 0 ; k < C ; k ++ ) { if ( j != r && k != c ) { sum += mat [ j , k ] ; } } } Console . WriteLine ( sum ) ; } }
public static void Main ( String [ ] args ) { int [ , ] mat = { { 1 , 1 , 2 } , { 3 , 4 , 6 } , { 5 , 3 , 2 } } ; Cell [ ] arr = { new Cell ( 0 , 0 ) , new Cell ( 1 , 1 ) , new Cell ( 0 , 1 ) } ; int n = arr . Length ; printSums ( mat , arr , n ) ; } }
static int countIslands ( int [ , ] mat , int m , int n ) {
int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( mat [ i , j ] == ' X ' ) { if ( ( i == 0 mat [ i - 1 , j ] == ' O ' ) && ( j == 0 mat [ i , j - 1 ] == ' O ' ) ) count ++ ; } } } return count ; }
public static void Main ( ) { int m = 6 ; int n = 3 ; int [ , ] mat = { { ' O ' , ' O ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' } , { ' O ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' O ' } } ; Console . WriteLine ( " Number ▁ of ▁ rectangular ▁ " + " islands ▁ is : ▁ " + countIslands ( mat , m , n ) ) ; } }
static int M = 4 ; static int N = 5 ;
static int findCommon ( int [ , ] mat ) {
int [ ] column = new int [ M ] ;
int min_row ;
int i ; for ( i = 0 ; i < M ; i ++ ) column [ i ] = N - 1 ;
min_row = 0 ;
while ( column [ min_row ] >= 0 ) {
for ( i = 0 ; i < M ; i ++ ) { if ( mat [ i , column [ i ] ] < mat [ min_row , column [ min_row ] ] ) min_row = i ; }
int eq_count = 0 ;
for ( i = 0 ; i < M ; i ++ ) {
if ( mat [ i , column [ i ] ] > mat [ min_row , column [ min_row ] ] ) { if ( column [ i ] == 0 ) return - 1 ;
column [ i ] -= 1 ; } else eq_count ++ ; }
if ( eq_count == M ) return mat [ min_row , column [ min_row ] ] ; } return - 1 ; }
public static void Main ( ) { int [ , ] mat = { { 1 , 2 , 3 , 4 , 5 } , { 2 , 4 , 5 , 8 , 10 } , { 3 , 5 , 7 , 9 , 11 } , { 1 , 3 , 5 , 7 , 9 } } ; int result = findCommon ( mat ) ; if ( result == - 1 ) Console . Write ( " No ▁ common ▁ element " ) ; else Console . Write ( " Common ▁ element ▁ is ▁ " + result ) ; } }
static int M = 4 ; static int N = 5 ;
static int findCommon ( int [ , ] mat ) {
Dictionary < int , int > cnt = new Dictionary < int , int > ( ) ; int i , j ; for ( i = 0 ; i < M ; i ++ ) {
if ( cnt . ContainsKey ( mat [ i , 0 ] ) ) { cnt [ mat [ i , 0 ] ] = cnt [ mat [ i , 0 ] ] + 1 ; } else { cnt . Add ( mat [ i , 0 ] , 1 ) ; }
for ( j = 1 ; j < N ; j ++ ) {
if ( mat [ i , j ] != mat [ i , j - 1 ] ) if ( cnt . ContainsKey ( mat [ i , j ] ) ) { cnt [ mat [ i , j ] ] = cnt [ mat [ i , j ] ] + 1 ; } else { cnt . Add ( mat [ i , j ] , 1 ) ; } } }
foreach ( KeyValuePair < int , int > ele in cnt ) { if ( ele . Value == M ) return ele . Key ; }
return - 1 ; }
public static void Main ( String [ ] args ) { int [ , ] mat = { { 1 , 2 , 3 , 4 , 5 } , { 2 , 4 , 5 , 8 , 10 } , { 3 , 5 , 7 , 9 , 11 } , { 1 , 3 , 5 , 7 , 9 } } ; int result = findCommon ( mat ) ; if ( result == - 1 ) Console . WriteLine ( " No ▁ common ▁ element " ) ; else Console . WriteLine ( " Common ▁ element ▁ is ▁ " + result ) ; } }
static int M = 6 ; static int N = 6 ;
static void floodFillUtil ( char [ , ] mat , int x , int y , char prevV , char newV ) {
if ( x < 0 x >= M y < 0 y >= N ) return ; if ( mat [ x , y ] != prevV ) return ;
mat [ x , y ] = newV ;
floodFillUtil ( mat , x + 1 , y , prevV , newV ) ; floodFillUtil ( mat , x - 1 , y , prevV , newV ) ; floodFillUtil ( mat , x , y + 1 , prevV , newV ) ; floodFillUtil ( mat , x , y - 1 , prevV , newV ) ; }
static void replaceSurrounded ( char [ , ] mat ) {
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i , j ] == ' O ' ) mat [ i , j ] = ' - ' ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i , 0 ] == ' - ' ) floodFillUtil ( mat , i , 0 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i , N - 1 ] == ' - ' ) floodFillUtil ( mat , i , N - 1 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ 0 , i ] == ' - ' ) floodFillUtil ( mat , 0 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ M - 1 , i ] == ' - ' ) floodFillUtil ( mat , M - 1 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i , j ] == ' - ' ) mat [ i , j ] = ' X ' ; }
public static void Main ( ) { char [ , ] mat = new char [ , ] { { ' X ' , ' O ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' X ' , ' O ' , ' X ' , ' X ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' O ' , ' X ' , ' X ' , ' X ' , ' X ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' , ' O ' , ' O ' , ' O ' } } ; replaceSurrounded ( mat ) ; for ( int i = 0 ; i < M ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) Console . Write ( mat [ i , j ] + " ▁ " ) ; Console . WriteLine ( " " ) ; } } }
public class Node { public int data ; public Node left , right ; public Node ( int data ) { this . data = data ; left = right = null ; } } class GFG { public Node root ;
public Node head ;
public virtual void BinaryTree2DoubleLinkedList ( Node root ) {
if ( root == null ) { return ; }
public static Node prev = null ;
BinaryTree2DoubleLinkedList ( root . left ) ;
if ( prev == null ) { head = root ; } else { root . left = prev ; prev . right = root ; } prev = root ;
BinaryTree2DoubleLinkedList ( root . right ) ; }
public virtual void printList ( Node node ) { while ( node != null ) { Console . Write ( node . data + " ▁ " ) ; node = node . right ; } }
GFG tree = new GFG ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 12 ) ; tree . root . right = new Node ( 15 ) ; tree . root . left . left = new Node ( 25 ) ; tree . root . left . right = new Node ( 30 ) ; tree . root . right . left = new Node ( 36 ) ;
tree . BinaryTree2DoubleLinkedList ( tree . root ) ;
tree . printList ( tree . head ) ; } }
using System ; class GFG { static int INF = int . MaxValue ; static int N = 4 ;
static void youngify ( int [ , ] mat , int i , int j ) {
int downVal = ( i + 1 < N ) ? mat [ i + 1 , j ] : INF ; int rightVal = ( j + 1 < N ) ? mat [ i , j + 1 ] : INF ;
if ( downVal == INF && rightVal == INF ) { return ; }
if ( downVal < rightVal ) { mat [ i , j ] = downVal ; mat [ i + 1 , j ] = INF ; youngify ( mat , i + 1 , j ) ; } else { mat [ i , j ] = rightVal ; mat [ i , j + 1 ] = INF ; youngify ( mat , i , j + 1 ) ; } }
static int extractMin ( int [ , ] mat ) { int ret = mat [ 0 , 0 ] ; mat [ 0 , 0 ] = INF ; youngify ( mat , 0 , 0 ) ; return ret ; }
static void printSorted ( int [ , ] mat ) { Console . WriteLine ( " Elements ▁ of ▁ matrix ▁ in ▁ sorted ▁ order ▁ n " ) ; for ( int i = 0 ; i < N * N ; i ++ ) { Console . Write ( extractMin ( mat ) + " ▁ " ) ; } }
static int n = 5 ;
static void printSumSimple ( int [ , ] mat , int k ) {
if ( k > n ) return ;
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
for ( int j = 0 ; j < n - k + 1 ; j ++ ) {
int sum = 0 ; for ( int p = i ; p < k + i ; p ++ ) for ( int q = j ; q < k + j ; q ++ ) sum += mat [ p , q ] ; Console . Write ( sum + " ▁ " ) ; }
Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] mat = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } } ; int k = 3 ; printSumSimple ( mat , k ) ; } }
static int n = 5 ;
static void printSumTricky ( int [ , ] mat , int k ) {
if ( k > n ) return ;
int [ , ] stripSum = new int [ n , n ] ;
for ( int j = 0 ; j < n ; j ++ ) {
int sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) sum += mat [ i , j ] ; stripSum [ 0 , j ] = sum ;
for ( int i = 1 ; i < n - k + 1 ; i ++ ) { sum += ( mat [ i + k - 1 , j ] - mat [ i - 1 , j ] ) ; stripSum [ i , j ] = sum ; } }
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
int sum = 0 ; for ( int j = 0 ; j < k ; j ++ ) sum += stripSum [ i , j ] ; Console . Write ( sum + " ▁ " ) ;
for ( int j = 1 ; j < n - k + 1 ; j ++ ) { sum += ( stripSum [ i , j + k - 1 ] - stripSum [ i , j - 1 ] ) ; Console . Write ( sum + " ▁ " ) ; } Console . WriteLine ( ) ; } }
public static void Main ( ) { int [ , ] mat = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; int k = 3 ; printSumTricky ( mat , k ) ; } }
using System ; class GFG { static int M = 3 ; static int N = 4 ;
static void transpose ( int [ , ] A , int [ , ] B ) { int i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < M ; j ++ ) B [ i , j ] = A [ j , i ] ; }
public static void Main ( ) { int [ , ] A = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } } ; int [ , ] B = new int [ N , M ] ; transpose ( A , B ) ; Console . WriteLine ( " Result ▁ matrix ▁ is ▁ STRNEWLINE " ) ; for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) Console . Write ( B [ i , j ] + " ▁ " ) ; Console . Write ( " STRNEWLINE " ) ; } } }
using System ; class GFG { static int N = 4 ;
static void transpose ( int [ , ] A ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) { int temp = A [ i , j ] ; A [ i , j ] = A [ j , i ] ; A [ j , i ] = temp ; } }
public static void Main ( ) { int [ , ] A = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; transpose ( A ) ; Console . WriteLine ( " Modified ▁ matrix ▁ is ▁ " ) ; for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) Console . Write ( A [ i , j ] + " ▁ " ) ; Console . WriteLine ( ) ; } } }
using System ; class GFG { static readonly int R = 5 ; static readonly int C = 4 ;
static bool isValid ( int x , int y1 , int y2 ) { return ( x >= 0 && x < R && y1 >= 0 && y1 < C && y2 >= 0 && y2 < C ) ; }
static int getMaxUtil ( int [ , ] arr , int [ , , ] mem , int x , int y1 , int y2 ) {
if ( ! isValid ( x , y1 , y2 ) ) return int . MinValue ;
if ( x == R - 1 && y1 == 0 && y2 == C - 1 ) return ( y1 == y2 ) ? arr [ x , y1 ] : arr [ x , y1 ] + arr [ x , y2 ] ;
if ( x == R - 1 ) return int . MinValue ;
if ( mem [ x , y1 , y2 ] != - 1 ) return mem [ x , y1 , y2 ] ;
int ans = int . MinValue ;
int temp = ( y1 == y2 ) ? arr [ x , y1 ] : arr [ x , y1 ] + arr [ x , y2 ] ;
ans = Math . Max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 - 1 ) ) ; ans = Math . Max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 + 1 ) ) ; ans = Math . Max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 ) ) ; ans = Math . Max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 ) ) ; ans = Math . Max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 - 1 ) ) ; ans = Math . Max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 + 1 ) ) ; ans = Math . Max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 ) ) ; ans = Math . Max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 - 1 ) ) ; ans = Math . Max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 + 1 ) ) ; return ( mem [ x , y1 , y2 ] = ans ) ; }
static int geMaxCollection ( int [ , ] arr ) {
int [ , , ] mem = new int [ R , C , C ] ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) { for ( int l = 0 ; l < C ; l ++ ) mem [ i , j , l ] = - 1 ; } }
return getMaxUtil ( arr , mem , 0 , 0 , C - 1 ) ; }
public static void Main ( String [ ] args ) { int [ , ] arr = { { 3 , 6 , 8 , 2 } , { 5 , 2 , 4 , 3 } , { 1 , 1 , 20 , 10 } , { 1 , 1 , 20 , 10 } , { 1 , 1 , 20 , 10 } , } ; Console . Write ( " Maximum ▁ collection ▁ is ▁ " + geMaxCollection ( arr ) ) ; } }
using System ; public class GFG { public const int R = 3 ; public const int C = 3 ;
public static int pathCountRec ( int [ ] [ ] mat , int m , int n , int k ) {
if ( m < 0 n < 0 ) { return 0 ; } if ( m == 0 && n == 0 && ( k == mat [ m ] [ n ] ) ) { return 1 ; }
return pathCountRec ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountRec ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; }
public static int pathCount ( int [ ] [ ] mat , int k ) { return pathCountRec ( mat , R - 1 , C - 1 , k ) ; }
public static void Main ( string [ ] args ) { int k = 12 ; int [ ] [ ] mat = new int [ ] [ ] { new int [ ] { 1 , 2 , 3 } , new int [ ] { 4 , 6 , 5 } , new int [ ] { 3 , 2 , 1 } } ; Console . WriteLine ( pathCount ( mat , k ) ) ; } }
using System ; class GFG { static readonly int R = 3 ; static readonly int C = 3 ; static readonly int MAX_K = 100 ; static int [ , , ] dp = new int [ R , C , MAX_K ] ; static int pathCountDPRecDP ( int [ , ] mat , int m , int n , int k ) {
if ( m < 0 n < 0 ) return 0 ; if ( m == 0 && n == 0 ) return ( k == mat [ m , n ] ? 1 : 0 ) ;
if ( dp [ m , n , k ] != - 1 ) return dp [ m , n , k ] ;
dp [ m , n , k ] = pathCountDPRecDP ( mat , m - 1 , n , k - mat [ m , n ] ) + pathCountDPRecDP ( mat , m , n - 1 , k - mat [ m , n ] ) ; return dp [ m , n , k ] ; }
static int pathCountDP ( int [ , ] mat , int k ) { for ( int i = 0 ; i < R ; i ++ ) for ( int j = 0 ; j < C ; j ++ ) for ( int l = 0 ; l < MAX_K ; l ++ ) dp [ i , j , l ] = - 1 ; return pathCountDPRecDP ( mat , R - 1 , C - 1 , k ) ; }
public static void Main ( String [ ] args ) { int k = 12 ; int [ , ] mat = { { 1 , 2 , 3 } , { 4 , 6 , 5 } , { 3 , 2 , 1 } } ; Console . WriteLine ( pathCountDP ( mat , k ) ) ; } }
static int [ ] x = { 0 , 1 , 1 , - 1 , 1 , 0 , - 1 , - 1 } ; static int [ ] y = { 1 , 0 , 1 , 1 , - 1 , - 1 , 0 , - 1 } ; static int R = 3 ; static int C = 3 ;
static int [ , ] dp = new int [ R , C ] ;
static bool isvalid ( int i , int j ) { if ( i < 0 j < 0 i >= R j >= C ) return false ; return true ; }
static bool isadjacent ( char prev , char curr ) { return ( ( curr - prev ) == 1 ) ; }
static int getLenUtil ( char [ , ] mat , int i , int j , char prev ) {
if ( ! isvalid ( i , j ) || ! isadjacent ( prev , mat [ i , j ] ) ) return 0 ;
if ( dp [ i , j ] != - 1 ) return dp [ i , j ] ;
int ans = 0 ;
for ( int k = 0 ; k < 8 ; k ++ ) ans = Math . Max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , mat [ i , j ] ) ) ;
return dp [ i , j ] = ans ; }
static int getLen ( char [ , ] mat , char s ) { for ( int i = 0 ; i < R ; ++ i ) for ( int j = 0 ; j < C ; ++ j ) dp [ i , j ] = - 1 ; int ans = 0 ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) {
if ( mat [ i , j ] == s ) {
for ( int k = 0 ; k < 8 ; k ++ ) ans = Math . Max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , s ) ) ; } } } return ans ; }
public static void Main ( ) { char [ , ] mat = { { ' a ' , ' c ' , ' d ' } , { ' h ' , ' b ' , ' a ' } , { ' i ' , ' g ' , ' f ' } } ; Console . WriteLine ( getLen ( mat , ' a ' ) ) ; Console . WriteLine ( getLen ( mat , ' e ' ) ) ; Console . WriteLine ( getLen ( mat , ' b ' ) ) ; Console . WriteLine ( getLen ( mat , ' f ' ) ) ; } }
using System ; class GFG { public static int n = 3 ;
public static int findLongestFromACell ( int i , int j , int [ ] [ ] mat , int [ ] [ ] dp ) {
if ( i < 0 i >= n j < 0 j >= n ) { return 0 ; }
if ( dp [ i ] [ j ] != - 1 ) { return dp [ i ] [ j ] ; }
int x = int . MinValue , y = int . MinValue , z = int . MinValue , w = int . MinValue ;
if ( j < n - 1 && ( ( mat [ i ] [ j ] + 1 ) == mat [ i ] [ j + 1 ] ) ) { x = dp [ i ] [ j ] = 1 + findLongestFromACell ( i , j + 1 , mat , dp ) ; } if ( j > 0 && ( mat [ i ] [ j ] + 1 == mat [ i ] [ j - 1 ] ) ) { y = dp [ i ] [ j ] = 1 + findLongestFromACell ( i , j - 1 , mat , dp ) ; } if ( i > 0 && ( mat [ i ] [ j ] + 1 == mat [ i - 1 ] [ j ] ) ) { z = dp [ i ] [ j ] = 1 + findLongestFromACell ( i - 1 , j , mat , dp ) ; } if ( i < n - 1 && ( mat [ i ] [ j ] + 1 == mat [ i + 1 ] [ j ] ) ) { w = dp [ i ] [ j ] = 1 + findLongestFromACell ( i + 1 , j , mat , dp ) ; }
dp [ i ] [ j ] = Math . Max ( x , Math . Max ( y , Math . Max ( z , Math . Max ( w , 1 ) ) ) ) ; return dp [ i ] [ j ] ; }
public static int finLongestOverAll ( int [ ] [ ] mat ) {
int result = 1 ;
int [ ] [ ] dp = RectangularArrays . ReturnRectangularIntArray ( n , n ) ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { dp [ i ] [ j ] = - 1 ; } }
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( dp [ i ] [ j ] == - 1 ) { findLongestFromACell ( i , j , mat , dp ) ; }
result = Math . Max ( result , dp [ i ] [ j ] ) ; } } return result ; }
public static void Main ( string [ ] args ) { int [ ] [ ] mat = new int [ ] [ ] { new int [ ] { 1 , 2 , 9 } , new int [ ] { 5 , 3 , 8 } , new int [ ] { 4 , 6 , 7 } } ; Console . WriteLine ( " Length ▁ of ▁ the ▁ longest ▁ path ▁ is ▁ " + finLongestOverAll ( mat ) ) ; } }
