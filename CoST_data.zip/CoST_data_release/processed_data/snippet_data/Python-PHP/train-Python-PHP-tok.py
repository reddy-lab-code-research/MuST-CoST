def TowerOfHanoi ( n , from_rod , to_rod , aux_rod ) : NEW_LINE INDENT if n == 1 : NEW_LINE INDENT print ( " Move ▁ disk ▁ 1 ▁ from ▁ rod " , from_rod , " to ▁ rod " , to_rod ) NEW_LINE return NEW_LINE DEDENT TowerOfHanoi ( n - 1 , from_rod , aux_rod , to_rod ) NEW_LINE print ( " Move ▁ disk " , n , " from ▁ rod " , from_rod , " to ▁ rod " , to_rod ) NEW_LINE TowerOfHanoi ( n - 1 , aux_rod , to_rod , from_rod ) NEW_LINE DEDENT
n = 4 NEW_LINE
TowerOfHanoi ( n , ' A ' , ' C ' , ' B ' ) NEW_LINE
INT_MIN = - 1000000 NEW_LINE def printMaxOfMin ( arr , n ) : NEW_LINE
for k in range ( 1 , n + 1 ) : NEW_LINE
maxOfMin = INT_MIN ; NEW_LINE
for i in range ( n - k + 1 ) : NEW_LINE
min = arr [ i ] NEW_LINE for j in range ( k ) : NEW_LINE INDENT if ( arr [ i + j ] < min ) : NEW_LINE INDENT min = arr [ i + j ] NEW_LINE DEDENT DEDENT
if ( min > maxOfMin ) : NEW_LINE INDENT maxOfMin = min NEW_LINE DEDENT
print ( maxOfMin , end = " ▁ " ) NEW_LINE
arr = [ 10 , 20 , 30 , 50 , 10 , 70 , 30 ] NEW_LINE n = len ( arr ) NEW_LINE printMaxOfMin ( arr , n ) NEW_LINE
def PrintMinNumberForPattern ( arr ) : NEW_LINE
curr_max = 0 NEW_LINE
last_entry = 0 NEW_LINE i = 0 NEW_LINE
while i < len ( arr ) : NEW_LINE
noOfNextD = 0 NEW_LINE if arr [ i ] == " I " : NEW_LINE
j = i + 1 NEW_LINE while j < len ( arr ) and arr [ j ] == " D " : NEW_LINE INDENT noOfNextD += 1 NEW_LINE j += 1 NEW_LINE DEDENT if i == 0 : NEW_LINE INDENT curr_max = noOfNextD + 2 NEW_LINE last_entry += 1 NEW_LINE DEDENT
print ( " " , last_entry , end = " " ) NEW_LINE print ( " " , curr_max , end = " " ) NEW_LINE
last_entry = curr_max NEW_LINE else : NEW_LINE
curr_max += noOfNextD + 1 NEW_LINE
last_entry = curr_max NEW_LINE print ( " " , last_entry , end = " " ) NEW_LINE
for k in range ( noOfNextD ) : NEW_LINE INDENT last_entry -= 1 NEW_LINE print ( " " , last_entry , end = " " ) NEW_LINE i += 1 NEW_LINE DEDENT
elif arr [ i ] == " D " : NEW_LINE INDENT if i == 0 : NEW_LINE DEDENT
j = i + 1 NEW_LINE while j < len ( arr ) and arr [ j ] == " D " : NEW_LINE INDENT noOfNextD += 1 NEW_LINE j += 1 NEW_LINE DEDENT
curr_max = noOfNextD + 2 NEW_LINE
print ( " " , curr_max , curr_max - 1 , end = " " ) NEW_LINE
last_entry = curr_max - 1 NEW_LINE else : NEW_LINE
print ( " " , last_entry - 1 , end = " " ) NEW_LINE last_entry -= 1 NEW_LINE i += 1 NEW_LINE print ( ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT PrintMinNumberForPattern ( " IDID " ) NEW_LINE PrintMinNumberForPattern ( " I " ) NEW_LINE PrintMinNumberForPattern ( " DD " ) NEW_LINE PrintMinNumberForPattern ( " II " ) NEW_LINE PrintMinNumberForPattern ( " DIDI " ) NEW_LINE PrintMinNumberForPattern ( " IIDDD " ) NEW_LINE PrintMinNumberForPattern ( " DDIDDIID " ) NEW_LINE DEDENT
st = [ ] ; NEW_LINE
def push_digits ( number ) : NEW_LINE INDENT while ( number != 0 ) : NEW_LINE INDENT st . append ( number % 10 ) ; NEW_LINE number = int ( number / 10 ) ; NEW_LINE DEDENT DEDENT
def reverse_number ( number ) : NEW_LINE
push_digits ( number ) ; NEW_LINE reverse = 0 ; NEW_LINE i = 1 ; NEW_LINE
while ( len ( st ) > 0 ) : NEW_LINE INDENT reverse = reverse + ( st [ len ( st ) - 1 ] * i ) ; NEW_LINE st . pop ( ) ; NEW_LINE i = i * 10 ; NEW_LINE DEDENT
return reverse ; NEW_LINE
number = 39997 ; NEW_LINE
print ( reverse_number ( number ) ) ; NEW_LINE
def heapify ( arr , n , i ) : NEW_LINE
largest = i NEW_LINE
l = 2 * i + 1 NEW_LINE
r = 2 * i + 2 NEW_LINE
if l < n and arr [ largest ] < arr [ l ] : NEW_LINE INDENT largest = l NEW_LINE DEDENT
if r < n and arr [ largest ] < arr [ r ] : NEW_LINE INDENT largest = r NEW_LINE DEDENT
if largest != i : NEW_LINE INDENT arr [ i ] , arr [ largest ] = arr [ largest ] , arr [ i ] NEW_LINE DEDENT
heapify ( arr , n , largest ) NEW_LINE
def heapSort ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE DEDENT
for i in range ( n // 2 - 1 , - 1 , - 1 ) : NEW_LINE INDENT heapify ( arr , n , i ) NEW_LINE DEDENT
for i in range ( n - 1 , 0 , - 1 ) : NEW_LINE
arr [ i ] , arr [ 0 ] = arr [ 0 ] , arr [ i ] NEW_LINE
heapify ( arr , i , 0 ) NEW_LINE
arr = [ 12 , 11 , 13 , 5 , 6 , 7 ] NEW_LINE heapSort ( arr ) NEW_LINE n = len ( arr ) NEW_LINE print ( " Sorted ▁ array ▁ is " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( " % d " % arr [ i ] ) , NEW_LINE DEDENT
def isHeap ( arr , i , n ) : NEW_LINE
if i >= int ( ( n - 2 ) / 2 ) : NEW_LINE INDENT return True NEW_LINE DEDENT
if ( arr [ i ] >= arr [ 2 * i + 1 ] and arr [ i ] >= arr [ 2 * i + 2 ] and isHeap ( arr , 2 * i + 1 , n ) and isHeap ( arr , 2 * i + 2 , n ) ) : NEW_LINE INDENT return True NEW_LINE DEDENT return False NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 ] NEW_LINE n = len ( arr ) - 1 NEW_LINE if isHeap ( arr , 0 , n ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT DEDENT
def isHeap ( arr , n ) : NEW_LINE
for i in range ( int ( ( n - 2 ) / 2 ) + 1 ) : NEW_LINE
if arr [ 2 * i + 1 ] > arr [ i ] : NEW_LINE INDENT return False NEW_LINE DEDENT
if ( 2 * i + 2 < n and arr [ 2 * i + 2 ] > arr [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE if isHeap ( arr , n ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT DEDENT
def generate_derangement ( N ) : NEW_LINE
S = [ 0 ] * ( N + 1 ) NEW_LINE for i in range ( 1 , N + 1 ) : NEW_LINE INDENT S [ i ] = i NEW_LINE DEDENT
D = [ 0 ] * ( N + 1 ) NEW_LINE for i in range ( 1 , N + 1 , 2 ) : NEW_LINE INDENT if i == N : NEW_LINE DEDENT
D [ N ] = S [ N - 1 ] NEW_LINE D [ N - 1 ] = S [ N ] NEW_LINE else : NEW_LINE D [ i ] = i + 1 NEW_LINE D [ i + 1 ] = i NEW_LINE
for i in range ( 1 , N + 1 ) : NEW_LINE INDENT print ( D [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT generate_derangement ( 10 ) NEW_LINE DEDENT
def sumBetweenTwoKth ( arr , n , k1 , k2 ) : NEW_LINE
arr . sort ( ) NEW_LINE
result = 0 NEW_LINE for i in range ( k1 , k2 - 1 ) : NEW_LINE INDENT result += arr [ i ] NEW_LINE DEDENT return result NEW_LINE
arr = [ 20 , 8 , 22 , 4 , 12 , 10 , 14 ] NEW_LINE k1 = 3 ; k2 = 6 NEW_LINE n = len ( arr ) NEW_LINE print ( sumBetweenTwoKth ( arr , n , k1 , k2 ) ) NEW_LINE
def minSum ( a , n ) : NEW_LINE
a = sorted ( a ) NEW_LINE num1 , num2 = 0 , 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if i % 2 == 0 : NEW_LINE INDENT num1 = num1 * 10 + a [ i ] NEW_LINE DEDENT else : NEW_LINE INDENT num2 = num2 * 10 + a [ i ] NEW_LINE DEDENT DEDENT return num2 + num1 NEW_LINE
arr = [ 5 , 3 , 0 , 7 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ required ▁ sum ▁ is " , minSum ( arr , n ) ) NEW_LINE
def printDistance ( mat ) : NEW_LINE INDENT global N , M NEW_LINE ans = [ [ None ] * M for i in range ( N ) ] NEW_LINE DEDENT
for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE INDENT ans [ i ] [ j ] = 999999999999 NEW_LINE DEDENT DEDENT
for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE DEDENT
for k in range ( N ) : NEW_LINE INDENT for l in range ( M ) : NEW_LINE DEDENT
if ( mat [ k ] [ l ] == 1 ) : NEW_LINE INDENT ans [ i ] [ j ] = min ( ans [ i ] [ j ] , abs ( i - k ) + abs ( j - l ) ) NEW_LINE DEDENT
for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE INDENT print ( ans [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
N = 3 NEW_LINE M = 4 NEW_LINE mat = [ [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 1 , 1 ] , [ 0 , 1 , 1 , 0 ] ] NEW_LINE printDistance ( mat ) NEW_LINE
def isMinHeap ( level , n ) : NEW_LINE
for i in range ( int ( n / 2 ) - 1 , - 1 , - 1 ) : NEW_LINE
if level [ i ] > level [ 2 * i + 1 ] : NEW_LINE INDENT return False NEW_LINE DEDENT if 2 * i + 2 < n : NEW_LINE
if level [ i ] > level [ 2 * i + 2 ] : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT level = [ 10 , 15 , 14 , 25 , 30 ] NEW_LINE n = len ( level ) NEW_LINE if isMinHeap ( level , n ) : NEW_LINE INDENT print ( " True " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " False " ) NEW_LINE DEDENT DEDENT
def mostFrequent ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
max_count = 1 ; res = arr [ 0 ] ; curr_count = 1 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] == arr [ i - 1 ] ) : NEW_LINE INDENT curr_count += 1 NEW_LINE DEDENT else : NEW_LINE INDENT if ( curr_count > max_count ) : NEW_LINE INDENT max_count = curr_count NEW_LINE res = arr [ i - 1 ] NEW_LINE DEDENT curr_count = 1 NEW_LINE DEDENT DEDENT
if ( curr_count > max_count ) : NEW_LINE INDENT max_count = curr_count NEW_LINE res = arr [ n - 1 ] NEW_LINE DEDENT return res NEW_LINE
arr = [ 1 , 5 , 2 , 1 , 3 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( mostFrequent ( arr , n ) ) NEW_LINE
def areDisjoint ( set1 , set2 , m , n ) : NEW_LINE
for i in range ( 0 , m ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE INDENT if ( set1 [ i ] == set2 [ j ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT
return True NEW_LINE
set1 = [ 12 , 34 , 11 , 9 , 3 ] NEW_LINE set2 = [ 7 , 2 , 1 , 5 ] NEW_LINE m = len ( set1 ) NEW_LINE n = len ( set2 ) NEW_LINE print ( " yes " ) if areDisjoint ( set1 , set2 , m , n ) else ( " ▁ No " ) NEW_LINE
def findMissing ( a , b , n , m ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT if ( a [ i ] == b [ j ] ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT if ( j == m - 1 ) : NEW_LINE INDENT print ( a [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 1 , 2 , 6 , 3 , 4 , 5 ] NEW_LINE b = [ 2 , 4 , 3 , 1 , 0 ] NEW_LINE n = len ( a ) NEW_LINE m = len ( b ) NEW_LINE findMissing ( a , b , n , m ) NEW_LINE DEDENT
def areEqual ( arr1 , arr2 , n , m ) : NEW_LINE
if ( n != m ) : NEW_LINE INDENT return False NEW_LINE DEDENT
arr1 . sort ( ) NEW_LINE arr2 . sort ( ) NEW_LINE
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( arr1 [ i ] != arr2 [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
return True NEW_LINE
arr1 = [ 3 , 5 , 2 , 5 , 2 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 5 , 2 ] NEW_LINE n = len ( arr1 ) NEW_LINE m = len ( arr2 ) NEW_LINE if ( areEqual ( arr1 , arr2 , n , m ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def isProduct ( arr , n , x ) : NEW_LINE
for i in arr : NEW_LINE INDENT for j in arr : NEW_LINE INDENT if i * j == x : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT DEDENT return False NEW_LINE
arr = [ 10 , 20 , 9 , 40 ] NEW_LINE x = 400 NEW_LINE n = len ( arr ) NEW_LINE if ( isProduct ( arr , n , x ) == True ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT x = 900 NEW_LINE if ( isProduct ( arr , n , x ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def findGreatest ( arr , n ) : NEW_LINE INDENT result = - 1 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n - 1 ) : NEW_LINE INDENT for k in range ( j + 1 , n ) : NEW_LINE INDENT if ( arr [ j ] * arr [ k ] == arr [ i ] ) : NEW_LINE INDENT result = max ( result , arr [ i ] ) NEW_LINE DEDENT DEDENT DEDENT DEDENT return result NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 30 , 10 , 9 , 3 , 35 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findGreatest ( arr , n ) ) NEW_LINE DEDENT
def subset ( ar , n ) : NEW_LINE
res = 0 NEW_LINE
ar . sort ( ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT count = 1 NEW_LINE DEDENT
for i in range ( n - 1 ) : NEW_LINE INDENT if ar [ i ] == ar [ i + 1 ] : NEW_LINE INDENT count += 1 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
res = max ( res , count ) NEW_LINE return res NEW_LINE
ar = [ 5 , 6 , 9 , 3 , 4 , 3 , 4 ] NEW_LINE n = len ( ar ) NEW_LINE print ( subset ( ar , n ) ) NEW_LINE
def getPairsCount ( arr , n , sum ) : NEW_LINE
count = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT if arr [ i ] + arr [ j ] == sum : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT DEDENT return count NEW_LINE
arr = [ 1 , 5 , 7 , - 1 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE sum = 6 NEW_LINE print ( " Count ▁ of ▁ pairs ▁ is " , getPairsCount ( arr , n , sum ) ) NEW_LINE
def countPairs ( arr1 , arr2 , m , n , x ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in range ( m ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE DEDENT
if arr1 [ i ] + arr2 [ j ] == x : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT
return count NEW_LINE
arr1 = [ 1 , 3 , 5 , 7 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 8 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE x = 10 NEW_LINE print ( " Count ▁ = ▁ " , countPairs ( arr1 , arr2 , m , n , x ) ) NEW_LINE
def isPresent ( arr , low , high , value ) : NEW_LINE INDENT while ( low <= high ) : NEW_LINE INDENT mid = ( low + high ) // 2 NEW_LINE DEDENT DEDENT
if ( arr [ mid ] == value ) : NEW_LINE INDENT return True NEW_LINE DEDENT elif ( arr [ mid ] > value ) : NEW_LINE INDENT high = mid - 1 NEW_LINE DEDENT else : NEW_LINE INDENT low = mid + 1 NEW_LINE DEDENT
return False NEW_LINE
def countPairs ( arr1 , arr2 , m , n , x ) : NEW_LINE INDENT count = 0 NEW_LINE for i in range ( m ) : NEW_LINE DEDENT
value = x - arr1 [ i ] NEW_LINE
if ( isPresent ( arr2 , 0 , n - 1 , value ) ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
return count NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr1 = [ 1 , 3 , 5 , 7 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 8 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE x = 10 NEW_LINE print ( " Count ▁ = ▁ " , countPairs ( arr1 , arr2 , m , n , x ) ) NEW_LINE DEDENT
def countPairs ( arr1 , arr2 , m , n , x ) : NEW_LINE INDENT count , l , r = 0 , 0 , n - 1 NEW_LINE DEDENT
while ( l < m and r >= 0 ) : NEW_LINE
if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) : NEW_LINE INDENT l += 1 NEW_LINE r -= 1 NEW_LINE count += 1 NEW_LINE DEDENT
elif ( ( arr1 [ l ] + arr2 [ r ] ) < x ) : NEW_LINE INDENT l += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT r -= 1 NEW_LINE DEDENT
return count NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr1 = [ 1 , 3 , 5 , 7 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 8 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE x = 10 NEW_LINE print ( " Count ▁ = " , countPairs ( arr1 , arr2 , m , n , x ) ) NEW_LINE DEDENT
def countPairs ( arr , n ) : NEW_LINE INDENT result = 0 ; NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT product = arr [ i ] * arr [ j ] ; NEW_LINE DEDENT DEDENT DEDENT
for k in range ( 0 , n ) : NEW_LINE
if ( arr [ k ] == product ) : NEW_LINE INDENT result = result + 1 ; NEW_LINE break ; NEW_LINE DEDENT
return result ; NEW_LINE
arr = [ 6 , 2 , 4 , 12 , 5 , 3 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE print ( countPairs ( arr , n ) ) ; NEW_LINE
def findPairs ( arr1 , arr2 , n , m , x ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , m ) : NEW_LINE INDENT if ( arr1 [ i ] + arr2 [ j ] == x ) : NEW_LINE INDENT print ( arr1 [ i ] , arr2 [ j ] ) NEW_LINE DEDENT DEDENT DEDENT DEDENT
arr1 = [ 1 , 2 , 3 , 7 , 5 , 4 ] NEW_LINE arr2 = [ 0 , 7 , 4 , 3 , 2 , 1 ] NEW_LINE n = len ( arr1 ) NEW_LINE m = len ( arr2 ) NEW_LINE x = 8 NEW_LINE findPairs ( arr1 , arr2 , n , m , x ) NEW_LINE
def findPair ( arr , n ) : NEW_LINE INDENT found = False NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT for k in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] + arr [ j ] == arr [ k ] ) : NEW_LINE INDENT print ( arr [ i ] , arr [ j ] ) NEW_LINE found = True NEW_LINE DEDENT DEDENT DEDENT DEDENT if ( found == False ) : NEW_LINE INDENT print ( " Not ▁ exist " ) NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 10 , 4 , 8 , 13 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE findPair ( arr , n ) NEW_LINE DEDENT
def printPairs ( arr , n , k ) : NEW_LINE INDENT isPairFound = True NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT
if ( i != j and arr [ i ] % arr [ j ] == k ) : NEW_LINE INDENT print ( " ( " , arr [ i ] , " , ▁ " , arr [ j ] , " ) " , sep = " " , end = " ▁ " ) NEW_LINE isPairFound = True NEW_LINE DEDENT return isPairFound NEW_LINE
arr = [ 2 , 3 , 5 , 4 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE if ( printPairs ( arr , n , k ) == False ) : NEW_LINE INDENT print ( " No ▁ such ▁ pair ▁ exists " ) NEW_LINE DEDENT
ASCII_SIZE = 256 NEW_LINE def getMaxOccuringChar ( str ) : NEW_LINE
count = [ 0 ] * ASCII_SIZE NEW_LINE
for i in str : NEW_LINE INDENT count [ ord ( i ) ] += 1 ; NEW_LINE DEDENT
max = - 1 NEW_LINE
for i in str : NEW_LINE INDENT if max < count [ ord ( i ) ] : NEW_LINE INDENT max = count [ ord ( i ) ] NEW_LINE c = i NEW_LINE DEDENT DEDENT return c NEW_LINE
str = " sample ▁ string " NEW_LINE print " Max ▁ occurring ▁ character ▁ is ▁ " + getMaxOccuringChar ( str ) NEW_LINE
def firstNonRepeating ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT j = 0 NEW_LINE while ( j < n ) : NEW_LINE INDENT if ( i != j and arr [ i ] == arr [ j ] ) : NEW_LINE INDENT break NEW_LINE DEDENT j += 1 NEW_LINE DEDENT if ( j == n ) : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT
arr = [ 9 , 4 , 9 , 6 , 7 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( firstNonRepeating ( arr , n ) ) NEW_LINE
def printKDistinct ( arr , n , k ) : NEW_LINE INDENT dist_count = 0 NEW_LINE for i in range ( n ) : NEW_LINE DEDENT
j = 0 NEW_LINE while j < n : NEW_LINE INDENT if ( i != j and arr [ j ] == arr [ i ] ) : NEW_LINE INDENT break NEW_LINE DEDENT j += 1 NEW_LINE DEDENT
if ( j == n ) : NEW_LINE INDENT dist_count += 1 NEW_LINE DEDENT if ( dist_count == k ) : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT return - 1 NEW_LINE
ar = [ 1 , 2 , 1 , 3 , 4 , 2 ] NEW_LINE n = len ( ar ) NEW_LINE k = 2 NEW_LINE print ( printKDistinct ( ar , n , k ) ) NEW_LINE
def subarrayDivisibleByK ( arr , n , k ) : NEW_LINE
mp = [ 0 ] * 1000 NEW_LINE
s = 0 ; e = 0 ; maxs = 0 ; maxe = 0 ; NEW_LINE
mp [ arr [ 0 ] % k ] = mp [ arr [ 0 ] % k ] + 1 ; NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT mod = arr [ i ] % k NEW_LINE DEDENT
while ( mp [ k - mod ] != 0 or ( mod == 0 and mp [ mod ] != 0 ) ) : NEW_LINE INDENT mp [ arr [ s ] % k ] = mp [ arr [ s ] % k ] - 1 NEW_LINE s = s + 1 NEW_LINE DEDENT
mp [ mod ] = mp [ mod ] + 1 NEW_LINE e = e + 1 NEW_LINE
if ( ( e - s ) > ( maxe - maxs ) ) : NEW_LINE INDENT maxe = e NEW_LINE maxs = s NEW_LINE DEDENT print ( " The ▁ maximum ▁ size ▁ is ▁ { } ▁ and ▁ the ▁ " . format ( ( maxe - maxs + 1 ) ) ) for i in range ( maxs , maxe + 1 ) : NEW_LINE print ( " { } ▁ " . format ( arr [ i ] ) , end = " " ) NEW_LINE
k = 3 NEW_LINE arr = [ 5 , 10 , 15 , 20 , 25 ] NEW_LINE n = len ( arr ) NEW_LINE subarrayDivisibleByK ( arr , n , k ) NEW_LINE
def findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) : NEW_LINE INDENT for i in range ( 0 , n1 ) : NEW_LINE INDENT for j in range ( 0 , n2 ) : NEW_LINE INDENT for k in range ( 0 , n3 ) : NEW_LINE INDENT if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT DEDENT DEDENT return False NEW_LINE DEDENT
a1 = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE a2 = [ 2 , 3 , 6 , 1 , 2 ] NEW_LINE a3 = [ 3 , 2 , 4 , 5 , 6 ] NEW_LINE sum = 9 NEW_LINE n1 = len ( a1 ) NEW_LINE n2 = len ( a2 ) NEW_LINE n3 = len ( a3 ) NEW_LINE print ( " Yes " ) if findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) else print ( " No " ) NEW_LINE
def areElementsContiguous ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] - arr [ i - 1 ] > 1 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT DEDENT return 1 NEW_LINE
arr = [ 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE if areElementsContiguous ( arr , n ) : print ( " Yes " ) NEW_LINE else : print ( " No " ) NEW_LINE
def minInsertion ( tr1 ) : NEW_LINE
n = len ( str1 ) NEW_LINE
res = 0 NEW_LINE
count = [ 0 for i in range ( 26 ) ] NEW_LINE
for i in range ( n ) : NEW_LINE INDENT count [ ord ( str1 [ i ] ) - ord ( ' a ' ) ] += 1 NEW_LINE DEDENT
for i in range ( 26 ) : NEW_LINE INDENT if ( count [ i ] % 2 == 1 ) : NEW_LINE INDENT res += 1 NEW_LINE DEDENT DEDENT
if ( res == 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE INDENT return res - 1 NEW_LINE DEDENT
str1 = " geeksforgeeks " NEW_LINE print ( minInsertion ( str1 ) ) NEW_LINE
def findDiff ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE count = 0 ; max_count = 0 ; min_count = n NEW_LINE for i in range ( 0 , ( n - 1 ) ) : NEW_LINE
if arr [ i ] == arr [ i + 1 ] : NEW_LINE INDENT count += 1 NEW_LINE continue NEW_LINE DEDENT else : NEW_LINE INDENT max_count = max ( max_count , count ) NEW_LINE min_count = min ( min_count , count ) NEW_LINE count = 0 NEW_LINE DEDENT return max_count - min_count NEW_LINE
arr = [ 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findDiff ( arr , n ) ) NEW_LINE
def maxDiff ( arr , n ) : NEW_LINE INDENT SubsetSum_1 = 0 NEW_LINE SubsetSum_2 = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT isSingleOccurance = True NEW_LINE for j in range ( i + 1 , n ) : NEW_LINE DEDENT DEDENT
if ( arr [ i ] == arr [ j ] ) : NEW_LINE INDENT isSingleOccurance = False NEW_LINE arr [ i ] = arr [ j ] = 0 NEW_LINE break NEW_LINE DEDENT if ( isSingleOccurance == True ) : NEW_LINE if ( arr [ i ] > 0 ) : NEW_LINE INDENT SubsetSum_1 += arr [ i ] NEW_LINE DEDENT else : NEW_LINE INDENT SubsetSum_2 += arr [ i ] NEW_LINE DEDENT return abs ( SubsetSum_1 - SubsetSum_2 ) NEW_LINE
arr = [ 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Maximum ▁ Difference ▁ = ▁ { } " . format ( maxDiff ( arr , n ) ) ) NEW_LINE
def maxDiff ( arr , n ) : NEW_LINE INDENT result = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
for i in range ( n - 1 ) : NEW_LINE INDENT if ( abs ( arr [ i ] ) != abs ( arr [ i + 1 ] ) ) : NEW_LINE INDENT result += abs ( arr [ i ] ) NEW_LINE DEDENT else : NEW_LINE INDENT pass NEW_LINE DEDENT DEDENT
if ( arr [ n - 2 ] != arr [ n - 1 ] ) : NEW_LINE INDENT result += abs ( arr [ n - 1 ] ) NEW_LINE DEDENT
return result NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Maximum ▁ Difference ▁ = ▁ " , maxDiff ( arr , n ) ) NEW_LINE DEDENT
def calculate ( a ) : NEW_LINE
a . sort ( ) NEW_LINE count = 1 NEW_LINE answer = 0 NEW_LINE
for i in range ( 1 , len ( a ) ) : NEW_LINE INDENT if a [ i ] == a [ i - 1 ] : NEW_LINE DEDENT
count += 1 NEW_LINE else : NEW_LINE
answer = answer + count * ( count - 1 ) // 2 NEW_LINE count = 1 NEW_LINE answer = answer + count * ( count - 1 ) // 2 NEW_LINE return answer NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 1 , 2 , 1 , 2 , 4 ] NEW_LINE DEDENT
print ( calculate ( a ) ) NEW_LINE
def calculate ( a ) : NEW_LINE
maximum = max ( a ) NEW_LINE
frequency = [ 0 for x in range ( maximum + 1 ) ] NEW_LINE
for i in a : NEW_LINE
frequency [ i ] += 1 NEW_LINE answer = 0 NEW_LINE
for i in frequency : NEW_LINE
answer = answer + i * ( i - 1 ) // 2 NEW_LINE return answer NEW_LINE
a = [ 1 , 2 , 1 , 2 , 4 ] NEW_LINE
print ( calculate ( a ) ) NEW_LINE
def printAllAPTriplets ( arr , n ) : NEW_LINE INDENT s = [ ] ; NEW_LINE for i in range ( 0 , n - 1 ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT DEDENT
diff = arr [ j ] - arr [ i ] ; NEW_LINE if ( ( arr [ i ] - diff ) in arr ) : NEW_LINE INDENT print ( " { } ▁ { } ▁ { } " . format ( ( arr [ i ] - diff ) , arr [ i ] , arr [ j ] ) , end =   " " ) ; NEW_LINE DEDENT s . append ( arr [ i ] ) ; NEW_LINE
arr = [ 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE printAllAPTriplets ( arr , n ) ; NEW_LINE
def printAllAPTriplets ( arr , n ) : NEW_LINE INDENT for i in range ( 1 , n - 1 ) : NEW_LINE DEDENT
j = i - 1 NEW_LINE k = i + 1 NEW_LINE while ( j >= 0 and k < n ) : NEW_LINE
if ( arr [ j ] + arr [ k ] == 2 * arr [ i ] ) : NEW_LINE INDENT print ( arr [ j ] , " " , arr [ i ] , " " , arr [ k ] ) NEW_LINE DEDENT
k += 1 NEW_LINE j -= 1 NEW_LINE
elif ( arr [ j ] + arr [ k ] < 2 * arr [ i ] ) : NEW_LINE INDENT k += 1 NEW_LINE DEDENT else : NEW_LINE INDENT j -= 1 NEW_LINE DEDENT
arr = [ 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 ] NEW_LINE n = len ( arr ) NEW_LINE printAllAPTriplets ( arr , n ) NEW_LINE
def countTriplets ( arr , n , m ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in range ( n - 2 ) : NEW_LINE INDENT for j in range ( i + 1 , n - 1 ) : NEW_LINE INDENT for k in range ( j + 1 , n ) : NEW_LINE INDENT if ( arr [ i ] * arr [ j ] * arr [ k ] == m ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT DEDENT DEDENT return count NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 4 , 6 , 2 , 3 , 8 ] NEW_LINE m = 24 NEW_LINE print ( countTriplets ( arr , len ( arr ) , m ) ) NEW_LINE DEDENT
def countPairs ( arr , n ) : NEW_LINE INDENT ans = 0 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT
if ( arr [ i ] == arr [ j ] ) : NEW_LINE INDENT ans += 1 NEW_LINE DEDENT return ans NEW_LINE
arr = [ 1 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countPairs ( arr , n ) ) NEW_LINE
def countNum ( arr , n ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( arr [ i ] != arr [ i + 1 ] and arr [ i ] != arr [ i + 1 ] - 1 ) : NEW_LINE INDENT count += arr [ i + 1 ] - arr [ i ] - 1 ; NEW_LINE DEDENT DEDENT return count NEW_LINE
arr = [ 3 , 5 , 8 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countNum ( arr , n ) ) NEW_LINE
def countSubarrays ( arr , n ) : NEW_LINE
difference = 0 NEW_LINE ans = 0 NEW_LINE
hash_positive = [ 0 ] * ( n + 1 ) NEW_LINE hash_negative = [ 0 ] * ( n + 1 ) NEW_LINE
hash_positive [ 0 ] = 1 NEW_LINE
for i in range ( n ) : NEW_LINE
if ( arr [ i ] & 1 == 1 ) : NEW_LINE INDENT difference = difference + 1 NEW_LINE DEDENT else : NEW_LINE INDENT difference = difference - 1 NEW_LINE DEDENT
if ( difference < 0 ) : NEW_LINE INDENT ans += hash_negative [ - difference ] NEW_LINE hash_negative [ - difference ] = hash_negative [ - difference ] + 1 NEW_LINE DEDENT
else : NEW_LINE INDENT ans += hash_positive [ difference ] NEW_LINE hash_positive [ difference ] = hash_positive [ difference ] + 1 NEW_LINE DEDENT
return ans NEW_LINE
arr = [ 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE
print ( " Total ▁ Number ▁ of ▁ Even - Odd ▁ subarrays ▁ are ▁ " + str ( countSubarrays ( arr , n ) ) ) NEW_LINE
def findLargestd ( S , n ) : NEW_LINE INDENT found = False NEW_LINE DEDENT
S . sort ( ) NEW_LINE
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT
if ( i == j ) : NEW_LINE INDENT continue NEW_LINE DEDENT for k in range ( j + 1 , n ) : NEW_LINE INDENT if ( i == k ) : NEW_LINE INDENT continue NEW_LINE DEDENT for l in range ( k + 1 , n ) : NEW_LINE INDENT if ( i == l ) : NEW_LINE INDENT continue NEW_LINE DEDENT DEDENT DEDENT
if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) : NEW_LINE INDENT found = True NEW_LINE return S [ i ] NEW_LINE DEDENT if ( found == False ) : NEW_LINE return - 1 NEW_LINE
S = [ 2 , 3 , 5 , 7 , 12 ] NEW_LINE n = len ( S ) NEW_LINE ans = findLargestd ( S , n ) NEW_LINE if ( ans == - 1 ) : NEW_LINE INDENT print ( " No ▁ Solution " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Largest ▁ d ▁ such ▁ that ▁ a ▁ + ▁ b ▁ + " , " c ▁ = ▁ d ▁ is " , ans ) NEW_LINE DEDENT
def recaman ( n ) : NEW_LINE
arr [ 0 ] = 0 NEW_LINE print ( arr [ 0 ] , end = " , ▁ " ) NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT curr = arr [ i - 1 ] - i NEW_LINE for j in range ( 0 , i ) : NEW_LINE DEDENT
if ( ( arr [ j ] == curr ) or curr < 0 ) : NEW_LINE INDENT curr = arr [ i - 1 ] + i NEW_LINE break NEW_LINE DEDENT arr [ i ] = curr NEW_LINE print ( arr [ i ] , end = " , ▁ " ) NEW_LINE
n = 17 NEW_LINE recaman ( n ) NEW_LINE
def recaman ( n ) : NEW_LINE INDENT if ( n <= 0 ) : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
print ( 0 , " , " , end = ' ' ) NEW_LINE s = set ( [ ] ) NEW_LINE s . add ( 0 ) NEW_LINE
prev = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT curr = prev - i NEW_LINE DEDENT
if ( curr < 0 or curr in s ) : NEW_LINE INDENT curr = prev + i NEW_LINE DEDENT s . add ( curr ) NEW_LINE print ( curr , " , " , end = ' ' ) NEW_LINE prev = curr NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = 17 NEW_LINE recaman ( n ) NEW_LINE DEDENT
def findArea ( arr , n ) : NEW_LINE
arr . sort ( reverse = True ) NEW_LINE
dimension = [ 0 , 0 ] NEW_LINE
i = 0 NEW_LINE j = 0 NEW_LINE while ( i < n - 1 and j < 2 ) : NEW_LINE
if ( arr [ i ] == arr [ i + 1 ] ) : NEW_LINE INDENT dimension [ j ] = arr [ i ] NEW_LINE j += 1 NEW_LINE i += 1 NEW_LINE DEDENT i += 1 NEW_LINE
return ( dimension [ 0 ] * dimension [ 1 ] ) NEW_LINE
arr = [ 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findArea ( arr , n ) ) NEW_LINE
def search ( arr , l , h , key ) : NEW_LINE INDENT if l > h : NEW_LINE INDENT return - 1 NEW_LINE DEDENT mid = ( l + h ) // 2 NEW_LINE if arr [ mid ] == key : NEW_LINE INDENT return mid NEW_LINE DEDENT DEDENT
if arr [ l ] <= arr [ mid ] : NEW_LINE
if key >= arr [ l ] and key <= arr [ mid ] : NEW_LINE INDENT return search ( arr , l , mid - 1 , key ) NEW_LINE DEDENT
return search ( arr , mid + 1 , h , key ) NEW_LINE
if key >= arr [ mid ] and key <= arr [ h ] : NEW_LINE INDENT return search ( a , mid + 1 , h , key ) NEW_LINE DEDENT return search ( arr , l , mid - 1 , key ) NEW_LINE
arr = [ 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 ] NEW_LINE key = 6 NEW_LINE i = search ( arr , 0 , len ( arr ) - 1 , key ) NEW_LINE if i != - 1 : NEW_LINE INDENT print ( " Index : ▁ % ▁ d " % i ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Key ▁ not ▁ found " ) NEW_LINE DEDENT
def pairInSortedRotated ( arr , n , x ) : NEW_LINE
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( arr [ i ] > arr [ i + 1 ] ) : NEW_LINE INDENT break ; NEW_LINE DEDENT DEDENT
l = ( i + 1 ) % n NEW_LINE
r = i NEW_LINE
while ( l != r ) : NEW_LINE
if ( arr [ l ] + arr [ r ] == x ) : NEW_LINE INDENT return True ; NEW_LINE DEDENT
if ( arr [ l ] + arr [ r ] < x ) : NEW_LINE INDENT l = ( l + 1 ) % n ; NEW_LINE DEDENT else : NEW_LINE
r = ( n + r - 1 ) % n ; NEW_LINE return False ; NEW_LINE
arr = [ 11 , 15 , 6 , 8 , 9 , 10 ] NEW_LINE sum = 16 NEW_LINE n = len ( arr ) NEW_LINE if ( pairInSortedRotated ( arr , n , sum ) ) : NEW_LINE INDENT print ( " Array ▁ has ▁ two ▁ elements ▁ with ▁ sum ▁ 16" ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Array ▁ doesn ' t ▁ have ▁ two ▁ elements ▁ with ▁ sum ▁ 16 ▁ " ) NEW_LINE DEDENT
def pairsInSortedRotated ( arr , n , x ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if arr [ i ] > arr [ i + 1 ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
l = ( i + 1 ) % n NEW_LINE
r = i NEW_LINE
cnt = 0 NEW_LINE
while ( l != r ) : NEW_LINE
if arr [ l ] + arr [ r ] == x : NEW_LINE INDENT cnt += 1 NEW_LINE DEDENT
if l == ( r - 1 + n ) % n : NEW_LINE INDENT return cnt NEW_LINE DEDENT l = ( l + 1 ) % n NEW_LINE r = ( r - 1 + n ) % n NEW_LINE
elif arr [ l ] + arr [ r ] < x : NEW_LINE INDENT l = ( l + 1 ) % n NEW_LINE DEDENT
else : NEW_LINE INDENT r = ( n + r - 1 ) % n NEW_LINE DEDENT return cnt NEW_LINE
arr = [ 11 , 15 , 6 , 7 , 9 , 10 ] NEW_LINE s = 16 NEW_LINE print ( pairsInSortedRotated ( arr , 6 , s ) ) NEW_LINE
def maxSum ( arr ) : NEW_LINE
arrSum = 0 NEW_LINE
currVal = 0 NEW_LINE n = len ( arr ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT arrSum = arrSum + arr [ i ] NEW_LINE currVal = currVal + ( i * arr [ i ] ) NEW_LINE DEDENT
maxVal = currVal NEW_LINE
for j in range ( 1 , n ) : NEW_LINE INDENT currVal = currVal + arrSum - n * arr [ n - j ] NEW_LINE if currVal > maxVal : NEW_LINE INDENT maxVal = currVal NEW_LINE DEDENT DEDENT
return maxVal NEW_LINE
arr = [ 10 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ] NEW_LINE print " Max ▁ sum ▁ is : ▁ " , maxSum ( arr ) NEW_LINE
def maxSum ( arr , n ) : NEW_LINE
res = - sys . maxsize NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
curr_sum = 0 NEW_LINE
for j in range ( 0 , n ) : NEW_LINE INDENT index = int ( ( i + j ) % n ) NEW_LINE curr_sum += j * arr [ index ] NEW_LINE DEDENT
res = max ( res , curr_sum ) NEW_LINE return res NEW_LINE
arr = [ 8 , 3 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxSum ( arr , n ) ) NEW_LINE
def maxSum ( arr , n ) : NEW_LINE
cum_sum = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT cum_sum += arr [ i ] NEW_LINE DEDENT
curr_val = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT curr_val += i * arr [ i ] NEW_LINE DEDENT
res = curr_val NEW_LINE
for i in range ( 1 , n ) : NEW_LINE
next_val = ( curr_val - ( cum_sum - arr [ i - 1 ] ) + arr [ i - 1 ] * ( n - 1 ) ) NEW_LINE
curr_val = next_val NEW_LINE
res = max ( res , next_val ) NEW_LINE return res NEW_LINE
arr = [ 8 , 3 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxSum ( arr , n ) ) NEW_LINE
def countRotations ( arr , n ) : NEW_LINE
min = arr [ 0 ] NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT if ( min > arr [ i ] ) : NEW_LINE INDENT min = arr [ i ] NEW_LINE min_index = i NEW_LINE DEDENT DEDENT return min_index ; NEW_LINE
arr = [ 15 , 18 , 2 , 3 , 6 , 12 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countRotations ( arr , n ) ) NEW_LINE
def countRotations ( arr , low , high ) : NEW_LINE
if ( high < low ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( high == low ) : NEW_LINE INDENT return low NEW_LINE DEDENT
mid = low + ( high - low ) / 2 ; NEW_LINE mid = int ( mid ) NEW_LINE
if ( mid < high and arr [ mid + 1 ] < arr [ mid ] ) : NEW_LINE INDENT return ( mid + 1 ) NEW_LINE DEDENT
if ( mid > low and arr [ mid ] < arr [ mid - 1 ] ) : NEW_LINE INDENT return mid NEW_LINE DEDENT
if ( arr [ high ] > arr [ mid ] ) : NEW_LINE INDENT return countRotations ( arr , low , mid - 1 ) ; NEW_LINE DEDENT return countRotations ( arr , mid + 1 , high ) NEW_LINE
arr = [ 15 , 18 , 2 , 3 , 6 , 12 ] NEW_LINE n = len ( arr ) NEW_LINE print ( countRotations ( arr , 0 , n - 1 ) ) NEW_LINE
def preprocess ( arr , n ) : NEW_LINE INDENT temp = [ None ] * ( 2 * n ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT temp [ i ] = temp [ i + n ] = arr [ i ] NEW_LINE DEDENT return temp NEW_LINE
def leftRotate ( arr , n , k , temp ) : NEW_LINE
start = k % n NEW_LINE
for i in range ( start , start + n ) : NEW_LINE INDENT print ( temp [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( " " ) NEW_LINE
arr = [ 1 , 3 , 5 , 7 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE temp = preprocess ( arr , n ) NEW_LINE k = 2 NEW_LINE leftRotate ( arr , n , k , temp ) NEW_LINE k = 3 NEW_LINE leftRotate ( arr , n , k , temp ) NEW_LINE k = 4 NEW_LINE leftRotate ( arr , n , k , temp ) NEW_LINE
def leftRotate ( arr , n , k ) : NEW_LINE
for i in range ( k , k + n ) : NEW_LINE INDENT print ( str ( arr [ i % n ] ) , end = " ▁ " ) NEW_LINE DEDENT
arr = [ 1 , 3 , 5 , 7 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE k = 2 ; NEW_LINE leftRotate ( arr , n , k ) NEW_LINE print ( ) NEW_LINE k = 3 ; NEW_LINE leftRotate ( arr , n , k ) NEW_LINE print ( ) NEW_LINE k = 4 NEW_LINE leftRotate ( arr , n , k ) NEW_LINE print ( ) NEW_LINE
def reverseArray ( arr , start , end ) : NEW_LINE INDENT while ( start < end ) : NEW_LINE INDENT arr [ start ] , arr [ end ] = arr [ end ] , arr [ start ] NEW_LINE start = start + 1 NEW_LINE end = end - 1 NEW_LINE DEDENT DEDENT
def rightRotate ( arr , d , n ) : NEW_LINE INDENT reverseArray ( arr , 0 , n - 1 ) ; NEW_LINE reverseArray ( arr , 0 , d - 1 ) ; NEW_LINE reverseArray ( arr , d , n - 1 ) ; NEW_LINE DEDENT
def prArray ( arr , size ) : NEW_LINE INDENT for i in range ( 0 , size ) : NEW_LINE INDENT print ( arr [ i ] , end = ' ▁ ' ) NEW_LINE DEDENT DEDENT
arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE rightRotate ( arr , k , n ) NEW_LINE prArray ( arr , n ) NEW_LINE
def maxHamming ( arr , n ) : NEW_LINE
brr = [ 0 ] * ( 2 * n + 1 ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT brr [ i ] = arr [ i ] NEW_LINE DEDENT for i in range ( n ) : NEW_LINE INDENT brr [ n + i ] = arr [ i ] NEW_LINE DEDENT
maxHam = 0 NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT currHam = 0 NEW_LINE k = 0 NEW_LINE for j in range ( i , i + n ) : NEW_LINE INDENT if brr [ j ] != arr [ k ] : NEW_LINE INDENT currHam += 1 NEW_LINE k = k + 1 NEW_LINE DEDENT DEDENT DEDENT
if currHam == n : NEW_LINE INDENT return n NEW_LINE DEDENT maxHam = max ( maxHam , currHam ) NEW_LINE return maxHam NEW_LINE
arr = [ 2 , 4 , 6 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxHamming ( arr , n ) ) NEW_LINE
def leftRotate ( arr , n , k ) : NEW_LINE
mod = k % n NEW_LINE s = " " NEW_LINE
for i in range ( n ) : NEW_LINE INDENT print str ( arr [ ( mod + i ) % n ] ) , NEW_LINE DEDENT print NEW_LINE return NEW_LINE
arr = [ 1 , 3 , 5 , 7 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE k = 2 NEW_LINE
leftRotate ( arr , n , k ) NEW_LINE k = 3 NEW_LINE
leftRotate ( arr , n , k ) NEW_LINE k = 4 NEW_LINE
leftRotate ( arr , n , k ) NEW_LINE
def findElement ( arr , ranges , rotations , index ) : NEW_LINE INDENT for i in range ( rotations - 1 , - 1 , - 1 ) : NEW_LINE DEDENT
left = ranges [ i ] [ 0 ] NEW_LINE right = ranges [ i ] [ 1 ] NEW_LINE
if ( left <= index and right >= index ) : NEW_LINE INDENT if ( index == left ) : NEW_LINE INDENT index = right NEW_LINE DEDENT else : NEW_LINE INDENT index = index - 1 NEW_LINE DEDENT DEDENT
return arr [ index ] NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE
rotations = 2 NEW_LINE
ranges = [ [ 0 , 2 ] , [ 0 , 3 ] ] NEW_LINE index = 1 NEW_LINE print ( findElement ( arr , ranges , rotations , index ) ) NEW_LINE
def splitArr ( arr , n , k ) : NEW_LINE INDENT for i in range ( 0 , k ) : NEW_LINE DEDENT
x = arr [ 0 ] NEW_LINE for j in range ( 0 , n - 1 ) : NEW_LINE INDENT arr [ j ] = arr [ j + 1 ] NEW_LINE DEDENT arr [ n - 1 ] = x NEW_LINE
arr = [ 12 , 10 , 5 , 6 , 52 , 36 ] NEW_LINE n = len ( arr ) NEW_LINE position = 2 NEW_LINE splitArr ( arr , n , position ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = ' ▁ ' ) NEW_LINE DEDENT
def rearrangeArr ( arr , n ) : NEW_LINE
evenPos = int ( n / 2 ) NEW_LINE
oddPos = n - evenPos NEW_LINE tempArr = np . empty ( n , dtype = object ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT tempArr [ i ] = arr [ i ] NEW_LINE DEDENT
tempArr . sort ( ) NEW_LINE j = oddPos - 1 NEW_LINE
for i in range ( 0 , n , 2 ) : NEW_LINE INDENT arr [ i ] = tempArr [ j ] NEW_LINE j = j - 1 NEW_LINE DEDENT j = oddPos NEW_LINE
for i in range ( 1 , n , 2 ) : NEW_LINE INDENT arr [ i ] = tempArr [ j ] NEW_LINE j = j + 1 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = ' ▁ ' ) NEW_LINE DEDENT
arr = a . array ( ' i ' , [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ) NEW_LINE rearrangeArr ( arr , 7 ) NEW_LINE
def pushZerosToEnd ( arr , n ) : NEW_LINE
count = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if arr [ i ] != 0 : NEW_LINE DEDENT
arr [ count ] = arr [ i ] NEW_LINE count += 1 NEW_LINE
while count < n : NEW_LINE INDENT arr [ count ] = 0 NEW_LINE count += 1 NEW_LINE DEDENT
arr = [ 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE pushZerosToEnd ( arr , n ) NEW_LINE print ( " Array ▁ after ▁ pushing ▁ all ▁ zeros ▁ to ▁ end ▁ of ▁ array : " ) NEW_LINE print ( arr ) NEW_LINE
def minSwap ( arr , n , k ) : NEW_LINE
count = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] <= k ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT DEDENT
bad = 0 NEW_LINE for i in range ( 0 , count ) : NEW_LINE INDENT if ( arr [ i ] > k ) : NEW_LINE INDENT bad = bad + 1 NEW_LINE DEDENT DEDENT
ans = bad NEW_LINE j = count NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT if ( j == n ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if ( arr [ i ] > k ) : NEW_LINE INDENT bad = bad - 1 NEW_LINE DEDENT
if ( arr [ j ] > k ) : NEW_LINE INDENT bad = bad + 1 NEW_LINE DEDENT
ans = min ( ans , bad ) NEW_LINE j = j + 1 NEW_LINE return ans NEW_LINE
arr = [ 2 , 1 , 5 , 6 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE print ( minSwap ( arr , n , k ) ) NEW_LINE arr1 = [ 2 , 7 , 9 , 5 , 8 , 7 , 4 ] NEW_LINE n = len ( arr1 ) NEW_LINE k = 5 NEW_LINE print ( minSwap ( arr1 , n , k ) ) NEW_LINE
def reorder ( arr , index , n ) : NEW_LINE INDENT temp = [ 0 ] * n ; NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT temp [ index [ i ] ] = arr [ i ] NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT arr [ i ] = temp [ i ] NEW_LINE index [ i ] = i NEW_LINE DEDENT
arr = [ 50 , 40 , 70 , 60 , 90 ] NEW_LINE index = [ 3 , 0 , 4 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE reorder ( arr , index , n ) NEW_LINE print ( " Reordered ▁ array ▁ is : " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( " Modified Index array is : " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( index [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def printArray ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
def RearrangePosNeg ( arr , n ) : NEW_LINE INDENT for i in range ( 1 , n ) : NEW_LINE INDENT key = arr [ i ] NEW_LINE DEDENT DEDENT
if ( key > 0 ) : NEW_LINE INDENT continue NEW_LINE DEDENT
j = i - 1 NEW_LINE while ( j >= 0 and arr [ j ] > 0 ) : NEW_LINE INDENT arr [ j + 1 ] = arr [ j ] NEW_LINE j = j - 1 NEW_LINE DEDENT
arr [ j + 1 ] = key NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 ] NEW_LINE n = len ( arr ) NEW_LINE RearrangePosNeg ( arr , n ) NEW_LINE printArray ( arr , n ) NEW_LINE DEDENT
def rearrange ( arr , n ) : NEW_LINE
temp = n * [ None ] NEW_LINE
small , large = 0 , n - 1 NEW_LINE
flag = True NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if flag is True : NEW_LINE INDENT temp [ i ] = arr [ large ] NEW_LINE large -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT temp [ i ] = arr [ small ] NEW_LINE small += 1 NEW_LINE DEDENT flag = bool ( 1 - flag ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT arr [ i ] = temp [ i ] NEW_LINE DEDENT return arr NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Original ▁ Array " ) NEW_LINE print ( arr ) NEW_LINE print ( " Modified ▁ Array " ) NEW_LINE print ( rearrange ( arr , n ) ) NEW_LINE
def rearrange ( arr , n ) : NEW_LINE
max_idx = n - 1 NEW_LINE min_idx = 0 NEW_LINE
max_elem = arr [ n - 1 ] + 1 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
if i % 2 == 0 : NEW_LINE INDENT arr [ i ] += ( arr [ max_idx ] % max_elem ) * max_elem NEW_LINE max_idx -= 1 NEW_LINE DEDENT
else : NEW_LINE INDENT arr [ i ] += ( arr [ min_idx ] % max_elem ) * max_elem NEW_LINE min_idx += 1 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT arr [ i ] = arr [ i ] / max_elem NEW_LINE DEDENT
arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Original ▁ Array " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT rearrange ( arr , n ) NEW_LINE print ( " Modified Array " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( int ( arr [ i ] ) , end = " ▁ " ) NEW_LINE DEDENT
def rearrange ( arr , n ) : NEW_LINE INDENT j = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] < 0 ) : NEW_LINE INDENT temp = arr [ i ] NEW_LINE arr [ i ] = arr [ j ] NEW_LINE arr [ j ] = temp NEW_LINE j = j + 1 NEW_LINE DEDENT DEDENT DEDENT
print ( arr ) NEW_LINE
arr = [ - 1 , 2 , - 3 , 4 , 5 , 6 , - 7 , 8 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE rearrange ( arr , n ) NEW_LINE
def segregateElements ( arr , n ) : NEW_LINE
temp = [ 0 for k in range ( n ) ] NEW_LINE
j = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] >= 0 ) : NEW_LINE INDENT temp [ j ] = arr [ i ] NEW_LINE j += 1 NEW_LINE DEDENT DEDENT
if ( j == n or j == 0 ) : NEW_LINE INDENT return NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] < 0 ) : NEW_LINE INDENT temp [ j ] = arr [ i ] NEW_LINE j += 1 NEW_LINE DEDENT DEDENT
for k in range ( n ) : NEW_LINE INDENT arr [ k ] = temp [ k ] NEW_LINE DEDENT
arr = [ 1 , - 1 , - 3 , - 2 , 7 , 5 , 11 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE segregateElements ( arr , n ) ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT print arr [ i ] , NEW_LINE DEDENT
def rearrange ( arr , n ) : NEW_LINE INDENT for i in range ( n - 1 ) : NEW_LINE INDENT if ( i % 2 == 0 and arr [ i ] > arr [ i + 1 ] ) : NEW_LINE INDENT temp = arr [ i ] NEW_LINE arr [ i ] = arr [ i + 1 ] NEW_LINE arr [ i + 1 ] = temp NEW_LINE DEDENT if ( i % 2 != 0 and arr [ i ] < arr [ i + 1 ] ) : NEW_LINE INDENT temp = arr [ i ] NEW_LINE arr [ i ] = arr [ i + 1 ] NEW_LINE arr [ i + 1 ] = temp NEW_LINE DEDENT DEDENT DEDENT
def printArray ( arr , size ) : NEW_LINE INDENT for i in range ( size ) : NEW_LINE INDENT print ( arr [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
arr = [ 6 , 4 , 2 , 1 , 8 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Before ▁ rearranging : ▁ " ) NEW_LINE printArray ( arr , n ) NEW_LINE rearrange ( arr , n ) NEW_LINE print ( " After ▁ rearranging : " ) NEW_LINE printArray ( arr , n ) ; NEW_LINE
def rearrange ( a , size ) : NEW_LINE INDENT positive = 0 NEW_LINE negative = 1 NEW_LINE while ( True ) : NEW_LINE DEDENT
while ( positive < size and a [ positive ] >= 0 ) : NEW_LINE INDENT positive = positive + 2 NEW_LINE DEDENT
while ( negative < size and a [ negative ] <= 0 ) : NEW_LINE INDENT negative = negative + 2 NEW_LINE DEDENT
if ( positive < size and negative < size ) : NEW_LINE INDENT temp = a [ positive ] NEW_LINE a [ positive ] = a [ negative ] NEW_LINE a [ negative ] = temp NEW_LINE DEDENT
else : NEW_LINE INDENT break NEW_LINE DEDENT
arr = [ 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE rearrange ( arr , n ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def arrayEvenAndOdd ( arr , n ) : NEW_LINE INDENT i = - 1 NEW_LINE j = 0 NEW_LINE while ( j != n ) : NEW_LINE INDENT if ( arr [ j ] % 2 == 0 ) : NEW_LINE INDENT i = i + 1 NEW_LINE DEDENT DEDENT DEDENT
arr [ i ] , arr [ j ] = arr [ j ] , arr [ i ] NEW_LINE j = j + 1 NEW_LINE
for i in arr : NEW_LINE INDENT print ( str ( i ) + " ▁ " , end = ' ' ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE arrayEvenAndOdd ( arr , n ) NEW_LINE DEDENT
def largest ( arr , n ) : NEW_LINE INDENT return max ( arr ) NEW_LINE DEDENT
arr = [ 10 , 324 , 45 , 90 , 9808 ] NEW_LINE n = len ( arr ) NEW_LINE print ( largest ( arr , n ) ) NEW_LINE
def findElements ( arr , n ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT count = 0 NEW_LINE for j in range ( 0 , n ) : NEW_LINE INDENT if arr [ j ] > arr [ i ] : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT DEDENT if count >= 2 : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 2 , - 6 , 3 , 5 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE findElements ( arr , n ) NEW_LINE
def findElements ( arr , n ) : NEW_LINE INDENT arr . sort ( ) NEW_LINE for i in range ( 0 , n - 2 ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 2 , - 6 , 3 , 5 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE findElements ( arr , n ) NEW_LINE
import sys NEW_LINE def findElements ( arr , n ) : NEW_LINE INDENT first = - sys . maxsize NEW_LINE second = - sys . maxsize NEW_LINE for i in range ( 0 , n ) : NEW_LINE DEDENT
if ( arr [ i ] > first ) : NEW_LINE INDENT second = first NEW_LINE first = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > second ) : NEW_LINE INDENT second = arr [ i ] NEW_LINE DEDENT for i in range ( 0 , n ) : NEW_LINE if ( arr [ i ] < second ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
arr = [ 2 , - 6 , 3 , 5 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE findElements ( arr , n ) NEW_LINE
def findMean ( a , n ) : NEW_LINE INDENT sum = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT sum += a [ i ] NEW_LINE DEDENT return float ( sum / n ) NEW_LINE DEDENT
def findMedian ( a , n ) : NEW_LINE
sorted ( a ) NEW_LINE
if n % 2 != 0 : NEW_LINE INDENT return float ( a [ int ( n / 2 ) ] ) NEW_LINE DEDENT return float ( ( a [ int ( ( n - 1 ) / 2 ) ] + a [ int ( n / 2 ) ] ) / 2.0 ) NEW_LINE
a = [ 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 ] NEW_LINE n = len ( a ) NEW_LINE
print ( " Mean ▁ = " , findMean ( a , n ) ) NEW_LINE print ( " Median ▁ = " , findMedian ( a , n ) ) NEW_LINE
def printSmall ( arr , n , k ) : NEW_LINE
for i in range ( k , n ) : NEW_LINE
max_var = arr [ k - 1 ] NEW_LINE pos = k - 1 NEW_LINE for j in range ( k - 2 , - 1 , - 1 ) : NEW_LINE INDENT if ( arr [ j ] > max_var ) : NEW_LINE INDENT max_var = arr [ j ] NEW_LINE pos = j NEW_LINE DEDENT DEDENT
if ( max_var > arr [ i ] ) : NEW_LINE INDENT j = pos NEW_LINE while ( j < k - 1 ) : NEW_LINE INDENT arr [ j ] = arr [ j + 1 ] NEW_LINE j += 1 NEW_LINE DEDENT DEDENT
arr [ k - 1 ] = arr [ i ] NEW_LINE
for i in range ( 0 , k ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
arr = [ 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 ] NEW_LINE n = len ( arr ) NEW_LINE k = 5 NEW_LINE printSmall ( arr , n , k ) NEW_LINE
def sumNodes ( l ) : NEW_LINE
leafNodeCount = math . pow ( 2 , l - 1 ) ; NEW_LINE sumLastLevel = 0 ; NEW_LINE
sumLastLevel = ( ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ) ; NEW_LINE
sum = sumLastLevel * l ; NEW_LINE return int ( sum ) ; NEW_LINE
l = 3 ; NEW_LINE print ( sumNodes ( l ) ) ; NEW_LINE
def add ( arr , N , lo , hi , val ) : NEW_LINE INDENT arr [ lo ] += val NEW_LINE if ( hi != N - 1 ) : NEW_LINE INDENT arr [ hi + 1 ] -= val NEW_LINE DEDENT DEDENT
def updateArray ( arr , N ) : NEW_LINE
for i in range ( 1 , N ) : NEW_LINE INDENT arr [ i ] += arr [ i - 1 ] NEW_LINE DEDENT
def printArr ( arr , N ) : NEW_LINE INDENT updateArray ( arr , N ) NEW_LINE for i in range ( N ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
N = 6 NEW_LINE arr = [ 0 for i in range ( N ) ] NEW_LINE
add ( arr , N , 0 , 2 , 100 ) NEW_LINE add ( arr , N , 1 , 5 , 100 ) NEW_LINE add ( arr , N , 2 , 3 , 100 ) NEW_LINE printArr ( arr , N ) NEW_LINE
def GCD ( a , b ) : NEW_LINE INDENT if ( b == 0 ) : NEW_LINE INDENT return a NEW_LINE DEDENT return GCD ( b , a % b ) NEW_LINE DEDENT
def FillPrefixSuffix ( prefix , arr , suffix , n ) : NEW_LINE
prefix [ 0 ] = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT prefix [ i ] = GCD ( prefix [ i - 1 ] , arr [ i ] ) NEW_LINE DEDENT
suffix [ n - 1 ] = arr [ n - 1 ] NEW_LINE for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT suffix [ i ] = GCD ( suffix [ i + 1 ] , arr [ i ] ) NEW_LINE DEDENT
def GCDoutsideRange ( l , r , prefix , suffix , n ) : NEW_LINE
if ( l == 0 ) : NEW_LINE INDENT return suffix [ r + 1 ] NEW_LINE DEDENT
if ( r == n - 1 ) : NEW_LINE INDENT return prefix [ l - 1 ] NEW_LINE DEDENT return GCD ( prefix [ l - 1 ] , suffix [ r + 1 ] ) NEW_LINE
arr = [ 2 , 6 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE prefix = [ ] NEW_LINE suffix = [ ] NEW_LINE for i in range ( n + 1 ) : NEW_LINE INDENT prefix . append ( 0 ) NEW_LINE suffix . append ( 0 ) NEW_LINE DEDENT FillPrefixSuffix ( prefix , arr , suffix , n ) NEW_LINE l = 0 NEW_LINE r = 0 NEW_LINE print ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) NEW_LINE l = 1 NEW_LINE r = 1 NEW_LINE print ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) NEW_LINE l = 1 NEW_LINE r = 2 NEW_LINE print ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) NEW_LINE
def countInRange ( arr , n , x , y ) : NEW_LINE
count = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE
if ( arr [ i ] >= x and arr [ i ] <= y ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT return count NEW_LINE
arr = [ 1 , 3 , 4 , 9 , 10 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE
i = 1 NEW_LINE j = 4 NEW_LINE print ( countInRange ( arr , n , i , j ) ) NEW_LINE i = 9 NEW_LINE j = 12 NEW_LINE print ( countInRange ( arr , n , i , j ) ) NEW_LINE
def lowerIndex ( arr , n , x ) : NEW_LINE INDENT l = 0 NEW_LINE h = n - 1 NEW_LINE while ( l <= h ) : NEW_LINE INDENT mid = int ( ( l + h ) / 2 ) NEW_LINE if ( arr [ mid ] >= x ) : NEW_LINE h = mid - 1 NEW_LINE else : NEW_LINE l = mid + 1 NEW_LINE DEDENT return l NEW_LINE DEDENT
def upperIndex ( arr , n , x ) : NEW_LINE INDENT l = 0 NEW_LINE h = n - 1 NEW_LINE while ( l <= h ) : NEW_LINE INDENT mid = int ( ( l + h ) / 2 ) NEW_LINE if ( arr [ mid ] <= x ) : NEW_LINE l = mid + 1 NEW_LINE else : NEW_LINE h = mid - 1 NEW_LINE DEDENT return h NEW_LINE DEDENT
def countInRange ( arr , n , x , y ) : NEW_LINE
INDENT count = 0 ; NEW_LINE count = upperIndex ( arr , n , y ) - lowerIndex ( arr , n , x ) + 1 ; NEW_LINE return count NEW_LINE DEDENT
arr = [ 1 , 3 , 4 , 9 , 10 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE
arr . sort ( ) NEW_LINE
i = 1 NEW_LINE j = 4 NEW_LINE print ( countInRange ( arr , n , i , j ) ) NEW_LINE i = 9 NEW_LINE j = 12 NEW_LINE print ( countInRange ( arr , n , i , j ) ) NEW_LINE
def precompute ( arr , n , pre ) : NEW_LINE INDENT pre [ n - 1 ] = arr [ n - 1 ] * pow ( 2 , 0 ) NEW_LINE i = n - 2 NEW_LINE while ( i >= 0 ) : NEW_LINE INDENT pre [ i ] = ( pre [ i + 1 ] + arr [ i ] * ( 1 << ( n - 1 - i ) ) ) NEW_LINE i -= 1 NEW_LINE DEDENT DEDENT
def decimalOfSubarr ( arr , l , r , n , pre ) : NEW_LINE
if ( r != n - 1 ) : NEW_LINE INDENT return ( ( pre [ l ] - pre [ r + 1 ] ) / ( 1 << ( n - 1 - r ) ) ) NEW_LINE DEDENT return pre [ l ] / ( 1 << ( n - 1 - r ) ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 0 , 1 , 0 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE pre = [ 0 for i in range ( n ) ] NEW_LINE precompute ( arr , n , pre ) NEW_LINE print ( int ( decimalOfSubarr ( arr , 2 , 4 , n , pre ) ) ) NEW_LINE print ( int ( decimalOfSubarr ( arr , 4 , 5 , n , pre ) ) ) NEW_LINE DEDENT
def answerQuery ( a , n , l , r ) : NEW_LINE
count = 0 NEW_LINE
l = l - 1 NEW_LINE
for i in range ( l , r , 1 ) : NEW_LINE INDENT element = a [ i ] NEW_LINE divisors = 0 NEW_LINE DEDENT
for j in range ( l , r , 1 ) : NEW_LINE
if ( a [ j ] % a [ i ] == 0 ) : NEW_LINE INDENT divisors += 1 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT
if ( divisors == ( r - l ) ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
return count NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 1 , 2 , 3 , 5 ] NEW_LINE n = len ( a ) NEW_LINE l = 1 NEW_LINE r = 4 NEW_LINE print ( answerQuery ( a , n , l , r ) ) NEW_LINE l = 2 NEW_LINE r = 4 NEW_LINE print ( answerQuery ( a , n , l , r ) ) NEW_LINE DEDENT
import math NEW_LINE one = [ [ 0 for x in range ( 32 ) ] for y in range ( 100001 ) ] NEW_LINE MAX = 2147483647 NEW_LINE
def make_prefix ( A , n ) : NEW_LINE INDENT global one , MAX NEW_LINE for j in range ( 0 , 32 ) : NEW_LINE INDENT one [ 0 ] [ j ] = 0 NEW_LINE DEDENT DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT a = A [ i - 1 ] NEW_LINE for j in range ( 0 , 32 ) : NEW_LINE INDENT x = int ( math . pow ( 2 , j ) ) NEW_LINE DEDENT DEDENT
if ( a & x ) : NEW_LINE INDENT one [ i ] [ j ] = 1 + one [ i - 1 ] [ j ] NEW_LINE DEDENT else : NEW_LINE INDENT one [ i ] [ j ] = one [ i - 1 ] [ j ] NEW_LINE DEDENT
def Solve ( L , R ) : NEW_LINE INDENT global one , MAX NEW_LINE l = L NEW_LINE r = R NEW_LINE tot_bits = r - l + 1 NEW_LINE DEDENT
X = MAX NEW_LINE
for i in range ( 0 , 31 ) : NEW_LINE
x = one [ r ] [ i ] - one [ l - 1 ] [ i ] NEW_LINE
if ( x >= ( tot_bits - x ) ) : NEW_LINE INDENT ith_bit = pow ( 2 , i ) NEW_LINE DEDENT
X = X ^ ith_bit NEW_LINE return X NEW_LINE
n = 5 NEW_LINE q = 3 NEW_LINE A = [ 210 , 11 , 48 , 22 , 133 ] NEW_LINE L = [ 1 , 4 , 2 ] NEW_LINE R = [ 3 , 14 , 4 ] NEW_LINE make_prefix ( A , n ) NEW_LINE for j in range ( 0 , q ) : NEW_LINE INDENT print ( Solve ( L [ j ] , R [ j ] ) , end = " " ) NEW_LINE DEDENT
def answer_query ( a , n , l , r ) : NEW_LINE
count = 0 NEW_LINE for i in range ( l , r ) : NEW_LINE INDENT if ( a [ i ] == a [ i + 1 ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
a = [ 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 ] NEW_LINE n = len ( a ) NEW_LINE
L = 1 NEW_LINE R = 8 NEW_LINE print ( answer_query ( a , n , L , R ) ) NEW_LINE
L = 0 NEW_LINE R = 4 NEW_LINE print ( answer_query ( a , n , L , R ) ) NEW_LINE
N = 1000 NEW_LINE
prefixans = [ 0 ] * N ; NEW_LINE
def countIndex ( a , n ) : NEW_LINE INDENT global N , prefixans NEW_LINE DEDENT
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( a [ i ] == a [ i + 1 ] ) : NEW_LINE INDENT prefixans [ i ] = 1 NEW_LINE DEDENT if ( i != 0 ) : NEW_LINE INDENT prefixans [ i ] = ( prefixans [ i ] + prefixans [ i - 1 ] ) NEW_LINE DEDENT DEDENT
def answer_query ( l , r ) : NEW_LINE INDENT global N , prefixans NEW_LINE if ( l == 0 ) : NEW_LINE INDENT return prefixans [ r - 1 ] NEW_LINE DEDENT else : NEW_LINE INDENT return ( prefixans [ r - 1 ] - prefixans [ l - 1 ] ) NEW_LINE DEDENT DEDENT
a = [ 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 ] NEW_LINE n = len ( a ) NEW_LINE
countIndex ( a , n ) NEW_LINE
L = 1 NEW_LINE R = 8 NEW_LINE print ( answer_query ( L , R ) ) NEW_LINE
L = 0 NEW_LINE R = 4 NEW_LINE print ( answer_query ( L , R ) ) NEW_LINE
def repeated_digit ( n ) : NEW_LINE INDENT a = [ ] NEW_LINE DEDENT
while n != 0 : NEW_LINE INDENT d = n % 10 NEW_LINE DEDENT
if d in a : NEW_LINE
return 0 NEW_LINE a . append ( d ) NEW_LINE n = n // 10 NEW_LINE
return 1 NEW_LINE
def calculate ( L , R ) : NEW_LINE INDENT answer = 0 NEW_LINE DEDENT
for i in range ( L , R + 1 ) : NEW_LINE
answer = answer + repeated_digit ( i ) NEW_LINE return answer NEW_LINE
L = 1 NEW_LINE R = 100 NEW_LINE
print ( calculate ( L , R ) ) NEW_LINE
from sys import maxint NEW_LINE def maxSubArraySum ( a , size ) : NEW_LINE INDENT max_so_far = - maxint - 1 NEW_LINE max_ending_here = 0 NEW_LINE for i in range ( 0 , size ) : NEW_LINE INDENT max_ending_here = max_ending_here + a [ i ] NEW_LINE if ( max_so_far < max_ending_here ) : NEW_LINE INDENT max_so_far = max_ending_here NEW_LINE DEDENT if max_ending_here < 0 : NEW_LINE INDENT max_ending_here = 0 NEW_LINE DEDENT DEDENT return max_so_far NEW_LINE DEDENT
a = [ - 13 , - 3 , - 25 , - 20 , - 3 , - 16 , - 23 , - 12 , - 5 , - 22 , - 15 , - 4 , - 7 ] NEW_LINE print " Maximum ▁ contiguous ▁ sum ▁ is " , maxSubArraySum ( a , len ( a ) ) NEW_LINE
def maxSubArraySum ( a , size ) : NEW_LINE INDENT max_so_far = a [ 0 ] NEW_LINE max_ending_here = 0 NEW_LINE for i in range ( 0 , size ) : NEW_LINE INDENT max_ending_here = max_ending_here + a [ i ] NEW_LINE if max_ending_here < 0 : NEW_LINE INDENT max_ending_here = 0 NEW_LINE DEDENT DEDENT DEDENT
elif ( max_so_far < max_ending_here ) : NEW_LINE INDENT max_so_far = max_ending_here NEW_LINE DEDENT return max_so_far NEW_LINE
def maxSubArraySum ( a , size ) : NEW_LINE INDENT max_so_far = a [ 0 ] NEW_LINE curr_max = a [ 0 ] NEW_LINE for i in range ( 1 , size ) : NEW_LINE INDENT curr_max = max ( a [ i ] , curr_max + a [ i ] ) NEW_LINE max_so_far = max ( max_so_far , curr_max ) NEW_LINE DEDENT return max_so_far NEW_LINE DEDENT
a = [ - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 ] NEW_LINE print " Maximum ▁ contiguous ▁ sum ▁ is " , maxSubArraySum ( a , len ( a ) ) NEW_LINE
from sys import maxsize NEW_LINE def maxSubArraySum ( a , size ) : NEW_LINE INDENT max_so_far = - maxsize - 1 NEW_LINE max_ending_here = 0 NEW_LINE start = 0 NEW_LINE end = 0 NEW_LINE s = 0 NEW_LINE for i in range ( 0 , size ) : NEW_LINE INDENT max_ending_here += a [ i ] NEW_LINE if max_so_far < max_ending_here : NEW_LINE INDENT max_so_far = max_ending_here NEW_LINE start = s NEW_LINE end = i NEW_LINE DEDENT if max_ending_here < 0 : NEW_LINE INDENT max_ending_here = 0 NEW_LINE s = i + 1 NEW_LINE DEDENT DEDENT print ( " Maximum ▁ contiguous ▁ sum ▁ is ▁ % d " % ( max_so_far ) ) NEW_LINE print ( " Starting ▁ Index ▁ % d " % ( start ) ) NEW_LINE print ( " Ending ▁ Index ▁ % d " % ( end ) ) NEW_LINE DEDENT
a = [ - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 ] NEW_LINE maxSubArraySum ( a , len ( a ) ) NEW_LINE
def findMinAvgSubarray ( arr , n , k ) : NEW_LINE
if ( n < k ) : return 0 NEW_LINE
res_index = 0 NEW_LINE
curr_sum = 0 NEW_LINE for i in range ( k ) : NEW_LINE INDENT curr_sum += arr [ i ] NEW_LINE DEDENT
min_sum = curr_sum NEW_LINE
for i in range ( k , n ) : NEW_LINE
curr_sum += arr [ i ] - arr [ i - k ] NEW_LINE
if ( curr_sum < min_sum ) : NEW_LINE INDENT min_sum = curr_sum NEW_LINE res_index = ( i - k + 1 ) NEW_LINE DEDENT print ( " Subarray ▁ between ▁ [ " , res_index , " , ▁ " , ( res_index + k - 1 ) , " ] ▁ has ▁ minimum ▁ average " ) NEW_LINE
arr = [ 3 , 7 , 90 , 20 , 10 , 50 , 40 ] NEW_LINE
k = 3 NEW_LINE n = len ( arr ) NEW_LINE findMinAvgSubarray ( arr , n , k ) NEW_LINE
def minJumps ( arr , n ) : NEW_LINE
jumps = [ 0 for i in range ( n ) ] NEW_LINE
for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE
if ( arr [ i ] == 0 ) : NEW_LINE INDENT jumps [ i ] = float ( ' inf ' ) NEW_LINE DEDENT
elif ( arr [ i ] >= n - i - 1 ) : NEW_LINE INDENT jumps [ i ] = 1 NEW_LINE DEDENT
else : NEW_LINE
min = float ( ' inf ' ) NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( j <= arr [ i ] + i ) : NEW_LINE INDENT if ( min > jumps [ j ] ) : NEW_LINE INDENT min = jumps [ j ] NEW_LINE DEDENT DEDENT DEDENT
if ( min != float ( ' inf ' ) ) : NEW_LINE INDENT jumps [ i ] = min + 1 NEW_LINE DEDENT else : NEW_LINE
jumps [ i ] = min NEW_LINE return jumps [ 0 ] NEW_LINE
arr = [ 1 , 3 , 6 , 3 , 2 , 3 , 6 , 8 , 9 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE print ( ' Minimum ▁ number ▁ of ▁ jumps ▁ to ▁ reach ' , ' end ▁ is ' , minJumps ( arr , n - 1 ) ) NEW_LINE
def smallestSubWithSum ( arr , n , x ) : NEW_LINE
min_len = n + 1 NEW_LINE
for start in range ( 0 , n ) : NEW_LINE
curr_sum = arr [ start ] NEW_LINE
if ( curr_sum > x ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
for end in range ( start + 1 , n ) : NEW_LINE
curr_sum += arr [ end ] NEW_LINE
if curr_sum > x and ( end - start + 1 ) < min_len : NEW_LINE INDENT min_len = ( end - start + 1 ) NEW_LINE DEDENT return min_len ; NEW_LINE
arr1 = [ 1 , 4 , 45 , 6 , 10 , 19 ] NEW_LINE x = 51 NEW_LINE n1 = len ( arr1 ) NEW_LINE res1 = smallestSubWithSum ( arr1 , n1 , x ) ; NEW_LINE if res1 == n1 + 1 : NEW_LINE INDENT print ( " Not ▁ possible " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( res1 ) NEW_LINE DEDENT arr2 = [ 1 , 10 , 5 , 2 , 7 ] NEW_LINE n2 = len ( arr2 ) NEW_LINE x = 9 NEW_LINE res2 = smallestSubWithSum ( arr2 , n2 , x ) ; NEW_LINE if res2 == n2 + 1 : NEW_LINE INDENT print ( " Not ▁ possible " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( res2 ) NEW_LINE DEDENT arr3 = [ 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ] NEW_LINE n3 = len ( arr3 ) NEW_LINE x = 280 NEW_LINE res3 = smallestSubWithSum ( arr3 , n3 , x ) NEW_LINE if res3 == n3 + 1 : NEW_LINE INDENT print ( " Not ▁ possible " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( res3 ) NEW_LINE DEDENT
def smallestSubWithSum ( arr , n , x ) : NEW_LINE
curr_sum = 0 NEW_LINE min_len = n + 1 NEW_LINE
start = 0 NEW_LINE end = 0 NEW_LINE while ( end < n ) : NEW_LINE
while ( curr_sum <= x and end < n ) : NEW_LINE INDENT curr_sum += arr [ end ] NEW_LINE end += 1 NEW_LINE DEDENT
while ( curr_sum > x and start < n ) : NEW_LINE
if ( end - start < min_len ) : NEW_LINE INDENT min_len = end - start NEW_LINE DEDENT
curr_sum -= arr [ start ] NEW_LINE start += 1 NEW_LINE return min_len NEW_LINE
arr1 = [ 1 , 4 , 45 , 6 , 10 , 19 ] NEW_LINE x = 51 NEW_LINE n1 = len ( arr1 ) NEW_LINE res1 = smallestSubWithSum ( arr1 , n1 , x ) NEW_LINE print ( " Not ▁ possible " ) if ( res1 == n1 + 1 ) else print ( res1 ) NEW_LINE arr2 = [ 1 , 10 , 5 , 2 , 7 ] NEW_LINE n2 = len ( arr2 ) NEW_LINE x = 9 NEW_LINE res2 = smallestSubWithSum ( arr2 , n2 , x ) NEW_LINE print ( " Not ▁ possible " ) if ( res2 == n2 + 1 ) else print ( res2 ) NEW_LINE arr3 = [ 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ] NEW_LINE n3 = len ( arr3 ) NEW_LINE x = 280 NEW_LINE res3 = smallestSubWithSum ( arr3 , n3 , x ) NEW_LINE print ( " Not ▁ possible " ) if ( res3 == n3 + 1 ) else print ( res3 ) NEW_LINE
def findMaxAverage ( arr , n , k ) : NEW_LINE
if k > n : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
csum = [ 0 ] * n NEW_LINE csum [ 0 ] = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT csum [ i ] = csum [ i - 1 ] + arr [ i ] ; NEW_LINE DEDENT
max_sum = csum [ k - 1 ] NEW_LINE max_end = k - 1 NEW_LINE
for i in range ( k , n ) : NEW_LINE INDENT curr_sum = csum [ i ] - csum [ i - k ] NEW_LINE if curr_sum > max_sum : NEW_LINE INDENT max_sum = curr_sum NEW_LINE max_end = i NEW_LINE DEDENT DEDENT
return max_end - k + 1 NEW_LINE
arr = [ 1 , 12 , - 5 , - 6 , 50 , 3 ] NEW_LINE k = 4 NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ length " , k , " begins ▁ at ▁ index " , findMaxAverage ( arr , n , k ) ) NEW_LINE
def findMaxAverage ( arr , n , k ) : NEW_LINE
if ( k > n ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
sum = arr [ 0 ] NEW_LINE for i in range ( 1 , k ) : NEW_LINE INDENT sum += arr [ i ] NEW_LINE DEDENT max_sum = sum NEW_LINE max_end = k - 1 NEW_LINE
for i in range ( k , n ) : NEW_LINE INDENT sum = sum + arr [ i ] - arr [ i - k ] NEW_LINE if ( sum > max_sum ) : NEW_LINE INDENT max_sum = sum NEW_LINE max_end = i NEW_LINE DEDENT DEDENT
return max_end - k + 1 NEW_LINE
arr = [ 1 , 12 , - 5 , - 6 , 50 , 3 ] NEW_LINE k = 4 NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ length " , k , " begins ▁ at ▁ index " , findMaxAverage ( arr , n , k ) ) NEW_LINE
def countMinOperations ( target , n ) : NEW_LINE
result = 0 ; NEW_LINE
while ( True ) : NEW_LINE
zero_count = 0 ; NEW_LINE
i = 0 ; NEW_LINE while ( i < n ) : NEW_LINE
if ( ( target [ i ] & 1 ) > 0 ) : NEW_LINE INDENT break ; NEW_LINE DEDENT
elif ( target [ i ] == 0 ) : NEW_LINE INDENT zero_count += 1 ; NEW_LINE DEDENT i += 1 ; NEW_LINE
if ( zero_count == n ) : NEW_LINE INDENT return result ; NEW_LINE DEDENT
if ( i == n ) : NEW_LINE
for j in range ( n ) : NEW_LINE INDENT target [ j ] = target [ j ] // 2 ; NEW_LINE DEDENT result += 1 ; NEW_LINE
for j in range ( i , n ) : NEW_LINE INDENT if ( target [ j ] & 1 ) : NEW_LINE INDENT target [ j ] -= 1 ; NEW_LINE result += 1 ; NEW_LINE DEDENT DEDENT
arr = [ 16 , 16 , 16 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE print ( " Minimum ▁ number ▁ of ▁ steps ▁ required ▁ to " , 	 	 " get the given target array is " , countMinOperations ( arr , n ) ) ; NEW_LINE
def findMinOps ( arr , n ) : NEW_LINE
ans = 0 NEW_LINE
i , j = 0 , n - 1 NEW_LINE while i <= j : NEW_LINE
if arr [ i ] == arr [ j ] : NEW_LINE INDENT i += 1 NEW_LINE j -= 1 NEW_LINE DEDENT
elif arr [ i ] > arr [ j ] : NEW_LINE
j -= 1 NEW_LINE arr [ j ] += arr [ j + 1 ] NEW_LINE ans += 1 NEW_LINE
else : NEW_LINE INDENT i += 1 NEW_LINE arr [ i ] += arr [ i - 1 ] NEW_LINE ans += 1 NEW_LINE DEDENT return ans NEW_LINE
arr = [ 1 , 4 , 5 , 9 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Count ▁ of ▁ minimum ▁ operations ▁ is ▁ " + str ( findMinOps ( arr , n ) ) ) NEW_LINE
def findSmallest ( arr , n ) : NEW_LINE
res = 1 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT if arr [ i ] <= res : NEW_LINE INDENT res = res + arr [ i ] NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT return res NEW_LINE
arr1 = [ 1 , 3 , 4 , 5 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE print ( findSmallest ( arr1 , n1 ) ) NEW_LINE arr2 = [ 1 , 2 , 6 , 10 , 11 , 15 ] NEW_LINE n2 = len ( arr2 ) NEW_LINE print ( findSmallest ( arr2 , n2 ) ) NEW_LINE arr3 = [ 1 , 1 , 1 , 1 ] NEW_LINE n3 = len ( arr3 ) NEW_LINE print ( findSmallest ( arr3 , n3 ) ) NEW_LINE arr4 = [ 1 , 1 , 3 , 4 ] NEW_LINE n4 = len ( arr4 ) NEW_LINE print ( findSmallest ( arr4 , n4 ) ) NEW_LINE
def findMinDiff ( arr , n ) : NEW_LINE
diff = 10 ** 20 NEW_LINE
for i in range ( n - 1 ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT if abs ( arr [ i ] - arr [ j ] ) < diff : NEW_LINE INDENT diff = abs ( arr [ i ] - arr [ j ] ) NEW_LINE DEDENT DEDENT DEDENT
return diff NEW_LINE
arr = [ 1 , 5 , 3 , 19 , 18 , 25 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ difference ▁ is ▁ " + str ( findMinDiff ( arr , n ) ) ) NEW_LINE
def findMinDiff ( arr , n ) : NEW_LINE
arr = sorted ( arr ) NEW_LINE
diff = 10 ** 20 NEW_LINE
for i in range ( n - 1 ) : NEW_LINE INDENT if arr [ i + 1 ] - arr [ i ] < diff : NEW_LINE INDENT diff = arr [ i + 1 ] - arr [ i ] NEW_LINE DEDENT DEDENT
return diff NEW_LINE
arr = [ 1 , 5 , 3 , 19 , 18 , 25 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ difference ▁ is ▁ " + str ( findMinDiff ( arr , n ) ) ) NEW_LINE
a = 2 NEW_LINE b = 10 NEW_LINE size = abs ( b - a ) + 1 NEW_LINE array = [ 0 ] * size NEW_LINE
for i in range ( a , b + 1 ) : NEW_LINE INDENT if ( i % 2 == 0 or i % 5 == 0 ) : NEW_LINE INDENT array [ i - a ] = 1 NEW_LINE DEDENT DEDENT print ( " MULTIPLES ▁ of ▁ 2 ▁ and ▁ 5 : " ) NEW_LINE for i in range ( a , b + 1 ) : NEW_LINE INDENT if ( array [ i - a ] == 1 ) : NEW_LINE INDENT print ( i , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def longestCommonSum ( arr1 , arr2 , n ) : NEW_LINE
maxLen = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
sum1 = 0 NEW_LINE sum2 = 0 NEW_LINE
for j in range ( i , n ) : NEW_LINE
sum1 += arr1 [ j ] NEW_LINE sum2 += arr2 [ j ] NEW_LINE
if ( sum1 == sum2 ) : NEW_LINE INDENT len = j - i + 1 NEW_LINE if ( len > maxLen ) : NEW_LINE INDENT maxLen = len NEW_LINE DEDENT DEDENT return maxLen NEW_LINE
arr1 = [ 0 , 1 , 0 , 1 , 1 , 1 , 1 ] NEW_LINE arr2 = [ 1 , 1 , 1 , 1 , 1 , 0 , 1 ] NEW_LINE n = len ( arr1 ) NEW_LINE print ( " Length ▁ of ▁ the ▁ longest ▁ common ▁ span ▁ with ▁ same ▁ " " sum ▁ is " , longestCommonSum ( arr1 , arr2 , n ) ) NEW_LINE
def sortedAfterSwap ( A , B , n ) : NEW_LINE
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( B [ i ] == 1 ) : NEW_LINE INDENT j = i NEW_LINE while ( B [ j ] == 1 ) : NEW_LINE INDENT j = j + 1 NEW_LINE DEDENT DEDENT DEDENT
A = A [ 0 : i ] + sorted ( A [ i : j + 1 ] ) + A [ j + 1 : ] NEW_LINE i = j NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT if ( A [ i ] != i + 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
A = [ 1 , 2 , 5 , 3 , 4 , 6 ] NEW_LINE B = [ 0 , 1 , 1 , 1 , 0 ] NEW_LINE n = len ( A ) NEW_LINE if ( sortedAfterSwap ( A , B , n ) ) : NEW_LINE INDENT print ( " A ▁ can ▁ be ▁ sorted " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " A ▁ can ▁ not ▁ be ▁ sorted " ) NEW_LINE DEDENT
def sortedAfterSwap ( A , B , n ) : NEW_LINE INDENT for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if B [ i ] : NEW_LINE INDENT if A [ i ] != i + 1 : NEW_LINE INDENT A [ i ] , A [ i + 1 ] = A [ i + 1 ] , A [ i ] NEW_LINE DEDENT DEDENT DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT if A [ i ] != i + 1 : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT A = [ 1 , 2 , 5 , 3 , 4 , 6 ] NEW_LINE B = [ 0 , 1 , 1 , 1 , 0 ] NEW_LINE n = len ( A ) NEW_LINE if ( sortedAfterSwap ( A , B , n ) ) : NEW_LINE INDENT print ( " A ▁ can ▁ be ▁ sorted " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " A ▁ can ▁ not ▁ be ▁ sorted " ) NEW_LINE DEDENT DEDENT
def segregate0and1 ( arr , n ) : NEW_LINE INDENT type0 = 0 ; type1 = n - 1 NEW_LINE while ( type0 < type1 ) : NEW_LINE INDENT if ( arr [ type0 ] == 1 ) : NEW_LINE INDENT arr [ type0 ] , arr [ type1 ] = arr [ type1 ] , arr [ type0 ] NEW_LINE type1 -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT type0 += 1 NEW_LINE DEDENT DEDENT DEDENT
arr = [ 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE segregate0and1 ( arr , n ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def increasing ( a , n ) : NEW_LINE INDENT for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( a [ i ] >= a [ i + 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE DEDENT
def decreasing ( a , n ) : NEW_LINE INDENT for i in range ( 0 , n - 1 ) : NEW_LINE INDENT if ( a [ i ] < a [ i + 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE DEDENT def shortestUnsorted ( a , n ) : NEW_LINE
if ( increasing ( a , n ) == True or decreasing ( a , n ) == True ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE INDENT return 3 NEW_LINE DEDENT
ar = [ 7 , 9 , 10 , 8 , 11 ] NEW_LINE n = len ( ar ) NEW_LINE print ( shortestUnsorted ( ar , n ) ) NEW_LINE
def printUnion ( arr1 , arr2 , m , n ) : NEW_LINE INDENT i , j = 0 , 0 NEW_LINE while i < m and j < n : NEW_LINE INDENT if arr1 [ i ] < arr2 [ j ] : NEW_LINE INDENT print ( arr1 [ i ] ) NEW_LINE i += 1 NEW_LINE DEDENT elif arr2 [ j ] < arr1 [ i ] : NEW_LINE INDENT print ( arr2 [ j ] ) NEW_LINE j += 1 NEW_LINE DEDENT else : NEW_LINE INDENT print ( arr2 [ j ] ) NEW_LINE j += 1 NEW_LINE i += 1 NEW_LINE DEDENT DEDENT DEDENT
while i < m : NEW_LINE INDENT print ( arr1 [ i ] ) NEW_LINE i += 1 NEW_LINE DEDENT while j < n : NEW_LINE INDENT print ( arr2 [ j ] ) NEW_LINE j += 1 NEW_LINE DEDENT
arr1 = [ 1 , 2 , 4 , 5 , 6 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 7 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE printUnion ( arr1 , arr2 , m , n ) NEW_LINE
def printIntersection ( arr1 , arr2 , m , n ) : NEW_LINE INDENT i , j = 0 , 0 NEW_LINE while i < m and j < n : NEW_LINE INDENT if arr1 [ i ] < arr2 [ j ] : NEW_LINE INDENT i += 1 NEW_LINE DEDENT elif arr2 [ j ] < arr1 [ i ] : NEW_LINE INDENT j += 1 NEW_LINE DEDENT else : NEW_LINE INDENT print ( arr2 [ j ] ) NEW_LINE j += 1 NEW_LINE i += 1 NEW_LINE DEDENT DEDENT DEDENT
arr1 = [ 1 , 2 , 4 , 5 , 6 ] NEW_LINE arr2 = [ 2 , 3 , 5 , 7 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE
printIntersection ( arr1 , arr2 , m , n ) NEW_LINE
def printUnion ( arr1 , arr2 , m , n ) : NEW_LINE
if ( m > n ) : NEW_LINE INDENT tempp = arr1 NEW_LINE arr1 = arr2 NEW_LINE arr2 = tempp NEW_LINE temp = m NEW_LINE m = n NEW_LINE n = temp NEW_LINE DEDENT
arr1 . sort ( ) NEW_LINE for i in range ( 0 , m ) : NEW_LINE INDENT print ( arr1 [ i ] , end = " ▁ " ) NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) == - 1 ) : NEW_LINE INDENT print ( arr2 [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def printIntersection ( arr1 , arr2 , m , n ) : NEW_LINE
if ( m > n ) : NEW_LINE INDENT tempp = arr1 NEW_LINE arr1 = arr2 NEW_LINE arr2 = tempp NEW_LINE temp = m NEW_LINE m = n NEW_LINE n = temp NEW_LINE DEDENT
arr1 . sort ( ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) != - 1 ) : NEW_LINE INDENT print ( arr2 [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def binarySearch ( arr , l , r , x ) : NEW_LINE INDENT if ( r >= l ) : NEW_LINE INDENT mid = int ( l + ( r - l ) / 2 ) NEW_LINE DEDENT DEDENT
if ( arr [ mid ] == x ) : NEW_LINE INDENT return mid NEW_LINE DEDENT
if ( arr [ mid ] > x ) : NEW_LINE INDENT return binarySearch ( arr , l , mid - 1 , x ) NEW_LINE DEDENT
return binarySearch ( arr , mid + 1 , r , x ) NEW_LINE
return - 1 NEW_LINE
arr1 = [ 7 , 1 , 5 , 2 , 3 , 6 ] NEW_LINE arr2 = [ 3 , 8 , 6 , 20 , 7 ] NEW_LINE m = len ( arr1 ) NEW_LINE n = len ( arr2 ) NEW_LINE
print ( " Union ▁ of ▁ two ▁ arrays ▁ is ▁ " ) NEW_LINE printUnion ( arr1 , arr2 , m , n ) NEW_LINE print ( " Intersection of two arrays is   " ) NEW_LINE printIntersection ( arr1 , arr2 , m , n ) NEW_LINE
def intersection ( a , b , n , m ) : NEW_LINE INDENT i = 0 NEW_LINE j = 0 NEW_LINE while ( i < n and j < m ) : NEW_LINE INDENT if ( a [ i ] > b [ j ] ) : NEW_LINE INDENT j += 1 NEW_LINE DEDENT else : NEW_LINE INDENT if ( b [ j ] > a [ i ] ) : NEW_LINE INDENT i += 1 NEW_LINE DEDENT else : NEW_LINE DEDENT DEDENT DEDENT
print ( a [ i ] , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE j += 1 NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ 1 , 3 , 2 , 3 , 4 , 5 , 5 , 6 ] NEW_LINE b = [ 3 , 3 , 5 ] NEW_LINE n = len ( a ) NEW_LINE m = len ( b ) NEW_LINE DEDENT
a . sort ( ) NEW_LINE b . sort ( ) NEW_LINE
intersection ( a , b , n , m ) NEW_LINE
def countPairsWithDiffK ( arr , n , k ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE INDENT if arr [ i ] - arr [ j ] == k or arr [ j ] - arr [ i ] == k : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
arr = [ 1 , 5 , 3 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE print ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " , countPairsWithDiffK ( arr , n , k ) ) NEW_LINE
def binarySearch ( arr , low , high , x ) : NEW_LINE INDENT if ( high >= low ) : NEW_LINE INDENT mid = low + ( high - low ) // 2 NEW_LINE if x == arr [ mid ] : NEW_LINE INDENT return ( mid ) NEW_LINE DEDENT elif ( x > arr [ mid ] ) : NEW_LINE INDENT return binarySearch ( arr , ( mid + 1 ) , high , x ) NEW_LINE DEDENT else : NEW_LINE INDENT return binarySearch ( arr , low , ( mid - 1 ) , x ) NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT
def countPairsWithDiffK ( arr , n , k ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
for i in range ( 0 , n - 2 ) : NEW_LINE INDENT if ( binarySearch ( arr , i + 1 , n - 1 , arr [ i ] + k ) != - 1 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
arr = [ 1 , 5 , 3 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE print ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " , countPairsWithDiffK ( arr , n , k ) ) NEW_LINE
def countPairsWithDiffK ( arr , n , k ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE l = 0 NEW_LINE r = 0 NEW_LINE while r < n : NEW_LINE INDENT if arr [ r ] - arr [ l ] == k : NEW_LINE INDENT count += 1 NEW_LINE l += 1 NEW_LINE r += 1 NEW_LINE DEDENT DEDENT
elif arr [ r ] - arr [ l ] > k : NEW_LINE INDENT l += 1 NEW_LINE DEDENT else : NEW_LINE INDENT r += 1 NEW_LINE DEDENT return count NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 5 , 3 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE print ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " , countPairsWithDiffK ( arr , n , k ) ) NEW_LINE DEDENT
def constructArr ( arr , pair , n ) : NEW_LINE INDENT arr [ 0 ] = ( pair [ 0 ] + pair [ 1 ] - pair [ n - 1 ] ) // 2 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT arr [ i ] = pair [ i - 1 ] - arr [ 0 ] NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT pair = [ 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 ] NEW_LINE n = 5 NEW_LINE arr = [ 0 ] * n NEW_LINE constructArr ( arr , pair , n ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def merge ( ar1 , ar2 , m , n ) : NEW_LINE
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE
last = ar1 [ m - 1 ] NEW_LINE j = m - 2 NEW_LINE while ( j >= 0 and ar1 [ j ] > ar2 [ i ] ) : NEW_LINE INDENT ar1 [ j + 1 ] = ar1 [ j ] NEW_LINE j -= 1 NEW_LINE DEDENT
if ( j != m - 2 or last > ar2 [ i ] ) : NEW_LINE INDENT ar1 [ j + 1 ] = ar2 [ i ] NEW_LINE ar2 [ i ] = last NEW_LINE DEDENT
ar1 = [ 1 , 5 , 9 , 10 , 15 , 20 ] NEW_LINE ar2 = [ 2 , 3 , 8 , 13 ] NEW_LINE m = len ( ar1 ) NEW_LINE n = len ( ar2 ) NEW_LINE merge ( ar1 , ar2 , m , n ) NEW_LINE print ( " After Merging First Array : " , ▁ end = " " ) NEW_LINE for i in range ( m ) : NEW_LINE INDENT print ( ar1 [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT print ( " Second Array : " , ▁ end = " " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( ar2 [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT
def minmaxProduct ( arr1 , arr2 , n1 , n2 ) : NEW_LINE
arr1 . sort ( ) NEW_LINE arr2 . sort ( ) NEW_LINE
return arr1 [ n1 - 1 ] * arr2 [ 0 ] NEW_LINE
arr1 = [ 10 , 2 , 3 , 6 , 4 , 1 ] NEW_LINE arr2 = [ 5 , 1 , 4 , 2 , 6 , 9 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE n2 = len ( arr2 ) NEW_LINE print ( minmaxProduct ( arr1 , arr2 , n1 , n2 ) ) NEW_LINE
def minMaxProduct ( arr1 , arr2 , n1 , n2 ) : NEW_LINE
max = arr1 [ 0 ] NEW_LINE
min = arr2 [ 0 ] NEW_LINE i = 1 NEW_LINE while ( i < n1 and i < n2 ) : NEW_LINE
if ( arr1 [ i ] > max ) : NEW_LINE INDENT max = arr1 [ i ] NEW_LINE DEDENT
if ( arr2 [ i ] < min ) : NEW_LINE INDENT min = arr2 [ i ] NEW_LINE DEDENT i += 1 NEW_LINE
while ( i < n1 ) : NEW_LINE INDENT if ( arr1 [ i ] > max ) : NEW_LINE INDENT max = arr1 [ i ] NEW_LINE i += 1 NEW_LINE DEDENT DEDENT while ( i < n2 ) : NEW_LINE INDENT if ( arr2 [ i ] < min ) : NEW_LINE INDENT min = arr2 [ i ] NEW_LINE i += 1 NEW_LINE DEDENT DEDENT return max * min NEW_LINE
arr1 = [ 10 , 2 , 3 , 6 , 4 , 1 ] NEW_LINE arr2 = [ 5 , 1 , 4 , 2 , 6 , 9 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE n2 = len ( arr1 ) NEW_LINE print ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) NEW_LINE
def findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) : NEW_LINE
i , j , k = 0 , 0 , 0 NEW_LINE
while ( i < n1 and j < n2 and k < n3 ) : NEW_LINE
if ( ar1 [ i ] == ar2 [ j ] and ar2 [ j ] == ar3 [ k ] ) : NEW_LINE INDENT print ar1 [ i ] , NEW_LINE i += 1 NEW_LINE j += 1 NEW_LINE k += 1 NEW_LINE DEDENT
elif ar1 [ i ] < ar2 [ j ] : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
elif ar2 [ j ] < ar3 [ k ] : NEW_LINE INDENT j += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT k += 1 NEW_LINE DEDENT
ar1 = [ 1 , 5 , 10 , 20 , 40 , 80 ] NEW_LINE ar2 = [ 6 , 7 , 20 , 80 , 100 ] NEW_LINE ar3 = [ 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 ] NEW_LINE n1 = len ( ar1 ) NEW_LINE n2 = len ( ar2 ) NEW_LINE n3 = len ( ar3 ) NEW_LINE print " Common ▁ elements ▁ are " , NEW_LINE findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) NEW_LINE
def binary_search ( arr , l , r , x ) : NEW_LINE INDENT if r >= l : NEW_LINE INDENT mid = l + ( r - l ) / 2 NEW_LINE if arr [ mid ] == x : NEW_LINE INDENT return mid NEW_LINE DEDENT if arr [ mid ] > x : NEW_LINE INDENT return binary_search ( arr , l , mid - 1 , x ) NEW_LINE DEDENT return binary_search ( arr , mid + 1 , r , x ) NEW_LINE DEDENT return - 1 NEW_LINE DEDENT
def findPos ( a , key ) : NEW_LINE INDENT l , h , val = 0 , 1 , arr [ 0 ] NEW_LINE DEDENT
while val < key : NEW_LINE
l = h NEW_LINE
h = 2 * h NEW_LINE
val = arr [ h ] NEW_LINE
return binary_search ( a , l , h , key ) NEW_LINE
arr = [ 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 ] NEW_LINE ans = findPos ( arr , 10 ) NEW_LINE if ans == - 1 : NEW_LINE INDENT print " Element ▁ not ▁ found " NEW_LINE DEDENT else : NEW_LINE INDENT print " Element ▁ found ▁ at ▁ index " , ans NEW_LINE DEDENT
def findSingle ( ar , n ) : NEW_LINE INDENT res = ar [ 0 ] NEW_LINE DEDENT
for i in range ( 1 , n ) : NEW_LINE INDENT res = res ^ ar [ i ] NEW_LINE DEDENT return res NEW_LINE
ar = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] NEW_LINE print " Element ▁ occurring ▁ once ▁ is " , findSingle ( ar , len ( ar ) ) NEW_LINE
INT_MIN = - 2147483648 NEW_LINE def isPresent ( B , m , x ) : NEW_LINE INDENT for i in range ( 0 , m ) : NEW_LINE INDENT if B [ i ] == x : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT return False NEW_LINE DEDENT
def findMaxSubarraySumUtil ( A , B , n , m ) : NEW_LINE
max_so_far = INT_MIN NEW_LINE curr_max = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE
if isPresent ( B , m , A [ i ] ) == True : NEW_LINE INDENT curr_max = 0 NEW_LINE continue NEW_LINE DEDENT
curr_max = max ( A [ i ] , curr_max + A [ i ] ) NEW_LINE max_so_far = max ( max_so_far , curr_max ) NEW_LINE return max_so_far NEW_LINE
def findMaxSubarraySum ( A , B , n , m ) : NEW_LINE INDENT maxSubarraySum = findMaxSubarraySumUtil ( A , B , n , m ) NEW_LINE DEDENT
if maxSubarraySum == INT_MIN : NEW_LINE INDENT print ( ' Maximum ▁ Subarray ▁ Sum ▁ cant ▁ be ▁ found ' ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( ' The ▁ Maximum ▁ Subarray ▁ Sum ▁ = ' , maxSubarraySum ) NEW_LINE DEDENT
A = [ 3 , 4 , 5 , - 4 , 6 ] NEW_LINE B = [ 1 , 8 , 5 ] NEW_LINE n = len ( A ) NEW_LINE m = len ( B ) NEW_LINE
findMaxSubarraySum ( A , B , n , m ) NEW_LINE
def findMaxSum ( arr , n ) : NEW_LINE INDENT res = - sys . maxsize - 1 NEW_LINE for i in range ( n ) : NEW_LINE INDENT prefix_sum = arr [ i ] NEW_LINE for j in range ( i ) : NEW_LINE INDENT prefix_sum += arr [ j ] NEW_LINE DEDENT suffix_sum = arr [ i ] NEW_LINE j = n - 1 NEW_LINE while ( j > i ) : NEW_LINE INDENT suffix_sum += arr [ j ] NEW_LINE j -= 1 NEW_LINE DEDENT if ( prefix_sum == suffix_sum ) : NEW_LINE INDENT res = max ( res , prefix_sum ) NEW_LINE DEDENT DEDENT return res NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findMaxSum ( arr , n ) ) NEW_LINE DEDENT
def findMaxSum ( arr , n ) : NEW_LINE
preSum = [ 0 for i in range ( n ) ] NEW_LINE
suffSum = [ 0 for i in range ( n ) ] NEW_LINE
ans = - 10000000 NEW_LINE
preSum [ 0 ] = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT preSum [ i ] = preSum [ i - 1 ] + arr [ i ] NEW_LINE DEDENT
suffSum [ n - 1 ] = arr [ n - 1 ] NEW_LINE if ( preSum [ n - 1 ] == suffSum [ n - 1 ] ) : NEW_LINE INDENT ans = max ( ans , preSum [ n - 1 ] ) NEW_LINE DEDENT for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT suffSum [ i ] = suffSum [ i + 1 ] + arr [ i ] NEW_LINE if ( suffSum [ i ] == preSum [ i ] ) : NEW_LINE INDENT ans = max ( ans , preSum [ i ] ) NEW_LINE DEDENT DEDENT return ans NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findMaxSum ( arr , n ) ) NEW_LINE DEDENT
def printLeaders ( arr , size ) : NEW_LINE INDENT for i in range ( 0 , size ) : NEW_LINE INDENT for j in range ( i + 1 , size ) : NEW_LINE INDENT if arr [ i ] <= arr [ j ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT DEDENT
if j == size - 1 : NEW_LINE INDENT print arr [ i ] , NEW_LINE DEDENT
arr = [ 16 , 17 , 4 , 3 , 5 , 2 ] NEW_LINE printLeaders ( arr , len ( arr ) ) NEW_LINE
def printLeaders ( arr , size ) : NEW_LINE INDENT max_from_right = arr [ size - 1 ] NEW_LINE DEDENT
print max_from_right , NEW_LINE for i in range ( size - 2 , - 1 , - 1 ) : NEW_LINE INDENT if max_from_right < arr [ i ] : NEW_LINE INDENT print arr [ i ] , NEW_LINE max_from_right = arr [ i ] NEW_LINE DEDENT DEDENT
arr = [ 16 , 17 , 4 , 3 , 5 , 2 ] NEW_LINE printLeaders ( arr , len ( arr ) ) NEW_LINE
def findMajority ( arr , n ) : NEW_LINE INDENT maxCount = 0 NEW_LINE DEDENT
index = - 1 NEW_LINE for i in range ( n ) : NEW_LINE INDENT count = 0 NEW_LINE for j in range ( n ) : NEW_LINE INDENT if ( arr [ i ] == arr [ j ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT DEDENT
if ( count > maxCount ) : NEW_LINE INDENT maxCount = count NEW_LINE index = i NEW_LINE DEDENT
if ( maxCount > n // 2 ) : NEW_LINE INDENT print ( arr [ index ] ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ Majority ▁ Element " ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 1 , 2 , 1 , 3 , 5 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE DEDENT
findMajority ( arr , n ) NEW_LINE
def maxTripletSum ( arr , n ) : NEW_LINE
sm = - 1000000 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT for k in range ( j + 1 , n ) : NEW_LINE INDENT if ( sm < ( arr [ i ] + arr [ j ] + arr [ k ] ) ) : NEW_LINE INDENT sm = arr [ i ] + arr [ j ] + arr [ k ] NEW_LINE DEDENT DEDENT DEDENT DEDENT return sm NEW_LINE
arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxTripletSum ( arr , n ) ) NEW_LINE
def maxTripletSum ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
return ( arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ) NEW_LINE
arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxTripletSum ( arr , n ) ) NEW_LINE
def maxTripletSum ( arr , n ) : NEW_LINE
maxA = - 100000000 NEW_LINE maxB = - 100000000 NEW_LINE maxC = - 100000000 NEW_LINE for i in range ( 0 , n ) : NEW_LINE
if ( arr [ i ] > maxA ) : NEW_LINE INDENT maxC = maxB NEW_LINE maxB = maxA NEW_LINE maxA = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > maxB ) : NEW_LINE INDENT maxC = maxB NEW_LINE maxB = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > maxC ) : NEW_LINE INDENT maxC = arr [ i ] NEW_LINE DEDENT return ( maxA + maxB + maxC ) NEW_LINE
arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxTripletSum ( arr , n ) ) NEW_LINE
def maximum ( a , b , c ) : NEW_LINE INDENT return max ( max ( a , b ) , c ) NEW_LINE DEDENT
def minimum ( a , b , c ) : NEW_LINE INDENT return min ( min ( a , b ) , c ) NEW_LINE DEDENT
def smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) : NEW_LINE
arr1 . sort ( ) NEW_LINE arr2 . sort ( ) NEW_LINE arr3 . sort ( ) NEW_LINE
res_min = 0 ; res_max = 0 ; res_mid = 0 NEW_LINE
i = 0 ; j = 0 ; k = 0 NEW_LINE
diff = 2147483647 NEW_LINE while ( i < n and j < n and k < n ) : NEW_LINE INDENT sum = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] NEW_LINE DEDENT
max = maximum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) NEW_LINE
min = minimum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) NEW_LINE if ( min == arr1 [ i ] ) : NEW_LINE INDENT i += 1 NEW_LINE DEDENT elif ( min == arr2 [ j ] ) : NEW_LINE INDENT j += 1 NEW_LINE DEDENT else : NEW_LINE INDENT k += 1 NEW_LINE DEDENT
if ( diff > ( max - min ) ) : NEW_LINE INDENT diff = max - min NEW_LINE res_max = max NEW_LINE res_mid = sum - ( max + min ) NEW_LINE res_min = min NEW_LINE DEDENT
print ( res_max , " , " , res_mid , " , " , res_min ) NEW_LINE
arr1 = [ 5 , 2 , 8 ] NEW_LINE arr2 = [ 10 , 7 , 12 ] NEW_LINE arr3 = [ 9 , 14 , 6 ] NEW_LINE n = len ( arr1 ) NEW_LINE smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) NEW_LINE
def find3Numbers ( A , arr_size , sum ) : NEW_LINE
A . sort ( ) NEW_LINE
for i in range ( 0 , arr_size - 2 ) : NEW_LINE
l = i + 1 NEW_LINE
r = arr_size - 1 NEW_LINE while ( l < r ) : NEW_LINE INDENT if ( A [ i ] + A [ l ] + A [ r ] == sum ) : NEW_LINE INDENT print ( " Triplet ▁ is " , A [ i ] , ' , ▁ ' , A [ l ] , ' , ▁ ' , A [ r ] ) ; NEW_LINE return True NEW_LINE DEDENT elif ( A [ i ] + A [ l ] + A [ r ] < sum ) : NEW_LINE INDENT l += 1 NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT r -= 1 NEW_LINE DEDENT
return False NEW_LINE
A = [ 1 , 4 , 45 , 6 , 10 , 8 ] NEW_LINE sum = 22 NEW_LINE arr_size = len ( A ) NEW_LINE find3Numbers ( A , arr_size , sum ) NEW_LINE
def subArray ( arr , n ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
for j in range ( i , n ) : NEW_LINE
for k in range ( i , j + 1 ) : NEW_LINE INDENT print ( arr [ k ] , end = " ▁ " ) NEW_LINE DEDENT print ( " " , end = " " ) NEW_LINE
arr = [ 1 , 2 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " All ▁ Non - empty ▁ Subarrays " ) NEW_LINE subArray ( arr , n ) ; NEW_LINE
import math NEW_LINE def printSubsequences ( arr , n ) : NEW_LINE
opsize = math . pow ( 2 , n ) NEW_LINE
for counter in range ( 1 , ( int ) ( opsize ) ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT
if ( counter & ( 1 << j ) ) : NEW_LINE INDENT print ( arr [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE
arr = [ 1 , 2 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " All ▁ Non - empty ▁ Subsequences " ) NEW_LINE printSubsequences ( arr , n ) NEW_LINE
def productArray ( arr , n ) : NEW_LINE
if n == 1 : NEW_LINE INDENT print ( 0 ) NEW_LINE return NEW_LINE DEDENT i , temp = 1 , 1 NEW_LINE
prod = [ 1 for i in range ( n ) ] NEW_LINE
for i in range ( n ) : NEW_LINE INDENT prod [ i ] = temp NEW_LINE temp *= arr [ i ] NEW_LINE DEDENT
temp = 1 NEW_LINE
for i in range ( n - 1 , - 1 , - 1 ) : NEW_LINE INDENT prod [ i ] *= temp NEW_LINE temp *= arr [ i ] NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT print ( prod [ i ] , end = " ▁ " ) NEW_LINE DEDENT return NEW_LINE
arr = [ 10 , 3 , 5 , 6 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ product ▁ array ▁ is : ▁ n " ) NEW_LINE productArray ( arr , n ) NEW_LINE
def areConsecutive ( arr , n ) : NEW_LINE INDENT if ( n < 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
Min = min ( arr ) NEW_LINE
Max = max ( arr ) NEW_LINE
if ( Max - Min + 1 == n ) : NEW_LINE
visited = [ False for i in range ( n ) ] NEW_LINE for i in range ( n ) : NEW_LINE
if ( visited [ arr [ i ] - Min ] != False ) : NEW_LINE INDENT return False NEW_LINE DEDENT
visited [ arr [ i ] - Min ] = True NEW_LINE
return True NEW_LINE
return False NEW_LINE
arr = [ 5 , 4 , 2 , 3 , 1 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE if ( areConsecutive ( arr , n ) == True ) : NEW_LINE INDENT print ( " Array ▁ elements ▁ are ▁ consecutive ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Array ▁ elements ▁ are ▁ not ▁ consecutive ▁ " ) NEW_LINE DEDENT
def areConsecutive ( arr , n ) : NEW_LINE INDENT if ( n < 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
min = getMin ( arr , n ) NEW_LINE
max = getMax ( arr , n ) NEW_LINE
if ( max - min + 1 == n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] < 0 ) : NEW_LINE INDENT j = - arr [ i ] - min NEW_LINE DEDENT else : NEW_LINE INDENT j = arr [ i ] - min NEW_LINE DEDENT DEDENT DEDENT
if ( arr [ j ] > 0 ) : NEW_LINE INDENT arr [ j ] = - arr [ j ] NEW_LINE DEDENT else : NEW_LINE INDENT return False NEW_LINE DEDENT
return True NEW_LINE
return False NEW_LINE
def getMin ( arr , n ) : NEW_LINE INDENT min = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] < min ) : NEW_LINE INDENT min = arr [ i ] NEW_LINE DEDENT DEDENT return min NEW_LINE DEDENT def getMax ( arr , n ) : NEW_LINE INDENT max = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] > max ) : NEW_LINE INDENT max = arr [ i ] NEW_LINE DEDENT DEDENT return max NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 4 , 5 , 3 , 2 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE if ( areConsecutive ( arr , n ) == True ) : NEW_LINE INDENT print ( " ▁ Array ▁ elements ▁ are ▁ consecutive ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " ▁ Array ▁ elements ▁ are ▁ not ▁ consecutive ▁ " ) NEW_LINE DEDENT DEDENT
def relativeComplement ( arr1 , arr2 , n , m ) : NEW_LINE INDENT i = 0 NEW_LINE j = 0 NEW_LINE while ( i < n and j < m ) : NEW_LINE DEDENT
if ( arr1 [ i ] < arr2 [ j ] ) : NEW_LINE INDENT print ( arr1 [ i ] , " ▁ " , end = " " ) NEW_LINE i += 1 NEW_LINE DEDENT
elif ( arr1 [ i ] > arr2 [ j ] ) : NEW_LINE INDENT j += 1 NEW_LINE DEDENT
elif ( arr1 [ i ] == arr2 [ j ] ) : NEW_LINE INDENT i += 1 NEW_LINE j += 1 NEW_LINE DEDENT
while ( i < n ) : NEW_LINE INDENT print ( arr1 [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT
arr1 = [ 3 , 6 , 10 , 12 , 15 ] NEW_LINE arr2 = [ 1 , 3 , 5 , 10 , 16 ] NEW_LINE n = len ( arr1 ) NEW_LINE m = len ( arr2 ) NEW_LINE relativeComplement ( arr1 , arr2 , n , m ) NEW_LINE
def minOps ( arr , n , k ) : NEW_LINE
max1 = max ( arr ) NEW_LINE res = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
if ( ( max1 - arr [ i ] ) % k != 0 ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
else : NEW_LINE INDENT res += ( max1 - arr [ i ] ) / k NEW_LINE DEDENT
return int ( res ) NEW_LINE
arr = [ 21 , 33 , 9 , 45 , 63 ] NEW_LINE n = len ( arr ) NEW_LINE k = 6 NEW_LINE print ( minOps ( arr , n , k ) ) NEW_LINE
def solve ( A , B , C ) : NEW_LINE
min_diff = abs ( max ( A [ i ] , B [ j ] , C [ k ] ) - min ( A [ i ] , B [ j ] , C [ k ] ) ) NEW_LINE while i != - 1 and j != - 1 and k != - 1 : NEW_LINE INDENT current_diff = abs ( max ( A [ i ] , B [ j ] , C [ k ] ) - min ( A [ i ] , B [ j ] , C [ k ] ) ) NEW_LINE DEDENT
if current_diff < min_diff : NEW_LINE INDENT min_diff = current_diff NEW_LINE DEDENT
max_term = max ( A [ i ] , B [ j ] , C [ k ] ) NEW_LINE
if A [ i ] == max_term : NEW_LINE INDENT i -= 1 NEW_LINE DEDENT elif B [ j ] == max_term : NEW_LINE INDENT j -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT k -= 1 NEW_LINE DEDENT return min_diff NEW_LINE
A = [ 5 , 8 , 10 , 15 ] NEW_LINE B = [ 6 , 9 , 15 , 78 , 89 ] NEW_LINE C = [ 2 , 3 , 6 , 6 , 8 , 8 , 10 ] NEW_LINE print ( solve ( A , B , C ) ) NEW_LINE
def search ( arr , x ) : NEW_LINE INDENT for index , value in enumerate ( arr ) : NEW_LINE INDENT if value == x : NEW_LINE INDENT return index NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT
arr = [ 1 , 10 , 30 , 15 ] NEW_LINE x = 30 NEW_LINE print ( x , " is ▁ present ▁ at ▁ index " , search ( arr , x ) ) NEW_LINE
def binarySearch ( arr , l , r , x ) : NEW_LINE INDENT while l <= r : NEW_LINE INDENT mid = l + ( r - l ) // 2 ; NEW_LINE DEDENT DEDENT
if arr [ mid ] == x : NEW_LINE INDENT return mid NEW_LINE DEDENT
elif arr [ mid ] < x : NEW_LINE INDENT l = mid + 1 NEW_LINE DEDENT
else : NEW_LINE INDENT r = mid - 1 NEW_LINE DEDENT
return - 1 NEW_LINE
arr = [ 2 , 3 , 4 , 10 , 40 ] NEW_LINE x = 10 NEW_LINE result = binarySearch ( arr , 0 , len ( arr ) - 1 , x ) NEW_LINE if result != - 1 : NEW_LINE INDENT print ( " Element ▁ is ▁ present ▁ at ▁ index ▁ % ▁ d " % result ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) NEW_LINE DEDENT
import math NEW_LINE def jumpSearch ( arr , x , n ) : NEW_LINE
step = math . sqrt ( n ) NEW_LINE
prev = 0 NEW_LINE while arr [ int ( min ( step , n ) - 1 ) ] < x : NEW_LINE INDENT prev = step NEW_LINE step += math . sqrt ( n ) NEW_LINE if prev >= n : NEW_LINE INDENT return - 1 NEW_LINE DEDENT DEDENT
while arr [ int ( prev ) ] < x : NEW_LINE INDENT prev += 1 NEW_LINE DEDENT
if prev == min ( step , n ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
if arr [ int ( prev ) ] == x : NEW_LINE INDENT return prev NEW_LINE DEDENT return - 1 NEW_LINE
arr = [ 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 ] NEW_LINE x = 55 NEW_LINE n = len ( arr ) NEW_LINE
index = jumpSearch ( arr , x , n ) NEW_LINE
print ( " Number " , x , " is ▁ at ▁ index " , " % .0f " % index ) NEW_LINE
def exponentialSearch ( arr , n , x ) : NEW_LINE
if arr [ 0 ] == x : NEW_LINE INDENT return 0 NEW_LINE DEDENT
i = 1 NEW_LINE while i < n and arr [ i ] <= x : NEW_LINE INDENT i = i * 2 NEW_LINE DEDENT
return binarySearch ( arr , i / 2 , min ( i , n - 1 ) , x ) NEW_LINE
def binarySearch ( arr , l , r , x ) : NEW_LINE INDENT if r >= l : NEW_LINE INDENT mid = l + ( r - l ) / 2 NEW_LINE DEDENT DEDENT
if arr [ mid ] == x : NEW_LINE INDENT return mid NEW_LINE DEDENT
if arr [ mid ] > x : NEW_LINE INDENT return binarySearch ( arr , l , mid - 1 , x ) NEW_LINE DEDENT
return binarySearch ( arr , mid + 1 , r , x ) NEW_LINE
return - 1 NEW_LINE
arr = [ 2 , 3 , 4 , 10 , 40 ] NEW_LINE n = len ( arr ) NEW_LINE x = 10 NEW_LINE result = exponentialSearch ( arr , n , x ) NEW_LINE if result == - 1 : NEW_LINE INDENT print " Element ▁ not ▁ found ▁ in ▁ thye ▁ array " NEW_LINE DEDENT else : NEW_LINE INDENT print " Element ▁ is ▁ present ▁ at ▁ index ▁ % d " % ( result ) NEW_LINE DEDENT
def bubbleSort ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT swapped = False NEW_LINE for j in range ( 0 , n - i - 1 ) : NEW_LINE INDENT if arr [ j ] > arr [ j + 1 ] : NEW_LINE DEDENT DEDENT DEDENT
arr [ j ] , arr [ j + 1 ] = arr [ j + 1 ] , arr [ j ] NEW_LINE swapped = True NEW_LINE
if swapped == False : NEW_LINE INDENT break NEW_LINE DEDENT
arr = [ 64 , 34 , 25 , 12 , 22 , 11 , 90 ] NEW_LINE bubbleSort ( arr ) NEW_LINE print ( " Sorted ▁ array ▁ : " ) NEW_LINE for i in range ( len ( arr ) ) : NEW_LINE INDENT print ( " % d " % arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def countingSort ( arr , exp1 ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE DEDENT
output = [ 0 ] * ( n ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT index = ( arr [ i ] / exp1 ) NEW_LINE count [ int ( index % 10 ) ] += 1 NEW_LINE DEDENT
for i in range ( 1 , 10 ) : NEW_LINE INDENT count [ i ] += count [ i - 1 ] NEW_LINE DEDENT
i = n - 1 NEW_LINE while i >= 0 : NEW_LINE INDENT index = ( arr [ i ] / exp1 ) NEW_LINE output [ count [ int ( index % 10 ) ] - 1 ] = arr [ i ] NEW_LINE count [ int ( index % 10 ) ] -= 1 NEW_LINE i -= 1 NEW_LINE DEDENT
i = 0 NEW_LINE for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT arr [ i ] = output [ i ] NEW_LINE DEDENT
def radixSort ( arr ) : NEW_LINE
max1 = max ( arr ) NEW_LINE
exp = 1 NEW_LINE while max1 / exp > 0 : NEW_LINE INDENT countingSort ( arr , exp ) NEW_LINE exp *= 10 NEW_LINE DEDENT
arr = [ 170 , 45 , 75 , 90 , 802 , 24 , 2 , 66 ] NEW_LINE
radixSort ( arr ) NEW_LINE for i in range ( len ( arr ) ) : NEW_LINE INDENT print ( arr [ i ] ) NEW_LINE DEDENT
def partition ( arr , low , high ) : NEW_LINE INDENT i = ( low - 1 ) NEW_LINE pivot = arr [ high ] NEW_LINE for j in range ( low , high ) : NEW_LINE INDENT if arr [ j ] <= pivot : NEW_LINE INDENT i += 1 NEW_LINE arr [ i ] , arr [ j ] = arr [ j ] , arr [ i ] NEW_LINE DEDENT DEDENT arr [ i + 1 ] , arr [ high ] = arr [ high ] , arr [ i + 1 ] NEW_LINE return ( i + 1 ) NEW_LINE DEDENT
def quickSort ( arr , low , high ) : NEW_LINE INDENT if low < high : NEW_LINE DEDENT
pi = partition ( arr , low , high ) NEW_LINE quickSort ( arr , low , pi - 1 ) NEW_LINE quickSort ( arr , pi + 1 , high ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 4 , 2 , 6 , 9 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE quickSort ( arr , 0 , n - 1 ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def partition ( arr , l , h ) : NEW_LINE INDENT i = ( l - 1 ) NEW_LINE x = arr [ h ] NEW_LINE for j in range ( l , h ) : NEW_LINE INDENT if arr [ j ] <= x : NEW_LINE INDENT i = i + 1 NEW_LINE arr [ i ] , arr [ j ] = arr [ j ] , arr [ i ] NEW_LINE DEDENT DEDENT arr [ i + 1 ] , arr [ h ] = arr [ h ] , arr [ i + 1 ] NEW_LINE return ( i + 1 ) NEW_LINE DEDENT
def quickSortIterative ( arr , l , h ) : NEW_LINE
size = h - l + 1 NEW_LINE stack = [ 0 ] * ( size ) NEW_LINE
top = - 1 NEW_LINE
top = top + 1 NEW_LINE stack [ top ] = l NEW_LINE top = top + 1 NEW_LINE stack [ top ] = h NEW_LINE
while top >= 0 : NEW_LINE
h = stack [ top ] NEW_LINE top = top - 1 NEW_LINE l = stack [ top ] NEW_LINE top = top - 1 NEW_LINE
p = partition ( arr , l , h ) NEW_LINE
if p - 1 > l : NEW_LINE INDENT top = top + 1 NEW_LINE stack [ top ] = l NEW_LINE top = top + 1 NEW_LINE stack [ top ] = p - 1 NEW_LINE DEDENT
if p + 1 < h : NEW_LINE INDENT top = top + 1 NEW_LINE stack [ top ] = p + 1 NEW_LINE top = top + 1 NEW_LINE stack [ top ] = h NEW_LINE DEDENT
arr = [ 4 , 3 , 5 , 2 , 1 , 3 , 2 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE
quickSortIterative ( arr , 0 , n - 1 ) NEW_LINE print ( " Sorted ▁ array ▁ is : " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT print ( " % ▁ d " % arr [ i ] ) , NEW_LINE DEDENT
def findCrossOver ( arr , low , high , x ) : NEW_LINE
if ( arr [ high ] <= x ) : NEW_LINE INDENT return high NEW_LINE DEDENT
if ( arr [ low ] > x ) : NEW_LINE INDENT return low NEW_LINE DEDENT
mid = ( low + high ) // 2 NEW_LINE
if ( arr [ mid ] <= x and arr [ mid + 1 ] > x ) : NEW_LINE INDENT return mid NEW_LINE DEDENT
if ( arr [ mid ] < x ) : NEW_LINE INDENT return findCrossOver ( arr , mid + 1 , high , x ) NEW_LINE DEDENT return findCrossOver ( arr , low , mid - 1 , x ) NEW_LINE
def printKclosest ( arr , x , k , n ) : NEW_LINE
l = findCrossOver ( arr , 0 , n - 1 , x ) NEW_LINE
r = l + 1 NEW_LINE
count = 0 NEW_LINE
if ( arr [ l ] == x ) : NEW_LINE INDENT l -= 1 NEW_LINE DEDENT
while ( l >= 0 and r < n and count < k ) : NEW_LINE INDENT if ( x - arr [ l ] < arr [ r ] - x ) : NEW_LINE INDENT print ( arr [ l ] , end = " ▁ " ) NEW_LINE l -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT print ( arr [ r ] , end = " ▁ " ) NEW_LINE r += 1 NEW_LINE DEDENT count += 1 NEW_LINE DEDENT
while ( count < k and l >= 0 ) : NEW_LINE INDENT print ( arr [ l ] , end = " ▁ " ) NEW_LINE l -= 1 NEW_LINE count += 1 NEW_LINE DEDENT
while ( count < k and r < n ) : NEW_LINE INDENT print ( arr [ r ] , end = " ▁ " ) NEW_LINE r += 1 NEW_LINE count += 1 NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 ] NEW_LINE n = len ( arr ) NEW_LINE x = 35 NEW_LINE k = 4 NEW_LINE printKclosest ( arr , x , 4 , n ) NEW_LINE DEDENT
def binarySearch ( arr , l , r , x ) : NEW_LINE INDENT if ( r >= l ) : NEW_LINE INDENT mid = int ( l + ( r - l ) / 2 ) NEW_LINE DEDENT DEDENT
if ( arr [ mid ] == x ) : return mid NEW_LINE if ( mid > l and arr [ mid - 1 ] == x ) : NEW_LINE INDENT return ( mid - 1 ) NEW_LINE DEDENT if ( mid < r and arr [ mid + 1 ] == x ) : NEW_LINE INDENT return ( mid + 1 ) NEW_LINE DEDENT
if ( arr [ mid ] > x ) : NEW_LINE INDENT return binarySearch ( arr , l , mid - 2 , x ) NEW_LINE DEDENT
return binarySearch ( arr , mid + 2 , r , x ) NEW_LINE
return - 1 NEW_LINE
arr = [ 3 , 2 , 10 , 4 , 40 ] NEW_LINE n = len ( arr ) NEW_LINE x = 4 NEW_LINE result = binarySearch ( arr , 0 , n - 1 , x ) NEW_LINE if ( result == - 1 ) : NEW_LINE INDENT print ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Element ▁ is ▁ present ▁ at ▁ index " , result ) NEW_LINE DEDENT
def printClosest ( ar1 , ar2 , m , n , x ) : NEW_LINE
diff = sys . maxsize NEW_LINE
l = 0 NEW_LINE r = n - 1 NEW_LINE while ( l < m and r >= 0 ) : NEW_LINE
if abs ( ar1 [ l ] + ar2 [ r ] - x ) < diff : NEW_LINE INDENT res_l = l NEW_LINE res_r = r NEW_LINE diff = abs ( ar1 [ l ] + ar2 [ r ] - x ) NEW_LINE DEDENT
if ar1 [ l ] + ar2 [ r ] > x : NEW_LINE INDENT r = r - 1 NEW_LINE DEDENT
else : NEW_LINE INDENT l = l + 1 NEW_LINE DEDENT
print ( " The ▁ closest ▁ pair ▁ is ▁ [ " , ar1 [ res_l ] , " , " , ar2 [ res_r ] , " ] " ) NEW_LINE
ar1 = [ 1 , 4 , 5 , 7 ] NEW_LINE ar2 = [ 10 , 20 , 30 , 40 ] NEW_LINE m = len ( ar1 ) NEW_LINE n = len ( ar2 ) NEW_LINE x = 38 NEW_LINE printClosest ( ar1 , ar2 , m , n , x ) NEW_LINE
def printClosest ( arr , n , x ) : NEW_LINE
res_l , res_r = 0 , 0 NEW_LINE
l , r , diff = 0 , n - 1 , MAX_VAL NEW_LINE
while r > l : NEW_LINE
if abs ( arr [ l ] + arr [ r ] - x ) < diff : NEW_LINE INDENT res_l = l NEW_LINE res_r = r NEW_LINE diff = abs ( arr [ l ] + arr [ r ] - x ) NEW_LINE DEDENT if arr [ l ] + arr [ r ] > x : NEW_LINE
r -= 1 NEW_LINE else : NEW_LINE
l += 1 NEW_LINE print ( ' The ▁ closest ▁ pair ▁ is ▁ { } ▁ and ▁ { } ' . format ( arr [ res_l ] , arr [ res_r ] ) ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 10 , 22 , 28 , 29 , 30 , 40 ] NEW_LINE n = len ( arr ) NEW_LINE x = 54 NEW_LINE printClosest ( arr , n , x ) NEW_LINE DEDENT
def countOnes ( arr , low , high ) : NEW_LINE INDENT if high >= low : NEW_LINE DEDENT
mid = low + ( high - low ) // 2 NEW_LINE
if ( ( mid == high or arr [ mid + 1 ] == 0 ) and ( arr [ mid ] == 1 ) ) : NEW_LINE INDENT return mid + 1 NEW_LINE DEDENT
if arr [ mid ] == 1 : NEW_LINE INDENT return countOnes ( arr , ( mid + 1 ) , high ) NEW_LINE DEDENT
return countOnes ( arr , low , mid - 1 ) NEW_LINE return 0 NEW_LINE
arr = [ 1 , 1 , 1 , 1 , 0 , 0 , 0 ] NEW_LINE print ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is " , countOnes ( arr , 0 , len ( arr ) - 1 ) ) NEW_LINE
def minSwaps ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE maxx , minn , l , r = - 1 , arr [ 0 ] , 0 , 0 NEW_LINE for i in range ( n ) : NEW_LINE DEDENT
if arr [ i ] > maxx : NEW_LINE INDENT maxx = arr [ i ] NEW_LINE l = i NEW_LINE DEDENT
if arr [ i ] <= minn : NEW_LINE INDENT minn = arr [ i ] NEW_LINE r = i NEW_LINE DEDENT if r < l : NEW_LINE print ( l + ( n - r - 2 ) ) NEW_LINE else : NEW_LINE print ( l + ( n - r - 1 ) ) NEW_LINE
arr = [ 5 , 6 , 1 , 3 ] NEW_LINE minSwaps ( arr ) NEW_LINE
def lcs ( X , Y , m , n ) : NEW_LINE INDENT if m == 0 or n == 0 : NEW_LINE return 0 ; NEW_LINE elif X [ m - 1 ] == Y [ n - 1 ] : NEW_LINE return 1 + lcs ( X , Y , m - 1 , n - 1 ) ; NEW_LINE else : NEW_LINE return max ( lcs ( X , Y , m , n - 1 ) , lcs ( X , Y , m - 1 , n ) ) ; NEW_LINE DEDENT
X = " AGGTAB " NEW_LINE Y = " GXTXAYB " NEW_LINE print " Length ▁ of ▁ LCS ▁ is ▁ " , lcs ( X , Y , len ( X ) , len ( Y ) ) NEW_LINE
def lcs ( X , Y ) : NEW_LINE
m = len ( X ) NEW_LINE n = len ( Y ) NEW_LINE L = [ [ None ] * ( n + 1 ) for i in xrange ( m + 1 ) ] NEW_LINE
for i in range ( m + 1 ) : NEW_LINE INDENT for j in range ( n + 1 ) : NEW_LINE INDENT if i == 0 or j == 0 : NEW_LINE INDENT L [ i ] [ j ] = 0 NEW_LINE DEDENT elif X [ i - 1 ] == Y [ j - 1 ] : NEW_LINE INDENT L [ i ] [ j ] = L [ i - 1 ] [ j - 1 ] + 1 NEW_LINE DEDENT else : NEW_LINE INDENT L [ i ] [ j ] = max ( L [ i - 1 ] [ j ] , L [ i ] [ j - 1 ] ) NEW_LINE DEDENT DEDENT DEDENT
return L [ m ] [ n ] NEW_LINE
X = " AGGTAB " NEW_LINE Y = " GXTXAYB " NEW_LINE print " Length ▁ of ▁ LCS ▁ is ▁ " , lcs ( X , Y ) NEW_LINE
def count ( S , m , n ) : NEW_LINE
if ( n == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
if ( n < 0 ) : NEW_LINE INDENT return 0 ; NEW_LINE DEDENT
if ( m <= 0 and n >= 1 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
return count ( S , m - 1 , n ) + count ( S , m , n - S [ m - 1 ] ) ; NEW_LINE
arr = [ 1 , 2 , 3 ] NEW_LINE m = len ( arr ) NEW_LINE print ( count ( arr , m , 4 ) ) NEW_LINE
def count ( S , m , n ) : NEW_LINE
table = [ 0 for k in range ( n + 1 ) ] NEW_LINE
table [ 0 ] = 1 NEW_LINE
for i in range ( 0 , m ) : NEW_LINE INDENT for j in range ( S [ i ] , n + 1 ) : NEW_LINE INDENT table [ j ] += table [ j - S [ i ] ] NEW_LINE DEDENT DEDENT return table [ n ] NEW_LINE
arr = [ 1 , 2 , 3 ] NEW_LINE m = len ( arr ) NEW_LINE n = 4 NEW_LINE x = count ( arr , m , n ) NEW_LINE print ( x ) NEW_LINE
def binomialCoeff ( n , k ) : NEW_LINE INDENT C = [ 0 for i in xrange ( k + 1 ) ] NEW_LINE DEDENT
C [ 0 ] = 1 NEW_LINE for i in range ( 1 , n + 1 ) : NEW_LINE
j = min ( i , k ) NEW_LINE while ( j > 0 ) : NEW_LINE INDENT C [ j ] = C [ j ] + C [ j - 1 ] NEW_LINE j -= 1 NEW_LINE DEDENT return C [ k ] NEW_LINE
n = 5 NEW_LINE k = 2 NEW_LINE print " Value ▁ of ▁ C ( % d , % d ) ▁ is ▁ % d " % ( n , k , binomialCoeff ( n , k ) ) NEW_LINE
def eggDrop ( n , k ) : NEW_LINE
eggFloor = [ [ 0 for x in range ( k + 1 ) ] for x in range ( n + 1 ) ] NEW_LINE
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT eggFloor [ i ] [ 1 ] = 1 NEW_LINE eggFloor [ i ] [ 0 ] = 0 NEW_LINE DEDENT
for j in range ( 1 , k + 1 ) : NEW_LINE INDENT eggFloor [ 1 ] [ j ] = j NEW_LINE DEDENT
for i in range ( 2 , n + 1 ) : NEW_LINE INDENT for j in range ( 2 , k + 1 ) : NEW_LINE INDENT eggFloor [ i ] [ j ] = INT_MAX NEW_LINE for x in range ( 1 , j + 1 ) : NEW_LINE INDENT res = 1 + max ( eggFloor [ i - 1 ] [ x - 1 ] , eggFloor [ i ] [ j - x ] ) NEW_LINE if res < eggFloor [ i ] [ j ] : NEW_LINE INDENT eggFloor [ i ] [ j ] = res NEW_LINE DEDENT DEDENT DEDENT DEDENT
return eggFloor [ n ] [ k ] NEW_LINE
n = 2 NEW_LINE k = 36 NEW_LINE print ( " Minimum ▁ number ▁ of ▁ trials ▁ in ▁ worst ▁ case ▁ with " + str ( n ) + " eggs ▁ and ▁ " + str ( k ) + " ▁ floors ▁ is ▁ " + str ( eggDrop ( n , k ) ) ) NEW_LINE
def lps ( str ) : NEW_LINE INDENT n = len ( str ) NEW_LINE DEDENT
L = [ [ 0 for x in range ( n ) ] for x in range ( n ) ] NEW_LINE
for i in range ( n ) : NEW_LINE INDENT L [ i ] [ i ] = 1 NEW_LINE DEDENT
for cl in range ( 2 , n + 1 ) : NEW_LINE INDENT for i in range ( n - cl + 1 ) : NEW_LINE INDENT j = i + cl - 1 NEW_LINE if str [ i ] == str [ j ] and cl == 2 : NEW_LINE INDENT L [ i ] [ j ] = 2 NEW_LINE DEDENT elif str [ i ] == str [ j ] : NEW_LINE INDENT L [ i ] [ j ] = L [ i + 1 ] [ j - 1 ] + 2 NEW_LINE DEDENT else : NEW_LINE INDENT L [ i ] [ j ] = max ( L [ i ] [ j - 1 ] , L [ i + 1 ] [ j ] ) ; NEW_LINE DEDENT DEDENT DEDENT return L [ 0 ] [ n - 1 ] NEW_LINE
seq = " GEEKS ▁ FOR ▁ GEEKS " NEW_LINE n = len ( seq ) NEW_LINE print ( " The ▁ length ▁ of ▁ the ▁ LPS ▁ is ▁ " + str ( lps ( seq ) ) ) NEW_LINE
def cutRod ( price , n ) : NEW_LINE INDENT if ( n <= 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT max_val = - sys . maxsize - 1 NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT max_val = max ( max_val , price [ i ] + cutRod ( price , n - i - 1 ) ) NEW_LINE DEDENT return max_val NEW_LINE
arr = [ 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ] NEW_LINE size = len ( arr ) NEW_LINE print ( " Maximum ▁ Obtainable ▁ Value ▁ is " , cutRod ( arr , size ) ) NEW_LINE
def cutRod ( price , n ) : NEW_LINE INDENT val = [ 0 for x in range ( n + 1 ) ] NEW_LINE val [ 0 ] = 0 NEW_LINE DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT max_val = INT_MIN NEW_LINE for j in range ( i ) : NEW_LINE INDENT max_val = max ( max_val , price [ j ] + val [ i - j - 1 ] ) NEW_LINE DEDENT val [ i ] = max_val NEW_LINE DEDENT return val [ n ] NEW_LINE
arr = [ 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ] NEW_LINE size = len ( arr ) NEW_LINE print ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " + str ( cutRod ( arr , size ) ) ) NEW_LINE
def lbs ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE DEDENT
lis = [ 1 for i in range ( n + 1 ) ] NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT for j in range ( 0 , i ) : NEW_LINE INDENT if ( ( arr [ i ] > arr [ j ] ) and ( lis [ i ] < lis [ j ] + 1 ) ) : NEW_LINE INDENT lis [ i ] = lis [ j ] + 1 NEW_LINE DEDENT DEDENT DEDENT
lds = [ 1 for i in range ( n + 1 ) ] NEW_LINE
for i in reversed ( range ( n - 1 ) ) : NEW_LINE INDENT for j in reversed ( range ( i - 1 , n ) ) : NEW_LINE INDENT if ( arr [ i ] > arr [ j ] and lds [ i ] < lds [ j ] + 1 ) : NEW_LINE INDENT lds [ i ] = lds [ j ] + 1 NEW_LINE DEDENT DEDENT DEDENT
maximum = lis [ 0 ] + lds [ 0 ] - 1 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT maximum = max ( ( lis [ i ] + lds [ i ] - 1 ) , maximum ) NEW_LINE DEDENT return maximum NEW_LINE
arr = [ 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 ] NEW_LINE print " Length ▁ of ▁ LBS ▁ is " , lbs ( arr ) NEW_LINE
def maxDivide ( a , b ) : NEW_LINE INDENT while a % b == 0 : NEW_LINE INDENT a = a / b NEW_LINE DEDENT return a NEW_LINE DEDENT
def isUgly ( no ) : NEW_LINE INDENT no = maxDivide ( no , 2 ) NEW_LINE no = maxDivide ( no , 3 ) NEW_LINE no = maxDivide ( no , 5 ) NEW_LINE return 1 if no == 1 else 0 NEW_LINE DEDENT
def getNthUglyNo ( n ) : NEW_LINE INDENT i = 1 NEW_LINE DEDENT
count = 1 NEW_LINE
while n > count : NEW_LINE INDENT i += 1 NEW_LINE if isUgly ( i ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT return i NEW_LINE
no = getNthUglyNo ( 150 ) NEW_LINE print ( "150th ▁ ugly ▁ no . ▁ is ▁ " , no ) NEW_LINE
def isSubsetSum ( set , n , sum ) : NEW_LINE
if ( sum == 0 ) : NEW_LINE INDENT return True NEW_LINE DEDENT if ( n == 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT
if ( set [ n - 1 ] > sum ) : NEW_LINE INDENT return isSubsetSum ( set , n - 1 , sum ) NEW_LINE DEDENT
return isSubsetSum ( set , n - 1 , sum ) or isSubsetSum ( set , n - 1 , sum - set [ n - 1 ] ) NEW_LINE
set = [ 3 , 34 , 4 , 12 , 5 , 2 ] NEW_LINE sum = 9 NEW_LINE n = len ( set ) NEW_LINE if ( isSubsetSum ( set , n , sum ) == True ) : NEW_LINE INDENT print ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ subset ▁ with ▁ given ▁ sum " ) NEW_LINE DEDENT
def isSubsetSum ( set , n , sum ) : NEW_LINE
subset = ( [ [ False for i in range ( sum + 1 ) ] for i in range ( n + 1 ) ] ) NEW_LINE
for i in range ( n + 1 ) : NEW_LINE INDENT subset [ i ] [ 0 ] = True NEW_LINE DEDENT
for i in range ( 1 , sum + 1 ) : NEW_LINE INDENT subset [ 0 ] [ i ] = False NEW_LINE DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT for j in range ( 1 , sum + 1 ) : NEW_LINE INDENT if j < set [ i - 1 ] : NEW_LINE INDENT subset [ i ] [ j ] = subset [ i - 1 ] [ j ] NEW_LINE DEDENT if j >= set [ i - 1 ] : NEW_LINE INDENT subset [ i ] [ j ] = ( subset [ i - 1 ] [ j ] or subset [ i - 1 ] [ j - set [ i - 1 ] ] ) NEW_LINE DEDENT DEDENT DEDENT
for i in range ( n + 1 ) : NEW_LINE INDENT for j in range ( sum + 1 ) : NEW_LINE INDENT print ( subset [ i ] [ j ] , end = " ▁ " ) NEW_LINE print ( ) NEW_LINE DEDENT DEDENT return subset [ n ] [ sum ] NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT set = [ 3 , 34 , 4 , 12 , 5 , 2 ] NEW_LINE sum = 9 NEW_LINE n = len ( set ) NEW_LINE if ( isSubsetSum ( set , n , sum ) == True ) : NEW_LINE INDENT print ( " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ subset ▁ with ▁ given ▁ sum " ) NEW_LINE DEDENT DEDENT
def countRec ( n , sum ) : NEW_LINE
if ( n == 0 ) : NEW_LINE INDENT return ( sum == 0 ) NEW_LINE DEDENT if ( sum == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT
ans = 0 NEW_LINE
for i in range ( 0 , 10 ) : NEW_LINE INDENT if ( sum - i >= 0 ) : NEW_LINE INDENT ans = ans + countRec ( n - 1 , sum - i ) NEW_LINE DEDENT DEDENT return ans NEW_LINE
def finalCount ( n , sum ) : NEW_LINE
ans = 0 NEW_LINE
for i in range ( 1 , 10 ) : NEW_LINE INDENT if ( sum - i >= 0 ) : NEW_LINE INDENT ans = ans + countRec ( n - 1 , sum - i ) NEW_LINE DEDENT DEDENT return ans NEW_LINE
n = 2 NEW_LINE sum = 5 NEW_LINE print ( finalCount ( n , sum ) ) NEW_LINE
lookup = [ [ - 1 for i in range ( 501 ) ] for i in range ( 101 ) ] NEW_LINE
def countRec ( n , Sum ) : NEW_LINE
if ( n == 0 ) : NEW_LINE INDENT return Sum == 0 NEW_LINE DEDENT
if ( lookup [ n ] [ Sum ] != - 1 ) : NEW_LINE INDENT return lookup [ n ] [ Sum ] NEW_LINE DEDENT
ans = 0 NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT if ( Sum - i >= 0 ) : NEW_LINE INDENT ans += countRec ( n - 1 , Sum - i ) NEW_LINE DEDENT DEDENT lookup [ n ] [ Sum ] = ans NEW_LINE return lookup [ n ] [ Sum ] NEW_LINE
def finalCount ( n , Sum ) : NEW_LINE
ans = 0 NEW_LINE
for i in range ( 1 , 10 ) : NEW_LINE INDENT if ( Sum - i >= 0 ) : NEW_LINE INDENT ans += countRec ( n - 1 , Sum - i ) NEW_LINE DEDENT DEDENT return ans NEW_LINE
n , Sum = 3 , 5 NEW_LINE print ( finalCount ( n , Sum ) ) NEW_LINE
import math NEW_LINE def findCount ( n , sum ) : NEW_LINE
start = math . pow ( 10 , n - 1 ) ; NEW_LINE end = math . pow ( 10 , n ) - 1 ; NEW_LINE count = 0 ; NEW_LINE i = start ; NEW_LINE while ( i <= end ) : NEW_LINE INDENT cur = 0 ; NEW_LINE temp = i ; NEW_LINE while ( temp != 0 ) : NEW_LINE INDENT cur += temp % 10 ; NEW_LINE temp = temp // 10 ; NEW_LINE DEDENT if ( cur == sum ) : NEW_LINE INDENT count = count + 1 ; NEW_LINE i += 9 ; NEW_LINE DEDENT else : NEW_LINE INDENT i = i + 1 ; NEW_LINE DEDENT DEDENT print ( count ) ; NEW_LINE
n = 3 ; NEW_LINE sum = 5 ; NEW_LINE findCount ( n , sum ) ; NEW_LINE
def countNonDecreasing ( n ) : NEW_LINE
dp = [ [ 0 for i in range ( n + 1 ) ] for i in range ( 10 ) ] NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT dp [ i ] [ 1 ] = 1 NEW_LINE DEDENT
for digit in range ( 10 ) : NEW_LINE
for len in range ( 2 , n + 1 ) : NEW_LINE
for x in range ( digit + 1 ) : NEW_LINE INDENT dp [ digit ] [ len ] += dp [ x ] [ len - 1 ] NEW_LINE DEDENT count = 0 NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT count += dp [ i ] [ n ] NEW_LINE DEDENT return count NEW_LINE
n = 3 NEW_LINE print ( countNonDecreasing ( n ) ) NEW_LINE
def countNonDecreasing ( n ) : NEW_LINE INDENT N = 10 NEW_LINE DEDENT
count = 1 NEW_LINE for i in range ( 1 , n + 1 ) : NEW_LINE INDENT count = int ( count * ( N + i - 1 ) ) NEW_LINE count = int ( count / i ) NEW_LINE DEDENT return count NEW_LINE
n = 3 ; NEW_LINE print ( countNonDecreasing ( n ) ) NEW_LINE
def getMinSquares ( n ) : NEW_LINE
if n <= 3 : NEW_LINE INDENT return n ; NEW_LINE DEDENT
res = n NEW_LINE
for x in range ( 1 , n + 1 ) : NEW_LINE INDENT temp = x * x ; NEW_LINE if temp > n : NEW_LINE INDENT break NEW_LINE DEDENT else : NEW_LINE INDENT res = min ( res , 1 + getMinSquares ( n - temp ) ) NEW_LINE DEDENT DEDENT return res ; NEW_LINE
print ( getMinSquares ( 6 ) ) NEW_LINE
def getMinSquares ( n ) : NEW_LINE
dp = [ 0 , 1 , 2 , 3 ] NEW_LINE
for i in range ( 4 , n + 1 ) : NEW_LINE
dp . append ( i ) NEW_LINE
for x in range ( 1 , int ( ceil ( sqrt ( i ) ) ) + 1 ) : NEW_LINE INDENT temp = x * x ; NEW_LINE if temp > i : NEW_LINE INDENT break NEW_LINE DEDENT else : NEW_LINE INDENT dp [ i ] = min ( dp [ i ] , 1 + dp [ i - temp ] ) NEW_LINE DEDENT DEDENT
return dp [ n ] NEW_LINE
print ( getMinSquares ( 6 ) ) NEW_LINE
def minCoins ( coins , m , V ) : NEW_LINE
if ( V == 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
res = sys . maxsize NEW_LINE
for i in range ( 0 , m ) : NEW_LINE INDENT if ( coins [ i ] <= V ) : NEW_LINE INDENT sub_res = minCoins ( coins , m , V - coins [ i ] ) NEW_LINE DEDENT DEDENT
if ( sub_res != sys . maxsize and sub_res + 1 < res ) : NEW_LINE INDENT res = sub_res + 1 NEW_LINE DEDENT return res NEW_LINE
coins = [ 9 , 6 , 5 , 1 ] NEW_LINE m = len ( coins ) NEW_LINE V = 11 NEW_LINE print ( " Minimum ▁ coins ▁ required ▁ is " , minCoins ( coins , m , V ) ) NEW_LINE
def minCoins ( coins , m , V ) : NEW_LINE
table = [ 0 for i in range ( V + 1 ) ] NEW_LINE
table [ 0 ] = 0 NEW_LINE
for i in range ( 1 , V + 1 ) : NEW_LINE INDENT table [ i ] = sys . maxsize NEW_LINE DEDENT
for i in range ( 1 , V + 1 ) : NEW_LINE
for j in range ( m ) : NEW_LINE INDENT if ( coins [ j ] <= i ) : NEW_LINE INDENT sub_res = table [ i - coins [ j ] ] NEW_LINE if ( sub_res != sys . maxsize and sub_res + 1 < table [ i ] ) : NEW_LINE INDENT table [ i ] = sub_res + 1 NEW_LINE DEDENT DEDENT DEDENT if table [ V ] == sys . maxsize : NEW_LINE return - 1 NEW_LINE return table [ V ] NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT coins = [ 9 , 6 , 5 , 1 ] NEW_LINE m = len ( coins ) NEW_LINE V = 11 NEW_LINE print ( " Minimum ▁ coins ▁ required ▁ is ▁ " , minCoins ( coins , m , V ) ) NEW_LINE DEDENT
def superSeq ( X , Y , m , n ) : NEW_LINE INDENT if ( not m ) : NEW_LINE INDENT return n NEW_LINE DEDENT if ( not n ) : NEW_LINE INDENT return m NEW_LINE DEDENT if ( X [ m - 1 ] == Y [ n - 1 ] ) : NEW_LINE INDENT return 1 + superSeq ( X , Y , m - 1 , n - 1 ) NEW_LINE DEDENT return 1 + min ( superSeq ( X , Y , m - 1 , n ) , superSeq ( X , Y , m , n - 1 ) ) NEW_LINE DEDENT
X = " AGGTAB " NEW_LINE Y = " GXTXAYB " NEW_LINE print ( " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ % d " % superSeq ( X , Y , len ( X ) , len ( Y ) ) ) NEW_LINE
def superSeq ( X , Y , m , n ) : NEW_LINE INDENT dp = [ [ 0 ] * ( n + 2 ) for i in range ( m + 2 ) ] NEW_LINE DEDENT
for i in range ( m + 1 ) : NEW_LINE INDENT for j in range ( n + 1 ) : NEW_LINE DEDENT
if ( not i ) : NEW_LINE INDENT dp [ i ] [ j ] = j NEW_LINE DEDENT elif ( not j ) : NEW_LINE INDENT dp [ i ] [ j ] = i NEW_LINE DEDENT elif ( X [ i - 1 ] == Y [ j - 1 ] ) : NEW_LINE INDENT dp [ i ] [ j ] = 1 + dp [ i - 1 ] [ j - 1 ] NEW_LINE DEDENT else : NEW_LINE INDENT dp [ i ] [ j ] = 1 + min ( dp [ i - 1 ] [ j ] , dp [ i ] [ j - 1 ] ) NEW_LINE DEDENT return dp [ m ] [ n ] NEW_LINE
X = " AGGTAB " NEW_LINE Y = " GXTXAYB " NEW_LINE print ( " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ % d " % superSeq ( X , Y , len ( X ) , len ( Y ) ) ) NEW_LINE
def sumOfDigitsFrom1ToN ( n ) : NEW_LINE
result = 0 NEW_LINE
for x in range ( 1 , n + 1 ) : NEW_LINE INDENT result = result + sumOfDigits ( x ) NEW_LINE DEDENT return result NEW_LINE
def sumOfDigits ( x ) : NEW_LINE INDENT sum = 0 NEW_LINE while ( x != 0 ) : NEW_LINE INDENT sum = sum + x % 10 NEW_LINE x = x // 10 NEW_LINE DEDENT return sum NEW_LINE DEDENT
n = 328 NEW_LINE print ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from ▁ 1 ▁ to " , n , " is " , sumOfDigitsFrom1ToN ( n ) ) NEW_LINE
def sumOfDigitsFrom1ToN ( n ) : NEW_LINE
if ( n < 10 ) : NEW_LINE INDENT return ( n * ( n + 1 ) / 2 ) NEW_LINE DEDENT
d = ( int ) ( math . log10 ( n ) ) NEW_LINE
a = [ 0 ] * ( d + 1 ) NEW_LINE a [ 0 ] = 0 NEW_LINE a [ 1 ] = 45 NEW_LINE for i in range ( 2 , d + 1 ) : NEW_LINE INDENT a [ i ] = a [ i - 1 ] * 10 + 45 * ( int ) ( math . ceil ( math . pow ( 10 , i - 1 ) ) ) NEW_LINE DEDENT
p = ( int ) ( math . ceil ( math . pow ( 10 , d ) ) ) NEW_LINE
msd = n // p NEW_LINE
return ( int ) ( msd * a [ d ] + ( msd * ( msd - 1 ) // 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToN ( n % p ) ) NEW_LINE
n = 328 NEW_LINE print ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from ▁ 1 ▁ to " , n , " is " , sumOfDigitsFrom1ToN ( n ) ) NEW_LINE
def countWays ( N ) : NEW_LINE
if ( N == 1 ) : NEW_LINE
return 4 NEW_LINE
countB = 1 NEW_LINE countS = 1 NEW_LINE
for i in range ( 2 , N + 1 ) : NEW_LINE INDENT prev_countB = countB NEW_LINE prev_countS = countS NEW_LINE countS = prev_countB + prev_countS NEW_LINE countB = prev_countS NEW_LINE DEDENT
result = countS + countB NEW_LINE
return ( result * result ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT N = 3 NEW_LINE print ( " Count ▁ of ▁ ways ▁ for ▁ " , N , " ▁ sections ▁ is ▁ " , countWays ( N ) ) NEW_LINE DEDENT
def area ( x1 , y1 , x2 , y2 , x3 , y3 ) : NEW_LINE INDENT return abs ( ( x1 * ( y2 - y3 ) + x2 * ( y3 - y1 ) + x3 * ( y1 - y2 ) ) / 2.0 ) NEW_LINE DEDENT
def isInside ( x1 , y1 , x2 , y2 , x3 , y3 , x , y ) : NEW_LINE
A = area ( x1 , y1 , x2 , y2 , x3 , y3 ) NEW_LINE
A1 = area ( x , y , x2 , y2 , x3 , y3 ) NEW_LINE
A2 = area ( x1 , y1 , x , y , x3 , y3 ) NEW_LINE
A3 = area ( x1 , y1 , x2 , y2 , x , y ) NEW_LINE
if ( A == A1 + A2 + A3 ) : NEW_LINE INDENT return True NEW_LINE DEDENT else : NEW_LINE INDENT return False NEW_LINE DEDENT
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) : NEW_LINE INDENT print ( ' Inside ' ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( ' Not ▁ Inside ' ) NEW_LINE DEDENT
def getAvg ( prev_avg , x , n ) : NEW_LINE INDENT return ( ( prev_avg * n + x ) / ( n + 1 ) ) ; NEW_LINE DEDENT
def streamAvg ( arr , n ) : NEW_LINE INDENT avg = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT avg = getAvg ( avg , arr [ i ] , i ) ; NEW_LINE print ( " Average ▁ of ▁ " , i + 1 , " ▁ numbers ▁ is ▁ " , avg ) ; NEW_LINE DEDENT DEDENT
arr = [ 10 , 20 , 30 , 40 , 50 , 60 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE streamAvg ( arr , n ) ; NEW_LINE
def SieveOfEratosthenes ( n ) : NEW_LINE
prime = [ True for i in range ( n + 1 ) ] NEW_LINE p = 2 NEW_LINE while ( p * p <= n ) : NEW_LINE
if ( prime [ p ] == True ) : NEW_LINE
for i in range ( p * p , n + 1 , p ) : NEW_LINE INDENT prime [ i ] = False NEW_LINE DEDENT p += 1 NEW_LINE
for p in range ( 2 , n + 1 ) : NEW_LINE INDENT if prime [ p ] : NEW_LINE INDENT print p , NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = 30 NEW_LINE print " Following ▁ are ▁ the ▁ prime ▁ numbers ▁ smaller " , NEW_LINE print " than ▁ or ▁ equal ▁ to " , n NEW_LINE SieveOfEratosthenes ( n ) NEW_LINE DEDENT
def maximumNumberDistinctPrimeRange ( m , n ) : NEW_LINE
factorCount = [ 0 ] * ( n + 1 ) NEW_LINE
prime = [ False ] * ( n + 1 ) NEW_LINE
for i in range ( n + 1 ) : NEW_LINE INDENT factorCount [ i ] = 0 NEW_LINE DEDENT
prime [ i ] = True NEW_LINE for i in range ( 2 , n + 1 ) : NEW_LINE
if ( prime [ i ] == True ) : NEW_LINE
factorCount [ i ] = 1 NEW_LINE
for j in range ( i * 2 , n + 1 , i ) : NEW_LINE
factorCount [ j ] += 1 NEW_LINE
prime [ j ] = False NEW_LINE
max = factorCount [ m ] NEW_LINE num = m NEW_LINE
for i in range ( m , n + 1 ) : NEW_LINE
if ( factorCount [ i ] > max ) : NEW_LINE INDENT max = factorCount [ i ] NEW_LINE num = i NEW_LINE DEDENT return num NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT m = 4 NEW_LINE n = 6 NEW_LINE DEDENT
print ( maximumNumberDistinctPrimeRange ( m , n ) ) NEW_LINE
MAX_CHAR = 256 ; NEW_LINE
count = [ 0 ] * ( MAX_CHAR + 1 ) ; NEW_LINE
def fact ( n ) : NEW_LINE INDENT return 1 if ( n <= 1 ) else ( n * fact ( n - 1 ) ) ; NEW_LINE DEDENT
def populateAndIncreaseCount ( str ) : NEW_LINE INDENT for i in range ( len ( str ) ) : NEW_LINE INDENT count [ ord ( str [ i ] ) ] += 1 ; NEW_LINE DEDENT for i in range ( 1 , MAX_CHAR ) : NEW_LINE INDENT count [ i ] += count [ i - 1 ] ; NEW_LINE DEDENT DEDENT
def updatecount ( ch ) : NEW_LINE INDENT for i in range ( ord ( ch ) , MAX_CHAR ) : NEW_LINE INDENT count [ i ] -= 1 ; NEW_LINE DEDENT DEDENT
def findRank ( str ) : NEW_LINE INDENT len1 = len ( str ) ; NEW_LINE mul = fact ( len1 ) ; NEW_LINE rank = 1 ; NEW_LINE DEDENT
populateAndIncreaseCount ( str ) ; NEW_LINE for i in range ( len1 ) : NEW_LINE INDENT mul = mul // ( len1 - i ) ; NEW_LINE DEDENT
rank += count [ ord ( str [ i ] ) - 1 ] * mul ; NEW_LINE
updatecount ( str [ i ] ) ; NEW_LINE return rank ; NEW_LINE
str = " string " ; NEW_LINE print ( findRank ( str ) ) ; NEW_LINE
def binomialCoeff ( n , k ) : NEW_LINE INDENT res = 1 NEW_LINE if ( k > n - k ) : NEW_LINE INDENT k = n - k NEW_LINE DEDENT for i in range ( 0 , k ) : NEW_LINE INDENT res = res * ( n - i ) NEW_LINE res = res // ( i + 1 ) NEW_LINE DEDENT return res NEW_LINE DEDENT
def printPascal ( n ) : NEW_LINE
for line in range ( 0 , n ) : NEW_LINE
for i in range ( 0 , line + 1 ) : NEW_LINE INDENT print ( binomialCoeff ( line , i ) , " ▁ " , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE
n = 7 NEW_LINE printPascal ( n ) NEW_LINE
def isPerfectSquare ( x ) : NEW_LINE INDENT s = int ( math . sqrt ( x ) ) NEW_LINE return s * s == x NEW_LINE DEDENT
def isFibonacci ( n ) : NEW_LINE
return isPerfectSquare ( 5 * n * n + 4 ) or isPerfectSquare ( 5 * n * n - 4 ) NEW_LINE
for i in range ( 1 , 11 ) : NEW_LINE INDENT if ( isFibonacci ( i ) == True ) : NEW_LINE INDENT print i , " is ▁ a ▁ Fibonacci ▁ Number " NEW_LINE DEDENT else : NEW_LINE INDENT print i , " is ▁ a ▁ not ▁ Fibonacci ▁ Number ▁ " NEW_LINE DEDENT DEDENT
def findTrailingZeros ( n ) : NEW_LINE
count = 0 NEW_LINE
while ( n >= 5 ) : NEW_LINE INDENT n //= 5 NEW_LINE count += n NEW_LINE DEDENT return count NEW_LINE
n = 100 NEW_LINE print ( " Count ▁ of ▁ trailing ▁ 0s ▁ " + " in ▁ 100 ! ▁ is " , findTrailingZeros ( n ) ) NEW_LINE
def catalan ( n ) : NEW_LINE
if n <= 1 : NEW_LINE INDENT return 1 NEW_LINE DEDENT
res = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT res += catalan ( i ) * catalan ( n - i - 1 ) NEW_LINE DEDENT return res NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT print catalan ( i ) , NEW_LINE DEDENT
def catalan ( n ) : NEW_LINE INDENT if ( n == 0 or n == 1 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT DEDENT
catalan = [ 0 ] * ( n + 1 ) NEW_LINE
catalan [ 0 ] = 1 NEW_LINE catalan [ 1 ] = 1 NEW_LINE
for i in range ( 2 , n + 1 ) : NEW_LINE INDENT for j in range ( i ) : NEW_LINE INDENT catalan [ i ] += catalan [ j ] * catalan [ i - j - 1 ] NEW_LINE DEDENT DEDENT
return catalan [ n ] NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT print ( catalan ( i ) , end = " ▁ " ) NEW_LINE DEDENT
def binomialCoefficient ( n , k ) : NEW_LINE INDENT res = 1 NEW_LINE DEDENT
if ( k > n - k ) : NEW_LINE INDENT k = n - k NEW_LINE DEDENT
for i in range ( k ) : NEW_LINE INDENT res = res * ( n - i ) NEW_LINE res = res / ( i + 1 ) NEW_LINE DEDENT return res NEW_LINE
def catalan ( n ) : NEW_LINE
c = binomialCoefficient ( 2 * n , n ) NEW_LINE
return c / ( n + 1 ) NEW_LINE
for i in range ( 10 ) : NEW_LINE INDENT print ( catalan ( i ) , end = " ▁ " ) NEW_LINE DEDENT
def getInvCount ( arr ) : NEW_LINE INDENT inv_count = 0 NEW_LINE for i in range ( 0 , 2 ) : NEW_LINE INDENT for j in range ( i + 1 , 3 ) : NEW_LINE DEDENT DEDENT
if ( arr [ j ] [ i ] > 0 and arr [ j ] [ i ] > arr [ i ] [ j ] ) : NEW_LINE INDENT inv_count += 1 NEW_LINE DEDENT return inv_count NEW_LINE
def isSolvable ( puzzle ) : NEW_LINE
invCount = getInvCount ( puzzle ) NEW_LINE
return ( invCount % 2 == 0 ) NEW_LINE
puzzle = [ [ 1 , 8 , 2 ] , [ 0 , 4 , 3 ] , [ 7 , 6 , 5 ] ] NEW_LINE if ( isSolvable ( puzzle ) ) : NEW_LINE INDENT print ( " Solvable " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Not ▁ Solvable " ) NEW_LINE DEDENT
def find ( p ) : NEW_LINE INDENT return math . ceil ( math . sqrt ( 2 * 365 * math . log ( 1 / ( 1 - p ) ) ) ) ; NEW_LINE DEDENT
print ( find ( 0.70 ) ) NEW_LINE
def countSolutions ( n ) : NEW_LINE INDENT res = 0 NEW_LINE x = 0 NEW_LINE while ( x * x < n ) : NEW_LINE INDENT y = 0 NEW_LINE while ( x * x + y * y < n ) : NEW_LINE INDENT res = res + 1 NEW_LINE y = y + 1 NEW_LINE DEDENT x = x + 1 NEW_LINE DEDENT return res NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT print ( " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " , countSolutions ( 6 ) ) NEW_LINE DEDENT
def countSolutions ( n ) : NEW_LINE INDENT x = 0 NEW_LINE res = 0 NEW_LINE yCount = 0 NEW_LINE DEDENT
while ( yCount * yCount < n ) : NEW_LINE INDENT yCount = yCount + 1 NEW_LINE DEDENT
while ( yCount != 0 ) : NEW_LINE
res = res + yCount NEW_LINE
x = x + 1 NEW_LINE
while ( yCount != 0 and ( x * x + ( yCount - 1 ) * ( yCount - 1 ) >= n ) ) : NEW_LINE INDENT yCount = yCount - 1 NEW_LINE DEDENT return res NEW_LINE
print ( " Total ▁ Number ▁ of ▁ distinct ▁ " , , countSolutions ( 6 ) )
def func ( x ) : NEW_LINE INDENT return x * x * x - x * x + 2 NEW_LINE DEDENT
def derivFunc ( x ) : NEW_LINE INDENT return 3 * x * x - 2 * x NEW_LINE DEDENT
def newtonRaphson ( x ) : NEW_LINE INDENT h = func ( x ) / derivFunc ( x ) NEW_LINE while abs ( h ) >= 0.0001 : NEW_LINE INDENT h = func ( x ) / derivFunc ( x ) NEW_LINE DEDENT DEDENT
x = x - h NEW_LINE print ( " The ▁ value ▁ of ▁ the ▁ root ▁ is ▁ : ▁ " , " % .4f " % x ) NEW_LINE
x0 = - 20 NEW_LINE newtonRaphson ( x0 ) NEW_LINE
def oppositeSigns ( x , y ) : NEW_LINE INDENT return ( ( x ^ y ) < 0 ) ; NEW_LINE DEDENT
x = 100 NEW_LINE y = 1 NEW_LINE if ( oppositeSigns ( x , y ) == True ) : NEW_LINE INDENT print " Signs ▁ are ▁ opposite " NEW_LINE DEDENT else : NEW_LINE INDENT print " Signs ▁ are ▁ not ▁ opposite " NEW_LINE DEDENT
def update ( arr , l , r , val ) : NEW_LINE INDENT arr [ l ] += val NEW_LINE if r + 1 < len ( arr ) : NEW_LINE INDENT arr [ r + 1 ] -= val NEW_LINE DEDENT DEDENT
def getElement ( arr , i ) : NEW_LINE
res = 0 NEW_LINE for j in range ( i + 1 ) : NEW_LINE INDENT res += arr [ j ] NEW_LINE DEDENT return res NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 0 , 0 , 0 , 0 , 0 ] NEW_LINE n = len ( arr ) NEW_LINE l = 2 NEW_LINE r = 4 NEW_LINE val = 2 NEW_LINE update ( arr , l , r , val ) NEW_LINE DEDENT
index = 4 NEW_LINE print ( " Element ▁ at ▁ index " , index , " is " , getElement ( arr , index ) ) NEW_LINE l = 0 NEW_LINE r = 3 NEW_LINE val = 4 NEW_LINE update ( arr , l , r , val ) NEW_LINE
index = 3 NEW_LINE print ( " Element ▁ at ▁ index " , index , " is " , getElement ( arr , index ) ) NEW_LINE
def countSetBits ( n ) : NEW_LINE
bitCount = 0 NEW_LINE for i in range ( 1 , n + 1 ) : NEW_LINE INDENT bitCount += countSetBitsUtil ( i ) NEW_LINE DEDENT return bitCount NEW_LINE
def countSetBitsUtil ( x ) : NEW_LINE INDENT if ( x <= 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT return ( 0 if int ( x % 2 ) == 0 else 1 ) + countSetBitsUtil ( int ( x / 2 ) ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = 4 NEW_LINE print ( " Total ▁ set ▁ bit ▁ count ▁ is " , countSetBits ( n ) ) NEW_LINE DEDENT
def countSetBits ( n ) : NEW_LINE INDENT i = 0 NEW_LINE DEDENT
ans = 0 NEW_LINE
while ( ( 1 << i ) <= n ) : NEW_LINE
k = 0 NEW_LINE
change = 1 << i NEW_LINE
for j in range ( 0 , n + 1 ) : NEW_LINE INDENT ans += k NEW_LINE if change == 1 : NEW_LINE DEDENT
k = not k NEW_LINE
change = 1 << i NEW_LINE else : NEW_LINE change -= 1 NEW_LINE
i += 1 NEW_LINE return ans NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 17 NEW_LINE print ( countSetBits ( n ) ) NEW_LINE DEDENT
def snoob ( x ) : NEW_LINE INDENT next = 0 NEW_LINE if ( x ) : NEW_LINE DEDENT
rightOne = x & - ( x ) NEW_LINE
nextHigherOneBit = x + int ( rightOne ) NEW_LINE
rightOnesPattern = x ^ int ( nextHigherOneBit ) NEW_LINE
rightOnesPattern = ( int ( rightOnesPattern ) / int ( rightOne ) ) NEW_LINE
rightOnesPattern = int ( rightOnesPattern ) >> 2 NEW_LINE
next = nextHigherOneBit | rightOnesPattern NEW_LINE return next NEW_LINE
x = 156 NEW_LINE print ( " Next ▁ higher ▁ number ▁ with ▁ " + " same ▁ number ▁ of ▁ set ▁ bits ▁ is " , snoob ( x ) ) NEW_LINE
def multiplyWith3Point5 ( x ) : NEW_LINE INDENT return ( x << 1 ) + x + ( x >> 1 ) NEW_LINE DEDENT
x = 4 NEW_LINE print ( multiplyWith3Point5 ( x ) ) NEW_LINE
def getModulo ( n , d ) : NEW_LINE INDENT return ( n & ( d - 1 ) ) NEW_LINE DEDENT
n = 6 NEW_LINE
d = 4 NEW_LINE print ( n , " moduo " , d , " is " , getModulo ( n , d ) ) NEW_LINE
def getOddOccurrence ( arr , arr_size ) : NEW_LINE INDENT for i in range ( 0 , arr_size ) : NEW_LINE INDENT count = 0 NEW_LINE for j in range ( 0 , arr_size ) : NEW_LINE INDENT if arr [ i ] == arr [ j ] : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT if ( count % 2 != 0 ) : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT
arr = [ 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE
print ( getOddOccurrence ( arr , n ) ) NEW_LINE
def fastPow ( N , K ) : NEW_LINE INDENT if ( K == 0 ) : NEW_LINE INDENT return 1 ; NEW_LINE DEDENT temp = fastPow ( N , int ( K / 2 ) ) ; NEW_LINE if ( K % 2 == 0 ) : NEW_LINE INDENT return temp * temp ; NEW_LINE DEDENT else : NEW_LINE INDENT return N * temp * temp ; NEW_LINE DEDENT DEDENT def countWays ( N , K ) : NEW_LINE INDENT return K * fastPow ( K - 1 , N - 1 ) ; NEW_LINE DEDENT
N = 3 ; NEW_LINE K = 3 ; NEW_LINE print ( countWays ( N , K ) ) ; NEW_LINE
def countSetBits ( n ) : NEW_LINE
if ( n == 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT else : NEW_LINE INDENT return 1 + countSetBits ( n & ( n - 1 ) ) NEW_LINE DEDENT
n = 9 NEW_LINE
print ( countSetBits ( n ) ) NEW_LINE
print ( bin ( 4 ) . count ( '1' ) ) ; NEW_LINE print ( bin ( 15 ) . count ( '1' ) ) ; NEW_LINE
def countSetBits ( n ) : NEW_LINE INDENT count = 0 NEW_LINE while n : NEW_LINE INDENT count += 1 NEW_LINE n &= ( n - 1 ) NEW_LINE DEDENT return count NEW_LINE DEDENT
def FlippedCount ( a , b ) : NEW_LINE
return countSetBits ( a ^ b ) NEW_LINE
a = 10 NEW_LINE b = 20 NEW_LINE print ( FlippedCount ( a , b ) ) NEW_LINE
def PositionRightmostSetbit ( n ) : NEW_LINE
position = 1 NEW_LINE m = 1 NEW_LINE while ( not ( n & m ) ) : NEW_LINE
m = m << 1 NEW_LINE position += 1 NEW_LINE return position NEW_LINE
n = 16 NEW_LINE
print ( PositionRightmostSetbit ( n ) ) NEW_LINE
INT_SIZE = 32 NEW_LINE def Right_most_setbit ( num ) : NEW_LINE INDENT pos = 1 NEW_LINE DEDENT
for i in range ( INT_SIZE ) : NEW_LINE INDENT if not ( num & ( 1 << i ) ) : NEW_LINE INDENT pos += 1 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT return pos NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT num = 18 NEW_LINE pos = Right_most_setbit ( num ) NEW_LINE print ( pos ) NEW_LINE DEDENT
def bin ( n ) : NEW_LINE INDENT if ( n > 1 ) : NEW_LINE INDENT bin ( n >> 1 ) NEW_LINE DEDENT print ( n & 1 , end = " " ) NEW_LINE DEDENT
bin ( 131 ) NEW_LINE print ( ) NEW_LINE bin ( 3 ) NEW_LINE
def maxOnesIndex ( arr , n ) : NEW_LINE
max_count = 0 NEW_LINE
max_index = 0 NEW_LINE
prev_zero = - 1 NEW_LINE
prev_prev_zero = - 1 NEW_LINE
for curr in range ( n ) : NEW_LINE
if ( arr [ curr ] == 0 ) : NEW_LINE
if ( curr - prev_prev_zero > max_count ) : NEW_LINE INDENT max_count = curr - prev_prev_zero NEW_LINE max_index = prev_zero NEW_LINE DEDENT
prev_prev_zero = prev_zero NEW_LINE prev_zero = curr NEW_LINE
if ( n - prev_prev_zero > max_count ) : NEW_LINE INDENT max_index = prev_zero NEW_LINE DEDENT return max_index NEW_LINE
arr = [ 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Index ▁ of ▁ 0 ▁ to ▁ be ▁ replaced ▁ is ▁ " , maxOnesIndex ( arr , n ) ) NEW_LINE
def min ( x , y ) : NEW_LINE INDENT return x if ( x < y ) else y NEW_LINE DEDENT def max ( x , y ) : NEW_LINE INDENT return x if ( x > y ) else y NEW_LINE DEDENT
def findLength ( arr , n ) : NEW_LINE
max_len = 1 NEW_LINE for i in range ( n - 1 ) : NEW_LINE
mn = arr [ i ] NEW_LINE mx = arr [ i ] NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE
mn = min ( mn , arr [ j ] ) NEW_LINE mx = max ( mx , arr [ j ] ) NEW_LINE
if ( ( mx - mn ) == j - i ) : NEW_LINE INDENT max_len = max ( max_len , mx - mn + 1 ) NEW_LINE DEDENT
return max_len NEW_LINE
arr = [ 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Length ▁ of ▁ the ▁ longest ▁ contiguous ▁ subarray ▁ is ▁ " , findLength ( arr , n ) ) NEW_LINE
def printArr ( arr , k ) : NEW_LINE INDENT for i in range ( k ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) ; NEW_LINE DEDENT print ( ) ; NEW_LINE DEDENT
def printSeqUtil ( n , k , len1 , arr ) : NEW_LINE
if ( len1 == k ) : NEW_LINE INDENT printArr ( arr , k ) ; NEW_LINE return ; NEW_LINE DEDENT
i = 1 if ( len1 == 0 ) else ( arr [ len1 - 1 ] + 1 ) ; NEW_LINE
len1 += 1 ; NEW_LINE
while ( i <= n ) : NEW_LINE INDENT arr [ len1 - 1 ] = i ; NEW_LINE printSeqUtil ( n , k , len1 , arr ) ; NEW_LINE i += 1 ; NEW_LINE DEDENT
len1 -= 1 ; NEW_LINE
def printSeq ( n , k ) : NEW_LINE
arr = [ 0 ] * k ; NEW_LINE
len1 = 0 ; NEW_LINE printSeqUtil ( n , k , len1 , arr ) ; NEW_LINE
k = 3 ; NEW_LINE n = 7 ; NEW_LINE printSeq ( n , k ) ; NEW_LINE
def isSubSequence ( string1 , string2 , m , n ) : NEW_LINE
if m == 0 : NEW_LINE INDENT return True NEW_LINE DEDENT if n == 0 : NEW_LINE INDENT return False NEW_LINE DEDENT
if string1 [ m - 1 ] == string2 [ n - 1 ] : NEW_LINE INDENT return isSubSequence ( string1 , string2 , m - 1 , n - 1 ) NEW_LINE DEDENT
return isSubSequence ( string1 , string2 , m , n - 1 ) NEW_LINE
string1 = " gksrek " NEW_LINE string2 = " geeksforgeeks " NEW_LINE if isSubSequence ( string1 , string2 , len ( string1 ) , len ( string2 ) ) : NEW_LINE INDENT print " Yes " NEW_LINE DEDENT else : NEW_LINE INDENT print " No " NEW_LINE DEDENT
def segregate0and1 ( arr , n ) : NEW_LINE
count = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] == 0 ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT DEDENT
for i in range ( 0 , count ) : NEW_LINE INDENT arr [ i ] = 0 NEW_LINE DEDENT
for i in range ( count , n ) : NEW_LINE INDENT arr [ i ] = 1 NEW_LINE DEDENT
def print_arr ( arr , n ) : NEW_LINE INDENT print ( " Array ▁ after ▁ segregation ▁ is ▁ " , end = " " ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 0 , 1 , 0 , 1 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE segregate0and1 ( arr , n ) NEW_LINE print_arr ( arr , n ) NEW_LINE
def segregate0and1 ( arr , size ) : NEW_LINE INDENT type0 = 0 NEW_LINE type1 = size - 1 NEW_LINE while ( type0 < type1 ) : NEW_LINE INDENT if ( arr [ type0 ] == 1 ) : NEW_LINE INDENT ( arr [ type0 ] , arr [ type1 ] ) = ( arr [ type1 ] , arr [ type0 ] ) NEW_LINE type1 -= 1 NEW_LINE DEDENT else : NEW_LINE INDENT type0 += 1 NEW_LINE DEDENT DEDENT DEDENT
arr = [ 0 , 1 , 0 , 1 , 1 , 1 ] NEW_LINE arr_size = len ( arr ) NEW_LINE segregate0and1 ( arr , arr_size ) NEW_LINE print ( " Array ▁ after ▁ segregation ▁ is " , end = " ▁ " ) NEW_LINE for i in range ( 0 , arr_size ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
def GetCeilIndex ( arr , T , l , r , key ) : NEW_LINE INDENT while ( r - l > 1 ) : NEW_LINE INDENT m = l + ( r - l ) // 2 NEW_LINE if ( arr [ T [ m ] ] >= key ) : NEW_LINE INDENT r = m NEW_LINE DEDENT else : NEW_LINE INDENT l = m NEW_LINE DEDENT DEDENT return r NEW_LINE DEDENT def LongestIncreasingSubsequence ( arr , n ) : NEW_LINE
tailIndices = [ 0 for i in range ( n + 1 ) ] NEW_LINE
prevIndices = [ - 1 for i in range ( n + 1 ) ] NEW_LINE
len = 1 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] < arr [ tailIndices [ 0 ] ] ) : NEW_LINE DEDENT
tailIndices [ 0 ] = i NEW_LINE elif ( arr [ i ] > arr [ tailIndices [ len - 1 ] ] ) : NEW_LINE
prevIndices [ i ] = tailIndices [ len - 1 ] NEW_LINE tailIndices [ len ] = i NEW_LINE len += 1 NEW_LINE else : NEW_LINE
pos = GetCeilIndex ( arr , tailIndices , - 1 , len - 1 , arr [ i ] ) NEW_LINE prevIndices [ i ] = tailIndices [ pos - 1 ] NEW_LINE tailIndices [ pos ] = i NEW_LINE print ( " LIS ▁ of ▁ given ▁ input " ) NEW_LINE i = tailIndices [ len - 1 ] NEW_LINE while ( i >= 0 ) : NEW_LINE print ( arr [ i ] , " ▁ " , end = " " ) NEW_LINE i = prevIndices [ i ] NEW_LINE print ( ) NEW_LINE return len NEW_LINE
arr = [ 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " LIS size " , LongestIncreasingSubsequence ( arr , n ) ) NEW_LINE
def generateUtil ( A , B , C , i , j , m , n , len , flag ) : NEW_LINE
if ( flag ) : NEW_LINE
if ( len ) : NEW_LINE INDENT printArr ( C , len + 1 ) NEW_LINE DEDENT
for k in range ( i , m ) : NEW_LINE INDENT if ( not len ) : NEW_LINE DEDENT
C [ len ] = A [ k ] NEW_LINE
generateUtil ( A , B , C , k + 1 , j , m , n , len , not flag ) NEW_LINE else : NEW_LINE
if ( A [ k ] > C [ len ] ) : NEW_LINE INDENT C [ len + 1 ] = A [ k ] NEW_LINE generateUtil ( A , B , C , k + 1 , j , m , n , len + 1 , not flag ) NEW_LINE DEDENT else : NEW_LINE
for l in range ( j , n ) : NEW_LINE INDENT if ( B [ l ] > C [ len ] ) : NEW_LINE INDENT C [ len + 1 ] = B [ l ] NEW_LINE generateUtil ( A , B , C , i , l + 1 , m , n , len + 1 , not flag ) NEW_LINE DEDENT DEDENT
def generate ( A , B , m , n ) : NEW_LINE
C = [ ] NEW_LINE for i in range ( m + n + 1 ) : NEW_LINE INDENT C . append ( 0 ) NEW_LINE DEDENT generateUtil ( A , B , C , 0 , 0 , m , n , 0 , True ) NEW_LINE
def printArr ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , " ▁ " , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
A = [ 10 , 15 , 25 ] NEW_LINE B = [ 5 , 20 , 30 ] NEW_LINE n = len ( A ) NEW_LINE m = len ( B ) NEW_LINE generate ( A , B , n , m ) NEW_LINE
def replace_elements ( arr , n ) : NEW_LINE
pos = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT arr [ pos ] = arr [ i ] NEW_LINE pos = pos + 1 NEW_LINE while ( pos > 1 and arr [ pos - 2 ] == arr [ pos - 1 ] ) : NEW_LINE INDENT pos -= 1 NEW_LINE arr [ pos - 1 ] += 1 NEW_LINE DEDENT DEDENT
for i in range ( 0 , pos ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT
arr = [ 6 , 4 , 3 , 4 , 3 , 3 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE replace_elements ( arr , n ) NEW_LINE
def arrangeString ( str1 , x , y ) : NEW_LINE INDENT count_0 = 0 NEW_LINE count_1 = 0 NEW_LINE n = len ( str1 ) NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if str1 [ i ] == '0' : NEW_LINE INDENT count_0 += 1 NEW_LINE DEDENT else : NEW_LINE INDENT count_1 += 1 NEW_LINE DEDENT DEDENT
while count_0 > 0 or count_1 > 0 : NEW_LINE INDENT for i in range ( 0 , x ) : NEW_LINE INDENT if count_0 > 0 : NEW_LINE INDENT print ( "0" , end = " " ) NEW_LINE count_0 -= 1 NEW_LINE DEDENT DEDENT for j in range ( 0 , y ) : NEW_LINE INDENT if count_1 > 0 : NEW_LINE INDENT print ( "1" , end = " " ) NEW_LINE count_1 -= 1 NEW_LINE DEDENT DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT str1 = "01101101101101101000000" NEW_LINE x = 1 NEW_LINE y = 2 NEW_LINE arrangeString ( str1 , x , y ) NEW_LINE DEDENT
def rearrange ( n ) : NEW_LINE INDENT global arr NEW_LINE DEDENT
if ( n % 2 == 1 ) : NEW_LINE INDENT return NEW_LINE DEDENT
currIdx = int ( ( n - 1 ) / 2 ) NEW_LINE
while ( currIdx > 0 ) : NEW_LINE INDENT count = currIdx NEW_LINE swapIdx = currIdx NEW_LINE while ( count > 0 ) : NEW_LINE INDENT temp = arr [ swapIdx + 1 ] NEW_LINE arr [ swapIdx + 1 ] = arr [ swapIdx ] NEW_LINE arr [ swapIdx ] = temp NEW_LINE swapIdx = swapIdx + 1 NEW_LINE count = count - 1 NEW_LINE DEDENT currIdx = currIdx - 1 NEW_LINE DEDENT
n = len ( arr ) NEW_LINE rearrange ( n ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( " { } ▁ " . format ( arr [ i ] ) , end = " " ) NEW_LINE DEDENT
def maxDiff ( arr , n ) : NEW_LINE
maxDiff = - 1 NEW_LINE
maxRight = arr [ n - 1 ] NEW_LINE for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT if ( arr [ i ] > maxRight ) : NEW_LINE INDENT maxRight = arr [ i ] NEW_LINE DEDENT else : NEW_LINE INDENT diff = maxRight - arr [ i ] NEW_LINE if ( diff > maxDiff ) : NEW_LINE INDENT maxDiff = diff NEW_LINE DEDENT DEDENT DEDENT return maxDiff NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 1 , 2 , 90 , 10 , 110 ] NEW_LINE n = len ( arr ) NEW_LINE DEDENT
print ( " Maximum ▁ difference ▁ is " , maxDiff ( arr , n ) ) NEW_LINE
def maxDiff ( arr , n ) : NEW_LINE
diff = arr [ 1 ] - arr [ 0 ] NEW_LINE curr_sum = diff NEW_LINE max_sum = curr_sum NEW_LINE for i in range ( 1 , n - 1 ) : NEW_LINE
diff = arr [ i + 1 ] - arr [ i ] NEW_LINE
if ( curr_sum > 0 ) : NEW_LINE INDENT curr_sum += diff NEW_LINE DEDENT else : NEW_LINE INDENT curr_sum = diff NEW_LINE DEDENT
if ( curr_sum > max_sum ) : NEW_LINE INDENT max_sum = curr_sum NEW_LINE DEDENT return max_sum NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 80 , 2 , 6 , 3 , 100 ] NEW_LINE n = len ( arr ) NEW_LINE DEDENT
print ( " Maximum ▁ difference ▁ is " , maxDiff ( arr , n ) ) NEW_LINE
def maxRepeating ( arr , n , k ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT arr [ arr [ i ] % k ] += k NEW_LINE DEDENT
max = arr [ 0 ] NEW_LINE result = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if arr [ i ] > max : NEW_LINE INDENT max = arr [ i ] NEW_LINE result = i NEW_LINE DEDENT DEDENT
return result NEW_LINE
arr = [ 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE k = 8 NEW_LINE print ( " The ▁ maximum ▁ repeating ▁ number ▁ is " , maxRepeating ( arr , n , k ) ) NEW_LINE
def maxPathSum ( ar1 , ar2 , m , n ) : NEW_LINE
i , j = 0 , 0 NEW_LINE
result , sum1 , sum2 = 0 , 0 , 0 NEW_LINE
while ( i < m and j < n ) : NEW_LINE
if ar1 [ i ] < ar2 [ j ] : NEW_LINE INDENT sum1 += ar1 [ i ] NEW_LINE i += 1 NEW_LINE DEDENT
elif ar1 [ i ] > ar2 [ j ] : NEW_LINE INDENT sum2 += ar2 [ j ] NEW_LINE j += 1 NEW_LINE DEDENT
else : NEW_LINE
result += max ( sum1 , sum2 ) + ar1 [ i ] NEW_LINE
sum1 = 0 NEW_LINE sum2 = 0 NEW_LINE
i += 1 NEW_LINE j += 1 NEW_LINE
while i < m : NEW_LINE INDENT sum1 += ar1 [ i ] NEW_LINE i += 1 NEW_LINE DEDENT
while j < n : NEW_LINE INDENT sum2 += ar2 [ j ] NEW_LINE j += 1 NEW_LINE DEDENT
result += max ( sum1 , sum2 ) NEW_LINE return result NEW_LINE
ar1 = [ 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 ] NEW_LINE ar2 = [ 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 ] NEW_LINE m = len ( ar1 ) NEW_LINE n = len ( ar2 ) NEW_LINE
print " Maximum ▁ sum ▁ path ▁ is " , maxPathSum ( ar1 , ar2 , m , n ) NEW_LINE
def smallestGreater ( arr , n ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE DEDENT
diff = 1000 ; NEW_LINE closest = - 1 ; NEW_LINE for j in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] < arr [ j ] and arr [ j ] - arr [ i ] < diff ) : NEW_LINE INDENT diff = arr [ j ] - arr [ i ] ; NEW_LINE closest = j ; NEW_LINE DEDENT DEDENT
if ( closest == - 1 ) : NEW_LINE INDENT print ( " _ ▁ " , end = " " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " { } ▁ " . format ( arr [ closest ] ) , end = " " ) ; NEW_LINE DEDENT
ar = [ 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 ] ; NEW_LINE n = len ( ar ) ; NEW_LINE smallestGreater ( ar , n ) ; NEW_LINE
def findZeroes ( arr , n , m ) : NEW_LINE
wL = wR = 0 NEW_LINE
bestL = bestWindow = 0 NEW_LINE
zeroCount = 0 NEW_LINE
while wR < n : NEW_LINE
if zeroCount <= m : NEW_LINE INDENT if arr [ wR ] == 0 : NEW_LINE INDENT zeroCount += 1 NEW_LINE DEDENT wR += 1 NEW_LINE DEDENT
if zeroCount > m : NEW_LINE INDENT if arr [ wL ] == 0 : NEW_LINE INDENT zeroCount -= 1 NEW_LINE DEDENT wL += 1 NEW_LINE DEDENT
if ( wR - wL > bestWindow ) and ( zeroCount <= m ) : NEW_LINE INDENT bestWindow = wR - wL NEW_LINE bestL = wL NEW_LINE DEDENT
for i in range ( 0 , bestWindow ) : NEW_LINE INDENT if arr [ bestL + i ] == 0 : NEW_LINE INDENT print ( bestL + i , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 1 , 0 , 0 , 1 , 1 , 0 , 1 , 0 , 1 , 1 ] NEW_LINE m = 2 NEW_LINE n = len ( arr ) NEW_LINE print ( " Indexes ▁ of ▁ zeroes ▁ to ▁ be ▁ flipped ▁ are " , end = " ▁ " ) NEW_LINE findZeroes ( arr , n , m ) NEW_LINE
def countIncreasing ( arr , n ) : NEW_LINE
cnt = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE
for j in range ( i + 1 , n ) : NEW_LINE INDENT if arr [ j ] > arr [ j - 1 ] : NEW_LINE INDENT cnt += 1 NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT break NEW_LINE DEDENT return cnt NEW_LINE
arr = [ 1 , 2 , 2 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is " , countIncreasing ( arr , n ) ) NEW_LINE
def countIncreasing ( arr , n ) : NEW_LINE
cnt = 0 NEW_LINE
len = 1 NEW_LINE
for i in range ( 0 , n - 1 ) : NEW_LINE
if arr [ i + 1 ] > arr [ i ] : NEW_LINE INDENT len += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT cnt += ( ( ( len - 1 ) * len ) / 2 ) NEW_LINE len = 1 NEW_LINE DEDENT
if len > 1 : NEW_LINE INDENT cnt += ( ( ( len - 1 ) * len ) / 2 ) NEW_LINE DEDENT return cnt NEW_LINE
arr = [ 1 , 2 , 2 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is " , int ( countIncreasing ( arr , n ) ) ) NEW_LINE
def arraySum ( arr , n ) : NEW_LINE INDENT sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum = sum + arr [ i ] NEW_LINE DEDENT return sum NEW_LINE DEDENT
def maxDiff ( arr , n , k ) : NEW_LINE
arr . sort ( ) NEW_LINE
arraysum = arraySum ( arr , n ) NEW_LINE
diff1 = abs ( arraysum - 2 * arraySum ( arr , k ) ) NEW_LINE
arr . reverse ( ) NEW_LINE
diff2 = abs ( arraysum - 2 * arraySum ( arr , k ) ) NEW_LINE
return ( max ( diff1 , diff2 ) ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 1 , 7 , 4 , 8 , - 1 , 5 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE print ( " Maximum ▁ Difference ▁ = " , maxDiff ( arr , n , k ) ) NEW_LINE DEDENT
def minNumber ( a , n , x ) : NEW_LINE
a . sort ( reverse = False ) NEW_LINE k = 0 NEW_LINE while ( a [ int ( ( n - 1 ) / 2 ) ] != x ) : NEW_LINE INDENT a [ n - 1 ] = x NEW_LINE n += 1 NEW_LINE a . sort ( reverse = False ) NEW_LINE k += 1 NEW_LINE DEDENT return k NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT x = 10 NEW_LINE a = [ 10 , 20 , 30 ] NEW_LINE n = 3 NEW_LINE print ( minNumber ( a , n , x ) ) NEW_LINE DEDENT
def minNumber ( a , n , x ) : NEW_LINE INDENT l = 0 NEW_LINE h = 0 NEW_LINE e = 0 NEW_LINE for i in range ( n ) : NEW_LINE DEDENT
if a [ i ] == x : NEW_LINE INDENT e += 1 NEW_LINE DEDENT
elif a [ i ] > x : NEW_LINE INDENT h += 1 NEW_LINE DEDENT
elif a [ i ] < x : NEW_LINE INDENT l += 1 NEW_LINE DEDENT ans = 0 ; NEW_LINE if l > h : NEW_LINE ans = l - h NEW_LINE elif l < h : NEW_LINE ans = h - l - 1 ; NEW_LINE
return ans + 1 - e NEW_LINE
x = 10 NEW_LINE a = [ 10 , 20 , 30 ] NEW_LINE n = len ( a ) NEW_LINE print ( minNumber ( a , n , x ) ) NEW_LINE
def fun ( x ) : NEW_LINE INDENT y = ( x // 4 ) * 4 NEW_LINE DEDENT
ans = 0 NEW_LINE for i in range ( y , x + 1 ) : NEW_LINE INDENT ans ^= i NEW_LINE DEDENT return ans NEW_LINE
def query ( x ) : NEW_LINE
if ( x == 0 ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT k = ( x + 1 ) // 2 NEW_LINE
if x % 2 == 0 : NEW_LINE INDENT return ( ( fun ( k - 1 ) * 2 ) ^ ( k & 1 ) ) NEW_LINE DEDENT else : NEW_LINE INDENT return ( 2 * fun ( k ) ) NEW_LINE DEDENT def allQueries ( q , l , r ) : NEW_LINE for i in range ( q ) : NEW_LINE INDENT print ( query ( r [ i ] ) ^ query ( l [ i ] - 1 ) ) NEW_LINE DEDENT
q = 3 NEW_LINE l = [ 2 , 2 , 5 ] NEW_LINE r = [ 4 , 8 , 9 ] NEW_LINE allQueries ( q , l , r ) NEW_LINE
def checkEVENodd ( arr , n , l , r ) : NEW_LINE
if ( arr [ r ] == 1 ) : NEW_LINE INDENT print ( " odd " ) NEW_LINE DEDENT
else : NEW_LINE INDENT print ( " even " ) NEW_LINE DEDENT
arr = [ 1 , 1 , 0 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE checkEVENodd ( arr , n , 1 , 3 ) NEW_LINE
def findMean ( arr , l , r ) : NEW_LINE
sum , count = 0 , 0 NEW_LINE
for i in range ( l , r + 1 ) : NEW_LINE INDENT sum += arr [ i ] NEW_LINE count += 1 NEW_LINE DEDENT
mean = math . floor ( sum / count ) NEW_LINE
return mean NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 5 ] NEW_LINE print ( findMean ( arr , 0 , 2 ) ) NEW_LINE print ( findMean ( arr , 1 , 3 ) ) NEW_LINE print ( findMean ( arr , 0 , 4 ) ) NEW_LINE
def calculateProduct ( A , L , R , P ) : NEW_LINE
L = L - 1 NEW_LINE R = R - 1 NEW_LINE ans = 1 NEW_LINE for i in range ( R + 1 ) : NEW_LINE INDENT ans = ans * A [ i ] NEW_LINE ans = ans % P NEW_LINE DEDENT return ans NEW_LINE
A = [ 1 , 2 , 3 , 4 , 5 , 6 ] NEW_LINE P = 229 NEW_LINE L = 2 NEW_LINE R = 5 NEW_LINE print ( calculateProduct ( A , L , R , P ) ) NEW_LINE L = 1 NEW_LINE R = 3 NEW_LINE print ( calculateProduct ( A , L , R , P ) ) NEW_LINE
MAX = 10000 NEW_LINE
prefix = [ 0 ] * ( MAX + 1 ) NEW_LINE def buildPrefix ( ) : NEW_LINE
prime = [ 1 ] * ( MAX + 1 ) NEW_LINE p = 2 NEW_LINE while ( p * p <= MAX ) : NEW_LINE
if ( prime [ p ] == 1 ) : NEW_LINE
i = p * 2 NEW_LINE while ( i <= MAX ) : NEW_LINE INDENT prime [ i ] = 0 NEW_LINE i += p NEW_LINE DEDENT p += 1 NEW_LINE
for p in range ( 2 , MAX + 1 ) : NEW_LINE INDENT prefix [ p ] = prefix [ p - 1 ] NEW_LINE if ( prime [ p ] == 1 ) : NEW_LINE INDENT prefix [ p ] += 1 NEW_LINE DEDENT DEDENT
def query ( L , R ) : NEW_LINE INDENT return prefix [ R ] - prefix [ L - 1 ] NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT buildPrefix ( ) NEW_LINE L = 5 NEW_LINE R = 10 NEW_LINE print ( query ( L , R ) ) NEW_LINE L = 1 NEW_LINE R = 10 NEW_LINE print ( query ( L , R ) ) NEW_LINE DEDENT
def command ( brr , a , b ) : NEW_LINE INDENT arr [ a ] ^= 1 NEW_LINE arr [ b + 1 ] ^= 1 NEW_LINE DEDENT
def process ( arr , n ) : NEW_LINE INDENT for k in range ( 1 , n + 1 , 1 ) : NEW_LINE INDENT arr [ k ] ^= arr [ k - 1 ] NEW_LINE DEDENT DEDENT
def result ( arr , n ) : NEW_LINE INDENT for k in range ( 1 , n + 1 , 1 ) : NEW_LINE INDENT print ( arr [ k ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = 5 NEW_LINE m = 3 NEW_LINE arr = [ 0 for i in range ( n + 2 ) ] NEW_LINE DEDENT
command ( arr , 1 , 5 ) NEW_LINE command ( arr , 2 , 5 ) NEW_LINE command ( arr , 3 , 5 ) NEW_LINE
process ( arr , n ) NEW_LINE
result ( arr , n ) NEW_LINE
def probability ( a , b , size1 , size2 ) : NEW_LINE
max1 = - ( sys . maxsize - 1 ) NEW_LINE count1 = 0 NEW_LINE for i in range ( size1 ) : NEW_LINE INDENT if a [ i ] > max1 : NEW_LINE INDENT count1 = 1 NEW_LINE DEDENT elif a [ i ] == max1 : NEW_LINE INDENT count1 += 1 NEW_LINE DEDENT DEDENT
max2 = - ( sys . maxsize - 1 ) NEW_LINE count2 = 0 NEW_LINE for i in range ( size2 ) : NEW_LINE INDENT if b [ i ] > max2 : NEW_LINE INDENT max2 = b [ i ] NEW_LINE count2 = 1 NEW_LINE DEDENT elif b [ i ] == max2 : NEW_LINE INDENT count2 += 1 NEW_LINE DEDENT DEDENT
return round ( ( count1 * count2 ) / ( size1 * size2 ) , 6 ) NEW_LINE
a = [ 1 , 2 , 3 ] NEW_LINE b = [ 1 , 3 , 3 ] NEW_LINE size1 = len ( a ) NEW_LINE size2 = len ( b ) NEW_LINE print ( probability ( a , b , size1 , size2 ) ) NEW_LINE
def countDe ( arr , n ) : NEW_LINE INDENT i = 0 NEW_LINE DEDENT
v = arr . copy ( ) NEW_LINE
arr . sort ( ) NEW_LINE
count1 = 0 NEW_LINE i = 0 NEW_LINE while ( i < n ) : NEW_LINE INDENT if ( arr [ i ] != v [ i ] ) : NEW_LINE INDENT count1 = count1 + 1 NEW_LINE DEDENT i = i + 1 NEW_LINE DEDENT
arr . sort ( reverse = True ) NEW_LINE
count2 = 0 NEW_LINE i = 0 NEW_LINE while ( i < n ) : NEW_LINE INDENT if ( arr [ i ] != v [ i ] ) : NEW_LINE INDENT count2 = count2 + 1 NEW_LINE DEDENT i = i + 1 NEW_LINE DEDENT
return ( min ( count1 , count2 ) ) NEW_LINE
arr = [ 5 , 9 , 21 , 17 , 13 ] NEW_LINE n = 5 NEW_LINE print ( " Minimum ▁ Dearrangement ▁ = " , countDe ( arr , n ) ) NEW_LINE
def maxOfSegmentMins ( a , n , k ) : NEW_LINE
if k == 1 : NEW_LINE INDENT return min ( a ) NEW_LINE DEDENT if k == 2 : NEW_LINE INDENT return max ( a [ 0 ] , a [ n - 1 ] ) NEW_LINE DEDENT
return max ( a ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ - 10 , - 9 , - 8 , 2 , 7 , - 6 , - 5 ] NEW_LINE n = len ( a ) NEW_LINE k = 2 NEW_LINE print ( maxOfSegmentMins ( a , n , k ) ) NEW_LINE DEDENT
def printMinimumProduct ( arr , n ) : NEW_LINE
first_min = min ( arr [ 0 ] , arr [ 1 ] ) NEW_LINE second_min = max ( arr [ 0 ] , arr [ 1 ] ) NEW_LINE
for i in range ( 2 , n ) : NEW_LINE INDENT if ( arr [ i ] < first_min ) : NEW_LINE INDENT second_min = first_min NEW_LINE first_min = arr [ i ] NEW_LINE DEDENT elif ( arr [ i ] < second_min ) : NEW_LINE INDENT second_min = arr [ i ] NEW_LINE DEDENT DEDENT return first_min * second_min NEW_LINE
a = [ 11 , 8 , 5 , 7 , 5 , 100 ] NEW_LINE n = len ( a ) NEW_LINE print ( printMinimumProduct ( a , n ) ) NEW_LINE
def noOfTriples ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
count = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if arr [ i ] == arr [ 2 ] : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT
if arr [ 0 ] == arr [ 2 ] : NEW_LINE INDENT return ( count - 2 ) * ( count - 1 ) * ( count ) / 6 NEW_LINE DEDENT
elif arr [ 1 ] == arr [ 2 ] : NEW_LINE INDENT return ( count - 1 ) * ( count ) / 2 NEW_LINE DEDENT
return count NEW_LINE
arr = [ 1 , 3 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( noOfTriples ( arr , n ) ) NEW_LINE
def checkReverse ( arr , n ) : NEW_LINE
temp = [ 0 ] * n NEW_LINE for i in range ( n ) : NEW_LINE INDENT temp [ i ] = arr [ i ] NEW_LINE DEDENT
temp . sort ( ) NEW_LINE
for front in range ( n ) : NEW_LINE INDENT if temp [ front ] != arr [ front ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
for back in range ( n - 1 , - 1 , - 1 ) : NEW_LINE INDENT if temp [ back ] != arr [ back ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if front >= back : NEW_LINE INDENT return True NEW_LINE DEDENT
while front != back : NEW_LINE INDENT front += 1 NEW_LINE if arr [ front - 1 ] < arr [ front ] : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
arr = [ 1 , 2 , 5 , 4 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE if checkReverse ( arr , n ) == True : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def checkReverse ( arr , n ) : NEW_LINE INDENT if ( n == 1 ) : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT
i = 1 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if arr [ i - 1 ] < arr [ i ] : NEW_LINE INDENT if ( i == n ) : NEW_LINE INDENT return True NEW_LINE DEDENT DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
j = i NEW_LINE while ( j < n and arr [ j ] < arr [ j - 1 ] ) : NEW_LINE INDENT if ( i > 1 and arr [ j ] < arr [ i - 2 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT j += 1 NEW_LINE DEDENT if ( j == n ) : NEW_LINE INDENT return True NEW_LINE DEDENT
k = j NEW_LINE
if ( arr [ k ] < arr [ i - 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT while ( k > 1 and k < n ) : NEW_LINE INDENT if ( arr [ k ] < arr [ k - 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT k += 1 NEW_LINE DEDENT return True NEW_LINE
arr = [ 1 , 3 , 4 , 10 , 9 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE if checkReverse ( arr , n ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def MinOperation ( a , b , n ) : NEW_LINE
a . sort ( reverse = False ) NEW_LINE b . sort ( reverse = False ) NEW_LINE
result = 0 NEW_LINE
for i in range ( 0 , n , 1 ) : NEW_LINE INDENT if ( a [ i ] > b [ i ] ) : NEW_LINE INDENT result = result + abs ( a [ i ] - b [ i ] ) NEW_LINE DEDENT elif ( a [ i ] < b [ i ] ) : NEW_LINE INDENT result = result + abs ( a [ i ] - b [ i ] ) NEW_LINE DEDENT DEDENT return result NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 3 , 1 , 1 ] NEW_LINE b = [ 1 , 2 , 2 ] NEW_LINE n = len ( a ) NEW_LINE print ( MinOperation ( a , b , n ) ) NEW_LINE DEDENT
def sortExceptUandL ( a , l , u , n ) : NEW_LINE
b = [ 0 ] * ( n - ( u - l + 1 ) ) NEW_LINE for i in range ( 0 , l ) : NEW_LINE INDENT b [ i ] = a [ i ] NEW_LINE DEDENT for i in range ( u + 1 , n ) : NEW_LINE INDENT b [ l + ( i - ( u + 1 ) ) ] = a [ i ] NEW_LINE DEDENT
b . sort ( ) NEW_LINE
for i in range ( 0 , l ) : NEW_LINE INDENT a [ i ] = b [ i ] NEW_LINE DEDENT for i in range ( u + 1 , n ) : NEW_LINE INDENT a [ i ] = b [ l + ( i - ( u + 1 ) ) ] NEW_LINE DEDENT
a = [ 5 , 4 , 3 , 12 , 14 , 9 ] NEW_LINE n = len ( a ) NEW_LINE l = 2 NEW_LINE u = 4 NEW_LINE sortExceptUandL ( a , l , u , n ) NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT print ( " { } ▁ " . format ( a [ i ] ) , end = " " ) NEW_LINE DEDENT
def sortExcept ( arr , k , n ) : NEW_LINE
arr [ k ] , arr [ - 1 ] = arr [ - 1 ] , arr [ k ] NEW_LINE
arr = sorted ( arr , key = lambda i : ( i is arr [ - 1 ] , i ) ) NEW_LINE
last = arr [ - 1 ] NEW_LINE
i = n - 1 NEW_LINE while i > k : NEW_LINE INDENT arr [ i ] = arr [ i - 1 ] NEW_LINE i -= 1 NEW_LINE DEDENT
arr [ k ] = last NEW_LINE return arr NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 10 , 4 , 11 , 7 , 6 , 20 ] NEW_LINE k = 2 NEW_LINE n = len ( a ) NEW_LINE a = sortExcept ( a , k , n ) NEW_LINE print ( " ▁ " . join ( list ( map ( str , a ) ) ) ) NEW_LINE DEDENT
def findMinSwaps ( arr , n ) : NEW_LINE
noOfZeroes = [ 0 ] * n NEW_LINE count = 0 NEW_LINE
noOfZeroes [ n - 1 ] = 1 - arr [ n - 1 ] NEW_LINE for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT noOfZeroes [ i ] = noOfZeroes [ i + 1 ] NEW_LINE if ( arr [ i ] == 0 ) : NEW_LINE INDENT noOfZeroes [ i ] = noOfZeroes [ i ] + 1 NEW_LINE DEDENT DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT if ( arr [ i ] == 1 ) : NEW_LINE INDENT count = count + noOfZeroes [ i ] NEW_LINE DEDENT DEDENT return count NEW_LINE
arr = [ 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findMinSwaps ( arr , n ) ) NEW_LINE
def maxPartitions ( arr , n ) : NEW_LINE INDENT ans = 0 ; max_so_far = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE DEDENT
max_so_far = max ( max_so_far , arr [ i ] ) NEW_LINE
if ( max_so_far == i ) : NEW_LINE INDENT ans += 1 NEW_LINE DEDENT return ans NEW_LINE
arr = [ 1 , 0 , 2 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxPartitions ( arr , n ) ) NEW_LINE
def rankify ( A ) : NEW_LINE
R = [ 0 for x in range ( len ( A ) ) ] NEW_LINE
for i in range ( len ( A ) ) : NEW_LINE INDENT ( r , s ) = ( 1 , 1 ) NEW_LINE for j in range ( len ( A ) ) : NEW_LINE INDENT if j != i and A [ j ] < A [ i ] : NEW_LINE INDENT r += 1 NEW_LINE DEDENT if j != i and A [ j ] == A [ i ] : NEW_LINE INDENT s += 1 NEW_LINE DEDENT DEDENT DEDENT
R [ i ] = r + ( s - 1 ) / 2 NEW_LINE return R NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT A = [ 1 , 2 , 5 , 2 , 1 , 25 , 2 ] NEW_LINE print ( A ) NEW_LINE print ( rankify ( A ) ) NEW_LINE DEDENT
def min_noOf_operation ( arr , n , k ) : NEW_LINE INDENT res = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT noOfSubtraction = 0 NEW_LINE if ( arr [ i ] > arr [ i - 1 ] ) : NEW_LINE DEDENT DEDENT
noOfSubtraction = ( arr [ i ] - arr [ i - 1 ] ) / k ; NEW_LINE
if ( ( arr [ i ] - arr [ i - 1 ] ) % k != 0 ) : NEW_LINE INDENT noOfSubtraction += 1 NEW_LINE DEDENT
arr [ i ] = arr [ i ] - k * noOfSubtraction NEW_LINE
res = res + noOfSubtraction NEW_LINE return int ( res ) NEW_LINE
arr = [ 1 , 1 , 2 , 3 ] NEW_LINE N = len ( arr ) NEW_LINE k = 5 NEW_LINE print ( min_noOf_operation ( arr , N , k ) ) NEW_LINE
def maxSum ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum += arr [ i ] * i NEW_LINE DEDENT return sum NEW_LINE
arr = [ 3 , 5 , 6 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxSum ( arr , n ) ) NEW_LINE
def countPairs ( a , n , k ) : NEW_LINE INDENT res = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( abs ( a [ j ] - a [ i ] ) < k ) : NEW_LINE INDENT res += 1 NEW_LINE DEDENT DEDENT DEDENT return res NEW_LINE DEDENT
a = [ 1 , 10 , 4 , 2 ] NEW_LINE k = 3 NEW_LINE n = len ( a ) NEW_LINE print ( countPairs ( a , n , k ) , end = " " ) NEW_LINE
def countPairs ( a , n , k ) : NEW_LINE
a . sort ( ) NEW_LINE res = 0 NEW_LINE for i in range ( n ) : NEW_LINE
j = i + 1 NEW_LINE while ( j < n and a [ j ] - a [ i ] < k ) : NEW_LINE INDENT res += 1 NEW_LINE j += 1 NEW_LINE DEDENT return res NEW_LINE
a = [ 1 , 10 , 4 , 2 ] NEW_LINE k = 3 NEW_LINE n = len ( a ) NEW_LINE print ( countPairs ( a , n , k ) , end = " " ) NEW_LINE
def sumOfMinAbsDifferences ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
sum = 0 NEW_LINE
sum += abs ( arr [ 0 ] - arr [ 1 ] ) ; NEW_LINE
sum += abs ( arr [ n - 1 ] - arr [ n - 2 ] ) ; NEW_LINE
for i in range ( 1 , n - 1 ) : NEW_LINE INDENT sum += min ( abs ( arr [ i ] - arr [ i - 1 ] ) , abs ( arr [ i ] - arr [ i + 1 ] ) ) NEW_LINE DEDENT
return sum ; NEW_LINE
arr = [ 5 , 10 , 1 , 4 , 8 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Sum ▁ = ▁ " , sumOfMinAbsDifferences ( arr , n ) ) NEW_LINE
def findSmallestDifference ( A , B , m , n ) : NEW_LINE
A . sort ( ) NEW_LINE B . sort ( ) NEW_LINE a = 0 NEW_LINE b = 0 NEW_LINE
result = sys . maxsize NEW_LINE
while ( a < m and b < n ) : NEW_LINE INDENT if ( abs ( A [ a ] - B [ b ] ) < result ) : NEW_LINE INDENT result = abs ( A [ a ] - B [ b ] ) NEW_LINE DEDENT DEDENT
if ( A [ a ] < B [ b ] ) : NEW_LINE INDENT a += 1 NEW_LINE DEDENT else : NEW_LINE INDENT b += 1 NEW_LINE DEDENT
return result NEW_LINE
A = [ 1 , 2 , 11 , 5 ] NEW_LINE
B = [ 4 , 12 , 19 , 23 , 127 , 235 ] NEW_LINE
m = len ( A ) NEW_LINE n = len ( B ) NEW_LINE
print ( findSmallestDifference ( A , B , m , n ) ) NEW_LINE
def findLarger ( arr , n ) : NEW_LINE
x = sorted ( arr ) NEW_LINE
for i in range ( n / 2 , n ) : NEW_LINE INDENT print ( x [ i ] ) , NEW_LINE DEDENT
arr = [ 1 , 3 , 6 , 1 , 0 , 9 ] NEW_LINE n = len ( arr ) ; NEW_LINE findLarger ( arr , n ) NEW_LINE
def findSingle ( ar , n ) : NEW_LINE
res = ar [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT res = res ^ ar [ i ] NEW_LINE DEDENT return res NEW_LINE
ar = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] NEW_LINE print " Element ▁ occurring ▁ once ▁ is " , findSingle ( ar , len ( ar ) ) NEW_LINE
def countOccurrences ( arr , n , x ) : NEW_LINE INDENT res = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if x == arr [ i ] : NEW_LINE INDENT res += 1 NEW_LINE DEDENT DEDENT return res NEW_LINE DEDENT
arr = [ 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE x = 2 NEW_LINE print ( countOccurrences ( arr , n , x ) ) NEW_LINE
def binarySearch ( arr , l , r , x ) : NEW_LINE INDENT if ( r < l ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT mid = int ( l + ( r - l ) / 2 ) NEW_LINE DEDENT
if arr [ mid ] == x : NEW_LINE INDENT return mid NEW_LINE DEDENT
if arr [ mid ] > x : NEW_LINE INDENT return binarySearch ( arr , l , mid - 1 , x ) NEW_LINE DEDENT
return binarySearch ( arr , mid + 1 , r , x ) NEW_LINE
def countOccurrences ( arr , n , x ) : NEW_LINE INDENT ind = binarySearch ( arr , 0 , n - 1 , x ) NEW_LINE DEDENT
if ind == - 1 : NEW_LINE INDENT return 0 NEW_LINE DEDENT
count = 1 NEW_LINE left = ind - 1 NEW_LINE while ( left >= 0 and arr [ left ] == x ) : NEW_LINE INDENT count += 1 NEW_LINE left -= 1 NEW_LINE DEDENT
right = ind + 1 ; NEW_LINE while ( right < n and arr [ right ] == x ) : NEW_LINE INDENT count += 1 NEW_LINE right += 1 NEW_LINE DEDENT return count NEW_LINE
arr = [ 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE x = 2 NEW_LINE print ( countOccurrences ( arr , n , x ) ) NEW_LINE
def printClosest ( arr , n , x ) : NEW_LINE
res_l , res_r = 0 , 0 NEW_LINE
l , r , diff = 0 , n - 1 , MAX_VAL NEW_LINE
while r > l : NEW_LINE
if abs ( arr [ l ] + arr [ r ] - x ) < diff : NEW_LINE INDENT res_l = l NEW_LINE res_r = r NEW_LINE diff = abs ( arr [ l ] + arr [ r ] - x ) NEW_LINE DEDENT if arr [ l ] + arr [ r ] > x : NEW_LINE
r -= 1 NEW_LINE else : NEW_LINE
l += 1 NEW_LINE print ( ' The ▁ closest ▁ pair ▁ is ▁ { } ▁ and ▁ { } ' . format ( arr [ res_l ] , arr [ res_r ] ) ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 10 , 22 , 28 , 29 , 30 , 40 ] NEW_LINE n = len ( arr ) NEW_LINE x = 54 NEW_LINE printClosest ( arr , n , x ) NEW_LINE DEDENT
def countOnes ( arr , low , high ) : NEW_LINE INDENT if high >= low : NEW_LINE DEDENT
mid = low + ( high - low ) // 2 NEW_LINE
if ( ( mid == high or arr [ mid + 1 ] == 0 ) and ( arr [ mid ] == 1 ) ) : NEW_LINE INDENT return mid + 1 NEW_LINE DEDENT
if arr [ mid ] == 1 : NEW_LINE INDENT return countOnes ( arr , ( mid + 1 ) , high ) NEW_LINE DEDENT
return countOnes ( arr , low , mid - 1 ) NEW_LINE return 0 NEW_LINE
arr = [ 1 , 1 , 1 , 1 , 0 , 0 , 0 ] NEW_LINE print ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is " , countOnes ( arr , 0 , len ( arr ) - 1 ) ) NEW_LINE
def findMissingUtil ( arr1 , arr2 , N ) : NEW_LINE
if N == 1 : NEW_LINE INDENT return arr1 [ 0 ] ; NEW_LINE DEDENT
if arr1 [ 0 ] != arr2 [ 0 ] : NEW_LINE INDENT return arr1 [ 0 ] NEW_LINE DEDENT
lo = 0 NEW_LINE hi = N - 1 NEW_LINE
while ( lo < hi ) : NEW_LINE INDENT mid = ( lo + hi ) / 2 NEW_LINE DEDENT
if arr1 [ mid ] == arr2 [ mid ] : NEW_LINE INDENT lo = mid NEW_LINE DEDENT else : NEW_LINE INDENT hi = mid NEW_LINE DEDENT
if lo == hi - 1 : NEW_LINE INDENT break NEW_LINE DEDENT
return arr1 [ hi ] NEW_LINE
def findMissing ( arr1 , arr2 , M , N ) : NEW_LINE INDENT if N == M - 1 : NEW_LINE INDENT print ( " Missing ▁ Element ▁ is " , findMissingUtil ( arr1 , arr2 , M ) ) NEW_LINE DEDENT elif M == N - 1 : NEW_LINE INDENT print ( " Missing ▁ Element ▁ is " , findMissingUtil ( arr2 , arr1 , N ) ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Invalid ▁ Input " ) NEW_LINE DEDENT DEDENT
arr1 = [ 1 , 4 , 5 , 7 , 9 ] NEW_LINE arr2 = [ 4 , 5 , 7 , 9 ] NEW_LINE M = len ( arr1 ) NEW_LINE N = len ( arr2 ) NEW_LINE findMissing ( arr1 , arr2 , M , N ) NEW_LINE
def findMissing ( arr1 , arr2 , M , N ) : NEW_LINE INDENT if ( M != N - 1 and N != M - 1 ) : NEW_LINE INDENT print ( " Invalid ▁ Input " ) NEW_LINE return NEW_LINE DEDENT DEDENT
res = 0 NEW_LINE for i in range ( 0 , M ) : NEW_LINE INDENT res = res ^ arr1 [ i ] ; NEW_LINE DEDENT for i in range ( 0 , N ) : NEW_LINE INDENT res = res ^ arr2 [ i ] NEW_LINE DEDENT print ( " Missing ▁ element ▁ is " , res ) NEW_LINE
arr1 = [ 4 , 1 , 5 , 9 , 7 ] NEW_LINE arr2 = [ 7 , 5 , 9 , 4 ] NEW_LINE M = len ( arr1 ) NEW_LINE N = len ( arr2 ) NEW_LINE findMissing ( arr1 , arr2 , M , N ) NEW_LINE
def getTwoElements ( arr , n ) : NEW_LINE INDENT global x , y NEW_LINE x = 0 NEW_LINE y = 0 NEW_LINE DEDENT
xor1 = arr [ 0 ] NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT xor1 = xor1 ^ arr [ i ] NEW_LINE DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT xor1 = xor1 ^ i NEW_LINE DEDENT
set_bit_no = xor1 & ~ ( xor1 - 1 ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] & set_bit_no ) != 0 : NEW_LINE DEDENT
x = x ^ arr [ i ] NEW_LINE else : NEW_LINE
y = y ^ arr [ i ] NEW_LINE for i in range ( 1 , n + 1 ) : NEW_LINE if ( i & set_bit_no ) != 0 : NEW_LINE
x = x ^ i NEW_LINE else : NEW_LINE
y = y ^ i NEW_LINE
arr = [ 1 , 3 , 4 , 5 , 5 , 6 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE getTwoElements ( arr , n ) NEW_LINE print ( " The ▁ missing ▁ element ▁ is " , x , " and ▁ the ▁ repeating ▁ number ▁ is " , y ) NEW_LINE
def search ( arr , n , x ) : NEW_LINE
i = 0 NEW_LINE while ( i < n ) : NEW_LINE
if ( arr [ i ] == x ) : NEW_LINE INDENT return i NEW_LINE DEDENT
i = i + abs ( arr [ i ] - x ) NEW_LINE print ( " number ▁ is ▁ not ▁ present ! " ) NEW_LINE return - 1 NEW_LINE
arr = [ 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE x = 3 NEW_LINE print ( " Element " , x , " ▁ is ▁ present ▁ at ▁ index ▁ " , search ( arr , n , 3 ) ) NEW_LINE
import sys NEW_LINE def thirdLargest ( arr , arr_size ) : NEW_LINE
if ( arr_size < 3 ) : NEW_LINE INDENT print ( " ▁ Invalid ▁ Input ▁ " ) NEW_LINE return NEW_LINE DEDENT
first = arr [ 0 ] NEW_LINE for i in range ( 1 , arr_size ) : NEW_LINE INDENT if ( arr [ i ] > first ) : NEW_LINE INDENT first = arr [ i ] NEW_LINE DEDENT DEDENT
second = - sys . maxsize NEW_LINE for i in range ( 0 , arr_size ) : NEW_LINE INDENT if ( arr [ i ] > second and arr [ i ] < first ) : NEW_LINE INDENT second = arr [ i ] NEW_LINE DEDENT DEDENT
third = - sys . maxsize NEW_LINE for i in range ( 0 , arr_size ) : NEW_LINE INDENT if ( arr [ i ] > third and arr [ i ] < second ) : NEW_LINE INDENT third = arr [ i ] NEW_LINE DEDENT DEDENT print ( " The ▁ Third ▁ Largest " , " element ▁ is " , third ) NEW_LINE
arr = [ 12 , 13 , 1 , 10 , 34 , 16 ] NEW_LINE n = len ( arr ) NEW_LINE thirdLargest ( arr , n ) NEW_LINE
import sys NEW_LINE def thirdLargest ( arr , arr_size ) : NEW_LINE
if ( arr_size < 3 ) : NEW_LINE INDENT print ( " ▁ Invalid ▁ Input ▁ " ) NEW_LINE return NEW_LINE DEDENT
first = arr [ 0 ] NEW_LINE second = - sys . maxsize NEW_LINE third = - sys . maxsize NEW_LINE
for i in range ( 1 , arr_size ) : NEW_LINE
if ( arr [ i ] > first ) : NEW_LINE INDENT third = second NEW_LINE second = first NEW_LINE first = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > second ) : NEW_LINE INDENT third = second NEW_LINE second = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] > third ) : NEW_LINE INDENT third = arr [ i ] NEW_LINE DEDENT print ( " The ▁ third ▁ Largest " , " element ▁ is " , third ) NEW_LINE
arr = [ 12 , 13 , 1 , 10 , 34 , 16 ] NEW_LINE n = len ( arr ) NEW_LINE thirdLargest ( arr , n ) NEW_LINE
def checkPair ( arr , n ) : NEW_LINE INDENT s = set ( ) NEW_LINE sum = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT sum += arr [ i ] NEW_LINE DEDENT
if sum % 2 != 0 : NEW_LINE INDENT return False NEW_LINE DEDENT sum = sum / 2 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT val = sum - arr [ i ] NEW_LINE if arr [ i ] not in s : NEW_LINE INDENT s . add ( arr [ i ] ) NEW_LINE DEDENT DEDENT
if val in s : NEW_LINE INDENT print ( " Pair ▁ elements ▁ are " , arr [ i ] , " and " , int ( val ) ) NEW_LINE DEDENT
arr = [ 2 , 11 , 5 , 1 , 4 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE if checkPair ( arr , n ) == False : NEW_LINE INDENT print ( " No ▁ pair ▁ found " ) NEW_LINE DEDENT
def search ( arr , n , x ) : NEW_LINE
if ( arr [ n - 1 ] == x ) : NEW_LINE INDENT return " Found " NEW_LINE DEDENT backup = arr [ n - 1 ] NEW_LINE arr [ n - 1 ] = x NEW_LINE
i = 0 NEW_LINE while ( i < n ) : NEW_LINE
if ( arr [ i ] == x ) : NEW_LINE
arr [ n - 1 ] = backup NEW_LINE
if ( i < n - 1 ) : NEW_LINE INDENT return " Found " NEW_LINE DEDENT
return " Not ▁ Found " NEW_LINE i = i + 1 NEW_LINE
arr = [ 4 , 6 , 1 , 5 , 8 ] NEW_LINE n = len ( arr ) NEW_LINE x = 1 NEW_LINE print ( search ( arr , n , x ) ) NEW_LINE
def findMajority ( arr , n ) : NEW_LINE INDENT return arr [ int ( n / 2 ) ] NEW_LINE DEDENT
arr = [ 1 , 2 , 2 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findMajority ( arr , n ) ) NEW_LINE
def minAdjDifference ( arr , n ) : NEW_LINE INDENT if ( n < 2 ) : return NEW_LINE DEDENT
res = abs ( arr [ 1 ] - arr [ 0 ] ) NEW_LINE for i in range ( 2 , n ) : NEW_LINE INDENT res = min ( res , abs ( arr [ i ] - arr [ i - 1 ] ) ) NEW_LINE DEDENT
res = min ( res , abs ( arr [ n - 1 ] - arr [ 0 ] ) ) NEW_LINE print ( " Min ▁ Difference ▁ = ▁ " , res ) NEW_LINE
a = [ 10 , 12 , 13 , 15 , 10 ] NEW_LINE n = len ( a ) NEW_LINE minAdjDifference ( a , n ) NEW_LINE
MAX = 100000 NEW_LINE def Print3Smallest ( arr , n ) : NEW_LINE INDENT firstmin = MAX NEW_LINE secmin = MAX NEW_LINE thirdmin = MAX NEW_LINE for i in range ( 0 , n ) : NEW_LINE DEDENT
if arr [ i ] < firstmin : NEW_LINE INDENT thirdmin = secmin NEW_LINE secmin = firstmin NEW_LINE firstmin = arr [ i ] NEW_LINE DEDENT
elif arr [ i ] < secmin : NEW_LINE INDENT thirdmin = secmin NEW_LINE secmin = arr [ i ] NEW_LINE DEDENT
elif arr [ i ] < thirdmin : NEW_LINE INDENT thirdmin = arr [ i ] NEW_LINE DEDENT print ( " First ▁ min ▁ = ▁ " , firstmin ) NEW_LINE print ( " Second ▁ min ▁ = ▁ " , secmin ) NEW_LINE print ( " Third ▁ min ▁ = ▁ " , thirdmin ) NEW_LINE
arr = [ 4 , 9 , 1 , 32 , 12 ] NEW_LINE n = len ( arr ) NEW_LINE Print3Smallest ( arr , n ) NEW_LINE
def getMin ( arr , n ) : NEW_LINE INDENT return min ( arr ) NEW_LINE DEDENT def getMax ( arr , n ) : NEW_LINE INDENT return max ( arr ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 12 , 1234 , 45 , 67 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ element ▁ of ▁ array : ▁ " , getMin ( arr , n ) ) NEW_LINE print ( " Maximum ▁ element ▁ of ▁ array : ▁ " , getMax ( arr , n ) ) NEW_LINE DEDENT
def printfrequency ( arr , n ) : NEW_LINE
for j in range ( n ) : NEW_LINE INDENT arr [ j ] = arr [ j ] - 1 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT arr [ arr [ i ] % n ] = arr [ arr [ i ] % n ] + n NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT print ( i + 1 , " - > " , arr [ i ] // n ) NEW_LINE DEDENT
arr = [ 2 , 3 , 3 , 2 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE printfrequency ( arr , n ) NEW_LINE
def getInvCount ( arr , n ) : NEW_LINE
invcount = 0 NEW_LINE for i in range ( 1 , n - 1 ) : NEW_LINE
small = 0 NEW_LINE for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( arr [ i ] > arr [ j ] ) : NEW_LINE INDENT small += 1 NEW_LINE DEDENT DEDENT
great = 0 ; NEW_LINE for j in range ( i - 1 , - 1 , - 1 ) : NEW_LINE INDENT if ( arr [ i ] < arr [ j ] ) : NEW_LINE INDENT great += 1 NEW_LINE DEDENT DEDENT
invcount += great * small NEW_LINE return invcount NEW_LINE
arr = [ 8 , 4 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Inversion ▁ Count ▁ : " , getInvCount ( arr , n ) ) NEW_LINE
def findWater ( arr , n ) : NEW_LINE
water = 0 NEW_LINE
left [ 0 ] = arr [ 0 ] NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT left [ i ] = max ( left [ i - 1 ] , arr [ i ] ) NEW_LINE DEDENT
right [ n - 1 ] = arr [ n - 1 ] NEW_LINE for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT right [ i ] = max ( right [ i + 1 ] , arr [ i ] ) ; NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT water += min ( left [ i ] , right [ i ] ) - arr [ i ] NEW_LINE DEDENT return water NEW_LINE
arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is " , findWater ( arr , n ) ) NEW_LINE
def findWater ( arr , n ) : NEW_LINE
result = 0 NEW_LINE
left_max = 0 NEW_LINE right_max = 0 NEW_LINE
lo = 0 NEW_LINE hi = n - 1 NEW_LINE while ( lo <= hi ) : NEW_LINE INDENT if ( arr [ lo ] < arr [ hi ] ) : NEW_LINE INDENT if ( arr [ lo ] > left_max ) : NEW_LINE DEDENT DEDENT
left_max = arr [ lo ] NEW_LINE else : NEW_LINE
result += left_max - arr [ lo ] NEW_LINE lo += 1 NEW_LINE else : NEW_LINE if ( arr [ hi ] > right_max ) : NEW_LINE
right_max = arr [ hi ] NEW_LINE else : NEW_LINE result += right_max - arr [ hi ] NEW_LINE hi -= 1 NEW_LINE return result NEW_LINE
arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " , findWater ( arr , n ) ) NEW_LINE
def missingK ( a , k , n ) : NEW_LINE INDENT difference = 0 NEW_LINE ans = 0 NEW_LINE count = k NEW_LINE flag = 0 NEW_LINE DEDENT
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT difference = 0 NEW_LINE DEDENT
if ( ( a [ i ] + 1 ) != a [ i + 1 ] ) : NEW_LINE
difference += ( a [ i + 1 ] - a [ i ] ) - 1 NEW_LINE
if ( difference >= count ) : NEW_LINE INDENT ans = a [ i ] + count NEW_LINE flag = 1 NEW_LINE break NEW_LINE DEDENT else : NEW_LINE INDENT count -= difference NEW_LINE DEDENT
if ( flag ) : NEW_LINE INDENT return ans NEW_LINE DEDENT else : NEW_LINE INDENT return - 1 NEW_LINE DEDENT
a = [ 1 , 5 , 11 , 19 ] NEW_LINE
k = 11 NEW_LINE n = len ( a ) NEW_LINE
missing = missingK ( a , k , n ) NEW_LINE print ( missing ) NEW_LINE
median = 0 NEW_LINE i = 0 NEW_LINE j = 0 NEW_LINE
def maximum ( a , b ) : NEW_LINE INDENT return a if a > b else b NEW_LINE DEDENT
def minimum ( a , b ) : NEW_LINE INDENT return a if a < b else b NEW_LINE DEDENT
def findMedianSortedArrays ( a , n , b , m ) : NEW_LINE INDENT global median , i , j NEW_LINE min_index = 0 NEW_LINE max_index = n NEW_LINE while ( min_index <= max_index ) : NEW_LINE INDENT i = int ( ( min_index + max_index ) / 2 ) NEW_LINE j = int ( ( ( n + m + 1 ) / 2 ) - i ) NEW_LINE DEDENT DEDENT
if ( i < n and j > 0 and b [ j - 1 ] > a [ i ] ) : NEW_LINE INDENT min_index = i + 1 NEW_LINE DEDENT
elif ( i > 0 and j < m and b [ j ] < a [ i - 1 ] ) : NEW_LINE INDENT max_index = i - 1 NEW_LINE DEDENT
else : NEW_LINE
if ( i == 0 ) : NEW_LINE INDENT median = b [ j - 1 ] NEW_LINE DEDENT
elif ( j == 0 ) : NEW_LINE INDENT median = a [ i - 1 ] NEW_LINE DEDENT else : NEW_LINE INDENT median = maximum ( a [ i - 1 ] , b [ j - 1 ] ) NEW_LINE DEDENT break NEW_LINE
if ( ( n + m ) % 2 == 1 ) : NEW_LINE INDENT return median NEW_LINE DEDENT
if ( i == n ) : NEW_LINE INDENT return ( ( median + b [ j ] ) / 2.0 ) NEW_LINE DEDENT
if ( j == m ) : NEW_LINE INDENT return ( ( median + a [ i ] ) / 2.0 ) NEW_LINE DEDENT return ( ( median + minimum ( a [ i ] , b [ j ] ) ) / 2.0 ) NEW_LINE
a = [ 900 ] NEW_LINE b = [ 10 , 13 , 14 ] NEW_LINE n = len ( a ) NEW_LINE m = len ( b ) NEW_LINE
if ( n < m ) : NEW_LINE INDENT print ( " The ▁ median ▁ is ▁ : ▁ { } " . format ( findMedianSortedArrays ( a , n , b , m ) ) ) NEW_LINE DEDENT else : NEW_LINE INDENT echo ( " The ▁ median ▁ is ▁ : ▁ { } " . format ( findMedianSortedArrays ( b , m , a , n ) ) ) NEW_LINE DEDENT
def printUncommon ( arr1 , arr2 , n1 , n2 ) : NEW_LINE INDENT i = 0 NEW_LINE j = 0 NEW_LINE k = 0 NEW_LINE while ( i < n1 and j < n2 ) : NEW_LINE DEDENT
if ( arr1 [ i ] < arr2 [ j ] ) : NEW_LINE INDENT print ( arr1 [ i ] , end = " ▁ " ) NEW_LINE i = i + 1 NEW_LINE k = k + 1 NEW_LINE DEDENT elif ( arr2 [ j ] < arr1 [ i ] ) : NEW_LINE INDENT print ( arr2 [ j ] , end = " ▁ " ) NEW_LINE k = k + 1 NEW_LINE j = j + 1 NEW_LINE DEDENT
else : NEW_LINE INDENT i = i + 1 NEW_LINE j = j + 1 NEW_LINE DEDENT
while ( i < n1 ) : NEW_LINE INDENT print ( arr1 [ i ] , end = " ▁ " ) NEW_LINE i = i + 1 NEW_LINE k = k + 1 NEW_LINE DEDENT while ( j < n2 ) : NEW_LINE INDENT print ( arr2 [ j ] , end = " ▁ " ) NEW_LINE j = j + 1 NEW_LINE k = k + 1 NEW_LINE DEDENT
arr1 = [ 10 , 20 , 30 ] NEW_LINE arr2 = [ 20 , 25 , 30 , 40 , 50 ] NEW_LINE n1 = len ( arr1 ) NEW_LINE n2 = len ( arr2 ) NEW_LINE printUncommon ( arr1 , arr2 , n1 , n2 ) NEW_LINE
def leastFrequent ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
min_count = n + 1 NEW_LINE res = - 1 NEW_LINE curr_count = 1 NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] == arr [ i - 1 ] ) : NEW_LINE INDENT curr_count = curr_count + 1 NEW_LINE DEDENT else : NEW_LINE INDENT if ( curr_count < min_count ) : NEW_LINE INDENT min_count = curr_count NEW_LINE res = arr [ i - 1 ] NEW_LINE DEDENT curr_count = 1 NEW_LINE DEDENT DEDENT
if ( curr_count < min_count ) : NEW_LINE INDENT min_count = curr_count NEW_LINE res = arr [ n - 1 ] NEW_LINE DEDENT return res NEW_LINE
arr = [ 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE print ( leastFrequent ( arr , n ) ) NEW_LINE
M = 4 ; NEW_LINE
def maximumSum ( a , n ) : NEW_LINE INDENT global M ; NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT a [ i ] . sort ( ) ; NEW_LINE DEDENT
sum = a [ n - 1 ] [ M - 1 ] ; NEW_LINE prev = a [ n - 1 ] [ M - 1 ] ; NEW_LINE
for i in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT for j in range ( M - 1 , - 1 , - 1 ) : NEW_LINE INDENT if ( a [ i ] [ j ] < prev ) : NEW_LINE INDENT prev = a [ i ] [ j ] ; NEW_LINE sum += prev ; NEW_LINE break ; NEW_LINE DEDENT DEDENT DEDENT
if ( j == - 1 ) : NEW_LINE INDENT return 0 ; NEW_LINE DEDENT return sum ; NEW_LINE
arr = [ [ 1 , 7 , 3 , 4 ] , [ 4 , 2 , 5 , 1 ] , [ 9 , 5 , 1 , 8 ] ] ; NEW_LINE n = len ( arr ) ; NEW_LINE print ( maximumSum ( arr , n ) ) ; NEW_LINE
def countPairs ( A , n , k ) : NEW_LINE INDENT ans = 0 NEW_LINE DEDENT
A . sort ( ) NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT
x = 0 NEW_LINE
while ( ( A [ i ] * math . pow ( k , x ) ) <= A [ j ] ) : NEW_LINE INDENT if ( ( A [ i ] * math . pow ( k , x ) ) == A [ j ] ) : NEW_LINE INDENT ans += 1 NEW_LINE break NEW_LINE DEDENT x += 1 NEW_LINE DEDENT return ans NEW_LINE
A = [ 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 ] NEW_LINE n = len ( A ) NEW_LINE k = 3 NEW_LINE print ( countPairs ( A , n , k ) ) NEW_LINE
def minDistance ( arr , n ) : NEW_LINE INDENT maximum_element = arr [ 0 ] NEW_LINE min_dis = n NEW_LINE index = 0 NEW_LINE for i in range ( 1 , n ) : NEW_LINE DEDENT
if ( maximum_element == arr [ i ] ) : NEW_LINE INDENT min_dis = min ( min_dis , ( i - index ) ) NEW_LINE index = i NEW_LINE DEDENT
elif ( maximum_element < arr [ i ] ) : NEW_LINE INDENT maximum_element = arr [ i ] NEW_LINE min_dis = n NEW_LINE index = i NEW_LINE DEDENT
else : NEW_LINE INDENT continue NEW_LINE DEDENT return min_dis NEW_LINE
arr = [ 6 , 3 , 1 , 3 , 6 , 4 , 6 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ distance ▁ = " , minDistance ( arr , n ) ) NEW_LINE
def findValue ( arr , n , k ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] == k ) : NEW_LINE INDENT k = k * 2 NEW_LINE DEDENT DEDENT return k NEW_LINE
arr = [ 2 , 3 , 4 , 10 , 8 , 1 ] NEW_LINE k = 2 NEW_LINE n = len ( arr ) NEW_LINE print ( findValue ( arr , n , k ) ) NEW_LINE
def dupLastIndex ( arr , n ) : NEW_LINE
if ( arr == None or n <= 0 ) : NEW_LINE INDENT return NEW_LINE DEDENT
for i in range ( n - 1 , 0 , - 1 ) : NEW_LINE INDENT if ( arr [ i ] == arr [ i - 1 ] ) : NEW_LINE INDENT print ( " Last ▁ index : " , i ,   " Last " , ▁ " duplicate item : " , arr [ i ] ) NEW_LINE return NEW_LINE DEDENT DEDENT
print ( " no ▁ duplicate ▁ found " ) NEW_LINE
arr = [ 1 , 5 , 5 , 6 , 6 , 7 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE dupLastIndex ( arr , n ) NEW_LINE
def findSmallest ( a , n ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE INDENT if ( ( a [ j ] % a [ i ] ) >= 1 ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT DEDENT
if ( j == n - 1 ) : NEW_LINE INDENT return a [ i ] NEW_LINE DEDENT return - 1 NEW_LINE
a = [ 25 , 20 , 5 , 10 , 100 ] NEW_LINE n = len ( a ) NEW_LINE print ( findSmallest ( a , n ) ) NEW_LINE
def findSmallest ( a , n ) : NEW_LINE
smallest = min_element ( a ) NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT if ( a [ i ] % smallest >= 1 ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT DEDENT return smallest NEW_LINE
a = [ 25 , 20 , 5 , 10 , 100 ] NEW_LINE n = len ( a ) NEW_LINE print ( findSmallest ( a , n ) ) NEW_LINE
def findIndex ( arr ) : NEW_LINE
maxIndex = 0 NEW_LINE for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT if ( arr [ i ] > arr [ maxIndex ] ) : NEW_LINE INDENT maxIndex = i NEW_LINE DEDENT DEDENT
for i in range ( 0 , len ( arr ) ) : NEW_LINE INDENT if ( maxIndex != i and arr [ maxIndex ] < ( 2 * arr [ i ] ) ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT DEDENT return maxIndex NEW_LINE
arr = [ 3 , 6 , 1 , 0 ] NEW_LINE print ( findIndex ( arr ) ) NEW_LINE
def find_consecutive_steps ( arr , len ) : NEW_LINE INDENT count = 0 ; maximum = 0 NEW_LINE for index in range ( 1 , len ) : NEW_LINE DEDENT
if ( arr [ index ] > arr [ index - 1 ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT else : NEW_LINE INDENT maximum = max ( maximum , count ) NEW_LINE count = 0 NEW_LINE DEDENT return max ( maximum , count ) NEW_LINE
arr = [ 1 , 2 , 3 , 4 ] NEW_LINE len = len ( arr ) NEW_LINE print ( find_consecutive_steps ( arr , len ) ) NEW_LINE
def CalculateMax ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE min_sum = arr [ 0 ] + arr [ 1 ] NEW_LINE max_sum = arr [ n - 1 ] + arr [ n - 2 ] NEW_LINE return abs ( max_sum - min_sum ) NEW_LINE
arr = [ 6 , 7 , 1 , 11 ] NEW_LINE n = len ( arr ) NEW_LINE print ( CalculateMax ( arr , n ) ) NEW_LINE
def calculate ( a , n ) : NEW_LINE
a . sort ( ) ; NEW_LINE
s = [ ] ; NEW_LINE i = 0 ; NEW_LINE j = n - 1 ; NEW_LINE while ( i < j ) : NEW_LINE INDENT s . append ( ( a [ i ] + a [ j ] ) ) ; NEW_LINE i += 1 ; NEW_LINE j -= 1 ; NEW_LINE DEDENT mini = min ( s ) ; NEW_LINE maxi = max ( s ) ; NEW_LINE return abs ( maxi - mini ) ; NEW_LINE
a = [ 2 , 6 , 4 , 3 ] ; NEW_LINE n = len ( a ) ; NEW_LINE print ( calculate ( a , n ) ) ; NEW_LINE
def printMinDiffPairs ( arr , n ) : NEW_LINE INDENT if n <= 1 : return NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
minDiff = arr [ 1 ] - arr [ 0 ] NEW_LINE for i in range ( 2 , n ) : NEW_LINE INDENT minDiff = min ( minDiff , arr [ i ] - arr [ i - 1 ] ) NEW_LINE DEDENT
for i in range ( 1 , n ) : NEW_LINE INDENT if ( arr [ i ] - arr [ i - 1 ] ) == minDiff : NEW_LINE INDENT print ( " ( " + str ( arr [ i - 1 ] ) + " , ▁ " + str ( arr [ i ] ) + " ) , ▁ " , end = ' ' ) NEW_LINE DEDENT DEDENT
arr = [ 5 , 3 , 2 , 4 , 1 ] NEW_LINE n = len ( arr ) NEW_LINE printMinDiffPairs ( arr , n ) NEW_LINE
def calculateDiff ( i , j , arr ) : NEW_LINE
return abs ( arr [ i ] - arr [ j ] ) + abs ( i - j ) NEW_LINE
def maxDistance ( arr , n ) : NEW_LINE
result = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( i , n ) : NEW_LINE DEDENT
if ( calculateDiff ( i , j , arr ) > result ) : NEW_LINE INDENT result = calculateDiff ( i , j , arr ) NEW_LINE DEDENT return result NEW_LINE
arr = [ - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 ] NEW_LINE n = len ( arr ) NEW_LINE print ( maxDistance ( arr , n ) ) NEW_LINE
def maxDistance ( array ) : NEW_LINE
max1 = - 2147483648 NEW_LINE min1 = + 2147483647 NEW_LINE max2 = - 2147483648 NEW_LINE min2 = + 2147483647 NEW_LINE for i in range ( len ( array ) ) : NEW_LINE
max1 = max ( max1 , array [ i ] + i ) NEW_LINE min1 = min ( min1 , array [ i ] + i ) NEW_LINE max2 = max ( max2 , array [ i ] - i ) NEW_LINE min2 = min ( min2 , array [ i ] - i ) NEW_LINE
return max ( max1 - min1 , max2 - min2 ) NEW_LINE
array = [ - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 ] NEW_LINE print ( maxDistance ( array ) ) NEW_LINE
def extrema ( a , n ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in range ( 1 , n - 1 ) : NEW_LINE
count += ( a [ i ] > a [ i - 1 ] and a [ i ] > a [ i + 1 ] ) ; NEW_LINE
count += ( a [ i ] < a [ i - 1 ] and a [ i ] < a [ i + 1 ] ) ; NEW_LINE return count NEW_LINE
a = [ 1 , 0 , 2 , 1 ] NEW_LINE n = len ( a ) NEW_LINE print ( extrema ( a , n ) ) NEW_LINE
def findClosest ( arr , n , target ) : NEW_LINE
if ( target <= arr [ 0 ] ) : NEW_LINE INDENT return arr [ 0 ] NEW_LINE DEDENT if ( target >= arr [ n - 1 ] ) : NEW_LINE INDENT return arr [ n - 1 ] NEW_LINE DEDENT
i = 0 ; j = n ; mid = 0 NEW_LINE while ( i < j ) : NEW_LINE INDENT mid = ( i + j ) // 2 NEW_LINE if ( arr [ mid ] == target ) : NEW_LINE INDENT return arr [ mid ] NEW_LINE DEDENT DEDENT
if ( target < arr [ mid ] ) : NEW_LINE
if ( mid > 0 and target > arr [ mid - 1 ] ) : NEW_LINE INDENT return getClosest ( arr [ mid - 1 ] , arr [ mid ] , target ) NEW_LINE DEDENT
j = mid NEW_LINE
else : NEW_LINE INDENT if ( mid < n - 1 and target < arr [ mid + 1 ] ) : NEW_LINE INDENT return getClosest ( arr [ mid ] , arr [ mid + 1 ] , target ) NEW_LINE DEDENT DEDENT
i = mid + 1 NEW_LINE
return arr [ mid ] NEW_LINE
def getClosest ( val1 , val2 , target ) : NEW_LINE INDENT if ( target - val1 >= val2 - target ) : NEW_LINE INDENT return val2 NEW_LINE DEDENT else : NEW_LINE INDENT return val1 NEW_LINE DEDENT DEDENT
arr = [ 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE target = 11 NEW_LINE print ( findClosest ( arr , n , target ) ) NEW_LINE
def _sum ( a , n ) : NEW_LINE
maxSum = - 9999999 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT maxSum = max ( maxSum , a [ i ] + a [ j ] ) NEW_LINE DEDENT DEDENT
c = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT if a [ i ] + a [ j ] == maxSum : NEW_LINE INDENT c += 1 NEW_LINE DEDENT DEDENT DEDENT return c NEW_LINE
array = [ 1 , 1 , 1 , 2 , 2 , 2 ] NEW_LINE n = len ( array ) NEW_LINE print ( _sum ( array , n ) ) NEW_LINE
def sum ( a , n ) : NEW_LINE
maxVal = a [ 0 ] ; maxCount = 1 NEW_LINE secondMax = sys . maxsize NEW_LINE for i in range ( 1 , n ) : NEW_LINE INDENT if ( a [ i ] == maxVal ) : NEW_LINE INDENT maxCount += 1 NEW_LINE DEDENT elif ( a [ i ] > maxVal ) : NEW_LINE INDENT secondMax = maxVal NEW_LINE secondMaxCount = maxCount NEW_LINE maxVal = a [ i ] NEW_LINE maxCount = 1 NEW_LINE DEDENT elif ( a [ i ] == secondMax ) : NEW_LINE INDENT secondMax = a [ i ] NEW_LINE secondMaxCount += 1 NEW_LINE DEDENT elif ( a [ i ] > secondMax ) : NEW_LINE INDENT secondMax = a [ i ] NEW_LINE secondMaxCount = 1 NEW_LINE DEDENT DEDENT
if ( maxCount > 1 ) : NEW_LINE INDENT return maxCount * ( maxCount - 1 ) / 2 NEW_LINE DEDENT
return secondMaxCount NEW_LINE
array = [ 1 , 1 , 1 , 2 , 2 , 2 , 3 ] NEW_LINE n = len ( array ) NEW_LINE print ( sum ( array , n ) ) NEW_LINE
def printKMissing ( arr , n , k ) : NEW_LINE INDENT arr . sort ( ) NEW_LINE DEDENT
i = 0 NEW_LINE while ( i < n and arr [ i ] <= 0 ) : NEW_LINE INDENT i = i + 1 NEW_LINE DEDENT
count = 0 NEW_LINE curr = 1 NEW_LINE while ( count < k and i < n ) : NEW_LINE INDENT if ( arr [ i ] != curr ) : NEW_LINE INDENT print ( str ( curr ) + " ▁ " , end = ' ' ) NEW_LINE count = count + 1 NEW_LINE DEDENT else : NEW_LINE INDENT i = i + 1 NEW_LINE DEDENT curr = curr + 1 NEW_LINE DEDENT
while ( count < k ) : NEW_LINE INDENT print ( str ( curr ) + " ▁ " , end = ' ' ) NEW_LINE curr = curr + 1 NEW_LINE count = count + 1 NEW_LINE DEDENT
arr = [ 2 , 3 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE k = 3 NEW_LINE printKMissing ( arr , n , k ) ; NEW_LINE
def nobleInteger ( arr , size ) : NEW_LINE INDENT for i in range ( 0 , size ) : NEW_LINE INDENT count = 0 NEW_LINE for j in range ( 0 , size ) : NEW_LINE INDENT if ( arr [ i ] < arr [ j ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT DEDENT DEDENT
if ( count == arr [ i ] ) : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT return - 1 NEW_LINE
arr = [ 10 , 3 , 20 , 40 , 2 ] NEW_LINE size = len ( arr ) NEW_LINE res = nobleInteger ( arr , size ) NEW_LINE if ( res != - 1 ) : NEW_LINE INDENT print ( " The ▁ noble ▁ integer ▁ is ▁ " , res ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ Noble ▁ Integer ▁ Found " ) NEW_LINE DEDENT
def nobleInteger ( arr ) : NEW_LINE INDENT arr . sort ( ) NEW_LINE DEDENT
n = len ( arr ) NEW_LINE for i in range ( n - 1 ) : NEW_LINE INDENT if arr [ i ] == arr [ i + 1 ] : NEW_LINE INDENT continue NEW_LINE DEDENT DEDENT
if arr [ i ] == n - i - 1 : NEW_LINE INDENT return arr [ i ] NEW_LINE DEDENT if arr [ n - 1 ] == 0 : NEW_LINE return arr [ n - 1 ] NEW_LINE return - 1 NEW_LINE
arr = [ 10 , 3 , 20 , 40 , 2 ] NEW_LINE res = nobleInteger ( arr ) NEW_LINE if res != - 1 : NEW_LINE INDENT print ( " The ▁ noble ▁ integer ▁ is " , res ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ Noble ▁ Integer ▁ Found " ) NEW_LINE DEDENT
def findMinSum ( a , b , n ) : NEW_LINE
a . sort ( ) NEW_LINE b . sort ( ) NEW_LINE
sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum = sum + abs ( a [ i ] - b [ i ] ) NEW_LINE DEDENT return sum NEW_LINE
a = [ 4 , 1 , 8 , 7 ] NEW_LINE b = [ 2 , 3 , 6 , 5 ] NEW_LINE n = len ( a ) NEW_LINE print ( findMinSum ( a , b , n ) ) NEW_LINE
def checkIsAP ( arr , n ) : NEW_LINE INDENT if ( n == 1 ) : return True NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
d = arr [ 1 ] - arr [ 0 ] NEW_LINE for i in range ( 2 , n ) : NEW_LINE INDENT if ( arr [ i ] - arr [ i - 1 ] != d ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
arr = [ 20 , 15 , 5 , 0 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Yes " ) if ( checkIsAP ( arr , n ) ) else print ( " No " ) NEW_LINE
def minProductSubset ( a , n ) : NEW_LINE INDENT if ( n == 1 ) : NEW_LINE INDENT return a [ 0 ] NEW_LINE DEDENT DEDENT
max_neg = float ( ' - inf ' ) NEW_LINE min_pos = float ( ' inf ' ) NEW_LINE count_neg = 0 NEW_LINE count_zero = 0 NEW_LINE prod = 1 NEW_LINE for i in range ( 0 , n ) : NEW_LINE
if ( a [ i ] == 0 ) : NEW_LINE INDENT count_zero = count_zero + 1 NEW_LINE continue NEW_LINE DEDENT
if ( a [ i ] < 0 ) : NEW_LINE INDENT count_neg = count_neg + 1 NEW_LINE max_neg = max ( max_neg , a [ i ] ) NEW_LINE DEDENT
if ( a [ i ] > 0 ) : NEW_LINE INDENT min_pos = min ( min_pos , a [ i ] ) NEW_LINE DEDENT prod = prod * a [ i ] NEW_LINE
if ( count_zero == n or ( count_neg == 0 and count_zero > 0 ) ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( count_neg == 0 ) : NEW_LINE INDENT return min_pos NEW_LINE DEDENT
if ( ( count_neg & 1 ) == 0 and count_neg != 0 ) : NEW_LINE
prod = int ( prod / max_neg ) NEW_LINE return prod NEW_LINE
a = [ - 1 , - 1 , - 2 , 4 , 3 ] NEW_LINE n = len ( a ) NEW_LINE print ( minProductSubset ( a , n ) ) NEW_LINE
def countPairs ( a , n ) : NEW_LINE
mn = + 2147483647 NEW_LINE mx = - 2147483648 NEW_LINE for i in range ( n ) : NEW_LINE INDENT mn = min ( mn , a [ i ] ) NEW_LINE mx = max ( mx , a [ i ] ) NEW_LINE DEDENT
c1 = 0 NEW_LINE
c2 = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( a [ i ] == mn ) : NEW_LINE INDENT c1 += 1 NEW_LINE DEDENT if ( a [ i ] == mx ) : NEW_LINE INDENT c2 += 1 NEW_LINE DEDENT DEDENT
if ( mn == mx ) : NEW_LINE INDENT return n * ( n - 1 ) // 2 NEW_LINE DEDENT else : NEW_LINE INDENT return c1 * c2 NEW_LINE DEDENT
a = [ 3 , 2 , 1 , 1 , 3 ] NEW_LINE n = len ( a ) NEW_LINE print ( countPairs ( a , n ) ) NEW_LINE
def binary_search ( a , x , lo = 0 , hi = None ) : NEW_LINE INDENT if hi is None : NEW_LINE INDENT hi = len ( a ) NEW_LINE DEDENT while lo < hi : NEW_LINE INDENT mid = ( lo + hi ) // 2 NEW_LINE midval = a [ mid ] NEW_LINE if midval < x : NEW_LINE INDENT lo = mid + 1 NEW_LINE DEDENT elif midval > x : NEW_LINE INDENT hi = mid NEW_LINE DEDENT else : NEW_LINE INDENT return mid NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT def findElement ( a , n , b ) : NEW_LINE
a . sort ( ) NEW_LINE
mx = a [ n - 1 ] NEW_LINE while ( b < max ) : NEW_LINE
if ( binary_search ( a , b , 0 , n ) != - 1 ) : NEW_LINE INDENT b *= 2 NEW_LINE DEDENT else : NEW_LINE INDENT return b NEW_LINE DEDENT return b NEW_LINE
a = [ 1 , 2 , 3 ] NEW_LINE n = len ( a ) NEW_LINE b = 1 NEW_LINE print findElement ( a , n , b ) NEW_LINE
Mod = 1000000007 NEW_LINE
def findSum ( arr , n ) : NEW_LINE INDENT sum = 0 NEW_LINE DEDENT
arr . sort ( ) NEW_LINE
i = 0 NEW_LINE while i < n and arr [ i ] < 0 : NEW_LINE INDENT if i != n - 1 and arr [ i + 1 ] <= 0 : NEW_LINE INDENT sum = ( sum + ( arr [ i ] * arr [ i + 1 ] ) % Mod ) % Mod NEW_LINE i += 2 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
j = n - 1 NEW_LINE while j >= 0 and arr [ j ] > 0 : NEW_LINE INDENT if j != 0 and arr [ j - 1 ] > 0 : NEW_LINE INDENT sum = ( sum + ( arr [ j ] * arr [ j - 1 ] ) % Mod ) % Mod NEW_LINE j -= 2 NEW_LINE DEDENT else : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if j > i : NEW_LINE INDENT sum = ( sum + ( arr [ i ] * arr [ j ] ) % Mod ) % Mod NEW_LINE DEDENT
elif i == j : NEW_LINE INDENT sum = ( sum + arr [ i ] ) % Mod NEW_LINE DEDENT return sum NEW_LINE
arr = [ - 1 , 9 , 4 , 5 , - 4 , 7 ] NEW_LINE n = len ( arr ) NEW_LINE print ( findSum ( arr , n ) ) NEW_LINE
def countOddRotations ( n ) : NEW_LINE INDENT odd_count = 0 ; even_count = 0 NEW_LINE while n != 0 : NEW_LINE INDENT digit = n % 10 NEW_LINE if digit % 2 == 0 : NEW_LINE INDENT odd_count += 1 NEW_LINE DEDENT else : NEW_LINE INDENT even_count += 1 NEW_LINE DEDENT n = n // 10 NEW_LINE DEDENT print ( " Odd ▁ = " , odd_count ) NEW_LINE print ( " Even ▁ = " , even_count ) NEW_LINE DEDENT
n = 1234 NEW_LINE countOddRotations ( n ) NEW_LINE
def numberofDigits ( n ) : NEW_LINE INDENT cnt = 0 NEW_LINE while n > 0 : NEW_LINE INDENT cnt += 1 NEW_LINE n //= 10 NEW_LINE DEDENT return cnt NEW_LINE DEDENT
def cal ( num ) : NEW_LINE INDENT digit = numberofDigits ( num ) NEW_LINE powTen = pow ( 10 , digit - 1 ) NEW_LINE for i in range ( digit - 1 ) : NEW_LINE INDENT firstDigit = num // powTen NEW_LINE DEDENT DEDENT
left = ( num * 10 + firstDigit - ( firstDigit * powTen * 10 ) ) NEW_LINE print ( left , end = " ▁ " ) NEW_LINE
num = left NEW_LINE
num = 1445 NEW_LINE cal ( num ) NEW_LINE
def CheckKCycles ( n , s ) : NEW_LINE INDENT ff = True NEW_LINE for i in range ( 1 , n ) : NEW_LINE DEDENT
x = int ( s [ i : ] + s [ 0 : i ] ) NEW_LINE
if ( x >= int ( s ) ) : NEW_LINE INDENT continue NEW_LINE DEDENT ff = False NEW_LINE break NEW_LINE if ( ff ) : NEW_LINE print ( " Yes " ) NEW_LINE else : NEW_LINE print ( " No " ) NEW_LINE
n = 3 NEW_LINE s = "123" NEW_LINE CheckKCycles ( n , s ) NEW_LINE
def rightRotationDivisor ( N ) : NEW_LINE INDENT lastDigit = N % 10 NEW_LINE rightRotation = ( lastDigit * 10 ** int ( log10 ( N ) ) + N // 10 ) NEW_LINE return rightRotation % N == 0 NEW_LINE DEDENT
def generateNumbers ( m ) : NEW_LINE INDENT for i in range ( 10 ** ( m - 1 ) , 10 ** m ) : NEW_LINE INDENT if rightRotationDivisor ( i ) : NEW_LINE INDENT print ( i ) NEW_LINE DEDENT DEDENT DEDENT
m = 3 NEW_LINE generateNumbers ( m ) NEW_LINE
def checkIfSortRotated ( arr , n ) : NEW_LINE INDENT minEle = sys . maxsize NEW_LINE maxEle = - sys . maxsize - 1 NEW_LINE minIndex = - 1 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT if arr [ i ] < minEle : NEW_LINE INDENT minEle = arr [ i ] NEW_LINE minIndex = i NEW_LINE DEDENT DEDENT flag1 = 1 NEW_LINE
for i in range ( 1 , minIndex ) : NEW_LINE INDENT if arr [ i ] < arr [ i - 1 ] : NEW_LINE INDENT flag1 = 0 NEW_LINE break NEW_LINE DEDENT DEDENT flag2 = 2 NEW_LINE
for i in range ( minIndex + 1 , n ) : NEW_LINE INDENT if arr [ i ] < arr [ i - 1 ] : NEW_LINE INDENT flag2 = 0 NEW_LINE break NEW_LINE DEDENT DEDENT
if ( flag1 and flag2 and arr [ n - 1 ] < arr [ 0 ] ) : NEW_LINE INDENT print ( " YES " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " NO " ) NEW_LINE DEDENT
arr = [ 3 , 4 , 5 , 1 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE
checkIfSortRotated ( arr , n ) NEW_LINE
def occurredOnce ( arr , n ) : NEW_LINE
arr . sort ( ) NEW_LINE
if arr [ 0 ] != arr [ 1 ] : NEW_LINE INDENT print ( arr [ 0 ] , end = " ▁ " ) NEW_LINE DEDENT
for i in range ( 1 , n - 1 ) : NEW_LINE INDENT if ( arr [ i ] != arr [ i + 1 ] and arr [ i ] != arr [ i - 1 ] ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
if arr [ n - 2 ] != arr [ n - 1 ] : NEW_LINE INDENT print ( arr [ n - 1 ] , end = " ▁ " ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE occurredOnce ( arr , n ) NEW_LINE DEDENT
def occurredOnce ( arr , n ) : NEW_LINE INDENT i = 1 NEW_LINE len = n NEW_LINE DEDENT
if arr [ 0 ] == arr [ len - 1 ] : NEW_LINE INDENT i = 2 NEW_LINE len -= 1 NEW_LINE DEDENT
while i < n : NEW_LINE
if arr [ i ] == arr [ i - 1 ] : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
else : NEW_LINE INDENT print ( arr [ i - 1 ] , end = " ▁ " ) NEW_LINE DEDENT i += 1 NEW_LINE
if ( arr [ n - 1 ] != arr [ 0 ] and arr [ n - 1 ] != arr [ n - 2 ] ) : NEW_LINE INDENT print ( arr [ n - 1 ] ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ] NEW_LINE n = len ( arr ) NEW_LINE occurredOnce ( arr , n ) NEW_LINE DEDENT
def rvereseArray ( arr , start , end ) : NEW_LINE INDENT while start < end : NEW_LINE INDENT temp = arr [ start ] NEW_LINE arr [ start ] = arr [ end ] NEW_LINE arr [ end ] = temp NEW_LINE start += 1 NEW_LINE end -= 1 NEW_LINE DEDENT DEDENT
def printArray ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
def splitArr ( arr , k , n ) : NEW_LINE INDENT rvereseArray ( arr , 0 , n - 1 ) NEW_LINE rvereseArray ( arr , 0 , n - k - 1 ) NEW_LINE rvereseArray ( arr , n - k , n - 1 ) NEW_LINE DEDENT
arr = [ 12 , 10 , 5 , 6 , 52 , 36 ] NEW_LINE n = len ( arr ) NEW_LINE k = 2 NEW_LINE
splitArr ( arr , k , n ) NEW_LINE printArray ( arr , n ) NEW_LINE
def countRotationsDivBy8 ( n ) : NEW_LINE INDENT l = len ( n ) NEW_LINE count = 0 NEW_LINE DEDENT
if ( l == 1 ) : NEW_LINE INDENT oneDigit = int ( n [ 0 ] ) NEW_LINE if ( oneDigit % 8 == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT return 0 NEW_LINE DEDENT
if ( l == 2 ) : NEW_LINE
first = int ( n [ 0 ] ) * 10 + int ( n [ 1 ] ) NEW_LINE
second = int ( n [ 1 ] ) * 10 + int ( n [ 0 ] ) NEW_LINE if ( first % 8 == 0 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT if ( second % 8 == 0 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT return count NEW_LINE
threeDigit = 0 NEW_LINE for i in range ( 0 , ( l - 2 ) ) : NEW_LINE INDENT threeDigit = ( int ( n [ i ] ) * 100 + int ( n [ i + 1 ] ) * 10 + int ( n [ i + 2 ] ) ) NEW_LINE if ( threeDigit % 8 == 0 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT
threeDigit = ( int ( n [ l - 1 ] ) * 100 + int ( n [ 0 ] ) * 10 + int ( n [ 1 ] ) ) NEW_LINE if ( threeDigit % 8 == 0 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
threeDigit = ( int ( n [ l - 2 ] ) * 100 + int ( n [ l - 1 ] ) * 10 + int ( n [ 0 ] ) ) NEW_LINE if ( threeDigit % 8 == 0 ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
return count NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT n = "43262488612" NEW_LINE print ( " Rotations : " , countRotationsDivBy8 ( n ) ) NEW_LINE DEDENT
def findRotations ( str ) : NEW_LINE
tmp = str + str NEW_LINE n = len ( str ) NEW_LINE for i in range ( 1 , n + 1 ) : NEW_LINE
substring = tmp [ i : i + n ] NEW_LINE
if ( str == substring ) : NEW_LINE INDENT return i NEW_LINE DEDENT return n NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT str = " abc " NEW_LINE print ( findRotations ( str ) ) NEW_LINE DEDENT
def isRotation ( x , y ) : NEW_LINE
x64 = x | ( x << 32 ) NEW_LINE while ( x64 >= y ) : NEW_LINE
if ( ( x64 ) == y ) : NEW_LINE INDENT return True NEW_LINE DEDENT
x64 >>= 1 NEW_LINE return False NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT x = 122 NEW_LINE y = 2147483678 NEW_LINE if ( isRotation ( x , y ) == False ) : NEW_LINE INDENT print ( " yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " no " ) NEW_LINE DEDENT DEDENT
def countRotations ( n ) : NEW_LINE INDENT l = len ( n ) NEW_LINE DEDENT
if ( l == 1 ) : NEW_LINE INDENT oneDigit = ( int ) ( n [ 0 ] ) NEW_LINE if ( oneDigit % 4 == 0 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT return 0 NEW_LINE DEDENT
count = 0 NEW_LINE for i in range ( 0 , l - 1 ) : NEW_LINE INDENT twoDigit = ( int ) ( n [ i ] ) * 10 + ( int ) ( n [ i + 1 ] ) NEW_LINE if ( twoDigit % 4 == 0 ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT DEDENT
twoDigit = ( int ) ( n [ l - 1 ] ) * 10 + ( int ) ( n [ 0 ] ) NEW_LINE if ( twoDigit % 4 == 0 ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT return count NEW_LINE
n = "4834" NEW_LINE print ( " Rotations : ▁ " , countRotations ( n ) ) NEW_LINE
def solve ( A , n ) : NEW_LINE INDENT cnt = 0 NEW_LINE DEDENT
parent = [ None ] * ( n + 1 ) NEW_LINE
vis = [ None ] * ( n + 1 ) NEW_LINE
for i in range ( 0 , n + 1 ) : NEW_LINE INDENT parent [ i ] = - 1 NEW_LINE vis [ i ] = 0 NEW_LINE DEDENT for i in range ( 0 , n ) : NEW_LINE INDENT j = i NEW_LINE DEDENT
if ( parent [ j ] == - 1 ) : NEW_LINE
while ( parent [ j ] == - 1 ) : NEW_LINE INDENT parent [ j ] = i NEW_LINE j = ( j + A [ j ] + 1 ) % n NEW_LINE DEDENT
if ( parent [ j ] == i ) : NEW_LINE
while ( vis [ j ] == 0 ) : NEW_LINE INDENT vis [ j ] = 1 NEW_LINE cnt = cnt + 1 NEW_LINE j = ( j + A [ j ] + 1 ) % n NEW_LINE DEDENT return cnt NEW_LINE
A = [ 0 , 0 , 0 , 2 ] NEW_LINE n = len ( A ) NEW_LINE print ( solve ( A , n ) ) NEW_LINE
def TOWUtil ( arr , n , curr_elements , no_of_selected_elements , soln , min_diff , Sum , curr_sum , curr_position ) : NEW_LINE
if ( curr_position == n ) : NEW_LINE INDENT return NEW_LINE DEDENT
if ( ( int ( n / 2 ) - no_of_selected_elements ) > ( n - curr_position ) ) : NEW_LINE INDENT return NEW_LINE DEDENT
TOWUtil ( arr , n , curr_elements , no_of_selected_elements , soln , min_diff , Sum , curr_sum , curr_position + 1 ) NEW_LINE
no_of_selected_elements += 1 NEW_LINE curr_sum = curr_sum + arr [ curr_position ] NEW_LINE curr_elements [ curr_position ] = True NEW_LINE
if ( no_of_selected_elements == int ( n / 2 ) ) : NEW_LINE
if ( abs ( int ( Sum / 2 ) - curr_sum ) < min_diff [ 0 ] ) : NEW_LINE INDENT min_diff [ 0 ] = abs ( int ( Sum / 2 ) - curr_sum ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT soln [ i ] = curr_elements [ i ] NEW_LINE DEDENT DEDENT else : NEW_LINE
TOWUtil ( arr , n , curr_elements , no_of_selected_elements , soln , min_diff , Sum , curr_sum , curr_position + 1 ) NEW_LINE
curr_elements [ curr_position ] = False NEW_LINE
def tugOfWar ( arr , n ) : NEW_LINE
curr_elements = [ None ] * n NEW_LINE
soln = [ None ] * n NEW_LINE min_diff = [ 999999999999 ] NEW_LINE Sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT Sum += arr [ i ] NEW_LINE curr_elements [ i ] = soln [ i ] = False NEW_LINE DEDENT
TOWUtil ( arr , n , curr_elements , 0 , soln , min_diff , Sum , 0 , 0 ) NEW_LINE
print ( " The ▁ first ▁ subset ▁ is : ▁ " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( soln [ i ] == True ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT print ( ) NEW_LINE print ( " The ▁ second ▁ subset ▁ is : ▁ " ) NEW_LINE for i in range ( n ) : NEW_LINE INDENT if ( soln [ i ] == False ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 23 , 45 , - 34 , 12 , 0 , 98 , - 99 , 4 , 189 , - 1 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE tugOfWar ( arr , n ) NEW_LINE DEDENT
INF = 2147483647 NEW_LINE N = 4 NEW_LINE
def minCost ( cost ) : NEW_LINE
dist = [ 0 for i in range ( N ) ] NEW_LINE for i in range ( N ) : NEW_LINE INDENT dist [ i ] = INF NEW_LINE DEDENT dist [ 0 ] = 0 NEW_LINE
for i in range ( N ) : NEW_LINE INDENT for j in range ( i + 1 , N ) : NEW_LINE INDENT if ( dist [ j ] > dist [ i ] + cost [ i ] [ j ] ) : NEW_LINE INDENT dist [ j ] = dist [ i ] + cost [ i ] [ j ] NEW_LINE DEDENT DEDENT DEDENT return dist [ N - 1 ] NEW_LINE
cost = [ [ 0 , 15 , 80 , 90 ] , [ INF , 0 , 40 , 50 ] , [ INF , INF , 0 , 70 ] , [ INF , INF , INF , 0 ] ] NEW_LINE print ( " The ▁ Minimum ▁ cost ▁ to ▁ reach ▁ station ▁ " , N , " ▁ is ▁ " , minCost ( cost ) ) NEW_LINE
def numOfways ( n , k ) : NEW_LINE INDENT p = 1 NEW_LINE if ( k % 2 ) : NEW_LINE INDENT p = - 1 NEW_LINE DEDENT return ( pow ( n - 1 , k ) + p * ( n - 1 ) ) / n NEW_LINE DEDENT
n = 4 NEW_LINE k = 2 NEW_LINE print ( numOfways ( n , k ) ) NEW_LINE
def power ( n ) : NEW_LINE INDENT if n == 1 : NEW_LINE INDENT return 2 NEW_LINE DEDENT return 2 * power ( n - 1 ) NEW_LINE DEDENT
n = 4 NEW_LINE print ( power ( n ) ) NEW_LINE
size = 4 NEW_LINE
def checkStar ( mat ) : NEW_LINE INDENT global size NEW_LINE DEDENT
vertexD1 = 0 NEW_LINE vertexDn_1 = 0 NEW_LINE
if ( size == 1 ) : NEW_LINE INDENT return ( mat [ 0 ] [ 0 ] == 0 ) NEW_LINE DEDENT
if ( size == 2 ) : NEW_LINE INDENT return ( mat [ 0 ] [ 0 ] == 0 and mat [ 0 ] [ 1 ] == 1 and mat [ 1 ] [ 0 ] == 1 and mat [ 1 ] [ 1 ] == 0 ) NEW_LINE DEDENT
for i in range ( 0 , size ) : NEW_LINE INDENT degreeI = 0 NEW_LINE for j in range ( 0 , size ) : NEW_LINE INDENT if ( mat [ i ] [ j ] ) : NEW_LINE INDENT degreeI = degreeI + 1 NEW_LINE DEDENT DEDENT if ( degreeI == 1 ) : NEW_LINE INDENT vertexD1 = vertexD1 + 1 NEW_LINE DEDENT elif ( degreeI == size - 1 ) : NEW_LINE INDENT vertexDn_1 = vertexDn_1 + 1 NEW_LINE DEDENT DEDENT return ( vertexD1 == ( size - 1 ) and vertexDn_1 == 1 ) NEW_LINE
mat = [ [ 0 , 1 , 1 , 1 ] , [ 1 , 0 , 0 , 0 ] , [ 1 , 0 , 0 , 0 ] , [ 1 , 0 , 0 , 0 ] ] NEW_LINE if ( checkStar ( mat ) ) : NEW_LINE INDENT print ( " Star ▁ Graph " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Not ▁ a ▁ Star ▁ Graph " ) NEW_LINE DEDENT
def fib ( n ) : NEW_LINE INDENT if n <= 1 : NEW_LINE INDENT return n NEW_LINE DEDENT return fib ( n - 1 ) + fib ( n - 2 ) NEW_LINE DEDENT
def findVertices ( n ) : NEW_LINE
return fib ( n + 2 ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 3 NEW_LINE print ( findVertices ( n ) ) NEW_LINE DEDENT
def check ( degree , n ) : NEW_LINE
deg_sum = sum ( degree ) NEW_LINE
if ( 2 * ( n - 1 ) == deg_sum ) : NEW_LINE INDENT return True NEW_LINE DEDENT else : NEW_LINE INDENT return False NEW_LINE DEDENT
n = 5 NEW_LINE degree = [ 2 , 3 , 1 , 1 , 1 ] ; NEW_LINE if ( check ( degree , n ) ) : NEW_LINE INDENT print " Tree " NEW_LINE DEDENT else : NEW_LINE INDENT print " Graph " NEW_LINE DEDENT
def isInorder ( arr , n ) : NEW_LINE
if ( n == 0 or n == 1 ) : NEW_LINE INDENT return True NEW_LINE DEDENT for i in range ( 1 , n , 1 ) : NEW_LINE
if ( arr [ i - 1 ] > arr [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT
return True NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 19 , 23 , 25 , 30 , 45 ] NEW_LINE n = len ( arr ) NEW_LINE if ( isInorder ( arr , n ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT DEDENT
def isLeaf ( pre , i , n , Min , Max ) : NEW_LINE INDENT if i [ 0 ] >= n : NEW_LINE INDENT return False NEW_LINE DEDENT if pre [ i [ 0 ] ] > Min and pre [ i [ 0 ] ] < Max : NEW_LINE INDENT i [ 0 ] += 1 NEW_LINE left = isLeaf ( pre , i , n , Min , pre [ i [ 0 ] - 1 ] ) NEW_LINE right = isLeaf ( pre , i , n , pre [ i [ 0 ] - 1 ] , Max ) NEW_LINE if left == False and right == False : NEW_LINE INDENT print ( pre [ i [ 0 ] - 1 ] , end = " ▁ " ) NEW_LINE DEDENT return True NEW_LINE DEDENT return False NEW_LINE DEDENT def printLeaves ( preorder , n ) : NEW_LINE INDENT i = [ 0 ] NEW_LINE INT_MIN , INT_MAX = - 999999999999 , 999999999999 NEW_LINE isLeaf ( preorder , i , n , INT_MIN , INT_MAX ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT preorder = [ 890 , 325 , 290 , 530 , 965 ] NEW_LINE n = len ( preorder ) NEW_LINE printLeaves ( preorder , n ) NEW_LINE DEDENT
def pairs ( arr , n , k ) : NEW_LINE
smallest = 999999999999 NEW_LINE count = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT
if abs ( arr [ i ] + arr [ j ] - k ) < smallest : NEW_LINE INDENT smallest = abs ( arr [ i ] + arr [ j ] - k ) NEW_LINE count = 1 NEW_LINE DEDENT
elif abs ( arr [ i ] + arr [ j ] - k ) == smallest : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
print ( " Minimal ▁ Value ▁ = ▁ " , smallest ) NEW_LINE print ( " Total ▁ Pairs ▁ = ▁ " , count ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 3 , 5 , 7 , 5 , 1 , 9 , 9 ] NEW_LINE k = 12 NEW_LINE n = len ( arr ) NEW_LINE pairs ( arr , n , k ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT a = [ 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 ] NEW_LINE key = 20 NEW_LINE arraySize = len ( a ) NEW_LINE count = 0 NEW_LINE for i in range ( arraySize ) : NEW_LINE INDENT if a [ i ] <= key : NEW_LINE INDENT count += 1 NEW_LINE DEDENT DEDENT print ( " Rank ▁ of " , key , " in ▁ stream ▁ is : " , count - 1 ) NEW_LINE DEDENT
MAX_SIZE = 10 NEW_LINE
def sortByRow ( mat , n , ascending ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT if ( ascending ) : NEW_LINE INDENT mat [ i ] . sort ( ) NEW_LINE DEDENT else : NEW_LINE INDENT mat [ i ] . sort ( reverse = True ) NEW_LINE DEDENT DEDENT DEDENT
def transpose ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT DEDENT
temp = mat [ i ] [ j ] NEW_LINE mat [ i ] [ j ] = mat [ j ] [ i ] NEW_LINE mat [ j ] [ i ] = temp NEW_LINE
def sortMatRowAndColWise ( mat , n ) : NEW_LINE
sortByRow ( mat , n , True ) NEW_LINE
transpose ( mat , n ) NEW_LINE
sortByRow ( mat , n , False ) NEW_LINE
transpose ( mat , n ) NEW_LINE
def printMat ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , " ▁ " , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
n = 3 NEW_LINE mat = [ [ 3 , 2 , 1 ] , [ 9 , 8 , 7 ] , [ 6 , 5 , 4 ] ] NEW_LINE print ( " Original ▁ Matrix : " ) NEW_LINE printMat ( mat , n ) NEW_LINE sortMatRowAndColWise ( mat , n ) NEW_LINE print ( " Matrix ▁ After ▁ Sorting : " ) NEW_LINE printMat ( mat , n ) NEW_LINE
def middlesum ( mat , n ) : NEW_LINE INDENT row_sum = 0 NEW_LINE col_sum = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT row_sum += mat [ n // 2 ] [ i ] NEW_LINE DEDENT print ( " Sum ▁ of ▁ middle ▁ row ▁ = ▁ " , row_sum ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT col_sum += mat [ i ] [ n // 2 ] NEW_LINE DEDENT print ( " Sum ▁ of ▁ middle ▁ column ▁ = ▁ " , col_sum ) NEW_LINE
mat = [ [ 2 , 5 , 7 ] , [ 3 , 7 , 2 ] , [ 5 , 6 , 9 ] ] NEW_LINE middlesum ( mat , 3 ) NEW_LINE
M = 3 NEW_LINE N = 3 NEW_LINE matrix = [ [ 12 , 23 , 34 ] , [ 45 , 56 , 67 ] , [ 78 , 89 , 91 ] ] NEW_LINE
def rotateMatrix ( k ) : NEW_LINE INDENT global M , N , matrix NEW_LINE DEDENT
temp = [ 0 ] * M NEW_LINE
k = k % M NEW_LINE for i in range ( 0 , N ) : NEW_LINE
for t in range ( 0 , M - k ) : NEW_LINE INDENT temp [ t ] = matrix [ i ] [ t ] NEW_LINE DEDENT
for j in range ( M - k , M ) : NEW_LINE INDENT matrix [ i ] [ j - M + k ] = matrix [ i ] [ j ] NEW_LINE DEDENT
for j in range ( k , M ) : NEW_LINE INDENT matrix [ i ] [ j ] = temp [ j - k ] NEW_LINE DEDENT
def displayMatrix ( ) : NEW_LINE INDENT global M , N , matrix NEW_LINE for i in range ( 0 , N ) : NEW_LINE INDENT for j in range ( 0 , M ) : NEW_LINE INDENT print ( " { } ▁ " . format ( matrix [ i ] [ j ] ) , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
k = 2 NEW_LINE
rotateMatrix ( k ) NEW_LINE
displayMatrix ( ) NEW_LINE
N = 3 ; NEW_LINE
def multiply ( mat , res ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT res [ i ] [ j ] = 0 ; NEW_LINE for k in range ( N ) : NEW_LINE INDENT res [ i ] [ j ] += mat [ i ] [ k ] * mat [ k ] [ j ] ; NEW_LINE DEDENT DEDENT DEDENT return res ; NEW_LINE DEDENT
def InvolutoryMatrix ( mat ) : NEW_LINE INDENT res = [ [ 0 for i in range ( N ) ] for j in range ( N ) ] ; NEW_LINE DEDENT
res = multiply ( mat , res ) ; NEW_LINE for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT if ( i == j and res [ i ] [ j ] != 1 ) : NEW_LINE INDENT return False ; NEW_LINE DEDENT if ( i != j and res [ i ] [ j ] != 0 ) : NEW_LINE INDENT return False ; NEW_LINE DEDENT DEDENT DEDENT return True ; NEW_LINE
mat = [ [ 1 , 0 , 0 ] , [ 0 , - 1 , 0 ] , [ 0 , 0 , - 1 ] ] ; NEW_LINE
if ( InvolutoryMatrix ( mat ) ) : NEW_LINE INDENT print ( " Involutory ▁ Matrix " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Not ▁ Involutory ▁ Matrix " ) ; NEW_LINE DEDENT
def interchangeFirstLast ( mat , n , m ) : NEW_LINE INDENT rows = n NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT t = mat [ 0 ] [ i ] NEW_LINE mat [ 0 ] [ i ] = mat [ rows - 1 ] [ i ] NEW_LINE mat [ rows - 1 ] [ i ] = t NEW_LINE DEDENT
mat = [ [ 8 , 9 , 7 , 6 ] , [ 4 , 7 , 6 , 5 ] , [ 3 , 2 , 1 , 8 ] , [ 9 , 9 , 7 , 7 ] ] NEW_LINE n = 4 NEW_LINE m = 4 NEW_LINE interchangeFirstLast ( mat , n , m ) NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( " " ) NEW_LINE DEDENT
def checkMarkov ( m ) : NEW_LINE
for i in range ( 0 , len ( m ) ) : NEW_LINE
sm = 0 NEW_LINE for j in range ( 0 , len ( m [ i ] ) ) : NEW_LINE INDENT sm = sm + m [ i ] [ j ] NEW_LINE DEDENT if ( sm != 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
m = [ [ 0 , 0 , 1 ] , [ 0.5 , 0 , 0.5 ] , [ 1 , 0 , 0 ] ] NEW_LINE
if ( checkMarkov ( m ) ) : NEW_LINE INDENT print ( " ▁ yes ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " ▁ no ▁ " ) NEW_LINE DEDENT
N = 4 NEW_LINE
def isDiagonalMatrix ( mat ) : NEW_LINE INDENT for i in range ( 0 , N ) : NEW_LINE INDENT for j in range ( 0 , N ) : NEW_LINE DEDENT DEDENT
if ( ( i != j ) and ( mat [ i ] [ j ] != 0 ) ) : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
mat = [ [ 4 , 0 , 0 , 0 ] , [ 0 , 7 , 0 , 0 ] , [ 0 , 0 , 5 , 0 ] , [ 0 , 0 , 0 , 1 ] ] NEW_LINE if ( isDiagonalMatrix ( mat ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
N = 4 NEW_LINE
def isScalarMatrix ( mat ) : NEW_LINE
for i in range ( 0 , N ) : NEW_LINE INDENT for j in range ( 0 , N ) : NEW_LINE INDENT if ( ( i != j ) and ( mat [ i ] [ j ] != 0 ) ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT
for i in range ( 0 , N - 1 ) : NEW_LINE INDENT if ( mat [ i ] [ i ] != mat [ i + 1 ] [ i + 1 ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE
mat = [ [ 2 , 0 , 0 , 0 ] , [ 0 , 2 , 0 , 0 ] , [ 0 , 0 , 2 , 0 ] , [ 0 , 0 , 0 , 2 ] ] NEW_LINE
if ( isScalarMatrix ( mat ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
MAX_SIZE = 10 NEW_LINE
def sortByRow ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE DEDENT
for j in range ( n - 1 ) : NEW_LINE INDENT if mat [ i ] [ j ] > mat [ i ] [ j + 1 ] : NEW_LINE INDENT temp = mat [ i ] [ j ] NEW_LINE mat [ i ] [ j ] = mat [ i ] [ j + 1 ] NEW_LINE mat [ i ] [ j + 1 ] = temp NEW_LINE DEDENT DEDENT
def transpose ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE DEDENT DEDENT
t = mat [ i ] [ j ] NEW_LINE mat [ i ] [ j ] = mat [ j ] [ i ] NEW_LINE mat [ j ] [ i ] = t NEW_LINE
def sortMatRowAndColWise ( mat , n ) : NEW_LINE
sortByRow ( mat , n ) NEW_LINE
transpose ( mat , n ) NEW_LINE
sortByRow ( mat , n ) NEW_LINE
transpose ( mat , n ) NEW_LINE
def printMat ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( str ( mat [ i ] [ j ] ) , end = " ▁ " ) NEW_LINE DEDENT print ( ) ; NEW_LINE DEDENT DEDENT
mat = [ [ 4 , 1 , 3 ] , [ 9 , 6 , 8 ] , [ 5 , 2 , 7 ] ] NEW_LINE n = 3 NEW_LINE print ( " Original ▁ Matrix : " ) NEW_LINE printMat ( mat , n ) NEW_LINE sortMatRowAndColWise ( mat , n ) NEW_LINE print ( " Matrix After Sorting : " ) NEW_LINE printMat ( mat , n ) NEW_LINE
def DoublyEven ( n ) : NEW_LINE
arr = [ [ ( n * y ) + x + 1 for x in range ( n ) ] for y in range ( n ) ] NEW_LINE
for i in range ( 0 , n / 4 ) : NEW_LINE INDENT for j in range ( 0 , n / 4 ) : NEW_LINE INDENT arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( 0 , n / 4 ) : NEW_LINE INDENT for j in range ( 3 * ( n / 4 ) , n ) : NEW_LINE INDENT arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( 3 * ( n / 4 ) , n ) : NEW_LINE INDENT for j in range ( 0 , n / 4 ) : NEW_LINE INDENT arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( 3 * ( n / 4 ) , n ) : NEW_LINE INDENT for j in range ( 3 * ( n / 4 ) , n ) : NEW_LINE INDENT arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( n / 4 , 3 * ( n / 4 ) ) : NEW_LINE INDENT for j in range ( n / 4 , 3 * ( n / 4 ) ) : NEW_LINE INDENT arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ' % 2d ▁ ' % ( arr [ i ] [ j ] ) , NEW_LINE DEDENT print NEW_LINE DEDENT
n = 8 NEW_LINE
DoublyEven ( n ) NEW_LINE
def isMagicSquare ( mat ) : NEW_LINE
s = 0 NEW_LINE for i in range ( 0 , N ) : NEW_LINE INDENT s = s + mat [ i ] [ i ] NEW_LINE DEDENT
s2 = 0 NEW_LINE for i in range ( 0 , N ) : NEW_LINE INDENT s2 = s2 + mat [ i ] [ N - i - 1 ] NEW_LINE DEDENT if ( s != s2 ) : NEW_LINE INDENT return False NEW_LINE DEDENT
for i in range ( 0 , N ) : NEW_LINE INDENT rowSum = 0 ; NEW_LINE for j in range ( 0 , N ) : NEW_LINE INDENT rowSum += mat [ i ] [ j ] NEW_LINE DEDENT DEDENT
if ( rowSum != s ) : NEW_LINE INDENT return False NEW_LINE DEDENT
for i in range ( 0 , N ) : NEW_LINE INDENT colSum = 0 NEW_LINE for j in range ( 0 , N ) : NEW_LINE INDENT colSum += mat [ j ] [ i ] NEW_LINE DEDENT DEDENT
if ( s != colSum ) : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE
mat = [ [ 2 , 7 , 6 ] , [ 9 , 5 , 1 ] , [ 4 , 3 , 8 ] ] NEW_LINE if ( isMagicSquare ( mat ) ) : NEW_LINE INDENT print ( " Magic ▁ Square " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Not ▁ a ▁ magic ▁ Square " ) NEW_LINE DEDENT
def subCount ( arr , n , k ) : NEW_LINE
mod = [ 0 ] * k ; NEW_LINE
cumSum = 0 ; NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT cumSum = cumSum + arr [ i ] ; NEW_LINE DEDENT
mod [ ( ( cumSum % k ) + k ) % k ] = mod [ ( ( cumSum % k ) + k ) % k ] + 1 ; NEW_LINE
result = 0 ; NEW_LINE
for i in range ( 0 , k ) : NEW_LINE
if ( mod [ i ] > 1 ) : NEW_LINE INDENT result = result + int ( ( mod [ i ] * ( mod [ i ] - 1 ) ) / 2 ) ; NEW_LINE DEDENT
result = result + mod [ 0 ] ; NEW_LINE return result ; NEW_LINE
def countSubmatrix ( mat , n , k ) : NEW_LINE
tot_count = 0 ; NEW_LINE temp = [ 0 ] * n ; NEW_LINE
for left in range ( 0 , n - 1 ) : NEW_LINE
for right in range ( left , n ) : NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT temp [ i ] = ( temp [ i ] + mat [ i ] [ right ] ) ; NEW_LINE DEDENT
tot_count = ( tot_count + subCount ( temp , n , k ) ) ; NEW_LINE
return tot_count ; NEW_LINE
mat = [ [ 5 , - 1 , 6 ] , [ - 2 , 3 , 8 ] , [ 7 , 4 , - 9 ] ] ; NEW_LINE n = 3 ; NEW_LINE k = 4 ; NEW_LINE print ( " Count ▁ = ▁ { } " . format ( countSubmatrix ( mat , n , k ) ) ) ; NEW_LINE
import math NEW_LINE def find ( n , k ) : NEW_LINE INDENT if ( n + 1 >= k ) : NEW_LINE INDENT return ( k - 1 ) NEW_LINE DEDENT else : NEW_LINE INDENT return ( 2 * n + 1 - k ) NEW_LINE DEDENT DEDENT
n = 4 NEW_LINE k = 7 NEW_LINE freq = find ( n , k ) NEW_LINE if ( freq < 0 ) : NEW_LINE INDENT print ( " ▁ element ▁ not ▁ exist " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " ▁ Frequency ▁ of ▁ " , k , " ▁ is ▁ " , freq ) NEW_LINE DEDENT
def ZigZag ( rows , columns , numbers ) : NEW_LINE INDENT k = 0 NEW_LINE DEDENT
arr = [ [ 0 for i in range ( columns ) ] for j in range ( rows ) ] NEW_LINE for i in range ( rows ) : NEW_LINE
if ( i % 2 == 0 ) : NEW_LINE
j = 0 NEW_LINE while j < columns and numbers [ k ] > 0 : NEW_LINE
arr [ i ] [ j ] = k + 1 NEW_LINE
numbers [ k ] -= 1 NEW_LINE
if numbers [ k ] == 0 : NEW_LINE INDENT k += 1 NEW_LINE DEDENT j += 1 NEW_LINE
else : NEW_LINE
j = columns - 1 NEW_LINE while j >= 0 and numbers [ k ] > 0 : NEW_LINE
arr [ i ] [ j ] = k + 1 NEW_LINE
numbers [ k ] -= 1 NEW_LINE
if numbers [ k ] == 0 : NEW_LINE INDENT k += 1 NEW_LINE DEDENT j -= 1 NEW_LINE
for i in arr : NEW_LINE INDENT for j in i : NEW_LINE INDENT print ( j , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
rows = 4 ; NEW_LINE columns = 5 ; NEW_LINE Numbers = [ 3 , 4 , 2 , 2 , 3 , 1 , 5 ] NEW_LINE ZigZag ( rows , columns , Numbers ) NEW_LINE
n = 5 NEW_LINE
def FindMaxProduct ( arr , n ) : NEW_LINE INDENT max = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE
for j in range ( n ) : NEW_LINE
if ( ( j - 3 ) >= 0 ) : NEW_LINE INDENT result = ( arr [ i ] [ j ] * arr [ i ] [ j - 1 ] * arr [ i ] [ j - 2 ] * arr [ i ] [ j - 3 ] ) NEW_LINE if ( max < result ) : NEW_LINE INDENT max = result NEW_LINE DEDENT DEDENT
if ( ( i - 3 ) >= 0 ) : NEW_LINE INDENT result = ( arr [ i ] [ j ] * arr [ i - 1 ] [ j ] * arr [ i - 2 ] [ j ] * arr [ i - 3 ] [ j ] ) NEW_LINE if ( max < result ) : NEW_LINE INDENT max = result NEW_LINE DEDENT DEDENT
if ( ( i - 3 ) >= 0 and ( j - 3 ) >= 0 ) : NEW_LINE INDENT result = ( arr [ i ] [ j ] * arr [ i - 1 ] [ j - 1 ] * arr [ i - 2 ] [ j - 2 ] * arr [ i - 3 ] [ j - 3 ] ) NEW_LINE if ( max < result ) : NEW_LINE INDENT max = result NEW_LINE DEDENT DEDENT
if ( ( i - 3 ) >= 0 and ( j - 1 ) <= 0 ) : NEW_LINE INDENT result = ( arr [ i ] [ j ] * arr [ i - 1 ] [ j + 1 ] * arr [ i - 2 ] [ j + 2 ] * arr [ i - 3 ] [ j + 3 ] ) NEW_LINE if ( max < result ) : NEW_LINE INDENT max = result NEW_LINE DEDENT DEDENT return max NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT arr = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 6 , 7 , 8 , 9 , 1 ] , [ 2 , 3 , 4 , 5 , 6 ] , [ 7 , 8 , 9 , 1 , 0 ] , [ 9 , 6 , 4 , 2 , 3 ] ] NEW_LINE print ( FindMaxProduct ( arr , n ) ) NEW_LINE DEDENT
N = 3 NEW_LINE
def minimumflip ( mat , n ) : NEW_LINE INDENT transpose = [ [ 0 ] * n ] * n NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT transpose [ i ] [ j ] = mat [ j ] [ i ] NEW_LINE DEDENT DEDENT
flip = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT if transpose [ i ] [ j ] != mat [ i ] [ j ] : NEW_LINE INDENT flip += 1 NEW_LINE DEDENT DEDENT DEDENT return int ( flip / 2 ) NEW_LINE
n = 3 NEW_LINE mat = [ [ 0 , 0 , 1 ] , [ 1 , 1 , 1 ] , [ 1 , 0 , 0 ] ] NEW_LINE print ( minimumflip ( mat , n ) ) NEW_LINE
N = 3 NEW_LINE
def minimumflip ( mat , n ) : NEW_LINE
flip = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( i ) : NEW_LINE INDENT if mat [ i ] [ j ] != mat [ j ] [ i ] : NEW_LINE INDENT flip += 1 NEW_LINE DEDENT DEDENT DEDENT return flip NEW_LINE
n = 3 NEW_LINE mat = [ [ 0 , 0 , 1 ] , [ 1 , 1 , 1 ] , [ 1 , 0 , 0 ] ] NEW_LINE print ( minimumflip ( mat , n ) ) NEW_LINE
def islowertriangular ( M ) : NEW_LINE INDENT for i in range ( 0 , len ( M ) ) : NEW_LINE INDENT for j in range ( i + 1 , len ( M ) ) : NEW_LINE INDENT if ( M [ i ] [ j ] != 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT return True NEW_LINE DEDENT
M = [ [ 1 , 0 , 0 , 0 ] , [ 1 , 4 , 0 , 0 ] , [ 4 , 6 , 2 , 0 ] , [ 0 , 4 , 7 , 6 ] ] NEW_LINE
if islowertriangular ( M ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
def isuppertriangular ( M ) : NEW_LINE INDENT for i in range ( 1 , len ( M ) ) : NEW_LINE INDENT for j in range ( 0 , i ) : NEW_LINE INDENT if ( M [ i ] [ j ] != 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT return True NEW_LINE DEDENT
M = [ [ 1 , 3 , 5 , 3 ] , [ 0 , 4 , 6 , 2 ] , [ 0 , 0 , 2 , 5 ] , [ 0 , 0 , 0 , 6 ] ] NEW_LINE if isuppertriangular ( M ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
MAX = 100 NEW_LINE
def freq ( ar , m , n ) : NEW_LINE INDENT even = 0 NEW_LINE odd = 0 NEW_LINE for i in range ( m ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE DEDENT DEDENT
if ( ( ar [ i ] [ j ] % 2 ) == 0 ) : NEW_LINE INDENT even += 1 NEW_LINE DEDENT else : NEW_LINE INDENT odd += 1 NEW_LINE DEDENT
print ( " ▁ Frequency ▁ of ▁ odd ▁ number ▁ = " , odd ) NEW_LINE print ( " ▁ Frequency ▁ of ▁ even ▁ number ▁ = " , even ) NEW_LINE
m = 3 NEW_LINE n = 3 NEW_LINE array = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] NEW_LINE freq ( array , m , n ) NEW_LINE
MAX = 100 NEW_LINE
def HalfDiagonalSums ( mat , n ) : NEW_LINE
diag1_left = 0 NEW_LINE diag1_right = 0 NEW_LINE diag2_left = 0 NEW_LINE diag2_right = 0 NEW_LINE i = 0 NEW_LINE j = n - 1 NEW_LINE while i < n : NEW_LINE INDENT if ( i < n // 2 ) : NEW_LINE INDENT diag1_left += mat [ i ] [ i ] NEW_LINE diag2_left += mat [ j ] [ i ] NEW_LINE DEDENT elif ( i > n // 2 ) : NEW_LINE INDENT diag1_right += mat [ i ] [ i ] NEW_LINE diag2_right += mat [ j ] [ i ] NEW_LINE DEDENT i += 1 NEW_LINE j -= 1 NEW_LINE DEDENT return ( diag1_left == diag2_right and diag2_right == diag2_left and diag1_right == diag2_left and diag2_right == mat [ n // 2 ] [ n // 2 ] ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT a = [ [ 2 , 9 , 1 , 4 , - 2 ] , [ 6 , 7 , 2 , 11 , 4 ] , [ 4 , 2 , 9 , 2 , 4 ] , [ 1 , 9 , 2 , 4 , 4 ] , [ 0 , 2 , 4 , 2 , 5 ] ] NEW_LINE print ( " Yes " ) if ( HalfDiagonalSums ( a , 5 ) ) else print ( " No " ) NEW_LINE DEDENT
MAX = 100 ; NEW_LINE def isIdentity ( mat , N ) : NEW_LINE INDENT for row in range ( N ) : NEW_LINE INDENT for col in range ( N ) : NEW_LINE INDENT if ( row == col and mat [ row ] [ col ] != 1 ) : NEW_LINE INDENT return False ; NEW_LINE DEDENT elif ( row != col and mat [ row ] [ col ] != 0 ) : NEW_LINE INDENT return False ; NEW_LINE DEDENT DEDENT DEDENT return True ; NEW_LINE DEDENT
N = 4 ; NEW_LINE mat = [ [ 1 , 0 , 0 , 0 ] , [ 0 , 1 , 0 , 0 ] , [ 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 1 ] ] ; NEW_LINE if ( isIdentity ( mat , N ) ) : NEW_LINE INDENT print ( " Yes ▁ " ) ; NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No ▁ " ) ; NEW_LINE DEDENT
def modPower ( a , t ) : NEW_LINE INDENT now = a ; NEW_LINE ret = 1 ; NEW_LINE mod = 100000007 ; NEW_LINE DEDENT
while ( t ) : NEW_LINE INDENT if ( t & 1 ) : NEW_LINE INDENT ret = now * ( ret % mod ) ; NEW_LINE DEDENT now = now * ( now % mod ) ; NEW_LINE t >>= 1 ; NEW_LINE DEDENT return ret ; NEW_LINE
def countWays ( n , m , k ) : NEW_LINE INDENT mod = 100000007 ; NEW_LINE DEDENT
if ( k == - 1 and ( ( n + m ) % 2 == 1 ) ) : NEW_LINE INDENT return 0 ; NEW_LINE DEDENT
if ( n == 1 or m == 1 ) : NEW_LINE INDENT return 1 ; NEW_LINE DEDENT
return ( modPower ( modPower ( 2 , n - 1 ) , m - 1 ) % mod ) ; NEW_LINE
n = 2 ; NEW_LINE m = 7 ; NEW_LINE k = 1 ; NEW_LINE print ( countWays ( n , m , k ) ) ; NEW_LINE
from builtins import range NEW_LINE MAX = 100 ; NEW_LINE def imageSwap ( mat , n ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 ) : NEW_LINE INDENT t = mat [ i ] [ j ] ; NEW_LINE mat [ i ] [ j ] = mat [ j ] [ i ] NEW_LINE mat [ j ] [ i ] = t NEW_LINE DEDENT DEDENT
def printMatrix ( mat , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " ▁ " ) ; NEW_LINE DEDENT print ( ) ; NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT mat = [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 ] ; NEW_LINE n = 4 ; NEW_LINE imageSwap ( mat , n ) ; NEW_LINE printMatrix ( mat , n ) ; NEW_LINE DEDENT
m = 3 NEW_LINE
n = 2 NEW_LINE
def countSets ( a ) : NEW_LINE
res = 0 NEW_LINE
for i in range ( n ) : NEW_LINE INDENT u = 0 NEW_LINE v = 0 NEW_LINE for j in range ( m ) : NEW_LINE INDENT if a [ i ] [ j ] : NEW_LINE INDENT u += 1 NEW_LINE DEDENT else : NEW_LINE INDENT v += 1 NEW_LINE DEDENT DEDENT res += pow ( 2 , u ) - 1 + pow ( 2 , v ) - 1 NEW_LINE DEDENT
for i in range ( m ) : NEW_LINE INDENT u = 0 NEW_LINE v = 0 NEW_LINE for j in range ( n ) : NEW_LINE INDENT if a [ j ] [ i ] : NEW_LINE INDENT u += 1 NEW_LINE DEDENT else : NEW_LINE INDENT v += 1 NEW_LINE DEDENT DEDENT res += pow ( 2 , u ) - 1 + pow ( 2 , v ) - 1 NEW_LINE DEDENT
return res - ( n * m ) NEW_LINE
a = [ [ 1 , 0 , 1 ] , [ 0 , 1 , 0 ] ] NEW_LINE print ( countSets ( a ) ) NEW_LINE
def fill0X ( m , n ) : NEW_LINE
i , k , l = 0 , 0 , 0 NEW_LINE
r = m NEW_LINE c = n NEW_LINE
x = ' X ' NEW_LINE
while k < m and l < n : NEW_LINE
for i in range ( l , n ) : NEW_LINE INDENT a [ k ] [ i ] = x NEW_LINE DEDENT k += 1 NEW_LINE
for i in range ( k , m ) : NEW_LINE INDENT a [ i ] [ n - 1 ] = x NEW_LINE DEDENT n -= 1 NEW_LINE
if k < m : NEW_LINE INDENT for i in range ( n - 1 , l - 1 , - 1 ) : NEW_LINE INDENT a [ m - 1 ] [ i ] = x NEW_LINE DEDENT m -= 1 NEW_LINE DEDENT
if l < n : NEW_LINE INDENT for i in range ( m - 1 , k - 1 , - 1 ) : NEW_LINE INDENT a [ i ] [ l ] = x NEW_LINE DEDENT l += 1 NEW_LINE DEDENT
x = ' X ' if x == '0' else '0' NEW_LINE
for i in range ( r ) : NEW_LINE INDENT for j in range ( c ) : NEW_LINE INDENT print ( a [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT print ( " Output ▁ for ▁ m ▁ = ▁ 5 , ▁ n ▁ = ▁ 6" ) NEW_LINE fill0X ( 5 , 6 ) NEW_LINE print ( " Output ▁ for ▁ m ▁ = ▁ 4 , ▁ n ▁ = ▁ 4" ) NEW_LINE fill0X ( 4 , 4 ) NEW_LINE print ( " Output ▁ for ▁ m ▁ = ▁ 3 , ▁ n ▁ = ▁ 4" ) NEW_LINE fill0X ( 3 , 4 ) NEW_LINE DEDENT
def calculateEnergy ( mat , n ) : NEW_LINE INDENT tot_energy = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE DEDENT
q = mat [ i ] [ j ] // n NEW_LINE
i_des = q NEW_LINE j_des = mat [ i ] [ j ] - ( n * q ) NEW_LINE
tot_energy += ( abs ( i_des - i ) + abs ( j_des - j ) ) NEW_LINE
return tot_energy NEW_LINE
mat = [ [ 4 , 7 , 0 , 3 ] , [ 8 , 5 , 6 , 1 ] , [ 9 , 11 , 10 , 2 ] , [ 15 , 13 , 14 , 12 ] ] NEW_LINE print ( " Total ▁ energy ▁ required ▁ = ▁ " , calculateEnergy ( mat , n ) , " units " ) NEW_LINE
MAX = 100 NEW_LINE
def isUnique ( mat , i , j , n , m ) : NEW_LINE
sumrow = 0 NEW_LINE for k in range ( m ) : NEW_LINE INDENT sumrow += mat [ i ] [ k ] NEW_LINE if ( sumrow > 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT
sumcol = 0 NEW_LINE for k in range ( n ) : NEW_LINE INDENT sumcol += mat [ k ] [ j ] NEW_LINE if ( sumcol > 1 ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT return True NEW_LINE def countUnique ( mat , n , m ) : NEW_LINE uniquecount = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT if ( mat [ i ] [ j ] and isUnique ( mat , i , j , n , m ) ) : NEW_LINE INDENT uniquecount += 1 NEW_LINE DEDENT DEDENT DEDENT return uniquecount NEW_LINE
mat = [ [ 0 , 1 , 0 , 0 ] , [ 0 , 0 , 1 , 0 ] , [ 1 , 0 , 0 , 1 ] ] NEW_LINE print ( countUnique ( mat , 3 , 4 ) ) NEW_LINE
MAX = 100 NEW_LINE def isSparse ( array , m , n ) : NEW_LINE INDENT counter = 0 NEW_LINE DEDENT
for i in range ( 0 , m ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE INDENT if ( array [ i ] [ j ] == 0 ) : NEW_LINE INDENT counter = counter + 1 NEW_LINE DEDENT DEDENT DEDENT return ( counter > ( ( m * n ) // 2 ) ) NEW_LINE
array = [ [ 1 , 0 , 3 ] , [ 0 , 0 , 4 ] , [ 6 , 0 , 0 ] ] NEW_LINE m = 3 NEW_LINE n = 3 NEW_LINE if ( isSparse ( array , m , n ) ) : NEW_LINE INDENT print ( " Yes " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " No " ) NEW_LINE DEDENT
Max = 100 NEW_LINE
def countCommon ( mat , n ) : NEW_LINE INDENT res = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT if mat [ i ] [ i ] == mat [ i ] [ n - i - 1 ] : NEW_LINE INDENT res = res + 1 NEW_LINE DEDENT DEDENT return res NEW_LINE DEDENT
mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] NEW_LINE print ( countCommon ( mat , 3 ) ) NEW_LINE
def areSumSame ( a , n , m ) : NEW_LINE INDENT sum1 = 0 NEW_LINE sum2 = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT sum1 = 0 NEW_LINE sum2 = 0 NEW_LINE for j in range ( 0 , m ) : NEW_LINE INDENT sum1 += a [ i ] [ j ] NEW_LINE sum2 += a [ j ] [ i ] NEW_LINE DEDENT if ( sum1 == sum2 ) : NEW_LINE INDENT return 1 NEW_LINE DEDENT DEDENT return 0 NEW_LINE DEDENT
n = 4 ; NEW_LINE
m = 4 ; NEW_LINE M = [ [ 1 , 2 , 3 , 4 ] , [ 9 , 5 , 3 , 1 ] , [ 0 , 3 , 5 , 6 ] , [ 0 , 4 , 5 , 6 ] ] NEW_LINE print ( areSumSame ( M , n , m ) ) NEW_LINE
N = 4 NEW_LINE
def findMax ( arr ) : NEW_LINE INDENT row = 0 NEW_LINE j = N - 1 NEW_LINE for i in range ( 0 , N ) : NEW_LINE DEDENT
while ( arr [ i ] [ j ] == 1 and j >= 0 ) : NEW_LINE INDENT row = i NEW_LINE j -= 1 NEW_LINE DEDENT print ( " Row ▁ number ▁ = ▁ " , row + 1 , " , ▁ MaxCount ▁ = ▁ " , N - 1 - j ) NEW_LINE
arr = [ [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 0 ] , [ 0 , 1 , 1 , 1 ] ] NEW_LINE findMax ( arr ) NEW_LINE
def transpose ( mat , tr , N ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT tr [ i ] [ j ] = mat [ j ] [ i ] NEW_LINE DEDENT DEDENT DEDENT
def isSymmetric ( mat , N ) : NEW_LINE INDENT tr = [ [ 0 for j in range ( len ( mat [ 0 ] ) ) ] for i in range ( len ( mat ) ) ] NEW_LINE transpose ( mat , tr , N ) NEW_LINE for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT if ( mat [ i ] [ j ] != tr [ i ] [ j ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT return True NEW_LINE DEDENT
mat = [ [ 1 , 3 , 5 ] , [ 3 , 2 , 4 ] , [ 5 , 4 , 1 ] ] NEW_LINE if ( isSymmetric ( mat , 3 ) ) : NEW_LINE INDENT print " Yes " NEW_LINE DEDENT else : NEW_LINE INDENT print " No " NEW_LINE DEDENT
def isSymmetric ( mat , N ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) : NEW_LINE INDENT return False NEW_LINE DEDENT DEDENT DEDENT return True NEW_LINE DEDENT
mat = [ [ 1 , 3 , 5 ] , [ 3 , 2 , 4 ] , [ 5 , 4 , 1 ] ] NEW_LINE if ( isSymmetric ( mat , 3 ) ) : NEW_LINE INDENT print " Yes " NEW_LINE DEDENT else : NEW_LINE INDENT print " No " NEW_LINE DEDENT
n = 4 ; NEW_LINE m = 4 ; NEW_LINE
def findPossibleMoves ( mat , p , q ) : NEW_LINE INDENT global n , m ; NEW_LINE DEDENT
X = [ 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 ] ; NEW_LINE Y = [ 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 ] ; NEW_LINE count = 0 ; NEW_LINE
for i in range ( 8 ) : NEW_LINE
x = p + X [ i ] ; NEW_LINE y = q + Y [ i ] ; NEW_LINE
if ( x >= 0 and y >= 0 and x < n and y < m and mat [ x ] [ y ] == 0 ) : NEW_LINE INDENT count += 1 ; NEW_LINE DEDENT
return count ; NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT mat = [ [ 1 , 0 , 1 , 0 ] , [ 0 , 1 , 1 , 1 ] , [ 1 , 1 , 0 , 1 ] , [ 0 , 1 , 1 , 1 ] ] ; NEW_LINE p , q = 2 , 2 ; NEW_LINE print ( findPossibleMoves ( mat , p , q ) ) ; NEW_LINE DEDENT
MAX = 100 NEW_LINE def printDiagonalSums ( mat , n ) : NEW_LINE INDENT principal = 0 NEW_LINE secondary = 0 ; NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT DEDENT
if ( i == j ) : NEW_LINE INDENT principal += mat [ i ] [ j ] NEW_LINE DEDENT
if ( ( i + j ) == ( n - 1 ) ) : NEW_LINE INDENT secondary += mat [ i ] [ j ] NEW_LINE DEDENT print ( " Principal ▁ Diagonal : " , principal ) NEW_LINE print ( " Secondary ▁ Diagonal : " , secondary ) NEW_LINE
a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] NEW_LINE printDiagonalSums ( a , 4 ) NEW_LINE
MAX = 100 NEW_LINE def printDiagonalSums ( mat , n ) : NEW_LINE INDENT principal = 0 NEW_LINE secondary = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT principal += mat [ i ] [ i ] NEW_LINE secondary += mat [ i ] [ n - i - 1 ] NEW_LINE DEDENT print ( " Principal ▁ Diagonal : " , principal ) NEW_LINE print ( " Secondary ▁ Diagonal : " , secondary ) NEW_LINE DEDENT
a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] NEW_LINE printDiagonalSums ( a , 4 ) NEW_LINE
MAX = 100 NEW_LINE def printBoundary ( a , m , n ) : NEW_LINE INDENT for i in range ( m ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT if ( i == 0 ) : NEW_LINE INDENT print a [ i ] [ j ] , NEW_LINE DEDENT elif ( i == m - 1 ) : NEW_LINE INDENT print a [ i ] [ j ] , NEW_LINE DEDENT elif ( j == 0 ) : NEW_LINE INDENT print a [ i ] [ j ] , NEW_LINE DEDENT elif ( j == n - 1 ) : NEW_LINE INDENT print a [ i ] [ j ] , NEW_LINE DEDENT else : NEW_LINE INDENT print " ▁ " , NEW_LINE DEDENT DEDENT print NEW_LINE DEDENT DEDENT
a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] NEW_LINE printBoundary ( a , 4 , 4 ) NEW_LINE
MAX = 100 NEW_LINE def printBoundary ( a , m , n ) : NEW_LINE INDENT sum = 0 NEW_LINE for i in range ( m ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT if ( i == 0 ) : NEW_LINE INDENT sum += a [ i ] [ j ] NEW_LINE DEDENT elif ( i == m - 1 ) : NEW_LINE INDENT sum += a [ i ] [ j ] NEW_LINE DEDENT elif ( j == 0 ) : NEW_LINE INDENT sum += a [ i ] [ j ] NEW_LINE DEDENT elif ( j == n - 1 ) : NEW_LINE INDENT sum += a [ i ] [ j ] NEW_LINE DEDENT DEDENT DEDENT return sum NEW_LINE DEDENT
a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] NEW_LINE sum = printBoundary ( a , 4 , 4 ) NEW_LINE print " Sum ▁ of ▁ boundary ▁ elements ▁ is " , sum NEW_LINE
MAX = 100 NEW_LINE def printSpiral ( mat , r , c ) : NEW_LINE INDENT a = 0 NEW_LINE b = 2 NEW_LINE low_row = 0 if ( 0 > a ) else a NEW_LINE low_column = 0 if ( 0 > b ) else b - 1 NEW_LINE high_row = r - 1 if ( ( a + 1 ) >= r ) else a + 1 NEW_LINE high_column = c - 1 if ( ( b + 1 ) >= c ) else b + 1 NEW_LINE while ( ( low_row > 0 - r and low_column > 0 - c ) ) : NEW_LINE INDENT i = low_column + 1 NEW_LINE while ( i <= high_column and i < c and low_row >= 0 ) : NEW_LINE INDENT print ( mat [ low_row ] [ i ] , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE DEDENT low_row -= 1 NEW_LINE i = low_row + 2 NEW_LINE while ( i <= high_row and i < r and high_column < c ) : NEW_LINE INDENT print ( mat [ i ] [ high_column ] , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE DEDENT high_column += 1 NEW_LINE i = high_column - 2 NEW_LINE while ( i >= low_column and i >= 0 and high_row < r ) : NEW_LINE INDENT print ( mat [ high_row ] [ i ] , end = " ▁ " ) NEW_LINE i -= 1 NEW_LINE DEDENT high_row += 1 NEW_LINE i = high_row - 2 NEW_LINE while ( i > low_row and i >= 0 and low_column >= 0 ) : NEW_LINE INDENT print ( mat [ i ] [ low_column ] , end = " ▁ " ) NEW_LINE i -= 1 NEW_LINE DEDENT low_column -= 1 NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] NEW_LINE r = 3 NEW_LINE c = 3 NEW_LINE DEDENT
printSpiral ( mat , r , c ) NEW_LINE
def difference ( arr , n ) : NEW_LINE
d1 = 0 NEW_LINE d2 = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT
if ( i == j ) : NEW_LINE INDENT d1 += arr [ i ] [ j ] NEW_LINE DEDENT
if ( i == n - j - 1 ) : NEW_LINE INDENT d2 += arr [ i ] [ j ] NEW_LINE DEDENT
return abs ( d1 - d2 ) ; NEW_LINE
n = 3 NEW_LINE arr = [ [ 11 , 2 , 4 ] , [ 4 , 5 , 6 ] , [ 10 , 8 , - 12 ] ] NEW_LINE print ( difference ( arr , n ) ) NEW_LINE
def difference ( arr , n ) : NEW_LINE
d1 = 0 NEW_LINE d2 = 0 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT d1 = d1 + arr [ i ] [ i ] NEW_LINE d2 = d2 + arr [ i ] [ n - i - 1 ] NEW_LINE DEDENT
return abs ( d1 - d2 ) NEW_LINE
n = 3 NEW_LINE arr = [ [ 11 , 2 , 4 ] , [ 4 , 5 , 6 ] , [ 10 , 8 , - 12 ] ] NEW_LINE print ( difference ( arr , n ) ) NEW_LINE
def spiralFill ( m , n , a ) : NEW_LINE
val = 1 NEW_LINE
k , l = 0 , 0 NEW_LINE while ( k < m and l < n ) : NEW_LINE
for i in range ( l , n ) : NEW_LINE INDENT a [ k ] [ i ] = val NEW_LINE val += 1 NEW_LINE DEDENT k += 1 NEW_LINE
for i in range ( k , m ) : NEW_LINE INDENT a [ i ] [ n - 1 ] = val NEW_LINE val += 1 NEW_LINE DEDENT n -= 1 NEW_LINE
if ( k < m ) : NEW_LINE INDENT for i in range ( n - 1 , l - 1 , - 1 ) : NEW_LINE INDENT a [ m - 1 ] [ i ] = val NEW_LINE val += 1 NEW_LINE DEDENT m -= 1 NEW_LINE DEDENT
if ( l < n ) : NEW_LINE INDENT for i in range ( m - 1 , k - 1 , - 1 ) : NEW_LINE INDENT a [ i ] [ l ] = val NEW_LINE val += 1 NEW_LINE DEDENT l += 1 NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT m , n = 4 , 4 NEW_LINE a = [ [ 0 for j in range ( m ) ] for i in range ( n ) ] NEW_LINE spiralFill ( m , n , a ) NEW_LINE for i in range ( m ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT print ( a [ i ] [ j ] , end = ' ▁ ' ) NEW_LINE DEDENT print ( ' ' ) NEW_LINE DEDENT DEDENT
MAX = 100 NEW_LINE
def MAXMIN ( arr , n ) : NEW_LINE INDENT MIN = 10 ** 9 NEW_LINE MAX = - 10 ** 9 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( n // 2 + 1 ) : NEW_LINE DEDENT
if ( arr [ i ] [ j ] > arr [ i ] [ n - j - 1 ] ) : NEW_LINE INDENT if ( MIN > arr [ i ] [ n - j - 1 ] ) : NEW_LINE INDENT MIN = arr [ i ] [ n - j - 1 ] NEW_LINE DEDENT if ( MAX < arr [ i ] [ j ] ) : NEW_LINE INDENT MAX = arr [ i ] [ j ] NEW_LINE DEDENT DEDENT else : NEW_LINE INDENT if ( MIN > arr [ i ] [ j ] ) : NEW_LINE INDENT MIN = arr [ i ] [ j ] NEW_LINE DEDENT if ( MAX < arr [ i ] [ n - j - 1 ] ) : NEW_LINE INDENT MAX = arr [ i ] [ n - j - 1 ] NEW_LINE DEDENT DEDENT print ( " MAXimum ▁ = " , MAX , " , ▁ MINimum ▁ = " , MIN ) NEW_LINE
arr = [ [ 5 , 9 , 11 ] , [ 25 , 0 , 14 ] , [ 21 , 6 , 4 ] ] NEW_LINE MAXMIN ( arr , 3 ) NEW_LINE
MAX = 100 ; NEW_LINE
def findNormal ( mat , n ) : NEW_LINE INDENT sum = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT sum += mat [ i ] [ j ] * mat [ i ] [ j ] ; NEW_LINE DEDENT DEDENT return math . floor ( math . sqrt ( sum ) ) ; NEW_LINE DEDENT
def findTrace ( mat , n ) : NEW_LINE INDENT sum = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum += mat [ i ] [ i ] ; NEW_LINE DEDENT return sum ; NEW_LINE DEDENT
mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] ; NEW_LINE print ( " Trace ▁ of ▁ Matrix ▁ = " , findTrace ( mat , 5 ) ) ; NEW_LINE print ( " Normal ▁ of ▁ Matrix ▁ = " , findNormal ( mat , 5 ) ) ; NEW_LINE
def minOperation ( arr ) : NEW_LINE INDENT ans = 0 NEW_LINE for i in range ( N - 1 , - 1 , - 1 ) : NEW_LINE INDENT for j in range ( M - 1 , - 1 , - 1 ) : NEW_LINE DEDENT DEDENT
if ( arr [ i ] [ j ] == 0 ) : NEW_LINE
ans += 1 NEW_LINE
for k in range ( i + 1 ) : NEW_LINE INDENT for h in range ( j + 1 ) : NEW_LINE DEDENT
if ( arr [ k ] [ h ] == 1 ) : NEW_LINE INDENT arr [ k ] [ h ] = 0 NEW_LINE DEDENT else : NEW_LINE INDENT arr [ k ] [ h ] = 1 NEW_LINE DEDENT return ans NEW_LINE
mat = [ [ 0 , 0 , 1 , 1 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] ] NEW_LINE M = 5 NEW_LINE N = 5 NEW_LINE print ( minOperation ( mat ) ) NEW_LINE
def findSum ( n ) : NEW_LINE INDENT ans = 0 ; temp = 0 ; NEW_LINE DEDENT
for i in range ( 1 , n + 1 ) : NEW_LINE INDENT if temp < n : NEW_LINE DEDENT
temp = i - 1 NEW_LINE
num = 1 NEW_LINE while temp < n : NEW_LINE INDENT if temp + i <= n : NEW_LINE INDENT ans += i * num NEW_LINE DEDENT else : NEW_LINE INDENT ans += ( n - temp ) * num NEW_LINE DEDENT temp += i NEW_LINE num += 1 NEW_LINE DEDENT return ans NEW_LINE
N = 2 NEW_LINE print ( findSum ( N ) ) NEW_LINE
def countOps ( A , B , m , n ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT A [ i ] [ j ] -= B [ i ] [ j ] ; NEW_LINE DEDENT DEDENT
for i in range ( 1 , n ) : NEW_LINE INDENT for j in range ( 1 , n ) : NEW_LINE INDENT if ( A [ i ] [ j ] - A [ i ] [ 0 ] - A [ 0 ] [ j ] + A [ 0 ] [ 0 ] != 0 ) : NEW_LINE INDENT return - 1 ; NEW_LINE DEDENT DEDENT DEDENT
result = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT result += abs ( A [ i ] [ 0 ] ) ; NEW_LINE DEDENT for j in range ( m ) : NEW_LINE INDENT result += abs ( A [ 0 ] [ j ] - A [ 0 ] [ 0 ] ) ; NEW_LINE DEDENT return ( result ) ; NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT A = [ [ 1 , 1 , 1 ] , [ 1 , 1 , 1 ] , [ 1 , 1 , 1 ] ] ; NEW_LINE B = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] ; NEW_LINE print ( countOps ( A , B , 3 , 3 ) ) ; NEW_LINE DEDENT
def printCoils ( n ) : NEW_LINE
m = 8 * n * n NEW_LINE
coil1 = [ 0 ] * m NEW_LINE
coil1 [ 0 ] = 8 * n * n + 2 * n NEW_LINE curr = coil1 [ 0 ] NEW_LINE nflg = 1 NEW_LINE step = 2 NEW_LINE
index = 1 NEW_LINE while ( index < m ) : NEW_LINE
for i in range ( step ) : NEW_LINE
curr = coil1 [ index ] = ( curr - 4 * n * nflg ) NEW_LINE index += 1 NEW_LINE if ( index >= m ) : NEW_LINE INDENT break NEW_LINE DEDENT if ( index >= m ) : NEW_LINE break NEW_LINE
for i in range ( step ) : NEW_LINE INDENT curr = coil1 [ index ] = curr + nflg NEW_LINE index += 1 NEW_LINE if ( index >= m ) : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT nflg = nflg * ( - 1 ) NEW_LINE step += 2 NEW_LINE
coil2 = [ 0 ] * m NEW_LINE i = 0 NEW_LINE while ( i < 8 * n * n ) : NEW_LINE INDENT coil2 [ i ] = 16 * n * n + 1 - coil1 [ i ] NEW_LINE i += 1 NEW_LINE DEDENT
print ( " Coil ▁ 1 ▁ : " , end = " ▁ " ) NEW_LINE i = 0 NEW_LINE while ( i < 8 * n * n ) : NEW_LINE INDENT print ( coil1 [ i ] , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE DEDENT print ( " Coil 2 : " , ▁ end ▁ = ▁ "   " ) NEW_LINE i = 0 NEW_LINE while ( i < 8 * n * n ) : NEW_LINE INDENT print ( coil2 [ i ] , end = " ▁ " ) NEW_LINE i += 1 NEW_LINE DEDENT
n = 1 NEW_LINE printCoils ( n ) NEW_LINE
def findSum ( n ) : NEW_LINE
arr = [ [ 0 for x in range ( n ) ] for y in range ( n ) ] NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT arr [ i ] [ j ] = abs ( i - j ) NEW_LINE DEDENT DEDENT
sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( n ) : NEW_LINE INDENT sum += arr [ i ] [ j ] NEW_LINE DEDENT DEDENT return sum NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 3 NEW_LINE print ( findSum ( n ) ) NEW_LINE DEDENT
def findSum ( n ) : NEW_LINE INDENT sum = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT sum += i * ( n - i ) NEW_LINE DEDENT return 2 * sum NEW_LINE DEDENT
n = 3 NEW_LINE print ( findSum ( n ) ) NEW_LINE
def findSum ( n ) : NEW_LINE INDENT n -= 1 NEW_LINE sum = 0 NEW_LINE sum += ( n * ( n + 1 ) ) / 2 NEW_LINE sum += ( n * ( n + 1 ) * ( 2 * n + 1 ) ) / 6 NEW_LINE return int ( sum ) NEW_LINE DEDENT
n = 3 NEW_LINE print ( findSum ( n ) ) NEW_LINE
MAX = 1000 NEW_LINE def checkHV ( arr , N , M ) : NEW_LINE
horizontal = True NEW_LINE vertical = True NEW_LINE
i = 0 NEW_LINE k = N - 1 NEW_LINE while ( i < N // 2 ) : NEW_LINE
for j in range ( M ) : NEW_LINE
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) : NEW_LINE INDENT horizontal = False NEW_LINE break NEW_LINE DEDENT i += 1 NEW_LINE k -= 1 NEW_LINE
i = 0 NEW_LINE k = M - 1 NEW_LINE while ( i < M // 2 ) : NEW_LINE
for j in range ( N ) : NEW_LINE
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) : NEW_LINE INDENT vertical = False NEW_LINE break NEW_LINE DEDENT i += 1 NEW_LINE k -= 1 NEW_LINE if ( not horizontal and not vertical ) : NEW_LINE print ( " NO " ) NEW_LINE elif ( horizontal and not vertical ) : NEW_LINE print ( " HORIZONTAL " ) NEW_LINE elif ( vertical and not horizontal ) : NEW_LINE print ( " VERTICAL " ) NEW_LINE else : NEW_LINE print ( " BOTH " ) NEW_LINE
mat = [ [ 1 , 0 , 1 ] , [ 0 , 0 , 0 ] , [ 1 , 0 , 1 ] ] NEW_LINE checkHV ( mat , 3 , 3 ) NEW_LINE
def maxDet ( n ) : NEW_LINE INDENT return 2 * n * n * n NEW_LINE DEDENT
def resMatrix ( n ) : NEW_LINE INDENT for i in range ( 3 ) : NEW_LINE INDENT for j in range ( 3 ) : NEW_LINE DEDENT DEDENT
if i == 0 and j == 2 : NEW_LINE INDENT print ( "0" , end = " ▁ " ) NEW_LINE DEDENT elif i == 1 and j == 0 : NEW_LINE INDENT print ( "0" , end = " ▁ " ) NEW_LINE DEDENT elif i == 2 and j == 1 : NEW_LINE INDENT print ( "0" , end = " ▁ " ) NEW_LINE DEDENT
else : NEW_LINE INDENT print ( n , end = " ▁ " ) NEW_LINE DEDENT print ( " " ) NEW_LINE
n = 15 NEW_LINE print ( " Maximum ▁ Detrminat = " , maxDet ( n ) ) NEW_LINE print ( " Resultant ▁ Matrix : " ) NEW_LINE resMatrix ( n ) NEW_LINE
def spiralDiaSum ( n ) : NEW_LINE INDENT if n == 1 : NEW_LINE INDENT return 1 NEW_LINE DEDENT DEDENT
return ( 4 * n * n - 6 * n + 6 + spiralDiaSum ( n - 2 ) ) NEW_LINE
n = 7 ; NEW_LINE print ( spiralDiaSum ( n ) ) NEW_LINE
R = 3 NEW_LINE C = 5 NEW_LINE
def numofneighbour ( mat , i , j ) : NEW_LINE INDENT count = 0 ; NEW_LINE DEDENT
if ( i > 0 and mat [ i - 1 ] [ j ] ) : NEW_LINE INDENT count += 1 ; NEW_LINE DEDENT
if ( j > 0 and mat [ i ] [ j - 1 ] ) : NEW_LINE INDENT count += 1 ; NEW_LINE DEDENT
if ( i < R - 1 and mat [ i + 1 ] [ j ] ) : NEW_LINE INDENT count += 1 NEW_LINE DEDENT
if ( j < C - 1 and mat [ i ] [ j + 1 ] ) : NEW_LINE INDENT count += 1 ; NEW_LINE DEDENT return count ; NEW_LINE
def findperimeter ( mat ) : NEW_LINE INDENT perimeter = 0 ; NEW_LINE DEDENT
for i in range ( 0 , R ) : NEW_LINE INDENT for j in range ( 0 , C ) : NEW_LINE INDENT if ( mat [ i ] [ j ] ) : NEW_LINE INDENT perimeter += ( 4 - numofneighbour ( mat , i , j ) ) ; NEW_LINE DEDENT DEDENT DEDENT return perimeter ; NEW_LINE
mat = [ [ 0 , 1 , 0 , 0 , 0 ] , [ 1 , 1 , 1 , 0 , 0 ] , [ 1 , 0 , 0 , 0 , 0 ] ] NEW_LINE print ( findperimeter ( mat ) , end = " " ) ; NEW_LINE
MAX = 100 NEW_LINE def printMatrixDiagonal ( mat , n ) : NEW_LINE
i = 0 NEW_LINE j = 0 NEW_LINE k = 0 NEW_LINE
isUp = True NEW_LINE
while k < n * n : NEW_LINE
if isUp : NEW_LINE INDENT while i >= 0 and j < n : NEW_LINE INDENT print ( str ( mat [ i ] [ j ] ) , end = " ▁ " ) NEW_LINE k += 1 NEW_LINE j += 1 NEW_LINE i -= 1 NEW_LINE DEDENT DEDENT
if i < 0 and j <= n - 1 : NEW_LINE INDENT i = 0 NEW_LINE DEDENT if j == n : NEW_LINE INDENT i = i + 2 NEW_LINE j -= 1 NEW_LINE DEDENT
else : NEW_LINE INDENT while j >= 0 and i < n : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " ▁ " ) NEW_LINE k += 1 NEW_LINE i += 1 NEW_LINE j -= 1 NEW_LINE DEDENT DEDENT
if j < 0 and i <= n - 1 : NEW_LINE INDENT j = 0 NEW_LINE DEDENT if i == n : NEW_LINE INDENT j = j + 2 NEW_LINE i -= 1 NEW_LINE DEDENT
isUp = not isUp NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] NEW_LINE n = 3 NEW_LINE printMatrixDiagonal ( mat , n ) NEW_LINE DEDENT
def maxRowDiff ( mat , m , n ) : NEW_LINE
rowSum = [ 0 ] * m NEW_LINE
for i in range ( 0 , m ) : NEW_LINE INDENT sum = 0 NEW_LINE for j in range ( 0 , n ) : NEW_LINE INDENT sum += mat [ i ] [ j ] NEW_LINE DEDENT rowSum [ i ] = sum NEW_LINE DEDENT
max_diff = rowSum [ 1 ] - rowSum [ 0 ] NEW_LINE min_element = rowSum [ 0 ] NEW_LINE for i in range ( 1 , m ) : NEW_LINE
if ( rowSum [ i ] - min_element > max_diff ) : NEW_LINE INDENT max_diff = rowSum [ i ] - min_element NEW_LINE DEDENT
if ( rowSum [ i ] < min_element ) : NEW_LINE INDENT min_element = rowSum [ i ] NEW_LINE DEDENT return max_diff NEW_LINE
m = 5 NEW_LINE n = 4 NEW_LINE mat = [ [ - 1 , 2 , 3 , 4 ] , [ 5 , 3 , - 2 , 1 ] , [ 6 , 7 , 2 , - 3 ] , [ 2 , 9 , 1 , 4 ] , [ 2 , 1 , - 2 , 0 ] ] NEW_LINE print ( maxRowDiff ( mat , m , n ) ) NEW_LINE
def sortedCount ( mat , r , c ) : NEW_LINE
result = 0 NEW_LINE
for i in range ( r ) : NEW_LINE
j = 0 NEW_LINE for j in range ( c - 1 ) : NEW_LINE INDENT if mat [ i ] [ j + 1 ] <= mat [ i ] [ j ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if j == c - 2 : NEW_LINE INDENT result += 1 NEW_LINE DEDENT
for i in range ( 0 , r ) : NEW_LINE
j = 0 NEW_LINE for j in range ( c - 1 , 0 , - 1 ) : NEW_LINE INDENT if mat [ i ] [ j - 1 ] <= mat [ i ] [ j ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT
if c > 1 and j == 1 : NEW_LINE INDENT result += 1 NEW_LINE DEDENT return result NEW_LINE
m , n = 4 , 5 NEW_LINE mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 4 , 3 , 1 , 2 , 6 ] , [ 8 , 7 , 6 , 5 , 4 ] , [ 5 , 7 , 8 , 9 , 10 ] ] NEW_LINE print ( sortedCount ( mat , m , n ) ) NEW_LINE
MAX = 1000 NEW_LINE
def maxXOR ( mat , N ) : NEW_LINE
max_xor = 0 NEW_LINE
for i in range ( N ) : NEW_LINE INDENT r_xor = 0 NEW_LINE c_xor = 0 NEW_LINE for j in range ( N ) : NEW_LINE DEDENT
r_xor = r_xor ^ mat [ i ] [ j ] NEW_LINE
c_xor = c_xor ^ mat [ j ] [ i ] NEW_LINE
if ( max_xor < max ( r_xor , c_xor ) ) : NEW_LINE INDENT max_xor = max ( r_xor , c_xor ) NEW_LINE DEDENT
return max_xor NEW_LINE
N = 3 NEW_LINE mat = [ [ 1 , 5 , 4 ] , [ 3 , 7 , 2 ] , [ 5 , 9 , 10 ] ] NEW_LINE print ( " maximum ▁ XOR ▁ value ▁ : ▁ " , maxXOR ( mat , N ) ) NEW_LINE
def direction ( R , C ) : NEW_LINE INDENT if ( R != C and R % 2 == 0 and C % 2 != 0 and R < C ) : NEW_LINE INDENT print ( " Left " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 == 0 and C % 2 == 0 and R > C ) : NEW_LINE INDENT print ( " Up " ) NEW_LINE return NEW_LINE DEDENT if R == C and R % 2 != 0 and C % 2 != 0 : NEW_LINE INDENT print ( " Right " ) NEW_LINE return NEW_LINE DEDENT if R == C and R % 2 == 0 and C % 2 == 0 : NEW_LINE INDENT print ( " Left " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 != 0 and C % 2 != 0 and R < C ) : NEW_LINE INDENT print ( " Right " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 != 0 and C % 2 != 0 and R > C ) : NEW_LINE INDENT print ( " Down " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 == 0 and C % 2 != 0 and R < C ) : NEW_LINE INDENT print ( " Left " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 == 0 and C % 2 == 0 and R > C ) : NEW_LINE INDENT print ( " Up " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 != 0 and C % 2 != 0 and R > C ) : NEW_LINE INDENT print ( " Down " ) NEW_LINE return NEW_LINE DEDENT if ( R != C and R % 2 != 0 and C % 2 != 0 and R < C ) : NEW_LINE INDENT print ( " Right " ) NEW_LINE return NEW_LINE DEDENT DEDENT
R = 3 ; C = 1 NEW_LINE direction ( R , C ) NEW_LINE
def checkDiagonal ( mat , i , j ) : NEW_LINE INDENT res = mat [ i ] [ j ] NEW_LINE i += 1 NEW_LINE j += 1 NEW_LINE while ( i < N and j < M ) : NEW_LINE DEDENT
if ( mat [ i ] [ j ] != res ) : NEW_LINE INDENT return False NEW_LINE DEDENT i += 1 NEW_LINE j += 1 NEW_LINE
return True NEW_LINE
def isToeplitz ( mat ) : NEW_LINE
for j in range ( M ) : NEW_LINE
if not ( checkDiagonal ( mat , 0 , j ) ) : NEW_LINE INDENT return False NEW_LINE DEDENT
for i in range ( 1 , N ) : NEW_LINE
if not ( checkDiagonal ( mat , i , 0 ) ) : NEW_LINE INDENT return False NEW_LINE DEDENT
return True NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 6 , 7 , 8 , 9 ] , [ 4 , 6 , 7 , 8 ] , [ 1 , 4 , 6 , 7 ] , [ 0 , 1 , 4 , 6 ] , [ 2 , 0 , 1 , 4 ] ] NEW_LINE DEDENT
if ( isToeplitz ( mat ) ) : NEW_LINE INDENT print ( " Matrix ▁ is ▁ a ▁ Toeplitz " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " Matrix ▁ is ▁ not ▁ a ▁ Toeplitz " ) NEW_LINE DEDENT
N = 5 ; NEW_LINE
def countZeroes ( mat ) : NEW_LINE
row = N - 1 ; NEW_LINE col = 0 ; NEW_LINE
count = 0 ; NEW_LINE while ( col < N ) : NEW_LINE
while ( mat [ row ] [ col ] ) : NEW_LINE
if ( row < 0 ) : NEW_LINE INDENT return count ; NEW_LINE DEDENT row = row - 1 ; NEW_LINE
count = count + ( row + 1 ) ; NEW_LINE
col = col + 1 ; NEW_LINE return count ; NEW_LINE
mat = [ [ 0 , 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 0 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] ] ; NEW_LINE print ( countZeroes ( mat ) ) ; NEW_LINE
def countNegative ( M , n , m ) : NEW_LINE INDENT count = 0 NEW_LINE DEDENT
for i in range ( n ) : NEW_LINE INDENT for j in range ( m ) : NEW_LINE INDENT if M [ i ] [ j ] < 0 : NEW_LINE INDENT count += 1 NEW_LINE DEDENT else : NEW_LINE DEDENT DEDENT
break NEW_LINE return count NEW_LINE
M = [ [ - 3 , - 2 , - 1 , 1 ] , [ - 2 , 2 , 3 , 4 ] , [ 4 , 5 , 7 , 8 ] ] NEW_LINE print ( countNegative ( M , 3 , 4 ) ) NEW_LINE
def countNegative ( M , n , m ) : NEW_LINE
count = 0 NEW_LINE
i = 0 NEW_LINE j = m - 1 NEW_LINE
while j >= 0 and i < n : NEW_LINE INDENT if M [ i ] [ j ] < 0 : NEW_LINE DEDENT
count += ( j + 1 ) NEW_LINE
i += 1 NEW_LINE else : NEW_LINE
j -= 1 NEW_LINE return count NEW_LINE
M = [ [ - 3 , - 2 , - 1 , 1 ] , [ - 2 , 2 , 3 , 4 ] , [ 4 , 5 , 7 , 8 ] ] NEW_LINE print ( countNegative ( M , 3 , 4 ) ) NEW_LINE
N = 10 NEW_LINE
def findLargestPlus ( mat ) : NEW_LINE
left = [ [ 0 for x in range ( N ) ] for y in range ( N ) ] NEW_LINE right = [ [ 0 for x in range ( N ) ] for y in range ( N ) ] NEW_LINE top = [ [ 0 for x in range ( N ) ] for y in range ( N ) ] NEW_LINE bottom = [ [ 0 for x in range ( N ) ] for y in range ( N ) ] NEW_LINE
for i in range ( N ) : NEW_LINE
top [ 0 ] [ i ] = mat [ 0 ] [ i ] NEW_LINE
bottom [ N - 1 ] [ i ] = mat [ N - 1 ] [ i ] NEW_LINE
left [ i ] [ 0 ] = mat [ i ] [ 0 ] NEW_LINE
right [ i ] [ N - 1 ] = mat [ i ] [ N - 1 ] NEW_LINE
for i in range ( N ) : NEW_LINE INDENT for j in range ( 1 , N ) : NEW_LINE DEDENT
if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT left [ i ] [ j ] = left [ i ] [ j - 1 ] + 1 NEW_LINE DEDENT else : NEW_LINE INDENT left [ i ] [ j ] = 0 NEW_LINE DEDENT
if ( mat [ j ] [ i ] == 1 ) : NEW_LINE INDENT top [ j ] [ i ] = top [ j - 1 ] [ i ] + 1 NEW_LINE DEDENT else : NEW_LINE INDENT top [ j ] [ i ] = 0 NEW_LINE DEDENT
j = N - 1 - j NEW_LINE
if ( mat [ j ] [ i ] == 1 ) : NEW_LINE INDENT bottom [ j ] [ i ] = bottom [ j + 1 ] [ i ] + 1 NEW_LINE DEDENT else : NEW_LINE INDENT bottom [ j ] [ i ] = 0 NEW_LINE DEDENT
if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT right [ i ] [ j ] = right [ i ] [ j + 1 ] + 1 NEW_LINE DEDENT else : NEW_LINE INDENT right [ i ] [ j ] = 0 NEW_LINE DEDENT
j = N - 1 - j NEW_LINE
n = 0 NEW_LINE
for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE DEDENT
l = min ( min ( top [ i ] [ j ] , bottom [ i ] [ j ] ) , min ( left [ i ] [ j ] , right [ i ] [ j ] ) ) NEW_LINE
if ( l > n ) : NEW_LINE INDENT n = l NEW_LINE DEDENT
if ( n ) : NEW_LINE INDENT return 4 * ( n - 1 ) + 1 NEW_LINE DEDENT
return 0 NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 ] , [ 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 ] , [ 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 ] , [ 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 ] , [ 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 ] , [ 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 ] , [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 ] , [ 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 ] , [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 ] ] NEW_LINE print ( findLargestPlus ( mat ) ) NEW_LINE DEDENT
def findLeft ( str ) : NEW_LINE INDENT n = len ( str ) - 1 ; NEW_LINE DEDENT
while ( n > 0 ) : NEW_LINE
if ( str [ n ] == ' d ' ) : NEW_LINE INDENT str = str [ 0 : n ] + ' c ' + str [ n + 1 : ] ; NEW_LINE break ; NEW_LINE DEDENT if ( str [ n ] == ' b ' ) : NEW_LINE INDENT str = str [ 0 : n ] + ' a ' + str [ n + 1 : ] ; NEW_LINE break ; NEW_LINE DEDENT
if ( str [ n ] == ' a ' ) : NEW_LINE INDENT str = str [ 0 : n ] + ' b ' + str [ n + 1 : ] ; NEW_LINE DEDENT elif ( str [ n ] == ' c ' ) : NEW_LINE INDENT str = str [ 0 : n ] + ' d ' + str [ n + 1 : ] ; NEW_LINE DEDENT n -= 1 ; NEW_LINE return str ; NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT str = " aacbddc " ; NEW_LINE print ( " Left ▁ of " , str , " is " , findLeft ( str ) ) ; NEW_LINE DEDENT
def printSpiral ( n ) : NEW_LINE INDENT for i in range ( 0 , n ) : NEW_LINE INDENT for j in range ( 0 , n ) : NEW_LINE DEDENT DEDENT
x = min ( min ( i , j ) , min ( n - 1 - i , n - 1 - j ) ) NEW_LINE
if ( i <= j ) : NEW_LINE INDENT print ( ( n - 2 * x ) * ( n - 2 * x ) - ( i - x ) - ( j - x ) , end = " TABSYMBOL " ) NEW_LINE DEDENT
else : NEW_LINE INDENT print ( ( ( n - 2 * x - 2 ) * ( n - 2 * x - 2 ) + ( i - x ) + ( j - x ) ) , end = " TABSYMBOL " ) NEW_LINE DEDENT print ( ) NEW_LINE
n = 5 NEW_LINE
printSpiral ( n ) NEW_LINE
N = 5 NEW_LINE
def findMaxValue ( mat ) : NEW_LINE
maxValue = 0 NEW_LINE
for a in range ( N - 1 ) : NEW_LINE INDENT for b in range ( N - 1 ) : NEW_LINE INDENT for d in range ( a + 1 , N ) : NEW_LINE INDENT for e in range ( b + 1 , N ) : NEW_LINE INDENT if maxValue < int ( mat [ d ] [ e ] - mat [ a ] [ b ] ) : NEW_LINE INDENT maxValue = int ( mat [ d ] [ e ] - mat [ a ] [ b ] ) ; NEW_LINE DEDENT DEDENT DEDENT DEDENT DEDENT return maxValue ; NEW_LINE
mat = [ [ 1 , 2 , - 1 , - 4 , - 20 ] , [ - 8 , - 3 , 4 , 2 , 1 ] , [ 3 , 8 , 6 , 1 , 3 ] , [ - 4 , - 1 , 1 , 7 , - 6 ] , [ 0 , - 4 , 10 , - 5 , 1 ] ] ; NEW_LINE print ( " Maximum ▁ Value ▁ is ▁ " + str ( findMaxValue ( mat ) ) ) NEW_LINE
import sys NEW_LINE N = 5 NEW_LINE
def findMaxValue ( mat ) : NEW_LINE
maxValue = - sys . maxsize - 1 NEW_LINE
maxArr = [ [ 0 for x in range ( N ) ] for y in range ( N ) ] NEW_LINE
maxArr [ N - 1 ] [ N - 1 ] = mat [ N - 1 ] [ N - 1 ] NEW_LINE
maxv = mat [ N - 1 ] [ N - 1 ] ; NEW_LINE for j in range ( N - 2 , - 1 , - 1 ) : NEW_LINE INDENT if ( mat [ N - 1 ] [ j ] > maxv ) : NEW_LINE INDENT maxv = mat [ N - 1 ] [ j ] NEW_LINE DEDENT maxArr [ N - 1 ] [ j ] = maxv NEW_LINE DEDENT
maxv = mat [ N - 1 ] [ N - 1 ] ; NEW_LINE for i in range ( N - 2 , - 1 , - 1 ) : NEW_LINE INDENT if ( mat [ i ] [ N - 1 ] > maxv ) : NEW_LINE INDENT maxv = mat [ i ] [ N - 1 ] NEW_LINE DEDENT maxArr [ i ] [ N - 1 ] = maxv NEW_LINE DEDENT
for i in range ( N - 2 , - 1 , - 1 ) : NEW_LINE INDENT for j in range ( N - 2 , - 1 , - 1 ) : NEW_LINE DEDENT
if ( maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] > maxValue ) : NEW_LINE INDENT maxValue = ( maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] ) NEW_LINE DEDENT
maxArr [ i ] [ j ] = max ( mat [ i ] [ j ] , max ( maxArr [ i ] [ j + 1 ] , maxArr [ i + 1 ] [ j ] ) ) NEW_LINE return maxValue NEW_LINE
mat = [ [ 1 , 2 , - 1 , - 4 , - 20 ] , [ - 8 , - 3 , 4 , 2 , 1 ] , [ 3 , 8 , 6 , 1 , 3 ] , [ - 4 , - 1 , 1 , 7 , - 6 ] , [ 0 , - 4 , 10 , - 5 , 1 ] ] NEW_LINE print ( " Maximum ▁ Value ▁ is " , findMaxValue ( mat ) ) NEW_LINE
R = 3 NEW_LINE C = 4 NEW_LINE def modifyMatrix ( mat ) : NEW_LINE INDENT row = [ 0 ] * R NEW_LINE col = [ 0 ] * C NEW_LINE DEDENT
for i in range ( 0 , R ) : NEW_LINE INDENT row [ i ] = 0 NEW_LINE DEDENT
for i in range ( 0 , C ) : NEW_LINE INDENT col [ i ] = 0 NEW_LINE DEDENT
for i in range ( 0 , R ) : NEW_LINE INDENT for j in range ( 0 , C ) : NEW_LINE INDENT if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT row [ i ] = 1 NEW_LINE col [ j ] = 1 NEW_LINE DEDENT DEDENT DEDENT
for i in range ( 0 , R ) : NEW_LINE INDENT for j in range ( 0 , C ) : NEW_LINE INDENT if ( row [ i ] == 1 or col [ j ] == 1 ) : NEW_LINE INDENT mat [ i ] [ j ] = 1 NEW_LINE DEDENT DEDENT DEDENT
def printMatrix ( mat ) : NEW_LINE INDENT for i in range ( 0 , R ) : NEW_LINE INDENT for j in range ( 0 , C ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
mat = [ [ 1 , 0 , 0 , 1 ] , [ 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 0 ] ] NEW_LINE print ( " Input ▁ Matrix ▁ n " ) NEW_LINE printMatrix ( mat ) NEW_LINE modifyMatrix ( mat ) NEW_LINE print ( " Matrix ▁ after ▁ modification ▁ n " ) NEW_LINE printMatrix ( mat ) NEW_LINE
def modifyMatrix ( mat ) : NEW_LINE
row_flag = False NEW_LINE col_flag = False NEW_LINE
for i in range ( 0 , len ( mat ) ) : NEW_LINE INDENT for j in range ( 0 , len ( mat ) ) : NEW_LINE INDENT if ( i == 0 and mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT row_flag = True NEW_LINE DEDENT if ( j == 0 and mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT col_flag = True NEW_LINE DEDENT if ( mat [ i ] [ j ] == 1 ) : NEW_LINE INDENT mat [ 0 ] [ j ] = 1 NEW_LINE mat [ i ] [ 0 ] = 1 NEW_LINE DEDENT DEDENT DEDENT
for i in range ( 1 , len ( mat ) ) : NEW_LINE INDENT for j in range ( 1 , len ( mat ) + 1 ) : NEW_LINE INDENT if ( mat [ 0 ] [ j ] == 1 or mat [ i ] [ 0 ] == 1 ) : NEW_LINE INDENT mat [ i ] [ j ] = 1 NEW_LINE DEDENT DEDENT DEDENT
if ( row_flag == True ) : NEW_LINE INDENT for i in range ( 0 , len ( mat ) ) : NEW_LINE INDENT mat [ 0 ] [ i ] = 1 NEW_LINE DEDENT DEDENT
if ( col_flag == True ) : NEW_LINE INDENT for i in range ( 0 , len ( mat ) ) : NEW_LINE INDENT mat [ i ] [ 0 ] = 1 NEW_LINE DEDENT DEDENT
def printMatrix ( mat ) : NEW_LINE INDENT for i in range ( 0 , len ( mat ) ) : NEW_LINE INDENT for j in range ( 0 , len ( mat ) + 1 ) : NEW_LINE INDENT print ( mat [ i ] [ j ] , end = " " ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT DEDENT
mat = [ [ 1 , 0 , 0 , 1 ] , [ 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 0 ] ] NEW_LINE print ( " Input ▁ Matrix ▁ : " ) NEW_LINE printMatrix ( mat ) NEW_LINE modifyMatrix ( mat ) NEW_LINE print ( " Matrix ▁ After ▁ Modification ▁ : " ) NEW_LINE printMatrix ( mat ) NEW_LINE
def find ( arr ) : NEW_LINE INDENT n = len ( arr ) NEW_LINE DEDENT
i = 0 NEW_LINE j = n - 1 NEW_LINE
res = - 1 NEW_LINE
while i < n and j >= 0 : NEW_LINE
if arr [ i ] [ j ] == 0 : NEW_LINE
while j >= 0 and ( arr [ i ] [ j ] == 0 or i == j ) : NEW_LINE INDENT j -= 1 NEW_LINE DEDENT
if j == - 1 : NEW_LINE INDENT res = i NEW_LINE break NEW_LINE DEDENT
else : i += 1 NEW_LINE
else : NEW_LINE
while i < n and ( arr [ i ] [ j ] == 1 or i == j ) : NEW_LINE INDENT i += 1 NEW_LINE DEDENT
if i == n : NEW_LINE INDENT res = j NEW_LINE break NEW_LINE DEDENT
else : j -= 1 NEW_LINE
if res == - 1 : NEW_LINE INDENT return res NEW_LINE DEDENT
for i in range ( 0 , n ) : NEW_LINE INDENT if res != i and arr [ i ] [ res ] != 1 : NEW_LINE INDENT return - 1 NEW_LINE DEDENT DEDENT for j in range ( 0 , j ) : NEW_LINE INDENT if res != j and arr [ res ] [ j ] != 0 : NEW_LINE INDENT return - 1 ; NEW_LINE DEDENT DEDENT return res ; NEW_LINE
arr = [ [ 0 , 0 , 1 , 1 , 0 ] , [ 0 , 0 , 0 , 1 , 0 ] , [ 1 , 1 , 1 , 1 , 0 ] , [ 0 , 0 , 0 , 0 , 0 ] , [ 1 , 1 , 1 , 1 , 1 ] ] NEW_LINE print find ( arr ) NEW_LINE
def preProcess ( mat , aux ) : NEW_LINE
for i in range ( 0 , N , 1 ) : NEW_LINE INDENT aux [ 0 ] [ i ] = mat [ 0 ] [ i ] NEW_LINE DEDENT
for i in range ( 1 , M , 1 ) : NEW_LINE INDENT for j in range ( 0 , N , 1 ) : NEW_LINE INDENT aux [ i ] [ j ] = mat [ i ] [ j ] + aux [ i - 1 ] [ j ] NEW_LINE DEDENT DEDENT
for i in range ( 0 , M , 1 ) : NEW_LINE INDENT for j in range ( 1 , N , 1 ) : NEW_LINE INDENT aux [ i ] [ j ] += aux [ i ] [ j - 1 ] NEW_LINE DEDENT DEDENT
def sumQuery ( aux , tli , tlj , rbi , rbj ) : NEW_LINE
res = aux [ rbi ] [ rbj ] NEW_LINE
if ( tli > 0 ) : NEW_LINE INDENT res = res - aux [ tli - 1 ] [ rbj ] NEW_LINE DEDENT
if ( tlj > 0 ) : NEW_LINE INDENT res = res - aux [ rbi ] [ tlj - 1 ] NEW_LINE DEDENT
if ( tli > 0 and tlj > 0 ) : NEW_LINE INDENT res = res + aux [ tli - 1 ] [ tlj - 1 ] NEW_LINE DEDENT return res NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT mat = [ [ 1 , 2 , 3 , 4 , 6 ] , [ 5 , 3 , 8 , 1 , 2 ] , [ 4 , 6 , 7 , 5 , 5 ] , [ 2 , 4 , 8 , 9 , 4 ] ] NEW_LINE DEDENT aux = [ [ 0 for i in range ( N ) ] for j in range ( M ) ] NEW_LINE preProcess ( mat , aux ) NEW_LINE tli = 2 NEW_LINE tlj = 2 NEW_LINE rbi = 3 NEW_LINE rbj = 4 NEW_LINE print ( " Query1 : " , sumQuery ( aux , tli , tlj , rbi , rbj ) ) NEW_LINE tli = 0 NEW_LINE tlj = 0 NEW_LINE rbi = 1 NEW_LINE rbj = 1 NEW_LINE print ( " Query2 : " , sumQuery ( aux , tli , tlj , rbi , rbj ) ) NEW_LINE tli = 1 NEW_LINE tlj = 2 NEW_LINE rbi = 3 NEW_LINE rbj = 3 NEW_LINE print ( " Query3 : " , sumQuery ( aux , tli , tlj , rbi , rbj ) ) NEW_LINE
class rankMatrix ( object ) : NEW_LINE INDENT def __init__ ( self , Matrix ) : NEW_LINE INDENT self . R = len ( Matrix ) NEW_LINE self . C = len ( Matrix [ 0 ] ) NEW_LINE DEDENT DEDENT
def swap ( self , Matrix , row1 , row2 , col ) : NEW_LINE INDENT for i in range ( col ) : NEW_LINE INDENT temp = Matrix [ row1 ] [ i ] NEW_LINE Matrix [ row1 ] [ i ] = Matrix [ row2 ] [ i ] NEW_LINE Matrix [ row2 ] [ i ] = temp NEW_LINE DEDENT DEDENT
def rankOfMatrix ( self , Matrix ) : NEW_LINE INDENT rank = self . C NEW_LINE for row in range ( 0 , rank , 1 ) : NEW_LINE DEDENT
if Matrix [ row ] [ row ] != 0 : NEW_LINE INDENT for col in range ( 0 , self . R , 1 ) : NEW_LINE INDENT if col != row : NEW_LINE DEDENT DEDENT
multiplier = ( Matrix [ col ] [ row ] / Matrix [ row ] [ row ] ) NEW_LINE for i in range ( rank ) : NEW_LINE INDENT Matrix [ col ] [ i ] -= ( multiplier * Matrix [ row ] [ i ] ) NEW_LINE DEDENT
else : NEW_LINE INDENT reduce = True NEW_LINE DEDENT
for i in range ( row + 1 , self . R , 1 ) : NEW_LINE
if Matrix [ i ] [ row ] != 0 : NEW_LINE INDENT self . swap ( Matrix , row , i , rank ) NEW_LINE reduce = False NEW_LINE break NEW_LINE DEDENT
if reduce : NEW_LINE
rank -= 1 NEW_LINE
for i in range ( 0 , self . R , 1 ) : NEW_LINE INDENT Matrix [ i ] [ row ] = Matrix [ i ] [ rank ] NEW_LINE DEDENT
row -= 1 NEW_LINE
return ( rank ) NEW_LINE
def Display ( self , Matrix , row , col ) : NEW_LINE INDENT for i in range ( row ) : NEW_LINE INDENT for j in range ( col ) : NEW_LINE INDENT print ( " ▁ " + str ( Matrix [ i ] [ j ] ) ) NEW_LINE DEDENT print ( ' ' ) NEW_LINE DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT Matrix = [ [ 10 , 20 , 10 ] , [ - 20 , - 30 , 10 ] , [ 30 , 50 , 0 ] ] NEW_LINE RankMatrix = rankMatrix ( Matrix ) NEW_LINE print ( " Rank ▁ of ▁ the ▁ Matrix ▁ is : " , ( RankMatrix . rankOfMatrix ( Matrix ) ) ) NEW_LINE DEDENT
def countIslands ( mat ) : NEW_LINE
count = 0 ; NEW_LINE
for i in range ( 0 , M ) : NEW_LINE INDENT for j in range ( 0 , N ) : NEW_LINE DEDENT
if ( mat [ i ] [ j ] == ' X ' ) : NEW_LINE INDENT if ( ( i == 0 or mat [ i - 1 ] [ j ] == ' O ' ) and ( j == 0 or mat [ i ] [ j - 1 ] == ' O ' ) ) : NEW_LINE INDENT count = count + 1 NEW_LINE DEDENT DEDENT return count NEW_LINE
M = 6 NEW_LINE N = 3 NEW_LINE mat = [ [ ' O ' , ' O ' , ' O ' ] , [ ' X ' , ' X ' , ' O ' ] , [ ' X ' , ' X ' , ' O ' ] , [ ' O ' , ' O ' , ' X ' ] , [ ' O ' , ' O ' , ' X ' ] , [ ' X ' , ' X ' , ' O ' ] ] NEW_LINE print ( " Number ▁ of ▁ rectangular ▁ islands ▁ is " , countIslands ( mat ) ) NEW_LINE
M = 6 NEW_LINE N = 6 NEW_LINE
def floodFillUtil ( mat , x , y , prevV , newV ) : NEW_LINE
if ( x < 0 or x >= M or y < 0 or y >= N ) : NEW_LINE INDENT return NEW_LINE DEDENT if ( mat [ x ] [ y ] != prevV ) : NEW_LINE INDENT return NEW_LINE DEDENT
mat [ x ] [ y ] = newV NEW_LINE
floodFillUtil ( mat , x + 1 , y , prevV , newV ) NEW_LINE floodFillUtil ( mat , x - 1 , y , prevV , newV ) NEW_LINE floodFillUtil ( mat , x , y + 1 , prevV , newV ) NEW_LINE floodFillUtil ( mat , x , y - 1 , prevV , newV ) NEW_LINE
def replaceSurrounded ( mat ) : NEW_LINE
for i in range ( M ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT if ( mat [ i ] [ j ] == ' O ' ) : NEW_LINE INDENT mat [ i ] [ j ] = ' - ' NEW_LINE DEDENT DEDENT DEDENT
for i in range ( M ) : NEW_LINE INDENT if ( mat [ i ] [ 0 ] == ' - ' ) : NEW_LINE INDENT floodFillUtil ( mat , i , 0 , ' - ' , ' O ' ) NEW_LINE DEDENT DEDENT
for i in range ( M ) : NEW_LINE INDENT if ( mat [ i ] [ N - 1 ] == ' - ' ) : NEW_LINE INDENT floodFillUtil ( mat , i , N - 1 , ' - ' , ' O ' ) NEW_LINE DEDENT DEDENT
for i in range ( N ) : NEW_LINE INDENT if ( mat [ 0 ] [ i ] == ' - ' ) : NEW_LINE INDENT floodFillUtil ( mat , 0 , i , ' - ' , ' O ' ) NEW_LINE DEDENT DEDENT
for i in range ( N ) : NEW_LINE INDENT if ( mat [ M - 1 ] [ i ] == ' - ' ) : NEW_LINE INDENT floodFillUtil ( mat , M - 1 , i , ' - ' , ' O ' ) NEW_LINE DEDENT DEDENT
for i in range ( M ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT if ( mat [ i ] [ j ] == ' - ' ) : NEW_LINE INDENT mat [ i ] [ j ] = ' X ' NEW_LINE DEDENT DEDENT DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT mat = [ [ ' X ' , ' O ' , ' X ' , ' O ' , ' X ' , ' X ' ] , [ ' X ' , ' O ' , ' X ' , ' X ' , ' O ' , ' X ' ] , [ ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' X ' ] , [ ' O ' , ' X ' , ' X ' , ' X ' , ' X ' , ' X ' ] , [ ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' O ' ] , [ ' O ' , ' O ' , ' X ' , ' O ' , ' O ' , ' O ' ] ] ; NEW_LINE replaceSurrounded ( mat ) NEW_LINE for i in range ( M ) : NEW_LINE INDENT print ( * mat [ i ] ) NEW_LINE DEDENT DEDENT
n = 5 NEW_LINE
def printSumSimple ( mat , k ) : NEW_LINE
if ( k > n ) : NEW_LINE INDENT return NEW_LINE DEDENT
for i in range ( n - k + 1 ) : NEW_LINE
for j in range ( n - k + 1 ) : NEW_LINE
sum = 0 NEW_LINE for p in range ( i , k + i ) : NEW_LINE INDENT for q in range ( j , k + j ) : NEW_LINE INDENT sum += mat [ p ] [ q ] NEW_LINE DEDENT DEDENT print ( sum , end = " ▁ " ) NEW_LINE
print ( ) NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] NEW_LINE k = 3 NEW_LINE printSumSimple ( mat , k ) NEW_LINE DEDENT
n = 5 NEW_LINE
def printSumTricky ( mat , k ) : NEW_LINE INDENT global n NEW_LINE DEDENT
if k > n : NEW_LINE INDENT return NEW_LINE DEDENT
stripSum = [ [ None ] * n for i in range ( n ) ] NEW_LINE
for j in range ( n ) : NEW_LINE
Sum = 0 NEW_LINE for i in range ( k ) : NEW_LINE INDENT Sum += mat [ i ] [ j ] NEW_LINE DEDENT stripSum [ 0 ] [ j ] = Sum NEW_LINE
for i in range ( 1 , n - k + 1 ) : NEW_LINE INDENT Sum += ( mat [ i + k - 1 ] [ j ] - mat [ i - 1 ] [ j ] ) NEW_LINE stripSum [ i ] [ j ] = Sum NEW_LINE DEDENT
for i in range ( n - k + 1 ) : NEW_LINE
Sum = 0 NEW_LINE for j in range ( k ) : NEW_LINE INDENT Sum += stripSum [ i ] [ j ] NEW_LINE DEDENT print ( Sum , end = " ▁ " ) NEW_LINE
for j in range ( 1 , n - k + 1 ) : NEW_LINE INDENT Sum += ( stripSum [ i ] [ j + k - 1 ] - stripSum [ i ] [ j - 1 ] ) NEW_LINE print ( Sum , end = " ▁ " ) NEW_LINE DEDENT print ( ) NEW_LINE
mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] NEW_LINE k = 3 NEW_LINE printSumTricky ( mat , k ) NEW_LINE
M = 3 NEW_LINE N = 4 NEW_LINE
def transpose ( A , B ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE INDENT B [ i ] [ j ] = A [ j ] [ i ] NEW_LINE DEDENT DEDENT DEDENT
A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] ] NEW_LINE B = [ [ 0 for x in range ( M ) ] for y in range ( N ) ] NEW_LINE transpose ( A , B ) NEW_LINE print ( " Result ▁ matrix ▁ is " ) NEW_LINE for i in range ( N ) : NEW_LINE INDENT for j in range ( M ) : NEW_LINE INDENT print ( B [ i ] [ j ] , " ▁ " , end = ' ' ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
N = 4 NEW_LINE
def transpose ( A ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( i + 1 , N ) : NEW_LINE INDENT A [ i ] [ j ] , A [ j ] [ i ] = A [ j ] [ i ] , A [ i ] [ j ] NEW_LINE DEDENT DEDENT DEDENT
A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] NEW_LINE transpose ( A ) NEW_LINE print ( " Modified ▁ matrix ▁ is " ) NEW_LINE for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT print ( A [ i ] [ j ] , " ▁ " , end = ' ' ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
R = 3 NEW_LINE C = 3 NEW_LINE
def pathCountRec ( mat , m , n , k ) : NEW_LINE
if m < 0 or n < 0 : NEW_LINE INDENT return 0 NEW_LINE DEDENT elif m == 0 and n == 0 : NEW_LINE INDENT return k == mat [ m ] [ n ] NEW_LINE DEDENT
return ( pathCountRec ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountRec ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ) NEW_LINE
def pathCount ( mat , k ) : NEW_LINE INDENT return pathCountRec ( mat , R - 1 , C - 1 , k ) NEW_LINE DEDENT
k = 12 NEW_LINE mat = [ [ 1 , 2 , 3 ] , [ 4 , 6 , 5 ] , [ 3 , 2 , 1 ] ] NEW_LINE print ( pathCount ( mat , k ) ) NEW_LINE
R = 3 NEW_LINE C = 3 NEW_LINE
x = [ 0 , 1 , 1 , - 1 , 1 , 0 , - 1 , - 1 ] NEW_LINE y = [ 1 , 0 , 1 , 1 , - 1 , - 1 , 0 , - 1 ] NEW_LINE
dp = [ [ 0 for i in range ( C ) ] for i in range ( R ) ] NEW_LINE
def isvalid ( i , j ) : NEW_LINE INDENT if ( i < 0 or j < 0 or i >= R or j >= C ) : NEW_LINE INDENT return False NEW_LINE DEDENT return True NEW_LINE DEDENT
def isadjacent ( prev , curr ) : NEW_LINE INDENT if ( ord ( curr ) - ord ( prev ) ) == 1 : NEW_LINE INDENT return True NEW_LINE DEDENT return False NEW_LINE DEDENT
def getLenUtil ( mat , i , j , prev ) : NEW_LINE
if ( isvalid ( i , j ) == False or isadjacent ( prev , mat [ i ] [ j ] ) == False ) : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( dp [ i ] [ j ] != - 1 ) : NEW_LINE INDENT return dp [ i ] [ j ] NEW_LINE DEDENT
ans = 0 NEW_LINE
for k in range ( 8 ) : NEW_LINE INDENT ans = max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , mat [ i ] [ j ] ) ) NEW_LINE DEDENT
dp [ i ] [ j ] = ans NEW_LINE return dp [ i ] [ j ] NEW_LINE
def getLen ( mat , s ) : NEW_LINE INDENT for i in range ( R ) : NEW_LINE INDENT for j in range ( C ) : NEW_LINE INDENT dp [ i ] [ j ] = - 1 NEW_LINE DEDENT DEDENT ans = 0 NEW_LINE for i in range ( R ) : NEW_LINE INDENT for j in range ( C ) : NEW_LINE DEDENT DEDENT
if ( mat [ i ] [ j ] == s ) : NEW_LINE
for k in range ( 8 ) : NEW_LINE INDENT ans = max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , s ) ) ; NEW_LINE DEDENT return ans NEW_LINE
mat = [ [ ' a ' , ' c ' , ' d ' ] , [ ' h ' , ' b ' , ' a ' ] , [ ' i ' , ' g ' , ' f ' ] ] NEW_LINE print ( getLen ( mat , ' a ' ) ) NEW_LINE print ( getLen ( mat , ' e ' ) ) NEW_LINE print ( getLen ( mat , ' b ' ) ) NEW_LINE print ( getLen ( mat , ' f ' ) ) NEW_LINE
import math as mt NEW_LINE R = 3 NEW_LINE C = 3 NEW_LINE def minInitialPoints ( points ) : NEW_LINE
dp = [ [ 0 for x in range ( C + 1 ) ] for y in range ( R + 1 ) ] NEW_LINE m , n = R , C NEW_LINE
if points [ m - 1 ] [ n - 1 ] > 0 : NEW_LINE INDENT dp [ m - 1 ] [ n - 1 ] = 1 NEW_LINE DEDENT else : NEW_LINE INDENT dp [ m - 1 ] [ n - 1 ] = abs ( points [ m - 1 ] [ n - 1 ] ) + 1 NEW_LINE DEDENT
for i in range ( m - 2 , - 1 , - 1 ) : NEW_LINE INDENT dp [ i ] [ n - 1 ] = max ( dp [ i + 1 ] [ n - 1 ] - points [ i ] [ n - 1 ] , 1 ) NEW_LINE DEDENT for i in range ( 2 , - 1 , - 1 ) : NEW_LINE INDENT dp [ m - 1 ] [ i ] = max ( dp [ m - 1 ] [ i + 1 ] - points [ m - 1 ] [ i ] , 1 ) NEW_LINE DEDENT
for i in range ( m - 2 , - 1 , - 1 ) : NEW_LINE INDENT for j in range ( n - 2 , - 1 , - 1 ) : NEW_LINE INDENT min_points_on_exit = min ( dp [ i + 1 ] [ j ] , dp [ i ] [ j + 1 ] ) NEW_LINE dp [ i ] [ j ] = max ( min_points_on_exit - points [ i ] [ j ] , 1 ) NEW_LINE DEDENT DEDENT return dp [ 0 ] [ 0 ] NEW_LINE
points = [ [ - 2 , - 3 , 3 ] , [ - 5 , - 10 , 1 ] , [ 10 , 30 , - 5 ] ] NEW_LINE print ( " Minimum ▁ Initial ▁ Points ▁ Required : " , minInitialPoints ( points ) ) NEW_LINE
