def calculateSpan ( price , n , S ) : NEW_LINE
S [ 0 ] = 1 NEW_LINE
for i in range ( 1 , n , 1 ) : NEW_LINE
S [ i ] = 1 NEW_LINE
j = i - 1 NEW_LINE while ( j >= 0 ) and ( price [ i ] >= price [ j ] ) : NEW_LINE INDENT S [ i ] += 1 NEW_LINE j -= 1 NEW_LINE DEDENT
def printArray ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
price = [ 10 , 4 , 5 , 90 , 120 , 80 ] NEW_LINE n = len ( price ) NEW_LINE S = [ None ] * n NEW_LINE
calculateSpan ( price , n , S ) NEW_LINE
def findSubArray ( arr , n ) : NEW_LINE INDENT sum = 0 NEW_LINE maxsize = - 1 NEW_LINE DEDENT
for i in range ( 0 , n - 1 ) : NEW_LINE INDENT sum = - 1 if ( arr [ i ] == 0 ) else 1 NEW_LINE DEDENT
for j in range ( i + 1 , n ) : NEW_LINE INDENT sum = sum + ( - 1 ) if ( arr [ j ] == 0 ) else sum + 1 NEW_LINE DEDENT
if ( sum == 0 and maxsize < j - i + 1 ) : NEW_LINE INDENT maxsize = j - i + 1 NEW_LINE startindex = i NEW_LINE DEDENT if ( maxsize == - 1 ) : NEW_LINE print ( " No ▁ such ▁ subarray " ) ; NEW_LINE else : NEW_LINE print ( startindex , " to " , startindex + maxsize - 1 ) ; NEW_LINE return maxsize NEW_LINE
arr = [ 1 , 0 , 0 , 1 , 0 , 1 , 1 ] NEW_LINE size = len ( arr ) NEW_LINE findSubArray ( arr , size ) NEW_LINE
def leftRotatebyOne ( arr , n ) : NEW_LINE INDENT temp = arr [ 0 ] NEW_LINE for i in range ( n - 1 ) : NEW_LINE INDENT arr [ i ] = arr [ i + 1 ] NEW_LINE DEDENT arr [ n - 1 ] = temp NEW_LINE DEDENT
def leftRotate ( arr , d , n ) : NEW_LINE INDENT for i in range ( d ) : NEW_LINE INDENT leftRotatebyOne ( arr , n ) NEW_LINE DEDENT DEDENT
def printArray ( arr , size ) : NEW_LINE INDENT for i in range ( size ) : NEW_LINE INDENT print ( " % ▁ d " % arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT DEDENT
arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] NEW_LINE leftRotate ( arr , 2 , 7 ) NEW_LINE printArray ( arr , 7 ) NEW_LINE
def print2Smallest ( arr ) : NEW_LINE
arr_size = len ( arr ) NEW_LINE if arr_size < 2 : NEW_LINE INDENT print " Invalid ▁ Input " NEW_LINE return NEW_LINE DEDENT first = second = sys . maxint NEW_LINE for i in range ( 0 , arr_size ) : NEW_LINE
if arr [ i ] < first : NEW_LINE INDENT second = first NEW_LINE first = arr [ i ] NEW_LINE DEDENT
elif ( arr [ i ] < second and arr [ i ] != first ) : NEW_LINE INDENT second = arr [ i ] ; NEW_LINE DEDENT if ( second == sys . maxint ) : NEW_LINE print " No ▁ second ▁ smallest ▁ element " NEW_LINE else : NEW_LINE print ' The ▁ smallest ▁ element ▁ is ' , first , ' and ' ' ▁ second ▁ smallest ▁ element ▁ is ' , second NEW_LINE
arr = [ 12 , 13 , 1 , 10 , 34 , 1 ] NEW_LINE print2Smallest ( arr ) NEW_LINE
def findFirstMissing ( array , start , end ) : NEW_LINE INDENT if ( start > end ) : NEW_LINE INDENT return end + 1 NEW_LINE DEDENT if ( start != array [ start ] ) : NEW_LINE INDENT return start ; NEW_LINE DEDENT mid = int ( ( start + end ) / 2 ) NEW_LINE DEDENT
if ( array [ mid ] == mid ) : NEW_LINE INDENT return findFirstMissing ( array , mid + 1 , end ) NEW_LINE DEDENT return findFirstMissing ( array , start , mid ) NEW_LINE
arr = [ 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 10 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Smallest ▁ missing ▁ element ▁ is " , findFirstMissing ( arr , 0 , n - 1 ) ) NEW_LINE
def getInvCount ( arr , n ) : NEW_LINE INDENT inv_count = 0 NEW_LINE for i in range ( n ) : NEW_LINE INDENT for j in range ( i + 1 , n ) : NEW_LINE INDENT if ( arr [ i ] > arr [ j ] ) : NEW_LINE INDENT inv_count += 1 NEW_LINE DEDENT DEDENT DEDENT return inv_count NEW_LINE DEDENT
arr = [ 1 , 20 , 6 , 4 , 5 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Number ▁ of ▁ inversions ▁ are " , getInvCount ( arr , n ) ) NEW_LINE
def printUnsorted ( arr , n ) : NEW_LINE INDENT e = n - 1 NEW_LINE DEDENT
for s in range ( 0 , n - 1 ) : NEW_LINE INDENT if arr [ s ] > arr [ s + 1 ] : NEW_LINE INDENT break NEW_LINE DEDENT DEDENT if s == n - 1 : NEW_LINE INDENT print ( " The ▁ complete ▁ array ▁ is ▁ sorted " ) NEW_LINE exit ( ) NEW_LINE DEDENT
e = n - 1 NEW_LINE while e > 0 : NEW_LINE INDENT if arr [ e ] < arr [ e - 1 ] : NEW_LINE INDENT break NEW_LINE DEDENT e -= 1 NEW_LINE DEDENT
max = arr [ s ] NEW_LINE min = arr [ s ] NEW_LINE for i in range ( s + 1 , e + 1 ) : NEW_LINE INDENT if arr [ i ] > max : NEW_LINE INDENT max = arr [ i ] NEW_LINE DEDENT if arr [ i ] < min : NEW_LINE INDENT min = arr [ i ] NEW_LINE DEDENT DEDENT
for i in range ( s ) : NEW_LINE INDENT if arr [ i ] > min : NEW_LINE INDENT s = i NEW_LINE break NEW_LINE DEDENT DEDENT
i = n - 1 NEW_LINE while i >= e + 1 : NEW_LINE INDENT if arr [ i ] < max : NEW_LINE INDENT e = i NEW_LINE break NEW_LINE DEDENT i -= 1 NEW_LINE DEDENT
print ( " The ▁ unsorted ▁ subarray ▁ which ▁ makes ▁ the ▁ given ▁ array " ) NEW_LINE print ( " sorted ▁ lies ▁ between ▁ the ▁ indexes ▁ % d ▁ and ▁ % d " % ( s , e ) ) NEW_LINE arr = [ 10 , 12 , 20 , 30 , 25 , 40 , 32 , 31 , 35 , 50 , 60 ] NEW_LINE arr_size = len ( arr ) NEW_LINE printUnsorted ( arr , arr_size ) NEW_LINE
def findElement ( arr , n , key ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT if ( arr [ i ] == key ) : NEW_LINE INDENT return i NEW_LINE DEDENT DEDENT return - 1 NEW_LINE DEDENT
arr = [ 12 , 34 , 10 , 6 , 40 ] NEW_LINE n = len ( arr ) NEW_LINE
key = 40 NEW_LINE index = findElement ( arr , n , key ) NEW_LINE if index != - 1 : NEW_LINE INDENT print ( " element ▁ found ▁ at ▁ position : ▁ " + str ( index + 1 ) ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " element ▁ not ▁ found " ) NEW_LINE DEDENT
def equilibrium ( arr ) : NEW_LINE
total_sum = sum ( arr ) NEW_LINE leftsum = 0 NEW_LINE for i , num in enumerate ( arr ) : NEW_LINE
total_sum -= num NEW_LINE if leftsum == total_sum : NEW_LINE INDENT return i NEW_LINE DEDENT leftsum += num NEW_LINE
return - 1 NEW_LINE
arr = [ - 7 , 1 , 5 , 2 , - 4 , 3 , 0 ] NEW_LINE print ( ' First ▁ equilibrium ▁ index ▁ is ▁ ' , equilibrium ( arr ) ) NEW_LINE
def ceilSearch ( arr , low , high , x ) : NEW_LINE
if x <= arr [ low ] : NEW_LINE INDENT return low NEW_LINE DEDENT
i = low NEW_LINE for i in range ( high ) : NEW_LINE INDENT if arr [ i ] == x : NEW_LINE INDENT return i NEW_LINE DEDENT DEDENT
if arr [ i ] < x and arr [ i + 1 ] >= x : NEW_LINE INDENT return i + 1 NEW_LINE DEDENT
return - 1 NEW_LINE
arr = [ 1 , 2 , 8 , 10 , 10 , 12 , 19 ] NEW_LINE n = len ( arr ) NEW_LINE x = 3 NEW_LINE index = ceilSearch ( arr , 0 , n - 1 , x ) ; NEW_LINE if index == - 1 : NEW_LINE INDENT print ( " Ceiling ▁ of ▁ % d ▁ doesn ' t ▁ exist ▁ in ▁ array ▁ " % x ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " ceiling ▁ of ▁ % d ▁ is ▁ % d " % ( x , arr [ index ] ) ) NEW_LINE DEDENT
def isMajority ( arr , n , x ) : NEW_LINE
last_index = ( n // 2 + 1 ) if n % 2 == 0 else ( n // 2 ) NEW_LINE
for i in range ( last_index ) : NEW_LINE
if arr [ i ] == x and arr [ i + n // 2 ] == x : NEW_LINE INDENT return 1 NEW_LINE DEDENT
arr = [ 1 , 2 , 3 , 4 , 4 , 4 , 4 ] NEW_LINE n = len ( arr ) NEW_LINE x = 4 NEW_LINE if ( isMajority ( arr , n , x ) ) : NEW_LINE INDENT print ( " % ▁ d ▁ appears ▁ more ▁ than ▁ % ▁ d ▁ times ▁ in ▁ arr [ ] " % ( x , n // 2 ) ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " % ▁ d ▁ does ▁ not ▁ appear ▁ more ▁ than ▁ % ▁ d ▁ times ▁ in ▁ arr [ ] " % ( x , n // 2 ) ) NEW_LINE DEDENT
def findPeakUtil ( arr , low , high , n ) : NEW_LINE
mid = low + ( high - low ) / 2 NEW_LINE mid = int ( mid ) NEW_LINE
if ( ( mid == 0 or arr [ mid - 1 ] <= arr [ mid ] ) and ( mid == n - 1 or arr [ mid + 1 ] <= arr [ mid ] ) ) : NEW_LINE INDENT return mid NEW_LINE DEDENT
elif ( mid > 0 and arr [ mid - 1 ] > arr [ mid ] ) : NEW_LINE INDENT return findPeakUtil ( arr , low , ( mid - 1 ) , n ) NEW_LINE DEDENT
else : NEW_LINE INDENT return findPeakUtil ( arr , ( mid + 1 ) , high , n ) NEW_LINE DEDENT
def findPeak ( arr , n ) : NEW_LINE INDENT return findPeakUtil ( arr , 0 , n - 1 , n ) NEW_LINE DEDENT
arr = [ 1 , 3 , 20 , 4 , 1 , 0 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Index ▁ of ▁ a ▁ peak ▁ point ▁ is " , findPeak ( arr , n ) ) NEW_LINE
def printRepeating ( arr , size ) : NEW_LINE INDENT count = [ 0 ] * size NEW_LINE print ( " ▁ Repeating ▁ elements ▁ are ▁ " , end = " " ) NEW_LINE for i in range ( 0 , size ) : NEW_LINE INDENT if ( count [ arr [ i ] ] == 1 ) : NEW_LINE INDENT print ( arr [ i ] , end = " ▁ " ) NEW_LINE DEDENT else : NEW_LINE INDENT count [ arr [ i ] ] = count [ arr [ i ] ] + 1 NEW_LINE DEDENT DEDENT DEDENT
arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 1 ] NEW_LINE arr_size = len ( arr ) NEW_LINE printRepeating ( arr , arr_size ) NEW_LINE
def linearSearch ( arr , n ) : NEW_LINE INDENT for i in range ( n ) : NEW_LINE INDENT if arr [ i ] is i : NEW_LINE INDENT return i NEW_LINE DEDENT DEDENT DEDENT
return - 1 NEW_LINE
arr = [ - 10 , - 1 , 0 , 3 , 10 , 11 , 30 , 50 , 100 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Fixed ▁ Point ▁ is ▁ " + str ( linearSearch ( arr , n ) ) ) NEW_LINE
def subArraySum ( arr , n , sum_ ) : NEW_LINE
for i in range ( n ) : NEW_LINE INDENT curr_sum = arr [ i ] NEW_LINE DEDENT
j = i + 1 NEW_LINE while j <= n : NEW_LINE INDENT if curr_sum == sum_ : NEW_LINE INDENT print ( " Sum ▁ found ▁ between " ) NEW_LINE print ( " indexes ▁ % ▁ d ▁ and ▁ % ▁ d " % ( i , j - 1 ) ) NEW_LINE return 1 NEW_LINE DEDENT if curr_sum > sum_ or j == n : NEW_LINE INDENT break NEW_LINE DEDENT curr_sum = curr_sum + arr [ j ] NEW_LINE j += 1 NEW_LINE DEDENT print ( " No ▁ subarray ▁ found " ) NEW_LINE return 0 NEW_LINE
arr = [ 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 ] NEW_LINE n = len ( arr ) NEW_LINE sum_ = 23 NEW_LINE subArraySum ( arr , n , sum_ ) NEW_LINE
def subArraySum ( arr , n , sum_ ) : NEW_LINE
curr_sum = arr [ 0 ] NEW_LINE start = 0 NEW_LINE
i = 1 NEW_LINE while i <= n : NEW_LINE
while curr_sum > sum_ and start < i - 1 : NEW_LINE INDENT curr_sum = curr_sum - arr [ start ] NEW_LINE start += 1 NEW_LINE DEDENT
if curr_sum == sum_ : NEW_LINE INDENT print ( " Sum ▁ found ▁ between ▁ indexes " ) NEW_LINE print ( " % ▁ d ▁ and ▁ % ▁ d " % ( start , i - 1 ) ) NEW_LINE return 1 NEW_LINE DEDENT
if i < n : NEW_LINE INDENT curr_sum = curr_sum + arr [ i ] NEW_LINE DEDENT i += 1 NEW_LINE
print ( " No ▁ subarray ▁ found " ) NEW_LINE return 0 NEW_LINE
arr = [ 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 ] NEW_LINE n = len ( arr ) NEW_LINE sum_ = 23 NEW_LINE subArraySum ( arr , n , sum_ ) NEW_LINE
def MatrixChainOrder ( p , i , j ) : NEW_LINE INDENT if i == j : NEW_LINE INDENT return 0 NEW_LINE DEDENT _min = sys . maxsize NEW_LINE DEDENT
for k in range ( i , j ) : NEW_LINE INDENT count = ( MatrixChainOrder ( p , i , k ) + MatrixChainOrder ( p , k + 1 , j ) + p [ i - 1 ] * p [ k ] * p [ j ] ) NEW_LINE if count < _min : NEW_LINE INDENT _min = count NEW_LINE DEDENT DEDENT
return _min NEW_LINE
arr = [ 1 , 2 , 3 , 4 , 3 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " , MatrixChainOrder ( arr , 1 , n - 1 ) ) NEW_LINE
def MatrixChainOrder ( p , n ) : NEW_LINE
m = [ [ 0 for x in range ( n ) ] for x in range ( n ) ] NEW_LINE
for i in range ( 1 , n ) : NEW_LINE INDENT m [ i ] [ i ] = 0 NEW_LINE DEDENT
for L in range ( 2 , n ) : NEW_LINE INDENT for i in range ( 1 , n - L + 1 ) : NEW_LINE INDENT j = i + L - 1 NEW_LINE m [ i ] [ j ] = sys . maxint NEW_LINE for k in range ( i , j ) : NEW_LINE DEDENT DEDENT
q = m [ i ] [ k ] + m [ k + 1 ] [ j ] + p [ i - 1 ] * p [ k ] * p [ j ] NEW_LINE if q < m [ i ] [ j ] : NEW_LINE INDENT m [ i ] [ j ] = q NEW_LINE DEDENT return m [ 1 ] [ n - 1 ] NEW_LINE
arr = [ 1 , 2 , 3 , 4 ] NEW_LINE size = len ( arr ) NEW_LINE print ( " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " + str ( MatrixChainOrder ( arr , size ) ) ) NEW_LINE
def knapSack ( W , wt , val , n ) : NEW_LINE
if n == 0 or W == 0 : NEW_LINE INDENT return 0 NEW_LINE DEDENT
if ( wt [ n - 1 ] > W ) : NEW_LINE INDENT return knapSack ( W , wt , val , n - 1 ) NEW_LINE DEDENT
else : NEW_LINE INDENT return max ( val [ n - 1 ] + knapSack ( W - wt [ n - 1 ] , wt , val , n - 1 ) , knapSack ( W , wt , val , n - 1 ) ) NEW_LINE DEDENT
val = [ 60 , 100 , 120 ] NEW_LINE wt = [ 10 , 20 , 30 ] NEW_LINE W = 50 NEW_LINE n = len ( val ) NEW_LINE print knapSack ( W , wt , val , n ) NEW_LINE
def count ( n ) : NEW_LINE
table = [ 0 for i in range ( n + 1 ) ] NEW_LINE
table [ 0 ] = 1 NEW_LINE
for i in range ( 3 , n + 1 ) : NEW_LINE INDENT table [ i ] += table [ i - 3 ] NEW_LINE DEDENT for i in range ( 5 , n + 1 ) : NEW_LINE INDENT table [ i ] += table [ i - 5 ] NEW_LINE DEDENT for i in range ( 10 , n + 1 ) : NEW_LINE INDENT table [ i ] += table [ i - 10 ] NEW_LINE DEDENT return table [ n ] NEW_LINE
n = 20 NEW_LINE print ( ' Count ▁ for ' , n , ' is ' , count ( n ) ) NEW_LINE n = 13 NEW_LINE print ( ' Count ▁ for ' , n , ' is ' , count ( n ) ) NEW_LINE
def search ( pat , txt ) : NEW_LINE INDENT M = len ( pat ) NEW_LINE N = len ( txt ) NEW_LINE DEDENT
for i in range ( N - M + 1 ) : NEW_LINE INDENT j = 0 NEW_LINE DEDENT
while ( j < M ) : NEW_LINE INDENT if ( txt [ i + j ] != pat [ j ] ) : NEW_LINE INDENT break NEW_LINE DEDENT j += 1 NEW_LINE DEDENT
if ( j == M ) : NEW_LINE INDENT print ( " Pattern ▁ found ▁ at ▁ index ▁ " , i ) NEW_LINE DEDENT
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT txt = " AABAACAADAABAAABAA " NEW_LINE pat = " AABA " NEW_LINE search ( pat , txt ) NEW_LINE DEDENT
d = 256 NEW_LINE
def search ( pat , txt , q ) : NEW_LINE INDENT M = len ( pat ) NEW_LINE N = len ( txt ) NEW_LINE i = 0 NEW_LINE j = 0 NEW_LINE DEDENT
p = 0 NEW_LINE
t = 0 NEW_LINE h = 1 NEW_LINE
for i in xrange ( M - 1 ) : NEW_LINE INDENT h = ( h * d ) % q NEW_LINE DEDENT
for i in xrange ( M ) : NEW_LINE INDENT p = ( d * p + ord ( pat [ i ] ) ) % q NEW_LINE t = ( d * t + ord ( txt [ i ] ) ) % q NEW_LINE DEDENT
for i in xrange ( N - M + 1 ) : NEW_LINE
if p == t : NEW_LINE
for j in xrange ( M ) : NEW_LINE INDENT if txt [ i + j ] != pat [ j ] : NEW_LINE INDENT break NEW_LINE DEDENT else : j += 1 NEW_LINE DEDENT
if j == M : NEW_LINE INDENT print " Pattern ▁ found ▁ at ▁ index ▁ " + str ( i ) NEW_LINE DEDENT
if i < N - M : NEW_LINE INDENT t = ( d * ( t - ord ( txt [ i ] ) * h ) + ord ( txt [ i + M ] ) ) % q NEW_LINE DEDENT
if t < 0 : NEW_LINE INDENT t = t + q NEW_LINE DEDENT
txt = " GEEKS ▁ FOR ▁ GEEKS " NEW_LINE pat = " GEEK " NEW_LINE
q = 101 NEW_LINE
search ( pat , txt , q ) NEW_LINE
def power ( x , y ) : NEW_LINE INDENT if ( y == 0 ) : return 1 NEW_LINE elif ( int ( y % 2 ) == 0 ) : NEW_LINE INDENT return ( power ( x , int ( y / 2 ) ) * power ( x , int ( y / 2 ) ) ) NEW_LINE DEDENT else : NEW_LINE INDENT return ( x * power ( x , int ( y / 2 ) ) * power ( x , int ( y / 2 ) ) ) NEW_LINE DEDENT DEDENT
x = 2 ; y = 3 NEW_LINE print ( power ( x , y ) ) NEW_LINE
def isLucky ( n ) : NEW_LINE
next_position = n NEW_LINE if isLucky . counter > n : NEW_LINE INDENT return 1 NEW_LINE DEDENT if n % isLucky . counter == 0 : NEW_LINE INDENT return 0 NEW_LINE DEDENT
next_position = next_position - next_position / isLucky . counter NEW_LINE isLucky . counter = isLucky . counter + 1 NEW_LINE return isLucky ( next_position ) NEW_LINE
isLucky . counter = 2 NEW_LINE x = 5 NEW_LINE if isLucky ( x ) : NEW_LINE INDENT print x , " is ▁ a ▁ Lucky ▁ number " NEW_LINE DEDENT else : NEW_LINE INDENT print x , " is ▁ not ▁ a ▁ Lucky ▁ number " NEW_LINE DEDENT
def squareRoot ( n ) : NEW_LINE
x = n NEW_LINE y = 1 NEW_LINE
e = 0.000001 NEW_LINE while ( x - y > e ) : NEW_LINE INDENT x = ( x + y ) / 2 NEW_LINE y = n / x NEW_LINE DEDENT return x NEW_LINE
n = 50 NEW_LINE print ( " Square ▁ root ▁ of " , n , " is " , round ( squareRoot ( n ) , 6 ) ) NEW_LINE
def multiply ( x , y ) : NEW_LINE INDENT if ( y ) : NEW_LINE INDENT return ( x + multiply ( x , y - 1 ) ) ; NEW_LINE DEDENT else : NEW_LINE INDENT return 0 ; NEW_LINE DEDENT DEDENT
def pow ( a , b ) : NEW_LINE INDENT if ( b ) : NEW_LINE INDENT return multiply ( a , pow ( a , b - 1 ) ) ; NEW_LINE DEDENT else : NEW_LINE INDENT return 1 ; NEW_LINE DEDENT DEDENT
print ( pow ( 5 , 3 ) ) ; NEW_LINE
def getAvg ( x , n , sum ) : NEW_LINE INDENT sum = sum + x ; NEW_LINE return float ( sum ) / n ; NEW_LINE DEDENT
def streamAvg ( arr , n ) : NEW_LINE INDENT avg = 0 ; NEW_LINE sum = 0 ; NEW_LINE for i in range ( n ) : NEW_LINE INDENT avg = getAvg ( arr [ i ] , i + 1 , sum ) ; NEW_LINE sum = avg * ( i + 1 ) ; NEW_LINE print ( " Average ▁ of ▁ " , end = " " ) ; NEW_LINE print ( i + 1 , end = " " ) ; NEW_LINE print ( " ▁ numbers ▁ is ▁ " , end = " " ) ; NEW_LINE print ( avg ) ; NEW_LINE DEDENT return ; NEW_LINE DEDENT
arr = [ 10 , 20 , 30 , 40 , 50 , 60 ] ; NEW_LINE n = len ( arr ) ; NEW_LINE streamAvg ( arr , n ) ; NEW_LINE
def count ( n ) : NEW_LINE
if n < 3 : NEW_LINE INDENT return n NEW_LINE DEDENT elif n >= 3 and n < 10 : NEW_LINE INDENT return n - 1 NEW_LINE DEDENT
po = 1 NEW_LINE while n / po > 9 : NEW_LINE INDENT po = po * 10 NEW_LINE DEDENT
msd = n / po NEW_LINE if msd != 3 : NEW_LINE
return count ( msd ) * count ( po - 1 ) + count ( msd ) + count ( n % po ) NEW_LINE else : NEW_LINE
return count ( msd * po - 1 ) NEW_LINE
n = 578 NEW_LINE print count ( n ) NEW_LINE
def printPascal ( n : int ) : NEW_LINE
arr = [ [ 0 for x in range ( n ) ] for y in range ( n ) ] NEW_LINE
for line in range ( 0 , n ) : NEW_LINE
for i in range ( 0 , line + 1 ) : NEW_LINE
if ( i == 0 or i == line ) : NEW_LINE INDENT arr [ line ] [ i ] = 1 NEW_LINE print ( arr [ line ] [ i ] , end = " ▁ " ) NEW_LINE DEDENT
else : NEW_LINE INDENT arr [ line ] [ i ] = ( arr [ line - 1 ] [ i - 1 ] + arr [ line - 1 ] [ i ] ) NEW_LINE print ( arr [ line ] [ i ] , end = " ▁ " ) NEW_LINE DEDENT print ( " " , ▁ end ▁ = ▁ " " ) NEW_LINE
n = 5 NEW_LINE printPascal ( n ) NEW_LINE
def primeFactors ( n ) : NEW_LINE
while n % 2 == 0 : NEW_LINE INDENT print 2 , NEW_LINE n = n / 2 NEW_LINE DEDENT
for i in range ( 3 , int ( math . sqrt ( n ) ) + 1 , 2 ) : NEW_LINE
while n % i == 0 : NEW_LINE INDENT print i , NEW_LINE n = n / i NEW_LINE DEDENT
if n > 2 : NEW_LINE INDENT print n NEW_LINE DEDENT
n = 315 NEW_LINE primeFactors ( n ) NEW_LINE
def printCombination ( arr , n , r ) : NEW_LINE
data = [ 0 ] * r ; NEW_LINE
combinationUtil ( arr , data , 0 , n - 1 , 0 , r ) ; NEW_LINE
def combinationUtil ( arr , data , start , end , index , r ) : NEW_LINE
if ( index == r ) : NEW_LINE INDENT for j in range ( r ) : NEW_LINE INDENT print ( data [ j ] , end = " ▁ " ) ; NEW_LINE DEDENT print ( ) ; NEW_LINE return ; NEW_LINE DEDENT
i = start ; NEW_LINE while ( i <= end and end - i + 1 >= r - index ) : NEW_LINE INDENT data [ index ] = arr [ i ] ; NEW_LINE combinationUtil ( arr , data , i + 1 , end , index + 1 , r ) ; NEW_LINE i += 1 ; NEW_LINE DEDENT
arr = [ 1 , 2 , 3 , 4 , 5 ] ; NEW_LINE r = 3 ; NEW_LINE n = len ( arr ) ; NEW_LINE printCombination ( arr , n , r ) ; NEW_LINE
def findgroups ( arr , n ) : NEW_LINE
c = [ 0 , 0 , 0 ] NEW_LINE
res = 0 NEW_LINE
for i in range ( 0 , n ) : NEW_LINE INDENT c [ arr [ i ] % 3 ] += 1 NEW_LINE DEDENT
res += ( ( c [ 0 ] * ( c [ 0 ] - 1 ) ) >> 1 ) NEW_LINE
res += c [ 1 ] * c [ 2 ] NEW_LINE
res += ( c [ 0 ] * ( c [ 0 ] - 1 ) * ( c [ 0 ] - 2 ) ) / 6 NEW_LINE
res += ( c [ 1 ] * ( c [ 1 ] - 1 ) * ( c [ 1 ] - 2 ) ) / 6 NEW_LINE
res += ( ( c [ 2 ] * ( c [ 2 ] - 1 ) * ( c [ 2 ] - 2 ) ) / 6 ) NEW_LINE
res += c [ 0 ] * c [ 1 ] * c [ 2 ] NEW_LINE
return res NEW_LINE
arr = [ 3 , 6 , 7 , 2 , 9 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " Required ▁ number ▁ of ▁ groups ▁ are " , int ( findgroups ( arr , n ) ) ) NEW_LINE
def swapBits ( x , p1 , p2 , n ) : NEW_LINE
set1 = ( x >> p1 ) & ( ( 1 << n ) - 1 ) NEW_LINE
set2 = ( x >> p2 ) & ( ( 1 << n ) - 1 ) NEW_LINE
xor = ( set1 ^ set2 ) NEW_LINE
xor = ( xor << p1 ) | ( xor << p2 ) NEW_LINE
result = x ^ xor NEW_LINE return result NEW_LINE
res = swapBits ( 28 , 0 , 3 , 2 ) NEW_LINE print ( " Result ▁ = " , res ) NEW_LINE
def Add ( x , y ) : NEW_LINE
while ( y != 0 ) : NEW_LINE
carry = x & y NEW_LINE
x = x ^ y NEW_LINE
y = carry << 1 NEW_LINE return x NEW_LINE
print ( Add ( 15 , 32 ) ) NEW_LINE
def addOne ( x ) : NEW_LINE INDENT m = 1 ; NEW_LINE DEDENT
while ( x & m ) : NEW_LINE INDENT x = x ^ m NEW_LINE m <<= 1 NEW_LINE DEDENT
x = x ^ m NEW_LINE return x NEW_LINE
n = 13 NEW_LINE print addOne ( n ) NEW_LINE
def fun ( n ) : NEW_LINE INDENT return n & ( n - 1 ) NEW_LINE DEDENT
n = 7 NEW_LINE print ( " The ▁ number ▁ after ▁ unsetting ▁ the ▁ rightmost ▁ set ▁ bit " , fun ( n ) ) NEW_LINE
def isPowerOfFour ( n ) : NEW_LINE INDENT if ( n == 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT while ( n != 1 ) : NEW_LINE INDENT if ( n % 4 != 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT n = n // 4 NEW_LINE DEDENT return True NEW_LINE DEDENT
test_no = 64 NEW_LINE if ( isPowerOfFour ( 64 ) ) : NEW_LINE INDENT print ( test_no , ' is ▁ a ▁ power ▁ of ▁ 4' ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( test_no , ' is ▁ not ▁ a ▁ power ▁ of ▁ 4' ) NEW_LINE DEDENT
def nextPowerOf2 ( n ) : NEW_LINE INDENT count = 0 ; NEW_LINE DEDENT
if ( n and not ( n & ( n - 1 ) ) ) : NEW_LINE INDENT return n NEW_LINE DEDENT while ( n != 0 ) : NEW_LINE INDENT n >>= 1 NEW_LINE count += 1 NEW_LINE DEDENT return 1 << count ; NEW_LINE
n = 0 NEW_LINE print ( nextPowerOf2 ( n ) ) NEW_LINE
def isPowerOfTwo ( n ) : NEW_LINE INDENT if ( n == 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT while ( n != 1 ) : NEW_LINE INDENT if ( n % 2 != 0 ) : NEW_LINE INDENT return False NEW_LINE DEDENT n = n // 2 NEW_LINE DEDENT return True NEW_LINE DEDENT
if ( isPowerOfTwo ( 31 ) ) : NEW_LINE INDENT print ( ' Yes ' ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( ' No ' ) NEW_LINE DEDENT if ( isPowerOfTwo ( 64 ) ) : NEW_LINE INDENT print ( ' Yes ' ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( ' No ' ) NEW_LINE DEDENT
import math NEW_LINE def getFirstSetBitPos ( n ) : NEW_LINE INDENT return math . log2 ( n & - n ) + 1 NEW_LINE DEDENT
n = 12 NEW_LINE print ( int ( getFirstSetBitPos ( n ) ) ) NEW_LINE
def isPowerOfTwo ( n ) : NEW_LINE INDENT return ( n and ( not ( n & ( n - 1 ) ) ) ) NEW_LINE DEDENT
def findPosition ( n ) : NEW_LINE INDENT if not isPowerOfTwo ( n ) : NEW_LINE INDENT return - 1 NEW_LINE DEDENT count = 0 NEW_LINE DEDENT
while ( n ) : NEW_LINE INDENT n = n >> 1 NEW_LINE DEDENT
count += 1 NEW_LINE return count NEW_LINE
if __name__ == " _ _ main _ _ " : NEW_LINE INDENT n = 0 NEW_LINE pos = findPosition ( n ) NEW_LINE if pos == - 1 : NEW_LINE INDENT print ( " n ▁ = " , n , " Invalid ▁ number " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " n ▁ = " , n , " Position " , pos ) NEW_LINE DEDENT n = 12 NEW_LINE pos = findPosition ( n ) NEW_LINE if pos == - 1 : NEW_LINE INDENT print ( " n ▁ = " , n , " Invalid ▁ number " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " n ▁ = " , n , " Position " , pos ) NEW_LINE DEDENT n = 128 NEW_LINE pos = findPosition ( n ) NEW_LINE if pos == - 1 : NEW_LINE INDENT print ( " n ▁ = " , n , " Invalid ▁ number " ) NEW_LINE DEDENT else : NEW_LINE INDENT print ( " n ▁ = " , n , " Position " , pos ) NEW_LINE DEDENT DEDENT
x = 10 NEW_LINE y = 5 NEW_LINE
x = x * y NEW_LINE
y = x // y ; NEW_LINE
x = x // y ; NEW_LINE print ( " After ▁ Swapping : ▁ x ▁ = " , x , " ▁ y ▁ = " , y ) ; NEW_LINE
x = 10 NEW_LINE y = 5 NEW_LINE
x = x ^ y ; NEW_LINE
y = x ^ y ; NEW_LINE
x = x ^ y ; NEW_LINE print ( " After ▁ Swapping : ▁ x ▁ = ▁ " , x , " ▁ y ▁ = " , y ) NEW_LINE
def swap ( xp , yp ) : NEW_LINE INDENT xp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] NEW_LINE yp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] NEW_LINE xp [ 0 ] = xp [ 0 ] ^ yp [ 0 ] NEW_LINE DEDENT
x = [ 10 ] NEW_LINE swap ( x , x ) NEW_LINE print ( " After ▁ swap ( & x , ▁ & x ) : ▁ x ▁ = ▁ " , x [ 0 ] ) NEW_LINE
def maxIndexDiff ( arr , n ) : NEW_LINE INDENT maxDiff = - 1 NEW_LINE for i in range ( 0 , n ) : NEW_LINE INDENT j = n - 1 NEW_LINE while ( j > i ) : NEW_LINE INDENT if arr [ j ] > arr [ i ] and maxDiff < ( j - i ) : NEW_LINE INDENT maxDiff = j - i NEW_LINE DEDENT j -= 1 NEW_LINE DEDENT DEDENT return maxDiff NEW_LINE DEDENT
arr = [ 9 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 18 , 0 ] NEW_LINE n = len ( arr ) NEW_LINE maxDiff = maxIndexDiff ( arr , n ) NEW_LINE print ( maxDiff ) NEW_LINE
def findMaximum ( arr , low , high ) : NEW_LINE INDENT max = arr [ low ] NEW_LINE i = low NEW_LINE for i in range ( high + 1 ) : NEW_LINE INDENT if arr [ i ] > max : NEW_LINE INDENT max = arr [ i ] NEW_LINE DEDENT DEDENT return max NEW_LINE DEDENT
arr = [ 1 , 30 , 40 , 50 , 60 , 70 , 23 , 20 ] NEW_LINE n = len ( arr ) NEW_LINE print ( " The ▁ maximum ▁ element ▁ is ▁ % d " % findMaximum ( arr , 0 , n - 1 ) ) NEW_LINE
def printSorted ( arr , start , end ) : NEW_LINE INDENT if start > end : NEW_LINE INDENT return NEW_LINE DEDENT DEDENT
printSorted ( arr , start * 2 + 1 , end ) NEW_LINE
print ( arr [ start ] , end = " ▁ " ) NEW_LINE
printSorted ( arr , start * 2 + 2 , end ) NEW_LINE
if __name__ == ' _ _ main _ _ ' : NEW_LINE INDENT arr = [ 4 , 2 , 5 , 1 , 3 ] NEW_LINE arr_size = len ( arr ) NEW_LINE printSorted ( arr , 0 , arr_size - 1 ) NEW_LINE DEDENT
def search ( mat , n , x ) : NEW_LINE INDENT i = 0 NEW_LINE DEDENT
j = n - 1 NEW_LINE while ( i < n and j >= 0 ) : NEW_LINE INDENT if ( mat [ i ] [ j ] == x ) : NEW_LINE INDENT print ( " n ▁ Found ▁ at ▁ " , i , " , ▁ " , j ) NEW_LINE return 1 NEW_LINE DEDENT if ( mat [ i ] [ j ] > x ) : NEW_LINE INDENT j -= 1 NEW_LINE DEDENT DEDENT
else : NEW_LINE INDENT i += 1 NEW_LINE DEDENT print ( " Element ▁ not ▁ found " ) NEW_LINE
return 0 NEW_LINE
mat = [ [ 10 , 20 , 30 , 40 ] , [ 15 , 25 , 35 , 45 ] , [ 27 , 29 , 37 , 48 ] , [ 32 , 33 , 39 , 50 ] ] NEW_LINE search ( mat , 4 , 29 ) NEW_LINE
N = 4 NEW_LINE
def add ( A , B , C ) : NEW_LINE INDENT for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT C [ i ] [ j ] = A [ i ] [ j ] + B [ i ] [ j ] NEW_LINE DEDENT DEDENT DEDENT
A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] NEW_LINE B = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] NEW_LINE C = A [ : ] [ : ] NEW_LINE add ( A , B , C ) NEW_LINE print ( " Result ▁ matrix ▁ is " ) NEW_LINE for i in range ( N ) : NEW_LINE INDENT for j in range ( N ) : NEW_LINE INDENT print ( C [ i ] [ j ] , " ▁ " , end = ' ' ) NEW_LINE DEDENT print ( ) NEW_LINE DEDENT
