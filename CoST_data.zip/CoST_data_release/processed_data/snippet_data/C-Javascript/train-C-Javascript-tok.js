class Node { constructor ( item ) { this . data = item ; this . left = this . right = null ; } } var root ;
function isFullTree ( node ) {
if ( node == null ) return true ;
if ( node . left == null && node . right == null ) return true ;
if ( ( node . left != null ) && ( node . right != null ) ) return ( isFullTree ( node . left ) && isFullTree ( node . right ) ) ;
return false ; }
root = new Node ( 10 ) ; root . left = new Node ( 20 ) ; root . right = new Node ( 30 ) ; root . left . right = new Node ( 40 ) ; root . left . left = new Node ( 50 ) ; root . right . left = new Node ( 60 ) ; root . left . left . left = new Node ( 80 ) ; root . right . right = new Node ( 70 ) ; root . left . left . right = new Node ( 90 ) ; root . left . right . left = new Node ( 80 ) ; root . left . right . right = new Node ( 90 ) ; root . right . left . left = new Node ( 80 ) ; root . right . left . right = new Node ( 90 ) ; root . right . right . left = new Node ( 80 ) ; root . right . right . right = new Node ( 90 ) ; if ( isFullTree ( root ) ) document . write ( " " ) ; else document . write ( " " ) ;
function areElementsContiguous ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ;
for ( let i = 1 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] > 1 ) return false ; return true ; }
let arr = [ 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ] ; let n = arr . length ; if ( areElementsContiguous ( arr , n ) ) document . write ( " " ) ; else document . write ( " " ) ;
let leftRotate = ( arr , d , n ) => {
if ( d == 0 d == n ) return ;
if ( n - d == d ) { arr = swap ( arr , 0 , n - d , d ) ; return ; }
if ( d < n - d ) { arr = swap ( arr , 0 , n - d , d ) ; leftRotate ( arr , d , n - d ) ; }
else { arr = swap ( arr , 0 , d , n - d ) ; leftRotate ( arr + n - d , 2 * d - n , d ) ; } }
let printArray = ( arr , size ) => { ans = ' ' for ( let i = 0 ; i < size ; i ++ ) ans += arr [ i ] + " " ; document . write ( ans ) }
let swap = ( arr , fi , si , d ) => { for ( let i = 0 ; i < d ; i ++ ) { let temp = arr [ fi + i ] ; arr [ fi + i ] = arr [ si + i ] ; arr [ si + i ] = temp ; } return arr }
arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ; leftRotate ( arr , 2 , 7 ) ; printArray ( arr , 7 ) ;
function leftRotate ( arr , d , n ) { if ( d == 0 d == n ) return ; let i = d ; let j = n - d ; while ( i != j ) {
if ( i < j ) { arr = swap ( arr , d - i , d + j - i , i ) ; j -= i ; }
else { arr = swap ( arr , d - i , d , j ) ; i -= j ; } }
arr = swap ( arr , d - i , d , i ) ; }
function rearrangeNaive ( arr , n ) {
let temp = new Array ( n ) , i ;
for ( i = 0 ; i < n ; i ++ ) temp [ arr [ i ] ] = i ;
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
function printArray ( arr , n ) { let i ; for ( i = 0 ; i < n ; i ++ ) document . write ( " " + arr [ i ] ) ; document . write ( " " ) ; }
let arr = [ 1 , 3 , 0 , 2 ] ; let n = arr . length ; document . write ( " " ) ; printArray ( arr , n ) ; rearrangeNaive ( arr , n ) ; document . write ( " " ) ; printArray ( arr , n ) ;
class Node { constructor ( val ) { this . key = val ; this . left = null ; this . right = null ; } }
function printPostorder ( node ) { if ( node == null ) return ;
printPostorder ( node . left ) ;
printPostorder ( node . right ) ;
document . write ( node . key + " " ) ; }
function printInorder ( node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
document . write ( node . key + " " ) ;
printInorder ( node . right ) ; }
function printPreorder ( node ) { if ( node == null ) return ;
document . write ( node . key + " " ) ;
printPreorder ( node . left ) ;
printPreorder ( node . right ) ; }
root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; document . write ( " " ) ; printPreorder ( root ) ; document . write ( " " ) ; printInorder ( root ) ; document . write ( " " ) ; printPostorder ( root ) ;
function largest ( arr ) { let i ;
let max = arr [ 0 ] ;
for ( i = 1 ; i < arr . length ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
let arr = [ 10 , 324 , 45 , 90 , 9808 ] ; document . write ( " " + largest ( arr ) ) ;
function smallestSubWithSum ( arr , n , x ) {
let min_len = n + 1 ;
for ( let start = 0 ; start < n ; start ++ ) {
let curr_sum = arr [ start ] ;
if ( curr_sum > x ) return 1 ;
for ( let end = start + 1 ; end < n ; end ++ ) {
curr_sum += arr [ end ] ;
if ( curr_sum > x && ( end - start + 1 ) < min_len ) min_len = ( end - start + 1 ) ; } } return min_len ; }
let arr1 = [ 1 , 4 , 45 , 6 , 10 , 19 ] ; let x = 51 ; let n1 = arr1 . length ; let res1 = smallestSubWithSum ( arr1 , n1 , x ) ; ( res1 == n1 + 1 ) ? document . write ( " " ) : document . write ( res1 + " " ) ; let arr2 = [ 1 , 10 , 5 , 2 , 7 ] ; let n2 = arr2 . length ; x = 9 ; let res2 = smallestSubWithSum ( arr2 , n2 , x ) ; ( res2 == n2 + 1 ) ? document . write ( " " ) : document . write ( res2 + " " ) ; let arr3 = [ 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ] ; let n3 = arr3 . length ; x = 280 ; let res3 = smallestSubWithSum ( arr3 , n3 , x ) ; ( res3 == n3 + 1 ) ? document . write ( " " ) : document . write ( res3 + " " ) ;
function insertSorted ( arr , n , key , capacity ) {
if ( n >= capacity ) return n ; arr [ n ] = key ; return ( n + 1 ) ; }
let arr = new Array ( 20 ) ; arr [ 0 ] = 12 ; arr [ 1 ] = 16 ; arr [ 2 ] = 20 ; arr [ 3 ] = 40 ; arr [ 4 ] = 50 ; arr [ 5 ] = 70 ; let capacity = 20 ; let n = 6 ; let i , key = 26 ; document . write ( " " ) ; for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ;
n = insertSorted ( arr , n , key , capacity ) ; document . write ( " " ) ; for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function findElement ( arr , n , key ) { let i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
function deleteElement ( arr , n , key ) {
let pos = findElement ( arr , n , key ) ; if ( pos == - 1 ) { document . write ( " " ) ; return n ; }
let i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
let i ; let arr = [ 10 , 50 , 30 , 40 , 20 ] ; let n = arr . length ; let key = 30 ; document . write ( " " ) ; for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; n = deleteElement ( arr , n , key ) ; document . write ( " " ) ; for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function _binarySearch ( arr , low , high , x ) { if ( high >= low ) { let mid = parseInt ( ( low + high ) / 2 , 10 ) ;
if ( ( mid == 0 x > arr [ mid - 1 ] ) && ( arr [ mid ] == x ) ) return mid ; else if ( x > arr [ mid ] ) return _binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return _binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
function isMajority ( arr , n , x ) {
let i = _binarySearch ( arr , 0 , n - 1 , x ) ;
if ( i == - 1 ) return false ;
if ( ( ( i + parseInt ( n / 2 , 10 ) ) <= ( n - 1 ) ) && arr [ i + parseInt ( n / 2 , 10 ) ] == x ) return true ; else return false ; }
let arr = [ 1 , 2 , 3 , 3 , 3 , 3 , 10 ] ; let n = arr . length ; let x = 3 ; if ( isMajority ( arr , n , x ) == true ) document . write ( x + " " + parseInt ( n / 2 , 10 ) + " " ) ; else document . write ( x + " " + parseInt ( n / 2 , 10 ) + " " ) ;
function isMajorityElement ( arr , n , key ) { if ( arr [ parseInt ( n / 2 , 10 ) ] == key ) return true ; else return false ; }
let arr = [ 1 , 2 , 3 , 3 , 3 , 3 , 10 ] ; let n = arr . length ; let x = 3 ; if ( isMajorityElement ( arr , n , x ) ) document . write ( x + " " + parseInt ( n / 2 , 10 ) + " " ) ; else document . write ( x + " " + " " + parseInt ( n / 2 , 10 ) + " " ) ;
function isPairSum ( A , N , X ) {
var i = 0 ;
var j = N - 1 ; while ( i < j ) {
if ( A [ i ] + A [ j ] == X ) return true ;
else if ( A [ i ] + A [ j ] < X ) i ++ ;
else j -- ; } return false ; }
var arr = [ 3 , 5 , 9 , 2 , 8 , 10 , 11 ] ;
var val = 17 ;
var arrSize = 7 ;
document . write ( isPairSum ( arr , arrSize , val ) ) ;
function interpolationSearch ( arr , lo , hi , x ) { let pos ;
if ( lo <= hi && x >= arr [ lo ] && x <= arr [ hi ] ) {
pos = lo + Math . floor ( ( ( hi - lo ) / ( arr [ hi ] - arr [ lo ] ) ) * ( x - arr [ lo ] ) ) ; ;
if ( arr [ pos ] == x ) { return pos ; }
if ( arr [ pos ] < x ) { return interpolationSearch ( arr , pos + 1 , hi , x ) ; }
if ( arr [ pos ] > x ) { return interpolationSearch ( arr , lo , pos - 1 , x ) ; } } return - 1 ; }
let arr = [ 10 , 12 , 13 , 16 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 33 , 35 , 42 , 47 ] ; let n = arr . length ;
let x = 18 let index = interpolationSearch ( arr , 0 , n - 1 , x ) ;
if ( index != - 1 ) { document . write ( ` ${ index } ` ) } else { document . write ( " " ) ; }
function merge ( arr , l , m , r ) {
var n1 = m - l + 1 ; var n2 = r - m ;
var L = new Array ( n1 ) ; var R = new Array ( n2 ) ;
for ( var i = 0 ; i < n1 ; i ++ ) L [ i ] = arr [ l + i ] ; for ( var j = 0 ; j < n2 ; j ++ ) R [ j ] = arr [ m + 1 + j ] ;
var i = 0 ; var j = 0 ;
var k = l ; while ( i < n1 && j < n2 ) { if ( L [ i ] <= R [ j ] ) { arr [ k ] = L [ i ] ; i ++ ; } else { arr [ k ] = R [ j ] ; j ++ ; } k ++ ; }
while ( i < n1 ) { arr [ k ] = L [ i ] ; i ++ ; k ++ ; }
while ( j < n2 ) { arr [ k ] = R [ j ] ; j ++ ; k ++ ; } }
function mergeSort ( arr , l , r ) { if ( l >= r ) { return ; }
var m = l + parseInt ( ( r - l ) / 2 ) ;
mergeSort ( arr , l , m ) ; mergeSort ( arr , m + 1 , r ) ;
merge ( arr , l , m , r ) ; }
function printArray ( A , size ) { for ( var i = 0 ; i < size ; i ++ ) document . write ( A [ i ] + " " ) ; }
var arr = [ 12 , 11 , 13 , 5 , 6 , 7 ] ; var arr_size = arr . length ; document . write ( " " ) ; printArray ( arr , arr_size ) ; mergeSort ( arr , 0 , arr_size - 1 ) ; document . write ( " " ) ; printArray ( arr , arr_size ) ;
function eggDrop ( n , k ) {
if ( k == 1 k == 0 ) return k ;
if ( n == 1 ) return k ; let min = Number . MAX_VALUE ; let x , res ;
for ( x = 1 ; x <= k ; x ++ ) { res = Math . max ( eggDrop ( n - 1 , x - 1 ) , eggDrop ( n , k - x ) ) ; if ( res < min ) min = res ; } return min + 1 ; }
let n = 2 , k = 10 ; document . write ( " " + " " + n + " " + k + " " + eggDrop ( n , k ) ) ;
let t = new Array ( 9 ) ; for ( var i = 0 ; i < t . length ; i ++ ) { t [ i ] = new Array ( 2 ) ; }
function un_kp ( price , length , Max_len , n ) {
if ( n == 0 Max_len == 0 ) { return 0 ; }
if ( length [ n - 1 ] <= Max_len ) { t [ n ] [ Max_len ] = Math . max ( price [ n - 1 ] + un_kp ( price , length , Max_len - length [ n - 1 ] , n ) , un_kp ( price , length , Max_len , n - 1 ) ) ; }
else { t [ n ] [ Max_len ] = un_kp ( price , length , Max_len , n - 1 ) ; }
return t [ n ] [ Max_len ] ; }
let price = [ 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ] ; let n = price . length ; let length = Array ( n ) . fill ( 0 ) ; for ( let i = 0 ; i < n ; i ++ ) { length [ i ] = i + 1 ; } let Max_len = n ;
document . write ( " " + un_kp ( price , length , n , Max_len ) ) ;
let MAX = Number . MAX_VALUE ;
function printSolution ( p , n ) { let k ; if ( p [ n ] == 1 ) k = 1 ; else k = printSolution ( p , p [ n ] - 1 ) + 1 ; document . write ( " " + " " + k + " " + " " + " " + p [ n ] + " " + " " + " " + n + " " ) ; return k ; }
function solveWordWrap ( l , n , M ) {
let extras = new Array ( n + 1 ) ;
let lc = new Array ( n + 1 ) ; for ( let i = 0 ; i < n + 1 ; i ++ ) { extras [ i ] = new Array ( n + 1 ) ; lc [ i ] = new Array ( n + 1 ) ; for ( let j = 0 ; j < n + 1 ; j ++ ) { extras [ i ] [ j ] = 0 ; lc [ i ] [ j ] = 0 ; } }
let c = new Array ( n + 1 ) ;
let p = new Array ( n + 1 ) ;
for ( let i = 1 ; i <= n ; i ++ ) { extras [ i ] [ i ] = M - l [ i - 1 ] ; for ( let j = i + 1 ; j <= n ; j ++ ) extras [ i ] [ j ] = extras [ i ] [ j - 1 ] - l [ j - 1 ] - 1 ; }
for ( let i = 1 ; i <= n ; i ++ ) { for ( let j = i ; j <= n ; j ++ ) { if ( extras [ i ] [ j ] < 0 ) lc [ i ] [ j ] = MAX ; else if ( j == n && extras [ i ] [ j ] >= 0 ) lc [ i ] [ j ] = 0 ; else lc [ i ] [ j ] = extras [ i ] [ j ] * extras [ i ] [ j ] ; } }
c [ 0 ] = 0 ; for ( let j = 1 ; j <= n ; j ++ ) { c [ j ] = MAX ; for ( let i = 1 ; i <= j ; i ++ ) { if ( c [ i - 1 ] != MAX && lc [ i ] [ j ] != MAX && ( c [ i - 1 ] + lc [ i ] [ j ] < c [ j ] ) ) { c [ j ] = c [ i - 1 ] + lc [ i ] [ j ] ; p [ j ] = i ; } } } printSolution ( p , n ) ; }
let l = [ 3 , 2 , 2 , 5 ] ; let n = l . length ; let M = 6 ; solveWordWrap ( l , n , M ) ;
function sum ( freq , i , j ) { var s = 0 ; for ( var k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
function optCost ( freq , i , j ) {
if ( j < i ) return 0 ;
if ( j == i ) return freq [ i ] ;
var fsum = sum ( freq , i , j ) ;
var min = Number . MAX_SAFE_INTEGER ;
for ( var r = i ; r <= j ; ++ r ) { var cost = optCost ( freq , i , r - 1 ) + optCost ( freq , r + 1 , j ) ; if ( cost < min ) min = cost ; }
return min + fsum ; }
function optimalSearchTree ( keys , freq , n ) {
return optCost ( freq , 0 , n - 1 ) ; }
var keys = [ 10 , 12 , 20 ] ; var freq = [ 34 , 8 , 50 ] ; var n = keys . length ; document . write ( " " + optimalSearchTree ( keys , freq , n ) ) ;
function sum ( freq , i , j ) { var s = 0 ; for ( var k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
function optimalSearchTree ( keys , freq , n ) {
var cost = new Array ( n ) ; for ( var i = 0 ; i < n ; i ++ ) cost [ i ] = new Array ( n ) ;
for ( var i = 0 ; i < n ; i ++ ) cost [ i ] [ i ] = freq [ i ] ;
for ( var L = 2 ; L <= n ; L ++ ) {
for ( var i = 0 ; i <= n - L + 1 ; i ++ ) {
var j = i + L - 1 ; if ( i >= n j >= n ) break cost [ i ] [ j ] = Number . MAX_SAFE_INTEGER ;
for ( var r = i ; r <= j ; r ++ ) {
var c = 0 ; if ( r > i ) c += cost [ i ] [ r - 1 ] if ( r < j ) c += cost [ r + 1 ] [ j ] c += sum ( freq , i , j ) ; if ( c < cost [ i ] [ j ] ) cost [ i ] [ j ] = c ; } } } return cost [ 0 ] [ n - 1 ] ; }
var keys = [ 10 , 12 , 20 ] ; var freq = [ 34 , 8 , 50 ] ; var n = keys . length ; document . write ( " " + optimalSearchTree ( keys , freq , n ) ) ;
function getCount ( keypad , n ) { if ( keypad == null n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
var odd = Array . from ( { length : 10 } , ( _ , i ) => 0 ) ; var even = Array . from ( { length : 10 } , ( _ , i ) => 0 ) ; var i = 0 , j = 0 , useOdd = 0 , totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ )
odd [ i ] = 1 ;
for ( j = 2 ; j <= n ; j ++ ) { useOdd = 1 - useOdd ;
if ( useOdd == 1 ) { even [ 0 ] = odd [ 0 ] + odd [ 8 ] ; even [ 1 ] = odd [ 1 ] + odd [ 2 ] + odd [ 4 ] ; even [ 2 ] = odd [ 2 ] + odd [ 1 ] + odd [ 3 ] + odd [ 5 ] ; even [ 3 ] = odd [ 3 ] + odd [ 2 ] + odd [ 6 ] ; even [ 4 ] = odd [ 4 ] + odd [ 1 ] + odd [ 5 ] + odd [ 7 ] ; even [ 5 ] = odd [ 5 ] + odd [ 2 ] + odd [ 4 ] + odd [ 8 ] + odd [ 6 ] ; even [ 6 ] = odd [ 6 ] + odd [ 3 ] + odd [ 5 ] + odd [ 9 ] ; even [ 7 ] = odd [ 7 ] + odd [ 4 ] + odd [ 8 ] ; even [ 8 ] = odd [ 8 ] + odd [ 0 ] + odd [ 5 ] + odd [ 7 ] + odd [ 9 ] ; even [ 9 ] = odd [ 9 ] + odd [ 6 ] + odd [ 8 ] ; } else { odd [ 0 ] = even [ 0 ] + even [ 8 ] ; odd [ 1 ] = even [ 1 ] + even [ 2 ] + even [ 4 ] ; odd [ 2 ] = even [ 2 ] + even [ 1 ] + even [ 3 ] + even [ 5 ] ; odd [ 3 ] = even [ 3 ] + even [ 2 ] + even [ 6 ] ; odd [ 4 ] = even [ 4 ] + even [ 1 ] + even [ 5 ] + even [ 7 ] ; odd [ 5 ] = even [ 5 ] + even [ 2 ] + even [ 4 ] + even [ 8 ] + even [ 6 ] ; odd [ 6 ] = even [ 6 ] + even [ 3 ] + even [ 5 ] + even [ 9 ] ; odd [ 7 ] = even [ 7 ] + even [ 4 ] + even [ 8 ] ; odd [ 8 ] = even [ 8 ] + even [ 0 ] + even [ 5 ] + even [ 7 ] + even [ 9 ] ; odd [ 9 ] = even [ 9 ] + even [ 6 ] + even [ 8 ] ; } }
totalCount = 0 ; if ( useOdd == 1 ) { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += even [ i ] ; } else { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += odd [ i ] ; } return totalCount ; }
var keypad = [ [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] ] ; document . write ( " " + 1 + " " + getCount ( keypad , 1 ) ) ; document . write ( " " + 2 + " " + getCount ( keypad , 2 ) ) ; document . write ( " " + 3 + " " + getCount ( keypad , 3 ) ) ; document . write ( " " + 4 + " " + getCount ( keypad , 4 ) ) ; document . write ( " " + 5 + " " + getCount ( keypad , 5 ) ) ;
function findoptimal ( N ) {
if ( N <= 6 ) return N ;
let screen = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { screen [ i ] = 0 ; }
let b ;
let n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = 0 ;
for ( b = n - 3 ; b >= 1 ; b -- ) {
let curr = ( n - b - 1 ) * screen [ b - 1 ] ; if ( curr > screen [ n - 1 ] ) screen [ n - 1 ] = curr ; } } return screen [ N - 1 ] ; }
let N ;
for ( N = 1 ; N <= 20 ; N ++ ) document . write ( " " + N + " " + findoptimal ( N ) + " " ) ;
function power ( x , y ) { var temp ; if ( y == 0 ) return 1 ; temp = power ( x , y / 2 ) ; if ( y % 2 == 0 ) return temp * temp ; else return x * temp * temp ; }
function findCeil ( arr , r , l , h ) { let mid ; while ( l < h ) {
mid = l + ( ( h - l ) >> 1 ) ; ( r > arr [ mid ] ) ? ( l = mid + 1 ) : ( h = mid ) ; } return ( arr [ l ] >= r ) ? l : - 1 ; }
function myRand ( arr , freq , n ) {
let prefix = [ ] ; let i ; prefix [ 0 ] = freq [ 0 ] ; for ( i = 1 ; i < n ; ++ i ) prefix [ i ] = prefix [ i - 1 ] + freq [ i ] ;
let r = Math . floor ( ( Math . random ( ) * prefix [ n - 1 ] ) ) + 1 ;
let indexc = findCeil ( prefix , r , 0 , n - 1 ) ; return arr [ indexc ] ; }
let arr = [ 1 , 2 , 3 , 4 ] ; let freq = [ 10 , 5 , 20 , 100 ] ; let i ; let n = arr . length ;
for ( i = 0 ; i < 5 ; i ++ ) document . write ( myRand ( arr , freq , n ) ) ;
function Add ( x , y ) { if ( y == 0 ) return x ; else return Add ( x ^ y , ( x & y ) << 1 ) ; }
let CHAR_BIT = 8 ;
function min ( x , y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( 32 * CHAR_BIT - 1 ) ) ) }
function smallest ( x , y , z ) { return Math . min ( x , Math . min ( y , z ) ) ; }
let x = 12 , y = 15 , z = 5 ; document . write ( " " + smallest ( x , y , z ) ) ;
function smallest ( x , y , z ) {
if ( ! ( y / x ) ) return ( ! ( y / z ) ) ? y : z ; return ( ! ( x / z ) ) ? x : z ; }
let x = 78 , y = 88 , z = 68 ; document . write ( " " + smallest ( x , y , z ) ) ;
function changeToZero ( a ) { a [ a [ 1 ] ] = a [ 1 - a [ 1 ] ] ; }
let arr ; arr = [ ] ; arr [ 0 ] = 1 ; arr [ 1 ] = 0 ; changeToZero ( arr ) ; document . write ( " " + arr [ 0 ] + " " ) ; document . write ( " " + arr [ 1 ] ) ;
function isPowerOfFour ( n ) { return n != 0 && ( ( n & ( n - 1 ) ) == 0 ) && ! ( n & 0xAAAAAAAA ) ; }
test_no = 64 ; if ( isPowerOfFour ( test_no ) ) document . write ( test_no + " " ) ; else document . write ( test_no + " " ) ;
var CHAR_BIT = 4 ; var INT_BIT = 8 ;
function min ( x , y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( INT_BIT * CHAR_BIT - 1 ) ) ) ; }
function max ( x , y ) { return x - ( ( x - y ) & ( ( x - y ) >> ( INT_BIT * CHAR_BIT - 1 ) ) ) ; }
var x = 15 ; var y = 6 ; document . write ( " " + x + " " + y + " " + min ( x , y ) + " " ) ; document . write ( " " + x + " " + y + " " + max ( x , y ) ) ;
function countSetBits ( N ) { var count = 0 ;
for ( i = 0 ; i < 4 * 8 ; i ++ ) { if ( ( N & ( 1 << i ) ) != 0 ) count ++ ; } return count ; }
var N = 15 ; document . write ( countSetBits ( N ) ) ;
function bin ( n ) { let i ; document . write ( " " ) ; for ( i = 1 << 30 ; i > 0 ; i = Math . floor ( i / 2 ) ) { if ( ( n & i ) != 0 ) { document . write ( " " ) ; } else { document . write ( " " ) ; } } }
bin ( 7 ) ; document . write ( " " ) ; bin ( 4 ) ;
function constructLowerArray ( arr , countSmaller , n ) { let i , j ;
for ( i = 0 ; i < n ; i ++ ) countSmaller [ i ] = 0 ; for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < arr [ i ] ) countSmaller [ i ] ++ ; } } }
function printArray ( arr , size ) { let i ; for ( i = 0 ; i < size ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; }
let arr = [ 12 , 10 , 5 , 4 , 2 , 20 , 6 , 1 , 0 , 2 ] ; let n = arr . length ; let low = new Array ( n ) ; constructLowerArray ( arr , low , n ) ; printArray ( low , n ) ;
function segregate ( arr , size ) { let j = 0 , i ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] <= 0 ) { let temp ; temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ;
j ++ ; } } return j ; }
function findMissingPositive ( arr , size ) { let i ;
for ( i = 0 ; i < size ; i ++ ) { let x = Math . abs ( arr [ i ] ) ; if ( x - 1 < size && arr [ x - 1 ] > 0 ) arr [ x - 1 ] = - arr [ x - 1 ] ; }
for ( i = 0 ; i < size ; i ++ ) if ( arr [ i ] > 0 )
return i + 1 ; return size + 1 ; }
function findMissing ( arr , size ) {
let shift = segregate ( arr , size ) ; let arr2 = new Array ( size - shift ) ; let j = 0 ; for ( let i = shift ; i < size ; i ++ ) { arr2 [ j ] = arr [ i ] ; j ++ ; }
return findMissingPositive ( arr2 , j ) ; }
let arr = [ 0 , 10 , 2 , - 10 , - 20 ] ; let arr_size = arr . length ; let missing = findMissing ( arr , arr_size ) ; document . write ( " " + missing ) ;
function minDistance ( arr , n ) { let maximum_element = arr [ 0 ] ; let min_dis = n ; let index = 0 ; for ( let i = 1 ; i < n ; i ++ ) {
if ( maximum_element == arr [ i ] ) { min_dis = Math . min ( min_dis , ( i - index ) ) ; index = i ; }
else if ( maximum_element < arr [ i ] ) { maximum_element = arr [ i ] ; min_dis = n ; index = i ; }
else continue ; } return min_dis ; }
let arr = [ 6 , 3 , 1 , 3 , 6 , 4 , 6 ] ; let n = arr . length ; document . write ( " " + minDistance ( arr , n ) ) ;
function push ( new_data ) {
var new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function insertAfter ( prev_node , new_data ) {
if ( prev_node == null ) { document . write ( " " ) ; return ; }
var new_node = new Node ( new_data ) ;
new_node . next = prev_node . next ;
prev_node . next = new_node ; }
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
function push ( new_data ) {
var new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function search ( head , x ) {
if ( head == null ) return false ;
if ( head . data == x ) return true ;
return search ( head . next , x ) ; }
push ( 10 ) ; push ( 30 ) ; push ( 11 ) ; push ( 21 ) ; push ( 14 ) ; if ( search ( head , 21 ) ) document . write ( " " ) ; else document . write ( " " ) ;
function deleteAlt ( head ) { if ( head == null ) return ; var node = head . next ; if ( node == null ) return ;
head . next = node . next ;
head . next = deleteAlt ( head . next ) ; }
function AlternatingSplit ( source , aRef , bRef ) { var aDummy = new Node ( ) ; var aTail = aDummy ;
var bDummy = new Node ( ) ; var bTail = bDummy ;
var current = source ; aDummy . next = null ; bDummy . next = null ; while ( current != null ) { MoveNode ( ( aTail . next ) , current ) ;
aTail = aTail . next ;
if ( current != null ) { MoveNode ( ( bTail . next ) , current ) ; bTail = bTail . next ; } } aRef = aDummy . next ; bRef = bDummy . next ; }
function areIdenticalRecur ( a , b ) {
if ( a == null && b == null ) return true ;
if ( a != null && b != null ) return ( a . data == b . data ) && areIdenticalRecur ( a . next , b . next ) ;
return false ; }
class Node { constructor ( val ) { this . data = val ; this . next = null ; } } function sortList ( ) {
var count = [ 0 , 0 , 0 ] ; var ptr = head ;
while ( ptr != null ) { count [ ptr . data ] ++ ; ptr = ptr . next ; } var i = 0 ; ptr = head ;
while ( ptr != null ) { if ( count [ i ] == 0 ) i ++ ; else { ptr . data = i ; -- count [ i ] ; ptr = ptr . next ; } } }
function push ( new_data ) {
var new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function printList ( ) { var temp = head ; while ( temp != null ) { document . write ( temp . data + " " ) ; temp = temp . next ; } document . write ( " " ) ; }
push ( 0 ) ; push ( 1 ) ; push ( 0 ) ; push ( 2 ) ; push ( 1 ) ; push ( 1 ) ; push ( 2 ) ; push ( 1 ) ; push ( 2 ) ; document . write ( " " ) ; printList ( ) ; sortList ( ) ; document . write ( " " ) ; printList ( ) ;
class List { constructor ( ) { this . data = 0 ; this . next = null ; this . child = null ; } }
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function newNode ( key ) { var temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
function rearrangeEvenOdd ( head ) {
if ( head == null ) return null ;
var odd = head ; var even = head . next ;
var evenFirst = even ; while ( 1 == 1 ) {
if ( odd == null || even == null || ( even . next ) == null ) { odd . next = evenFirst ; break ; }
odd . next = even . next ; odd = even . next ;
if ( odd . next == null ) { even . next = null ; odd . next = evenFirst ; break ; }
even . next = odd . next ; even = odd . next ; } return head ; }
function printlist ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } document . write ( " " ) ; }
var head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; document . write ( " " ) ; printlist ( head ) ; head = rearrangeEvenOdd ( head ) ; document . write ( " " ) ; printlist ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function deleteLast ( head , x ) { var temp = head , ptr = null ; while ( temp != null ) {
if ( temp . data == x ) ptr = temp ; temp = temp . next ; }
if ( ptr != null && ptr . next == null ) { temp = head ; while ( temp . next != ptr ) temp = temp . next ; temp . next = null ; }
if ( ptr != null && ptr . next != null ) { ptr . data = ptr . next . data ; temp = ptr . next ; ptr . next = ptr . next . next ; } }
function newNode ( x ) { var node = new Node ( ) ; node . data = x ; node . next = null ; return node ; }
function display ( head ) { var temp = head ; if ( head == null ) { document . write ( " " ) ; return ; } while ( temp != null ) { document . write ( temp . data + " " ) ; temp = temp . next ; } document . write ( " " ) ; }
var head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; head . next . next . next . next . next = newNode ( 4 ) ; head . next . next . next . next . next . next = newNode ( 4 ) ; document . write ( " " ) ; display ( head ) ; deleteLast ( head , 4 ) ; document . write ( " " ) ; display ( head ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } }
function LinkedListLength ( head ) { while ( head != null && head . next != null ) { head = head . next . next ; } if ( head == null ) return 0 ; return 1 ; }
function push ( head , info ) {
node = new Node ( ) ;
node . data = info ;
node . next = ( head ) ;
( head ) = node ; }
head = null ;
push ( head , 4 ) ; push ( head , 5 ) ; push ( head , 7 ) ; push ( head , 2 ) ; push ( head , 9 ) ; push ( head , 6 ) ; push ( head , 1 ) ; push ( head , 2 ) ; push ( head , 0 ) ; push ( head , 5 ) ; push ( head , 5 ) ; var check = LinkedListLength ( head ) ;
if ( check == 0 ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function SortedMerge ( a , b ) { let result = null ;
let lastPtrRef = result ; while ( 1 ) { if ( a == null ) { lastPtrRef = b ; break ; } else if ( b == null ) { lastPtrRef = a ; break ; } if ( a . data <= b . data ) { MoveNode ( lastPtrRef , a ) ; } else { MoveNode ( lastPtrRef , b ) ; }
lastPtrRef = ( ( lastPtrRef ) . next ) ; } return ( result ) ; }
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } var tail ;
function rotateHelper ( blockHead , blockTail , d , k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { var temp = blockHead ; for ( i = 1 ; temp . next . next != null && i < k - 1 ; i ++ ) temp = temp . next ; blockTail . next = blockHead ; tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , k ) ; }
if ( d < 0 ) { blockTail . next = blockHead ; tail = blockHead ; return rotateHelper ( blockHead . next , blockHead , d + 1 , k ) ; } return blockHead ; }
function rotateByBlocks ( head , k , d ) {
if ( head == null head . next == null ) return head ;
if ( d == 0 ) return head ; var temp = head ; tail = null ;
var i ; for ( i = 1 ; temp . next != null && i < k ; i ++ ) temp = temp . next ;
var nextBlock = temp . next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , i ) ; else head = rotateHelper ( head , temp , d % k , k ) ;
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
function push ( head_ref , new_data ) { var new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } }
var head = null ;
for ( i = 9 ; i > 0 ; i -= 1 ) head = push ( head , i ) ; document . write ( " " ) ; printList ( head ) ;
var k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( val ) { this . data = val ; this . next = null ; } } var head ;
function setMiddleHead ( ) { if ( head == null ) return ;
one_node = head ;
two_node = head ;
prev = null ; while ( two_node != null && two_node . next != null ) {
prev = one_node ;
two_node = two_node . next . next ;
one_node = one_node . next ; }
prev . next = prev . next . next ; one_node . next = head ; head = one_node ; }
function push ( new_data ) {
new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function printList ( ptr ) { while ( ptr != null ) { document . write ( ptr . data + " " ) ; ptr = ptr . next ; } document . write ( " " ) ; }
head = null ; var i ; for ( i = 5 ; i > 0 ; i -- ) push ( i ) ; document . write ( " " ) ; printList ( head ) ; setMiddleHead ( ) ; document . write ( " " ) ; printList ( head ) ;
function InsertAfter ( prev_Node , new_data ) {
if ( prev_Node == null ) { document . write ( " " ) ; return ; }
let new_node = new Node ( new_data ) ;
new_node . next = prev_Node . next ;
prev_Node . next = new_node ;
new_node . prev = prev_Node ;
if ( new_node . next != null ) new_node . next . prev = new_node ; }
class Node { constructor ( item ) { this . data = item ; this . left = null ; this . right = null ; } } var root = null ; function printKDistant ( node , k ) { if ( node == null k < 0 ) { return ; } if ( k == 0 ) { document . write ( node . data + " " ) ; return ; } printKDistant ( node . left , k - 1 ) ; printKDistant ( node . right , k - 1 ) ; }
root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 8 ) ; printKDistant ( root , 2 ) ;
let COUNT = 10 ;
class Node {
constructor ( data ) { this . data = data ; this . left = null ; this . right = null ; } }
function print2DUtil ( root , space ) {
if ( root == null ) return ;
space += COUNT ;
print2DUtil ( root . right , space ) ;
document . write ( " " ) ; for ( let i = COUNT ; i < space ; i ++ ) document . write ( " " ) ; document . write ( root . data + " " ) ;
print2DUtil ( root . left , space ) ; }
function print2D ( root ) {
print2DUtil ( root , 0 ) ; }
let root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; root . left . left . left = new Node ( 8 ) ; root . left . left . right = new Node ( 9 ) ; root . left . right . left = new Node ( 10 ) ; root . left . right . right = new Node ( 11 ) ; root . right . left . left = new Node ( 12 ) ; root . right . left . right = new Node ( 13 ) ; root . right . right . left = new Node ( 14 ) ; root . right . right . right = new Node ( 15 ) ; print2D ( root ) ;
class Node { constructor ( item ) { this . data = item ; this . left = null ; this . right = null ; } }
function leftViewUtil ( node , level ) {
if ( node == null ) { return ; }
if ( max_level < level ) { document . write ( " " + node . data ) ; max_level = level ; }
leftViewUtil ( node . left , level + 1 ) ; leftViewUtil ( node . right , level + 1 ) ; }
function leftView ( ) { leftViewUtil ( root , 1 ) ; }
root = new Node ( 12 ) ; root . left = new Node ( 10 ) ; root . right = new Node ( 30 ) ; root . right . left = new Node ( 25 ) ; root . right . right = new Node ( 40 ) ; leftView ( ) ;
function cntRotations ( s , n ) { let lh = 0 , rh = 0 , i , ans = 0 ;
for ( i = 0 ; i < parseInt ( n / 2 , 10 ) ; ++ i ) if ( s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' ) { lh ++ ; }
for ( i = parseInt ( n / 2 , 10 ) ; i < n ; ++ i ) if ( s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' s [ i ] == ' ' ) { rh ++ ; }
if ( lh > rh ) ans ++ ;
for ( i = 1 ; i < n ; ++ i ) { if ( s [ i - 1 ] == ' ' s [ i - 1 ] == ' ' s [ i - 1 ] == ' ' s [ i - 1 ] == ' ' s [ i - 1 ] == ' ' ) { rh ++ ; lh -- ; } if ( s [ ( i - 1 + n / 2 ) % n ] == ' ' || s [ ( i - 1 + n / 2 ) % n ] == ' ' || s [ ( i - 1 + n / 2 ) % n ] == ' ' || s [ ( i - 1 + n / 2 ) % n ] == ' ' || s [ ( i - 1 + n / 2 ) % n ] == ' ' ) { rh -- ; lh ++ ; } if ( lh > rh ) ans ++ ; }
return ans ; }
let s = [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] ; let n = s . length ;
document . write ( cntRotations ( s , n ) ) ;
class Node { constructor ( ) { this . data = 0 ; this . next = null ; } } var tail ;
function rotateHelper ( blockHead , blockTail , d , k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { var temp = blockHead ; for ( i = 1 ; temp . next . next != null && i < k - 1 ; i ++ ) temp = temp . next ; blockTail . next = blockHead ; tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , k ) ; }
if ( d < 0 ) { blockTail . next = blockHead ; tail = blockHead ; return rotateHelper ( blockHead . next , blockHead , d + 1 , k ) ; } return blockHead ; }
function rotateByBlocks ( head , k , d ) {
if ( head == null head . next == null ) return head ;
if ( d == 0 ) return head ; var temp = head ; tail = null ;
var i ; for ( i = 1 ; temp . next != null && i < k ; i ++ ) temp = temp . next ;
var nextBlock = temp . next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , i ) ; else head = rotateHelper ( head , temp , d % k , k ) ;
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
function push ( head_ref , new_data ) { var new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . next ; } }
var head = null ;
for ( i = 9 ; i > 0 ; i -= 1 ) head = push ( head , i ) ; document . write ( " " ) ; printList ( head ) ;
var k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; document . write ( " " ) ; printList ( head ) ;
function DeleteFirst ( head ) { previous = head , firstNode = head ;
if ( head == null ) { document . write ( " " ) ; return ; }
if ( previous . next == previous ) { head = null ; return ; }
while ( previous . next != head ) { previous = previous . next ; }
previous . next = firstNode . next ;
head = previous . next ; return ; }
function DeleteLast ( head ) { let current = head , temp = head , previous = null ;
if ( head == null ) { document . write ( " " ) ; return null ; }
if ( current . next == current ) { head = null ; return null ; }
while ( current . next != head ) { previous = current ; current = current . next ; } previous . next = current . next ; head = previous . next ; return head ; }
class Node { constructor ( item ) { this . data = item ; this . left = this . right = null ; } } var root ;
function printInorder ( node ) { if ( node != null ) { printInorder ( node . left ) ; document . write ( node . data + " " ) ; printInorder ( node . right ) ; } }
function RemoveHalfNodes ( node ) { if ( node == null ) return null ; node . left = RemoveHalfNodes ( node . left ) ; node . right = RemoveHalfNodes ( node . right ) ; if ( node . left == null && node . right == null ) return node ;
if ( node . left == null ) { new_root = node . right ; return new_root ; }
if ( node . right == null ) { new_root = node . left ; return new_root ; } return node ; }
NewRoot = null ; root = new Node ( 2 ) ; root . left = new Node ( 7 ) ; root . right = new Node ( 5 ) ; root . left . right = new Node ( 6 ) ; root . left . right . left = new Node ( 1 ) ; root . left . right . right = new Node ( 11 ) ; root . right . right = new Node ( 9 ) ; root . right . right . left = new Node ( 4 ) ; document . write ( " " ) ; printInorder ( root ) ; NewRoot = RemoveHalfNodes ( root ) ; document . write ( " " ) ; printInorder ( NewRoot ) ; script
class Node { constructor ( val ) { this . data = val ; this . left = null ; this . right = null ; } }
function extractLeafList ( root ) { if ( root == null ) return null ; if ( root . left == null && root . right == null ) { if ( head == null ) { head = root ; prev = root ; } else { prev . right = root ; root . left = prev ; prev = root ; } return null ; } root . left = extractLeafList ( root . left ) ; root . right = extractLeafList ( root . right ) ; return root ; }
function inorder ( node ) { if ( node == null ) return ; inorder ( node . left ) ; document . write ( node . data + " " ) ; inorder ( node . right ) ; }
function printDLL ( head ) { var last = null ; while ( head != null ) { document . write ( head . data + " " ) ; last = head ; head = head . right ; } }
root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . right = new Node ( 6 ) ; root . left . left . left = new Node ( 7 ) ; root . left . left . right = new Node ( 8 ) ; root . right . right . left = new Node ( 9 ) ; root . right . right . right = new Node ( 10 ) ; document . write ( " " ) ; inorder ( root ) ; extractLeafList ( root ) ; document . write ( " " ) ; document . write ( " " ) ; printDLL ( head ) ; document . write ( " " ) ; document . write ( " " ) ; inorder ( root ) ;
let N = 8 ;
function isSafe ( x , y , sol ) { return ( x >= 0 && x < N && y >= 0 && y < N && sol [ x ] [ y ] == - 1 ) ; }
function printSolution ( sol ) { for ( let x = 0 ; x < N ; x ++ ) { for ( let y = 0 ; y < N ; y ++ ) document . write ( sol [ x ] [ y ] + " " ) ; document . write ( " " ) ; } }
function solveKT ( ) { let sol = new Array ( 8 ) ; for ( var i = 0 ; i < sol . length ; i ++ ) { sol [ i ] = new Array ( 2 ) ; }
for ( let x = 0 ; x < N ; x ++ ) for ( let y = 0 ; y < N ; y ++ ) sol [ x ] [ y ] = - 1 ;
let xMove = [ 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 ] ; let yMove = [ 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 ] ;
sol [ 0 ] [ 0 ] = 0 ;
if ( ! solveKTUtil ( 0 , 0 , 1 , sol , xMove , yMove ) ) { document . write ( " " ) ; return false ; } else printSolution ( sol ) ; return true ; }
function solveKTUtil ( x , y , movei , sol , xMove , yMove ) { let k , next_x , next_y ; if ( movei == N * N ) return true ;
for ( k = 0 ; k < 8 ; k ++ ) { next_x = x + xMove [ k ] ; next_y = y + yMove [ k ] ; if ( isSafe ( next_x , next_y , sol ) ) { sol [ next_x ] [ next_y ] = movei ; if ( solveKTUtil ( next_x , next_y , movei + 1 , sol , xMove , yMove ) ) return true ; else
sol [ next_x ] [ next_y ] = - 1 ; } } return false ; }
solveKT ( ) ;
let V = 4 ;
function printSolution ( color ) { document . write ( " " + " " ) ; for ( let i = 0 ; i < V ; i ++ ) document . write ( " " + color [ i ] ) ; document . write ( " " ) ; }
function isSafe ( graph , color ) {
for ( let i = 0 ; i < V ; i ++ ) for ( let j = i + 1 ; j < V ; j ++ ) if ( graph [ i ] [ j ] && color [ j ] == color [ i ] ) return false ; return true ; }
function graphColoring ( graph , m , i , color ) {
if ( i == V ) {
if ( isSafe ( graph , color ) ) {
printSolution ( color ) ; return true ; } return false ; }
for ( let j = 1 ; j <= m ; j ++ ) { color [ i ] = j ;
if ( graphColoring ( graph , m , i + 1 , color ) ) return true ; color [ i ] = 0 ; } return false ; }
let graph = [ [ false , true , true , true ] , [ true , false , true , false ] , [ true , true , false , true ] , [ true , false , true , false ] ] ;
let m = 3 ;
let color = new Array ( V ) ; for ( let i = 0 ; i < V ; i ++ ) color [ i ] = 0 ; if ( ! graphColoring ( graph , m , 0 , color ) ) document . write ( " " ) ;
function push ( new_data ) {
var new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function insertAfter ( prev_node , new_data ) {
if ( prev_node == null ) { document . write ( " " ) ; return ; }
var new_node = new Node ( new_data ) ;
new_node . next = prev_node . next ;
prev_node . next = new_node ; }
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
function isPalindrome ( head ) { slow_ptr = head ; fast_ptr = head ; var prev_of_slow_ptr = head ;
var midnode = null ;
var res = true ; if ( head != null && head . next != null ) {
while ( fast_ptr != null && fast_ptr . next != null ) { fast_ptr = fast_ptr . next . next ;
prev_of_slow_ptr = slow_ptr ; slow_ptr = slow_ptr . next ; }
if ( fast_ptr != null ) { midnode = slow_ptr ; slow_ptr = slow_ptr . next ; }
second_half = slow_ptr ;
prev_of_slow_ptr . next = null ;
reverse ( ) ;
res = compareLists ( head , second_half ) ;
reverse ( ) ; if ( midnode != null ) {
prev_of_slow_ptr . next = midnode ; midnode . next = second_half ; } else prev_of_slow_ptr . next = second_half ; } return res ; }
function reverse ( ) { var prev = null ; var current = second_half ; var next ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } second_half = prev ; }
function compareLists ( head1 , head2 ) { var temp1 = head1 ; var temp2 = head2 ; while ( temp1 != null && temp2 != null ) { if ( temp1 . data == temp2 . data ) { temp1 = temp1 . next ; temp2 = temp2 . next ; } else return false ; }
if ( temp1 == null && temp2 == null ) return true ;
return false ; }
function push ( new_data ) {
var new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
function printList ( ptr ) { while ( ptr != null ) { document . write ( ptr . data + " " ) ; ptr = ptr . next ; } document . write ( " " ) ; }
var str = [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] ; var string = str . toString ( ) ; for ( i = 0 ; i < 7 ; i ++ ) { push ( str [ i ] ) ; printList ( head ) ; if ( isPalindrome ( head ) != false ) { document . write ( " " ) ; document . write ( " " ) ; } else { document . write ( " " ) ; document . write ( " " ) ; } }
class Node { constructor ( val ) { this . data = val ; this . next = null ; } }
function swapNodes ( x , y ) {
if ( x == y ) return ;
var prevX = null , currX = head ; while ( currX != null && currX . data != x ) { prevX = currX ; currX = currX . next ; }
var prevY = null , currY = head ; while ( currY != null && currY . data != y ) { prevY = currY ; currY = currY . next ; }
if ( currX == null currY == null ) return ;
if ( prevX != null ) prevX . next = currY ;
else head = currY ;
if ( prevY != null ) prevY . next = currX ;
else head = currX ;
var temp = currX . next ; currX . next = currY . next ; currY . next = temp ; }
function push ( new_data ) {
var new_Node = new Node ( new_data ) ;
new_Node . next = head ;
head = new_Node ; }
function printList ( ) { var tNode = head ; while ( tNode != null ) { document . write ( tNode . data + " " ) ; tNode = tNode . next ; } }
push ( 7 ) ; push ( 6 ) ; push ( 5 ) ; push ( 4 ) ; push ( 3 ) ; push ( 2 ) ; push ( 1 ) ; document . write ( " " ) ; printList ( ) ; swapNodes ( 4 , 3 ) ; document . write ( " " ) ; printList ( ) ;
class Node { constructor ( ) { this . info = 0 ; this . prev = null ; this . next = null ; } } var head , tail ;
function nodeInsetail ( key ) { p = new Node ( ) ; p . info = key ; p . next = null ;
if ( head == null ) { head = p ; tail = p ; head . prev = null ; return ; }
if ( p . info < head . info ) { p . prev = null ; head . prev = p ; p . next = head ; head = p ; return ; }
if ( p . info > tail . info ) { p . prev = tail ; tail . next = p ; tail = p ; return ; }
temp = head . next ; while ( temp . info < p . info ) temp = temp . next ;
( temp . prev ) . next = p ; p . prev = temp . prev ; temp . prev = p ; p . next = temp ; }
function printList ( temp ) { while ( temp != null ) { document . write ( temp . info + " " ) ; temp = temp . next ; } }
head = tail = null ; nodeInsetail ( 30 ) ; nodeInsetail ( 50 ) ; nodeInsetail ( 90 ) ; nodeInsetail ( 10 ) ; nodeInsetail ( 40 ) ; nodeInsetail ( 110 ) ; nodeInsetail ( 60 ) ; nodeInsetail ( 95 ) ; nodeInsetail ( 23 ) ; document . write ( " " ) ; printList ( head ) ;
class Node { constructor ( item ) { this . data = item ; this . next = null ; } }
class Node { constructor ( val ) { this . data = val ; this . left = null ; this . right = null ; this . parent = null ; } } var head ;
function insert ( node , data ) {
if ( node == null ) { return ( new Node ( data ) ) ; } else { var temp = null ;
if ( data <= node . data ) { temp = insert ( node . left , data ) ; node . left = temp ; temp . parent = node ; } else { temp = insert ( node . right , data ) ; node . right = temp ; temp . parent = node ; }
return node ; } } function inOrderSuccessor ( root , n ) {
if ( n . right != null ) { return minValue ( n . right ) ; }
var p = n . parent ; while ( p != null && n == p . right ) { n = p ; p = p . parent ; } return p ; }
function minValue ( node ) { var current = node ;
while ( current . left != null ) { current = current . left ; } return current ; }
var root = null , temp = null , suc = null , min = null ; root = insert ( root , 20 ) ; root = insert ( root , 8 ) ; root = insert ( root , 22 ) ; root = insert ( root , 4 ) ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 14 ) ; temp = root . left . right . right ; suc = inOrderSuccessor ( root , temp ) ; if ( suc != null ) { document . write ( " " + temp . data + " " + suc . data ) ; } else { document . write ( " " ) ; }
class node { constructor ( val ) { this . key = val ; this . left = null ; this . right = null ; } } var head ; var tail ;
function convertBSTtoDLL ( root ) {
if ( root == null ) return ;
if ( root . left != null ) convertBSTtoDLL ( root . left ) ;
root . left = tail ;
if ( tail != null ) ( tail ) . right = root ; else head = root ;
tail = root ;
if ( root . right != null ) convertBSTtoDLL ( root . right ) ; }
function isPresentInDLL ( head , tail , sum ) { while ( head != tail ) { var curr = head . key + tail . key ; if ( curr == sum ) return true ; else if ( curr > sum ) tail = tail . left ; else head = head . right ; } return false ; }
function isTripletPresent ( root ) {
if ( root == null ) return false ;
head = null ; tail = null ; convertBSTtoDLL ( root ) ;
while ( ( head . right != tail ) && ( head . key < 0 ) ) {
if ( isPresentInDLL ( head . right , tail , - 1 * head . key ) ) return true ; else head = head . right ; }
return false ; }
function newNode ( num ) { var temp = new node ( ) ; temp . key = num ; temp . left = temp . right = null ; return temp ; }
function insert ( root , key ) { if ( root == null ) return newNode ( key ) ; if ( root . key > key ) root . left = insert ( root . left , key ) ; else root . right = insert ( root . right , key ) ; return root ; }
var root = null ; root = insert ( root , 6 ) ; root = insert ( root , - 13 ) ; root = insert ( root , 14 ) ; root = insert ( root , - 8 ) ; root = insert ( root , 15 ) ; root = insert ( root , 13 ) ; root = insert ( root , 7 ) ; if ( isTripletPresent ( root ) ) document . write ( " " ) ; else document . write ( " " ) ;
class Node { constructor ( x ) { this . data = x ; this . left = null ; this . right = null ; } } let root ;
function Ceil ( node , input ) {
if ( node == null ) { return - 1 ; }
if ( node . data == input ) { return node . data ; }
if ( node . data < input ) { return Ceil ( node . right , input ) ; }
let ceil = Ceil ( node . left , input ) ; return ( ceil >= input ) ? ceil : node . data ; }
root = new Node ( 8 ) root . left = new Node ( 4 ) root . right = new Node ( 12 ) root . left . left = new Node ( 2 ) root . left . right = new Node ( 6 ) root . right . left = new Node ( 10 ) root . right . right = new Node ( 14 ) for ( let i = 0 ; i < 16 ; i ++ ) { document . write ( i + " " + Ceil ( root , i ) + " " ) ; }
class node { constructor ( ) { this . key = 0 ; this . count = 0 ; this . left = null ; this . right = null ; } }
function newNode ( item ) { var temp = new node ( ) ; temp . key = item ; temp . left = temp . right = null ; temp . count = 1 ; return temp ; }
function inorder ( root ) { if ( root != null ) { inorder ( root . left ) ; document . write ( root . key + " " + root . count + " " ) ; inorder ( root . right ) ; } }
function insert ( node , key ) {
if ( node == null ) return newNode ( key ) ;
if ( key == node . key ) { ( node . count ) ++ ; return node ; }
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
return node ; }
function minValueNode ( node ) { var current = node ;
while ( current . left != null ) current = current . left ; return current ; }
function deleteNode ( root , key ) {
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . count > 1 ) { ( root . count ) -- ; return root ; }
if ( root . left == null ) { var temp = root . right ; root = null ; return temp ; } else if ( root . right == null ) { var temp = root . left ; root = null ; return temp ; }
var temp = minValueNode ( root . right ) ;
root . key = temp . key ;
root . right = deleteNode ( root . right , temp . key ) ; } return root ; }
var root = null ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 20 ) ; root = insert ( root , 9 ) ; root = insert ( root , 11 ) ; root = insert ( root , 10 ) ; root = insert ( root , 12 ) ; root = insert ( root , 12 ) ; document . write ( " " + " " + " " ) ; inorder ( root ) ; document . write ( " " ) ; root = deleteNode ( root , 20 ) ; document . write ( " " + " " ) ; inorder ( root ) ; document . write ( " " ) ; root = deleteNode ( root , 12 ) ; document . write ( " " + " " ) ; inorder ( root ) ; document . write ( " " ) ; root = deleteNode ( root , 9 ) ; document . write ( " " + " " ) ; inorder ( root ) ;
class node { constructor ( ) { this . key = 0 ; this . left = null ; this . right = null ; } } var root = null ;
function newNode ( item ) { var temp = new node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; return temp ; }
function inorder ( root ) { if ( root != null ) { inorder ( root . left ) ; document . write ( root . key + " " ) ; inorder ( root . right ) ; } }
function insert ( node , key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
return node ; }
function minValueNode ( Node ) { var current = Node ;
while ( current . left != null ) current = current . left ; return current ; }
function deleteNode ( root , key ) {
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . left == null ) { temp = root . right ; return temp ; } else if ( root . right == null ) { temp = root . left ; return temp ; }
var temp = minValueNode ( root . right ) ;
root . key = temp . key ;
root . right = deleteNode ( root . right , temp . key ) ; } return root ; }
function changeKey ( root , oldVal , newVal ) {
root = deleteNode ( root , oldVal ) ;
root = insert ( root , newVal ) ;
return root ; }
root = insert ( root , 50 ) ; root = insert ( root , 30 ) ; root = insert ( root , 20 ) ; root = insert ( root , 40 ) ; root = insert ( root , 70 ) ; root = insert ( root , 60 ) ; root = insert ( root , 80 ) ; document . write ( " " ) ; inorder ( root ) ; root = changeKey ( root , 40 , 10 ) ;
document . write ( " " ) ; inorder ( root ) ;
class Node { constructor ( d ) { this . info = d ; this . left = this . right = null ; } } let head ; let count = 0 ;
function insert ( node , info ) {
if ( node == null ) { return ( new Node ( info ) ) ; } else {
if ( info <= node . info ) { node . left = insert ( node . left , info ) ; } else { node . right = insert ( node . right , info ) ; }
function check ( num ) { let sum = 0 , i = num , sum_of_digits , prod_of_digits ;
if ( num < 10 num > 99 ) return 0 ; else { sum_of_digits = ( i % 10 ) + Math . floor ( i / 10 ) ; prod_of_digits = ( i % 10 ) * Math . floor ( i / 10 ) ; sum = sum_of_digits + prod_of_digits ; } if ( sum == num ) return 1 ; else return 0 ; }
function countSpecialDigit ( rt ) { let x ; if ( rt == null ) return ; else { x = check ( rt . info ) ; if ( x == 1 ) count = count + 1 ; countSpecialDigit ( rt . left ) ; countSpecialDigit ( rt . right ) ; } }
let root = null ; root = insert ( root , 50 ) ; root = insert ( root , 29 ) ; root = insert ( root , 59 ) ; root = insert ( root , 19 ) ; root = insert ( root , 53 ) ; root = insert ( root , 556 ) ; root = insert ( root , 56 ) ; root = insert ( root , 94 ) ; root = insert ( root , 13 ) ;
countSpecialDigit ( root ) ; document . write ( count ) ;
function fill0X ( m , n ) {
let i , k = 0 , l = 0 ;
let r = m , c = n ;
let a = new Array ( m ) ; for ( let i = 0 ; i < m ; i ++ ) { a [ i ] = new Array ( n ) ; }
let x = ' ' ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) { a [ k ] [ i ] = x ; } k ++ ;
for ( i = k ; i < m ; ++ i ) { a [ i ] [ n - 1 ] = x ; } n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = x ; m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) { a [ i ] [ l ] = x ; } l ++ ; }
x = ( x == ' ' ) ? ' ' : ' ' ; }
for ( i = 0 ; i < r ; i ++ ) { for ( let j = 0 ; j < c ; j ++ ) { document . write ( a [ i ] [ j ] + " " ) ; } document . write ( " " ) ; } }
document . write ( " " ) ; fill0X ( 5 , 6 ) ; document . write ( " " ) ; fill0X ( 4 , 4 ) ; document . write ( " " ) ; fill0X ( 3 , 4 ) ;
let N = 3 ;
function interchangeDiagonals ( array ) {
for ( let i = 0 ; i < N ; ++ i ) if ( i != parseInt ( N / 2 ) ) { let temp = array [ i ] [ i ] ; array [ i ] [ i ] = array [ i ] [ N - i - 1 ] ; array [ i ] [ N - i - 1 ] = temp ; } for ( let i = 0 ; i < N ; ++ i ) { for ( let j = 0 ; j < N ; ++ j ) document . write ( " " + array [ i ] [ j ] ) ; document . write ( " " ) ; } }
let array = [ [ 4 , 5 , 6 ] , [ 1 , 2 , 3 ] , [ 7 , 8 , 9 ] ] ; interchangeDiagonals ( array ) ;
class Node { constructor ( val ) { this . data = val ; this . left = null ; this . right = null ; } } var root ;
function bintree2listUtil ( node ) {
if ( node == null ) return node ;
if ( node . left != null ) {
var left = bintree2listUtil ( node . left ) ;
for ( ; left . right != null ; left = left . right )
left . right = node ;
node . left = left ; }
if ( node . right != null ) {
var right = bintree2listUtil ( node . right ) ;
for ( ; right . left != null ; right = right . left )
right . left = node ;
node . right = right ; } return node ; }
function bintree2list ( node ) {
if ( node == null ) return node ;
node = bintree2listUtil ( node ) ;
while ( node . left != null ) node = node . left ; return node ; }
function printList ( node ) { while ( node != null ) { document . write ( node . data + " " ) ; node = node . right ; } }
root = new Node ( 10 ) ; root . left = new Node ( 12 ) ; root . right = new Node ( 15 ) ; root . left . left = new Node ( 25 ) ; root . left . right = new Node ( 30 ) ; root . right . left = new Node ( 36 ) ;
var head = bintree2list ( root ) ;
printList ( head ) ;
class node { constructor ( val ) { this . data = val ; this . left = null ; this . right = null ; } } var prev ;
function inorder ( root ) { if ( root == null ) return ; inorder ( root . left ) ; document . write ( root . data + " " ) ; inorder ( root . right ) ; }
function fixPrevptr ( root ) { if ( root == null ) return ; fixPrevptr ( root . left ) ; root . left = prev ; prev = root ; fixPrevptr ( root . right ) ; }
function fixNextptr ( root ) {
while ( root . right != null ) root = root . right ;
while ( root != null && root . left != null ) { var left = root . left ; left . right = root ; root = root . left ; }
return root ; }
function BTTtoDLL ( root ) { prev = null ;
fixPrevptr ( root ) ;
return fixNextptr ( root ) ; }
function printlist ( root ) { while ( root != null ) { document . write ( root . data + " " ) ; root = root . right ; } }
var root = new node ( 10 ) ; root . left = new node ( 12 ) ; root . right = new node ( 15 ) ; root . left . left = new node ( 25 ) ; root . left . right = new node ( 30 ) ; root . right . left = new node ( 36 ) ; document . write ( " " ) ; inorder ( root ) ; var head = BTTtoDLL ( root ) ; document . write ( " " ) ; printlist ( head ) ;
let M = 4 ; let N = 5 ;
function findCommon ( mat ) {
let column = new Array ( M ) ;
let min_row ;
let i ; for ( i = 0 ; i < M ; i ++ ) column [ i ] = N - 1 ;
min_row = 0 ;
while ( column [ min_row ] >= 0 ) {
for ( i = 0 ; i < M ; i ++ ) { if ( mat [ i ] [ column [ i ] ] < mat [ min_row ] [ column [ min_row ] ] ) min_row = i ; }
let eq_count = 0 ;
for ( i = 0 ; i < M ; i ++ ) {
if ( mat [ i ] [ column [ i ] ] > mat [ min_row ] [ column [ min_row ] ] ) { if ( column [ i ] == 0 ) return - 1 ;
column [ i ] -= 1 ; } else eq_count ++ ; }
if ( eq_count == M ) return mat [ min_row ] [ column [ min_row ] ] ; } return - 1 ; }
let mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 2 , 4 , 5 , 8 , 10 ] , [ 3 , 5 , 7 , 9 , 11 ] , [ 1 , 3 , 5 , 7 , 9 ] ] ; let result = findCommon ( mat ) if ( result == - 1 ) { document . write ( " " ) ; } else { document . write ( " " , result ) ; }
