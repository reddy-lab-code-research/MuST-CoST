import java . util . * ; import java . io . * ; import java . math . * ; class GFG { static void towerOfHanoi ( int n , char from_rod , char to_rod , char aux_rod ) { if ( n == 1 ) { System . out . println ( " Move ▁ disk ▁ 1 ▁ from ▁ rod ▁ " + from_rod + " ▁ to ▁ rod ▁ " + to_rod ) ; return ; } towerOfHanoi ( n - 1 , from_rod , aux_rod , to_rod ) ; System . out . println ( " Move ▁ disk ▁ " + n + " ▁ from ▁ rod ▁ " + from_rod + " ▁ to ▁ rod ▁ " + to_rod ) ; towerOfHanoi ( n - 1 , aux_rod , to_rod , from_rod ) ; }
int n = 4 ;
towerOfHanoi ( n , ' A ' , ' C ' , ' B ' ) ; } }
class Test { static int arr [ ] = { 10 , 20 , 30 , 50 , 10 , 70 , 30 } ; static void printMaxOfMin ( int n ) {
for ( int k = 1 ; k <= n ; k ++ ) {
int maxOfMin = Integer . MIN_VALUE ;
for ( int i = 0 ; i <= n - k ; i ++ ) {
int min = arr [ i ] ; for ( int j = 1 ; j < k ; j ++ ) { if ( arr [ i + j ] < min ) min = arr [ i + j ] ; }
if ( min > maxOfMin ) maxOfMin = min ; }
System . out . print ( maxOfMin + " ▁ " ) ; } }
public static void main ( String [ ] args ) { printMaxOfMin ( arr . length ) ; } }
static void PrintMinNumberForPattern ( String arr ) {
int curr_max = 0 ;
int last_entry = 0 ; int j ;
for ( int i = 0 ; i < arr . length ( ) ; i ++ ) {
int noOfNextD = 0 ; switch ( arr . charAt ( i ) ) { case ' I ' :
j = i + 1 ; while ( j < arr . length ( ) && arr . charAt ( j ) == ' D ' ) { noOfNextD ++ ; j ++ ; } if ( i == 0 ) { curr_max = noOfNextD + 2 ;
System . out . print ( " ▁ " + ++ last_entry ) ; System . out . print ( " ▁ " + curr_max ) ;
last_entry = curr_max ; } else {
curr_max = curr_max + noOfNextD + 1 ;
last_entry = curr_max ; System . out . print ( " ▁ " + last_entry ) ; }
for ( int k = 0 ; k < noOfNextD ; k ++ ) { System . out . print ( " ▁ " + -- last_entry ) ; i ++ ; } break ;
case ' D ' : if ( i == 0 ) {
j = i + 1 ; while ( j < arr . length ( ) && arr . charAt ( j ) == ' D ' ) { noOfNextD ++ ; j ++ ; }
curr_max = noOfNextD + 2 ;
System . out . print ( " ▁ " + curr_max + " ▁ " + ( curr_max - 1 ) ) ;
last_entry = curr_max - 1 ; } else {
System . out . print ( " ▁ " + ( last_entry - 1 ) ) ; last_entry -- ; } break ; } } System . out . println ( ) ; }
public static void main ( String [ ] args ) { PrintMinNumberForPattern ( " IDID " ) ; PrintMinNumberForPattern ( " I " ) ; PrintMinNumberForPattern ( " DD " ) ; PrintMinNumberForPattern ( " II " ) ; PrintMinNumberForPattern ( " DIDI " ) ; PrintMinNumberForPattern ( " IIDDD " ) ; PrintMinNumberForPattern ( " DDIDDIID " ) ; } }
static Stack < Integer > st = new Stack < > ( ) ;
static void push_digits ( int number ) { while ( number != 0 ) { st . push ( number % 10 ) ; number = number / 10 ; } }
static int reverse_number ( int number ) {
push_digits ( number ) ; int reverse = 0 ; int i = 1 ;
while ( ! st . isEmpty ( ) ) { reverse = reverse + ( st . peek ( ) * i ) ; st . pop ( ) ; i = i * 10 ; }
return reverse ; }
public static void main ( String [ ] args ) { int number = 39997 ;
System . out . println ( reverse_number ( number ) ) ; } }
void heapify ( int arr [ ] , int n , int i ) {
int largest = i ;
int l = 2 * i + 1 ;
int r = 2 * i + 2 ;
if ( l < n && arr [ l ] > arr [ largest ] ) largest = l ;
if ( r < n && arr [ r ] > arr [ largest ] ) largest = r ;
if ( largest != i ) { int swap = arr [ i ] ; arr [ i ] = arr [ largest ] ; arr [ largest ] = swap ;
heapify ( arr , n , largest ) ; } }
public void sort ( int arr [ ] ) { int n = arr . length ;
for ( int i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( int i = n - 1 ; i > 0 ; i -- ) {
int temp = arr [ 0 ] ; arr [ 0 ] = arr [ i ] ; arr [ i ] = temp ;
heapify ( arr , i , 0 ) ; } }
static void printArray ( int arr [ ] ) { int n = arr . length ; for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 12 , 11 , 13 , 5 , 6 , 7 } ; int n = arr . length ; HeapSort ob = new HeapSort ( ) ; ob . sort ( arr ) ; System . out . println ( " Sorted ▁ array ▁ is " ) ; printArray ( arr ) ; } }
static boolean isHeap ( int arr [ ] , int i , int n ) {
if ( i >= ( n - 2 ) / 2 ) { return true ; }
if ( arr [ i ] >= arr [ 2 * i + 1 ] && arr [ i ] >= arr [ 2 * i + 2 ] && isHeap ( arr , 2 * i + 1 , n ) && isHeap ( arr , 2 * i + 2 , n ) ) { return true ; } return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 } ; int n = arr . length - 1 ; if ( isHeap ( arr , 0 , n ) ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " No " ) ; } } }
static boolean isHeap ( int arr [ ] , int n ) {
for ( int i = 0 ; i <= ( n - 2 ) / 2 ; i ++ ) {
if ( arr [ 2 * i + 1 ] > arr [ i ] ) { return false ; }
if ( 2 * i + 2 < n && arr [ 2 * i + 2 ] > arr [ i ] ) { return false ; } } return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 } ; int n = arr . length ; if ( isHeap ( arr , n ) ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " No " ) ; } } }
class GFG { static void generate_derangement ( int N ) {
int S [ ] = new int [ N + 1 ] ; for ( int i = 1 ; i <= N ; i ++ ) S [ i ] = i ;
int D [ ] = new int [ N + 1 ] ; for ( int i = 1 ; i <= N ; i += 2 ) { if ( i == N ) {
D [ N ] = S [ N - 1 ] ; D [ N - 1 ] = S [ N ] ; } else { D [ i ] = i + 1 ; D [ i + 1 ] = i ; } }
for ( int i = 1 ; i <= N ; i ++ ) System . out . print ( D [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String [ ] args ) { generate_derangement ( 10 ) ; } }
static int sumBetweenTwoKth ( int arr [ ] , int k1 , int k2 ) {
Arrays . sort ( arr ) ;
int result = 0 ; for ( int i = k1 ; i < k2 - 1 ; i ++ ) result += arr [ i ] ; return result ; }
public static void main ( String [ ] args ) { int arr [ ] = { 20 , 8 , 22 , 4 , 12 , 10 , 14 } ; int k1 = 3 , k2 = 6 ; int n = arr . length ; System . out . print ( sumBetweenTwoKth ( arr , k1 , k2 ) ) ; } }
static int minSum ( int a [ ] , int n ) {
Arrays . sort ( a ) ; int num1 = 0 ; int num2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) num1 = num1 * 10 + a [ i ] ; else num2 = num2 * 10 + a [ i ] ; } return num2 + num1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 5 , 3 , 0 , 7 , 4 } ; int n = arr . length ; System . out . println ( " The ▁ required ▁ sum ▁ is ▁ " + minSum ( arr , n ) ) ; } }
import java . io . * ; class GFG { static int N = 3 ; static int M = 4 ;
static void printDistance ( int mat [ ] [ ] ) { int ans [ ] [ ] = new int [ N ] [ M ] ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) ans [ i ] [ j ] = Integer . MAX_VALUE ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) {
for ( int k = 0 ; k < N ; k ++ ) for ( int l = 0 ; l < M ; l ++ ) {
if ( mat [ k ] [ l ] == 1 ) ans [ i ] [ j ] = Math . min ( ans [ i ] [ j ] , Math . abs ( i - k ) + Math . abs ( j - l ) ) ; } }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) System . out . print ( ans [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 0 , 0 , 0 , 1 } , { 0 , 0 , 1 , 1 } , { 0 , 1 , 1 , 0 } } ; printDistance ( mat ) ; } }
static boolean isMinHeap ( int [ ] level ) { int n = level . length - 1 ;
for ( int i = ( n / 2 - 1 ) ; i >= 0 ; i -- ) {
if ( level [ i ] > level [ 2 * i + 1 ] ) return false ; if ( 2 * i + 2 < n ) {
if ( level [ i ] > level [ 2 * i + 2 ] ) return false ; } } return true ; }
public static void main ( String [ ] args ) throws IOException { int [ ] level = new int [ ] { 10 , 15 , 14 , 25 , 30 } ; if ( isMinHeap ( level ) ) System . out . println ( " True " ) ; else System . out . println ( " False " ) ; } }
import java . util . * ; class GFG { static int mostFrequent ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
int max_count = 1 , res = arr [ 0 ] ; int curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 5 , 2 , 1 , 3 , 2 , 1 } ; int n = arr . length ; System . out . println ( mostFrequent ( arr , n ) ) ; } }
boolean aredisjoint ( int set1 [ ] , int set2 [ ] ) {
for ( int i = 0 ; i < set1 . length ; i ++ ) { for ( int j = 0 ; j < set2 . length ; j ++ ) { if ( set1 [ i ] == set2 [ j ] ) return false ; } }
return true ; }
public static void main ( String [ ] args ) { disjoint1 dis = new disjoint1 ( ) ; int set1 [ ] = { 12 , 34 , 11 , 9 , 3 } ; int set2 [ ] = { 7 , 2 , 1 , 5 } ; boolean result = dis . aredisjoint ( set1 , set2 ) ; if ( result ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static void findMissing ( int a [ ] , int b [ ] , int n , int m ) { for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < m ; j ++ ) if ( a [ i ] == b [ j ] ) break ; if ( j == m ) System . out . print ( a [ i ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 6 , 3 , 4 , 5 } ; int b [ ] = { 2 , 4 , 3 , 1 , 0 } ; int n = a . length ; int m = b . length ; findMissing ( a , b , n , m ) ; } }
public static boolean areEqual ( int arr1 [ ] , int arr2 [ ] ) { int n = arr1 . length ; int m = arr2 . length ;
if ( n != m ) return false ;
Arrays . sort ( arr1 ) ; Arrays . sort ( arr2 ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr1 [ i ] != arr2 [ i ] ) return false ;
return true ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 3 , 5 , 2 , 5 , 2 } ; int arr2 [ ] = { 2 , 3 , 5 , 5 , 2 } ; if ( areEqual ( arr1 , arr2 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
boolean isProduct ( int arr [ ] , int n , int x ) {
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] * arr [ j ] == x ) return true ; return false ; }
public static void main ( String [ ] args ) { GFG g = new GFG ( ) ; int arr [ ] = { 10 , 20 , 9 , 40 } ; int x = 400 ; int n = arr . length ; if ( g . isProduct ( arr , n , x ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; x = 190 ; if ( g . isProduct ( arr , n , x ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static int findGreatest ( int [ ] arr , int n ) { int result = - 1 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ j ] * arr [ k ] == arr [ i ] ) result = Math . max ( result , arr [ i ] ) ; return result ; }
static public void main ( String [ ] args ) { int [ ] arr = { 30 , 10 , 9 , 3 , 35 } ; int n = arr . length ; System . out . println ( findGreatest ( arr , n ) ) ; } }
public static int subset ( int ar [ ] , int n ) {
int res = 0 ;
Arrays . sort ( ar ) ;
for ( int i = 0 ; i < n ; i ++ ) { int count = 1 ;
for ( ; i < n - 1 ; i ++ ) { if ( ar [ i ] == ar [ i + 1 ] ) count ++ ; else break ; }
res = Math . max ( res , count ) ; } return res ; }
public static void main ( String argc [ ] ) { int arr [ ] = { 5 , 6 , 9 , 3 , 4 , 3 , 4 } ; int n = 7 ; System . out . println ( subset ( arr , n ) ) ; } }
public static void getPairsCount ( int [ ] arr , int sum ) {
int count = 0 ;
for ( int i = 0 ; i < arr . length ; i ++ ) for ( int j = i + 1 ; j < arr . length ; j ++ ) if ( ( arr [ i ] + arr [ j ] ) == sum ) count ++ ; System . out . printf ( " Count ▁ of ▁ pairs ▁ is ▁ % d " , count ) ; }
public static void main ( String args [ ] ) { int [ ] arr = { 1 , 5 , 7 , - 1 , 5 } ; int sum = 6 ; getPairsCount ( arr , sum ) ; } }
static int countPairs ( int [ ] arr1 , int [ ] arr2 , int m , int n , int x ) { int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ )
if ( ( arr1 [ i ] + arr2 [ j ] ) == x ) count ++ ;
return count ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = arr1 . length ; int n = arr2 . length ; int x = 10 ; System . out . println ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static boolean isPresent ( int arr [ ] , int low , int high , int value ) { while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
static int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ; for ( int i = 0 ; i < m ; i ++ ) {
int value = x - arr1 [ i ] ;
if ( isPresent ( arr2 , 0 , n - 1 , value ) ) count ++ ; }
return count ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = arr1 . length ; int n = arr2 . length ; int x = 10 ; System . out . println ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ; int l = 0 , r = n - 1 ;
while ( l < m && r >= 0 ) {
if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) { l ++ ; r -- ; count ++ ; }
else if ( ( arr1 [ l ] + arr2 [ r ] ) < x ) l ++ ;
else r -- ; }
return count ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = arr1 . length ; int n = arr2 . length ; int x = 10 ; System . out . println ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static boolean isPresent ( int [ ] arr , int low , int high , int value ) { while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
static int countQuadruples ( int [ ] arr1 , int [ ] arr2 , int [ ] arr3 , int [ ] arr4 , int n , int x ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) for ( int k = 0 ; k < n ; k ++ ) {
int T = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
if ( isPresent ( arr4 , 0 , n - 1 , x - T ) )
count ++ ; }
return count ; }
int [ ] arr1 = { 1 , 4 , 5 , 6 } ; int [ ] arr2 = { 2 , 3 , 7 , 8 } ; int [ ] arr3 = { 1 , 4 , 6 , 10 } ; int [ ] arr4 = { 2 , 4 , 7 , 8 } ; int n = 4 ; int x = 30 ; System . out . println ( " Count ▁ = ▁ " + countQuadruples ( arr1 , arr2 , arr3 , arr4 , n , x ) ) ; } }
static int countPairs ( int arr [ ] , int n ) { int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int product = arr [ i ] * arr [ j ] ;
for ( int k = 0 ; k < n ; k ++ ) {
if ( arr [ k ] == product ) { result ++ ; break ; } } } }
return result ; }
public static void main ( String [ ] args ) { int arr [ ] = { 6 , 2 , 4 , 12 , 5 , 3 } ; int n = arr . length ; System . out . println ( countPairs ( arr , n ) ) ; } }
static void findPairs ( int arr1 [ ] , int arr2 [ ] , int n , int m , int x ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( arr1 [ i ] + arr2 [ j ] == x ) System . out . println ( arr1 [ i ] + " ▁ " + arr2 [ j ] ) ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 2 , 3 , 7 , 5 , 4 } ; int arr2 [ ] = { 0 , 7 , 4 , 3 , 2 , 1 } ; int x = 8 ; findPairs ( arr1 , arr2 , arr1 . length , arr2 . length , x ) ; } }
static void findPair ( int [ ] arr , int n ) { boolean found = false ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { for ( int k = 0 ; k < n ; k ++ ) { if ( arr [ i ] + arr [ j ] == arr [ k ] ) { System . out . println ( arr [ i ] + " ▁ " + arr [ j ] ) ; found = true ; } } } } if ( found == false ) System . out . println ( " Not ▁ exist " ) ; }
static public void main ( String [ ] args ) { int [ ] arr = { 10 , 4 , 8 , 13 , 5 } ; int n = arr . length ; findPair ( arr , n ) ; } }
static boolean printPairs ( int arr [ ] , int n , int k ) { boolean isPairFound = true ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i != j && arr [ i ] % arr [ j ] == k ) { System . out . print ( " ( " + arr [ i ] + " , ▁ " + arr [ j ] + " ) " + " ▁ " ) ; isPairFound = true ; } } } return isPairFound ; }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , 3 , 5 , 4 , 7 } ; int k = 3 ; if ( printPairs ( arr , arr . length , k ) == false ) System . out . println ( " No ▁ such ▁ pair ▁ exists " ) ; } }
public class GFG { static final int ASCII_SIZE = 256 ; static char getMaxOccuringChar ( String str ) {
int count [ ] = new int [ ASCII_SIZE ] ;
int len = str . length ( ) ; for ( int i = 0 ; i < len ; i ++ ) count [ str . charAt ( i ) ] ++ ;
int max = - 1 ;
for ( int i = 0 ; i < len ; i ++ ) { if ( max < count [ str . charAt ( i ) ] ) { max = count [ str . charAt ( i ) ] ; result = str . charAt ( i ) ; } } return result ; }
public static void main ( String [ ] args ) { String str = " sample ▁ string " ; System . out . println ( " Max ▁ occurring ▁ character ▁ is ▁ " + getMaxOccuringChar ( str ) ) ; } }
class GFG { static int firstNonRepeating ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ i ] == arr [ j ] ) break ; if ( j == n ) return arr [ i ] ; } return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 9 , 4 , 9 , 6 , 7 , 4 } ; int n = arr . length ; System . out . print ( firstNonRepeating ( arr , n ) ) ; } }
static int printKDistinct ( int arr [ ] , int n , int k ) { int dist_count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ j ] == arr [ i ] ) break ;
if ( j == n ) dist_count ++ ; if ( dist_count == k ) return arr [ i ] ; } return - 1 ; }
public static void main ( String [ ] args ) { int ar [ ] = { 1 , 2 , 1 , 3 , 4 , 2 } ; int n = ar . length ; int k = 2 ; System . out . print ( printKDistinct ( ar , n , k ) ) ; } }
static void subarrayDivisibleByK ( int [ ] arr , int n , int k ) {
int [ ] mp = new int [ 1000 ] ;
int s = 0 , e = 0 , maxs = 0 , maxe = 0 ;
mp [ arr [ 0 ] % k ] ++ ; for ( int i = 1 ; i < n ; i ++ ) { int mod = arr [ i ] % k ;
while ( mp [ k - mod ] != 0 || ( mod == 0 && mp [ mod ] != 0 ) ) { mp [ arr [ s ] % k ] -- ; s ++ ; }
mp [ mod ] ++ ; e ++ ;
if ( ( e - s ) > ( maxe - maxs ) ) { maxe = e ; maxs = s ; } } System . out . print ( " The ▁ maximum ▁ size ▁ is ▁ " + ( maxe - maxs + 1 ) + " and the subarray is as followsNEW_LINE"); for ( int i = maxs ; i <= maxe ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int k = 3 ; int [ ] arr = { 5 , 10 , 15 , 20 , 25 } ; int n = arr . length ; subarrayDivisibleByK ( arr , n , k ) ; } }
static boolean findTriplet ( int a1 [ ] , int a2 [ ] , int a3 [ ] , int n1 , int n2 , int n3 , int sum ) { for ( int i = 0 ; i < n1 ; i ++ ) for ( int j = 0 ; j < n2 ; j ++ ) for ( int k = 0 ; k < n3 ; k ++ ) if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) return true ; return false ; }
public static void main ( String [ ] args ) { int a1 [ ] = { 1 , 2 , 3 , 4 , 5 } ; int a2 [ ] = { 2 , 3 , 6 , 1 , 2 } ; int a3 [ ] = { 3 , 2 , 4 , 5 , 6 } ; int sum = 9 ; int n1 = a1 . length ; int n2 = a2 . length ; int n3 = a3 . length ; if ( findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) ) System . out . print ( " Yes " ) ; else System . out . print ( " No " ) ; } }
static boolean areElementsContiguous ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] > 1 ) return false ; return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = arr . length ; if ( areElementsContiguous ( arr , n ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static int minInsertion ( String str ) {
int n = str . length ( ) ;
int res = 0 ;
int [ ] count = new int [ 26 ] ;
for ( int i = 0 ; i < n ; i ++ ) count [ str . charAt ( i ) - ' a ' ] ++ ;
for ( int i = 0 ; i < 26 ; i ++ ) { if ( count [ i ] % 2 == 1 ) res ++ ; }
return ( res == 0 ) ? 0 : res - 1 ; }
public static void main ( String [ ] args ) { String str = " geeksforgeeks " ; System . out . println ( minInsertion ( str ) ) ; } }
import java . util . * ; class GFG { static int findDiff ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ; int count = 0 , max_count = 0 , min_count = n ; for ( int i = 0 ; i < ( n - 1 ) ; i ++ ) {
if ( arr [ i ] == arr [ i + 1 ] ) { count += 1 ; continue ; } else { max_count = Math . max ( max_count , count ) ; min_count = Math . min ( min_count , count ) ; count = 0 ; } } return ( max_count - min_count ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 } ; int n = arr . length ; System . out . println ( findDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) { int SubsetSum_1 = 0 , SubsetSum_2 = 0 ; for ( int i = 0 ; i <= n - 1 ; i ++ ) { boolean isSingleOccurance = true ; for ( int j = i + 1 ; j <= n - 1 ; j ++ ) {
if ( arr [ i ] == arr [ j ] ) { isSingleOccurance = false ; arr [ i ] = arr [ j ] = 0 ; break ; } } if ( isSingleOccurance ) { if ( arr [ i ] > 0 ) SubsetSum_1 += arr [ i ] ; else SubsetSum_2 += arr [ i ] ; } } return Math . abs ( SubsetSum_1 - SubsetSum_2 ) ; }
static public void main ( String [ ] args ) { int [ ] arr = { 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 } ; int n = arr . length ; System . out . println ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) { int result = 0 ;
Arrays . sort ( arr ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) result += Math . abs ( arr [ i ] ) ; else i ++ ; }
if ( arr [ n - 2 ] != arr [ n - 1 ] ) result += Math . abs ( arr [ n - 1 ] ) ;
return result ; }
static public void main ( String [ ] args ) { int [ ] arr = { 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 } ; int n = arr . length ; System . out . println ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n ) ) ; } }
static int calculate ( int a [ ] , int n ) {
Arrays . sort ( a ) ; int count = 1 ; int answer = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == a [ i - 1 ] ) {
count += 1 ; } else {
answer = answer + ( count * ( count - 1 ) ) / 2 ; count = 1 ; } } answer = answer + ( count * ( count - 1 ) ) / 2 ; return answer ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 1 , 2 , 4 } ; int n = a . length ;
System . out . println ( calculate ( a , n ) ) ; } }
static int calculate ( int a [ ] , int n ) {
int maximum = Arrays . stream ( a ) . max ( ) . getAsInt ( ) ;
int frequency [ ] = new int [ maximum + 1 ] ;
for ( int i = 0 ; i < n ; i ++ ) {
frequency [ a [ i ] ] += 1 ; } int answer = 0 ;
for ( int i = 0 ; i < ( maximum ) + 1 ; i ++ ) {
answer = answer + frequency [ i ] * ( frequency [ i ] - 1 ) ; } return answer / 2 ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 1 , 2 , 4 } ; int n = a . length ;
System . out . println ( calculate ( a , n ) ) ; } }
static void printAllAPTriplets ( int [ ] arr , int n ) { ArrayList < Integer > s = new ArrayList < Integer > ( ) ; for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int diff = arr [ j ] - arr [ i ] ; boolean exists = s . contains ( arr [ i ] - diff ) ; if ( exists ) System . out . println ( arr [ i ] - diff + " ▁ " + arr [ i ] + " ▁ " + arr [ j ] ) ; } s . add ( arr [ i ] ) ; } }
public static void main ( String args [ ] ) { int [ ] arr = { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = arr . length ; printAllAPTriplets ( arr , n ) ; } }
static void findAllTriplets ( int arr [ ] , int n ) { for ( int i = 1 ; i < n - 1 ; i ++ ) {
for ( int j = i - 1 , k = i + 1 ; j >= 0 && k < n ; ) {
if ( arr [ j ] + arr [ k ] == 2 * arr [ i ] ) { System . out . println ( arr [ j ] + " ▁ " + arr [ i ] + " ▁ " + arr [ k ] ) ;
k ++ ; j -- ; }
else if ( arr [ j ] + arr [ k ] < 2 * arr [ i ] ) k ++ ; else j -- ; } } }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = arr . length ; findAllTriplets ( arr , n ) ; } }
static int countTriplets ( int arr [ ] , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) for ( int j = i + 1 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] * arr [ j ] * arr [ k ] == m ) count ++ ; return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 4 , 6 , 2 , 3 , 8 } ; int m = 24 ; System . out . println ( countTriplets ( arr , arr . length , m ) ) ; } }
static int countPairs ( int arr [ ] , int n ) { int ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ )
if ( arr [ i ] == arr [ j ] ) ans ++ ; return ans ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 2 } ; int n = arr . length ; System . out . println ( countPairs ( arr , n ) ) ; } }
static int countNum ( int [ ] arr , int n ) { int count = 0 ;
Arrays . sort ( arr ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) count += arr [ i + 1 ] - arr [ i ] - 1 ; return count ; }
static public void main ( String [ ] args ) { int [ ] arr = { 3 , 5 , 8 , 6 } ; int n = arr . length ; System . out . println ( countNum ( arr , n ) ) ; } }
static int countSubarrays ( int [ ] arr , int n ) {
int difference = 0 ; int ans = 0 ;
int [ ] hash_positive = new int [ n + 1 ] ; int [ ] hash_negative = new int [ n + 1 ] ;
hash_positive [ 0 ] = 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ( arr [ i ] & 1 ) == 1 ) { difference ++ ; } else { difference -- ; }
if ( difference < 0 ) { ans += hash_negative [ - difference ] ; hash_negative [ - difference ] ++ ;
} else { ans += hash_positive [ difference ] ; hash_positive [ difference ] ++ ; } }
return ans ; }
public static void main ( String [ ] args ) { int [ ] arr = new int [ ] { 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 } ; int n = arr . length ;
System . out . println ( " Total ▁ Number ▁ of ▁ Even - Odd " + " ▁ subarrays ▁ are ▁ " + countSubarrays ( arr , n ) ) ; } }
static int findLargestd ( int [ ] S , int n ) { boolean found = false ;
Arrays . sort ( S ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) continue ; for ( int k = j + 1 ; k < n ; k ++ ) { if ( i == k ) continue ; for ( int l = k + 1 ; l < n ; l ++ ) { if ( i == l ) continue ;
if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) { found = true ; return S [ i ] ; } } } } } if ( found == false ) return Integer . MAX_VALUE ; return - 1 ; }
public static void main ( String [ ] args ) { int [ ] S = new int [ ] { 2 , 3 , 5 , 7 , 12 } ; int n = S . length ; int ans = findLargestd ( S , n ) ; if ( ans == Integer . MAX_VALUE ) System . out . println ( " No ▁ Solution " ) ; else System . out . println ( " Largest ▁ d ▁ such ▁ that ▁ " + " a ▁ + ▁ " + " b ▁ + ▁ c ▁ = ▁ d ▁ is ▁ " + ans ) ; } }
static void recaman ( int n ) {
arr [ 0 ] = 0 ; System . out . print ( arr [ 0 ] + " ▁ , " ) ;
for ( int i = 1 ; i < n ; i ++ ) { int curr = arr [ i - 1 ] - i ; int j ; for ( j = 0 ; j < i ; j ++ ) {
if ( ( arr [ j ] == curr ) curr < 0 ) { curr = arr [ i - 1 ] + i ; break ; } } arr [ i ] = curr ; System . out . print ( arr [ i ] + " , ▁ " ) ; } }
public static void main ( String [ ] args ) { int n = 17 ; recaman ( n ) ; } }
static void recaman ( int n ) { if ( n <= 0 ) return ;
System . out . printf ( " % d , ▁ " , 0 ) ; HashSet < Integer > s = new HashSet < Integer > ( ) ; s . add ( 0 ) ;
int prev = 0 ; for ( int i = 1 ; i < n ; i ++ ) { int curr = prev - i ;
if ( curr < 0 || s . contains ( curr ) ) curr = prev + i ; s . add ( curr ) ; System . out . printf ( " % d , ▁ " , curr ) ; prev = curr ; } }
public static void main ( String [ ] args ) { int n = 17 ; recaman ( n ) ; } }
static int findArea ( Integer arr [ ] , int n ) {
Arrays . sort ( arr , Collections . reverseOrder ( ) ) ;
int [ ] dimension = { 0 , 0 } ;
for ( int i = 0 , j = 0 ; i < n - 1 && j < 2 ; i ++ )
if ( arr [ i ] == arr [ i + 1 ] ) dimension [ j ++ ] = arr [ i ++ ] ;
return ( dimension [ 0 ] * dimension [ 1 ] ) ; }
public static void main ( String args [ ] ) { Integer arr [ ] = { 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 } ; int n = arr . length ; System . out . println ( findArea ( arr , n ) ) ; } }
static int search ( int arr [ ] , int l , int h , int key ) { if ( l > h ) return - 1 ; int mid = ( l + h ) / 2 ; if ( arr [ mid ] == key ) return mid ;
if ( arr [ l ] <= arr [ mid ] ) {
if ( key >= arr [ l ] && key <= arr [ mid ] ) return search ( arr , l , mid - 1 , key ) ;
return search ( arr , mid + 1 , h , key ) ; }
if ( key >= arr [ mid ] && key <= arr [ h ] ) return search ( arr , mid + 1 , h , key ) ; return search ( arr , l , mid - 1 , key ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 } ; int n = arr . length ; int key = 6 ; int i = search ( arr , 0 , n - 1 , key ) ; if ( i != - 1 ) System . out . println ( " Index : ▁ " + i ) ; else System . out . println ( " Key ▁ not ▁ found " ) ; } }
static boolean pairInSortedRotated ( int arr [ ] , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) return true ;
if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 11 , 15 , 6 , 8 , 9 , 10 } ; int sum = 16 ; int n = arr . length ; if ( pairInSortedRotated ( arr , n , sum ) ) System . out . print ( " Array ▁ has ▁ two ▁ elements " + " ▁ with ▁ sum ▁ 16" ) ; else System . out . print ( " Array ▁ doesn ' t ▁ have ▁ two " + " ▁ elements ▁ with ▁ sum ▁ 16 ▁ " ) ; } }
static int pairsInSortedRotated ( int arr [ ] , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
int cnt = 0 ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) { cnt ++ ;
if ( l == ( r - 1 + n ) % n ) { return cnt ; } l = ( l + 1 ) % n ; r = ( r - 1 + n ) % n ; }
else if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return cnt ; }
public static void main ( String [ ] args ) { int arr [ ] = { 11 , 15 , 6 , 7 , 9 , 10 } ; int sum = 16 ; int n = arr . length ; System . out . println ( pairsInSortedRotated ( arr , n , sum ) ) ; } }
static int maxSum ( ) {
int arrSum = 0 ;
int currVal = 0 ; for ( int i = 0 ; i < arr . length ; i ++ ) { arrSum = arrSum + arr [ i ] ; currVal = currVal + ( i * arr [ i ] ) ; }
int maxVal = currVal ;
for ( int j = 1 ; j < arr . length ; j ++ ) { currVal = currVal + arrSum - arr . length * arr [ arr . length - j ] ; if ( currVal > maxVal ) maxVal = currVal ; }
return maxVal ; }
public static void main ( String [ ] args ) { System . out . println ( " Max ▁ sum ▁ is ▁ " + maxSum ( ) ) ; } }
static int maxSum ( int arr [ ] , int n ) {
int res = Integer . MIN_VALUE ;
for ( int i = 0 ; i < n ; i ++ ) {
int curr_sum = 0 ;
for ( int j = 0 ; j < n ; j ++ ) { int index = ( i + j ) % n ; curr_sum += j * arr [ index ] ; }
res = Math . max ( res , curr_sum ) ; } return res ; }
public static void main ( String args [ ] ) { int arr [ ] = { 8 , 3 , 1 , 2 } ; int n = arr . length ; System . out . println ( maxSum ( arr , n ) ) ; } }
import java . io . * ; class GFG { static int maxSum ( int arr [ ] , int n ) {
int cum_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) cum_sum += arr [ i ] ;
int curr_val = 0 ; for ( int i = 0 ; i < n ; i ++ ) curr_val += i * arr [ i ] ;
int res = curr_val ;
for ( int i = 1 ; i < n ; i ++ ) {
int next_val = curr_val - ( cum_sum - arr [ i - 1 ] ) + arr [ i - 1 ] * ( n - 1 ) ;
curr_val = next_val ;
res = Math . max ( res , next_val ) ; } return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { 8 , 3 , 1 , 2 } ; int n = arr . length ; System . out . println ( maxSum ( arr , n ) ) ; } }
static int countRotations ( int arr [ ] , int n ) {
int min = arr [ 0 ] , min_index = - 1 ; for ( int i = 0 ; i < n ; i ++ ) { if ( min > arr [ i ] ) { min = arr [ i ] ; min_index = i ; } } return min_index ; }
public static void main ( String [ ] args ) { int arr [ ] = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = arr . length ; System . out . println ( countRotations ( arr , n ) ) ; } }
static int countRotations ( int arr [ ] , int low , int high ) {
if ( high < low ) return 0 ;
if ( high == low ) return low ;
int mid = low + ( high - low ) / 2 ;
if ( mid < high && arr [ mid + 1 ] < arr [ mid ] ) return ( mid + 1 ) ;
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) return mid ;
if ( arr [ high ] > arr [ mid ] ) return countRotations ( arr , low , mid - 1 ) ; return countRotations ( arr , mid + 1 , high ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = arr . length ; System . out . println ( countRotations ( arr , 0 , n - 1 ) ) ; } }
static void preprocess ( int arr [ ] , int n , int temp [ ] ) {
for ( int i = 0 ; i < n ; i ++ ) temp [ i ] = temp [ i + n ] = arr [ i ] ; }
static void leftRotate ( int arr [ ] , int n , int k , int temp [ ] ) {
int start = k % n ;
for ( int i = start ; i < start + n ; i ++ ) System . out . print ( temp [ i ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . length ; int temp [ ] = new int [ 2 * n ] ; preprocess ( arr , n , temp ) ; int k = 2 ; leftRotate ( arr , n , k , temp ) ; k = 3 ; leftRotate ( arr , n , k , temp ) ; k = 4 ; leftRotate ( arr , n , k , temp ) ; } }
static void leftRotate ( int arr [ ] , int n , int k ) {
for ( int i = k ; i < k + n ; i ++ ) System . out . print ( arr [ i % n ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . length ; int k = 2 ; leftRotate ( arr , n , k ) ; System . out . println ( ) ; k = 3 ; leftRotate ( arr , n , k ) ; System . out . println ( ) ; k = 4 ; leftRotate ( arr , n , k ) ; System . out . println ( ) ; } }
static void reverseArray ( int arr [ ] , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
static void rightRotate ( int arr [ ] , int d , int n ) { reverseArray ( arr , 0 , n - 1 ) ; reverseArray ( arr , 0 , d - 1 ) ; reverseArray ( arr , d , n - 1 ) ; }
static void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 } ; int n = arr . length ; int k = 3 ; rightRotate ( arr , k , n ) ; printArray ( arr , n ) ; } }
static int maxHamming ( int arr [ ] , int n ) {
int brr [ ] = new int [ 2 * n + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ i ] = arr [ i ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ n + i ] = arr [ i ] ;
int maxHam = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { int currHam = 0 ; for ( int j = i , k = 0 ; j < ( i + n ) ; j ++ , k ++ ) if ( brr [ j ] != arr [ k ] ) currHam ++ ;
if ( currHam == n ) return n ; maxHam = Math . max ( maxHam , currHam ) ; } return maxHam ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 4 , 6 , 8 } ; int n = arr . length ; System . out . print ( maxHamming ( arr , n ) ) ; } }
static void leftRotate ( int arr [ ] , int n , int k ) {
int mod = k % n ;
for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ ( i + mod ) % n ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . length ; int k = 2 ;
leftRotate ( arr , n , k ) ; k = 3 ;
leftRotate ( arr , n , k ) ; k = 4 ;
leftRotate ( arr , n , k ) ; } }
static int findElement ( int [ ] arr , int [ ] [ ] ranges , int rotations , int index ) { for ( int i = rotations - 1 ; i >= 0 ; i -- ) {
int left = ranges [ i ] [ 0 ] ; int right = ranges [ i ] [ 1 ] ;
if ( left <= index && right >= index ) { if ( index == left ) index = right ; else index -- ; } }
return arr [ index ] ; }
public static void main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ;
int rotations = 2 ;
int [ ] [ ] ranges = { { 0 , 2 } , { 0 , 3 } } ; int index = 1 ; System . out . println ( findElement ( arr , ranges , rotations , index ) ) ; } }
import java . util . * ; import java . lang . * ; class GFG { public static void splitArr ( int arr [ ] , int n , int k ) { for ( int i = 0 ; i < k ; i ++ ) {
int x = arr [ 0 ] ; for ( int j = 0 ; j < n - 1 ; ++ j ) arr [ j ] = arr [ j + 1 ] ; arr [ n - 1 ] = x ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = arr . length ; int position = 2 ; splitArr ( arr , 6 , position ) ; for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void rearrangeArr ( int arr [ ] , int n ) {
int evenPos = n / 2 ;
int oddPos = n - evenPos ; int [ ] tempArr = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) tempArr [ i ] = arr [ i ] ;
Arrays . sort ( tempArr ) ; int j = oddPos - 1 ;
for ( int i = 0 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j -- ; } j = oddPos ;
for ( int i = 1 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j ++ ; }
for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String argc [ ] ) { int [ ] arr = new int [ ] { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int size = 7 ; rearrangeArr ( arr , size ) ; } }
static void pushZerosToEnd ( int arr [ ] , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 } ; int n = arr . length ; pushZerosToEnd ( arr , n ) ; System . out . println ( " Array ▁ after ▁ pushing ▁ zeros ▁ to ▁ the ▁ back : ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static int minSwap ( int arr [ ] , int n , int k ) {
int count = 0 ; for ( int i = 0 ; i < n ; ++ i ) if ( arr [ i ] <= k ) ++ count ;
int bad = 0 ; for ( int i = 0 ; i < count ; ++ i ) if ( arr [ i ] > k ) ++ bad ;
int ans = bad ; for ( int i = 0 , j = count ; j < n ; ++ i , ++ j ) {
if ( arr [ i ] > k ) -- bad ;
if ( arr [ j ] > k ) ++ bad ;
ans = Math . min ( ans , bad ) ; } return ans ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 1 , 5 , 6 , 3 } ; int n = arr . length ; int k = 3 ; System . out . print ( minSwap ( arr , n , k ) + "NEW_LINE"); int arr1 [ ] = { 2 , 7 , 9 , 5 , 8 , 7 , 4 } ; n = arr1 . length ; k = 5 ; System . out . print ( minSwap ( arr1 , n , k ) ) ; } }
static void reorder ( ) { int temp [ ] = new int [ arr . length ] ;
for ( int i = 0 ; i < arr . length ; i ++ ) temp [ index [ i ] ] = arr [ i ] ;
for ( int i = 0 ; i < arr . length ; i ++ ) { arr [ i ] = temp [ i ] ; index [ i ] = i ; } }
public static void main ( String [ ] args ) { reorder ( ) ; System . out . println ( " Reordered ▁ array ▁ is : ▁ " ) ; System . out . println ( Arrays . toString ( arr ) ) ; System . out . println ( " Modified ▁ Index ▁ array ▁ is : " ) ; System . out . println ( Arrays . toString ( index ) ) ; } }
static void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
static void RearrangePosNeg ( int arr [ ] , int n ) { int key , j ; for ( int i = 1 ; i < n ; i ++ ) { key = arr [ i ] ;
if ( key > 0 ) continue ;
j = i - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { arr [ j + 1 ] = arr [ j ] ; j = j - 1 ; }
arr [ j + 1 ] = key ; } }
public static void main ( String [ ] args ) { int arr [ ] = { - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 } ; int n = arr . length ; RearrangePosNeg ( arr , n ) ; printArray ( arr , n ) ; } }
static void rearrange ( int [ ] arr , int n ) {
int temp [ ] = arr . clone ( ) ;
int small = 0 , large = n - 1 ;
boolean flag = true ;
for ( int i = 0 ; i < n ; i ++ ) { if ( flag ) arr [ i ] = temp [ large -- ] ; else arr [ i ] = temp [ small ++ ] ; flag = ! flag ; } }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 1 , 2 , 3 , 4 , 5 , 6 } ; System . out . println ( " Original ▁ Array ▁ " ) ; System . out . println ( Arrays . toString ( arr ) ) ; rearrange ( arr , arr . length ) ; System . out . println ( " Modified ▁ Array ▁ " ) ; System . out . println ( Arrays . toString ( arr ) ) ; } }
public static void rearrange ( int arr [ ] , int n ) {
int max_idx = n - 1 , min_idx = 0 ;
int max_elem = arr [ n - 1 ] + 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] += ( arr [ max_idx ] % max_elem ) * max_elem ; max_idx -- ; }
else { arr [ i ] += ( arr [ min_idx ] % max_elem ) * max_elem ; min_idx ++ ; } }
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = arr [ i ] / max_elem ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = arr . length ; System . out . println ( " Original ▁ Array " ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; rearrange ( arr , n ) ; System . out . print ( " Modified Array "); for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
import java . io . * ; class GFG { static void rearrange ( int arr [ ] , int n ) { int j = 0 , temp ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < 0 ) { if ( i != j ) { temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } j ++ ; } } }
static void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { - 1 , 2 , - 3 , 4 , 5 , 6 , - 7 , 8 , 9 } ; int n = arr . length ; rearrange ( arr , n ) ; printArray ( arr , n ) ; } }
static void segregateElements ( int arr [ ] , int n ) {
int temp [ ] = new int [ n ] ;
int j = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] >= 0 ) temp [ j ++ ] = arr [ i ] ;
if ( j == n j == 0 ) return ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < 0 ) temp [ j ++ ] = arr [ i ] ;
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
public static void main ( String arg [ ] ) { int arr [ ] = { 1 , - 1 , - 3 , - 2 , 7 , 5 , 11 , 6 } ; int n = arr . length ; segregateElements ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static void rearrange ( int arr [ ] , int n ) { int temp ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( i % 2 == 0 && arr [ i ] > arr [ i + 1 ] ) { temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } if ( i % 2 != 0 && arr [ i ] < arr [ i + 1 ] ) { temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } } }
static void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 6 , 4 , 2 , 1 , 8 , 3 } ; int n = arr . length ; System . out . print ( "Before rearranging: NEW_LINE"); printArray ( arr , n ) ; rearrange ( arr , n ) ; System . out . print ( "After rearranging: NEW_LINE"); printArray ( arr , n ) ; } }
import java . io . * ; class GFG { static void rearrange ( int a [ ] , int size ) { int positive = 0 , negative = 1 , temp ; while ( true ) {
while ( positive < size && a [ positive ] >= 0 ) positive += 2 ;
while ( negative < size && a [ negative ] <= 0 ) negative += 2 ;
if ( positive < size && negative < size ) { temp = a [ positive ] ; a [ positive ] = a [ negative ] ; a [ negative ] = temp ; }
else break ; } }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 } ; int n = arr . length ; rearrange ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static void arrayEvenAndOdd ( int arr [ ] , int n ) { int i = - 1 , j = 0 ; while ( j != n ) { if ( arr [ j ] % 2 == 0 ) { i ++ ;
int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } j ++ ; }
for ( int k = 0 ; k < n ; k ++ ) System . out . print ( arr [ k ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 } ; int n = arr . length ; arrayEvenAndOdd ( arr , n ) ; } }
static int largest ( ) { int i ;
int max = arr [ 0 ] ;
for ( i = 1 ; i < arr . length ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
public static void main ( String [ ] args ) { System . out . println ( " Largest ▁ in ▁ given ▁ array ▁ is ▁ " + largest ( ) ) ; } }
static int largest ( int [ ] arr , int n ) { Arrays . sort ( arr ) ; return arr [ n - 1 ] ; }
static public void main ( String [ ] args ) { int [ ] arr = { 10 , 324 , 45 , 90 , 9808 } ; int n = arr . length ; System . out . println ( largest ( arr , n ) ) ; } }
import java . util . * ; import java . io . * ; class GFG { static void findElements ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) if ( arr [ j ] > arr [ i ] ) count ++ ; if ( count >= 2 ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . length ; findElements ( arr , n ) ; } }
import java . util . * ; import java . io . * ; class GFG { static void findElements ( int arr [ ] , int n ) { Arrays . sort ( arr ) ; for ( int i = 0 ; i < n - 2 ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . length ; findElements ( arr , n ) ; } }
import java . util . * ; import java . io . * ; class GFG { static void findElements ( int arr [ ] , int n ) { int first = Integer . MIN_VALUE ; int second = Integer . MAX_VALUE ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) second = arr [ i ] ; } for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < second ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . length ; findElements ( arr , n ) ; } }
public static double findMean ( int a [ ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += a [ i ] ; return ( double ) sum / ( double ) n ; }
public static double findMedian ( int a [ ] , int n ) {
Arrays . sort ( a ) ;
if ( n % 2 != 0 ) return ( double ) a [ n / 2 ] ; return ( double ) ( a [ ( n - 1 ) / 2 ] + a [ n / 2 ] ) / 2.0 ; }
public static void main ( String args [ ] ) { int a [ ] = { 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 } ; int n = a . length ;
System . out . println ( " Mean ▁ = ▁ " + findMean ( a , n ) ) ; System . out . println ( " Median ▁ = ▁ " + findMedian ( a , n ) ) ; } }
public static void printSmall ( int arr [ ] , int n , int k ) {
for ( int i = k ; i < n ; ++ i ) {
int max_var = arr [ k - 1 ] ; int pos = k - 1 ; for ( int j = k - 2 ; j >= 0 ; j -- ) { if ( arr [ j ] > max_var ) { max_var = arr [ j ] ; pos = j ; } }
if ( max_var > arr [ i ] ) { int j = pos ; while ( j < k - 1 ) { arr [ j ] = arr [ j + 1 ] ; j ++ ; }
arr [ k - 1 ] = arr [ i ] ; } }
for ( int i = 0 ; i < k ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String argc [ ] ) { int [ ] arr = { 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 } ; int n = 10 ; int k = 5 ; printSmall ( arr , n , k ) ; } }
static double sumNodes ( int l ) {
double leafNodeCount = Math . pow ( 2 , l - 1 ) ; double sumLastLevel = 0 ;
sumLastLevel = ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ;
double sum = sumLastLevel * l ; return sum ; }
public static void main ( String [ ] args ) { int l = 3 ; System . out . println ( sumNodes ( l ) ) ; } }
static void add ( int arr [ ] , int N , int lo , int hi , int val ) { arr [ lo ] += val ; if ( hi != N - 1 ) arr [ hi + 1 ] -= val ; }
static void updateArray ( int arr [ ] , int N ) {
for ( int i = 1 ; i < N ; i ++ ) arr [ i ] += arr [ i - 1 ] ; }
static void printArr ( int arr [ ] , int N ) { updateArray ( arr , N ) ; for ( int i = 0 ; i < N ; i ++ ) System . out . print ( " " + arr [ i ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); }
public static void main ( String [ ] args ) { int N = 6 ; int arr [ ] = new int [ N ] ;
add ( arr , N , 0 , 2 , 100 ) ; add ( arr , N , 1 , 5 , 100 ) ; add ( arr , N , 2 , 3 , 100 ) ; printArr ( arr , N ) ; } }
static int GCD ( int a , int b ) { if ( b == 0 ) return a ; return GCD ( b , a % b ) ; }
static void FillPrefixSuffix ( int prefix [ ] , int arr [ ] , int suffix [ ] , int n ) {
prefix [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) prefix [ i ] = GCD ( prefix [ i - 1 ] , arr [ i ] ) ;
suffix [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) suffix [ i ] = GCD ( suffix [ i + 1 ] , arr [ i ] ) ; }
static int GCDoutsideRange ( int l , int r , int prefix [ ] , int suffix [ ] , int n ) {
if ( l == 0 ) return suffix [ r + 1 ] ;
if ( r == n - 1 ) return prefix [ l - 1 ] ; return GCD ( prefix [ l - 1 ] , suffix [ r + 1 ] ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 6 , 9 } ; int n = arr . length ; int prefix [ ] = new int [ n ] ; int suffix [ ] = new int [ n ] ; FillPrefixSuffix ( prefix , arr , suffix , n ) ; int l = 0 , r = 0 ; System . out . println ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; l = 1 ; r = 1 ; System . out . println ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; l = 1 ; r = 2 ; System . out . println ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; } }
static int countInRange ( int arr [ ] , int n , int x , int y ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] >= x && arr [ i ] <= y ) count ++ ; } return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 4 , 9 , 10 , 3 } ; int n = arr . length ;
int i = 1 , j = 4 ; System . out . println ( countInRange ( arr , n , i , j ) ) ; i = 9 ; j = 12 ; System . out . println ( countInRange ( arr , n , i , j ) ) ; } }
static int lowerIndex ( int arr [ ] , int n , int x ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] >= x ) h = mid - 1 ; else l = mid + 1 ; } return l ; }
static int upperIndex ( int arr [ ] , int n , int y ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] <= y ) l = mid + 1 ; else h = mid - 1 ; } return h ; }
static int countInRange ( int arr [ ] , int n , int x , int y ) {
int count = 0 ; count = upperIndex ( arr , n , y ) - lowerIndex ( arr , n , x ) + 1 ; return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 4 , 4 , 9 , 10 , 3 } ; int n = arr . length ;
Arrays . sort ( arr ) ;
int i = 1 , j = 4 ; System . out . println ( countInRange ( arr , n , i , j ) ) ; ; i = 9 ; j = 12 ; System . out . println ( countInRange ( arr , n , i , j ) ) ; } }
static void precompute ( int arr [ ] , int n , int pre [ ] ) { Arrays . fill ( pre , 0 ) ; pre [ n - 1 ] = arr [ n - 1 ] * ( int ) ( Math . pow ( 2 , 0 ) ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) pre [ i ] = pre [ i + 1 ] + arr [ i ] * ( 1 << ( n - 1 - i ) ) ; }
static int decimalOfSubarr ( int arr [ ] , int l , int r , int n , int pre [ ] ) {
if ( r != n - 1 ) return ( pre [ l ] - pre [ r + 1 ] ) / ( 1 << ( n - 1 - r ) ) ; return pre [ l ] / ( 1 << ( n - 1 - r ) ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 0 , 1 , 0 , 1 , 1 } ; int n = arr . length ; int pre [ ] = new int [ n ] ; precompute ( arr , n , pre ) ; System . out . println ( decimalOfSubarr ( arr , 2 , 4 , n , pre ) ) ; System . out . println ( decimalOfSubarr ( arr , 4 , 5 , n , pre ) ) ; } }
static int answerQuery ( int a [ ] , int n , int l , int r ) {
int count = 0 ;
l = l - 1 ;
for ( int i = l ; i < r ; i ++ ) { int element = a [ i ] ; int divisors = 0 ;
for ( int j = l ; j < r ; j ++ ) {
if ( a [ j ] % a [ i ] == 0 ) divisors ++ ; else break ; }
if ( divisors == ( r - l ) ) count ++ ; }
return count ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 3 , 5 } ; int n = a . length ; int l = 1 , r = 4 ; System . out . println ( answerQuery ( a , n , l , r ) ) ; l = 2 ; r = 4 ; System . out . println ( answerQuery ( a , n , l , r ) ) ; } }
import java . lang . Math ; class GFG { private static final int MAX = 2147483647 ; static int [ ] [ ] one = new int [ 100001 ] [ 32 ] ;
static void make_prefix ( int A [ ] , int n ) { for ( int j = 0 ; j < 32 ; j ++ ) one [ 0 ] [ j ] = 0 ;
for ( int i = 1 ; i <= n ; i ++ ) { int a = A [ i - 1 ] ; for ( int j = 0 ; j < 32 ; j ++ ) { int x = ( int ) Math . pow ( 2 , j ) ;
if ( ( a & x ) != 0 ) one [ i ] [ j ] = 1 + one [ i - 1 ] [ j ] ; else one [ i ] [ j ] = one [ i - 1 ] [ j ] ; } } }
static int Solve ( int L , int R ) { int l = L , r = R ; int tot_bits = r - l + 1 ;
int X = MAX ;
for ( int i = 0 ; i < 31 ; i ++ ) {
int x = one [ r ] [ i ] - one [ l - 1 ] [ i ] ;
if ( x >= tot_bits - x ) { int ith_bit = ( int ) Math . pow ( 2 , i ) ;
X = X ^ ith_bit ; } } return X ; }
public static void main ( String [ ] args ) { int n = 5 , q = 3 ; int A [ ] = { 210 , 11 , 48 , 22 , 133 } ; int L [ ] = { 1 , 4 , 2 } , R [ ] = { 3 , 14 , 4 } ; make_prefix ( A , n ) ; for ( int j = 0 ; j < q ; j ++ ) System . out . println ( Solve ( L [ j ] , R [ j ] ) ) ; } }
static int answer_query ( int a [ ] , int n , int l , int r ) {
int count = 0 ; for ( int i = l ; i < r ; i ++ ) if ( a [ i ] == a [ i + 1 ] ) count += 1 ; return count ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = a . length ;
int L , R ; L = 1 ; R = 8 ; System . out . println ( answer_query ( a , n , L , R ) ) ;
L = 0 ; R = 4 ; System . out . println ( answer_query ( a , n , L , R ) ) ; } }
class GFG { public static int N = 1000 ;
static int prefixans [ ] = new int [ 1000 ] ;
public static void countIndex ( int a [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { if ( i + 1 < n && a [ i ] == a [ i + 1 ] ) prefixans [ i ] = 1 ; if ( i != 0 ) prefixans [ i ] += prefixans [ i - 1 ] ; } }
public static int answer_query ( int l , int r ) { if ( l == 0 ) return prefixans [ r - 1 ] ; else return prefixans [ r - 1 ] - prefixans [ l - 1 ] ; }
public static void main ( String args [ ] ) { int a [ ] = { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = 9 ;
countIndex ( a , n ) ; int L , R ;
L = 1 ; R = 8 ; System . out . println ( answer_query ( L , R ) ) ;
L = 0 ; R = 4 ; System . out . println ( answer_query ( L , R ) ) ; } }
static int repeated_digit ( int n ) { LinkedHashSet < Integer > s = new LinkedHashSet < > ( ) ;
while ( n != 0 ) { int d = n % 10 ;
if ( s . contains ( d ) ) {
return 0 ; } s . add ( d ) ; n = n / 10 ; }
return 1 ; }
static int calculate ( int L , int R ) { int answer = 0 ;
for ( int i = L ; i < R + 1 ; ++ i ) {
answer = answer + repeated_digit ( i ) ; } return answer ; }
public static void main ( String [ ] args ) { int L = 1 , R = 100 ;
System . out . println ( calculate ( L , R ) ) ; } }
import java . io . * ; import java . util . * ; class Kadane { static int maxSubArraySum ( int a [ ] ) { int size = a . length ; int max_so_far = Integer . MIN_VALUE , max_ending_here = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here = max_ending_here + a [ i ] ; if ( max_so_far < max_ending_here ) max_so_far = max_ending_here ; if ( max_ending_here < 0 ) max_ending_here = 0 ; } return max_so_far ; }
public static void main ( String [ ] args ) { int [ ] a = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; System . out . println ( " Maximum ▁ contiguous ▁ sum ▁ is ▁ " + maxSubArraySum ( a ) ) ; } }
static int maxSubArraySum ( int a [ ] , int size ) { int max_so_far = a [ 0 ] , max_ending_here = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here = max_ending_here + a [ i ] ; if ( max_ending_here < 0 ) max_ending_here = 0 ;
else if ( max_so_far < max_ending_here ) max_so_far = max_ending_here ; } return max_so_far ; }
import java . io . * ; class GFG { static int maxSubArraySum ( int a [ ] , int size ) { int max_so_far = a [ 0 ] ; int curr_max = a [ 0 ] ; for ( int i = 1 ; i < size ; i ++ ) { curr_max = Math . max ( a [ i ] , curr_max + a [ i ] ) ; max_so_far = Math . max ( max_so_far , curr_max ) ; } return max_so_far ; }
public static void main ( String [ ] args ) { int a [ ] = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; int n = a . length ; int max_sum = maxSubArraySum ( a , n ) ; System . out . println ( " Maximum ▁ contiguous ▁ sum ▁ is ▁ " + max_sum ) ; } }
class GFG { static void maxSubArraySum ( int a [ ] , int size ) { int max_so_far = Integer . MIN_VALUE , max_ending_here = 0 , start = 0 , end = 0 , s = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here += a [ i ] ; if ( max_so_far < max_ending_here ) { max_so_far = max_ending_here ; start = s ; end = i ; } if ( max_ending_here < 0 ) { max_ending_here = 0 ; s = i + 1 ; } } System . out . println ( " Maximum ▁ contiguous ▁ sum ▁ is ▁ " + max_so_far ) ; System . out . println ( " Starting ▁ index ▁ " + start ) ; System . out . println ( " Ending ▁ index ▁ " + end ) ; }
public static void main ( String [ ] args ) { int a [ ] = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; int n = a . length ; maxSubArraySum ( a , n ) ; } }
static void findMinAvgSubarray ( int n , int k ) {
if ( n < k ) return ;
int res_index = 0 ;
int curr_sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) curr_sum += arr [ i ] ;
int min_sum = curr_sum ;
for ( int i = k ; i < n ; i ++ ) {
curr_sum += arr [ i ] - arr [ i - k ] ;
if ( curr_sum < min_sum ) { min_sum = curr_sum ; res_index = ( i - k + 1 ) ; } } System . out . println ( " Subarray ▁ between ▁ [ " + res_index + " , ▁ " + ( res_index + k - 1 ) + " ] ▁ has ▁ minimum ▁ average " ) ; }
public static void main ( String [ ] args ) {
int k = 3 ; findMinAvgSubarray ( arr . length , k ) ; } }
static int minJumps ( int arr [ ] , int n ) {
int [ ] jumps = new int [ n ] ; int min ;
jumps [ n - 1 ] = 0 ;
for ( int i = n - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] == 0 ) jumps [ i ] = Integer . MAX_VALUE ;
else if ( arr [ i ] >= n - i - 1 ) jumps [ i ] = 1 ;
else {
min = Integer . MAX_VALUE ;
for ( int j = i + 1 ; j < n && j <= arr [ i ] + i ; j ++ ) { if ( min > jumps [ j ] ) min = jumps [ j ] ; }
if ( min != Integer . MAX_VALUE ) jumps [ i ] = min + 1 ; else
jumps [ i ] = min ; } } return jumps [ 0 ] ; }
public static void main ( String [ ] args ) { int [ ] arr = { 1 , 3 , 6 , 1 , 0 , 9 } ; int size = arr . length ; System . out . println ( " Minimum ▁ number ▁ of " + " ▁ jumps ▁ to ▁ reach ▁ end ▁ is ▁ " + minJumps ( arr , size ) ) ; } }
static int smallestSubWithSum ( int arr [ ] , int n , int x ) {
int min_len = n + 1 ;
for ( int start = 0 ; start < n ; start ++ ) {
int curr_sum = arr [ start ] ;
if ( curr_sum > x ) return 1 ;
for ( int end = start + 1 ; end < n ; end ++ ) {
curr_sum += arr [ end ] ;
if ( curr_sum > x && ( end - start + 1 ) < min_len ) min_len = ( end - start + 1 ) ; } } return min_len ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = arr1 . length ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; if ( res1 == n1 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res1 ) ; int arr2 [ ] = { 1 , 10 , 5 , 2 , 7 } ; int n2 = arr2 . length ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; if ( res2 == n2 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res2 ) ; int arr3 [ ] = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = arr3 . length ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; if ( res3 == n3 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res3 ) ; } }
static int smallestSubWithSum ( int arr [ ] , int n , int x ) {
int curr_sum = 0 , min_len = n + 1 ;
int start = 0 , end = 0 ; while ( end < n ) {
while ( curr_sum <= x && end < n ) curr_sum += arr [ end ++ ] ;
while ( curr_sum > x && start < n ) {
if ( end - start < min_len ) min_len = end - start ;
curr_sum -= arr [ start ++ ] ; } } return min_len ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = arr1 . length ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; if ( res1 == n1 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res1 ) ; int arr2 [ ] = { 1 , 10 , 5 , 2 , 7 } ; int n2 = arr2 . length ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; if ( res2 == n2 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res2 ) ; int arr3 [ ] = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = arr3 . length ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; if ( res3 == n3 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res3 ) ; } }
static int findMaxAverage ( int [ ] arr , int n , int k ) {
if ( k > n ) return - 1 ;
int [ ] csum = new int [ n ] ; csum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) csum [ i ] = csum [ i - 1 ] + arr [ i ] ;
int max_sum = csum [ k - 1 ] , max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { int curr_sum = csum [ i ] - csum [ i - k ] ; if ( curr_sum > max_sum ) { max_sum = curr_sum ; max_end = i ; } }
return max_end - k + 1 ; }
static public void main ( String [ ] args ) { int [ ] arr = { 1 , 12 , - 5 , - 6 , 50 , 3 } ; int k = 4 ; int n = arr . length ; System . out . println ( " The ▁ maximum ▁ " + " average ▁ subarray ▁ of ▁ length ▁ " + k + " ▁ begins ▁ at ▁ index ▁ " + findMaxAverage ( arr , n , k ) ) ; } }
static int findMaxAverage ( int arr [ ] , int n , int k ) {
if ( k > n ) return - 1 ;
int sum = arr [ 0 ] ; for ( int i = 1 ; i < k ; i ++ ) sum += arr [ i ] ; int max_sum = sum , max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { sum = sum + arr [ i ] - arr [ i - k ] ; if ( sum > max_sum ) { max_sum = sum ; max_end = i ; } }
return max_end - k + 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 12 , - 5 , - 6 , 50 , 3 } ; int k = 4 ; int n = arr . length ; System . out . println ( " The ▁ maximum ▁ average " + " ▁ subarray ▁ of ▁ length ▁ " + k + " ▁ begins ▁ at ▁ index ▁ " + findMaxAverage ( arr , n , k ) ) ; } }
static int countMinOperations ( int n ) {
int result = 0 ;
while ( true ) {
int zero_count = 0 ;
int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] % 2 == 1 ) break ;
else if ( arr [ i ] == 0 ) zero_count ++ ; }
if ( zero_count == n ) return result ;
if ( i == n ) {
for ( int j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] / 2 ; result ++ ; }
for ( int j = i ; j < n ; j ++ ) { if ( arr [ j ] % 2 == 1 ) { arr [ j ] -- ; result ++ ; } } } }
public static void main ( String [ ] args ) { System . out . println ( "Minimum number of steps required to NEW_LINE" + " get ▁ the ▁ given ▁ target ▁ array ▁ is ▁ " + countMinOperations ( arr . length ) ) ; } }
static int findMinOps ( int [ ] arr , int n ) {
int ans = 0 ;
for ( int i = 0 , j = n - 1 ; i <= j ; ) {
if ( arr [ i ] == arr [ j ] ) { i ++ ; j -- ; }
else if ( arr [ i ] > arr [ j ] ) {
j -- ; arr [ j ] += arr [ j + 1 ] ; ans ++ ; }
else { i ++ ; arr [ i ] += arr [ i - 1 ] ; ans ++ ; } } return ans ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 1 , 4 , 5 , 9 , 1 } ; System . out . println ( " Count ▁ of ▁ minimum ▁ operations ▁ is ▁ " + findMinOps ( arr , arr . length ) ) ; } }
int findSmallest ( int arr [ ] , int n ) {
int res = 1 ;
for ( int i = 0 ; i < n && arr [ i ] <= res ; i ++ ) res = res + arr [ i ] ; return res ; }
public static void main ( String [ ] args ) { FindSmallestInteger small = new FindSmallestInteger ( ) ; int arr1 [ ] = { 1 , 3 , 4 , 5 } ; int n1 = arr1 . length ; System . out . println ( small . findSmallest ( arr1 , n1 ) ) ; int arr2 [ ] = { 1 , 2 , 6 , 10 , 11 , 15 } ; int n2 = arr2 . length ; System . out . println ( small . findSmallest ( arr2 , n2 ) ) ; int arr3 [ ] = { 1 , 1 , 1 , 1 } ; int n3 = arr3 . length ; System . out . println ( small . findSmallest ( arr3 , n3 ) ) ; int arr4 [ ] = { 1 , 1 , 3 , 4 } ; int n4 = arr4 . length ; System . out . println ( small . findSmallest ( arr4 , n4 ) ) ; } }
static int findMinDiff ( int [ ] arr , int n ) {
int diff = Integer . MAX_VALUE ;
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( Math . abs ( ( arr [ i ] - arr [ j ] ) ) < diff ) diff = Math . abs ( ( arr [ i ] - arr [ j ] ) ) ;
return diff ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 1 , 5 , 3 , 19 , 18 , 25 } ; System . out . println ( " Minimum ▁ difference ▁ is ▁ " + findMinDiff ( arr , arr . length ) ) ; } }
static int findMinDiff ( int [ ] arr , int n ) {
Arrays . sort ( arr ) ;
int diff = Integer . MAX_VALUE ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i + 1 ] - arr [ i ] < diff ) diff = arr [ i + 1 ] - arr [ i ] ;
return diff ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 1 , 5 , 3 , 19 , 18 , 25 } ; System . out . println ( " Minimum ▁ difference ▁ is ▁ " + findMinDiff ( arr , arr . length ) ) ; } }
public static void main ( String [ ] args ) { int a = 2 , b = 10 ; int size = Math . abs ( b - a ) + 1 ; int array [ ] = new int [ size ] ;
for ( int i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) array [ i - a ] = 1 ; System . out . println ( " MULTIPLES ▁ of ▁ 2" + " ▁ and ▁ 5 : " ) ; for ( int i = a ; i <= b ; i ++ ) if ( array [ i - a ] == 1 ) System . out . printf ( i + " ▁ " ) ; } }
static int longestCommonSum ( int n ) {
int maxLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int sum1 = 0 , sum2 = 0 ;
for ( int j = i ; j < n ; j ++ ) {
sum1 += arr1 [ j ] ; sum2 += arr2 [ j ] ;
if ( sum1 == sum2 ) { int len = j - i + 1 ; if ( len > maxLen ) maxLen = len ; } } } return maxLen ; }
public static void main ( String [ ] args ) { System . out . print ( " Length ▁ of ▁ the ▁ longest ▁ common ▁ span ▁ with ▁ same ▁ sum ▁ is ▁ " ) ; System . out . println ( longestCommonSum ( arr1 . length ) ) ; } }
static boolean sortedAfterSwap ( int A [ ] , boolean B [ ] , int n ) { int i , j ;
for ( i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] ) { j = i ; while ( B [ j ] ) { j ++ ; }
Arrays . sort ( A , i , 1 + j ) ; i = j ; } }
for ( i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) { return false ; } } return true ; }
public static void main ( String [ ] args ) { int A [ ] = { 1 , 2 , 5 , 3 , 4 , 6 } ; boolean B [ ] = { false , true , true , true , false } ; int n = A . length ; if ( sortedAfterSwap ( A , B , n ) ) { System . out . println ( " A ▁ can ▁ be ▁ sorted " ) ; } else { System . out . println ( " A ▁ can ▁ not ▁ be ▁ sorted " ) ; } } }
static int sortedAfterSwap ( int [ ] A , int [ ] B , int n ) { int t = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] != 0 ) { if ( A [ i ] != i + 1 ) t = A [ i ] ; A [ i ] = A [ i + 1 ] ; A [ i + 1 ] = t ; } }
for ( int i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) return 0 ; } return 1 ; }
public static void main ( String [ ] args ) { int [ ] A = { 1 , 2 , 5 , 3 , 4 , 6 } ; int [ ] B = { 0 , 1 , 1 , 1 , 0 } ; int n = A . length ; if ( sortedAfterSwap ( A , B , n ) == 0 ) System . out . println ( " A ▁ can ▁ be ▁ sorted " ) ; else System . out . println ( " A ▁ can ▁ not ▁ be ▁ sorted " ) ; } }
static void segregate0and1 ( int arr [ ] , int n ) { int type0 = 0 ; int type1 = n - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type0 ] = arr [ type0 ] + arr [ type1 ] ; arr [ type1 ] = arr [ type0 ] - arr [ type1 ] ; arr [ type0 ] = arr [ type0 ] - arr [ type1 ] ; type1 -- ; } else { type0 ++ ; } } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 , 1 , 0 , 0 } ; segregate0and1 ( arr , arr . length ) ; for ( int a : arr ) System . out . print ( a + " ▁ " ) ; } }
public static boolean increasing ( int a [ ] , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( a [ i ] >= a [ i + 1 ] ) return false ; return true ; }
public static boolean decreasing ( int arr [ ] , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] < arr [ i + 1 ] ) return false ; return true ; } public static int shortestUnsorted ( int a [ ] , int n ) {
if ( increasing ( a , n ) == true || decreasing ( a , n ) == true ) return 0 ; else return 3 ; }
public static void main ( String [ ] args ) { int ar [ ] = new int [ ] { 7 , 9 , 10 , 8 , 11 } ; int n = ar . length ; System . out . println ( shortestUnsorted ( ar , n ) ) ; } }
static int printUnion ( int arr1 [ ] , int arr2 [ ] , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) System . out . print ( arr1 [ i ++ ] + " ▁ " ) ; else if ( arr2 [ j ] < arr1 [ i ] ) System . out . print ( arr2 [ j ++ ] + " ▁ " ) ; else { System . out . print ( arr2 [ j ++ ] + " ▁ " ) ; i ++ ; } }
while ( i < m ) System . out . print ( arr1 [ i ++ ] + " ▁ " ) ; while ( j < n ) System . out . print ( arr2 [ j ++ ] + " ▁ " ) ; return 0 ; }
public static void main ( String args [ ] ) { int arr1 [ ] = { 1 , 2 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 5 , 7 } ; int m = arr1 . length ; int n = arr2 . length ; printUnion ( arr1 , arr2 , m , n ) ; } }
static void printIntersection ( int arr1 [ ] , int arr2 [ ] , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) i ++ ; else if ( arr2 [ j ] < arr1 [ i ] ) j ++ ; else { System . out . print ( arr2 [ j ++ ] + " ▁ " ) ; i ++ ; } } }
public static void main ( String args [ ] ) { int arr1 [ ] = { 1 , 2 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 5 , 7 } ; int m = arr1 . length ; int n = arr2 . length ;
printIntersection ( arr1 , arr2 , m , n ) ; } }
void printUnion ( int arr1 [ ] , int arr2 [ ] , int m , int n ) {
if ( m > n ) { int tempp [ ] = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
Arrays . sort ( arr1 ) ; for ( int i = 0 ; i < m ; i ++ ) System . out . print ( arr1 [ i ] + " ▁ " ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) == - 1 ) System . out . print ( arr2 [ i ] + " ▁ " ) ; } }
void printIntersection ( int arr1 [ ] , int arr2 [ ] , int m , int n ) {
if ( m > n ) { int tempp [ ] = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
Arrays . sort ( arr1 ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) != - 1 ) System . out . print ( arr2 [ i ] + " ▁ " ) ; } }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
public static void main ( String [ ] args ) { UnionAndIntersection u_i = new UnionAndIntersection ( ) ; int arr1 [ ] = { 7 , 1 , 5 , 2 , 3 , 6 } ; int arr2 [ ] = { 3 , 8 , 6 , 20 , 7 } ; int m = arr1 . length ; int n = arr2 . length ;
System . out . println ( " Union ▁ of ▁ two ▁ arrays ▁ is ▁ " ) ; u_i . printUnion ( arr1 , arr2 , m , n ) ; System . out . println ( " " ) ; System . out . println ( " Intersection ▁ of ▁ two ▁ arrays ▁ is ▁ " ) ; u_i . printIntersection ( arr1 , arr2 , m , n ) ; } }
static void intersection ( int a [ ] , int b [ ] , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) { if ( a [ i ] > b [ j ] ) { j ++ ; } else if ( b [ j ] > a [ i ] ) { i ++ ; } else {
System . out . print ( a [ i ] + " ▁ " ) ; i ++ ; j ++ ; } } }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 3 , 2 , 3 , 4 , 5 , 5 , 6 } ; int b [ ] = { 3 , 3 , 5 } ; int n = a . length ; int m = b . length ;
Arrays . sort ( a ) ; Arrays . sort ( b ) ;
intersection ( a , b , n , m ) ; } }
import java . util . * ; import java . io . * ; class GFG { static int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] - arr [ j ] == k arr [ j ] - arr [ i ] == k ) count ++ ; } return count ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . length ; int k = 3 ; System . out . println ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static int binarySearch ( int arr [ ] , int low , int high , int x ) { if ( high >= low ) { int mid = low + ( high - low ) / 2 ; if ( x == arr [ mid ] ) return mid ; if ( x > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
static int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 , i ;
Arrays . sort ( arr ) ;
for ( i = 0 ; i < n - 1 ; i ++ ) if ( binarySearch ( arr , i + 1 , n - 1 , arr [ i ] + k ) != - 1 ) count ++ ; return count ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . length ; int k = 3 ; System . out . println ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 ;
Arrays . sort ( arr ) ; int l = 0 ; int r = 0 ; while ( r < n ) { if ( arr [ r ] - arr [ l ] == k ) { count ++ ; l ++ ; r ++ ; } else if ( arr [ r ] - arr [ l ] > k ) l ++ ;
else r ++ ; } return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . length ; int k = 3 ; System . out . println ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static void constructArr ( int arr [ ] , int pair [ ] , int n ) { arr [ 0 ] = ( pair [ 0 ] + pair [ 1 ] - pair [ n - 1 ] ) / 2 ; for ( int i = 1 ; i < n ; i ++ ) arr [ i ] = pair [ i - 1 ] - arr [ 0 ] ; }
public static void main ( String [ ] args ) { int pair [ ] = { 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 } ; int n = 5 ; int [ ] arr = new int [ n ] ; constructArr ( arr , pair , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static int arr1 [ ] = new int [ ] { 1 , 5 , 9 , 10 , 15 , 20 } ; static int arr2 [ ] = new int [ ] { 2 , 3 , 8 , 13 } ; static void merge ( int m , int n ) {
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int j , last = arr1 [ m - 1 ] ; for ( j = m - 2 ; j >= 0 && arr1 [ j ] > arr2 [ i ] ; j -- ) arr1 [ j + 1 ] = arr1 [ j ] ;
if ( j != m - 2 last > arr2 [ i ] ) { arr1 [ j + 1 ] = arr2 [ i ] ; arr2 [ i ] = last ; } } }
public static void main ( String [ ] args ) { merge ( arr1 . length , arr2 . length ) ; System . out . print ( " After ▁ Merging ▁ nFirst ▁ Array : ▁ " ) ; System . out . println ( Arrays . toString ( arr1 ) ) ; System . out . print ( " Second ▁ Array : ▁ " ) ; System . out . println ( Arrays . toString ( arr2 ) ) ; } }
public static int minMaxProduct ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) {
Arrays . sort ( arr1 ) ; Arrays . sort ( arr2 ) ;
return arr1 [ n1 - 1 ] * arr2 [ 0 ] ; }
public static void main ( String argc [ ] ) { int [ ] arr1 = new int [ ] { 10 , 2 , 3 , 6 , 4 , 1 } ; int [ ] arr2 = new int [ ] { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = 6 ; int n2 = 6 ; System . out . println ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ; } }
public static int minMaxProduct ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) {
int max = arr1 [ 0 ] ;
int min = arr2 [ 0 ] ; int i ; for ( i = 1 ; i < n1 && i < n2 ; ++ i ) {
if ( arr1 [ i ] > max ) max = arr1 [ i ] ;
if ( arr2 [ i ] < min ) min = arr2 [ i ] ; }
while ( i < n1 ) { if ( arr1 [ i ] > max ) max = arr1 [ i ] ; i ++ ; } while ( i < n2 ) { if ( arr2 [ i ] < min ) min = arr2 [ i ] ; i ++ ; } return max * min ; }
public static void main ( String argc [ ] ) { int [ ] arr1 = new int [ ] { 10 , 2 , 3 , 6 , 4 , 1 } ; int [ ] arr2 = new int [ ] { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = 6 ; int n2 = 6 ; System . out . println ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ; } }
static int insertSorted ( int arr [ ] , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; arr [ n ] = key ; return ( n + 1 ) ; }
public static void main ( String [ ] args ) { int [ ] arr = new int [ 20 ] ; arr [ 0 ] = 12 ; arr [ 1 ] = 16 ; arr [ 2 ] = 20 ; arr [ 3 ] = 40 ; arr [ 4 ] = 50 ; arr [ 5 ] = 70 ; int capacity = 20 ; int n = 6 ; int i , key = 26 ; System . out . print ( " Before ▁ Insertion : ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ;
n = insertSorted ( arr , n , key , capacity ) ; System . out . print ( " After Insertion : "); for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static int findElement ( int arr [ ] , int n , int key ) { int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
static int deleteElement ( int arr [ ] , int n , int key ) {
int pos = findElement ( arr , n , key ) ; if ( pos == - 1 ) { System . out . println ( " Element ▁ not ▁ found " ) ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
public static void main ( String args [ ] ) { int i ; int arr [ ] = { 10 , 50 , 30 , 40 , 20 } ; int n = arr . length ; int key = 30 ; System . out . println ( " Array ▁ before ▁ deletion " ) ; for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; n = deleteElement ( arr , n , key ) ; System . out . println ( " Array after deletion "); for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
void findCommon ( int ar1 [ ] , int ar2 [ ] , int ar3 [ ] ) {
int i = 0 , j = 0 , k = 0 ;
while ( i < ar1 . length && j < ar2 . length && k < ar3 . length ) {
if ( ar1 [ i ] == ar2 [ j ] && ar2 [ j ] == ar3 [ k ] ) { System . out . print ( ar1 [ i ] + " ▁ " ) ; i ++ ; j ++ ; k ++ ; }
else if ( ar1 [ i ] < ar2 [ j ] ) i ++ ;
else if ( ar2 [ j ] < ar3 [ k ] ) j ++ ;
else k ++ ; } }
public static void main ( String args [ ] ) { FindCommon ob = new FindCommon ( ) ; int ar1 [ ] = { 1 , 5 , 10 , 20 , 40 , 80 } ; int ar2 [ ] = { 6 , 7 , 20 , 80 , 100 } ; int ar3 [ ] = { 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 } ; System . out . print ( " Common ▁ elements ▁ are ▁ " ) ; ob . findCommon ( ar1 , ar2 , ar3 ) ; } }
static int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ; if ( arr [ mid ] == x ) return mid ; if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ; return binarySearch ( arr , mid + 1 , r , x ) ; } return - 1 ; }
static int findPos ( int arr [ ] , int key ) { int l = 0 , h = 1 ; int val = arr [ 0 ] ;
while ( val < key ) {
l = h ;
if ( 2 * h < arr . length - 1 ) h = 2 * h ; else h = arr . length - 1 ;
val = arr [ h ] ; }
return binarySearch ( arr , l , h , key ) ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 } ; int ans = findPos ( arr , 10 ) ; if ( ans == - 1 ) System . out . println ( " Element ▁ not ▁ found " ) ; else System . out . println ( " Element ▁ found ▁ at ▁ index ▁ " + ans ) ; } }
static int findSingle ( int ar [ ] , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
public static void main ( String [ ] args ) { int ar [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = ar . length ; System . out . println ( " Element ▁ occurring ▁ once ▁ is ▁ " + findSingle ( ar , n ) + " ▁ " ) ; } }
static boolean isPresent ( int B [ ] , int m , int x ) { for ( int i = 0 ; i < m ; i ++ ) if ( B [ i ] == x ) return true ; return false ; }
static int findMaxSubarraySumUtil ( int A [ ] , int B [ ] , int n , int m ) {
int max_so_far = - 2147483648 , curr_max = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( isPresent ( B , m , A [ i ] ) ) { curr_max = 0 ; continue ; }
curr_max = Math . max ( A [ i ] , curr_max + A [ i ] ) ; max_so_far = Math . max ( max_so_far , curr_max ) ; } return max_so_far ; }
static void findMaxSubarraySum ( int A [ ] , int B [ ] , int n , int m ) { int maxSubarraySum = findMaxSubarraySumUtil ( A , B , n , m ) ;
if ( maxSubarraySum == - 2147483648 ) { System . out . println ( " Maximum ▁ Subarray ▁ Sum " + " ▁ " + " can ' t ▁ be ▁ found " ) ; } else { System . out . println ( " The ▁ Maximum ▁ Subarray ▁ Sum ▁ = ▁ " + maxSubarraySum ) ; } }
public static void main ( String [ ] args ) { int A [ ] = { 3 , 4 , 5 , - 4 , 6 } ; int B [ ] = { 1 , 8 , 5 } ; int n = A . length ; int m = B . length ;
findMaxSubarraySum ( A , B , n , m ) ; } }
static int findMaxSum ( int [ ] arr , int n ) { int res = Integer . MIN_VALUE ; for ( int i = 0 ; i < n ; i ++ ) { int prefix_sum = arr [ i ] ; for ( int j = 0 ; j < i ; j ++ ) prefix_sum += arr [ j ] ; int suffix_sum = arr [ i ] ; for ( int j = n - 1 ; j > i ; j -- ) suffix_sum += arr [ j ] ; if ( prefix_sum == suffix_sum ) res = Math . max ( res , prefix_sum ) ; } return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 } ; int n = arr . length ; System . out . println ( findMaxSum ( arr , n ) ) ; } }
static int findMaxSum ( int [ ] arr , int n ) {
int [ ] preSum = new int [ n ] ;
int [ ] suffSum = new int [ n ] ;
int ans = Integer . MIN_VALUE ;
preSum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) preSum [ i ] = preSum [ i - 1 ] + arr [ i ] ;
suffSum [ n - 1 ] = arr [ n - 1 ] ; if ( preSum [ n - 1 ] == suffSum [ n - 1 ] ) ans = Math . max ( ans , preSum [ n - 1 ] ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) { suffSum [ i ] = suffSum [ i + 1 ] + arr [ i ] ; if ( suffSum [ i ] == preSum [ i ] ) ans = Math . max ( ans , preSum [ i ] ) ; } return ans ; }
static public void main ( String [ ] args ) { int [ ] arr = { - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 } ; int n = arr . length ; System . out . println ( findMaxSum ( arr , n ) ) ; } }
class LeadersInArray { void printLeaders ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) { int j ; for ( j = i + 1 ; j < size ; j ++ ) { if ( arr [ i ] <= arr [ j ] ) break ; }
if ( j == size ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { LeadersInArray lead = new LeadersInArray ( ) ; int arr [ ] = new int [ ] { 16 , 17 , 4 , 3 , 5 , 2 } ; int n = arr . length ; lead . printLeaders ( arr , n ) ; } }
void printLeaders ( int arr [ ] , int size ) { int max_from_right = arr [ size - 1 ] ;
System . out . print ( max_from_right + " ▁ " ) ; for ( int i = size - 2 ; i >= 0 ; i -- ) { if ( max_from_right < arr [ i ] ) { max_from_right = arr [ i ] ; System . out . print ( max_from_right + " ▁ " ) ; } } }
public static void main ( String [ ] args ) { LeadersInArray lead = new LeadersInArray ( ) ; int arr [ ] = new int [ ] { 16 , 17 , 4 , 3 , 5 , 2 } ; int n = arr . length ; lead . printLeaders ( arr , n ) ; } }
static void findMajority ( int arr [ ] , int n ) { int maxCount = 0 ;
int index = - 1 ; for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; }
if ( count > maxCount ) { maxCount = count ; index = i ; } }
if ( maxCount > n / 2 ) System . out . println ( arr [ index ] ) ; else System . out . println ( " No ▁ Majority ▁ Element " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 2 , 1 , 3 , 5 , 1 } ; int n = arr . length ;
findMajority ( arr , n ) ; } }
import java . io . * ; class GFG { static int maxTripletSum ( int arr [ ] , int n ) {
int sum = - 1000000 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( sum < arr [ i ] + arr [ j ] + arr [ k ] ) sum = arr [ i ] + arr [ j ] + arr [ k ] ; return sum ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . length ; System . out . println ( maxTripletSum ( arr , n ) ) ; } }
static int maxTripletSum ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
return arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . length ; System . out . println ( maxTripletSum ( arr , n ) ) ; } }
static int maxTripletSum ( int arr [ ] , int n ) {
int maxA = - 100000000 , maxB = - 100000000 ; int maxC = - 100000000 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > maxA ) { maxC = maxB ; maxB = maxA ; maxA = arr [ i ] ; }
else if ( arr [ i ] > maxB ) { maxC = maxB ; maxB = arr [ i ] ; }
else if ( arr [ i ] > maxC ) maxC = arr [ i ] ; } return ( maxA + maxB + maxC ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . length ; System . out . println ( maxTripletSum ( arr , n ) ) ; } }
static int maximum ( int a , int b , int c ) { return Math . max ( Math . max ( a , b ) , c ) ; }
static int minimum ( int a , int b , int c ) { return Math . min ( Math . min ( a , b ) , c ) ; }
static void smallestDifferenceTriplet ( int arr1 [ ] , int arr2 [ ] , int arr3 [ ] , int n ) {
Arrays . sort ( arr1 ) ; Arrays . sort ( arr2 ) ; Arrays . sort ( arr3 ) ;
int res_min = 0 , res_max = 0 , res_mid = 0 ;
int i = 0 , j = 0 , k = 0 ;
int diff = 2147483647 ; while ( i < n && j < n && k < n ) { int sum = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
int max = maximum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ;
int min = minimum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ; if ( min == arr1 [ i ] ) i ++ ; else if ( min == arr2 [ j ] ) j ++ ; else k ++ ;
if ( diff > ( max - min ) ) { diff = max - min ; res_max = max ; res_mid = sum - ( max + min ) ; res_min = min ; } }
System . out . print ( res_max + " , ▁ " + res_mid + " , ▁ " + res_min ) ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 5 , 2 , 8 } ; int arr2 [ ] = { 10 , 7 , 12 } ; int arr3 [ ] = { 9 , 14 , 6 } ; int n = arr1 . length ; smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) ; } }
boolean find3Numbers ( int A [ ] , int arr_size , int sum ) { int l , r ;
quickSort ( A , 0 , arr_size - 1 ) ;
for ( int i = 0 ; i < arr_size - 2 ; i ++ ) {
l = i + 1 ;
r = arr_size - 1 ; while ( l < r ) { if ( A [ i ] + A [ l ] + A [ r ] == sum ) { System . out . print ( " Triplet ▁ is ▁ " + A [ i ] + " , ▁ " + A [ l ] + " , ▁ " + A [ r ] ) ; return true ; } else if ( A [ i ] + A [ l ] + A [ r ] < sum ) l ++ ;
else r -- ; } }
return false ; }
public static void main ( String [ ] args ) { FindTriplet triplet = new FindTriplet ( ) ; int A [ ] = { 1 , 4 , 45 , 6 , 10 , 8 } ; int sum = 22 ; int arr_size = A . length ; triplet . find3Numbers ( A , arr_size , sum ) ; } }
static void subArray ( int n ) {
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i ; j < n ; j ++ ) {
for ( int k = i ; k <= j ; k ++ ) System . out . print ( arr [ k ] + " ▁ " ) ; } } }
public static void main ( String [ ] args ) { System . out . println ( " All ▁ Non - empty ▁ Subarrays " ) ; subArray ( arr . length ) ; } }
import java . math . BigInteger ; class Test { static int arr [ ] = new int [ ] { 1 , 2 , 3 , 4 } ; static void printSubsequences ( int n ) {
int opsize = ( int ) Math . pow ( 2 , n ) ;
for ( int counter = 1 ; counter < opsize ; counter ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( BigInteger . valueOf ( counter ) . testBit ( j ) ) System . out . print ( arr [ j ] + " ▁ " ) ; } System . out . println ( ) ; } }
public static void main ( String [ ] args ) { System . out . println ( " All ▁ Non - empty ▁ Subsequences " ) ; printSubsequences ( arr . length ) ; } }
void productArray ( int arr [ ] , int n ) {
if ( n == 1 ) { System . out . print ( "0" ) ; return ; } int i , temp = 1 ;
int prod [ ] = new int [ n ] ;
for ( int j = 0 ; j < n ; j ++ ) prod [ j ] = 1 ;
for ( i = 0 ; i < n ; i ++ ) { prod [ i ] = temp ; temp *= arr [ i ] ; }
temp = 1 ;
for ( i = n - 1 ; i >= 0 ; i -- ) { prod [ i ] *= temp ; temp *= arr [ i ] ; }
for ( i = 0 ; i < n ; i ++ ) System . out . print ( prod [ i ] + " ▁ " ) ; return ; }
public static void main ( String [ ] args ) { ProductArray pa = new ProductArray ( ) ; int arr [ ] = { 10 , 3 , 5 , 6 , 2 } ; int n = arr . length ; System . out . println ( " The ▁ product ▁ array ▁ is ▁ : ▁ " ) ; pa . productArray ( arr , n ) ; } }
boolean areConsecutive ( int arr [ ] , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) {
boolean visited [ ] = new boolean [ n ] ; int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( visited [ arr [ i ] - min ] != false ) return false ;
visited [ arr [ i ] - min ] = true ; }
return true ; }
return false ; }
int getMin ( int arr [ ] , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void main ( String [ ] args ) { AreConsecutive consecutive = new AreConsecutive ( ) ; int arr [ ] = { 5 , 4 , 2 , 3 , 1 , 6 } ; int n = arr . length ; if ( consecutive . areConsecutive ( arr , n ) == true ) System . out . println ( " Array ▁ elements ▁ are ▁ consecutive " ) ; else System . out . println ( " Array ▁ elements ▁ are ▁ not ▁ consecutive " ) ; } }
boolean areConsecutive ( int arr [ ] , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { int j ; if ( arr [ i ] < 0 ) j = - arr [ i ] - min ; else j = arr [ i ] - min ;
if ( arr [ j ] > 0 ) arr [ j ] = - arr [ j ] ; else return false ; }
return true ; }
return false ; }
int getMin ( int arr [ ] , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void main ( String [ ] args ) { AreConsecutive consecutive = new AreConsecutive ( ) ; int arr [ ] = { 5 , 4 , 2 , 3 , 1 , 6 } ; int n = arr . length ; if ( consecutive . areConsecutive ( arr , n ) == true ) System . out . println ( " Array ▁ elements ▁ are ▁ consecutive " ) ; else System . out . println ( " Array ▁ elements ▁ are ▁ not ▁ consecutive " ) ; } }
class GFG { static void relativeComplement ( int arr1 [ ] , int arr2 [ ] , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) {
if ( arr1 [ i ] < arr2 [ j ] ) { System . out . print ( arr1 [ i ] + " ▁ " ) ; i ++ ;
} else if ( arr1 [ i ] > arr2 [ j ] ) { j ++ ;
} else if ( arr1 [ i ] == arr2 [ j ] ) { i ++ ; j ++ ; } }
while ( i < n ) System . out . print ( arr1 [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 3 , 6 , 10 , 12 , 15 } ; int arr2 [ ] = { 1 , 3 , 5 , 10 , 16 } ; int n = arr1 . length ; int m = arr2 . length ; relativeComplement ( arr1 , arr2 , n , m ) ; } }
static int minOps ( int arr [ ] , int n , int k ) {
Arrays . sort ( arr ) ; int max = arr [ arr . length - 1 ] ; int res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ( max - arr [ i ] ) % k != 0 ) return - 1 ;
else res += ( max - arr [ i ] ) / k ; }
return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { 21 , 33 , 9 , 45 , 63 } ; int n = arr . length ; int k = 6 ; System . out . println ( minOps ( arr , n , k ) ) ; } }
import java . util . * ; class GFG { static int solve ( int [ ] A , int [ ] B , int [ ] C ) { int i , j , k ;
min_diff = Math . abs ( Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) - Math . min ( A [ i ] , Math . min ( B [ j ] , C [ k ] ) ) ) ; while ( i != - 1 && j != - 1 && k != - 1 ) { current_diff = Math . abs ( Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) - Math . min ( A [ i ] , Math . min ( B [ j ] , C [ k ] ) ) ) ;
if ( current_diff < min_diff ) min_diff = current_diff ;
max_term = Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) ;
if ( A [ i ] == max_term ) i -= 1 ; else if ( B [ j ] == max_term ) j -= 1 ; else k -= 1 ; } return min_diff ; }
public static void main ( String [ ] args ) { int [ ] D = { 5 , 8 , 10 , 15 } ; int [ ] E = { 6 , 9 , 15 , 78 , 89 } ; int [ ] F = { 2 , 3 , 6 , 6 , 8 , 8 , 10 } ; System . out . println ( solve ( D , E , F ) ) ; } }
static int search ( int arr [ ] , int n , int x ) { int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == x ) { return i ; } } return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 10 , 30 , 15 } ; int x = 30 ; int n = arr . length ; System . out . printf ( " % d ▁ is ▁ present ▁ at ▁ index ▁ % d " , x , search ( arr , n , x ) ) ; } }
int binarySearch ( int arr [ ] , int x ) { int l = 0 , r = arr . length - 1 ; while ( l <= r ) { int m = l + ( r - l ) / 2 ;
if ( arr [ m ] == x ) return m ;
if ( arr [ m ] < x ) l = m + 1 ;
else r = m - 1 ; }
return - 1 ; }
public static void main ( String args [ ] ) { BinarySearch ob = new BinarySearch ( ) ; int arr [ ] = { 2 , 3 , 4 , 10 , 40 } ; int n = arr . length ; int x = 10 ; int result = ob . binarySearch ( arr , x ) ; if ( result == - 1 ) System . out . println ( " Element ▁ not ▁ present " ) ; else System . out . println ( " Element ▁ found ▁ at ▁ " + " index ▁ " + result ) ; } }
public class JumpSearch { public static int jumpSearch ( int [ ] arr , int x ) { int n = arr . length ;
int step = ( int ) Math . floor ( Math . sqrt ( n ) ) ;
int prev = 0 ; while ( arr [ Math . min ( step , n ) - 1 ] < x ) { prev = step ; step += ( int ) Math . floor ( Math . sqrt ( n ) ) ; if ( prev >= n ) return - 1 ; }
while ( arr [ prev ] < x ) { prev ++ ;
if ( prev == Math . min ( step , n ) ) return - 1 ; }
if ( arr [ prev ] == x ) return prev ; return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 } ; int x = 55 ;
int index = jumpSearch ( arr , x ) ;
System . out . println ( " Number " ▁ + ▁ x ▁ + ▁ " is at index " + index); } }
static int exponentialSearch ( int arr [ ] , int n , int x ) {
if ( arr [ 0 ] == x ) return 0 ;
int i = 1 ; while ( i < n && arr [ i ] <= x ) i = i * 2 ;
return Arrays . binarySearch ( arr , i / 2 , Math . min ( i , n - 1 ) , x ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , 3 , 4 , 10 , 40 } ; int x = 10 ; int result = exponentialSearch ( arr , arr . length , x ) ; System . out . println ( ( result < 0 ) ? " Element ▁ is ▁ not ▁ present ▁ in ▁ array " : " Element ▁ is ▁ present ▁ at ▁ index ▁ " + result ) ; } }
void sort ( int arr [ ] ) { int n = arr . length ;
for ( int i = 0 ; i < n - 1 ; i ++ ) {
int min_idx = i ; for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ j ] < arr [ min_idx ] ) min_idx = j ;
int temp = arr [ min_idx ] ; arr [ min_idx ] = arr [ i ] ; arr [ i ] = temp ; } }
public static void main ( String args [ ] ) { SelectionSort ob = new SelectionSort ( ) ; int arr [ ] = { 64 , 25 , 12 , 22 , 11 } ; ob . sort ( arr ) ; System . out . println ( " Sorted ▁ array " ) ; ob . printArray ( arr ) ; } }
static void bubbleSort ( int arr [ ] , int n ) { int i , j , temp ; boolean swapped ; for ( i = 0 ; i < n - 1 ; i ++ ) { swapped = false ; for ( j = 0 ; j < n - i - 1 ; j ++ ) { if ( arr [ j ] > arr [ j + 1 ] ) {
temp = arr [ j ] ; arr [ j ] = arr [ j + 1 ] ; arr [ j + 1 ] = temp ; swapped = true ; } }
if ( swapped == false ) break ; } }
public static void main ( String args [ ] ) { int arr [ ] = { 64 , 34 , 25 , 12 , 22 , 11 , 90 } ; int n = arr . length ; bubbleSort ( arr , n ) ; System . out . println ( " Sorted ▁ array : ▁ " ) ; printArray ( arr , n ) ; } }
static void countSort ( int arr [ ] , int n , int exp ) {
int output [ ] = new int [ n ] ; int i ; int count [ ] = new int [ 10 ] ; Arrays . fill ( count , 0 ) ;
for ( i = 0 ; i < n ; i ++ ) count [ ( arr [ i ] / exp ) % 10 ] ++ ;
for ( i = 1 ; i < 10 ; i ++ ) count [ i ] += count [ i - 1 ] ;
for ( i = n - 1 ; i >= 0 ; i -- ) { output [ count [ ( arr [ i ] / exp ) % 10 ] - 1 ] = arr [ i ] ; count [ ( arr [ i ] / exp ) % 10 ] -- ; }
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = output [ i ] ; }
static void radixsort ( int arr [ ] , int n ) {
int m = getMax ( arr , n ) ;
for ( int exp = 1 ; m / exp > 0 ; exp *= 10 ) countSort ( arr , n , exp ) ; }
static void print ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 170 , 45 , 75 , 90 , 802 , 24 , 2 , 66 } ; int n = arr . length ;
radixsort ( arr , n ) ; print ( arr , n ) ; } }
static int partition ( int arr [ ] , int low , int high ) { int pivot = arr [ high ] ; int i = ( low - 1 ) ; for ( int j = low ; j <= high - 1 ; j ++ ) { if ( arr [ j ] <= pivot ) { i ++ ; int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } } int temp = arr [ i + 1 ] ; arr [ i + 1 ] = arr [ high ] ; arr [ high ] = temp ; return i + 1 ; }
static void qSort ( int arr [ ] , int low , int high ) { if ( low < high ) {
int pi = partition ( arr , low , high ) ; qSort ( arr , low , pi - 1 ) ; qSort ( arr , pi + 1 , high ) ; } }
public static void main ( String args [ ] ) { int n = 5 ; int arr [ ] = { 4 , 2 , 6 , 9 , 2 } ; qSort ( arr , 0 , n - 1 ) ; for ( int i = 0 ; i < n ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } } }
static int partition ( int arr [ ] , int low , int high ) { int pivot = arr [ high ] ; int i = ( low - 1 ) ; for ( int j = low ; j <= high - 1 ; j ++ ) { if ( arr [ j ] <= pivot ) { i ++ ; int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } } int temp = arr [ i + 1 ] ; arr [ i + 1 ] = arr [ high ] ; arr [ high ] = temp ; return i + 1 ; }
static void quickSortIterative ( int arr [ ] , int l , int h ) {
int [ ] stack = new int [ h - l + 1 ] ;
int top = - 1 ;
stack [ ++ top ] = l ; stack [ ++ top ] = h ;
while ( top >= 0 ) {
h = stack [ top -- ] ; l = stack [ top -- ] ;
int p = partition ( arr , l , h ) ;
if ( p - 1 > l ) { stack [ ++ top ] = l ; stack [ ++ top ] = p - 1 ; }
if ( p + 1 < h ) { stack [ ++ top ] = p + 1 ; stack [ ++ top ] = h ; } } }
public static void main ( String args [ ] ) { int arr [ ] = { 4 , 3 , 5 , 2 , 1 , 3 , 2 , 3 } ; int n = 8 ;
quickSortIterative ( arr , 0 , n - 1 ) ; for ( int i = 0 ; i < n ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } } }
int findCrossOver ( int arr [ ] , int low , int high , int x ) {
if ( arr [ high ] <= x ) return high ;
if ( arr [ low ] > x ) return low ;
int mid = ( low + high ) / 2 ;
if ( arr [ mid ] <= x && arr [ mid + 1 ] > x ) return mid ;
if ( arr [ mid ] < x ) return findCrossOver ( arr , mid + 1 , high , x ) ; return findCrossOver ( arr , low , mid - 1 , x ) ; }
void printKclosest ( int arr [ ] , int x , int k , int n ) {
int l = findCrossOver ( arr , 0 , n - 1 , x ) ;
int r = l + 1 ;
int count = 0 ;
if ( arr [ l ] == x ) l -- ;
while ( l >= 0 && r < n && count < k ) { if ( x - arr [ l ] < arr [ r ] - x ) System . out . print ( arr [ l -- ] + " ▁ " ) ; else System . out . print ( arr [ r ++ ] + " ▁ " ) ; count ++ ; }
while ( count < k && l >= 0 ) { System . out . print ( arr [ l -- ] + " ▁ " ) ; count ++ ; }
while ( count < k && r < n ) { System . out . print ( arr [ r ++ ] + " ▁ " ) ; count ++ ; } }
public static void main ( String args [ ] ) { KClosest ob = new KClosest ( ) ; int arr [ ] = { 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 } ; int n = arr . length ; int x = 35 , k = 4 ; ob . printKclosest ( arr , x , 4 , n ) ; } }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ; if ( mid > l && arr [ mid - 1 ] == x ) return ( mid - 1 ) ; if ( mid < r && arr [ mid + 1 ] == x ) return ( mid + 1 ) ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 2 , x ) ;
return binarySearch ( arr , mid + 2 , r , x ) ; }
return - 1 ; }
public static void main ( String args [ ] ) { GFG ob = new GFG ( ) ; int arr [ ] = { 3 , 2 , 10 , 4 , 40 } ; int n = arr . length ; int x = 4 ; int result = ob . binarySearch ( arr , 0 , n - 1 , x ) ; if ( result == - 1 ) System . out . println ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) ; else System . out . println ( " Element ▁ is ▁ present ▁ at ▁ index ▁ " + result ) ; } }
void printClosest ( int ar1 [ ] , int ar2 [ ] , int m , int n , int x ) {
int diff = Integer . MAX_VALUE ;
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 ; while ( l < m && r >= 0 ) {
if ( Math . abs ( ar1 [ l ] + ar2 [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( ar1 [ l ] + ar2 [ r ] - x ) ; }
if ( ar1 [ l ] + ar2 [ r ] > x ) r -- ;
else l ++ ; }
System . out . print ( " The ▁ closest ▁ pair ▁ is ▁ [ " + ar1 [ res_l ] + " , ▁ " + ar2 [ res_r ] + " ] " ) ; }
public static void main ( String args [ ] ) { ClosestPair ob = new ClosestPair ( ) ; int ar1 [ ] = { 1 , 4 , 5 , 7 } ; int ar2 [ ] = { 10 , 20 , 30 , 40 } ; int m = ar1 . length ; int n = ar2 . length ; int x = 38 ; ob . printClosest ( ar1 , ar2 , m , n , x ) ; } }
static void printClosest ( int arr [ ] , int n , int x ) {
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 , diff = Integer . MAX_VALUE ;
while ( r > l ) {
if ( Math . abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } System . out . println ( " ▁ The ▁ closest ▁ pair ▁ is ▁ " + arr [ res_l ] + " ▁ and ▁ " + arr [ res_r ] ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 10 , 22 , 28 , 29 , 30 , 40 } , x = 54 ; int n = arr . length ; printClosest ( arr , n , x ) ; } }
int countOnes ( int arr [ ] , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
public static void main ( String args [ ] ) { CountOnes ob = new CountOnes ( ) ; int arr [ ] = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = arr . length ; System . out . println ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " + ob . countOnes ( arr , 0 , n - 1 ) ) ; } }
public static void minimumSwaps ( int a [ ] , int n ) { int maxx = - 1 , minn = a [ 0 ] , l = 0 , r = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] > maxx ) { maxx = a [ i ] ; l = i ; }
if ( a [ i ] <= minn ) { minn = a [ i ] ; r = i ; } } if ( r < l ) System . out . println ( l + ( n - r - 2 ) ) ; else System . out . println ( l + ( n - r - 1 ) ) ; }
public static void main ( String args [ ] ) throws IOException { int a [ ] = { 5 , 6 , 1 , 3 } ; int n = a . length ; minimumSwaps ( a , n ) ; } }
int lcs ( char [ ] X , char [ ] Y , int m , int n ) { if ( m == 0 n == 0 ) return 0 ; if ( X [ m - 1 ] == Y [ n - 1 ] ) return 1 + lcs ( X , Y , m - 1 , n - 1 ) ; else return max ( lcs ( X , Y , m , n - 1 ) , lcs ( X , Y , m - 1 , n ) ) ; }
public static void main ( String [ ] args ) { LongestCommonSubsequence lcs = new LongestCommonSubsequence ( ) ; String s1 = " AGGTAB " ; String s2 = " GXTXAYB " ; char [ ] X = s1 . toCharArray ( ) ; char [ ] Y = s2 . toCharArray ( ) ; int m = X . length ; int n = Y . length ; System . out . println ( " Length ▁ of ▁ LCS ▁ is " + " ▁ " + lcs . lcs ( X , Y , m , n ) ) ; } }
public class LongestCommonSubsequence {
int lcs ( char [ ] X , char [ ] Y , int m , int n ) { int L [ ] [ ] = new int [ m + 1 ] [ n + 1 ] ;
for ( int i = 0 ; i <= m ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) { if ( i == 0 j == 0 ) L [ i ] [ j ] = 0 ; else if ( X [ i - 1 ] == Y [ j - 1 ] ) L [ i ] [ j ] = L [ i - 1 ] [ j - 1 ] + 1 ; else L [ i ] [ j ] = max ( L [ i - 1 ] [ j ] , L [ i ] [ j - 1 ] ) ; } }
return L [ m ] [ n ] ; }
public static void main ( String [ ] args ) { LongestCommonSubsequence lcs = new LongestCommonSubsequence ( ) ; String s1 = " AGGTAB " ; String s2 = " GXTXAYB " ; char [ ] X = s1 . toCharArray ( ) ; char [ ] Y = s2 . toCharArray ( ) ; int m = X . length ; int n = Y . length ; System . out . println ( " Length ▁ of ▁ LCS ▁ is " + " ▁ " + lcs . lcs ( X , Y , m , n ) ) ; } }
public static int count ( int S [ ] , int m , int n ) {
int table [ ] = new int [ n + 1 ] ;
table [ 0 ] = 1 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = S [ i ] ; j <= n ; j ++ ) table [ j ] += table [ j - S [ i ] ] ; return table [ n ] ; }
import java . util . * ; class GFG { static int binomialCoeff ( int n , int k ) { int C [ ] = new int [ k + 1 ] ;
C [ 0 ] = 1 ; for ( int i = 1 ; i <= n ; i ++ ) {
for ( int j = Math . min ( i , k ) ; j > 0 ; j -- ) C [ j ] = C [ j ] + C [ j - 1 ] ; } return C [ k ] ; }
public static void main ( String [ ] args ) { int n = 5 , k = 2 ; System . out . printf ( " Value ▁ of ▁ C ( % d , ▁ % d ) ▁ is ▁ % d ▁ " , n , k , binomialCoeff ( n , k ) ) ; } }
static int eggDrop ( int n , int k ) {
int eggFloor [ ] [ ] = new int [ n + 1 ] [ k + 1 ] ; int res ; int i , j , x ;
for ( i = 1 ; i <= n ; i ++ ) { eggFloor [ i ] [ 1 ] = 1 ; eggFloor [ i ] [ 0 ] = 0 ; }
for ( j = 1 ; j <= k ; j ++ ) eggFloor [ 1 ] [ j ] = j ;
for ( i = 2 ; i <= n ; i ++ ) { for ( j = 2 ; j <= k ; j ++ ) { eggFloor [ i ] [ j ] = Integer . MAX_VALUE ; for ( x = 1 ; x <= j ; x ++ ) { res = 1 + max ( eggFloor [ i - 1 ] [ x - 1 ] , eggFloor [ i ] [ j - x ] ) ; if ( res < eggFloor [ i ] [ j ] ) eggFloor [ i ] [ j ] = res ; } } }
return eggFloor [ n ] [ k ] ; }
public static void main ( String args [ ] ) { int n = 2 , k = 10 ; System . out . println ( " Minimum ▁ number ▁ of ▁ trials ▁ in ▁ worst " + " ▁ case ▁ with ▁ " + n + " ▁ eggs ▁ and ▁ " + k + " ▁ floors ▁ is ▁ " + eggDrop ( n , k ) ) ; } }
static int max ( int x , int y ) { return ( x > y ) ? x : y ; }
static int lps ( String seq ) { int n = seq . length ( ) ; int i , j , cl ;
int L [ ] [ ] = new int [ n ] [ n ] ;
for ( i = 0 ; i < n ; i ++ ) L [ i ] [ i ] = 1 ;
for ( cl = 2 ; cl <= n ; cl ++ ) { for ( i = 0 ; i < n - cl + 1 ; i ++ ) { j = i + cl - 1 ; if ( seq . charAt ( i ) == seq . charAt ( j ) && cl == 2 ) L [ i ] [ j ] = 2 ; else if ( seq . charAt ( i ) == seq . charAt ( j ) ) L [ i ] [ j ] = L [ i + 1 ] [ j - 1 ] + 2 ; else L [ i ] [ j ] = max ( L [ i ] [ j - 1 ] , L [ i + 1 ] [ j ] ) ; } } return L [ 0 ] [ n - 1 ] ; }
public static void main ( String args [ ] ) { String seq = " GEEKSFORGEEKS " ; int n = seq . length ( ) ; System . out . println ( " The ▁ length ▁ of ▁ the ▁ lps ▁ is ▁ " + lps ( seq ) ) ; } }
static int cutRod ( int price [ ] , int n ) { if ( n <= 0 ) return 0 ; int max_val = Integer . MIN_VALUE ;
for ( int i = 0 ; i < n ; i ++ ) max_val = Math . max ( max_val , price [ i ] + cutRod ( price , n - i - 1 ) ) ; return max_val ; }
public static void main ( String args [ ] ) { int arr [ ] = new int [ ] { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = arr . length ; System . out . println ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " + cutRod ( arr , size ) ) ; } }
static int cutRod ( int price [ ] , int n ) { int val [ ] = new int [ n + 1 ] ; val [ 0 ] = 0 ;
for ( int i = 1 ; i <= n ; i ++ ) { int max_val = Integer . MIN_VALUE ; for ( int j = 0 ; j < i ; j ++ ) max_val = Math . max ( max_val , price [ j ] + val [ i - j - 1 ] ) ; val [ i ] = max_val ; } return val [ n ] ; }
public static void main ( String args [ ] ) { int arr [ ] = new int [ ] { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = arr . length ; System . out . println ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " + cutRod ( arr , size ) ) ; } }
static int lbs ( int arr [ ] , int n ) { int i , j ;
int [ ] lis = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
int [ ] lds = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lds [ i ] = 1 ;
for ( i = n - 2 ; i >= 0 ; i -- ) for ( j = n - 1 ; j > i ; j -- ) if ( arr [ i ] > arr [ j ] && lds [ i ] < lds [ j ] + 1 ) lds [ i ] = lds [ j ] + 1 ;
int max = lis [ 0 ] + lds [ 0 ] - 1 ; for ( i = 1 ; i < n ; i ++ ) if ( lis [ i ] + lds [ i ] - 1 > max ) max = lis [ i ] + lds [ i ] - 1 ; return max ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 } ; int n = arr . length ; System . out . println ( " Length ▁ of ▁ LBS ▁ is ▁ " + lbs ( arr , n ) ) ; } }
static int maxDivide ( int a , int b ) { while ( a % b == 0 ) a = a / b ; return a ; }
static int isUgly ( int no ) { no = maxDivide ( no , 2 ) ; no = maxDivide ( no , 3 ) ; no = maxDivide ( no , 5 ) ; return ( no == 1 ) ? 1 : 0 ; }
static int getNthUglyNo ( int n ) { int i = 1 ;
int count = 1 ;
while ( n > count ) { i ++ ; if ( isUgly ( i ) == 1 ) count ++ ; } return i ; }
public static void main ( String args [ ] ) { int no = getNthUglyNo ( 150 ) ; System . out . println ( "150th ▁ ugly ▁ " + " no . ▁ is ▁ " + no ) ; } }
static boolean isSubsetSum ( int set [ ] , int n , int sum ) {
if ( sum == 0 ) return true ; if ( n == 0 ) return false ;
if ( set [ n - 1 ] > sum ) return isSubsetSum ( set , n - 1 , sum ) ;
return isSubsetSum ( set , n - 1 , sum ) || isSubsetSum ( set , n - 1 , sum - set [ n - 1 ] ) ; }
public static void main ( String args [ ] ) { int set [ ] = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = set . length ; if ( isSubsetSum ( set , n , sum ) == true ) System . out . println ( " Found ▁ a ▁ subset " + " ▁ with ▁ given ▁ sum " ) ; else System . out . println ( " No ▁ subset ▁ with " + " ▁ given ▁ sum " ) ; } }
static boolean isSubsetSum ( int set [ ] , int n , int sum ) {
boolean subset [ ] [ ] = new boolean [ sum + 1 ] [ n + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) subset [ 0 ] [ i ] = true ;
for ( int i = 1 ; i <= sum ; i ++ ) subset [ i ] [ 0 ] = false ;
for ( int i = 1 ; i <= sum ; i ++ ) { for ( int j = 1 ; j <= n ; j ++ ) { subset [ i ] [ j ] = subset [ i ] [ j - 1 ] ; if ( i >= set [ j - 1 ] ) subset [ i ] [ j ] = subset [ i ] [ j ] || subset [ i - set [ j - 1 ] ] [ j - 1 ] ; } }
for ( int i = 0 ; i <= sum ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) System . out . println ( subset [ i ] [ j ] ) ; } return subset [ sum ] [ n ] ; }
public static void main ( String args [ ] ) { int set [ ] = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = set . length ; if ( isSubsetSum ( set , n , sum ) == true ) System . out . println ( " Found ▁ a ▁ subset " + " ▁ with ▁ given ▁ sum " ) ; else System . out . println ( " No ▁ subset ▁ with " + " ▁ given ▁ sum " ) ; } }
static int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ? 1 : 0 ; if ( sum == 0 ) return 1 ;
int ans = 0 ;
for ( int i = 0 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
static int finalCount ( int n , int sum ) {
int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
public static void main ( String args [ ] ) { int n = 2 , sum = 5 ; System . out . println ( finalCount ( n , sum ) ) ; } }
static int lookup [ ] [ ] = new int [ 101 ] [ 501 ] ;
static int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ? 1 : 0 ;
if ( lookup [ n ] [ sum ] != - 1 ) return lookup [ n ] [ sum ] ;
int ans = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return lookup [ n ] [ sum ] = ans ; }
static int finalCount ( int n , int sum ) {
int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
public static void main ( String args [ ] ) { int n = 3 , sum = 5 ; System . out . println ( finalCount ( n , sum ) ) ; } }
public class GFG { private static void findCount ( int n , int sum ) {
int start = ( int ) Math . pow ( 10 , n - 1 ) ; int end = ( int ) Math . pow ( 10 , n ) - 1 ; int count = 0 ; int i = start ; while ( i < end ) { int cur = 0 ; int temp = i ; while ( temp != 0 ) { cur += temp % 10 ; temp = temp / 10 ; } if ( cur == sum ) { count ++ ; i += 9 ; } else i ++ ; } System . out . println ( count ) ; }
public static void main ( String [ ] args ) { int n = 3 ; int sum = 5 ; findCount ( n , sum ) ; } }
class NDN { static int countNonDecreasing ( int n ) {
int dp [ ] [ ] = new int [ 10 ] [ n + 1 ] ;
for ( int i = 0 ; i < 10 ; i ++ ) dp [ i ] [ 1 ] = 1 ;
for ( int digit = 0 ; digit <= 9 ; digit ++ ) {
for ( int len = 2 ; len <= n ; len ++ ) {
for ( int x = 0 ; x <= digit ; x ++ ) dp [ digit ] [ len ] += dp [ x ] [ len - 1 ] ; } } int count = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) count += dp [ i ] [ n ] ; return count ; }
public static void main ( String args [ ] ) { int n = 3 ; System . out . println ( countNonDecreasing ( n ) ) ; } }
public class GFG { static long countNonDecreasing ( int n ) { int N = 10 ;
long count = 1 ; for ( int i = 1 ; i <= n ; i ++ ) { count *= ( N + i - 1 ) ; count /= i ; } return count ; }
public static void main ( String args [ ] ) { int n = 3 ; System . out . print ( countNonDecreasing ( n ) ) ; } }
static int getMinSquares ( int n ) {
if ( n <= 3 ) return n ;
int res = n ;
for ( int x = 1 ; x <= n ; x ++ ) { int temp = x * x ; if ( temp > n ) break ; else res = Math . min ( res , 1 + getMinSquares ( n - temp ) ) ; } return res ; }
public static void main ( String args [ ] ) { System . out . println ( getMinSquares ( 6 ) ) ; } }
static int getMinSquares ( int n ) {
int dp [ ] = new int [ n + 1 ] ;
dp [ 0 ] = 0 ; dp [ 1 ] = 1 ; dp [ 2 ] = 2 ; dp [ 3 ] = 3 ;
for ( int i = 4 ; i <= n ; i ++ ) {
dp [ i ] = i ;
for ( int x = 1 ; x <= Math . ceil ( Math . sqrt ( i ) ) ; x ++ ) { int temp = x * x ; if ( temp > i ) break ; else dp [ i ] = Math . min ( dp [ i ] , 1 + dp [ i - temp ] ) ; } }
int res = dp [ n ] ; return res ; }
public static void main ( String args [ ] ) { System . out . println ( getMinSquares ( 6 ) ) ; } }
static int minCoins ( int coins [ ] , int m , int V ) {
if ( V == 0 ) return 0 ;
int res = Integer . MAX_VALUE ;
for ( int i = 0 ; i < m ; i ++ ) { if ( coins [ i ] <= V ) { int sub_res = minCoins ( coins , m , V - coins [ i ] ) ;
if ( sub_res != Integer . MAX_VALUE && sub_res + 1 < res ) res = sub_res + 1 ; } } return res ; }
public static void main ( String args [ ] ) { int coins [ ] = { 9 , 6 , 5 , 1 } ; int m = coins . length ; int V = 11 ; System . out . println ( " Minimum ▁ coins ▁ required ▁ is ▁ " + minCoins ( coins , m , V ) ) ; } }
static int minCoins ( int coins [ ] , int m , int V ) {
int table [ ] = new int [ V + 1 ] ;
table [ 0 ] = 0 ;
for ( int i = 1 ; i <= V ; i ++ ) table [ i ] = Integer . MAX_VALUE ;
for ( int i = 1 ; i <= V ; i ++ ) {
for ( int j = 0 ; j < m ; j ++ ) if ( coins [ j ] <= i ) { int sub_res = table [ i - coins [ j ] ] ; if ( sub_res != Integer . MAX_VALUE && sub_res + 1 < table [ i ] ) table [ i ] = sub_res + 1 ; } } if ( table [ V ] == Integer . MAX_VALUE ) return - 1 ; return table [ V ] ; }
public static void main ( String [ ] args ) { int coins [ ] = { 9 , 6 , 5 , 1 } ; int m = coins . length ; int V = 11 ; System . out . println ( " Minimum ▁ coins ▁ required ▁ is ▁ " + minCoins ( coins , m , V ) ) ; } }
class GFG { static int superSeq ( String X , String Y , int m , int n ) { if ( m == 0 ) return n ; if ( n == 0 ) return m ; if ( X . charAt ( m - 1 ) == Y . charAt ( n - 1 ) ) return 1 + superSeq ( X , Y , m - 1 , n - 1 ) ; return 1 + Math . min ( superSeq ( X , Y , m - 1 , n ) , superSeq ( X , Y , m , n - 1 ) ) ; }
public static void main ( String args [ ] ) { String X = " AGGTAB " ; String Y = " GXTXAYB " ; System . out . println ( " Length ▁ of ▁ the ▁ shortest " + " supersequence ▁ is : ▁ " + superSeq ( X , Y , X . length ( ) , Y . length ( ) ) ) ; } }
static int superSeq ( String X , String Y , int m , int n ) { int [ ] [ ] dp = new int [ m + 1 ] [ n + 1 ] ;
for ( int i = 0 ; i <= m ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) {
if ( i == 0 ) dp [ i ] [ j ] = j ; else if ( j == 0 ) dp [ i ] [ j ] = i ; else if ( X . charAt ( i - 1 ) == Y . charAt ( j - 1 ) ) dp [ i ] [ j ] = 1 + dp [ i - 1 ] [ j - 1 ] ; else dp [ i ] [ j ] = 1 + Math . min ( dp [ i - 1 ] [ j ] , dp [ i ] [ j - 1 ] ) ; } } return dp [ m ] [ n ] ; }
public static void main ( String args [ ] ) { String X = " AGGTAB " ; String Y = " GXTXAYB " ; System . out . println ( " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ " + superSeq ( X , Y , X . length ( ) , Y . length ( ) ) ) ; } }
static int sumOfDigitsFrom1ToN ( int n ) {
int result = 0 ;
for ( int x = 1 ; x <= n ; x ++ ) result += sumOfDigits ( x ) ; return result ; }
static int sumOfDigits ( int x ) { int sum = 0 ; while ( x != 0 ) { sum += x % 10 ; x = x / 10 ; } return sum ; }
public static void main ( String args [ ] ) { int n = 328 ; System . out . println ( " Sum ▁ of ▁ digits ▁ in ▁ numbers " + " ▁ from ▁ 1 ▁ to ▁ " + n + " ▁ is ▁ " + sumOfDigitsFrom1ToN ( n ) ) ; } }
static int sumOfDigitsFrom1ToN ( int n ) {
if ( n < 10 ) return ( n * ( n + 1 ) / 2 ) ;
int d = ( int ) ( Math . log10 ( n ) ) ;
int a [ ] = new int [ d + 1 ] ; a [ 0 ] = 0 ; a [ 1 ] = 45 ; for ( int i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * ( int ) ( Math . ceil ( Math . pow ( 10 , i - 1 ) ) ) ;
int p = ( int ) ( Math . ceil ( Math . pow ( 10 , d ) ) ) ;
int msd = n / p ;
return ( msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToN ( n % p ) ) ; }
public static void main ( String args [ ] ) { int n = 328 ; System . out . println ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ " + " from ▁ 1 ▁ to ▁ " + n + " ▁ is ▁ " + sumOfDigitsFrom1ToN ( n ) ) ; } }
static int countWays ( int N ) {
if ( N == 1 )
return 4 ;
int countB = 1 , countS = 1 , prev_countB , prev_countS ;
for ( int i = 2 ; i <= N ; i ++ ) { prev_countB = countB ; prev_countS = countS ; countS = prev_countB + prev_countS ; countB = prev_countS ; }
int result = countS + countB ;
return ( result * result ) ; }
public static void main ( String args [ ] ) { int N = 3 ; System . out . println ( " Count ▁ of ▁ ways ▁ for ▁ " + N + " ▁ sections ▁ is ▁ " + countWays ( N ) ) ; } }
static void printPatternUtil ( String str , char buf [ ] , int i , int j , int n ) { if ( i == n ) { buf [ j ] = ' \0' ; System . out . println ( buf ) ; return ; }
buf [ j ] = str . charAt ( i ) ; printPatternUtil ( str , buf , i + 1 , j + 1 , n ) ;
buf [ j ] = ' ▁ ' ; buf [ j + 1 ] = str . charAt ( i ) ; printPatternUtil ( str , buf , i + 1 , j + 2 , n ) ; }
static void printPattern ( String str ) { int len = str . length ( ) ;
char [ ] buf = new char [ 2 * len ] ;
buf [ 0 ] = str . charAt ( 0 ) ; printPatternUtil ( str , buf , 1 , 1 , len ) ; }
public static void main ( String [ ] args ) { String str = " ABCD " ; printPattern ( str ) ; } }
static double area ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 ) { return Math . abs ( ( x1 * ( y2 - y3 ) + x2 * ( y3 - y1 ) + x3 * ( y1 - y2 ) ) / 2.0 ) ; }
static boolean isInside ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 , int x , int y ) {
double A = area ( x1 , y1 , x2 , y2 , x3 , y3 ) ;
double A1 = area ( x , y , x2 , y2 , x3 , y3 ) ;
double A2 = area ( x1 , y1 , x , y , x3 , y3 ) ;
double A3 = area ( x1 , y1 , x2 , y2 , x , y ) ;
return ( A == A1 + A2 + A3 ) ; }
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) System . out . println ( " Inside " ) ; else System . out . println ( " Not ▁ Inside " ) ; } }
static float getAvg ( float prev_avg , float x , int n ) { return ( prev_avg * n + x ) / ( n + 1 ) ; }
static void streamAvg ( float arr [ ] , int n ) { float avg = 0 ; for ( int i = 0 ; i < n ; i ++ ) { avg = getAvg ( avg , arr [ i ] , i ) ; System . out . printf ( "Average of %d numbers is %f NEW_LINE", i + 1, avg); } return ; }
public static void main ( String [ ] args ) { float arr [ ] = { 10 , 20 , 30 , 40 , 50 , 60 } ; int n = arr . length ; streamAvg ( arr , n ) ; } }
class SieveOfEratosthenes { void sieveOfEratosthenes ( int n ) {
boolean prime [ ] = new boolean [ n + 1 ] ; for ( int i = 0 ; i <= n ; i ++ ) prime [ i ] = true ; for ( int p = 2 ; p * p <= n ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * p ; i <= n ; i += p ) prime [ i ] = false ; } }
for ( int i = 2 ; i <= n ; i ++ ) { if ( prime [ i ] == true ) System . out . print ( i + " ▁ " ) ; } }
public static void main ( String args [ ] ) { int n = 30 ; System . out . print ( " Following ▁ are ▁ the ▁ prime ▁ numbers ▁ " ) ; System . out . println ( " smaller ▁ than ▁ or ▁ equal ▁ to ▁ " + n ) ; SieveOfEratosthenes g = new SieveOfEratosthenes ( ) ; g . sieveOfEratosthenes ( n ) ; } }
static int maximumNumberDistinctPrimeRange ( int m , int n ) {
long factorCount [ ] = new long [ n + 1 ] ;
boolean prime [ ] = new boolean [ n + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) { factorCount [ i ] = 0 ;
prime [ i ] = true ; } for ( int i = 2 ; i <= n ; i ++ ) {
if ( prime [ i ] == true ) {
factorCount [ i ] = 1 ;
for ( int j = i * 2 ; j <= n ; j += i ) {
factorCount [ j ] ++ ;
prime [ j ] = false ; } } }
int max = ( int ) factorCount [ m ] ; int num = m ;
for ( int i = m ; i <= n ; i ++ ) {
if ( factorCount [ i ] > max ) { max = ( int ) factorCount [ i ] ; num = i ; } } return num ; }
public static void main ( String [ ] args ) { int m = 4 , n = 6 ;
System . out . println ( maximumNumberDistinctPrimeRange ( m , n ) ) ; } }
class GFG { static int MAX_CHAR = 256 ;
int count [ ] = new int [ MAX_CHAR ] ;
static int fact ( int n ) { return ( n <= 1 ) ? 1 : n * fact ( n - 1 ) ; }
static void populateAndIncreaseCount ( int [ ] count , char [ ] str ) { int i ; for ( i = 0 ; i < str . length ; ++ i ) ++ count [ str [ i ] ] ; for ( i = 1 ; i < MAX_CHAR ; ++ i ) count [ i ] += count [ i - 1 ] ; }
static void updatecount ( int [ ] count , char ch ) { int i ; for ( i = ch ; i < MAX_CHAR ; ++ i ) -- count [ i ] ; }
static int findRank ( char [ ] str ) { int len = str . length ; int mul = fact ( len ) ; int rank = 1 , i ;
populateAndIncreaseCount ( count , str ) ; for ( i = 0 ; i < len ; ++ i ) { mul /= len - i ;
rank += count [ str [ i ] - 1 ] * mul ;
updatecount ( count , str [ i ] ) ; } return rank ; }
public static void main ( String args [ ] ) { char str [ ] = " string " . toCharArray ( ) ; System . out . println ( findRank ( str ) ) ; } }
static int binomialCoeff ( int n , int k ) { int res = 1 ; if ( k > n - k ) k = n - k ; for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
static void printPascal ( int n ) {
for ( int line = 0 ; line < n ; line ++ ) {
for ( int i = 0 ; i <= line ; i ++ ) System . out . print ( binomialCoeff ( line , i ) + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String args [ ] ) { int n = 7 ; printPascal ( n ) ; } }
static boolean isPerfectSquare ( int x ) { int s = ( int ) Math . sqrt ( x ) ; return ( s * s == x ) ; }
static boolean isFibonacci ( int n ) {
return isPerfectSquare ( 5 * n * n + 4 ) || isPerfectSquare ( 5 * n * n - 4 ) ; }
public static void main ( String [ ] args ) { for ( int i = 1 ; i <= 10 ; i ++ ) System . out . println ( isFibonacci ( i ) ? i + " ▁ is ▁ a ▁ Fibonacci ▁ Number " : i + " ▁ is ▁ a ▁ not ▁ Fibonacci ▁ Number " ) ; } }
static int findTrailingZeros ( int n ) {
int count = 0 ;
for ( int i = 5 ; n / i >= 1 ; i *= 5 ) count += n / i ; return count ; }
public static void main ( String [ ] args ) { int n = 100 ; System . out . println ( " Count ▁ of ▁ trailing ▁ 0s ▁ in ▁ " + n + " ! ▁ is ▁ " + findTrailingZeros ( n ) ) ; } }
int catalan ( int n ) {
if ( n <= 1 ) { return 1 ; }
int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) { res += catalan ( i ) * catalan ( n - i - 1 ) ; } return res ; }
public static void main ( String [ ] args ) { CatalnNumber cn = new CatalnNumber ( ) ; for ( int i = 0 ; i < 10 ; i ++ ) { System . out . print ( cn . catalan ( i ) + " ▁ " ) ; } } }
class GFG { static int catalanDP ( int n ) {
int catalan [ ] = new int [ n + 2 ] ;
catalan [ 0 ] = 1 ; catalan [ 1 ] = 1 ;
for ( int i = 2 ; i <= n ; i ++ ) { catalan [ i ] = 0 ; for ( int j = 0 ; j < i ; j ++ ) { catalan [ i ] += catalan [ j ] * catalan [ i - j - 1 ] ; } }
return catalan [ n ] ; }
public static void main ( String [ ] args ) { for ( int i = 0 ; i < 10 ; i ++ ) { System . out . print ( catalanDP ( i ) + " ▁ " ) ; } } }
static long binomialCoeff ( int n , int k ) { long res = 1 ;
if ( k > n - k ) { k = n - k ; }
for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
static long catalan ( int n ) {
long c = binomialCoeff ( 2 * n , n ) ;
return c / ( n + 1 ) ; }
public static void main ( String [ ] args ) { for ( int i = 0 ; i < 10 ; i ++ ) { System . out . print ( catalan ( i ) + " ▁ " ) ; } } }
static int getInvCount ( int [ ] [ ] arr ) { int inv_count = 0 ; for ( int i = 0 ; i < 3 - 1 ; i ++ ) for ( int j = i + 1 ; j < 3 ; j ++ )
if ( arr [ j ] [ i ] > 0 && arr [ j ] [ i ] > arr [ i ] [ j ] ) inv_count ++ ; return inv_count ; }
static boolean isSolvable ( int [ ] [ ] puzzle ) {
int invCount = getInvCount ( puzzle ) ;
return ( invCount % 2 == 0 ) ; }
public static void main ( String [ ] args ) { int [ ] [ ] puzzle = { { 1 , 8 , 2 } , { 0 , 4 , 3 } , { 7 , 6 , 5 } } ; if ( isSolvable ( puzzle ) ) System . out . println ( " Solvable " ) ; else System . out . println ( " Not ▁ Solvable " ) ; } }
static double find ( double p ) { return Math . ceil ( Math . sqrt ( 2 * 365 * Math . log ( 1 / ( 1 - p ) ) ) ) ; }
public static void main ( String [ ] args ) { System . out . println ( find ( 0.70 ) ) ; } }
static int countSolutions ( int n ) { int res = 0 ; for ( int x = 0 ; x * x < n ; x ++ ) for ( int y = 0 ; x * x + y * y < n ; y ++ ) res ++ ; return res ; }
public static void main ( String args [ ] ) { System . out . println ( " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " + countSolutions ( 6 ) ) ; } }
static int countSolutions ( int n ) { int x = 0 , yCount , res = 0 ;
for ( yCount = 0 ; yCount * yCount < n ; yCount ++ ) ;
while ( yCount != 0 ) {
res += yCount ;
x ++ ;
while ( yCount != 0 && ( x * x + ( yCount - 1 ) * ( yCount - 1 ) >= n ) ) yCount -- ; } return res ; }
public static void main ( String args [ ] ) { System . out . println ( " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " + countSolutions ( 6 ) ) ; } }
class GFG { static final double EPSILON = 0.001 ;
static double func ( double x ) { return x * x * x - x * x + 2 ; }
static double derivFunc ( double x ) { return 3 * x * x - 2 * x ; }
static void newtonRaphson ( double x ) { double h = func ( x ) / derivFunc ( x ) ; while ( Math . abs ( h ) >= EPSILON ) { h = func ( x ) / derivFunc ( x ) ;
x = x - h ; } System . out . print ( " The ▁ value ▁ of ▁ the " + " ▁ root ▁ is ▁ : ▁ " + Math . round ( x * 100.0 ) / 100.0 ) ; }
double x0 = - 20 ; newtonRaphson ( x0 ) ; } }
static boolean oppositeSigns ( int x , int y ) { return ( ( x ^ y ) < 0 ) ; }
public static void main ( String [ ] args ) { int x = 100 , y = - 100 ; if ( oppositeSigns ( x , y ) == true ) System . out . println ( " Signs ▁ are ▁ opposite " ) ; else System . out . println ( " Signs ▁ are ▁ not ▁ opposite " ) ; } }
static void update ( int arr [ ] , int l , int r , int val ) { arr [ l ] += val ; if ( r + 1 < arr . length ) arr [ r + 1 ] -= val ; }
static int getElement ( int arr [ ] , int i ) {
int res = 0 ; for ( int j = 0 ; j <= i ; j ++ ) res += arr [ j ] ; return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 0 , 0 , 0 , 0 } ; int n = arr . length ; int l = 2 , r = 4 , val = 2 ; update ( arr , l , r , val ) ;
int index = 4 ; System . out . println ( " Element ▁ at ▁ index ▁ " + index + " ▁ is ▁ " + getElement ( arr , index ) ) ; l = 0 ; r = 3 ; val = 4 ; update ( arr , l , r , val ) ;
index = 3 ; System . out . println ( " Element ▁ at ▁ index ▁ " + index + " ▁ is ▁ " + getElement ( arr , index ) ) ; } }
static int countSetBits ( int n ) {
int bitCount = 0 ; for ( int i = 1 ; i <= n ; i ++ ) bitCount += countSetBitsUtil ( i ) ; return bitCount ; }
static int countSetBitsUtil ( int x ) { if ( x <= 0 ) return 0 ; return ( x % 2 == 0 ? 0 : 1 ) + countSetBitsUtil ( x / 2 ) ; }
public static void main ( String [ ] args ) { int n = 4 ; System . out . print ( " Total ▁ set ▁ bit ▁ count ▁ is ▁ " ) ; System . out . print ( countSetBits ( n ) ) ; } }
public class GFG { static int countSetBits ( int n ) { int i = 0 ;
int ans = 0 ;
while ( ( 1 << i ) <= n ) {
boolean k = false ;
int change = 1 << i ;
for ( int j = 0 ; j <= n ; j ++ ) { if ( k == true ) ans += 1 ; else ans += 0 ; if ( change == 1 ) {
k = ! k ;
change = 1 << i ; } else { change -- ; } }
i ++ ; } return ans ; }
public static void main ( String [ ] args ) { int n = 17 ; System . out . println ( countSetBits ( n ) ) ; } }
static int snoob ( int x ) { int rightOne , nextHigherOneBit , rightOnesPattern , next = 0 ; if ( x > 0 ) {
rightOne = x & - x ;
nextHigherOneBit = x + rightOne ;
rightOnesPattern = x ^ nextHigherOneBit ;
rightOnesPattern = ( rightOnesPattern ) / rightOne ;
rightOnesPattern >>= 2 ;
next = nextHigherOneBit | rightOnesPattern ; } return next ; }
public static void main ( String [ ] args ) { int x = 156 ; System . out . println ( " Next ▁ higher ▁ number ▁ with ▁ same " + " number ▁ of ▁ set ▁ bits ▁ is ▁ " + snoob ( x ) ) ; } }
class GFG { static int multiplyWith3Point5 ( int x ) { return ( x << 1 ) + x + ( x >> 1 ) ; }
public static void main ( String [ ] args ) { int x = 2 ; System . out . println ( multiplyWith3Point5 ( x ) ) ; } }
static int getModulo ( int n , int d ) { return ( n & ( d - 1 ) ) ; }
public static void main ( String [ ] args ) { int n = 6 ;
int d = 4 ; System . out . println ( n + " ▁ moduo ▁ " + d + " ▁ is ▁ " + getModulo ( n , d ) ) ; } }
static int getOddOccurrence ( int arr [ ] , int arr_size ) { int i ; for ( i = 0 ; i < arr_size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < arr_size ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; } if ( count % 2 != 0 ) return arr [ i ] ; } return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 } ; int n = arr . length ;
System . out . println ( getOddOccurrence ( arr , n ) ) ; } }
static int fastPow ( int N , int K ) { if ( K == 0 ) return 1 ; int temp = fastPow ( N , K / 2 ) ; if ( K % 2 == 0 ) return temp * temp ; else return N * temp * temp ; } static int countWays ( int N , int K ) { return K * fastPow ( K - 1 , N - 1 ) ; }
public static void main ( String [ ] args ) { int N = 3 , K = 3 ; System . out . println ( countWays ( N , K ) ) ; } }
public static int countSetBits ( int n ) {
if ( n == 0 ) return 0 ; else return 1 + countSetBits ( n & ( n - 1 ) ) ; }
int n = 9 ;
System . out . println ( countSetBits ( n ) ) ; } }
public static void main ( String [ ] args ) { System . out . println ( Integer . bitCount ( 4 ) ) ; System . out . println ( Integer . bitCount ( 15 ) ) ; } }
public static int countSetBits ( int n ) { int count = 0 ; while ( n != 0 ) { count ++ ; n &= ( n - 1 ) ; } return count ; }
public static int FlippedCount ( int a , int b ) {
return countSetBits ( a ^ b ) ; }
public static void main ( String [ ] args ) { int a = 10 ; int b = 20 ; System . out . print ( FlippedCount ( a , b ) ) ; } }
static int PositionRightmostSetbit ( int n ) {
int position = 1 ; int m = 1 ; while ( ( n & m ) == 0 ) {
m = m << 1 ; position ++ ; } return position ; }
public static void main ( String [ ] args ) { int n = 16 ;
System . out . println ( PositionRightmostSetbit ( n ) ) ; } }
public class GFG { static int INT_SIZE = 32 ; static int Right_most_setbit ( int num ) { int pos = 1 ;
for ( int i = 0 ; i < INT_SIZE ; i ++ ) { if ( ( num & ( 1 << i ) ) == 0 ) pos ++ ; else break ; } return pos ; }
public static void main ( String [ ] args ) { int num = 18 ; int pos = Right_most_setbit ( num ) ; System . out . println ( pos ) ; } }
static void bin ( Integer n ) { if ( n > 1 ) bin ( n >> 1 ) ; System . out . printf ( " % d " , n & 1 ) ; }
public static void main ( String [ ] args ) { bin ( 131 ) ; System . out . printf ( "NEW_LINE"); bin ( 3 ) ; } }
static int maxOnesIndex ( int arr [ ] , int n ) {
int max_count = 0 ;
int max_index = 0 ;
int prev_zero = - 1 ;
int prev_prev_zero = - 1 ;
for ( int curr = 0 ; curr < n ; ++ curr ) {
if ( arr [ curr ] == 0 ) {
if ( curr - prev_prev_zero > max_count ) { max_count = curr - prev_prev_zero ; max_index = prev_zero ; }
prev_prev_zero = prev_zero ; prev_zero = curr ; } }
if ( n - prev_prev_zero > max_count ) max_index = prev_zero ; return max_index ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } ; int n = arr . length ; System . out . println ( " Index ▁ of ▁ 0 ▁ to ▁ be ▁ replaced ▁ is ▁ " + maxOnesIndex ( arr , n ) ) ; } }
int min ( int x , int y ) { return ( x < y ) ? x : y ; } int max ( int x , int y ) { return ( x > y ) ? x : y ; }
int findLength ( int arr [ ] , int n ) {
int max_len = 1 ; for ( int i = 0 ; i < n - 1 ; i ++ ) {
int mn = arr [ i ] , mx = arr [ i ] ;
for ( int j = i + 1 ; j < n ; j ++ ) {
mn = min ( mn , arr [ j ] ) ; mx = max ( mx , arr [ j ] ) ;
if ( ( mx - mn ) == j - i ) max_len = max ( max_len , mx - mn + 1 ) ; } }
return max_len ; }
public static void main ( String [ ] args ) { LargestSubArray2 large = new LargestSubArray2 ( ) ; int arr [ ] = { 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 } ; int n = arr . length ; System . out . println ( " Length ▁ of ▁ the ▁ longest ▁ contiguous ▁ subarray ▁ is ▁ " + large . findLength ( arr , n ) ) ; } }
static void printArr ( int [ ] arr , int k ) { for ( int i = 0 ; i < k ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); }
static void printSeqUtil ( int n , int k , int len , int [ ] arr ) {
if ( len == k ) { printArr ( arr , k ) ; return ; }
int i = ( len == 0 ) ? 1 : arr [ len - 1 ] + 1 ;
len ++ ;
while ( i <= n ) { arr [ len - 1 ] = i ; printSeqUtil ( n , k , len , arr ) ; i ++ ; }
len -- ; }
static void printSeq ( int n , int k ) {
int [ ] arr = new int [ k ] ;
int len = 0 ; printSeqUtil ( n , k , len , arr ) ; }
static public void main ( String [ ] args ) { int k = 3 , n = 7 ; printSeq ( n , k ) ; } }
static boolean isSubSequence ( String str1 , String str2 , int m , int n ) {
if ( m == 0 ) return true ; if ( n == 0 ) return false ;
if ( str1 . charAt ( m - 1 ) == str2 . charAt ( n - 1 ) ) return isSubSequence ( str1 , str2 , m - 1 , n - 1 ) ;
return isSubSequence ( str1 , str2 , m , n - 1 ) ; }
public static void main ( String [ ] args ) { String str1 = " gksrek " ; String str2 = " geeksforgeeks " ; int m = str1 . length ( ) ; int n = str2 . length ( ) ; boolean res = isSubSequence ( str1 , str2 , m , n ) ; if ( res ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static void segregate0and1 ( int arr [ ] , int n ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 0 ) count ++ ; }
for ( int i = 0 ; i < count ; i ++ ) arr [ i ] = 0 ;
for ( int i = count ; i < n ; i ++ ) arr [ i ] = 1 ; }
static void print ( int arr [ ] , int n ) { System . out . print ( " Array ▁ after ▁ segregation ▁ is ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 0 , 1 , 0 , 1 , 1 , 1 } ; int n = arr . length ; segregate0and1 ( arr , n ) ; print ( arr , n ) ; } }
static void segregate0and1 ( int arr [ ] ) { int type0 = 0 ; int type1 = arr . length - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type1 ] = arr [ type1 ] + arr [ type0 ] ; arr [ type0 ] = arr [ type1 ] - arr [ type0 ] ; arr [ type1 ] = arr [ type1 ] - arr [ type0 ] ; type1 -- ; } else { type0 ++ ; } } }
public static void main ( String [ ] args ) { int [ ] array = { 0 , 1 , 0 , 1 , 1 , 1 } ; segregate0and1 ( array ) ; for ( int a : array ) { System . out . print ( a + " ▁ " ) ; } } }
static int GetCeilIndex ( int arr [ ] , int T [ ] , int l , int r , int key ) { while ( r - l > 1 ) { int m = l + ( r - l ) / 2 ; if ( arr [ T [ m ] ] >= key ) r = m ; else l = m ; } return r ; } static int LongestIncreasingSubsequence ( int arr [ ] , int n ) {
int tailIndices [ ] = new int [ n ] ; Arrays . fill ( tailIndices , 0 ) ; int prevIndices [ ] = new int [ n ] ;
Arrays . fill ( prevIndices , - 1 ) ;
int len = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ tailIndices [ 0 ] ] )
tailIndices [ 0 ] = i ; else if ( arr [ i ] > arr [ tailIndices [ len - 1 ] ] ) {
prevIndices [ i ] = tailIndices [ len - 1 ] ; tailIndices [ len ++ ] = i ; } else {
int pos = GetCeilIndex ( arr , tailIndices , - 1 , len - 1 , arr [ i ] ) ; prevIndices [ i ] = tailIndices [ pos - 1 ] ; tailIndices [ pos ] = i ; } } System . out . println ( " LIS ▁ of ▁ given ▁ input " ) ; for ( int i = tailIndices [ len - 1 ] ; i >= 0 ; i = prevIndices [ i ] ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; return len ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 } ; int n = arr . length ; System . out . print ( "LIS sizeNEW_LINE" + LongestIncreasingSubsequence(arr, n)); } }
void generateUtil ( int A [ ] , int B [ ] , int C [ ] , int i , int j , int m , int n , int len , boolean flag ) {
if ( flag ) {
if ( len != 0 ) printArr ( C , len + 1 ) ;
for ( int k = i ; k < m ; k ++ ) { if ( len == 0 ) {
C [ len ] = A [ k ] ;
generateUtil ( A , B , C , k + 1 , j , m , n , len , ! flag ) ; }
else if ( A [ k ] > C [ len ] ) { C [ len + 1 ] = A [ k ] ; generateUtil ( A , B , C , k + 1 , j , m , n , len + 1 , ! flag ) ; } } }
else { for ( int l = j ; l < n ; l ++ ) { if ( B [ l ] > C [ len ] ) { C [ len + 1 ] = B [ l ] ; generateUtil ( A , B , C , i , l + 1 , m , n , len + 1 , ! flag ) ; } } } }
void generate ( int A [ ] , int B [ ] , int m , int n ) { int C [ ] = new int [ m + n ] ;
generateUtil ( A , B , C , 0 , 0 , m , n , 0 , true ) ; }
void printArr ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( " " ) ; }
public static void main ( String [ ] args ) { GenerateArrays generate = new GenerateArrays ( ) ; int A [ ] = { 10 , 15 , 25 } ; int B [ ] = { 5 , 20 , 30 } ; int n = A . length ; int m = B . length ; generate . generate ( A , B , n , m ) ; } }
static void replace_elements ( int arr [ ] , int n ) {
int pos = 0 ; for ( int i = 0 ; i < n ; i ++ ) { arr [ pos ++ ] = arr [ i ] ; while ( pos > 1 && arr [ pos - 2 ] == arr [ pos - 1 ] ) { pos -- ; arr [ pos - 1 ] ++ ; } }
for ( int i = 0 ; i < pos ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 6 , 4 , 3 , 4 , 3 , 3 , 5 } ; int n = arr . length ; replace_elements ( arr , n ) ; } }
static void arrangeString ( String str , int x , int y ) { int count_0 = 0 ; int count_1 = 0 ; int len = str . length ( ) ;
for ( int i = 0 ; i < len ; i ++ ) { if ( str . charAt ( i ) == '0' ) count_0 ++ ; else count_1 ++ ; }
while ( count_0 > 0 count_1 > 0 ) { for ( int j = 0 ; j < x && count_0 > 0 ; j ++ ) { if ( count_0 > 0 ) { System . out . print ( "0" ) ; count_0 -- ; } } for ( int j = 0 ; j < y && count_1 > 0 ; j ++ ) { if ( count_1 > 0 ) { System . out . print ( "1" ) ; count_1 -- ; } } } }
public static void main ( String [ ] args ) { String str = "01101101101101101000000" ; int x = 1 ; int y = 2 ; arrangeString ( str , x , y ) ; } }
public static void rearrange ( int [ ] arr ) {
if ( arr == null arr . length % 2 == 1 ) return ;
int currIdx = ( arr . length - 1 ) / 2 ;
while ( currIdx > 0 ) { int count = currIdx , swapIdx = currIdx ; while ( count -- > 0 ) { int temp = arr [ swapIdx + 1 ] ; arr [ swapIdx + 1 ] = arr [ swapIdx ] ; arr [ swapIdx ] = temp ; swapIdx ++ ; } currIdx -- ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 5 , 2 , 4 , 6 } ; rearrange ( arr ) ; for ( int i = 0 ; i < arr . length ; i ++ ) System . out . print ( " ▁ " + arr [ i ] ) ; } }
static int maxDiff ( int arr [ ] , int n ) {
int maxDiff = - 1 ;
int maxRight = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) { if ( arr [ i ] > maxRight ) maxRight = arr [ i ] ; else { int diff = maxRight - arr [ i ] ; if ( diff > maxDiff ) { maxDiff = diff ; } } } return maxDiff ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 90 , 10 , 110 } ; int n = arr . length ;
System . out . println ( " Maximum ▁ difference ▁ is ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxDiff ( int arr [ ] , int n ) {
int diff = arr [ 1 ] - arr [ 0 ] ; int curr_sum = diff ; int max_sum = curr_sum ; for ( int i = 1 ; i < n - 1 ; i ++ ) {
diff = arr [ i + 1 ] - arr [ i ] ;
if ( curr_sum > 0 ) curr_sum += diff ; else curr_sum = diff ;
if ( curr_sum > max_sum ) max_sum = curr_sum ; } return max_sum ; }
public static void main ( String [ ] args ) { int arr [ ] = { 80 , 2 , 6 , 3 , 100 } ; int n = arr . length ;
System . out . print ( " Maximum ▁ difference ▁ is ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxRepeating ( int arr [ ] , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) arr [ ( arr [ i ] % k ) ] += k ;
int max = arr [ 0 ] , result = 0 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; result = i ; } }
return result ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 } ; int n = arr . length ; int k = 8 ; System . out . println ( " Maximum ▁ repeating ▁ element ▁ is : ▁ " + maxRepeating ( arr , n , k ) ) ; } }
int maxPathSum ( int ar1 [ ] , int ar2 [ ] , int m , int n ) {
int i = 0 , j = 0 ;
int result = 0 , sum1 = 0 , sum2 = 0 ;
while ( i < m && j < n ) {
if ( ar1 [ i ] < ar2 [ j ] ) sum1 += ar1 [ i ++ ] ;
else if ( ar1 [ i ] > ar2 [ j ] ) sum2 += ar2 [ j ++ ] ;
else {
result += max ( sum1 , sum2 ) + ar1 [ i ] ;
sum1 = 0 ; sum2 = 0 ;
i ++ ; j ++ ; } }
while ( i < m ) sum1 += ar1 [ i ++ ] ;
while ( j < n ) sum2 += ar2 [ j ++ ] ;
result += max ( sum1 , sum2 ) ; return result ; }
public static void main ( String [ ] args ) { MaximumSumPath sumpath = new MaximumSumPath ( ) ; int ar1 [ ] = { 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 } ; int ar2 [ ] = { 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 } ; int m = ar1 . length ; int n = ar2 . length ;
System . out . println ( " Maximum ▁ sum ▁ path ▁ is ▁ : " + sumpath . maxPathSum ( ar1 , ar2 , m , n ) ) ; } }
import java . io . * ; class GFG { static void smallestGreater ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) {
int diff = Integer . MAX_VALUE ; int closest = - 1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] < arr [ j ] && arr [ j ] - arr [ i ] < diff ) { diff = arr [ j ] - arr [ i ] ; closest = j ; } }
if ( closest == - 1 ) System . out . print ( " _ ▁ " ) ; else System . out . print ( arr [ closest ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int ar [ ] = { 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 } ; int n = ar . length ; smallestGreater ( ar , n ) ; } }
static void findZeroes ( int m ) {
int wL = 0 , wR = 0 ;
int bestL = 0 , bestWindow = 0 ;
int zeroCount = 0 ;
while ( wR < arr . length ) {
if ( zeroCount <= m ) { if ( arr [ wR ] == 0 ) zeroCount ++ ; wR ++ ; }
if ( zeroCount > m ) { if ( arr [ wL ] == 0 ) zeroCount -- ; wL ++ ; }
if ( ( wR - wL > bestWindow ) && ( zeroCount <= m ) ) { bestWindow = wR - wL ; bestL = wL ; } }
for ( int i = 0 ; i < bestWindow ; i ++ ) { if ( arr [ bestL + i ] == 0 ) System . out . print ( bestL + i + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int m = 2 ; System . out . println ( " Indexes ▁ of ▁ zeroes ▁ to ▁ be ▁ flipped ▁ are ▁ " ) ; findZeroes ( m ) ; } }
class Test { static int arr [ ] = new int [ ] { 1 , 2 , 2 , 4 } ; static int countIncreasing ( int n ) {
int cnt = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] > arr [ j - 1 ] ) cnt ++ ;
else break ; } } return cnt ; }
public static void main ( String [ ] args ) { System . out . println ( " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is ▁ " + countIncreasing ( arr . length ) ) ; } }
class Test { static int arr [ ] = new int [ ] { 1 , 2 , 2 , 4 } ; static int countIncreasing ( int n ) {
int cnt = 0 ;
int len = 1 ;
for ( int i = 0 ; i < n - 1 ; ++ i ) {
if ( arr [ i + 1 ] > arr [ i ] ) len ++ ;
else { cnt += ( ( ( len - 1 ) * len ) / 2 ) ; len = 1 ; } }
if ( len > 1 ) cnt += ( ( ( len - 1 ) * len ) / 2 ) ; return cnt ; }
public static void main ( String [ ] args ) { System . out . println ( " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is ▁ " + countIncreasing ( arr . length ) ) ; } }
static long arraySum ( int arr [ ] , int n ) { long sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + arr [ i ] ; return sum ; }
static long maxDiff ( int arr [ ] , int n , int k ) {
Arrays . sort ( arr ) ;
long arraysum = arraySum ( arr , n ) ;
long diff1 = Math . abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
int end = arr . length - 1 ; int start = 0 ; while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; }
long diff2 = Math . abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
return ( Math . max ( diff1 , diff2 ) ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 7 , 4 , 8 , - 1 , 5 , 2 , 1 } ; int n = arr . length ; int k = 3 ; System . out . println ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n , k ) ) ; } }
static int minNumber ( int a [ ] , int n , int x ) {
Arrays . sort ( a ) ; int k ; for ( k = 0 ; a [ ( n ) / 2 ] != x ; k ++ ) { a [ n ++ ] = x ; Arrays . sort ( a ) ; } return k ; }
public static void main ( String [ ] args ) { int x = 10 ; int a [ ] = { 10 , 20 , 30 } ; int n = 3 ; System . out . println ( minNumber ( a , n - 1 , x ) ) ; } }
import java . util . * ; import java . lang . * ; class GFG { public static int minNumber ( int a [ ] , int n , int x ) { int l = 0 , h = 0 , e = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == x ) e ++ ;
else if ( a [ i ] > x ) h ++ ;
else if ( a [ i ] < x ) l ++ ; } int ans = 0 ; if ( l > h ) ans = l - h ; else if ( l < h ) ans = h - l - 1 ;
return ans + 1 - e ; }
public static void main ( String [ ] args ) { int x = 10 ; int a [ ] = { 10 , 20 , 30 } ; int n = a . length ; System . out . println ( minNumber ( a , n , x ) ) ; } }
static int fun ( int x ) { int y = ( x / 4 ) * 4 ;
int ans = 0 ; for ( int i = y ; i <= x ; i ++ ) ans ^= i ; return ans ; }
static int query ( int x ) {
if ( x == 0 ) return 0 ; int k = ( x + 1 ) / 2 ;
return ( ( x %= 2 ) != 0 ) ? 2 * fun ( k ) : ( ( fun ( k - 1 ) * 2 ) ^ ( k & 1 ) ) ; } static void allQueries ( int q , int l [ ] , int r [ ] ) { for ( int i = 0 ; i < q ; i ++ ) System . out . println ( ( query ( r [ i ] ) ^ query ( l [ i ] - 1 ) ) ) ; }
public static void main ( String [ ] args ) { int q = 3 ; int [ ] l = { 2 , 2 , 5 } ; int [ ] r = { 4 , 8 , 9 } ; allQueries ( q , l , r ) ; } }
static void checkEVENodd ( int arr [ ] , int n , int l , int r ) {
if ( arr [ r ] == 1 ) System . out . println ( " odd " ) ;
else System . out . println ( " even " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 0 , 1 } ; int n = arr . length ; checkEVENodd ( arr , n , 1 , 3 ) ; } }
static int findMean ( int arr [ ] , int l , int r ) {
int sum = 0 , count = 0 ;
for ( int i = l ; i <= r ; i ++ ) { sum += arr [ i ] ; count ++ ; }
int mean = ( int ) Math . floor ( sum / count ) ;
return mean ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; System . out . println ( findMean ( arr , 0 , 2 ) ) ; System . out . println ( findMean ( arr , 1 , 3 ) ) ; System . out . println ( findMean ( arr , 0 , 4 ) ) ; } }
static int calculateProduct ( int [ ] A , int L , int R , int P ) {
L = L - 1 ; R = R - 1 ; int ans = 1 ; for ( int i = L ; i <= R ; i ++ ) { ans = ans * A [ i ] ; ans = ans % P ; } return ans ; }
static public void main ( String [ ] args ) { int [ ] A = { 1 , 2 , 3 , 4 , 5 , 6 } ; int P = 229 ; int L = 2 , R = 5 ; System . out . println ( calculateProduct ( A , L , R , P ) ) ; L = 1 ; R = 3 ; System . out . println ( calculateProduct ( A , L , R , P ) ) ; } }
import java . util . * ; class GFG { static final int MAX = 10000 ;
static int prefix [ ] = new int [ MAX + 1 ] ; static void buildPrefix ( ) {
boolean prime [ ] = new boolean [ MAX + 1 ] ; Arrays . fill ( prime , true ) ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * 2 ; i <= MAX ; i += p ) prime [ i ] = false ; } }
prefix [ 0 ] = prefix [ 1 ] = 0 ; for ( int p = 2 ; p <= MAX ; p ++ ) { prefix [ p ] = prefix [ p - 1 ] ; if ( prime [ p ] ) prefix [ p ] ++ ; } }
static int query ( int L , int R ) { return prefix [ R ] - prefix [ L - 1 ] ; }
public static void main ( String [ ] args ) { buildPrefix ( ) ; int L = 5 , R = 10 ; System . out . println ( query ( L , R ) ) ; L = 1 ; R = 10 ; System . out . println ( query ( L , R ) ) ; } }
static void command ( boolean arr [ ] , int a , int b ) { arr [ a ] ^= true ; arr [ b + 1 ] ^= true ; }
static void process ( boolean arr [ ] , int n ) { for ( int k = 1 ; k <= n ; k ++ ) { arr [ k ] ^= arr [ k - 1 ] ; } }
static void result ( boolean arr [ ] , int n ) { for ( int k = 1 ; k <= n ; k ++ ) { if ( arr [ k ] == true ) System . out . print ( "1" + " ▁ " ) ; else System . out . print ( "0" + " ▁ " ) ; } }
public static void main ( String args [ ] ) { int n = 5 , m = 3 ; boolean arr [ ] = new boolean [ n + 2 ] ;
command ( arr , 1 , 5 ) ; command ( arr , 2 , 5 ) ; command ( arr , 3 , 5 ) ;
process ( arr , n ) ;
result ( arr , n ) ; } }
static double probability ( int a [ ] , int b [ ] , int size1 , int size2 ) {
int max1 = Integer . MIN_VALUE , count1 = 0 ; for ( int i = 0 ; i < size1 ; i ++ ) { if ( a [ i ] > max1 ) { max1 = a [ i ] ; count1 = 1 ; } else if ( a [ i ] == max1 ) { count1 ++ ; } }
int max2 = Integer . MIN_VALUE , count2 = 0 ; for ( int i = 0 ; i < size2 ; i ++ ) { if ( b [ i ] > max2 ) { max2 = b [ i ] ; count2 = 1 ; } else if ( b [ i ] == max2 ) { count2 ++ ; } }
return ( double ) ( count1 * count2 ) / ( size1 * size2 ) ; }
public static void main ( String args [ ] ) { int a [ ] = { 1 , 2 , 3 } ; int b [ ] = { 1 , 3 , 3 } ; int size1 = a . length ; int size2 = b . length ; System . out . println ( probability ( a , b , size1 , size2 ) ) ; } }
public static int countDe ( int arr [ ] , int n ) { int v [ ] = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) v [ i ] = arr [ i ] ;
Arrays . sort ( arr ) ;
int count1 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count1 ++ ;
Collections . reverse ( Arrays . asList ( arr ) ) ;
int count2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count2 ++ ;
return ( Math . min ( count1 , count2 ) ) ; }
public static void main ( String argc [ ] ) { int arr [ ] = { 5 , 9 , 21 , 17 , 13 } ; int n = 5 ; System . out . println ( " Minimum ▁ Dearrangement ▁ = ▁ " + countDe ( arr , n ) ) ; } }
static int maxOfSegmentMins ( int [ ] a , int n , int k ) {
if ( k == 1 ) { Arrays . sort ( a ) ; return a [ 0 ] ; } if ( k == 2 ) return Math . max ( a [ 0 ] , a [ n - 1 ] ) ;
return a [ n - 1 ] ; }
static public void main ( String [ ] args ) { int [ ] a = { - 10 , - 9 , - 8 , 2 , 7 , - 6 , - 5 } ; int n = a . length ; int k = 2 ; System . out . println ( maxOfSegmentMins ( a , n , k ) ) ; } }
static int printMinimumProduct ( int arr [ ] , int n ) {
int first_min = Math . min ( arr [ 0 ] , arr [ 1 ] ) ; int second_min = Math . max ( arr [ 0 ] , arr [ 1 ] ) ;
for ( int i = 2 ; i < n ; i ++ ) { if ( arr [ i ] < first_min ) { second_min = first_min ; first_min = arr [ i ] ; } else if ( arr [ i ] < second_min ) second_min = arr [ i ] ; } return first_min * second_min ; }
public static void main ( String [ ] args ) { int a [ ] = { 11 , 8 , 5 , 7 , 5 , 100 } ; int n = a . length ; System . out . print ( printMinimumProduct ( a , n ) ) ; } }
static long noOfTriples ( long arr [ ] , int n ) {
Arrays . sort ( arr ) ;
long count = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] == arr [ 2 ] ) count ++ ;
if ( arr [ 0 ] == arr [ 2 ] ) return ( count - 2 ) * ( count - 1 ) * ( count ) / 6 ;
else if ( arr [ 1 ] == arr [ 2 ] ) return ( count - 1 ) * ( count ) / 2 ;
return count ; }
public static void main ( String arg [ ] ) { long arr [ ] = { 1 , 3 , 3 , 4 } ; int n = arr . length ; System . out . print ( noOfTriples ( arr , n ) ) ; } }
static boolean checkReverse ( int arr [ ] , int n ) {
int temp [ ] = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { temp [ i ] = arr [ i ] ; }
Arrays . sort ( temp ) ;
int front ; for ( front = 0 ; front < n ; front ++ ) { if ( temp [ front ] != arr [ front ] ) { break ; } }
int back ; for ( back = n - 1 ; back >= 0 ; back -- ) { if ( temp [ back ] != arr [ back ] ) { break ; } }
if ( front >= back ) { return true ; }
do { front ++ ; if ( arr [ front - 1 ] < arr [ front ] ) { return false ; } } while ( front != back ) ; return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 5 , 4 , 3 } ; int n = arr . length ; if ( checkReverse ( arr , n ) ) { System . out . print ( " Yes " ) ; } else { System . out . print ( " No " ) ; } } }
static boolean checkReverse ( int arr [ ] , int n ) { if ( n == 1 ) { return true ; }
int i ; for ( i = 1 ; arr [ i - 1 ] < arr [ i ] && i < n ; i ++ ) ; if ( i == n ) { return true ; }
int j = i ; while ( j < n && arr [ j ] < arr [ j - 1 ] ) { if ( i > 1 && arr [ j ] < arr [ i - 2 ] ) { return false ; } j ++ ; } if ( j == n ) { return true ; }
int k = j ;
if ( arr [ k ] < arr [ i - 1 ] ) { return false ; } while ( k > 1 && k < n ) { if ( arr [ k ] < arr [ k - 1 ] ) { return false ; } k ++ ; } return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 4 , 10 , 9 , 8 } ; int n = arr . length ; if ( checkReverse ( arr , n ) ) { System . out . print ( " Yes " ) ; } else { System . out . print ( " No " ) ; } } }
import java . util . Arrays ; import java . io . * ; class GFG { static int MinOperation ( int a [ ] , int b [ ] , int n ) {
Arrays . sort ( a ) ; Arrays . sort ( b ) ;
int result = 0 ;
for ( int i = 0 ; i < n ; ++ i ) { if ( a [ i ] > b [ i ] ) result = result + Math . abs ( a [ i ] - b [ i ] ) ; else if ( a [ i ] < b [ i ] ) result = result + Math . abs ( a [ i ] - b [ i ] ) ; } return result ; }
public static void main ( String [ ] args ) { int a [ ] = { 3 , 1 , 1 } ; int b [ ] = { 1 , 2 , 2 } ; int n = a . length ; System . out . println ( MinOperation ( a , b , n ) ) ; } }
public static void sortExceptUandL ( int a [ ] , int l , int u , int n ) {
int b [ ] = new int [ n - ( u - l + 1 ) ] ; for ( int i = 0 ; i < l ; i ++ ) b [ i ] = a [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) b [ l + ( i - ( u + 1 ) ) ] = a [ i ] ;
Arrays . sort ( b ) ;
for ( int i = 0 ; i < l ; i ++ ) a [ i ] = b [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) a [ i ] = b [ l + ( i - ( u + 1 ) ) ] ; }
public static void main ( String args [ ] ) { int a [ ] = { 5 , 4 , 3 , 12 , 14 , 9 } ; int n = a . length ; int l = 2 , u = 4 ; sortExceptUandL ( a , l , u , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( a [ i ] + " ▁ " ) ; } }
import java . util . Arrays ; class GFG { static int sortExceptK ( int arr [ ] , int k , int n ) {
int temp = arr [ k ] ; arr [ k ] = arr [ n - 1 ] ; arr [ n - 1 ] = temp ;
Arrays . sort ( arr , 0 , n - 1 ) ;
int last = arr [ n - 1 ] ;
for ( int i = n - 1 ; i > k ; i -- ) arr [ i ] = arr [ i - 1 ] ;
arr [ k ] = last ; return 0 ; }
public static void main ( String [ ] args ) { int a [ ] = { 10 , 4 , 11 , 7 , 6 , 20 } ; int k = 2 ; int n = a . length ; sortExceptK ( a , k , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( a [ i ] + " ▁ " ) ; } }
static int findMinSwaps ( int arr [ ] , int n ) {
int noOfZeroes [ ] = new int [ n ] ; int i , count = 0 ;
noOfZeroes [ n - 1 ] = 1 - arr [ n - 1 ] ; for ( i = n - 2 ; i >= 0 ; i -- ) { noOfZeroes [ i ] = noOfZeroes [ i + 1 ] ; if ( arr [ i ] == 0 ) noOfZeroes [ i ] ++ ; }
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 1 ) count += noOfZeroes [ i ] ; } return count ; }
public static void main ( String args [ ] ) { int ar [ ] = { 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 } ; System . out . println ( findMinSwaps ( ar , ar . length ) ) ; } }
static int maxPartitions ( int arr [ ] , int n ) { int ans = 0 , max_so_far = 0 ; for ( int i = 0 ; i < n ; ++ i ) {
max_so_far = Math . max ( max_so_far , arr [ i ] ) ;
if ( max_so_far == i ) ans ++ ; } return ans ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 0 , 2 , 3 , 4 } ; int n = arr . length ; System . out . println ( maxPartitions ( arr , n ) ) ; } }
public static void cuttringRopes ( int Ropes [ ] , int n ) {
Arrays . sort ( Ropes ) ; int singleOperation = 0 ;
int cuttingLenght = Ropes [ 0 ] ;
for ( int i = 1 ; i < n ; i ++ ) {
if ( Ropes [ i ] - cuttingLenght > 0 ) { System . out . print ( n - i + " ▁ " ) ;
cuttingLenght = Ropes [ i ] ; singleOperation ++ ; } }
if ( singleOperation == 0 ) System . out . print ( "0" ) ; }
public static void main ( String [ ] arg ) { int [ ] Ropes = { 5 , 1 , 1 , 2 , 3 , 5 } ; int n = Ropes . length ; cuttringRopes ( Ropes , n ) ; } }
public static void rankify ( int A [ ] , int n ) {
float R [ ] = new float [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) { int r = 1 , s = 1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( j != i && A [ j ] < A [ i ] ) r += 1 ; if ( j != i && A [ j ] == A [ i ] ) s += 1 ; }
R [ i ] = r + ( float ) ( s - 1 ) / ( float ) 2 ; } for ( int i = 0 ; i < n ; i ++ ) System . out . print ( R [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int A [ ] = { 1 , 2 , 5 , 2 , 1 , 25 , 2 } ; int n = A . length ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( A [ i ] + " ▁ " ) ; System . out . println ( ) ; rankify ( A , n ) ; } }
public static int min_noOf_operation ( int arr [ ] , int n , int k ) { int noOfSubtraction ; int res = 0 ; for ( int i = 1 ; i < n ; i ++ ) { noOfSubtraction = 0 ; if ( arr [ i ] > arr [ i - 1 ] ) {
noOfSubtraction = ( arr [ i ] - arr [ i - 1 ] ) / k ;
if ( ( arr [ i ] - arr [ i - 1 ] ) % k != 0 ) noOfSubtraction ++ ;
arr [ i ] = arr [ i ] - k * noOfSubtraction ; }
res = res + noOfSubtraction ; } return res ; }
public static void main ( String argc [ ] ) { int arr = { 1 , 1 , 2 , 3 } ; int N = 4 ; int k = 5 ; System . out . println ( min_noOf_operation ( arr , N , k ) ) ; } }
import java . util . * ; class GFG { static int maxSum ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += ( arr [ i ] * i ) ; return sum ; }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 5 , 6 , 1 } ; int n = arr . length ; System . out . println ( maxSum ( arr , n ) ) ; } }
static int countPairs ( int a [ ] , int n , int k ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( Math . abs ( a [ j ] - a [ i ] ) < k ) res ++ ; return res ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = a . length ; System . out . println ( countPairs ( a , n , k ) ) ; } }
import java . io . * ; import java . util . Arrays ; class GFG { static int countPairs ( int a [ ] , int n , int k ) {
Arrays . sort ( a ) ; int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j = i + 1 ; while ( j < n && a [ j ] - a [ i ] < k ) { res ++ ; j ++ ; } } return res ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = a . length ; System . out . println ( countPairs ( a , n , k ) ) ; } }
static int sumOfMinAbsDifferences ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
int sum = 0 ;
sum += Math . abs ( arr [ 0 ] - arr [ 1 ] ) ;
sum += Math . abs ( arr [ n - 1 ] - arr [ n - 2 ] ) ;
for ( int i = 1 ; i < n - 1 ; i ++ ) sum += Math . min ( Math . abs ( arr [ i ] - arr [ i - 1 ] ) , Math . abs ( arr [ i ] - arr [ i + 1 ] ) ) ;
return sum ; }
public static void main ( String args [ ] ) { int arr [ ] = { 5 , 10 , 1 , 4 , 8 , 7 } ; int n = arr . length ; System . out . println ( " Sum ▁ = ▁ " + sumOfMinAbsDifferences ( arr , n ) ) ; } }
static int findSmallestDifference ( int A [ ] , int B [ ] , int m , int n ) {
Arrays . sort ( A ) ; Arrays . sort ( B ) ; int a = 0 , b = 0 ;
int result = Integer . MAX_VALUE ;
while ( a < m && b < n ) { if ( Math . abs ( A [ a ] - B [ b ] ) < result ) result = Math . abs ( A [ a ] - B [ b ] ) ;
if ( A [ a ] < B [ b ] ) a ++ ; else b ++ ; }
return result ; }
public static void main ( String [ ] args ) {
int A [ ] = { 1 , 2 , 11 , 5 } ;
int B [ ] = { 4 , 12 , 19 , 23 , 127 , 235 } ;
int m = A . length ; int n = B . length ;
System . out . println ( findSmallestDifference ( A , B , m , n ) ) ; } }
static void findLarger ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
for ( int i = n - 1 ; i >= n / 2 ; i -- ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 6 , 1 , 0 , 9 } ; int n = arr . length ; findLarger ( arr , n ) ; } }
static int findSingle ( int ar [ ] , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
public static void main ( String [ ] args ) { int ar [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = ar . length ; System . out . println ( " Element ▁ occurring ▁ once ▁ is ▁ " + findSingle ( ar , n ) + " ▁ " ) ; } }
static int countOccurrences ( int arr [ ] , int n , int x ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( x == arr [ i ] ) res ++ ; return res ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = arr . length ; int x = 2 ; System . out . println ( countOccurrences ( arr , n , x ) ) ; } }
static int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r < l ) return - 1 ; int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
static int countOccurrences ( int arr [ ] , int n , int x ) { int ind = binarySearch ( arr , 0 , n - 1 , x ) ;
if ( ind == - 1 ) return 0 ;
int count = 1 ; int left = ind - 1 ; while ( left >= 0 && arr [ left ] == x ) { count ++ ; left -- ; }
int right = ind + 1 ; while ( right < n && arr [ right ] == x ) { count ++ ; right ++ ; } return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = arr . length ; int x = 2 ; System . out . print ( countOccurrences ( arr , n , x ) ) ; } }
static void printClosest ( int arr [ ] , int n , int x ) {
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 , diff = Integer . MAX_VALUE ;
while ( r > l ) {
if ( Math . abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } System . out . println ( " ▁ The ▁ closest ▁ pair ▁ is ▁ " + arr [ res_l ] + " ▁ and ▁ " + arr [ res_r ] ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 10 , 22 , 28 , 29 , 30 , 40 } , x = 54 ; int n = arr . length ; printClosest ( arr , n , x ) ; } }
int countOnes ( int arr [ ] , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
public static void main ( String args [ ] ) { CountOnes ob = new CountOnes ( ) ; int arr [ ] = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = arr . length ; System . out . println ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " + ob . countOnes ( arr , 0 , n - 1 ) ) ; } }
int findMissingUtil ( int arr1 [ ] , int arr2 [ ] , int N ) {
if ( N == 1 ) return arr1 [ 0 ] ;
if ( arr1 [ 0 ] != arr2 [ 0 ] ) return arr1 [ 0 ] ;
int lo = 0 , hi = N - 1 ;
while ( lo < hi ) { int mid = ( lo + hi ) / 2 ;
if ( arr1 [ mid ] == arr2 [ mid ] ) lo = mid ; else hi = mid ;
if ( lo == hi - 1 ) break ; }
return arr1 [ hi ] ; }
void findMissing ( int arr1 [ ] , int arr2 [ ] , int M , int N ) { if ( N == M - 1 ) System . out . println ( " Missing ▁ Element ▁ is ▁ " + findMissingUtil ( arr1 , arr2 , M ) + "NEW_LINE"); else if ( M == N - 1 ) System . out . println ( " Missing ▁ Element ▁ is ▁ " + findMissingUtil ( arr2 , arr1 , N ) + "NEW_LINE"); else System . out . println ( " Invalid ▁ Input " ) ; }
public static void main ( String args [ ] ) { MissingNumber obj = new MissingNumber ( ) ; int arr1 [ ] = { 1 , 4 , 5 , 7 , 9 } ; int arr2 [ ] = { 4 , 5 , 7 , 9 } ; int M = arr1 . length ; int N = arr2 . length ; obj . findMissing ( arr1 , arr2 , M , N ) ; } }
void findMissing ( int arr1 [ ] , int arr2 [ ] , int M , int N ) { if ( M != N - 1 && N != M - 1 ) { System . out . println ( " Invalid ▁ Input " ) ; return ; }
int res = 0 ; for ( int i = 0 ; i < M ; i ++ ) res = res ^ arr1 [ i ] ; for ( int i = 0 ; i < N ; i ++ ) res = res ^ arr2 [ i ] ; System . out . println ( " Missing ▁ element ▁ is ▁ " + res ) ; }
public static void main ( String args [ ] ) { Missing obj = new Missing ( ) ; int arr1 [ ] = { 4 , 1 , 5 , 9 , 7 } ; int arr2 [ ] = { 7 , 5 , 9 , 4 } ; int M = arr1 . length ; int N = arr2 . length ; obj . findMissing ( arr1 , arr2 , M , N ) ; } }
static void getTwoElements ( int arr [ ] , int n ) {
int xor1 ;
int set_bit_no ; int i ; x = 0 ; y = 0 ; xor1 = arr [ 0 ] ;
for ( i = 1 ; i < n ; i ++ ) xor1 = xor1 ^ arr [ i ] ;
for ( i = 1 ; i <= n ; i ++ ) xor1 = xor1 ^ i ;
set_bit_no = xor1 & ~ ( xor1 - 1 ) ;
for ( i = 0 ; i < n ; i ++ ) { if ( ( arr [ i ] & set_bit_no ) != 0 )
x = x ^ arr [ i ] ; else
y = y ^ arr [ i ] ; } for ( i = 1 ; i <= n ; i ++ ) { if ( ( i & set_bit_no ) != 0 )
x = x ^ i ; else
y = y ^ i ; }
}
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 4 , 5 , 1 , 6 , 2 } ; int n = arr . length ; getTwoElements ( arr , n ) ; System . out . println ( " ▁ The ▁ missing ▁ element ▁ is ▁ " + x + " and ▁ the ▁ " + " repeating ▁ number ▁ is ▁ " + y ) ; } }
static int search ( int arr [ ] , int n , int x ) {
int i = 0 ; while ( i < n ) {
if ( arr [ i ] == x ) return i ;
i = i + Math . abs ( arr [ i ] - x ) ; } System . out . println ( " number ▁ is ▁ not " + " ▁ present ! " ) ; return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 } ; int n = arr . length ; int x = 3 ; System . out . println ( " Element ▁ " + x + " ▁ is ▁ present ▁ at ▁ index ▁ " + search ( arr , n , 3 ) ) ; } }
class GFG { static void thirdLargest ( int arr [ ] , int arr_size ) {
if ( arr_size < 3 ) { System . out . printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] ; for ( int i = 1 ; i < arr_size ; i ++ ) if ( arr [ i ] > first ) first = arr [ i ] ;
int second = Integer . MIN_VALUE ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > second && arr [ i ] < first ) second = arr [ i ] ;
int third = Integer . MIN_VALUE ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > third && arr [ i ] < second ) third = arr [ i ] ; System . out . printf ( " The ▁ third ▁ Largest ▁ " + "element is %dNEW_LINE", third); }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = arr . length ; thirdLargest ( arr , n ) ; } }
class GFG { static void thirdLargest ( int arr [ ] , int arr_size ) {
if ( arr_size < 3 ) { System . out . printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] , second = Integer . MIN_VALUE , third = Integer . MIN_VALUE ;
for ( int i = 1 ; i < arr_size ; i ++ ) {
if ( arr [ i ] > first ) { third = second ; second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) { third = second ; second = arr [ i ] ; }
else if ( arr [ i ] > third ) { third = arr [ i ] ; } } System . out . printf ( "The third Largest element is %dNEW_LINE", third); }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = arr . length ; thirdLargest ( arr , n ) ; } }
static boolean checkPair ( int arr [ ] , int n ) {
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum += arr [ i ] ; }
if ( sum % 2 != 0 ) { return false ; } sum = sum / 2 ;
HashSet < Integer > s = new HashSet < Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { int val = sum - arr [ i ] ;
if ( s . contains ( val ) && val == ( int ) s . toArray ( ) [ s . size ( ) - 1 ] ) { System . out . printf ( "Pair elements are %d and %dNEW_LINE", arr[i], val); return true ; } s . add ( arr [ i ] ) ; } return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 11 , 5 , 1 , 4 , 7 } ; int n = arr . length ; if ( checkPair ( arr , n ) == false ) { System . out . printf ( " No ▁ pair ▁ found " ) ; } } }
static String search ( int arr [ ] , int n , int x ) {
if ( arr [ n - 1 ] == x ) return " Found " ; int backup = arr [ n - 1 ] ; arr [ n - 1 ] = x ;
for ( int i = 0 ; ; i ++ ) {
if ( arr [ i ] == x ) {
arr [ n - 1 ] = backup ;
if ( i < n - 1 ) return " Found " ;
return " Not ▁ Found " ; } } }
public static void main ( String [ ] args ) { int arr [ ] = { 4 , 6 , 1 , 5 , 8 } ; int n = arr . length ; int x = 1 ; System . out . println ( search ( arr , n , x ) ) ; } }
public class Test { public static int findMajority ( int arr [ ] , int n ) { return arr [ n / 2 ] ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 2 , 3 } ; int n = arr . length ; System . out . println ( findMajority ( arr , n ) ) ; } }
class GFG { static void minAdjDifference ( int arr [ ] , int n ) { if ( n < 2 ) return ;
int res = Math . abs ( arr [ 1 ] - arr [ 0 ] ) ; for ( int i = 2 ; i < n ; i ++ ) res = Math . min ( res , Math . abs ( arr [ i ] - arr [ i - 1 ] ) ) ;
res = Math . min ( res , Math . abs ( arr [ n - 1 ] - arr [ 0 ] ) ) ; System . out . print ( " Min ▁ Difference ▁ = ▁ " + res ) ; }
public static void main ( String arg [ ] ) { int a [ ] = { 10 , 12 , 13 , 15 , 10 } ; int n = a . length ; minAdjDifference ( a , n ) ; } }
import java . util . * ; public class GFG { static void Print3Smallest ( int array [ ] , int n ) { int firstmin = Integer . MAX_VALUE ; int secmin = Integer . MAX_VALUE ; int thirdmin = Integer . MAX_VALUE ; for ( int i = 0 ; i < n ; i ++ ) {
if ( array [ i ] < firstmin ) { thirdmin = secmin ; secmin = firstmin ; firstmin = array [ i ] ; }
else if ( array [ i ] < secmin ) { thirdmin = secmin ; secmin = array [ i ] ; }
else if ( array [ i ] < thirdmin ) thirdmin = array [ i ] ; } System . out . println ( " First ▁ min ▁ = ▁ " + firstmin ) ; System . out . println ( " Second ▁ min ▁ = ▁ " + secmin ) ; System . out . println ( " Third ▁ min ▁ = ▁ " + thirdmin ) ; }
public static void main ( String [ ] args ) { int array [ ] = { 4 , 9 , 1 , 32 , 12 } ; int n = array . length ; Print3Smallest ( array , n ) ; } }
import java . util . Arrays ; class GFG { static int getMin ( int arr [ ] , int n ) { return Arrays . stream ( arr ) . min ( ) . getAsInt ( ) ; } static int getMax ( int arr [ ] , int n ) { return Arrays . stream ( arr ) . max ( ) . getAsInt ( ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 1234 , 45 , 67 , 1 } ; int n = arr . length ; System . out . println ( " Minimum ▁ element ▁ of ▁ array : ▁ " + getMin ( arr , n ) ) ; System . out . println ( " Maximum ▁ element ▁ of ▁ array : ▁ " + getMax ( arr , n ) ) ; } }
void printfrequency ( int arr [ ] , int n ) {
for ( int j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] - 1 ;
for ( int i = 0 ; i < n ; i ++ ) arr [ arr [ i ] % n ] = arr [ arr [ i ] % n ] + n ;
for ( int i = 0 ; i < n ; i ++ ) System . out . println ( i + 1 + " - > " + arr [ i ] / n ) ; }
public static void main ( String [ ] args ) { CountFrequency count = new CountFrequency ( ) ; int arr [ ] = { 2 , 3 , 3 , 2 , 5 } ; int n = arr . length ; count . printfrequency ( arr , n ) ; } }
int getInvCount ( int arr [ ] , int n ) {
int invcount = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) {
int small = 0 ; for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) small ++ ;
int great = 0 ; for ( int j = i - 1 ; j >= 0 ; j -- ) if ( arr [ i ] < arr [ j ] ) great ++ ;
invcount += great * small ; } return invcount ; }
public static void main ( String args [ ] ) { Inversion inversion = new Inversion ( ) ; int arr [ ] = new int [ ] { 8 , 4 , 2 , 1 } ; int n = arr . length ; System . out . print ( " Inversion ▁ count ▁ : ▁ " + inversion . getInvCount ( arr , n ) ) ; } }
static int findWater ( int n ) {
int water = 0 ;
left [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) left [ i ] = Math . max ( left [ i - 1 ] , arr [ i ] ) ;
right [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) right [ i ] = Math . max ( right [ i + 1 ] , arr [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) water += Math . min ( left [ i ] , right [ i ] ) - arr [ i ] ; return water ; }
public static void main ( String [ ] args ) { System . out . println ( " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " + findWater ( arr . length ) ) ; } }
import java . util . * ; class GFG { static int findWater ( int arr [ ] , int n ) {
int result = 0 ;
int left_max = 0 , right_max = 0 ;
int lo = 0 , hi = n - 1 ; while ( lo <= hi ) { if ( arr [ lo ] < arr [ hi ] ) { if ( arr [ lo ] > left_max )
left_max = arr [ lo ] ; else
result += left_max - arr [ lo ] ; lo ++ ; } else { if ( arr [ hi ] > right_max )
right_max = arr [ hi ] ; else result += right_max - arr [ hi ] ; hi -- ; } } return result ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = arr . length ; System . out . println ( " Maximum ▁ water ▁ that ▁ " + " can ▁ be ▁ accumulated ▁ is ▁ " + findWater ( arr , n ) ) ; } }
static int missingK ( int [ ] a , int k , int n ) { int difference = 0 , ans = 0 , count = k ; boolean flag = false ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { difference = 0 ;
if ( ( a [ i ] + 1 ) != a [ i + 1 ] ) {
difference += ( a [ i + 1 ] - a [ i ] ) - 1 ;
if ( difference >= count ) { ans = a [ i ] + count ; flag = true ; break ; } else count -= difference ; } }
if ( flag ) return ans ; else return - 1 ; }
int [ ] a = { 1 , 5 , 11 , 19 } ;
int k = 11 ; int n = a . length ;
int missing = missingK ( a , k , n ) ; System . out . print ( missing ) ; } }
import java . io . * ; class GFG { static int [ ] a = new int [ ] { 900 } ; static int [ ] b = new int [ ] { 10 , 13 , 14 } ;
static int maximum ( int a , int b ) { return a > b ? a : b ; }
static int minimum ( int a , int b ) { return a < b ? a : b ; }
static double findMedianSortedArrays ( int n , int m ) { int min_index = 0 , max_index = n , i = 0 , j = 0 , median = 0 ; while ( min_index <= max_index ) { i = ( min_index + max_index ) / 2 ; j = ( ( n + m + 1 ) / 2 ) - i ;
if ( i < n && j > 0 && b [ j - 1 ] > a [ i ] ) min_index = i + 1 ;
else if ( i > 0 && j < m && b [ j ] < a [ i - 1 ] ) max_index = i - 1 ;
else {
if ( i == 0 ) median = b [ j - 1 ] ;
else if ( j == 0 ) median = a [ i - 1 ] ; else median = maximum ( a [ i - 1 ] , b [ j - 1 ] ) ; break ; } }
if ( ( n + m ) % 2 == 1 ) return ( double ) median ;
if ( i == n ) return ( median + b [ j ] ) / 2.0 ;
if ( j == m ) return ( median + a [ i ] ) / 2.0 ; return ( median + minimum ( a [ i ] , b [ j ] ) ) / 2.0 ; }
public static void main ( String args [ ] ) { int n = a . length ; int m = b . length ;
if ( n < m ) System . out . print ( " The ▁ median ▁ is ▁ : ▁ " + findMedianSortedArrays ( n , m ) ) ; else System . out . print ( " The ▁ median ▁ is ▁ : ▁ " + findMedianSortedArrays ( m , n ) ) ; } }
import java . io . * ; class GFG { static void printUncommon ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) { int i = 0 , j = 0 , k = 0 ; while ( i < n1 && j < n2 ) {
if ( arr1 [ i ] < arr2 [ j ] ) { System . out . print ( arr1 [ i ] + " ▁ " ) ; i ++ ; k ++ ; } else if ( arr2 [ j ] < arr1 [ i ] ) { System . out . print ( arr2 [ j ] + " ▁ " ) ; k ++ ; j ++ ; }
else { i ++ ; j ++ ; } }
while ( i < n1 ) { System . out . print ( arr1 [ i ] + " ▁ " ) ; i ++ ; k ++ ; } while ( j < n2 ) { System . out . print ( arr2 [ j ] + " ▁ " ) ; j ++ ; k ++ ; } }
public static void main ( String [ ] args ) { int arr1 [ ] = { 10 , 20 , 30 } ; int arr2 [ ] = { 20 , 25 , 30 , 40 , 50 } ; int n1 = arr1 . length ; int n2 = arr2 . length ; printUncommon ( arr1 , arr2 , n1 , n2 ) ; } }
import java . io . * ; import java . util . * ; class GFG { static int leastFrequent ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
int min_count = n + 1 , res = - 1 ; int curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 } ; int n = arr . length ; System . out . print ( leastFrequent ( arr , n ) ) ; } }
import java . io . * ; class GFG { static int M = 4 ; static int arr [ ] [ ] = { { 1 , 7 , 3 , 4 } , { 4 , 2 , 5 , 1 } , { 9 , 5 , 1 , 8 } } ; static void sort ( int a [ ] [ ] , int row , int n ) { for ( int i = 0 ; i < M - 1 ; i ++ ) { if ( a [ row ] [ i ] > a [ row ] [ i + 1 ] ) { int temp = a [ row ] [ i ] ; a [ row ] [ i ] = a [ row ] [ i + 1 ] ; a [ row ] [ i + 1 ] = temp ; } } }
static int maximumSum ( int a [ ] [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) sort ( a , i , n ) ;
int sum = a [ n - 1 ] [ M - 1 ] ; int prev = a [ n - 1 ] [ M - 1 ] ; int i , j ;
for ( i = n - 2 ; i >= 0 ; i -- ) { for ( j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i ] [ j ] < prev ) { prev = a [ i ] [ j ] ; sum += prev ; break ; } }
if ( j == - 1 ) return 0 ; } return sum ; }
public static void main ( String args [ ] ) { int n = arr . length ; System . out . print ( maximumSum ( arr , n ) ) ; } }
static int countPairs ( int A [ ] , int n , int k ) { int ans = 0 ;
Arrays . sort ( A ) ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int x = 0 ;
while ( ( A [ i ] * Math . pow ( k , x ) ) <= A [ j ] ) { if ( ( A [ i ] * Math . pow ( k , x ) ) == A [ j ] ) { ans ++ ; break ; } x ++ ; } } } return ans ; }
public static void main ( String [ ] args ) { int A [ ] = { 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 } ; int n = A . length ; int k = 3 ; System . out . println ( countPairs ( A , n , k ) ) ; } }
static int minDistance ( int arr [ ] , int n ) { int maximum_element = arr [ 0 ] ; int min_dis = n ; int index = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( maximum_element == arr [ i ] ) { min_dis = Math . min ( min_dis , ( i - index ) ) ; index = i ; }
else if ( maximum_element < arr [ i ] ) { maximum_element = arr [ i ] ; min_dis = n ; index = i ; }
else continue ; } return min_dis ; }
public static void main ( String [ ] args ) { int arr [ ] = { 6 , 3 , 1 , 3 , 6 , 4 , 6 } ; int n = arr . length ; System . out . print ( " Minimum ▁ distance ▁ = ▁ " + minDistance ( arr , n ) ) ; } }
static int findValue ( int arr [ ] , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] == k ) k *= 2 ; return k ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 3 , 4 , 10 , 8 , 1 } , k = 2 ; int n = arr . length ; System . out . print ( findValue ( arr , n , k ) ) ; } }
import java . io . * ; class GFG { static void dupLastIndex ( int arr [ ] , int n ) {
if ( arr == null n <= 0 ) return ;
for ( int i = n - 1 ; i > 0 ; i -- ) { if ( arr [ i ] == arr [ i - 1 ] ) { System . out . println ( " Last ▁ index : " + i ) ; System . out . println ( " Last ▁ duplicate ▁ item : ▁ " + arr [ i ] ) ; return ; } }
System . out . print ( " no ▁ duplicate ▁ found " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 5 , 5 , 6 , 6 , 7 , 9 } ; int n = arr . length ; dupLastIndex ( arr , n ) ; } }
static int findSmallest ( int a [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < n ; j ++ ) if ( a [ j ] % a [ i ] >= 1 ) break ;
if ( j == n ) return a [ i ] ; } return - 1 ; }
public static void main ( String args [ ] ) { int a [ ] = { 25 , 20 , 5 , 10 , 100 } ; int n = a . length ; System . out . println ( findSmallest ( a , n ) ) ; } }
static int findSmallest ( int a [ ] , int n ) {
int smallest = min_element ( a ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( a [ i ] % smallest >= 1 ) return - 1 ; return smallest ; }
public static void main ( String args [ ] ) { int a [ ] = { 25 , 20 , 5 , 10 , 100 } ; int n = a . length ; System . out . println ( findSmallest ( a , n ) ) ; } }
public static int findIndex ( int [ ] arr ) {
int maxIndex = 0 ; for ( int i = 0 ; i < arr . length ; ++ i ) if ( arr [ i ] > arr [ maxIndex ] ) maxIndex = i ;
for ( int i = 0 ; i < arr . length ; ++ i ) if ( maxIndex != i && arr [ maxIndex ] < 2 * arr [ i ] ) return - 1 ; return maxIndex ; }
public static void main ( String argc [ ] ) { int [ ] arr = new int [ ] { 3 , 6 , 1 , 0 } ; System . out . println ( findIndex ( arr ) ) ; } }
static int find_consecutive_steps ( int arr [ ] , int len ) { int count = 0 ; int maximum = 0 ; for ( int index = 1 ; index < len ; index ++ ) {
if ( arr [ index ] > arr [ index - 1 ] ) count ++ ; else { maximum = Math . max ( maximum , count ) ; count = 0 ; } } return Math . max ( maximum , count ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int len = arr . length ; System . out . println ( find_consecutive_steps ( arr , len ) ) ; } }
import java . util . Arrays ; import java . io . * ; class GFG { static int CalculateMax ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ; int min_sum = arr [ 0 ] + arr [ 1 ] ; int max_sum = arr [ n - 1 ] + arr [ n - 2 ] ; return ( Math . abs ( max_sum - min_sum ) ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 6 , 7 , 1 , 11 } ; int n = arr . length ; System . out . println ( CalculateMax ( arr , n ) ) ; } }
import java . util . Arrays ; import java . util . Collections ; import java . util . Vector ; class GFG { static long calculate ( long a [ ] , int n ) {
Arrays . sort ( a ) ; int i , j ;
Vector < Long > s = new Vector < > ( ) ; for ( i = 0 , j = n - 1 ; i < j ; i ++ , j -- ) s . add ( ( a [ i ] + a [ j ] ) ) ; long mini = Collections . min ( s ) ; long maxi = Collections . max ( s ) ; return Math . abs ( maxi - mini ) ; }
public static void main ( String [ ] args ) { long a [ ] = { 2 , 6 , 4 , 3 } ; int n = a . length ; System . out . println ( calculate ( a , n ) ) ; } }
static void printMinDiffPairs ( int arr [ ] , int n ) { if ( n <= 1 ) return ;
Arrays . sort ( arr ) ;
int minDiff = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) minDiff = Math . min ( minDiff , arr [ i ] - arr [ i - 1 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) { if ( ( arr [ i ] - arr [ i - 1 ] ) == minDiff ) { System . out . print ( " ( " + arr [ i - 1 ] + " , ▁ " + arr [ i ] + " ) , " ) ; } } }
public static void main ( String [ ] args ) { int arr [ ] = { 5 , 3 , 2 , 4 , 1 } ; int n = arr . length ; printMinDiffPairs ( arr , n ) ; } }
public class MaximumAbsoluteDifference { private static int calculateDiff ( int i , int j , int [ ] array ) {
return Math . abs ( array [ i ] - array [ j ] ) + Math . abs ( i - j ) ; }
private static int maxDistance ( int [ ] array ) {
int result = 0 ;
for ( int i = 0 ; i < array . length ; i ++ ) { for ( int j = i ; j < array . length ; j ++ ) {
result = Math . max ( result , calculateDiff ( i , j , array ) ) ; } } return result ; }
public static void main ( String [ ] args ) { int [ ] array = { - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 } ; System . out . println ( maxDistance ( array ) ) ; } }
private static int maxDistance ( int [ ] array ) {
int max1 = Integer . MIN_VALUE ; int min1 = Integer . MAX_VALUE ; int max2 = Integer . MIN_VALUE ; int min2 = Integer . MAX_VALUE ; for ( int i = 0 ; i < array . length ; i ++ ) {
max1 = Math . max ( max1 , array [ i ] + i ) ; min1 = Math . min ( min1 , array [ i ] + i ) ; max2 = Math . max ( max2 , array [ i ] - i ) ; min2 = Math . min ( min2 , array [ i ] - i ) ; }
return Math . max ( max1 - min1 , max2 - min2 ) ; }
public static void main ( String [ ] args ) { int [ ] array = { - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 } ; System . out . println ( maxDistance ( array ) ) ; } }
static int extrema ( int a [ ] , int n ) { int count = 0 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
if ( a [ i ] > a [ i - 1 ] && a [ i ] > a [ i + 1 ] ) count += 1 ;
if ( a [ i ] < a [ i - 1 ] && a [ i ] < a [ i + 1 ] ) count += 1 ; } return count ; }
public static void main ( String args [ ] ) throws IOException { int a [ ] = { 1 , 0 , 2 , 1 } ; int n = a . length ; System . out . println ( extrema ( a , n ) ) ; } }
public static int findClosest ( int arr [ ] , int target ) { int n = arr . length ;
if ( target <= arr [ 0 ] ) return arr [ 0 ] ; if ( target >= arr [ n - 1 ] ) return arr [ n - 1 ] ;
int i = 0 , j = n , mid = 0 ; while ( i < j ) { mid = ( i + j ) / 2 ; if ( arr [ mid ] == target ) return arr [ mid ] ;
if ( target < arr [ mid ] ) {
if ( mid > 0 && target > arr [ mid - 1 ] ) return getClosest ( arr [ mid - 1 ] , arr [ mid ] , target ) ;
j = mid ; }
else { if ( mid < n - 1 && target < arr [ mid + 1 ] ) return getClosest ( arr [ mid ] , arr [ mid + 1 ] , target ) ;
i = mid + 1 ; } }
return arr [ mid ] ; }
public static int getClosest ( int val1 , int val2 , int target ) { if ( target - val1 >= val2 - target ) return val2 ; else return val1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 } ; int target = 11 ; System . out . println ( findClosest ( arr , target ) ) ; } }
static int sum ( int a [ ] , int n ) {
int maxSum = Integer . MIN_VALUE ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) maxSum = Math . max ( maxSum , a [ i ] + a [ j ] ) ;
int c = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( a [ i ] + a [ j ] == maxSum ) c ++ ; return c ; }
public static void main ( String [ ] args ) { int array [ ] = { 1 , 1 , 1 , 2 , 2 , 2 } ; int n = array . length ; System . out . println ( sum ( array , n ) ) ; } }
static int sum ( int a [ ] , int n ) {
int maxVal = a [ 0 ] , maxCount = 1 ; int secondMax = Integer . MIN_VALUE , secondMaxCount = 0 ; for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == maxVal ) maxCount ++ ; else if ( a [ i ] > maxVal ) { secondMax = maxVal ; secondMaxCount = maxCount ; maxVal = a [ i ] ; maxCount = 1 ; } else if ( a [ i ] == secondMax ) { secondMax = a [ i ] ; secondMaxCount ++ ; } else if ( a [ i ] > secondMax ) { secondMax = a [ i ] ; secondMaxCount = 1 ; } }
if ( maxCount > 1 ) return maxCount * ( maxCount - 1 ) / 2 ;
return secondMaxCount ; }
public static void main ( String [ ] args ) { int array [ ] = { 1 , 1 , 1 , 2 , 2 , 2 , 3 } ; int n = array . length ; System . out . println ( sum ( array , n ) ) ; } }
static void printKMissing ( int [ ] arr , int n , int k ) { Arrays . sort ( arr ) ;
int i = 0 ; while ( i < n && arr [ i ] <= 0 ) i ++ ;
int count = 0 , curr = 1 ; while ( count < k && i < n ) { if ( arr [ i ] != curr ) { System . out . print ( curr + " ▁ " ) ; count ++ ; } else i ++ ; curr ++ ; }
while ( count < k ) { System . out . print ( curr + " ▁ " ) ; curr ++ ; count ++ ; } }
public static void main ( String [ ] args ) { int [ ] arr = { 2 , 3 , 4 } ; int n = arr . length ; int k = 3 ; printKMissing ( arr , n , k ) ; } }
public static int nobleInteger ( int arr [ ] ) { int size = arr . length ; for ( int i = 0 ; i < size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( arr [ i ] < arr [ j ] ) count ++ ;
if ( count == arr [ i ] ) return arr [ i ] ; } return - 1 ; }
public static void main ( String args [ ] ) { int [ ] arr = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr ) ; if ( res != - 1 ) System . out . println ( " The ▁ noble ▁ " + " integer ▁ is ▁ " + res ) ; else System . out . println ( " No ▁ Noble ▁ " + " Integer ▁ Found " ) ; } }
public static int nobleInteger ( int arr [ ] ) { Arrays . sort ( arr ) ;
int n = arr . length ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] == arr [ i + 1 ] ) continue ;
if ( arr [ i ] == n - i - 1 ) return arr [ i ] ; } if ( arr [ n - 1 ] == 0 ) return arr [ n - 1 ] ; return - 1 ; }
public static void main ( String args [ ] ) { int [ ] arr = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr ) ; if ( res != - 1 ) System . out . println ( " The ▁ noble ▁ integer ▁ is ▁ " + res ) ; else System . out . println ( " No ▁ Noble ▁ Integer ▁ Found " ) ; } }
static long findMinSum ( long a [ ] , long b [ ] , long n ) {
Arrays . sort ( a ) ; Arrays . sort ( b ) ;
long sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + Math . abs ( a [ i ] - b [ i ] ) ; return sum ; }
long a [ ] = { 4 , 1 , 8 , 7 } ; long b [ ] = { 2 , 3 , 6 , 5 } ; int n = a . length ; System . out . println ( findMinSum ( a , b , n ) ) ; } }
static boolean checkIsAP ( int arr [ ] , int n ) { if ( n == 1 ) return true ;
Arrays . sort ( arr ) ;
int d = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] != d ) return false ; return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 20 , 15 , 5 , 0 , 10 } ; int n = arr . length ; if ( checkIsAP ( arr , n ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
class GFG { static int minProductSubset ( int a [ ] , int n ) { if ( n == 1 ) return a [ 0 ] ;
int negmax = Integer . MIN_VALUE ; int posmin = Integer . MAX_VALUE ; int count_neg = 0 , count_zero = 0 ; int product = 1 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == 0 ) { count_zero ++ ; continue ; }
if ( a [ i ] < 0 ) { count_neg ++ ; negmax = Math . max ( negmax , a [ i ] ) ; }
if ( a [ i ] > 0 && a [ i ] < posmin ) posmin = a [ i ] ; product *= a [ i ] ; }
if ( count_zero == n || ( count_neg == 0 && count_zero > 0 ) ) return 0 ;
if ( count_neg == 0 ) return posmin ;
if ( count_neg % 2 == 0 && count_neg != 0 ) {
product = product / negmax ; } return product ; }
public static void main ( String [ ] args ) { int a [ ] = { - 1 , - 1 , - 2 , 4 , 3 } ; int n = 5 ; System . out . println ( minProductSubset ( a , n ) ) ; } }
import java . util . * ; class GFG { static int countPairs ( int a [ ] , int n ) {
int mn = Integer . MAX_VALUE ; int mx = Integer . MIN_VALUE ; for ( int i = 0 ; i < n ; i ++ ) { mn = Math . min ( mn , a [ i ] ) ; mx = Math . max ( mx , a [ i ] ) ; }
int c1 = 0 ;
int c2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] == mn ) c1 ++ ; if ( a [ i ] == mx ) c2 ++ ; }
if ( mn == mx ) return n * ( n - 1 ) / 2 ; else return c1 * c2 ; }
public static void main ( String [ ] args ) { int a [ ] = { 3 , 2 , 1 , 1 , 3 } ; int n = a . length ; System . out . print ( countPairs ( a , n ) ) ; } }
import java . util . Arrays ; public class Test4 { static int findElement ( int a [ ] , int n , int b ) {
Arrays . sort ( a ) ;
int max = a [ n - 1 ] ; while ( b < max ) {
if ( Arrays . binarySearch ( a , b ) > - 1 ) b *= 2 ; else return b ; } return b ; }
public static void main ( String args [ ] ) { int a [ ] = { 1 , 2 , 3 } ; int n = a . length ; int b = 1 ; System . out . println ( findElement ( a , n , b ) ) ; } }
import java . io . * ; import java . util . * ; class GFG { static int Mod = 1000000007 ;
static long findSum ( int arr [ ] , int n ) { long sum = 0 ;
Arrays . sort ( arr ) ;
int i = 0 ; while ( i < n && arr [ i ] < 0 ) { if ( i != n - 1 && arr [ i + 1 ] <= 0 ) { sum = ( sum + ( arr [ i ] * arr [ i + 1 ] ) % Mod ) % Mod ; i += 2 ; } else break ; }
int j = n - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { if ( j != 0 && arr [ j - 1 ] > 0 ) { sum = ( sum + ( arr [ j ] * arr [ j - 1 ] ) % Mod ) % Mod ; j -= 2 ; } else break ; }
if ( j > i ) sum = ( sum + ( arr [ i ] * arr [ j ] ) % Mod ) % Mod ;
else if ( i == j ) sum = ( sum + arr [ i ] ) % Mod ; return sum ; }
public static void main ( String args [ ] ) { int arr [ ] = { - 1 , 9 , 4 , 5 , - 4 , 7 } ; int n = arr . length ; System . out . println ( findSum ( arr , n ) ) ; } }
static void countOddRotations ( int n ) { int odd_count = 0 , even_count = 0 ; do { int digit = n % 10 ; if ( digit % 2 == 1 ) odd_count ++ ; else even_count ++ ; n = n / 10 ; } while ( n != 0 ) ; System . out . println ( " Odd ▁ = ▁ " + odd_count ) ; System . out . println ( " Even ▁ = ▁ " + even_count ) ; }
public static void main ( String [ ] args ) { int n = 1234 ; countOddRotations ( n ) ; } }
static int numberOfDigits ( int n ) { int cnt = 0 ; while ( n > 0 ) { cnt ++ ; n /= 10 ; } return cnt ; }
static void cal ( int num ) { int digits = numberOfDigits ( num ) ; int powTen = ( int ) Math . pow ( 10 , digits - 1 ) ; for ( int i = 0 ; i < digits - 1 ; i ++ ) { int firstDigit = num / powTen ;
int left = ( ( num * 10 ) + firstDigit ) - ( firstDigit * powTen * 10 ) ; System . out . print ( left + " ▁ " ) ;
num = left ; } }
public static void main ( String [ ] args ) { int num = 1445 ; cal ( num ) ; } }
class GFG { static void CheckKCycles ( int n , String s ) { boolean ff = true ; int x = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
x = ( s . substring ( i ) + s . substring ( 0 , i ) ) . length ( ) ;
if ( x >= s . length ( ) ) { continue ; } ff = false ; break ; } if ( ff ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " No " ) ; } }
public static void main ( String [ ] args ) { int n = 3 ; String s = "123" ; CheckKCycles ( n , s ) ; } }
static boolean rightRotationDivisor ( int N ) { int lastDigit = N % 10 ; int rightRotation = ( int ) ( lastDigit * Math . pow ( 10 , ( int ) ( Math . log10 ( N ) ) ) + Math . floor ( N / 10 ) ) ; return ( rightRotation % N == 0 ) ; }
static void generateNumbers ( int m ) { for ( int i = ( int ) Math . pow ( 10 , ( m - 1 ) ) ; i < Math . pow ( 10 , m ) ; i ++ ) if ( rightRotationDivisor ( i ) ) System . out . println ( i ) ; }
public static void main ( String args [ ] ) { int m = 3 ; generateNumbers ( m ) ; } }
static void checkIfSortRotated ( int arr [ ] , int n ) { int minEle = Integer . MAX_VALUE ; int maxEle = Integer . MIN_VALUE ; int minIndex = - 1 ;
for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < minEle ) { minEle = arr [ i ] ; minIndex = i ; } } boolean flag1 = true ;
for ( int i = 1 ; i < minIndex ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag1 = false ; break ; } } boolean flag2 = true ;
for ( int i = minIndex + 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag2 = false ; break ; } }
if ( flag1 && flag2 && ( arr [ n - 1 ] < arr [ 0 ] ) ) System . out . println ( " YES " ) ; else System . out . print ( " NO " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 4 , 5 , 1 , 2 } ; int n = arr . length ;
checkIfSortRotated ( arr , n ) ; } }
static void occurredOnce ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
if ( arr [ 0 ] != arr [ 1 ] ) System . out . println ( arr [ 0 ] + " ▁ " ) ;
for ( int i = 1 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i - 1 ] ) System . out . print ( arr [ i ] + " ▁ " ) ;
if ( arr [ n - 2 ] != arr [ n - 1 ] ) System . out . print ( arr [ n - 1 ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = arr . length ; occurredOnce ( arr , n ) ; } }
static void occurredOnce ( int arr [ ] , int n ) { int i = 1 , len = n ;
if ( arr [ 0 ] == arr [ len - 1 ] ) { i = 2 ; len -- ; }
for ( ; i < n ; i ++ )
if ( arr [ i ] == arr [ i - 1 ] ) i ++ ;
else System . out . print ( arr [ i - 1 ] + " ▁ " ) ;
if ( arr [ n - 1 ] != arr [ 0 ] && arr [ n - 1 ] != arr [ n - 2 ] ) System . out . print ( arr [ n - 1 ] ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = arr . length ; occurredOnce ( arr , n ) ; } }
static void rvereseArray ( int arr [ ] , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
static void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
static void splitArr ( int arr [ ] , int k , int n ) { rvereseArray ( arr , 0 , n - 1 ) ; rvereseArray ( arr , 0 , n - k - 1 ) ; rvereseArray ( arr , n - k , n - 1 ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = arr . length ; int k = 2 ;
splitArr ( arr , k , n ) ; printArray ( arr , n ) ; } }
static int countRotationsDivBy8 ( String n ) { int len = n . length ( ) ; int count = 0 ;
if ( len == 1 ) { int oneDigit = n . charAt ( 0 ) - '0' ; if ( oneDigit % 8 == 0 ) return 1 ; return 0 ; }
if ( len == 2 ) {
int first = ( n . charAt ( 0 ) - '0' ) * 10 + ( n . charAt ( 1 ) - '0' ) ;
int second = ( n . charAt ( 1 ) - '0' ) * 10 + ( n . charAt ( 0 ) - '0' ) ; if ( first % 8 == 0 ) count ++ ; if ( second % 8 == 0 ) count ++ ; return count ; }
int threeDigit ; for ( int i = 0 ; i < ( len - 2 ) ; i ++ ) { threeDigit = ( n . charAt ( i ) - '0' ) * 100 + ( n . charAt ( i + 1 ) - '0' ) * 10 + ( n . charAt ( i + 2 ) - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ; }
threeDigit = ( n . charAt ( len - 1 ) - '0' ) * 100 + ( n . charAt ( 0 ) - '0' ) * 10 + ( n . charAt ( 1 ) - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
threeDigit = ( n . charAt ( len - 2 ) - '0' ) * 100 + ( n . charAt ( len - 1 ) - '0' ) * 10 + ( n . charAt ( 0 ) - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
return count ; }
public static void main ( String [ ] args ) { String n = "43262488612" ; System . out . println ( " Rotations : ▁ " + countRotationsDivBy8 ( n ) ) ; } }
static int findRotations ( String str ) {
String tmp = str + str ; int n = str . length ( ) ; for ( int i = 1 ; i <= n ; i ++ ) {
String substring = tmp . substring ( i , i + str . length ( ) ) ;
if ( str . equals ( substring ) ) return i ; } return n ; }
public static void main ( String [ ] args ) { String str = " aaaa " ; System . out . println ( findRotations ( str ) ) ; } }
static boolean isRotation ( long x , long y ) {
long x64 = x | ( x << 32 ) ; while ( x64 >= y ) {
if ( x64 == y ) { return true ; }
x64 >>= 1 ; } return false ; }
public static void main ( String [ ] args ) { long x = 122 ; long y = 2147483678L ; if ( isRotation ( x , y ) == false ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " No " ) ; } } }
static int countRotations ( String n ) { int len = n . length ( ) ;
if ( len == 1 ) { int oneDigit = n . charAt ( 0 ) - '0' ; if ( oneDigit % 4 == 0 ) return 1 ; return 0 ; }
int twoDigit , count = 0 ; for ( int i = 0 ; i < ( len - 1 ) ; i ++ ) { twoDigit = ( n . charAt ( i ) - '0' ) * 10 + ( n . charAt ( i + 1 ) - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; }
twoDigit = ( n . charAt ( len - 1 ) - '0' ) * 10 + ( n . charAt ( 0 ) - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; return count ; }
public static void main ( String args [ ] ) { String n = "4834" ; System . out . println ( " Rotations : ▁ " + countRotations ( n ) ) ; } }
static int solve ( int [ ] A , int n ) { int i , cnt = 0 , j ;
int [ ] parent = new int [ n + 1 ] ;
int [ ] vis = new int [ n + 1 ] ;
for ( i = 0 ; i < n + 1 ; i ++ ) { parent [ i ] = - 1 ; vis [ i ] = 0 ; } for ( i = 0 ; i < n ; i ++ ) { j = i ;
if ( parent [ j ] == - 1 ) {
while ( parent [ j ] == - 1 ) { parent [ j ] = i ; j = ( j + A [ j ] + 1 ) % n ; }
if ( parent [ j ] == i ) {
while ( vis [ j ] == 0 ) { vis [ j ] = 1 ; cnt ++ ; j = ( j + A [ j ] + 1 ) % n ; } } } } return cnt ; }
public static void main ( String args [ ] ) { int [ ] A = { 0 , 0 , 0 , 2 } ; int n = A . length ; System . out . print ( solve ( A , n ) ) ; } }
void TOWUtil ( int arr [ ] , int n , boolean curr_elements [ ] , int no_of_selected_elements , boolean soln [ ] , int sum , int curr_sum , int curr_position ) {
if ( curr_position == n ) return ;
if ( ( n / 2 - no_of_selected_elements ) > ( n - curr_position ) ) return ;
TOWUtil ( arr , n , curr_elements , no_of_selected_elements , soln , sum , curr_sum , curr_position + 1 ) ;
no_of_selected_elements ++ ; curr_sum = curr_sum + arr [ curr_position ] ; curr_elements [ curr_position ] = true ;
if ( no_of_selected_elements == n / 2 ) {
if ( Math . abs ( sum / 2 - curr_sum ) < min_diff ) { min_diff = Math . abs ( sum / 2 - curr_sum ) ; for ( int i = 0 ; i < n ; i ++ ) soln [ i ] = curr_elements [ i ] ; } } else {
TOWUtil ( arr , n , curr_elements , no_of_selected_elements , soln , sum , curr_sum , curr_position + 1 ) ; }
curr_elements [ curr_position ] = false ; }
void tugOfWar ( int arr [ ] ) { int n = arr . length ;
boolean [ ] curr_elements = new boolean [ n ] ;
boolean [ ] soln = new boolean [ n ] ; min_diff = Integer . MAX_VALUE ; int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum += arr [ i ] ; curr_elements [ i ] = soln [ i ] = false ; }
TOWUtil ( arr , n , curr_elements , 0 , soln , sum , 0 , 0 ) ;
System . out . print ( " The ▁ first ▁ subset ▁ is : ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( soln [ i ] == true ) System . out . print ( arr [ i ] + " ▁ " ) ; } System . out . print ( " The second subset is : "); for ( int i = 0 ; i < n ; i ++ ) { if ( soln [ i ] == false ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 23 , 45 , - 34 , 12 , 0 , 98 , - 99 , 4 , 189 , - 1 , 4 } ; TugOfWar a = new TugOfWar ( ) ; a . tugOfWar ( arr ) ; } }
class shortest_path { static int INF = Integer . MAX_VALUE , N = 4 ;
static int minCost ( int cost [ ] [ ] ) {
int dist [ ] = new int [ N ] ; for ( int i = 0 ; i < N ; i ++ ) dist [ i ] = INF ; dist [ 0 ] = 0 ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( dist [ j ] > dist [ i ] + cost [ i ] [ j ] ) dist [ j ] = dist [ i ] + cost [ i ] [ j ] ; return dist [ N - 1 ] ; }
public static void main ( String args [ ] ) { int cost [ ] [ ] = { { 0 , 15 , 80 , 90 } , { INF , 0 , 40 , 50 } , { INF , INF , 0 , 70 } , { INF , INF , INF , 0 } } ; System . out . println ( " The ▁ Minimum ▁ cost ▁ to ▁ reach ▁ station ▁ " + N + " ▁ is ▁ " + minCost ( cost ) ) ; } }
static int numOfways ( int n , int k ) { int p = 1 ; if ( k % 2 != 0 ) p = - 1 ; return ( int ) ( Math . pow ( n - 1 , k ) + p * ( n - 1 ) ) / n ; }
public static void main ( String args [ ] ) { int n = 4 , k = 2 ; System . out . println ( numOfways ( n , k ) ) ; } }
class GfG {
static int power ( int n ) { if ( n == 1 ) return 2 ; return 2 * power ( n - 1 ) ; }
public static void main ( String [ ] args ) { int n = 4 ; System . out . println ( power ( n ) ) ; } }
static int size = 4 ;
static boolean checkStar ( int mat [ ] [ ] ) {
int vertexD1 = 0 , vertexDn_1 = 0 ;
if ( size == 1 ) return ( mat [ 0 ] [ 0 ] == 0 ) ;
if ( size == 2 ) return ( mat [ 0 ] [ 0 ] == 0 && mat [ 0 ] [ 1 ] == 1 && mat [ 1 ] [ 0 ] == 1 && mat [ 1 ] [ 1 ] == 0 ) ;
for ( int i = 0 ; i < size ; i ++ ) { int degreeI = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( mat [ i ] [ j ] == 1 ) degreeI ++ ; if ( degreeI == 1 ) vertexD1 ++ ; else if ( degreeI == size - 1 ) vertexDn_1 ++ ; } return ( vertexD1 == ( size - 1 ) && vertexDn_1 == 1 ) ; }
public static void main ( String args [ ] ) { int mat [ ] [ ] = { { 0 , 1 , 1 , 1 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } } ; if ( checkStar ( mat ) ) System . out . print ( " Star ▁ Graph " ) ; else System . out . print ( " Not ▁ a ▁ Star ▁ Graph " ) ; } }
static int fib ( int n ) { if ( n <= 1 ) return n ; return fib ( n - 1 ) + fib ( n - 2 ) ; }
static int findVertices ( int n ) {
return fib ( n + 2 ) ; } public static void main ( String args [ ] ) {
int n = 3 ; System . out . println ( findVertices ( n ) ) ; } }
static boolean check ( int degree [ ] , int n ) {
int deg_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { deg_sum += degree [ i ] ; }
return ( 2 * ( n - 1 ) == deg_sum ) ; }
public static void main ( String [ ] args ) { int n = 5 ; int degree [ ] = { 2 , 3 , 1 , 1 , 1 } ; if ( check ( degree , n ) ) { System . out . println ( " Tree " ) ; } else { System . out . println ( " Graph " ) ; } } }
static boolean isInorder ( int [ ] arr , int n ) {
if ( n == 0 n == 1 ) { return true ; }
for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i - 1 ] > arr [ i ] ) { return false ; } }
return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 19 , 23 , 25 , 30 , 45 } ; int n = arr . length ; if ( isInorder ( arr , n ) ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " Non " ) ; } } }
static boolean isLeaf ( int pre [ ] , int n , int min , int max ) { if ( i >= n ) { return false ; } if ( pre [ i ] > min && pre [ i ] < max ) { i ++ ; boolean left = isLeaf ( pre , n , min , pre [ i - 1 ] ) ; boolean right = isLeaf ( pre , n , pre [ i - 1 ] , max ) ; if ( ! left && ! right ) { System . out . print ( pre [ i - 1 ] + " ▁ " ) ; } return true ; } return false ; } static void printLeaves ( int preorder [ ] , int n ) { isLeaf ( preorder , n , Integer . MIN_VALUE , Integer . MAX_VALUE ) ; }
public static void main ( String [ ] args ) { int preorder [ ] = { 890 , 325 , 290 , 530 , 965 } ; int n = preorder . length ; printLeaves ( preorder , n ) ; } }
static void pairs ( int arr [ ] , int n , int k ) {
int smallest = Integer . MAX_VALUE ; int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
if ( Math . abs ( arr [ i ] + arr [ j ] - k ) < smallest ) { smallest = Math . abs ( arr [ i ] + arr [ j ] - k ) ; count = 1 ; }
else if ( Math . abs ( arr [ i ] + arr [ j ] - k ) == smallest ) count ++ ; }
System . out . println ( " Minimal ▁ Value ▁ = ▁ " + smallest ) ; System . out . println ( " Total ▁ Pairs ▁ = ▁ " + count ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 5 , 7 , 5 , 1 , 9 , 9 } ; int k = 12 ; int n = arr . length ; pairs ( arr , n , k ) ; } }
public static void main ( String [ ] args ) { int a [ ] = { 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 } ; int key = 20 ; int arraySize = a . length ; int count = 0 ; for ( int i = 0 ; i < arraySize ; i ++ ) { if ( a [ i ] <= key ) { count += 1 ; } } System . out . println ( " Rank ▁ of ▁ " + key + " ▁ in ▁ stream ▁ is : ▁ " + ( count - 1 ) ) ; } }
import java . util . Arrays ; import java . util . Collections ; class GFG { static int MAX_SIZE = 10 ;
static void sortByRow ( Integer mat [ ] [ ] , int n , boolean ascending ) { for ( int i = 0 ; i < n ; i ++ ) { if ( ascending ) Arrays . sort ( mat [ i ] ) ; else Arrays . sort ( mat [ i ] , Collections . reverseOrder ( ) ) ; } }
static void transpose ( Integer mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
int temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ j ] [ i ] ; mat [ j ] [ i ] = temp ; } }
static void sortMatRowAndColWise ( Integer mat [ ] [ ] , int n ) {
sortByRow ( mat , n , true ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n , false ) ;
transpose ( mat , n ) ; }
static void printMat ( Integer mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int n = 3 ; Integer mat [ ] [ ] = { { 3 , 2 , 1 } , { 9 , 8 , 7 } , { 6 , 5 , 4 } } ; System . out . print ( "Original Matrix:NEW_LINE"); printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; System . out . print ( " Matrix After Sorting : "); printMat ( mat , n ) ; } }
import java . io . * ; class GFG { static int MAX = 100 ; static void middlesum ( int mat [ ] [ ] , int n ) { int row_sum = 0 , col_sum = 0 ;
for ( int i = 0 ; i < n ; i ++ ) row_sum += mat [ n / 2 ] [ i ] ; System . out . println ( " Sum ▁ of ▁ middle ▁ row ▁ = ▁ " + row_sum ) ;
for ( int i = 0 ; i < n ; i ++ ) col_sum += mat [ i ] [ n / 2 ] ; System . out . println ( " Sum ▁ of ▁ middle ▁ column ▁ = ▁ " + col_sum ) ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 2 , 5 , 7 } , { 3 , 7 , 2 } , { 5 , 6 , 9 } } ; middlesum ( mat , 3 ) ; } }
static final int M = 3 ; static final int N = 3 ;
static void rotateMatrix ( int matrix [ ] [ ] , int k ) {
int temp [ ] = new int [ M ] ;
k = k % M ; for ( int i = 0 ; i < N ; i ++ ) {
for ( int t = 0 ; t < M - k ; t ++ ) temp [ t ] = matrix [ i ] [ t ] ;
for ( int j = M - k ; j < M ; j ++ ) matrix [ i ] [ j - M + k ] = matrix [ i ] [ j ] ;
for ( int j = k ; j < M ; j ++ ) matrix [ i ] [ j ] = temp [ j - k ] ; } }
static void displayMatrix ( int matrix [ ] [ ] ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) System . out . print ( matrix [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int matrix [ ] [ ] = { { 12 , 23 , 34 } , { 45 , 56 , 67 } , { 78 , 89 , 91 } } ; int k = 2 ;
rotateMatrix ( matrix , k ) ;
displayMatrix ( matrix ) ; } }
import java . io . * ; class GFG { static int N = 3 ;
static void multiply ( int mat [ ] [ ] , int res [ ] [ ] ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) { res [ i ] [ j ] = 0 ; for ( int k = 0 ; k < N ; k ++ ) res [ i ] [ j ] += mat [ i ] [ k ] * mat [ k ] [ j ] ; } } }
static boolean InvolutoryMatrix ( int mat [ ] [ ] ) { int res [ ] [ ] = new int [ N ] [ N ] ;
multiply ( mat , res ) ; for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) { if ( i == j && res [ i ] [ j ] != 1 ) return false ; if ( i != j && res [ i ] [ j ] != 0 ) return false ; } } return true ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 0 , 0 } , { 0 , - 1 , 0 } , { 0 , 0 , - 1 } } ;
if ( InvolutoryMatrix ( mat ) ) System . out . println ( " Involutory ▁ Matrix " ) ; else System . out . println ( " Not ▁ Involutory ▁ Matrix " ) ; } }
import java . io . * ; public class Interchange { static void interchangeFirstLast ( int m [ ] [ ] ) { int rows = m . length ;
for ( int i = 0 ; i < m [ 0 ] . length ; i ++ ) { int t = m [ 0 ] [ i ] ; m [ 0 ] [ i ] = m [ rows - 1 ] [ i ] ; m [ rows - 1 ] [ i ] = t ; } }
int m [ ] [ ] = { { 8 , 9 , 7 , 6 } , { 4 , 7 , 6 , 5 } , { 3 , 2 , 1 , 8 } , { 9 , 9 , 7 , 7 } } ; interchangeFirstLast ( m ) ;
for ( int i = 0 ; i < m . length ; i ++ ) { for ( int j = 0 ; j < m [ 0 ] . length ; j ++ ) System . out . print ( m [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } } }
import java . io . * ; public class markov { static boolean checkMarkov ( double m [ ] [ ] ) {
for ( int i = 0 ; i < m . length ; i ++ ) {
double sum = 0 ; for ( int j = 0 ; j < m [ i ] . length ; j ++ ) sum = sum + m [ i ] [ j ] ; if ( sum != 1 ) return false ; } return true ; }
double m [ ] [ ] = { { 0 , 0 , 1 } , { 0.5 , 0 , 0.5 } , { 1 , 0 , 0 } } ;
if ( checkMarkov ( m ) ) System . out . println ( " ▁ yes ▁ " ) ; else System . out . println ( " ▁ no ▁ " ) ; } }
import java . io . * ; class GFG { static int N = 4 ;
static boolean isDiagonalMatrix ( int mat [ ] [ ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ )
if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ; return true ; }
public static void main ( String args [ ] ) { int mat [ ] [ ] = { { 4 , 0 , 0 , 0 } , { 0 , 7 , 0 , 0 } , { 0 , 0 , 5 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isDiagonalMatrix ( mat ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . io . * ; class GFG { static int N = 4 ;
static boolean isScalarMatrix ( int mat [ ] [ ] ) {
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ;
for ( int i = 0 ; i < N - 1 ; i ++ ) if ( mat [ i ] [ i ] != mat [ i + 1 ] [ i + 1 ] ) return false ; return true ; }
public static void main ( String args [ ] ) { int mat [ ] [ ] = { { 2 , 0 , 0 , 0 } , { 0 , 2 , 0 , 0 } , { 0 , 0 , 2 , 0 } , { 0 , 0 , 0 , 2 } } ;
if ( isScalarMatrix ( mat ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . util . Arrays ; class GFG { static final int MAX_SIZE = 10 ;
static void sortByRow ( int mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ )
Arrays . sort ( mat [ i ] ) ; }
static void transpose ( int mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
int temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ j ] [ i ] ; mat [ j ] [ i ] = temp ; } }
static void sortMatRowAndColWise ( int mat [ ] [ ] , int n ) {
sortByRow ( mat , n ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n ) ;
transpose ( mat , n ) ; }
static void printMat ( int mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 4 , 1 , 3 } , { 9 , 6 , 8 } , { 5 , 2 , 7 } } ; int n = 3 ; System . out . print ( "Original Matrix:NEW_LINE"); printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; System . out . print ( " Matrix After Sorting : "); printMat ( mat , n ) ; } }
static void doublyEven ( int n ) { int [ ] [ ] arr = new int [ n ] [ n ] ; int i , j ;
for ( i = 0 ; i < n ; i ++ ) for ( j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * i ) + j + 1 ;
for ( i = 0 ; i < n / 4 ; i ++ ) for ( j = 0 ; j < n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < n / 4 ; i ++ ) for ( j = 3 * ( n / 4 ) ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * n / 4 ; i < n ; i ++ ) for ( j = 0 ; j < n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * n / 4 ; i < n ; i ++ ) for ( j = 3 * n / 4 ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = n / 4 ; i < 3 * n / 4 ; i ++ ) for ( j = n / 4 ; j < 3 * n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) System . out . print ( arr [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int n = 8 ;
doublyEven ( n ) ; } }
static boolean isMagicSquare ( int mat [ ] [ ] ) {
int sum = 0 , sum2 = 0 ; for ( int i = 0 ; i < N ; i ++ ) sum = sum + mat [ i ] [ i ] ;
for ( int i = 0 ; i < N ; i ++ ) sum2 = sum2 + mat [ i ] [ N - 1 - i ] ; if ( sum != sum2 ) return false ;
for ( int i = 0 ; i < N ; i ++ ) { int rowSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) rowSum += mat [ i ] [ j ] ;
if ( rowSum != sum ) return false ; }
for ( int i = 0 ; i < N ; i ++ ) { int colSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) colSum += mat [ j ] [ i ] ;
if ( sum != colSum ) return false ; } return true ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 2 , 7 , 6 } , { 9 , 5 , 1 } , { 4 , 3 , 8 } } ; if ( isMagicSquare ( mat ) ) System . out . println ( " Magic ▁ Square " ) ; else System . out . println ( " Not ▁ a ▁ magic " + " ▁ Square " ) ; } }
static int subCount ( int arr [ ] , int n , int k ) {
int mod [ ] = new int [ k ] ; Arrays . fill ( mod , 0 ) ;
int cumSum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { cumSum += arr [ i ] ;
mod [ ( ( cumSum % k ) + k ) % k ] ++ ; }
int result = 0 ;
for ( int i = 0 ; i < k ; i ++ )
if ( mod [ i ] > 1 ) result += ( mod [ i ] * ( mod [ i ] - 1 ) ) / 2 ;
result += mod [ 0 ] ; return result ; }
static int countSubmatrix ( int mat [ ] [ ] , int n , int k ) {
int tot_count = 0 ; int left , right , i ; int temp [ ] = new int [ n ] ;
for ( left = 0 ; left < n ; left ++ ) {
Arrays . fill ( temp , 0 ) ;
for ( right = left ; right < n ; right ++ ) {
for ( i = 0 ; i < n ; ++ i ) temp [ i ] += mat [ i ] [ right ] ;
tot_count += subCount ( temp , n , k ) ; } }
return tot_count ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 5 , - 1 , 6 } , { - 2 , 3 , 8 } , { 7 , 4 , - 9 } } ; int n = 3 , k = 4 ; System . out . print ( " Count ▁ = ▁ " + countSubmatrix ( mat , n , k ) ) ; } }
import java . util . * ; import java . lang . * ; public class GfG { public static int find ( int n , int k ) { if ( n + 1 >= k ) return ( k - 1 ) ; else return ( 2 * n + 1 - k ) ; }
public static void main ( String argc [ ] ) { int n = 4 , k = 7 ; int freq = find ( n , k ) ; if ( freq < 0 ) System . out . print ( " ▁ element " + " not exist NEW_LINE "); else System . out . print ( " ▁ Frequency " + " ▁ of ▁ " + k + " ▁ is ▁ " + freq + "NEW_LINE"); } }
public static void ZigZag ( int rows , int columns , int numbers [ ] ) { int k = 0 ;
int [ ] [ ] arr = new int [ rows ] [ columns ] ; for ( int i = 0 ; i < rows ; i ++ ) {
if ( i % 2 == 0 ) {
for ( int j = 0 ; j < columns && numbers [ k ] > 0 ; j ++ ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } }
else {
for ( int j = columns - 1 ; j >= 0 && numbers [ k ] > 0 ; j -- ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } } }
for ( int i = 0 ; i < rows ; i ++ ) { for ( int j = 0 ; j < columns ; j ++ ) System . out . print ( arr [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String argc [ ] ) { int rows = 4 ; int columns = 5 ; int [ ] Numbers = new int [ ] { 3 , 4 , 2 , 2 , 3 , 1 , 5 } ; ZigZag ( rows , columns , Numbers ) ; } }
static int numberofPosition ( int n , int k , int x , int y , int obstPosx [ ] , int obstPosy [ ] ) {
int d11 , d12 , d21 , d22 , r1 , r2 , c1 , c2 ;
d11 = Math . min ( x - 1 , y - 1 ) ; d12 = Math . min ( n - x , n - y ) ; d21 = Math . min ( n - x , y - 1 ) ; d22 = Math . min ( x - 1 , n - y ) ; r1 = y - 1 ; r2 = n - y ; c1 = x - 1 ; c2 = n - x ;
for ( int i = 0 ; i < k ; i ++ ) { if ( x > obstPosx [ i ] && y > obstPosy [ i ] && x - obstPosx [ i ] == y - obstPosy [ i ] ) d11 = Math . min ( d11 , x - obstPosx [ i ] - 1 ) ; if ( obstPosx [ i ] > x && obstPosy [ i ] > y && obstPosx [ i ] - x == obstPosy [ i ] - y ) d12 = Math . min ( d12 , obstPosx [ i ] - x - 1 ) ; if ( obstPosx [ i ] > x && y > obstPosy [ i ] && obstPosx [ i ] - x == y - obstPosy [ i ] ) d21 = Math . min ( d21 , obstPosx [ i ] - x - 1 ) ; if ( x > obstPosx [ i ] && obstPosy [ i ] > y && x - obstPosx [ i ] == obstPosy [ i ] - y ) d22 = Math . min ( d22 , x - obstPosx [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] < y ) r1 = Math . min ( r1 , y - obstPosy [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] > y ) r2 = Math . min ( r2 , obstPosy [ i ] - y - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] < x ) c1 = Math . min ( c1 , x - obstPosx [ i ] - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] > x ) c2 = Math . min ( c2 , obstPosx [ i ] - x - 1 ) ; } return d11 + d12 + d21 + d22 + r1 + r2 + c1 + c2 ; }
int n = 8 ;
int k = 1 ;
int Qposx = 4 ;
int Qposy = 4 ;
int obstPosx [ ] = { 3 } ;
int obstPosy [ ] = { 5 } ; System . out . println ( numberofPosition ( n , k , Qposx , Qposy , obstPosx , obstPosy ) ) ; } }
class GFG { static final int n = 5 ;
static int FindMaxProduct ( int arr [ ] [ ] , int n ) { int max = 0 , result ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = 0 ; j < n ; j ++ ) {
if ( ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i ] [ j - 1 ] * arr [ i ] [ j - 2 ] * arr [ i ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j ] * arr [ i - 2 ] [ j ] * arr [ i - 3 ] [ j ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j - 1 ] * arr [ i - 2 ] [ j - 2 ] * arr [ i - 3 ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 1 ) <= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j + 1 ] * arr [ i - 2 ] [ j + 2 ] * arr [ i - 3 ] [ j + 3 ] ; if ( max < result ) max = result ; } } } return max ; }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 1 } , { 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 1 , 0 } , { 9 , 6 , 4 , 2 , 3 } } ; System . out . print ( FindMaxProduct ( arr , n ) ) ; } }
import java . util . * ; class GFG {
static int minimumflip ( int mat [ ] [ ] , int n ) { int transpose [ ] [ ] = new int [ n ] [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) transpose [ i ] [ j ] = mat [ j ] [ i ] ;
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( transpose [ i ] [ j ] != mat [ i ] [ j ] ) flip ++ ; return flip / 2 ; }
public static void main ( String [ ] args ) { int n = 3 ; int mat [ ] [ ] = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; System . out . println ( minimumflip ( mat , n ) ) ; } }
import java . util . * ; class GFG {
static int minimumflip ( int mat [ ] [ ] , int n ) {
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) flip ++ ; return flip ; }
public static void main ( String [ ] args ) { int n = 3 ; int mat [ ] [ ] = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; System . out . println ( minimumflip ( mat , n ) ) ; } }
import java . io . * ; class Lower_triangular { int N = 4 ;
boolean isLowerTriangularMatrix ( int mat [ ] [ ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
public static void main ( String args [ ] ) { Lower_triangular ob = new Lower_triangular ( ) ; int mat [ ] [ ] = { { 1 , 0 , 0 , 0 } , { 1 , 4 , 0 , 0 } , { 4 , 6 , 2 , 0 } , { 0 , 4 , 7 , 6 } } ;
if ( ob . isLowerTriangularMatrix ( mat ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . util . * ; import java . lang . * ; public class GfG { private static final int N = 4 ;
public static Boolean isUpperTriangularMatrix ( int mat [ ] [ ] ) { for ( int i = 1 ; i < N ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
public static void main ( String argc [ ] ) { int [ ] [ ] mat = { { 1 , 3 , 5 , 3 } , { 0 , 4 , 6 , 2 } , { 0 , 0 , 2 , 5 } , { 0 , 0 , 0 , 6 } } ; if ( isUpperTriangularMatrix ( mat ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
class GFG { static final int MAX = 100 ;
static void freq ( int ar [ ] [ ] , int m , int n ) { int even = 0 , odd = 0 ; for ( int i = 0 ; i < m ; ++ i ) { for ( int j = 0 ; j < n ; ++ j ) {
if ( ( ar [ i ] [ j ] % 2 ) == 0 ) ++ even ; else ++ odd ; } }
System . out . print ( " ▁ Frequency ▁ of ▁ odd ▁ number ▁ = " + odd + " NEW_LINE"); System . out . print ( " ▁ Frequency ▁ of ▁ even ▁ number ▁ = ▁ " + even + " NEW_LINE"); }
public static void main ( String [ ] args ) { int m = 3 , n = 3 ; int array [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; freq ( array , m , n ) ; } }
import java . util . Arrays ; public class GFG { static int MAX = 100 ;
static boolean HalfDiagonalSums ( int mat [ ] [ ] , int n ) {
int diag1_left = 0 , diag1_right = 0 ; int diag2_left = 0 , diag2_right = 0 ; for ( int i = 0 , j = n - 1 ; i < n ; i ++ , j -- ) { if ( i < n / 2 ) { diag1_left += mat [ i ] [ i ] ; diag2_left += mat [ j ] [ i ] ; } else if ( i > n / 2 ) { diag1_right += mat [ i ] [ i ] ; diag2_right += mat [ j ] [ i ] ; } } return ( diag1_left == diag2_right && diag2_right == diag2_left && diag1_right == diag2_left && diag2_right == mat [ n / 2 ] [ n / 2 ] ) ; }
public static void main ( String args [ ] ) { int a [ ] [ ] = { { 2 , 9 , 1 , 4 , - 2 } , { 6 , 7 , 2 , 11 , 4 } , { 4 , 2 , 9 , 2 , 4 } , { 1 , 9 , 2 , 4 , 4 } , { 0 , 2 , 4 , 2 , 5 } } ; System . out . print ( HalfDiagonalSums ( a , 5 ) ? " Yes " : " No " ) ; } }
class GFG { int MAX = 100 ; static boolean isIdentity ( int mat [ ] [ ] , int N ) { for ( int row = 0 ; row < N ; row ++ ) { for ( int col = 0 ; col < N ; col ++ ) { if ( row == col && mat [ row ] [ col ] != 1 ) return false ; else if ( row != col && mat [ row ] [ col ] != 0 ) return false ; } } return true ; }
public static void main ( String args [ ] ) { int N = 4 ; int mat [ ] [ ] = { { 1 , 0 , 0 , 0 } , { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isIdentity ( mat , N ) ) System . out . println ( " Yes ▁ " ) ; else System . out . println ( " No ▁ " ) ; } }
import java . io . * ; class Example { final static long mod = 100000007 ;
static long modPower ( long a , long t , long mod ) { long now = a , ret = 1 ;
while ( t > 0 ) { if ( t % 2 == 1 ) ret = now * ( ret % mod ) ; now = now * ( now % mod ) ; t >>= 1 ; } return ret ; }
static long countWays ( int n , int m , int k ) {
if ( n == 1 m == 1 ) return 1 ;
else if ( ( n + m ) % 2 == 1 && k == - 1 ) return 0 ;
return ( modPower ( modPower ( ( long ) 2 , n - 1 , mod ) , m - 1 , mod ) % mod ) ; }
public static void main ( String args [ ] ) throws IOException { int n = 2 , m = 7 , k = 1 ; System . out . println ( countWays ( n , m , k ) ) ; } }
import java . io . * ; class GFG { static int MAX = 100 ; static void imageSwap ( int mat [ ] [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j <= i ; j ++ ) mat [ i ] [ j ] = mat [ i ] [ j ] + mat [ j ] [ i ] - ( mat [ j ] [ i ] = mat [ i ] [ j ] ) ; }
static void printMatrix ( int mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; int n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ; } }
static final int m = 3 ;
static final int n = 2 ;
static long countSets ( int a [ ] [ ] ) {
long res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < m ; j ++ ) { if ( a [ i ] [ j ] == 1 ) u ++ ; else v ++ ; } res += Math . pow ( 2 , u ) - 1 + Math . pow ( 2 , v ) - 1 ; }
for ( int i = 0 ; i < m ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < n ; j ++ ) { if ( a [ j ] [ i ] == 1 ) u ++ ; else v ++ ; } res += Math . pow ( 2 , u ) - 1 + Math . pow ( 2 , v ) - 1 ; }
return res - ( n * m ) ; }
public static void main ( String [ ] args ) { int a [ ] [ ] = { { 1 , 0 , 1 } , { 0 , 1 , 0 } } ; System . out . print ( countSets ( a ) ) ; } }
static void fill0X ( int m , int n ) {
int i , k = 0 , l = 0 ;
int r = m , c = n ;
char x = ' X ' ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) a [ k ] [ i ] = x ; k ++ ;
for ( i = k ; i < m ; ++ i ) a [ i ] [ n - 1 ] = x ; n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = x ; m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) a [ i ] [ l ] = x ; l ++ ; }
x = ( x == '0' ) ? ' X ' : '0' ; }
for ( i = 0 ; i < r ; i ++ ) { for ( int j = 0 ; j < c ; j ++ ) System . out . print ( a [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { System . out . println ( " Output ▁ for ▁ m ▁ = ▁ 5 , ▁ n ▁ = ▁ 6" ) ; fill0X ( 5 , 6 ) ; System . out . println ( " Output ▁ for ▁ m ▁ = ▁ 4 , ▁ n ▁ = ▁ 4" ) ; fill0X ( 4 , 4 ) ; System . out . println ( " Output ▁ for ▁ m ▁ = ▁ 3 , ▁ n ▁ = ▁ 4" ) ; fill0X ( 3 , 4 ) ; } }
public static int calculateEnergy ( int mat [ ] [ ] , int n ) { int i_des , j_des , q ; int tot_energy = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
q = mat [ i ] [ j ] / n ;
i_des = q ; j_des = mat [ i ] [ j ] - ( n * q ) ;
tot_energy += Math . abs ( i_des - i ) + Math . abs ( j_des - j ) ; } }
return tot_energy ; }
public static void main ( String argc [ ] ) { int [ ] [ ] mat = new int [ ] [ ] { { 4 , 7 , 0 , 3 } , { 8 , 5 , 6 , 1 } , { 9 , 11 , 10 , 2 } , { 15 , 13 , 14 , 12 } } ; int n = 4 ; System . out . println ( " Total ▁ energy ▁ required ▁ = ▁ " + calculateEnergy ( mat , n ) + " ▁ units " ) ; } }
class GFG { static final int MAX = 100 ;
static boolean isUnique ( int mat [ ] [ ] , int i , int j , int n , int m ) {
int sumrow = 0 ; for ( int k = 0 ; k < m ; k ++ ) { sumrow += mat [ i ] [ k ] ; if ( sumrow > 1 ) return false ; }
int sumcol = 0 ; for ( int k = 0 ; k < n ; k ++ ) { sumcol += mat [ k ] [ j ] ; if ( sumcol > 1 ) return false ; } return true ; } static int countUnique ( int mat [ ] [ ] , int n , int m ) { int uniquecount = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] != 0 && isUnique ( mat , i , j , n , m ) ) uniquecount ++ ; return uniquecount ; }
static public void main ( String [ ] args ) { int mat [ ] [ ] = { { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 1 , 0 , 0 , 1 } } ; System . out . print ( countUnique ( mat , 3 , 4 ) ) ; } }
import java . io . * ; class GFG { static int MAX = 100 ; static boolean isSparse ( int array [ ] [ ] , int m , int n ) { int counter = 0 ;
for ( int i = 0 ; i < m ; ++ i ) for ( int j = 0 ; j < n ; ++ j ) if ( array [ i ] [ j ] == 0 ) ++ counter ; return ( counter > ( ( m * n ) / 2 ) ) ; }
public static void main ( String args [ ] ) { int array [ ] [ ] = { { 1 , 0 , 3 } , { 0 , 0 , 4 } , { 6 , 0 , 0 } } ; int m = 3 , n = 3 ; if ( isSparse ( array , m , n ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . io . * ; class GFG { int MAX = 100 ;
static int countCommon ( int mat [ ] [ ] , int n ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( mat [ i ] [ i ] == mat [ i ] [ n - i - 1 ] ) res ++ ; return res ; }
public static void main ( String args [ ] ) throws IOException { int mat [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; System . out . println ( countCommon ( mat , 3 ) ) ; } }
static boolean areSumSame ( int a [ ] [ ] , int n , int m ) { int sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum1 = 0 ; sum2 = 0 ; for ( int j = 0 ; j < m ; j ++ ) { sum1 += a [ i ] [ j ] ; sum2 += a [ j ] [ i ] ; } if ( sum1 == sum2 ) return true ; } return false ; }
int n = 4 ;
int m = 4 ; int M [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 9 , 5 , 3 , 1 } , { 0 , 3 , 5 , 6 } , { 0 , 4 , 5 , 6 } } ; if ( areSumSame ( M , n , m ) == true ) System . out . print ( "1NEW_LINE"); else System . out . print ( "0NEW_LINE"); } }
class GFG { static final int N = 4 ;
static void findMax ( int arr [ ] [ ] ) { int row = 0 , i , j ; for ( i = 0 , j = N - 1 ; i < N ; i ++ ) {
while ( j >= 0 && arr [ i ] [ j ] == 1 ) { row = i ; j -- ; } } System . out . print ( " Row ▁ number ▁ = ▁ " + ( row + 1 ) ) ; System . out . print ( " , ▁ MaxCount ▁ = ▁ " + ( N - 1 - j ) ) ; }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 0 } , { 0 , 1 , 1 , 1 } } ; findMax ( arr ) ; } }
static void transpose ( int mat [ ] [ ] , int tr [ ] [ ] , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) tr [ i ] [ j ] = mat [ j ] [ i ] ; }
static boolean isSymmetric ( int mat [ ] [ ] , int N ) { int tr [ ] [ ] = new int [ N ] [ MAX ] ; transpose ( mat , tr , N ) ; for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != tr [ i ] [ j ] ) return false ; return true ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . io . * ; class GFG { static int MAX = 100 ;
static boolean isSymmetric ( int mat [ ] [ ] , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) return false ; return true ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " NO " ) ; } }
public class Main { public static final int n = 4 ; public static final int m = 4 ;
static int findPossibleMoves ( int mat [ ] [ ] , int p , int q ) {
int X [ ] = { 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 } ; int Y [ ] = { 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 } ; int count = 0 ;
for ( int i = 0 ; i < 8 ; i ++ ) {
int x = p + X [ i ] ; int y = q + Y [ i ] ;
if ( x >= 0 && y >= 0 && x < n && y < m && mat [ x ] [ y ] == 0 ) count ++ ; }
return count ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 0 , 1 , 0 } , { 0 , 1 , 1 , 1 } , { 1 , 1 , 0 , 1 } , { 0 , 1 , 1 , 1 } } ; int p = 2 , q = 2 ; System . out . println ( findPossibleMoves ( mat , p , q ) ) ; } }
import java . io . * ; public class GFG { static void printDiagonalSums ( int [ ] [ ] mat , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) principal += mat [ i ] [ j ] ;
if ( ( i + j ) == ( n - 1 ) ) secondary += mat [ i ] [ j ] ; } } System . out . println ( " Principal ▁ Diagonal : " + principal ) ; System . out . println ( " Secondary ▁ Diagonal : " + secondary ) ; }
static public void main ( String [ ] args ) { int [ ] [ ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; } }
import java . io . * ; public class GFG { static void printDiagonalSums ( int [ ] [ ] mat , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { principal += mat [ i ] [ i ] ; secondary += mat [ i ] [ n - i - 1 ] ; } System . out . println ( " Principal ▁ Diagonal : " + principal ) ; System . out . println ( " Secondary ▁ Diagonal : " + secondary ) ; }
static public void main ( String [ ] args ) { int [ ] [ ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; } }
class GFG { public static void printBoundary ( int a [ ] [ ] , int m , int n ) { for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( i == 0 ) System . out . print ( a [ i ] [ j ] + " ▁ " ) ; else if ( i == m - 1 ) System . out . print ( a [ i ] [ j ] + " ▁ " ) ; else if ( j == 0 ) System . out . print ( a [ i ] [ j ] + " ▁ " ) ; else if ( j == n - 1 ) System . out . print ( a [ i ] [ j ] + " ▁ " ) ; else System . out . print ( " ▁ " ) ; } System . out . println ( " " ) ; } }
public static void main ( String [ ] args ) { int a [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printBoundary ( a , 4 , 4 ) ; } }
class GFG { public static long getBoundarySum ( int a [ ] [ ] , int m , int n ) { long sum = 0 ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( i == 0 ) sum += a [ i ] [ j ] ; else if ( i == m - 1 ) sum += a [ i ] [ j ] ; else if ( j == 0 ) sum += a [ i ] [ j ] ; else if ( j == n - 1 ) sum += a [ i ] [ j ] ; } } return sum ; }
public static void main ( String [ ] args ) { int a [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; long sum = getBoundarySum ( a , 4 , 4 ) ; System . out . println ( " Sum ▁ of ▁ boundary ▁ elements " + " ▁ is ▁ " + sum ) ; } }
import java . io . * ; class GFG { static void printSpiral ( int [ ] [ ] mat , int r , int c ) { int i , a = 0 , b = 2 ; int low_row = ( 0 > a ) ? 0 : a ; int low_column = ( 0 > b ) ? 0 : b - 1 ; int high_row = ( ( a + 1 ) >= r ) ? r - 1 : a + 1 ; int high_column = ( ( b + 1 ) >= c ) ? c - 1 : b + 1 ; while ( ( low_row > 0 - r && low_column > 0 - c ) ) { for ( i = low_column + 1 ; i <= high_column && i < c && low_row >= 0 ; ++ i ) System . out . print ( mat [ low_row ] [ i ] + " ▁ " ) ; low_row -= 1 ; for ( i = low_row + 2 ; i <= high_row && i < r && high_column < c ; ++ i ) System . out . print ( mat [ i ] [ high_column ] + " ▁ " ) ; high_column += 1 ; for ( i = high_column - 2 ; i >= low_column && i >= 0 && high_row < r ; -- i ) System . out . print ( mat [ high_row ] [ i ] + " ▁ " ) ; high_row += 1 ; for ( i = high_row - 2 ; i > low_row && i >= 0 && low_column >= 0 ; -- i ) System . out . print ( mat [ i ] [ low_column ] + " ▁ " ) ; low_column -= 1 ; } System . out . println ( ) ; }
static public void main ( String [ ] args ) { int [ ] [ ] mat = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int r = 3 , c = 3 ;
printSpiral ( mat , r , c ) ; } }
class GFG { public static int difference ( int arr [ ] [ ] , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) d1 += arr [ i ] [ j ] ;
if ( i == n - j - 1 ) d2 += arr [ i ] [ j ] ; } }
return Math . abs ( d1 - d2 ) ; }
public static void main ( String [ ] args ) { int n = 3 ; int arr [ ] [ ] = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , - 12 } } ; System . out . print ( difference ( arr , n ) ) ; } }
class GFG { public static int difference ( int arr [ ] [ ] , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { d1 += arr [ i ] [ i ] ; d2 += arr [ i ] [ n - i - 1 ] ; }
return Math . abs ( d1 - d2 ) ; }
public static void main ( String [ ] args ) { int n = 3 ; int arr [ ] [ ] = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , - 12 } } ; System . out . print ( difference ( arr , n ) ) ; } }
static void spiralFill ( int m , int n , int a [ ] [ ] ) {
int val = 1 ;
int k = 0 , l = 0 ; while ( k < m && l < n ) {
for ( int i = l ; i < n ; ++ i ) { a [ k ] [ i ] = val ++ ; } k ++ ;
for ( int i = k ; i < m ; ++ i ) { a [ i ] [ n - 1 ] = val ++ ; } n -- ;
if ( k < m ) { for ( int i = n - 1 ; i >= l ; -- i ) { a [ m - 1 ] [ i ] = val ++ ; } m -- ; }
if ( l < n ) { for ( int i = m - 1 ; i >= k ; -- i ) { a [ i ] [ l ] = val ++ ; } l ++ ; } } }
public static void main ( String [ ] args ) { int m = 4 , n = 4 ; int a [ ] [ ] = new int [ MAX ] [ MAX ] ; spiralFill ( m , n , a ) ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { System . out . print ( a [ i ] [ j ] + " ▁ " ) ; } System . out . println ( " " ) ; } } }
class GFG { static final int MAX = 100 ;
static void maxMin ( int arr [ ] [ ] , int n ) { int min = + 2147483647 ; int max = - 2147483648 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j <= n / 2 ; j ++ ) {
if ( arr [ i ] [ j ] > arr [ i ] [ n - j - 1 ] ) { if ( min > arr [ i ] [ n - j - 1 ] ) min = arr [ i ] [ n - j - 1 ] ; if ( max < arr [ i ] [ j ] ) max = arr [ i ] [ j ] ; } else { if ( min > arr [ i ] [ j ] ) min = arr [ i ] [ j ] ; if ( max < arr [ i ] [ n - j - 1 ] ) max = arr [ i ] [ n - j - 1 ] ; } } } System . out . print ( " Maximum ▁ = ▁ " + max + " , ▁ Minimum ▁ = ▁ " + min ) ; }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 5 , 9 , 11 } , { 25 , 0 , 14 } , { 21 , 6 , 4 } } ; maxMin ( arr , 3 ) ; } }
static int MAX = 100 ;
static int findNormal ( int mat [ ] [ ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] * mat [ i ] [ j ] ; return ( int ) Math . sqrt ( sum ) ; }
static int findTrace ( int mat [ ] [ ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += mat [ i ] [ i ] ; return sum ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; System . out . println ( " Trace ▁ of ▁ Matrix ▁ = ▁ " + findTrace ( mat , 5 ) ) ; System . out . println ( " Normal ▁ of ▁ Matrix ▁ = ▁ " + findNormal ( mat , 5 ) ) ; } }
class GFG { static final int N = 5 ; static final int M = 5 ;
static int minOperation ( boolean arr [ ] [ ] ) { int ans = 0 ; for ( int i = N - 1 ; i >= 0 ; i -- ) { for ( int j = M - 1 ; j >= 0 ; j -- ) {
if ( arr [ i ] [ j ] == false ) {
ans ++ ;
for ( int k = 0 ; k <= i ; k ++ ) { for ( int h = 0 ; h <= j ; h ++ ) {
if ( arr [ k ] [ h ] == true ) { arr [ k ] [ h ] = false ; } else { arr [ k ] [ h ] = true ; } } } } } } return ans ; }
public static void main ( String [ ] args ) { boolean mat [ ] [ ] = { { false , false , true , true , true } , { false , false , false , true , true } , { false , false , false , true , true } , { true , true , true , true , true } , { true , true , true , true , true } } ; System . out . println ( minOperation ( mat ) ) ; } }
static int findSum ( int n ) { int ans = 0 , temp = 0 , num ;
for ( int i = 1 ; i <= n && temp < n ; i ++ ) {
temp = i - 1 ;
num = 1 ; while ( temp < n ) { if ( temp + i <= n ) ans += ( i * num ) ; else ans += ( ( n - temp ) * num ) ; temp += i ; num ++ ; } } return ans ; }
public static void main ( String [ ] args ) { int N = 2 ; System . out . println ( findSum ( N ) ) ; } }
import java . io . * ; class GFG { static int countOps ( int A [ ] [ ] , int B [ ] [ ] , int m , int n ) {
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) A [ i ] [ j ] -= B [ i ] [ j ] ;
for ( int i = 1 ; i < n ; i ++ ) for ( int j = 1 ; j < m ; j ++ ) if ( A [ i ] [ j ] - A [ i ] [ 0 ] - A [ 0 ] [ j ] + A [ 0 ] [ 0 ] != 0 ) return - 1 ;
int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) result += Math . abs ( A [ i ] [ 0 ] ) ; for ( int j = 0 ; j < m ; j ++ ) result += Math . abs ( A [ 0 ] [ j ] - A [ 0 ] [ 0 ] ) ; return ( result ) ; }
public static void main ( String [ ] args ) { int A [ ] [ ] = { { 1 , 1 , 1 } , { 1 , 1 , 1 } , { 1 , 1 , 1 } } ; int B [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; System . out . println ( countOps ( A , B , 3 , 3 ) ) ; } }
static void printCoils ( int n ) {
int m = 8 * n * n ;
int coil1 [ ] = new int [ m ] ;
coil1 [ 0 ] = 8 * n * n + 2 * n ; int curr = coil1 [ 0 ] ; int nflg = 1 , step = 2 ;
int index = 1 ; while ( index < m ) {
for ( int i = 0 ; i < step ; i ++ ) {
curr = coil1 [ index ++ ] = ( curr - 4 * n * nflg ) ; if ( index >= m ) break ; } if ( index >= m ) break ;
for ( int i = 0 ; i < step ; i ++ ) { curr = coil1 [ index ++ ] = curr + nflg ; if ( index >= m ) break ; } nflg = nflg * ( - 1 ) ; step += 2 ; }
int coil2 [ ] = new int [ m ] ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) coil2 [ i ] = 16 * n * n + 1 - coil1 [ i ] ;
System . out . print ( " Coil ▁ 1 ▁ : ▁ " ) ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) System . out . print ( coil1 [ i ] + " ▁ " ) ; System . out . print ( " Coil 2 : "); for ( int i = 0 ; i < 8 * n * n ; i ++ ) System . out . print ( coil2 [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int n = 1 ; printCoils ( n ) ; } }
static int findSum ( int n ) {
int [ ] [ ] arr = new int [ n ] [ n ] ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = Math . abs ( i - j ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += arr [ i ] [ j ] ; return sum ; }
static public void main ( String [ ] args ) { int n = 3 ; System . out . println ( findSum ( n ) ) ; } }
static int findSum ( int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += i * ( n - i ) ; return 2 * sum ; }
static public void main ( String [ ] args ) { int n = 3 ; System . out . println ( findSum ( n ) ) ; } }
static int findSum ( int n ) { n -- ; int sum = 0 ; sum += ( n * ( n + 1 ) ) / 2 ; sum += ( n * ( n + 1 ) * ( 2 * n + 1 ) ) / 6 ; return sum ; }
static public void main ( String [ ] args ) { int n = 3 ; System . out . println ( findSum ( n ) ) ; } }
import java . io . * ; public class GFG { static void checkHV ( int [ ] [ ] arr , int N , int M ) {
boolean horizontal = true ; boolean vertical = true ;
for ( int i = 0 , k = N - 1 ; i < N / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < M ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { horizontal = false ; break ; } } }
for ( int i = 0 , k = M - 1 ; i < M / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < N ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { horizontal = false ; break ; } } } if ( ! horizontal && ! vertical ) System . out . println ( " NO " ) ; else if ( horizontal && ! vertical ) System . out . println ( " HORIZONTAL " ) ; else if ( vertical && ! horizontal ) System . out . println ( " VERTICAL " ) ; else System . out . println ( " BOTH " ) ; }
static public void main ( String [ ] args ) { int [ ] [ ] mat = { { 1 , 0 , 1 } , { 0 , 0 , 0 } , { 1 , 0 , 1 } } ; checkHV ( mat , 3 , 3 ) ; } }
static int maxDet ( int n ) { return ( 2 * n * n * n ) ; }
void resMatrix ( int n ) { for ( int i = 0 ; i < 3 ; i ++ ) { for ( int j = 0 ; j < 3 ; j ++ ) {
if ( i == 0 && j == 2 ) System . out . print ( "0 ▁ " ) ; else if ( i == 1 && j == 0 ) System . out . print ( "0 ▁ " ) ; else if ( i == 2 && j == 1 ) System . out . print ( "0 ▁ " ) ;
else System . out . print ( n + " ▁ " ) ; } System . out . println ( " " ) ; } }
static public void main ( String [ ] args ) { int n = 15 ; GFG geeks = new GFG ( ) ; System . out . println ( " Maximum ▁ Determinant ▁ = ▁ " + maxDet ( n ) ) ; System . out . println ( " Resultant ▁ Matrix ▁ : " ) ; geeks . resMatrix ( n ) ; } }
static int spiralDiaSum ( int n ) { if ( n == 1 ) return 1 ;
return ( 4 * n * n - 6 * n + 6 + spiralDiaSum ( n - 2 ) ) ; }
public static void main ( String [ ] args ) { int n = 7 ; System . out . print ( spiralDiaSum ( n ) ) ; } }
class GFG { static final int R = 3 ; static final int C = 5 ;
static int numofneighbour ( int mat [ ] [ ] , int i , int j ) { int count = 0 ;
if ( i > 0 && mat [ i - 1 ] [ j ] == 1 ) count ++ ;
if ( j > 0 && mat [ i ] [ j - 1 ] == 1 ) count ++ ;
if ( i < R - 1 && mat [ i + 1 ] [ j ] == 1 ) count ++ ;
if ( j < C - 1 && mat [ i ] [ j + 1 ] == 1 ) count ++ ; return count ; }
static int findperimeter ( int mat [ ] [ ] ) { int perimeter = 0 ;
for ( int i = 0 ; i < R ; i ++ ) for ( int j = 0 ; j < C ; j ++ ) if ( mat [ i ] [ j ] == 1 ) perimeter += ( 4 - numofneighbour ( mat , i , j ) ) ; return perimeter ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 0 , 1 , 0 , 0 , 0 } , { 1 , 1 , 1 , 0 , 0 } , { 1 , 0 , 0 , 0 , 0 } } ; System . out . println ( findperimeter ( mat ) ) ; } }
class GFG { static final int MAX = 100 ; static void printMatrixDiagonal ( int mat [ ] [ ] , int n ) {
int i = 0 , j = 0 ;
boolean isUp = true ;
for ( int k = 0 ; k < n * n ; ) {
if ( isUp ) { for ( ; i >= 0 && j < n ; j ++ , i -- ) { System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; k ++ ; }
if ( i < 0 && j <= n - 1 ) i = 0 ; if ( j == n ) { i = i + 2 ; j -- ; } }
else { for ( ; j >= 0 && i < n ; i ++ , j -- ) { System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; k ++ ; }
if ( j < 0 && i <= n - 1 ) j = 0 ; if ( i == n ) { j = j + 2 ; i -- ; } }
isUp = ! isUp ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int n = 3 ; printMatrixDiagonal ( mat , n ) ; } }
class GFG { static final int MAX = 100 ;
static int maxRowDiff ( int mat [ ] [ ] , int m , int n ) {
int rowSum [ ] = new int [ m ] ;
for ( int i = 0 ; i < m ; i ++ ) { int sum = 0 ; for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] ; rowSum [ i ] = sum ; }
int max_diff = rowSum [ 1 ] - rowSum [ 0 ] ; int min_element = rowSum [ 0 ] ; for ( int i = 1 ; i < m ; i ++ ) {
if ( rowSum [ i ] - min_element > max_diff ) max_diff = rowSum [ i ] - min_element ;
if ( rowSum [ i ] < min_element ) min_element = rowSum [ i ] ; } return max_diff ; }
public static void main ( String [ ] args ) { int m = 5 , n = 4 ; int mat [ ] [ ] = { { - 1 , 2 , 3 , 4 } , { 5 , 3 , - 2 , 1 } , { 6 , 7 , 2 , - 3 } , { 2 , 9 , 1 , 4 } , { 2 , 1 , - 2 , 0 } } ; System . out . print ( maxRowDiff ( mat , m , n ) ) ; } }
class GFG { static int MAX = 100 ;
static int sortedCount ( int mat [ ] [ ] , int r , int c ) {
int result = 0 ;
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = 0 ; j < c - 1 ; j ++ ) if ( mat [ i ] [ j + 1 ] <= mat [ i ] [ j ] ) break ;
if ( j == c - 1 ) result ++ ; }
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = c - 1 ; j > 0 ; j -- ) if ( mat [ i ] [ j - 1 ] <= mat [ i ] [ j ] ) break ;
if ( c > 1 && j == 0 ) result ++ ; } return result ; }
public static void main ( String arg [ ] ) { int m = 4 , n = 5 ; int mat [ ] [ ] = { { 1 , 2 , 3 , 4 , 5 } , { 4 , 3 , 1 , 2 , 6 } , { 8 , 7 , 6 , 5 , 4 } , { 5 , 7 , 8 , 9 , 10 } } ; System . out . print ( sortedCount ( mat , m , n ) ) ; } }
class GFG { static final int MAX = 1000 ;
static int maxXOR ( int mat [ ] [ ] , int N ) {
int r_xor , c_xor ; int max_xor = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { r_xor = 0 ; c_xor = 0 ; for ( int j = 0 ; j < N ; j ++ ) {
r_xor = r_xor ^ mat [ i ] [ j ] ;
c_xor = c_xor ^ mat [ j ] [ i ] ; }
if ( max_xor < Math . max ( r_xor , c_xor ) ) max_xor = Math . max ( r_xor , c_xor ) ; }
return max_xor ; }
public static void main ( String [ ] args ) { int N = 3 ; int mat [ ] [ ] = { { 1 , 5 , 4 } , { 3 , 7 , 2 } , { 5 , 9 , 10 } } ; System . out . print ( " maximum ▁ XOR ▁ value ▁ : ▁ " + maxXOR ( mat , N ) ) ; } }
static void direction ( int R , int C ) { if ( R != C && R % 2 == 0 && C % 2 != 0 && R < C ) { System . out . println ( " Left " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R > C ) { System . out . println ( " Up " ) ; return ; } if ( R == C && R % 2 != 0 && C % 2 != 0 ) { System . out . println ( " Right " ) ; return ; } if ( R == C && R % 2 == 0 && C % 2 == 0 ) { System . out . println ( " Left " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R < C ) { System . out . println ( " Right " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R > C ) { System . out . println ( " Down " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R < C ) { System . out . println ( " Left " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R > C ) { System . out . println ( " Up " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 != 0 && R > C ) { System . out . println ( " Down " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R < C ) { System . out . println ( " Right " ) ; return ; } }
public static void main ( String [ ] args ) { int R = 3 , C = 1 ; direction ( R , C ) ; } }
static boolean checkDiagonal ( int mat [ ] [ ] , int i , int j ) { int res = mat [ i ] [ j ] ; while ( ++ i < N && ++ j < M ) {
if ( mat [ i ] [ j ] != res ) return false ; }
return true ; }
static boolean isToepliz ( int mat [ ] [ ] ) {
for ( int i = 0 ; i < M ; i ++ ) {
if ( ! checkDiagonal ( mat , 0 , i ) ) return false ; }
for ( int i = 1 ; i < N ; i ++ ) {
if ( ! checkDiagonal ( mat , i , 0 ) ) return false ; }
return true ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 6 , 7 , 8 , 9 } , { 4 , 6 , 7 , 8 } , { 1 , 4 , 6 , 7 } , { 0 , 1 , 4 , 6 } , { 2 , 0 , 1 , 4 } } ;
if ( isToepliz ( mat ) ) System . out . println ( " Matrix ▁ is ▁ a ▁ Toepliz ▁ " ) ; else System . out . println ( " Matrix ▁ is ▁ not ▁ a ▁ Toepliz ▁ " ) ; } }
import java . io . * ; class GFG { public static int N = 5 ;
static int countZeroes ( int mat [ ] [ ] ) {
int row = N - 1 , col = 0 ;
int count = 0 ; while ( col < N ) {
while ( mat [ row ] [ col ] > 0 )
if ( -- row < 0 ) return count ;
count += ( row + 1 ) ;
col ++ ; } return count ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 1 , 1 } , { 0 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } } ; System . out . println ( countZeroes ( mat ) ) ; } }
import java . util . * ; import java . lang . * ; import java . io . * ; class GFG { static int countNegative ( int M [ ] [ ] , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < m ; j ++ ) { if ( M [ i ] [ j ] < 0 ) count += 1 ;
else break ; } } return count ; }
public static void main ( String [ ] args ) { int M [ ] [ ] = { { - 3 , - 2 , - 1 , 1 } , { - 2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; System . out . println ( countNegative ( M , 3 , 4 ) ) ; } }
static int countNegative ( int M [ ] [ ] , int n , int m ) {
int count = 0 ;
int i = 0 ; int j = m - 1 ;
while ( j >= 0 && i < n ) { if ( M [ i ] [ j ] < 0 ) {
count += j + 1 ;
i += 1 ; }
else j -= 1 ; } return count ; }
public static void main ( String [ ] args ) { int M [ ] [ ] = { { - 3 , - 2 , - 1 , 1 } , { - 2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; System . out . println ( countNegative ( M , 3 , 4 ) ) ; } }
static int N = 10 ;
static int findLargestPlus ( int mat [ ] [ ] ) {
int left [ ] [ ] = new int [ N ] [ N ] ; int right [ ] [ ] = new int [ N ] [ N ] ; int top [ ] [ ] = new int [ N ] [ N ] ; int bottom [ ] [ ] = new int [ N ] [ N ] ;
for ( int i = 0 ; i < N ; i ++ ) {
top [ 0 ] [ i ] = mat [ 0 ] [ i ] ;
bottom [ N - 1 ] [ i ] = mat [ N - 1 ] [ i ] ;
left [ i ] [ 0 ] = mat [ i ] [ 0 ] ;
right [ i ] [ N - 1 ] = mat [ i ] [ N - 1 ] ; }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 1 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] == 1 ) left [ i ] [ j ] = left [ i ] [ j - 1 ] + 1 ; else left [ i ] [ j ] = 0 ;
if ( mat [ j ] [ i ] == 1 ) top [ j ] [ i ] = top [ j - 1 ] [ i ] + 1 ; else top [ j ] [ i ] = 0 ;
j = N - 1 - j ;
if ( mat [ j ] [ i ] == 1 ) bottom [ j ] [ i ] = bottom [ j + 1 ] [ i ] + 1 ; else bottom [ j ] [ i ] = 0 ;
if ( mat [ i ] [ j ] == 1 ) right [ i ] [ j ] = right [ i ] [ j + 1 ] + 1 ; else right [ i ] [ j ] = 0 ;
j = N - 1 - j ; } }
int n = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
int len = Math . min ( Math . min ( top [ i ] [ j ] , bottom [ i ] [ j ] ) , Math . min ( left [ i ] [ j ] , right [ i ] [ j ] ) ) ;
if ( len > n ) n = len ; } }
if ( n > 0 ) return 4 * ( n - 1 ) + 1 ;
return 0 ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } , { 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 } , { 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 } , { 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 } , { 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 } , { 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 } , { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 } } ; System . out . println ( findLargestPlus ( mat ) ) ; } }
static StringBuilder findLeft ( StringBuilder str ) { int n = str . length ( ) ;
while ( n > 0 ) { n -- ;
if ( str . charAt ( n ) == ' d ' ) { str . setCharAt ( n , ' c ' ) ; break ; } if ( str . charAt ( n ) == ' b ' ) { str . setCharAt ( n , ' a ' ) ; break ; }
if ( str . charAt ( n ) == ' a ' ) str . setCharAt ( n , ' b ' ) ; else if ( str . charAt ( n ) == ' c ' ) str . setCharAt ( n , ' d ' ) ; } return str ; }
public static void main ( String [ ] args ) { StringBuilder str = new StringBuilder ( " aacbddc " ) ; System . out . print ( " Left ▁ of ▁ " + str + " ▁ is ▁ " + findLeft ( str ) ) ; } }
static void printSpiral ( int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
int x ;
x = Math . min ( Math . min ( i , j ) , Math . min ( n - 1 - i , n - 1 - j ) ) ;
if ( i <= j ) System . out . print ( ( n - 2 * x ) * ( n - 2 * x ) - ( i - x ) - ( j - x ) + " TABSYMBOL " ) ;
else System . out . print ( ( n - 2 * x - 2 ) * ( n - 2 * x - 2 ) + ( i - x ) + ( j - x ) + " TABSYMBOL " ) ; } System . out . println ( ) ; } }
public static void main ( String args [ ] ) { int n = 5 ;
printSpiral ( n ) ; } }
import java . io . * ; import java . util . * ; class GFG {
static int findMaxValue ( int N , int mat [ ] [ ] ) {
int maxValue = Integer . MIN_VALUE ;
for ( int a = 0 ; a < N - 1 ; a ++ ) for ( int b = 0 ; b < N - 1 ; b ++ ) for ( int d = a + 1 ; d < N ; d ++ ) for ( int e = b + 1 ; e < N ; e ++ ) if ( maxValue < ( mat [ d ] [ e ] - mat [ a ] [ b ] ) ) maxValue = mat [ d ] [ e ] - mat [ a ] [ b ] ; return maxValue ; }
public static void main ( String [ ] args ) { int N = 5 ; int mat [ ] [ ] = { { 1 , 2 , - 1 , - 4 , - 20 } , { - 8 , - 3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { - 4 , - 1 , 1 , 7 , - 6 } , { 0 , - 4 , 10 , - 5 , 1 } } ; System . out . print ( " Maximum ▁ Value ▁ is ▁ " + findMaxValue ( N , mat ) ) ; } }
import java . io . * ; import java . util . * ; class GFG {
static int findMaxValue ( int N , int mat [ ] [ ] ) {
int maxValue = Integer . MIN_VALUE ;
int maxArr [ ] [ ] = new int [ N ] [ N ] ;
maxArr [ N - 1 ] [ N - 1 ] = mat [ N - 1 ] [ N - 1 ] ;
int maxv = mat [ N - 1 ] [ N - 1 ] ; for ( int j = N - 2 ; j >= 0 ; j -- ) { if ( mat [ N - 1 ] [ j ] > maxv ) maxv = mat [ N - 1 ] [ j ] ; maxArr [ N - 1 ] [ j ] = maxv ; }
maxv = mat [ N - 1 ] [ N - 1 ] ; for ( int i = N - 2 ; i >= 0 ; i -- ) { if ( mat [ i ] [ N - 1 ] > maxv ) maxv = mat [ i ] [ N - 1 ] ; maxArr [ i ] [ N - 1 ] = maxv ; }
for ( int i = N - 2 ; i >= 0 ; i -- ) { for ( int j = N - 2 ; j >= 0 ; j -- ) {
if ( maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] > maxValue ) maxValue = maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] ;
maxArr [ i ] [ j ] = Math . max ( mat [ i ] [ j ] , Math . max ( maxArr [ i ] [ j + 1 ] , maxArr [ i + 1 ] [ j ] ) ) ; } } return maxValue ; }
public static void main ( String [ ] args ) { int N = 5 ; int mat [ ] [ ] = { { 1 , 2 , - 1 , - 4 , - 20 } , { - 8 , - 3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { - 4 , - 1 , 1 , 7 , - 6 } , { 0 , - 4 , 10 , - 5 , 1 } } ; System . out . print ( " Maximum ▁ Value ▁ is ▁ " + findMaxValue ( N , mat ) ) ; } }
class GFG { public static void modifyMatrix ( int mat [ ] [ ] , int R , int C ) { int row [ ] = new int [ R ] ; int col [ ] = new int [ C ] ; int i , j ;
for ( i = 0 ; i < R ; i ++ ) { row [ i ] = 0 ; }
for ( i = 0 ; i < C ; i ++ ) { col [ i ] = 0 ; }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( mat [ i ] [ j ] == 1 ) { row [ i ] = 1 ; col [ j ] = 1 ; } } }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( row [ i ] == 1 col [ j ] == 1 ) { mat [ i ] [ j ] = 1 ; } } } }
public static void printMatrix ( int mat [ ] [ ] , int R , int C ) { int i , j ; for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; } System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 0 , 0 , 1 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 } , } ; System . out . println ( " Matrix ▁ Intially " ) ; printMatrix ( mat , 3 , 4 ) ; modifyMatrix ( mat , 3 , 4 ) ; System . out . println ( " Matrix ▁ after ▁ modification ▁ n " ) ; printMatrix ( mat , 3 , 4 ) ; } }
class GFG { public static void modifyMatrix ( int mat [ ] [ ] ) {
boolean row_flag = false ; boolean col_flag = false ;
for ( int i = 0 ; i < mat . length ; i ++ ) { for ( int j = 0 ; j < mat [ 0 ] . length ; j ++ ) { if ( i == 0 && mat [ i ] [ j ] == 1 ) row_flag = true ; if ( j == 0 && mat [ i ] [ j ] == 1 ) col_flag = true ; if ( mat [ i ] [ j ] == 1 ) { mat [ 0 ] [ j ] = 1 ; mat [ i ] [ 0 ] = 1 ; } } }
for ( int i = 1 ; i < mat . length ; i ++ ) { for ( int j = 1 ; j < mat [ 0 ] . length ; j ++ ) { if ( mat [ 0 ] [ j ] == 1 mat [ i ] [ 0 ] == 1 ) { mat [ i ] [ j ] = 1 ; } } }
if ( row_flag == true ) { for ( int i = 0 ; i < mat [ 0 ] . length ; i ++ ) { mat [ 0 ] [ i ] = 1 ; } }
if ( col_flag == true ) { for ( int i = 0 ; i < mat . length ; i ++ ) { mat [ i ] [ 0 ] = 1 ; } } }
public static void printMatrix ( int mat [ ] [ ] ) { for ( int i = 0 ; i < mat . length ; i ++ ) { for ( int j = 0 ; j < mat [ 0 ] . length ; j ++ ) { System . out . print ( mat [ i ] [ j ] ) ; } System . out . println ( " " ) ; } }
public static void main ( String args [ ] ) { int mat [ ] [ ] = { { 1 , 0 , 0 , 1 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 } } ; System . out . println ( " Input ▁ Matrix ▁ : " ) ; printMatrix ( mat ) ; modifyMatrix ( mat ) ; System . out . println ( " Matrix ▁ After ▁ Modification ▁ : " ) ; printMatrix ( mat ) ; } }
class GFG { static int n = 5 ; static int find ( boolean arr [ ] [ ] ) {
int i = 0 , j = n - 1 ;
int res = - 1 ;
while ( i < n && j >= 0 ) {
if ( arr [ i ] [ j ] == false ) {
while ( j >= 0 && ( arr [ i ] [ j ] == false i == j ) ) { j -- ; }
if ( j == - 1 ) { res = i ; break ;
} else { i ++ ; }
} else {
while ( i < n && ( arr [ i ] [ j ] == true i == j ) ) { i ++ ; }
if ( i == n ) { res = j ; break ;
} else { j -- ; } } }
if ( res == - 1 ) { return res ; }
for ( int k = 0 ; k < n ; k ++ ) { if ( res != k && arr [ k ] [ res ] != true ) { return - 1 ; } } for ( int l = 0 ; l < n ; l ++ ) { if ( res != l && arr [ res ] [ l ] != false ) { return - 1 ; } } return res ; }
public static void main ( String [ ] args ) { boolean mat [ ] [ ] = { { false , false , true , true , false } , { false , false , false , true , false } , { true , true , true , true , false } , { false , false , false , false , false } , { true , true , true , true , true } } ; System . out . println ( find ( mat ) ) ; } }
static int preProcess ( int mat [ ] [ ] , int aux [ ] [ ] ) {
for ( int i = 0 ; i < N ; i ++ ) aux [ 0 ] [ i ] = mat [ 0 ] [ i ] ;
for ( int i = 1 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) aux [ i ] [ j ] = mat [ i ] [ j ] + aux [ i - 1 ] [ j ] ;
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 1 ; j < N ; j ++ ) aux [ i ] [ j ] += aux [ i ] [ j - 1 ] ; return 0 ; }
static int sumQuery ( int aux [ ] [ ] , int tli , int tlj , int rbi , int rbj ) {
int res = aux [ rbi ] [ rbj ] ;
if ( tli > 0 ) res = res - aux [ tli - 1 ] [ rbj ] ;
if ( tlj > 0 ) res = res - aux [ rbi ] [ tlj - 1 ] ;
if ( tli > 0 && tlj > 0 ) res = res + aux [ tli - 1 ] [ tlj - 1 ] ; return res ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 , 4 , 6 } , { 5 , 3 , 8 , 1 , 2 } , { 4 , 6 , 7 , 5 , 5 } , { 2 , 4 , 8 , 9 , 4 } } ; int aux [ ] [ ] = new int [ M ] [ N ] ; preProcess ( mat , aux ) ; int tli = 2 , tlj = 2 , rbi = 3 , rbj = 4 ; System . out . print ( " Query1 : " + sumQuery ( aux , tli , tlj , rbi , rbj ) ) ; tli = 0 ; tlj = 0 ; rbi = 1 ; rbj = 1 ; System . out . print ( " Query2 : " + sumQuery ( aux , tli , tlj , rbi , rbj ) ) ; tli = 1 ; tlj = 2 ; rbi = 3 ; rbj = 3 ; System . out . print ( " Query3 : "  + sumQuery ( aux , tli , tlj , rbi , rbj ) ) ; } }
class GFG { static final int R = 3 ; static final int C = 3 ;
static void swap ( int mat [ ] [ ] , int row1 , int row2 , int col ) { for ( int i = 0 ; i < col ; i ++ ) { int temp = mat [ row1 ] [ i ] ; mat [ row1 ] [ i ] = mat [ row2 ] [ i ] ; mat [ row2 ] [ i ] = temp ; } }
static int rankOfMatrix ( int mat [ ] [ ] ) { int rank = C ; for ( int row = 0 ; row < rank ; row ++ ) {
if ( mat [ row ] [ row ] != 0 ) { for ( int col = 0 ; col < R ; col ++ ) { if ( col != row ) {
double mult = ( double ) mat [ col ] [ row ] / mat [ row ] [ row ] ; for ( int i = 0 ; i < rank ; i ++ ) mat [ col ] [ i ] -= mult * mat [ row ] [ i ] ; } } }
else { boolean reduce = true ;
for ( int i = row + 1 ; i < R ; i ++ ) {
if ( mat [ i ] [ row ] != 0 ) { swap ( mat , row , i , rank ) ; reduce = false ; break ; } }
if ( reduce ) {
rank -- ;
for ( int i = 0 ; i < R ; i ++ ) mat [ i ] [ row ] = mat [ i ] [ rank ] ; }
row -- ; }
} return rank ; }
static void display ( int mat [ ] [ ] , int row , int col ) { for ( int i = 0 ; i < row ; i ++ ) { for ( int j = 0 ; j < col ; j ++ ) System . out . print ( " ▁ " + mat [ i ] [ j ] ) ; System . out . print ( "NEW_LINE"); } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 10 , 20 , 10 } , { - 20 , - 30 , 10 } , { 30 , 50 , 0 } } ; System . out . print ( " Rank ▁ of ▁ the ▁ matrix ▁ is ▁ : ▁ " + rankOfMatrix ( mat ) ) ; } }
static int countIslands ( int mat [ ] [ ] , int m , int n ) {
int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( mat [ i ] [ j ] == ' X ' ) { if ( ( i == 0 mat [ i - 1 ] [ j ] == ' O ' ) && ( j == 0 mat [ i ] [ j - 1 ] == ' O ' ) ) count ++ ; } } } return count ; }
public static void main ( String [ ] args ) { int m = 6 ; int n = 3 ; int mat [ ] [ ] = { { ' O ' , ' O ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' } , { ' O ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' O ' } } ; System . out . println ( " Number ▁ of ▁ rectangular ▁ islands ▁ is : ▁ " + countIslands ( mat , m , n ) ) ; } }
static int M = 6 ; static int N = 6 ;
static void floodFillUtil ( char mat [ ] [ ] , int x , int y , char prevV , char newV ) {
if ( x < 0 x >= M y < 0 y >= N ) return ; if ( mat [ x ] [ y ] != prevV ) return ;
mat [ x ] [ y ] = newV ;
floodFillUtil ( mat , x + 1 , y , prevV , newV ) ; floodFillUtil ( mat , x - 1 , y , prevV , newV ) ; floodFillUtil ( mat , x , y + 1 , prevV , newV ) ; floodFillUtil ( mat , x , y - 1 , prevV , newV ) ; }
static void replaceSurrounded ( char mat [ ] [ ] ) {
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' O ' ) mat [ i ] [ j ] = ' - ' ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ 0 ] == ' - ' ) floodFillUtil ( mat , i , 0 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ N - 1 ] == ' - ' ) floodFillUtil ( mat , i , N - 1 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ 0 ] [ i ] == ' - ' ) floodFillUtil ( mat , 0 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ M - 1 ] [ i ] == ' - ' ) floodFillUtil ( mat , M - 1 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' - ' ) mat [ i ] [ j ] = ' X ' ; }
public static void main ( String [ ] args ) { char [ ] [ ] mat = { { ' X ' , ' O ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' X ' , ' O ' , ' X ' , ' X ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' O ' , ' X ' , ' X ' , ' X ' , ' X ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' , ' O ' , ' O ' , ' O ' } } ; replaceSurrounded ( mat ) ; for ( int i = 0 ; i < M ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; System . out . println ( " " ) ; } } }
static final int n = 5 ;
static void printSumSimple ( int mat [ ] [ ] , int k ) {
if ( k > n ) return ;
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
for ( int j = 0 ; j < n - k + 1 ; j ++ ) {
int sum = 0 ; for ( int p = i ; p < k + i ; p ++ ) for ( int q = j ; q < k + j ; q ++ ) sum += mat [ p ] [ q ] ; System . out . print ( sum + " ▁ " ) ; }
System . out . println ( ) ; } }
public static void main ( String arg [ ] ) { int mat [ ] [ ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } } ; int k = 3 ; printSumSimple ( mat , k ) ; } }
static int n = 5 ;
static void printSumTricky ( int mat [ ] [ ] , int k ) {
if ( k > n ) return ;
int stripSum [ ] [ ] = new int [ n ] [ n ] ;
for ( int j = 0 ; j < n ; j ++ ) {
int sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) sum += mat [ i ] [ j ] ; stripSum [ 0 ] [ j ] = sum ;
for ( int i = 1 ; i < n - k + 1 ; i ++ ) { sum += ( mat [ i + k - 1 ] [ j ] - mat [ i - 1 ] [ j ] ) ; stripSum [ i ] [ j ] = sum ; } }
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
int sum = 0 ; for ( int j = 0 ; j < k ; j ++ ) sum += stripSum [ i ] [ j ] ; System . out . print ( sum + " ▁ " ) ;
for ( int j = 1 ; j < n - k + 1 ; j ++ ) { sum += ( stripSum [ i ] [ j + k - 1 ] - stripSum [ i ] [ j - 1 ] ) ; System . out . print ( sum + " ▁ " ) ; } System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; int k = 3 ; printSumTricky ( mat , k ) ; } }
class GFG { static final int M = 3 ; static final int N = 4 ;
static void transpose ( int A [ ] [ ] , int B [ ] [ ] ) { int i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < M ; j ++ ) B [ i ] [ j ] = A [ j ] [ i ] ; }
public static void main ( String [ ] args ) { int A [ ] [ ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } } ; int B [ ] [ ] = new int [ N ] [ M ] , i , j ; transpose ( A , B ) ; System . out . print ( "Result matrix is NEW_LINE"); for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < M ; j ++ ) System . out . print ( B [ i ] [ j ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); } } }
class GFG { static final int N = 4 ;
static void transpose ( int A [ ] [ ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) { int temp = A [ i ] [ j ] ; A [ i ] [ j ] = A [ j ] [ i ] ; A [ j ] [ i ] = temp ; } }
public static void main ( String [ ] args ) { int A [ ] [ ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; transpose ( A ) ; System . out . print ( "Modified matrix is NEW_LINE"); for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) System . out . print ( A [ i ] [ j ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); } } }
class GFG { static final int R = 3 ; static final int C = 3 ;
static int pathCountRec ( int mat [ ] [ ] , int m , int n , int k ) {
if ( m < 0 n < 0 ) { return 0 ; } if ( m == 0 && n == 0 && ( k == mat [ m ] [ n ] ) ) { return 1 ; }
return pathCountRec ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountRec ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; }
static int pathCount ( int mat [ ] [ ] , int k ) { return pathCountRec ( mat , R - 1 , C - 1 , k ) ; }
public static void main ( String [ ] args ) { int k = 12 ; int mat [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 6 , 5 } , { 3 , 2 , 1 } } ; System . out . println ( pathCount ( mat , k ) ) ; } }
class path {
static int x [ ] = { 0 , 1 , 1 , - 1 , 1 , 0 , - 1 , - 1 } ; static int y [ ] = { 1 , 0 , 1 , 1 , - 1 , - 1 , 0 , - 1 } ; static int R = 3 ; static int C = 3 ;
static int dp [ ] [ ] = new int [ R ] [ C ] ;
static boolean isvalid ( int i , int j ) { if ( i < 0 j < 0 i >= R j >= C ) return false ; return true ; }
static boolean isadjacent ( char prev , char curr ) { return ( ( curr - prev ) == 1 ) ; }
static int getLenUtil ( char mat [ ] [ ] , int i , int j , char prev ) {
if ( ! isvalid ( i , j ) || ! isadjacent ( prev , mat [ i ] [ j ] ) ) return 0 ;
if ( dp [ i ] [ j ] != - 1 ) return dp [ i ] [ j ] ;
int ans = 0 ;
for ( int k = 0 ; k < 8 ; k ++ ) ans = Math . max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , mat [ i ] [ j ] ) ) ;
return dp [ i ] [ j ] = ans ; }
static int getLen ( char mat [ ] [ ] , char s ) { for ( int i = 0 ; i < R ; ++ i ) for ( int j = 0 ; j < C ; ++ j ) dp [ i ] [ j ] = - 1 ; int ans = 0 ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) {
if ( mat [ i ] [ j ] == s ) {
for ( int k = 0 ; k < 8 ; k ++ ) ans = Math . max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , s ) ) ; } } } return ans ; }
public static void main ( String args [ ] ) { char mat [ ] [ ] = { { ' a ' , ' c ' , ' d ' } , { ' h ' , ' b ' , ' a ' } , { ' i ' , ' g ' , ' f ' } } ; System . out . println ( getLen ( mat , ' a ' ) ) ; System . out . println ( getLen ( mat , ' e ' ) ) ; System . out . println ( getLen ( mat , ' b ' ) ) ; System . out . println ( getLen ( mat , ' f ' ) ) ; } }
class min_steps { static int minInitialPoints ( int points [ ] [ ] , int R , int C ) {
int dp [ ] [ ] = new int [ R ] [ C ] ; int m = R , n = C ;
dp [ m - 1 ] [ n - 1 ] = points [ m - 1 ] [ n - 1 ] > 0 ? 1 : Math . abs ( points [ m - 1 ] [ n - 1 ] ) + 1 ;
for ( int i = m - 2 ; i >= 0 ; i -- ) dp [ i ] [ n - 1 ] = Math . max ( dp [ i + 1 ] [ n - 1 ] - points [ i ] [ n - 1 ] , 1 ) ; for ( int j = n - 2 ; j >= 0 ; j -- ) dp [ m - 1 ] [ j ] = Math . max ( dp [ m - 1 ] [ j + 1 ] - points [ m - 1 ] [ j ] , 1 ) ;
for ( int i = m - 2 ; i >= 0 ; i -- ) { for ( int j = n - 2 ; j >= 0 ; j -- ) { int min_points_on_exit = Math . min ( dp [ i + 1 ] [ j ] , dp [ i ] [ j + 1 ] ) ; dp [ i ] [ j ] = Math . max ( min_points_on_exit - points [ i ] [ j ] , 1 ) ; } } return dp [ 0 ] [ 0 ] ; }
public static void main ( String args [ ] ) { int points [ ] [ ] = { { - 2 , - 3 , 3 } , { - 5 , - 10 , 1 } , { 10 , 30 , - 5 } } ; int R = 3 , C = 3 ; System . out . println ( " Minimum ▁ Initial ▁ Points ▁ Required : ▁ " + minInitialPoints ( points , R , C ) ) ; } }
