function printNGE ( $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ next = -1 ; for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) { if ( $ arr [ $ i ] < $ arr [ $ j ] ) { $ next = $ arr [ $ j ] ; break ; } } echo $ arr [ $ i ] . " -- " . ▁ $ next . " " } }
$ arr = array ( 11 , 13 , 21 , 3 ) ; $ n = count ( $ arr ) ; printNGE ( $ arr , $ n ) ; ? >
function findMin ( $ arr , $ low , $ high ) {
if ( $ high < $ low ) return $ arr [ 0 ] ;
if ( $ high == $ low ) return $ arr [ $ low ] ;
$ mid = $ low + ( $ high - $ low ) / 2 ;
if ( $ mid < $ high && $ arr [ $ mid + 1 ] < $ arr [ $ mid ] ) return $ arr [ $ mid + 1 ] ;
if ( $ mid > $ low && $ arr [ $ mid ] < $ arr [ $ mid - 1 ] ) return $ arr [ $ mid ] ;
if ( $ arr [ $ high ] > $ arr [ $ mid ] ) return findMin ( $ arr , $ low , $ mid - 1 ) ; return findMin ( $ arr , $ mid + 1 , $ high ) ; }
$ arr1 = array ( 5 , 6 , 1 , 2 , 3 , 4 ) ; $ n1 = sizeof ( $ arr1 ) ; echo " The ▁ minimum ▁ element ▁ is ▁ " . findMin ( $ arr1 , 0 , $ n1 - 1 ) . " STRNEWLINE " ; $ arr2 = array ( 1 , 2 , 3 , 4 ) ; $ n2 = sizeof ( $ arr2 ) ; echo " The ▁ minimum ▁ element ▁ is ▁ " . findMin ( $ arr2 , 0 , $ n2 - 1 ) . " STRNEWLINE " ; $ arr3 = array ( 1 ) ; $ n3 = sizeof ( $ arr3 ) ; echo " The ▁ minimum ▁ element ▁ is ▁ " . findMin ( $ arr3 , 0 , $ n3 - 1 ) . " STRNEWLINE " ; $ arr4 = array ( 1 , 2 ) ; $ n4 = sizeof ( $ arr4 ) ; echo " The ▁ minimum ▁ element ▁ is ▁ " . findMin ( $ arr4 , 0 , $ n4 - 1 ) . " STRNEWLINE " ; $ arr5 = array ( 2 , 1 ) ; $ n5 = sizeof ( $ arr5 ) ; echo " The ▁ minimum ▁ element ▁ is ▁ " . findMin ( $ arr5 , 0 , $ n5 - 1 ) . " STRNEWLINE " ; $ arr6 = array ( 5 , 6 , 7 , 1 , 2 , 3 , 4 ) ; $ n6 = sizeof ( $ arr6 ) ; echo " The ▁ minimum ▁ element ▁ is ▁ " . findMin ( $ arr6 , 0 , $ n6 - 1 ) . " STRNEWLINE " ; $ arr7 = array ( 1 , 2 , 3 , 4 , 5 , 6 , 7 ) ; $ n7 = sizeof ( $ arr7 ) ; echo " The ▁ minimum ▁ element ▁ is ▁ " . findMin ( $ arr7 , 0 , $ n7 - 1 ) . " STRNEWLINE " ; $ arr8 = array ( 2 , 3 , 4 , 5 , 6 , 7 , 8 , 1 ) ; $ n8 = sizeof ( $ arr8 ) ; echo " The ▁ minimum ▁ element ▁ is ▁ " . findMin ( $ arr8 , 0 , $ n8 - 1 ) . " STRNEWLINE " ; $ arr9 = array ( 3 , 4 , 5 , 1 , 2 ) ; $ n9 = sizeof ( $ arr9 ) ; echo " The ▁ minimum ▁ element ▁ is ▁ " . findMin ( $ arr9 , 0 , $ n9 - 1 ) . " STRNEWLINE " ; ? >
function print2largest ( $ arr , $ arr_size ) {
if ( $ arr_size < 2 ) { echo ( " ▁ Invalid ▁ Input ▁ " ) ; return ; } $ first = $ second = PHP_INT_MIN ; for ( $ i = 0 ; $ i < $ arr_size ; $ i ++ ) {
if ( $ arr [ $ i ] > $ first ) { $ second = $ first ; $ first = $ arr [ $ i ] ; }
else if ( $ arr [ $ i ] > $ second && $ arr [ $ i ] != $ first ) $ second = $ arr [ $ i ] ; } if ( $ second == PHP_INT_MIN ) echo ( " There ▁ is ▁ no ▁ second ▁ largest ▁ element STRNEWLINE " ) ; else echo ( " The ▁ second ▁ largest ▁ element ▁ is ▁ " . $ second . " STRNEWLINE " ) ; }
$ arr = array ( 12 , 35 , 1 , 10 , 34 , 1 ) ; $ n = sizeof ( $ arr ) ; print2largest ( $ arr , $ n ) ; ? >
function FindMaxSum ( $ arr , $ n ) { $ incl = $ arr [ 0 ] ; $ excl = 0 ; $ excl_new ; $ i ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) {
$ excl_new = ( $ incl > $ excl ) ? $ incl : $ excl ;
$ incl = $ excl + $ arr [ $ i ] ; $ excl = $ excl_new ; }
return ( ( $ incl > $ excl ) ? $ incl : $ excl ) ; }
$ arr = array ( 5 , 5 , 10 , 100 , 10 , 5 ) ; $ n = sizeof ( $ arr ) ; echo FindMaxSum ( $ arr , $ n ) ; ? >
function minJumps ( $ arr , $ l , $ h ) {
if ( $ h == $ l ) return 0 ;
if ( $ arr [ $ l ] == 0 ) return INT_MAX ;
$ min = 999999 ; for ( $ i = $ l + 1 ; $ i <= $ h && $ i <= $ l + $ arr [ $ l ] ; $ i ++ ) { $ jumps = minJumps ( $ arr , $ i , $ h ) ; if ( $ jumps != 999999 && $ jumps + 1 < $ min ) $ min = $ jumps + 1 ; } return $ min ; }
$ arr = array ( 1 , 3 , 6 , 3 , 2 , 3 , 6 , 8 , 9 , 5 ) ; $ n = count ( $ arr ) ; echo " Minimum ▁ number ▁ of ▁ jumps ▁ to ▁ reach ▁ " . " end ▁ is ▁ " . minJumps ( $ arr , 0 , $ n - 1 ) ; ? >
function maxSumIS ( $ arr , $ n ) { $ max = 0 ; $ msis = array ( $ n ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ msis [ $ i ] = $ arr [ $ i ] ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ i ; $ j ++ ) if ( $ arr [ $ i ] > $ arr [ $ j ] && $ msis [ $ i ] < $ msis [ $ j ] + $ arr [ $ i ] ) $ msis [ $ i ] = $ msis [ $ j ] + $ arr [ $ i ] ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ max < $ msis [ $ i ] ) $ max = $ msis [ $ i ] ; return $ max ; }
$ arr = array ( 1 , 101 , 2 , 3 , 100 , 4 , 5 ) ; $ n = count ( $ arr ) ; echo " Sum ▁ of ▁ maximum ▁ sum ▁ increasing ▁ subsequence ▁ is ▁ " . maxSumIS ( $ arr , $ n ) ; ? >
function moveToEnd ( & $ mPlusN , $ size ) { global $ NA ; $ j = $ size - 1 ; for ( $ i = $ size - 1 ; $ i >= 0 ; $ i -- ) if ( $ mPlusN [ $ i ] != $ NA ) { $ mPlusN [ $ j ] = $ mPlusN [ $ i ] ; $ j -- ; } }
function merge ( & $ mPlusN , & $ N , $ m , $ n ) { $ i = $ n ;
$ j = 0 ;
$ k = 0 ;
while ( $ k < ( $ m + $ n ) ) {
if ( ( $ j == $ n ) || ( $ i < ( $ m + $ n ) && $ mPlusN [ $ i ] <= $ N [ $ j ] ) ) { $ mPlusN [ $ k ] = $ mPlusN [ $ i ] ; $ k ++ ; $ i ++ ; }
else { $ mPlusN [ $ k ] = $ N [ $ j ] ; $ k ++ ; $ j ++ ; } } }
function printArray ( & $ arr , $ size ) { for ( $ i = 0 ; $ i < $ size ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; echo " STRNEWLINE " ; }
$ mPlusN = array ( 2 , 8 , $ NA , $ NA , $ NA , 13 , $ NA , 15 , 20 ) ; $ N = array ( 5 , 7 , 9 , 25 ) ; $ n = sizeof ( $ N ) ; $ m = sizeof ( $ mPlusN ) - $ n ;
moveToEnd ( $ mPlusN , $ m + $ n ) ;
merge ( $ mPlusN , $ N , $ m , $ n ) ;
printArray ( $ mPlusN , $ m + $ n ) ; ? >
function minAbsSumPair ( $ arr , $ arr_size ) { $ inv_count = 0 ;
if ( $ arr_size < 2 ) { echo " Invalid ▁ Input " ; return ; }
$ min_l = 0 ; $ min_r = 1 ; $ min_sum = $ arr [ 0 ] + $ arr [ 1 ] ; for ( $ l = 0 ; $ l < $ arr_size - 1 ; $ l ++ ) { for ( $ r = $ l + 1 ; $ r < $ arr_size ; $ r ++ ) { $ sum = $ arr [ $ l ] + $ arr [ $ r ] ; if ( abs ( $ min_sum ) > abs ( $ sum ) ) { $ min_sum = $ sum ; $ min_l = $ l ; $ min_r = $ r ; } } } echo " The ▁ two ▁ elements ▁ whose ▁ sum ▁ is ▁ minimum ▁ are ▁ " . $ arr [ $ min_l ] . " ▁ and ▁ " . $ arr [ $ min_r ] ; }
$ arr = array ( 1 , 60 , -10 , 70 , -80 , 85 ) ; minAbsSumPair ( $ arr , 6 ) ; ? >
function sort012 ( & $ a , $ arr_size ) { $ lo = 0 ; $ hi = $ arr_size - 1 ; $ mid = 0 ; while ( $ mid <= $ hi ) { switch ( $ a [ $ mid ] ) { case 0 : swap ( $ a [ $ lo ++ ] , $ a [ $ mid ++ ] ) ; break ; case 1 : $ mid ++ ; break ; case 2 : swap ( $ a [ $ mid ] , $ a [ $ hi -- ] ) ; break ; } } }
function printArray ( & $ arr , $ arr_size ) { for ( $ i = 0 ; $ i < $ arr_size ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; echo " STRNEWLINE " ; }
$ arr = array ( 0 , 1 , 1 , 0 , 1 , 2 , 1 , 2 , 0 , 0 , 0 , 1 ) ; $ arr_size = sizeof ( $ arr ) ; sort012 ( $ arr , $ arr_size ) ; echo " array ▁ after ▁ segregation ▁ " ; printArray ( $ arr , $ arr_size ) ; ? >
function findNumberOfTriangles ( $ arr ) { $ n = count ( $ arr ) ;
sort ( $ arr ) ;
$ count = 0 ;
for ( $ i = 0 ; $ i < $ n - 2 ; ++ $ i ) {
$ k = $ i + 2 ;
for ( $ j = $ i + 1 ; $ j < $ n ; ++ $ j ) {
while ( $ k < $ n && $ arr [ $ i ] + $ arr [ $ j ] > $ arr [ $ k ] ) ++ $ k ;
if ( $ k > $ j ) $ count += $ k - $ j - 1 ; } } return $ count ; }
$ arr = array ( 10 , 21 , 22 , 100 , 101 , 200 , 300 ) ; echo " Total ▁ number ▁ of ▁ triangles ▁ is ▁ " , findNumberOfTriangles ( $ arr ) ; ? >
function binarySearch ( $ arr , $ low , $ high , $ key ) { if ( $ high < $ low ) return -1 ;
$ mid = ( $ low + $ high ) / 2 ; if ( $ key == $ arr [ ( int ) $ mid ] ) return $ mid ; if ( $ key > $ arr [ ( int ) $ mid ] ) return binarySearch ( $ arr , ( $ mid + 1 ) , $ high , $ key ) ; return ( binarySearch ( $ arr , $ low , ( $ mid -1 ) , $ key ) ) ; }
$ arr = array ( 5 , 6 , 7 , 8 , 9 , 10 ) ; $ n = count ( $ arr ) ; $ key = 10 ; echo " Index : ▁ " , ( int ) binarySearch ( $ arr , 0 , $ n -1 , $ key ) ; ? >
function equilibrium ( $ arr , $ n ) { $ i ; $ j ; $ leftsum ; $ rightsum ;
for ( $ i = 0 ; $ i < $ n ; ++ $ i ) { $ leftsum = 0 ; $ rightsum = 0 ;
for ( $ j = 0 ; $ j < $ i ; $ j ++ ) $ leftsum += $ arr [ $ j ] ;
for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) $ rightsum += $ arr [ $ j ] ;
if ( $ leftsum == $ rightsum ) return $ i ; }
return -1 ; }
$ arr = array ( -7 , 1 , 5 , 2 , -4 , 3 , 0 ) ; $ arr_size = sizeof ( $ arr ) ; echo equilibrium ( $ arr , $ arr_size ) ; ? >
function ceilSearch ( $ arr , $ low , $ high , $ x ) { $ mid ;
if ( $ x <= $ arr [ $ low ] ) return $ low ;
if ( $ x > $ arr [ $ high ] ) return -1 ;
$ mid = ( $ low + $ high ) / 2 ;
if ( $ arr [ $ mid ] == $ x ) return $ mid ;
else if ( $ arr [ $ mid ] < $ x ) { if ( $ mid + 1 <= $ high && $ x <= $ arr [ $ mid + 1 ] ) return $ mid + 1 ; else return ceilSearch ( $ arr , $ mid + 1 , $ high , $ x ) ; }
else { if ( $ mid - 1 >= $ low && $ x > $ arr [ $ mid - 1 ] ) return $ mid ; else return ceilSearch ( $ arr , $ low , $ mid - 1 , $ x ) ; } }
$ arr = array ( 1 , 2 , 8 , 10 , 10 , 12 , 19 ) ; $ n = sizeof ( $ arr ) ; $ x = 20 ; $ index = ceilSearch ( $ arr , 0 , $ n - 1 , $ x ) ; if ( $ index == -1 ) echo ( " Ceiling ▁ of ▁ $ x ▁ doesn ' t ▁ exist ▁ in ▁ array ▁ " ) ; else echo ( " ceiling ▁ of ▁ $ x ▁ is " ) ; echo ( isset ( $ arr [ $ index ] ) ) ; ? >
function findCandidate ( $ a , $ size ) { $ maj_index = 0 ; $ count = 1 ; for ( $ i = 1 ; $ i < $ size ; $ i ++ ) { if ( $ a [ $ maj_index ] == $ a [ $ i ] ) $ count ++ ; else $ count -- ; if ( $ count == 0 ) { $ maj_index = $ i ; $ count = 1 ; } } return $ a [ $ maj_index ] ; }
function isMajority ( $ a , $ size , $ cand ) { $ count = 0 ; for ( $ i = 0 ; $ i < $ size ; $ i ++ ) if ( $ a [ $ i ] == $ cand ) $ count ++ ; if ( $ count > $ size / 2 ) return 1 ; else return 0 ; }
function printMajority ( $ a , $ size ) {
$ cand = findCandidate ( $ a , $ size ) ;
if ( isMajority ( $ a , $ size , $ cand ) ) echo " " , ▁ $ cand , ▁ " " else echo " No ▁ Majority ▁ Element " ; }
$ a = array ( 1 , 3 , 3 , 1 , 2 ) ; $ size = sizeof ( $ a ) ;
printMajority ( $ a , $ size ) ; ? >
function printRepeating ( $ arr , $ size ) { $ i ; $ j ; echo " ▁ Repeating ▁ elements ▁ are ▁ " ; for ( $ i = 0 ; $ i < $ size ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ size ; $ j ++ ) if ( $ arr [ $ i ] == $ arr [ $ j ] ) echo $ arr [ $ i ] , " ▁ " ; }
$ arr = array ( 4 , 2 , 4 , 5 , 2 , 3 , 1 ) ; $ arr_size = sizeof ( $ arr , 0 ) ; printRepeating ( $ arr , $ arr_size ) ; ? >
function printRepeating ( $ arr , $ size ) {
$ S = 0 ;
$ P = 1 ;
$ x ; $ y ;
$ D ; $ n = $ size - 2 ;
for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { $ S = $ S + $ arr [ $ i ] ; $ P = $ P * $ arr [ $ i ] ; }
$ S = $ S - $ n * ( $ n + 1 ) / 2 ;
$ P = $ P / fact ( $ n ) ;
$ D = sqrt ( $ S * $ S - 4 * $ P ) ; $ x = ( $ D + $ S ) / 2 ; $ y = ( $ S - $ D ) / 2 ; echo " The ▁ two ▁ Repeating ▁ elements ▁ are ▁ " . $ x . " & " }
function fact ( $ n ) { return ( $ n == 0 ) ? 1 : $ n * fact ( $ n - 1 ) ; }
$ arr = array ( 4 , 2 , 4 , 5 , 2 , 3 , 1 ) ; $ arr_size = count ( $ arr ) ; printRepeating ( $ arr , $ arr_size ) ; ? >
function printRepeating ( $ arr , $ size ) {
$ xor = $ arr [ 0 ] ;
$ set_bit_no ; $ i ; $ n = $ size - 2 ; $ x = 0 ; $ y = 0 ;
for ( $ i = 1 ; $ i < $ size ; $ i ++ ) $ xor ^= $ arr [ $ i ] ; for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) $ xor ^= $ i ;
$ set_bit_no = $ xor & ~ ( $ xor - 1 ) ;
for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { if ( $ arr [ $ i ] & $ set_bit_no ) $ x = $ x ^ $ arr [ $ i ] ;
else $ y = $ y ^ $ arr [ $ i ] ;
} for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) { if ( $ i & $ set_bit_no ) $ x = $ x ^ $ i ;
else $ y = $ y ^ $ i ; }
echo " n ▁ The ▁ two ▁ repeating ▁ elements ▁ are ▁ " ; echo $ y . " ▁ " . $ x ; } ? >
$ arr = array ( 4 , 2 , 4 , 5 , 2 , 3 , 1 ) ; $ arr_size = count ( $ arr ) ; printRepeating ( $ arr , $ arr_size ) ;
function printRepeating ( $ arr , $ size ) { $ i ; echo " The ▁ repeating ▁ elements ▁ are " , " ▁ " ; for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { if ( $ arr [ abs ( $ arr [ $ i ] ) ] > 0 ) $ arr [ abs ( $ arr [ $ i ] ) ] = - $ arr [ abs ( $ arr [ $ i ] ) ] ; else echo abs ( $ arr [ $ i ] ) , " ▁ " ; } }
$ arr = array ( 4 , 2 , 4 , 5 , 2 , 3 , 1 ) ; $ arr_size = sizeof ( $ arr ) ; printRepeating ( $ arr , $ arr_size ) ; #This  code is contributed by aj_36 NEW_LINE ? >
function binarySearch ( $ arr , $ low , $ high ) { if ( $ high >= $ low ) {
$ mid = ( int ) ( ( $ low + $ high ) / 2 ) ; if ( $ mid == $ arr [ $ mid ] ) return $ mid ; if ( $ mid > $ arr [ $ mid ] ) return binarySearch ( $ arr , ( $ mid + 1 ) , $ high ) ; else return binarySearch ( $ arr , $ low , ( $ mid - 1 ) ) ; }
return -1 ; }
$ arr = array ( -10 , -1 , 0 , 3 , 10 , 11 , 30 , 50 , 100 ) ; $ n = count ( $ arr ) ; echo " Fixed ▁ Point ▁ is : ▁ " . binarySearch ( $ arr , 0 , $ n - 1 ) ; ? >
function find3Numbers ( $ A , $ arr_size , $ sum ) { $ l ; $ r ;
for ( $ i = 0 ; $ i < $ arr_size - 2 ; $ i ++ ) {
for ( $ j = $ i + 1 ; $ j < $ arr_size - 1 ; $ j ++ ) {
for ( $ k = $ j + 1 ; $ k < $ arr_size ; $ k ++ ) { if ( $ A [ $ i ] + $ A [ $ j ] + $ A [ $ k ] == $ sum ) { echo " Triplet ▁ is " , " ▁ " , $ A [ $ i ] , " , ▁ " , $ A [ $ j ] , " , ▁ " , $ A [ $ k ] ; return true ; } } } }
return false ; }
$ A = array ( 1 , 4 , 45 , 6 , 10 , 8 ) ; $ sum = 22 ; $ arr_size = sizeof ( $ A ) ; find3Numbers ( $ A , $ arr_size , $ sum ) ; ? >
function search ( $ arr , $ x ) { $ n = sizeof ( $ arr ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] == $ x ) return $ i ; } return -1 ; }
$ arr = array ( 2 , 3 , 4 , 10 , 40 ) ; $ x = 10 ;
$ result = search ( $ arr , $ x ) ; if ( $ result == -1 ) echo " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ; else echo " Element ▁ is ▁ present ▁ at ▁ index ▁ " , $ result ; ? >
function binarySearch ( $ arr , $ l , $ r , $ x ) { if ( $ r >= $ l ) { $ mid = ceil ( $ l + ( $ r - $ l ) / 2 ) ;
if ( $ arr [ $ mid ] == $ x ) return floor ( $ mid ) ;
if ( $ arr [ $ mid ] > $ x ) return binarySearch ( $ arr , $ l , $ mid - 1 , $ x ) ;
return binarySearch ( $ arr , $ mid + 1 , $ r , $ x ) ; }
return -1 ; }
$ arr = array ( 2 , 3 , 4 , 10 , 40 ) ; $ n = count ( $ arr ) ; $ x = 10 ; $ result = binarySearch ( $ arr , 0 , $ n - 1 , $ x ) ; if ( ( $ result == -1 ) ) echo " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ; else echo " Element ▁ is ▁ present ▁ at ▁ index ▁ " , $ result ; ? >
$ RANGE = 255 ;
function countSort ( $ arr ) { global $ RANGE ;
$ output = array ( strlen ( $ arr ) ) ; $ len = strlen ( $ arr ) ;
$ count = array_fill ( 0 , $ RANGE + 1 , 0 ) ;
for ( $ i = 0 ; $ i < $ len ; ++ $ i ) ++ $ count [ ord ( $ arr [ $ i ] ) ] ;
for ( $ i = 1 ; $ i <= $ RANGE ; ++ $ i ) $ count [ $ i ] += $ count [ $ i - 1 ] ;
for ( $ i = $ len - 1 ; $ i >= 0 ; $ i -- ) { $ output [ $ count [ ord ( $ arr [ $ i ] ) ] - 1 ] = $ arr [ $ i ] ; -- $ count [ ord ( $ arr [ $ i ] ) ] ; }
for ( $ i = 0 ; $ i < $ len ; ++ $ i ) $ arr [ $ i ] = $ output [ $ i ] ; return $ arr ; }
$ arr = " geeksforgeeks " ; $ arr = countSort ( $ arr ) ; echo " Sorted ▁ character ▁ array ▁ is ▁ " . $ arr ; ? >
function printMaxActivities ( $ s , $ f , $ n ) { echo " Following ▁ activities ▁ are ▁ selected ▁ " . " STRNEWLINE " ;
$ i = 0 ; echo $ i . " " ;
for ( $ j = 1 ; $ j < $ n ; $ j ++ ) {
if ( $ s [ $ j ] >= $ f [ $ i ] ) { echo $ j . " " ; $ i = $ j ; } } }
$ s = array ( 1 , 3 , 0 , 5 , 8 , 5 ) ; $ f = array ( 2 , 4 , 6 , 7 , 9 , 9 ) ; $ n = sizeof ( $ s ) ; printMaxActivities ( $ s , $ f , $ n ) ; ? >
$ R = 3 ; $ C = 3 ;
function min1 ( $ x , $ y , $ z ) { if ( $ x < $ y ) return ( $ x < $ z ) ? $ x : $ z ; else return ( $ y < $ z ) ? $ y : $ z ; }
function minCost ( $ cost , $ m , $ n ) { global $ R ; global $ C ; if ( $ n < 0 $ m < 0 ) return PHP_INT_MAX ; else if ( $ m == 0 && $ n == 0 ) return $ cost [ $ m ] [ $ n ] ; else return $ cost [ $ m ] [ $ n ] + min1 ( minCost ( $ cost , $ m - 1 , $ n - 1 ) , minCost ( $ cost , $ m - 1 , $ n ) , minCost ( $ cost , $ m , $ n - 1 ) ) ; }
$ cost = array ( array ( 1 , 2 , 3 ) , array ( 4 , 8 , 2 ) , array ( 1 , 5 , 3 ) ) ; echo minCost ( $ cost , 2 , 2 ) ; ? >
$ R = 3 ; $ C = 3 ; function minCost ( $ cost , $ m , $ n ) { global $ R ; global $ C ;
$ tc ; for ( $ i = 0 ; $ i <= $ R ; $ i ++ ) for ( $ j = 0 ; $ j <= $ C ; $ j ++ ) $ tc [ $ i ] [ $ j ] = 0 ; $ tc [ 0 ] [ 0 ] = $ cost [ 0 ] [ 0 ] ;
for ( $ i = 1 ; $ i <= $ m ; $ i ++ ) $ tc [ $ i ] [ 0 ] = $ tc [ $ i - 1 ] [ 0 ] + $ cost [ $ i ] [ 0 ] ;
for ( $ j = 1 ; $ j <= $ n ; $ j ++ ) $ tc [ 0 ] [ $ j ] = $ tc [ 0 ] [ $ j - 1 ] + $ cost [ 0 ] [ $ j ] ;
for ( $ i = 1 ; $ i <= $ m ; $ i ++ ) for ( $ j = 1 ; $ j <= $ n ; $ j ++ )
$ tc [ $ i ] [ $ j ] = min ( $ tc [ $ i - 1 ] [ $ j - 1 ] , $ tc [ $ i - 1 ] [ $ j ] , $ tc [ $ i ] [ $ j - 1 ] ) + $ cost [ $ i ] [ $ j ] ; return $ tc [ $ m ] [ $ n ] ; }
$ cost = array ( array ( 1 , 2 , 3 ) , array ( 4 , 8 , 2 ) , array ( 1 , 5 , 3 ) ) ; echo minCost ( $ cost , 2 , 2 ) ; ? >
function binomialCoeff ( $ n , $ k ) {
if ( $ k > $ n ) return 0 ; if ( $ k == 0 $ k == $ n ) return 1 ;
return binomialCoeff ( $ n - 1 , $ k - 1 ) + binomialCoeff ( $ n - 1 , $ k ) ; }
$ n = 5 ; $ k = 2 ; echo " Value ▁ of ▁ C " , " ( " , $ n , $ k , " ) ▁ is ▁ " , binomialCoeff ( $ n , $ k ) ; ? >
function knapSack ( $ W , $ wt , $ val , $ n ) { $ K = array ( array ( ) ) ;
for ( $ i = 0 ; $ i <= $ n ; $ i ++ ) { for ( $ w = 0 ; $ w <= $ W ; $ w ++ ) { if ( $ i == 0 $ w == 0 ) $ K [ $ i ] [ $ w ] = 0 ; else if ( $ wt [ $ i - 1 ] <= $ w ) $ K [ $ i ] [ $ w ] = max ( $ val [ $ i - 1 ] + $ K [ $ i - 1 ] [ $ w - $ wt [ $ i - 1 ] ] , $ K [ $ i - 1 ] [ $ w ] ) ; else $ K [ $ i ] [ $ w ] = $ K [ $ i - 1 ] [ $ w ] ; } } return $ K [ $ n ] [ $ W ] ; }
$ val = array ( 60 , 100 , 120 ) ; $ wt = array ( 10 , 20 , 30 ) ; $ W = 50 ; $ n = count ( $ val ) ; echo knapSack ( $ W , $ wt , $ val , $ n ) ; ? >
function lps ( $ seq , $ i , $ j ) {
if ( $ i == $ j ) return 1 ;
if ( $ seq [ $ i ] == $ seq [ $ j ] && $ i + 1 == $ j ) return 2 ;
if ( $ seq [ $ i ] == $ seq [ $ j ] ) return lps ( $ seq , $ i + 1 , $ j - 1 ) + 2 ;
return max ( lps ( $ seq , $ i , $ j - 1 ) , lps ( $ seq , $ i + 1 , $ j ) ) ; }
$ seq = " GEEKSFORGEEKS " ; $ n = strlen ( $ seq ) ; echo " The ▁ length ▁ of ▁ the ▁ LPS ▁ is ▁ " . lps ( $ seq , 0 , $ n - 1 ) ; ? >
function isSubsetSum ( $ arr , $ n , $ sum ) {
if ( $ sum == 0 ) return true ; if ( $ n == 0 && $ sum != 0 ) return false ;
if ( $ arr [ $ n - 1 ] > $ sum ) return isSubsetSum ( $ arr , $ n - 1 , $ sum ) ;
return isSubsetSum ( $ arr , $ n - 1 , $ sum ) || isSubsetSum ( $ arr , $ n - 1 , $ sum - $ arr [ $ n - 1 ] ) ; }
function findPartiion ( $ arr , $ n ) {
$ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ sum += $ arr [ $ i ] ;
if ( $ sum % 2 != 0 ) return false ;
return isSubsetSum ( $ arr , $ n , $ sum / 2 ) ; }
$ arr = array ( 3 , 1 , 5 , 9 , 12 ) ; $ n = count ( $ arr ) ;
if ( findPartiion ( $ arr , $ n ) == true ) echo " Can ▁ be ▁ divided ▁ into ▁ two ▁ subsets ▁ of ▁ equal ▁ sum " ; else echo " Can ▁ not ▁ be ▁ divided ▁ into ▁ two ▁ subsets ▁ of ▁ equal ▁ sum " ; ? >
function findoptimal ( $ N ) {
if ( $ N <= 6 ) return $ N ;
$ max = 0 ;
$ b ; for ( $ b = $ N - 3 ; $ b >= 1 ; $ b -= 1 ) {
$ curr = ( $ N - $ b - 1 ) * findoptimal ( $ b ) ; if ( $ curr > $ max ) $ max = $ curr ; } return $ max ; }
$ N ;
for ( $ N = 1 ; $ N <= 20 ; $ N += 1 ) echo ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with " . $ N . " keystrokes ▁ is ▁ " . findoptimal ( $ N ) . " STRNEWLINE " ) ; ? >
function search ( $ pat , $ txt ) { $ M = strlen ( $ pat ) ; $ N = strlen ( $ txt ) ; $ i = 0 ; while ( $ i <= $ N - $ M ) { $ j ;
for ( $ j = 0 ; $ j < $ M ; $ j ++ ) if ( $ txt [ $ i + $ j ] != $ pat [ $ j ] ) break ;
if ( $ j == $ M ) { echo ( " Pattern ▁ found ▁ at ▁ index ▁ $ i " . " STRNEWLINE " ) ; $ i = $ i + $ M ; } else if ( $ j == 0 ) $ i = $ i + 1 ; else
$ i = $ i + $ j ; } }
$ txt = " ABCEABCDABCEABCD " ; $ pat = " ABCD " ; search ( $ pat , $ txt ) ; ? >
function power ( $ x , $ y ) { $ temp ; if ( $ y == 0 ) return 1 ; $ temp = power ( $ x , $ y / 2 ) ; if ( $ y % 2 == 0 ) return $ temp * $ temp ; else { if ( $ y > 0 ) return $ x * $ temp * $ temp ; else return ( $ temp * $ temp ) / $ x ; } }
$ x = 2 ; $ y = -3 ; echo power ( $ x , $ y ) ; ? >
function getMedian ( $ ar1 , $ ar2 , $ n ) { $ i = 0 ; $ j = 0 ; $ count ; $ m1 = -1 ; $ m2 = -1 ;
for ( $ count = 0 ; $ count <= $ n ; $ count ++ ) {
if ( $ i == $ n ) { $ m1 = $ m2 ; $ m2 = $ ar2 [ 0 ] ; break ; }
else if ( $ j == $ n ) { $ m1 = $ m2 ; $ m2 = $ ar1 [ 0 ] ; break ; }
if ( $ ar1 [ $ i ] <= $ ar2 [ $ j ] ) {
$ m1 = $ m2 ; $ m2 = $ ar1 [ $ i ] ; $ i ++ ; } else {
$ m1 = $ m2 ; $ m2 = $ ar2 [ $ j ] ; $ j ++ ; } } return ( $ m1 + $ m2 ) / 2 ; }
$ ar1 = array ( 1 , 12 , 15 , 26 , 38 ) ; $ ar2 = array ( 2 , 13 , 17 , 30 , 45 ) ; $ n1 = sizeof ( $ ar1 ) ; $ n2 = sizeof ( $ ar2 ) ; if ( $ n1 == $ n2 ) echo ( " Median ▁ is ▁ " . getMedian ( $ ar1 , $ ar2 , $ n1 ) ) ; else echo ( " Doesn ' t ▁ work ▁ for ▁ arrays " . " of ▁ unequal ▁ size " ) ; ? >
function multiply ( $ x , $ y ) {
if ( $ y == 0 ) return 0 ;
if ( $ y > 0 ) return ( $ x + multiply ( $ x , $ y - 1 ) ) ;
if ( $ y < 0 ) return - multiply ( $ x , - $ y ) ; }
echo multiply ( 5 , -11 ) ; ? >
function poww ( $ a , $ b ) { if ( $ b == 0 ) return 1 ; $ answer = $ a ; $ increment = $ a ; $ i ; $ j ; for ( $ i = 1 ; $ i < $ b ; $ i ++ ) { for ( $ j = 1 ; $ j < $ a ; $ j ++ ) { $ answer += $ increment ; } $ increment = $ answer ; } return $ answer ; }
echo ( poww ( 5 , 3 ) ) ; ? >
function fact ( $ n ) { return ( $ n <= 1 ) ? 1 : $ n * fact ( $ n - 1 ) ; }
function findSmallerInRight ( $ str , $ low , $ high ) { $ countRight = 0 ; for ( $ i = $ low + 1 ; $ i <= $ high ; ++ $ i ) if ( $ str [ $ i ] < $ str [ $ low ] ) ++ $ countRight ; return $ countRight ; }
function findRank ( $ str ) { $ len = strlen ( $ str ) ; $ mul = fact ( $ len ) ; $ rank = 1 ; for ( $ i = 0 ; $ i < $ len ; ++ $ i ) { $ mul /= $ len - $ i ;
$ countRight = findSmallerInRight ( $ str , $ i , $ len - 1 ) ; $ rank += $ countRight * $ mul ; } return $ rank ; }
$ str = " string " ; echo findRank ( $ str ) ; ? >
function binomialCoeff ( $ n , $ k ) { $ res = 1 ;
if ( $ k > $ n - $ k ) $ k = $ n - $ k ;
for ( $ i = 0 ; $ i < $ k ; ++ $ i ) { $ res *= ( $ n - $ i ) ; $ res /= ( $ i + 1 ) ; } return $ res ; }
$ n = 8 ; $ k = 2 ; echo " ▁ Value ▁ of ▁ C ▁ ( $ n , ▁ $ k ) ▁ is ▁ " , binomialCoeff ( $ n , $ k ) ; ? >
function printPascal ( $ n ) { for ( $ line = 1 ; $ line <= $ n ; $ line ++ ) {
$ C = 1 ; for ( $ i = 1 ; $ i <= $ line ; $ i ++ ) {
print ( $ C . " " ) ; $ C = $ C * ( $ line - $ i ) / $ i ; } print ( " STRNEWLINE " ) ; } }
$ n = 5 ; printPascal ( $ n ) ; ? >
function exponential ( $ n , $ x ) {
$ sum = 1.0 ; for ( $ i = $ n - 1 ; $ i > 0 ; -- $ i ) $ sum = 1 + $ x * $ sum / $ i ; return $ sum ; }
$ n = 10 ; $ x = 1.0 ; echo ( " e ^ x ▁ = ▁ " . exponential ( $ n , $ x ) ) ; ? >
function printCombination ( $ arr , $ n , $ r ) {
$ data = Array ( ) ;
combinationUtil ( $ arr , $ n , $ r , 0 , $ data , 0 ) ; }
function combinationUtil ( $ arr , $ n , $ r , $ index , $ data , $ i ) {
if ( $ index == $ r ) { for ( $ j = 0 ; $ j < $ r ; $ j ++ ) echo $ data [ $ j ] , " ▁ " ; echo " STRNEWLINE " ; return ; }
if ( $ i >= $ n ) return ;
$ data [ $ index ] = $ arr [ $ i ] ; combinationUtil ( $ arr , $ n , $ r , $ index + 1 , $ data , $ i + 1 ) ;
combinationUtil ( $ arr , $ n , $ r , $ index , $ data , $ i + 1 ) ; }
$ arr = array ( 1 , 2 , 3 , 4 , 5 ) ; $ r = 3 ; $ n = sizeof ( $ arr ) ; printCombination ( $ arr , $ n , $ r ) ; ? >
function calcAngle ( $ h , $ m ) {
if ( $ h < 0 $ m < 0 $ h > 12 $ m > 60 ) echo " Wrong ▁ input " ; if ( $ h == 12 ) $ h = 0 ; if ( $ m == 60 ) { $ m = 0 ; $ h += 1 ; if ( $ h > 12 ) $ h = $ h - 12 ; }
$ hour_angle = 0.5 * ( $ h * 60 + $ m ) ; $ minute_angle = 6 * $ m ;
$ angle = abs ( $ hour_angle - $ minute_angle ) ;
$ angle = min ( 360 - $ angle , $ angle ) ; return $ angle ; }
echo calcAngle ( 9 , 60 ) , " STRNEWLINE " ; echo calcAngle ( 3 , 30 ) , " STRNEWLINE " ; ? >
function getSingle ( $ arr , $ n ) { $ ones = 0 ; $ twos = 0 ; $ common_bit_mask ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ twos = $ twos | ( $ ones & $ arr [ $ i ] ) ;
$ ones = $ ones ^ $ arr [ $ i ] ;
$ common_bit_mask = ~ ( $ ones & $ twos ) ;
$ ones &= $ common_bit_mask ;
$ twos &= $ common_bit_mask ; } return $ ones ; }
$ arr = array ( 3 , 3 , 2 , 3 ) ; $ n = sizeof ( $ arr ) ; echo " The ▁ element ▁ with ▁ single ▁ " . " occurrence ▁ is ▁ " , getSingle ( $ arr , $ n ) ; ? >
$ INT_SIZE = 32 ; function getSingle ( $ arr , $ n ) { global $ INT_SIZE ;
$ result = 0 ; $ x ; $ sum ;
for ( $ i = 0 ; $ i < $ INT_SIZE ; $ i ++ ) {
$ sum = 0 ; $ x = ( 1 << $ i ) ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) { if ( $ arr [ $ j ] & $ x ) $ sum ++ ; }
if ( ( $ sum % 3 ) != 0 ) $ result |= $ x ; } return $ result ; }
$ arr = array ( 12 , 1 , 12 , 3 , 12 , 1 , 1 , 2 , 3 , 2 , 2 , 3 , 7 ) ; $ n = sizeof ( $ arr ) ; echo " The ▁ element ▁ with ▁ single ▁ occurrence ▁ is ▁ " , getSingle ( $ arr , $ n ) ; ? >
function smallest ( $ x , $ y , $ z ) { $ c = 0 ; while ( $ x && $ y && $ z ) { $ x -- ; $ y -- ; $ z -- ; $ c ++ ; } return $ c ; }
$ x = 12 ; $ y = 15 ; $ z = 5 ; echo " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ " . smallest ( $ x , $ y , $ z ) ; ? >
function addOne ( $ x ) { return ( - ( ~ $ x ) ) ; }
echo addOne ( 13 ) ; ? >
function isPowerOfFour ( $ n ) { $ count = 0 ;
if ( $ n && ! ( $ n & ( $ n - 1 ) ) ) {
while ( $ n > 1 ) { $ n >>= 1 ; $ count += 1 ; }
return ( $ count % 2 == 0 ) ? 1 : 0 ; }
return 0 ; }
$ test_no = 64 ; if ( isPowerOfFour ( $ test_no ) ) echo $ test_no , " ▁ is ▁ a ▁ power ▁ of ▁ 4" ; else echo $ test_no , " ▁ not ▁ is ▁ a ▁ power ▁ of ▁ 4" ; ? >
function m_in ( $ x , $ y ) { return $ y ^ ( ( $ x ^ $ y ) & - ( $ x < $ y ) ) ; }
function m_ax ( $ x , $ y ) { return $ x ^ ( ( $ x ^ $ y ) & - ( $ x < $ y ) ) ; }
$ x = 15 ; $ y = 6 ; echo " Minimum ▁ of " , " ▁ " , $ x , " ▁ " , " and " , " ▁ " , $ y , " ▁ " , " ▁ is ▁ " , " ▁ " ; echo m_in ( $ x , $ y ) ; echo " Maximum of " , " " , $ x , " " , STRNEWLINE " and " , " " , $ y , " " , ▁ " is " echo m_ax ( $ x , $ y ) ; ? >
function countSetBits ( $ n ) { $ count = 0 ; while ( $ n ) { $ count += $ n & 1 ; $ n >>= 1 ; } return $ count ; }
$ i = 9 ; echo countSetBits ( $ i ) ; ? >
$ num_to_bits = array ( 0 , 1 , 1 , 2 , 1 , 2 , 2 , 3 , 1 , 2 , 2 , 3 , 2 , 3 , 3 , 4 ) ;
function countSetBitsRec ( $ num ) { global $ num_to_bits ; $ nibble = 0 ; if ( 0 == $ num ) return $ num_to_bits [ 0 ] ;
$ nibble = $ num & 0xf ;
return $ num_to_bits [ $ nibble ] + countSetBitsRec ( $ num >> 4 ) ; }
$ num = 31 ; echo ( countSetBitsRec ( $ num ) ) ; ? >
function nextPowerOf2 ( $ n ) { $ count = 0 ; if ( $ n && ! ( $ n & ( $ n - 1 ) ) ) return $ n ; while ( $ n != 0 ) { $ n >>= 1 ; $ count += 1 ; } return 1 << $ count ; }
$ n = 5 ; echo ( nextPowerOf2 ( $ n ) ) ; ? >
function nextPowerOf2 ( $ n ) { $ n -- ; $ n |= $ n >> 1 ; $ n |= $ n >> 2 ; $ n |= $ n >> 4 ; $ n |= $ n >> 8 ; $ n |= $ n >> 16 ; $ n ++ ; return $ n ; }
$ n = 5 ; echo nextPowerOf2 ( $ n ) ; ? >
function getParity ( $ n ) { $ parity = 0 ; while ( $ n ) { $ parity = ! $ parity ; $ n = $ n & ( $ n - 1 ) ; } return $ parity ; }
$ n = 7 ; echo " Parity ▁ of ▁ no ▁ " , $ n , " ▁ = ▁ " , getParity ( $ n ) ? " odd " : " even " ; ? >
function Log2 ( $ x ) { return ( log10 ( $ x ) / log10 ( 2 ) ) ; }
function isPowerOfTwo ( $ n ) { return ( ceil ( Log2 ( $ n ) ) == floor ( Log2 ( $ n ) ) ) ; }
if ( isPowerOfTwo ( 31 ) ) echo " Yes STRNEWLINE " ; else echo " No STRNEWLINE " ; if ( isPowerOfTwo ( 64 ) ) echo " Yes STRNEWLINE " ; else echo " No STRNEWLINE " ; ? >
function isPowerOfTwo ( $ x ) {
return $ x && ( ! ( $ x & ( $ x - 1 ) ) ) ; }
if ( isPowerOfTwo ( 31 ) ) echo " Yes STRNEWLINE " ; else echo " No STRNEWLINE " ; if ( isPowerOfTwo ( 64 ) ) echo " Yes STRNEWLINE " ; else echo " No STRNEWLINE " ; ? >
function swapBits ( $ x ) {
$ even_bits = $ x & 0xAAAAAAAA ;
$ odd_bits = $ x & 0x55555555 ;
$ even_bits >>= 1 ;
$ odd_bits <<= 1 ;
return ( $ even_bits $ odd_bits ) ; }
$ x = 23 ;
echo swapBits ( $ x ) ; ? >
function isPowerOfTwo ( $ n ) { return $ n && ( ! ( $ n & ( $ n - 1 ) ) ) ; }
function findPosition ( $ n ) { if ( ! isPowerOfTwo ( $ n ) ) return -1 ; $ i = 1 ; $ pos = 1 ;
while ( ! ( $ i & $ n ) ) {
$ i = $ i << 1 ;
++ $ pos ; } return $ pos ; }
$ n = 16 ; $ pos = findPosition ( $ n ) ; if ( ( $ pos == -1 ) == true ) echo " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Invalid number " , ▁ " " ; STRNEWLINE else STRNEWLINE echo ▁ " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Position " , ▁ $ pos , ▁ " " $ n = 12 ; $ pos = findPosition ( $ n ) ; if ( ( $ pos == -1 ) == true ) echo " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Invalid number " , ▁ " " ; STRNEWLINE else STRNEWLINE echo ▁ " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Position " , ▁ $ pos , ▁ " " $ n = 128 ; $ pos = findPosition ( $ n ) ; if ( ( $ pos == -1 ) == true ) echo " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Invalid number " , ▁ " " ; STRNEWLINE else STRNEWLINE echo ▁ " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Position " , ▁ $ pos , ▁ " " ? >
function segregate0and1 ( & $ arr , $ size ) {
$ left = 0 ; $ right = $ size - 1 ; while ( $ left < $ right ) {
while ( $ arr [ $ left ] == 0 && $ left < $ right ) $ left ++ ;
while ( $ arr [ $ right ] == 1 && $ left < $ right ) $ right -- ;
if ( $ left < $ right ) { $ arr [ $ left ] = 0 ; $ arr [ $ right ] = 1 ; $ left ++ ; $ right -- ; } } }
$ arr = array ( 0 , 1 , 0 , 1 , 1 , 1 ) ; $ arr_size = sizeof ( $ arr ) ; segregate0and1 ( $ arr , $ arr_size ) ; printf ( " Array ▁ after ▁ segregation ▁ is ▁ " ) ; for ( $ i = 0 ; $ i < 6 ; $ i ++ ) echo ( $ arr [ $ i ] . " ▁ " ) ; ? >
function nextGreatest ( & $ arr , $ size ) {
$ max_from_right = $ arr [ $ size - 1 ] ;
$ arr [ $ size - 1 ] = -1 ;
for ( $ i = $ size - 2 ; $ i >= 0 ; $ i -- ) {
$ temp = $ arr [ $ i ] ;
$ arr [ $ i ] = $ max_from_right ;
if ( $ max_from_right < $ temp ) $ max_from_right = $ temp ; } }
function printArray ( $ arr , $ size ) { for ( $ i = 0 ; $ i < $ size ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; echo " STRNEWLINE " ; }
$ arr = array ( 16 , 17 , 4 , 3 , 5 , 2 ) ; $ size = count ( $ arr ) ; nextGreatest ( $ arr , $ size ) ; echo " The ▁ modified ▁ array ▁ is : ▁ STRNEWLINE " ; printArray ( $ arr , $ size ) ; ? >
function maxDiff ( $ arr , $ arr_size ) { $ max_diff = $ arr [ 1 ] - $ arr [ 0 ] ; for ( $ i = 0 ; $ i < $ arr_size ; $ i ++ ) { for ( $ j = $ i + 1 ; $ j < $ arr_size ; $ j ++ ) { if ( $ arr [ $ j ] - $ arr [ $ i ] > $ max_diff ) $ max_diff = $ arr [ $ j ] - $ arr [ $ i ] ; } } return $ max_diff ; }
$ arr = array ( 1 , 2 , 90 , 10 , 110 ) ; $ n = sizeof ( $ arr ) ;
echo " Maximum ▁ difference ▁ is ▁ " . maxDiff ( $ arr , $ n ) ;
function findMaximum ( $ arr , $ low , $ high ) {
if ( $ low == $ high ) return $ arr [ $ low ] ;
if ( ( $ high == $ low + 1 ) && $ arr [ $ low ] >= $ arr [ $ high ] ) return $ arr [ $ low ] ;
if ( ( $ high == $ low + 1 ) && $ arr [ $ low ] < $ arr [ $ high ] ) return $ arr [ $ high ] ; $ mid = ( $ low + $ high ) / 2 ;
if ( $ arr [ $ mid ] > $ arr [ $ mid + 1 ] && $ arr [ $ mid ] > $ arr [ $ mid - 1 ] ) return $ arr [ $ mid ] ;
if ( $ arr [ $ mid ] > $ arr [ $ mid + 1 ] && $ arr [ $ mid ] < $ arr [ $ mid - 1 ] ) return findMaximum ( $ arr , $ low , $ mid - 1 ) ;
else return findMaximum ( $ arr , $ mid + 1 , $ high ) ; }
$ arr = array ( 1 , 3 , 50 , 10 , 9 , 7 , 6 ) ; $ n = sizeof ( $ arr ) ; echo ( " The ▁ maximum ▁ element ▁ is ▁ " ) ; echo ( findMaximum ( $ arr , 0 , $ n -1 ) ) ; ? >
function getMissingNo ( $ a , $ n ) { $ total = ( $ n + 1 ) * ( $ n + 2 ) / 2 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ total -= $ a [ $ i ] ; return $ total ; }
$ a = array ( 1 , 2 , 4 , 5 , 6 ) ; $ miss = getMissingNo ( $ a , 5 ) ; echo ( $ miss ) ; ? >
function printTwoElements ( $ arr , $ size ) { $ i ; echo " The ▁ repeating ▁ element ▁ is " , " ▁ " ; for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { if ( $ arr [ abs ( $ arr [ $ i ] ) - 1 ] > 0 ) $ arr [ abs ( $ arr [ $ i ] ) - 1 ] = - $ arr [ abs ( $ arr [ $ i ] ) - 1 ] ; else echo ( abs ( $ arr [ $ i ] ) ) ; } echo " and the missing element is " ; for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { if ( $ arr [ $ i ] > 0 ) echo ( $ i + 1 ) ; } }
$ arr = array ( 7 , 3 , 4 , 5 , 5 , 6 , 2 ) ; $ n = count ( $ arr ) ; printTwoElements ( $ arr , $ n ) ; ? >
function printTwoOdd ( $ arr , $ size ) {
$ xor2 = $ arr [ 0 ] ;
$ set_bit_no ; $ i ; $ n = $ size - 2 ; $ x = 0 ; $ y = 0 ;
for ( $ i = 1 ; $ i < $ size ; $ i ++ ) $ xor2 = $ xor2 ^ $ arr [ $ i ] ;
$ set_bit_no = $ xor2 & ~ ( $ xor2 - 1 ) ;
for ( $ i = 0 ; $ i < $ size ; $ i ++ ) {
if ( $ arr [ $ i ] & $ set_bit_no ) $ x = $ x ^ $ arr [ $ i ] ;
else $ y = $ y ^ $ arr [ $ i ] ; } echo " The ▁ two ▁ ODD ▁ elements ▁ are ▁ " , $ x , " ▁ & ▁ " , $ y ; }
$ arr = array ( 4 , 2 , 4 , 5 , 2 , 3 , 3 , 1 ) ; $ arr_size = sizeof ( $ arr ) ; printTwoOdd ( $ arr , $ arr_size ) ; ? >
function findPair ( & $ arr , $ size , $ n ) {
$ i = 0 ; $ j = 1 ;
while ( $ i < $ size && $ j < $ size ) { if ( $ i != $ j && $ arr [ $ j ] - $ arr [ $ i ] == $ n ) { echo " Pair ▁ Found : ▁ " . " ( " . $ arr [ $ i ] . " , ▁ " . $ arr [ $ j ] . " ) " ; return true ; } else if ( $ arr [ $ j ] - $ arr [ $ i ] < $ n ) $ j ++ ; else $ i ++ ; } echo " No ▁ such ▁ pair " ; return false ; }
$ arr = array ( 1 , 8 , 30 , 40 , 100 ) ; $ size = sizeof ( $ arr ) ; $ n = 60 ; findPair ( $ arr , $ size , $ n ) ; ? >
function findFourElements ( $ A , $ n , $ X ) {
for ( $ i = 0 ; $ i < $ n - 3 ; $ i ++ ) {
for ( $ j = $ i + 1 ; $ j < $ n - 2 ; $ j ++ ) {
for ( $ k = $ j + 1 ; $ k < $ n - 1 ; $ k ++ ) {
for ( $ l = $ k + 1 ; $ l < $ n ; $ l ++ ) if ( $ A [ $ i ] + $ A [ $ j ] + $ A [ $ k ] + $ A [ $ l ] == $ X ) echo $ A [ $ i ] , " , ▁ " , $ A [ $ j ] , " , ▁ " , $ A [ $ k ] , " , ▁ " , $ A [ $ l ] ; } } } }
$ A = array ( 10 , 20 , 30 , 40 , 1 , 2 ) ; $ n = sizeof ( $ A ) ; $ X = 91 ; findFourElements ( $ A , $ n , $ X ) ; ? >
$ cola = 2 ; $ rowa = 3 ; $ colb = 3 ; $ rowb = 2 ;
function Kroneckerproduct ( $ A , $ B ) { global $ cola ; global $ rowa ; global $ colb ; global $ rowb ; $ C ;
for ( $ i = 0 ; $ i < $ rowa ; $ i ++ ) {
for ( $ k = 0 ; $ k < $ rowb ; $ k ++ ) {
for ( $ j = 0 ; $ j < $ cola ; $ j ++ ) {
for ( $ l = 0 ; $ l < $ colb ; $ l ++ ) {
$ C [ $ i + $ l + 1 ] [ $ j + $ k + 1 ] = $ A [ $ i ] [ $ j ] * $ B [ $ k ] [ $ l ] ; echo ( $ C [ $ i + $ l + 1 ] [ $ j + $ k + 1 ] ) , " TABSYMBOL " ; } } echo " " } } }
$ A = array ( array ( 1 , 2 ) , array ( 3 , 4 ) , array ( 1 , 0 ) ) ; $ B = array ( array ( 0 , 5 , 2 ) , array ( 6 , 7 , 3 ) ) ; Kroneckerproduct ( $ A , $ B ) ; ? >
function Identity ( $ num ) { $ row ; $ col ; for ( $ row = 0 ; $ row < $ num ; $ row ++ ) { for ( $ col = 0 ; $ col < $ num ; $ col ++ ) {
if ( $ row == $ col ) echo 1 , " ▁ " ; else echo 0 , " ▁ " ; } echo " " } return 0 ; }
$ size = 5 ; identity ( $ size ) ; ? >
function subtract ( & $ A , & $ B , & $ C ) { $ N = 4 ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ N ; $ j ++ ) $ C [ $ i ] [ $ j ] = $ A [ $ i ] [ $ j ] - $ B [ $ i ] [ $ j ] ; }
$ N = 4 ; $ A = array ( array ( 1 , 1 , 1 , 1 ) , array ( 2 , 2 , 2 , 2 ) , array ( 3 , 3 , 3 , 3 ) , array ( 4 , 4 , 4 , 4 ) ) ; $ B = array ( array ( 1 , 1 , 1 , 1 ) , array ( 2 , 2 , 2 , 2 ) , array ( 3 , 3 , 3 , 3 ) , array ( 4 , 4 , 4 , 4 ) ) ; subtract ( $ A , $ B , $ C ) ; echo " Result ▁ matrix ▁ is ▁ STRNEWLINE " ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { for ( $ j = 0 ; $ j < $ N ; $ j ++ ) { echo $ C [ $ i ] [ $ j ] ; echo " ▁ " ; } echo " STRNEWLINE " ; } ? >
