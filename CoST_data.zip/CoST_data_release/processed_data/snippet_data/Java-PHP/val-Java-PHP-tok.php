function calculateSpan ( $ price , $ n , $ S ) {
$ S [ 0 ] = 1 ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) {
$ S [ $ i ] = 1 ;
for ( $ j = $ i - 1 ; ( $ j >= 0 ) && ( $ price [ $ i ] >= $ price [ $ j ] ) ; $ j -- ) $ S [ $ i ] ++ ; }
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ S [ $ i ] . " ▁ " ; ; }
$ price = array ( 10 , 4 , 5 , 90 , 120 , 80 ) ; $ n = count ( $ price ) ; $ S = array ( $ n ) ;
calculateSpan ( $ price , $ n , $ S ) ; ? >
function findSubArray ( & $ arr , $ n ) { $ sum = 0 ; $ maxsize = -1 ;
for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) { $ sum = ( $ arr [ $ i ] == 0 ) ? -1 : 1 ;
for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) { ( $ arr [ $ j ] == 0 ) ? ( $ sum += -1 ) : ( $ sum += 1 ) ;
if ( $ sum == 0 && $ maxsize < $ j - $ i + 1 ) { $ maxsize = $ j - $ i + 1 ; $ startindex = $ i ; } } } if ( $ maxsize == -1 ) echo " No ▁ such ▁ subarray " ; else echo $ startindex . " ▁ to ▁ " . ( $ startindex + $ maxsize - 1 ) ; return $ maxsize ; }
$ arr = array ( 1 , 0 , 0 , 1 , 0 , 1 , 1 ) ; $ size = sizeof ( $ arr ) ; findSubArray ( $ arr , $ size ) ; ? >
function leftRotatebyOne ( & $ arr , $ n ) { $ temp = $ arr [ 0 ] ; for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) $ arr [ $ i ] = $ arr [ $ i + 1 ] ; $ arr [ $ n - 1 ] = $ temp ; }
function leftRotate ( & $ arr , $ d , $ n ) { for ( $ i = 0 ; $ i < $ d ; $ i ++ ) leftRotatebyOne ( $ arr , $ n ) ; }
function printArray ( & $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; }
$ arr = array ( 1 , 2 , 3 , 4 , 5 , 6 , 7 ) ; $ n = sizeof ( $ arr ) ; leftRotate ( $ arr , 2 , $ n ) ; printArray ( $ arr , $ n ) ; ? >
function print2Smallest ( $ arr , $ arr_size ) { $ INT_MAX = 2147483647 ;
if ( $ arr_size < 2 ) { echo ( " ▁ Invalid ▁ Input ▁ " ) ; return ; } $ first = $ second = $ INT_MAX ; for ( $ i = 0 ; $ i < $ arr_size ; $ i ++ ) {
if ( $ arr [ $ i ] < $ first ) { $ second = $ first ; $ first = $ arr [ $ i ] ; }
else if ( $ arr [ $ i ] < $ second && $ arr [ $ i ] != $ first ) $ second = $ arr [ $ i ] ; } if ( $ second == $ INT_MAX ) echo ( " There ▁ is ▁ no ▁ second ▁ smallest ▁ element STRNEWLINE " ) ; else echo " The ▁ smallest ▁ element ▁ is ▁ " , $ first , " ▁ and ▁ second ▁ Smallest ▁ element ▁ is ▁ " , $ second ; }
$ arr = array ( 12 , 13 , 1 , 10 , 34 , 1 ) ; $ n = count ( $ arr ) ; print2Smallest ( $ arr , $ n ) ? >
function findFirstMissing ( $ array , $ start , $ end ) { if ( $ start > $ end ) return $ end + 1 ; if ( $ start != $ array [ $ start ] ) return $ start ; $ mid = ( $ start + $ end ) / 2 ;
if ( $ array [ $ mid ] == $ mid ) return findFirstMissing ( $ array , $ mid + 1 , $ end ) ; return findFirstMissing ( $ array , $ start , $ mid ) ; }
$ arr = array ( 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 10 ) ; $ n = count ( $ arr ) ; echo " Smallest ▁ missing ▁ element ▁ is ▁ " , findFirstMissing ( $ arr , 2 , $ n - 1 ) ; ? >
function getInvCount ( & $ arr , $ n ) { $ inv_count = 0 ; for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) if ( $ arr [ $ i ] > $ arr [ $ j ] ) $ inv_count ++ ; return $ inv_count ; }
$ arr = array ( 1 , 20 , 6 , 4 , 5 ) ; $ n = sizeof ( $ arr ) ; echo " Number ▁ of ▁ inversions ▁ are ▁ " , getInvCount ( $ arr , $ n ) ; ? >
function printUnsorted ( & $ arr , $ n ) { $ s = 0 ; $ e = $ n - 1 ;
for ( $ s = 0 ; $ s < $ n - 1 ; $ s ++ ) { if ( $ arr [ $ s ] > $ arr [ $ s + 1 ] ) break ; } if ( $ s == $ n - 1 ) { echo " The ▁ complete ▁ array ▁ is ▁ sorted " ; return ; }
for ( $ e = $ n - 1 ; $ e > 0 ; $ e -- ) { if ( $ arr [ $ e ] < $ arr [ $ e - 1 ] ) break ; }
$ max = $ arr [ $ s ] ; $ min = $ arr [ $ s ] ; for ( $ i = $ s + 1 ; $ i <= $ e ; $ i ++ ) { if ( $ arr [ $ i ] > $ max ) $ max = $ arr [ $ i ] ; if ( $ arr [ $ i ] < $ min ) $ min = $ arr [ $ i ] ; }
for ( $ i = 0 ; $ i < $ s ; $ i ++ ) { if ( $ arr [ $ i ] > $ min ) { $ s = $ i ; break ; } }
for ( $ i = $ n - 1 ; $ i >= $ e + 1 ; $ i -- ) { if ( $ arr [ $ i ] < $ max ) { $ e = $ i ; break ; } }
echo " ▁ The ▁ unsorted ▁ subarray ▁ which ▁ makes ▁ " . " the ▁ given ▁ array ▁ " . " STRNEWLINE " . " ▁ sorted ▁ lies ▁ between ▁ the ▁ indees ▁ " . $ s . " ▁ and ▁ " . $ e ; return ; } $ arr = array ( 10 , 12 , 20 , 30 , 25 , 40 , 32 , 31 , 35 , 50 , 60 ) ; $ arr_size = sizeof ( $ arr ) ; printUnsorted ( $ arr , $ arr_size ) ; ? >
function findElement ( $ arr , $ n , $ key ) { $ i ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] == $ key ) return $ i ; return -1 ; }
$ arr = array ( 12 , 34 , 10 , 6 , 40 ) ; $ n = sizeof ( $ arr ) ;
$ key = 40 ; $ position = findElement ( $ arr , $ n , $ key ) ; if ( $ position == - 1 ) echo ( " Element ▁ not ▁ found " ) ; else echo ( " Element ▁ Found ▁ at ▁ Position : ▁ " . ( $ position + 1 ) ) ; ? >
function equilibrium ( $ arr , $ n ) {
$ sum = 0 ;
$ leftsum = 0 ;
for ( $ i = 0 ; $ i < $ n ; ++ $ i ) $ sum += $ arr [ $ i ] ; for ( $ i = 0 ; $ i < $ n ; ++ $ i ) {
$ sum -= $ arr [ $ i ] ; if ( $ leftsum == $ sum ) return $ i ; $ leftsum += $ arr [ $ i ] ; }
return -1 ; }
$ arr = array ( -7 , 1 , 5 , 2 , -4 , 3 , 0 ) ; $ arr_size = sizeof ( $ arr ) ; echo " First ▁ equilibrium ▁ index ▁ is ▁ " , equilibrium ( $ arr , $ arr_size ) ; ? >
function ceilSearch ( $ arr , $ low , $ high , $ x ) {
if ( $ x <= $ arr [ $ low ] ) return $ low ;
for ( $ i = $ low ; $ i < $ high ; $ i ++ ) { if ( $ arr [ $ i ] == $ x ) return $ i ;
if ( $ arr [ $ i ] < $ x && $ arr [ $ i + 1 ] >= $ x ) return $ i + 1 ; }
return -1 ; }
$ arr = array ( 1 , 2 , 8 , 10 , 10 , 12 , 19 ) ; $ n = sizeof ( $ arr ) ; $ x = 3 ; $ index = ceilSearch ( $ arr , 0 , $ n - 1 , $ x ) ; if ( $ index == -1 ) echo ( " Ceiling ▁ of ▁ " . $ x . " ▁ doesn ' t ▁ exist ▁ in ▁ array ▁ " ) ; else echo ( " ceiling ▁ of ▁ " . $ x . " ▁ is ▁ " . $ arr [ $ index ] ) ; ? >
function isMajority ( $ arr , $ n , $ x ) { $ i ;
$ last_index = $ n % 2 ? ( $ n / 2 + 1 ) : ( $ n / 2 ) ;
for ( $ i = 0 ; $ i < $ last_index ; $ i ++ ) {
if ( $ arr [ $ i ] == $ x && $ arr [ $ i + $ n / 2 ] == $ x ) return 1 ; } return 0 ; }
$ arr = array ( 1 , 2 , 3 , 4 , 4 , 4 , 4 ) ; $ n = sizeof ( $ arr ) ; $ x = 4 ; if ( isMajority ( $ arr , $ n , $ x ) ) echo $ x , " ▁ appears ▁ more ▁ than ▁ " , floor ( $ n / 2 ) , " ▁ times ▁ in ▁ arr [ ] " ; else echo $ x , " does ▁ not ▁ appear ▁ more ▁ than ▁ " , floor ( $ n / 2 ) , " times ▁ in ▁ arr [ ] " ; ? >
function findPeakUtil ( $ arr , $ low , $ high , $ n ) {
$ mid = $ low + ( $ high - $ low ) / 2 ;
if ( ( $ mid == 0 $ arr [ $ mid - 1 ] <= $ arr [ $ mid ] ) && ( $ mid == $ n - 1 $ arr [ $ mid + 1 ] <= $ arr [ $ mid ] ) ) return $ mid ;
else if ( $ mid > 0 && $ arr [ $ mid - 1 ] > $ arr [ $ mid ] ) return findPeakUtil ( $ arr , $ low , ( $ mid - 1 ) , $ n ) ;
else return ( findPeakUtil ( $ arr , ( $ mid + 1 ) , $ high , $ n ) ) ; }
function findPeak ( $ arr , $ n ) { return floor ( findPeakUtil ( $ arr , 0 , $ n - 1 , $ n ) ) ; }
$ arr = array ( 1 , 3 , 20 , 4 , 1 , 0 ) ; $ n = sizeof ( $ arr ) ; echo " Index ▁ of ▁ a ▁ peak ▁ point ▁ is ▁ " , findPeak ( $ arr , $ n ) ; ? >
function printRepeating ( $ arr , $ size ) { $ count = array_fill ( 0 , $ size , 0 ) ; echo " Repeated ▁ elements ▁ are ▁ " ; for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { if ( $ count [ $ arr [ $ i ] ] == 1 ) echo $ arr [ $ i ] . " ▁ " ; else $ count [ $ arr [ $ i ] ] ++ ; } }
$ arr = array ( 4 , 2 , 4 , 5 , 2 , 3 , 1 ) ; $ arr_size = count ( $ arr ) ; printRepeating ( $ arr , $ arr_size ) ; ? >
function linearSearch ( $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] == $ i ) return $ i ; }
return -1 ; }
$ arr = array ( -10 , -1 , 0 , 3 , 10 , 11 , 30 , 50 , 100 ) ; $ n = count ( $ arr ) ; echo " Fixed ▁ Point ▁ is ▁ " . linearSearch ( $ arr , $ n ) ; ? >
function subArraySum ( $ arr , $ n , $ sum ) { $ curr_sum ; $ i ; $ j ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ curr_sum = $ arr [ $ i ] ;
for ( $ j = $ i + 1 ; $ j <= $ n ; $ j ++ ) { if ( $ curr_sum == $ sum ) { echo " Sum ▁ found ▁ between ▁ indexes ▁ " , $ i , " ▁ and ▁ " , $ j - 1 ; return 1 ; } if ( $ curr_sum > $ sum $ j == $ n ) break ; $ curr_sum = $ curr_sum + $ arr [ $ j ] ; } } echo " No ▁ subarray ▁ found " ; return 0 ; }
$ arr = array ( 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 ) ; $ n = sizeof ( $ arr ) ; $ sum = 23 ; subArraySum ( $ arr , $ n , $ sum ) ; return 0 ; ? >
function subArraySum ( $ arr , $ n , $ sum ) {
$ curr_sum = $ arr [ 0 ] ; $ start = 0 ; $ i ;
for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) {
while ( $ curr_sum > $ sum and $ start < $ i - 1 ) { $ curr_sum = $ curr_sum - $ arr [ $ start ] ; $ start ++ ; }
if ( $ curr_sum == $ sum ) { echo " Sum ▁ found ▁ between ▁ indexes " , " ▁ " , $ start , " ▁ " , " and ▁ " , " ▁ " , $ i - 1 ; return 1 ; }
if ( $ i < $ n ) $ curr_sum = $ curr_sum + $ arr [ $ i ] ; }
echo " No ▁ subarray ▁ found " ; return 0 ; }
$ arr = array ( 15 , 2 , 4 , 8 , 9 , 5 , 10 , 23 ) ; $ n = count ( $ arr ) ; $ sum = 23 ; subArraySum ( $ arr , $ n , $ sum ) ;
function MatrixChainOrder ( & $ p , $ i , $ j ) { if ( $ i == $ j ) return 0 ; $ min = PHP_INT_MAX ;
for ( $ k = $ i ; $ k < $ j ; $ k ++ ) { $ count = MatrixChainOrder ( $ p , $ i , $ k ) + MatrixChainOrder ( $ p , $ k + 1 , $ j ) + $ p [ $ i - 1 ] * $ p [ $ k ] * $ p [ $ j ] ; if ( $ count < $ min ) $ min = $ count ; }
return $ min ; }
$ arr = array ( 1 , 2 , 3 , 4 , 3 ) ; $ n = sizeof ( $ arr ) ; echo " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " . MatrixChainOrder ( $ arr , 1 , $ n - 1 ) ; ? >
function MatrixChainOrder ( $ p , $ n ) {
$ m [ ] [ ] = array ( $ n , $ n ) ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) $ m [ $ i ] [ $ i ] = 0 ;
for ( $ L = 2 ; $ L < $ n ; $ L ++ ) { for ( $ i = 1 ; $ i < $ n - $ L + 1 ; $ i ++ ) { $ j = $ i + $ L - 1 ; if ( $ j == $ n ) continue ; $ m [ $ i ] [ $ j ] = PHP_INT_MAX ; for ( $ k = $ i ; $ k <= $ j - 1 ; $ k ++ ) {
$ q = $ m [ $ i ] [ $ k ] + $ m [ $ k + 1 ] [ $ j ] + $ p [ $ i - 1 ] * $ p [ $ k ] * $ p [ $ j ] ; if ( $ q < $ m [ $ i ] [ $ j ] ) $ m [ $ i ] [ $ j ] = $ q ; } } } return $ m [ 1 ] [ $ n - 1 ] ; }
$ arr = array ( 1 , 2 , 3 , 4 ) ; $ size = sizeof ( $ arr ) ; echo " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " . MatrixChainOrder ( $ arr , $ size ) ; ? >
function knapSack ( $ W , $ wt , $ val , $ n ) {
if ( $ n == 0 $ W == 0 ) return 0 ;
if ( $ wt [ $ n - 1 ] > $ W ) return knapSack ( $ W , $ wt , $ val , $ n - 1 ) ;
else return max ( $ val [ $ n - 1 ] + knapSack ( $ W - $ wt [ $ n - 1 ] , $ wt , $ val , $ n - 1 ) , knapSack ( $ W , $ wt , $ val , $ n -1 ) ) ; }
$ val = array ( 60 , 100 , 120 ) ; $ wt = array ( 10 , 20 , 30 ) ; $ W = 50 ; $ n = count ( $ val ) ; echo knapSack ( $ W , $ wt , $ val , $ n ) ; ? >
function counts ( $ n ) {
for ( $ j = 0 ; $ j < $ n + 1 ; $ j ++ ) $ table [ $ j ] = 0 ;
$ table [ 0 ] = 1 ;
for ( $ i = 3 ; $ i <= $ n ; $ i ++ ) $ table [ $ i ] += $ table [ $ i - 3 ] ; for ( $ i = 5 ; $ i <= $ n ; $ i ++ ) $ table [ $ i ] += $ table [ $ i - 5 ] ; for ( $ i = 10 ; $ i <= $ n ; $ i ++ ) $ table [ $ i ] += $ table [ $ i - 10 ] ; return $ table [ $ n ] ; }
$ n = 20 ; echo " Count ▁ for ▁ " ; echo ( $ n ) ; echo ( " ▁ is ▁ " ) ; echo counts ( $ n ) ; $ n = 13 ; echo ( " STRNEWLINE " ) ; echo " Count ▁ for ▁ " ; echo ( $ n ) ; echo ( " ▁ is ▁ " ) ; echo counts ( $ n ) ; ? >
function search ( $ pat , $ txt ) { $ M = strlen ( $ pat ) ; $ N = strlen ( $ txt ) ;
for ( $ i = 0 ; $ i <= $ N - $ M ; $ i ++ ) {
for ( $ j = 0 ; $ j < $ M ; $ j ++ ) if ( $ txt [ $ i + $ j ] != $ pat [ $ j ] ) break ;
if ( $ j == $ M ) echo " Pattern ▁ found ▁ at ▁ index ▁ " , $ i . " STRNEWLINE " ; } }
$ txt = " AABAACAADAABAAABAA " ; $ pat = " AABA " ; search ( $ pat , $ txt ) ; ? >
$ d = 256 ;
function search ( $ pat , $ txt , $ q ) { $ M = strlen ( $ pat ) ; $ N = strlen ( $ txt ) ; $ i ; $ j ;
$ p = 0 ;
$ t = 0 ; $ h = 1 ; $ d = 1 ;
for ( $ i = 0 ; $ i < $ M - 1 ; $ i ++ ) $ h = ( $ h * $ d ) % $ q ;
for ( $ i = 0 ; $ i < $ M ; $ i ++ ) { $ p = ( $ d * $ p + $ pat [ $ i ] ) % $ q ; $ t = ( $ d * $ t + $ txt [ $ i ] ) % $ q ; }
for ( $ i = 0 ; $ i <= $ N - $ M ; $ i ++ ) {
if ( $ p == $ t ) {
for ( $ j = 0 ; $ j < $ M ; $ j ++ ) { if ( $ txt [ $ i + $ j ] != $ pat [ $ j ] ) break ; }
if ( $ j == $ M ) echo " Pattern ▁ found ▁ at ▁ index ▁ " , $ i , " STRNEWLINE " ; }
if ( $ i < $ N - $ M ) { $ t = ( $ d * ( $ t - $ txt [ $ i ] * $ h ) + $ txt [ $ i + $ M ] ) % $ q ;
if ( $ t < 0 ) $ t = ( $ t + $ q ) ; } } }
$ txt = " GEEKS ▁ FOR ▁ GEEKS " ; $ pat = " GEEK " ;
$ q = 101 ;
search ( $ pat , $ txt , $ q ) ; ? >
function power ( $ x , $ y ) { if ( $ y == 0 ) return 1 ; else if ( $ y % 2 == 0 ) return power ( $ x , ( int ) $ y / 2 ) * power ( $ x , ( int ) $ y / 2 ) ; else return $ x * power ( $ x , ( int ) $ y / 2 ) * power ( $ x , ( int ) $ y / 2 ) ; }
$ x = 2 ; $ y = 3 ; echo power ( $ x , $ y ) ; ? >
function isLucky ( $ n ) { $ counter = 2 ;
$ next_position = $ n ; if ( $ counter > $ n ) return 1 ; if ( $ n % $ counter == 0 ) return 0 ;
$ next_position -= $ next_position / $ counter ; $ counter ++ ; return isLucky ( $ next_position ) ; }
$ x = 5 ; if ( isLucky ( $ x ) ) echo $ x , " ▁ is ▁ a ▁ lucky ▁ no . " ; else echo $ x , " ▁ is ▁ not ▁ a ▁ lucky ▁ no . " ; ? >
function squareRoot ( $ n ) {
$ x = $ n ; $ y = 1 ;
$ e = 0.000001 ; while ( $ x - $ y > $ e ) { $ x = ( $ x + $ y ) / 2 ; $ y = $ n / $ x ; } return $ x ; }
{ $ n = 50 ; echo " Square ▁ root ▁ of ▁ $ n ▁ is ▁ " , squareRoot ( $ n ) ; } ? >
function multiply ( $ x , $ y ) { if ( $ y ) return ( $ x + multiply ( $ x , $ y - 1 ) ) ; else return 0 ; }
function p_ow ( $ a , $ b ) { if ( $ b ) return multiply ( $ a , p_ow ( $ a , $ b - 1 ) ) ; else return 1 ; }
echo pow ( 5 , 3 ) ; ? >
function getAvg ( $ x ) { static $ sum ; static $ n ; $ sum += $ x ; return ( ( ( float ) $ sum ) / ++ $ n ) ; }
function streamAvg ( $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ avg = getAvg ( $ arr [ $ i ] ) ; echo " Average ▁ of ▁ " . ( $ i + 1 ) . " ▁ numbers ▁ is ▁ " . $ avg . " ▁ STRNEWLINE " ; } return ; }
$ arr = array ( 10 , 20 , 30 , 40 , 50 , 60 ) ; $ n = sizeof ( $ arr ) / sizeof ( $ arr [ 0 ] ) ; streamAvg ( $ arr , $ n ) ; ? >
function count1 ( $ n ) {
if ( $ n < 3 ) return $ n ; if ( $ n >= 3 && $ n < 10 ) return $ n - 1 ;
$ po = 1 ; for ( $ x = intval ( $ n / $ po ) ; $ x > 9 ; $ x = intval ( $ n / $ po ) ) $ po = $ po * 10 ;
$ msd = intval ( $ n / $ po ) ; if ( $ msd != 3 )
return count1 ( $ msd ) * count1 ( $ po - 1 ) + count1 ( $ msd ) + count1 ( $ n % $ po ) ; else
return count1 ( $ msd * $ po - 1 ) ; }
echo count1 ( 578 ) ; ? >
function printPascal ( $ n ) {
$ arr = array ( array ( ) ) ;
for ( $ line = 0 ; $ line < $ n ; $ line ++ ) {
for ( $ i = 0 ; $ i <= $ line ; $ i ++ ) {
if ( $ line == $ i $ i == 0 ) $ arr [ $ line ] [ $ i ] = 1 ;
else $ arr [ $ line ] [ $ i ] = $ arr [ $ line - 1 ] [ $ i - 1 ] + $ arr [ $ line - 1 ] [ $ i ] ; echo $ arr [ $ line ] [ $ i ] . " " ; } echo " " } }
$ n = 5 ; printPascal ( $ n ) ; ? >
function primeFactors ( $ n ) {
while ( $ n % 2 == 0 ) { echo 2 , " ▁ " ; $ n = $ n / 2 ; }
for ( $ i = 3 ; $ i <= sqrt ( $ n ) ; $ i = $ i + 2 ) {
while ( $ n % $ i == 0 ) { echo $ i , " " ; $ n = $ n / $ i ; } }
if ( $ n > 2 ) echo $ n , " ▁ " ; }
$ n = 315 ; primeFactors ( $ n ) ; ? >
function printCombination ( $ arr , $ n , $ r ) {
$ data = array ( ) ;
combinationUtil ( $ arr , $ data , 0 , $ n - 1 , 0 , $ r ) ; }
function combinationUtil ( $ arr , $ data , $ start , $ end , $ index , $ r ) {
if ( $ index == $ r ) { for ( $ j = 0 ; $ j < $ r ; $ j ++ ) echo $ data [ $ j ] ; echo " STRNEWLINE " ; return ; }
for ( $ i = $ start ; $ i <= $ end && $ end - $ i + 1 >= $ r - $ index ; $ i ++ ) { $ data [ $ index ] = $ arr [ $ i ] ; combinationUtil ( $ arr , $ data , $ i + 1 , $ end , $ index + 1 , $ r ) ; } }
$ arr = array ( 1 , 2 , 3 , 4 , 5 ) ; $ r = 3 ; $ n = sizeof ( $ arr ) ; printCombination ( $ arr , $ n , $ r ) ; ? >
function findgroups ( $ arr , $ n ) {
$ c = array ( 0 , 0 , 0 ) ;
$ res = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ c [ $ arr [ $ i ] % 3 ] += 1 ;
$ res += ( ( $ c [ 0 ] * ( $ c [ 0 ] - 1 ) ) >> 1 ) ;
$ res += $ c [ 1 ] * $ c [ 2 ] ;
$ res += ( $ c [ 0 ] * ( $ c [ 0 ] - 1 ) * ( $ c [ 0 ] - 2 ) ) / 6 ;
$ res += ( $ c [ 1 ] * ( $ c [ 1 ] - 1 ) * ( $ c [ 1 ] - 2 ) ) / 6 ;
$ res += ( ( $ c [ 2 ] * ( $ c [ 2 ] - 1 ) * ( $ c [ 2 ] - 2 ) ) / 6 ) ;
$ res += $ c [ 0 ] * $ c [ 1 ] * $ c [ 2 ] ;
return $ res ; }
$ arr = array ( 3 , 6 , 7 , 2 , 9 ) ; $ n = count ( $ arr ) ; echo " Required ▁ number ▁ of ▁ groups ▁ are ▁ " . ( int ) ( findgroups ( $ arr , $ n ) ) ; ? >
function swapBits ( $ x , $ p1 , $ p2 , $ n ) {
$ set1 = ( $ x >> $ p1 ) & ( ( 1 << $ n ) - 1 ) ;
$ set2 = ( $ x >> $ p2 ) & ( ( 1 << $ n ) - 1 ) ;
$ xor = ( $ set1 ^ $ set2 ) ;
$ xor = ( $ xor << $ p1 ) | ( $ xor << $ p2 ) ;
$ result = $ x ^ $ xor ; return $ result ; }
$ res = swapBits ( 28 , 0 , 3 , 2 ) ; echo " Result = " ? >
function Add ( $ x , $ y ) {
while ( $ y != 0 ) {
$ carry = $ x & $ y ;
$ x = $ x ^ $ y ;
$ y = $ carry << 1 ; } return $ x ; }
echo Add ( 15 , 32 ) ; ? >
function addOne ( $ x ) { $ m = 1 ;
while ( $ x & $ m ) { $ x = $ x ^ $ m ; $ m <<= 1 ; }
$ x = $ x ^ $ m ; return $ x ; }
echo addOne ( 13 ) ; ? >
function fun ( $ n ) { return $ n & ( $ n - 1 ) ; }
$ n = 7 ; echo " The ▁ number ▁ after ▁ unsetting ▁ the " . " ▁ rightmost ▁ set ▁ bit ▁ " , fun ( $ n ) ; ? >
function isPowerOfFour ( $ n ) { if ( $ n == 0 ) return 0 ; while ( $ n != 1 ) { if ( $ n % 4 != 0 ) return 0 ; $ n = $ n / 4 ; } return 1 ; }
$ test_no = 64 ; if ( isPowerOfFour ( $ test_no ) ) echo $ test_no , " ▁ is ▁ a ▁ power ▁ of ▁ 4" ; else echo $ test_no , " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ; ? >
function nextPowerOf2 ( $ n ) { $ count = 0 ;
if ( $ n && ! ( $ n & ( $ n - 1 ) ) ) return $ n ; while ( $ n != 0 ) { $ n >>= 1 ; $ count += 1 ; } return 1 << $ count ; }
$ n = 0 ; echo ( nextPowerOf2 ( $ n ) ) ; ? >
function isPowerOfTwo ( $ n ) { if ( $ n == 0 ) return 0 ; while ( $ n != 1 ) { if ( $ n % 2 != 0 ) return 0 ; $ n = $ n / 2 ; } return 1 ; }
if ( isPowerOfTwo ( 31 ) ) echo " Yes STRNEWLINE " ; else echo " No STRNEWLINE " ; if ( isPowerOfTwo ( 64 ) ) echo " Yes STRNEWLINE " ; else echo " No STRNEWLINE " ; ? >
function getFirstSetBitPos ( $ n ) { return ceil ( log ( ( $ n & - $ n ) + 1 , 2 ) ) ; }
$ n = 12 ; echo getFirstSetBitPos ( $ n ) ; ? >
function isPowerOfTwo ( $ n ) { return $ n && ( ! ( $ n & ( $ n - 1 ) ) ) ; }
function findPosition ( $ n ) { if ( ! isPowerOfTwo ( $ n ) ) return -1 ; $ count = 0 ;
while ( $ n ) { $ n = $ n >> 1 ;
++ $ count ; } return $ count ; }
$ n = 0 ; $ pos = findPosition ( $ n ) ; if ( ( $ pos == -1 ) == true ) echo " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Invalid number " , ▁ " " ; STRNEWLINE else STRNEWLINE echo ▁ " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Position " , ▁ $ pos , ▁ " " $ n = 12 ; $ pos = findPosition ( $ n ) ; if ( ( $ pos == -1 ) == true ) echo " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Invalid number " , ▁ " " ; STRNEWLINE else STRNEWLINE echo ▁ " n = " , ▁ $ n , STRNEWLINE " Position " , ▁ $ pos , ▁ " " $ n = 128 ; $ pos = findPosition ( $ n ) ; if ( ( $ pos == -1 ) == true ) echo " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Invalid number " , ▁ " " ; STRNEWLINE else STRNEWLINE echo ▁ " n = " , ▁ $ n , ▁ " , " , STRNEWLINE " Position " , ▁ $ pos , ▁ " " ? >
$ x = 10 ; $ y = 5 ;
$ x = $ x * $ y ;
$ y = $ x / $ y ;
$ x = $ x / $ y ; echo " After ▁ Swapping : ▁ x ▁ = ▁ " , $ x , " ▁ " , " y ▁ = ▁ " , $ y ; ? >
$ x = 10 ; $ y = 5 ;
$ x = $ x ^ $ y ;
$ y = $ x ^ $ y ;
$ x = $ x ^ $ y ; echo " After ▁ Swapping : ▁ x ▁ = ▁ " , $ x , " , ▁ " , " y ▁ = ▁ " , $ y ; ? >
function swap ( & $ xp , & $ yp ) { $ xp = $ xp ^ $ yp ; $ yp = $ xp ^ $ yp ; $ xp = $ xp ^ $ yp ; }
$ x = 10 ; swap ( $ x , $ x ) ; print ( " After ▁ swap ( & x , ▁ & x ) : ▁ x ▁ = ▁ " . $ x ) ; ? >
function maxIndexDiff ( $ arr , $ n ) { $ maxDiff = -1 ; for ( $ i = 0 ; $ i < $ n ; ++ $ i ) { for ( $ j = $ n - 1 ; $ j > $ i ; -- $ j ) { if ( $ arr [ $ j ] > $ arr [ $ i ] && $ maxDiff < ( $ j - $ i ) ) $ maxDiff = $ j - $ i ; } } return $ maxDiff ; }
$ arr = array ( 9 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 18 , 0 ) ; $ n = count ( $ arr ) ; $ maxDiff = maxIndexDiff ( $ arr , $ n ) ; echo $ maxDiff ; ? >
function findMaximum ( $ arr , $ low , $ high ) { $ max = $ arr [ $ low ] ; $ i ; for ( $ i = $ low ; $ i <= $ high ; $ i ++ ) { if ( $ arr [ $ i ] > $ max ) $ max = $ arr [ $ i ] ; } return $ max ; }
$ arr = array ( 1 , 30 , 40 , 50 , 60 , 70 , 23 , 20 ) ; $ n = count ( $ arr ) ; echo " The ▁ maximum ▁ element ▁ is ▁ " , findMaximum ( $ arr , 0 , $ n - 1 ) ; ? >
function printSorted ( $ arr , $ start , $ end ) { if ( $ start > $ end ) return ;
printSorted ( $ arr , $ start * 2 + 1 , $ end ) ;
echo ( $ arr [ $ start ] . " " ) ;
printSorted ( $ arr , $ start * 2 + 2 , $ end ) ; }
$ arr = array ( 4 , 2 , 5 , 1 , 3 ) ; printSorted ( $ arr , 0 , sizeof ( $ arr ) - 1 ) ;
function search ( & $ mat , $ n , $ x ) { $ i = 0 ;
$ j = $ n - 1 ; while ( $ i < $ n && $ j >= 0 ) { if ( $ mat [ $ i ] [ $ j ] == $ x ) { echo " n ▁ found ▁ at ▁ " . $ i . " , ▁ " . $ j ; return 1 ; } if ( $ mat [ $ i ] [ $ j ] > $ x ) $ j -- ;
else $ i ++ ; } echo " n ▁ Element ▁ not ▁ found " ;
return 0 ; }
$ mat = array ( array ( 10 , 20 , 30 , 40 ) , array ( 15 , 25 , 35 , 45 ) , array ( 27 , 29 , 37 , 48 ) , array ( 32 , 33 , 39 , 50 ) ) ; search ( $ mat , 4 , 29 ) ; ? >
$ N = 4 ;
function add ( & $ A , & $ B , & $ C ) { for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ N ; $ j ++ ) $ C [ $ i ] [ $ j ] = $ A [ $ i ] [ $ j ] + $ B [ $ i ] [ $ j ] ; }
$ A = array ( array ( 1 , 1 , 1 , 1 ) , array ( 2 , 2 , 2 , 2 ) , array ( 3 , 3 , 3 , 3 ) , array ( 4 , 4 , 4 , 4 ) ) ; $ B = array ( array ( 1 , 1 , 1 , 1 ) , array ( 2 , 2 , 2 , 2 ) , array ( 3 , 3 , 3 , 3 ) , array ( 4 , 4 , 4 , 4 ) ) ; $ N = 4 ; add ( $ A , $ B , $ C ) ; echo " Result ▁ matrix ▁ is ▁ STRNEWLINE " ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { for ( $ j = 0 ; $ j < $ N ; $ j ++ ) { echo $ C [ $ i ] [ $ j ] ; echo " ▁ " ; } echo " STRNEWLINE " ; } ? >
