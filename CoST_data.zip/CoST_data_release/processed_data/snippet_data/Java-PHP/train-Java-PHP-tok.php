$ poles = array ( array ( ) , array ( ) , array ( ) ) ; function TOH ( $ n , $ A = " A " , $ B = " B " , $ C = " C " ) { if ( $ n > 0 ) { TOH ( $ n - 1 , $ A , $ C , $ B ) ; echo " Move ▁ disk ▁ from ▁ rod ▁ $ A ▁ to ▁ rod ▁ $ C ▁ STRNEWLINE " ; move ( $ A , $ C ) ; dispPoles ( ) ; TOH ( $ n - 1 , $ B , $ A , $ C ) ; } else { return ; } } function initPoles ( $ n ) { global $ poles ; for ( $ i = $ n ; $ i >= 1 ; -- $ i ) { $ poles [ 0 ] [ ] = $ i ; } } function move ( $ source , $ destination ) { global $ poles ; if ( $ source == " A " ) $ ptr1 = 0 ; elseif ( $ source == " B " ) $ ptr1 = 1 ; else $ ptr1 = 2 ; if ( $ destination == " A " ) $ ptr2 = 0 ; elseif ( $ destination == " B " ) $ ptr2 = 1 ; else $ ptr2 = 2 ; $ top = array_pop ( $ poles [ $ ptr1 ] ) ; array_push ( $ poles [ $ ptr2 ] , $ top ) ; } function dispPoles ( ) { global $ poles ; echo " A : ▁ [ " . implode ( " , ▁ " , $ poles [ 0 ] ) . " ] ▁ " ; echo " B : ▁ [ " . implode ( " , ▁ " , $ poles [ 1 ] ) . " ] ▁ " ; echo " C : ▁ [ " . implode ( " , ▁ " , $ poles [ 2 ] ) . " ] ▁ " ; echo " STRNEWLINE STRNEWLINE " ; }
$ numdisks = 4 ;
initPoles ( $ numdisks ) ; echo " Tower ▁ of ▁ Hanoi ▁ Solution ▁ for ▁ $ numdisks ▁ disks : ▁ STRNEWLINE STRNEWLINE " ; dispPoles ( ) ; TOH ( $ numdisks ) ; ? >
function printMaxOfMin ( $ arr , $ n ) {
for ( $ k = 1 ; $ k <= $ n ; $ k ++ ) {
$ maxOfMin = PHP_INT_MIN ;
for ( $ i = 0 ; $ i <= $ n - $ k ; $ i ++ ) {
$ min = $ arr [ $ i ] ; for ( $ j = 1 ; $ j < $ k ; $ j ++ ) { if ( $ arr [ $ i + $ j ] < $ min ) $ min = $ arr [ $ i + $ j ] ; }
if ( $ min > $ maxOfMin ) $ maxOfMin = $ min ; }
echo $ maxOfMin , " " ; } }
$ arr = array ( 10 , 20 , 30 , 50 , 10 , 70 , 30 ) ; $ n = sizeof ( $ arr ) ; printMaxOfMin ( $ arr , $ n ) ; ? >
function PrintMinNumberForPattern ( $ arr ) {
$ curr_max = 0 ;
$ last_entry = 0 ; $ j ;
for ( $ i = 0 ; $ i < strlen ( $ arr ) ; $ i ++ ) {
$ noOfNextD = 0 ; switch ( $ arr [ $ i ] ) { case ' I ' :
$ j = $ i + 1 ; while ( $ arr [ $ j ] == ' D ' && $ j < strlen ( $ arr ) ) { $ noOfNextD ++ ; $ j ++ ; } if ( $ i == 0 ) { $ curr_max = $ noOfNextD + 2 ;
echo " ▁ " , ++ $ last_entry ; echo " ▁ " , $ curr_max ;
$ last_entry = $ curr_max ; } else {
$ curr_max = $ curr_max + $ noOfNextD + 1 ;
$ last_entry = $ curr_max ; echo " ▁ " , $ last_entry ; }
for ( $ k = 0 ; $ k < $ noOfNextD ; $ k ++ ) { echo " ▁ " , -- $ last_entry ; $ i ++ ; } break ;
case ' D ' : if ( $ i == 0 ) {
$ j = $ i + 1 ; while ( ( $ arr [ $ j ] == ' D ' ) && ( $ j < strlen ( $ arr ) ) ) { $ noOfNextD ++ ; $ j ++ ; }
$ curr_max = $ noOfNextD + 2 ;
echo " " ▁ , ▁ $ curr _ max ▁ , STRNEWLINE " "
$ last_entry = $ curr_max - 1 ; } else {
echo " ▁ " , $ last_entry - 1 ; $ last_entry -- ; } break ; } } echo " " }
PrintMinNumberForPattern ( " IDID " ) ; PrintMinNumberForPattern ( " I " ) ; PrintMinNumberForPattern ( " DD " ) ; PrintMinNumberForPattern ( " II " ) ; PrintMinNumberForPattern ( " DIDI " ) ; PrintMinNumberForPattern ( " IIDDD " ) ; PrintMinNumberForPattern ( " DDIDDIID " ) ; ? >
$ st = array ( ) ;
function push_digits ( $ number ) { global $ st ; while ( $ number != 0 ) { array_push ( $ st , $ number % 10 ) ; $ number = ( int ) ( $ number / 10 ) ; } }
function reverse_number ( $ number ) { global $ st ;
push_digits ( $ number ) ; $ reverse = 0 ; $ i = 1 ;
while ( ! empty ( $ st ) ) { $ reverse = $ reverse + ( $ st [ count ( $ st ) - 1 ] * $ i ) ; array_pop ( $ st ) ; $ i = $ i * 10 ; }
return $ reverse ; }
$ number = 39997 ;
echo reverse_number ( $ number ) ; ? >
function heapify ( & $ arr , $ n , $ i ) {
$ largest = $ i ;
$ l = 2 * $ i + 1 ;
$ r = 2 * $ i + 2 ;
if ( $ l < $ n && $ arr [ $ l ] > $ arr [ $ largest ] ) $ largest = $ l ;
if ( $ r < $ n && $ arr [ $ r ] > $ arr [ $ largest ] ) $ largest = $ r ;
if ( $ largest != $ i ) { $ swap = $ arr [ $ i ] ; $ arr [ $ i ] = $ arr [ $ largest ] ; $ arr [ $ largest ] = $ swap ;
heapify ( $ arr , $ n , $ largest ) ; } }
function heapSort ( & $ arr , $ n ) {
for ( $ i = $ n / 2 - 1 ; $ i >= 0 ; $ i -- ) heapify ( $ arr , $ n , $ i ) ;
for ( $ i = $ n - 1 ; $ i > 0 ; $ i -- ) {
$ temp = $ arr [ 0 ] ; $ arr [ 0 ] = $ arr [ $ i ] ; $ arr [ $ i ] = $ temp ;
heapify ( $ arr , $ i , 0 ) ; } }
function printArray ( & $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; ++ $ i ) echo ( $ arr [ $ i ] . " ▁ " ) ; }
$ arr = array ( 12 , 11 , 13 , 5 , 6 , 7 ) ; $ n = sizeof ( $ arr ) / sizeof ( $ arr [ 0 ] ) ; heapSort ( $ arr , $ n ) ; echo ' Sorted array is ' . " STRNEWLINE " ; printArray ( $ arr , $ n ) ; ? >
function isHeap ( $ arr , $ i , $ n ) {
if ( $ i >= ( $ n - 2 ) / 2 ) return true ;
if ( $ arr [ $ i ] >= $ arr [ 2 * $ i + 1 ] && $ arr [ $ i ] >= $ arr [ 2 * $ i + 2 ] && isHeap ( $ arr , 2 * $ i + 1 , $ n ) && isHeap ( $ arr , 2 * $ i + 2 , $ n ) ) return true ; return false ; }
$ arr = array ( 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 ) ; $ n = sizeof ( $ arr ) ; if ( isHeap ( $ arr , 0 , $ n ) ) echo " Yes " ; else echo " No " ; ? >
function isHeap ( $ arr , $ i , $ n ) {
for ( $ i = 0 ; $ i < ( ( $ n - 2 ) / 2 ) + 1 ; $ i ++ ) {
if ( $ arr [ 2 * $ i + 1 ] > $ arr [ $ i ] ) return False ;
if ( 2 * $ i + 2 < $ n && $ arr [ 2 * $ i + 2 ] > $ arr [ $ i ] ) return False ; return True ; } }
$ arr = array ( 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 ) ; $ n = sizeof ( $ arr ) ; if ( isHeap ( $ arr , 0 , $ n ) ) echo " Yes " ; else echo " No " ; ? >
function generate_derangement ( $ N ) {
$ S = array ( ) ; for ( $ i = 1 ; $ i <= $ N ; $ i ++ ) $ S [ $ i ] = $ i ;
$ D = array ( ) ; for ( $ i = 1 ; $ i <= $ N ; $ i += 2 ) { if ( $ i == $ N ) {
$ D [ $ N ] = $ S [ $ N - 1 ] ; $ D [ $ N - 1 ] = $ S [ $ N ] ; } else { $ D [ $ i ] = $ i + 1 ; $ D [ $ i + 1 ] = $ i ; } }
for ( $ i = 1 ; $ i <= $ N ; $ i ++ ) echo $ D [ $ i ] . " ▁ " ; echo " STRNEWLINE " ; }
generate_derangement ( 10 ) ; ? >
function sumBetweenTwoKth ( $ arr , $ n , $ k1 , $ k2 ) {
sort ( $ arr ) ;
$ result = 0 ; for ( $ i = $ k1 ; $ i < $ k2 - 1 ; $ i ++ ) $ result += $ arr [ $ i ] ; return $ result ; }
$ arr = array ( 20 , 8 , 22 , 4 , 12 , 10 , 14 ) ; $ k1 = 3 ; $ k2 = 6 ; $ n = count ( $ arr ) ; ; echo sumBetweenTwoKth ( $ arr , $ n , $ k1 , $ k2 ) ; ? >
function minSum ( $ a , $ n ) {
sort ( $ a ) ; $ num1 = 0 ; $ num2 = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ i % 2 == 0 ) $ num1 = $ num1 * 10 + $ a [ $ i ] ; else $ num2 = $ num2 * 10 + $ a [ $ i ] ; } return ( $ num2 + $ num1 ) ; }
$ arr = array ( 5 , 3 , 0 , 7 , 4 ) ; $ n = sizeof ( $ arr ) ; echo " The ▁ required ▁ sum ▁ is ▁ " , minSum ( $ arr , $ n ) , " STRNEWLINE " ; ? >
$ N = 3 ; $ M = 4 ;
function printDistance ( $ mat ) { global $ N , $ M ; $ ans = array ( array ( ) ) ;
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ M ; $ j ++ ) $ ans [ $ i ] [ $ j ] = PHP_INT_MAX ;
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ M ; $ j ++ ) {
for ( $ k = 0 ; $ k < $ N ; $ k ++ ) for ( $ l = 0 ; $ l < $ M ; $ l ++ ) {
if ( $ mat [ $ k ] [ $ l ] == 1 ) $ ans [ $ i ] [ $ j ] = min ( $ ans [ $ i ] [ $ j ] , abs ( $ i - $ k ) + abs ( $ j - $ l ) ) ; } }
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { for ( $ j = 0 ; $ j < $ M ; $ j ++ ) echo $ ans [ $ i ] [ $ j ] , " ▁ " ; echo " STRNEWLINE " ; } }
$ mat = array ( array ( 0 , 0 , 0 , 1 ) , array ( 0 , 0 , 1 , 1 ) , array ( 0 , 1 , 1 , 0 ) ) ; printDistance ( $ mat ) ; ? >
function isMinHeap ( $ level , $ n ) {
for ( $ i = ( $ n / 2 - 1 ) ; $ i >= 0 ; $ i -- ) {
if ( $ level [ $ i ] > $ level [ 2 * $ i + 1 ] ) return false ; if ( 2 * $ i + 2 < $ n ) {
if ( $ level [ $ i ] > $ level [ 2 * $ i + 2 ] ) return false ; } } return true ; }
$ level = array ( 10 , 15 , 14 , 25 , 30 ) ; $ n = sizeof ( $ level ) ; if ( isMinHeap ( $ level , $ n ) ) echo " True " ; else echo " False " ;
function mostFrequent ( $ arr , $ n ) {
sort ( $ arr ) ; sort ( $ arr , $ n ) ;
$ max_count = 1 ; $ res = $ arr [ 0 ] ; $ curr_count = 1 ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] == $ arr [ $ i - 1 ] ) $ curr_count ++ ; else { if ( $ curr_count > $ max_count ) { $ max_count = $ curr_count ; $ res = $ arr [ $ i - 1 ] ; } $ curr_count = 1 ; } }
if ( $ curr_count > $ max_count ) { $ max_count = $ curr_count ; $ res = $ arr [ $ n - 1 ] ; } return $ res ; }
{ $ arr = array ( 1 , 5 , 2 , 1 , 3 , 2 , 1 ) ; $ n = sizeof ( $ arr ) / sizeof ( $ arr [ 0 ] ) ; echo mostFrequent ( $ arr , $ n ) ; return 0 ; } ? >
function areDisjoint ( $ set1 , $ set2 , $ m , $ n ) {
for ( $ i = 0 ; $ i < $ m ; $ i ++ ) for ( $ j = 0 ; $ j < $ n ; $ j ++ ) if ( $ set1 [ $ i ] == $ set2 [ $ j ] ) return false ;
return true ; }
$ set1 = array ( 12 , 34 , 11 , 9 , 3 ) ; $ set2 = array ( 7 , 2 , 1 , 5 ) ; $ m = sizeof ( $ set1 ) ; $ n = sizeof ( $ set2 ) ; if ( areDisjoint ( $ set1 , $ set2 , $ m , $ n ) == true ) echo " Yes " ; else echo " ▁ No " ; ? >
function findMissing ( $ a , $ b , $ n , $ m ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ j ; for ( $ j = 0 ; $ j < $ m ; $ j ++ ) if ( $ a [ $ i ] == $ b [ $ j ] ) break ; if ( $ j == $ m ) echo $ a [ $ i ] , " ▁ " ; } }
$ a = array ( 1 , 2 , 6 , 3 , 4 , 5 ) ; $ b = array ( 2 , 4 , 3 , 1 , 0 ) ; $ n = count ( $ a ) ; $ m = count ( $ b ) ; findMissing ( $ a , $ b , $ n , $ m ) ; ? >
function areEqual ( $ arr1 , $ arr2 , $ n , $ m ) {
if ( $ n != $ m ) return false ;
sort ( $ arr1 ) ; sort ( $ arr2 ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr1 [ $ i ] != $ arr2 [ $ i ] ) return false ;
return true ; }
$ arr1 = array ( 3 , 5 , 2 , 5 , 2 ) ; $ arr2 = array ( 2 , 3 , 5 , 5 , 2 ) ; $ n = count ( $ arr1 ) ; $ m = count ( $ arr2 ) ; if ( areEqual ( $ arr1 , $ arr2 , $ n , $ m ) ) echo " Yes " ; else echo " No " ; ? >
function isProduct ( $ arr , $ n , $ x ) {
for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) for ( $ j = $ i + 1 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] * $ arr [ $ j ] == $ x ) return true ; return false ; }
$ arr = array ( 10 , 20 , 9 , 40 ) ; $ x = 400 ; $ n = count ( $ arr ) ; if ( isProduct ( $ arr , $ n , $ x ) ) echo " Yes STRNEWLINE " ; else echo " No STRNEWLINE " ; $ x = 190 ; if ( isProduct ( $ arr , $ n , $ x ) ) echo " Yes STRNEWLINE " ; else echo " No STRNEWLINE " ; ? >
function findGreatest ( $ arr , $ n ) { $ result = -1 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ n - 1 ; $ j ++ ) for ( $ k = $ j + 1 ; $ k < $ n ; $ k ++ ) if ( $ arr [ $ j ] * $ arr [ $ k ] == $ arr [ $ i ] ) $ result = max ( $ result , $ arr [ $ i ] ) ; return $ result ; }
$ arr = array ( 30 , 10 , 9 , 3 , 35 ) ; $ n = count ( $ arr ) ; echo findGreatest ( $ arr , $ n ) ; ? >
function subset ( $ ar , $ n ) {
$ res = 0 ;
sort ( $ ar ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ count = 1 ;
for ( ; $ i < $ n - 1 ; $ i ++ ) { if ( $ ar [ $ i ] == $ ar [ $ i + 1 ] ) $ count ++ ; else break ; }
$ res = max ( $ res , $ count ) ; } return $ res ; }
$ arr = array ( 5 , 6 , 9 , 3 , 4 , 3 , 4 ) ; $ n = sizeof ( $ arr ) ; echo subset ( $ arr , $ n ) ; ? >
function getPairsCount ( $ arr , $ n , $ sum ) {
$ count = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) if ( $ arr [ $ i ] + $ arr [ $ j ] == $ sum ) $ count ++ ; return $ count ; }
$ arr = array ( 1 , 5 , 7 , -1 , 5 ) ; $ n = sizeof ( $ arr ) ; $ sum = 6 ; echo " Count ▁ of ▁ pairs ▁ is ▁ " , getPairsCount ( $ arr , $ n , $ sum ) ; ? >
function countPairs ( $ arr1 , $ arr2 , $ m , $ n , $ x ) { $ count = 0 ;
for ( $ i = 0 ; $ i < $ m ; $ i ++ ) for ( $ j = 0 ; $ j < $ n ; $ j ++ )
if ( ( $ arr1 [ $ i ] + $ arr2 [ $ j ] ) == $ x ) $ count ++ ;
return $ count ; }
$ arr1 = array ( 1 , 3 , 5 , 7 ) ; $ arr2 = array ( 2 , 3 , 5 , 8 ) ; $ m = count ( $ arr1 ) ; $ n = count ( $ arr2 ) ; $ x = 10 ; echo " Count ▁ = ▁ " , countPairs ( $ arr1 , $ arr2 , $ m , $ n , $ x ) ; ? >
function isPresent ( $ arr , $ low , $ high , $ value ) { while ( $ low <= $ high ) { $ mid = ( $ low + $ high ) / 2 ;
if ( $ arr [ $ mid ] == $ value ) return true ; else if ( $ arr [ $ mid ] > $ value ) $ high = $ mid - 1 ; else $ low = $ mid + 1 ; }
return false ; }
function countPairs ( $ arr1 , $ arr2 , $ m , $ n , $ x ) { $ count = 0 ; for ( $ i = 0 ; $ i < $ m ; $ i ++ ) {
$ value = $ x - $ arr1 [ $ i ] ;
if ( isPresent ( $ arr2 , 0 , $ n - 1 , $ value ) ) $ count ++ ; }
return $ count ; }
$ arr1 = array ( 1 , 3 , 5 , 7 ) ; $ arr2 = array ( 2 , 3 , 5 , 8 ) ; $ m = count ( $ arr1 ) ; $ n = count ( $ arr2 ) ; $ x = 10 ; echo " Count ▁ = ▁ " , countPairs ( $ arr1 , $ arr2 , $ m , $ n , $ x ) ; ? >
function countPairs ( $ arr1 , $ arr2 , $ m , $ n , $ x ) { $ count = 0 ; $ l = 0 ; $ r = $ n - 1 ;
while ( $ l < $ m and $ r >= 0 ) {
if ( ( $ arr1 [ $ l ] + $ arr2 [ $ r ] ) == $ x ) { $ l ++ ; $ r -- ; $ count ++ ; }
else if ( ( $ arr1 [ $ l ] + $ arr2 [ $ r ] ) < $ x ) $ l ++ ;
else $ r -- ; }
return $ count ; }
$ arr1 = array ( 1 , 3 , 5 , 7 ) ; $ arr2 = array ( 2 , 3 , 5 , 8 ) ; $ m = count ( $ arr1 ) ; $ n = count ( $ arr2 ) ; $ x = 10 ; echo " Count ▁ = ▁ " , countPairs ( $ arr1 , $ arr2 , $ m , $ n , $ x ) ; ? >
function isPresent ( $ arr , $ low , $ high , $ value ) { while ( $ low <= $ high ) { $ mid = ( $ low + $ high ) / 2 ;
if ( $ arr [ $ mid ] == $ value ) return true ; else if ( $ arr [ $ mid ] > $ value ) $ high = $ mid - 1 ; else $ low = $ mid + 1 ; }
return false ; }
function countQuadruples ( $ arr1 , $ arr2 , $ arr3 , $ arr4 , $ n , $ x ) { $ count = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ n ; $ j ++ ) for ( $ k = 0 ; $ k < $ n ; $ k ++ ) {
$ T = $ arr1 [ $ i ] + $ arr2 [ $ j ] + $ arr3 [ $ k ] ;
if ( isPresent ( $ arr4 , 0 , $ n , $ x - $ T ) )
$ count ++ ; }
return $ count ; }
$ arr1 = array ( 1 , 4 , 5 , 6 ) ; $ arr2 = array ( 2 , 3 , 7 , 8 ) ; $ arr3 = array ( 1 , 4 , 6 , 10 ) ; $ arr4 = array ( 2 , 4 , 7 , 8 ) ; $ n = sizeof ( $ arr1 ) ; $ x = 30 ; echo " Count = " ? >
function countPairs ( $ arr , $ n ) { $ result = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) { $ product = $ arr [ $ i ] * $ arr [ $ j ] ;
for ( $ k = 0 ; $ k < $ n ; $ k ++ ) {
if ( $ arr [ $ k ] == $ product ) { $ result ++ ; break ; } } } }
return $ result ; }
$ arr = array ( 6 , 2 , 4 , 12 , 5 , 3 ) ; $ n = sizeof ( $ arr ) ; echo countPairs ( $ arr , $ n ) ;
function findPairs ( $ arr1 , $ arr2 , $ n , $ m , $ x ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ m ; $ j ++ ) if ( $ arr1 [ $ i ] + $ arr2 [ $ j ] == $ x ) echo $ arr1 [ $ i ] . " ▁ " . $ arr2 [ $ j ] . " STRNEWLINE " ; }
$ arr1 = array ( 1 , 2 , 3 , 7 , 5 , 4 ) ; $ arr2 = array ( 0 , 7 , 4 , 3 , 2 , 1 ) ; $ n = count ( $ arr1 ) ; $ m = count ( $ arr2 ) ; $ x = 8 ; findPairs ( $ arr1 , $ arr2 , $ n , $ m , $ x ) ; ? >
function findPair ( $ arr , $ n ) { $ found = false ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) { for ( $ k = 0 ; $ k < $ n ; $ k ++ ) { if ( $ arr [ $ i ] + $ arr [ $ j ] == $ arr [ $ k ] ) { echo $ arr [ $ i ] , " ▁ " , $ arr [ $ j ] ; $ found = true ; } } } } if ( $ found == false ) echo " Not ▁ exist " ; }
$ arr = array ( 10 , 4 , 8 , 13 , 5 ) ; $ n = sizeof ( $ arr ) / sizeof ( $ arr [ 0 ] ) ; findPair ( $ arr , $ n ) ; ? >
function printPairs ( $ arr , $ n , $ k ) { $ isPairFound = true ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) {
if ( $ i != $ j && $ arr [ $ i ] % $ arr [ $ j ] == $ k ) { echo " ( " , $ arr [ $ i ] , " , ▁ " , $ arr [ $ j ] , " ) " , " ▁ " ; $ isPairFound = true ; } } } return $ isPairFound ; }
$ arr = array ( 2 , 3 , 5 , 4 , 7 ) ; $ n = sizeof ( $ arr ) ; $ k = 3 ; if ( printPairs ( $ arr , $ n , $ k ) == false ) echo " No ▁ such ▁ pair ▁ exists " ; ? >
$ ASCII_SIZE = 256 ; function getMaxOccuringChar ( $ str ) { global $ ASCII_SIZE ;
$ count = array_fill ( 0 , $ ASCII_SIZE , NULL ) ;
$ len = strlen ( $ str ) ;
$ max = 0 ;
for ( $ i = 0 ; $ i < ( $ len ) ; $ i ++ ) { $ count [ ord ( $ str [ $ i ] ) ] ++ ; if ( $ max < $ count [ ord ( $ str [ $ i ] ) ] ) { $ max = $ count [ ord ( $ str [ $ i ] ) ] ; $ result = $ str [ $ i ] ; } } return $ result ; }
$ str = " sample ▁ string " ; echo " Max ▁ occurring ▁ character ▁ is ▁ " . getMaxOccuringChar ( $ str ) ; ? >
function firstNonRepeating ( $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ j ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) if ( $ i != $ j && $ arr [ $ i ] == $ arr [ $ j ] ) break ; if ( $ j == $ n ) return $ arr [ $ i ] ; } return -1 ; }
$ arr = array ( 9 , 4 , 9 , 6 , 7 , 4 ) ; $ n = sizeof ( $ arr ) ; echo firstNonRepeating ( $ arr , $ n ) ; ? >
function printKDistinct ( $ arr , $ n , $ k ) { $ dist_count = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ j ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) if ( $ i != $ j && $ arr [ $ j ] == $ arr [ $ i ] ) break ;
if ( $ j == $ n ) $ dist_count ++ ; if ( $ dist_count == $ k ) return $ arr [ $ i ] ; } return -1 ; }
$ ar = array ( 1 , 2 , 1 , 3 , 4 , 2 ) ; $ n = sizeof ( $ ar ) / sizeof ( $ ar [ 0 ] ) ; $ k = 2 ; echo printKDistinct ( $ ar , $ n , $ k ) ; ? >
function subarrayDivisibleByK ( $ arr , $ n , $ k ) {
$ mp = array_fill ( 0 , 1000 , 0 ) ;
$ s = 0 ; $ e = 0 ; $ maxs = 0 ; $ maxe = 0 ;
$ mp [ $ arr [ 0 ] % $ k ] ++ ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { $ mod = $ arr [ $ i ] % $ k ;
while ( $ mp [ $ k - $ mod ] != 0 || ( $ mod == 0 && $ mp [ $ mod ] != 0 ) ) { $ mp [ $ arr [ $ s ] % $ k ] -- ; $ s ++ ; }
$ mp [ $ mod ] ++ ; $ e ++ ;
if ( ( $ e - $ s ) > ( $ maxe - $ maxs ) ) { $ maxe = $ e ; $ maxs = $ s ; } } echo ( " The ▁ maximum ▁ size ▁ is ▁ " . ( $ maxe - $ maxs + 1 ) . " ▁ and ▁ the ▁ subarray ▁ is " . " ▁ as ▁ follows STRNEWLINE " ) ; for ( $ i = $ maxs ; $ i <= $ maxe ; $ i ++ ) echo ( $ arr [ $ i ] . " ▁ " ) ; }
$ k = 3 ; $ arr = array ( 5 , 10 , 15 , 20 , 25 ) ; $ n = count ( $ arr ) ; subarrayDivisibleByK ( $ arr , $ n , $ k ) ; ? >
function findTriplet ( $ a1 , $ a2 , $ a3 , $ n1 , $ n2 , $ n3 , $ sum ) { for ( $ i = 0 ; $ i < $ n1 ; $ i ++ ) for ( $ j = 0 ; $ j < $ n2 ; $ j ++ ) for ( $ k = 0 ; $ k < $ n3 ; $ k ++ ) if ( $ a1 [ $ i ] + $ a2 [ $ j ] + $ a3 [ $ k ] == $ sum ) return true ; return false ; }
$ a1 = array ( 1 , 2 , 3 , 4 , 5 ) ; $ a2 = array ( 2 , 3 , 6 , 1 , 2 ) ; $ a3 = array ( 3 , 2 , 4 , 5 , 6 ) ; $ sum = 9 ; $ n1 = count ( $ a1 ) ; $ n2 = count ( $ a2 ) ; $ n3 = count ( $ a3 ) ; if ( findTriplet ( $ a1 , $ a2 , $ a3 , $ n1 , $ n2 , $ n3 , $ sum ) == true ) echo " Yes " ; else echo " No " ; ? >
function areElementsContiguous ( $ arr , $ n ) {
sort ( $ arr ) ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] - $ arr [ $ i - 1 ] > 1 ) return false ; return true ; }
$ arr = array ( 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ) ; $ n = sizeof ( $ arr ) ; if ( areElementsContiguous ( $ arr , $ n ) ) echo " Yes " ; else echo " No " ; ? >
function minInsertion ( $ str ) {
$ n = strlen ( $ str ) ;
$ res = 0 ;
$ count = array ( 26 ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ count [ ord ( $ str [ $ i ] ) - ord ( ' a ' ) ] ++ ;
for ( $ i = 0 ; $ i < 26 ; $ i ++ ) { if ( $ count [ $ i ] % 2 == 1 ) $ res ++ ; }
return ( $ res == 0 ) ? 0 : $ res - 1 ; }
$ str = " geeksforgeeks " ; echo ( minInsertion ( $ str ) ) ; ? >
function findDiff ( $ arr , $ n ) {
sort ( $ arr ) ; $ count = 0 ; $ max_count = 0 ; $ min_count = $ n ; for ( $ i = 0 ; $ i < ( $ n - 1 ) ; $ i ++ ) {
if ( $ arr [ $ i ] == $ arr [ $ i + 1 ] ) { $ count += 1 ; continue ; } else { $ max_count = max ( $ max_count , $ count ) ; $ min_count = min ( $ min_count , $ count ) ; $ count = 0 ; } } return ( $ max_count - $ min_count ) ; }
$ arr = array ( 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 ) ; $ n = sizeof ( $ arr ) ; echo ( findDiff ( $ arr , $ n ) . " " ) ; ? >
function maxDiff ( $ arr , $ n ) { $ SubsetSum_1 = 0 ; $ SubsetSum_2 = 0 ; for ( $ i = 0 ; $ i <= $ n - 1 ; $ i ++ ) { $ isSingleOccurance = true ; for ( $ j = $ i + 1 ; $ j <= $ n - 1 ; $ j ++ ) {
if ( $ arr [ $ i ] == $ arr [ $ j ] ) { $ isSingleOccurance = false ; $ arr [ $ i ] = $ arr [ $ j ] = 0 ; break ; } } if ( $ isSingleOccurance ) { if ( $ arr [ $ i ] > 0 ) $ SubsetSum_1 += $ arr [ $ i ] ; else $ SubsetSum_2 += $ arr [ $ i ] ; } } return abs ( $ SubsetSum_1 - $ SubsetSum_2 ) ; }
$ arr = array ( 4 , 2 , -3 , 3 , -2 , -2 , 8 ) ; $ n = sizeof ( $ arr ) ; echo " Maximum ▁ Difference ▁ = ▁ " , maxDiff ( $ arr , $ n ) ; ? >
function maxDiff ( $ arr , $ n ) { $ result = 0 ;
sort ( $ arr ) ;
for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) { if ( $ arr [ $ i ] != $ arr [ $ i + 1 ] ) $ result += abs ( $ arr [ $ i ] ) ; else $ i ++ ; }
if ( $ arr [ $ n - 2 ] != $ arr [ $ n - 1 ] ) $ result += abs ( $ arr [ $ n - 1 ] ) ;
return $ result ; }
$ arr = array ( 4 , 2 , -3 , 3 , -2 , -2 , 8 ) ; $ n = count ( $ arr ) ; echo " Maximum ▁ Difference ▁ = ▁ " , maxDiff ( $ arr , $ n ) ; ? >
function calculate ( $ a , $ n ) {
sort ( $ a ) ; $ count = 1 ; $ answer = 0 ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { if ( $ a [ $ i ] == $ a [ $ i - 1 ] ) {
$ count += 1 ; } else {
$ answer = $ answer + ( $ count * ( $ count - 1 ) ) / 2 ; $ count = 1 ; } } $ answer = $ answer + ( $ count * ( $ count - 1 ) ) / 2 ; return $ answer ; }
$ a = array ( 1 , 2 , 1 , 2 , 4 ) ; $ n = count ( $ a ) ;
echo calculate ( $ a , $ n ) ; ? >
function calculate ( $ a , $ n ) {
$ maximum = max ( $ a ) ;
$ frequency = array_fill ( 0 , $ maximum + 1 , 0 ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ frequency [ $ a [ $ i ] ] += 1 ; } $ answer = 0 ;
for ( $ i = 0 ; $ i < ( $ maximum ) + 1 ; $ i ++ ) {
$ answer = $ answer + $ frequency [ $ i ] * ( $ frequency [ $ i ] - 1 ) ; } return $ answer / 2 ; }
$ a = array ( 1 , 2 , 1 , 2 , 4 ) ; $ n = count ( $ a ) ;
echo ( calculate ( $ a , $ n ) ) ; ? >
function printAllAPTriplets ( $ arr , $ n ) { $ s = array ( ) ; for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) { for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) {
$ diff = $ arr [ $ j ] - $ arr [ $ i ] ; if ( in_array ( $ arr [ $ i ] - $ diff , $ arr ) ) echo ( ( $ arr [ $ i ] - $ diff ) . " " ▁ . ▁ $ arr [ $ i ] ▁ . ▁ " " ▁ . ▁ $ arr [ $ j ] ▁ . ▁ " " } array_push ( $ s , $ arr [ $ i ] ) ; } }
$ arr = array ( 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 ) ; $ n = count ( $ arr ) ; printAllAPTriplets ( $ arr , $ n ) ; ? >
function findAllTriplets ( $ arr , $ n ) { for ( $ i = 1 ; $ i < $ n - 1 ; $ i ++ ) {
for ( $ j = $ i - 1 , $ k = $ i + 1 ; $ j >= 0 && $ k < $ n {
if ( $ arr [ $ j ] + $ arr [ $ k ] == 2 * $ arr [ $ i ] ) { echo $ arr [ $ j ] . " ▁ " . $ arr [ $ i ] . " ▁ " . $ arr [ $ k ] . " STRNEWLINE " ;
$ k ++ ; $ j -- ; }
else if ( $ arr [ $ j ] + $ arr [ $ k ] < 2 * $ arr [ $ i ] ) $ k ++ ; else $ j -- ; } } }
$ arr = array ( 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 ) ; $ n = count ( $ arr ) ; findAllTriplets ( $ arr , $ n ) ; ? >
function countTriplets ( $ arr , $ n , $ m ) { $ count = 0 ;
for ( $ i = 0 ; $ i < $ n - 2 ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ n - 1 ; $ j ++ ) for ( $ k = $ j + 1 ; $ k < $ n ; $ k ++ ) if ( $ arr [ $ i ] * $ arr [ $ j ] * $ arr [ $ k ] == $ m ) $ count ++ ; return $ count ; }
$ arr = array ( 1 , 4 , 6 , 2 , 3 , 8 ) ; $ n = sizeof ( $ arr ) ; $ m = 24 ; echo countTriplets ( $ arr , $ n , $ m ) ; ? >
function countPairs ( $ arr , $ n ) { $ ans = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ )
if ( $ arr [ $ i ] == $ arr [ $ j ] ) $ ans ++ ; return $ ans ; }
$ arr = array ( 1 , 1 , 2 ) ; $ n = count ( $ arr ) ; echo countPairs ( $ arr , $ n ) ; ? >
function countNum ( $ arr , $ n ) { $ count = 0 ;
sort ( $ arr ) ;
for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) if ( $ arr [ $ i ] != $ arr [ $ i + 1 ] && $ arr [ $ i ] != $ arr [ $ i + 1 ] - 1 ) $ count += $ arr [ $ i + 1 ] - $ arr [ $ i ] - 1 ; return $ count ; }
$ arr = array ( 3 , 5 , 8 , 6 ) ; $ n = count ( $ arr ) ; echo countNum ( $ arr , $ n ) ; ? >
function countSubarrays ( & $ arr , $ n ) {
$ difference = 0 ; $ ans = 0 ;
$ hash_positive = array_fill ( 0 , $ n + 1 , NULL ) ; $ hash_negative = array_fill ( 0 , $ n + 1 , NULL ) ;
$ hash_positive [ 0 ] = 1 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ arr [ $ i ] & 1 == 1 ) $ difference ++ ; else $ difference -- ;
if ( $ difference < 0 ) { $ ans += $ hash_negative [ - $ difference ] ; $ hash_negative [ - $ difference ] ++ ; }
else { $ ans += $ hash_positive [ $ difference ] ; $ hash_positive [ $ difference ] ++ ; } }
return $ ans ; }
$ arr = array ( 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 ) ; $ n = sizeof ( $ arr ) ;
echo " Total ▁ Number ▁ of ▁ Even - Odd ▁ subarrays " . " ▁ are ▁ " . countSubarrays ( $ arr , $ n ) ; ? >
function findLargestd ( $ S , $ n ) { $ found = false ;
sort ( $ S ) ;
for ( $ i = $ n - 1 ; $ i >= 0 ; $ i -- ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) {
if ( $ i == $ j ) continue ; for ( $ k = $ j + 1 ; $ k < $ n ; $ k ++ ) { if ( $ i == $ k ) continue ; for ( $ l = $ k + 1 ; $ l < $ n ; $ l ++ ) { if ( $ i == $ l ) continue ;
if ( $ S [ $ i ] == $ S [ $ j ] + $ S [ $ k ] + $ S [ $ l ] ) { $ found = true ; return $ S [ $ i ] ; } } } } } if ( $ found == false ) return PHP_INT_MIN ; }
$ S = array ( 2 , 3 , 5 , 7 , 12 ) ; $ n = count ( $ S ) ; $ ans = findLargestd ( $ S , $ n ) ; if ( $ ans == PHP_INT_MIN ) echo " No ▁ Solution " ; else echo " Largest ▁ d ▁ such ▁ that ▁ a ▁ + ▁ b ▁ + ▁ " , " c ▁ = ▁ d ▁ is ▁ " , $ ans ; ? >
function recaman ( $ n ) {
$ arr [ 0 ] = 0 ; echo $ arr [ 0 ] , " , ▁ " ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { $ curr = $ arr [ $ i - 1 ] - $ i ; $ j ; for ( $ j = 0 ; $ j < $ i ; $ j ++ ) {
if ( ( $ arr [ $ j ] == $ curr ) $ curr < 0 ) { $ curr = $ arr [ $ i - 1 ] + $ i ; break ; } } $ arr [ $ i ] = $ curr ; echo $ arr [ $ i ] , " , ▁ " ; } }
$ n = 17 ; recaman ( $ n ) ; ? >
function recaman ( $ n ) { if ( $ n <= 0 ) return ;
print ( "0 , ▁ " ) ; $ s = array ( ) ; array_push ( $ s , 0 ) ;
$ prev = 0 ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { $ curr = $ prev - $ i ;
if ( $ curr < 0 or in_array ( $ curr , $ s ) ) $ curr = $ prev + $ i ; array_push ( $ s , $ curr ) ; print ( $ curr . " , " ) ; $ prev = $ curr ; } }
$ n = 17 ; recaman ( $ n ) ; ? >
function findArea ( $ arr , $ n ) {
rsort ( $ arr ) ;
$ dimension = array ( 0 , 0 ) ;
for ( $ i = 0 , $ j = 0 ; $ i < $ n - 1 && $ j < 2 ; $ i ++ )
if ( $ arr [ $ i ] == $ arr [ $ i + 1 ] ) $ dimension [ $ j ++ ] = $ arr [ $ i ++ ] ;
return ( $ dimension [ 0 ] * $ dimension [ 1 ] ) ; }
$ arr = array ( 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 ) ; $ n = count ( $ arr ) ; echo findArea ( $ arr , $ n ) ; ? >
function search ( $ arr , $ l , $ h , $ key ) { if ( $ l > $ h ) return -1 ; $ mid = ( $ l + $ h ) / 2 ; if ( $ arr [ $ mid ] == $ key ) return $ mid ;
if ( $ arr [ $ l ] <= $ arr [ $ mid ] ) {
if ( $ key >= $ arr [ $ l ] && $ key <= $ arr [ $ mid ] ) return search ( $ arr , $ l , $ mid - 1 , $ key ) ;
return search ( $ arr , $ mid + 1 , $ h , $ key ) ; }
if ( $ key >= $ arr [ $ mid ] && $ key <= $ arr [ $ h ] ) return search ( $ arr , $ mid + 1 , $ h , $ key ) ; return search ( $ arr , $ l , $ mid - 1 , $ key ) ; }
$ arr = array ( 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 ) ; $ n = sizeof ( $ arr ) ; $ key = 6 ; $ i = search ( $ arr , 0 , $ n - 1 , $ key ) ; if ( $ i != -1 ) echo " Index : ▁ " , floor ( $ i ) , " ▁ STRNEWLINE " ; else echo " Key ▁ not ▁ found " ; ? >
function pairInSortedRotated ( $ arr , $ n , $ x ) {
$ i ; for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) if ( $ arr [ $ i ] > $ arr [ $ i + 1 ] ) break ;
$ l = ( $ i + 1 ) % $ n ;
$ r = $ i ;
while ( $ l != $ r ) {
if ( $ arr [ $ l ] + $ arr [ $ r ] == $ x ) return true ;
if ( $ arr [ $ l ] + $ arr [ $ r ] < $ x ) $ l = ( $ l + 1 ) % $ n ;
else $ r = ( $ n + $ r - 1 ) % $ n ; } return false ; }
$ arr = array ( 11 , 15 , 6 , 8 , 9 , 10 ) ; $ sum = 16 ; $ n = sizeof ( $ arr ) ; if ( pairInSortedRotated ( $ arr , $ n , $ sum ) ) echo " Array ▁ has ▁ two ▁ elements ▁ " . " with ▁ sum ▁ 16" ; else echo " Array ▁ doesn ' t ▁ have ▁ two ▁ " . " elements ▁ with ▁ sum ▁ 16 ▁ " ; ? >
function pairsInSortedRotated ( $ arr , $ n , $ x ) {
$ i ; for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) if ( $ arr [ $ i ] > $ arr [ $ i + 1 ] ) break ;
$ l = ( $ i + 1 ) % $ n ;
$ r = $ i ;
$ cnt = 0 ;
while ( $ l != $ r ) {
if ( $ arr [ $ l ] + $ arr [ $ r ] == $ x ) { $ cnt ++ ;
if ( $ l == ( $ r - 1 + $ n ) % $ n ) { return $ cnt ; } $ l = ( $ l + 1 ) % $ n ; $ r = ( $ r - 1 + $ n ) % $ n ; }
else if ( $ arr [ $ l ] + $ arr [ $ r ] < $ x ) $ l = ( $ l + 1 ) % $ n ;
else $ r = ( $ n + $ r - 1 ) % $ n ; } return $ cnt ; }
$ arr = array ( 11 , 15 , 6 , 7 , 9 , 10 ) ; $ sum = 16 ; $ n = sizeof ( $ arr ) / sizeof ( $ arr [ 0 ] ) ; echo pairsInSortedRotated ( $ arr , $ n , $ sum ) ; ? >
function maxSum ( $ arr , $ n ) {
$ arrSum = 0 ;
$ currVal = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ arrSum = $ arrSum + $ arr [ $ i ] ; $ currVal = $ currVal + ( $ i * $ arr [ $ i ] ) ; }
$ maxVal = $ currVal ;
for ( $ j = 1 ; $ j < $ n ; $ j ++ ) { $ currVal = $ currVal + $ arrSum - $ n * $ arr [ $ n - $ j ] ; if ( $ currVal > $ maxVal ) $ maxVal = $ currVal ; }
return $ maxVal ; }
$ arr = array ( 10 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ) ; $ n = sizeof ( $ arr ) ; echo " Max ▁ sum ▁ is ▁ " , maxSum ( $ arr , $ n ) ; ? >
function maxSum ( $ arr , $ n ) {
$ res = PHP_INT_MIN ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ curr_sum = 0 ;
for ( $ j = 0 ; $ j < $ n ; $ j ++ ) { $ index = ( $ i + $ j ) % $ n ; $ curr_sum += $ j * $ arr [ $ index ] ; }
$ res = max ( $ res , $ curr_sum ) ; } return $ res ; }
$ arr = array ( 8 , 3 , 1 , 2 ) ; $ n = sizeof ( $ arr ) ; echo maxSum ( $ arr , $ n ) , " STRNEWLINE " ; ? >
function maxSum ( $ arr , $ n ) {
$ cum_sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ cum_sum += $ arr [ $ i ] ;
$ curr_val = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ curr_val += $ i * $ arr [ $ i ] ;
$ res = $ curr_val ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) {
$ next_val = $ curr_val - ( $ cum_sum - $ arr [ $ i - 1 ] ) + $ arr [ $ i - 1 ] * ( $ n - 1 ) ;
$ curr_val = $ next_val ;
$ res = max ( $ res , $ next_val ) ; } return $ res ; }
$ arr = array ( 8 , 3 , 1 , 2 ) ; $ n = sizeof ( $ arr ) ; echo maxSum ( $ arr , $ n ) ; ? >
function countRotations ( $ arr , $ n ) {
$ min = $ arr [ 0 ] ; $ min_index ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ min > $ arr [ $ i ] ) { $ min = $ arr [ $ i ] ; $ min_index = $ i ; } } return $ min_index ; }
$ arr = array ( 15 , 18 , 2 , 3 , 6 , 12 ) ; $ n = sizeof ( $ arr ) ; echo countRotations ( $ arr , $ n ) ; ? >
function countRotations ( $ arr , $ low , $ high ) {
if ( $ high < $ low ) return 0 ;
if ( $ high == $ low ) return $ low ;
$ mid = $ low + ( $ high - $ low ) / 2 ;
if ( $ mid < $ high && $ arr [ $ mid + 1 ] < $ arr [ $ mid ] ) return ( int ) ( $ mid + 1 ) ;
if ( $ mid > $ low && $ arr [ $ mid ] < $ arr [ $ mid - 1 ] ) return ( int ) ( $ mid ) ;
if ( $ arr [ $ high ] > $ arr [ $ mid ] ) return countRotations ( $ arr , $ low , $ mid - 1 ) ; return countRotations ( $ arr , $ mid + 1 , $ high ) ; }
$ arr = array ( 15 , 18 , 2 , 3 , 6 , 12 ) ; $ n = sizeof ( $ arr ) ; echo countRotations ( $ arr , 0 , $ n - 1 ) ; ? >
function preprocess ( & $ arr , $ n , & $ temp ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ temp [ $ i ] = $ temp [ $ i + $ n ] = $ arr [ $ i ] ; }
function leftRotate ( & $ arr , $ n , $ k , & $ temp ) {
$ start = $ k % $ n ;
for ( $ i = $ start ; $ i < $ start + $ n ; $ i ++ ) echo $ temp [ $ i ] . " ▁ " ; echo " STRNEWLINE " ; }
$ arr = array ( 1 , 3 , 5 , 7 , 9 ) ; $ n = sizeof ( $ arr ) ; $ temp [ 2 * $ n ] = array ( ) ; preprocess ( $ arr , $ n , $ temp ) ; $ k = 2 ; leftRotate ( $ arr , $ n , $ k , $ temp ) ; $ k = 3 ; leftRotate ( $ arr , $ n , $ k , $ temp ) ; $ k = 4 ; leftRotate ( $ arr , $ n , $ k , $ temp ) ; ? >
function leftRotate ( $ arr , $ n , $ k ) {
for ( $ i = $ k ; $ i < $ k + $ n ; $ i ++ ) echo $ arr [ $ i % $ n ] , " ▁ " ; }
$ arr = array ( 1 , 3 , 5 , 7 , 9 ) ; $ n = sizeof ( $ arr ) ; $ k = 2 ; leftRotate ( $ arr , $ n , $ k ) ; echo " STRNEWLINE " ; $ k = 3 ; leftRotate ( $ arr , $ n , $ k ) ; echo " STRNEWLINE " ; $ k = 4 ; leftRotate ( $ arr , $ n , $ k ) ; echo " STRNEWLINE " ; ? >
function reverseArray ( & $ arr , $ start , $ end ) { while ( $ start < $ end ) { $ temp = $ arr [ $ start ] ; $ arr [ $ start ] = $ arr [ $ end ] ; $ arr [ $ end ] = $ temp ; $ start ++ ; $ end -- ; } }
function rightRotate ( & $ arr , $ d , $ n ) { reverseArray ( $ arr , 0 , $ n - 1 ) ; reverseArray ( $ arr , 0 , $ d - 1 ) ; reverseArray ( $ arr , $ d , $ n - 1 ) ; }
function printArray ( & $ arr , $ size ) { for ( $ i = 0 ; $ i < $ size ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; }
$ arr = array ( 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 ) ; $ n = sizeof ( $ arr ) ; $ k = 3 ; rightRotate ( $ arr , $ k , $ n ) ; printArray ( $ arr , $ n ) ; ? >
function maxHamming ( $ arr , $ n ) {
$ brr = array ( ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ brr [ $ i ] = $ arr [ $ i ] ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ brr [ $ n + $ i ] = $ arr [ $ i ] ;
$ maxHam = 0 ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { $ currHam = 0 ; for ( $ j = $ i , $ k = 0 ; $ j < ( $ i + $ n ) ; $ j ++ , $ k ++ ) if ( $ brr [ $ j ] != $ arr [ $ k ] ) $ currHam ++ ;
if ( $ currHam == $ n ) return $ n ; $ maxHam = max ( $ maxHam , $ currHam ) ; } return $ maxHam ; }
$ arr = array ( 2 , 4 , 6 , 80 ) ; $ n = count ( $ arr ) ; echo maxHamming ( $ arr , $ n ) ; ? >
function leftRotate ( $ arr , $ n , $ k ) {
$ mod = $ k % $ n ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo ( $ arr [ ( $ mod + $ i ) % $ n ] ) , " ▁ " ; echo " STRNEWLINE " ; }
$ arr = array ( 1 , 3 , 5 , 7 , 9 ) ; $ n = sizeof ( $ arr ) ; $ k = 2 ;
leftRotate ( $ arr , $ n , $ k ) ; $ k = 3 ;
leftRotate ( $ arr , $ n , $ k ) ; $ k = 4 ;
leftRotate ( $ arr , $ n , $ k ) ; ? >
function findElement ( $ arr , $ ranges , $ rotations , $ index ) { for ( $ i = $ rotations - 1 ; $ i >= 0 ; $ i -- ) {
$ left = $ ranges [ $ i ] [ 0 ] ; $ right = $ ranges [ $ i ] [ 1 ] ;
if ( $ left <= $ index && $ right >= $ index ) { if ( $ index == $ left ) $ index = $ right ; else $ index -- ; } }
return $ arr [ $ index ] ; }
$ arr = array ( 1 , 2 , 3 , 4 , 5 ) ;
$ rotations = 2 ;
$ ranges = array ( array ( 0 , 2 ) , array ( 0 , 3 ) ) ; $ index = 1 ; echo findElement ( $ arr , $ ranges , $ rotations , $ index ) ; ? >
function splitArr ( & $ arr , $ n , $ k ) { for ( $ i = 0 ; $ i < $ k ; $ i ++ ) {
$ x = $ arr [ 0 ] ; for ( $ j = 0 ; $ j < $ n - 1 ; ++ $ j ) $ arr [ $ j ] = $ arr [ $ j + 1 ] ; $ arr [ $ n - 1 ] = $ x ; } }
$ arr = array ( 12 , 10 , 5 , 6 , 52 , 36 ) ; $ n = sizeof ( $ arr ) ; $ position = 2 ; splitArr ( $ arr , 6 , $ position ) ; for ( $ i = 0 ; $ i < $ n ; ++ $ i ) echo $ arr [ $ i ] . " ▁ " ; ? >
function rearrangeArr ( & $ arr , $ n ) {
$ evenPos = intval ( $ n / 2 ) ;
$ oddPos = $ n - $ evenPos ; $ tempArr = array_fill ( 0 , $ n , NULL ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ tempArr [ $ i ] = $ arr [ $ i ] ;
sort ( $ tempArr ) ; $ j = $ oddPos - 1 ;
for ( $ i = 0 ; $ i < $ n ; $ i += 2 ) { $ arr [ $ i ] = $ tempArr [ $ j ] ; $ j -- ; } $ j = $ oddPos ;
for ( $ i = 1 ; $ i < $ n ; $ i += 2 ) { $ arr [ $ i ] = $ tempArr [ $ j ] ; $ j ++ ; }
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; }
$ arr = array ( 1 , 2 , 3 , 4 , 5 , 6 , 7 ) ; $ size = sizeof ( $ arr ) ; rearrangeArr ( $ arr , $ size ) ; ? >
function pushZerosToEnd ( & $ arr , $ n ) {
$ count = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] != 0 )
$ arr [ $ count ++ ] = $ arr [ $ i ] ;
while ( $ count < $ n ) $ arr [ $ count ++ ] = 0 ; }
$ arr = array ( 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 ) ; $ n = sizeof ( $ arr ) ; pushZerosToEnd ( $ arr , $ n ) ; echo " Array ▁ after ▁ pushing ▁ all ▁ " . " zeros ▁ to ▁ end ▁ of ▁ array ▁ : STRNEWLINE " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function minSwap ( $ arr , $ n , $ k ) {
$ count = 0 ; for ( $ i = 0 ; $ i < $ n ; ++ $ i ) if ( $ arr [ $ i ] <= $ k ) ++ $ count ;
$ bad = 0 ; for ( $ i = 0 ; $ i < $ count ; ++ $ i ) if ( $ arr [ $ i ] > $ k ) ++ $ bad ;
$ ans = $ bad ; for ( $ i = 0 , $ j = $ count ; $ j < $ n ; ++ $ i , ++ $ j ) {
if ( $ arr [ $ i ] > $ k ) -- $ bad ;
if ( $ arr [ $ j ] > $ k ) ++ $ bad ;
$ ans = min ( $ ans , $ bad ) ; } return $ ans ; }
$ arr = array ( 2 , 1 , 5 , 6 , 3 ) ; $ n = sizeof ( $ arr ) ; $ k = 3 ; echo ( minSwap ( $ arr , $ n , $ k ) . " " ) ; $ arr1 = array ( 2 , 7 , 9 , 5 , 8 , 7 , 4 ) ; $ n = sizeof ( $ arr1 ) ; $ k = 5 ; echo ( minSwap ( $ arr1 , $ n , $ k ) ) ; ? >
function reorder ( $ arr , $ index , $ n ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ temp [ $ index [ $ i ] ] = $ arr [ $ i ] ; }
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ arr [ $ i ] = $ temp [ $ i ] ; $ index [ $ i ] = $ i ; } echo " Reordered ▁ array ▁ is : ▁ STRNEWLINE " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { echo $ arr [ $ i ] . " " ; } echo " Modified Index array is : " for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { echo $ index [ $ i ] . " " ; } }
$ arr = array ( 50 , 40 , 70 , 60 , 90 ) ; $ index = array ( 3 , 0 , 4 , 1 , 2 ) ; $ n = sizeof ( $ arr ) ; reorder ( $ arr , $ index , $ n ) ; ? >
function printArray ( $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo ( $ arr [ $ i ] . " ▁ " ) ; }
function RearrangePosNeg ( & $ arr , $ n ) { $ key ; $ j ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { $ key = $ arr [ $ i ] ;
if ( $ key > 0 ) continue ;
$ j = $ i - 1 ; while ( $ j >= 0 && $ arr [ $ j ] > 0 ) { $ arr [ $ j + 1 ] = $ arr [ $ j ] ; $ j = $ j - 1 ; }
$ arr [ $ j + 1 ] = $ key ; } }
{ $ arr = array ( -12 , 11 , -13 , -5 , 6 , -7 , 5 , -3 , -6 ) ; $ n = sizeof ( $ arr ) ; RearrangePosNeg ( $ arr , $ n ) ; printArray ( $ arr , $ n ) ; }
function rearrange ( & $ arr , $ n ) {
$ temp = array ( ) ;
$ small = 0 ; $ large = $ n - 1 ;
$ flag = true ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ flag ) $ temp [ $ i ] = $ arr [ $ large -- ] ; else $ temp [ $ i ] = $ arr [ $ small ++ ] ; $ flag = ! $ flag ; }
$ arr = array ( 1 , 2 , 3 , 4 , 5 , 6 ) ; $ n = count ( $ arr ) ; echo " Original ▁ Arrayn STRNEWLINE " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; rearrange ( $ arr , $ n ) ; echo " Modified Arrayn " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function rearrange ( & $ arr , $ n ) {
$ max_idx = $ n - 1 ; $ min_idx = 0 ;
$ max_elem = $ arr [ $ n - 1 ] + 1 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ i % 2 == 0 ) { $ arr [ $ i ] += ( $ arr [ $ max_idx ] % $ max_elem ) * $ max_elem ; $ max_idx -- ; }
else { $ arr [ $ i ] += ( $ arr [ $ min_idx ] % $ max_elem ) * $ max_elem ; $ min_idx ++ ; } }
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ arr [ $ i ] = ( int ) ( $ arr [ $ i ] / $ max_elem ) ; }
$ arr = array ( 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ) ; $ n = sizeof ( $ arr ) ; echo " Original ▁ Array " . " STRNEWLINE " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; rearrange ( $ arr , $ n ) ; echo " Modified Array " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ;
function rearrange ( & $ arr , $ n ) { $ j = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] < 0 ) { if ( $ i != $ j ) { $ temp = $ arr [ $ i ] ; $ arr [ $ i ] = $ arr [ $ j ] ; $ arr [ $ j ] = $ temp ; } $ j ++ ; } } }
function printArray ( & $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; }
$ arr = array ( -1 , 2 , -3 , 4 , 5 , 6 , -7 , 8 , 9 ) ; $ n = sizeof ( $ arr ) ; rearrange ( $ arr , $ n ) ; printArray ( $ arr , $ n ) ; ? >
function segregateElements ( & $ arr , $ n ) {
$ temp = array ( 0 , $ n , NULL ) ;
$ j = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] >= 0 ) $ temp [ $ j ++ ] = $ arr [ $ i ] ;
if ( $ j == $ n $ j == 0 ) return ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] < 0 ) $ temp [ $ j ++ ] = $ arr [ $ i ] ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ arr [ $ i ] = $ temp [ $ i ] ; }
$ arr = array ( 1 , -1 , -3 , -2 , 7 , 5 , 11 , 6 ) ; $ n = sizeof ( $ arr ) ; segregateElements ( $ arr , $ n ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function rearrange ( & $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) { if ( $ i % 2 == 0 && $ arr [ $ i ] > $ arr [ $ i + 1 ] ) swap ( $ arr [ $ i ] , $ arr [ $ i + 1 ] ) ; if ( $ i % 2 != 0 && $ arr [ $ i ] < $ arr [ $ i + 1 ] ) swap ( $ arr [ $ i ] , $ arr [ $ i + 1 ] ) ; } }
function printArray ( & $ arr , $ size ) { for ( $ i = 0 ; $ i < $ size ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; echo " STRNEWLINE " ; }
$ arr = array ( 6 , 4 , 2 , 1 , 8 , 3 ) ; $ n = sizeof ( $ arr ) ; echo " Before ▁ rearranging : ▁ STRNEWLINE " ; printArray ( $ arr , $ n ) ; rearrange ( $ arr , $ n ) ; echo " After ▁ rearranging : ▁ STRNEWLINE " ; printArray ( $ arr , $ n ) ; ? >
function rearrange ( & $ a , $ size ) { $ positive = 0 ; $ negative = 1 ; while ( true ) {
while ( $ positive < $ size && $ a [ $ positive ] >= 0 ) $ positive += 2 ;
while ( $ negative < $ size && $ a [ $ negative ] <= 0 ) $ negative += 2 ;
if ( $ positive < $ size && $ negative < $ size ) { $ temp = $ a [ $ positive ] ; $ a [ $ positive ] = $ a [ $ negative ] ; $ a [ $ negative ] = $ temp ; }
else break ; } }
$ arr = array ( 1 , -3 , 5 , 6 , -3 , 6 , 7 , -4 , 9 , 10 ) ; $ n = sizeof ( $ arr ) ; rearrange ( $ arr , $ n ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function arrayEvenAndOdd ( $ arr , $ n ) { $ i = -1 ; $ j = 0 ; $ t ; while ( $ j != $ n ) { if ( $ arr [ $ j ] % 2 == 0 ) { $ i ++ ;
$ x = $ arr [ $ i ] ; $ arr [ $ i ] = $ arr [ $ j ] ; $ arr [ $ j ] = $ x ; } $ j ++ ; }
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; }
$ arr = array ( 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 ) ; $ n = sizeof ( $ arr ) ; arrayEvenAndOdd ( $ arr , $ n ) ; ? >
function largest ( $ arr , $ n ) { $ i ;
$ max = $ arr [ 0 ] ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] > $ max ) $ max = $ arr [ $ i ] ; return $ max ; }
$ arr = array ( 10 , 324 , 45 , 90 , 9808 ) ; $ n = sizeof ( $ arr ) ; echo " Largest ▁ in ▁ given ▁ array ▁ is ▁ " , largest ( $ arr , $ n ) ; ? >
function largest ( $ arr , $ n ) { return max ( $ arr ) ; }
$ arr = array ( 10 , 324 , 45 , 90 , 9808 ) ; $ n = count ( $ arr ) ; echo largest ( $ arr , $ n ) ; ? >
function findElements ( $ arr , $ n ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ count = 0 ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) if ( $ arr [ $ j ] > $ arr [ $ i ] ) $ count ++ ; if ( $ count >= 2 ) echo $ arr [ $ i ] . " ▁ " ; } }
$ arr = array ( 2 , -6 , 3 , 5 , 1 ) ; $ n = sizeof ( $ arr ) ; findElements ( $ arr , $ n ) ; ? >
function findElements ( $ arr , $ n ) { sort ( $ arr ) ; for ( $ i = 0 ; $ i < $ n - 2 ; $ i ++ ) echo $ arr [ $ i ] , " ▁ " ; }
$ arr = array ( 2 , -6 , 3 , 5 , 1 ) ; $ n = count ( $ arr ) ; findElements ( $ arr , $ n ) ; ? > ;
function findElements ( $ arr , $ n ) { $ first = PHP_INT_MIN ; $ second = PHP_INT_MIN ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ arr [ $ i ] > $ first ) { $ second = $ first ; $ first = $ arr [ $ i ] ; }
else if ( $ arr [ $ i ] > $ second ) $ second = $ arr [ $ i ] ; } for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] < $ second ) echo $ arr [ $ i ] , " ▁ " ; }
$ arr = array ( 2 , -6 , 3 , 5 , 1 ) ; $ n = count ( $ arr ) ; findElements ( $ arr , $ n ) ; ? >
function findMean ( & $ a , $ n ) { $ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ sum += $ a [ $ i ] ; return ( double ) $ sum / ( double ) $ n ; }
function findMedian ( & $ a , $ n ) {
sort ( $ a ) ;
if ( $ n % 2 != 0 ) return ( double ) $ a [ $ n / 2 ] ; return ( double ) ( $ a [ ( $ n - 1 ) / 2 ] + $ a [ $ n / 2 ] ) / 2.0 ; }
$ a = array ( 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 ) ; $ n = sizeof ( $ a ) ;
echo " Mean ▁ = ▁ " . findMean ( $ a , $ n ) . " STRNEWLINE " ; echo " Median ▁ = ▁ " . findMedian ( $ a , $ n ) ; ? >
function printSmall ( $ arr , $ n , $ k ) {
for ( $ i = $ k ; $ i < $ n ; ++ $ i ) {
$ max_var = $ arr [ $ k - 1 ] ; $ pos = $ k - 1 ; for ( $ j = $ k - 2 ; $ j >= 0 ; $ j -- ) { if ( $ arr [ $ j ] > $ max_var ) { $ max_var = $ arr [ $ j ] ; $ pos = $ j ; } }
if ( $ max_var > $ arr [ $ i ] ) { $ j = $ pos ; while ( $ j < $ k - 1 ) { $ arr [ $ j ] = $ arr [ $ j + 1 ] ; $ j ++ ; }
$ arr [ $ k - 1 ] = $ arr [ $ i ] ; } }
for ( $ i = 0 ; $ i < $ k ; $ i ++ ) echo $ arr [ $ i ] , " ▁ " ; }
$ arr = array ( 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 ) ; $ n = count ( $ arr ) ; $ k = 5 ; printSmall ( $ arr , $ n , $ k ) ; ? >
function sumNodes ( $ l ) {
$ leafNodeCount = ( $ l - 1 ) * ( $ l - 1 ) ; $ sumLastLevel = 0 ;
$ sumLastLevel = ( $ leafNodeCount * ( $ leafNodeCount + 1 ) ) / 2 ;
$ sum = $ sumLastLevel * $ l ; return $ sum ; }
$ l = 3 ; echo ( sumNodes ( $ l ) ) ; ? >
function add ( & $ arr , $ N , $ lo , $ hi , $ val ) { $ arr [ $ lo ] += $ val ; if ( $ hi != $ N - 1 ) $ arr [ $ hi + 1 ] -= $ val ; }
function updateArray ( & $ arr , $ N ) {
for ( $ i = 1 ; $ i < $ N ; $ i ++ ) $ arr [ $ i ] += $ arr [ $ i - 1 ] ; }
function printArr ( & $ arr , $ N ) { updateArray ( $ arr , $ N ) ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; echo " STRNEWLINE " ; }
$ N = 6 ; $ arr = array_fill ( 0 , $ N , NULL ) ;
add ( $ arr , $ N , 0 , 2 , 100 ) ; add ( $ arr , $ N , 1 , 5 , 100 ) ; add ( $ arr , $ N , 2 , 3 , 100 ) ; printArr ( $ arr , $ N ) ; ? >
function GCD ( $ a , $ b ) { if ( $ b == 0 ) return $ a ; return GCD ( $ b , $ a % $ b ) ; }
function FillPrefixSuffix ( & $ prefix , & $ arr , & $ suffix , $ n ) {
$ prefix [ 0 ] = $ arr [ 0 ] ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) $ prefix [ $ i ] = GCD ( $ prefix [ $ i - 1 ] , $ arr [ $ i ] ) ;
$ suffix [ $ n - 1 ] = $ arr [ $ n - 1 ] ; for ( $ i = $ n - 2 ; $ i >= 0 ; $ i -- ) $ suffix [ $ i ] = GCD ( $ suffix [ $ i + 1 ] , $ arr [ $ i ] ) ; }
function GCDoutsideRange ( $ l , $ r , & $ prefix , & $ suffix , $ n ) {
if ( $ l == 0 ) return $ suffix [ $ r + 1 ] ;
if ( $ r == $ n - 1 ) return $ prefix [ $ l - 1 ] ; return GCD ( $ prefix [ $ l - 1 ] , $ suffix [ $ r + 1 ] ) ; }
$ arr = array ( 2 , 6 , 9 ) ; $ n = sizeof ( $ arr ) ; $ prefix = array_fill ( 0 , $ n , NULL ) ; $ suffix = array_fill ( 0 , $ n , NULL ) ; FillPrefixSuffix ( $ prefix , $ arr , $ suffix , $ n ) ; $ l = 0 ; $ r = 0 ; echo GCDoutsideRange ( $ l , $ r , $ prefix , $ suffix , $ n ) . " " ; $ l = 1 ; $ r = 1 ; echo GCDoutsideRange ( $ l , $ r , $ prefix , $ suffix , $ n ) . " " ; $ l = 1 ; $ r = 2 ; echo GCDoutsideRange ( $ l , $ r , $ prefix , $ suffix , $ n ) . " " ; ? >
function countInRange ( $ arr , $ n , $ x , $ y ) {
$ count = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ arr [ $ i ] >= $ x && $ arr [ $ i ] <= $ y ) $ count ++ ; } return $ count ; }
$ arr = array ( 1 , 3 , 4 , 9 , 10 , 3 ) ; $ n = count ( $ arr ) ;
$ i = 1 ; $ j = 4 ; echo countInRange ( $ arr , $ n , $ i , $ j ) . " " ; $ i = 9 ; $ j = 12 ; echo countInRange ( $ arr , $ n , $ i , $ j ) . " " ; ? >
function lowerIndex ( $ arr , $ n , $ x ) { $ l = 0 ; $ h = $ n - 1 ; while ( $ l <= $ h ) { $ mid = ( $ l + $ h ) / 2 ; if ( $ arr [ $ mid ] >= $ x ) $ h = $ mid - 1 ; else $ l = $ mid + 1 ; } return $ l ; }
function upperIndex ( $ arr , $ n , $ y ) { $ l = 0 ; $ h = $ n - 1 ; while ( $ l <= $ h ) { $ mid = ( $ l + $ h ) / 2 ; if ( $ arr [ $ mid ] <= $ y ) $ l = $ mid + 1 ; else $ h = $ mid - 1 ; } return $ h ; }
function countInRange ( $ arr , $ n , $ x , $ y ) {
$ count = 0 ; $ count = ( upperIndex ( $ arr , $ n , $ y ) - lowerIndex ( $ arr , $ n , $ x ) + 1 ) ; $ t = floor ( $ count ) ; return $ t ; }
$ arr = array ( 1 , 4 , 4 , 9 , 10 , 3 ) ; $ n = sizeof ( $ arr ) ;
sort ( $ arr ) ;
$ i = 1 ; $ j = 4 ; echo countInRange ( $ arr , $ n , $ i , $ j ) , " " ; $ i = 9 ; $ j = 12 ; echo countInRange ( $ arr , $ n , $ i , $ j ) , " " ; ? >
function precompute ( & $ arr , $ n , & $ pre ) { $ pre [ $ n - 1 ] = $ arr [ $ n - 1 ] * pow ( 2 , 0 ) ; for ( $ i = $ n - 2 ; $ i >= 0 ; $ i -- ) $ pre [ $ i ] = $ pre [ $ i + 1 ] + $ arr [ $ i ] * ( 1 << ( $ n - 1 - $ i ) ) ; }
function decimalOfSubarr ( & $ arr , $ l , $ r , $ n , & $ pre ) {
if ( $ r != $ n - 1 ) return ( $ pre [ $ l ] - $ pre [ $ r + 1 ] ) / ( 1 << ( $ n - 1 - $ r ) ) ; return $ pre [ $ l ] / ( 1 << ( $ n - 1 - $ r ) ) ; }
$ arr = array ( 1 , 0 , 1 , 0 , 1 , 1 ) ; $ n = sizeof ( $ arr ) ; $ pre = array_fill ( 0 , $ n , NULL ) ; precompute ( $ arr , $ n , $ pre ) ; echo decimalOfSubarr ( $ arr , 2 , 4 , $ n , $ pre ) . " " ; echo decimalOfSubarr ( $ arr , 4 , 5 , $ n , $ pre ) . " " ; ? >
function answerQuery ( $ a , $ n , $ l , $ r ) {
$ count = 0 ;
$ l = $ l - 1 ;
for ( $ i = $ l ; $ i < $ r ; $ i ++ ) { $ element = $ a [ $ i ] ; $ divisors = 0 ;
for ( $ j = $ l ; $ j < $ r ; $ j ++ ) {
if ( $ a [ $ j ] % $ a [ $ i ] == 0 ) $ divisors ++ ; else break ; }
if ( $ divisors == ( $ r - $ l ) ) $ count ++ ; }
return $ count ; }
$ a = array ( 1 , 2 , 3 , 5 ) ; $ n = sizeof ( $ a ) ; $ l = 1 ; $ r = 4 ; echo answerQuery ( $ a , $ n , $ l , $ r ) . " STRNEWLINE " ; $ l = 2 ; $ r = 4 ; echo answerQuery ( $ a , $ n , $ l , $ r ) . " STRNEWLINE " ;
$ one = array ( ) ; $ MAX = 2147483647 ;
function make_prefix ( $ A , $ n ) { global $ one , $ MAX ; for ( $ j = 0 ; $ j < 32 ; $ j ++ ) $ one [ 0 ] [ $ j ] = 0 ;
for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) { $ a = $ A [ $ i - 1 ] ; for ( $ j = 0 ; $ j < 32 ; $ j ++ ) { $ x = pow ( 2 , $ j ) ;
if ( $ a & $ x ) $ one [ $ i ] [ $ j ] = 1 + $ one [ $ i - 1 ] [ $ j ] ; else $ one [ $ i ] [ $ j ] = $ one [ $ i - 1 ] [ $ j ] ; } } }
function Solve ( $ L , $ R ) { global $ one , $ MAX ; $ l = $ L ; $ r = $ R ; $ tot_bits = $ r - $ l + 1 ;
$ X = $ MAX ;
for ( $ i = 0 ; $ i < 31 ; $ i ++ ) {
$ x = $ one [ $ r ] [ $ i ] - $ one [ $ l - 1 ] [ $ i ] ;
if ( $ x >= ( $ tot_bits - $ x ) ) { $ ith_bit = pow ( 2 , $ i ) ;
$ X = $ X ^ $ ith_bit ; } } return $ X ; }
$ n = 5 ; $ q = 3 ; $ A = [ 210 , 11 , 48 , 22 , 133 ] ; $ L = [ 1 , 4 , 2 ] ; $ R = [ 3 , 14 , 4 ] ; make_prefix ( $ A , $ n ) ; for ( $ j = 0 ; $ j < $ q ; $ j ++ ) echo ( Solve ( $ L [ $ j ] , $ R [ $ j ] ) . " STRNEWLINE " ) ; ? >
function answer_query ( $ a , $ n , $ l , $ r ) {
$ count = 0 ; for ( $ i = $ l ; $ i < $ r ; $ i ++ ) if ( $ a [ $ i ] == $ a [ $ i + 1 ] ) $ count += 1 ; return $ count ; }
$ a = array ( 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 ) ; $ n = count ( $ a ) ;
$ L = 1 ; $ R = 8 ; echo ( answer_query ( $ a , $ n , $ L , $ R ) . " " ) ;
$ L = 0 ; $ R = 4 ; echo ( answer_query ( $ a , $ n , $ L , $ R ) . " " ) ; ? >
$ N = 1000 ;
$ prefixans = array_fill ( 0 , $ N , 0 ) ;
function countIndex ( $ a , $ n ) { global $ N , $ prefixans ;
for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) { if ( $ a [ $ i ] == $ a [ $ i + 1 ] ) $ prefixans [ $ i ] = 1 ; if ( $ i != 0 ) $ prefixans [ $ i ] += $ prefixans [ $ i - 1 ] ; } }
function answer_query ( $ l , $ r ) { global $ N , $ prefixans ; if ( $ l == 0 ) return $ prefixans [ $ r - 1 ] ; else return ( $ prefixans [ $ r - 1 ] - $ prefixans [ $ l - 1 ] ) ; }
$ a = array ( 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 ) ; $ n = count ( $ a ) ;
countIndex ( $ a , $ n ) ;
$ L = 1 ; $ R = 8 ; echo ( answer_query ( $ L , $ R ) . " " ) ;
$ L = 0 ; $ R = 4 ; echo ( answer_query ( $ L , $ R ) . " " ) ; ? >
function repeated_digit ( $ n ) { $ c = 10 ; $ a = array_fill ( 0 , $ c , 0 ) ;
while ( $ n > 0 ) { $ d = $ n % 10 ;
if ( $ a [ $ d ] > 0 ) {
return 0 ; } $ a [ $ d ] ++ ; $ n = ( int ) ( $ n / 10 ) ; }
return 1 ; }
function calculate ( $ L , $ R ) { $ answer = 0 ;
for ( $ i = $ L ; $ i <= $ R ; $ i ++ ) {
$ answer += repeated_digit ( $ i ) ; } return $ answer ; }
$ L = 1 ; $ R = 100 ;
echo calculate ( $ L , $ R ) ; ? >
function maxSubArraySum ( $ a , $ size ) { $ max_so_far = PHP_INT_MIN ; $ max_ending_here = 0 ; for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { $ max_ending_here = $ max_ending_here + $ a [ $ i ] ; if ( $ max_so_far < $ max_ending_here ) $ max_so_far = $ max_ending_here ; if ( $ max_ending_here < 0 ) $ max_ending_here = 0 ; } return $ max_so_far ; }
$ a = array ( -2 , -3 , 4 , -1 , -2 , 1 , 5 , -3 ) ; $ n = count ( $ a ) ; $ max_sum = maxSubArraySum ( $ a , $ n ) ; echo " Maximum ▁ contiguous ▁ sum ▁ is ▁ " , $ max_sum ; ? >
< ? php function maxSubArraySum ( & $ a , $ size ) { $ max_so_far = $ a [ 0 ] ; $ max_ending_here = 0 ; for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { $ max_ending_here = $ max_ending_here + $ a [ $ i ] ; if ( $ max_ending_here < 0 ) $ max_ending_here = 0 ;
else if ( $ max_so_far < $ max_ending_here ) $ max_so_far = $ max_ending_here ; } return $ max_so_far ; ? >
< ? php function maxSubArraySum ( $ a , $ size ) { $ max_so_far = $ a [ 0 ] ; $ curr_max = $ a [ 0 ] ; for ( $ i = 1 ; $ i < $ size ; $ i ++ ) { $ curr_max = max ( $ a [ $ i ] , $ curr_max + $ a [ $ i ] ) ; $ max_so_far = max ( $ max_so_far , $ curr_max ) ; } return $ max_so_far ; }
$ a = array ( -2 , -3 , 4 , -1 , -2 , 1 , 5 , -3 ) ; $ n = sizeof ( $ a ) ; $ max_sum = maxSubArraySum ( $ a , $ n ) ; echo " Maximum ▁ contiguous ▁ sum ▁ is ▁ " . $ max_sum ; ? >
function maxSubArraySum ( $ a , $ size ) { $ max_so_far = PHP_INT_MIN ; $ max_ending_here = 0 ; $ start = 0 ; $ end = 0 ; $ s = 0 ; for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { $ max_ending_here += $ a [ $ i ] ; if ( $ max_so_far < $ max_ending_here ) { $ max_so_far = $ max_ending_here ; $ start = $ s ; $ end = $ i ; } if ( $ max_ending_here < 0 ) { $ max_ending_here = 0 ; $ s = $ i + 1 ; } } echo " Maximum ▁ contiguous ▁ sum ▁ is ▁ " . $ max_so_far . " STRNEWLINE " ; echo " Starting ▁ index ▁ " . $ start . " " . STRNEWLINE " Ending index " ▁ . ▁ $ end ▁ . ▁ " " }
$ a = array ( -2 , -3 , 4 , -1 , -2 , 1 , 5 , -3 ) ; $ n = sizeof ( $ a ) ; $ max_sum = maxSubArraySum ( $ a , $ n ) ; ? >
function findMinAvgSubarray ( $ arr , $ n , $ k ) {
if ( $ n < $ k ) return ;
$ res_index = 0 ;
$ curr_sum = 0 ; for ( $ i = 0 ; $ i < $ k ; $ i ++ ) $ curr_sum += $ arr [ $ i ] ;
$ min_sum = $ curr_sum ;
for ( $ i = $ k ; $ i < $ n ; $ i ++ ) {
$ curr_sum += $ arr [ $ i ] - $ arr [ $ i - $ k ] ;
if ( $ curr_sum < $ min_sum ) { $ min_sum = $ curr_sum ; $ res_index = ( $ i - $ k + 1 ) ; } } echo " Subarray between [ " ▁ , $ res _ index ▁ , ▁ " , " ▁ , $ res _ index ▁ + ▁ $ k ▁ - ▁ 1 , ▁ " ] has minimum average " ; }
$ arr = array ( 3 , 7 , 90 , 20 , 10 , 50 , 40 ) ;
$ k = 3 ; $ n = sizeof ( $ arr ) / sizeof ( $ arr [ 0 ] ) ; findMinAvgSubarray ( $ arr , $ n , $ k ) ; return 0 ; ? >
function minJumps ( $ arr , $ n ) {
$ jumps [ $ n ] = array ( ) ; $ min ;
$ jumps [ $ n - 1 ] = array ( 0 ) ;
for ( $ i = $ n - 2 ; $ i >= 0 ; $ i -- ) {
if ( $ arr [ $ i ] == 0 ) $ jumps [ $ i ] = PHP_INT_MAX ;
else if ( $ arr [ $ i ] >= ( $ n - $ i ) - 1 ) $ jumps [ $ i ] = 1 ;
else {
$ min = PHP_INT_MAX ;
for ( $ j = $ i + 1 ; $ j < $ n && $ j <= $ arr [ $ i ] + $ i ; $ j ++ ) { if ( $ min > $ jumps [ $ j ] ) $ min = $ jumps [ $ j ] ; }
if ( $ min != PHP_INT_MAX ) $ jumps [ $ i ] = $ min + 1 ; else
$ jumps [ $ i ] = $ min ; } } return $ jumps [ 0 ] ; }
$ arr = array ( 1 , 3 , 6 , 1 , 0 , 9 ) ; $ size = sizeof ( $ arr ) ; echo " Minimum ▁ number ▁ of ▁ jumps ▁ to ▁ reach " , " ▁ end ▁ is ▁ " , minJumps ( $ arr , $ size ) ; ? >
function smallestSubWithSum ( $ arr , $ n , $ x ) {
$ min_len = $ n + 1 ;
for ( $ start = 0 ; $ start < $ n ; $ start ++ ) {
$ curr_sum = $ arr [ $ start ] ;
if ( $ curr_sum > $ x ) return 1 ;
for ( $ end = $ start + 1 ; $ end < $ n ; $ end ++ ) {
$ curr_sum += $ arr [ $ end ] ;
if ( $ curr_sum > $ x && ( $ end - $ start + 1 ) < $ min_len ) $ min_len = ( $ end - $ start + 1 ) ; } } return $ min_len ; }
$ arr1 = array ( 1 , 4 , 45 , 6 , 10 , 19 ) ; $ x = 51 ; $ n1 = sizeof ( $ arr1 ) ; $ res1 = smallestSubWithSum ( $ arr1 , $ n1 , $ x ) ; if ( ( $ res1 == $ n1 + 1 ) == true ) echo " Not ▁ possible STRNEWLINE " ; else echo $ res1 , " STRNEWLINE " ; $ arr2 = array ( 1 , 10 , 5 , 2 , 7 ) ; $ n2 = sizeof ( $ arr2 ) ; $ x = 9 ; $ res2 = smallestSubWithSum ( $ arr2 , $ n2 , $ x ) ; if ( ( $ res2 == $ n2 + 1 ) == true ) echo " Not ▁ possible STRNEWLINE " ; else echo $ res2 , " STRNEWLINE " ; $ arr3 = array ( 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ) ; $ n3 = sizeof ( $ arr3 ) ; $ x = 280 ; $ res3 = smallestSubWithSum ( $ arr3 , $ n3 , $ x ) ; if ( ( $ res3 == $ n3 + 1 ) == true ) echo " Not ▁ possible STRNEWLINE " ; else echo $ res3 , " STRNEWLINE " ; ? >
function smallestSubWithSum ( $ arr , $ n , $ x ) {
$ curr_sum = 0 ; $ min_len = $ n + 1 ;
$ start = 0 ; $ end = 0 ; while ( $ end < $ n ) {
while ( $ curr_sum <= $ x && $ end < $ n ) $ curr_sum += $ arr [ $ end ++ ] ;
while ( $ curr_sum > $ x && $ start < $ n ) {
if ( $ end - $ start < $ min_len ) $ min_len = $ end - $ start ;
$ curr_sum -= $ arr [ $ start ++ ] ; } } return $ min_len ; }
$ arr1 = array ( 1 , 4 , 45 , 6 , 10 , 19 ) ; $ x = 51 ; $ n1 = sizeof ( $ arr1 ) ; $ res1 = smallestSubWithSum ( $ arr1 , $ n1 , $ x ) ; if ( $ res1 == $ n1 + 1 ) echo " Not ▁ possible STRNEWLINE " ; else echo $ res1 , " STRNEWLINE " ; $ arr2 = array ( 1 , 10 , 5 , 2 , 7 ) ; $ n2 = sizeof ( $ arr2 ) ; $ x = 9 ; $ res2 = smallestSubWithSum ( $ arr2 , $ n2 , $ x ) ; if ( $ res2 == $ n2 + 1 ) echo " Not ▁ possible STRNEWLINE " ; else echo $ res2 , " STRNEWLINE " ; $ arr3 = array ( 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ) ; $ n3 = sizeof ( $ arr3 ) ; $ x = 280 ; $ res3 = smallestSubWithSum ( $ arr3 , $ n3 , $ x ) ; if ( $ res3 == $ n3 + 1 ) echo " Not ▁ possible STRNEWLINE " ; else echo $ res3 , " STRNEWLINE " ; ? >
function findMaxAverage ( $ arr , $ n , $ k ) {
if ( $ k > $ n ) return -1 ;
$ csum = array ( ) ; $ csum [ 0 ] = $ arr [ 0 ] ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) $ csum [ $ i ] = $ csum [ $ i - 1 ] + $ arr [ $ i ] ;
$ max_sum = $ csum [ $ k - 1 ] ; $ max_end = $ k - 1 ;
for ( $ i = $ k ; $ i < $ n ; $ i ++ ) { $ curr_sum = $ csum [ $ i ] - $ csum [ $ i - $ k ] ; if ( $ curr_sum > $ max_sum ) { $ max_sum = $ curr_sum ; $ max_end = $ i ; } }
return $ max_end - $ k + 1 ; }
$ arr = array ( 1 , 12 , -5 , -6 , 50 , 3 ) ; $ k = 4 ; $ n = count ( $ arr ) ; echo " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ " , " length ▁ " , $ k , " ▁ begins ▁ at ▁ index ▁ " , findMaxAverage ( $ arr , $ n , $ k ) ; ? >
function findMaxAverage ( $ arr , $ n , $ k ) {
if ( $ k > $ n ) return -1 ;
$ sum = $ arr [ 0 ] ; for ( $ i = 1 ; $ i < $ k ; $ i ++ ) $ sum += $ arr [ $ i ] ; $ max_sum = $ sum ; $ max_end = $ k - 1 ;
for ( $ i = $ k ; $ i < $ n ; $ i ++ ) { $ sum = $ sum + $ arr [ $ i ] - $ arr [ $ i - $ k ] ; if ( $ sum > $ max_sum ) { $ max_sum = $ sum ; $ max_end = $ i ; } }
return $ max_end - $ k + 1 ; }
$ arr = array ( 1 , 12 , -5 , -6 , 50 , 3 ) ; $ k = 4 ; $ n = count ( $ arr ) ; echo " The ▁ maximum ▁ average ▁ subarray ▁ of ▁ " , " length ▁ " , $ k , " ▁ begins ▁ at ▁ index ▁ " , findMaxAverage ( $ arr , $ n , $ k ) ; ? >
function countMinOperations ( $ target , $ n ) {
$ result = 0 ;
while ( 1 ) {
$ zero_count = 0 ;
$ i = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ target [ $ i ] & 1 ) break ;
else if ( $ target [ $ i ] == 0 ) $ zero_count ++ ; }
if ( $ zero_count == $ n ) return $ result ;
if ( $ i == $ n ) {
for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ target [ $ j ] = $ target [ $ j ] / 2 ; $ result ++ ; }
for ( $ j = $ i ; $ j < $ n ; $ j ++ ) { if ( $ target [ $ j ] & 1 ) { $ target [ $ j ] -- ; $ result ++ ; } } } }
$ arr = array ( 16 , 16 , 16 ) ; $ n = sizeof ( $ arr ) ; echo " Minimum ▁ number ▁ of ▁ steps ▁ required ▁ to ▁ STRNEWLINE " . " get ▁ the ▁ given ▁ target ▁ array ▁ is ▁ " . countMinOperations ( $ arr , $ n ) ; ? >
function findMinOps ( $ arr , $ n ) {
$ ans = 1 ;
for ( $ i = 0 , $ j = $ n - 1 ; $ i <= $ j {
if ( $ arr [ $ i ] == $ arr [ $ j ] ) { $ i ++ ; $ j -- ; }
else if ( $ arr [ $ i ] > $ arr [ $ j ] ) {
$ j -- ; $ arr [ $ j ] += $ arr [ $ j + 1 ] ; $ ans ++ ; }
else { $ i ++ ; $ arr [ $ i ] += $ arr [ $ i - 1 ] ; $ ans ++ ; } } return $ ans ; }
$ arr [ ] = array ( 1 , 4 , 5 , 9 , 1 ) ; $ n = sizeof ( $ arr ) ; echo " Count ▁ of ▁ minimum ▁ operations ▁ is ▁ " , findMinOps ( $ arr , $ n ) ; ? >
function findSmallest ( $ arr , $ n ) {
$ res = 1 ;
for ( $ i = 0 ; $ i < $ n and $ arr [ $ i ] <= $ res ; $ i ++ ) $ res = $ res + $ arr [ $ i ] ; return $ res ; }
$ arr1 = array ( 1 , 3 , 4 , 5 ) ; $ n1 = count ( $ arr1 ) ; echo findSmallest ( $ arr1 , $ n1 ) , " STRNEWLINE " ; $ arr2 = array ( 1 , 2 , 6 , 10 , 11 , 15 ) ; $ n2 = count ( $ arr2 ) ; echo findSmallest ( $ arr2 , $ n2 ) , " STRNEWLINE " ; $ arr3 = array ( 1 , 1 , 1 , 1 ) ; $ n3 = count ( $ arr3 ) ; echo findSmallest ( $ arr3 , $ n3 ) , " STRNEWLINE " ; $ arr4 = array ( 1 , 1 , 3 , 4 ) ; $ n4 = count ( $ arr4 ) ; echo findSmallest ( $ arr4 , $ n4 ) ; ? >
function findMinDiff ( $ arr , $ n ) {
$ diff = PHP_INT_MAX ;
for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) if ( abs ( $ arr [ $ i ] - $ arr [ $ j ] ) < $ diff ) $ diff = abs ( $ arr [ $ i ] - $ arr [ $ j ] ) ;
return $ diff ; }
$ arr = array ( 1 , 5 , 3 , 19 , 18 , 25 ) ; $ n = sizeof ( $ arr ) ; echo " Minimum ▁ difference ▁ is ▁ " , findMinDiff ( $ arr , $ n ) ; ? >
function findMinDiff ( $ arr , $ n ) {
sort ( $ arr ) ;
$ diff = PHP_INT_MAX ;
for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) if ( $ arr [ $ i + 1 ] - $ arr [ $ i ] < $ diff ) $ diff = $ arr [ $ i + 1 ] - $ arr [ $ i ] ;
return $ diff ; }
$ arr = array ( 1 , 5 , 3 , 19 , 18 , 25 ) ; $ n = sizeof ( $ arr ) ; echo " Minimum ▁ difference ▁ is ▁ " , findMinDiff ( $ arr , $ n ) ; ? >
$ a = 2 ; $ b = 10 ; $ size = abs ( $ b - $ a ) + 1 ; $ array = array_fill ( 0 , $ size , 0 ) ;
for ( $ i = $ a ; $ i <= $ b ; $ i ++ ) if ( $ i % 2 == 0 $ i % 5 == 0 ) $ array [ $ i - $ a ] = 1 ; echo " MULTIPLES ▁ of ▁ 2 ▁ and ▁ 5 : STRNEWLINE " ; for ( $ i = $ a ; $ i <= $ b ; $ i ++ ) if ( $ array [ $ i - $ a ] == 1 ) echo $ i . " " ; ? >
function longestCommonSum ( $ arr1 , $ arr2 , $ n ) {
$ maxLen = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ sum1 = 0 ; $ sum2 = 0 ;
for ( $ j = $ i ; $ j < $ n ; $ j ++ ) {
$ sum1 += $ arr1 [ $ j ] ; $ sum2 += $ arr2 [ $ j ] ;
if ( $ sum1 == $ sum2 ) { $ len = $ j - $ i + 1 ; if ( $ len > $ maxLen ) $ maxLen = $ len ; } } } return $ maxLen ; }
$ arr1 = array ( 0 , 1 , 0 , 1 , 1 , 1 , 1 ) ; $ arr2 = array ( 1 , 1 , 1 , 1 , 1 , 0 , 1 ) ; $ n = sizeof ( $ arr1 ) ; echo " Length ▁ of ▁ the ▁ longest ▁ common ▁ span ▁ " . " with ▁ same ▁ " , " sum ▁ is ▁ " , longestCommonSum ( $ arr1 , $ arr2 , $ n ) ; ? >
function sortedAfterSwap ( $ A , $ B , $ n ) {
for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) { if ( $ B [ $ i ] ) { $ j = $ i ; while ( $ B [ $ j ] ) $ j ++ ;
sort ( $ A ) ; $ i = $ j ; } }
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ A [ $ i ] != $ i + 1 ) return false ; } return true ; }
$ A = array ( 1 , 2 , 5 , 3 , 4 , 6 ) ; $ B = array ( 0 , 1 , 1 , 1 , 0 ) ; $ n = count ( $ A ) ; if ( sortedAfterSwap ( $ A , $ B , $ n ) ) echo " A ▁ can ▁ be ▁ sorted STRNEWLINE " ; else echo " A ▁ can ▁ not ▁ be ▁ sorted STRNEWLINE " ; ? >
function sortedAfterSwap ( & $ A , & $ B , $ n ) { for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) { if ( $ B [ $ i ] ) { if ( $ A [ $ i ] != $ i + 1 ) { $ t = $ A [ $ i ] ; $ A [ $ i ] = $ A [ $ i + 1 ] ; $ A [ $ i + 1 ] = $ t ; } } }
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ A [ $ i ] != $ i + 1 ) return false ; } return true ; }
$ A = array ( 1 , 2 , 5 , 3 , 4 , 6 ) ; $ B = array ( 0 , 1 , 1 , 1 , 0 ) ; $ n = sizeof ( $ A ) ; if ( sortedAfterSwap ( $ A , $ B , $ n ) ) echo " A ▁ can ▁ be ▁ sorted STRNEWLINE " ; else echo " A ▁ can ▁ not ▁ be ▁ sorted STRNEWLINE " ; ? >
function segregate0and1 ( $ arr , $ n ) { $ type0 = 0 ; $ type1 = $ n - 1 ; while ( $ type0 < $ type1 ) { if ( $ arr [ $ type0 ] == 1 ) { $ temp = $ arr [ $ type0 ] ; $ arr [ $ type0 ] = $ arr [ $ type1 ] ; $ arr [ $ type1 ] = $ temp ; $ type1 -- ; } else { $ type0 ++ ; } } return $ arr ; }
$ arr = array ( 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 ) ; $ n = count ( $ arr ) ; $ arr1 = segregate0and1 ( $ arr , $ n ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr1 [ $ i ] . " ▁ " ; ? >
function increasing ( $ a , $ n ) { for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) if ( $ a [ $ i ] >= $ a [ $ i + 1 ] ) return false ; return true ; }
function decreasing ( $ a , $ n ) { for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) if ( $ a [ $ i ] < $ a [ $ i + 1 ] ) return false ; return true ; } function shortestUnsorted ( $ a , $ n ) {
if ( increasing ( $ a , $ n ) == true || decreasing ( $ a , $ n ) == true ) return 0 ; else return 3 ; }
$ ar = array ( 7 , 9 , 10 , 8 , 11 ) ; $ n = sizeof ( $ ar ) ; echo shortestUnsorted ( $ ar , $ n ) ; ? >
function printUnion ( $ arr1 , $ arr2 , $ m , $ n ) { $ i = 0 ; $ j = 0 ; while ( $ i < $ m && $ j < $ n ) { if ( $ arr1 [ $ i ] < $ arr2 [ $ j ] ) echo ( $ arr1 [ $ i ++ ] . " ▁ " ) ; else if ( $ arr2 [ $ j ] < $ arr1 [ $ i ] ) echo ( $ arr2 [ $ j ++ ] . " ▁ " ) ; else { echo ( $ arr2 [ $ j ++ ] . " " ) ; $ i ++ ; } }
while ( $ i < $ m ) echo ( $ arr1 [ $ i ++ ] . " ▁ " ) ; while ( $ j < $ n ) echo ( $ arr2 [ $ j ++ ] . " ▁ " ) ; }
$ arr1 = array ( 1 , 2 , 4 , 5 , 6 ) ; $ arr2 = array ( 2 , 3 , 5 , 7 ) ; $ m = sizeof ( $ arr1 ) ; $ n = sizeof ( $ arr2 ) ; printUnion ( $ arr1 , $ arr2 , $ m , $ n ) ; ? >
function printIntersection ( $ arr1 , $ arr2 , $ m , $ n ) { $ i = 0 ; $ j = 0 ; while ( $ i < $ m && $ j < $ n ) { if ( $ arr1 [ $ i ] < $ arr2 [ $ j ] ) $ i ++ ; else if ( $ arr2 [ $ j ] < $ arr1 [ $ i ] ) $ j ++ ; else { echo $ arr2 [ $ j ] , " " ; $ i ++ ; $ j ++ ; } } }
$ arr1 = array ( 1 , 2 , 4 , 5 , 6 ) ; $ arr2 = array ( 2 , 3 , 5 , 7 ) ; $ m = count ( $ arr1 ) ; $ n = count ( $ arr2 ) ;
printIntersection ( $ arr1 , $ arr2 , $ m , $ n ) ; ? >
function printUnion ( $ arr1 , $ arr2 , $ m , $ n ) {
if ( $ m > $ n ) { $ tempp = $ arr1 ; $ arr1 = $ arr2 ; $ arr2 = $ tempp ; $ temp = $ m ; $ m = $ n ; $ n = $ temp ; }
sort ( $ arr1 ) ; for ( $ i = 0 ; $ i < $ m ; $ i ++ ) echo $ arr1 [ $ i ] . " ▁ " ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( binarySearch ( $ arr1 , 0 , $ m - 1 , $ arr2 [ $ i ] ) == -1 ) echo $ arr2 [ $ i ] . " ▁ " ; }
function printIntersection ( $ arr1 , $ arr2 , $ m , $ n ) {
if ( $ m > $ n ) { $ tempp = $ arr1 ; $ arr1 = $ arr2 ; $ arr2 = $ tempp ; $ temp = $ m ; $ m = $ n ; $ n = $ temp ; }
sort ( $ arr1 ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( binarySearch ( $ arr1 , 0 , $ m - 1 , $ arr2 [ $ i ] ) != -1 ) echo $ arr2 [ $ i ] . " ▁ " ; }
function binarySearch ( $ arr , $ l , $ r , $ x ) { if ( $ r >= $ l ) { $ mid = ( int ) ( $ l + ( $ r - $ l ) / 2 ) ;
if ( $ arr [ $ mid ] == $ x ) return $ mid ;
if ( $ arr [ $ mid ] > $ x ) return binarySearch ( $ arr , $ l , $ mid - 1 , $ x ) ;
return binarySearch ( $ arr , $ mid + 1 , $ r , $ x ) ; }
return -1 ; }
$ arr1 = array ( 7 , 1 , 5 , 2 , 3 , 6 ) ; $ arr2 = array ( 3 , 8 , 6 , 20 , 7 ) ; $ m = count ( $ arr1 ) ; $ n = count ( $ arr2 ) ;
echo " Union ▁ of ▁ two ▁ arrays ▁ is ▁ STRNEWLINE " ; printUnion ( $ arr1 , $ arr2 , $ m , $ n ) ; echo " Intersection of two arrays is " ; printIntersection ( $ arr1 , $ arr2 , $ m , $ n ) ; ? >
function intersection ( $ a , $ b , $ n , $ m ) { $ i = 0 ; $ j = 0 ; while ( $ i < $ n && $ j < $ m ) { if ( $ a [ $ i ] > $ b [ $ j ] ) { $ j ++ ; } else if ( $ b [ $ j ] > $ a [ $ i ] ) { $ i ++ ; } else {
echo ( $ a [ $ i ] . " " ) ; $ i ++ ; $ j ++ ; } } }
$ a = array ( 1 , 3 , 2 , 3 , 4 , 5 , 5 , 6 ) ; $ b = array ( 3 , 3 , 5 ) ; $ n = sizeof ( $ a ) ; $ m = sizeof ( $ b ) ;
sort ( $ a ) ; sort ( $ b ) ;
intersection ( $ a , $ b , $ n , $ m ) ; ? >
function countPairsWithDiffK ( $ arr , $ n , $ k ) { $ count = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) if ( $ arr [ $ i ] - $ arr [ $ j ] == $ k or $ arr [ $ j ] - $ arr [ $ i ] == $ k ) $ count ++ ; } return $ count ; }
$ arr = array ( 1 , 5 , 3 , 4 , 2 ) ; $ n = count ( $ arr ) ; $ k = 3 ; echo " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " , countPairsWithDiffK ( $ arr , $ n , $ k ) ; ? >
function binarySearch ( $ arr , $ low , $ high , $ x ) { if ( $ high >= $ low ) { $ mid = $ low + ( $ high - $ low ) / 2 ; if ( $ x == $ arr [ $ mid ] ) return $ mid ; if ( $ x > $ arr [ $ mid ] ) return binarySearch ( $ arr , ( $ mid + 1 ) , $ high , $ x ) ; else return binarySearch ( $ arr , $ low , ( $ mid - 1 ) , $ x ) ; } return -1 ; }
function countPairsWithDiffK ( $ arr , $ n , $ k ) { $ count = 0 ; $ i ;
sort ( $ arr ) ;
for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) if ( binarySearch ( $ arr , $ i + 1 , $ n - 1 , $ arr [ $ i ] + $ k ) != -1 ) $ count ++ ; return $ count ; }
$ arr = array ( 1 , 5 , 3 , 4 , 2 ) ; $ n = count ( $ arr ) ; $ k = 3 ; echo " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " , countPairsWithDiffK ( $ arr , $ n , $ k ) ; ? >
function countPairsWithDiffK ( $ arr , $ n , $ k ) { $ count = 0 ;
sort ( $ arr ) ; $ l = 0 ; $ r = 0 ; while ( $ r < $ n ) { if ( $ arr [ $ r ] - $ arr [ $ l ] == $ k ) { $ count ++ ; $ l ++ ; $ r ++ ; } else if ( $ arr [ $ r ] - $ arr [ $ l ] > $ k ) $ l ++ ;
else $ r ++ ; } return $ count ; }
$ arr = array ( 1 , 5 , 3 , 4 , 2 ) ; $ n = count ( $ arr ) ; $ k = 3 ; echo " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " , countPairsWithDiffK ( $ arr , $ n , $ k ) ; ? >
function constructArr ( $ pair ) { $ arr = array ( ) ; $ n = 5 ; $ arr [ 0 ] = intval ( ( $ pair [ 0 ] + $ pair [ 1 ] - $ pair [ $ n - 1 ] ) / 2 ) ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) $ arr [ $ i ] = $ pair [ $ i - 1 ] - $ arr [ 0 ] ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; }
$ pair = array ( 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 ) ; constructArr ( $ pair ) ; ? >
function merge ( & $ ar1 , & $ ar2 , $ m , $ n ) {
for ( $ i = $ n - 1 ; $ i >= 0 ; $ i -- ) {
$ last = $ ar1 [ $ m - 1 ] ; for ( $ j = $ m - 2 ; $ j >= 0 && $ ar1 [ $ j ] > $ ar2 [ $ i ] ; $ j -- ) $ ar1 [ $ j + 1 ] = $ ar1 [ $ j ] ;
if ( $ j != $ m - 2 $ last > $ ar2 [ $ i ] ) { $ ar1 [ $ j + 1 ] = $ ar2 [ $ i ] ; $ ar2 [ $ i ] = $ last ; } } }
$ ar1 = array ( 1 , 5 , 9 , 10 , 15 , 20 ) ; $ ar2 = array ( 2 , 3 , 8 , 13 ) ; $ m = sizeof ( $ ar1 ) / sizeof ( $ ar1 [ 0 ] ) ; $ n = sizeof ( $ ar2 ) / sizeof ( $ ar2 [ 0 ] ) ; merge ( $ ar1 , $ ar2 , $ m , $ n ) ; echo " First Array : " for ( $ i = 0 ; $ i < $ m ; $ i ++ ) echo $ ar1 [ $ i ] . " ▁ " ; echo " Second Array : " for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ ar2 [ $ i ] . " ▁ " ; return 0 ; ? >
function minMaxProduct ( $ arr1 , $ arr2 , $ n1 , $ n2 ) {
sort ( $ arr1 ) ; sort ( $ arr2 ) ;
return $ arr1 [ $ n1 - 1 ] * $ arr2 [ 0 ] ; }
$ arr1 = array ( 10 , 2 , 3 , 6 , 4 , 1 ) ; $ arr2 = array ( 5 , 1 , 4 , 2 , 6 , 9 ) ; $ n1 = count ( $ arr1 ) ; $ n2 = count ( $ arr2 ) ; echo minMaxProduct ( $ arr1 , $ arr2 , $ n1 , $ n2 ) ; ? >
function minMaxProduct ( $ arr1 , $ arr2 , $ n1 , $ n2 ) {
$ max = $ arr1 [ 0 ] ;
$ min = $ arr2 [ 0 ] ; $ i ; for ( $ i = 1 ; $ i < $ n1 && $ i < $ n2 ; ++ $ i ) {
if ( $ arr1 [ $ i ] > $ max ) $ max = $ arr1 [ $ i ] ;
if ( $ arr2 [ $ i ] < $ min ) $ min = $ arr2 [ $ i ] ; }
while ( $ i < $ n1 ) { if ( $ arr1 [ $ i ] > $ max ) $ max = $ arr1 [ $ i ] ; $ i ++ ; } while ( $ i < $ n2 ) { if ( $ arr2 [ $ i ] < $ min ) $ min = $ arr2 [ $ i ] ; $ i ++ ; } return $ max * $ min ; }
$ arr1 = array ( 10 , 2 , 3 , 6 , 4 , 1 ) ; $ arr2 = array ( 5 , 1 , 4 , 2 , 6 , 9 ) ; $ n1 = count ( $ arr1 ) ; $ n2 = count ( $ arr2 ) ; echo minMaxProduct ( $ arr1 , $ arr2 , $ n1 , $ n2 ) ; ? >
function insertSorted ( & $ arr , $ n , $ key , $ capacity ) {
if ( $ n >= $ capacity ) return $ n ; array_push ( $ arr , $ key ) ; return ( $ n + 1 ) ; }
$ arr = array ( 12 , 16 , 20 , 40 , 50 , 70 ) ; $ capacity = 20 ; $ n = 6 ; $ key = 26 ; echo " Before ▁ Insertion : ▁ " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ;
$ n = insertSorted ( $ arr , $ n , $ key , $ capacity ) ; echo " After Insertion : " for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function findElement ( & $ arr , $ n , $ key ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] == $ key ) return $ i ; return -1 ; }
function deleteElement ( & $ arr , $ n , $ key ) {
$ pos = findElement ( $ arr , $ n , $ key ) ; if ( $ pos == -1 ) { echo " Element ▁ not ▁ found " ; return $ n ; }
for ( $ i = $ pos ; $ i < $ n - 1 ; $ i ++ ) $ arr [ $ i ] = $ arr [ $ i + 1 ] ; return $ n - 1 ; }
$ arr = array ( 10 , 50 , 30 , 40 , 20 ) ; $ n = count ( $ arr ) ; $ key = 30 ; echo " Array ▁ before ▁ deletion STRNEWLINE " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; $ n = deleteElement ( $ arr , $ n , $ key ) ; echo " Array after deletion " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function findCommon ( $ ar1 , $ ar2 , $ ar3 , $ n1 , $ n2 , $ n3 ) {
$ i = 0 ; $ j = 0 ; $ k = 0 ;
while ( $ i < $ n1 && $ j < $ n2 && $ k < $ n3 ) {
if ( $ ar1 [ $ i ] == $ ar2 [ $ j ] && $ ar2 [ $ j ] == $ ar3 [ $ k ] ) { echo $ ar1 [ $ i ] , " " ; $ i ++ ; $ j ++ ; $ k ++ ; }
else if ( $ ar1 [ $ i ] < $ ar2 [ $ j ] ) $ i ++ ;
else if ( $ ar2 [ $ j ] < $ ar3 [ $ k ] ) $ j ++ ;
else $ k ++ ; } }
$ ar1 = array ( 1 , 5 , 10 , 20 , 40 , 80 ) ; $ ar2 = array ( 6 , 7 , 20 , 80 , 100 ) ; $ ar3 = array ( 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 ) ; $ n1 = count ( $ ar1 ) ; $ n2 = count ( $ ar2 ) ; $ n3 = count ( $ ar3 ) ; echo " Common ▁ Elements ▁ are ▁ " ; findCommon ( $ ar1 , $ ar2 , $ ar3 , $ n1 , $ n2 , $ n3 ) ; ? >
function binarySearch ( $ arr , $ l , $ r , $ x ) { if ( $ r >= $ l ) { $ mid = $ l + ( $ r - $ l ) / 2 ; if ( $ arr [ $ mid ] == $ x ) return $ mid ; if ( $ arr [ $ mid ] > $ x ) return binarySearch ( $ arr , $ l , $ mid - 1 , $ x ) ; return binarySearch ( $ arr , $ mid + 1 , $ r , $ x ) ; } return -1 ; }
function findPos ( $ arr , $ key ) { $ l = 0 ; $ h = 1 ; $ val = $ arr [ 0 ] ;
while ( $ val < $ key ) {
$ l = $ h ;
$ h = 2 * $ h ;
$ val = $ arr [ $ h ] ; }
return binarySearch ( $ arr , $ l , $ h , $ key ) ; }
$ arr = array ( 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 ) ; $ ans = findPos ( $ arr , 10 ) ; if ( $ ans == -1 ) echo " Element ▁ not ▁ found " ; else echo " Element ▁ found ▁ at ▁ index ▁ " , $ ans ; ? >
function findSingle ( $ ar , $ ar_size ) {
$ res = $ ar [ 0 ] ; for ( $ i = 1 ; $ i < $ ar_size ; $ i ++ ) $ res = $ res ^ $ ar [ $ i ] ; return $ res ; }
$ ar = array ( 2 , 3 , 5 , 4 , 5 , 3 , 4 ) ; $ n = count ( $ ar ) ; echo " Element ▁ occurring ▁ once ▁ is ▁ " , findSingle ( $ ar , $ n ) ; ? >
function isPresent ( $ B , $ m , $ x ) { for ( $ i = 0 ; $ i < $ m ; $ i ++ ) if ( $ B [ $ i ] == $ x ) return true ; return false ; }
function findMaxSubarraySumUtil ( $ A , $ B , $ n , $ m ) {
$ max_so_far = PHP_INT_MIN ; $ curr_max = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( isPresent ( $ B , $ m , $ A [ $ i ] ) ) { $ curr_max = 0 ; continue ; }
$ curr_max = max ( $ A [ $ i ] , $ curr_max + $ A [ $ i ] ) ; $ max_so_far = max ( $ max_so_far , $ curr_max ) ; } return $ max_so_far ; }
function findMaxSubarraySum ( $ A , $ B , $ n , $ m ) { $ maxSubarraySum = findMaxSubarraySumUtil ( $ A , $ B , $ n , $ m ) ;
if ( $ maxSubarraySum == PHP_INT_MIN ) { echo ( " Maximum ▁ Subarray ▁ " . " Sum ▁ cant ▁ be ▁ found STRNEWLINE " ) ; } else { echo ( " The ▁ Maximum ▁ Subarray ▁ Sum ▁ = ▁ " . $ maxSubarraySum . " STRNEWLINE " ) ; } }
$ A = array ( 3 , 4 , 5 , -4 , 6 ) ; $ B = array ( 1 , 8 , 5 ) ; $ n = count ( $ A ) ; $ m = count ( $ B ) ;
findMaxSubarraySum ( $ A , $ B , $ n , $ m ) ; ? >
function findMaxSum ( $ arr , $ n ) { $ res = PHP_INT_MIN ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ prefix_sum = $ arr [ $ i ] ; for ( $ j = 0 ; $ j < $ i ; $ j ++ ) $ prefix_sum += $ arr [ $ j ] ; $ suffix_sum = $ arr [ $ i ] ; for ( $ j = $ n - 1 ; $ j > $ i ; $ j -- ) $ suffix_sum += $ arr [ $ j ] ; if ( $ prefix_sum == $ suffix_sum ) $ res = max ( $ res , $ prefix_sum ) ; } return $ res ; }
$ arr = array ( -2 , 5 , 3 , 1 , 2 , 6 , -4 , 2 ) ; $ n = count ( $ arr ) ; echo findMaxSum ( $ arr , $ n ) ; ? >
function findMaxSum ( $ arr , $ n ) {
$ preSum [ $ n ] = array ( ) ;
$ suffSum [ $ n ] = array ( ) ;
$ ans = PHP_INT_MIN ;
$ preSum [ 0 ] = $ arr [ 0 ] ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) $ preSum [ $ i ] = $ preSum [ $ i - 1 ] + $ arr [ $ i ] ;
$ suffSum [ $ n - 1 ] = $ arr [ $ n - 1 ] ; if ( $ preSum [ $ n - 1 ] == $ suffSum [ $ n - 1 ] ) $ ans = max ( $ ans , $ preSum [ $ n - 1 ] ) ; for ( $ i = $ n - 2 ; $ i >= 0 ; $ i -- ) { $ suffSum [ $ i ] = $ suffSum [ $ i + 1 ] + $ arr [ $ i ] ; if ( $ suffSum [ $ i ] == $ preSum [ $ i ] ) $ ans = max ( $ ans , $ preSum [ $ i ] ) ; } return $ ans ; }
$ arr = array ( -2 , 5 , 3 , 1 , 2 , 6 , -4 , 2 ) ; $ n = sizeof ( $ arr ) ; echo findMaxSum ( $ arr , $ n ) ;
function printLeaders ( $ arr , $ size ) { for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { for ( $ j = $ i + 1 ; $ j < $ size ; $ j ++ ) { if ( $ arr [ $ i ] <= $ arr [ $ j ] ) break ; }
if ( $ j == $ size ) echo ( $ arr [ $ i ] . " ▁ " ) ; } }
$ arr = array ( 16 , 17 , 4 , 3 , 5 , 2 ) ; $ n = sizeof ( $ arr ) ; printLeaders ( $ arr , $ n ) ; ? >
function printLeaders ( & $ arr , $ size ) { $ max_from_right = $ arr [ $ size - 1 ] ;
echo ( $ max_from_right ) ; echo ( " ▁ " ) ; for ( $ i = $ size - 2 ; $ i >= 0 ; $ i -- ) { if ( $ max_from_right < $ arr [ $ i ] ) { $ max_from_right = $ arr [ $ i ] ; echo ( $ max_from_right ) ; echo ( " ▁ " ) ; } } }
$ arr = array ( 16 , 17 , 4 , 3 , 5 , 2 ) ; $ n = sizeof ( $ arr ) ; printLeaders ( $ arr , $ n ) ; ? >
function findMajority ( $ arr , $ n ) { $ maxCount = 0 ;
$ index = -1 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ count = 0 ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) { if ( $ arr [ $ i ] == $ arr [ $ j ] ) $ count ++ ; }
if ( $ count > $ maxCount ) { $ maxCount = $ count ; $ index = $ i ; } }
if ( $ maxCount > $ n / 2 ) echo $ arr [ $ index ] . " STRNEWLINE " ; else echo " No ▁ Majority ▁ Element " . " STRNEWLINE " ; }
$ arr = array ( 1 , 1 , 2 , 1 , 3 , 5 , 1 ) ; $ n = sizeof ( $ arr ) ;
findMajority ( $ arr , $ n ) ;
function maxTripletSum ( $ arr , $ n ) {
$ sum = PHP_INT_MIN ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) for ( $ k = $ j + 1 ; $ k < $ n ; $ k ++ ) if ( $ sum < $ arr [ $ i ] + $ arr [ $ j ] + $ arr [ $ k ] ) $ sum = $ arr [ $ i ] + $ arr [ $ j ] + $ arr [ $ k ] ; return $ sum ; }
$ arr = array ( 1 , 0 , 8 , 6 , 4 , 2 ) ; $ n = count ( $ arr ) ; echo maxTripletSum ( $ arr , $ n ) ; ? >
function maxTripletSum ( $ arr , $ n ) {
sort ( $ arr ) ;
return $ arr [ $ n - 1 ] + $ arr [ $ n - 2 ] + $ arr [ $ n - 3 ] ; }
$ arr = array ( 1 , 0 , 8 , 6 , 4 , 2 ) ; $ n = count ( $ arr ) ; echo maxTripletSum ( $ arr , $ n ) ; ? >
function maxTripletSum ( $ arr , $ n ) {
$ maxA = PHP_INT_MIN ; $ maxB = PHP_INT_MIN ; $ maxC = PHP_INT_MIN ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ arr [ $ i ] > $ maxA ) { $ maxC = $ maxB ; $ maxB = $ maxA ; $ maxA = $ arr [ $ i ] ; }
else if ( $ arr [ $ i ] > $ maxB ) { $ maxC = $ maxB ; $ maxB = $ arr [ $ i ] ; }
else if ( $ arr [ $ i ] > $ maxC ) $ maxC = $ arr [ $ i ] ; } return ( $ maxA + $ maxB + $ maxC ) ; }
$ arr = array ( 1 , 0 , 8 , 6 , 4 , 2 ) ; $ n = count ( $ arr ) ; echo maxTripletSum ( $ arr , $ n ) ; ? >
function maximum ( $ a , $ b , $ c ) { return max ( max ( $ a , $ b ) , $ c ) ; }
function minimum ( $ a , $ b , $ c ) { return min ( min ( $ a , $ b ) , $ c ) ; }
function smallestDifferenceTriplet ( $ arr1 , $ arr2 , $ arr3 , $ n ) {
sort ( $ arr1 ) ; sort ( $ arr2 ) ; sort ( $ arr3 ) ;
$ res_min ; $ res_max ; $ res_mid ;
$ i = 0 ; $ j = 0 ; $ k = 0 ;
$ diff = PHP_INT_MAX ; while ( $ i < $ n && $ j < $ n && $ k < $ n ) { $ sum = $ arr1 [ $ i ] + $ arr2 [ $ j ] + $ arr3 [ $ k ] ;
$ max = maximum ( $ arr1 [ $ i ] , $ arr2 [ $ j ] , $ arr3 [ $ k ] ) ;
$ min = minimum ( $ arr1 [ $ i ] , $ arr2 [ $ j ] , $ arr3 [ $ k ] ) ; if ( $ min == $ arr1 [ $ i ] ) $ i ++ ; else if ( $ min == $ arr2 [ $ j ] ) $ j ++ ; else $ k ++ ;
if ( $ diff > ( $ max - $ min ) ) { $ diff = $ max - $ min ; $ res_max = $ max ; $ res_mid = $ sum - ( $ max + $ min ) ; $ res_min = $ min ; } }
echo $ res_max , " , ▁ " , $ res_mid , " , ▁ " , $ res_min ; }
$ arr1 = array ( 5 , 2 , 8 ) ; $ arr2 = array ( 10 , 7 , 12 ) ; $ arr3 = array ( 9 , 14 , 6 ) ; $ n = sizeof ( $ arr1 ) ; smallestDifferenceTriplet ( $ arr1 , $ arr2 , $ arr3 , $ n ) ; ? >
function find3Numbers ( $ A , $ arr_size , $ sum ) { $ l ; $ r ;
sort ( $ A ) ;
for ( $ i = 0 ; $ i < $ arr_size - 2 ; $ i ++ ) {
$ l = $ i + 1 ;
$ r = $ arr_size - 1 ; while ( $ l < $ r ) { if ( $ A [ $ i ] + $ A [ $ l ] + $ A [ $ r ] == $ sum ) { echo " Triplet ▁ is ▁ " , $ A [ $ i ] , " ▁ " , $ A [ $ l ] , " ▁ " , $ A [ $ r ] , " STRNEWLINE " ; return true ; } else if ( $ A [ $ i ] + $ A [ $ l ] + $ A [ $ r ] < $ sum ) $ l ++ ;
else $ r -- ; } }
return false ; }
$ A = array ( 1 , 4 , 45 , 6 , 10 , 8 ) ; $ sum = 22 ; $ arr_size = sizeof ( $ A ) ; find3Numbers ( $ A , $ arr_size , $ sum ) ; ? >
function subArray ( $ arr , $ n ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
for ( $ j = $ i ; $ j < $ n ; $ j ++ ) {
for ( $ k = $ i ; $ k <= $ j ; $ k ++ ) echo $ arr [ $ k ] , " ▁ " ; echo " STRNEWLINE " ; } } }
$ arr = array ( 1 , 2 , 3 , 4 ) ; $ n = sizeof ( $ arr ) ; echo " All ▁ Non - empty ▁ Subarrays STRNEWLINE " ; subArray ( $ arr , $ n ) ; ? >
function printSubsequences ( $ arr , $ n ) {
$ opsize = pow ( 2 , $ n ) ;
for ( $ counter = 1 ; $ counter < $ opsize ; $ counter ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) {
if ( $ counter & ( 1 << $ j ) ) echo $ arr [ $ j ] , " ▁ " ; } echo " " } }
$ arr = array ( 1 , 2 , 3 , 4 ) ; $ n = sizeof ( $ arr ) ; echo " All ▁ Non - empty ▁ Subsequences STRNEWLINE " ; printSubsequences ( $ arr , $ n ) ; ? >
function productArray ( $ arr , $ n ) {
if ( $ n == 1 ) { echo "0" ; return ; } $ i ; $ temp = 1 ;
$ prod = array ( ) ;
for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ prod [ $ j ] = 1 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ prod [ $ i ] = $ temp ; $ temp *= $ arr [ $ i ] ; }
$ temp = 1 ;
for ( $ i = $ n - 1 ; $ i >= 0 ; $ i -- ) { $ prod [ $ i ] *= $ temp ; $ temp *= $ arr [ $ i ] ; }
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ prod [ $ i ] , " ▁ " ; return ; }
$ arr = array ( 10 , 3 , 5 , 6 , 2 ) ; $ n = count ( $ arr ) ; echo " The ▁ product ▁ array ▁ is ▁ : ▁ STRNEWLINE " ; productArray ( $ arr , $ n ) ; ? >
function areConsecutive ( $ arr , $ n ) { if ( $ n < 1 ) return false ;
$ min = getMin ( $ arr , $ n ) ;
$ max = getMax ( $ arr , $ n ) ;
if ( $ max - $ min + 1 == $ n ) {
$ visited = array ( ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ visited [ $ i ] = false ; } for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ visited [ $ arr [ $ i ] - $ min ] != false ) return false ;
$ visited [ $ arr [ $ i ] - $ min ] = true ; }
return true ; }
return false ; }
function getMin ( $ arr , $ n ) { $ min = $ arr [ 0 ] ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] < $ min ) $ min = $ arr [ $ i ] ; return $ min ; } function getMax ( $ arr , $ n ) { $ max = $ arr [ 0 ] ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] > $ max ) $ max = $ arr [ $ i ] ; return $ max ; }
$ arr = array ( 5 , 4 , 2 , 3 , 1 , 6 ) ; $ n = count ( $ arr ) ; if ( areConsecutive ( $ arr , $ n ) == true ) echo " Array ▁ elements ▁ are ▁ consecutive ▁ " ; else echo " Array ▁ elements ▁ are ▁ not ▁ consecutive ▁ " ; ? >
function areConsecutive ( $ arr , $ n ) { if ( $ n < 1 ) return false ;
$ min = getMin ( $ arr , $ n ) ;
$ max = getMax ( $ arr , $ n ) ;
if ( $ max - $ min + 1 == $ n ) { $ i ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ j ; if ( $ arr [ $ i ] < 0 ) $ j = - $ arr [ $ i ] - $ min ; else $ j = $ arr [ $ i ] - $ min ;
if ( $ arr [ $ j ] > 0 ) $ arr [ $ j ] = - $ arr [ $ j ] ; else return false ; }
return true ; }
return false ; }
function getMin ( $ arr , $ n ) { $ min = $ arr [ 0 ] ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] < $ min ) $ min = $ arr [ $ i ] ; return $ min ; } function getMax ( $ arr , $ n ) { $ max = $ arr [ 0 ] ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] > $ max ) $ max = $ arr [ $ i ] ; return $ max ; }
$ arr = array ( 1 , 4 , 5 , 3 , 2 , 6 ) ; $ n = count ( $ arr ) ; if ( areConsecutive ( $ arr , $ n ) == true ) echo " ▁ Array ▁ elements ▁ are ▁ consecutive ▁ " ; else echo " ▁ Array ▁ elements ▁ are ▁ not ▁ consecutive ▁ " ; ? >
function relativeComplement ( $ arr1 , $ arr2 , $ n , $ m ) { $ i = 0 ; $ j = 0 ; while ( $ i < $ n && $ j < $ m ) {
if ( $ arr1 [ $ i ] < $ arr2 [ $ j ] ) { echo $ arr1 [ $ i ] , " " ; $ i ++ ;
} else if ( $ arr1 [ $ i ] > $ arr2 [ $ j ] ) { $ j ++ ;
} else if ( $ arr1 [ $ i ] == $ arr2 [ $ j ] ) { $ i ++ ; $ j ++ ; } }
while ( $ i < $ n ) echo $ arr1 [ $ i ] , " ▁ " ; }
{ $ arr1 = array ( 3 , 6 , 10 , 12 , 15 ) ; $ arr2 = array ( 1 , 3 , 5 , 10 , 16 ) ; $ n = sizeof ( $ arr1 ) / sizeof ( $ arr1 [ 0 ] ) ; $ m = sizeof ( $ arr2 ) / sizeof ( $ arr2 [ 0 ] ) ; relativeComplement ( $ arr1 , $ arr2 , $ n , $ m ) ; return 0 ; } ? >
function minOps ( $ arr , $ n , $ k ) {
$ max = max ( $ arr ) ; $ res = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( ( $ max - $ arr [ $ i ] ) % $ k != 0 ) return -1 ;
else $ res += ( $ max - $ arr [ $ i ] ) / $ k ; }
return $ res ; }
$ arr = array ( 21 , 33 , 9 , 45 , 63 ) ; $ n = count ( $ arr ) ; $ k = 6 ; print ( minOps ( $ arr , $ n , $ k ) ) ; ? >
function solve ( $ A , $ B , $ C , $ i , $ j , $ k ) { $ min_diff ; $ current_diff ; $ max_term ;
$ min_diff = abs ( max ( $ A [ $ i ] , max ( $ B [ $ j ] , $ C [ $ k ] ) ) - min ( $ A [ $ i ] , min ( $ B [ $ j ] , $ C [ $ k ] ) ) ) ; while ( $ i != -1 && $ j != -1 && $ k != -1 ) { $ current_diff = abs ( max ( $ A [ $ i ] , max ( $ B [ $ j ] , $ C [ $ k ] ) ) - min ( $ A [ $ i ] , min ( $ B [ $ j ] , $ C [ $ k ] ) ) ) ;
if ( $ current_diff < $ min_diff ) $ min_diff = $ current_diff ;
$ max_term = max ( $ A [ $ i ] , max ( $ B [ $ j ] , $ C [ $ k ] ) ) ;
if ( $ A [ $ i ] == $ max_term ) $ i -= 1 ; else if ( $ B [ $ j ] == $ max_term ) $ j -= 1 ; else $ k -= 1 ; } return $ min_diff ; }
$ D = array ( 5 , 8 , 10 , 15 ) ; $ E = array ( 6 , 9 , 15 , 78 , 89 ) ; $ F = array ( 2 , 3 , 6 , 6 , 8 , 8 , 10 ) ; $ nD = sizeof ( $ D ) ; $ nE = sizeof ( $ E ) ; $ nF = sizeof ( $ F ) ; echo solve ( $ D , $ E , $ F , $ nD - 1 , $ nE - 1 , $ nF - 1 ) ; ? >
function search ( $ arr , $ n , $ x ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] == $ x ) return $ i ; } return -1 ; }
$ arr = array ( 1 , 10 , 30 , 15 ) ; $ x = 30 ; $ n = sizeof ( $ arr ) ; echo $ x . " ▁ is ▁ present ▁ at ▁ index ▁ " . search ( $ arr , $ n , $ x ) ;
function binarySearch ( $ arr , $ l , $ r , $ x ) { while ( $ l <= $ r ) { $ m = $ l + ( $ r - $ l ) / 2 ;
if ( $ arr [ $ m ] == $ x ) return floor ( $ m ) ;
if ( $ arr [ $ m ] < $ x ) $ l = $ m + 1 ;
else $ r = $ m - 1 ; }
return -1 ; }
$ arr = array ( 2 , 3 , 4 , 10 , 40 ) ; $ n = count ( $ arr ) ; $ x = 10 ; $ result = binarySearch ( $ arr , 0 , $ n - 1 , $ x ) ; if ( ( $ result == -1 ) ) echo " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ; else echo " Element ▁ is ▁ present ▁ at ▁ index ▁ " , $ result ; ? >
function jumpSearch ( $ arr , $ x , $ n ) {
$ step = sqrt ( $ n ) ;
$ prev = 0 ; while ( $ arr [ min ( $ step , $ n ) - 1 ] < $ x ) { $ prev = $ step ; $ step += sqrt ( $ n ) ; if ( $ prev >= $ n ) return -1 ; }
while ( $ arr [ $ prev ] < $ x ) { $ prev ++ ;
if ( $ prev == min ( $ step , $ n ) ) return -1 ; }
if ( $ arr [ $ prev ] == $ x ) return $ prev ; return -1 ; }
$ arr = array ( 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 ) ; $ x = 55 ; $ n = sizeof ( $ arr ) / sizeof ( $ arr [ 0 ] ) ;
$ index = jumpSearch ( $ arr , $ x , $ n ) ;
echo " Number ▁ " . $ x . " ▁ is ▁ at ▁ index ▁ " . $ index ; return 0 ; ? >
function exponentialSearch ( $ arr , $ n , $ x ) {
if ( $ arr [ 0 ] == $ x ) return 0 ;
$ i = 1 ; while ( $ i < $ n and $ arr [ $ i ] <= $ x ) $ i = $ i * 2 ;
return binarySearch ( $ arr , $ i / 2 , min ( $ i , $ n - 1 ) , $ x ) ; }
$ arr = array ( 2 , 3 , 4 , 10 , 40 ) ; $ n = count ( $ arr ) ; $ x = 10 ; $ result = exponentialSearch ( $ arr , $ n , $ x ) ; if ( $ result == -1 ) echo " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ; else echo " Element ▁ is ▁ present ▁ at ▁ index ▁ " , $ result ; ? >
function selection_sort ( & $ arr , $ n ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ low = $ i ; for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) { if ( $ arr [ $ j ] < $ arr [ $ low ] ) { $ low = $ j ; } }
if ( $ arr [ $ i ] > $ arr [ $ low ] ) { $ tmp = $ arr [ $ i ] ; $ arr [ $ i ] = $ arr [ $ low ] ; $ arr [ $ low ] = $ tmp ; } } }
$ arr = array ( 64 , 25 , 12 , 22 , 11 ) ; $ len = count ( $ arr ) ; selection_sort ( $ arr , $ len ) ; echo " Sorted ▁ array ▁ : ▁ STRNEWLINE " ; for ( $ i = 0 ; $ i < $ len ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function bubbleSort ( & $ arr ) { $ n = sizeof ( $ arr ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ swapped = False ; for ( $ j = 0 ; $ j < $ n - $ i - 1 ; $ j ++ ) { if ( $ arr [ $ j ] > $ arr [ $ j + 1 ] ) {
$ t = $ arr [ $ j ] ; $ arr [ $ j ] = $ arr [ $ j + 1 ] ; $ arr [ $ j + 1 ] = $ t ; $ swapped = True ; } }
if ( $ swapped == False ) break ; } }
$ arr = array ( 64 , 34 , 25 , 12 , 22 , 11 , 90 ) ; $ len = sizeof ( $ arr ) ; bubbleSort ( $ arr ) ; echo " Sorted ▁ array ▁ : ▁ STRNEWLINE " ; for ( $ i = 0 ; $ i < $ len ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; ? >
function countSort ( & $ arr , $ n , $ exp ) {
$ output = array_fill ( 0 , $ n , 0 ) ; $ count = array_fill ( 0 , 10 , 0 ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ count [ ( $ arr [ $ i ] / $ exp ) % 10 ] ++ ;
for ( $ i = 1 ; $ i < 10 ; $ i ++ ) $ count [ $ i ] += $ count [ $ i - 1 ] ;
for ( $ i = $ n - 1 ; $ i >= 0 ; $ i -- ) { $ output [ $ count [ ( $ arr [ $ i ] / $ exp ) % 10 ] - 1 ] = $ arr [ $ i ] ; $ count [ ( $ arr [ $ i ] / $ exp ) % 10 ] -- ; }
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ arr [ $ i ] = $ output [ $ i ] ; }
function radixsort ( & $ arr , $ n ) {
$ m = max ( $ arr ) ;
for ( $ exp = 1 ; $ m / $ exp > 0 ; $ exp *= 10 ) countSort ( $ arr , $ n , $ exp ) ; }
function PrintArray ( & $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; }
$ arr = array ( 170 , 45 , 75 , 90 , 802 , 24 , 2 , 66 ) ; $ n = count ( $ arr ) ;
radixsort ( $ arr , $ n ) ; PrintArray ( $ arr , $ n ) ; ? >
function partition ( & $ arr , $ l , $ h ) { $ x = $ arr [ $ h ] ; $ i = ( $ l - 1 ) ; for ( $ j = $ l ; $ j <= $ h - 1 ; $ j ++ ) { if ( $ arr [ $ j ] <= $ x ) { $ i ++ ; swap ( $ arr [ $ i ] , $ arr [ $ j ] ) ; } } swap ( $ arr [ $ i + 1 ] , $ arr [ $ h ] ) ; return ( $ i + 1 ) ; }
function quickSort ( & $ A , $ l , $ h ) { if ( $ l < $ h ) {
$ p = partition ( $ A , $ l , $ h ) ; quickSort ( $ A , $ l , $ p - 1 ) ; quickSort ( $ A , $ p + 1 , $ h ) ; } }
$ n = 5 ; $ arr = array ( 4 , 2 , 6 , 9 , 2 ) ; quickSort ( $ arr , 0 , $ n - 1 ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { echo $ arr [ $ i ] . " ▁ " ; } ? >
function partition ( & $ arr , $ l , $ h ) { $ x = $ arr [ $ h ] ; $ i = ( $ l - 1 ) ; for ( $ j = $ l ; $ j <= $ h - 1 ; $ j ++ ) { if ( $ arr [ $ j ] <= $ x ) { $ i ++ ; swap ( $ arr [ $ i ] , $ arr [ $ j ] ) ; } } swap ( $ arr [ $ i + 1 ] , $ arr [ $ h ] ) ; return ( $ i + 1 ) ; }
function quickSortIterative ( & $ arr , $ l , $ h ) {
$ stack = array_fill ( 0 , $ h - $ l + 1 , 0 ) ;
$ top = -1 ;
$ stack [ ++ $ top ] = $ l ; $ stack [ ++ $ top ] = $ h ;
while ( $ top >= 0 ) {
$ h = $ stack [ $ top -- ] ; $ l = $ stack [ $ top -- ] ;
$ p = partition ( $ arr , $ l , $ h ) ;
if ( $ p - 1 > $ l ) { $ stack [ ++ $ top ] = $ l ; $ stack [ ++ $ top ] = $ p - 1 ; }
if ( $ p + 1 < $ h ) { $ stack [ ++ $ top ] = $ p + 1 ; $ stack [ ++ $ top ] = $ h ; } } }
$ arr = array ( 4 , 3 , 5 , 2 , 1 , 3 , 2 , 3 ) ; $ n = count ( $ arr ) ;
quickSortIterative ( $ arr , 0 , $ n - 1 ) ; printArr ( $ arr , $ n ) ; ? >
function findCrossOver ( $ arr , $ low , $ high , $ x ) {
if ( $ arr [ $ high ] <= $ x ) return $ high ;
if ( $ arr [ $ low ] > $ x ) return $ low ;
$ mid = ( $ low + $ high ) / 2 ;
if ( $ arr [ $ mid ] <= $ x and $ arr [ $ mid + 1 ] > $ x ) return $ mid ;
if ( $ arr [ $ mid ] < $ x ) return findCrossOver ( $ arr , $ mid + 1 , $ high , $ x ) ; return findCrossOver ( $ arr , $ low , $ mid - 1 , $ x ) ; }
function printKclosest ( $ arr , $ x , $ k , $ n ) {
$ l = findCrossOver ( $ arr , 0 , $ n - 1 , $ x ) ;
$ r = $ l + 1 ;
$ count = 0 ;
if ( $ arr [ $ l ] == $ x ) $ l -- ;
while ( $ l >= 0 and $ r < $ n and $ count < $ k ) { if ( $ x - $ arr [ $ l ] < $ arr [ $ r ] - $ x ) echo $ arr [ $ l -- ] , " ▁ " ; else echo $ arr [ $ r ++ ] , " ▁ " ; $ count ++ ; }
while ( $ count < $ k and $ l >= 0 ) echo $ arr [ $ l -- ] , " ▁ " ; $ count ++ ;
while ( $ count < $ k and $ r < $ n ) echo $ arr [ $ r ++ ] ; $ count ++ ; }
$ arr = array ( 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 ) ; $ n = count ( $ arr ) ; $ x = 35 ; $ k = 4 ; printKclosest ( $ arr , $ x , 4 , $ n ) ; ? >
function binarySearch ( $ arr , $ l , $ r , $ x ) { if ( $ r >= $ l ) { $ mid = $ l + ( $ r - $ l ) / 2 ;
if ( $ arr [ $ mid ] == $ x ) return $ mid ; if ( $ mid > $ l && $ arr [ $ mid - 1 ] == $ x ) return ( $ mid - 1 ) ; if ( $ mid < $ r && $ arr [ $ mid + 1 ] == $ x ) return ( $ mid + 1 ) ;
if ( $ arr [ $ mid ] > $ x ) return binarySearch ( $ arr , $ l , $ mid - 2 , $ x ) ;
return binarySearch ( $ arr , $ mid + 2 , $ r , $ x ) ; }
return -1 ; }
$ arr = array ( 3 , 2 , 10 , 4 , 40 ) ; $ n = sizeof ( $ arr ) ; $ x = 4 ; $ result = binarySearch ( $ arr , 0 , $ n - 1 , $ x ) ; if ( $ result == -1 ) echo ( " Element ▁ is ▁ not ▁ present ▁ in ▁ array " ) ; else echo ( " Element ▁ is ▁ present ▁ at ▁ index ▁ $ result " ) ; ? >
function printClosest ( $ ar1 , $ ar2 , $ m , $ n , $ x ) {
$ diff = PHP_INT_MAX ;
$ res_l ; $ res_r ;
$ l = 0 ; $ r = $ n - 1 ; while ( $ l < $ m and $ r >= 0 ) {
if ( abs ( $ ar1 [ $ l ] + $ ar2 [ $ r ] - $ x ) < $ diff ) { $ res_l = $ l ; $ res_r = $ r ; $ diff = abs ( $ ar1 [ $ l ] + $ ar2 [ $ r ] - $ x ) ; }
if ( $ ar1 [ $ l ] + $ ar2 [ $ r ] > $ x ) $ r -- ;
else $ l ++ ; }
echo " The ▁ closest ▁ pair ▁ is ▁ [ " , $ ar1 [ $ res_l ] , " , ▁ " , $ ar2 [ $ res_r ] , " ] ▁ STRNEWLINE " ; }
$ ar1 = array ( 1 , 4 , 5 , 7 ) ; $ ar2 = array ( 10 , 20 , 30 , 40 ) ; $ m = count ( $ ar1 ) ; $ n = count ( $ ar2 ) ; $ x = 38 ; printClosest ( $ ar1 , $ ar2 , $ m , $ n , $ x ) ; ? >
function printClosest ( $ arr , $ n , $ x ) {
$ res_l ; $ res_r ;
$ l = 0 ; $ r = $ n - 1 ; $ diff = PHP_INT_MAX ;
while ( $ r > $ l ) {
if ( abs ( $ arr [ $ l ] + $ arr [ $ r ] - $ x ) < $ diff ) { $ res_l = $ l ; $ res_r = $ r ; $ diff = abs ( $ arr [ $ l ] + $ arr [ $ r ] - $ x ) ; }
if ( $ arr [ $ l ] + $ arr [ $ r ] > $ x ) $ r -- ;
else $ l ++ ; } echo " ▁ The ▁ closest ▁ pair ▁ is ▁ " , $ arr [ $ res_l ] , " ▁ and ▁ " , $ arr [ $ res_r ] ; }
$ arr = array ( 10 , 22 , 28 , 29 , 30 , 40 ) ; $ x = 54 ; $ n = count ( $ arr ) ; printClosest ( $ arr , $ n , $ x ) ; ? >
function countOnes ( $ arr , $ low , $ high ) { if ( $ high >= $ low ) {
$ mid = $ low + ( $ high - $ low ) / 2 ;
if ( ( $ mid == $ high or $ arr [ $ mid + 1 ] == 0 ) and ( $ arr [ $ mid ] == 1 ) ) return $ mid + 1 ;
if ( $ arr [ $ mid ] == 1 ) return countOnes ( $ arr , ( $ mid + 1 ) , $ high ) ;
return countOnes ( $ arr , $ low , ( $ mid - 1 ) ) ; } return 0 ; }
$ arr = array ( 1 , 1 , 1 , 1 , 0 , 0 , 0 ) ; $ n = count ( $ arr ) ; echo " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " , countOnes ( $ arr , 0 , $ n - 1 ) ; ? >
function solve ( $ a , $ n ) { $ maxx = -1 ; $ minn = $ a [ 0 ] ; $ l = 0 ; $ r = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ a [ $ i ] > $ maxx ) { $ maxx = $ a [ $ i ] ; $ l = $ i ; }
if ( $ a [ $ i ] <= $ minn ) { $ minn = $ a [ $ i ] ; $ r = $ i ; } } if ( $ r < $ l ) echo $ l + ( $ n - $ r - 2 ) ; else echo $ l + ( $ n - $ r - 1 ) ; }
$ a = array ( 5 , 6 , 1 , 3 ) ; $ n = count ( $ a ) ; solve ( $ a , $ n ) ; ? >
function lcs ( $ X , $ Y , $ m , $ n ) { if ( $ m == 0 $ n == 0 ) return 0 ; else if ( $ X [ $ m - 1 ] == $ Y [ $ n - 1 ] ) return 1 + lcs ( $ X , $ Y , $ m - 1 , $ n - 1 ) ; else return max ( lcs ( $ X , $ Y , $ m , $ n - 1 ) , lcs ( $ X , $ Y , $ m - 1 , $ n ) ) ; }
$ X = " AGGTAB " ; $ Y = " GXTXAYB " ; echo " Length ▁ of ▁ LCS ▁ is ▁ " ; echo lcs ( $ X , $ Y , strlen ( $ X ) , strlen ( $ Y ) ) ; ? >
function lcs ( $ X , $ Y ) {
$ m = strlen ( $ X ) ; $ n = strlen ( $ Y ) ;
for ( $ i = 0 ; $ i <= $ m ; $ i ++ ) { for ( $ j = 0 ; $ j <= $ n ; $ j ++ ) { if ( $ i == 0 $ j == 0 ) $ L [ $ i ] [ $ j ] = 0 ; else if ( $ X [ $ i - 1 ] == $ Y [ $ j - 1 ] ) $ L [ $ i ] [ $ j ] = $ L [ $ i - 1 ] [ $ j - 1 ] + 1 ; else $ L [ $ i ] [ $ j ] = max ( $ L [ $ i - 1 ] [ $ j ] , $ L [ $ i ] [ $ j - 1 ] ) ; } }
return $ L [ $ m ] [ $ n ] ; }
$ X = " AGGTAB " ; $ Y = " GXTXAYB " ; echo " Length ▁ of ▁ LCS ▁ is ▁ " ; echo lcs ( $ X , $ Y ) ; ? >
function count_1 ( & $ S , $ m , $ n ) {
$ table = array_fill ( 0 , $ n + 1 , NULl ) ;
$ table [ 0 ] = 1 ;
for ( $ i = 0 ; $ i < $ m ; $ i ++ ) for ( $ j = $ S [ $ i ] ; $ j <= $ n ; $ j ++ ) $ table [ $ j ] += $ table [ $ j - $ S [ $ i ] ] ; return $ table [ $ n ] ; }
function binomialCoeff ( $ n , $ k ) { $ C = array_fill ( 0 , $ k + 1 , 0 ) ;
$ C [ 0 ] = 1 ; for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) {
for ( $ j = min ( $ i , $ k ) ; $ j > 0 ; $ j -- ) $ C [ $ j ] = $ C [ $ j ] + $ C [ $ j - 1 ] ; } return $ C [ $ k ] ; }
$ n = 5 ; $ k = 2 ; echo " Value ▁ of ▁ C [ $ n , ▁ $ k ] ▁ is ▁ " . binomialCoeff ( $ n , $ k ) ; ? >
function eggDrop ( $ n , $ k ) {
$ eggFloor = array ( array ( ) ) ; ;
for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) { $ eggFloor [ $ i ] [ 1 ] = 1 ; $ eggFloor [ $ i ] [ 0 ] = 0 ; }
for ( $ j = 1 ; $ j <= $ k ; $ j ++ ) $ eggFloor [ 1 ] [ $ j ] = $ j ;
for ( $ i = 2 ; $ i <= $ n ; $ i ++ ) { for ( $ j = 2 ; $ j <= $ k ; $ j ++ ) { $ eggFloor [ $ i ] [ $ j ] = 999999 ; for ( $ x = 1 ; $ x <= $ j ; $ x ++ ) { $ res = 1 + max ( $ eggFloor [ $ i - 1 ] [ $ x - 1 ] , $ eggFloor [ $ i ] [ $ j - $ x ] ) ; if ( $ res < $ eggFloor [ $ i ] [ $ j ] ) $ eggFloor [ $ i ] [ $ j ] = $ res ; } } }
return $ eggFloor [ $ n ] [ $ k ] ; }
$ n = 2 ; $ k = 36 ; echo " Minimum ▁ number ▁ of ▁ trials ▁ in ▁ worst ▁ case ▁ with ▁ " . $ n . " ▁ eggs ▁ and ▁ " . $ k . " ▁ floors ▁ is ▁ " . eggDrop ( $ n , $ k ) ; ? >
function max ( $ x , $ y ) { return ( $ x > $ y ) ? $ x : $ y ; }
function lps ( $ str ) { $ n = strlen ( $ str ) ; $ i ; $ j ; $ cl ;
$ L [ ] [ ] = array ( array ( ) ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ L [ $ i ] [ $ i ] = 1 ;
for ( $ cl = 2 ; $ cl <= $ n ; $ cl ++ ) { for ( $ i = 0 ; $ i < $ n - $ cl + 1 ; $ i ++ ) { $ j = $ i + $ cl - 1 ; if ( $ str [ $ i ] == $ str [ $ j ] && $ cl == 2 ) $ L [ $ i ] [ $ j ] = 2 ; else if ( $ str [ $ i ] == $ str [ $ j ] ) $ L [ $ i ] [ $ j ] = $ L [ $ i + 1 ] [ $ j - 1 ] + 2 ; else $ L [ $ i ] [ $ j ] = max ( $ L [ $ i ] [ $ j - 1 ] , $ L [ $ i + 1 ] [ $ j ] ) ; } } return $ L [ 0 ] [ $ n - 1 ] ; }
$ seq = ' EEKS FOR GEEKS ' $ n = strlen ( $ seq ) ; echo " The ▁ length ▁ of ▁ the ▁ " . " LPS ▁ is ▁ " , lps ( $ seq ) ; ? >
function cutRod ( $ price , $ n ) { if ( $ n <= 0 ) return 0 ; $ max_val = PHP_INT_MIN ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ max_val = max ( $ max_val , $ price [ $ i ] + cutRod ( $ price , $ n - $ i - 1 ) ) ; return $ max_val ; }
$ arr = array ( 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ) ; $ size = count ( $ arr ) ; echo " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " , cutRod ( $ arr , $ size ) ; ? >
function cutRod ( $ price , $ n ) { $ val = array ( ) ; $ val [ 0 ] = 0 ; $ i ; $ j ;
for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) { $ max_val = PHP_INT_MIN ; for ( $ j = 0 ; $ j < $ i ; $ j ++ ) $ max_val = max ( $ max_val , $ price [ $ j ] + $ val [ $ i - $ j - 1 ] ) ; $ val [ $ i ] = $ max_val ; } return $ val [ $ n ] ; }
$ arr = array ( 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ) ; $ size = count ( $ arr ) ; echo " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " , cutRod ( $ arr , $ size ) ; ? >
function lbs ( & $ arr , $ n ) {
$ lis = array_fill ( 0 , $ n , NULL ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ lis [ $ i ] = 1 ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ i ; $ j ++ ) if ( $ arr [ $ i ] > $ arr [ $ j ] && $ lis [ $ i ] < $ lis [ $ j ] + 1 ) $ lis [ $ i ] = $ lis [ $ j ] + 1 ;
$ lds = array_fill ( 0 , $ n , NULL ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ lds [ $ i ] = 1 ;
for ( $ i = $ n - 2 ; $ i >= 0 ; $ i -- ) for ( $ j = $ n - 1 ; $ j > $ i ; $ j -- ) if ( $ arr [ $ i ] > $ arr [ $ j ] && $ lds [ $ i ] < $ lds [ $ j ] + 1 ) $ lds [ $ i ] = $ lds [ $ j ] + 1 ;
$ max = $ lis [ 0 ] + $ lds [ 0 ] - 1 ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( $ lis [ $ i ] + $ lds [ $ i ] - 1 > $ max ) $ max = $ lis [ $ i ] + $ lds [ $ i ] - 1 ; return $ max ; }
$ arr = array ( 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 ) ; $ n = sizeof ( $ arr ) ; echo " Length ▁ of ▁ LBS ▁ is ▁ " . lbs ( $ arr , $ n ) ; ? >
function maxDivide ( $ a , $ b ) { while ( $ a % $ b == 0 ) $ a = $ a / $ b ; return $ a ; }
function isUgly ( $ no ) { $ no = maxDivide ( $ no , 2 ) ; $ no = maxDivide ( $ no , 3 ) ; $ no = maxDivide ( $ no , 5 ) ; return ( $ no == 1 ) ? 1 : 0 ; }
function getNthUglyNo ( $ n ) { $ i = 1 ;
$ count = 1 ;
while ( $ n > $ count ) { $ i ++ ; if ( isUgly ( $ i ) ) $ count ++ ; } return $ i ; }
$ no = getNthUglyNo ( 150 ) ; echo "150th ▁ ugly ▁ no . ▁ is ▁ " . $ no ; ? >
function isSubsetSum ( $ set , $ n , $ sum ) {
if ( $ sum == 0 ) return true ; if ( $ n == 0 ) return false ;
if ( $ set [ $ n - 1 ] > $ sum ) return isSubsetSum ( $ set , $ n - 1 , $ sum ) ;
return isSubsetSum ( $ set , $ n - 1 , $ sum ) || isSubsetSum ( $ set , $ n - 1 , $ sum - $ set [ $ n - 1 ] ) ; }
$ set = array ( 3 , 34 , 4 , 12 , 5 , 2 ) ; $ sum = 9 ; $ n = 6 ; if ( isSubsetSum ( $ set , $ n , $ sum ) == true ) echo " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ; else echo " No ▁ subset ▁ with ▁ given ▁ sum " ; ? >
function isSubsetSum ( $ set , $ n , $ sum ) {
$ subset = array ( array ( ) ) ;
for ( $ i = 0 ; $ i <= $ n ; $ i ++ ) $ subset [ $ i ] [ 0 ] = true ;
for ( $ i = 1 ; $ i <= $ sum ; $ i ++ ) $ subset [ 0 ] [ $ i ] = false ;
for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) { for ( $ j = 1 ; $ j <= $ sum ; $ j ++ ) { if ( $ j < $ set [ $ i - 1 ] ) $ subset [ $ i ] [ $ j ] = $ subset [ $ i - 1 ] [ $ j ] ; if ( $ j >= $ set [ $ i - 1 ] ) $ subset [ $ i ] [ $ j ] = $ subset [ $ i - 1 ] [ $ j ] || $ subset [ $ i - 1 ] [ $ j - $ set [ $ i - 1 ] ] ; } }
for ( int i = 0 ; i <= n ; i ++ ) { for ( int j = 0 ; j <= sum ; j ++ ) printf ( " % 4d " , subset [ i ] [ j ] ) ; printf ( " n " ) ; } return $ subset [ $ n ] [ $ sum ] ; }
$ set = array ( 3 , 34 , 4 , 12 , 5 , 2 ) ; $ sum = 9 ; $ n = count ( $ set ) ; if ( isSubsetSum ( $ set , $ n , $ sum ) == true ) echo " Found ▁ a ▁ subset ▁ with ▁ given ▁ sum " ; else echo " No ▁ subset ▁ with ▁ given ▁ sum " ; ? >
function countRec ( $ n , $ sum ) {
if ( $ n == 0 ) return $ sum == 0 ; if ( $ sum == 0 ) return 1 ;
$ ans = 0 ;
for ( $ i = 0 ; $ i <= 9 ; $ i ++ ) if ( $ sum - $ i >= 0 ) $ ans += countRec ( $ n - 1 , $ sum - $ i ) ; return $ ans ; }
function finalCount ( $ n , $ sum ) {
$ ans = 0 ;
for ( $ i = 1 ; $ i <= 9 ; $ i ++ ) if ( $ sum - $ i >= 0 ) $ ans += countRec ( $ n - 1 , $ sum - $ i ) ; return $ ans ; }
$ n = 2 ; $ sum = 5 ; echo finalCount ( $ n , $ sum ) ; ? >
$ lookup = array_fill ( 0 , 101 , array_fill ( 0 , 501 , -1 ) ) ;
function countRec ( $ n , $ sum ) { global $ lookup ;
if ( $ n == 0 ) return $ sum == 0 ;
if ( $ lookup [ $ n ] [ $ sum ] != -1 ) return $ lookup [ $ n ] [ $ sum ] ;
$ ans = 0 ;
for ( $ i = 0 ; $ i < 10 ; $ i ++ ) if ( $ sum - $ i >= 0 ) $ ans += countRec ( $ n - 1 , $ sum - $ i ) ; return $ lookup [ $ n ] [ $ sum ] = $ ans ; }
function finalCount ( $ n , $ sum ) {
$ ans = 0 ;
for ( $ i = 1 ; $ i <= 9 ; $ i ++ ) if ( $ sum - $ i >= 0 ) $ ans += countRec ( $ n - 1 , $ sum - $ i ) ; return $ ans ; }
$ n = 3 ; $ sum = 5 ; echo finalCount ( $ n , $ sum ) ; ? >
function findCount ( $ n , $ sum ) {
$ start = ( int ) pow ( 10 , $ n - 1 ) ; $ end = ( int ) pow ( 10 , $ n ) - 1 ; $ count = 0 ; $ i = $ start ; while ( $ i < $ end ) { $ cur = 0 ; $ temp = $ i ; while ( $ temp != 0 ) { $ cur += $ temp % 10 ; $ temp = ( int ) $ temp / 10 ; } if ( $ cur == $ sum ) { $ count ++ ; $ i += 9 ; } else $ i ++ ; } echo ( $ count ) ; }
$ n = 3 ; $ sum = 5 ; findCount ( $ n , $ sum ) ; ? >
function countNonDecreasing ( $ n ) {
$ dp = array_fill ( 0 , 10 , array_fill ( 0 , $ n + 1 , NULL ) ) ;
for ( $ i = 0 ; $ i < 10 ; $ i ++ ) $ dp [ $ i ] [ 1 ] = 1 ;
for ( $ digit = 0 ; $ digit <= 9 ; $ digit ++ ) {
for ( $ len = 2 ; $ len <= $ n ; $ len ++ ) {
for ( $ x = 0 ; $ x <= $ digit ; $ x ++ ) $ dp [ $ digit ] [ $ len ] += $ dp [ $ x ] [ $ len - 1 ] ; } } $ count = 0 ;
for ( $ i = 0 ; $ i < 10 ; $ i ++ ) $ count += $ dp [ $ i ] [ $ n ] ; return $ count ; }
$ n = 3 ; echo countNonDecreasing ( $ n ) ; return 0 ; ? >
function countNonDecreasing ( $ n ) { $ N = 10 ;
$ count = 1 ; for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) { $ count *= ( $ N + $ i - 1 ) ; $ count /= $ i ; } return $ count ; }
$ n = 3 ; echo countNonDecreasing ( $ n ) ; ? >
function getMinSquares ( $ n ) {
if ( $ n <= 3 ) return $ n ;
$ res = $ n ;
for ( $ x = 1 ; $ x <= $ n ; $ x ++ ) { $ temp = $ x * $ x ; if ( $ temp > $ n ) break ; else $ res = min ( $ res , 1 + getMinSquares ( $ n - $ temp ) ) ; } return $ res ; }
echo getMinSquares ( 6 ) ; ? >
function getMinSquares ( $ n ) {
$ dp ;
$ dp [ 0 ] = 0 ; $ dp [ 1 ] = 1 ; $ dp [ 2 ] = 2 ; $ dp [ 3 ] = 3 ;
for ( $ i = 4 ; $ i <= $ n ; $ i ++ ) {
$ dp [ $ i ] = $ i ;
for ( $ x = 1 ; $ x <= ceil ( sqrt ( $ i ) ) ; $ x ++ ) { $ temp = $ x * $ x ; if ( $ temp > $ i ) break ; else $ dp [ $ i ] = min ( $ dp [ $ i ] , ( 1 + $ dp [ $ i - $ temp ] ) ) ; } }
$ res = $ dp [ $ n ] ; return $ res ; }
echo getMinSquares ( 6 ) ; ? >
function minCoins ( $ coins , $ m , $ V ) {
if ( $ V == 0 ) return 0 ;
$ res = PHP_INT_MAX ;
for ( $ i = 0 ; $ i < $ m ; $ i ++ ) { if ( $ coins [ $ i ] <= $ V ) { $ sub_res = minCoins ( $ coins , $ m , $ V - $ coins [ $ i ] ) ;
if ( $ sub_res != PHP_INT_MAX && $ sub_res + 1 < $ res ) $ res = $ sub_res + 1 ; } } return $ res ; }
$ coins = array ( 9 , 6 , 5 , 1 ) ; $ m = sizeof ( $ coins ) ; $ V = 11 ; echo " Minimum ▁ coins ▁ required ▁ is ▁ " , minCoins ( $ coins , $ m , $ V ) ; ? >
function minCoins ( $ coins , $ m , $ V ) {
$ table [ $ V + 1 ] = array ( ) ;
$ table [ 0 ] = 0 ;
for ( $ i = 1 ; $ i <= $ V ; $ i ++ ) $ table [ $ i ] = PHP_INT_MAX ;
for ( $ i = 1 ; $ i <= $ V ; $ i ++ ) {
for ( $ j = 0 ; $ j < $ m ; $ j ++ ) if ( $ coins [ $ j ] <= $ i ) { $ sub_res = $ table [ $ i - $ coins [ $ j ] ] ; if ( $ sub_res != PHP_INT_MAX && $ sub_res + 1 < $ table [ $ i ] ) $ table [ $ i ] = $ sub_res + 1 ; } } if ( $ table [ $ V ] == PHP_INT_MAX ) return -1 ; return $ table [ $ V ] ; }
$ coins = array ( 9 , 6 , 5 , 1 ) ; $ m = sizeof ( $ coins ) ; $ V = 11 ; echo " Minimum ▁ coins ▁ required ▁ is ▁ " , minCoins ( $ coins , $ m , $ V ) ; ? >
function superSeq ( $ X , $ Y , $ m , $ n ) { if ( ! $ m ) return $ n ; if ( ! $ n ) return $ m ; if ( $ X [ $ m - 1 ] == $ Y [ $ n - 1 ] ) return 1 + superSeq ( $ X , $ Y , $ m - 1 , $ n - 1 ) ; return 1 + min ( superSeq ( $ X , $ Y , $ m - 1 , $ n ) , superSeq ( $ X , $ Y , $ m , $ n - 1 ) ) ; }
$ X = " AGGTAB " ; $ Y = " GXTXAYB " ; echo " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ " , superSeq ( $ X , $ Y , strlen ( $ X ) , strlen ( $ Y ) ) ; ? >
function superSeq ( $ X , $ Y , $ m , $ n ) { $ dp = array_fill ( 0 , $ m + 1 , array_fill ( 0 , $ n + 1 , 0 ) ) ;
for ( $ i = 0 ; $ i <= $ m ; $ i ++ ) { for ( $ j = 0 ; $ j <= $ n ; $ j ++ ) {
if ( ! $ i ) $ dp [ $ i ] [ $ j ] = $ j ; else if ( ! $ j ) $ dp [ $ i ] [ $ j ] = $ i ; else if ( $ X [ $ i - 1 ] == $ Y [ $ j - 1 ] ) $ dp [ $ i ] [ $ j ] = 1 + $ dp [ $ i - 1 ] [ $ j - 1 ] ; else $ dp [ $ i ] [ $ j ] = 1 + min ( $ dp [ $ i - 1 ] [ $ j ] , $ dp [ $ i ] [ $ j - 1 ] ) ; } } return $ dp [ $ m ] [ $ n ] ; }
$ X = " AGGTAB " ; $ Y = " GXTXAYB " ; echo " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ " . superSeq ( $ X , $ Y , strlen ( $ X ) , strlen ( $ Y ) ) ; ? >
function sumOfDigitsFrom1ToN ( $ n ) {
$ result = 0 ;
for ( $ x = 1 ; $ x <= $ n ; $ x ++ ) $ result += sumOfDigits ( $ x ) ; return $ result ; }
function sumOfDigits ( $ x ) { $ sum = 0 ; while ( $ x != 0 ) { $ sum += $ x % 10 ; $ x = $ x / 10 ; } return $ sum ; }
$ n = 328 ; echo " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ from " . " ▁ 1 ▁ to ▁ " . $ n . " ▁ is ▁ " . sumOfDigitsFrom1ToN ( $ n ) ; ? >
function sumOfDigitsFrom1ToN ( $ n ) {
if ( $ n < 10 ) return ( $ n * ( $ n + 1 ) / 2 ) ;
$ d = ( int ) ( log10 ( $ n ) ) ;
$ a [ $ d + 1 ] = array ( ) ; $ a [ 0 ] = 0 ; $ a [ 1 ] = 45 ; for ( $ i = 2 ; $ i <= $ d ; $ i ++ ) $ a [ $ i ] = $ a [ $ i - 1 ] * 10 + 45 * ( int ) ( ceil ( pow ( 10 , $ i - 1 ) ) ) ;
$ p = ( int ) ( ceil ( pow ( 10 , $ d ) ) ) ;
$ msd = ( int ) ( $ n / $ p ) ;
return ( $ msd * $ a [ $ d ] + ( $ msd * ( int ) ( $ msd - 1 ) / 2 ) * $ p + $ msd * ( 1 + $ n % $ p ) + sumOfDigitsFrom1ToN ( $ n % $ p ) ) ; }
$ n = 328 ; echo ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ " ) , " from ▁ 1 ▁ to ▁ " , $ n , " ▁ is ▁ " , sumOfDigitsFrom1ToN ( $ n ) ; ? >
function countWays ( $ N ) {
if ( $ N == 1 )
return 4 ;
$ countB = 1 ; $ countS = 1 ; $ prev_countB ; $ prev_countS ;
for ( $ i = 2 ; $ i <= $ N ; $ i ++ ) { $ prev_countB = $ countB ; $ prev_countS = $ countS ; $ countS = $ prev_countB + $ prev_countS ; $ countB = $ prev_countS ; }
$ result = $ countS + $ countB ;
return ( $ result * $ result ) ; }
$ N = 3 ; echo " Count ▁ of ▁ ways ▁ for ▁ " , $ N , " ▁ sections ▁ is ▁ " , countWays ( $ N ) ; ? >
function printPatternUtil ( $ str , $ buff , $ i , $ j , $ n ) { if ( $ i == $ n ) { $ buff [ $ j ] = ' ' ; echo str_replace ( ' , ▁ ' , ' ' , implode ( ' , ▁ ' , $ buff ) ) . " STRNEWLINE " ; return ; }
$ buff [ $ j ] = $ str [ $ i ] ; printPatternUtil ( $ str , $ buff , $ i + 1 , $ j + 1 , $ n ) ;
$ buff [ $ j ] = ' ▁ ' ; $ buff [ $ j + 1 ] = $ str [ $ i ] ; printPatternUtil ( $ str , $ buff , $ i +1 , $ j + 2 , $ n ) ; }
function printPattern ( $ str ) { $ n = strlen ( $ str ) ;
$ buf = array_fill ( 0 , 2 * $ n , null ) ;
$ buf [ 0 ] = $ str [ 0 ] ; printPatternUtil ( $ str , $ buf , 1 , 1 , $ n ) ; }
$ str = " ABCD " ; printPattern ( $ str ) ; ? >
function area ( $ x1 , $ y1 , $ x2 , $ y2 , $ x3 , $ y3 ) { return abs ( ( $ x1 * ( $ y2 - $ y3 ) + $ x2 * ( $ y3 - $ y1 ) + $ x3 * ( $ y1 - $ y2 ) ) / 2.0 ) ; }
function isInside ( $ x1 , $ y1 , $ x2 , $ y2 , $ x3 , $ y3 , $ x , $ y ) {
$ A = area ( $ x1 , $ y1 , $ x2 , $ y2 , $ x3 , $ y3 ) ;
$ A1 = area ( $ x , $ y , $ x2 , $ y2 , $ x3 , $ y3 ) ;
$ A2 = area ( $ x1 , $ y1 , $ x , $ y , $ x3 , $ y3 ) ;
$ A3 = area ( $ x1 , $ y1 , $ x2 , $ y2 , $ x , $ y ) ;
return ( $ A == $ A1 + $ A2 + $ A3 ) ; }
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) echo " Inside " ; else echo " Not ▁ Inside " ; ? >
function getAvg ( $ prev_avg , $ x , $ n ) { return ( $ prev_avg * $ n + $ x ) / ( $ n + 1 ) ; }
function streamAvg ( $ arr , $ n ) { $ avg = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ avg = getAvg ( $ avg , $ arr [ $ i ] , $ i ) ; echo " Average ▁ of ▁ " , $ i + 1 , " numbers ▁ is ▁ " , $ avg , " STRNEWLINE " ; } return ; }
$ arr = array ( 10 , 20 , 30 , 40 , 50 , 60 ) ; $ n = sizeof ( $ arr ) ; streamAvg ( $ arr , $ n ) ; ? >
function SieveOfEratosthenes ( $ n ) {
$ prime = array_fill ( 0 , $ n + 1 , true ) ; for ( $ p = 2 ; $ p * $ p <= $ n ; $ p ++ ) {
if ( $ prime [ $ p ] == true ) {
for ( $ i = $ p * $ p ; $ i <= $ n ; $ i += $ p ) $ prime [ $ i ] = false ; } }
for ( $ p = 2 ; $ p <= $ n ; $ p ++ ) if ( $ prime [ $ p ] ) echo $ p . " " ; }
$ n = 30 ; echo " Following ▁ are ▁ the ▁ prime ▁ numbers ▁ " . " smaller ▁ than ▁ or ▁ equal ▁ to ▁ " . $ n . " STRNEWLINE " ; SieveOfEratosthenes ( $ n ) ; ? >
function maximumNumberDistinctPrimeRange ( $ m , $ n ) {
$ factorCount = array ( ) ;
$ prime = array ( ) ;
for ( $ i = 0 ; $ i <= $ n ; $ i ++ ) { $ factorCount [ $ i ] = 0 ;
$ prime [ $ i ] = true ; } for ( $ i = 2 ; $ i <= $ n ; $ i ++ ) {
if ( $ prime [ $ i ] == true ) {
$ factorCount [ $ i ] = 1 ;
for ( $ j = $ i * 2 ; $ j <= $ n ; $ j += $ i ) {
$ factorCount [ $ j ] ++ ;
$ prime [ $ j ] = false ; } } }
$ max = $ factorCount [ $ m ] ; $ num = $ m ;
for ( $ i = $ m ; $ i <= $ n ; $ i ++ ) {
if ( $ factorCount [ $ i ] > $ max ) { $ max = $ factorCount [ $ i ] ; $ num = $ i ; } } return $ num ; }
$ m = 4 ; $ n = 6 ;
echo maximumNumberDistinctPrimeRange ( $ m , $ n ) ; ? >
$ MAX_CHAR = 256 ;
$ count = array_fill ( 0 , $ MAX_CHAR + 1 , 0 ) ;
function fact ( $ n ) { return ( $ n <= 1 ) ? 1 : $ n * fact ( $ n - 1 ) ; }
function populateAndIncreaseCount ( & $ count , $ str ) { global $ MAX_CHAR ; for ( $ i = 0 ; $ i < strlen ( $ str ) ; ++ $ i ) ++ $ count [ ord ( $ str [ $ i ] ) ] ; for ( $ i = 1 ; $ i < $ MAX_CHAR ; ++ $ i ) $ count [ $ i ] += $ count [ $ i - 1 ] ; }
function updatecount ( & $ count , $ ch ) { global $ MAX_CHAR ; for ( $ i = ord ( $ ch ) ; $ i < $ MAX_CHAR ; ++ $ i ) -- $ count [ $ i ] ; }
function findRank ( $ str ) { global $ MAX_CHAR ; $ len = strlen ( $ str ) ; $ mul = fact ( $ len ) ; $ rank = 1 ;
populateAndIncreaseCount ( $ count , $ str ) ; for ( $ i = 0 ; $ i < $ len ; ++ $ i ) { $ mul = ( int ) ( $ mul / ( $ len - $ i ) ) ;
$ rank += $ count [ ord ( $ str [ $ i ] ) - 1 ] * $ mul ;
updatecount ( $ count , $ str [ $ i ] ) ; } return $ rank ; }
$ str = " string " ; echo findRank ( $ str ) ; ? >
function binomialCoeff ( $ n , $ k ) { $ res = 1 ; if ( $ k > $ n - $ k ) $ k = $ n - $ k ; for ( $ i = 0 ; $ i < $ k ; ++ $ i ) { $ res *= ( $ n - $ i ) ; $ res /= ( $ i + 1 ) ; } return $ res ; }
function printPascal ( $ n ) {
for ( $ line = 0 ; $ line < $ n ; $ line ++ ) {
for ( $ i = 0 ; $ i <= $ line ; $ i ++ ) echo " " . binomialCoeff ( $ line , ▁ $ i ) . " " echo " STRNEWLINE " ; } }
$ n = 7 ; printPascal ( $ n ) ; ? >
function isPerfectSquare ( $ x ) { $ s = ( int ) ( sqrt ( $ x ) ) ; return ( $ s * $ s == $ x ) ; }
function isFibonacci ( $ n ) {
return isPerfectSquare ( 5 * $ n * $ n + 4 ) || isPerfectSquare ( 5 * $ n * $ n - 4 ) ; }
for ( $ i = 1 ; $ i <= 10 ; $ i ++ ) if ( isFibonacci ( $ i ) ) echo " $ i ▁ is ▁ a ▁ Fibonacci ▁ Number ▁ STRNEWLINE " ; else echo " $ i ▁ is ▁ a ▁ not ▁ Fibonacci ▁ Number ▁ STRNEWLINE " ; ? >
function findTrailingZeros ( $ n ) {
$ count = 0 ;
for ( $ i = 5 ; $ n / $ i >= 1 ; $ i *= 5 ) $ count += $ n / $ i ; return $ count ; }
$ n = 100 ; echo " Count ▁ of ▁ trailing ▁ 0s ▁ in ▁ " , 100 , " ! ▁ is ▁ " , findTrailingZeros ( $ n ) ; ? >
function catalan ( $ n ) {
if ( $ n <= 1 ) return 1 ;
$ res = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ res += catalan ( $ i ) * catalan ( $ n - $ i - 1 ) ; return $ res ; }
for ( $ i = 0 ; $ i < 10 ; $ i ++ ) echo catalan ( $ i ) , " ▁ " ; ? >
function catalanDP ( $ n ) {
$ catalan = array ( ) ;
$ catalan [ 0 ] = $ catalan [ 1 ] = 1 ;
for ( $ i = 2 ; $ i <= $ n ; $ i ++ ) { $ catalan [ $ i ] = 0 ; for ( $ j = 0 ; $ j < $ i ; $ j ++ ) $ catalan [ $ i ] += $ catalan [ $ j ] * $ catalan [ $ i - $ j - 1 ] ; }
return $ catalan [ $ n ] ; }
for ( $ i = 0 ; $ i < 10 ; $ i ++ ) echo catalanDP ( $ i ) , " ▁ " ;
function binomialCoeff ( $ n , $ k ) { $ res = 1 ;
if ( $ k > $ n - $ k ) $ k = $ n - $ k ;
for ( $ i = 0 ; $ i < $ k ; ++ $ i ) { $ res *= ( $ n - $ i ) ; $ res = floor ( $ res / ( $ i + 1 ) ) ; } return $ res ; }
function catalan ( $ n ) {
$ c = binomialCoeff ( 2 * ( $ n ) , $ n ) ;
return floor ( $ c / ( $ n + 1 ) ) ; }
for ( $ i = 0 ; $ i < 10 ; $ i ++ ) echo catalan ( $ i ) , " ▁ " ; ? >
function getInvCount ( $ arr ) { $ inv_count = 0 ; for ( $ i = 0 ; $ i < 9 - 1 ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < 9 ; $ j ++ )
$ inv_count ++ ; return $ inv_count ; }
function isSolvable ( $ puzzle ) {
$ invCount = getInvCount ( $ puzzle ) ;
return ( $ invCount % 2 == 0 ) ; }
$ puzzle = array ( array ( 1 , 8 , 2 ) , array ( 0 , 4 , 3 ) , array ( 7 , 6 , 5 ) ) ; if ( isSolvable ( $ puzzle ) == true ) echo " Solvable " ; else echo " Not ▁ Solvable " ; ? >
function find ( $ p ) { return ceil ( sqrt ( 2 * 365 * log ( 1 / ( 1 - $ p ) ) ) ) ; }
echo find ( 0.70 ) ; ? >
function countSolutions ( $ n ) { $ res = 0 ; for ( $ x = 0 ; $ x * $ x < $ n ; $ x ++ ) for ( $ y = 0 ; $ x * $ x + $ y * $ y < $ n ; $ y ++ ) $ res ++ ; return $ res ; }
{ echo " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " ; echo countSolutions ( 6 ) ; return 0 ; } ? >
function countSolutions ( $ n ) { $ x = 0 ; $ yCount ; $ res = 0 ;
for ( $ yCount = 0 ; $ yCount * $ yCount < $ n ; $ yCount ++ ) ;
while ( $ yCount != 0 ) {
$ res += $ yCount ;
$ x ++ ;
while ( $ yCount != 0 and ( $ x * $ x + ( $ yCount - 1 ) * ( $ yCount - 1 ) >= $ n ) ) $ yCount -- ; } return $ res ; }
echo " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative " , " pairs ▁ is ▁ " , countSolutions ( 6 ) , " STRNEWLINE " ; ? >
$ EPSILON = 0.001 ;
function func ( $ x ) { return $ x * $ x * $ x - $ x * $ x + 2 ; }
function derivFunc ( $ x ) { return 3 * $ x * $ x - 2 * $ x ; }
function newtonRaphson ( $ x ) { global $ EPSILON ; $ h = func ( $ x ) / derivFunc ( $ x ) ; while ( abs ( $ h ) >= $ EPSILON ) { $ h = func ( $ x ) / derivFunc ( $ x ) ;
$ x = $ x - $ h ; } echo " The ▁ value ▁ of ▁ the ▁ " . " root ▁ is ▁ : ▁ " , $ x ; }
$ x0 = -20 ; newtonRaphson ( $ x0 ) ; ? >
function oppositeSigns ( $ x , $ y ) { return ( ( $ x ^ $ y ) < 0 ) ; }
$ x = 100 ; $ y = -100 ; if ( oppositeSigns ( $ x , $ y ) == true ) echo ( " Signs ▁ are ▁ opposite " ) ; else echo ( " Signs ▁ are ▁ not ▁ opposite " ) ; ? >
function update ( & $ arr , $ l , $ r , $ val ) { $ arr [ $ l ] += $ val ; if ( $ r + 1 < sizeof ( $ arr ) ) $ arr [ $ r + 1 ] -= $ val ; }
function getElement ( & $ arr , $ i ) {
$ res = 0 ; for ( $ j = 0 ; $ j <= $ i ; $ j ++ ) $ res += $ arr [ $ j ] ; return $ res ; }
$ arr = array ( 0 , 0 , 0 , 0 , 0 ) ; $ n = sizeof ( $ arr ) ; $ l = 2 ; $ r = 4 ; $ val = 2 ; update ( $ arr , $ l , $ r , $ val ) ;
$ index = 4 ; echo ( " Element ▁ at ▁ index ▁ " . $ index . " ▁ is ▁ " . getElement ( $ arr , $ index ) . " STRNEWLINE " ) ; $ l = 0 ; $ r = 3 ; $ val = 4 ; update ( $ arr , $ l , $ r , $ val ) ;
$ index = 3 ; echo ( " Element ▁ at ▁ index ▁ " . $ index . " ▁ is ▁ " . getElement ( $ arr , $ index ) ) ; ? >
function countSetBits ( $ n ) {
$ bitCount = 0 ; for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) $ bitCount += countSetBitsUtil ( $ i ) ; return $ bitCount ; }
function countSetBitsUtil ( $ x ) { if ( $ x <= 0 ) return 0 ; return ( $ x % 2 == 0 ? 0 : 1 ) + countSetBitsUtil ( $ x / 2 ) ; }
$ n = 4 ; echo " Total ▁ set ▁ bit ▁ count ▁ is ▁ " . countSetBits ( $ n ) ; ? >
function countSetBits ( $ n ) { $ i = 0 ;
$ ans = 0 ;
while ( ( 1 << $ i ) <= $ n ) {
$ k = 0 ;
$ change = 1 << $ i ;
for ( $ j = 0 ; $ j <= $ n ; $ j ++ ) { $ ans += $ k ; if ( $ change == 1 ) {
$ k = ! $ k ;
$ change = 1 << $ i ; } else { $ change -- ; } }
$ i ++ ; } return $ ans ; }
$ n = 17 ; echo ( countSetBits ( $ n ) ) ; ? >
function snoob ( $ x ) { $ next = 0 ; if ( $ x ) {
$ rightOne = $ x & - $ x ;
$ nextHigherOneBit = $ x + $ rightOne ;
$ rightOnesPattern = $ x ^ $ nextHigherOneBit ;
$ rightOnesPattern = intval ( ( $ rightOnesPattern ) / $ rightOne ) ;
$ rightOnesPattern >>= 2 ;
$ next = $ nextHigherOneBit | $ rightOnesPattern ; } return $ next ; }
$ x = 156 ; echo " Next ▁ higher ▁ number ▁ with ▁ same ▁ " . " number ▁ of ▁ set ▁ bits ▁ is ▁ " . snoob ( $ x ) ; ? >
function multiplyWith3Point5 ( $ x ) { return ( $ x << 1 ) + $ x + ( $ x >> 1 ) ; }
$ x = 4 ; echo multiplyWith3Point5 ( $ x ) ; ? >
function getModulo ( $ n , $ d ) { return ( $ n & ( $ d - 1 ) ) ; }
$ n = 6 ;
$ d = 4 ; echo $ n , " ▁ moduo " , " ▁ " , $ d , " ▁ is ▁ " , " ▁ " , getModulo ( $ n , $ d ) ; ? >
function getOddOccurrence ( & $ arr , $ arr_size ) { $ count = 0 ; for ( $ i = 0 ; $ i < $ arr_size ; $ i ++ ) { for ( $ j = 0 ; $ j < $ arr_size ; $ j ++ ) { if ( $ arr [ $ i ] == $ arr [ $ j ] ) $ count ++ ; } if ( $ count % 2 != 0 ) return $ arr [ $ i ] ; } return -1 ; }
$ arr = array ( 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 ) ; $ n = sizeof ( $ arr ) ;
echo ( getOddOccurrence ( $ arr , $ n ) ) ; ? >
function fastPow ( $ N , $ K ) { if ( $ K == 0 ) return 1 ; $ temp = fastPow ( $ N , $ K / 2 ) ; if ( $ K % 2 == 0 ) return $ temp * $ temp ; else return $ N * $ temp * $ temp ; } function countWays ( $ N , $ K ) { return $ K * fastPow ( $ K - 1 , $ N - 1 ) ; }
$ N = 3 ; $ K = 3 ; echo countWays ( $ N , $ K ) ; ? >
function countSetBits ( $ n ) {
if ( $ n == 0 ) return 0 ; else return 1 + countSetBits ( $ n & ( $ n - 1 ) ) ; }
$ n = 9 ;
echo countSetBits ( $ n ) ; ? >
$ t = log10 ( 4 ) ; $ x = log ( 15 , 2 ) ; $ tt = ceil ( $ t ) ; $ xx = ceil ( $ x ) ; echo ( $ tt ) , " STRNEWLINE " ; echo ( $ xx ) , " STRNEWLINE " ; ? >
function countSetBits ( $ n ) { $ count = 0 ; while ( $ n ) { $ count += 1 ; $ n &= ( n - 1 ) ; } return $ count ; }
function FlippedCount ( $ a , $ b ) {
return countSetBits ( $ a ^ $ b ) ; }
$ a = 10 ; $ b = 20 ; echo FlippedCount ( $ a , $ b ) ; ? >
function PositionRightmostSetbit ( $ n ) {
$ position = 1 ; $ m = 1 ; while ( ! ( $ n & $ m ) ) {
$ m = $ m << 1 ; $ position ++ ; } return $ position ; }
$ n = 16 ;
echo PositionRightmostSetbit ( $ n ) ; ? >
function Right_most_setbit ( $ num ) { $ pos = 1 ; $ INT_SIZE = 32 ;
for ( $ i = 0 ; $ i < $ INT_SIZE ; $ i ++ ) { if ( ! ( $ num & ( 1 << $ i ) ) ) $ pos ++ ; else break ; } return $ pos ; }
$ num = 18 ; $ pos = Right_most_setbit ( $ num ) ; echo $ pos ; echo ( " STRNEWLINE " ) ? >
function bin ( $ n ) { if ( $ n > 1 ) bin ( $ n >> 1 ) ; echo ( $ n & 1 ) ; }
bin ( 131 ) ; echo " STRNEWLINE " ; bin ( 3 ) ;
function maxOnesIndex ( $ arr , $ n ) {
$ max_count = 0 ;
$ max_index ;
$ prev_zero = -1 ;
$ prev_prev_zero = -1 ;
for ( $ curr = 0 ; $ curr < $ n ; ++ $ curr ) {
if ( $ arr [ $ curr ] == 0 ) {
if ( $ curr - $ prev_prev_zero > $ max_count ) { $ max_count = $ curr - $ prev_prev_zero ; $ max_index = $ prev_zero ; }
$ prev_prev_zero = $ prev_zero ; $ prev_zero = $ curr ; } }
if ( $ n - $ prev_prev_zero > $ max_count ) $ max_index = $ prev_zero ; return $ max_index ; }
$ arr = array ( 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 ) ; $ n = sizeof ( $ arr ) ; echo " Index ▁ of ▁ 0 ▁ to ▁ be ▁ replaced ▁ is ▁ " , maxOnesIndex ( $ arr , $ n ) ; ? >
function mins ( $ x , $ y ) { if ( $ x < $ y ) return $ x ; else return $ y ; } function maxi ( $ a , $ b ) { if ( $ a > $ b ) return $ a ; else return $ b ; }
function findLength ( & $ arr , $ n ) {
$ max_len = 1 ; for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) {
$ mn = $ arr [ $ i ] ; $ mx = $ arr [ $ i ] ;
for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) {
$ mn = mins ( $ mn , $ arr [ $ j ] ) ; $ mx = maxi ( $ mx , $ arr [ $ j ] ) ;
if ( ( $ mx - $ mn ) == $ j - $ i ) $ max_len = maxi ( $ max_len , $ mx - $ mn + 1 ) ; } }
return $ max_len ; }
$ arr = array ( 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 ) ; $ n = sizeof ( $ arr ) ; echo ( " Length ▁ of ▁ the ▁ longest ▁ contiguous " . " ▁ subarray ▁ is ▁ " ) ; echo ( findLength ( $ arr , $ n ) ) ; ? >
function printArr ( $ arr , $ k ) { for ( $ i = 0 ; $ i < $ k ; $ i ++ ) echo $ arr [ $ i ] , " ▁ " ; echo " STRNEWLINE " ; }
function printSeqUtil ( $ n , $ k , $ len , $ arr ) {
if ( $ len == $ k ) { printArr ( $ arr , $ k ) ; return ; }
$ i = ( $ len == 0 ) ? 1 : $ arr [ $ len - 1 ] + 1 ;
$ len ++ ;
while ( $ i <= $ n ) { $ arr [ $ len - 1 ] = $ i ; printSeqUtil ( $ n , $ k , $ len , $ arr ) ; $ i ++ ; }
$ len -- ; }
function printSeq ( $ n , $ k ) {
$ arr = array ( ) ;
$ len = 0 ; printSeqUtil ( $ n , $ k , $ len , $ arr ) ; }
$ k = 3 ; $ n = 7 ; printSeq ( $ n , $ k ) ; ? >
function isSubSequence ( $ str1 , $ str2 , $ m , $ n ) {
if ( $ m == 0 ) return true ; if ( $ n == 0 ) return false ;
if ( $ str1 [ $ m - 1 ] == $ str2 [ $ n - 1 ] ) return isSubSequence ( $ str1 , $ str2 , $ m - 1 , $ n - 1 ) ;
return isSubSequence ( $ str1 , $ str2 , $ m , $ n - 1 ) ; }
$ str1 = " gksrek " ; $ str2 = " geeksforgeeks " ; $ m = strlen ( $ str1 ) ; $ n = strlen ( $ str2 ) ; $ t = isSubSequence ( $ str1 , $ str2 , $ m , $ n ) ? " Yes ▁ " : " No " ; if ( $ t = true ) echo " Yes " ; else echo " No " ; ? >
function segregate0and1 ( & $ arr , $ n ) {
$ count = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] == 0 ) $ count ++ ; }
for ( $ i = 0 ; $ i < $ count ; $ i ++ ) $ arr [ $ i ] = 0 ;
for ( $ i = $ count ; $ i < $ n ; $ i ++ ) $ arr [ $ i ] = 1 ; }
function toprint ( & $ arr , $ n ) { echo ( " Array ▁ after ▁ segregation ▁ is ▁ " ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo ( $ arr [ $ i ] . " ▁ " ) ; }
$ arr = array ( 0 , 1 , 0 , 1 , 1 , 1 ) ; $ n = sizeof ( $ arr ) ; segregate0and1 ( $ arr , $ n ) ; toprint ( $ arr , $ n ) ; ? >
function segregate0and1 ( & $ arr , $ size ) { $ type0 = 0 ; $ type1 = $ size - 1 ; while ( $ type0 < $ type1 ) { if ( $ arr [ $ type0 ] == 1 ) { $ temp = $ arr [ $ type0 ] ; $ arr [ $ type0 ] = $ arr [ $ type1 ] ; $ arr [ $ type1 ] = $ temp ; $ type1 -- ; } else $ type0 ++ ; } }
$ arr = array ( 0 , 1 , 0 , 1 , 1 , 1 ) ; $ arr_size = sizeof ( $ arr ) ; segregate0and1 ( $ arr , $ arr_size ) ; echo ( " Array ▁ after ▁ segregation ▁ is ▁ " ) ; for ( $ i = 0 ; $ i < $ arr_size ; $ i ++ ) echo ( $ arr [ $ i ] . " ▁ " ) ; ? >
function GetCeilIndex ( $ arr , $ T , $ l , $ r , $ key ) { while ( $ r - $ l > 1 ) { $ m = ( int ) ( $ l + ( $ r - $ l ) / 2 ) ; if ( $ arr [ $ T [ $ m ] ] >= $ key ) $ r = $ m ; else $ l = $ m ; } return $ r ; } function LongestIncreasingSubsequence ( $ arr , $ n ) {
$ tailIndices = array_fill ( 0 , $ n + 1 , 0 ) ;
$ prevIndices = array_fill ( 0 , $ n + 1 , -1 ) ;
$ len = 1 ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] < $ arr [ $ tailIndices [ 0 ] ] ) {
$ tailIndices [ 0 ] = $ i ; } else if ( $ arr [ $ i ] > $ arr [ $ tailIndices [ $ len - 1 ] ] ) {
$ prevIndices [ $ i ] = $ tailIndices [ $ len - 1 ] ; $ tailIndices [ $ len ++ ] = $ i ; } else {
$ pos = GetCeilIndex ( $ arr , $ tailIndices , -1 , $ len - 1 , $ arr [ $ i ] ) ; $ prevIndices [ $ i ] = $ tailIndices [ $ pos - 1 ] ; $ tailIndices [ $ pos ] = $ i ; } } echo " LIS ▁ of ▁ given ▁ input STRNEWLINE " ; for ( $ i = $ tailIndices [ $ len - 1 ] ; $ i >= 0 ; $ i = $ prevIndices [ $ i ] ) echo $ arr [ $ i ] . " ▁ " ; echo " STRNEWLINE " ; return $ len ; }
$ arr = array ( 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 ) ; $ n = count ( $ arr ) ; print ( " LIS ▁ size ▁ " . LongestIncreasingSubsequence ( $ arr , $ n ) ) ; ? >
function generateUtil ( & $ A , & $ B , & $ C , $ i , $ j , $ m , $ n , $ len , $ flag ) {
if ( $ flag ) {
if ( $ len ) printArr ( $ C , $ len + 1 ) ;
for ( $ k = $ i ; $ k < $ m ; $ k ++ ) { if ( ! $ len ) {
$ C [ $ len ] = $ A [ $ k ] ;
generateUtil ( $ A , $ B , $ C , $ k + 1 , $ j , $ m , $ n , $ len , ! $ flag ) ; } else
{ if ( $ A [ $ k ] > $ C [ $ len ] ) { $ C [ $ len + 1 ] = $ A [ $ k ] ; generateUtil ( $ A , $ B , $ C , $ k + 1 , $ j , $ m , $ n , $ len + 1 , ! $ flag ) ; } } } } else
{ for ( $ l = $ j ; $ l < $ n ; $ l ++ ) { if ( $ B [ $ l ] > $ C [ $ len ] ) { $ C [ $ len + 1 ] = $ B [ $ l ] ; generateUtil ( $ A , $ B , $ C , $ i , $ l + 1 , $ m , $ n , $ len + 1 , ! $ flag ) ; } } } }
function generate ( & $ A , & $ B , $ m , $ n ) { $ C = array_fill ( 0 , ( $ m + $ n ) , NULL ) ;
generateUtil ( $ A , $ B , $ C , 0 , 0 , $ m , $ n , 0 , true ) ; }
function printArr ( & $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; echo " STRNEWLINE " ; }
$ A = array ( 10 , 15 , 25 ) ; $ B = array ( 5 , 20 , 30 ) ; $ n = sizeof ( $ A ) ; $ m = sizeof ( $ B ) ; generate ( $ A , $ B , $ n , $ m ) ; ? >
function replace_elements ( $ arr , $ n ) {
$ pos = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ arr [ $ pos ++ ] = $ arr [ $ i ] ; while ( $ pos > 1 && $ arr [ $ pos - 2 ] == $ arr [ $ pos - 1 ] ) { $ pos -- ; $ arr [ $ pos - 1 ] ++ ; } }
for ( $ i = 0 ; $ i < $ pos ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; }
$ arr = array ( 6 , 4 , 3 , 4 , 3 , 3 , 5 ) ; $ n = count ( $ arr ) ; replace_elements ( $ arr , $ n ) ; ? >
function arrangeString ( $ str , $ x , $ y ) { $ count_0 = 0 ; $ count_1 = 0 ; $ len = strlen ( $ str ) ;
for ( $ i = 0 ; $ i < $ len ; $ i ++ ) { if ( $ str [ $ i ] == '0' ) $ count_0 ++ ; else $ count_1 ++ ; }
while ( $ count_0 > 0 $ count_1 > 0 ) { for ( $ j = 0 ; $ j < $ x && $ count_0 > 0 ; $ j ++ ) { if ( $ count_0 > 0 ) { echo "0" ; $ count_0 -- ; } } for ( $ j = 0 ; $ j < $ y && $ count_1 > 0 ; $ j ++ ) { if ( $ count_1 > 0 ) { echo "1" ; $ count_1 -- ; } } } }
$ str = "01101101101101101000000" ; $ x = 1 ; $ y = 2 ; arrangeString ( $ str , $ x , $ y ) ; ? >
function rearrange ( & $ arr , $ n ) {
if ( $ arr == NULL $ n % 2 == 1 ) return ;
$ currIdx = intval ( ( $ n - 1 ) / 2 ) ;
while ( $ currIdx > 0 ) { $ count = $ currIdx ; $ swapIdx = $ currIdx ; while ( $ count -- > 0 ) { $ temp = $ arr [ $ swapIdx + 1 ] ; $ arr [ $ swapIdx + 1 ] = $ arr [ $ swapIdx ] ; $ arr [ $ swapIdx ] = $ temp ; $ swapIdx ++ ; } $ currIdx -- ; } }
$ arr = array ( 1 , 3 , 5 , 2 , 4 , 6 ) ; $ n = count ( $ arr ) ; rearrange ( $ arr , $ n ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo ( $ arr [ $ i ] . " ▁ " ) ; ? >
function maxDiff ( $ arr , $ n ) {
$ maxDiff = -1 ;
$ maxRight = $ arr [ $ n - 1 ] ; for ( $ i = $ n - 2 ; $ i >= 0 ; $ i -- ) { if ( $ arr [ $ i ] > $ maxRight ) $ maxRight = $ arr [ $ i ] ; else { $ diff = $ maxRight - $ arr [ $ i ] ; if ( $ diff > $ maxDiff ) { $ maxDiff = $ diff ; } } } return $ maxDiff ; }
$ arr = array ( 1 , 2 , 90 , 10 , 110 ) ; $ n = sizeof ( $ arr ) ;
echo " Maximum ▁ difference ▁ is ▁ " , maxDiff ( $ arr , $ n ) ; ? >
function maxDiff ( $ arr , $ n ) {
$ diff = $ arr [ 1 ] - $ arr [ 0 ] ; $ curr_sum = $ diff ; $ max_sum = $ curr_sum ; for ( $ i = 1 ; $ i < $ n - 1 ; $ i ++ ) {
$ diff = $ arr [ $ i + 1 ] - $ arr [ $ i ] ;
if ( $ curr_sum > 0 ) $ curr_sum += $ diff ; else $ curr_sum = $ diff ;
if ( $ curr_sum > $ max_sum ) $ max_sum = $ curr_sum ; } return $ max_sum ; }
$ arr = array ( 80 , 2 , 6 , 3 , 100 ) ; $ n = sizeof ( $ arr ) ;
echo " Maximum ▁ difference ▁ is ▁ " , maxDiff ( $ arr , $ n ) ; ? >
function maxRepeating ( $ arr , $ n , $ k ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ arr [ $ arr [ $ i ] % $ k ] += $ k ;
$ max = $ arr [ 0 ] ; $ result = 0 ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] > $ max ) { $ max = $ arr [ $ i ] ; $ result = $ i ; } }
return $ result ; }
$ arr = array ( 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 ) ; $ n = sizeof ( $ arr ) ; $ k = 8 ; echo " The ▁ maximum ▁ repeating ▁ number ▁ is ▁ " , maxRepeating ( $ arr , $ n , $ k ) ; ? >
function maxPathSum ( $ ar1 , $ ar2 , $ m , $ n ) {
$ i = 0 ; $ j = 0 ;
$ result = 0 ; $ sum1 = 0 ; $ sum2 = 0 ;
while ( $ i < $ m and $ j < $ n ) {
if ( $ ar1 [ $ i ] < $ ar2 [ $ j ] ) $ sum1 += $ ar1 [ $ i ++ ] ;
else if ( $ ar1 [ $ i ] > $ ar2 [ $ j ] ) $ sum2 += $ ar2 [ $ j ++ ] ;
else {
$ result += max ( $ sum1 , $ sum2 ) + $ ar1 [ $ i ] ;
$ sum1 = 0 ; $ sum2 = 0 ;
$ i ++ ; $ j ++ ; } }
while ( $ i < $ m ) $ sum1 += $ ar1 [ $ i ++ ] ;
while ( $ j < $ n ) $ sum2 += $ ar2 [ $ j ++ ] ;
$ result += max ( $ sum1 , $ sum2 ) ; return $ result ; }
$ ar1 = array ( 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 ) ; $ ar2 = array ( 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 ) ; $ m = count ( $ ar1 ) ; $ n = count ( $ ar2 ) ;
echo " Maximum ▁ sum ▁ path ▁ is ▁ " , maxPathSum ( $ ar1 , $ ar2 , $ m , $ n ) ; ? >
function smallestGreater ( $ arr , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ diff = PHP_INT_MAX ; $ closest = -1 ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) { if ( $ arr [ $ i ] < $ arr [ $ j ] && $ arr [ $ j ] - $ arr [ $ i ] < $ diff ) { $ diff = $ arr [ $ j ] - $ arr [ $ i ] ; $ closest = $ j ; } }
if ( $ closest == -1 ) echo " _ ▁ " ; else echo $ arr [ $ closest ] , " ▁ " ; } }
$ ar = array ( 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 ) ; $ n = sizeof ( $ ar ) ; smallestGreater ( $ ar , $ n ) ; ? >
function findZeroes ( $ arr , $ n , $ m ) {
$ wL = 0 ; $ wR = 0 ;
$ bestL = 0 ; $ bestWindow = 0 ;
$ zeroCount = 0 ;
while ( $ wR < $ n ) {
if ( $ zeroCount <= $ m ) { if ( $ arr [ $ wR ] == 0 ) $ zeroCount ++ ; $ wR ++ ; }
if ( $ zeroCount > $ m ) { if ( $ arr [ $ wL ] == 0 ) $ zeroCount -- ; $ wL ++ ; }
if ( ( $ wR - $ wL > $ bestWindow ) && ( $ zeroCount <= $ m ) ) { $ bestWindow = $ wR - $ wL ; $ bestL = $ wL ; } }
for ( $ i = 0 ; $ i < $ bestWindow ; $ i ++ ) { if ( $ arr [ $ bestL + $ i ] == 0 ) echo $ bestL + $ i . " ▁ " ; } }
$ arr = array ( 1 , 0 , 0 , 1 , 1 , 0 , 1 , 0 , 1 , 1 ) ; $ m = 2 ; $ n = sizeof ( $ arr ) / sizeof ( $ arr [ 0 ] ) ; echo " Indexes ▁ of ▁ zeroes ▁ to ▁ be ▁ flipped ▁ are ▁ " ; findZeroes ( $ arr , $ n , $ m ) ; return 0 ; ? >
function countIncreasing ( $ arr , $ n ) {
$ cnt = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) { if ( $ arr [ $ j ] > $ arr [ $ j - 1 ] ) $ cnt ++ ;
else break ; } } return $ cnt ; }
$ arr = array ( 1 , 2 , 2 , 4 ) ; $ n = count ( $ arr ) ; echo " Count ▁ of ▁ strictly ▁ increasing ▁ " , " subarrays ▁ is ▁ " , countIncreasing ( $ arr , $ n ) ; ? >
function countIncreasing ( $ arr , $ n ) {
$ cnt = 0 ;
$ len = 1 ;
for ( $ i = 0 ; $ i < $ n - 1 ; ++ $ i ) {
if ( $ arr [ $ i + 1 ] > $ arr [ $ i ] ) $ len ++ ;
else { $ cnt += ( ( ( $ len - 1 ) * $ len ) / 2 ) ; $ len = 1 ; } }
if ( $ len > 1 ) $ cnt += ( ( ( $ len - 1 ) * $ len ) / 2 ) ; return $ cnt ; }
$ arr = array ( 1 , 2 , 2 , 4 ) ; $ n = count ( $ arr ) ; echo " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is ▁ " , countIncreasing ( $ arr , $ n ) ; ? >
function arraySum ( $ arr , $ n ) { $ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ sum = $ sum + $ arr [ $ i ] ; return $ sum ; }
function maxDiff ( $ arr , $ n , $ k ) {
sort ( $ arr ) ;
$ arraysum = arraySum ( $ arr , $ n ) ;
$ diff1 = abs ( $ arraysum - 2 * arraySum ( $ arr , $ k ) ) ;
array_reverse ( $ arr ) ;
$ diff2 = abs ( $ arraysum - 2 * arraySum ( $ arr , $ k ) ) ;
return ( max ( $ diff1 , $ diff2 ) ) ; }
$ arr = array ( 1 , 7 , 4 , 8 , -1 , 5 , 2 , 1 ) ; $ n = count ( $ arr ) ; $ k = 3 ; echo " Maximum ▁ Difference ▁ = ▁ " , maxDiff ( $ arr , $ n , $ k ) ; ? >
function minNumber ( $ a , $ n , $ x ) {
sort ( $ a ) ; $ k ; for ( $ k = 0 ; $ a [ ( $ n - 1 ) / 2 ] != $ x ; $ k ++ ) { $ a [ $ n ++ ] = $ x ; sort ( $ a ) ; } return $ k ; }
$ x = 10 ; $ a = array ( 10 , 20 , 30 ) ; $ n = 3 ; echo minNumber ( $ a , $ n , $ x ) , " STRNEWLINE " ; ? >
function minNumber ( $ a , $ n , $ x ) { $ l = 0 ; $ h = 0 ; $ e = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ a [ $ i ] == $ x ) $ e ++ ;
else if ( $ a [ $ i ] > $ x ) $ h ++ ;
else if ( $ a [ $ i ] < $ x ) $ l ++ ; } $ ans = 0 ; if ( $ l > $ h ) $ ans = $ l - $ h ; else if ( $ l < $ h ) $ ans = $ h - $ l - 1 ;
return $ ans + 1 - $ e ; }
$ x = 10 ; $ a = array ( 10 , 20 , 30 ) ; $ n = sizeof ( $ a ) ; echo minNumber ( $ a , $ n , $ x ) , " STRNEWLINE " ; ? >
function fun ( $ x ) { $ y = ( ( int ) ( $ x / 4 ) * 4 ) ;
$ ans = 0 ; for ( $ i = $ y ; $ i <= $ x ; $ i ++ ) $ ans ^= $ i ; return $ ans ; }
function query ( $ x ) {
if ( $ x == 0 ) return 0 ; $ k = ( int ) ( ( $ x + 1 ) / 2 ) ;
return ( $ x %= 2 ) ? 2 * fun ( $ k ) : ( ( fun ( $ k - 1 ) * 2 ) ^ ( $ k & 1 ) ) ; } function allQueries ( $ q , $ l , $ r ) { for ( $ i = 0 ; $ i < $ q ; $ i ++ ) echo ( query ( $ r [ $ i ] ) ^ query ( $ l [ $ i ] - 1 ) ) , " STRNEWLINE " ; }
$ q = 3 ; $ l = array ( 2 , 2 , 5 ) ; $ r = array ( 4 , 8 , 9 ) ; allQueries ( $ q , $ l , $ r ) ; ? >
function checkEVENodd ( $ arr , $ n , $ l , $ r ) {
if ( $ arr [ $ r ] == 1 ) echo " odd " , " STRNEWLINE " ;
else echo " even " , " STRNEWLINE " ; }
$ arr = array ( 1 , 1 , 0 , 1 ) ; $ n = sizeof ( $ arr ) ; checkEVENodd ( $ arr , $ n , 1 , 3 ) ; ? >
function findMean ( $ arr , $ l , $ r ) {
$ sum = 0 ; $ count = 0 ;
for ( $ i = $ l ; $ i <= $ r ; $ i ++ ) { $ sum += $ arr [ $ i ] ; $ count ++ ; }
$ mean = floor ( $ sum / $ count ) ;
return $ mean ; }
$ arr = array ( 1 , 2 , 3 , 4 , 5 ) ; echo findMean ( $ arr , 0 , 2 ) , " STRNEWLINE " ; echo findMean ( $ arr , 1 , 3 ) , " STRNEWLINE " ; echo findMean ( $ arr , 0 , 4 ) , " STRNEWLINE " ; ? >
function calculateProduct ( $ A , $ L , $ R , $ P ) {
$ L = $ L - 1 ; $ R = $ R - 1 ; $ ans = 1 ; for ( $ i = $ L ; $ i <= $ R ; $ i ++ ) { $ ans = $ ans * $ A [ $ i ] ; $ ans = $ ans % $ P ; } return $ ans ; }
$ A = array ( 1 , 2 , 3 , 4 , 5 , 6 ) ; $ P = 229 ; $ L = 2 ; $ R = 5 ; echo calculateProduct ( $ A , $ L , $ R , $ P ) , " " ; $ L = 1 ; $ R = 3 ; echo calculateProduct ( $ A , $ L , $ R , $ P ) , " " ; ? >
$ MAX = 10000 ;
$ prefix = array_fill ( 0 , ( $ MAX + 1 ) , 0 ) ; function buildPrefix ( ) { global $ MAX , $ prefix ;
$ prime = array_fill ( 0 , ( $ MAX + 1 ) , true ) ; for ( $ p = 2 ; $ p * $ p <= $ MAX ; $ p ++ ) {
if ( $ prime [ $ p ] == true ) {
for ( $ i = $ p * 2 ; $ i <= $ MAX ; $ i += $ p ) $ prime [ $ i ] = false ; } }
for ( $ p = 2 ; $ p <= $ MAX ; $ p ++ ) { $ prefix [ $ p ] = $ prefix [ $ p - 1 ] ; if ( $ prime [ $ p ] ) $ prefix [ $ p ] ++ ; } }
function query ( $ L , $ R ) { global $ prefix ; return $ prefix [ $ R ] - $ prefix [ $ L - 1 ] ; }
buildPrefix ( ) ; $ L = 5 ; $ R = 10 ; echo query ( $ L , $ R ) . " STRNEWLINE " ; $ L = 1 ; $ R = 10 ; echo query ( $ L , $ R ) . " STRNEWLINE " ; ? >
function command ( $ arr , $ a , $ b ) { $ arr [ $ a ] = $ arr [ $ a ] ^ 1 ; $ arr [ $ b + 1 ] ^= 1 ; }
function process ( $ arr , $ n ) { for ( $ k = 1 ; $ k <= $ n ; $ k ++ ) { $ arr [ $ k ] = $ arr [ $ k ] ^ $ arr [ $ k - 1 ] ; } }
function result ( $ arr , $ n ) { for ( $ k = 1 ; $ k <= $ n ; $ k ++ ) echo $ arr [ $ k ] . " ▁ " ; }
$ n = 5 ; $ m = 3 ; $ arr = new SplFixedArray ( 7 ) ; $ arr [ 6 ] = array ( 0 ) ;
command ( $ arr , 1 , 5 ) ; command ( $ arr , 2 , 5 ) ; command ( $ arr , 3 , 5 ) ;
process ( $ arr , $ n ) ;
result ( $ arr , $ n ) ; ? >
function probability ( $ a , $ b , $ size1 , $ size2 ) {
$ max1 = PHP_INT_MIN ; $ count1 = 0 ; for ( $ i = 0 ; $ i < $ size1 ; $ i ++ ) { if ( $ a [ $ i ] > $ max1 ) { $ max1 = $ a [ $ i ] ; $ count1 = 1 ; } else if ( $ a [ $ i ] == $ max1 ) { $ count1 ++ ; } }
$ max2 = PHP_INT_MIN ; $ count2 = 0 ; for ( $ i = 0 ; $ i < $ size2 ; $ i ++ ) { if ( $ b [ $ i ] > $ max2 ) { $ max2 = $ b [ $ i ] ; $ count2 = 1 ; } else if ( $ b [ $ i ] == $ max2 ) { $ count2 ++ ; } }
return ( double ) ( $ count1 * $ count2 ) / ( $ size1 * $ size2 ) ; }
$ a = array ( 1 , 2 , 3 ) ; $ b = array ( 1 , 3 , 3 ) ; $ size1 = sizeof ( $ a ) ; $ size2 = sizeof ( $ b ) ; echo probability ( $ a , $ b , $ size1 , $ size2 ) ; ? >
function countDe ( $ arr , $ n ) {
$ v = $ arr ;
sort ( $ arr ) ;
$ count1 = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] != $ v [ $ i ] ) $ count1 ++ ;
rsort ( $ arr ) ;
$ count2 = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] != $ v [ $ i ] ) $ count2 ++ ;
return ( min ( $ count1 , $ count2 ) ) ; }
$ arr = array ( 5 , 9 , 21 , 17 , 13 ) ; $ n = count ( $ arr ) ; echo " Minimum ▁ Dearrangement ▁ = ▁ " . countDe ( $ arr , $ n ) ; ? >
function maxOfSegmentMins ( $ a , $ n , $ k ) {
if ( $ k == 1 ) return min ( $ a ) ; if ( $ k == 2 ) return max ( $ a [ 0 ] , $ a [ $ n - 1 ] ) ;
return max ( $ a ) ; }
$ a = array ( -10 , -9 , -8 , 2 , 7 , -6 , -5 ) ; $ n = count ( $ a ) ; $ k = 2 ; echo maxOfSegmentMins ( $ a , $ n , $ k ) ; ? >
function printMinimumProduct ( $ arr , $ n ) {
$ first_min = min ( $ arr [ 0 ] , $ arr [ 1 ] ) ; $ second_min = max ( $ arr [ 0 ] , $ arr [ 1 ] ) ;
for ( $ i = 2 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] < $ first_min ) { $ second_min = $ first_min ; $ first_min = $ arr [ $ i ] ; } else if ( $ arr [ $ i ] < $ second_min ) $ second_min = $ arr [ $ i ] ; } return $ first_min * $ second_min ; }
$ a = array ( 11 , 8 , 5 , 7 , 5 , 100 ) ; $ n = sizeof ( $ a ) ; echo ( printMinimumProduct ( $ a , $ n ) ) ; ? >
function noOfTriples ( $ arr , $ n ) {
sort ( $ arr ) ;
$ count = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] == $ arr [ 2 ] ) $ count ++ ;
if ( $ arr [ 0 ] == $ arr [ 2 ] ) return ( $ count - 2 ) * ( $ count - 1 ) * ( $ count ) / 6 ;
else if ( $ arr [ 1 ] == $ arr [ 2 ] ) return ( $ count - 1 ) * ( $ count ) / 2 ;
return $ count ; }
$ arr = array ( 1 , 3 , 3 , 4 ) ; $ n = count ( $ arr ) ; echo noOfTriples ( $ arr , $ n ) ; ? >
function checkReverse ( $ arr , $ n ) {
$ temp [ $ n ] = array ( ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ temp [ $ i ] = $ arr [ $ i ] ;
sort ( $ temp , 0 ) ;
$ front ; for ( $ front = 0 ; $ front < $ n ; $ front ++ ) if ( $ temp [ $ front ] != $ arr [ $ front ] ) break ;
$ back ; for ( $ back = $ n - 1 ; $ back >= 0 ; $ back -- ) if ( $ temp [ $ back ] != $ arr [ $ back ] ) break ;
if ( $ front >= $ back ) return true ;
do { $ front ++ ; if ( $ arr [ $ front - 1 ] < $ arr [ $ front ] ) return false ; } while ( $ front != $ back ) ; return true ; }
$ arr = array ( 1 , 2 , 5 , 4 , 3 ) ; $ n = sizeof ( $ arr ) ; if ( checkReverse ( $ arr , $ n ) ) echo " Yes " . " STRNEWLINE " ; else echo " No " . " STRNEWLINE " ; ? >
function checkReverse ( $ arr , $ n ) { if ( $ n == 1 ) return true ;
for ( $ i = 1 ; $ i < $ n && $ arr [ $ i - 1 ] < $ arr [ $ i ] ; $ i ++ ) ; if ( $ i == $ n ) return true ;
$ j = $ i ; while ( $ arr [ $ j ] < $ arr [ $ j - 1 ] ) { if ( $ i > 1 && $ arr [ $ j ] < $ arr [ $ i - 2 ] ) return false ; $ j ++ ; } if ( $ j == $ n ) return true ;
$ k = $ j ;
if ( $ arr [ $ k ] < $ arr [ $ i - 1 ] ) return false ; while ( $ k > 1 && $ k < $ n ) { if ( $ arr [ $ k ] < $ arr [ $ k - 1 ] ) return false ; $ k ++ ; } return true ; }
$ arr = array ( 1 , 3 , 4 , 10 , 9 , 8 ) ; $ n = sizeof ( $ arr ) ; if ( checkReverse ( $ arr , $ n ) ) echo " Yes " ; else echo " No " ; ? >
function MinOperation ( $ a , $ b , $ n ) {
sort ( $ a ) ; sort ( $ b ) ;
$ result = 0 ;
for ( $ i = 0 ; $ i < $ n ; ++ $ i ) { if ( $ a [ $ i ] > $ b [ $ i ] ) $ result = $ result + abs ( $ a [ $ i ] - $ b [ $ i ] ) ; else if ( $ a [ $ i ] < $ b [ $ i ] ) $ result = $ result + abs ( $ a [ $ i ] - $ b [ $ i ] ) ; } return $ result ; }
$ a = array ( 3 , 1 , 1 ) ; $ b = array ( 1 , 2 , 2 ) ; $ n = sizeof ( $ a ) ; echo MinOperation ( $ a , $ b , $ n ) ; ? >
function sortExceptUandL ( $ a , $ l , $ u , $ n ) {
$ b = array ( ) ; for ( $ i = 0 ; $ i < $ l ; $ i ++ ) $ b [ $ i ] = $ a [ $ i ] ; for ( $ i = $ u + 1 ; $ i < $ n ; $ i ++ ) $ b [ $ l + ( $ i - ( $ u + 1 ) ) ] = $ a [ $ i ] ;
sort ( $ b ) ;
for ( $ i = 0 ; $ i < $ l ; $ i ++ ) $ a [ $ i ] = $ b [ $ i ] ; for ( $ i = $ u + 1 ; $ i < $ n ; $ i ++ ) $ a [ $ i ] = $ b [ $ l + ( $ i - ( $ u + 1 ) ) ] ; }
$ a = array ( 4 , 5 , 3 , 12 , 14 , 9 ) ; $ n = count ( $ a ) ; $ l = 2 ; $ u = 4 ; sortExceptUandL ( $ a , $ l , $ u , $ n ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo ( $ a [ $ i ] . " ▁ " ) ; ? >
function sortExceptK ( & $ arr , $ k , $ n ) {
$ t = $ arr [ $ k ] ; $ arr [ $ k ] = $ arr [ $ n - 1 ] ; $ arr [ $ n - 1 ] = $ t ;
$ t = $ arr [ count ( $ arr ) - 1 ] ; $ arr = array_slice ( $ arr , 0 , -1 ) ; sort ( $ arr ) ; array_push ( $ arr , $ t ) ;
$ last = $ arr [ $ n - 1 ] ;
for ( $ i = $ n - 1 ; $ i > $ k ; $ i -- ) $ arr [ $ i ] = $ arr [ $ i - 1 ] ;
$ arr [ $ k ] = $ last ; }
$ a = array ( 10 , 4 , 11 , 7 , 6 , 20 ) ; $ k = 2 ; $ n = count ( $ a ) ; sortExceptK ( $ a , $ k , $ n ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo ( $ a [ $ i ] . " ▁ " ) ; ? >
function findMinSwaps ( $ arr , $ n ) {
$ noOfZeroes [ $ n ] = array ( ) ; $ noOfZeroes = array_fill ( 0 , $ n , true ) ; $ count = 0 ;
$ noOfZeroes [ $ n - 1 ] = 1 - $ arr [ $ n - 1 ] ; for ( $ i = $ n - 2 ; $ i >= 0 ; $ i -- ) { $ noOfZeroes [ $ i ] = $ noOfZeroes [ $ i + 1 ] ; if ( $ arr [ $ i ] == 0 ) $ noOfZeroes [ $ i ] ++ ; }
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] == 1 ) $ count += $ noOfZeroes [ $ i ] ; } return $ count ; }
$ arr = array ( 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 ) ; $ n = sizeof ( $ arr ) ; echo findMinSwaps ( $ arr , $ n ) ; ? >
function maxPartitions ( $ arr , $ n ) { $ ans = 0 ; $ max_so_far = 0 ; for ( $ i = 0 ; $ i < $ n ; ++ $ i ) {
$ max_so_far = max ( $ max_so_far , $ arr [ $ i ] ) ;
if ( $ max_so_far == $ i ) $ ans ++ ; } return $ ans ; }
{ $ arr = array ( 1 , 0 , 2 , 3 , 4 ) ; $ n = sizeof ( $ arr ) / sizeof ( $ arr [ 0 ] ) ; echo maxPartitions ( $ arr , $ n ) ; return 0 ; } ? >
function cuttringRopes ( $ Ropes , $ n ) {
sort ( $ Ropes ) ; $ singleOperation = 0 ;
$ cuttingLenght = $ Ropes [ 0 ] ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) {
if ( $ Ropes [ $ i ] - $ cuttingLenght > 0 ) { echo ( $ n - $ i ) . " ▁ " ;
$ cuttingLenght = $ Ropes [ $ i ] ; $ singleOperation ++ ; } }
if ( $ singleOperation == 0 ) echo "0 ▁ " ; }
$ Ropes = array ( 5 , 1 , 1 , 2 , 3 , 5 ) ; $ n = count ( $ Ropes ) ; cuttringRopes ( $ Ropes , $ n ) ; ? >
function rankify ( $ A , $ n ) {
$ R = array ( 0 ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ r = 1 ; $ s = 1 ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) { if ( $ j != $ i && $ A [ $ j ] < $ A [ $ i ] ) $ r += 1 ; if ( $ j != $ i && $ A [ $ j ] == $ A [ $ i ] ) $ s += 1 ; }
$ R [ $ i ] = $ r + ( float ) ( $ s - 1 ) / ( float ) 2 ; } for ( $ i = 0 ; $ i < $ n ; $ i ++ ) print number_format ( $ R [ $ i ] , 1 ) . ' ▁ ' ; }
$ A = array ( 1 , 2 , 5 , 2 , 1 , 25 , 2 ) ; $ n = count ( $ A ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ A [ $ i ] . ' ▁ ' ; echo " STRNEWLINE " ; rankify ( $ A , $ n ) ; ? >
function min_noOf_operation ( $ arr , $ n , $ k ) { $ noOfSubtraction ; $ res = 0 ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { $ noOfSubtraction = 0 ; if ( $ arr [ $ i ] > $ arr [ $ i - 1 ] ) {
$ noOfSubtraction = ( $ arr [ $ i ] - $ arr [ $ i - 1 ] ) / $ k ;
if ( ( $ arr [ $ i ] - $ arr [ $ i - 1 ] ) % $ k != 0 ) $ noOfSubtraction ++ ;
$ arr [ $ i ] = $ arr [ $ i ] - $ k * $ noOfSubtraction ; }
$ res = $ res + $ noOfSubtraction ; } return floor ( $ res ) ; }
$ arr = array ( 1 , 1 , 2 , 3 ) ; $ N = count ( $ arr ) ; $ k = 5 ; echo min_noOf_operation ( $ arr , $ N , $ k ) ; ? >
function maxSum ( $ arr , $ n ) {
sort ( $ arr ) ;
$ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ sum += ( $ arr [ $ i ] * $ i ) ; return $ sum ; }
$ arr = array ( 3 , 5 , 6 , 1 ) ; $ n = count ( $ arr ) ; echo maxSum ( $ arr , $ n ) ; ? >
function countPairs ( $ a , $ n , $ k ) { $ res = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) if ( abs ( $ a [ $ j ] - $ a [ $ i ] ) < $ k ) $ res ++ ; return $ res ; }
$ a = array ( 1 , 10 , 4 , 2 ) ; $ k = 3 ; $ n = count ( $ a ) ; echo countPairs ( $ a , $ n , $ k ) ; ? >
function countPairs ( $ a , $ n , $ k ) {
sort ( $ a ) ; $ res = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ j = $ i + 1 ; while ( $ j < $ n and $ a [ $ j ] - $ a [ $ i ] < $ k ) { $ res ++ ; $ j ++ ; } } return $ res ; }
$ a = array ( 1 , 10 , 4 , 2 ) ; $ k = 3 ; $ n = count ( $ a ) ; echo countPairs ( $ a , $ n , $ k ) ; ? >
function sumOfMinAbsDifferences ( $ arr , $ n ) {
sort ( $ arr ) ; sort ( $ arr , $ n ) ;
$ sum = 0 ;
$ sum += abs ( $ arr [ 0 ] - $ arr [ 1 ] ) ;
$ sum += abs ( $ arr [ $ n - 1 ] - $ arr [ $ n - 2 ] ) ;
for ( $ i = 1 ; $ i < $ n - 1 ; $ i ++ ) $ sum += min ( abs ( $ arr [ $ i ] - $ arr [ $ i - 1 ] ) , abs ( $ arr [ $ i ] - $ arr [ $ i + 1 ] ) ) ;
return $ sum ; }
$ arr = array ( 5 , 10 , 1 , 4 , 8 , 7 ) ; $ n = sizeof ( $ arr ) ; echo " Sum ▁ = ▁ " , sumOfMinAbsDifferences ( $ arr , $ n ) ; ? >
function findSmallestDifference ( $ A , $ B , $ m , $ n ) {
sort ( $ A ) ; sort ( $ A , $ m ) ; sort ( $ B ) ; sort ( $ B , $ n ) ; $ a = 0 ; $ b = 0 ; $ INT_MAX = 1 ;
$ result = $ INT_MAX ;
while ( $ a < $ m && $ b < $ n ) { if ( abs ( $ A [ $ a ] - $ B [ $ b ] ) < $ result ) $ result = abs ( $ A [ $ a ] - $ B [ $ b ] ) ;
if ( $ A [ $ a ] < $ B [ $ b ] ) $ a ++ ; else $ b ++ ; }
return $ result ; }
{
$ A = array ( 1 , 2 , 11 , 5 ) ;
$ B = array ( 4 , 12 , 19 , 23 , 127 , 235 ) ;
$ m = sizeof ( $ A ) / sizeof ( $ A [ 0 ] ) ; $ n = sizeof ( $ B ) / sizeof ( $ B [ 0 ] ) ;
echo findSmallestDifference ( $ A , $ B , $ m , $ n ) ; return 0 ; } ? >
function findLarger ( $ arr , $ n ) {
sort ( $ arr ) ;
for ( $ i = $ n - 1 ; $ i >= $ n / 2 ; $ i -- ) echo $ arr [ $ i ] , " ▁ " ; }
$ arr = array ( 1 , 3 , 6 , 1 , 0 , 9 ) ; $ n = count ( $ arr ) ; findLarger ( $ arr , $ n ) ; ? >
function findSingle ( $ ar , $ ar_size ) {
$ res = $ ar [ 0 ] ; for ( $ i = 1 ; $ i < $ ar_size ; $ i ++ ) $ res = $ res ^ $ ar [ $ i ] ; return $ res ; }
$ ar = array ( 2 , 3 , 5 , 4 , 5 , 3 , 4 ) ; $ n = count ( $ ar ) ; echo " Element ▁ occurring ▁ once ▁ is ▁ " , findSingle ( $ ar , $ n ) ; ? >
function countOccurrences ( $ arr , $ n , $ x ) { $ res = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ x == $ arr [ $ i ] ) $ res ++ ; return $ res ; }
$ arr = array ( 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 ) ; $ n = count ( $ arr ) ; $ x = 2 ; echo countOccurrences ( $ arr , $ n , $ x ) ; ? >
function binarySearch ( & $ arr , $ l , $ r , $ x ) { if ( $ r < $ l ) return -1 ; $ mid = $ l + ( $ r - $ l ) / 2 ;
if ( $ arr [ $ mid ] == $ x ) return $ mid ;
if ( $ arr [ $ mid ] > $ x ) return binarySearch ( $ arr , $ l , $ mid - 1 , $ x ) ;
return binarySearch ( $ arr , $ mid + 1 , $ r , $ x ) ; }
function countOccurrences ( $ arr , $ n , $ x ) { $ ind = binarySearch ( $ arr , 0 , $ n - 1 , $ x ) ;
if ( $ ind == -1 ) return 0 ;
$ count = 1 ; $ left = $ ind - 1 ; while ( $ left >= 0 && $ arr [ $ left ] == $ x ) { $ count ++ ; $ left -- ; }
$ right = $ ind + 1 ; while ( $ right < $ n && $ arr [ $ right ] == $ x ) { $ count ++ ; $ right ++ ; } return $ count ; }
$ arr = array ( 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 ) ; $ n = sizeof ( $ arr ) ; $ x = 2 ; echo countOccurrences ( $ arr , $ n , $ x ) ; ? >
function printClosest ( $ arr , $ n , $ x ) {
$ res_l ; $ res_r ;
$ l = 0 ; $ r = $ n - 1 ; $ diff = PHP_INT_MAX ;
while ( $ r > $ l ) {
if ( abs ( $ arr [ $ l ] + $ arr [ $ r ] - $ x ) < $ diff ) { $ res_l = $ l ; $ res_r = $ r ; $ diff = abs ( $ arr [ $ l ] + $ arr [ $ r ] - $ x ) ; }
if ( $ arr [ $ l ] + $ arr [ $ r ] > $ x ) $ r -- ;
else $ l ++ ; } echo " ▁ The ▁ closest ▁ pair ▁ is ▁ " , $ arr [ $ res_l ] , " ▁ and ▁ " , $ arr [ $ res_r ] ; }
$ arr = array ( 10 , 22 , 28 , 29 , 30 , 40 ) ; $ x = 54 ; $ n = count ( $ arr ) ; printClosest ( $ arr , $ n , $ x ) ; ? >
function countOnes ( $ arr , $ low , $ high ) { if ( $ high >= $ low ) {
$ mid = $ low + ( $ high - $ low ) / 2 ;
if ( ( $ mid == $ high or $ arr [ $ mid + 1 ] == 0 ) and ( $ arr [ $ mid ] == 1 ) ) return $ mid + 1 ;
if ( $ arr [ $ mid ] == 1 ) return countOnes ( $ arr , ( $ mid + 1 ) , $ high ) ;
return countOnes ( $ arr , $ low , ( $ mid - 1 ) ) ; } return 0 ; }
$ arr = array ( 1 , 1 , 1 , 1 , 0 , 0 , 0 ) ; $ n = count ( $ arr ) ; echo " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " , countOnes ( $ arr , 0 , $ n - 1 ) ; ? >
function findMissingUtil ( $ arr1 , $ arr2 , $ N ) {
if ( $ N == 1 ) return $ arr1 [ 0 ] ;
if ( $ arr1 [ 0 ] != $ arr2 [ 0 ] ) return $ arr1 [ 0 ] ;
$ lo = 0 ; $ hi = $ N - 1 ;
while ( $ lo < $ hi ) { $ mid = ( $ lo + $ hi ) / 2 ;
if ( $ arr1 [ $ mid ] == $ arr2 [ $ mid ] ) $ lo = $ mid ; else $ hi = $ mid ;
if ( $ lo == $ hi - 1 ) break ; }
return $ arr1 [ $ hi ] ; }
function findMissing ( $ arr1 , $ arr2 , $ M , $ N ) { if ( $ N == $ M - 1 ) echo " Missing ▁ Element ▁ is ▁ " , findMissingUtil ( $ arr1 , $ arr2 , $ M ) ; else if ( $ M == $ N - 1 ) echo " Missing ▁ Element ▁ is ▁ " , findMissingUtil ( $ arr2 , $ arr1 , $ N ) ; else echo " Invalid ▁ Input " ; }
$ arr1 = array ( 1 , 4 , 5 , 7 , 9 ) ; $ arr2 = array ( 4 , 5 , 7 , 9 ) ; $ M = count ( $ arr1 ) ; $ N = count ( $ arr2 ) ; findMissing ( $ arr1 , $ arr2 , $ M , $ N ) ; ? >
function findMissing ( $ arr1 , $ arr2 , $ M , $ N ) { if ( $ M != $ N - 1 && $ N != $ M - 1 ) { echo " Invalid ▁ Input " ; return ; }
$ res = 0 ; for ( $ i = 0 ; $ i < $ M ; $ i ++ ) $ res = $ res ^ $ arr1 [ $ i ] ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) $ res = $ res ^ $ arr2 [ $ i ] ; echo " Missing ▁ element ▁ is ▁ " , $ res ; }
$ arr1 = array ( 4 , 1 , 5 , 9 , 7 ) ; $ arr2 = array ( 7 , 5 , 9 , 4 ) ; $ M = sizeof ( $ arr1 ) ; $ N = sizeof ( $ arr2 ) ; findMissing ( $ arr1 , $ arr2 , $ M , $ N ) ; ? >
function getTwoElements ( & $ arr , $ n ) {
$ xor1 ;
$ set_bit_no ; $ i ; $ x = 0 ; $ y = 0 ; $ xor1 = $ arr [ 0 ] ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) $ xor1 = $ xor1 ^ $ arr [ $ i ] ;
for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) $ xor1 = $ xor1 ^ $ i ;
$ set_bit_no = $ xor1 & ~ ( $ xor1 - 1 ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( ( $ arr [ $ i ] & $ set_bit_no ) != 0 )
$ x = $ x ^ $ arr [ $ i ] ; else
$ y = $ y ^ $ arr [ $ i ] ; } for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) { if ( ( $ i & $ set_bit_no ) != 0 )
$ x = $ x ^ $ i ; else
$ y = $ y ^ $ i ; }
}
$ arr = array ( 1 , 3 , 4 , 5 , 1 , 6 , 2 ) ; $ n = sizeof ( $ arr ) ; getTwoElements ( $ arr , $ n ) ;
function search ( $ arr , $ n , $ x ) {
$ i = 0 ; while ( $ i < $ n ) {
if ( $ arr [ $ i ] == $ x ) return $ i ;
$ i = $ i + abs ( $ arr [ $ i ] - $ x ) ; } echo " number ▁ is ▁ not ▁ present ! " ; return -1 ; }
$ arr = array ( 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 ) ; $ n = sizeof ( $ arr ) ; $ x = 3 ; echo " Element ▁ " , $ x , " ▁ is ▁ present ▁ " , " at ▁ index ▁ " , search ( $ arr , $ n , 3 ) ; ? >
function thirdLargest ( $ arr , $ arr_size ) {
if ( $ arr_size < 3 ) { echo " ▁ Invalid ▁ Input ▁ " ; return ; }
$ first = $ arr [ 0 ] ; for ( $ i = 1 ; $ i < $ arr_size ; $ i ++ ) if ( $ arr [ $ i ] > $ first ) $ first = $ arr [ $ i ] ;
$ second = PHP_INT_MIN ; for ( $ i = 0 ; $ i < $ arr_size ; $ i ++ ) if ( $ arr [ $ i ] > $ second && $ arr [ $ i ] < $ first ) $ second = $ arr [ $ i ] ;
$ third = PHP_INT_MIN ; for ( $ i = 0 ; $ i < $ arr_size ; $ i ++ ) if ( $ arr [ $ i ] > $ third && $ arr [ $ i ] < $ second ) $ third = $ arr [ $ i ] ; echo " The ▁ third ▁ Largest ▁ element ▁ is ▁ " , $ third , " STRNEWLINE " ; }
$ arr = array ( 12 , 13 , 1 , 10 , 34 , 16 ) ; $ n = sizeof ( $ arr ) ; thirdLargest ( $ arr , $ n ) ; ? >
function thirdLargest ( $ arr , $ arr_size ) {
if ( $ arr_size < 3 ) { echo " ▁ Invalid ▁ Input ▁ " ; return ; }
$ first = $ arr [ 0 ] ; $ second = PHP_INT_MIN ; $ third = PHP_INT_MIN ;
for ( $ i = 1 ; $ i < $ arr_size ; $ i ++ ) {
if ( $ arr [ $ i ] > $ first ) { $ third = $ second ; $ second = $ first ; $ first = $ arr [ $ i ] ; }
else if ( $ arr [ $ i ] > $ second ) { $ third = $ second ; $ second = $ arr [ $ i ] ; }
else if ( $ arr [ $ i ] > $ third ) $ third = $ arr [ $ i ] ; } echo " The ▁ third ▁ Largest ▁ element ▁ is ▁ " , $ third ; }
$ arr = array ( 12 , 13 , 1 , 10 , 34 , 16 ) ; $ n = sizeof ( $ arr ) ; thirdLargest ( $ arr , $ n ) ; ? >
function checkPair ( & $ arr , $ n ) {
$ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ sum += $ arr [ $ i ] ;
if ( $ sum % 2 != 0 ) return false ; $ sum = $ sum / 2 ;
$ s = array ( ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ val = $ sum - $ arr [ $ i ] ;
if ( array_search ( $ val , $ s ) ) { echo " Pair ▁ elements ▁ are ▁ " . $ arr [ $ i ] . " ▁ and ▁ " . $ val . " STRNEWLINE " ; return true ; } array_push ( $ s , $ arr [ $ i ] ) ; } return false ; }
$ arr = array ( 2 , 11 , 5 , 1 , 4 , 7 ) ; $ n = sizeof ( $ arr ) ; if ( checkPair ( $ arr , $ n ) == false ) echo " No ▁ pair ▁ found " ; ? >
function search ( $ arr , $ n , $ x ) {
if ( $ arr [ $ n - 1 ] == $ x ) return " Found " ; $ backup = $ arr [ $ n - 1 ] ; $ arr [ $ n - 1 ] = $ x ;
for ( $ i = 0 ; ; $ i ++ ) {
if ( $ arr [ $ i ] == $ x ) {
$ arr [ $ n - 1 ] = $ backup ;
if ( $ i < $ n - 1 ) return " Found " ;
return " Not ▁ Found " ; } } }
$ arr = array ( 4 , 6 , 1 , 5 , 8 ) ; $ n = sizeof ( $ arr ) ; $ x = 1 ; echo ( search ( $ arr , $ n , $ x ) ) ; ? >
function findMajority ( $ arr , $ n ) { return $ arr [ intval ( $ n / 2 ) ] ; }
$ arr = array ( 1 , 2 , 2 , 3 ) ; $ n = count ( $ arr ) ; echo findMajority ( $ arr , $ n ) ; ? >
function minAdjDifference ( $ arr , $ n ) { if ( $ n < 2 ) return ;
$ res = abs ( $ arr [ 1 ] - $ arr [ 0 ] ) ; for ( $ i = 2 ; $ i < $ n ; $ i ++ ) $ res = min ( $ res , abs ( $ arr [ $ i ] - $ arr [ $ i - 1 ] ) ) ;
$ res = min ( $ res , abs ( $ arr [ $ n - 1 ] - $ arr [ 0 ] ) ) ; echo " Min ▁ Difference ▁ = ▁ " , $ res ; }
$ a = array ( 10 , 12 , 13 , 15 , 10 ) ; $ n = count ( $ a ) ; minAdjDifference ( $ a , $ n ) ; ? >
function Print3Smallest ( $ array , $ n ) { $ MAX = 100000 ; $ firstmin = $ MAX ; $ secmin = $ MAX ; $ thirdmin = $ MAX ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ array [ $ i ] < $ firstmin ) { $ thirdmin = $ secmin ; $ secmin = $ firstmin ; $ firstmin = $ array [ $ i ] ; }
else if ( $ array [ $ i ] < $ secmin ) { $ thirdmin = $ secmin ; $ secmin = $ array [ $ i ] ; }
else if ( $ array [ $ i ] < $ thirdmin ) $ thirdmin = $ array [ $ i ] ; } echo " First min = " . $ firstmin . " " ; STRNEWLINE echo ▁ " Second min = " . $ secmin . " " ; STRNEWLINE echo ▁ " Third min = " . $ thirdmin . " " }
$ array = array ( 4 , 9 , 1 , 32 , 12 ) ; $ n = sizeof ( $ array ) / sizeof ( $ array [ 0 ] ) ; Print3Smallest ( $ array , $ n ) ; ? >
function getMin ( & $ arr , $ n ) { return min ( $ arr ) ; } function getMax ( & $ arr , $ n ) { return max ( $ arr ) ; }
$ arr = array ( 12 , 1234 , 45 , 67 , 1 ) ; $ n = sizeof ( $ arr ) ; echo " Minimum ▁ element ▁ of ▁ array : ▁ " . getMin ( $ arr , $ n ) . " STRNEWLINE " ; echo " Maximum ▁ element ▁ of ▁ array : ▁ " . getMax ( $ arr , $ n ) ; ? >
function printfrequency ( $ arr , $ n ) {
for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ arr [ $ j ] = $ arr [ $ j ] - 1 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ arr [ $ arr [ $ i ] % $ n ] = $ arr [ $ arr [ $ i ] % $ n ] + $ n ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) echo $ i + 1 , " ▁ - > ▁ " , ( int ) ( $ arr [ $ i ] / $ n ) , " STRNEWLINE " ; }
$ arr = array ( 2 , 3 , 3 , 2 , 5 ) ; $ n = sizeof ( $ arr ) ; printfrequency ( $ arr , $ n ) ; ? >
function getInvCount ( $ arr , $ n ) {
$ invcount = 0 ; for ( $ i = 1 ; $ i < $ n - 1 ; $ i ++ ) {
$ small = 0 ; for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) if ( $ arr [ $ i ] > $ arr [ $ j ] ) $ small ++ ;
$ great = 0 ; for ( $ j = $ i - 1 ; $ j >= 0 ; $ j -- ) if ( $ arr [ $ i ] < $ arr [ $ j ] ) $ great ++ ;
$ invcount += $ great * $ small ; } return $ invcount ; }
$ arr = array ( 8 , 4 , 2 , 1 ) ; $ n = sizeof ( $ arr ) ; echo " Inversion ▁ Count ▁ : ▁ " , getInvCount ( $ arr , $ n ) ; ? >
function findWater ( $ arr , $ n ) {
$ water = 0 ;
$ left [ 0 ] = $ arr [ 0 ] ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) $ left [ $ i ] = max ( $ left [ $ i - 1 ] , $ arr [ $ i ] ) ;
$ right [ $ n - 1 ] = $ arr [ $ n - 1 ] ; for ( $ i = $ n - 2 ; $ i >= 0 ; $ i -- ) $ right [ $ i ] = max ( $ right [ $ i + 1 ] , $ arr [ $ i ] ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ water += min ( $ left [ $ i ] , $ right [ $ i ] ) - $ arr [ $ i ] ; return $ water ; }
$ arr = array ( 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ) ; $ n = sizeof ( $ arr ) ; echo " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " , findWater ( $ arr , $ n ) ; ? >
function findWater ( $ arr , $ n ) {
$ result = 0 ;
$ left_max = 0 ; $ right_max = 0 ;
$ lo = 0 ; $ hi = $ n - 1 ; while ( $ lo <= $ hi ) { if ( $ arr [ $ lo ] < $ arr [ $ hi ] ) { if ( $ arr [ $ lo ] > $ left_max )
$ left_max = $ arr [ $ lo ] ; else
$ result += $ left_max - $ arr [ $ lo ] ; $ lo ++ ; } else { if ( $ arr [ $ hi ] > $ right_max )
$ right_max = $ arr [ $ hi ] ; else $ result += $ right_max - $ arr [ $ hi ] ; $ hi -- ; } } return $ result ; }
$ arr = array ( 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ) ; $ n = count ( $ arr ) ; echo " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " , findWater ( $ arr , $ n ) ; ? >
function missingK ( & $ a , $ k , $ n ) { $ difference = 0 ; $ ans = 0 ; $ count = $ k ; $ flag = 0 ;
for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) { $ difference = 0 ;
if ( ( $ a [ $ i ] + 1 ) != $ a [ $ i + 1 ] ) {
$ difference += ( $ a [ $ i + 1 ] - $ a [ $ i ] ) - 1 ;
if ( $ difference >= $ count ) { $ ans = $ a [ $ i ] + $ count ; $ flag = 1 ; break ; } else $ count -= $ difference ; } }
if ( $ flag ) return $ ans ; else return -1 ; }
$ a = array ( 1 , 5 , 11 , 19 ) ;
$ k = 11 ; $ n = count ( $ a ) ;
$ missing = missingK ( $ a , $ k , $ n ) ; echo $ missing ; ? >
$ median = 0 ; $ i = 0 ; $ j = 0 ;
function maximum ( $ a , $ b ) { return $ a > $ b ? $ a : $ b ; }
function minimum ( $ a , $ b ) { return $ a < $ b ? $ a : $ b ; }
function findMedianSortedArrays ( & $ a , $ n , & $ b , $ m ) { global $ median , $ i , $ j ; $ min_index = 0 ; $ max_index = $ n ; while ( $ min_index <= $ max_index ) { $ i = intval ( ( $ min_index + $ max_index ) / 2 ) ; $ j = intval ( ( ( $ n + $ m + 1 ) / 2 ) - $ i ) ;
if ( $ i < $ n && $ j > 0 && $ b [ $ j - 1 ] > $ a [ $ i ] ) $ min_index = $ i + 1 ;
else if ( $ i > 0 && $ j < $ m && $ b [ $ j ] < $ a [ $ i - 1 ] ) $ max_index = $ i - 1 ;
else {
if ( $ i == 0 ) $ median = $ b [ $ j - 1 ] ;
else if ( $ j == 0 ) $ median = $ a [ $ i - 1 ] ; else $ median = maximum ( $ a [ $ i - 1 ] , $ b [ $ j - 1 ] ) ; break ; } }
if ( ( $ n + $ m ) % 2 == 1 ) return $ median ;
if ( $ i == $ n ) return ( ( $ median + $ b [ $ j ] ) / 2.0 ) ;
if ( $ j == $ m ) return ( ( $ median + $ a [ $ i ] ) / 2.0 ) ; return ( ( $ median + minimum ( $ a [ $ i ] , $ b [ $ j ] ) ) / 2.0 ) ; }
$ a = array ( 900 ) ; $ b = array ( 10 , 13 , 14 ) ; $ n = count ( $ a ) ; $ m = count ( $ b ) ;
if ( $ n < $ m ) echo ( " The ▁ median ▁ is ▁ : ▁ " . findMedianSortedArrays ( $ a , $ n , $ b , $ m ) ) ; else echo ( " The ▁ median ▁ is ▁ : ▁ " . findMedianSortedArrays ( $ b , $ m , $ a , $ n ) ) ; ? >
function printUncommon ( $ arr1 , $ arr2 , $ n1 , $ n2 ) { $ i = 0 ; $ j = 0 ; $ k = 0 ; while ( $ i < $ n1 && $ j < $ n2 ) {
if ( $ arr1 [ $ i ] < $ arr2 [ $ j ] ) { echo $ arr1 [ $ i ] . " " ; $ i ++ ; $ k ++ ; } else if ( $ arr2 [ $ j ] < $ arr1 [ $ i ] ) { echo $ arr2 [ $ j ] . " " ; $ k ++ ; $ j ++ ; }
else { $ i ++ ; $ j ++ ; } }
while ( $ i < $ n1 ) { echo $ arr1 [ $ i ] . " " ; $ i ++ ; $ k ++ ; } while ( $ j < $ n2 ) { echo $ arr2 [ $ j ] . " " ; $ j ++ ; $ k ++ ; } }
$ arr1 = array ( 10 , 20 , 30 ) ; $ arr2 = array ( 20 , 25 , 30 , 40 , 50 ) ; $ n1 = sizeof ( $ arr1 ) ; $ n2 = sizeof ( $ arr2 ) ; printUncommon ( $ arr1 , $ arr2 , $ n1 , $ n2 ) ; ? >
function leastFrequent ( $ arr , $ n ) {
sort ( $ arr ) ; sort ( $ arr , $ n ) ;
$ min_count = $ n + 1 ; $ res = -1 ; $ curr_count = 1 ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] == $ arr [ $ i - 1 ] ) $ curr_count ++ ; else { if ( $ curr_count < $ min_count ) { $ min_count = $ curr_count ; $ res = $ arr [ $ i - 1 ] ; } $ curr_count = 1 ; } }
if ( $ curr_count < $ min_count ) { $ min_count = $ curr_count ; $ res = $ arr [ $ n - 1 ] ; } return $ res ; }
{ $ arr = array ( 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 ) ; $ n = sizeof ( $ arr ) / sizeof ( $ arr [ 0 ] ) ; echo leastFrequent ( $ arr , $ n ) ; return 0 ; } ? >
$ M = 4 ;
function maximumSum ( $ a , $ n ) { global $ M ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) sort ( $ a [ $ i ] ) ;
$ sum = $ a [ $ n - 1 ] [ $ M - 1 ] ; $ prev = $ a [ $ n - 1 ] [ $ M - 1 ] ; $ i ; $ j ;
for ( $ i = $ n - 2 ; $ i >= 0 ; $ i -- ) { for ( $ j = $ M - 1 ; $ j >= 0 ; $ j -- ) { if ( $ a [ $ i ] [ $ j ] < $ prev ) { $ prev = $ a [ $ i ] [ $ j ] ; $ sum += $ prev ; break ; } }
if ( $ j == -1 ) return 0 ; } return $ sum ; }
$ arr = array ( array ( 1 , 7 , 3 , 4 ) , array ( 4 , 2 , 5 , 1 ) , array ( 9 , 5 , 1 , 8 ) ) ; $ n = sizeof ( $ arr ) ; echo maximumSum ( $ arr , $ n ) ; ? >
function countPairs ( $ A , $ n , $ k ) { $ ans = 0 ;
sort ( $ A ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) {
$ x = 0 ;
while ( ( $ A [ $ i ] * pow ( $ k , $ x ) ) <= $ A [ $ j ] ) { if ( ( $ A [ $ i ] * pow ( $ k , $ x ) ) == $ A [ $ j ] ) { $ ans ++ ; break ; } $ x ++ ; } } } return $ ans ; }
$ A = array ( 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 ) ; $ n = count ( $ A ) ; $ k = 3 ; echo countPairs ( $ A , $ n , $ k ) ; ? >
function minDistance ( $ arr , $ n ) { $ maximum_element = $ arr [ 0 ] ; $ min_dis = $ n ; $ index = 0 ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) {
if ( $ maximum_element == $ arr [ $ i ] ) { $ min_dis = min ( $ min_dis , ( $ i - $ index ) ) ; $ index = $ i ; }
else if ( $ maximum_element < $ arr [ $ i ] ) { $ maximum_element = $ arr [ $ i ] ; $ min_dis = $ n ; $ index = $ i ; }
else continue ; } return $ min_dis ; }
$ arr = array ( 6 , 3 , 1 , 3 , 6 , 4 , 6 ) ; $ n = count ( $ arr ) ; echo " Minimum ▁ distance ▁ = ▁ " . minDistance ( $ arr , $ n ) ; ? >
function findValue ( $ arr , $ n , $ k ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] == $ k ) $ k *= 2 ; return $ k ; }
$ arr = array ( 2 , 3 , 4 , 10 , 8 , 1 ) ; $ k = 2 ; $ n = count ( $ arr ) ; echo findValue ( $ arr , $ n , $ k ) ; ? >
function dupLastIndex ( $ arr , $ n ) {
if ( $ arr == null or $ n <= 0 ) return ;
for ( $ i = $ n - 1 ; $ i > 0 ; $ i -- ) { if ( $ arr [ $ i ] == $ arr [ $ i - 1 ] ) { echo " Last ▁ index : " , $ i , " STRNEWLINE " ; echo " Last ▁ duplicate ▁ item : " , $ arr [ $ i ] ; return ; } }
echo " no ▁ duplicate ▁ found " ; }
$ arr = array ( 1 , 5 , 5 , 6 , 6 , 7 , 9 ) ; $ n = count ( $ arr ) ; dupLastIndex ( $ arr , $ n ) ; ? >
function findSmallest ( $ a , $ n ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ j ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) if ( $ a [ $ j ] % $ a [ $ i ] ) break ;
if ( $ j == $ n ) return $ a [ $ i ] ; } return -1 ; }
$ a = array ( 25 , 20 , 5 , 10 , 100 ) ; $ n = sizeof ( $ a ) ; echo findSmallest ( $ a , $ n ) ; ? >
function findSmallest ( $ a , $ n ) {
$ smallest = min ( $ a ) ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( $ a [ $ i ] % $ smallest ) return -1 ; return $ smallest ; }
$ a = array ( 25 , 20 , 5 , 10 , 100 ) ; $ n = count ( $ a ) ; echo findSmallest ( $ a , $ n ) ; ? >
function findIndex ( $ arr , $ len ) {
$ maxIndex = 0 ; for ( $ i = 0 ; $ i < $ len ; ++ $ i ) if ( $ arr [ $ i ] > $ arr [ $ maxIndex ] ) $ maxIndex = $ i ;
for ( $ i = 0 ; $ i < $ len ; ++ $ i ) if ( $ maxIndex != $ i and $ arr [ $ maxIndex ] < 2 * $ arr [ $ i ] ) return -1 ; return $ maxIndex ; }
$ arr = array ( 3 , 6 , 1 , 0 ) ; $ len = count ( $ arr ) ; echo findIndex ( $ arr , $ len ) ; ? >
function find_consecutive_steps ( $ arr , $ len ) { $ count = 0 ; $ maximum = 0 ; for ( $ index = 1 ; $ index < $ len ; $ index ++ ) {
if ( $ arr [ $ index ] > $ arr [ $ index - 1 ] ) $ count ++ ; else { $ maximum = max ( $ maximum , $ count ) ; $ count = 0 ; } } return max ( $ maximum , $ count ) ; }
$ arr = array ( 1 , 2 , 3 , 4 ) ; $ len = count ( $ arr ) ; echo find_consecutive_steps ( $ arr , $ len ) ; ? >
function CalculateMax ( $ arr , $ n ) {
sort ( $ arr ) ; $ min_sum = $ arr [ 0 ] + $ arr [ 1 ] ; $ max_sum = $ arr [ $ n - 1 ] + $ arr [ $ n - 2 ] ; return abs ( $ max_sum - $ min_sum ) ; }
$ arr = array ( 6 , 7 , 1 , 11 ) ; $ n = sizeof ( $ arr ) ; echo CalculateMax ( $ arr , $ n ) , " STRNEWLINE " ; ? >
function calculate ( $ a , $ n ) {
sort ( $ a ) ;
$ s = array ( ) ; for ( $ i = 0 , $ j = $ n - 1 ; $ i < $ j ; $ i ++ , $ j -- ) array_push ( $ s , ( $ a [ $ i ] + $ a [ $ j ] ) ) ; $ mini = min ( $ s ) ; $ maxi = max ( $ s ) ; return abs ( $ maxi - $ mini ) ; }
$ a = array ( 2 , 6 , 4 , 3 ) ; $ n = sizeof ( $ a ) ; echo calculate ( $ a , $ n ) ; ? >
function printMinDiffPairs ( $ arr , $ n ) { if ( $ n <= 1 ) return ;
sort ( $ arr ) ;
$ minDiff = $ arr [ 1 ] - $ arr [ 0 ] ; for ( $ i = 2 ; $ i < $ n ; $ i ++ ) $ minDiff = min ( $ minDiff , $ arr [ $ i ] - $ arr [ $ i - 1 ] ) ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) if ( ( $ arr [ $ i ] - $ arr [ $ i - 1 ] ) == $ minDiff ) echo " ( " , $ arr [ $ i - 1 ] , " , ▁ " , $ arr [ $ i ] , " ) , ▁ " ; }
$ arr = array ( 5 , 3 , 2 , 4 , 1 ) ; $ n = sizeof ( $ arr ) ; printMinDiffPairs ( $ arr , $ n ) ; ? >
function calculateDiff ( $ i , $ j , $ arr ) {
return abs ( $ arr [ $ i ] - $ arr [ $ j ] ) + abs ( $ i - $ j ) ; }
function maxDistance ( $ arr , $ n ) {
$ result = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = $ i ; $ j < $ n ; $ j ++ ) {
if ( calculateDiff ( $ i , $ j , $ arr ) > $ result ) $ result = calculateDiff ( $ i , $ j , $ arr ) ; } } return $ result ; }
$ arr = array ( -70 , -64 , -6 , -56 , 64 , 61 , -57 , 16 , 48 , -98 ) ; $ n = sizeof ( $ arr ) ; echo maxDistance ( $ arr , $ n ) ; ? >
function maxDistance ( $ arr , $ n ) {
$ max1 = PHP_INT_MIN ; $ min1 = PHP_INT_MAX ; $ max2 = PHP_INT_MIN ; $ min2 = PHP_INT_MAX ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ max1 = max ( $ max1 , $ arr [ $ i ] + $ i ) ; $ min1 = min ( $ min1 , $ arr [ $ i ] + $ i ) ; $ max2 = max ( $ max2 , $ arr [ $ i ] - $ i ) ; $ min2 = min ( $ min2 , $ arr [ $ i ] - $ i ) ; }
return max ( $ max1 - $ min1 , $ max2 - $ min2 ) ; }
$ arr = array ( -70 , -64 , -6 , -56 , 64 , 61 , -57 , 16 , 48 , -98 ) ; $ n = count ( $ arr ) ; echo maxDistance ( $ arr , $ n ) ; ? >
function extrema ( $ a , $ n ) { $ count = 0 ;
for ( $ i = 1 ; $ i < $ n - 1 ; $ i ++ ) {
$ count += ( $ a [ $ i ] > $ a [ $ i - 1 ] and $ a [ $ i ] > $ a [ $ i + 1 ] ) ;
$ count += ( $ a [ $ i ] < $ a [ $ i - 1 ] and $ a [ $ i ] < $ a [ $ i + 1 ] ) ; } return $ count ; }
$ a = array ( 1 , 0 , 2 , 1 ) ; $ n = count ( $ a ) ; echo extrema ( $ a , $ n ) ; ? >
function findClosest ( $ arr , $ n , $ target ) {
if ( $ target <= $ arr [ 0 ] ) return $ arr [ 0 ] ; if ( $ target >= $ arr [ $ n - 1 ] ) return $ arr [ $ n - 1 ] ;
$ i = 0 ; $ j = $ n ; $ mid = 0 ; while ( $ i < $ j ) { $ mid = ( $ i + $ j ) / 2 ; if ( $ arr [ $ mid ] == $ target ) return $ arr [ $ mid ] ;
if ( $ target < $ arr [ $ mid ] ) {
if ( $ mid > 0 && $ target > $ arr [ $ mid - 1 ] ) return getClosest ( $ arr [ $ mid - 1 ] , $ arr [ $ mid ] , $ target ) ;
$ j = $ mid ; }
else { if ( $ mid < $ n - 1 && $ target < $ arr [ $ mid + 1 ] ) return getClosest ( $ arr [ $ mid ] , $ arr [ $ mid + 1 ] , $ target ) ;
$ i = $ mid + 1 ; } }
return $ arr [ $ mid ] ; }
function getClosest ( $ val1 , $ val2 , $ target ) { if ( $ target - $ val1 >= $ val2 - $ target ) return $ val2 ; else return $ val1 ; }
$ arr = array ( 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 ) ; $ n = sizeof ( $ arr ) ; $ target = 11 ; echo ( findClosest ( $ arr , $ n , $ target ) ) ; ? >
function sum ( $ a , $ n ) {
$ maxSum = PHP_INT_MIN ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) $ maxSum = max ( $ maxSum , $ a [ $ i ] + $ a [ $ j ] ) ;
$ c = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) if ( $ a [ $ i ] + $ a [ $ j ] == $ maxSum ) $ c ++ ; return $ c ; }
$ array = array ( 1 , 1 , 1 , 2 , 2 , 2 ) ; $ n = count ( $ array ) ; echo sum ( $ array , $ n ) ; ? >
function sum ( $ a , $ n ) {
$ maxVal = $ a [ 0 ] ; $ maxCount = 1 ; $ secondMax = PHP_INT_MIN ; $ secondMaxCount ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) { if ( $ a [ $ i ] == $ maxVal ) $ maxCount ++ ; else if ( $ a [ $ i ] > $ maxVal ) { $ secondMax = $ maxVal ; $ secondMaxCount = $ maxCount ; $ maxVal = $ a [ $ i ] ; $ maxCount = 1 ; } else if ( $ a [ $ i ] == $ secondMax ) { $ secondMax = $ a [ $ i ] ; $ secondMaxCount ++ ; } else if ( $ a [ $ i ] > $ secondMax ) { $ secondMax = $ a [ $ i ] ; $ secondMaxCount = 1 ; } }
if ( $ maxCount > 1 ) return $ maxCount * ( $ maxCount - 1 ) / 2 ;
return $ secondMaxCount ; }
$ array = array ( 1 , 1 , 1 , 2 , 2 , 2 , 3 ) ; $ n = count ( $ array ) ; echo sum ( $ array , $ n ) ; ? >
function printKMissing ( $ arr , $ n , $ k ) { sort ( $ arr ) ; sort ( $ arr , $ n ) ;
$ i = 0 ; while ( $ i < $ n && $ arr [ $ i ] <= 0 ) $ i ++ ;
$ count = 0 ; $ curr = 1 ; while ( $ count < $ k && $ i < $ n ) { if ( $ arr [ $ i ] != $ curr ) { echo $ curr , " " ; $ count ++ ; } else $ i ++ ; $ curr ++ ; }
while ( $ count < $ k ) { echo $ curr , " " ; $ curr ++ ; $ count ++ ; } }
$ arr = array ( 2 , 3 , 4 ) ; $ n = sizeof ( $ arr ) ; $ k = 3 ; printKMissing ( $ arr , $ n , $ k ) ; ? >
function nobleInteger ( $ arr , $ size ) { for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { $ count = 0 ; for ( $ j = 0 ; $ j < $ size ; $ j ++ ) if ( $ arr [ $ i ] < $ arr [ $ j ] ) $ count ++ ;
if ( $ count == $ arr [ $ i ] ) return $ arr [ $ i ] ; } return -1 ; }
$ arr = array ( 10 , 3 , 20 , 40 , 2 ) ; $ size = count ( $ arr ) ; $ res = nobleInteger ( $ arr , $ size ) ; if ( $ res != -1 ) echo " The ▁ noble ▁ integer ▁ is ▁ " , $ res ; else echo " No ▁ Noble ▁ Integer ▁ Found " ; ? >
function nobleInteger ( $ arr ) { sort ( $ arr ) ;
$ n = count ( $ arr ) ; for ( $ i = 0 ; $ i < $ n - 1 ; $ i ++ ) { if ( $ arr [ $ i ] == $ arr [ $ i + 1 ] ) continue ;
if ( $ arr [ $ i ] == $ n - $ i - 1 ) return $ arr [ $ i ] ; } if ( $ arr [ $ n - 1 ] == 0 ) return $ arr [ $ n - 1 ] ; return -1 ; }
$ arr = array ( 10 , 3 , 20 , 40 , 2 ) ; $ res = nobleInteger ( $ arr ) ; if ( $ res != -1 ) echo " The ▁ noble ▁ integer ▁ is ▁ " , $ res ; else echo " No ▁ Noble ▁ Integer ▁ Found " ; ? >
function findMinSum ( $ a , $ b , $ n ) {
sort ( $ a ) ; sort ( $ a , $ n ) ; sort ( $ b ) ; sort ( $ b , $ n ) ;
$ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ sum = $ sum + abs ( $ a [ $ i ] - $ b [ $ i ] ) ; return $ sum ; }
$ a = array ( 4 , 1 , 8 , 7 ) ; $ b = array ( 2 , 3 , 6 , 5 ) ; $ n = sizeof ( $ a ) ; echo ( findMinSum ( $ a , $ b , $ n ) ) ; ? >
function checkIsAP ( $ arr , $ n ) { if ( $ n == 1 ) return true ;
sort ( $ arr ) ;
$ d = $ arr [ 1 ] - $ arr [ 0 ] ; for ( $ i = 2 ; $ i < $ n ; $ i ++ ) if ( $ arr [ $ i ] - $ arr [ $ i - 1 ] != $ d ) return false ; return true ; }
$ arr = array ( 20 , 15 , 5 , 0 , 10 ) ; $ n = count ( $ arr ) ; if ( checkIsAP ( $ arr , $ n ) ) echo " Yes " ; else echo " No " ; ? >
function minProductSubset ( $ a , $ n ) { if ( $ n == 1 ) return $ a [ 0 ] ;
$ max_neg = PHP_INT_MIN ; $ min_pos = PHP_INT_MAX ; $ count_neg = 0 ; $ count_zero = 0 ; $ prod = 1 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
if ( $ a [ $ i ] == 0 ) { $ count_zero ++ ; continue ; }
if ( $ a [ $ i ] < 0 ) { $ count_neg ++ ; $ max_neg = max ( $ max_neg , $ a [ $ i ] ) ; }
if ( $ a [ $ i ] > 0 ) $ min_pos = min ( $ min_pos , $ a [ $ i ] ) ; $ prod = $ prod * $ a [ $ i ] ; }
if ( $ count_zero == $ n || ( $ count_neg == 0 && $ count_zero > 0 ) ) return 0 ;
if ( $ count_neg == 0 ) return $ min_pos ;
if ( ! ( $ count_neg & 1 ) && $ count_neg != 0 ) {
$ prod = $ prod / $ max_neg ; } return $ prod ; }
$ a = array ( -1 , -1 , -2 , 4 , 3 ) ; $ n = sizeof ( $ a ) ; echo ( minProductSubset ( $ a , $ n ) ) ; ? >
function countPairs ( $ a , $ n ) {
$ mn = PHP_INT_MAX ; $ mx = PHP_INT_MIN ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ mn = min ( $ mn , $ a [ $ i ] ) ; $ mx = max ( $ mx , $ a [ $ i ] ) ; }
$ c1 = 0 ;
$ c2 = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ a [ $ i ] == $ mn ) $ c1 ++ ; if ( $ a [ $ i ] == $ mx ) $ c2 ++ ; }
if ( $ mn == $ mx ) return $ n * ( $ n - 1 ) / 2 ; else return $ c1 * $ c2 ; }
$ a = array ( 3 , 2 , 1 , 1 , 3 ) ; $ n = count ( $ a ) ; echo countPairs ( $ a , $ n ) ; ? >
function binary_search ( $ a , $ x , $ lo = 0 , $ hi = NULL ) { if ( $ hi == NULL ) $ hi = count ( $ a ) ; while ( $ lo < $ hi ) { $ mid = ( $ lo + $ hi ) / 2 ; $ midval = $ a [ $ mid ] ; if ( $ midval < $ x ) $ lo = $ mid + 1 ; else if ( $ midval > $ x ) $ hi = $ mid ; else return $ mid ; } return -1 ; } function findElement ( $ a , $ n , $ b ) {
sort ( $ a ) ;
$ mx = $ a [ $ n - 1 ] ; while ( $ b < max ( $ a ) ) {
if ( binary_search ( $ a , $ b , 0 , $ n ) != -1 ) $ b *= 2 ; else return $ b ; } return $ b ; }
$ a = array ( 1 , 2 , 3 ) ; $ n = count ( $ a ) ; $ b = 1 ; echo findElement ( $ a , $ n , $ b ) ; ? >
$ Mod = 1000000007 ;
function findSum ( & $ arr , $ n ) { global $ Mod ; $ sum = 0 ;
sort ( $ arr ) ;
$ i = 0 ; while ( $ i < $ n && $ arr [ $ i ] < 0 ) { if ( $ i != $ n - 1 && $ arr [ $ i + 1 ] <= 0 ) { $ sum = ( $ sum + ( $ arr [ $ i ] * $ arr [ $ i + 1 ] ) % $ Mod ) % $ Mod ; $ i += 2 ; } else break ; }
$ j = $ n - 1 ; while ( $ j >= 0 && $ arr [ $ j ] > 0 ) { if ( $ j != 0 && $ arr [ $ j - 1 ] > 0 ) { $ sum = ( $ sum + ( $ arr [ $ j ] * $ arr [ $ j - 1 ] ) % $ Mod ) % $ Mod ; $ j -= 2 ; } else break ; }
if ( $ j > $ i ) $ sum = ( $ sum + ( $ arr [ $ i ] * $ arr [ $ j ] ) % $ Mod ) % $ Mod ;
else if ( $ i == $ j ) $ sum = ( $ sum + $ arr [ $ i ] ) % Mod ; return $ sum ; }
$ arr = array ( -1 , 9 , 4 , 5 , -4 , 7 ) ; $ n = sizeof ( $ arr ) ; echo findSum ( $ arr , $ n ) ; ? >
function countOddRotations ( $ n ) { $ odd_count = 0 ; $ even_count = 0 ; do { $ digit = $ n % 10 ; if ( $ digit % 2 == 1 ) $ odd_count ++ ; else $ even_count ++ ; $ n = ( int ) ( $ n / 10 ) ; } while ( $ n != 0 ) ; echo " Odd = " , ▁ $ odd _ count , ▁ " " ; STRNEWLINE echo ▁ " Even = " , ▁ $ even _ count , ▁ " " }
$ n = 1234 ; countOddRotations ( $ n ) ; ? >
function numberOfDigits ( $ n ) { $ cnt = 0 ; while ( $ n > 0 ) { $ cnt ++ ; $ n = floor ( $ n / 10 ) ; } return $ cnt ; }
function cal ( $ num ) { $ digits = numberOfDigits ( $ num ) ; $ powTen = pow ( 10 , $ digits - 1 ) ; for ( $ i = 0 ; $ i < $ digits - 1 ; $ i ++ ) { $ firstDigit = floor ( $ num / $ powTen ) ;
$ left = ( ( $ num * 10 ) + $ firstDigit ) - ( $ firstDigit * $ powTen * 10 ) ; echo $ left , " " ;
$ num = $ left ; } }
$ num = 1445 ; cal ( $ num ) ; ? >
function CheckKCycles ( $ n , $ s ) { $ ff = true ; $ x = 0 ; for ( $ i = 1 ; $ i < $ n ; $ i ++ ) {
$ x = strlen ( substr ( $ s , $ i ) . substr ( $ s , 0 , $ i ) ) ;
if ( $ x >= strlen ( $ s ) ) { continue ; } $ ff = false ; break ; } if ( $ ff ) { print ( " Yes " ) ; } else { print ( " No " ) ; } }
$ n = 3 ; $ s = "123" ; CheckKCycles ( $ n , $ s ) ; ? >
function rightRotationDivisor ( $ N ) { $ lastDigit = $ N % 10 ; $ rightRotation = ( $ lastDigit * pow ( 10 , ( int ) ( log10 ( $ N ) ) ) ) + floor ( $ N / 10 ) ; return ( $ rightRotation % $ N == 0 ) ; }
function generateNumbers ( $ m ) { for ( $ i = pow ( 10 , ( $ m - 1 ) ) ; $ i < pow ( 10 , $ m ) ; $ i ++ ) if ( rightRotationDivisor ( $ i ) ) echo $ i . " STRNEWLINE " ; }
$ m = 3 ; generateNumbers ( $ m ) ; ? >
function checkIfSortRotated ( $ arr , $ n ) { $ minEle = PHP_INT_MAX ; $ maxEle = PHP_INT_MIN ; $ minIndex = -1 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] < $ minEle ) { $ minEle = $ arr [ $ i ] ; $ minIndex = $ i ; } } $ flag1 = 1 ;
for ( $ i = 1 ; $ i < $ minIndex ; $ i ++ ) { if ( $ arr [ $ i ] < $ arr [ $ i - 1 ] ) { $ flag1 = 0 ; break ; } } $ flag2 = 1 ;
for ( $ i = $ minIndex + 1 ; $ i < $ n ; $ i ++ ) { if ( $ arr [ $ i ] < $ arr [ $ i - 1 ] ) { $ flag2 = 0 ; break ; } }
if ( $ flag1 && $ flag2 && ( $ arr [ $ n - 1 ] < $ arr [ $ 0 ] ) ) echo ( " YES " ) ; else echo ( " NO " ) ; }
$ arr = array ( 3 , 4 , 5 , 1 , 2 ) ;
$ n = count ( $ arr ) ; checkIfSortRotated ( $ arr , $ n ) ; ? >
function occurredOnce ( & $ arr , $ n ) {
sort ( $ arr ) ;
if ( $ arr [ 0 ] != $ arr [ 1 ] ) echo $ arr [ 0 ] . " ▁ " ;
for ( $ i = 1 ; $ i < $ n - 1 ; $ i ++ ) if ( $ arr [ $ i ] != $ arr [ $ i + 1 ] && $ arr [ $ i ] != $ arr [ $ i - 1 ] ) echo $ arr [ $ i ] . " ▁ " ;
if ( $ arr [ $ n - 2 ] != $ arr [ $ n - 1 ] ) echo $ arr [ $ n - 1 ] . " ▁ " ; }
$ arr = array ( 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ) ; $ n = sizeof ( $ arr ) ; occurredOnce ( $ arr , $ n ) ; ? >
function occurredOnce ( & $ arr , $ n ) { $ i = 1 ; $ len = $ n ;
if ( $ arr [ 0 ] == $ arr [ $ len - 1 ] ) { $ i = 2 ; $ len -- ; }
for ( ; $ i < $ n ; $ i ++ )
if ( $ arr [ $ i ] == $ arr [ $ i - 1 ] ) $ i ++ ;
else echo $ arr [ $ i - 1 ] . " " ;
if ( $ arr [ $ n - 1 ] != $ arr [ 0 ] && $ arr [ $ n - 1 ] != $ arr [ $ n - 2 ] ) echo $ arr [ $ n - 1 ] ; }
$ arr = array ( 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ) ; $ n = sizeof ( $ arr ) ; occurredOnce ( $ arr , $ n ) ; ? >
function rvereseArray ( & $ arr , $ start , $ end ) { while ( $ start < $ end ) { $ temp = $ arr [ $ start ] ; $ arr [ $ start ] = $ arr [ $ end ] ; $ arr [ $ end ] = $ temp ; $ start ++ ; $ end -- ; } }
function printArray ( & $ arr , $ size ) { for ( $ i = 0 ; $ i < $ size ; $ i ++ ) echo $ arr [ $ i ] . " ▁ " ; }
function splitArr ( & $ arr , $ k , $ n ) { rvereseArray ( $ arr , 0 , $ n - 1 ) ; rvereseArray ( $ arr , 0 , $ n - $ k - 1 ) ; rvereseArray ( $ arr , $ n - $ k , $ n - 1 ) ; }
$ arr = array ( 12 , 10 , 5 , 6 , 52 , 36 ) ; $ n = sizeof ( $ arr ) ; $ k = 2 ;
splitArr ( $ arr , $ k , $ n ) ; printArray ( $ arr , $ n ) ; ? >
function countRotationsDivBy8 ( $ n ) { $ len = strlen ( $ n ) ; $ count = 0 ;
if ( $ len == 1 ) { $ oneDigit = $ n [ 0 ] - '0' ; if ( $ oneDigit % 8 == 0 ) return 1 ; return 0 ; }
if ( $ len == 2 ) {
$ first = ( $ n [ 0 ] - '0' ) * 10 + ( $ n [ 1 ] - '0' ) ;
$ second = ( $ n [ 1 ] - '0' ) * 10 + ( $ n [ 0 ] - '0' ) ; if ( $ first % 8 == 0 ) $ count ++ ; if ( $ second % 8 == 0 ) $ count ++ ; return $ count ; }
$ threeDigit ; for ( $ i = 0 ; $ i < ( $ len - 2 ) ; $ i ++ ) { $ threeDigit = ( $ n [ $ i ] - '0' ) * 100 + ( $ n [ $ i + 1 ] - '0' ) * 10 + ( $ n [ $ i + 2 ] - '0' ) ; if ( $ threeDigit % 8 == 0 ) $ count ++ ; }
$ threeDigit = ( $ n [ $ len - 1 ] - '0' ) * 100 + ( $ n [ 0 ] - '0' ) * 10 + ( $ n [ 1 ] - '0' ) ; if ( $ threeDigit % 8 == 0 ) $ count ++ ;
$ threeDigit = ( $ n [ $ len - 2 ] - '0' ) * 100 + ( $ n [ $ len - 1 ] - '0' ) * 10 + ( $ n [ 0 ] - '0' ) ; if ( $ threeDigit % 8 == 0 ) $ count ++ ;
return $ count ; }
$ n = "43262488612" ; echo " Rotations : ▁ " . countRotationsDivBy8 ( $ n ) ; ? >
function findRotations ( $ str ) {
$ tmp = ( $ str + $ str ) ; $ n = strlen ( $ str ) ; for ( $ i = 1 ; $ i <= $ n ; $ i ++ ) {
$ substring = $ tmp . substr ( $ i , strlen ( $ str ) ) ;
if ( $ str == $ substring ) return $ i ; } return $ n ; }
$ str = " abc " ; echo findRotations ( $ str ) , " STRNEWLINE " ; ? >
function isRotation ( $ x , $ y ) {
$ x64 = $ x | ( $ x << 32 ) ; while ( $ x64 >= $ y ) {
if ( ( $ x64 ) == $ y ) return 1 ;
$ x64 >>= 1 ; } return -1 ; }
$ x = 122 ; $ y = 2147483678 ; if ( isRotation ( $ x , $ y ) ) echo " yes " , " STRNEWLINE " ; else echo " no " , " STRNEWLINE " ; ? >
function countRotations ( $ n ) { $ len = strlen ( $ n ) ;
if ( $ len == 1 ) { $ oneDigit = $ n [ 0 ] - '0' ; if ( $ oneDigit % 4 == 0 ) return 1 ; return 0 ; }
$ twoDigit ; $ count = 0 ; for ( $ i = 0 ; $ i < ( $ len - 1 ) ; $ i ++ ) { $ twoDigit = ( $ n [ $ i ] - '0' ) * 10 + ( $ n [ $ i + 1 ] - '0' ) ; if ( $ twoDigit % 4 == 0 ) $ count ++ ; }
$ twoDigit = ( $ n [ $ len - 1 ] - '0' ) * 10 + ( $ n [ 0 ] - '0' ) ; if ( $ twoDigit % 4 == 0 ) $ count ++ ; return $ count ; }
$ n = "4834" ; echo " Rotations : ▁ " , countRotations ( $ n ) ; ? >
function solve ( $ A , $ n ) { $ i = 0 ; $ cnt = 0 ; $ j = 0 ;
$ parent = array ( ) ;
$ vis = array ( ) ;
for ( $ i = 0 ; $ i < $ n + 1 ; $ i ++ ) { $ parent [ $ i ] = -1 ; $ vis [ $ i ] = 0 ; } for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ j = $ i ;
if ( $ parent [ $ j ] == -1 ) {
while ( $ parent [ $ j ] == -1 ) { $ parent [ $ j ] = $ i ; $ j = ( $ j + $ A [ $ j ] + 1 ) % $ n ; }
if ( $ parent [ $ j ] == $ i ) {
while ( $ vis [ $ j ] == 0 ) { $ vis [ $ j ] = 1 ; $ cnt ++ ; $ j = ( $ j + $ A [ $ j ] + 1 ) % $ n ; } } } } return $ cnt ; }
$ A = array ( 0 , 0 , 0 , 2 ) ; $ n = count ( $ A ) ; echo ( solve ( $ A , $ n ) ) ; ? >
function TOWUtil ( & $ arr , $ n , & $ curr_elements , $ no_of_selected_elements , & $ soln , & $ min_diff , $ sum , $ curr_sum , $ curr_position ) {
if ( $ curr_position == $ n ) return ;
if ( ( intval ( $ n / 2 ) - $ no_of_selected_elements ) > ( $ n - $ curr_position ) ) return ;
TOWUtil ( $ arr , $ n , $ curr_elements , $ no_of_selected_elements , $ soln , $ min_diff , $ sum , $ curr_sum , $ curr_position + 1 ) ;
$ no_of_selected_elements ++ ; $ curr_sum = ( $ curr_sum + $ arr [ $ curr_position ] ) ; $ curr_elements [ $ curr_position ] = true ;
if ( $ no_of_selected_elements == intval ( $ n / 2 ) ) {
if ( abs ( intval ( $ sum / 2 ) - $ curr_sum ) < $ min_diff ) { $ min_diff = abs ( intval ( $ sum / 2 ) - $ curr_sum ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ soln [ $ i ] = $ curr_elements [ $ i ] ; } } else {
TOWUtil ( $ arr , $ n , $ curr_elements , $ no_of_selected_elements , $ soln , $ min_diff , $ sum , $ curr_sum , $ curr_position + 1 ) ; }
$ curr_elements [ $ curr_position ] = false ; }
function tugOfWar ( & $ arr , $ n ) {
$ curr_elements = array_fill ( 0 , $ n , 0 ) ;
$ soln = array_fill ( 0 , $ n , 0 ) ; $ min_diff = PHP_INT_MAX ; $ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ sum += $ arr [ $ i ] ; $ curr_elements [ $ i ] = $ soln [ $ i ] = false ; }
TOWUtil ( $ arr , $ n , $ curr_elements , 0 , $ soln , $ min_diff , $ sum , 0 , 0 ) ;
echo " The ▁ first ▁ subset ▁ is : ▁ " ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ soln [ $ i ] == true ) echo $ arr [ $ i ] . " ▁ " ; } echo " The second subset is : " for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ soln [ $ i ] == false ) echo $ arr [ $ i ] . " ▁ " ; } }
$ arr = array ( 23 , 45 , -34 , 12 , 0 , 98 , -99 , 4 , 189 , -1 , 4 ) ; $ n = count ( $ arr ) ; tugOfWar ( $ arr , $ n ) ; ? >
$ INF = PHP_INT_MAX ; $ N = 4 ;
function minCost ( $ cost ) { global $ INF ; global $ N ;
$ dist [ $ N ] = array ( ) ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) $ dist [ $ i ] = $ INF ; $ dist [ 0 ] = 0 ;
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ N ; $ j ++ ) if ( $ dist [ $ j ] > $ dist [ $ i ] + $ cost [ $ i ] [ $ j ] ) $ dist [ $ j ] = $ dist [ $ i ] + $ cost [ $ i ] [ $ j ] ; return $ dist [ $ N - 1 ] ; }
$ cost = array ( array ( 0 , 15 , 80 , 90 ) , array ( INF , 0 , 40 , 50 ) , array ( INF , INF , 0 , 70 ) , array ( INF , INF , INF , 0 ) ) ; echo " The ▁ Minimum ▁ cost ▁ to ▁ reach ▁ station ▁ " , $ N , " ▁ is ▁ " , minCost ( $ cost ) ; ? >
function numOfways ( $ n , $ k ) { $ p = 1 ; if ( $ k % 2 ) $ p = -1 ; return ( pow ( $ n - 1 , $ k ) + $ p * ( $ n - 1 ) ) / $ n ; }
$ n = 4 ; $ k = 2 ; echo numOfways ( $ n , $ k ) ; ? >
{
function power ( $ n ) { if ( $ n == 1 ) return 2 ; return 2 * power ( $ n - 1 ) ; }
{ $ n = 4 ; echo ( power ( $ n ) ) ; } } ? >
$ size = 4 ;
function checkStar ( $ mat ) { global $ size ;
$ vertexD1 = 0 ; $ vertexDn_1 = 0 ;
if ( $ size == 1 ) return ( $ mat [ 0 ] [ 0 ] == 0 ) ;
if ( $ size == 2 ) return ( $ mat [ 0 ] [ 0 ] == 0 && $ mat [ 0 ] [ 1 ] == 1 && $ mat [ 1 ] [ 0 ] == 1 && $ mat [ 1 ] [ 1 ] == 0 ) ;
for ( $ i = 0 ; $ i < $ size ; $ i ++ ) { $ degreeI = 0 ; for ( $ j = 0 ; $ j < $ size ; $ j ++ ) if ( $ mat [ $ i ] [ $ j ] ) $ degreeI ++ ; if ( $ degreeI == 1 ) $ vertexD1 ++ ; else if ( $ degreeI == $ size - 1 ) $ vertexDn_1 ++ ; } return ( $ vertexD1 == ( $ size - 1 ) && $ vertexDn_1 == 1 ) ; }
$ mat = array ( array ( 0 , 1 , 1 , 1 ) , array ( 1 , 0 , 0 , 0 ) , array ( 1 , 0 , 0 , 0 ) , array ( 1 , 0 , 0 , 0 ) ) ; if ( checkStar ( $ mat ) ) echo ( " Star ▁ Graph " ) ; else echo ( " Not ▁ a ▁ Star ▁ Graph " ) ; ? >
function fib ( $ n ) { if ( $ n <= 1 ) return $ n ; return fib ( $ n - 1 ) + fib ( $ n - 2 ) ; }
function findVertices ( $ n ) {
return fib ( $ n + 2 ) ; }
$ n = 3 ; echo findVertices ( $ n ) ; ? >
function check ( & $ degree , $ n ) {
$ deg_sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ deg_sum += $ degree [ $ i ] ;
return ( 2 * ( $ n - 1 ) == $ deg_sum ) ; }
$ n = 5 ; $ degree = array ( 2 , 3 , 1 , 1 , 1 ) ; if ( check ( $ degree , $ n ) ) echo " Tree " ; else echo " Graph " ; ? >
function isInorder ( $ arr , $ n ) {
if ( $ n == 0 $ n == 1 ) return true ; for ( $ i = 1 ; $ i < $ n ; $ i ++ )
if ( $ arr [ $ i - 1 ] > $ arr [ $ i ] ) return false ;
return true ; }
$ arr = array ( 19 , 23 , 25 , 30 , 45 ) ; $ n = sizeof ( $ arr ) ; if ( isInorder ( $ arr , $ n ) ) echo " Yes " ; else echo " No " ; ? >
function isLeaf ( $ pre , & $ i , $ n , $ min , $ max ) { if ( $ i >= $ n ) return false ; if ( $ pre [ $ i ] > $ min && $ pre [ $ i ] < $ max ) { $ i ++ ; $ left = isLeaf ( $ pre , $ i , $ n , $ min , $ pre [ $ i - 1 ] ) ; $ right = isLeaf ( $ pre , $ i , $ n , $ pre [ $ i - 1 ] , $ max ) ; if ( ! $ left && ! $ right ) echo $ pre [ $ i - 1 ] , " ▁ " ; return true ; } return false ; } function printLeaves ( $ preorder , $ n ) { $ i = 0 ; isLeaf ( $ preorder , $ i , $ n , PHP_INT_MIN , PHP_INT_MAX ) ; }
$ preorder = array ( 890 , 325 , 290 , 530 , 965 ) ; $ n = sizeof ( $ preorder ) ; printLeaves ( $ preorder , $ n ) ; ? >
function pairs ( $ arr , $ n , $ k ) {
$ smallest = PHP_INT_MAX ; $ count = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) {
if ( abs ( $ arr [ $ i ] + $ arr [ $ j ] - $ k ) < $ smallest ) { $ smallest = abs ( $ arr [ $ i ] + $ arr [ $ j ] - $ k ) ; $ count = 1 ; }
else if ( abs ( $ arr [ $ i ] + $ arr [ $ j ] - $ k ) == $ smallest ) $ count ++ ; }
echo " Minimal Value = " ▁ , ▁ $ smallest ▁ , ▁ " " ; STRNEWLINE echo ▁ " Total Pairs = " , ▁ $ count ▁ , ▁ " " }
$ arr = array ( 3 , 5 , 7 , 5 , 1 , 9 , 9 ) ; $ k = 12 ; $ n = sizeof ( $ arr ) ; pairs ( $ arr , $ n , $ k ) ; ? >
$ a = array ( 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 ) ; $ key = 20 ; $ arraySize = sizeof ( $ a ) ; $ count = 0 ; for ( $ i = 0 ; $ i < $ arraySize ; $ i ++ ) { if ( $ a [ $ i ] <= $ key ) { $ count += 1 ; } } echo " Rank ▁ of ▁ " . $ key . " ▁ in ▁ stream ▁ is : ▁ " . ( $ count - 1 ) . " STRNEWLINE " ; ? >
$ MAX_SIZE = 10 ;
function sortByRow ( & $ mat , $ n , $ ascending ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { if ( $ ascending ) sort ( $ mat [ $ i ] ) ; else rsort ( $ mat [ $ i ] ) ; } }
function transpose ( & $ mat , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) {
$ temp = $ mat [ $ i ] [ $ j ] ; $ mat [ $ i ] [ $ j ] = $ mat [ $ j ] [ $ i ] ; $ mat [ $ j ] [ $ i ] = $ temp ; } } }
function sortMatRowAndColWise ( & $ mat , $ n ) {
sortByRow ( $ mat , $ n , true ) ;
transpose ( $ mat , $ n ) ;
sortByRow ( $ mat , $ n , false ) ;
transpose ( $ mat , $ n ) ; }
function printMat ( & $ mat , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) echo $ mat [ $ i ] [ $ j ] . " ▁ " ; echo " STRNEWLINE " ; } }
$ n = 3 ; $ mat = array ( array ( 3 , 2 , 1 ) , array ( 9 , 8 , 7 ) , array ( 6 , 5 , 4 ) ) ; echo " Original ▁ Matrix : STRNEWLINE " ; printMat ( $ mat , $ n ) ; sortMatRowAndColWise ( $ mat , $ n ) ; echo " Matrix After Sorting : " ; printMat ( $ mat , $ n ) ; ? >
function middlesum ( $ mat , $ n ) { $ row_sum = 0 ; $ col_sum = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ row_sum += $ mat [ $ n / 2 ] [ $ i ] ; echo " Sum ▁ of ▁ middle ▁ row ▁ = ▁ " , $ row_sum , " STRNEWLINE " ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ col_sum += $ mat [ $ i ] [ $ n / 2 ] ; echo " Sum ▁ of ▁ middle ▁ column ▁ = ▁ " , $ col_sum ; }
$ mat = array ( array ( 2 , 5 , 7 ) , array ( 3 , 7 , 2 ) , array ( 5 , 6 , 9 ) ) ; middlesum ( $ mat , 3 ) ; ? >
$ M = 3 ; $ N = 3 ;
function rotateMatrix ( & $ matrix , $ k ) { global $ M , $ N ;
$ temp = array ( ) ;
$ k = $ k % $ M ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) {
for ( $ t = 0 ; $ t < $ M - $ k ; $ t ++ ) $ temp [ $ t ] = $ matrix [ $ i ] [ $ t ] ;
for ( $ j = $ M - $ k ; $ j < $ M ; $ j ++ ) $ matrix [ $ i ] [ $ j - $ M + $ k ] = $ matrix [ $ i ] [ $ j ] ;
for ( $ j = $ k ; $ j < $ M ; $ j ++ ) $ matrix [ $ i ] [ $ j ] = $ temp [ $ j - $ k ] ; } }
function displayMatrix ( & $ matrix ) { global $ M , $ N ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { for ( $ j = 0 ; $ j < $ M ; $ j ++ ) echo ( $ matrix [ $ i ] [ $ j ] . " ▁ " ) ; echo ( " STRNEWLINE " ) ; } }
$ matrix = array ( array ( 12 , 23 , 34 ) , array ( 45 , 56 , 67 ) , array ( 78 , 89 , 91 ) ) ; $ k = 2 ;
rotateMatrix ( $ matrix , $ k ) ;
displayMatrix ( $ matrix ) ; ? >
$ N = 3 ;
function multiply ( $ mat , $ res ) { global $ N ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { for ( $ j = 0 ; $ j < $ N ; $ j ++ ) { $ res [ $ i ] [ $ j ] = 0 ; for ( $ k = 0 ; $ k < $ N ; $ k ++ ) $ res [ $ i ] [ $ j ] += $ mat [ $ i ] [ $ k ] * $ mat [ $ k ] [ $ j ] ; } } return $ res ; }
function InvolutoryMatrix ( $ mat ) { global $ N ; $ res ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ N ; $ j ++ ) $ res [ $ i ] [ $ j ] = 0 ;
$ res = multiply ( $ mat , $ res ) ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { for ( $ j = 0 ; $ j < $ N ; $ j ++ ) { if ( $ i == $ j && $ res [ $ i ] [ $ j ] != 1 ) return false ; if ( $ i != $ j && $ res [ $ i ] [ $ j ] != 0 ) return false ; } } return true ; }
$ mat = array ( array ( 1 , 0 , 0 ) , array ( 0 , -1 , 0 ) , array ( 0 , 0 , -1 ) ) ;
if ( InvolutoryMatrix ( $ mat ) ) echo " Involutory ▁ Matrix " ; else echo " Not ▁ Involutory ▁ Matrix " ; ? >
$ n = 4 ; function interchangeFirstLast ( & $ m ) { global $ n ; $ rows = $ n ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ t = $ m [ 0 ] [ $ i ] ; $ m [ 0 ] [ $ i ] = $ m [ $ rows - 1 ] [ $ i ] ; $ m [ $ rows - 1 ] [ $ i ] = $ t ; } }
$ m = array ( array ( 8 , 9 , 7 , 6 ) , array ( 4 , 7 , 6 , 5 ) , array ( 3 , 2 , 1 , 8 ) , array ( 9 , 9 , 7 , 7 ) ) ; interchangeFirstLast ( $ m ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) echo $ m [ $ i ] [ $ j ] . " ▁ " ; echo " STRNEWLINE " ; } ? >
function checkMarkov ( $ m ) { $ n = 3 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
$ sum = 0 ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ sum = $ sum + $ m [ $ i ] [ $ j ] ; if ( $ sum != 1 ) return false ; } return true ; }
$ m = array ( array ( 0 , 0 , 1 ) , array ( 0.5 , 0 , 0.5 ) , array ( 1 , 0 , 0 ) ) ;
if ( checkMarkov ( $ m ) ) echo " ▁ yes ▁ " ; else echo " ▁ no ▁ " ; ? >
$ N = 4 ;
function isDiagonalMatrix ( $ mat ) { global $ N ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ N ; $ j ++ )
if ( ( $ i != $ j ) && ( $ mat [ $ i ] [ $ j ] != 0 ) ) return false ; return true ; }
$ mat = array ( array ( 4 , 0 , 0 , 0 ) , array ( 0 , 7 , 0 , 0 ) , array ( 0 , 0 , 5 , 0 ) , array ( 0 , 0 , 0 , 1 ) ) ; if ( isDiagonalMatrix ( $ mat ) ) echo " Yes " , " STRNEWLINE " ; else echo " No " , " STRNEWLINE " ; ? >
$ N = 4 ;
function isScalarMatrix ( $ mat ) { global $ N ;
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ N ; $ j ++ ) if ( ( $ i != $ j ) && ( $ mat [ $ i ] [ $ j ] != 0 ) ) return false ;
for ( $ i = 0 ; $ i < $ N - 1 ; $ i ++ ) if ( $ mat [ $ i ] [ $ i ] != $ mat [ $ i + 1 ] [ $ i + 1 ] ) return false ; return true ; }
$ mat = array ( array ( 2 , 0 , 0 , 0 ) , array ( 0 , 2 , 0 , 0 ) , array ( 0 , 0 , 2 , 0 ) , array ( 0 , 0 , 0 , 2 ) ) ;
if ( isScalarMatrix ( $ mat ) ) echo " Yes " ; else echo " No " ; ? >
$ MAX_SIZE = 10 ;
function sortByRow ( & $ mat , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ )
sort ( $ mat [ $ i ] ) ; }
function transpose ( & $ mat , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = $ i + 1 ; $ j < $ n ; $ j ++ ) {
$ t = $ mat [ $ i ] [ $ j ] ; $ mat [ $ i ] [ $ j ] = $ mat [ $ j ] [ $ i ] ; $ mat [ $ j ] [ $ i ] = $ t ; } } }
function sortMatRowAndColWise ( & $ mat , $ n ) {
sortByRow ( $ mat , $ n ) ;
transpose ( $ mat , $ n ) ;
sortByRow ( $ mat , $ n ) ;
transpose ( $ mat , $ n ) ; }
function printMat ( & $ mat , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) echo $ mat [ $ i ] [ $ j ] . " ▁ " ; echo " STRNEWLINE " ; } }
$ mat = array ( array ( 4 , 1 , 3 ) , array ( 9 , 6 , 8 ) , array ( 5 , 2 , 7 ) ) ; $ n = 3 ; echo " Original ▁ Matrix : STRNEWLINE " ; printMat ( $ mat , $ n ) ; sortMatRowAndColWise ( $ mat , $ n ) ; echo " Matrix After Sorting : " ; printMat ( $ mat , $ n ) ; ? >
function doublyEven ( $ n ) { $ arr = array_fill ( 0 , $ n , array_fill ( 0 , $ n , 0 ) ) ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ arr [ $ i ] [ $ j ] = ( $ n * $ i ) + $ j + 1 ;
for ( $ i = 0 ; $ i < $ n / 4 ; $ i ++ ) for ( $ j = 0 ; $ j < $ n / 4 ; $ j ++ ) $ arr [ $ i ] [ $ j ] = ( $ n * $ n + 1 ) - $ arr [ $ i ] [ $ j ] ;
for ( $ i = 0 ; $ i < $ n / 4 ; $ i ++ ) for ( $ j = 3 * ( $ n / 4 ) ; $ j < $ n ; $ j ++ ) $ arr [ $ i ] [ $ j ] = ( $ n * $ n + 1 ) - $ arr [ $ i ] [ $ j ] ;
for ( $ i = 3 * $ n / 4 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ n / 4 ; $ j ++ ) $ arr [ $ i ] [ $ j ] = ( $ n * $ n + 1 ) - $ arr [ $ i ] [ $ j ] ;
for ( $ i = 3 * $ n / 4 ; $ i < $ n ; $ i ++ ) for ( $ j = 3 * $ n / 4 ; $ j < $ n ; $ j ++ ) $ arr [ $ i ] [ $ j ] = ( $ n * $ n + 1 ) - $ arr [ $ i ] [ $ j ] ;
for ( $ i = $ n / 4 ; $ i < 3 * $ n / 4 ; $ i ++ ) for ( $ j = $ n / 4 ; $ j < 3 * $ n / 4 ; $ j ++ ) $ arr [ $ i ] [ $ j ] = ( $ n * $ n + 1 ) - $ arr [ $ i ] [ $ j ] ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) echo $ arr [ $ i ] [ $ j ] . " ▁ " ; echo " STRNEWLINE " ; } }
$ n = 8 ;
doublyEven ( $ n ) ; ? >
function isMagicSquare ( $ mat ) {
$ sum = 0 ; $ N = 3 ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) $ sum = $ sum + $ mat [ $ i ] [ $ i ] ;
$ sum2 = 0 ; $ N = 3 ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) $ sum2 = $ sum2 + $ mat [ $ i ] [ $ N - $ i - 1 ] ; if ( $ sum != $ sum2 ) return false ;
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { $ rowSum = 0 ; for ( $ j = 0 ; $ j < $ N ; $ j ++ ) $ rowSum += $ mat [ $ i ] [ $ j ] ;
if ( $ rowSum != $ sum ) return false ; }
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { $ colSum = 0 ; for ( $ j = 0 ; $ j < $ N ; $ j ++ ) $ colSum += $ mat [ $ j ] [ $ i ] ;
if ( $ sum != $ colSum ) return false ; } return true ; }
{ $ mat = array ( array ( 2 , 7 , 6 ) , array ( 9 , 5 , 1 ) , array ( 4 , 3 , 8 ) ) ; if ( isMagicSquare ( $ mat ) ) echo " Magic ▁ Square " ; else echo " Not ▁ a ▁ magic ▁ Square " ; return 0 ; } ? >
function subCount ( $ arr , $ n , $ k ) {
$ mod = array ( ) ; for ( $ i = 0 ; $ i < $ k ; $ i ++ ) $ mod [ $ i ] = 0 ;
$ cumSum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ cumSum += $ arr [ $ i ] ;
$ mod [ ( ( $ cumSum % $ k ) + $ k ) % $ k ] ++ ; }
$ result = 0 ;
for ( $ i = 0 ; $ i < $ k ; $ i ++ )
if ( $ mod [ $ i ] > 1 ) $ result += ( $ mod [ $ i ] * ( $ mod [ $ i ] - 1 ) ) / 2 ;
$ result += $ mod [ 0 ] ; return $ result ; }
function countSubmatrix ( $ mat , $ n , $ k ) {
$ tot_count = 0 ; $ temp = array ( ) ;
for ( $ left = 0 ; $ left < $ n ; $ left ++ ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ temp [ $ i ] = 0 ;
for ( $ right = $ left ; $ right < $ n ; $ right ++ ) {
for ( $ i = 0 ; $ i < $ n ; ++ $ i ) $ temp [ $ i ] += $ mat [ $ i ] [ $ right ] ;
$ tot_count += subCount ( $ temp , $ n , $ k ) ; } }
return $ tot_count ; }
$ mat = array ( array ( 5 , -1 , 6 ) , array ( -2 , 3 , 8 ) , array ( 7 , 4 , -9 ) ) ; $ n = 3 ; $ k = 4 ; echo ( " Count ▁ = ▁ " . countSubmatrix ( $ mat , $ n , $ k ) ) ; ? >
function find ( $ n , $ k ) { if ( $ n + 1 >= $ k ) return ( $ k - 1 ) ; else return ( 2 * $ n + 1 - $ k ) ; }
$ n = 4 ; $ k = 7 ; $ freq = find ( $ n , $ k ) ; if ( $ freq < 0 ) echo " ▁ element ▁ not ▁ exist ▁ STRNEWLINE ▁ " ; else echo " ▁ Frequency ▁ of ▁ " , $ k , " ▁ is ▁ " , $ freq , " STRNEWLINE " ; ? >
function ZigZag ( $ rows , $ columns , $ numbers ) { $ k = 0 ;
$ arr = array ( array ( ) ) ; for ( $ i = 0 ; $ i < $ rows ; $ i ++ ) {
if ( $ i % 2 == 0 ) {
for ( $ j = 0 ; $ j < $ columns and $ numbers [ $ k ] > 0 ; $ j ++ ) {
$ arr [ $ i ] [ $ j ] = $ k + 1 ;
$ numbers [ $ k ] -- ;
if ( $ numbers [ $ k ] == 0 ) $ k ++ ; } }
else {
for ( $ j = $ columns - 1 ; $ j >= 0 and $ numbers [ $ k ] > 0 ; $ j -- ) {
$ arr [ $ i ] [ $ j ] = $ k + 1 ;
$ numbers [ $ k ] -- ;
if ( $ numbers [ $ k ] == 0 ) $ k ++ ; } } }
for ( $ i = 0 ; $ i < $ rows ; $ i ++ ) { for ( $ j = 0 ; $ j < $ columns ; $ j ++ ) echo $ arr [ $ i ] [ $ j ] , " ▁ " ; echo " STRNEWLINE " ; } }
$ rows = 4 ; $ columns = 5 ; $ Numbers = array ( 3 , 4 , 2 , 2 , 3 , 1 , 5 ) ; ZigZag ( $ rows , $ columns , $ Numbers ) ; ? >
function numberofPosition ( $ n , $ k , $ x , $ y , $ obstPosx , $ obstPosy ) {
$ d11 ; $ d12 ; $ d21 ; $ d22 ; $ r1 ; $ r2 ; $ c1 ; $ c2 ;
$ d11 = min ( $ x - 1 , $ y - 1 ) ; $ d12 = min ( $ n - $ x , $ n - $ y ) ; $ d21 = min ( $ n - $ x , $ y - 1 ) ; $ d22 = min ( $ x - 1 , $ n - $ y ) ; $ r1 = $ y - 1 ; $ r2 = $ n - $ y ; $ c1 = $ x - 1 ; $ c2 = $ n - $ x ;
for ( $ i = 0 ; $ i < $ k ; $ i ++ ) { if ( $ x > $ obstPosx [ $ i ] && $ y > $ obstPosy [ $ i ] && $ x - $ obstPosx [ $ i ] == $ y - $ obstPosy [ $ i ] ) $ d11 = min ( $ d11 , $ x - $ obstPosx [ $ i ] - 1 ) ; if ( $ obstPosx [ $ i ] > $ x && $ obstPosy [ $ i ] > $ y && $ obstPosx [ $ i ] - $ x == $ obstPosy [ $ i ] - $ y ) $ d12 = min ( $ d12 , $ obstPosx [ $ i ] - $ x - 1 ) ; if ( $ obstPosx [ $ i ] > $ x && $ y > $ obstPosy [ $ i ] && $ obstPosx [ $ i ] - $ x == $ y - $ obstPosy [ $ i ] ) $ d21 = min ( $ d21 , $ obstPosx [ $ i ] - $ x - 1 ) ; if ( $ x > $ obstPosx [ $ i ] && $ obstPosy [ $ i ] > $ y && $ x - $ obstPosx [ $ i ] == $ obstPosy [ $ i ] - $ y ) $ d22 = min ( $ d22 , $ x - $ obstPosx [ $ i ] - 1 ) ; if ( $ x == $ obstPosx [ $ i ] && $ obstPosy [ $ i ] < $ y ) $ r1 = min ( $ r1 , $ y - $ obstPosy [ $ i ] - 1 ) ; if ( $ x == $ obstPosx [ $ i ] && $ obstPosy [ $ i ] > $ y ) $ r2 = min ( $ r2 , $ obstPosy [ $ i ] - $ y - 1 ) ; if ( $ y == $ obstPosy [ $ i ] && $ obstPosx [ $ i ] < $ x ) $ c1 = min ( $ c1 , $ x - $ obstPosx [ $ i ] - 1 ) ; if ( $ y == $ obstPosy [ $ i ] && $ obstPosx [ $ i ] > $ x ) $ c2 = min ( $ c2 , $ obstPosx [ $ i ] - $ x - 1 ) ; } return $ d11 + $ d12 + $ d21 + $ d22 + $ r1 + $ r2 + $ c1 + $ c2 ; }
$ n = 8 ;
$ k = 1 ;
$ Qposx = 4 ;
$ Qposy = 4 ;
$ obstPosx = array ( 3 ) ;
$ obstPosy = array ( 5 ) ; echo numberofPosition ( $ n , $ k , $ Qposx , $ Qposy , $ obstPosx , $ obstPosy ) ; ? >
$ n = 5 ;
function FindMaxProduct ( $ arr , $ n ) { $ max = 0 ; $ result ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) {
for ( $ j = 0 ; $ j < $ n ; $ j ++ ) {
if ( ( $ j - 3 ) >= 0 ) { $ result = $ arr [ $ i ] [ $ j ] * $ arr [ $ i ] [ $ j - 1 ] * $ arr [ $ i ] [ $ j - 2 ] * $ arr [ $ i ] [ $ j - 3 ] ; if ( $ max < $ result ) $ max = $ result ; }
if ( ( $ i - 3 ) >= 0 ) { $ result = $ arr [ $ i ] [ $ j ] * $ arr [ $ i - 1 ] [ $ j ] * $ arr [ $ i - 2 ] [ $ j ] * $ arr [ $ i - 3 ] [ $ j ] ; if ( $ max < $ result ) $ max = $ result ; }
if ( ( $ i - 3 ) >= 0 and ( $ j - 3 ) >= 0 ) { $ result = $ arr [ $ i ] [ $ j ] * $ arr [ $ i - 1 ] [ $ j - 1 ] * $ arr [ $ i - 2 ] [ $ j - 2 ] * $ arr [ $ i - 3 ] [ $ j - 3 ] ; if ( $ max < $ result ) $ max = $ result ; }
if ( ( $ i - 3 ) >= 0 and ( $ j - 1 ) <= 0 ) { $ result = $ arr [ $ i ] [ $ j ] * $ arr [ $ i - 1 ] [ $ j + 1 ] * $ arr [ $ i - 2 ] [ $ j + 2 ] * $ arr [ $ i - 3 ] [ $ j + 3 ] ; if ( $ max < $ result ) $ max = $ result ; } } } return $ max ; }
$ arr = array ( array ( 1 , 2 , 3 , 4 , 5 ) , array ( 6 , 7 , 8 , 9 , 1 ) , array ( 2 , 3 , 4 , 5 , 6 ) , array ( 7 , 8 , 9 , 1 , 0 ) , array ( 9 , 6 , 4 , 2 , 3 ) ) ; echo FindMaxProduct ( $ arr , $ n ) ; ? >
$ N = 3 ;
function minimumflip ( $ mat , $ n ) { global $ N ; $ transpose ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ transpose [ $ i ] [ $ j ] = $ mat [ $ j ] [ $ i ] ;
$ flip = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ n ; $ j ++ ) if ( $ transpose [ $ i ] [ $ j ] != $ mat [ $ i ] [ $ j ] ) $ flip ++ ; return $ flip / 2 ; }
$ n = 3 ; $ mat = array ( array ( 0 , 0 , 1 ) , array ( 1 , 1 , 1 ) , array ( 1 , 0 , 0 ) ) ; echo minimumflip ( $ mat , $ n ) , " STRNEWLINE " ; ? >
$ N = 3 ;
function minimumflip ( $ mat , $ n ) {
$ flip = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ i ; $ j ++ ) if ( $ mat [ $ i ] [ $ j ] != $ mat [ $ j ] [ $ i ] ) $ flip ++ ; return $ flip ; }
$ n = 3 ; $ mat = array ( array ( 0 , 0 , 1 ) , array ( 1 , 1 , 1 ) , array ( 1 , 0 , 0 ) ) ; echo minimumflip ( $ mat , $ n ) , " STRNEWLINE " ; ? >
$ N = 4 ;
function isLowerTriangularMatrix ( $ mat ) { global $ N ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ N ; $ j ++ ) if ( $ mat [ $ i ] [ $ j ] != 0 ) return false ; return true ; }
$ mat = array ( array ( 1 , 0 , 0 , 0 ) , array ( 1 , 4 , 0 , 0 ) , array ( 4 , 6 , 2 , 0 ) , array ( 0 , 4 , 7 , 6 ) ) ;
if ( isLowerTriangularMatrix ( $ mat ) ) echo ( " Yes " ) ; else echo ( " No " ) ; ? >
$ N = 4 ;
function isUpperTriangularMatrix ( $ mat ) { global $ N ; for ( $ i = 1 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ i ; $ j ++ ) if ( $ mat [ $ i ] [ $ j ] != 0 ) return false ; return true ; }
$ mat = array ( array ( 1 , 3 , 5 , 3 ) , array ( 0 , 4 , 6 , 2 ) , array ( 0 , 0 , 2 , 5 ) , array ( 0 , 0 , 0 , 6 ) ) ; if ( isUpperTriangularMatrix ( $ mat ) ) echo " Yes " ; else echo " No " ; ? >
$ MAX = 100 ;
function freq ( $ ar , $ m , $ n ) { $ even = 0 ; $ odd = 0 ; for ( $ i = 0 ; $ i < $ m ; ++ $ i ) { for ( $ j = 0 ; $ j < $ n ; ++ $ j ) {
if ( ( $ ar [ $ i ] [ $ j ] % 2 ) == 0 ) ++ $ even ; else ++ $ odd ; } }
echo " ▁ Frequency ▁ of ▁ odd ▁ number ▁ = ▁ " , $ odd , " STRNEWLINE " ; echo " ▁ Frequency ▁ of ▁ even ▁ number ▁ = ▁ " , $ even ; }
$ m = 3 ; $ n = 3 ; $ array = array ( array ( 1 , 2 , 3 ) , array ( 4 , 5 , 6 ) , array ( 7 , 8 , 9 ) ) ; freq ( $ array , $ m , $ n ) ; ? >
$ MAX = 100 ;
function HalfDiagonalSums ( $ mat , $ n ) { global $ MAX ;
$ diag1_left = 1 ; $ diag1_right = 1 ; $ diag2_left = 1 ; $ diag2_right = 1 ; for ( $ i = 0 , $ j = $ n - 1 ; $ i < $ n ; $ i ++ , $ j -- ) { if ( $ i < $ n / 2 ) { $ diag1_left += $ mat [ $ i ] [ $ i ] ; $ diag2_left += $ mat [ $ j ] [ $ i ] ; } else if ( $ i > $ n / 2 ) { $ diag1_right += $ mat [ $ i ] [ $ i ] ; $ diag2_right += $ mat [ $ j ] [ $ i ] ; } } return ( $ diag1_left == $ diag2_right && $ diag2_right == $ diag2_left && $ diag1_right == $ diag2_left && $ diag2_right == $ mat [ $ n / 2 ] [ $ n / 2 ] ) ; }
$ a = array ( array ( 2 , 9 , 1 , 4 , -2 ) , array ( 6 , 7 , 2 , 11 , 4 ) , array ( 4 , 2 , 9 , 2 , 4 ) , array ( 1 , 9 , 2 , 4 , 4 ) , array ( 0 , 2 , 4 , 2 , 5 ) ) ; if ( HalfDiagonalSums ( $ a , 5 ) == 0 ) echo " Yes " ; else echo " No " ; ? >
function isIdentity ( $ mat , $ N ) { for ( $ row = 0 ; $ row < $ N ; $ row ++ ) { for ( $ col = 0 ; $ col < $ N ; $ col ++ ) { if ( $ row == $ col and $ mat [ $ row ] [ $ col ] != 1 ) return false ; else if ( $ row != $ col && $ mat [ $ row ] [ $ col ] != 0 ) return false ; } } return true ; }
$ N = 4 ; $ mat = array ( array ( 1 , 0 , 0 , 0 ) , array ( 0 , 1 , 0 , 0 ) , array ( 0 , 0 , 1 , 0 ) , array ( 0 , 0 , 0 , 1 ) ) ; if ( isIdentity ( $ mat , $ N ) ) echo " Yes ▁ " ; else echo " No ▁ " ; ? >
$ mod = 100000007 ;
function modPower ( $ a , $ t ) { global $ mod ; $ now = $ a ; $ ret = 1 ;
while ( $ t ) { if ( $ t & 1 ) $ ret = $ now * ( $ ret % $ mod ) ; $ now = $ now * ( $ now % $ mod ) ; $ t >>= 1 ; } return $ ret ; }
function countWays ( $ n , $ m , $ k ) { global $ mod ;
if ( $ k == -1 and ( $ n + $ m ) % 2 == 1 ) return 0 ;
if ( $ n == 1 or $ m == 1 ) return 1 ;
return ( modPower ( modPower ( 2 , $ n - 1 ) , $ m - 1 ) % $ mod ) ; }
$ n = 2 ; $ m = 7 ; $ k = 1 ; echo countWays ( $ n , $ m , $ k ) ; ? >
function imageSwap ( & $ mat , $ n ) {
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j <= $ i ; $ j ++ ) $ mat [ $ i ] [ $ j ] = $ mat [ $ i ] [ $ j ] + $ mat [ $ j ] [ $ i ] - ( $ mat [ $ j ] [ $ i ] = $ mat [ $ i ] [ $ j ] ) ; }
function printMatrix ( & $ mat , $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) { echo ( $ mat [ $ i ] [ $ j ] ) ; echo ( " ▁ " ) ; } echo ( " STRNEWLINE " ) ; } }
$ mat = array ( array ( 1 , 2 , 3 , 4 ) , array ( 5 , 6 , 7 , 8 ) , array ( 9 , 10 , 11 , 12 ) , array ( 13 , 14 , 15 , 16 ) ) ; $ n = 4 ; imageSwap ( $ mat , $ n ) ; printMatrix ( $ mat , $ n ) ; ? >
$ m = 3 ;
$ n = 2 ;
function countSets ( $ a ) { global $ m , $ n ;
$ res = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ u = 0 ; $ v = 0 ; for ( $ j = 0 ; $ j < $ m ; $ j ++ ) $ a [ $ i ] [ $ j ] ? $ u ++ : $ v ++ ; $ res += pow ( 2 , $ u ) - 1 + pow ( 2 , $ v ) - 1 ; }
for ( $ i = 0 ; $ i < $ m ; $ i ++ ) { $ u = 0 ; $ v = 0 ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ a [ $ j ] [ $ i ] ? $ u ++ : $ v ++ ; $ res += pow ( 2 , $ u ) - 1 + pow ( 2 , $ v ) - 1 ; }
return $ res - ( $ n * $ m ) ; }
$ a = array ( array ( 1 , 0 , 1 ) , array ( 0 , 1 , 0 ) ) ; echo countSets ( $ a ) ; ? >
function fill0X ( $ m , $ n ) {
$ k = 0 ; $ l = 0 ;
$ r = $ m ; $ c = $ n ;
$ x = ' X ' ;
while ( $ k < $ m && $ l < $ n ) {
for ( $ i = $ l ; $ i < $ n ; ++ $ i ) $ a [ $ k ] [ $ i ] = $ x ; $ k ++ ;
for ( $ i = $ k ; $ i < $ m ; ++ $ i ) $ a [ $ i ] [ $ n - 1 ] = $ x ; $ n -- ;
if ( $ k < $ m ) { for ( $ i = $ n - 1 ; $ i >= $ l ; -- $ i ) $ a [ $ m - 1 ] [ $ i ] = $ x ; $ m -- ; }
if ( $ l < $ n ) { for ( $ i = $ m - 1 ; $ i >= $ k ; -- $ i ) $ a [ $ i ] [ $ l ] = $ x ; $ l ++ ; }
$ x = ( $ x == '0' ) ? ' X ' : '0' ; }
for ( $ i = 0 ; $ i < $ r ; $ i ++ ) { for ( $ j = 0 ; $ j < $ c ; $ j ++ ) echo ( $ a [ $ i ] [ $ j ] . " ▁ " ) ; echo " STRNEWLINE " ; } }
echo " Output ▁ for ▁ m ▁ = ▁ 5 , ▁ n ▁ = ▁ 6 STRNEWLINE " ; fill0X ( 5 , 6 ) ; echo " Output for m = 4 , n = 4 " ; fill0X ( 4 , 4 ) ; echo " Output for m = 3 , n = 4 " ; fill0X ( 3 , 4 ) ; ? >
function calculateEnergy ( $ mat , $ n ) { $ i_des ; $ j_des ; $ q ; $ tot_energy = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) {
$ q = ( int ) ( $ mat [ $ i ] [ $ j ] / $ n ) ;
$ i_des = $ q ; $ j_des = $ mat [ $ i ] [ $ j ] - ( $ n * $ q ) ;
$ tot_energy += abs ( $ i_des - $ i ) + abs ( $ j_des - $ j ) ; } }
return $ tot_energy ; }
$ mat = array ( array ( 4 , 7 , 0 , 3 ) , array ( 8 , 5 , 6 , 1 ) , array ( 9 , 11 , 10 , 2 ) , array ( 15 , 13 , 14 , 12 ) ) ; $ n = 4 ; echo " Total ▁ energy ▁ required ▁ = ▁ " , calculateEnergy ( $ mat , $ n ) , " ▁ units " ; ? >
$ MAX = 100 ;
function isUnique ( $ mat , $ i , $ j , $ n , $ m ) { global $ MAX ;
$ sumrow = 0 ; for ( $ k = 0 ; $ k < $ m ; $ k ++ ) { $ sumrow += $ mat [ $ i ] [ $ k ] ; if ( $ sumrow > 1 ) return false ; }
$ sumcol = 0 ; for ( $ k = 0 ; $ k < $ n ; $ k ++ ) { $ sumcol += $ mat [ $ k ] [ $ j ] ; if ( $ sumcol > 1 ) return false ; } return true ; } function countUnique ( $ mat , $ n , $ m ) { $ uniquecount = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ m ; $ j ++ ) if ( $ mat [ $ i ] [ $ j ] && isUnique ( $ mat , $ i , $ j , $ n , $ m ) ) $ uniquecount ++ ; return $ uniquecount ; }
$ mat = array ( array ( 0 , 1 , 0 , 0 ) , array ( 0 , 0 , 1 , 0 ) , array ( 1 , 0 , 0 , 1 ) ) ; echo countUnique ( $ mat , 3 , 4 ) ; ? >
$ MAX = 100 ; function isSparse ( $ array , $ m , $ n ) { $ counter = 0 ;
for ( $ i = 0 ; $ i < $ m ; ++ $ i ) for ( $ j = 0 ; $ j < $ n ; ++ $ j ) if ( $ array [ $ i ] [ $ j ] == 0 ) ++ $ counter ; return ( $ counter > ( ( $ m * $ n ) / 2 ) ) ; }
$ array = array ( array ( 1 , 0 , 3 ) , array ( 0 , 0 , 4 ) , array ( 6 , 0 , 0 ) ) ; $ m = 3 ; $ n = 3 ; if ( isSparse ( $ array , $ m , $ n ) ) echo " Yes " ; else echo " No " ; ? >
$ MAX = 100 ;
function countCommon ( $ mat , $ n ) { global $ MAX ; $ res = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ mat [ $ i ] [ $ i ] == $ mat [ $ i ] [ $ n - $ i - 1 ] ) $ res ++ ; return $ res ; }
$ mat = array ( array ( 1 , 2 , 3 ) , array ( 4 , 5 , 6 ) , array ( 7 , 8 , 9 ) ) ; echo countCommon ( $ mat , 3 ) ; ? >
function areSumSame ( $ a , $ n , $ m ) { $ sum1 = 0 ; $ sum2 = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ sum1 = 0 ; $ sum2 = 0 ; for ( $ j = 0 ; $ j < $ m ; $ j ++ ) { $ sum1 += $ a [ $ i ] [ $ j ] ; $ sum2 += $ a [ $ j ] [ $ i ] ; } if ( $ sum1 == $ sum2 ) return true ; } return false ; }
$ n = 4 ;
$ m = 4 ; $ M = array ( array ( 1 , 2 , 3 , 4 ) , array ( 9 , 5 , 3 , 1 ) , array ( 0 , 3 , 5 , 6 ) , array ( 0 , 4 , 5 , 6 ) ) ; echo areSumSame ( $ M , $ n , $ m ) ; ? >
$ N = 4 ;
function findMax ( $ arr ) { global $ N ; $ row = 0 ; $ i ; $ j = $ N - 1 ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) {
while ( $ arr [ $ i ] [ $ j ] == 1 && $ j >= 0 ) { $ row = $ i ; $ j -- ; } } echo " Row ▁ number ▁ = ▁ " , $ row + 1 ; echo " , MaxCount = " }
$ arr = array ( array ( 0 , 0 , 0 , 1 ) , array ( 0 , 0 , 0 , 1 ) , array ( 0 , 0 , 0 , 0 ) , array ( 0 , 1 , 1 , 1 ) ) ; findMax ( $ arr ) ; ? >
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ N ; $ j ++ ) if ( $ mat [ $ i ] [ $ j ] != $ tr [ $ i ] [ $ j ] ) return false ; return true ; }
function isSymmetric ( $ mat , $ N ) { $ tr = array ( array ( ) ) ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ N ; $ j ++ ) $ tr [ $ i ] [ $ j ] = $ mat [ $ j ] [ $ i ] ;
$ mat = array ( array ( 1 , 3 , 5 ) , array ( 3 , 2 , 4 ) , array ( 5 , 4 , 1 ) ) ; if ( isSymmetric ( $ mat , 3 ) ) echo " Yes " ; else echo " No " ; ? >
$ MAX = 100 ;
function isSymmetric ( $ mat , $ N ) { for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ N ; $ j ++ ) if ( $ mat [ $ i ] [ $ j ] != $ mat [ $ j ] [ $ i ] ) return false ; return true ; }
$ mat = array ( array ( 1 , 3 , 5 ) , array ( 3 , 2 , 4 ) , array ( 5 , 4 , 1 ) ) ; if ( isSymmetric ( $ mat , 3 ) ) echo ( " Yes " ) ; else echo ( " No " ) ; ? >
$ n = 4 ; $ m = 4 ;
function findPossibleMoves ( $ mat , $ p , $ q ) { global $ n ; global $ m ;
$ X = array ( 2 , 1 , -1 , -2 , -2 , -1 , 1 , 2 ) ; $ Y = array ( 1 , 2 , 2 , 1 , -1 , -2 , -2 , -1 ) ; $ count = 0 ;
for ( $ i = 0 ; $ i < 8 ; $ i ++ ) {
$ x = $ p + $ X [ $ i ] ; $ y = $ q + $ Y [ $ i ] ;
if ( $ x >= 0 && $ y >= 0 && $ x < $ n && $ y < $ m && $ mat [ $ x ] [ $ y ] == 0 ) $ count ++ ; }
return $ count ; }
$ mat = array ( array ( 1 , 0 , 1 , 0 ) , array ( 0 , 1 , 1 , 1 ) , array ( 1 , 1 , 0 , 1 ) , array ( 0 , 1 , 1 , 1 ) ) ; $ p = 2 ; $ q = 2 ; echo findPossibleMoves ( $ mat , $ p , $ q ) ; ? >
$ MAX = 100 ; function printDiagonalSums ( $ mat , $ n ) { global $ MAX ; $ principal = 0 ; $ secondary = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) {
if ( $ i == $ j ) $ principal += $ mat [ $ i ] [ $ j ] ;
if ( ( $ i + $ j ) == ( $ n - 1 ) ) $ secondary += $ mat [ $ i ] [ $ j ] ; } } echo " Principal ▁ Diagonal : " , $ principal , " STRNEWLINE " ; echo " Secondary ▁ Diagonal : " , $ secondary , " STRNEWLINE " ; }
$ a = array ( array ( 1 , 2 , 3 , 4 ) , array ( 5 , 6 , 7 , 8 ) , array ( 1 , 2 , 3 , 4 ) , array ( 5 , 6 , 7 , 8 ) ) ; printDiagonalSums ( $ a , 4 ) ; ? >
$ MAX = 100 ; function printDiagonalSums ( $ mat , $ n ) { global $ MAX ; $ principal = 0 ; $ secondary = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ principal += $ mat [ $ i ] [ $ i ] ; $ secondary += $ mat [ $ i ] [ $ n - $ i - 1 ] ; } echo " Principal ▁ Diagonal : " , $ principal , " STRNEWLINE " ; echo " Secondary ▁ Diagonal : " , $ secondary , " STRNEWLINE " ; }
$ a = array ( array ( 1 , 2 , 3 , 4 ) , array ( 5 , 6 , 7 , 8 ) , array ( 1 , 2 , 3 , 4 ) , array ( 5 , 6 , 7 , 8 ) ) ; printDiagonalSums ( $ a , 4 ) ; ? >
$ MAX = 100 ; function printBoundary ( $ a , $ m , $ n ) { global $ MAX ; for ( $ i = 0 ; $ i < $ m ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) { if ( $ i == 0 ) echo $ a [ $ i ] [ $ j ] , " ▁ " ; else if ( $ i == $ m - 1 ) echo $ a [ $ i ] [ $ j ] , " ▁ " ; else if ( $ j == 0 ) echo $ a [ $ i ] [ $ j ] , " ▁ " ; else if ( $ j == $ n - 1 ) echo $ a [ $ i ] [ $ j ] , " ▁ " ; else echo " ▁ " , " ▁ " ; } echo " STRNEWLINE " ; } }
$ a = array ( array ( 1 , 2 , 3 , 4 ) , array ( 5 , 6 , 7 , 8 ) , array ( 1 , 2 , 3 , 4 ) , array ( 5 , 6 , 7 , 8 ) ) ; printBoundary ( $ a , 4 , 4 ) ; ? >
function getBoundarySum ( $ a , $ m , $ n ) { $ sum = 0 ; for ( $ i = 0 ; $ i < $ m ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) { if ( $ i == 0 ) $ sum += $ a [ $ i ] [ $ j ] ; else if ( $ i == $ m - 1 ) $ sum += $ a [ $ i ] [ $ j ] ; else if ( $ j == 0 ) $ sum += $ a [ $ i ] [ $ j ] ; else if ( $ j == $ n - 1 ) $ sum += $ a [ $ i ] [ $ j ] ; } } return $ sum ; }
$ a = array ( array ( 1 , 2 , 3 , 4 ) , array ( 5 , 6 , 7 , 8 ) , array ( 1 , 2 , 3 , 4 ) , array ( 5 , 6 , 7 , 8 ) ) ; $ sum = getBoundarySum ( $ a , 4 , 4 ) ; echo " Sum ▁ of ▁ boundary ▁ elements ▁ is ▁ " , $ sum ; ? >
$ MAX = 100 ; function printSpiral ( $ mat , $ r , $ c ) { global $ MAX ; $ i ; $ a = 0 ; $ b = 2 ; $ low_row = ( 0 > $ a ) ? 0 : $ a ; $ low_column = ( 0 > $ b ) ? 0 : $ b - 1 ; $ high_row = ( ( $ a + 1 ) >= $ r ) ? $ r - 1 : $ a + 1 ; $ high_column = ( ( $ b + 1 ) >= $ c ) ? $ c - 1 : $ b + 1 ; while ( ( $ low_row > 0 - $ r && $ low_column > 0 - $ c ) ) { for ( $ i = $ low_column + 1 ; $ i <= $ high_column && $ i < $ c && $ low_row >= 0 ; ++ $ i ) echo $ mat [ $ low_row ] [ $ i ] , " ▁ " ; $ low_row -= 1 ; for ( $ i = $ low_row + 2 ; $ i <= $ high_row && $ i < $ r && $ high_column < $ c ; ++ $ i ) echo $ mat [ $ i ] [ $ high_column ] , " ▁ " ; $ high_column += 1 ; for ( $ i = $ high_column - 2 ; $ i >= $ low_column && $ i >= 0 && $ high_row < $ r ; -- $ i ) echo $ mat [ $ high_row ] [ $ i ] , " ▁ " ; $ high_row += 1 ; for ( $ i = $ high_row - 2 ; $ i > $ low_row && $ i >= 0 && $ low_column >= 0 ; -- $ i ) echo $ mat [ $ i ] [ $ low_column ] , " ▁ " ; $ low_column -= 1 ; } echo " STRNEWLINE " ; }
$ mat = array ( array ( 1 , 2 , 3 ) , array ( 4 , 5 , 6 ) , array ( 7 , 8 , 9 ) ) ; $ r = 3 ; $ c = 3 ;
printSpiral ( $ mat , $ r , $ c ) ; ? >
function difference ( $ arr , $ n ) {
$ d1 = 0 ; $ d2 = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) {
if ( $ i == $ j ) $ d1 += $ arr [ $ i ] [ $ j ] ;
if ( $ i == $ n - $ j - 1 ) $ d2 += $ arr [ $ i ] [ $ j ] ; } }
return abs ( $ d1 - $ d2 ) ; }
{ $ n = 3 ; $ arr = array ( array ( 11 , 2 , 4 ) , array ( 4 , 5 , 6 ) , array ( 10 , 8 , -12 ) ) ; echo difference ( $ arr , $ n ) ; return 0 ; } ? >
function difference ( $ arr , $ n ) {
$ d1 = 0 ; $ d2 = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { $ d1 += $ arr [ $ i ] [ $ i ] ; $ d2 += $ arr [ $ i ] [ $ n - $ i - 1 ] ; }
return abs ( $ d1 - $ d2 ) ; }
{ $ n = 3 ; $ arr = array ( array ( 11 , 2 , 4 ) , array ( 4 , 5 , 6 ) , array ( 10 , 8 , -12 ) ) ; echo difference ( $ arr , $ n ) ; return 0 ; } ? >
function spiralFill ( $ m , $ n , & $ a ) {
$ val = 1 ;
$ k = 0 ; $ l = 0 ; while ( $ k < $ m && $ l < $ n ) {
for ( $ i = $ l ; $ i < $ n ; ++ $ i ) $ a [ $ k ] [ $ i ] = $ val ++ ; $ k ++ ;
for ( $ i = $ k ; $ i < $ m ; ++ $ i ) $ a [ $ i ] [ $ n - 1 ] = $ val ++ ; $ n -- ;
if ( $ k < $ m ) { for ( $ i = $ n - 1 ; $ i >= $ l ; -- $ i ) $ a [ $ m - 1 ] [ $ i ] = $ val ++ ; $ m -- ; }
if ( $ l < $ n ) { for ( $ i = $ m - 1 ; $ i >= $ k ; -- $ i ) $ a [ $ i ] [ $ l ] = $ val ++ ; $ l ++ ; } } }
$ m = 4 ; $ n = 4 ; spiralFill ( $ m , $ n , $ a ) ; for ( $ i = 0 ; $ i < $ m ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) { echo ( $ a [ $ i ] [ $ j ] ) ; echo ( " ▁ " ) ; } echo ( " STRNEWLINE " ) ; } ? >
$ MAX = 100 ;
function maxMin ( $ arr , $ n ) { $ min = PHP_INT_MAX ; $ max = PHP_INT_MIN ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j <= $ n / 2 ; $ j ++ ) {
if ( $ arr [ $ i ] [ $ j ] > $ arr [ $ i ] [ $ n - $ j - 1 ] ) { if ( $ min > $ arr [ $ i ] [ $ n - $ j - 1 ] ) $ min = $ arr [ $ i ] [ $ n - $ j - 1 ] ; if ( $ max < $ arr [ $ i ] [ $ j ] ) $ max = $ arr [ $ i ] [ $ j ] ; } else { if ( $ min > $ arr [ $ i ] [ $ j ] ) $ min = $ arr [ $ i ] [ $ j ] ; if ( $ max < $ arr [ $ i ] [ $ n - $ j - 1 ] ) $ max = $ arr [ $ i ] [ $ n - $ j - 1 ] ; } } } echo " Maximum = " ▁ , ▁ $ max STRNEWLINE , " , Minimum = " }
$ arr = array ( array ( 5 , 9 , 11 ) , array ( 25 , 0 , 14 ) , array ( 21 , 6 , 4 ) ) ; maxMin ( $ arr , 3 ) ; ? >
$ MAX = 100 ;
function findNormal ( $ mat , $ n ) { $ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ sum += $ mat [ $ i ] [ $ j ] * $ mat [ $ i ] [ $ j ] ; return floor ( sqrt ( $ sum ) ) ; }
function findTrace ( $ mat , $ n ) { $ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ sum += $ mat [ $ i ] [ $ i ] ; return $ sum ; }
$ mat = array ( array ( 1 , 1 , 1 , 1 , 1 ) , array ( 2 , 2 , 2 , 2 , 2 ) , array ( 3 , 3 , 3 , 3 , 3 ) , array ( 4 , 4 , 4 , 4 , 4 ) , array ( 5 , 5 , 5 , 5 , 5 ) ) ; echo " Trace ▁ of ▁ Matrix ▁ = ▁ " , findTrace ( $ mat , 5 ) , " STRNEWLINE " ; echo " Normal ▁ of ▁ Matrix ▁ = ▁ " , findNormal ( $ mat , 5 ) ; ? >
$ N = 5 ; $ M = 5 ;
function minOperation ( & $ arr ) { global $ N , $ M ; $ ans = 0 ; for ( $ i = $ N - 1 ; $ i >= 0 ; $ i -- ) { for ( $ j = $ M - 1 ; $ j >= 0 ; $ j -- ) {
if ( $ arr [ $ i ] [ $ j ] == 0 ) {
$ ans ++ ;
for ( $ k = 0 ; $ k <= $ i ; $ k ++ ) { for ( $ h = 0 ; $ h <= $ j ; $ h ++ ) {
if ( $ arr [ $ k ] [ $ h ] == 1 ) $ arr [ $ k ] [ $ h ] = 0 ; else $ arr [ $ k ] [ $ h ] = 1 ; } } } } } return $ ans ; }
$ mat = array ( array ( 0 , 0 , 1 , 1 , 1 ) , array ( 0 , 0 , 0 , 1 , 1 ) , array ( 0 , 0 , 0 , 1 , 1 ) , array ( 1 , 1 , 1 , 1 , 1 ) , array ( 1 , 1 , 1 , 1 , 1 ) ) ; echo minOperation ( $ mat ) ; ? >
function findSum ( $ n ) { $ ans = 0 ; $ temp = 0 ; $ num ;
for ( $ i = 1 ; $ i <= $ n and $ temp < $ n ; $ i ++ ) {
$ temp = $ i - 1 ;
$ num = 1 ; while ( $ temp < $ n ) { if ( $ temp + $ i <= $ n ) $ ans += ( $ i * $ num ) ; else $ ans += ( ( $ n - $ temp ) * $ num ) ; $ temp += $ i ; $ num ++ ; } } return $ ans ; }
$ N = 2 ; echo findSum ( $ N ) ; ? >
function countOps ( $ A , $ B , $ m , $ n ) { $ MAX = 1000 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ m ; $ j ++ ) $ A [ $ i ] [ $ j ] -= $ B [ $ i ] [ $ j ] ;
for ( $ i = 1 ; $ i < $ n ; $ i ++ ) for ( $ j = 1 ; $ j < $ m ; $ j ++ ) if ( $ A [ $ i ] [ $ j ] - $ A [ $ i ] [ 0 ] - $ A [ 0 ] [ $ j ] + $ A [ 0 ] [ 0 ] != 0 ) return -1 ;
$ result = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ result += abs ( $ A [ $ i ] [ 0 ] ) ; for ( $ j = 0 ; $ j < $ m ; $ j ++ ) $ result += abs ( $ A [ 0 ] [ $ j ] - $ A [ 0 ] [ 0 ] ) ; return ( $ result ) ; }
$ A = array ( array ( 1 , 1 , 1 ) , array ( 1 , 1 , 1 ) , array ( 1 , 1 , 1 ) ) ; $ B = array ( array ( 1 , 2 , 3 ) , array ( 4 , 5 , 6 ) , array ( 7 , 8 , 9 ) ) ; echo countOps ( $ A , $ B , 3 , 3 ) ; ? >
function printCoils ( $ n ) {
$ m = 8 * $ n * $ n ;
$ coil1 = array ( ) ;
$ coil1 [ 0 ] = 8 * $ n * $ n + 2 * $ n ; $ curr = $ coil1 [ 0 ] ; $ nflg = 1 ; $ step = 2 ;
$ index = 1 ; while ( $ index < $ m ) {
for ( $ i = 0 ; $ i < $ step ; $ i ++ ) {
$ curr = $ coil1 [ $ index ++ ] = ( $ curr - 4 * $ n * $ nflg ) ; if ( $ index >= $ m ) break ; } if ( $ index >= $ m ) break ;
for ( $ i = 0 ; $ i < $ step ; $ i ++ ) { $ curr = $ coil1 [ $ index ++ ] = $ curr + $ nflg ; if ( $ index >= $ m ) break ; } $ nflg = $ nflg * ( -1 ) ; $ step += 2 ; }
$ coil2 = array ( ) ; for ( $ i = 0 ; $ i < 8 * $ n * $ n ; $ i ++ ) $ coil2 [ $ i ] = 16 * $ n * $ n + 1 - $ coil1 [ $ i ] ;
echo " Coil ▁ 1 ▁ : ▁ " ; for ( $ i = 0 ; $ i < 8 * $ n * $ n ; $ i ++ ) echo $ coil1 [ $ i ] , " ▁ " ; echo " Coil 2 : " ; for ( $ i = 0 ; $ i < 8 * $ n * $ n ; $ i ++ ) echo $ coil2 [ $ i ] , " ▁ " ; }
$ n = 1 ; printCoils ( $ n ) ; ? >
function findSum ( $ n ) {
$ arr = array ( array ( ) ) ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ arr [ $ i ] [ $ j ] = abs ( $ i - $ j ) ;
$ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ sum += $ arr [ $ i ] [ $ j ] ; return $ sum ; }
$ n = 3 ; echo findSum ( $ n ) ; ? >
function findSum ( $ n ) { $ sum = 0 ; for ( $ i = 0 ; $ i < $ n ; $ i ++ ) $ sum += $ i * ( $ n - $ i ) ; return 2 * $ sum ; }
$ n = 3 ; echo findSum ( $ n ) ; ? >
function findSum ( $ n ) { $ n -- ; $ sum = 0 ; $ sum += ( $ n * ( $ n + 1 ) ) / 2 ; $ sum += ( $ n * ( $ n + 1 ) * ( 2 * $ n + 1 ) ) / 6 ; return $ sum ; }
$ n = 3 ; echo findSum ( $ n ) ; ? >
function checkHV ( $ arr , $ N , $ M ) {
$ horizontal = true ; $ vertical = true ;
for ( $ i = 0 , $ k = $ N - 1 ; $ i < $ N / 2 ; $ i ++ , $ k -- ) {
for ( $ j = 0 ; $ j < $ M ; $ j ++ ) {
if ( $ arr [ $ i ] [ $ j ] != $ arr [ $ k ] [ $ j ] ) { $ horizontal = false ; break ; } } }
for ( $ i = 0 , $ k = $ M - 1 ; $ i < $ M / 2 ; $ i ++ , $ k -- ) {
for ( $ j = 0 ; $ j < $ N ; $ j ++ ) {
if ( $ arr [ $ i ] [ $ j ] != $ arr [ $ k ] [ $ j ] ) { $ horizontal = false ; break ; } } } if ( ! $ horizontal && ! $ vertical ) echo " NO STRNEWLINE " ; else if ( $ horizontal && ! $ vertical ) cout << " HORIZONTAL STRNEWLINE " ; else if ( $ vertical && ! $ horizontal ) echo " VERTICAL STRNEWLINE " ; else echo " BOTH STRNEWLINE " ; }
$ mat = array ( array ( 1 , 0 , 1 ) , array ( 0 , 0 , 0 ) , array ( 1 , 0 , 1 ) ) ; checkHV ( $ mat , 3 , 3 ) ; ? >
function maxDet ( $ n ) { return ( 2 * $ n * $ n * $ n ) ; }
function resMatrix ( $ n ) { for ( $ i = 0 ; $ i < 3 ; $ i ++ ) { for ( $ j = 0 ; $ j < 3 ; $ j ++ ) {
if ( $ i == 0 && $ j == 2 ) echo "0 ▁ " ; else if ( $ i == 1 && $ j == 0 ) echo "0 ▁ " ; else if ( $ i == 2 && $ j == 1 ) echo "0 ▁ " ;
else echo $ n , " " ; } echo " " } }
$ n = 15 ; echo " Maximum ▁ Determinant ▁ = ▁ " , maxDet ( $ n ) ; echo " Resultant Matrix : " resMatrix ( $ n ) ; ? >
function spiralDiaSum ( $ n ) { if ( $ n == 1 ) return 1 ;
return ( 4 * $ n * $ n - 6 * $ n + 6 + spiralDiaSum ( $ n - 2 ) ) ; }
$ n = 7 ; echo spiralDiaSum ( $ n ) ; ? >
$ R = 3 ; $ C = 5 ;
function numofneighbour ( $ mat , $ i , $ j ) { global $ R ; global $ C ; $ count = 0 ;
if ( $ i > 0 && ( $ mat [ $ i - 1 ] [ $ j ] ) ) $ count ++ ;
if ( $ j > 0 && ( $ mat [ $ i ] [ $ j - 1 ] ) ) $ count ++ ;
if ( ( $ i < $ R - 1 ) && ( $ mat [ $ i + 1 ] [ $ j ] ) ) $ count ++ ;
if ( ( $ j < $ C - 1 ) && ( $ mat [ $ i ] [ $ j + 1 ] ) ) $ count ++ ; return $ count ; }
function findperimeter ( $ mat ) { global $ R ; global $ C ; $ perimeter = 0 ;
for ( $ i = 0 ; $ i < $ R ; $ i ++ ) for ( $ j = 0 ; $ j < $ C ; $ j ++ ) if ( $ mat [ $ i ] [ $ j ] ) $ perimeter += ( 4 - numofneighbour ( $ mat , $ i , $ j ) ) ; return $ perimeter ; }
$ mat = array ( array ( 0 , 1 , 0 , 0 , 0 ) , array ( 1 , 1 , 1 , 0 , 0 ) , array ( 1 , 0 , 0 , 0 , 0 ) ) ; echo findperimeter ( $ mat ) , " STRNEWLINE " ; ? >
$ MAX = 100 ; function printMatrixDiagonal ( $ mat , $ n ) {
$ i = 0 ; $ j = 0 ;
$ isUp = true ;
for ( $ k = 0 ; $ k < $ n * $ n {
if ( $ isUp ) { for ( ; $ i >= 0 && $ j < $ n ; $ j ++ , $ i -- ) { echo $ mat [ $ i ] [ $ j ] . " " ; $ k ++ ; }
if ( $ i < 0 && $ j <= $ n - 1 ) $ i = 0 ; if ( $ j == $ n ) { $ i = $ i + 2 ; $ j -- ; } }
else { for ( ; $ j >= 0 && $ i < $ n ; $ i ++ , $ j -- ) { echo $ mat [ $ i ] [ $ j ] . " " ; $ k ++ ; }
if ( $ j < 0 && $ i <= $ n - 1 ) $ j = 0 ; if ( $ i == $ n ) { $ j = $ j + 2 ; $ i -- ; } }
$ isUp = ! $ isUp ; } }
$ mat = array ( array ( 1 , 2 , 3 ) , array ( 4 , 5 , 6 ) , array ( 7 , 8 , 9 ) ) ; $ n = 3 ; printMatrixDiagonal ( $ mat , $ n ) ; ? >
$ MAX = 100 ;
function maxRowDiff ( $ mat , $ m , $ n ) { global $ MAX ;
$ rowSum = array ( ) ;
for ( $ i = 0 ; $ i < $ m ; $ i ++ ) { $ sum = 0 ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) $ sum += $ mat [ $ i ] [ $ j ] ; $ rowSum [ $ i ] = $ sum ; }
$ max_diff = $ rowSum [ 1 ] - $ rowSum [ 0 ] ; $ min_element = $ rowSum [ 0 ] ; for ( $ i = 1 ; $ i < $ m ; $ i ++ ) {
if ( $ rowSum [ $ i ] - $ min_element > $ max_diff ) $ max_diff = $ rowSum [ $ i ] - $ min_element ;
if ( $ rowSum [ $ i ] < $ min_element ) $ min_element = $ rowSum [ $ i ] ; } return $ max_diff ; }
$ m = 5 ; $ n = 4 ; $ mat = array ( array ( -1 , 2 , 3 , 4 ) , array ( 5 , 3 , -2 , 1 ) , array ( 6 , 7 , 2 , -3 ) , array ( 2 , 9 , 1 , 4 ) , array ( 2 , 1 , -2 , 0 ) ) ; echo maxRowDiff ( $ mat , $ m , $ n ) ; ? >
$ MAX = 100 ;
function sortedCount ( $ mat , $ r , $ c ) {
$ result = 0 ;
for ( $ i = 0 ; $ i < $ r ; $ i ++ ) {
$ j ; for ( $ j = 0 ; $ j < $ c - 1 ; $ j ++ ) if ( $ mat [ $ i ] [ $ j + 1 ] <= $ mat [ $ i ] [ $ j ] ) break ;
if ( $ j == $ c - 1 ) $ result ++ ; }
for ( $ i = 0 ; $ i < $ r ; $ i ++ ) {
$ j ; for ( $ j = $ c - 1 ; $ j > 0 ; $ j -- ) if ( $ mat [ $ i ] [ $ j - 1 ] <= $ mat [ $ i ] [ $ j ] ) break ;
if ( $ c > 1 && $ j == 0 ) $ result ++ ; } return $ result ; }
$ m = 4 ; $ n = 5 ; $ mat = array ( array ( 1 , 2 , 3 , 4 , 5 ) , array ( 4 , 3 , 1 , 2 , 6 ) , array ( 8 , 7 , 6 , 5 , 4 ) , array ( 5 , 7 , 8 , 9 , 10 ) ) ; echo sortedCount ( $ mat , $ m , $ n ) ; ? >
$ MAX = 1000 ;
function maxXOR ( $ mat , $ N ) {
$ r_xor ; $ c_xor ; $ max_xor = 0 ;
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { $ r_xor = 0 ; $ c_xor = 0 ; for ( $ j = 0 ; $ j < $ N ; $ j ++ ) {
$ r_xor = $ r_xor ^ $ mat [ $ i ] [ $ j ] ;
$ c_xor = $ c_xor ^ $ mat [ $ j ] [ $ i ] ; }
if ( $ max_xor < max ( $ r_xor , $ c_xor ) ) $ max_xor = max ( $ r_xor , $ c_xor ) ; }
return $ max_xor ; }
$ N = 3 ; $ mat = array ( array ( 1 , 5 , 4 ) , array ( 3 , 7 , 2 ) , array ( 5 , 9 , 10 ) ) ; echo " maximum ▁ XOR ▁ value ▁ : ▁ " , maxXOR ( $ mat , $ N ) ; ? >
function direction ( $ R , $ C ) { if ( $ R != $ C && $ R % 2 == 0 && $ C % 2 != 0 && $ R < $ C ) { echo " Left " , " STRNEWLINE " ; return ; } if ( $ R != $ C && $ R % 2 != 0 && $ C % 2 == 0 && $ R > $ C ) { echo " Up " , " STRNEWLINE " ; return ; } if ( $ R == $ C && $ R % 2 != 0 && $ C % 2 != 0 ) { echo " Right " , " STRNEWLINE " ; return ; } if ( $ R == $ C && $ R % 2 == 0 && $ C % 2 == 0 ) { echo " Left " , " STRNEWLINE " ; return ; } if ( $ R != $ C && $ R % 2 != 0 && $ C % 2 != 0 && $ R < $ C ) { echo " Right " , " STRNEWLINE " ; return ; } if ( $ R != $ C && $ R % 2 != 0 && $ C % 2 != 0 && $ R > $ C ) { echo " Down " , " STRNEWLINE " ; return ; } if ( $ R != $ C && $ R % 2 == 0 && $ C % 2 == 0 && $ R < $ C ) { echo " Left " , " STRNEWLINE " ; return ; } if ( $ R != $ C && $ R % 2 == 0 && $ C % 2 == 0 && $ R > $ C ) { echo " Up " , " STRNEWLINE " ; return ; } if ( $ R != $ C && $ R % 2 == 0 && $ C % 2 != 0 && $ R > $ C ) { echo " Down " , " STRNEWLINE " ; return ; } if ( $ R != $ C && $ R % 2 != 0 && $ C % 2 == 0 && $ R < $ C ) { echo " Right " , " STRNEWLINE " ; return ; } }
$ R = 3 ; $ C = 1 ; direction ( $ R , $ C ) ; ? >
function checkDiagonal ( $ mat , $ i , $ j ) { $ N = 5 ; $ M = 4 ; $ res = $ mat [ $ i ] [ $ j ] ; while ( ++ $ i < $ N && ++ $ j < $ M ) {
if ( $ mat [ $ i ] [ $ j ] != $ res ) return false ; }
return true ; }
function isToepliz ( $ mat ) { $ N = 5 ; $ M = 4 ;
for ( $ i = 0 ; $ i < $ M ; $ i ++ ) {
if ( ! checkDiagonal ( $ mat , 0 , $ i ) ) return false ; }
for ( $ i = 1 ; $ i < $ N ; $ i ++ ) {
if ( ! checkDiagonal ( $ mat , $ i , 0 ) ) return false ; }
return true ; }
$ mat = array ( array ( 6 , 7 , 8 , 9 ) , array ( 4 , 6 , 7 , 8 ) , array ( 1 , 4 , 6 , 7 ) , array ( 0 , 1 , 4 , 6 ) , array ( 2 , 0 , 1 , 4 ) ) ;
if ( isToepliz ( $ mat ) ) echo " Matrix ▁ is ▁ a ▁ Toepliz ▁ " ; else echo " Matrix ▁ is ▁ not ▁ a ▁ Toepliz ▁ " ; ? >
$ N = 5 ;
function countZeroes ( $ mat ) {
$ row = $ N - 1 ; $ col = 0 ;
$ count = 0 ; while ( $ col < $ N ) {
while ( $ mat [ $ row ] [ $ col ] )
if ( -- $ row < 0 ) return $ count ;
$ count += ( $ row + 1 ) ;
$ col ++ ; } return $ count ; }
$ mat = array ( array ( 0 , 0 , 0 , 0 , 1 ) , array ( 0 , 0 , 0 , 1 , 1 ) , array ( 0 , 1 , 1 , 1 , 1 ) , array ( 1 , 1 , 1 , 1 , 1 ) , array ( 1 , 1 , 1 , 1 , 1 ) ) ; echo countZeroes ( $ mat ) ; ? >
function countNegative ( $ M , $ n , $ m ) { $ count = 0 ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ m ; $ j ++ ) { if ( $ M [ $ i ] [ $ j ] < 0 ) $ count += 1 ;
else break ; } } return $ count ; }
$ M = array ( array ( -3 , -2 , -1 , 1 ) , array ( -2 , 2 , 3 , 4 ) , array ( 4 , 5 , 7 , 8 ) ) ; echo countNegative ( $ M , 3 , 4 ) ; ? >
function countNegative ( $ M , $ n , $ m ) {
$ count = 0 ;
$ i = 0 ; $ j = $ m - 1 ;
while ( $ j >= 0 and $ i < $ n ) { if ( $ M [ $ i ] [ $ j ] < 0 ) {
$ count += $ j + 1 ;
$ i += 1 ; }
else $ j -= 1 ; } return $ count ; }
$ M = array ( array ( -3 , -2 , -1 , 1 ) , array ( -2 , 2 , 3 , 4 ) , array ( 4 , 5 , 7 , 8 ) ) ; echo countNegative ( $ M , 3 , 4 ) ; return 0 ; ? >
$ N = 10 ;
function findLargestPlus ( $ mat ) { global $ N ;
$ left [ $ N ] [ $ N ] = array ( ) ; $ right [ $ N ] [ $ N ] = array ( ) ; $ top [ $ N ] [ $ N ] = array ( ) ; $ bottom [ $ N ] [ $ N ] = array ( ) ;
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) {
$ top [ 0 ] [ $ i ] = $ mat [ 0 ] [ $ i ] ;
$ bottom [ $ N - 1 ] [ $ i ] = $ mat [ $ N - 1 ] [ $ i ] ;
$ left [ $ i ] [ 0 ] = $ mat [ $ i ] [ 0 ] ;
$ right [ $ i ] [ $ N - 1 ] = $ mat [ $ i ] [ $ N - 1 ] ; }
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { for ( $ j = 1 ; $ j < $ N ; $ j ++ ) {
if ( $ mat [ $ i ] [ $ j ] == 1 ) $ left [ $ i ] [ $ j ] = $ left [ $ i ] [ $ j - 1 ] + 1 ; else $ left [ $ i ] [ $ j ] = 0 ;
if ( $ mat [ $ j ] [ $ i ] == 1 ) $ top [ $ j ] [ $ i ] = $ top [ $ j - 1 ] [ $ i ] + 1 ; else $ top [ $ j ] [ $ i ] = 0 ;
$ j = $ N - 1 - $ j ;
if ( $ mat [ $ j ] [ $ i ] == 1 ) $ bottom [ $ j ] [ $ i ] = $ bottom [ $ j + 1 ] [ $ i ] + 1 ; else $ bottom [ $ j ] [ $ i ] = 0 ;
if ( $ mat [ $ i ] [ $ j ] == 1 ) $ right [ $ i ] [ $ j ] = $ right [ $ i ] [ $ j + 1 ] + 1 ; else $ right [ $ i ] [ $ j ] = 0 ;
$ j = $ N - 1 - $ j ; } }
$ n = 0 ;
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { for ( $ j = 0 ; $ j < $ N ; $ j ++ ) {
$ len = min ( min ( $ top [ $ i ] [ $ j ] , $ bottom [ $ i ] [ $ j ] ) , min ( $ left [ $ i ] [ $ j ] , $ right [ $ i ] [ $ j ] ) ) ;
if ( $ len > $ n ) $ n = $ len ; } }
if ( $ n ) return 4 * ( $ n - 1 ) + 1 ;
return 0 ; }
$ mat = array ( array ( 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 ) , array ( 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 ) , array ( 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 ) , array ( 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 ) , array ( 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 ) , array ( 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 ) , array ( 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 ) , array ( 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 ) , array ( 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 ) , array ( 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 ) ) ; echo findLargestPlus ( $ mat ) ; ? >
function findLeft ( $ str ) { $ n = strlen ( $ str ) ;
while ( $ n -- ) {
if ( $ str [ $ n ] == ' d ' ) { $ str [ $ n ] = ' c ' ; break ; } if ( $ str [ $ n ] == ' b ' ) { $ str [ $ n ] = ' a ' ; break ; }
if ( $ str [ $ n ] == ' a ' ) $ str [ $ n ] = ' b ' ; else if ( $ str [ $ n ] == ' c ' ) $ str [ $ n ] = ' d ' ; } return $ str ; }
$ str = " aacbddc " ; echo " Left ▁ of ▁ " . $ str . " ▁ is ▁ " . findLeft ( $ str ) ; return 0 ; ? >
function printSpiral ( $ n ) { for ( $ i = 0 ; $ i < $ n ; $ i ++ ) { for ( $ j = 0 ; $ j < $ n ; $ j ++ ) {
$ x ;
$ x = min ( min ( $ i , $ j ) , min ( $ n - 1 - $ i , $ n - 1 - $ j ) ) ;
if ( $ i <= $ j ) echo " TABSYMBOL ▁ " , ( $ n - 2 * $ x ) * ( $ n - 2 * $ x ) - ( $ i - $ x ) - ( $ j - $ x ) ;
else echo " TABSYMBOL ▁ " , ( $ n - 2 * $ x - 2 ) * ( $ n - 2 * $ x - 2 ) + ( $ i - $ x ) + ( $ j - $ x ) ; } echo " " } }
$ n = 5 ;
printSpiral ( $ n ) ; ? >
$ N = 5 ;
function findMaxValue ( & $ mat ) { global $ N ;
$ maxValue = PHP_INT_MIN ;
for ( $ a = 0 ; $ a < $ N - 1 ; $ a ++ ) for ( $ b = 0 ; $ b < $ N - 1 ; $ b ++ ) for ( $ d = $ a + 1 ; $ d < $ N ; $ d ++ ) for ( $ e = $ b + 1 ; $ e < $ N ; $ e ++ ) if ( $ maxValue < ( $ mat [ $ d ] [ $ e ] - $ mat [ $ a ] [ $ b ] ) ) $ maxValue = $ mat [ $ d ] [ $ e ] - $ mat [ $ a ] [ $ b ] ; return $ maxValue ; }
$ mat = array ( array ( 1 , 2 , -1 , -4 , -20 ) , array ( -8 , -3 , 4 , 2 , 1 ) , array ( 3 , 8 , 6 , 1 , 3 ) , array ( -4 , -1 , 1 , 7 , -6 ) , array ( 0 , -4 , 10 , -5 , 1 ) ) ; echo " Maximum ▁ Value ▁ is ▁ " . findMaxValue ( $ mat ) ; ? >
$ N = 5 ;
function findMaxValue ( $ mat ) { global $ N ;
$ maxValue = PHP_INT_MIN ;
$ maxArr [ $ N ] [ $ N ] = array ( ) ;
$ maxArr [ $ N - 1 ] [ $ N - 1 ] = $ mat [ $ N - 1 ] [ $ N - 1 ] ;
$ maxv = $ mat [ $ N - 1 ] [ $ N - 1 ] ; for ( $ j = $ N - 2 ; $ j >= 0 ; $ j -- ) { if ( $ mat [ $ N - 1 ] [ $ j ] > $ maxv ) $ maxv = $ mat [ $ N - 1 ] [ $ j ] ; $ maxArr [ $ N - 1 ] [ $ j ] = $ maxv ; }
$ maxv = $ mat [ $ N - 1 ] [ $ N - 1 ] ; for ( $ i = $ N - 2 ; $ i >= 0 ; $ i -- ) { if ( $ mat [ $ i ] [ $ N - 1 ] > $ maxv ) $ maxv = $ mat [ $ i ] [ $ N - 1 ] ; $ maxArr [ $ i ] [ $ N - 1 ] = $ maxv ; }
for ( $ i = $ N - 2 ; $ i >= 0 ; $ i -- ) { for ( $ j = $ N - 2 ; $ j >= 0 ; $ j -- ) {
if ( $ maxArr [ $ i + 1 ] [ $ j + 1 ] - $ mat [ $ i ] [ $ j ] > $ maxValue ) $ maxValue = $ maxArr [ $ i + 1 ] [ $ j + 1 ] - $ mat [ $ i ] [ $ j ] ;
$ maxArr [ $ i ] [ $ j ] = max ( $ mat [ $ i ] [ $ j ] , max ( $ maxArr [ $ i ] [ $ j + 1 ] , $ maxArr [ $ i + 1 ] [ $ j ] ) ) ; } } return $ maxValue ; }
$ mat = array ( array ( 1 , 2 , -1 , -4 , -20 ) , array ( -8 , -3 , 4 , 2 , 1 ) , array ( 3 , 8 , 6 , 1 , 3 ) , array ( -4 , -1 , 1 , 7 , -6 ) , array ( 0 , -4 , 10 , -5 , 1 ) ) ; echo " Maximum ▁ Value ▁ is ▁ " . findMaxValue ( $ mat ) ; ? >
$ R = 3 ; $ C = 4 ; function modifyMatrix ( & $ mat ) { global $ R , $ C ; $ row = array ( ) ; $ col = array ( ) ;
for ( $ i = 0 ; $ i < $ R ; $ i ++ ) { $ row [ $ i ] = 0 ; }
for ( $ i = 0 ; $ i < $ C ; $ i ++ ) { $ col [ $ i ] = 0 ; }
for ( $ i = 0 ; $ i < $ R ; $ i ++ ) { for ( $ j = 0 ; $ j < $ C ; $ j ++ ) { if ( $ mat [ $ i ] [ $ j ] == 1 ) { $ row [ $ i ] = 1 ; $ col [ $ j ] = 1 ; } } }
for ( $ i = 0 ; $ i < $ R ; $ i ++ ) { for ( $ j = 0 ; $ j < $ C ; $ j ++ ) { if ( $ row [ $ i ] == 1 $ col [ $ j ] == 1 ) { $ mat [ $ i ] [ $ j ] = 1 ; } } } }
function printMatrix ( & $ mat ) { global $ R , $ C ; for ( $ i = 0 ; $ i < $ R ; $ i ++ ) { for ( $ j = 0 ; $ j < $ C ; $ j ++ ) { echo $ mat [ $ i ] [ $ j ] . " " ; } echo " STRNEWLINE " ; } }
$ mat = array ( array ( 1 , 0 , 0 , 1 ) , array ( 0 , 0 , 1 , 0 ) , array ( 0 , 0 , 0 , 0 ) ) ; echo " Input ▁ Matrix ▁ STRNEWLINE " ; printMatrix ( $ mat ) ; modifyMatrix ( $ mat ) ; echo " Matrix ▁ after ▁ modification ▁ STRNEWLINE " ; printMatrix ( $ mat ) ; ? >
$ R = 3 ; $ C = 4 ; function modifyMatrix ( & $ mat ) { global $ R , $ C ;
$ row_flag = false ; $ col_flag = false ;
for ( $ i = 0 ; $ i < $ R ; $ i ++ ) { for ( $ j = 0 ; $ j < $ C ; $ j ++ ) { if ( $ i == 0 && $ mat [ $ i ] [ $ j ] == 1 ) $ row_flag = true ; if ( $ j == 0 && $ mat [ $ i ] [ $ j ] == 1 ) $ col_flag = true ; if ( $ mat [ $ i ] [ $ j ] == 1 ) { $ mat [ 0 ] [ $ j ] = 1 ; $ mat [ $ i ] [ 0 ] = 1 ; } } }
for ( $ i = 1 ; $ i < $ R ; $ i ++ ) { for ( $ j = 1 ; $ j < $ C ; $ j ++ ) { if ( $ mat [ 0 ] [ $ j ] == 1 $ mat [ $ i ] [ 0 ] == 1 ) { $ mat [ $ i ] [ $ j ] = 1 ; } } }
if ( $ row_flag == true ) { for ( $ i = 0 ; $ i < $ C ; $ i ++ ) { $ mat [ 0 ] [ $ i ] = 1 ; } }
if ( $ col_flag == true ) { for ( $ i = 0 ; $ i < $ R ; $ i ++ ) { $ mat [ $ i ] [ 0 ] = 1 ; } } }
function printMatrix ( & $ mat ) { global $ R , $ C ; for ( $ i = 0 ; $ i < $ R ; $ i ++ ) { for ( $ j = 0 ; $ j < $ C ; $ j ++ ) { echo $ mat [ $ i ] [ $ j ] . " " ; } echo " STRNEWLINE " ; } }
$ mat = array ( array ( 1 , 0 , 0 , 1 ) , array ( 0 , 0 , 1 , 0 ) , array ( 0 , 0 , 0 , 0 ) ) ; echo " Input ▁ Matrix ▁ : STRNEWLINE " ; printMatrix ( $ mat ) ; modifyMatrix ( $ mat ) ; echo " Matrix ▁ After ▁ Modification ▁ : STRNEWLINE " ; printMatrix ( $ mat ) ; ? >
function find ( & $ arr ) { $ n = 5 ;
$ i = 0 ; $ j = $ n - 1 ;
$ res = -1 ;
while ( $ i < $ n && $ j >= 0 ) {
if ( $ arr [ $ i ] [ $ j ] == 0 ) {
while ( $ j >= 0 && ( $ arr [ $ i ] [ $ j ] == 0 $ i == $ j ) ) $ j -- ;
if ( $ j == -1 ) { $ res = $ i ; break ; }
else $ i ++ ; }
else {
while ( $ i < $ n && ( $ arr [ $ i ] [ $ j ] == 1 $ i == $ j ) ) $ i ++ ;
if ( $ i == $ n ) { $ res = $ j ; break ; }
else $ j -- ; } }
if ( $ res == -1 ) return $ res ;
for ( $ i = 0 ; $ i < $ n ; $ i ++ ) if ( $ res != $ i && $ arr [ $ i ] [ $ res ] != 1 ) return -1 ; for ( $ j = 0 ; $ j < $ n ; $ j ++ ) if ( $ res != $ j && $ arr [ $ res ] [ $ j ] != 0 ) return -1 ; return $ res ; }
$ mat = array ( array ( 0 , 0 , 1 , 1 , 0 ) , array ( 0 , 0 , 0 , 1 , 0 ) , array ( 1 , 1 , 1 , 1 , 0 ) , array ( 0 , 0 , 0 , 0 , 0 ) , array ( 1 , 1 , 1 , 1 , 1 ) ) ; echo ( find ( $ mat ) ) ; ? >
function preProcess ( & $ mat , & $ aux ) { $ M = 4 ; $ N = 5 ;
for ( $ i = 0 ; $ i < $ N ; $ i ++ ) $ aux [ 0 ] [ $ i ] = $ mat [ 0 ] [ $ i ] ;
for ( $ i = 1 ; $ i < $ M ; $ i ++ ) for ( $ j = 0 ; $ j < $ N ; $ j ++ ) $ aux [ $ i ] [ $ j ] = $ mat [ $ i ] [ $ j ] + $ aux [ $ i - 1 ] [ $ j ] ;
for ( $ i = 0 ; $ i < $ M ; $ i ++ ) for ( $ j = 1 ; $ j < $ N ; $ j ++ ) $ aux [ $ i ] [ $ j ] += $ aux [ $ i ] [ $ j - 1 ] ; }
function sumQuery ( & $ aux , $ tli , $ tlj , $ rbi , $ rbj ) {
$ res = $ aux [ $ rbi ] [ $ rbj ] ;
if ( $ tli > 0 ) $ res = $ res - $ aux [ $ tli - 1 ] [ $ rbj ] ;
if ( $ tlj > 0 ) $ res = $ res - $ aux [ $ rbi ] [ $ tlj - 1 ] ;
if ( $ tli > 0 && $ tlj > 0 ) $ res = $ res + $ aux [ $ tli - 1 ] [ $ tlj - 1 ] ; return $ res ; }
$ mat = array ( array ( 1 , 2 , 3 , 4 , 6 ) , array ( 5 , 3 , 8 , 1 , 2 ) , array ( 4 , 6 , 7 , 5 , 5 ) , array ( 2 , 4 , 8 , 9 , 4 ) ) ; preProcess ( $ mat , $ aux ) ; $ tli = 2 ; $ tlj = 2 ; $ rbi = 3 ; $ rbj = 4 ; echo ( " Query1 : ▁ " ) ; echo ( sumQuery ( $ aux , $ tli , $ tlj , $ rbi , $ rbj ) ) ; $ tli = 0 ; $ tlj = 0 ; $ rbi = 1 ; $ rbj = 1 ; echo ( " Query2 : " echo ( sumQuery ( $ aux , $ tli , $ tlj , $ rbi , $ rbj ) ) ; $ tli = 1 ; $ tlj = 2 ; $ rbi = 3 ; $ rbj = 3 ; echo ( " Query3 : " echo ( sumQuery ( $ aux , $ tli , $ tlj , $ rbi , $ rbj ) ) ; ? >
$ R = 3 ; $ C = 3 ;
function swap ( & $ mat , $ row1 , $ row2 , $ col ) { for ( $ i = 0 ; $ i < $ col ; $ i ++ ) { $ temp = $ mat [ $ row1 ] [ $ i ] ; $ mat [ $ row1 ] [ $ i ] = $ mat [ $ row2 ] [ $ i ] ; $ mat [ $ row2 ] [ $ i ] = $ temp ; } }
function rankOfMatrix ( $ mat ) { global $ R , $ C ; $ rank = $ C ; for ( $ row = 0 ; $ row < $ rank ; $ row ++ ) {
if ( $ mat [ $ row ] [ $ row ] ) { for ( $ col = 0 ; $ col < $ R ; $ col ++ ) { if ( $ col != $ row ) {
$ mult = $ mat [ $ col ] [ $ row ] / $ mat [ $ row ] [ $ row ] ; for ( $ i = 0 ; $ i < $ rank ; $ i ++ ) $ mat [ $ col ] [ $ i ] -= $ mult * $ mat [ $ row ] [ $ i ] ; } } }
else { $ reduce = true ;
for ( $ i = $ row + 1 ; $ i < $ R ; $ i ++ ) {
if ( $ mat [ $ i ] [ $ row ] ) { swap ( $ mat , $ row , $ i , $ rank ) ; $ reduce = false ; break ; } }
if ( $ reduce ) {
$ rank -- ;
for ( $ i = 0 ; $ i < $ R ; $ i ++ ) $ mat [ $ i ] [ $ row ] = $ mat [ $ i ] [ $ rank ] ; }
$ row -- ; }
} return $ rank ; }
function display ( $ mat , $ row , $ col ) { for ( $ i = 0 ; $ i < $ row ; $ i ++ ) { for ( $ j = 0 ; $ j < $ col ; $ j ++ ) print ( " ▁ $ mat [ $ i ] [ $ j ] " ) ; print ( " STRNEWLINE " ) ; } }
$ mat = array ( array ( 10 , 20 , 10 ) , array ( -20 , -30 , 10 ) , array ( 30 , 50 , 0 ) ) ; print ( " Rank ▁ of ▁ the ▁ matrix ▁ is ▁ : ▁ " . rankOfMatrix ( $ mat ) ) ; ? >
function countIslands ( $ mat ) { $ M = 6 ; $ N = 3 ;
$ count = 0 ;
for ( $ i = 0 ; $ i < $ M ; $ i ++ ) { for ( $ j = 0 ; $ j < $ N ; $ j ++ ) {
if ( $ mat [ $ i ] [ $ j ] == ' X ' ) { if ( ( $ i == 0 $ mat [ $ i - 1 ] [ $ j ] == ' O ' ) && ( $ j == 0 $ mat [ $ i ] [ $ j - 1 ] == ' O ' ) ) $ count ++ ; } } } return $ count ; }
$ mat = array ( array ( ' O ' , ' O ' , ' O ' ) , array ( ' X ' , ' X ' , ' O ' ) , array ( ' X ' , ' X ' , ' O ' ) , array ( ' O ' , ' O ' , ' X ' ) , array ( ' O ' , ' O ' , ' X ' ) , array ( ' X ' , ' X ' , ' O ' ) ) ; echo " Number ▁ of ▁ rectangular ▁ islands ▁ is ▁ " , countIslands ( $ mat ) ; ? >
$ M = 6 ; $ N = 6 ;
function floodFillUtil ( & $ mat , $ x , $ y , $ prevV , $ newV ) {
if ( $ x < 0 $ x >= $ GLOBALS [ ' M ' ] $ y < 0 $ y >= $ GLOBALS [ ' N ' ] ) return ; if ( $ mat [ $ x ] [ $ y ] != $ prevV ) return ;
$ mat [ $ x ] [ $ y ] = $ newV ;
floodFillUtil ( $ mat , $ x + 1 , $ y , $ prevV , $ newV ) ; floodFillUtil ( $ mat , $ x - 1 , $ y , $ prevV , $ newV ) ; floodFillUtil ( $ mat , $ x , $ y + 1 , $ prevV , $ newV ) ; floodFillUtil ( $ mat , $ x , $ y - 1 , $ prevV , $ newV ) ; }
function replaceSurrounded ( & $ mat ) {
for ( $ i = 0 ; $ i < $ GLOBALS [ ' M ' ] ; $ i ++ ) for ( $ j = 0 ; $ j < $ GLOBALS [ ' N ' ] ; $ j ++ ) if ( $ mat [ $ i ] [ $ j ] == ' O ' ) $ mat [ $ i ] [ $ j ] = ' - ' ;
for ( $ i = 0 ; $ i < $ GLOBALS [ ' M ' ] ; $ i ++ ) if ( $ mat [ $ i ] [ 0 ] == ' - ' ) floodFillUtil ( $ mat , $ i , 0 , ' - ' , ' O ' ) ;
for ( $ i = 0 ; $ i < $ GLOBALS [ ' M ' ] ; $ i ++ ) if ( $ mat [ $ i ] [ $ GLOBALS [ ' N ' ] - 1 ] == ' - ' ) floodFillUtil ( $ mat , $ i , $ GLOBALS [ ' N ' ] - 1 , ' - ' , ' O ' ) ;
for ( $ i = 0 ; $ i < $ GLOBALS [ ' N ' ] ; $ i ++ ) if ( $ mat [ 0 ] [ $ i ] == ' - ' ) floodFillUtil ( $ mat , 0 , $ i , ' - ' , ' O ' ) ;
for ( $ i = 0 ; $ i < $ GLOBALS [ ' N ' ] ; $ i ++ ) if ( $ mat [ $ GLOBALS [ ' M ' ] - 1 ] [ $ i ] == ' - ' ) floodFillUtil ( $ mat , $ GLOBALS [ ' M ' ] - 1 , $ i , ' - ' , ' O ' ) ;
for ( $ i = 0 ; $ i < $ GLOBALS [ ' M ' ] ; $ i ++ ) for ( $ j = 0 ; $ j < $ GLOBALS [ ' N ' ] ; $ j ++ ) if ( $ mat [ $ i ] [ $ j ] == ' - ' ) $ mat [ $ i ] [ $ j ] = ' X ' ; }
$ mat = array ( array ( ' X ' , ' O ' , ' X ' , ' O ' , ' X ' , ' X ' ) , array ( ' X ' , ' O ' , ' X ' , ' X ' , ' O ' , ' X ' ) , array ( ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' X ' ) , array ( ' O ' , ' X ' , ' X ' , ' X ' , ' X ' , ' X ' ) , array ( ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' O ' ) , array ( ' O ' , ' O ' , ' X ' , ' O ' , ' O ' , ' O ' ) ) ; replaceSurrounded ( $ mat ) ; for ( $ i = 0 ; $ i < $ GLOBALS [ ' M ' ] ; $ i ++ ) { for ( $ j = 0 ; $ j < $ GLOBALS [ ' N ' ] ; $ j ++ ) echo $ mat [ $ i ] [ $ j ] . " ▁ " ; echo " STRNEWLINE " ; } ? >
$ n = 5 ;
function printSumSimple ( $ mat , $ k ) { global $ n ;
if ( $ k > $ n ) return ;
for ( $ i = 0 ; $ i < $ n - $ k + 1 ; $ i ++ ) {
for ( $ j = 0 ; $ j < $ n - $ k + 1 ; $ j ++ ) {
$ sum = 0 ; for ( $ p = $ i ; $ p < $ k + $ i ; $ p ++ ) for ( $ q = $ j ; $ q < $ k + $ j ; $ q ++ ) $ sum += $ mat [ $ p ] [ $ q ] ; echo $ sum , " " ; }
echo " STRNEWLINE " ; } }
$ mat = array ( array ( 1 , 1 , 1 , 1 , 1 ) , array ( 2 , 2 , 2 , 2 , 2 , ) , array ( 3 , 3 , 3 , 3 , 3 , ) , array ( 4 , 4 , 4 , 4 , 4 , ) , array ( 5 , 5 , 5 , 5 , 5 ) ) ; $ k = 3 ; printSumSimple ( $ mat , $ k ) ; ? >
$ n = 5 ;
function printSumTricky ( $ mat , $ k ) { global $ n ;
if ( $ k > $ n ) return ;
$ stripSum = array ( array ( ) ) ;
for ( $ j = 0 ; $ j < $ n ; $ j ++ ) {
$ sum = 0 ; for ( $ i = 0 ; $ i < $ k ; $ i ++ ) $ sum += $ mat [ $ i ] [ $ j ] ; $ stripSum [ 0 ] [ $ j ] = $ sum ;
for ( $ i = 1 ; $ i < $ n - $ k + 1 ; $ i ++ ) { $ sum += ( $ mat [ $ i + $ k - 1 ] [ $ j ] - $ mat [ $ i - 1 ] [ $ j ] ) ; $ stripSum [ $ i ] [ $ j ] = $ sum ; } }
for ( $ i = 0 ; $ i < $ n - $ k + 1 ; $ i ++ ) {
$ sum = 0 ; for ( $ j = 0 ; $ j < $ k ; $ j ++ ) $ sum += $ stripSum [ $ i ] [ $ j ] ; echo $ sum , " " ;
for ( $ j = 1 ; $ j < $ n - $ k + 1 ; $ j ++ ) { $ sum += ( $ stripSum [ $ i ] [ $ j + $ k - 1 ] - $ stripSum [ $ i ] [ $ j - 1 ] ) ; echo $ sum , " " ; } echo " STRNEWLINE " ; } }
$ mat = array ( array ( 1 , 1 , 1 , 1 , 1 ) , array ( 2 , 2 , 2 , 2 , 2 ) , array ( 3 , 3 , 3 , 3 , 3 ) , array ( 4 , 4 , 4 , 4 , 4 ) , array ( 5 , 5 , 5 , 5 , 5 ) ) ; $ k = 3 ; printSumTricky ( $ mat , $ k ) ; ? >
$ N = 4 ; $ M = 3 ;
function transpose ( & $ A , & $ B ) { for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = 0 ; $ j < $ M ; $ j ++ ) $ B [ $ i ] [ $ j ] = $ A [ $ j ] [ $ i ] ; }
$ A = array ( array ( 1 , 1 , 1 , 1 ) , array ( 2 , 2 , 2 , 2 ) , array ( 3 , 3 , 3 , 3 ) ) ; $ N = 4 ; $ M = 3 ; transpose ( $ A , $ B ) ; echo " Result ▁ matrix ▁ is ▁ STRNEWLINE " ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { for ( $ j = 0 ; $ j < $ M ; $ j ++ ) { echo $ B [ $ i ] [ $ j ] ; echo " ▁ " ; } echo " STRNEWLINE " ; } ? >
$ N = 4 ;
function transpose ( & $ A ) { for ( $ i = 0 ; $ i < $ N ; $ i ++ ) for ( $ j = $ i + 1 ; $ j < $ N ; $ j ++ ) { $ temp = $ A [ $ i ] [ $ j ] ; $ A [ $ i ] [ $ j ] = $ A [ $ j ] [ $ i ] ; $ A [ $ j ] [ $ i ] = $ temp ; } }
$ N = 4 ; $ A = array ( array ( 1 , 1 , 1 , 1 ) , array ( 2 , 2 , 2 , 2 ) , array ( 3 , 3 , 3 , 3 ) , array ( 4 , 4 , 4 , 4 ) ) ; transpose ( $ A ) ; echo " Modified ▁ matrix ▁ is ▁ " . " STRNEWLINE " ; for ( $ i = 0 ; $ i < $ N ; $ i ++ ) { for ( $ j = 0 ; $ j < $ N ; $ j ++ ) echo $ A [ $ i ] [ $ j ] . " ▁ " ; echo " STRNEWLINE " ; } ? >
$ R = 3 ; $ C = 3 ;
function pathCountRec ( $ mat , $ m , $ n , $ k ) {
if ( $ m < 0 or $ n < 0 ) return 0 ; if ( $ m == 0 and $ n == 0 ) return ( $ k == $ mat [ $ m ] [ $ n ] ) ;
return pathCountRec ( $ mat , $ m - 1 , $ n , $ k - $ mat [ $ m ] [ $ n ] ) + pathCountRec ( $ mat , $ m , $ n - 1 , $ k - $ mat [ $ m ] [ $ n ] ) ; }
function pathCount ( $ mat , $ k ) { global $ R , $ C ; return pathCountRec ( $ mat , $ R - 1 , $ C - 1 , $ k ) ; }
$ k = 12 ; $ mat = array ( array ( 1 , 2 , 3 ) , array ( 4 , 6 , 5 ) , array ( 3 , 2 , 1 ) ) ; echo pathCount ( $ mat , $ k ) ; ? >
$ R = 3 ; $ C = 3 ;
$ x = array ( 0 , 1 , 1 , -1 , 1 , 0 , -1 , -1 ) ; $ y = array ( 1 , 0 , 1 , 1 , -1 , -1 , 0 , -1 ) ;
$ dp = array_fill ( 0 , $ R , array_fill ( 0 , $ C , -1 ) ) ;
function isvalid ( $ i , $ j ) { global $ R , $ C ; if ( $ i < 0 $ j < 0 $ i >= $ R $ j >= $ C ) return false ; return true ; }
function isadjacent ( $ prev , $ curr ) { return ( ( ord ( $ curr ) - ord ( $ prev ) ) == 1 ) ; }
function getLenUtil ( $ mat , $ i , $ j , $ prev ) { global $ x , $ y , $ dp ;
if ( ! isvalid ( $ i , $ j ) || ! isadjacent ( $ prev , $ mat [ $ i ] [ $ j ] ) ) return 0 ;
if ( $ dp [ $ i ] [ $ j ] != -1 ) return $ dp [ $ i ] [ $ j ] ;
$ ans = 0 ;
for ( $ k = 0 ; $ k < 8 ; $ k ++ ) $ ans = max ( $ ans , 1 + getLenUtil ( $ mat , $ i + $ x [ $ k ] , $ j + $ y [ $ k ] , $ mat [ $ i ] [ $ j ] ) ) ;
$ dp [ $ i ] [ $ j ] = $ ans ; return $ ans ; }
function getLen ( $ mat , $ s ) { global $ R , $ C , $ x , $ y ; $ ans = 0 ; for ( $ i = 0 ; $ i < $ R ; $ i ++ ) { for ( $ j = 0 ; $ j < $ C ; $ j ++ ) {
if ( $ mat [ $ i ] [ $ j ] == $ s ) {
for ( $ k = 0 ; $ k < 8 ; $ k ++ ) $ ans = max ( $ ans , 1 + getLenUtil ( $ mat , $ i + $ x [ $ k ] , $ j + $ y [ $ k ] , $ s ) ) ; } } } return $ ans ; }
$ mat = array ( array ( ' a ' , ' c ' , ' d ' ) , array ( ' h ' , ' b ' , ' a ' ) , array ( ' i ' , ' g ' , ' f ' ) ) ; print ( getLen ( $ mat , ' a ' ) . " " ) ; print ( getLen ( $ mat , ' e ' ) . " " ) ; print ( getLen ( $ mat , ' b ' ) . " " ) ; print ( getLen ( $ mat , ' f ' ) . " " ) ; ? >
$ R = 3 ; $ C = 3 ; function minInitialPoints ( $ points ) {
global $ R ; global $ C ; $ dp [ $ R ] [ $ C ] = array ( ) ; $ m = $ R ; $ n = $ C ;
$ dp [ $ m - 1 ] [ $ n - 1 ] = $ points [ $ m - 1 ] [ $ n - 1 ] > 0 ? 1 : abs ( $ points [ $ m - 1 ] [ $ n - 1 ] ) + 1 ;
for ( $ i = $ m - 2 ; $ i >= 0 ; $ i -- ) $ dp [ $ i ] [ $ n - 1 ] = max ( $ dp [ $ i + 1 ] [ $ n - 1 ] - $ points [ $ i ] [ $ n - 1 ] , 1 ) ; for ( $ j = $ n - 2 ; $ j >= 0 ; $ j -- ) $ dp [ $ m - 1 ] [ $ j ] = max ( $ dp [ $ m - 1 ] [ $ j + 1 ] - $ points [ $ m - 1 ] [ $ j ] , 1 ) ;
for ( $ i = $ m - 2 ; $ i >= 0 ; $ i -- ) { for ( $ j = $ n - 2 ; $ j >= 0 ; $ j -- ) { $ min_points_on_exit = min ( $ dp [ $ i + 1 ] [ $ j ] , $ dp [ $ i ] [ $ j + 1 ] ) ; $ dp [ $ i ] [ $ j ] = max ( $ min_points_on_exit - $ points [ $ i ] [ $ j ] , 1 ) ; } } return $ dp [ 0 ] [ 0 ] ; }
$ points = array ( array ( -2 , -3 , 3 ) , array ( -5 , -10 , 1 ) , array ( 10 , 30 , -5 ) ) ; echo " Minimum ▁ Initial ▁ Points ▁ Required : ▁ " , minInitialPoints ( $ points ) ; ? >
