struct node { int data ; struct node * left ; struct node * right ; } ;
bool IsFoldable ( struct node * root ) { if ( root == NULL ) { return true ; } return IsFoldableUtil ( root -> left , root -> right ) ; }
bool IsFoldableUtil ( struct node * n1 , struct node * n2 ) {
if ( n1 == NULL && n2 == NULL ) { return true ; }
if ( n1 == NULL n2 == NULL ) { return false ; }
return IsFoldableUtil ( n1 -> left , n2 -> right ) && IsFoldableUtil ( n1 -> right , n2 -> left ) ; }
int main ( void ) {
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> right = newNode ( 4 ) ; root -> right -> left = newNode ( 5 ) ; if ( IsFoldable ( root ) == true ) { printf ( " tree is foldable " } else { printf ( " tree is not foldable " } getchar ( ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ;
struct node { int data ; struct node * left , * right ; } ;
int updatetree ( node * root ) {
if ( ! root ) return 0 ; if ( root -> left == NULL && root -> right == NULL ) return root -> data ;
int leftsum = updatetree ( root -> left ) ; int rightsum = updatetree ( root -> right ) ;
root -> data += leftsum ;
return root -> data + rightsum ; }
void inorder ( struct node * node ) { if ( node == NULL ) return ; inorder ( node -> left ) ; printf ( " % d ▁ " , node -> data ) ; inorder ( node -> right ) ; }
int main ( ) {
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; updatetree ( root ) ; cout << " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ is ▁ STRNEWLINE " ; inorder ( root ) ; return 0 ; }
struct Node * newNode ( int data ) { struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
void mirror ( struct Node * node ) { if ( node == NULL ) return ; else { struct Node * temp ;
mirror ( node -> left ) ; mirror ( node -> right ) ;
temp = node -> left ; node -> left = node -> right ; node -> right = temp ; } }
void inOrder ( struct Node * node ) { if ( node == NULL ) return ; inOrder ( node -> left ) ; printf ( " % d ▁ " , node -> data ) ; inOrder ( node -> right ) ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ;
printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ constructed " " ▁ tree ▁ is ▁ STRNEWLINE " ) ; inOrder ( root ) ;
mirror ( root ) ;
printf ( " Inorder traversal of the mirror tree " ▁ " is " inOrder ( root ) ; return 0 ; }
int isSumProperty ( struct node * node ) {
int left_data = 0 , right_data = 0 ;
if ( node == NULL || ( node -> left == NULL && node -> right == NULL ) ) return 1 ; else {
if ( node -> left != NULL ) left_data = node -> left -> data ;
if ( node -> right != NULL ) right_data = node -> right -> data ;
if ( ( node -> data == left_data + right_data ) && isSumProperty ( node -> left ) && isSumProperty ( node -> right ) ) return 1 ; else return 0 ; } }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( ) { struct node * root = newNode ( 10 ) ; root -> left = newNode ( 8 ) ; root -> right = newNode ( 2 ) ; root -> left -> left = newNode ( 3 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 2 ) ; if ( isSumProperty ( root ) ) printf ( " The ▁ given ▁ tree ▁ satisfies ▁ the ▁ children ▁ sum ▁ property ▁ " ) ; else printf ( " The ▁ given ▁ tree ▁ does ▁ not ▁ satisfy ▁ the ▁ children ▁ sum ▁ property ▁ " ) ; getchar ( ) ; return 0 ; }
struct Node { int data ; struct Node * left , * right ; } ;
int isSibling ( struct Node * root , struct Node * a , struct Node * b ) {
if ( root == NULL ) return 0 ; return ( ( root -> left == a && root -> right == b ) || ( root -> left == b && root -> right == a ) || isSibling ( root -> left , a , b ) || isSibling ( root -> right , a , b ) ) ; }
int level ( struct Node * root , struct Node * ptr , int lev ) {
if ( root == NULL ) return 0 ; if ( root == ptr ) return lev ;
int l = level ( root -> left , ptr , lev + 1 ) ; if ( l != 0 ) return l ;
return level ( root -> right , ptr , lev + 1 ) ; }
int isCousin ( struct Node * root , struct Node * a , struct Node * b ) {
if ( ( level ( root , a , 1 ) == level ( root , b , 1 ) ) && ! ( isSibling ( root , a , b ) ) ) return 1 ; else return 0 ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> left -> right -> right = newNode ( 15 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> right -> left -> right = newNode ( 8 ) ; struct Node * Node1 , * Node2 ; Node1 = root -> left -> left ; Node2 = root -> right -> right ; isCousin ( root , Node1 , Node2 ) ? puts ( " Yes " ) : puts ( " No " ) ; return 0 ; }
struct Node { int data ; struct Node * left , * right ; } ;
bool checkUtil ( struct Node * root , int level , int * leafLevel ) {
if ( root == NULL ) return true ;
if ( root -> left == NULL && root -> right == NULL ) {
if ( * leafLevel == 0 ) {
* leafLevel = level ; return true ; }
return ( level == * leafLevel ) ; }
return checkUtil ( root -> left , level + 1 , leafLevel ) && checkUtil ( root -> right , level + 1 , leafLevel ) ; }
bool check ( struct Node * root ) { int level = 0 , leafLevel = 0 ; return checkUtil ( root , level , & leafLevel ) ; }
struct Node * root = newNode ( 12 ) ; root -> left = newNode ( 5 ) ; root -> left -> left = newNode ( 3 ) ; root -> left -> right = newNode ( 9 ) ; root -> left -> left -> left = newNode ( 1 ) ; root -> left -> right -> left = newNode ( 1 ) ; if ( check ( root ) ) printf ( " Leaves ▁ are ▁ at ▁ same ▁ level STRNEWLINE " ) ; else printf ( " Leaves ▁ are ▁ not ▁ at ▁ same ▁ level STRNEWLINE " ) ; getchar ( ) ; return 0 ; }
struct Node { int key ; struct Node * left , * right ; } ;
bool isFullTree ( struct Node * root ) {
if ( root == NULL ) return true ;
if ( root -> left == NULL && root -> right == NULL ) return true ;
if ( ( root -> left ) && ( root -> right ) ) return ( isFullTree ( root -> left ) && isFullTree ( root -> right ) ) ;
return false ; }
int main ( ) { struct Node * root = NULL ; root = newNode ( 10 ) ; root -> left = newNode ( 20 ) ; root -> right = newNode ( 30 ) ; root -> left -> right = newNode ( 40 ) ; root -> left -> left = newNode ( 50 ) ; root -> right -> left = newNode ( 60 ) ; root -> right -> right = newNode ( 70 ) ; root -> left -> left -> left = newNode ( 80 ) ; root -> left -> left -> right = newNode ( 90 ) ; root -> left -> right -> left = newNode ( 80 ) ; root -> left -> right -> right = newNode ( 90 ) ; root -> right -> left -> left = newNode ( 80 ) ; root -> right -> left -> right = newNode ( 90 ) ; root -> right -> right -> left = newNode ( 80 ) ; root -> right -> right -> right = newNode ( 90 ) ; if ( isFullTree ( root ) ) printf ( " The ▁ Binary ▁ Tree ▁ is ▁ full STRNEWLINE " ) ; else printf ( " The ▁ Binary ▁ Tree ▁ is ▁ not ▁ full STRNEWLINE " ) ; return ( 0 ) ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
int identicalTrees ( struct node * a , struct node * b ) {
if ( a == NULL && b == NULL ) return 1 ;
if ( a != NULL && b != NULL ) { return ( a -> data == b -> data && identicalTrees ( a -> left , b -> left ) && identicalTrees ( a -> right , b -> right ) ) ; }
return 0 ; }
int main ( ) { struct node * root1 = newNode ( 1 ) ; struct node * root2 = newNode ( 1 ) ; root1 -> left = newNode ( 2 ) ; root1 -> right = newNode ( 3 ) ; root1 -> left -> left = newNode ( 4 ) ; root1 -> left -> right = newNode ( 5 ) ; root2 -> left = newNode ( 2 ) ; root2 -> right = newNode ( 3 ) ; root2 -> left -> left = newNode ( 4 ) ; root2 -> left -> right = newNode ( 5 ) ; if ( identicalTrees ( root1 , root2 ) ) printf ( " Both ▁ tree ▁ are ▁ identical . " ) ; else printf ( " Trees ▁ are ▁ not ▁ identical . " ) ; getchar ( ) ; return 0 ; }
bool areElementsContiguous ( int arr [ ] , int n ) {
sort ( arr , arr + n ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] > 1 ) return false ; return true ; }
int main ( ) { int arr [ ] = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; if ( areElementsContiguous ( arr , n ) ) cout << " Yes " ; else cout << " No " ; return 0 ; }
Node * newNode ( int item ) { Node * temp = new Node ; temp -> data = item ; temp -> left = temp -> right = NULL ; return temp ; }
int getLevel ( Node * root , Node * node , int level ) {
if ( root == NULL ) return 0 ; if ( root == node ) return level ;
int downlevel = getLevel ( root -> left , node , level + 1 ) ; if ( downlevel != 0 ) return downlevel ;
return getLevel ( root -> right , node , level + 1 ) ; }
void printGivenLevel ( Node * root , Node * node , int level ) {
if ( root == NULL level < 2 ) return ;
if ( level == 2 ) { if ( root -> left == node root -> right == node ) return ; if ( root -> left ) printf ( " % d ▁ " , root -> left -> data ) ; if ( root -> right ) printf ( " % d ▁ " , root -> right -> data ) ; }
else if ( level > 2 ) { printGivenLevel ( root -> left , node , level - 1 ) ; printGivenLevel ( root -> right , node , level - 1 ) ; } }
void printCousins ( Node * root , Node * node ) {
int level = getLevel ( root , node , 1 ) ;
printGivenLevel ( root , node , level ) ; }
int main ( ) { Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> left -> right -> right = newNode ( 15 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> right -> left -> right = newNode ( 8 ) ; printCousins ( root , root -> left -> right ) ; return 0 ; }
void printArray ( int arr [ ] , int size ) ; void swap ( int arr [ ] , int fi , int si , int d ) ; void leftRotate ( int arr [ ] , int d , int n ) {
if ( d == 0 d == n ) return ;
if ( n - d == d ) { swap ( arr , 0 , n - d , d ) ; return ; }
if ( d < n - d ) { swap ( arr , 0 , n - d , d ) ; leftRotate ( arr , d , n - d ) ; }
else { swap ( arr , 0 , d , n - d ) ; leftRotate ( arr + n - d , 2 * d - n , d ) ; } }
void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; printf ( " STRNEWLINE ▁ " ) ; }
void swap ( int arr [ ] , int fi , int si , int d ) { int i , temp ; for ( i = 0 ; i < d ; i ++ ) { temp = arr [ fi + i ] ; arr [ fi + i ] = arr [ si + i ] ; arr [ si + i ] = temp ; } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; leftRotate ( arr , 2 , 7 ) ; printArray ( arr , 7 ) ; getchar ( ) ; return 0 ; }
void leftRotate ( int arr [ ] , int d , int n ) { int i , j ; if ( d == 0 d == n ) return ; i = d ; j = n - d ; while ( i != j ) {
if ( i < j ) { swap ( arr , d - i , d + j - i , i ) ; j -= i ; }
else { swap ( arr , d - i , d , j ) ; i -= j ; } }
swap ( arr , d - i , d , i ) ; }
void rotate ( int arr [ ] , int n ) { int i = 0 , j = n - 1 ; while ( i != j ) { swap ( & arr [ i ] , & arr [ j ] ) ; i ++ ; } }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } , i ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Given ▁ array ▁ is STRNEWLINE " ) ; for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; rotate ( arr , n ) ; printf ( " Rotated array is " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; return 0 ; }
void rearrangeNaive ( int arr [ ] , int n ) {
int temp [ n ] , i ;
for ( i = 0 ; i < n ; i ++ ) temp [ arr [ i ] ] = i ;
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
void printArray ( int arr [ ] , int n ) { int i ; for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; printf ( " STRNEWLINE " ) ; }
int main ( ) { int arr [ ] = { 1 , 3 , 0 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " Given ▁ array ▁ is ▁ STRNEWLINE " ) ; printArray ( arr , n ) ; rearrangeNaive ( arr , n ) ; printf ( " Modified ▁ array ▁ is ▁ STRNEWLINE " ) ; printArray ( arr , n ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
void printPostorder ( struct node * node ) { if ( node == NULL ) return ;
printPostorder ( node -> left ) ;
printPostorder ( node -> right ) ;
printf ( " % d ▁ " , node -> data ) ; }
void printInorder ( struct node * node ) { if ( node == NULL ) return ;
printInorder ( node -> left ) ;
printf ( " % d ▁ " , node -> data ) ;
printInorder ( node -> right ) ; }
void printPreorder ( struct node * node ) { if ( node == NULL ) return ;
printf ( " % d ▁ " , node -> data ) ;
printPreorder ( node -> left ) ;
printPreorder ( node -> right ) ; }
int main ( ) { struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; printf ( " Preorder traversal of binary tree is " printPreorder ( root ) ; printf ( " Inorder traversal of binary tree is " printInorder ( root ) ; printf ( " Postorder traversal of binary tree is " printPostorder ( root ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE struct pair { int min ; int max ; } ; struct pair getMinMax ( int arr [ ] , int n ) { struct pair minmax ; int i ;
if ( n == 1 ) { minmax . max = arr [ 0 ] ; minmax . min = arr [ 0 ] ; return minmax ; }
if ( arr [ 0 ] > arr [ 1 ] ) { minmax . max = arr [ 0 ] ; minmax . min = arr [ 1 ] ; } else { minmax . max = arr [ 1 ] ; minmax . min = arr [ 0 ] ; } for ( i = 2 ; i < n ; i ++ ) { if ( arr [ i ] > minmax . max ) minmax . max = arr [ i ] ; else if ( arr [ i ] < minmax . min ) minmax . min = arr [ i ] ; } return minmax ; }
int main ( ) { int arr [ ] = { 1000 , 11 , 445 , 1 , 330 , 3000 } ; int arr_size = 6 ; struct pair minmax = getMinMax ( arr , arr_size ) ; printf ( " nMinimum ▁ element ▁ is ▁ % d " , minmax . min ) ; printf ( " nMaximum ▁ element ▁ is ▁ % d " , minmax . max ) ; getchar ( ) ; }
struct pair { int min ; int max ; } ; struct pair getMinMax ( int arr [ ] , int n ) { struct pair minmax ; int i ;
if ( n % 2 == 0 ) { if ( arr [ 0 ] > arr [ 1 ] ) { minmax . max = arr [ 0 ] ; minmax . min = arr [ 1 ] ; } else { minmax . min = arr [ 0 ] ; minmax . max = arr [ 1 ] ; }
i = 2 ; }
else { minmax . min = arr [ 0 ] ; minmax . max = arr [ 0 ] ;
i = 1 ; }
while ( i < n - 1 ) { if ( arr [ i ] > arr [ i + 1 ] ) { if ( arr [ i ] > minmax . max ) minmax . max = arr [ i ] ; if ( arr [ i + 1 ] < minmax . min ) minmax . min = arr [ i + 1 ] ; } else { if ( arr [ i + 1 ] > minmax . max ) minmax . max = arr [ i + 1 ] ; if ( arr [ i ] < minmax . min ) minmax . min = arr [ i ] ; } i += 2 ;
} return minmax ; }
int main ( ) { int arr [ ] = { 1000 , 11 , 445 , 1 , 330 , 3000 } ; int arr_size = 6 ; struct pair minmax = getMinMax ( arr , arr_size ) ; printf ( " nMinimum ▁ element ▁ is ▁ % d " , minmax . min ) ; printf ( " nMaximum ▁ element ▁ is ▁ % d " , minmax . max ) ; getchar ( ) ; }
int smallestSubWithSum ( int arr [ ] , int n , int x ) {
int min_len = n + 1 ;
for ( int start = 0 ; start < n ; start ++ ) {
int curr_sum = arr [ start ] ;
if ( curr_sum > x ) return 1 ;
for ( int end = start + 1 ; end < n ; end ++ ) {
curr_sum += arr [ end ] ;
if ( curr_sum > x && ( end - start + 1 ) < min_len ) min_len = ( end - start + 1 ) ; } } return min_len ; }
int main ( ) { int arr1 [ ] = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; ( res1 == n1 + 1 ) ? cout << " Not ▁ possible STRNEWLINE " : cout << res1 << endl ; int arr2 [ ] = { 1 , 10 , 5 , 2 , 7 } ; int n2 = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; ( res2 == n2 + 1 ) ? cout << " Not ▁ possible STRNEWLINE " : cout << res2 << endl ; int arr3 [ ] = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = sizeof ( arr3 ) / sizeof ( arr3 [ 0 ] ) ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; ( res3 == n3 + 1 ) ? cout << " Not ▁ possible STRNEWLINE " : cout << res3 << endl ; return 0 ; }
struct Node { int data ; struct Node * left , * right ; } ;
void print ( struct Node * root ) { if ( root != NULL ) { print ( root -> left ) ; printf ( " % d ▁ " , root -> data ) ; print ( root -> right ) ; } }
struct Node * prune ( struct Node * root , int sum ) {
if ( root == NULL ) return NULL ;
root -> left = prune ( root -> left , sum - root -> data ) ; root -> right = prune ( root -> right , sum - root -> data ) ;
if ( root -> left == NULL && root -> right == NULL ) { if ( root -> data < sum ) { free ( root ) ; return NULL ; } } return root ; }
int main ( ) { int k = 45 ; struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> left -> left -> left = newNode ( 8 ) ; root -> left -> left -> right = newNode ( 9 ) ; root -> left -> right -> left = newNode ( 12 ) ; root -> right -> right -> left = newNode ( 10 ) ; root -> right -> right -> left -> right = newNode ( 11 ) ; root -> left -> left -> right -> left = newNode ( 13 ) ; root -> left -> left -> right -> right = newNode ( 14 ) ; root -> left -> left -> right -> right -> left = newNode ( 15 ) ; printf ( " Tree ▁ before ▁ truncation STRNEWLINE " ) ; print ( root ) ;
struct node { int data ; struct node * left ; struct node * right ; } ;
bool printPath ( struct node * root , struct node * target_leaf ) {
if ( root == NULL ) return false ;
if ( root == target_leaf || printPath ( root -> left , target_leaf ) || printPath ( root -> right , target_leaf ) ) { printf ( " % d ▁ " , root -> data ) ; return true ; } return false ; }
void getTargetLeaf ( struct node * node , int * max_sum_ref , int curr_sum , struct node * * target_leaf_ref ) { if ( node == NULL ) return ;
curr_sum = curr_sum + node -> data ;
if ( node -> left == NULL && node -> right == NULL ) { if ( curr_sum > * max_sum_ref ) { * max_sum_ref = curr_sum ; * target_leaf_ref = node ; } }
getTargetLeaf ( node -> left , max_sum_ref , curr_sum , target_leaf_ref ) ; getTargetLeaf ( node -> right , max_sum_ref , curr_sum , target_leaf_ref ) ; }
int maxSumPath ( struct node * node ) {
if ( node == NULL ) return 0 ; struct node * target_leaf ; int max_sum = INT_MIN ;
getTargetLeaf ( node , & max_sum , 0 , & target_leaf ) ;
printPath ( node , target_leaf ) ;
return max_sum ; }
struct node * newNode ( int data ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = data ; temp -> left = NULL ; temp -> right = NULL ; return temp ; }
int main ( ) { struct node * root = NULL ; root = newNode ( 10 ) ; root -> left = newNode ( -2 ) ; root -> right = newNode ( 7 ) ; root -> left -> left = newNode ( 8 ) ; root -> left -> right = newNode ( -4 ) ; printf ( " Following ▁ are ▁ the ▁ nodes ▁ on ▁ the ▁ maximum ▁ " " sum ▁ path ▁ STRNEWLINE " ) ; int sum = maxSumPath ( root ) ; printf ( " Sum of the nodes is % d " , sum ) ; getchar ( ) ; return 0 ; }
void printUnion ( int arr1 [ ] , int arr2 [ ] , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) printf ( " ▁ % d ▁ " , arr1 [ i ++ ] ) ; else if ( arr2 [ j ] < arr1 [ i ] ) printf ( " ▁ % d ▁ " , arr2 [ j ++ ] ) ; else { printf ( " ▁ % d ▁ " , arr2 [ j ++ ] ) ; i ++ ; } }
while ( i < m ) printf ( " ▁ % d ▁ " , arr1 [ i ++ ] ) ; while ( j < n ) printf ( " ▁ % d ▁ " , arr2 [ j ++ ] ) ; }
int main ( ) { int arr1 [ ] = { 1 , 2 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 5 , 7 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ; printUnion ( arr1 , arr2 , m , n ) ; getchar ( ) ; return 0 ; }
void printIntersection ( int arr1 [ ] , int arr2 [ ] , int m , int n ) { int i = 0 , j = 0 ; while ( i < m && j < n ) { if ( arr1 [ i ] < arr2 [ j ] ) i ++ ; else if ( arr2 [ j ] < arr1 [ i ] ) j ++ ; else { printf ( " ▁ % d ▁ " , arr2 [ j ++ ] ) ; i ++ ; } } }
int main ( ) { int arr1 [ ] = { 1 , 2 , 4 , 5 , 6 } ; int arr2 [ ] = { 2 , 3 , 5 , 7 } ; int m = sizeof ( arr1 ) / sizeof ( arr1 [ 0 ] ) ; int n = sizeof ( arr2 ) / sizeof ( arr2 [ 0 ] ) ;
printIntersection ( arr1 , arr2 , m , n ) ; getchar ( ) ; return 0 ; }
int insertSorted ( int arr [ ] , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; int i ; for ( i = n - 1 ; ( i >= 0 && arr [ i ] > key ) ; i -- ) arr [ i + 1 ] = arr [ i ] ; arr [ i + 1 ] = key ; return ( n + 1 ) ; }
int main ( ) { int arr [ 20 ] = { 12 , 16 , 20 , 40 , 50 , 70 } ; int capacity = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int n = 6 ; int i , key = 26 ; printf ( " Before Insertion : " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ;
n = insertSorted ( arr , n , key , capacity ) ; printf ( " After Insertion : " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; return 0 ; }
int binarySearch ( int arr [ ] , int low , int high , int key ) ; int binarySearch ( int arr [ ] , int low , int high , int key ) { if ( high < low ) return -1 ; int mid = ( low + high ) / 2 ; if ( key == arr [ mid ] ) return mid ; if ( key > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , key ) ; return binarySearch ( arr , low , ( mid - 1 ) , key ) ; }
int deleteElement ( int arr [ ] , int n , int key ) {
int pos = binarySearch ( arr , 0 , n - 1 , key ) ; if ( pos == -1 ) { printf ( " Element ▁ not ▁ found " ) ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
int main ( ) { int i ; int arr [ ] = { 10 , 20 , 30 , 40 , 50 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int key = 30 ; printf ( " Array ▁ before ▁ deletion STRNEWLINE " ) ; for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; n = deleteElement ( arr , n , key ) ; printf ( " Array after deletion " for ( i = 0 ; i < n ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; }
int _binarySearch ( int arr [ ] , int low , int high , int x ) { if ( high >= low ) { int mid = ( low + high ) / 2 ;
if ( ( mid == 0 x > arr [ mid - 1 ] ) && ( arr [ mid ] == x ) ) return mid ; else if ( x > arr [ mid ] ) return _binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return _binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return -1 ; }
bool isMajority ( int arr [ ] , int n , int x ) {
int i = _binarySearch ( arr , 0 , n - 1 , x ) ;
if ( i == -1 ) return false ;
if ( ( ( i + n / 2 ) <= ( n - 1 ) ) && arr [ i + n / 2 ] == x ) return true ; else return false ; }
#include <stdio.h> NEW_LINE #include <stdbool.h> NEW_LINE bool isMajorityElement ( int arr [ ] , int n , int key ) { if ( arr [ n / 2 ] == key ) return true ; else return false ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 3 ; if ( isMajorityElement ( arr , n , x ) ) printf ( " % d ▁ appears ▁ more ▁ than ▁ % d ▁ times ▁ in ▁ arr [ ] " , x , n / 2 ) ; else printf ( " % d ▁ does ▁ not ▁ appear ▁ more ▁ than ▁ % d ▁ times ▁ in ▁ " " arr [ ] " , x , n / 2 ) ; return 0 ; }
#include <stdio.h> NEW_LINE int isPairSum ( int A [ ] , int N , int X ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
if ( i == j ) continue ;
if ( A [ i ] + A [ j ] == X ) return true ;
if ( A [ i ] + A [ j ] > X ) break ; } }
return 0 ; }
int main ( ) { int arr [ ] = { 3 , 5 , 9 , 2 , 8 , 10 , 11 } ; int val = 17 ; int arrSize = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
printf ( " % d " , isPairSum ( arr , arrSize , val ) ) ; return 0 ; }
int isPairSum ( int A [ ] , int N , int X ) {
int i = 0 ;
int j = N - 1 ; while ( i < j ) {
if ( A [ i ] + A [ j ] == X ) return 1 ;
else if ( A [ i ] + A [ j ] < X ) i ++ ;
else j -- ; } return 0 ; }
int arr [ ] = { 3 , 5 , 9 , 2 , 8 , 10 , 11 } ;
int val = 17 ;
printf ( " % d " , isPairSum ( arr , arrSize , val ) ) ; return 0 ; }
struct node { int data ; struct node * left , * right ; } ;
int getLevelDiff ( struct node * root ) {
if ( root == NULL ) return 0 ;
return root -> data - getLevelDiff ( root -> left ) - getLevelDiff ( root -> right ) ; }
int main ( ) { struct node * root = newNode ( 5 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 6 ) ; root -> left -> left = newNode ( 1 ) ; root -> left -> right = newNode ( 4 ) ; root -> left -> right -> left = newNode ( 3 ) ; root -> right -> right = newNode ( 8 ) ; root -> right -> right -> right = newNode ( 9 ) ; root -> right -> right -> left = newNode ( 7 ) ; printf ( " % d ▁ is ▁ the ▁ required ▁ difference STRNEWLINE " , getLevelDiff ( root ) ) ; getchar ( ) ; return 0 ; }
int search ( int arr [ ] , int n , int x ) { int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == x ) return i ; } return -1 ; }
int main ( ) { int arr [ ] = { 1 , 10 , 30 , 15 } ; int x = 30 ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; printf ( " % d ▁ is ▁ present ▁ at ▁ index ▁ % d " , x , search ( arr , n , x ) ) ; getchar ( ) ; return 0 ; }
int binarySearch ( int arr [ ] , int l , int r , int x ) { while ( l <= r ) { int m = l + ( r - l ) / 2 ;
if ( arr [ m ] == x ) return m ;
if ( arr [ m ] < x ) l = m + 1 ;
else r = m - 1 ; }
return -1 ; }
int main ( void ) { int arr [ ] = { 2 , 3 , 4 , 10 , 40 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int x = 10 ; int result = binarySearch ( arr , 0 , n - 1 , x ) ; ( result == -1 ) ? printf ( " Element ▁ is ▁ not ▁ present " " ▁ in ▁ array " ) : printf ( " Element ▁ is ▁ present ▁ at ▁ " " index ▁ % d " , result ) ; return 0 ; }
int interpolationSearch ( int arr [ ] , int lo , int hi , int x ) { int pos ;
if ( lo <= hi && x >= arr [ lo ] && x <= arr [ hi ] ) {
pos = lo + ( ( ( double ) ( hi - lo ) / ( arr [ hi ] - arr [ lo ] ) ) * ( x - arr [ lo ] ) ) ;
if ( arr [ pos ] == x ) return pos ;
if ( arr [ pos ] < x ) return interpolationSearch ( arr , pos + 1 , hi , x ) ;
if ( arr [ pos ] > x ) return interpolationSearch ( arr , lo , pos - 1 , x ) ; } return -1 ; }
int arr [ ] = { 10 , 12 , 13 , 16 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 33 , 35 , 42 , 47 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
int x = 18 ; int index = interpolationSearch ( arr , 0 , n - 1 , x ) ;
if ( index != -1 ) printf ( " Element ▁ found ▁ at ▁ index ▁ % d " , index ) ; else printf ( " Element ▁ not ▁ found . " ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
bool hasPathSum ( struct node * node , int sum ) { if ( node == NULL ) { return ( sum == 0 ) ; } else { bool ans = 0 ; int subSum = sum - node -> data ; if ( subSum == 0 && node -> left == NULL && node -> right == NULL ) return 1 ; if ( node -> left ) ans = ans || hasPathSum ( node -> left , subSum ) ; if ( node -> right ) ans = ans || hasPathSum ( node -> right , subSum ) ; return ans ; } }
struct node * root = newnode ( 10 ) ; root -> left = newnode ( 8 ) ; root -> right = newnode ( 2 ) ; root -> left -> left = newnode ( 3 ) ; root -> left -> right = newnode ( 5 ) ; root -> right -> left = newnode ( 2 ) ; if ( hasPathSum ( root , sum ) ) printf ( " There ▁ is ▁ a ▁ root - to - leaf ▁ path ▁ with ▁ sum ▁ % d " , sum ) ; else printf ( " There ▁ is ▁ no ▁ root - to - leaf ▁ path ▁ with ▁ sum ▁ % d " , sum ) ; getchar ( ) ; return 0 ; }
int partition ( int arr [ ] , int l , int h ) { int x = arr [ h ] ; int i = ( l - 1 ) ; for ( int j = l ; j <= h - 1 ; j ++ ) { if ( arr [ j ] <= x ) { i ++ ; swap ( & arr [ i ] , & arr [ j ] ) ; } } swap ( & arr [ i + 1 ] , & arr [ h ] ) ; return ( i + 1 ) ; }
void quickSortIterative ( int arr [ ] , int l , int h ) {
int stack [ h - l + 1 ] ;
int top = -1 ;
stack [ ++ top ] = l ; stack [ ++ top ] = h ;
while ( top >= 0 ) {
h = stack [ top -- ] ; l = stack [ top -- ] ;
int p = partition ( arr , l , h ) ;
if ( p - 1 > l ) { stack [ ++ top ] = l ; stack [ ++ top ] = p - 1 ; }
if ( p + 1 < h ) { stack [ ++ top ] = p + 1 ; stack [ ++ top ] = h ; } } }
int main ( ) { int arr [ ] = { 4 , 3 , 5 , 2 , 1 , 3 , 2 , 3 } ; int n = sizeof ( arr ) / sizeof ( * arr ) ;
quickSortIterative ( arr , 0 , n - 1 ) ; printArr ( arr , n ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int data ; struct node * left , * right ; } ;
int treePathsSumUtil ( struct node * root , int val ) {
if ( root == NULL ) return 0 ;
val = ( val * 10 + root -> data ) ;
if ( root -> left == NULL && root -> right == NULL ) return val ;
return treePathsSumUtil ( root -> left , val ) + treePathsSumUtil ( root -> right , val ) ; }
int treePathsSum ( struct node * root ) {
return treePathsSumUtil ( root , 0 ) ; }
int main ( ) { struct node * root = newNode ( 6 ) ; root -> left = newNode ( 3 ) ; root -> right = newNode ( 5 ) ; root -> left -> left = newNode ( 2 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 4 ) ; root -> left -> right -> left = newNode ( 7 ) ; root -> left -> right -> right = newNode ( 4 ) ; printf ( " Sum ▁ of ▁ all ▁ paths ▁ is ▁ % d " , treePathsSum ( root ) ) ; return 0 ; }
int lcs ( char * X , char * Y , int m , int n ) { if ( m == 0 n == 0 ) return 0 ; if ( X [ m - 1 ] == Y [ n - 1 ] ) return 1 + lcs ( X , Y , m - 1 , n - 1 ) ; else return max ( lcs ( X , Y , m , n - 1 ) , lcs ( X , Y , m - 1 , n ) ) ; }
int main ( ) { char X [ ] = " AGGTAB " ; char Y [ ] = " GXTXAYB " ; int m = strlen ( X ) ; int n = strlen ( Y ) ; printf ( " Length ▁ of ▁ LCS ▁ is ▁ % d " , lcs ( X , Y , m , n ) ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE int max ( int a , int b ) ;
int lcs ( char * X , char * Y , int m , int n ) { int L [ m + 1 ] [ n + 1 ] ; int i , j ;
for ( i = 0 ; i <= m ; i ++ ) { for ( j = 0 ; j <= n ; j ++ ) { if ( i == 0 j == 0 ) L [ i ] [ j ] = 0 ; else if ( X [ i - 1 ] == Y [ j - 1 ] ) L [ i ] [ j ] = L [ i - 1 ] [ j - 1 ] + 1 ; else L [ i ] [ j ] = max ( L [ i - 1 ] [ j ] , L [ i ] [ j - 1 ] ) ; } }
return L [ m ] [ n ] ; }
int main ( ) { char X [ ] = " AGGTAB " ; char Y [ ] = " GXTXAYB " ; int m = strlen ( X ) ; int n = strlen ( Y ) ; printf ( " Length ▁ of ▁ LCS ▁ is ▁ % d " , lcs ( X , Y , m , n ) ) ; return 0 ; }
#include <limits.h> NEW_LINE #include <stdio.h>
int eggDrop ( int n , int k ) {
if ( k == 1 k == 0 ) return k ;
if ( n == 1 ) return k ; int min = INT_MAX , x , res ;
for ( x = 1 ; x <= k ; x ++ ) { res = max ( eggDrop ( n - 1 , x - 1 ) , eggDrop ( n , k - x ) ) ; if ( res < min ) min = res ; } return min + 1 ; }
int main ( ) { int n = 2 , k = 10 ; printf ( " nMinimum ▁ number ▁ of ▁ trials ▁ in ▁ " " worst ▁ case ▁ with ▁ % d ▁ eggs ▁ and ▁ " " % d ▁ floors ▁ is ▁ % d ▁ STRNEWLINE " , n , k , eggDrop ( n , k ) ) ; return 0 ; }
#include <limits.h> NEW_LINE #include <stdio.h> NEW_LINE #define INF  INT_MAX
int printSolution ( int p [ ] , int n ) ; int printSolution ( int p [ ] , int n ) { int k ; if ( p [ n ] == 1 ) k = 1 ; else k = printSolution ( p , p [ n ] - 1 ) + 1 ; printf ( " Line ▁ number ▁ % d : ▁ From ▁ word ▁ no . ▁ % d ▁ to ▁ % d ▁ STRNEWLINE " , k , p [ n ] , n ) ; return k ; }
void solveWordWrap ( int l [ ] , int n , int M ) {
int extras [ n + 1 ] [ n + 1 ] ;
int lc [ n + 1 ] [ n + 1 ] ;
int c [ n + 1 ] ;
int p [ n + 1 ] ; int i , j ;
for ( i = 1 ; i <= n ; i ++ ) { extras [ i ] [ i ] = M - l [ i - 1 ] ; for ( j = i + 1 ; j <= n ; j ++ ) extras [ i ] [ j ] = extras [ i ] [ j - 1 ] - l [ j - 1 ] - 1 ; }
for ( i = 1 ; i <= n ; i ++ ) { for ( j = i ; j <= n ; j ++ ) { if ( extras [ i ] [ j ] < 0 ) lc [ i ] [ j ] = INF ; else if ( j == n && extras [ i ] [ j ] >= 0 ) lc [ i ] [ j ] = 0 ; else lc [ i ] [ j ] = extras [ i ] [ j ] * extras [ i ] [ j ] ; } }
c [ 0 ] = 0 ; for ( j = 1 ; j <= n ; j ++ ) { c [ j ] = INF ; for ( i = 1 ; i <= j ; i ++ ) { if ( c [ i - 1 ] != INF && lc [ i ] [ j ] != INF && ( c [ i - 1 ] + lc [ i ] [ j ] < c [ j ] ) ) { c [ j ] = c [ i - 1 ] + lc [ i ] [ j ] ; p [ j ] = i ; } } } printSolution ( p , n ) ; }
int main ( ) { int l [ ] = { 3 , 2 , 2 , 5 } ; int n = sizeof ( l ) / sizeof ( l [ 0 ] ) ; int M = 6 ; solveWordWrap ( l , n , M ) ; return 0 ; }
int sum ( int freq [ ] , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
int optCost ( int freq [ ] , int i , int j ) {
if ( j < i ) return 0 ;
if ( j == i ) return freq [ i ] ;
int fsum = sum ( freq , i , j ) ;
int min = INT_MAX ;
for ( int r = i ; r <= j ; ++ r ) { int cost = optCost ( freq , i , r - 1 ) + optCost ( freq , r + 1 , j ) ; if ( cost < min ) min = cost ; }
return min + fsum ; }
int optimalSearchTree ( int keys [ ] , int freq [ ] , int n ) {
return optCost ( freq , 0 , n - 1 ) ; }
int main ( ) { int keys [ ] = { 10 , 12 , 20 } ; int freq [ ] = { 34 , 8 , 50 } ; int n = sizeof ( keys ) / sizeof ( keys [ 0 ] ) ; printf ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ % d ▁ " , optimalSearchTree ( keys , freq , n ) ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <limits.h>
int sum ( int freq [ ] , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
int optimalSearchTree ( int keys [ ] , int freq [ ] , int n ) {
int cost [ n ] [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) cost [ i ] [ i ] = freq [ i ] ;
for ( int L = 2 ; L <= n ; L ++ ) {
for ( int i = 0 ; i <= n - L + 1 ; i ++ ) {
int j = i + L - 1 ; cost [ i ] [ j ] = INT_MAX ;
for ( int r = i ; r <= j ; r ++ ) {
int c = ( ( r > i ) ? cost [ i ] [ r - 1 ] : 0 ) + ( ( r < j ) ? cost [ r + 1 ] [ j ] : 0 ) + sum ( freq , i , j ) ; if ( c < cost [ i ] [ j ] ) cost [ i ] [ j ] = c ; } } } return cost [ 0 ] [ n - 1 ] ; }
int main ( ) { int keys [ ] = { 10 , 12 , 20 } ; int freq [ ] = { 34 , 8 , 50 } ; int n = sizeof ( keys ) / sizeof ( keys [ 0 ] ) ; printf ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ % d ▁ " , optimalSearchTree ( keys , freq , n ) ) ; return 0 ; }
int max ( int x , int y ) { return ( x > y ) ? x : y ; }
struct node { int data ; struct node * left , * right ; } ;
int LISS ( struct node * root ) { if ( root == NULL ) return 0 ;
int size_excl = LISS ( root -> left ) + LISS ( root -> right ) ;
int size_incl = 1 ; if ( root -> left ) size_incl += LISS ( root -> left -> left ) + LISS ( root -> left -> right ) ; if ( root -> right ) size_incl += LISS ( root -> right -> left ) + LISS ( root -> right -> right ) ;
return max ( size_incl , size_excl ) ; }
struct node * newNode ( int data ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
struct node * root = newNode ( 20 ) ; root -> left = newNode ( 8 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 12 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 14 ) ; root -> right = newNode ( 22 ) ; root -> right -> right = newNode ( 25 ) ; printf ( " Size ▁ of ▁ the ▁ Largest ▁ Independent ▁ Set ▁ is ▁ % d ▁ " , LISS ( root ) ) ; return 0 ; }
int getCount ( char keypad [ ] [ 3 ] , int n ) { if ( keypad == NULL n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
int odd [ 10 ] , even [ 10 ] ; int i = 0 , j = 0 , useOdd = 0 , totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ )
odd [ i ] = 1 ;
for ( j = 2 ; j <= n ; j ++ ) { useOdd = 1 - useOdd ;
if ( useOdd == 1 ) { even [ 0 ] = odd [ 0 ] + odd [ 8 ] ; even [ 1 ] = odd [ 1 ] + odd [ 2 ] + odd [ 4 ] ; even [ 2 ] = odd [ 2 ] + odd [ 1 ] + odd [ 3 ] + odd [ 5 ] ; even [ 3 ] = odd [ 3 ] + odd [ 2 ] + odd [ 6 ] ; even [ 4 ] = odd [ 4 ] + odd [ 1 ] + odd [ 5 ] + odd [ 7 ] ; even [ 5 ] = odd [ 5 ] + odd [ 2 ] + odd [ 4 ] + odd [ 8 ] + odd [ 6 ] ; even [ 6 ] = odd [ 6 ] + odd [ 3 ] + odd [ 5 ] + odd [ 9 ] ; even [ 7 ] = odd [ 7 ] + odd [ 4 ] + odd [ 8 ] ; even [ 8 ] = odd [ 8 ] + odd [ 0 ] + odd [ 5 ] + odd [ 7 ] + odd [ 9 ] ; even [ 9 ] = odd [ 9 ] + odd [ 6 ] + odd [ 8 ] ; } else { odd [ 0 ] = even [ 0 ] + even [ 8 ] ; odd [ 1 ] = even [ 1 ] + even [ 2 ] + even [ 4 ] ; odd [ 2 ] = even [ 2 ] + even [ 1 ] + even [ 3 ] + even [ 5 ] ; odd [ 3 ] = even [ 3 ] + even [ 2 ] + even [ 6 ] ; odd [ 4 ] = even [ 4 ] + even [ 1 ] + even [ 5 ] + even [ 7 ] ; odd [ 5 ] = even [ 5 ] + even [ 2 ] + even [ 4 ] + even [ 8 ] + even [ 6 ] ; odd [ 6 ] = even [ 6 ] + even [ 3 ] + even [ 5 ] + even [ 9 ] ; odd [ 7 ] = even [ 7 ] + even [ 4 ] + even [ 8 ] ; odd [ 8 ] = even [ 8 ] + even [ 0 ] + even [ 5 ] + even [ 7 ] + even [ 9 ] ; odd [ 9 ] = even [ 9 ] + even [ 6 ] + even [ 8 ] ; } }
totalCount = 0 ; if ( useOdd == 1 ) { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += even [ i ] ; } else { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += odd [ i ] ; } return totalCount ; }
int main ( ) { char keypad [ 4 ] [ 3 ] = { { '1' , '2' , '3' } , { '4' , '5' , '6' } , { '7' , '8' , '9' } , { ' * ' , '0' , ' # ' } } ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 1 , getCount ( keypad , 1 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 2 , getCount ( keypad , 2 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 3 , getCount ( keypad , 3 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 4 , getCount ( keypad , 4 ) ) ; printf ( " Count ▁ for ▁ numbers ▁ of ▁ length ▁ % d : ▁ % dn " , 5 , getCount ( keypad , 5 ) ) ; return 0 ; }
int findoptimal ( int N ) {
if ( N <= 6 ) return N ;
int screen [ N ] ;
int n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = 0 ;
for ( b = n - 3 ; b >= 1 ; b -- ) {
int curr = ( n - b - 1 ) * screen [ b - 1 ] ; if ( curr > screen [ n - 1 ] ) screen [ n - 1 ] = curr ; } } return screen [ N - 1 ] ; }
int main ( ) { int N ;
for ( N = 1 ; N <= 20 ; N ++ ) printf ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with ▁ % d ▁ keystrokes ▁ is ▁ % d STRNEWLINE " , N , findoptimal ( N ) ) ; }
#include <stdio.h> NEW_LINE #include <string.h> NEW_LINE #define NO_OF_CHARS  256 NEW_LINE int getNextState ( char * pat , int M , int state , int x ) {
if ( state < M && x == pat [ state ] ) return state + 1 ;
for ( ns = state ; ns > 0 ; ns -- ) { if ( pat [ ns - 1 ] == x ) { for ( i = 0 ; i < ns - 1 ; i ++ ) if ( pat [ i ] != pat [ state - ns + 1 + i ] ) break ; if ( i == ns - 1 ) return ns ; } } return 0 ; }
void computeTF ( char * pat , int M , int TF [ ] [ NO_OF_CHARS ] ) { int state , x ; for ( state = 0 ; state <= M ; ++ state ) for ( x = 0 ; x < NO_OF_CHARS ; ++ x ) TF [ state ] [ x ] = getNextState ( pat , M , state , x ) ; }
void search ( char * pat , char * txt ) { int M = strlen ( pat ) ; int N = strlen ( txt ) ; int TF [ M + 1 ] [ NO_OF_CHARS ] ; computeTF ( pat , M , TF ) ;
int i , state = 0 ; for ( i = 0 ; i < N ; i ++ ) { state = TF [ state ] [ txt [ i ] ] ; if ( state == M ) printf ( " Pattern found at index % d " , i - M + 1 ) ; } }
int main ( ) { char * txt = " AABAACAADAABAAABAA " ; char * pat = " AABA " ; search ( pat , txt ) ; return 0 ; }
# include <limits.h> NEW_LINE # include <string.h> NEW_LINE # include <stdio.h> NEW_LINE # define NO_OF_CHARS  256
void badCharHeuristic ( char * str , int size , int badchar [ NO_OF_CHARS ] ) { int i ;
for ( i = 0 ; i < NO_OF_CHARS ; i ++ ) badchar [ i ] = -1 ;
for ( i = 0 ; i < size ; i ++ ) badchar [ ( int ) str [ i ] ] = i ; }
void search ( char * txt , char * pat ) { int m = strlen ( pat ) ; int n = strlen ( txt ) ; int badchar [ NO_OF_CHARS ] ;
badCharHeuristic ( pat , m , badchar ) ;
int s = 0 ;
while ( s <= ( n - m ) ) { int j = m - 1 ;
while ( j >= 0 && pat [ j ] == txt [ s + j ] ) j -- ;
if ( j < 0 ) { printf ( " pattern occurs at shift = % d "
s += ( s + m < n ) ? m - badchar [ txt [ s + m ] ] : 1 ; } else
s += max ( 1 , j - badchar [ txt [ s + j ] ] ) ; } }
int main ( ) { char txt [ ] = " ABAAABCD " ; char pat [ ] = " ABC " ; search ( txt , pat ) ; return 0 ; }
#define N  9
void print ( int arr [ N ] [ N ] ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) printf ( " % d ▁ " , arr [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } }
int isSafe ( int grid [ N ] [ N ] , int row , int col , int num ) {
for ( int x = 0 ; x <= 8 ; x ++ ) if ( grid [ row ] [ x ] == num ) return 0 ;
for ( int x = 0 ; x <= 8 ; x ++ ) if ( grid [ x ] [ col ] == num ) return 0 ;
int startRow = row - row % 3 , startCol = col - col % 3 ; for ( int i = 0 ; i < 3 ; i ++ ) for ( int j = 0 ; j < 3 ; j ++ ) if ( grid [ i + startRow ] [ j + startCol ] == num ) return 0 ; return 1 ; }
int solveSuduko ( int grid [ N ] [ N ] , int row , int col ) {
if ( row == N - 1 && col == N ) return 1 ;
if ( col == N ) { row ++ ; col = 0 ; }
if ( grid [ row ] [ col ] > 0 ) return solveSuduko ( grid , row , col + 1 ) ; for ( int num = 1 ; num <= N ; num ++ ) {
if ( isSafe ( grid , row , col , num ) == 1 ) {
grid [ row ] [ col ] = num ;
if ( solveSuduko ( grid , row , col + 1 ) == 1 ) return 1 ; }
grid [ row ] [ col ] = 0 ; } return 0 ; }
int main ( ) { int grid [ N ] [ N ] = { { 3 , 0 , 6 , 5 , 0 , 8 , 4 , 0 , 0 } , { 5 , 2 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } , { 0 , 8 , 7 , 0 , 0 , 0 , 0 , 3 , 1 } , { 0 , 0 , 3 , 0 , 1 , 0 , 0 , 8 , 0 } , { 9 , 0 , 0 , 8 , 6 , 3 , 0 , 0 , 5 } , { 0 , 5 , 0 , 0 , 9 , 0 , 6 , 0 , 0 } , { 1 , 3 , 0 , 0 , 0 , 0 , 2 , 5 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 7 , 4 } , { 0 , 0 , 5 , 2 , 0 , 6 , 3 , 0 , 0 } } ; if ( solveSuduko ( grid , 0 , 0 ) == 1 ) print ( grid ) ; else printf ( " No ▁ solution ▁ exists " ) ; return 0 ; }
int power ( int x , unsigned int y ) { int temp ; if ( y == 0 ) return 1 ; temp = power ( x , y / 2 ) ; if ( y % 2 == 0 ) return temp * temp ; else return x * temp * temp ; }
#include <stdio.h> NEW_LINE #include <float.h> NEW_LINE #include <stdlib.h> NEW_LINE #include <math.h>
struct Point { int x , y ; } ;
float dist ( Point p1 , Point p2 ) { return sqrt ( ( p1 . x - p2 . x ) * ( p1 . x - p2 . x ) + ( p1 . y - p2 . y ) * ( p1 . y - p2 . y ) ) ; }
float bruteForce ( Point P [ ] , int n ) { float min = FLT_MAX ; for ( int i = 0 ; i < n ; ++ i ) for ( int j = i + 1 ; j < n ; ++ j ) if ( dist ( P [ i ] , P [ j ] ) < min ) min = dist ( P [ i ] , P [ j ] ) ; return min ; }
float stripClosest ( Point strip [ ] , int size , float d ) {
float min = d ; qsort ( strip , size , sizeof ( Point ) , compareY ) ;
for ( int i = 0 ; i < size ; ++ i ) for ( int j = i + 1 ; j < size && ( strip [ j ] . y - strip [ i ] . y ) < min ; ++ j ) if ( dist ( strip [ i ] , strip [ j ] ) < min ) min = dist ( strip [ i ] , strip [ j ] ) ; return min ; }
float closestUtil ( Point P [ ] , int n ) {
if ( n <= 3 ) return bruteForce ( P , n ) ;
int mid = n / 2 ; Point midPoint = P [ mid ] ;
float dl = closestUtil ( P , mid ) ; float dr = closestUtil ( P + mid , n - mid ) ;
float d = min ( dl , dr ) ;
Point strip [ n ] ; int j = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( abs ( P [ i ] . x - midPoint . x ) < d ) strip [ j ] = P [ i ] , j ++ ;
return min ( d , stripClosest ( strip , j , d ) ) ; }
float closest ( Point P [ ] , int n ) { qsort ( P , n , sizeof ( Point ) , compareX ) ;
return closestUtil ( P , n ) ; }
int main ( ) { Point P [ ] = { { 2 , 3 } , { 12 , 30 } , { 40 , 50 } , { 5 , 1 } , { 12 , 10 } , { 3 , 4 } } ; int n = sizeof ( P ) / sizeof ( P [ 0 ] ) ; printf ( " The ▁ smallest ▁ distance ▁ is ▁ % f ▁ " , closest ( P , n ) ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
int main ( ) { struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <string.h> NEW_LINE #define MAX_CHAR  256
int count [ MAX_CHAR ] = { 0 } ;
int fact ( int n ) { return ( n <= 1 ) ? 1 : n * fact ( n - 1 ) ; }
void populateAndIncreaseCount ( int * count , char * str ) { int i ; for ( i = 0 ; str [ i ] ; ++ i ) ++ count [ str [ i ] ] ; for ( i = 1 ; i < MAX_CHAR ; ++ i ) count [ i ] += count [ i - 1 ] ; }
void updatecount ( int * count , char ch ) { int i ; for ( i = ch ; i < MAX_CHAR ; ++ i ) -- count [ i ] ; }
int findRank ( char * str ) { int len = strlen ( str ) ; int mul = fact ( len ) ; int rank = 1 , i ;
populateAndIncreaseCount ( count , str ) ; for ( i = 0 ; i < len ; ++ i ) { mul /= len - i ;
rank += count [ str [ i ] - 1 ] * mul ;
updatecount ( count , str [ i ] ) ; } return rank ; }
int main ( ) { char str [ ] = " string " ; printf ( " % d " , findRank ( str ) ) ; return 0 ; }
void reverse ( char str [ ] , int l , int h ) { while ( l < h ) { swap ( & str [ l ] , & str [ h ] ) ; l ++ ; h -- ; } }
int findCeil ( char str [ ] , char first , int l , int h ) { int ceilIndex = l ; for ( int i = l + 1 ; i <= h ; i ++ ) if ( str [ i ] > first && str [ i ] < str [ ceilIndex ] ) ceilIndex = i ; return ceilIndex ; }
void sortedPermutations ( char str [ ] ) {
int size = strlen ( str ) ;
qsort ( str , size , sizeof ( str [ 0 ] ) , compare ) ;
bool isFinished = false ; while ( ! isFinished ) {
printf ( " % s ▁ STRNEWLINE " , str ) ;
int i ; for ( i = size - 2 ; i >= 0 ; -- i ) if ( str [ i ] < str [ i + 1 ] ) break ;
if ( i == -1 ) isFinished = true ; else {
int ceilIndex = findCeil ( str , str [ i ] , i + 1 , size - 1 ) ;
swap ( & str [ i ] , & str [ ceilIndex ] ) ;
reverse ( str , i + 1 , size - 1 ) ; } } }
#include <stdio.h> NEW_LINE #include <stdlib.h>
int findCeil ( int arr [ ] , int r , int l , int h ) { int mid ; while ( l < h ) {
mid = l + ( ( h - l ) >> 1 ) ; ( r > arr [ mid ] ) ? ( l = mid + 1 ) : ( h = mid ) ; } return ( arr [ l ] >= r ) ? l : -1 ; }
int myRand ( int arr [ ] , int freq [ ] , int n ) {
int prefix [ n ] , i ; prefix [ 0 ] = freq [ 0 ] ; for ( i = 1 ; i < n ; ++ i ) prefix [ i ] = prefix [ i - 1 ] + freq [ i ] ;
int r = ( rand ( ) % prefix [ n - 1 ] ) + 1 ;
int indexc = findCeil ( prefix , r , 0 , n - 1 ) ; return arr [ indexc ] ; }
int main ( ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int freq [ ] = { 10 , 5 , 20 , 100 } ; int i , n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ;
for ( i = 0 ; i < 5 ; i ++ ) printf ( " % d STRNEWLINE " , myRand ( arr , freq , n ) ) ; return 0 ; }
int random ( int x , int y , int z , int px , int py , int pz ) {
int r = rand ( 1 , 100 ) ;
if ( r <= px ) return x ;
if ( r <= ( px + py ) ) return y ;
else return z ; }
unsigned int getLeftmostBit ( int n ) { int m = 0 ; while ( n > 1 ) { n = n >> 1 ; m ++ ; } return m ; }
unsigned int getNextLeftmostBit ( int n , int m ) { unsigned int temp = 1 << m ; while ( n < temp ) { temp = temp >> 1 ; m -- ; } return m ; }
unsigned int _countSetBits ( unsigned int n , int m ) ; unsigned int countSetBits ( unsigned int n ) {
int m = getLeftmostBit ( n ) ;
return _countSetBits ( n , m ) ; } unsigned int _countSetBits ( unsigned int n , int m ) {
if ( n == 0 ) return 0 ;
m = getNextLeftmostBit ( n , m ) ;
if ( n == ( ( unsigned int ) 1 << ( m + 1 ) ) - 1 ) return ( unsigned int ) ( m + 1 ) * ( 1 << m ) ;
n = n - ( 1 << m ) ; return ( n + 1 ) + countSetBits ( n ) + m * ( 1 << ( m - 1 ) ) ; }
int main ( ) { int n = 17 ; printf ( " Total ▁ set ▁ bit ▁ count ▁ is ▁ % d " , countSetBits ( n ) ) ; return 0 ; }
int Add ( int x , int y ) { if ( y == 0 ) return x ; else return Add ( x ^ y , ( x & y ) << 1 ) ; }
#include <stdio.h> NEW_LINE #define CHAR_BIT  8
int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHAR_BIT - 1 ) ) ) ; }
int smallest ( int x , int y , int z ) { return min ( x , min ( y , z ) ) ; }
int main ( ) { int x = 12 , y = 15 , z = 5 ; printf ( " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ % d " , smallest ( x , y , z ) ) ; return 0 ; }
int smallest ( int x , int y , int z ) {
if ( ! ( y / x ) ) return ( ! ( y / z ) ) ? y : z ; return ( ! ( x / z ) ) ? x : z ; }
int main ( ) { int x = 78 , y = 88 , z = 68 ; printf ( " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ % d " , smallest ( x , y , z ) ) ; return 0 ; }
void changeToZero ( int a [ 2 ] ) { a [ a [ 1 ] ] = a [ ! a [ 1 ] ] ; }
int main ( ) { int a [ ] = { 1 , 0 } ; changeToZero ( a ) ; printf ( " ▁ arr [ 0 ] ▁ = ▁ % d ▁ STRNEWLINE " , a [ 0 ] ) ; printf ( " ▁ arr [ 1 ] ▁ = ▁ % d ▁ " , a [ 1 ] ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #define bool  int NEW_LINE bool isPowerOfFour ( unsigned int n ) { return n != 0 && ( ( n & ( n - 1 ) ) == 0 ) && ! ( n & 0xAAAAAAAA ) ; }
int main ( ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) ) printf ( " % d ▁ is ▁ a ▁ power ▁ of ▁ 4" , test_no ) ; else printf ( " % d ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" , test_no ) ; getchar ( ) ; }
#include <stdio.h> NEW_LINE #define CHAR_BIT  8
int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHAR_BIT - 1 ) ) ) ; }
int max ( int x , int y ) { return x - ( ( x - y ) & ( ( x - y ) >> ( sizeof ( int ) * CHAR_BIT - 1 ) ) ) ; }
int main ( ) { int x = 15 ; int y = 6 ; printf ( " Minimum ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ " , x , y ) ; printf ( " % d " , min ( x , y ) ) ; printf ( " Maximum of % d and % d is " printf ( " % d " , max ( x , y ) ) ; getchar ( ) ; }
int countSetBits ( int N ) { int count = 0 ;
for ( int i = 0 ; i < sizeof ( int ) * 8 ; i ++ ) { if ( N & ( 1 << i ) ) count ++ ; } return count ; }
int main ( ) { int N = 15 ; printf ( " % d " , countSetBits ( N ) ) ; return 0 ; }
void bin ( unsigned n ) { unsigned i ; for ( i = 1 << 31 ; i > 0 ; i = i / 2 ) ( n & i ) ? printf ( "1" ) : printf ( "0" ) ; }
int main ( void ) { bin ( 7 ) ; printf ( " STRNEWLINE " ) ; bin ( 4 ) ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
int maxDepth ( struct node * node ) { if ( node == NULL ) return 0 ; else {
int lDepth = maxDepth ( node -> left ) ; int rDepth = maxDepth ( node -> right ) ;
if ( lDepth > rDepth ) return ( lDepth + 1 ) ; else return ( rDepth + 1 ) ; } }
int main ( ) { struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; printf ( " Height ▁ of ▁ tree ▁ is ▁ % d " , maxDepth ( root ) ) ; getchar ( ) ; return 0 ; }
void constructLowerArray ( int * arr [ ] , int * countSmaller , int n ) { int i , j ;
for ( i = 0 ; i < n ; i ++ ) countSmaller [ i ] = 0 ; for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < arr [ i ] ) countSmaller [ i ] ++ ; } } }
void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) printf ( " % d ▁ " , arr [ i ] ) ; printf ( " STRNEWLINE " ) ; }
int main ( ) { int arr [ ] = { 12 , 10 , 5 , 4 , 2 , 20 , 6 , 1 , 0 , 2 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int * low = ( int * ) malloc ( sizeof ( int ) * n ) ; constructLowerArray ( arr , low , n ) ; printArray ( low , n ) ; return 0 ; }
int segregate ( int arr [ ] , int size ) { int j = 0 , i ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] <= 0 ) { swap ( & arr [ i ] , & arr [ j ] ) ;
j ++ ; } } return j ; }
int findMissingPositive ( int arr [ ] , int size ) { int i ;
for ( i = 0 ; i < size ; i ++ ) { if ( abs ( arr [ i ] ) - 1 < size && arr [ abs ( arr [ i ] ) - 1 ] > 0 ) arr [ abs ( arr [ i ] ) - 1 ] = - arr [ abs ( arr [ i ] ) - 1 ] ; }
for ( i = 0 ; i < size ; i ++ ) if ( arr [ i ] > 0 )
return i + 1 ; return size + 1 ; }
int findMissing ( int arr [ ] , int size ) {
int shift = segregate ( arr , size ) ;
return findMissingPositive ( arr + shift , size - shift ) ; }
int main ( ) { int arr [ ] = { 0 , 10 , 2 , -10 , -20 } ; int arr_size = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; int missing = findMissing ( arr , arr_size ) ; printf ( " The ▁ smallest ▁ positive ▁ missing ▁ number ▁ is ▁ % d ▁ " , missing ) ; getchar ( ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
bool isBalanced ( struct node * root ) {
if ( root == NULL ) return 1 ;
lh = height ( root -> left ) ; rh = height ( root -> right ) ; if ( abs ( lh - rh ) <= 1 && isBalanced ( root -> left ) && isBalanced ( root -> right ) ) return 1 ;
return 0 ; }
int height ( struct node * node ) {
if ( node == NULL ) return 0 ;
return 1 + max ( height ( node -> left ) , height ( node -> right ) ) ; }
int main ( ) { struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> left -> left -> left = newNode ( 8 ) ; if ( isBalanced ( root ) ) printf ( " Tree ▁ is ▁ balanced " ) ; else printf ( " Tree ▁ is ▁ not ▁ balanced " ) ; getchar ( ) ; return 0 ; }
struct node { int data ; struct node * left , * right ; } ;
int height ( struct node * node ) {
if ( node == NULL ) return 0 ;
return 1 + max ( height ( node -> left ) , height ( node -> right ) ) ; }
int diameter ( struct node * tree ) {
if ( tree == NULL ) return 0 ;
int lheight = height ( tree -> left ) ; int rheight = height ( tree -> right ) ;
int ldiameter = diameter ( tree -> left ) ; int rdiameter = diameter ( tree -> right ) ;
return max ( lheight + rheight + 1 , max ( ldiameter , rdiameter ) ) ; }
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ;
printf ( " Diameter ▁ of ▁ the ▁ given ▁ binary ▁ tree ▁ is ▁ % d STRNEWLINE " , diameter ( root ) ) ; return 0 ; }
void getTwoElements ( int arr [ ] , int n , int * x , int * y ) {
int xor1 ;
for ( i = 1 ; i < n ; i ++ ) xor1 = xor1 ^ arr [ i ] ;
for ( i = 1 ; i <= n ; i ++ ) xor1 = xor1 ^ i ;
set_bit_no = xor1 & ~ ( xor1 - 1 ) ;
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] & set_bit_no )
* x = * x ^ arr [ i ] ; else
* y = * y ^ arr [ i ] ; } for ( i = 1 ; i <= n ; i ++ ) { if ( i & set_bit_no )
* x = * x ^ i ; else
* y = * y ^ i ; }
int main ( ) { int arr [ ] = { 1 , 3 , 4 , 5 , 5 , 6 , 2 } ; int * x = ( int * ) malloc ( sizeof ( int ) ) ; int * y = ( int * ) malloc ( sizeof ( int ) ) ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; getTwoElements ( arr , n , x , y ) ; printf ( " ▁ The ▁ missing ▁ element ▁ is ▁ % d " " ▁ and ▁ the ▁ repeating ▁ number " " ▁ is ▁ % d " , * x , * y ) ; getchar ( ) ; }
struct Node { int data ; struct Node * left , * right ; } ;
int depthOfOddLeafUtil ( struct Node * root , int level ) {
if ( root == NULL ) return 0 ;
if ( root -> left == NULL && root -> right == NULL && level & 1 ) return level ;
return max ( depthOfOddLeafUtil ( root -> left , level + 1 ) , depthOfOddLeafUtil ( root -> right , level + 1 ) ) ; }
int depthOfOddLeaf ( struct Node * root ) { int level = 1 , depth = 0 ; return depthOfOddLeafUtil ( root , level ) ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> right -> left = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; root -> right -> left -> right = newNode ( 7 ) ; root -> right -> right -> right = newNode ( 8 ) ; root -> right -> left -> right -> left = newNode ( 9 ) ; root -> right -> right -> right -> right = newNode ( 10 ) ; root -> right -> right -> right -> right -> left = newNode ( 11 ) ; printf ( " % d ▁ is ▁ the ▁ required ▁ depth STRNEWLINE " , depthOfOddLeaf ( root ) ) ; getchar ( ) ; return 0 ; }
int minDistance ( int arr [ ] , int n ) { int maximum_element = arr [ 0 ] ; int min_dis = n ; int index = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( maximum_element == arr [ i ] ) { min_dis = min ( min_dis , ( i - index ) ) ; index = i ; }
else if ( maximum_element < arr [ i ] ) { maximum_element = arr [ i ] ; min_dis = n ; index = i ; }
else continue ; } return min_dis ; }
int main ( ) { int arr [ ] = { 6 , 3 , 1 , 3 , 6 , 4 , 6 } ; int n = sizeof ( arr ) / sizeof ( arr [ 0 ] ) ; cout << " Minimum ▁ distance ▁ = ▁ " << minDistance ( arr , n ) ; return 0 ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void insertAfter ( struct Node * prev_node , int new_data ) {
if ( prev_node == NULL ) { printf ( " the ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL " ) ; return ; }
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = prev_node -> next ;
prev_node -> next = new_node ; }
void deleteAlt ( struct Node * head ) { if ( head == NULL ) return ; struct Node * node = head -> next ; if ( node == NULL ) return ;
head -> next = node -> next ;
deleteAlt ( head -> next ) ; }
struct Node { int data ; struct Node * next ; } ;
bool areIdentical ( struct Node * a , struct Node * b ) { while ( a != NULL && b != NULL ) { if ( a -> data != b -> data ) return false ;
a = a -> next ; b = b -> next ; }
return ( a == NULL && b == NULL ) ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
int main ( ) {
struct Node * a = NULL ; struct Node * b = NULL ; push ( & a , 1 ) ; push ( & a , 2 ) ; push ( & a , 3 ) ; push ( & b , 1 ) ; push ( & b , 2 ) ; push ( & b , 3 ) ; areIdentical ( a , b ) ? printf ( " Identical " ) : printf ( " Not ▁ identical " ) ; return 0 ; }
bool areIdentical ( struct Node * a , struct Node * b ) {
if ( a == NULL && b == NULL ) return true ;
if ( a != NULL && b != NULL ) return ( a -> data == b -> data ) && areIdentical ( a -> next , b -> next ) ;
return false ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ;
int count [ 3 ] = { 0 , 0 , 0 } ; struct Node * ptr = head ;
while ( ptr != NULL ) { count [ ptr -> data ] += 1 ; ptr = ptr -> next ; } int i = 0 ; ptr = head ;
while ( ptr != NULL ) { if ( count [ i ] == 0 ) ++ i ; else { ptr -> data = i ; -- count [ i ] ; ptr = ptr -> next ; } } }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } printf ( " n " ) ; }
struct Node * head = NULL ; push ( & head , 0 ) ; push ( & head , 1 ) ; push ( & head , 0 ) ; push ( & head , 2 ) ; push ( & head , 1 ) ; push ( & head , 1 ) ; push ( & head , 2 ) ; push ( & head , 1 ) ; push ( & head , 2 ) ; printf ( " Linked ▁ List ▁ Before ▁ Sorting STRNEWLINE " ) ; printList ( head ) ; sortList ( head ) ; printf ( " Linked ▁ List ▁ After ▁ Sorting STRNEWLINE " ) ; printList ( head ) ; return 0 ; }
struct List { int data ; struct List * next ; struct List * child ; } ;
struct Node { int data ; struct Node * next ; } ;
Node * newNode ( int key ) { Node * temp = new Node ; temp -> data = key ; temp -> next = NULL ; return temp ; }
Node * rearrangeEvenOdd ( Node * head ) {
if ( head == NULL ) return NULL ;
Node * odd = head ; Node * even = head -> next ;
Node * evenFirst = even ; while ( 1 ) {
if ( ! odd || ! even || ! ( even -> next ) ) { odd -> next = evenFirst ; break ; }
odd -> next = even -> next ; odd = even -> next ;
if ( odd -> next == NULL ) { even -> next = NULL ; odd -> next = evenFirst ; break ; }
even -> next = odd -> next ; even = odd -> next ; } return head ; }
void printlist ( Node * node ) { while ( node != NULL ) { cout << node -> data << " - > " ; node = node -> next ; } cout << " NULL " << endl ; }
int main ( void ) { Node * head = newNode ( 1 ) ; head -> next = newNode ( 2 ) ; head -> next -> next = newNode ( 3 ) ; head -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next = newNode ( 5 ) ; cout << " Given ▁ Linked ▁ List STRNEWLINE " ; printlist ( head ) ; head = rearrangeEvenOdd ( head ) ; cout << " Modified Linked List " ; printlist ( head ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
int getMaxWidth ( struct node * root ) { int maxWidth = 0 ; int width ; int h = height ( root ) ; int i ;
for ( i = 1 ; i <= h ; i ++ ) { width = getWidth ( root , i ) ; if ( width > maxWidth ) maxWidth = width ; } return maxWidth ; }
int getWidth ( struct node * root , int level ) { if ( root == NULL ) return 0 ; if ( level == 1 ) return 1 ; else if ( level > 1 ) return getWidth ( root -> left , level - 1 ) + getWidth ( root -> right , level - 1 ) ; }
int height ( struct node * node ) { if ( node == NULL ) return 0 ; else {
int lHeight = height ( node -> left ) ; int rHeight = height ( node -> right ) ;
return ( lHeight > rHeight ) ? ( lHeight + 1 ) : ( rHeight + 1 ) ; } }
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 8 ) ; root -> right -> right -> left = newNode ( 6 ) ; root -> right -> right -> right = newNode ( 7 ) ;
printf ( " Maximum ▁ width ▁ is ▁ % d ▁ STRNEWLINE " , getMaxWidth ( root ) ) ; getchar ( ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void deleteLast ( struct Node * head , int x ) { struct Node * temp = head , * ptr = NULL ; while ( temp ) {
if ( temp -> data == x ) ptr = temp ; temp = temp -> next ; }
if ( ptr != NULL && ptr -> next == NULL ) { temp = head ; while ( temp -> next != ptr ) temp = temp -> next ; temp -> next = NULL ; }
if ( ptr != NULL && ptr -> next != NULL ) { ptr -> data = ptr -> next -> data ; temp = ptr -> next ; ptr -> next = ptr -> next -> next ; free ( temp ) ; } }
struct Node * newNode ( int x ) { struct Node * node = malloc ( sizeof ( struct Node * ) ) ; node -> data = x ; node -> next = NULL ; return node ; }
void display ( struct Node * head ) { struct Node * temp = head ; if ( head == NULL ) { printf ( " NULL STRNEWLINE " ) ; return ; } while ( temp != NULL ) { printf ( " % d ▁ - - > ▁ " , temp -> data ) ; temp = temp -> next ; } printf ( " NULL STRNEWLINE " ) ; }
int main ( ) { struct Node * head = newNode ( 1 ) ; head -> next = newNode ( 2 ) ; head -> next -> next = newNode ( 3 ) ; head -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next = newNode ( 5 ) ; head -> next -> next -> next -> next -> next = newNode ( 4 ) ; head -> next -> next -> next -> next -> next -> next = newNode ( 4 ) ; printf ( " Created ▁ Linked ▁ list : ▁ " ) ; display ( head ) ; deleteLast ( head , 4 ) ; printf ( " List ▁ after ▁ deletion ▁ of ▁ 4 : ▁ " ) ; display ( head ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
int getMaxWidth ( struct node * root ) { int width ; int h = height ( root ) ;
int * count = ( int * ) calloc ( sizeof ( int ) , h ) ; int level = 0 ;
getMaxWidthRecur ( root , count , level ) ;
return getMax ( count , h ) ; }
void getMaxWidthRecur ( struct node * root , int count [ ] , int level ) { if ( root ) { count [ level ] ++ ; getMaxWidthRecur ( root -> left , count , level + 1 ) ; getMaxWidthRecur ( root -> right , count , level + 1 ) ; } }
int height ( struct node * node ) { if ( node == NULL ) return 0 ; else {
int lHeight = height ( node -> left ) ; int rHeight = height ( node -> right ) ;
return ( lHeight > rHeight ) ? ( lHeight + 1 ) : ( rHeight + 1 ) ; } }
int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; int i ; for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 8 ) ; root -> right -> right -> left = newNode ( 6 ) ; root -> right -> right -> right = newNode ( 7 ) ; printf ( " Maximum ▁ width ▁ is ▁ % d ▁ STRNEWLINE " , getMaxWidth ( root ) ) ; getchar ( ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
int LinkedListLength ( struct Node * head ) { while ( head && head -> next ) { head = head -> next -> next ; } if ( ! head ) return 0 ; return 1 ; }
void push ( struct Node * * head , int info ) {
struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
node -> next = ( * head ) ;
( * head ) = node ; }
int main ( void ) { struct Node * head = NULL ;
push ( & head , 4 ) ; push ( & head , 5 ) ; push ( & head , 7 ) ; push ( & head , 2 ) ; push ( & head , 9 ) ; push ( & head , 6 ) ; push ( & head , 1 ) ; push ( & head , 2 ) ; push ( & head , 0 ) ; push ( & head , 5 ) ; push ( & head , 5 ) ; int check = LinkedListLength ( head ) ;
if ( check == 0 ) { printf ( " Even STRNEWLINE " ) ; } else { printf ( " Odd STRNEWLINE " ) ; } return 0 ; }
struct Node { int data ; struct Node * next ; } ;
struct Node * rotateHelper ( struct Node * blockHead , struct Node * blockTail , int d , struct Node * * tail , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { struct Node * temp = blockHead ; for ( int i = 1 ; temp -> next -> next && i < k - 1 ; i ++ ) temp = temp -> next ; blockTail -> next = blockHead ; * tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , tail , k ) ; }
if ( d < 0 ) { blockTail -> next = blockHead ; * tail = blockHead ; return rotateHelper ( blockHead -> next , blockHead , d + 1 , tail , k ) ; } }
struct Node * rotateByBlocks ( struct Node * head , int k , int d ) {
if ( ! head ! head -> next ) return head ;
if ( d == 0 ) return head ; struct Node * temp = head , * tail = NULL ;
int i ; for ( i = 1 ; temp -> next && i < k ; i ++ ) temp = temp -> next ;
struct Node * nextBlock = temp -> next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , & tail , i ) ; else head = rotateHelper ( head , temp , d % k , & tail , k ) ;
tail -> next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
void push ( struct Node * * head_ref , int new_data ) { struct Node * new_node = new Node ; new_node -> data = new_data ; new_node -> next = ( * head_ref ) ; ( * head_ref ) = new_node ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
int main ( ) {
struct Node * head = NULL ;
for ( int i = 9 ; i > 0 ; i -= 1 ) push ( & head , i ) ; printf ( " Given ▁ linked ▁ list ▁ STRNEWLINE " ) ; printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; printf ( " Rotated by blocks Linked list " printList ( head ) ; return ( 0 ) ; }
struct Node { int data ; struct Node * next ; } ;
void setMiddleHead ( struct Node * * head ) { if ( * head == NULL ) return ;
struct Node * one_node = ( * head ) ;
struct Node * two_node = ( * head ) ;
struct Node * prev = NULL ; while ( two_node != NULL && two_node -> next != NULL ) {
prev = one_node ;
two_node = two_node -> next -> next ;
one_node = one_node -> next ; }
prev -> next = prev -> next -> next ; one_node -> next = ( * head ) ; ( * head ) = one_node ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( struct Node * ptr ) { while ( ptr != NULL ) { printf ( " % d ▁ " , ptr -> data ) ; ptr = ptr -> next ; } printf ( " STRNEWLINE " ) ; }
struct Node * head = NULL ; int i ; for ( i = 5 ; i > 0 ; i -- ) push ( & head , i ) ; printf ( " ▁ list ▁ before : ▁ " ) ; printList ( head ) ; setMiddleHead ( & head ) ; printf ( " ▁ list ▁ After : ▁ " ) ; printList ( head ) ; return 0 ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ; new_node -> prev = NULL ;
if ( ( * head_ref ) != NULL ) ( * head_ref ) -> prev = new_node ;
( * head_ref ) = new_node ; }
void insertAfter ( struct Node * prev_node , int new_data ) {
if ( prev_node == NULL ) { printf ( " the ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL " ) ; return ; }
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = prev_node -> next ;
prev_node -> next = new_node ;
new_node -> prev = prev_node ;
if ( new_node -> next != NULL ) new_node -> next -> prev = new_node ; }
void append ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; struct Node * last = * head_ref ; new_node -> data = new_data ;
new_node -> next = NULL ;
if ( * head_ref == NULL ) { new_node -> prev = NULL ; * head_ref = new_node ; return ; }
while ( last -> next != NULL ) last = last -> next ;
last -> next = new_node ;
new_node -> prev = last ; return ; }
struct node { int data ; struct node * left ; struct node * right ; } ; void printKDistant ( struct node * root , int k ) { if ( root == NULL k < 0 ) return ; if ( k == 0 ) { printf ( " % d ▁ " , root -> data ) ; return ; } printKDistant ( root -> left , k - 1 ) ; printKDistant ( root -> right , k - 1 ) ; }
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 8 ) ; printKDistant ( root , 2 ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <malloc.h> NEW_LINE #define COUNT  10
struct Node { int data ; struct Node * left , * right ; } ;
struct Node * newNode ( int data ) { struct Node * node = malloc ( sizeof ( struct Node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return node ; }
void print2DUtil ( struct Node * root , int space ) {
if ( root == NULL ) return ;
space += COUNT ;
print2DUtil ( root -> right , space ) ;
printf ( " STRNEWLINE " ) ; for ( int i = COUNT ; i < space ; i ++ ) printf ( " ▁ " ) ; printf ( " % d STRNEWLINE " , root -> data ) ;
print2DUtil ( root -> left , space ) ; }
void print2D ( struct Node * root ) {
print2DUtil ( root , 0 ) ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> left -> left -> left = newNode ( 8 ) ; root -> left -> left -> right = newNode ( 9 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 11 ) ; root -> right -> left -> left = newNode ( 12 ) ; root -> right -> left -> right = newNode ( 13 ) ; root -> right -> right -> left = newNode ( 14 ) ; root -> right -> right -> right = newNode ( 15 ) ; print2D ( root ) ; return 0 ; }
struct node * newNode ( int item ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = item ; temp -> left = temp -> right = NULL ; return temp ; }
void leftViewUtil ( struct node * root , int level , int * max_level ) {
if ( root == NULL ) return ;
if ( * max_level < level ) { printf ( " % d TABSYMBOL " , root -> data ) ; * max_level = level ; }
leftViewUtil ( root -> left , level + 1 , max_level ) ; leftViewUtil ( root -> right , level + 1 , max_level ) ; }
void leftView ( struct node * root ) { int max_level = 0 ; leftViewUtil ( root , 1 , & max_level ) ; }
int main ( ) { struct node * root = newNode ( 12 ) ; root -> left = newNode ( 10 ) ; root -> right = newNode ( 30 ) ; root -> right -> left = newNode ( 25 ) ; root -> right -> right = newNode ( 40 ) ; leftView ( root ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
unsigned int getLeafCount ( struct node * node ) { if ( node == NULL ) return 0 ; if ( node -> left == NULL && node -> right == NULL ) return 1 ; else return getLeafCount ( node -> left ) + getLeafCount ( node -> right ) ; }
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ;
printf ( " Leaf ▁ count ▁ of ▁ the ▁ tree ▁ is ▁ % d " , getLeafCount ( root ) ) ; getchar ( ) ; return 0 ; }
int cntRotations ( char s [ ] , int n ) { int lh = 0 , rh = 0 , i , ans = 0 ;
for ( i = 0 ; i < n / 2 ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { lh ++ ; }
for ( i = n / 2 ; i < n ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { rh ++ ; }
if ( lh > rh ) ans ++ ;
for ( i = 1 ; i < n ; ++ i ) { if ( s [ i - 1 ] == ' a ' s [ i - 1 ] == ' e ' s [ i - 1 ] == ' i ' s [ i - 1 ] == ' o ' s [ i - 1 ] == ' u ' ) { rh ++ ; lh -- ; } if ( s [ ( i - 1 + n / 2 ) % n ] == ' a ' || s [ ( i - 1 + n / 2 ) % n ] == ' e ' || s [ ( i - 1 + n / 2 ) % n ] == ' i ' || s [ ( i - 1 + n / 2 ) % n ] == ' o ' || s [ ( i - 1 + n / 2 ) % n ] == ' u ' ) { rh -- ; lh ++ ; } if ( lh > rh ) ans ++ ; }
return ans ; }
int main ( ) { char s [ ] = " abecidft " ; int n = strlen ( s ) ;
printf ( " % d " , cntRotations ( s , n ) ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
struct Node * rotateHelper ( struct Node * blockHead , struct Node * blockTail , int d , struct Node * * tail , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { struct Node * temp = blockHead ; for ( int i = 1 ; temp -> next -> next && i < k - 1 ; i ++ ) temp = temp -> next ; blockTail -> next = blockHead ; * tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , tail , k ) ; }
if ( d < 0 ) { blockTail -> next = blockHead ; * tail = blockHead ; return rotateHelper ( blockHead -> next , blockHead , d + 1 , tail , k ) ; } }
struct Node * rotateByBlocks ( struct Node * head , int k , int d ) {
if ( ! head ! head -> next ) return head ;
if ( d == 0 ) return head ; struct Node * temp = head , * tail = NULL ;
int i ; for ( i = 1 ; temp -> next && i < k ; i ++ ) temp = temp -> next ;
struct Node * nextBlock = temp -> next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , & tail , i ) ; else head = rotateHelper ( head , temp , d % k , & tail , k ) ;
tail -> next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
void push ( struct Node * * head_ref , int new_data ) { struct Node * new_node = new Node ; new_node -> data = new_data ; new_node -> next = ( * head_ref ) ; ( * head_ref ) = new_node ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
int main ( ) {
struct Node * head = NULL ;
for ( int i = 9 ; i > 0 ; i -= 1 ) push ( & head , i ) ; printf ( " Given ▁ linked ▁ list ▁ STRNEWLINE " ) ; printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; printf ( " Rotated by blocks Linked list " printList ( head ) ; return ( 0 ) ; }
struct node { int data ; struct node * left ; struct node * right ; struct node * nextRight ; } ; struct node * newnode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; node -> nextRight = NULL ; return ( node ) ; }
struct node * getNextRight ( struct node * p ) { struct node * temp = p -> nextRight ;
while ( temp != NULL ) { if ( temp -> left != NULL ) return temp -> left ; if ( temp -> right != NULL ) return temp -> right ; temp = temp -> nextRight ; }
return NULL ; }
void connect ( struct node * p ) { struct node * temp ; if ( ! p ) return ;
p -> nextRight = NULL ;
while ( p != NULL ) { struct node * q = p ;
while ( q != NULL ) {
if ( q -> left ) {
if ( q -> right ) q -> left -> nextRight = q -> right ; else q -> left -> nextRight = getNextRight ( q ) ; } if ( q -> right ) q -> right -> nextRight = getNextRight ( q ) ;
q = q -> nextRight ; }
if ( p -> left ) p = p -> left ; else if ( p -> right ) p = p -> right ; else p = getNextRight ( p ) ; } }
int main ( ) {
struct node * root = newnode ( 10 ) ; root -> left = newnode ( 8 ) ; root -> right = newnode ( 2 ) ; root -> left -> left = newnode ( 3 ) ; root -> right -> right = newnode ( 90 ) ;
connect ( root ) ;
struct node { int data ; struct node * left ; struct node * right ; struct node * nextRight ; } ;
void connect ( struct node * p ) {
p -> nextRight = NULL ;
connectRecur ( p ) ; }
void connectRecur ( struct node * p ) {
if ( ! p ) return ;
if ( p -> left ) p -> left -> nextRight = p -> right ;
if ( p -> right ) p -> right -> nextRight = ( p -> nextRight ) ? p -> nextRight -> left : NULL ;
connectRecur ( p -> left ) ; connectRecur ( p -> right ) ; }
int main ( ) {
struct node * root = newnode ( 10 ) ; root -> left = newnode ( 8 ) ; root -> right = newnode ( 2 ) ; root -> left -> left = newnode ( 3 ) ;
connect ( root ) ;
printf ( " Following ▁ are ▁ populated ▁ nextRight ▁ pointers ▁ in ▁ the ▁ tree ▁ " " ( -1 ▁ is ▁ printed ▁ if ▁ there ▁ is ▁ no ▁ nextRight ) ▁ STRNEWLINE " ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> data , root -> nextRight ? root -> nextRight -> data : -1 ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> left -> data , root -> left -> nextRight ? root -> left -> nextRight -> data : -1 ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> right -> data , root -> right -> nextRight ? root -> right -> nextRight -> data : -1 ) ; printf ( " nextRight ▁ of ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , root -> left -> left -> data , root -> left -> left -> nextRight ? root -> left -> left -> nextRight -> data : -1 ) ; return 0 ; }
void DeleteLast ( struct Node * * head ) { struct Node * current = * head , * temp = * head , * previous ;
if ( * head == NULL ) { printf ( " List is empty " return ; }
if ( current -> next == current ) { * head = NULL ; return ; }
while ( current -> next != * head ) { previous = current ; current = current -> next ; } previous -> next = current -> next ; * head = previous -> next ; free ( current ) ; return ; }
struct node { int data ; struct node * left ; struct node * right ; struct node * next ; }
void populateNext ( struct node * root ) {
struct node * next = NULL ; populateNextRecur ( root , & next ) ; }
void populateNextRecur ( struct node * p , struct node * * next_ref ) { if ( p ) {
populateNextRecur ( p -> right , next_ref ) ;
p -> next = * next_ref ;
* next_ref = p ;
populateNextRecur ( p -> left , next_ref ) ; } }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct node { int data ; struct node * left ; struct node * right ; } ;
int getLevelUtil ( struct node * node , int data , int level ) { if ( node == NULL ) return 0 ; if ( node -> data == data ) return level ; int downlevel = getLevelUtil ( node -> left , data , level + 1 ) ; if ( downlevel != 0 ) return downlevel ; downlevel = getLevelUtil ( node -> right , data , level + 1 ) ; return downlevel ; }
int getLevel ( struct node * node , int data ) { return getLevelUtil ( node , data , 1 ) ; }
int main ( ) { struct node * root ; int x ;
root = newNode ( 3 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 5 ) ; root -> left -> left = newNode ( 1 ) ; root -> left -> right = newNode ( 4 ) ; for ( x = 1 ; x <= 5 ; x ++ ) { int level = getLevel ( root , x ) ; if ( level ) printf ( " ▁ Level ▁ of ▁ % d ▁ is ▁ % d STRNEWLINE " , x , getLevel ( root , x ) ) ; else printf ( " ▁ % d ▁ is ▁ not ▁ present ▁ in ▁ tree ▁ STRNEWLINE " , x ) ; } getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int key ; struct Node * left , * right ; } ;
int findMirrorRec ( int target , struct Node * left , struct Node * right ) {
if ( left == NULL right == NULL ) return 0 ;
if ( left -> key == target ) return right -> key ; if ( right -> key == target ) return left -> key ;
int mirror_val = findMirrorRec ( target , left -> left , right -> right ) ; if ( mirror_val ) return mirror_val ;
findMirrorRec ( target , left -> right , right -> left ) ; }
int findMirror ( struct Node * root , int target ) { if ( root == NULL ) return 0 ; if ( root -> key == target ) return target ; return findMirrorRec ( target , root -> left , root -> right ) ; }
int main ( ) { struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> left -> right = newNode ( 7 ) ; root -> right = newNode ( 3 ) ; root -> right -> left = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; root -> right -> left -> left = newNode ( 8 ) ; root -> right -> left -> right = newNode ( 9 ) ;
int target = root -> left -> left -> key ; int mirror = findMirror ( root , target ) ; if ( mirror ) printf ( " Mirror ▁ of ▁ Node ▁ % d ▁ is ▁ Node ▁ % d STRNEWLINE " , target , mirror ) ; else printf ( " Mirror ▁ of ▁ Node ▁ % d ▁ is ▁ NULL ! STRNEWLINE " , target ) ; }
#include <iostream> NEW_LINE #include <queue> NEW_LINE using namespace std ;
struct node * newNode ( int data ) { struct node * node = new struct node ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
bool iterativeSearch ( node * root , int x ) {
if ( root == NULL ) return false ;
queue < node * > q ;
q . push ( root ) ;
while ( q . empty ( ) == false ) {
node * node = q . front ( ) ; if ( node -> data == x ) return true ;
q . pop ( ) ; if ( node -> left != NULL ) q . push ( node -> left ) ; if ( node -> right != NULL ) q . push ( node -> right ) ; } return false ; }
int main ( void ) { struct node * NewRoot = NULL ; struct node * root = newNode ( 2 ) ; root -> left = newNode ( 7 ) ; root -> right = newNode ( 5 ) ; root -> left -> right = newNode ( 6 ) ; root -> left -> right -> left = newNode ( 1 ) ; root -> left -> right -> right = newNode ( 11 ) ; root -> right -> right = newNode ( 9 ) ; root -> right -> right -> left = newNode ( 4 ) ; iterativeSearch ( root , 6 ) ? cout << " Found STRNEWLINE " : cout << " Not ▁ Found STRNEWLINE " ; iterativeSearch ( root , 12 ) ? cout << " Found STRNEWLINE " : cout << " Not ▁ Found STRNEWLINE " ; return 0 ; }
struct node { int data ; struct node * left , * right ; } ;
void printInoder ( struct node * root ) { if ( root != NULL ) { printInoder ( root -> left ) ; printf ( " % d ▁ " , root -> data ) ; printInoder ( root -> right ) ; } }
struct node * RemoveHalfNodes ( struct node * root ) { if ( root == NULL ) return NULL ; root -> left = RemoveHalfNodes ( root -> left ) ; root -> right = RemoveHalfNodes ( root -> right ) ; if ( root -> left == NULL && root -> right == NULL ) return root ;
if ( root -> left == NULL ) { struct node * new_root = root -> right ; free ( root ) ; return new_root ; }
if ( root -> right == NULL ) { struct node * new_root = root -> left ; free ( root ) ; return new_root ; } return root ; }
int main ( void ) { struct node * NewRoot = NULL ; struct node * root = newNode ( 2 ) ; root -> left = newNode ( 7 ) ; root -> right = newNode ( 5 ) ; root -> left -> right = newNode ( 6 ) ; root -> left -> right -> left = newNode ( 1 ) ; root -> left -> right -> right = newNode ( 11 ) ; root -> right -> right = newNode ( 9 ) ; root -> right -> right -> left = newNode ( 4 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ given ▁ tree ▁ STRNEWLINE " ) ; printInoder ( root ) ; NewRoot = RemoveHalfNodes ( root ) ; printf ( " Inorder traversal of the modified tree " printInoder ( NewRoot ) ; return 0 ; }
struct Node { int data ; struct Node * left , * right ; } ;
struct Node * newNode ( int data ) { struct Node * node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; node -> data = data ; node -> left = node -> right = NULL ; return ( node ) ; }
int findMax ( struct Node * root ) {
if ( root == NULL ) return INT_MIN ;
int res = root -> data ; int lres = findMax ( root -> left ) ; int rres = findMax ( root -> right ) ; if ( lres > res ) res = lres ; if ( rres > res ) res = rres ; return res ; }
int main ( void ) { struct Node * NewRoot = NULL ; struct Node * root = newNode ( 2 ) ; root -> left = newNode ( 7 ) ; root -> right = newNode ( 5 ) ; root -> left -> right = newNode ( 6 ) ; root -> left -> right -> left = newNode ( 1 ) ; root -> left -> right -> right = newNode ( 11 ) ; root -> right -> right = newNode ( 9 ) ; root -> right -> right -> left = newNode ( 4 ) ;
printf ( " Maximum ▁ element ▁ is ▁ % d ▁ STRNEWLINE " , findMax ( root ) ) ; return 0 ; }
int findMin ( struct Node * root ) { if ( root == NULL ) return INT_MAX ; int res = root -> data ; int lres = findMin ( root -> left ) ; int rres = findMin ( root -> right ) ; if ( lres < res ) res = lres ; if ( rres < res ) res = rres ; return res ; }
struct Node { int data ; struct Node * left , * right ; } ;
struct Node * extractLeafList ( struct Node * root , struct Node * * head_ref ) { if ( root == NULL ) return NULL ; if ( root -> left == NULL && root -> right == NULL ) { root -> right = * head_ref ; if ( * head_ref != NULL ) ( * head_ref ) -> left = root ; return NULL ; } root -> right = extractLeafList ( root -> right , head_ref ) ; root -> left = extractLeafList ( root -> left , head_ref ) ; return root ; }
void print ( struct Node * root ) { if ( root != NULL ) { print ( root -> left ) ; printf ( " % d ▁ " , root -> data ) ; print ( root -> right ) ; } }
void printList ( struct Node * head ) { while ( head ) { printf ( " % d ▁ " , head -> data ) ; head = head -> right ; } }
int main ( ) { struct Node * head = NULL ; struct Node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> right = newNode ( 6 ) ; root -> left -> left -> left = newNode ( 7 ) ; root -> left -> left -> right = newNode ( 8 ) ; root -> right -> right -> left = newNode ( 9 ) ; root -> right -> right -> right = newNode ( 10 ) ; printf ( " Inorder ▁ Trvaersal ▁ of ▁ given ▁ Tree ▁ is : STRNEWLINE " ) ; print ( root ) ; root = extractLeafList ( root , & head ) ; printf ( " Extracted Double Linked list is : " printList ( head ) ; printf ( " Inorder traversal of modified tree is : " print ( root ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * left ; struct Node * right ; } ;
void NthInorder ( struct Node * node , int n ) { static int count = 0 ; if ( node == NULL ) return ; if ( count <= n ) {
NthInorder ( node -> left , n ) ; count ++ ;
if ( count == n ) printf ( " % d ▁ " , node -> data ) ;
NthInorder ( node -> right , n ) ; } }
int main ( ) { struct Node * root = newNode ( 10 ) ; root -> left = newNode ( 20 ) ; root -> right = newNode ( 30 ) ; root -> left -> left = newNode ( 40 ) ; root -> left -> right = newNode ( 50 ) ; int n = 4 ; NthInorder ( root , n ) ; return 0 ; }
#include <stdio.h> NEW_LINE #define N  8 NEW_LINE int solveKTUtil ( int x , int y , int movei , int sol [ N ] [ N ] , int xMove [ ] , int yMove [ ] ) ;
int isSafe ( int x , int y , int sol [ N ] [ N ] ) { return ( x >= 0 && x < N && y >= 0 && y < N && sol [ x ] [ y ] == -1 ) ; }
void printSolution ( int sol [ N ] [ N ] ) { for ( int x = 0 ; x < N ; x ++ ) { for ( int y = 0 ; y < N ; y ++ ) printf ( " ▁ % 2d ▁ " , sol [ x ] [ y ] ) ; printf ( " STRNEWLINE " ) ; } }
int solveKT ( ) { int sol [ N ] [ N ] ;
for ( int x = 0 ; x < N ; x ++ ) for ( int y = 0 ; y < N ; y ++ ) sol [ x ] [ y ] = -1 ;
int xMove [ 8 ] = { 2 , 1 , -1 , -2 , -2 , -1 , 1 , 2 } ; int yMove [ 8 ] = { 1 , 2 , 2 , 1 , -1 , -2 , -2 , -1 } ;
sol [ 0 ] [ 0 ] = 0 ;
if ( solveKTUtil ( 0 , 0 , 1 , sol , xMove , yMove ) == 0 ) { printf ( " Solution ▁ does ▁ not ▁ exist " ) ; return 0 ; } else printSolution ( sol ) ; return 1 ; }
int solveKTUtil ( int x , int y , int movei , int sol [ N ] [ N ] , int xMove [ N ] , int yMove [ N ] ) { int k , next_x , next_y ; if ( movei == N * N ) return 1 ;
for ( k = 0 ; k < 8 ; k ++ ) { next_x = x + xMove [ k ] ; next_y = y + yMove [ k ] ; if ( isSafe ( next_x , next_y , sol ) ) { sol [ next_x ] [ next_y ] = movei ; if ( solveKTUtil ( next_x , next_y , movei + 1 , sol , xMove , yMove ) == 1 ) return 1 ; else
sol [ next_x ] [ next_y ] = -1 ; } } return 0 ; }
int main ( ) {
solveKT ( ) ; return 0 ; }
void printSolution ( int color [ ] ) { printf ( " Solution ▁ Exists : " " ▁ Following ▁ are ▁ the ▁ assigned ▁ colors ▁ STRNEWLINE " ) ; for ( int i = 0 ; i < V ; i ++ ) printf ( " ▁ % d ▁ " , color [ i ] ) ; printf ( " STRNEWLINE " ) ; }
bool isSafe ( bool graph [ V ] [ V ] , int color [ ] ) {
for ( int i = 0 ; i < V ; i ++ ) for ( int j = i + 1 ; j < V ; j ++ ) if ( graph [ i ] [ j ] && color [ j ] == color [ i ] ) return false ; return true ; }
bool graphColoring ( bool graph [ V ] [ V ] , int m , int i , int color [ V ] ) {
if ( i == V ) {
if ( isSafe ( graph , color ) ) {
printSolution ( color ) ; return true ; } return false ; }
for ( int j = 1 ; j <= m ; j ++ ) { color [ i ] = j ;
if ( graphColoring ( graph , m , i + 1 , color ) ) return true ; color [ i ] = 0 ; } return false ; }
int main ( ) {
bool graph [ V ] [ V ] = { { 0 , 1 , 1 , 1 } , { 1 , 0 , 1 , 0 } , { 1 , 1 , 0 , 1 } , { 1 , 0 , 1 , 0 } , } ;
int m = 3 ;
int color [ V ] ; for ( int i = 0 ; i < V ; i ++ ) color [ i ] = 0 ; if ( ! graphColoring ( graph , m , 0 , color ) ) printf ( " Solution ▁ does ▁ not ▁ exist " ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
void reverseLevelOrder ( struct node * root ) { int h = height ( root ) ; int i ; for ( i = h ; i >= 1 ; i -- ) printGivenLevel ( root , i ) ; }
void printGivenLevel ( struct node * root , int level ) { if ( root == NULL ) return ; if ( level == 1 ) printf ( " % d ▁ " , root -> data ) ; else if ( level > 1 ) { printGivenLevel ( root -> left , level - 1 ) ; printGivenLevel ( root -> right , level - 1 ) ; } }
int height ( struct node * node ) { if ( node == NULL ) return 0 ; else {
int lheight = height ( node -> left ) ; int rheight = height ( node -> right ) ;
if ( lheight > rheight ) return ( lheight + 1 ) ; else return ( rheight + 1 ) ; } }
struct node * root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; printf ( " Level ▁ Order ▁ traversal ▁ of ▁ binary ▁ tree ▁ is ▁ STRNEWLINE " ) ; reverseLevelOrder ( root ) ; return 0 ; }
bool bpm ( int table [ M ] [ N ] , int u , bool seen [ ] , int matchR [ ] ) {
for ( int v = 0 ; v < N ; v ++ ) {
if ( table [ u ] [ v ] > 0 && ! seen [ v ] ) {
seen [ v ] = true ;
if ( matchR [ v ] < 0 || bpm ( table , matchR [ v ] , seen , matchR ) ) { matchR [ v ] = u ; return true ; } } } return false ; }
int maxBPM ( int table [ M ] [ N ] ) {
memset ( matchR , -1 , sizeof ( matchR ) ) ;
int result = 0 ; for ( int u = 0 ; u < M ; u ++ ) {
bool seen [ N ] ; memset ( seen , 0 , sizeof ( seen ) ) ;
if ( bpm ( table , u , seen , matchR ) ) result ++ ; } cout << " The ▁ number ▁ of ▁ maximum ▁ packets ▁ sent ▁ in ▁ the ▁ time ▁ slot ▁ is ▁ " << result << " STRNEWLINE " ; for ( int x = 0 ; x < N ; x ++ ) if ( matchR [ x ] + 1 != 0 ) cout << " T " << matchR [ x ] + 1 << " - > ▁ R " << x + 1 << " STRNEWLINE " ; return result ; }
int main ( ) { int table [ M ] [ N ] = { { 0 , 2 , 0 } , { 3 , 0 , 1 } , { 2 , 4 , 0 } } ; int max_flow = maxBPM ( table ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int data ; struct node * left , * right ; } ;
void morrisTraversalPreorder ( struct node * root ) { while ( root ) {
if ( root -> left == NULL ) { printf ( " % d ▁ " , root -> data ) ; root = root -> right ; } else {
struct node * current = root -> left ; while ( current -> right && current -> right != root ) current = current -> right ;
if ( current -> right == root ) { current -> right = NULL ; root = root -> right ; }
else { printf ( " % d ▁ " , root -> data ) ; current -> right = root ; root = root -> left ; } } } }
void preorder ( struct node * root ) { if ( root ) { printf ( " % d ▁ " , root -> data ) ; preorder ( root -> left ) ; preorder ( root -> right ) ; } }
int main ( ) { struct node * root = NULL ; root = newNode ( 1 ) ; root -> left = newNode ( 2 ) ; root -> right = newNode ( 3 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 6 ) ; root -> right -> right = newNode ( 7 ) ; root -> left -> left -> left = newNode ( 8 ) ; root -> left -> left -> right = newNode ( 9 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 11 ) ; morrisTraversalPreorder ( root ) ; printf ( " STRNEWLINE " ) ; preorder ( root ) ; return 0 ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void insertAfter ( struct Node * prev_node , int new_data ) {
if ( prev_node == NULL ) { printf ( " the ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL " ) ; return ; }
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = prev_node -> next ;
prev_node -> next = new_node ; }
struct Node { char data ; struct Node * next ; } ; void reverse ( struct Node * * ) ; bool compareLists ( struct Node * , struct Node * ) ;
bool isPalindrome ( struct Node * head ) { struct Node * slow_ptr = head , * fast_ptr = head ; struct Node * second_half , * prev_of_slow_ptr = head ;
struct Node * midnode = NULL ;
bool res = true ; if ( head != NULL && head -> next != NULL ) {
while ( fast_ptr != NULL && fast_ptr -> next != NULL ) { fast_ptr = fast_ptr -> next -> next ;
prev_of_slow_ptr = slow_ptr ; slow_ptr = slow_ptr -> next ; }
if ( fast_ptr != NULL ) { midnode = slow_ptr ; slow_ptr = slow_ptr -> next ; }
second_half = slow_ptr ;
prev_of_slow_ptr -> next = NULL ;
reverse ( & second_half ) ;
res = compareLists ( head , second_half ) ;
reverse ( & second_half ) ;
if ( midnode != NULL ) { prev_of_slow_ptr -> next = midnode ; midnode -> next = second_half ; } else prev_of_slow_ptr -> next = second_half ; } return res ; }
void reverse ( struct Node * * head_ref ) { struct Node * prev = NULL ; struct Node * current = * head_ref ; struct Node * next ; while ( current != NULL ) { next = current -> next ; current -> next = prev ; prev = current ; current = next ; } * head_ref = prev ; }
bool compareLists ( struct Node * head1 , struct Node * head2 ) { struct Node * temp1 = head1 ; struct Node * temp2 = head2 ; while ( temp1 && temp2 ) { if ( temp1 -> data == temp2 -> data ) { temp1 = temp1 -> next ; temp2 = temp2 -> next ; } else return 0 ; }
if ( temp1 == NULL && temp2 == NULL ) return 1 ;
return 0 ; }
void push ( struct Node * * head_ref , char new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( struct Node * ptr ) { while ( ptr != NULL ) { printf ( " % c - > " , ptr -> data ) ; ptr = ptr -> next ; } printf ( " NULL STRNEWLINE " ) ; }
int main ( ) {
struct Node * head = NULL ; char str [ ] = " abacaba " ; int i ; for ( i = 0 ; str [ i ] != ' \0' ; i ++ ) { push ( & head , str [ i ] ) ; printList ( head ) ; isPalindrome ( head ) ? printf ( " Is ▁ Palindrome STRNEWLINE STRNEWLINE " ) : printf ( " Not ▁ Palindrome STRNEWLINE STRNEWLINE " ) ; } return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct Node { int data ; struct Node * next ; } ;
void swapNodes ( struct Node * * head_ref , int x , int y ) {
if ( x == y ) return ;
struct Node * prevX = NULL , * currX = * head_ref ; while ( currX && currX -> data != x ) { prevX = currX ; currX = currX -> next ; }
struct Node * prevY = NULL , * currY = * head_ref ; while ( currY && currY -> data != y ) { prevY = currY ; currY = currY -> next ; }
if ( currX == NULL currY == NULL ) return ;
if ( prevX != NULL ) prevX -> next = currY ;
else * head_ref = currY ;
if ( prevY != NULL ) prevY -> next = currX ;
else * head_ref = currX ;
struct Node * temp = currY -> next ; currY -> next = currX -> next ; currX -> next = temp ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
void printList ( struct Node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> next ; } }
int main ( ) { struct Node * start = NULL ;
push ( & start , 7 ) ; push ( & start , 6 ) ; push ( & start , 5 ) ; push ( & start , 4 ) ; push ( & start , 3 ) ; push ( & start , 2 ) ; push ( & start , 1 ) ; printf ( " Linked list before calling swapNodes ( ) " printList ( start ) ; swapNodes ( & start , 4 , 3 ) ; printf ( " Linked list after calling swapNodes ( ) " printList ( start ) ; return 0 ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ; new_node -> prev = NULL ;
if ( ( * head_ref ) != NULL ) ( * head_ref ) -> prev = new_node ;
( * head_ref ) = new_node ; }
void insertAfter ( struct Node * prev_node , int new_data ) {
if ( prev_node == NULL ) { printf ( " the ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL " ) ; return ; }
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; new_node -> data = new_data ;
new_node -> next = prev_node -> next ;
prev_node -> next = new_node ;
new_node -> prev = prev_node ;
if ( new_node -> next != NULL ) new_node -> next -> prev = new_node ; }
void append ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; struct Node * last = * head_ref ; new_node -> data = new_data ;
new_node -> next = NULL ;
if ( * head_ref == NULL ) { new_node -> prev = NULL ; * head_ref = new_node ; return ; }
while ( last -> next != NULL ) last = last -> next ;
last -> next = new_node ;
new_node -> prev = last ; return ; }
struct Node { struct Node * prev ; int info ; struct Node * next ; } ;
void nodeInsetail ( struct Node * * head , struct Node * * tail , int key ) { struct Node * p = new Node ; p -> info = key ; p -> next = NULL ;
if ( ( * head ) == NULL ) { ( * head ) = p ; ( * tail ) = p ; ( * head ) -> prev = NULL ; return ; }
if ( ( p -> info ) < ( ( * head ) -> info ) ) { p -> prev = NULL ; ( * head ) -> prev = p ; p -> next = ( * head ) ; ( * head ) = p ; return ; }
if ( ( p -> info ) > ( ( * tail ) -> info ) ) { p -> prev = ( * tail ) ; ( * tail ) -> next = p ; ( * tail ) = p ; return ; }
temp = ( * head ) -> next ; while ( ( temp -> info ) < ( p -> info ) ) temp = temp -> next ;
( temp -> prev ) -> next = p ; p -> prev = temp -> prev ; temp -> prev = p ; p -> next = temp ; }
void printList ( struct Node * temp ) { while ( temp != NULL ) { printf ( " % d ▁ " , temp -> info ) ; temp = temp -> next ; } }
int main ( ) { struct Node * left = NULL , * right = NULL ; nodeInsetail ( & left , & right , 30 ) ; nodeInsetail ( & left , & right , 50 ) ; nodeInsetail ( & left , & right , 90 ) ; nodeInsetail ( & left , & right , 10 ) ; nodeInsetail ( & left , & right , 40 ) ; nodeInsetail ( & left , & right , 110 ) ; nodeInsetail ( & left , & right , 60 ) ; nodeInsetail ( & left , & right , 95 ) ; nodeInsetail ( & left , & right , 23 ) ; printf ( " Doubly linked list on printing " ▁ " from left to right " printList ( left ) ; return 0 ; }
struct Node { int data ; struct Node * next ; } ;
void fun1 ( struct Node * head ) { if ( head == NULL ) return ; fun1 ( head -> next ) ; printf ( " % d ▁ " , head -> data ) ; }
void fun2 ( struct Node * head ) { if ( head == NULL ) return ; printf ( " % d ▁ " , head -> data ) ; if ( head -> next != NULL ) fun2 ( head -> next -> next ) ; printf ( " % d ▁ " , head -> data ) ; }
struct Node { int data ; struct Node * next ; } ;
void fun1 ( struct Node * head ) { if ( head == NULL ) return ; fun1 ( head -> next ) ; printf ( " % d ▁ " , head -> data ) ; }
void fun2 ( struct Node * start ) { if ( start == NULL ) return ; printf ( " % d ▁ " , start -> data ) ; if ( start -> next != NULL ) fun2 ( start -> next -> next ) ; printf ( " % d ▁ " , start -> data ) ; }
void push ( struct Node * * head_ref , int new_data ) {
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
struct Node * head = NULL ;
push ( & head , 5 ) ; push ( & head , 4 ) ; push ( & head , 3 ) ; push ( & head , 2 ) ; push ( & head , 1 ) ; printf ( " Output ▁ of ▁ fun1 ( ) ▁ for ▁ list ▁ 1 - > 2 - > 3 - > 4 - > 5 ▁ STRNEWLINE " ) ; fun1 ( head ) ; printf ( " Output of fun2 ( ) for list 1 -> 2 -> 3 -> 4 -> 5 " fun2 ( head ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h>
struct Node { int data ; struct Node * next ; } ;
int printsqrtn ( struct Node * head ) { struct Node * sqrtn = NULL ; int i = 1 , j = 1 ;
while ( head != NULL ) {
if ( i == j * j ) {
if ( sqrtn == NULL ) sqrtn = head ; else sqrtn = sqrtn -> next ;
j ++ ; } i ++ ; head = head -> next ; }
return sqrtn -> data ; } void print ( struct Node * head ) { while ( head != NULL ) { printf ( " % d ▁ " , head -> data ) ; head = head -> next ; } printf ( " STRNEWLINE " ) ; }
void push ( struct Node * * head_ref , int new_data ) {
struct Node * new_node = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ;
new_node -> data = new_data ;
new_node -> next = ( * head_ref ) ;
( * head_ref ) = new_node ; }
int main ( ) {
struct Node * head = NULL ; push ( & head , 40 ) ; push ( & head , 30 ) ; push ( & head , 20 ) ; push ( & head , 10 ) ; printf ( " Given ▁ linked ▁ list ▁ is : " ) ; print ( head ) ; printf ( " sqrt ( n ) th ▁ node ▁ is ▁ % d ▁ " , printsqrtn ( head ) ) ; return 0 ; }
struct node { char data ; struct node * left ; struct node * right ; } ;
struct node * buildTree ( char in [ ] , char pre [ ] , int inStrt , int inEnd ) { static int preIndex = 0 ; if ( inStrt > inEnd ) return NULL ;
struct node * tNode = newNode ( pre [ preIndex ++ ] ) ;
if ( inStrt == inEnd ) return tNode ;
int inIndex = search ( in , inStrt , inEnd , tNode -> data ) ;
tNode -> left = buildTree ( in , pre , inStrt , inIndex - 1 ) ; tNode -> right = buildTree ( in , pre , inIndex + 1 , inEnd ) ; return tNode ; }
int search ( char arr [ ] , int strt , int end , char value ) { int i ; for ( i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) return i ; } }
void printInorder ( struct node * node ) { if ( node == NULL ) return ;
printInorder ( node -> left ) ;
printf ( " % c ▁ " , node -> data ) ;
printInorder ( node -> right ) ; }
int main ( ) { char in [ ] = { ' D ' , ' B ' , ' E ' , ' A ' , ' F ' , ' C ' } ; char pre [ ] = { ' A ' , ' B ' , ' D ' , ' E ' , ' C ' , ' F ' } ; int len = sizeof ( in ) / sizeof ( in [ 0 ] ) ; struct node * root = buildTree ( in , pre , 0 , len - 1 ) ;
printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ constructed ▁ tree ▁ is ▁ STRNEWLINE " ) ; printInorder ( root ) ; getchar ( ) ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
struct node * insert ( struct node * node , int data ) {
if ( node == NULL ) return ( newNode ( data ) ) ; else {
if ( data <= node -> data ) node -> left = insert ( node -> left , data ) ; else node -> right = insert ( node -> right , data ) ;
return node ; } }
int minValue ( struct node * node ) { struct node * current = node ;
while ( current -> left != NULL ) { current = current -> left ; } return ( current -> data ) ; }
int main ( ) { struct node * root = NULL ; root = insert ( root , 4 ) ; insert ( root , 2 ) ; insert ( root , 1 ) ; insert ( root , 3 ) ; insert ( root , 6 ) ; insert ( root , 5 ) ; printf ( " Minimum value in BST is % d " , minValue ( root ) ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int data ; struct node * left , * right ; } ;
struct node * lca ( struct node * root , int n1 , int n2 ) { if ( root == NULL ) return NULL ;
if ( root -> data > n1 && root -> data > n2 ) return lca ( root -> left , n1 , n2 ) ;
if ( root -> data < n1 && root -> data < n2 ) return lca ( root -> right , n1 , n2 ) ; return root ; }
struct node * root = newNode ( 20 ) ; root -> left = newNode ( 8 ) ; root -> right = newNode ( 22 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 12 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 14 ) ; int n1 = 10 , n2 = 14 ; struct node * t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; n1 = 14 , n2 = 8 ; t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; n1 = 10 , n2 = 22 ; t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE #include <stdlib.h> NEW_LINE struct node { int data ; struct node * left , * right ; } ;
struct node * lca ( struct node * root , int n1 , int n2 ) { while ( root != NULL ) {
if ( root -> data > n1 && root -> data > n2 ) root = root -> left ;
else if ( root -> data < n1 && root -> data < n2 ) root = root -> right ; else break ; } return root ; }
struct node * root = newNode ( 20 ) ; root -> left = newNode ( 8 ) ; root -> right = newNode ( 22 ) ; root -> left -> left = newNode ( 4 ) ; root -> left -> right = newNode ( 12 ) ; root -> left -> right -> left = newNode ( 10 ) ; root -> left -> right -> right = newNode ( 14 ) ; int n1 = 10 , n2 = 14 ; struct node * t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; n1 = 14 , n2 = 8 ; t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; n1 = 10 , n2 = 22 ; t = lca ( root , n1 , n2 ) ; printf ( " LCA ▁ of ▁ % d ▁ and ▁ % d ▁ is ▁ % d ▁ STRNEWLINE " , n1 , n2 , t -> data ) ; getchar ( ) ; return 0 ; }
#include <stdio.h> NEW_LINE bool hasOnlyOneChild ( int pre [ ] , int size ) { int nextDiff , lastDiff ; for ( int i = 0 ; i < size - 1 ; i ++ ) { nextDiff = pre [ i ] - pre [ i + 1 ] ; lastDiff = pre [ i ] - pre [ size - 1 ] ; if ( nextDiff * lastDiff < 0 ) return false ; ; } return true ; }
int main ( ) { int pre [ ] = { 8 , 3 , 5 , 7 , 6 } ; int size = sizeof ( pre ) / sizeof ( pre [ 0 ] ) ; if ( hasOnlyOneChild ( pre , size ) == true ) printf ( " Yes " ) ; else printf ( " No " ) ; return 0 ; }
#include <stdio.h> NEW_LINE int hasOnlyOneChild ( int pre [ ] , int size ) {
int min , max ; if ( pre [ size - 1 ] > pre [ size - 2 ] ) { max = pre [ size - 1 ] ; min = pre [ size - 2 ] ) : else { max = pre [ size - 2 ] ; min = pre [ size - 1 ] ; }
for ( int i = size - 3 ; i >= 0 ; i -- ) { if ( pre [ i ] < min ) min = pre [ i ] ; else if ( pre [ i ] > max ) max = pre [ i ] ; else return false ; } return true ; }
int main ( ) { int pre [ ] = { 8 , 3 , 5 , 7 , 6 } ; int size = sizeof ( pre ) / sizeof ( pre [ 0 ] ) ; if ( hasOnlyOneChild ( pre , size ) ) printf ( " Yes " ) ; else printf ( " No " ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; struct node * parent ; } ; struct node * minValue ( struct node * node ) ;
struct node * insert ( struct node * node , int data ) {
if ( node == NULL ) return ( newNode ( data ) ) ; else { struct node * temp ;
if ( data <= node -> data ) { temp = insert ( node -> left , data ) ; node -> left = temp ; temp -> parent = node ; } else { temp = insert ( node -> right , data ) ; node -> right = temp ; temp -> parent = node ; }
return node ; } } struct node * inOrderSuccessor ( struct node * root , struct node * n ) {
if ( n -> right != NULL ) return minValue ( n -> right ) ;
struct node * p = n -> parent ; while ( p != NULL && n == p -> right ) { n = p ; p = p -> parent ; } return p ; }
struct node * minValue ( struct node * node ) { struct node * current = node ;
while ( current -> left != NULL ) { current = current -> left ; } return current ; }
int main ( ) { struct node * root = NULL , * temp , * succ , * min ; root = insert ( root , 20 ) ; root = insert ( root , 8 ) ; root = insert ( root , 22 ) ; root = insert ( root , 4 ) ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 14 ) ; temp = root -> left -> right -> right ; succ = inOrderSuccessor ( root , temp ) ; if ( succ != NULL ) printf ( " Inorder Successor of % d is % d " , temp -> data , succ -> data ) ; else printf ( " Inorder Successor doesn ' exit " getchar ( ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
struct node * constructTreeUtil ( int pre [ ] , int post [ ] , int * preIndex , int l , int h , int size ) {
if ( * preIndex >= size l > h ) return NULL ;
struct node * root = newNode ( pre [ * preIndex ] ) ; ++ * preIndex ;
if ( l == h ) return root ;
int i ; for ( i = l ; i <= h ; ++ i ) if ( pre [ * preIndex ] == post [ i ] ) break ;
if ( i <= h ) { root -> left = constructTreeUtil ( pre , post , preIndex , l , i , size ) ; root -> right = constructTreeUtil ( pre , post , preIndex , i + 1 , h , size ) ; } return root ; }
struct node * constructTree ( int pre [ ] , int post [ ] , int size ) { int preIndex = 0 ; return constructTreeUtil ( pre , post , & preIndex , 0 , size - 1 , size ) ; }
void printInorder ( struct node * node ) { if ( node == NULL ) return ; printInorder ( node -> left ) ; printf ( " % d ▁ " , node -> data ) ; printInorder ( node -> right ) ; }
int main ( ) { int pre [ ] = { 1 , 2 , 4 , 8 , 9 , 5 , 3 , 6 , 7 } ; int post [ ] = { 8 , 9 , 4 , 5 , 2 , 6 , 7 , 3 , 1 } ; int size = sizeof ( pre ) / sizeof ( pre [ 0 ] ) ; struct node * root = constructTree ( pre , post , size ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ constructed ▁ tree : ▁ STRNEWLINE " ) ; printInorder ( root ) ; return 0 ; }
struct node { int key ; struct node * left ; struct node * right ; } ;
int Ceil ( struct node * root , int input ) {
if ( root == NULL ) return -1 ;
if ( root -> key == input ) return root -> key ;
if ( root -> key < input ) return Ceil ( root -> right , input ) ;
int ceil = Ceil ( root -> left , input ) ; return ( ceil >= input ) ? ceil : root -> key ; }
int main ( ) { struct node * root = newNode ( 8 ) ; root -> left = newNode ( 4 ) ; root -> right = newNode ( 12 ) ; root -> left -> left = newNode ( 2 ) ; root -> left -> right = newNode ( 6 ) ; root -> right -> left = newNode ( 10 ) ; root -> right -> right = newNode ( 14 ) ; for ( int i = 0 ; i < 16 ; i ++ ) printf ( " % d ▁ % d STRNEWLINE " , i , Ceil ( root , i ) ) ; return 0 ; }
struct node * newNode ( int item ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> key = item ; temp -> left = temp -> right = NULL ; temp -> count = 1 ; return temp ; }
void inorder ( struct node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; printf ( " % d ( % d ) ▁ " , root -> key , root -> count ) ; inorder ( root -> right ) ; } }
struct node * insert ( struct node * node , int key ) {
if ( node == NULL ) return newNode ( key ) ;
if ( key == node -> key ) { ( node -> count ) ++ ; return node ; }
if ( key < node -> key ) node -> left = insert ( node -> left , key ) ; else node -> right = insert ( node -> right , key ) ;
return node ; }
struct node * minValueNode ( struct node * node ) { struct node * current = node ;
while ( current -> left != NULL ) current = current -> left ; return current ; }
struct node * deleteNode ( struct node * root , int key ) {
if ( root == NULL ) return root ;
if ( key < root -> key ) root -> left = deleteNode ( root -> left , key ) ;
else if ( key > root -> key ) root -> right = deleteNode ( root -> right , key ) ;
else {
if ( root -> count > 1 ) { ( root -> count ) -- ; return root ; }
if ( root -> left == NULL ) { struct node * temp = root -> right ; free ( root ) ; return temp ; } else if ( root -> right == NULL ) { struct node * temp = root -> left ; free ( root ) ; return temp ; }
struct node * temp = minValueNode ( root -> right ) ;
root -> key = temp -> key ;
root -> right = deleteNode ( root -> right , temp -> key ) ; } return root ; }
int main ( ) {
struct node * root = NULL ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 20 ) ; root = insert ( root , 9 ) ; root = insert ( root , 11 ) ; root = insert ( root , 10 ) ; root = insert ( root , 12 ) ; root = insert ( root , 12 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ given ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; printf ( " Delete 20 " root = deleteNode ( root , 20 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; printf ( " Delete 12 " root = deleteNode ( root , 12 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; printf ( " Delete 9 " root = deleteNode ( root , 9 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ modified ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; return 0 ; }
struct node * newNode ( int item ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> key = item ; temp -> left = temp -> right = NULL ; return temp ; }
void inorder ( struct node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; printf ( " % d ▁ " , root -> key ) ; inorder ( root -> right ) ; } }
struct node * insert ( struct node * node , int key ) {
if ( node == NULL ) return newNode ( key ) ;
if ( key < node -> key ) node -> left = insert ( node -> left , key ) ; else node -> right = insert ( node -> right , key ) ;
return node ; }
struct node * minValueNode ( struct node * node ) { struct node * current = node ;
while ( current -> left != NULL ) current = current -> left ; return current ; }
struct node * deleteNode ( struct node * root , int key ) {
if ( root == NULL ) return root ;
if ( key < root -> key ) root -> left = deleteNode ( root -> left , key ) ;
else if ( key > root -> key ) root -> right = deleteNode ( root -> right , key ) ;
else {
if ( root -> left == NULL ) { struct node * temp = root -> right ; free ( root ) ; return temp ; } else if ( root -> right == NULL ) { struct node * temp = root -> left ; free ( root ) ; return temp ; }
struct node * temp = minValueNode ( root -> right ) ;
root -> key = temp -> key ;
root -> right = deleteNode ( root -> right , temp -> key ) ; } return root ; }
struct node * changeKey ( struct node * root , int oldVal , int newVal ) {
root = deleteNode ( root , oldVal ) ;
root = insert ( root , newVal ) ;
return root ; }
int main ( ) {
struct node * root = NULL ; root = insert ( root , 50 ) ; root = insert ( root , 30 ) ; root = insert ( root , 20 ) ; root = insert ( root , 40 ) ; root = insert ( root , 70 ) ; root = insert ( root , 60 ) ; root = insert ( root , 80 ) ; printf ( " Inorder ▁ traversal ▁ of ▁ the ▁ given ▁ tree ▁ STRNEWLINE " ) ; inorder ( root ) ; root = changeKey ( root , 40 , 10 ) ;
printf ( " Inorder traversal of the modified tree " inorder ( root ) ; return 0 ; }
struct Node { struct Node * left ; int info ; struct Node * right ; } ;
void insert ( struct Node * * rt , int key ) {
if ( * rt == NULL ) { ( * rt ) = ( struct Node * ) malloc ( sizeof ( struct Node ) ) ; ( * rt ) -> left = NULL ; ( * rt ) -> right = NULL ; ( * rt ) -> info = key ; }
else if ( key < ( ( * rt ) -> info ) ) insert ( & ( ( * rt ) -> left ) , key ) ; else insert ( & ( * rt ) -> right , key ) ; }
int check ( int num ) { int sum = 0 , i = num , sum_of_digits , prod_of_digits ;
if ( num < 10 num > 99 ) return 0 ; else { sum_of_digits = ( i % 10 ) + ( i / 10 ) ; prod_of_digits = ( i % 10 ) * ( i / 10 ) ; sum = sum_of_digits + prod_of_digits ; } if ( sum == num ) return 1 ; else return 0 ; }
void countSpecialDigit ( struct Node * rt , int * c ) { int x ; if ( rt == NULL ) return ; else { x = check ( rt -> info ) ; if ( x == 1 ) * c = * c + 1 ; countSpecialDigit ( rt -> left , c ) ; countSpecialDigit ( rt -> right , c ) ; } }
int main ( ) { struct Node * root = NULL ; int count = 0 ; insert ( & root , 50 ) ; insert ( & root , 29 ) ; insert ( & root , 59 ) ; insert ( & root , 19 ) ; insert ( & root , 53 ) ; insert ( & root , 556 ) ; insert ( & root , 56 ) ; insert ( & root , 94 ) ; insert ( & root , 13 ) ;
countSpecialDigit ( root , & count ) ; printf ( " % d " , count ) ; return 0 ; }
struct node * buildTree ( int inorder [ ] , int start , int end ) { if ( start > end ) return NULL ;
int i = max ( inorder , start , end ) ;
struct node * root = newNode ( inorder [ i ] ) ;
if ( start == end ) return root ;
root -> left = buildTree ( inorder , start , i - 1 ) ; root -> right = buildTree ( inorder , i + 1 , end ) ; return root ; }
int max ( int arr [ ] , int strt , int end ) { int i , max = arr [ strt ] , maxind = strt ; for ( i = strt + 1 ; i <= end ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; maxind = i ; } } return maxind ; }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return node ; }
void printInorder ( struct node * node ) { if ( node == NULL ) return ;
printInorder ( node -> left ) ;
printf ( " % d ▁ " , node -> data ) ;
printInorder ( node -> right ) ; }
int main ( ) {
int inorder [ ] = { 5 , 10 , 40 , 30 , 28 } ; int len = sizeof ( inorder ) / sizeof ( inorder [ 0 ] ) ; struct node * root = buildTree ( inorder , 0 , len - 1 ) ;
printf ( " Inorder traversal of the constructed tree is " printInorder ( root ) ; return 0 ; }
void fill0X ( int m , int n ) {
int i , k = 0 , l = 0 ;
int r = m , c = n ;
char a [ m ] [ n ] ;
char x = ' X ' ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) a [ k ] [ i ] = x ; k ++ ;
for ( i = k ; i < m ; ++ i ) a [ i ] [ n - 1 ] = x ; n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = x ; m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) a [ i ] [ l ] = x ; l ++ ; }
x = ( x == '0' ) ? ' X ' : '0' ; }
for ( i = 0 ; i < r ; i ++ ) { for ( int j = 0 ; j < c ; j ++ ) printf ( " % c ▁ " , a [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } }
int main ( ) { puts ( " Output ▁ for ▁ m ▁ = ▁ 5 , ▁ n ▁ = ▁ 6" ) ; fill0X ( 5 , 6 ) ; puts ( " Output for m = 4 , n = 4 " ) ; fill0X ( 4 , 4 ) ; puts ( " Output for m = 3 , n = 4 " ) ; fill0X ( 3 , 4 ) ; return 0 ; }
#include <bits/stdc++.h> NEW_LINE using namespace std ; #define N  3
void interchangeDiagonals ( int array [ ] [ N ] ) {
for ( int i = 0 ; i < N ; ++ i ) if ( i != N / 2 ) swap ( array [ i ] [ i ] , array [ i ] [ N - i - 1 ] ) ; for ( int i = 0 ; i < N ; ++ i ) { for ( int j = 0 ; j < N ; ++ j ) printf ( " ▁ % d " , array [ i ] [ j ] ) ; printf ( " STRNEWLINE " ) ; } }
int main ( ) { int array [ N ] [ N ] = { 4 , 5 , 6 , 1 , 2 , 3 , 7 , 8 , 9 } ; interchangeDiagonals ( array ) ; return 0 ; }
#define SIZE  50
struct node { int data ; struct node * right , * left ; } ;
struct Queue { int front , rear ; int size ; struct node * * array ; } ;
struct node * newNode ( int data ) { struct node * temp = ( struct node * ) malloc ( sizeof ( struct node ) ) ; temp -> data = data ; temp -> left = temp -> right = NULL ; return temp ; }
struct Queue * createQueue ( int size ) { struct Queue * queue = ( struct Queue * ) malloc ( sizeof ( struct Queue ) ) ; queue -> front = queue -> rear = -1 ; queue -> size = size ; queue -> array = ( struct node * * ) malloc ( queue -> size * sizeof ( struct node * ) ) ; int i ; for ( i = 0 ; i < size ; ++ i ) queue -> array [ i ] = NULL ; return queue ; }
int isEmpty ( struct Queue * queue ) { return queue -> front == -1 ; } int isFull ( struct Queue * queue ) { return queue -> rear == queue -> size - 1 ; } int hasOnlyOneItem ( struct Queue * queue ) { return queue -> front == queue -> rear ; } void Enqueue ( struct node * root , struct Queue * queue ) { if ( isFull ( queue ) ) return ; queue -> array [ ++ queue -> rear ] = root ; if ( isEmpty ( queue ) ) ++ queue -> front ; } struct node * Dequeue ( struct Queue * queue ) { if ( isEmpty ( queue ) ) return NULL ; struct node * temp = queue -> array [ queue -> front ] ; if ( hasOnlyOneItem ( queue ) ) queue -> front = queue -> rear = -1 ; else ++ queue -> front ; return temp ; } struct node * getFront ( struct Queue * queue ) { return queue -> array [ queue -> front ] ; }
int hasBothChild ( struct node * temp ) { return temp && temp -> left && temp -> right ; }
void insert ( struct node * * root , int data , struct Queue * queue ) {
struct node * temp = newNode ( data ) ;
if ( ! * root ) * root = temp ; else {
struct node * front = getFront ( queue ) ;
if ( ! front -> left ) front -> left = temp ;
else if ( ! front -> right ) front -> right = temp ;
if ( hasBothChild ( front ) ) Dequeue ( queue ) ; }
Enqueue ( temp , queue ) ; }
void levelOrder ( struct node * root ) { struct Queue * queue = createQueue ( SIZE ) ; Enqueue ( root , queue ) ; while ( ! isEmpty ( queue ) ) { struct node * temp = Dequeue ( queue ) ; printf ( " % d ▁ " , temp -> data ) ; if ( temp -> left ) Enqueue ( temp -> left , queue ) ; if ( temp -> right ) Enqueue ( temp -> right , queue ) ; } }
int main ( ) { struct node * root = NULL ; struct Queue * queue = createQueue ( SIZE ) ; int i ; for ( i = 1 ; i <= 12 ; ++ i ) insert ( & root , i , queue ) ; levelOrder ( root ) ; return 0 ; }
struct node { int data ; node * left ; node * right ; } ;
node * bintree2listUtil ( node * root ) {
if ( root == NULL ) return root ;
if ( root -> left != NULL ) {
node * left = bintree2listUtil ( root -> left ) ;
for ( ; left -> right != NULL ; left = left -> right ) ;
left -> right = root ;
root -> left = left ; }
if ( root -> right != NULL ) {
node * right = bintree2listUtil ( root -> right ) ;
for ( ; right -> left != NULL ; right = right -> left ) ;
right -> left = root ;
root -> right = right ; } return root ; }
node * bintree2list ( node * root ) {
if ( root == NULL ) return root ;
root = bintree2listUtil ( root ) ;
while ( root -> left != NULL ) root = root -> left ; return ( root ) ; }
void printList ( node * node ) { while ( node != NULL ) { printf ( " % d ▁ " , node -> data ) ; node = node -> right ; } }
int main ( ) {
node * root = newNode ( 10 ) ; root -> left = newNode ( 12 ) ; root -> right = newNode ( 15 ) ; root -> left -> left = newNode ( 25 ) ; root -> left -> right = newNode ( 30 ) ; root -> right -> left = newNode ( 36 ) ;
node * head = bintree2list ( root ) ;
printList ( head ) ; return 0 ; }
struct node { int data ; struct node * left , * right ; } ;
void inorder ( struct node * root ) { if ( root != NULL ) { inorder ( root -> left ) ; printf ( " TABSYMBOL % d " , root -> data ) ; inorder ( root -> right ) ; } }
void fixPrevPtr ( struct node * root ) { static struct node * pre = NULL ; if ( root != NULL ) { fixPrevPtr ( root -> left ) ; root -> left = pre ; pre = root ; fixPrevPtr ( root -> right ) ; } }
struct node * fixNextPtr ( struct node * root ) { struct node * prev = NULL ;
while ( root && root -> right != NULL ) root = root -> right ;
while ( root && root -> left != NULL ) { prev = root ; root = root -> left ; root -> right = prev ; }
return ( root ) ; }
struct node * BTToDLL ( struct node * root ) {
fixPrevPtr ( root ) ;
return fixNextPtr ( root ) ; }
void printList ( struct node * root ) { while ( root != NULL ) { printf ( " TABSYMBOL % d " , root -> data ) ; root = root -> right ; } }
struct node * root = newNode ( 10 ) ; root -> left = newNode ( 12 ) ; root -> right = newNode ( 15 ) ; root -> left -> left = newNode ( 25 ) ; root -> left -> right = newNode ( 30 ) ; root -> right -> left = newNode ( 36 ) ; printf ( " Inorder Tree Traversal " inorder ( root ) ; struct node * head = BTToDLL ( root ) ; printf ( " DLL Traversal " printList ( head ) ; return 0 ; }
#define M  4 NEW_LINE #define N  5
int findCommon ( int mat [ M ] [ N ] ) {
int column [ M ] ;
min_row = 0 ;
while ( column [ min_row ] >= 0 ) {
for ( i = 0 ; i < M ; i ++ ) { if ( mat [ i ] [ column [ i ] ] < mat [ min_row ] [ column [ min_row ] ] ) min_row = i ; }
int eq_count = 0 ;
for ( i = 0 ; i < M ; i ++ ) {
if ( mat [ i ] [ column [ i ] ] > mat [ min_row ] [ column [ min_row ] ] ) { if ( column [ i ] == 0 ) return -1 ;
column [ i ] -= 1 ; } else eq_count ++ ; }
if ( eq_count == M ) return mat [ min_row ] [ column [ min_row ] ] ; } return -1 ; }
int main ( ) { int mat [ M ] [ N ] = { { 1 , 2 , 3 , 4 , 5 } , { 2 , 4 , 5 , 8 , 10 } , { 3 , 5 , 7 , 9 , 11 } , { 1 , 3 , 5 , 7 , 9 } , } ; int result = findCommon ( mat ) ; if ( result == -1 ) printf ( " No ▁ common ▁ element " ) ; else printf ( " Common ▁ element ▁ is ▁ % d " , result ) ; return 0 ; }
void convertTree ( struct node * node ) { int left_data = 0 , right_data = 0 , diff ;
if ( node == NULL || ( node -> left == NULL && node -> right == NULL ) ) return ; else {
convertTree ( node -> left ) ; convertTree ( node -> right ) ;
if ( node -> left != NULL ) left_data = node -> left -> data ;
if ( node -> right != NULL ) right_data = node -> right -> data ;
diff = left_data + right_data - node -> data ;
if ( diff > 0 ) node -> data = node -> data + diff ;
if ( diff < 0 )
increment ( node , - diff ) ; } }
void increment ( struct node * node , int diff ) {
if ( node -> left != NULL ) { node -> left -> data = node -> left -> data + diff ;
increment ( node -> left , diff ) ; }
else if ( node -> right != NULL ) { node -> right -> data = node -> right -> data + diff ;
increment ( node -> right , diff ) ; } }
void printInorder ( struct node * node ) { if ( node == NULL ) return ;
printInorder ( node -> left ) ;
printf ( " % d ▁ " , node -> data ) ;
printInorder ( node -> right ) ; }
struct node * newNode ( int data ) { struct node * node = ( struct node * ) malloc ( sizeof ( struct node ) ) ; node -> data = data ; node -> left = NULL ; node -> right = NULL ; return ( node ) ; }
int main ( ) { struct node * root = newNode ( 50 ) ; root -> left = newNode ( 7 ) ; root -> right = newNode ( 2 ) ; root -> left -> left = newNode ( 3 ) ; root -> left -> right = newNode ( 5 ) ; root -> right -> left = newNode ( 1 ) ; root -> right -> right = newNode ( 30 ) ; printf ( " Inorder traversal before conversion " printInorder ( root ) ; convertTree ( root ) ; printf ( " Inorder traversal after conversion " printInorder ( root ) ; getchar ( ) ; return 0 ; }
struct node { int data ; struct node * left ; struct node * right ; } ;
int toSumTree ( struct node * node ) {
if ( node == NULL ) return 0 ;
int old_val = node -> data ;
node -> data = toSumTree ( node -> left ) + toSumTree ( node -> right ) ;
return node -> data + old_val ; }
void printInorder ( struct node * node ) { if ( node == NULL ) return ; printInorder ( node -> left ) ; printf ( " % d ▁ " , node -> data ) ; printInorder ( node -> right ) ; }
struct node * newNode ( int data ) { struct node * temp = new struct node ; temp -> data = data ; temp -> left = NULL ; temp -> right = NULL ; return temp ; }
int main ( ) { struct node * root = NULL ; int x ;
root = newNode ( 10 ) ; root -> left = newNode ( -2 ) ; root -> right = newNode ( 6 ) ; root -> left -> left = newNode ( 8 ) ; root -> left -> right = newNode ( -4 ) ; root -> right -> left = newNode ( 7 ) ; root -> right -> right = newNode ( 5 ) ; toSumTree ( root ) ;
printf ( " Inorder ▁ Traversal ▁ of ▁ the ▁ resultant ▁ tree ▁ is : ▁ STRNEWLINE " ) ; printInorder ( root ) ; getchar ( ) ; return 0 ; }
