function towerOfHanoi ( n , from_rod , to_rod , aux_rod ) { if ( n == 1 ) { document . write ( " " + from_rod + " " + to_rod + " " ) ; return ; } towerOfHanoi ( n - 1 , from_rod , aux_rod , to_rod ) ; document . write ( " " + n + " " + from_rod + " " + to_rod + " " ) ; towerOfHanoi ( n - 1 , aux_rod , to_rod , from_rod ) ; }
var n = 4 ;
towerOfHanoi ( n , ' ' , ' ' , ' ' ) ;
var arr = [ 10 , 20 , 30 , 50 , 10 , 70 , 30 ] ; function printMaxOfMin ( n ) {
for ( k = 1 ; k <= n ; k ++ ) {
var maxOfMin = Number . MIN_VALUE ;
for ( i = 0 ; i <= n - k ; i ++ ) {
var min = arr [ i ] ; for ( j = 1 ; j < k ; j ++ ) { if ( arr [ i + j ] < min ) min = arr [ i + j ] ; }
if ( min > maxOfMin ) maxOfMin = min ; }
document . write ( maxOfMin + " " ) ; } }
printMaxOfMin ( arr . length ) ;
function heapify ( arr , n , i ) {
var largest = i ;
var l = 2 * i + 1 ;
var r = 2 * i + 2 ;
if ( l < n && arr [ l ] > arr [ largest ] ) largest = l ;
if ( r < n && arr [ r ] > arr [ largest ] ) largest = r ;
if ( largest != i ) { var swap = arr [ i ] ; arr [ i ] = arr [ largest ] ; arr [ largest ] = swap ;
heapify ( arr , n , largest ) ; } }
function sort ( arr ) { var n = arr . length ;
for ( var i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( var i = n - 1 ; i > 0 ; i -- ) {
var temp = arr [ 0 ] ; arr [ 0 ] = arr [ i ] ; arr [ i ] = temp ;
heapify ( arr , i , 0 ) ; } }
function printArray ( arr ) { var n = arr . length ; for ( var i = 0 ; i < n ; ++ i ) document . write ( arr [ i ] + " " ) ; }
var arr = [ 12 , 11 , 13 , 5 , 6 , 7 ] ; var n = arr . length ; sort ( arr ) ; document . write ( " " ) ; printArray ( arr , n ) ;
function isHeap ( arr , n ) {
for ( let i = 0 ; i <= Math . floor ( ( n - 2 ) / 2 ) ; i ++ ) {
if ( arr [ 2 * i + 1 ] > arr [ i ] ) return false ;
if ( 2 * i + 2 < n && arr [ 2 * i + 2 ] > arr [ i ] ) return false ; } return true ; }
let arr = [ 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 ] ; let n = arr . length ; if ( isHeap ( arr , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function generate_derangement ( N ) {
let S = [ ] ; for ( let i = 1 ; i <= N ; i ++ ) S [ i ] = i ;
let D = [ ] ; for ( let i = 1 ; i <= N ; i += 2 ) { if ( i == N ) {
D [ N ] = S [ N - 1 ] ; D [ N - 1 ] = S [ N ] ; } else { D [ i ] = i + 1 ; D [ i + 1 ] = i ; } }
for ( let i = 1 ; i <= N ; i ++ ) document . write ( D [ i ] + " " ) ; document . write ( " " ) ; }
generate_derangement ( 10 ) ;
function sumBetweenTwoKth ( arr , k1 , k2 ) {
arr . sort ( function ( a , b ) { return a - b } ) ;
var result = 0 ; for ( var i = k1 ; i < k2 - 1 ; i ++ ) result += arr [ i ] ; return result ; }
var arr = [ 20 , 8 , 22 , 4 , 12 , 10 , 14 ] ; var k1 = 3 , k2 = 6 ; var n = arr . length ; document . write ( sumBetweenTwoKth ( arr , k1 , k2 ) ) ;
function minSum ( a , n ) {
a . sort ( ) ; let num1 = 0 ; let num2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) num1 = num1 * 10 + a [ i ] ; else num2 = num2 * 10 + a [ i ] ; } return num2 + num1 ; }
let arr = [ 5 , 3 , 0 , 7 , 4 ] ; let n = arr . length ; document . write ( " " + minSum ( arr , n ) ) ;
let N = 3 ; let M = 4 ;
function printDistance ( mat ) { let ans = new Array ( N ) ;
for ( let i = 0 ; i < N ; i ++ ) { ans [ i ] = new Array ( M ) ; for ( let j = 0 ; j < M ; j ++ ) { ans [ i ] [ j ] = Number . MAX_VALUE ; } }
for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < M ; j ++ ) {
for ( let k = 0 ; k < N ; k ++ ) for ( let l = 0 ; l < M ; l ++ ) {
if ( mat [ k ] [ l ] == 1 ) ans [ i ] [ j ] = Math . min ( ans [ i ] [ j ] , Math . abs ( i - k ) + Math . abs ( j - l ) ) ; } }
for ( let i = 0 ; i < N ; i ++ ) { for ( let j = 0 ; j < M ; j ++ ) document . write ( ans [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let mat = [ [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 1 , 1 ] , [ 0 , 1 , 1 , 0 ] ] printDistance ( mat ) ;
function mostFrequent ( arr , n ) {
arr . sort ( ) ;
let max_count = 1 , res = arr [ 0 ] ; let curr_count = 1 ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
let arr = [ 1 , 5 , 2 , 1 , 3 , 2 , 1 ] ; let n = arr . length ; document . write ( mostFrequent ( arr , n ) ) ;
function aredisjoint ( set1 , set2 ) {
for ( let i = 0 ; i < set1 . length ; i ++ ) { for ( let j = 0 ; j < set2 . length ; j ++ ) { if ( set1 [ i ] == set2 [ j ] ) return false ; } }
return true ; }
let set1 = [ 12 , 34 , 11 , 9 , 3 ] ; let set2 = [ 7 , 2 , 1 , 5 ] ; result = aredisjoint ( set1 , set2 ) ; if ( result ) document . write ( " " ) ; else document . write ( " " ) ;
function findMissing ( a , b , n , m ) { for ( let i = 0 ; i < n ; i ++ ) { let j ; for ( j = 0 ; j < m ; j ++ ) if ( a [ i ] == b [ j ] ) break ; if ( j == m ) document . write ( a [ i ] + " " ) ; } }
let a = [ 1 , 2 , 6 , 3 , 4 , 5 ] ; let b = [ 2 , 4 , 3 , 1 , 0 ] ; let n = a . length ; let m = b . length ; findMissing ( a , b , n , m ) ;
function areEqual ( arr1 , arr2 ) { let n = arr1 . length ; let m = arr2 . length ;
if ( n != m ) return false ;
arr1 . sort ( ) ; arr2 . sort ( ) ;
for ( let i = 0 ; i < n ; i ++ ) if ( arr1 [ i ] != arr2 [ i ] ) return false ;
return true ; }
let arr1 = [ 3 , 5 , 2 , 5 , 2 ] ; let arr2 = [ 2 , 3 , 5 , 5 , 2 ] ; if ( areEqual ( arr1 , arr2 ) ) document . write ( " " ) ; else document . write ( " " ) ;
function isProduct ( arr , n , x ) {
for ( var i = 0 ; i < n - 1 ; i ++ ) for ( var j = i + 1 ; i < n ; i ++ ) if ( arr [ i ] * arr [ j ] == x ) return true ; return false ; }
var arr = [ 10 , 20 , 9 , 40 ] ; var x = 400 ; var n = arr . length ; isProduct ( arr , n , x ) ? document . write ( " " ) : document . write ( " " ) ; x = 190 ; isProduct ( arr , n , x ) ? document . write ( " " ) : document . write ( " " ) ;
function findGreatest ( arr , n ) { let result = - 1 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n - 1 ; j ++ ) for ( let k = j + 1 ; k < n ; k ++ ) if ( arr [ j ] * arr [ k ] == arr [ i ] ) result = Math . max ( result , arr [ i ] ) ; return result ; }
let arr = [ 30 , 10 , 9 , 3 , 35 ] ; let n = arr . length ; document . write ( findGreatest ( arr , n ) ) ;
function subset ( ar , n ) {
let res = 0 ;
ar . sort ( ) ;
for ( let i = 0 ; i < n ; i ++ ) { let count = 1 ;
for ( ; i < n - 1 ; i ++ ) { if ( ar [ i ] == ar [ i + 1 ] ) count ++ ; else break ; }
res = Math . max ( res , count ) ; } return res ; }
let arr = [ 5 , 6 , 9 , 3 , 4 , 3 , 4 ] ; let n = 7 ; document . write ( subset ( arr , n ) ) ;
function getPairsCount ( arr , n , sum ) {
let count = 0 ;
for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] + arr [ j ] == sum ) count ++ ; return count ; }
let arr = [ 1 , 5 , 7 , - 1 , 5 ] ; let n = arr . length ; let sum = 6 ; document . write ( " " + getPairsCount ( arr , n , sum ) ) ;
function countPairs ( arr1 , arr2 , m , n , x ) { let count = 0 ;
for ( let i = 0 ; i < m ; i ++ ) for ( let j = 0 ; j < n ; j ++ )
if ( ( arr1 [ i ] + arr2 [ j ] ) == x ) count ++ ;
return count ; }
let arr1 = [ 1 , 3 , 5 , 7 ] ; let arr2 = [ 2 , 3 , 5 , 8 ] ; let m = arr1 . length ; let n = arr2 . length ; let x = 10 ; document . write ( " " + countPairs ( arr1 , arr2 , m , n , x ) ) ;
function isPresent ( arr , low , high , value ) { while ( low <= high ) { let mid = Math . floor ( ( low + high ) / 2 ) ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
function countPairs ( arr1 , arr2 , m , n , x ) { let count = 0 ; for ( let i = 0 ; i < m ; i ++ ) {
let value = x - arr1 [ i ] ;
if ( isPresent ( arr2 , 0 , n - 1 , value ) ) count ++ ; }
return count ; }
let arr1 = [ 1 , 3 , 5 , 7 ] ; let arr2 = [ 2 , 3 , 5 , 8 ] ; let m = arr1 . length ; let n = arr2 . length ; let x = 10 ; document . write ( " " + countPairs ( arr1 , arr2 , m , n , x ) ) ;
function countPairs ( arr1 , arr2 , m , n , x ) { let count = 0 ; let l = 0 , r = n - 1 ;
while ( l < m && r >= 0 ) {
if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) { l ++ ; r -- ; count ++ ; }
else if ( ( arr1 [ l ] + arr2 [ r ] ) < x ) l ++ ;
else r -- ; }
return count ; }
let arr1 = [ 1 , 3 , 5 , 7 ] ; let arr2 = [ 2 , 3 , 5 , 8 ] ; let m = arr1 . length ; let n = arr2 . length ; let x = 10 ; document . write ( " " + countPairs ( arr1 , arr2 , m , n , x ) ) ;
function countPairs ( arr , n ) { var result = 0 ; for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { var product = arr [ i ] * arr [ j ] ;
for ( k = 0 ; k < n ; k ++ ) {
if ( arr [ k ] == product ) { result ++ ; break ; } } } }
return result ; }
var arr = [ 6 , 2 , 4 , 12 , 5 , 3 ] ; var n = arr . length ; document . write ( countPairs ( arr , n ) ) ;
function findPairs ( arr1 , arr2 , n , m , x ) { for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < m ; j ++ ) if ( arr1 [ i ] + arr2 [ j ] == x ) document . write ( arr1 [ i ] + " " + arr2 [ j ] + " " ) ; }
let arr1 = [ 1 , 2 , 3 , 7 , 5 , 4 ] ; let arr2 = [ 0 , 7 , 4 , 3 , 2 , 1 ] ; let n = arr1 . length ; let m = arr2 . length ; let x = 8 ; findPairs ( arr1 , arr2 , n , m , x ) ;
function findPair ( arr , n ) { let found = false ; for ( let i = 0 ; i < n ; i ++ ) { for ( let j = i + 1 ; j < n ; j ++ ) { for ( let k = 0 ; k < n ; k ++ ) { if ( arr [ i ] + arr [ j ] == arr [ k ] ) { document . write ( arr [ i ] + " " + arr [ j ] + " " ) ; found = true ; } } } } if ( found == false ) document . write ( " " ) ; }
let arr = [ 10 , 4 , 8 , 13 , 5 ] ; let n = arr . length ; findPair ( arr , n ) ;
function printPairs ( arr , n , k ) { let isPairFound = true ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( i != j && arr [ i ] % arr [ j ] == k ) { document . write ( " " + arr [ i ] + " " + arr [ j ] + " " + " " ) ; isPairFound = true ; } } } return isPairFound ; }
let arr = [ 2 , 3 , 5 , 4 , 7 ] ; let k = 3 ; if ( printPairs ( arr , arr . length , k ) == false ) document . write ( " " ) ;
let ASCII_SIZE = 256 ; function getMaxOccuringChar ( str ) {
let count = new Array ( ASCII_SIZE ) ; for ( let i = 0 ; i < ASCII_SIZE ; i ++ ) { count [ i ] = 0 ; }
let len = str . length ; for ( let i = 0 ; i < len ; i ++ ) { count [ str [ i ] . charCodeAt ( 0 ) ] += 1 ; }
let max = - 1 ;
for ( let i = 0 ; i < len ; i ++ ) { if ( max < count [ str [ i ] . charCodeAt ( 0 ) ] ) { max = count [ str [ i ] . charCodeAt ( 0 ) ] ; result = str [ i ] ; } } return result ; }
let str = " " ; document . write ( " " , getMaxOccuringChar ( str ) ) ;
function printKDistinct ( arr , n , k ) { var dist_count = 0 ; for ( var i = 0 ; i < n ; i ++ ) {
var j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ j ] == arr [ i ] ) break ;
if ( j == n ) dist_count ++ ; if ( dist_count == k ) return arr [ i ] ; } return - 1 ; }
var ar = [ 1 , 2 , 1 , 3 , 4 , 2 ] ; var n = ar . length ; var k = 2 ; document . write ( printKDistinct ( ar , n , k ) ) ;
function findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) { for ( var i = 0 ; i < n1 ; i ++ ) for ( var j = 0 ; j < n2 ; j ++ ) for ( var k = 0 ; k < n3 ; k ++ ) if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) return true ; return false ; }
var a1 = [ 1 , 2 , 3 , 4 , 5 ] ; var a2 = [ 2 , 3 , 6 , 1 , 2 ] ; var a3 = [ 3 , 2 , 4 , 5 , 6 ] ; var sum = 9 ; var n1 = a1 . length ; var n2 = a2 . length ; var n3 = a3 . length ; findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) ? document . write ( " " ) : document . write ( " " ) ;
function areElementsContiguous ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ;
for ( let i = 1 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] > 1 ) return false ; return true ; }
let arr = [ 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 ] ; let n = arr . length ; if ( areElementsContiguous ( arr , n ) ) document . write ( " " ) ; else document . write ( " " ) ;
function minInsertion ( str ) {
let n = str . length ;
let res = 0 ;
let count = new Array ( 26 ) ; for ( let i = 0 ; i < count . length ; i ++ ) { count [ i ] = 0 ; }
for ( let i = 0 ; i < n ; i ++ ) count [ str [ i ] . charCodeAt ( 0 ) - ' ' . charCodeAt ( 0 ) ] ++ ;
for ( let i = 0 ; i < 26 ; i ++ ) { if ( count [ i ] % 2 == 1 ) res ++ ; }
return ( res == 0 ) ? 0 : res - 1 ; }
let str = " " ; document . write ( minInsertion ( str ) ) ;
function findDiff ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ; let count = 0 , max_count = 0 , min_count = n ; for ( let i = 0 ; i < ( n - 1 ) ; i ++ ) {
if ( arr [ i ] == arr [ i + 1 ] ) { count += 1 ; continue ; } else { max_count = Math . max ( max_count , count ) ; min_count = Math . min ( min_count , count ) ; count = 0 ; } } return ( max_count - min_count ) ; }
let arr = [ 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 ] ; let n = arr . length ; document . write ( findDiff ( arr , n ) ) ;
function maxDiff ( arr , n ) { let SubsetSum_1 = 0 , SubsetSum_2 = 0 ; for ( let i = 0 ; i <= n - 1 ; i ++ ) { let isSingleOccurance = true ; for ( let j = i + 1 ; j <= n - 1 ; j ++ ) {
if ( arr [ i ] == arr [ j ] ) { isSingleOccurance = false ; arr [ i ] = arr [ j ] = 0 ; break ; } } if ( isSingleOccurance ) { if ( arr [ i ] > 0 ) SubsetSum_1 += arr [ i ] ; else SubsetSum_2 += arr [ i ] ; } } return Math . abs ( SubsetSum_1 - SubsetSum_2 ) ; }
let arr = [ 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 ] ; let n = arr . length ; document . write ( " " + maxDiff ( arr , n ) ) ;
function maxDiff ( arr , n ) { var result = 0 ;
arr . sort ( ( a , b ) => a - b )
for ( var i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) result += Math . abs ( arr [ i ] ) ; else i ++ ; }
if ( arr [ n - 2 ] != arr [ n - 1 ] ) result += Math . abs ( arr [ n - 1 ] ) ;
return result ; }
var arr = [ 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 ] ; var n = arr . length ; document . write ( " " + maxDiff ( arr , n ) ) ;
function calculate ( a , n ) {
a . sort ( ) ; let count = 1 ; let answer = 0 ;
for ( let i = 1 ; i < n ; i ++ ) { if ( a [ i ] == a [ i - 1 ] ) {
count += 1 ; } else {
answer = answer + Math . floor ( ( count * ( count - 1 ) ) / 2 ) ; count = 1 ; } } answer = answer + Math . floor ( ( count * ( count - 1 ) ) / 2 ) ; return answer ; }
let a = [ 1 , 2 , 1 , 2 , 4 ] ; let n = a . length ;
document . write ( calculate ( a , n ) ) ;
function calculate ( a , n ) {
let maximum = Math . max ( ... a ) ;
let frequency = new Array ( maximum + 1 ) . fill ( 0 ) ;
for ( let i = 0 ; i < n ; i ++ ) {
frequency [ a [ i ] ] += 1 ; } let answer = 0 ;
for ( let i = 0 ; i < maximum + 1 ; i ++ ) {
answer = answer + frequency [ i ] * ( frequency [ i ] - 1 ) ; } return parseInt ( answer / 2 ) ; }
let a = [ 1 , 2 , 1 , 2 , 4 ] ; let n = a . length ;
document . write ( calculate ( a , n ) ) ;
function printAllAPTriplets ( arr , n ) { const s = new Set ( ) for ( let i = 0 ; i < n - 1 ; i ++ ) { for ( let j = i + 1 ; j < n ; j ++ ) {
let diff = arr [ j ] - arr [ i ] ; if ( s . has ( arr [ i ] - diff ) ) document . write ( arr [ i ] - diff + " " + arr [ i ] + " " + arr [ j ] + " " ) ; } s . add ( arr [ i ] ) ; } }
let arr = [ 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 ] ; let n = arr . length ; printAllAPTriplets ( arr , n ) ;
function printAllAPTriplets ( arr , n ) { for ( let i = 1 ; i < n - 1 ; i ++ ) {
for ( let j = i - 1 , k = i + 1 ; j >= 0 && k < n ; ) {
if ( arr [ j ] + arr [ k ] == 2 * arr [ i ] ) { document . write ( arr [ j ] + " " + arr [ i ] + " " + arr [ k ] + " " ) ;
k ++ ; j -- ; }
else if ( arr [ j ] + arr [ k ] < 2 * arr [ i ] ) k ++ ; else j -- ; } } }
let arr = [ 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 ] ; let n = arr . length ; printAllAPTriplets ( arr , n ) ;
/ *function countTriplets(arr,n,m) { let count = 0 ;
for ( let i = 0 ; i < n - 2 ; i ++ ) for ( let j = i + 1 ; j < n - 1 ; j ++ ) for ( let k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] * arr [ j ] * arr [ k ] == m ) count ++ ; return count ; }
let arr = [ 1 , 4 , 6 , 2 , 3 , 8 ] ; let m = 24 ; document . write ( countTriplets ( arr , arr . length , m ) ) ;
function countPairs ( arr , n ) { let ans = 0 ;
for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ )
if ( arr [ i ] == arr [ j ] ) ans ++ ; return ans ; }
let arr = [ 1 , 1 , 2 ] ; let n = arr . length ; document . write ( countPairs ( arr , n ) ) ;
function countNum ( arr , n ) { let count = 0 ;
arr . sort ( ) ;
for ( let i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) count += arr [ i + 1 ] - arr [ i ] - 1 ; return count ; }
let arr = [ 3 , 5 , 8 , 6 ] ; let n = arr . length ; document . write ( countNum ( arr , n ) ) ;
function countSubarrays ( arr , n ) {
let difference = 0 ; let ans = 0 ;
for ( let i = 0 ; i < n + 1 ; i ++ ) { hash_positive [ i ] = 0 ; hash_negative [ i ] = 0 ; }
hash_positive [ 0 ] = 1 ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( ( arr [ i ] & 1 ) == 1 ) { difference ++ ; } else { difference -- ; }
if ( difference < 0 ) { ans += hash_negative [ - difference ] ; hash_negative [ - difference ] ++ ; }
else { ans += hash_positive [ difference ] ; hash_positive [ difference ] ++ ; } }
return ans ; }
let arr = [ 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 ] ; let n = arr . length ;
document . write ( " " + " " + countSubarrays ( arr , n ) ) ;
function findLargestd ( S , n ) { let found = false ;
S . sort ( ) ;
for ( let i = n - 1 ; i >= 0 ; i -- ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( i == j ) continue ; for ( let k = j + 1 ; k < n ; k ++ ) { if ( i == k ) continue ; for ( let l = k + 1 ; l < n ; l ++ ) { if ( i == l ) continue ;
if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) { found = true ; return S [ i ] ; } } } } } if ( found == false ) return Number . MAX_VALUE ; return - 1 ; }
let S = [ 2 , 3 , 5 , 7 , 12 ] ; let n = S . length ; let ans = findLargestd ( S , n ) ; if ( ans == Number . MAX_VALUE ) document . write ( " " ) ; else document . write ( " " + " " + ans ) ;
function recaman ( n ) {
arr [ 0 ] = 0 ; document . write ( arr [ 0 ] + " " ) ;
for ( let i = 1 ; i < n ; i ++ ) { let curr = arr [ i - 1 ] - i ; let j ; for ( j = 0 ; j < i ; j ++ ) {
if ( ( arr [ j ] == curr ) curr < 0 ) { curr = arr [ i - 1 ] + i ; break ; } } arr [ i ] = curr ; document . write ( arr [ i ] + " " ) ; } }
let n = 17 ; recaman ( n ) ;
function recaman ( n ) { if ( n <= 0 ) return ;
document . write ( 0 + " " ) ; let s = new Set ( ) ; s . add ( 0 ) ;
let prev = 0 ; for ( let i = 1 ; i < n ; i ++ ) { let curr = prev - i ;
if ( curr < 0 || s . has ( curr ) ) curr = prev + i ; s . add ( curr ) ; document . write ( curr + " " ) ; prev = curr ; } }
let n = 17 ; recaman ( n ) ;
function findArea ( arr , n ) {
arr . sort ( ( a , b ) => { return b - a ; } )
var dimension = [ 0 , 0 ] ;
for ( var i = 0 , j = 0 ; i < n - 1 && j < 2 ; i ++ )
if ( arr [ i ] == arr [ i + 1 ] ) dimension [ j ++ ] = arr [ i ++ ] ;
return ( dimension [ 0 ] * dimension [ 1 ] ) ; }
var arr = [ 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 ] ; var n = arr . length ; document . write ( findArea ( arr , n ) ) ;
function search ( arr , l , h , key ) { if ( l > h ) return - 1 ; let mid = Math . floor ( ( l + h ) / 2 ) ; if ( arr [ mid ] == key ) return mid ;
if ( arr [ l ] <= arr [ mid ] ) {
if ( key >= arr [ l ] && key <= arr [ mid ] ) return search ( arr , l , mid - 1 , key ) ;
return search ( arr , mid + 1 , h , key ) ; }
if ( key >= arr [ mid ] && key <= arr [ h ] ) return search ( arr , mid + 1 , h , key ) ; return search ( arr , l , mid - 1 , key ) ; }
let arr = [ 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 ] ; let n = arr . length ; let key = 6 ; let i = search ( arr , 0 , n - 1 , key ) ; if ( i != - 1 ) document . write ( " " + i + " " ) ; else document . write ( " " ) ;
function pairInSortedRotated ( arr , n , x ) {
let i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
let l = ( i + 1 ) % n ;
let r = i ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) return true ;
if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return false ; }
let arr = [ 11 , 15 , 6 , 8 , 9 , 10 ] ; let sum = 16 ; let n = arr . length ; if ( pairInSortedRotated ( arr , n , sum ) ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ;
function pairsInSortedRotated ( arr , n , x ) {
let i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
let l = ( i + 1 ) % n ;
let r = i ;
let cnt = 0 ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) { cnt ++ ;
if ( l == ( r - 1 + n ) % n ) { return cnt ; } l = ( l + 1 ) % n ; r = ( r - 1 + n ) % n ; }
else if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return cnt ; }
let arr = [ 11 , 15 , 6 , 7 , 9 , 10 ] ; let sum = 16 ; let n = arr . length ; document . write ( pairsInSortedRotated ( arr , n , sum ) ) ;
function maxSum ( arr , n ) {
let arrSum = 0 ;
let currVal = 0 ; for ( let i = 0 ; i < n ; i ++ ) { arrSum = arrSum + arr [ i ] ; currVal = currVal + ( i * arr [ i ] ) ; }
let maxVal = currVal ;
for ( let j = 1 ; j < n ; j ++ ) { currVal = currVal + arrSum - n * arr [ n - j ] ; if ( currVal > maxVal ) maxVal = currVal ; }
return maxVal ; }
let arr = [ 10 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ] ; let n = arr . length ; document . write ( " " + maxSum ( arr , n ) ) ;
function maxSum ( arr , n ) {
var res = Number . MIN_VALUE ;
for ( i = 0 ; i < n ; i ++ ) {
var curr_sum = 0 ;
for ( j = 0 ; j < n ; j ++ ) { var index = ( i + j ) % n ; curr_sum += j * arr [ index ] ; }
res = Math . max ( res , curr_sum ) ; } return res ; }
var arr = [ 8 , 3 , 1 , 2 ] ; var n = arr . length ; document . write ( maxSum ( arr , n ) ) ;
function maxSum ( arr , n ) {
let cum_sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) cum_sum += arr [ i ] ;
let curr_val = 0 ; for ( let i = 0 ; i < n ; i ++ ) curr_val += i * arr [ i ] ;
let res = curr_val ;
for ( let i = 1 ; i < n ; i ++ ) {
let next_val = curr_val - ( cum_sum - arr [ i - 1 ] ) + arr [ i - 1 ] * ( n - 1 ) ;
curr_val = next_val ;
res = Math . max ( res , next_val ) ; } return res ; }
let arr = [ 8 , 3 , 1 , 2 ] ; let n = arr . length ; document . write ( maxSum ( arr , n ) + " " ) ;
function countRotations ( arr , n ) {
let min = arr [ 0 ] , min_index = - 1 ; for ( let i = 0 ; i < n ; i ++ ) { if ( min > arr [ i ] ) { min = arr [ i ] ; min_index = i ; } } return min_index ; }
let arr = [ 15 , 18 , 2 , 3 , 6 , 12 ] ; let n = arr . length ; document . write ( countRotations ( arr , n ) ) ;
function countRotations ( arr , low , high ) {
if ( high < low ) return 0 ;
if ( high == low ) return low ;
let mid = Math . floor ( low + ( high - low ) / 2 ) ;
if ( mid < high && arr [ mid + 1 ] < arr [ mid ] ) return ( mid + 1 ) ;
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) return mid ;
if ( arr [ high ] > arr [ mid ] ) return countRotations ( arr , low , mid - 1 ) ; return countRotations ( arr , mid + 1 , high ) ; }
let arr = [ 15 , 18 , 2 , 3 , 6 , 12 ] ; let n = arr . length ; document . write ( countRotations ( arr , 0 , n - 1 ) ) ;
function preprocess ( arr , n , temp ) {
for ( i = 0 ; i < n ; i ++ ) temp [ i ] = temp [ i + n ] = arr [ i ] ; }
function leftRotate ( arr , n , k , temp ) {
var start = k % n ;
for ( i = start ; i < start + n ; i ++ ) document . write ( temp [ i ] + " " ) ; document . write ( " " ) ; }
var arr = [ 1 , 3 , 5 , 7 , 9 ] ; var n = arr . length ; var temp = Array ( 2 * n ) . fill ( 0 ) ; preprocess ( arr , n , temp ) ; var k = 2 ; leftRotate ( arr , n , k , temp ) ; k = 3 ; leftRotate ( arr , n , k , temp ) ; k = 4 ; leftRotate ( arr , n , k , temp ) ;
function leftRotate ( arr , n , k ) {
for ( let i = k ; i < k + n ; i ++ ) document . write ( arr [ i % n ] + " " ) ; }
let arr = [ 1 , 3 , 5 , 7 , 9 ] ; n = arr . length ; k = 2 ; leftRotate ( arr , n , k ) ; document . write ( " " ) ; k = 3 ; leftRotate ( arr , n , k ) ; document . write ( " " ) ; k = 4 ; leftRotate ( arr , n , k ) ; document . write ( " " ) ;
function reverseArray ( arr , start , end ) { while ( start < end ) { let temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } return arr ; }
function rightRotate ( arr , d , n ) { arr = reverseArray ( arr , 0 , n - 1 ) ; arr = reverseArray ( arr , 0 , d - 1 ) ; arr = reverseArray ( arr , d , n - 1 ) ; return arr ; }
function printArray ( arr , size ) { for ( let i = 0 ; i < size ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 ] ; let n = arr . length ; let k = 3 ; arr = rightRotate ( arr , k , n ) ; printArray ( arr , n ) ;
function maxHamming ( arr , n ) {
let brr = new Array ( 2 * n + 1 ) ; for ( let i = 0 ; i < n ; i ++ ) brr [ i ] = arr [ i ] ; for ( let i = 0 ; i < n ; i ++ ) brr [ n + i ] = arr [ i ] ;
let maxHam = 0 ;
for ( let i = 1 ; i < n ; i ++ ) { let currHam = 0 ; for ( let j = i , k = 0 ; j < ( i + n ) ; j ++ , k ++ ) if ( brr [ j ] != arr [ k ] ) currHam ++ ;
if ( currHam == n ) return n ; maxHam = max ( maxHam , currHam ) ; } return maxHam ; }
let arr = [ 2 , 4 , 6 , 8 ] ; let n = arr . length ; document . write ( maxHamming ( arr , n ) ) ;
function leftRotate ( arr , n , k ) {
let mod = k % n ;
for ( let i = 0 ; i < n ; i ++ ) document . write ( ( arr [ ( mod + i ) % n ] ) + " " ) ; document . write ( " " ) ; }
let arr = [ 1 , 3 , 5 , 7 , 9 ] ; let n = arr . length ; let k = 2 ;
leftRotate ( arr , n , k ) ; document . write ( " " ) ; k = 3 ;
leftRotate ( arr , n , k ) ; document . write ( " " ) ; k = 4 ;
leftRotate ( arr , n , k ) ;
let findElement = ( arr , ranges , rotations , index ) => { for ( let i = rotations - 1 ; i >= 0 ; i -- ) {
let left = ranges [ i ] [ 0 ] ; let right = ranges [ i ] [ 1 ] ;
if ( left <= index && right >= index ) { if ( index == left ) index = right ; else index -- ; } }
return arr [ index ] ; }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ;
let rotations = 2 ;
let ranges = [ [ 0 , 2 ] , [ 0 , 3 ] ] ; let index = 1 ; document . write ( findElement ( arr , ranges , rotations , index ) ) ;
function splitArr ( arr , n , k ) { for ( let i = 0 ; i < k ; i ++ ) {
let x = arr [ 0 ] ; for ( let j = 0 ; j < n - 1 ; ++ j ) arr [ j ] = arr [ j + 1 ] ; arr [ n - 1 ] = x ; } }
let arr = [ 12 , 10 , 5 , 6 , 52 , 36 ] ; let n = arr . length ; let position = 2 ; splitArr ( arr , 6 , position ) ; for ( let i = 0 ; i < n ; ++ i ) document . write ( arr [ i ] + " " ) ;
function rearrangeArr ( arr , n ) {
let evenPos = Math . floor ( n / 2 ) ;
let oddPos = n - evenPos ; let tempArr = new Array ( n ) ;
for ( let i = 0 ; i < n ; i ++ ) tempArr [ i ] = arr [ i ] ;
tempArr . sort ( ) ; let j = oddPos - 1 ;
for ( let i = 0 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j -- ; } j = oddPos ;
for ( let i = 1 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j ++ ; }
for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ; let size = arr . length ; rearrangeArr ( arr , size ) ;
function pushZerosToEnd ( arr , n ) {
let count = 0 ;
for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
let arr = [ 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 ] ; let n = arr . length ; pushZerosToEnd ( arr , n ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function reorder ( arr , index , n ) { var temp = [ ... Array ( n ) ] ;
for ( var i = 0 ; i < n ; i ++ ) temp [ index [ i ] ] = arr [ i ] ;
for ( var i = 0 ; i < n ; i ++ ) { arr [ i ] = temp [ i ] ; index [ i ] = i ; } }
var arr = [ 50 , 40 , 70 , 60 , 90 ] ; var index = [ 3 , 0 , 4 , 1 , 2 ] ; var n = arr . length ; reorder ( arr , index , n ) ; document . write ( " " ) ; document . write ( " " ) ; for ( var i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; document . write ( " " ) ; document . write ( " " ) ; for ( var i = 0 ; i < n ; i ++ ) document . write ( index [ i ] + " " ) ;
function printArray ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; }
function RearrangePosNeg ( arr , n ) { let key , j ; for ( let i = 1 ; i < n ; i ++ ) { key = arr [ i ] ;
if ( key > 0 ) continue ;
j = i - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { arr [ j + 1 ] = arr [ j ] ; j = j - 1 ; }
arr [ j + 1 ] = key ; } }
let arr = [ - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 ] ; let n = arr . length ; RearrangePosNeg ( arr , n ) ; printArray ( arr , n ) ;
function rearrange ( arr , n ) {
let temp = new Array ( n ) ;
let small = 0 , large = n - 1 ;
let flag = true ;
for ( let i = 0 ; i < n ; i ++ ) { if ( flag ) temp [ i ] = arr [ large -- ] ; else temp [ i ] = arr [ small ++ ] ; flag = ! flag ; }
for ( let i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 ] ; let n = arr . length ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; rearrange ( arr , n ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function rearrange ( arr , n ) {
let max_idx = n - 1 , min_idx = 0 ;
let max_elem = arr [ n - 1 ] + 1 ;
for ( let i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] += ( arr [ max_idx ] % max_elem ) * max_elem ; max_idx -- ; }
else { arr [ i ] += ( arr [ min_idx ] % max_elem ) * max_elem ; min_idx ++ ; } }
for ( let i = 0 ; i < n ; i ++ ) arr [ i ] = Math . floor ( arr [ i ] / max_elem ) ; }
let arr = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ] ; let n = arr . length ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; rearrange ( arr , n ) ; document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function rearrange ( arr , n ) { let j = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < 0 ) { if ( i != j ) { let temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } j ++ ; } } }
function printArray ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ - 1 , 2 , - 3 , 4 , 5 , 6 , - 7 , 8 , 9 ] ; let n = arr . length ; rearrange ( arr , n ) ; printArray ( arr , n ) ;
function segregateElements ( arr , n ) {
let temp = new Array ( n ) ;
let j = 0 ; for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] >= 0 ) temp [ j ++ ] = arr [ i ] ;
if ( j == n j == 0 ) return ;
for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] < 0 ) temp [ j ++ ] = arr [ i ] ;
for ( let i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
let arr = [ 1 , - 1 , - 3 , - 2 , 7 , 5 , 11 , 6 ] ; let n = arr . length ; segregateElements ( arr , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
let rearrange = ( arr , n ) => { for ( let i = 0 ; i < n - 1 ; i ++ ) { if ( i % 2 == 0 && arr [ i ] > arr [ i + 1 ] ) { let temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } if ( i % 2 != 0 && arr [ i ] < arr [ i + 1 ] ) { let temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } } }
let printArray = ( arr , size ) => { ans = ' ' ; for ( let i = 0 ; i < size ; i ++ ) { ans += arr [ i ] + " " ; } document . write ( ans ) ; }
let arr = [ 6 , 4 , 2 , 1 , 8 , 3 ] ; let n = arr . length ; document . write ( " " ) ; printArray ( arr , n ) ; rearrange ( arr , n ) ; document . write ( " " ) ; document . write ( " " ) ; printArray ( arr , n ) ;
function rearrange ( a , size ) { let positive = 0 ; let negative = 1 ; let temp ; while ( true ) {
while ( positive < size && a [ positive ] >= 0 ) positive += 2 ;
while ( negative < size && a [ negative ] <= 0 ) negative += 2 ;
if ( positive < size && negative < size ) { temp = a [ positive ] ; a [ positive ] = a [ negative ] ; a [ negative ] = temp ; }
else break ; } }
let arr = [ 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 ] ; let n = arr . length ; rearrange ( arr , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function arrayEvenAndOdd ( arr , n ) { let i = - 1 , j = 0 ; let t ; while ( j != n ) { if ( arr [ j ] % 2 == 0 ) { i ++ ;
let temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } j ++ ; }
for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 ] ; let n = arr . length ; arrayEvenAndOdd ( arr , n ) ;
function largest ( arr ) { let i ;
let max = arr [ 0 ] ;
for ( i = 1 ; i < arr . length ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
let arr = [ 10 , 324 , 45 , 90 , 9808 ] ; document . write ( " " + largest ( arr ) ) ;
function largest ( arr , n ) { arr . sort ( ) ; return arr [ n - 1 ] ; }
let arr = [ 10 , 324 , 45 , 90 , 9808 ] ; let n = arr . length ; document . write ( largest ( arr , n ) ) ;
function findElements ( arr , n ) {
for ( let i = 0 ; i < n ; i ++ ) { let count = 0 ; for ( let j = 0 ; j < n ; j ++ ) if ( arr [ j ] > arr [ i ] ) count ++ ; if ( count >= 2 ) document . write ( arr [ i ] + " " ) ; } }
let arr = [ 2 , - 6 , 3 , 5 , 1 ] ; let n = arr . length ; findElements ( arr , n ) ;
function findElements ( arr , n ) { arr . sort ( ) ; for ( let i = 0 ; i < n - 2 ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 2 , - 6 , 3 , 5 , 1 ] ; let n = arr . length ; findElements ( arr , n ) ;
function findElements ( arr , n ) { let first = Number . MIN_VALUE ; let second = Number . MAX_VALUE ; for ( let i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) second = arr [ i ] ; } for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] < second ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 2 , - 6 , 3 , 5 , 1 ] ; let n = arr . length ; findElements ( arr , n ) ;
function findMean ( a , n ) { let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) sum += a [ i ] ; return sum / n ; }
function findMedian ( a , n ) {
a . sort ( ) ;
if ( n % 2 != 0 ) return a [ n / 2 ] ; return ( a [ Math . floor ( ( n - 1 ) / 2 ) ] + a [ n / 2 ] ) / 2 ; }
let a = [ 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 ] let n = a . length ;
document . write ( " " + findMean ( a , n ) + " " ) ; document . write ( " " + findMedian ( a , n ) ) ;
function printSmall ( arr , n , k ) {
for ( let i = k ; i < n ; ++ i ) {
let max_var = arr [ k - 1 ] ; let pos = k - 1 ; for ( let j = k - 2 ; j >= 0 ; j -- ) { if ( arr [ j ] > max_var ) { max_var = arr [ j ] ; pos = j ; } }
if ( max_var > arr [ i ] ) { let j = pos ; while ( j < k - 1 ) { arr [ j ] = arr [ j + 1 ] ; j ++ ; }
arr [ k - 1 ] = arr [ i ] ; } }
for ( let i = 0 ; i < k ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 ] ; let n = 10 ; let k = 5 ; printSmall ( arr , n , k ) ;
function sumNodes ( l ) {
let leafNodeCount = Math . pow ( 2 , l - 1 ) ; let sumLastLevel = 0 ;
sumLastLevel = ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ;
let sum = sumLastLevel * l ; return sum ; }
let l = 3 ; document . write ( sumNodes ( l ) ) ;
function add ( arr , N , lo , hi , val ) { arr [ lo ] += val ; if ( hi != N - 1 ) arr [ hi + 1 ] -= val ; }
function updateArray ( arr , N ) {
for ( let i = 1 ; i < N ; i ++ ) arr [ i ] += arr [ i - 1 ] ; }
function printArr ( arr , N ) { updateArray ( arr , N ) ; for ( let i = 0 ; i < N ; i ++ ) document . write ( " " + arr [ i ] + " " ) ; document . write ( " " ) ; }
let N = 6 ; let arr = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { arr [ i ] = 0 ; }
add ( arr , N , 0 , 2 , 100 ) ; add ( arr , N , 1 , 5 , 100 ) ; add ( arr , N , 2 , 3 , 100 ) ; printArr ( arr , N ) ;
function GCD ( a , b ) { if ( b == 0 ) return a ; return GCD ( b , a % b ) ; }
function FillPrefixSuffix ( prefix , arr , suffix , n ) {
prefix [ 0 ] = arr [ 0 ] ; for ( i = 1 ; i < n ; i ++ ) prefix [ i ] = GCD ( prefix [ i - 1 ] , arr [ i ] ) ;
suffix [ n - 1 ] = arr [ n - 1 ] ; for ( i = n - 2 ; i >= 0 ; i -- ) suffix [ i ] = GCD ( suffix [ i + 1 ] , arr [ i ] ) ; }
function GCDoutsideRange ( l , r , prefix , suffix , n ) {
if ( l == 0 ) return suffix [ r + 1 ] ;
if ( r == n - 1 ) return prefix [ l - 1 ] ; return GCD ( prefix [ l - 1 ] , suffix [ r + 1 ] ) ; }
var arr = [ 2 , 6 , 9 ] ; var n = arr . length ; var prefix = Array ( n ) . fill ( 0 ) ; var suffix = Array ( n ) . fill ( 0 ) ; FillPrefixSuffix ( prefix , arr , suffix , n ) ; var l = 0 , r = 0 ; document . write ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; document . write ( " " ) ; l = 1 ; r = 1 ; document . write ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; document . write ( " " ) ; l = 1 ; r = 2 ; document . write ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; document . write ( " " ) ;
function countInRange ( arr , n , x , y ) {
let count = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] >= x && arr [ i ] <= y ) count ++ ; } return count ; }
let arr = [ 1 , 3 , 4 , 9 , 10 , 3 ] ; let n = arr . length ;
let i = 1 , j = 4 ; document . write ( countInRange ( arr , n , i , j ) + " " ) ; i = 9 ; j = 12 ; document . write ( countInRange ( arr , n , i , j ) ) ;
function lowerIndex ( arr , n , x ) { let l = 0 , h = n - 1 ; while ( l <= h ) { let mid = parseInt ( ( l + h ) / 2 , 10 ) ; if ( arr [ mid ] >= x ) h = mid - 1 ; else l = mid + 1 ; } return l ; }
function upperIndex ( arr , n , y ) { let l = 0 , h = n - 1 ; while ( l <= h ) { let mid = parseInt ( ( l + h ) / 2 , 10 ) ; if ( arr [ mid ] <= y ) l = mid + 1 ; else h = mid - 1 ; } return h ; }
function countInRange ( arr , n , x , y ) {
let count = 0 ; count = upperIndex ( arr , n , y ) - lowerIndex ( arr , n , x ) + 1 ; return count ; }
let arr = [ 1 , 4 , 4 , 9 , 10 , 3 ] ; let n = arr . length ;
arr . sort ( function ( a , b ) { return a - b } ) ;
let i = 1 , j = 4 ; document . write ( countInRange ( arr , n , i , j ) + " " ) ; ; i = 9 ; j = 12 ; document . write ( countInRange ( arr , n , i , j ) ) ;
function precompute ( arr , n , pre ) { for ( let i = 0 ; i < n ; i ++ ) pre [ i ] = 0 ; pre [ n - 1 ] = arr [ n - 1 ] * ( Math . pow ( 2 , 0 ) ) ; for ( let i = n - 2 ; i >= 0 ; i -- ) pre [ i ] = pre [ i + 1 ] + arr [ i ] * ( 1 << ( n - 1 - i ) ) ; }
function decimalOfSubarr ( arr , l , r , n , pre ) {
if ( r != n - 1 ) return ( pre [ l ] - pre [ r + 1 ] ) / ( 1 << ( n - 1 - r ) ) ; return pre [ l ] / ( 1 << ( n - 1 - r ) ) ; }
let arr = [ 1 , 0 , 1 , 0 , 1 , 1 ] ; let n = arr . length ; let pre = new Array ( n ) precompute ( arr , n , pre ) ; document . write ( decimalOfSubarr ( arr , 2 , 4 , n , pre ) + " " ) ; document . write ( decimalOfSubarr ( arr , 4 , 5 , n , pre ) ) ;
function answerQuery ( a , n , l , r ) {
var count = 0 ;
l = l - 1 ;
for ( i = l ; i < r ; i ++ ) { var element = a [ i ] ; var divisors = 0 ;
for ( j = l ; j < r ; j ++ ) {
if ( a [ j ] % a [ i ] == 0 ) divisors ++ ; else break ; }
if ( divisors == ( r - l ) ) count ++ ; }
return count ; }
var a = [ 1 , 2 , 3 , 5 ] ; var n = a . length ; var l = 1 , r = 4 ; document . write ( answerQuery ( a , n , l , r ) + " " ) ; l = 2 ; r = 4 ; document . write ( answerQuery ( a , n , l , r ) ) ;
const MAX = 2147483647 ; let one = new Array ( 100001 ) ; for ( let i = 0 ; i < 100001 ; i ++ ) one [ i ] = new Array ( 32 ) ;
function make_prefix ( A , n ) { for ( let j = 0 ; j < 32 ; j ++ ) one [ 0 ] [ j ] = 0 ;
for ( let i = 1 ; i <= n ; i ++ ) { let a = A [ i - 1 ] ; for ( let j = 0 ; j < 32 ; j ++ ) { let x = Math . pow ( 2 , j ) ;
if ( a & x ) one [ i ] [ j ] = 1 + one [ i - 1 ] [ j ] ; else one [ i ] [ j ] = one [ i - 1 ] [ j ] ; } } }
function Solve ( L , R ) { let l = L , r = R ; let tot_bits = r - l + 1 ;
let X = MAX ;
for ( let i = 0 ; i < 31 ; i ++ ) {
let x = one [ r ] [ i ] - one [ l - 1 ] [ i ] ;
if ( x >= tot_bits - x ) { let ith_bit = Math . pow ( 2 , i ) ;
X = X ^ ith_bit ; } } return X ; }
let n = 5 , q = 3 ; let A = [ 210 , 11 , 48 , 22 , 133 ] ; let L = [ 1 , 4 , 2 ] , R = [ 3 , 14 , 4 ] ; make_prefix ( A , n ) ; for ( let j = 0 ; j < q ; j ++ ) document . write ( Solve ( L [ j ] , R [ j ] ) + " " ) ;
function answer_query ( a , n , l , r ) {
var count = 0 ; for ( var i = l ; i < r ; i ++ ) if ( a [ i ] == a [ i + 1 ] ) count += 1 ; return count ; }
var a = [ 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 ] var n = a . length ;
var L , R ; L = 1 ; R = 8 ; document . write ( answer_query ( a , n , L , R ) + " " ) ;
L = 0 ; R = 4 ; document . write ( answer_query ( a , n , L , R ) ) ;
const N = 1000 ;
let prefixans = new Uint8Array ( N ) ;
function countIndex ( a , n ) {
for ( let i = 0 ; i < n ; i ++ ) { if ( a [ i ] == a [ i + 1 ] ) prefixans [ i ] = 1 ; if ( i != 0 ) prefixans [ i ] += prefixans [ i - 1 ] ; } }
function answer_query ( l , r ) { if ( l == 0 ) return prefixans [ r - 1 ] ; else return prefixans [ r - 1 ] - prefixans [ l - 1 ] ; }
let a = [ 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 ] ; let n = a . length ;
countIndex ( a , n ) ; let L , R ;
L = 1 ; R = 8 ; document . write ( answer_query ( L , R ) + " " ) ;
L = 0 ; R = 4 ; document . write ( answer_query ( L , R ) + " " ) ;
function maxSubArraySum ( a , size ) { var maxint = Math . pow ( 2 , 53 ) var max_so_far = - maxint - 1 var max_ending_here = 0 for ( var i = 0 ; i < size ; i ++ ) { max_ending_here = max_ending_here + a [ i ] if ( max_so_far < max_ending_here ) max_so_far = max_ending_here if ( max_ending_here < 0 ) max_ending_here = 0 } return max_so_far }
var a = [ - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 ] document . write ( " " , maxSubArraySum ( a , a . length ) )
function maxSubArraySum ( a , size ) { let max_so_far = a [ 0 ] ; let curr_max = a [ 0 ] ; for ( let i = 1 ; i < size ; i ++ ) { curr_max = Math . max ( a [ i ] , curr_max + a [ i ] ) ; max_so_far = Math . max ( max_so_far , curr_max ) ; } return max_so_far ; }
let a = [ - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 ] ; let n = a . length ; document . write ( " " , maxSubArraySum ( a , n ) ) ;
function findMinAvgSubarray ( arr , n , k ) {
if ( n < k ) return ;
let res_index = 0 ;
let curr_sum = 0 ; for ( let i = 0 ; i < k ; i ++ ) curr_sum += arr [ i ] ;
let min_sum = curr_sum ;
for ( let i = k ; i < n ; i ++ ) {
curr_sum += arr [ i ] - arr [ i - k ] ;
if ( curr_sum < min_sum ) { min_sum = curr_sum ; res_index = ( i - k + 1 ) ; } } document . write ( " " + res_index + " " + ( res_index + k - 1 ) + " " ) ; }
let arr = [ 3 , 7 , 90 , 20 , 10 , 50 , 40 ] ;
let k = 3 ; let n = arr . length ; findMinAvgSubarray ( arr , n , k ) ;
function minJumps ( arr , n ) {
var jumps = Array . from ( { length : n } , ( _ , i ) => 0 ) ; var min ;
jumps [ n - 1 ] = 0 ;
for ( i = n - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] == 0 ) jumps [ i ] = Number . MAX_VALUE ;
else if ( arr [ i ] >= n - i - 1 ) jumps [ i ] = 1 ;
else {
min = Number . MAX_VALUE ;
for ( j = i + 1 ; j < n && j <= arr [ i ] + i ; j ++ ) { if ( min > jumps [ j ] ) min = jumps [ j ] ; }
if ( min != Number . MAX_VALUE ) jumps [ i ] = min + 1 ; else
jumps [ i ] = min ; } } return jumps [ 0 ] ; }
var arr = [ 1 , 3 , 6 , 1 , 0 , 9 ] ; var size = arr . length ; document . write ( " " + " " + minJumps ( arr , size ) ) ;
function smallestSubWithSum ( arr , n , x ) {
let min_len = n + 1 ;
for ( let start = 0 ; start < n ; start ++ ) {
let curr_sum = arr [ start ] ;
if ( curr_sum > x ) return 1 ;
for ( let end = start + 1 ; end < n ; end ++ ) {
curr_sum += arr [ end ] ;
if ( curr_sum > x && ( end - start + 1 ) < min_len ) min_len = ( end - start + 1 ) ; } } return min_len ; }
let arr1 = [ 1 , 4 , 45 , 6 , 10 , 19 ] ; let x = 51 ; let n1 = arr1 . length ; let res1 = smallestSubWithSum ( arr1 , n1 , x ) ; ( res1 == n1 + 1 ) ? document . write ( " " ) : document . write ( res1 + " " ) ; let arr2 = [ 1 , 10 , 5 , 2 , 7 ] ; let n2 = arr2 . length ; x = 9 ; let res2 = smallestSubWithSum ( arr2 , n2 , x ) ; ( res2 == n2 + 1 ) ? document . write ( " " ) : document . write ( res2 + " " ) ; let arr3 = [ 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ] ; let n3 = arr3 . length ; x = 280 ; let res3 = smallestSubWithSum ( arr3 , n3 , x ) ; ( res3 == n3 + 1 ) ? document . write ( " " ) : document . write ( res3 + " " ) ;
function smallestSubWithSum ( arr , n , x ) {
let curr_sum = 0 , min_len = n + 1 ;
let start = 0 , end = 0 ; while ( end < n ) {
while ( curr_sum <= x && end < n ) curr_sum += arr [ end ++ ] ;
while ( curr_sum > x && start < n ) {
if ( end - start < min_len ) min_len = end - start ;
curr_sum -= arr [ start ++ ] ; } } return min_len ; }
let arr1 = [ 1 , 4 , 45 , 6 , 10 , 19 ] ; let x = 51 ; let n1 = arr1 . length ; let res1 = smallestSubWithSum ( arr1 , n1 , x ) ; ( res1 == n1 + 1 ) ? document . write ( " " ) : document . write ( res1 + " " ) ; let arr2 = [ 1 , 10 , 5 , 2 , 7 ] ; let n2 = arr2 . length ; x = 9 ; let res2 = smallestSubWithSum ( arr2 , n2 , x ) ; ( res2 == n2 + 1 ) ? document . write ( " " ) : document . write ( res2 + " " ) ; let arr3 = [ 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 ] ; let n3 = arr3 . length ; x = 280 ; let res3 = smallestSubWithSum ( arr3 , n3 , x ) ; ( res3 == n3 + 1 ) ? document . write ( " " ) : document . write ( res3 + " " ) ;
function findMaxAverage ( arr , n , k ) {
if ( k > n ) return - 1 ;
let csum = new Array ( n ) ; csum [ 0 ] = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) csum [ i ] = csum [ i - 1 ] + arr [ i ] ;
let max_sum = csum [ k - 1 ] , max_end = k - 1 ;
for ( let i = k ; i < n ; i ++ ) { let curr_sum = csum [ i ] - csum [ i - k ] ; if ( curr_sum > max_sum ) { max_sum = curr_sum ; max_end = i ; } }
return max_end - k + 1 ; }
let arr = [ 1 , 12 , - 5 , - 6 , 50 , 3 ] ; let k = 4 ; let n = arr . length ; document . write ( " " + " " + k + " " + findMaxAverage ( arr , n , k ) ) ;
function findMaxAverage ( arr , n , k ) {
if ( k > n ) return - 1 ;
let sum = arr [ 0 ] ; for ( let i = 1 ; i < k ; i ++ ) sum += arr [ i ] ; let max_sum = sum ; let max_end = k - 1 ;
for ( let i = k ; i < n ; i ++ ) { sum = sum + arr [ i ] - arr [ i - k ] ; if ( sum > max_sum ) { max_sum = sum ; max_end = i ; } }
return max_end - k + 1 ; }
let arr = [ 1 , 12 , - 5 , - 6 , 50 , 3 ] ; let k = 4 ; let n = arr . length ; document . write ( " " + " " + k + " " + findMaxAverage ( arr , n , k ) ) ;
function countMinOperations ( n ) {
let result = 0 ;
while ( true ) {
let zero_count = 0 ;
let i ; for ( i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] % 2 == 1 ) break ;
else if ( arr [ i ] == 0 ) zero_count ++ ; }
if ( zero_count == n ) return result ;
if ( i == n ) {
for ( let j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] / 2 ; result ++ ; }
for ( let j = i ; j < n ; j ++ ) { if ( arr [ j ] % 2 == 1 ) { arr [ j ] -- ; result ++ ; } } } }
document . write ( " " + " " + " " + countMinOperations ( arr . length ) ) ;
function findMinOps ( arr , n ) {
let ans = 0 ;
for ( let i = 0 , j = n - 1 ; i <= j ; ) {
if ( arr [ i ] == arr [ j ] ) { i ++ ; j -- ; }
else if ( arr [ i ] > arr [ j ] ) {
j -- ; arr [ j ] += arr [ j + 1 ] ; ans ++ ; }
else { i ++ ; arr [ i ] += arr [ i - 1 ] ; ans ++ ; } } return ans ; }
let arr = [ 1 , 4 , 5 , 9 , 1 ] ; document . write ( " " + findMinOps ( arr , arr . length ) ) ;
function findSmallest ( arr , n ) {
var res = 1 ;
for ( i = 0 ; i < n && arr [ i ] <= res ; i ++ ) res = res + arr [ i ] ; return res ; }
var arr1 = [ 1 , 3 , 4 , 5 ] ; var n1 = arr1 . length ; document . write ( findSmallest ( arr1 , n1 ) + " " ) ; var arr2 = [ 1 , 2 , 6 , 10 , 11 , 15 ] ; var n2 = arr2 . length ; document . write ( findSmallest ( arr2 , n2 ) + " " ) ; var arr3 = [ 1 , 1 , 1 , 1 ] ; var n3 = arr3 . length ; document . write ( findSmallest ( arr3 , n3 ) + " " ) ; var arr4 = [ 1 , 1 , 3 , 4 ] ; var n4 = arr4 . length ; document . write ( findSmallest ( arr4 , n4 ) + " " ) ;
function findMinDiff ( arr , n ) {
let diff = Number . MAX_VALUE ;
for ( let i = 0 ; i < n - 1 ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) if ( Math . abs ( ( arr [ i ] - arr [ j ] ) ) < diff ) diff = Math . abs ( ( arr [ i ] - arr [ j ] ) ) ;
return diff ; }
let arr = [ 1 , 5 , 3 , 19 , 18 , 25 ] ; document . write ( " " + findMinDiff ( arr , arr . length ) ) ;
function findMinDiff ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ;
let diff = Number . MAX_VALUE ;
for ( let i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i + 1 ] - arr [ i ] < diff ) diff = arr [ i + 1 ] - arr [ i ] ;
return diff ; }
let arr = [ 1 , 5 , 3 , 19 , 18 , 25 ] ; document . write ( " " + findMinDiff ( arr , arr . length ) ) ;
let a = 2 , b = 10 ; let size = Math . abs ( b - a ) + 1 ; let array = [ ] ;
for ( let i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) array [ i - a ] = 1 ; document . write ( " " + " " + " " ) ; for ( let i = a ; i <= b ; i ++ ) if ( array [ i - a ] == 1 ) document . write ( i + " " ) ;
function longestCommonSum ( n ) {
let maxLen = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
let sum1 = 0 , sum2 = 0 ;
for ( let j = i ; j < n ; j ++ ) {
sum1 += arr1 [ j ] ; sum2 += arr2 [ j ] ;
if ( sum1 == sum2 ) { let len = j - i + 1 ; if ( len > maxLen ) maxLen = len ; } } } return maxLen ; }
document . write ( " " + " " ) ; document . write ( longestCommonSum ( arr1 . length ) ) ;
function sortedAfterSwap ( A , B , n ) { let i , j ;
for ( i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] ) { j = i ; while ( B [ j ] ) { j ++ ; }
A . sort ( ) ; i = j ; } }
for ( i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) { return false ; } } return true ; }
let A = [ 1 , 2 , 5 , 3 , 4 , 6 ] ; let B = [ false , true , true , true , false ] ; let n = A . length ; if ( sortedAfterSwap ( A , B , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function sortedAfterSwap ( A , B , n ) { let t = 0 ; for ( let i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] != 0 ) { if ( A [ i ] != i + 1 ) t = A [ i ] ; A [ i ] = A [ i + 1 ] ; A [ i + 1 ] = t ; } }
for ( let i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) return 0 ; } return 1 ; }
let A = [ 1 , 2 , 5 , 3 , 4 , 6 ] ; let B = [ 0 , 1 , 1 , 1 , 0 ] ; let n = A . length ; if ( sortedAfterSwap ( A , B , n ) == 0 ) document . write ( " " ) ; else document . write ( " " ) ;
let type0 = 0 ; let type1 = n - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type0 ] = arr [ type0 ] + arr [ type1 ] ; arr [ type1 ] = arr [ type0 ] - arr [ type1 ] ; arr [ type0 ] = arr [ type0 ] - arr [ type1 ] ; type1 -- ; } else { type0 ++ ; } } }
let arr = [ 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 ] ; segregate0and1 ( arr , arr . length ) ; for ( let i = 0 ; i < arr . length ; i ++ ) document . write ( arr [ i ] + " " ) ;
function increasing ( a , n ) { for ( let i = 0 ; i < n - 1 ; i ++ ) if ( a [ i ] >= a [ i + 1 ] ) return false ; return true ; }
function decreasing ( arr , n ) { for ( let i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] < arr [ i + 1 ] ) return false ; return true ; } function shortestUnsorted ( a , n ) {
if ( increasing ( a , n ) == true || decreasing ( a , n ) == true ) return 0 ; else return 3 ; }
let ar = [ 7 , 9 , 10 , 8 , 11 ] ; let n = ar . length ; document . write ( shortestUnsorted ( ar , n ) ) ;
function printUnion ( arr1 , arr2 , m , n ) {
if ( m > n ) { let tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; let temp = m ; m = n ; n = temp ; }
arr1 . sort ( ( a , b ) => a - b ) ; for ( let i = 0 ; i < m ; i ++ ) document . write ( arr1 [ i ] + " " ) ;
for ( let i = 0 ; i < n ; i ++ ) if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) == - 1 ) document . write ( arr2 [ i ] + " " ) ; }
function printIntersection ( arr1 , arr2 , m , n ) {
if ( m > n ) { let tempp = arr1 ; arr1 = arr2 ; arr2 = tempp ; let temp = m ; m = n ; n = temp ; }
arr1 . sort ( ( a , b ) => a - b ) ;
for ( let i = 0 ; i < n ; i ++ ) if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) != - 1 ) document . write ( arr2 [ i ] + " " ) ; }
function binarySearch ( arr , l , r , x ) { if ( r >= l ) { let mid = l + Math . floor ( ( r - l ) / 2 ) ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
let arr1 = [ 7 , 1 , 5 , 2 , 3 , 6 ] ; let arr2 = [ 3 , 8 , 6 , 20 , 7 ] ; let m = arr1 . length ; let n = arr2 . length ;
document . write ( " " ) ; printUnion ( arr1 , arr2 , m , n ) ; document . write ( " " ) ; printIntersection ( arr1 , arr2 , m , n ) ;
function intersection ( a , b , n , m ) { let i = 0 , j = 0 ; while ( i < n && j < m ) { if ( a [ i ] > b [ j ] ) { j ++ ; } else if ( b [ j ] > a [ i ] ) { i ++ ; } else {
document . write ( a [ i ] + " " ) ; i ++ ; j ++ ; } } }
let a = [ 1 , 3 , 2 , 3 , 4 , 5 , 5 , 6 ] ; let b = [ 3 , 3 , 5 ] let n = a . length ; let m = b . length ;
a . sort ( ) ; b . sort ( ) ;
intersection ( a , b , n , m ) ;
function countPairsWithDiffK ( arr , n , k ) { count = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
for ( let j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] - arr [ j ] == k arr [ j ] - arr [ i ] == k ) count ++ ; } return count ; }
arr = new Array ( 1 , 5 , 3 , 4 , 2 ) ; n = arr . length ; k = 3 ; document . write ( " " + countPairsWithDiffK ( arr , n , k ) ) ;
function binarySearch ( arr , low , high , x ) { if ( high >= low ) { let mid = low + Math . floor ( ( high - low ) / 2 ) ; if ( x == arr [ mid ] ) return mid ; if ( x > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
function countPairsWithDiffK ( arr , n , k ) { let count = 0 , i ;
arr . sort ( ( a , b ) => a - b ) ;
for ( i = 0 ; i < n - 1 ; i ++ ) if ( binarySearch ( arr , i + 1 , n - 1 , arr [ i ] + k ) != - 1 ) count ++ ; return count ; }
let arr = [ 1 , 5 , 3 , 4 , 2 ] ; let n = arr . length ; let k = 3 ; document . write ( " " + countPairsWithDiffK ( arr , n , k ) ) ;
function countPairsWithDiffK ( arr , n , k ) { let count = 0 ;
arr . sort ( ) ; let l = 0 ; let r = 0 ; while ( r < n ) { if ( arr [ r ] - arr [ l ] == k ) { count ++ ; l ++ ; r ++ ; } else if ( arr [ r ] - arr [ l ] > k ) l ++ ;
else r ++ ; } return count ; }
let arr = [ 1 , 5 , 3 , 4 , 2 ] ; let n = arr . length ; let k = 3 ; document . write ( " " + countPairsWithDiffK ( arr , n , k ) ) ;
function constructArr ( arr , pair , n ) { arr [ 0 ] = Math . floor ( ( pair [ 0 ] + pair [ 1 ] - pair [ n - 1 ] ) / 2 ) ; for ( let i = 1 ; i < n ; i ++ ) arr [ i ] = pair [ i - 1 ] - arr [ 0 ] ; }
let pair = [ 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 ] ; let n = 5 ; let arr = new Array ( n ) ; constructArr ( arr , pair , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
let arr1 = [ 1 , 5 , 9 , 10 , 15 , 20 ] ; let arr2 = [ 2 , 3 , 8 , 13 ] ; function merge ( m , n ) {
for ( let i = n - 1 ; i >= 0 ; i -- ) {
let j , last = arr1 [ m - 1 ] ; for ( j = m - 2 ; j >= 0 && arr1 [ j ] > arr2 [ i ] ; j -- ) arr1 [ j + 1 ] = arr1 [ j ] ;
if ( j != m - 2 last > arr2 [ i ] ) { arr1 [ j + 1 ] = arr2 [ i ] ; arr2 [ i ] = last ; } } }
merge ( arr1 . length , arr2 . length ) ; document . write ( " " ) ; for ( let i = 0 ; i < arr1 . length ; i ++ ) { document . write ( arr1 [ i ] + " " ) ; } document . write ( " " ) ; for ( let i = 0 ; i < arr2 . length ; i ++ ) { document . write ( arr2 [ i ] + " " ) ; }
function minMaxProduct ( arr1 , arr2 , n1 , n2 ) {
arr1 . sort ( ( a , b ) => a - b ) ; arr2 . sort ( ( a , b ) => a - b ) ;
return ( arr1 [ n1 - 1 ] * arr2 [ 0 ] ) ; }
let arr1 = [ 10 , 2 , 3 , 6 , 4 , 1 ] ; let arr2 = [ 5 , 1 , 4 , 2 , 6 , 9 ] ; let n1 = arr1 . length ; let n2 = arr2 . length ; document . write ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ;
function minMaxProduct ( arr1 , arr2 , n1 , n2 ) {
let max = arr1 [ 0 ] ;
let min = arr2 [ 0 ] ; let i ; for ( i = 1 ; i < n1 && i < n2 ; ++ i ) {
if ( arr1 [ i ] > max ) max = arr1 [ i ] ;
if ( arr2 [ i ] < min ) min = arr2 [ i ] ; }
while ( i < n1 ) { if ( arr1 [ i ] > max ) max = arr1 [ i ] ; i ++ ; } while ( i < n2 ) { if ( arr2 [ i ] < min ) min = arr2 [ i ] ; i ++ ; } return max * min ; }
let arr1 = [ 10 , 2 , 3 , 6 , 4 , 1 ] ; let arr2 = [ 5 , 1 , 4 , 2 , 6 , 9 ] ; let n1 = 6 ; let n2 = 6 ; document . write ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ;
function insertSorted ( arr , n , key , capacity ) {
if ( n >= capacity ) return n ; arr [ n ] = key ; return ( n + 1 ) ; }
let arr = new Array ( 20 ) ; arr [ 0 ] = 12 ; arr [ 1 ] = 16 ; arr [ 2 ] = 20 ; arr [ 3 ] = 40 ; arr [ 4 ] = 50 ; arr [ 5 ] = 70 ; let capacity = 20 ; let n = 6 ; let i , key = 26 ; document . write ( " " ) ; for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ;
n = insertSorted ( arr , n , key , capacity ) ; document . write ( " " ) ; for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function findElement ( arr , n , key ) { let i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
function deleteElement ( arr , n , key ) {
let pos = findElement ( arr , n , key ) ; if ( pos == - 1 ) { document . write ( " " ) ; return n ; }
let i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
let i ; let arr = [ 10 , 50 , 30 , 40 , 20 ] ; let n = arr . length ; let key = 30 ; document . write ( " " ) ; for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; n = deleteElement ( arr , n , key ) ; document . write ( " " ) ; for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ;
function findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) {
var i = 0 , j = 0 , k = 0 ;
while ( i < n1 && j < n2 && k < n3 ) {
if ( ar1 [ i ] == ar2 [ j ] && ar2 [ j ] == ar3 [ k ] ) { document . write ( ar1 [ i ] + " " ) ; i ++ ; j ++ ; k ++ ; }
else if ( ar1 [ i ] < ar2 [ j ] ) i ++ ;
else if ( ar2 [ j ] < ar3 [ k ] ) j ++ ;
else k ++ ; } }
var ar1 = [ 1 , 5 , 10 , 20 , 40 , 80 ] ; var ar2 = [ 6 , 7 , 20 , 80 , 100 ] ; var ar3 = [ 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 ] ; var n1 = ar1 . length ; var n2 = ar2 . length ; var n3 = ar3 . length ; document . write ( " " ) ; findCommon ( ar1 , ar2 , ar3 , n1 , n2 , n3 ) ;
function binarySearch ( arr , l , r , x ) { if ( r >= l ) { let mid = l + Math . floor ( ( r - l ) / 2 ) ; if ( arr [ mid ] == x ) return mid ; if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ; return binarySearch ( arr , mid + 1 , r , x ) ; } return - 1 ; }
function findPos ( arr , key ) { let l = 0 , h = 1 ; let val = arr [ 0 ] ;
while ( val < key ) {
l = h ;
h = 2 * h ;
val = arr [ h ] ; }
return binarySearch ( arr , l , h , key ) ; }
let arr = [ 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 ] ; let ans = findPos ( arr , 10 ) ; if ( ans == - 1 ) document . write ( " " ) ; else document . write ( " " + ans ) ;
function findSingle ( ar , ar_size ) {
let res = ar [ 0 ] ; for ( let i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
let ar = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] ; let n = ar . length ; document . write ( " " + findSingle ( ar , n ) ) ;
function isPresent ( B , m , x ) { for ( let i = 0 ; i < m ; i ++ ) if ( B [ i ] == x ) return true ; return false ; }
function findMaxSubarraySumUtil ( A , B , n , m ) {
let max_so_far = - 2147483648 , curr_max = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( isPresent ( B , m , A [ i ] ) ) { curr_max = 0 ; continue ; }
curr_max = Math . max ( A [ i ] , curr_max + A [ i ] ) ; max_so_far = Math . max ( max_so_far , curr_max ) ; } return max_so_far ; }
function findMaxSubarraySum ( A , B , n , m ) { let maxSubarraySum = findMaxSubarraySumUtil ( A , B , n , m ) ;
if ( maxSubarraySum == - 2147483648 ) { document . write ( " " + " " + " " ) ; } else { document . write ( " " + maxSubarraySum ) ; } }
let A = [ 3 , 4 , 5 , - 4 , 6 ] ; let B = [ 1 , 8 , 5 ] ; let n = A . length ; let m = B . length ;
findMaxSubarraySum ( A , B , n , m ) ;
function findMaxSum ( arr , n ) { var res = - 1000000000 ; for ( var i = 0 ; i < n ; i ++ ) { var prefix_sum = arr [ i ] ; for ( var j = 0 ; j < i ; j ++ ) prefix_sum += arr [ j ] ; var suffix_sum = arr [ i ] ; for ( var j = n - 1 ; j > i ; j -- ) suffix_sum += arr [ j ] ; if ( prefix_sum == suffix_sum ) res = Math . max ( res , prefix_sum ) ; } return res ; }
var arr = [ - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 ] ; var n = arr . length ; document . write ( findMaxSum ( arr , n ) ) ;
function findMaxSum ( arr , n ) {
let preSum = new Array ( n ) ; preSum . fill ( 0 ) ;
let suffSum = new Array ( n ) ; suffSum . fill ( 0 ) ;
let ans = Number . MIN_VALUE ;
preSum [ 0 ] = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) preSum [ i ] = preSum [ i - 1 ] + arr [ i ] ;
suffSum [ n - 1 ] = arr [ n - 1 ] ; if ( preSum [ n - 1 ] == suffSum [ n - 1 ] ) ans = Math . max ( ans , preSum [ n - 1 ] ) ; for ( let i = n - 2 ; i >= 0 ; i -- ) { suffSum [ i ] = suffSum [ i + 1 ] + arr [ i ] ; if ( suffSum [ i ] == preSum [ i ] ) ans = Math . max ( ans , preSum [ i ] ) ; } return ans ; }
let arr = [ - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 ] ; let n = arr . length ; document . write ( findMaxSum ( arr , n ) ) ;
function printLeaders ( arr , size ) { for ( let i = 0 ; i < size ; i ++ ) { let j ; for ( j = i + 1 ; j < size ; j ++ ) { if ( arr [ i ] <= arr [ j ] ) break ; }
if ( j == size ) document . write ( arr [ i ] + " " ) ; } }
let arr = [ 16 , 17 , 4 , 3 , 5 , 2 ] ; let n = arr . length ;
function findMajority ( arr , n ) { let maxCount = 0 ;
let index = - 1 ; for ( let i = 0 ; i < n ; i ++ ) { let count = 0 ; for ( let j = 0 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; }
if ( count > maxCount ) { maxCount = count ; index = i ; } }
if ( maxCount > n / 2 ) document . write ( arr [ index ] ) ; else document . write ( " " ) ; }
let arr = [ 1 , 1 , 2 , 1 , 3 , 5 , 1 ] ; let n = arr . length ;
findMajority ( arr , n ) ;
function maxTripletSum ( arr , n ) {
let sum = - 1000000 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) for ( let k = j + 1 ; k < n ; k ++ ) if ( sum < arr [ i ] + arr [ j ] + arr [ k ] ) sum = arr [ i ] + arr [ j ] + arr [ k ] ; return sum ; }
let arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] ; let n = arr . length ; document . write ( maxTripletSum ( arr , n ) ) ;
function maxTripletSum ( arr , n ) {
arr . sort ( ) ;
return arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ; }
let arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] ; let n = arr . length ; document . write ( maxTripletSum ( arr , n ) ) ;
function maxTripletSum ( arr , n ) {
let maxA = Number . MIN_SAFE_INTEGER ; let maxB = Number . MIN_SAFE_INTEGER ; let maxC = Number . MIN_SAFE_INTEGER ; for ( let i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > maxA ) { maxC = maxB ; maxB = maxA ; maxA = arr [ i ] ; }
else if ( arr [ i ] > maxB ) { maxC = maxB ; maxB = arr [ i ] ; }
else if ( arr [ i ] > maxC ) maxC = arr [ i ] ; } return ( maxA + maxB + maxC ) ; }
let arr = [ 1 , 0 , 8 , 6 , 4 , 2 ] ; let n = arr . length ; document . write ( maxTripletSum ( arr , n ) ) ;
function maximum ( a , b , c ) { return Math . max ( Math . max ( a , b ) , c ) ; }
function minimum ( a , b , c ) { return Math . min ( Math . min ( a , b ) , c ) ; }
function smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) {
arr1 . sort ( function ( a , b ) { return a - b } ) ; arr2 . sort ( function ( a , b ) { return a - b } ) ; arr3 . sort ( function ( a , b ) { return a - b } ) ;
let res_min = 0 , res_max = 0 , res_mid = 0 ;
let i = 0 , j = 0 , k = 0 ;
let diff = 2147483647 ; while ( i < n && j < n && k < n ) { let sum = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
let max = maximum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ;
let min = minimum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ; if ( min == arr1 [ i ] ) i ++ ; else if ( min == arr2 [ j ] ) j ++ ; else k ++ ;
if ( diff > ( max - min ) ) { diff = max - min ; res_max = max ; res_mid = sum - ( max + min ) ; res_min = min ; } }
document . write ( res_max + " " + res_mid + " " + res_min ) ; }
let arr1 = [ 5 , 2 , 8 ] ; let arr2 = [ 10 , 7 , 12 ] ; let arr3 = [ 9 , 14 , 6 ] ; let n = arr1 . length ; smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) ;
function find3Numbers ( A , arr_size , sum ) { let l , r ;
A . sort ( ( a , b ) => a - b ) ;
for ( let i = 0 ; i < arr_size - 2 ; i ++ ) {
l = i + 1 ;
r = arr_size - 1 ; while ( l < r ) { if ( A [ i ] + A [ l ] + A [ r ] == sum ) { document . write ( " " + A [ i ] + " " + A [ l ] + " " + A [ r ] ) ; return true ; } else if ( A [ i ] + A [ l ] + A [ r ] < sum ) l ++ ;
else r -- ; } }
return false ; }
let A = [ 1 , 4 , 45 , 6 , 10 , 8 ] ; let sum = 22 ; let arr_size = A . length ; find3Numbers ( A , arr_size , sum ) ;
function subArray ( n ) {
for ( let i = 0 ; i < n ; i ++ ) {
for ( let j = i ; j < n ; j ++ ) {
for ( let k = i ; k <= j ; k ++ ) document . write ( arr [ k ] + " " ) ; document . write ( " " ) ; } } }
document . write ( " " + " " ) ; subArray ( arr . length ) ;
function printSubsequences ( arr , n ) {
let opsize = parseInt ( Math . pow ( 2 , n ) , 10 ) ;
for ( let counter = 1 ; counter < opsize ; counter ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( ( counter & ( 1 << j ) ) != 0 ) document . write ( arr [ j ] + " " ) ; } document . write ( " " ) ; } }
let arr = [ 1 , 2 , 3 , 4 ] ; let n = arr . length ; document . write ( " " + " " ) ; printSubsequences ( arr , n ) ;
function productArray ( arr , n ) {
if ( n == 1 ) { document . write ( " " ) ; return ; } var i , temp = 1 ;
var prod = Array ( n ) . fill ( 0 ) ;
for ( j = 0 ; j < n ; j ++ ) prod [ j ] = 1 ;
for ( i = 0 ; i < n ; i ++ ) { prod [ i ] = temp ; temp *= arr [ i ] ; }
temp = 1 ;
for ( i = n - 1 ; i >= 0 ; i -- ) { prod [ i ] *= temp ; temp *= arr [ i ] ; }
for ( i = 0 ; i < n ; i ++ ) document . write ( prod [ i ] + " " ) ; return ; }
var arr = [ 10 , 3 , 5 , 6 , 2 ] ; var n = arr . length ; document . write ( " " ) ; productArray ( arr , n ) ;
function areConsecutive ( arr , n ) { if ( n < 1 ) return false ;
let min = getMin ( arr , n ) ;
let max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) {
let visited = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) { visited [ i ] = false ; } let i ; for ( i = 0 ; i < n ; i ++ ) {
if ( visited [ arr [ i ] - min ] != false ) { return false ; }
visited [ arr [ i ] - min ] = true ; }
return true ; }
return false ; }
function getMin ( arr , n ) { let min = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } function getMax ( arr , n ) { let max = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
let arr = [ 5 , 4 , 2 , 3 , 1 , 6 ] let n = arr . length ; if ( areConsecutive ( arr , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function areConsecutive ( arr , n ) { if ( n < 1 ) return false ;
let min = getMin ( arr , n ) ;
let max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) { let i ; for ( i = 0 ; i < n ; i ++ ) { let j ; if ( arr [ i ] < 0 ) j = - arr [ i ] - min ; else j = arr [ i ] - min ;
if ( arr [ j ] > 0 ) arr [ j ] = - arr [ j ] ; else return false ; }
return true ; }
return false ; }
function getMin ( arr , n ) { let min = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } function getMax ( arr , n ) { let max = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
let arr = [ 5 , 4 , 2 , 3 , 1 , 6 ] ; let n = arr . length ; if ( areConsecutive ( arr , n ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
function relativeComplement ( arr1 , arr2 , n , m ) { let i = 0 , j = 0 ; while ( i < n && j < m ) {
if ( arr1 [ i ] < arr2 [ j ] ) { document . write ( arr1 [ i ] + " " ) ; i ++ ;
} else if ( arr1 [ i ] > arr2 [ j ] ) { j ++ ;
} else if ( arr1 [ i ] == arr2 [ j ] ) { i ++ ; j ++ ; } }
while ( i < n ) document . write ( arr1 [ i ] + " " ) ; }
let arr1 = [ 3 , 6 , 10 , 12 , 15 ] ; let arr2 = [ 1 , 3 , 5 , 10 , 16 ] ; let n = arr1 . length ; let m = arr2 . length ; relativeComplement ( arr1 , arr2 , n , m ) ;
function minOps ( arr , n , k ) {
var max = arr [ 0 ] ; for ( var i = 0 ; i < arr . length ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } var res = 0 ;
for ( var i = 0 ; i < n ; i ++ ) {
if ( ( max - arr [ i ] ) % k != 0 ) return - 1 ;
else res += ( max - arr [ i ] ) / k ; }
return res ; }
var arr = [ 21 , 33 , 9 , 45 , 63 ] ; var n = arr . length ; var k = 6 ; document . write ( minOps ( arr , n , k ) ) ;
function solve ( A , B , C ) { let i , j , k ;
min_diff = Math . abs ( Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) - Math . min ( A [ i ] , Math . min ( B [ j ] , C [ k ] ) ) ) ; while ( i != - 1 && j != - 1 && k != - 1 ) { current_diff = Math . abs ( Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) - Math . min ( A [ i ] , Math . min ( B [ j ] , C [ k ] ) ) ) ;
if ( current_diff < min_diff ) min_diff = current_diff ;
max_term = Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) ;
if ( A [ i ] == max_term ) i -= 1 ; else if ( B [ j ] == max_term ) j -= 1 ; else k -= 1 ; } return min_diff ; }
let D = [ 5 , 8 , 10 , 15 ] ; let E = [ 6 , 9 , 15 , 78 , 89 ] ; let F = [ 2 , 3 , 6 , 6 , 8 , 8 , 10 ] ; document . write ( solve ( D , E , F ) ) ;
function jumpSearch ( arr , x , n ) {
let step = Math . sqrt ( n ) ;
let prev = 0 ; while ( arr [ Math . min ( step , n ) - 1 ] < x ) { prev = step ; step += Math . sqrt ( n ) ; if ( prev >= n ) return - 1 ; }
while ( arr [ prev ] < x ) { prev ++ ;
if ( prev == Math . min ( step , n ) ) return - 1 ; }
if ( arr [ prev ] == x ) return prev ; return - 1 ; }
let arr = [ 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 ] ; let x = 55 ; let n = arr . length ;
let index = jumpSearch ( arr , x , n ) ;
document . write ( ` ${ x } ${ index } ` ) ;
function exponentialSearch ( arr , n , x ) {
if ( arr [ 0 ] == x ) return 0 ;
let i = 1 ; while ( i < n && arr [ i ] <= x ) i = i * 2 ;
return binarySearch ( arr , i / 2 , Math . min ( i , n - 1 ) , x ) ; }
function binarySearch ( arr , l , r , x ) { if ( r >= l ) { let mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
let arr = [ 2 , 3 , 4 , 10 , 40 ] ; let n = arr . length ; let x = 10 ; let result = exponentialSearch ( arr , n , x ) ; if ( result == - 1 ) document . write ( " " ) ; else document . write ( " " + result ) ;
function findCrossOver ( arr , low , high , x ) {
if ( arr [ high ] <= x ) return high
if ( arr [ low ] > x ) return low
var mid = ( low + high ) / 2
if ( arr [ mid ] <= x && arr [ mid + 1 ] > x ) return mid
if ( arr [ mid ] < x ) return findCrossOver ( arr , mid + 1 , high , x ) return findCrossOver ( arr , low , mid - 1 , x ) }
function printKclosest ( arr , x , k , n ) {
var l = findCrossOver ( arr , 0 , n - 1 , x )
var r = l + 1
var count = 0
if ( arr [ l ] == x ) l -= 1
while ( l >= 0 && r < n && count < k ) { if ( x - arr [ l ] < arr [ r ] - x ) { document . write ( arr [ l ] + " " ) l -= 1 } else { document . write ( arr [ r ] + " " ) r += 1 } count += 1 }
while ( count < k && l >= 0 ) { print ( arr [ l ] ) l -= 1 count += 1 }
while ( count < k && r < n ) { print ( arr [ r ] ) r += 1 count += 1 } }
var arr = [ 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 ] var n = arr . length var x = 35 var k = 4 printKclosest ( arr , x , 4 , n )
function printClosest ( ar1 , ar2 , m , n , x ) {
let diff = Number . MAX_VALUE ;
let res_l , res_r ;
let l = 0 , r = n - 1 ; while ( l < m && r >= 0 ) {
if ( Math . abs ( ar1 [ l ] + ar2 [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( ar1 [ l ] + ar2 [ r ] - x ) ; }
if ( ar1 [ l ] + ar2 [ r ] > x ) r -- ;
else l ++ ; }
document . write ( " " + ar1 [ res_l ] + " " + ar2 [ res_r ] + " " ) ; }
let ar1 = [ 1 , 4 , 5 , 7 ] ; let ar2 = [ 10 , 20 , 30 , 40 ] ; let m = ar1 . length ; let n = ar2 . length ; let x = 38 ; printClosest ( ar1 , ar2 , m , n , x ) ;
function printClosest ( arr , n , x ) {
let res_l = 0 , res_r = 0 ;
let l = 0 , r = n - 1 , diff = Number . MAX_VALUE ;
while ( r > l ) {
if ( Math . abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } document . write ( " " + arr [ res_l ] + " " + arr [ res_r ] ) ; }
let arr = [ 10 , 22 , 28 , 29 , 30 , 40 ] , x = 54 ; let n = arr . length ; printClosest ( arr , n , x ) ;
function countOnes ( arr , low , high ) { if ( high >= low ) {
let mid = Math . trunc ( low + ( high - low ) / 2 ) ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
let arr = [ 1 , 1 , 1 , 1 , 0 , 0 , 0 ] ; let n = arr . length ; document . write ( " " + countOnes ( arr , 0 , n - 1 ) ) ;
function solve ( a , n ) { let maxx = - 1 , minn = a [ 0 ] , l = 0 , r = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( a [ i ] > maxx ) { maxx = a [ i ] ; l = i ; }
if ( a [ i ] <= minn ) { minn = a [ i ] ; r = i ; } } if ( r < l ) document . write ( l + ( n - r - 2 ) ) ; else document . write ( l + ( n - r - 1 ) ) ; }
let a = [ 5 , 6 , 1 , 3 ] ; let n = a . length ; solve ( a , n ) ;
function count ( S , m , n ) {
if ( n == 0 ) return 1 ;
if ( n < 0 ) return 0 ;
if ( m <= 0 && n >= 1 ) return 0 ;
return count ( S , m - 1 , n ) + count ( S , m , n - S [ m - 1 ] ) ; }
var arr = [ 1 , 2 , 3 ] ; var m = arr . length ; document . write ( count ( arr , m , 4 ) ) ;
function count ( S , m , n ) {
let table = new Array ( n + 1 ) ; table . fill ( 0 ) ;
table [ 0 ] = 1 ;
for ( let i = 0 ; i < m ; i ++ ) for ( let j = S [ i ] ; j <= n ; j ++ ) table [ j ] += table [ j - S [ i ] ] ; return table [ n ] ; }
let arr = [ 1 , 2 , 3 ] ; let m = arr . length ; let n = 4 ; document . write ( count ( arr , m , n ) ) ;
function binomialCoeff ( n , k ) { let C = new Array ( k + 1 ) ; C . fill ( 0 ) ;
C [ 0 ] = 1 ; for ( let i = 1 ; i <= n ; i ++ ) {
for ( let j = Math . min ( i , k ) ; j > 0 ; j -- ) C [ j ] = C [ j ] + C [ j - 1 ] ; } return C [ k ] ; }
let n = 5 , k = 2 ; document . write ( " " + n + " " + k + " " + binomialCoeff ( n , k ) ) ;
function cutRod ( price , n ) { if ( n <= 0 ) return 0 ; let max_val = Number . MIN_VALUE ;
for ( let i = 0 ; i < n ; i ++ ) max_val = Math . max ( max_val , price [ i ] + cutRod ( price , n - i - 1 ) ) ; return max_val ; }
let arr = [ 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ] ; let size = arr . length ; document . write ( " " + cutRod ( arr , size ) ) ;
function cutRod ( price , n ) { let val = new Array ( n + 1 ) ; val [ 0 ] = 0 ;
for ( let i = 1 ; i <= n ; i ++ ) { let max_val = Number . MIN_VALUE ; for ( let j = 0 ; j < i ; j ++ ) max_val = Math . max ( max_val , price [ j ] + val [ i - j - 1 ] ) ; val [ i ] = max_val ; } return val [ n ] ; }
let arr = [ 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 ] ; let size = arr . length ; document . write ( " " + cutRod ( arr , size ) + " " ) ;
function lbs ( arr , n ) { let i , j ;
let lis = new Array ( n ) for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
let lds = new Array ( n ) ; for ( i = 0 ; i < n ; i ++ ) lds [ i ] = 1 ;
for ( i = n - 2 ; i >= 0 ; i -- ) for ( j = n - 1 ; j > i ; j -- ) if ( arr [ i ] > arr [ j ] && lds [ i ] < lds [ j ] + 1 ) lds [ i ] = lds [ j ] + 1 ;
let max = lis [ 0 ] + lds [ 0 ] - 1 ; for ( i = 1 ; i < n ; i ++ ) if ( lis [ i ] + lds [ i ] - 1 > max ) max = lis [ i ] + lds [ i ] - 1 ; return max ; }
let arr = [ 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 ] let n = arr . length ; document . write ( " " + lbs ( arr , n ) ) ;
function maxDivide ( a , b ) { while ( a % b == 0 ) a = a / b ; return a ; }
function isUgly ( no ) { no = maxDivide ( no , 2 ) ; no = maxDivide ( no , 3 ) ; no = maxDivide ( no , 5 ) ; return ( no == 1 ) ? 1 : 0 ; }
function getNthUglyNo ( n ) { var i = 1 ;
var count = 1 ;
while ( n > count ) { i ++ ; if ( isUgly ( i ) == 1 ) count ++ ; } return i ; }
var no = getNthUglyNo ( 150 ) ; document . write ( " " + " " + no ) ;
function isSubsetSum ( set , n , sum ) {
if ( sum == 0 ) return true ; if ( n == 0 ) return false ;
if ( set [ n - 1 ] > sum ) return isSubsetSum ( set , n - 1 , sum ) ;
return isSubsetSum ( set , n - 1 , sum ) || isSubsetSum ( set , n - 1 , sum - set [ n - 1 ] ) ; }
let set = [ 3 , 34 , 4 , 12 , 5 , 2 ] ; let sum = 9 ; let n = set . length ; if ( isSubsetSum ( set , n , sum ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
function isSubsetSum ( set , n , sum ) {
let subset = new Array ( sum + 1 ) ; for ( let i = 0 ; i < sum + 1 ; i ++ ) { subset [ i ] = new Array ( sum + 1 ) ; for ( let j = 0 ; j < n + 1 ; j ++ ) { subset [ i ] [ j ] = 0 ; } }
for ( let i = 0 ; i <= n ; i ++ ) subset [ 0 ] [ i ] = true ;
for ( let i = 1 ; i <= sum ; i ++ ) subset [ i ] [ 0 ] = false ;
for ( let i = 1 ; i <= sum ; i ++ ) { for ( let j = 1 ; j <= n ; j ++ ) { subset [ i ] [ j ] = subset [ i ] [ j - 1 ] ; if ( i >= set [ j - 1 ] ) subset [ i ] [ j ] = subset [ i ] [ j ] || subset [ i - set [ j - 1 ] ] [ j - 1 ] ; } }
for ( int i = 0 ; i <= sum ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) System . out . println ( subset [ i ] [ j ] ) ; } return subset [ sum ] [ n ] ; }
let set = [ 3 , 34 , 4 , 12 , 5 , 2 ] ; let sum = 9 ; let n = set . length ; if ( isSubsetSum ( set , n , sum ) == true ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ;
function countRec ( n , sum ) {
if ( n == 0 ) return sum == 0 ; if ( sum == 0 ) return 1 ;
let ans = 0 ;
for ( let i = 0 ; i <= 9 ; i ++ ) { if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; } return ans ; }
function finalCount ( n , sum ) {
let ans = 0 ;
for ( let i = 1 ; i <= 9 ; i ++ ) { if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; } return ans ; }
let n = 2 , sum = 5 ; document . write ( finalCount ( n , sum ) ) ;
let lookup = new Array ( 101 ) ;
function countRec ( n , sum ) {
if ( n == 0 ) return sum == 0 ? 1 : 0 ;
if ( lookup [ n ] [ sum ] != - 1 ) return lookup [ n ] [ sum ] ;
let ans = 0 ;
for ( let i = 0 ; i < 10 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return lookup [ n ] [ sum ] = ans ; }
function finalCount ( n , sum ) {
let ans = 0 ;
for ( let i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
let n = 3 , sum = 5 ; document . write ( finalCount ( n , sum ) ) ;
function findCount ( n , sum ) {
let start = Math . pow ( 10 , n - 1 ) ; let end = Math . pow ( 10 , n ) - 1 ; let count = 0 ; let i = start ; while ( i <= end ) { let cur = 0 ; let temp = i ; while ( temp != 0 ) { cur += temp % 10 ; temp = parseInt ( temp / 10 ) ; } if ( cur == sum ) { count ++ ; i += 9 ; } else i ++ ; } document . write ( count ) ; }
let n = 3 ; let sum = 5 ; findCount ( n , sum ) ;
function countNonDecreasing ( n ) {
let dp = new Array ( 10 ) ; for ( let i = 0 ; i < 10 ; i ++ ) { dp [ i ] = new Array ( n + 1 ) ; } for ( let i = 0 ; i < 10 ; i ++ ) { for ( let j = 0 ; j < n + 1 ; j ++ ) { dp [ i ] [ j ] = 0 ; } }
for ( let i = 0 ; i < 10 ; i ++ ) dp [ i ] [ 1 ] = 1 ;
for ( let digit = 0 ; digit <= 9 ; digit ++ ) {
for ( let len = 2 ; len <= n ; len ++ ) {
for ( let x = 0 ; x <= digit ; x ++ ) dp [ digit ] [ len ] += dp [ x ] [ len - 1 ] ; } } let count = 0 ;
for ( let i = 0 ; i < 10 ; i ++ ) count += dp [ i ] [ n ] ; return count ; }
let n = 3 ; document . write ( countNonDecreasing ( n ) ) ;
function countNonDecreasing ( n ) { let N = 10 ;
let count = 1 ; for ( let i = 1 ; i <= n ; i ++ ) { count *= ( N + i - 1 ) ; count = Math . floor ( count / i ) ; } return count ; }
let n = 3 ; document . write ( countNonDecreasing ( n ) ) ;
function getMinSquares ( n ) {
if ( n <= 3 ) return n ;
let res = n ;
for ( let x = 1 ; x <= n ; x ++ ) { let temp = x * x ; if ( temp > n ) break ; else res = Math . min ( res , 1 + getMinSquares ( n - temp ) ) ; } return res ; }
document . write ( getMinSquares ( 6 ) ) ;
function getMinSquares ( n ) {
var dp = new Array ( n + 1 ) ;
dp [ 0 ] = 0 ; dp [ 1 ] = 1 ; dp [ 2 ] = 2 ; dp [ 3 ] = 3 ;
for ( var i = 4 ; i <= n ; i ++ ) {
dp [ i ] = i ;
for ( var x = 1 ; x <= Math . ceil ( Math . sqrt ( i ) ) ; x ++ ) { var temp = x * x ; if ( temp > i ) break ; else dp [ i ] = Math . min ( dp [ i ] , 1 + dp [ i - temp ] ) ; } }
var res = dp [ n ] ; return res ; }
document . write ( getMinSquares ( 6 ) ) ;
function minCoins ( coins , m , V ) {
if ( V == 0 ) return 0 ;
let res = Number . MAX_VALUE ;
for ( let i = 0 ; i < m ; i ++ ) { if ( coins [ i ] <= V ) { let sub_res = minCoins ( coins , m , V - coins [ i ] ) ;
if ( sub_res != Number . MAX_VALUE && sub_res + 1 < res ) res = sub_res + 1 ; } } return res ; }
let coins = [ 9 , 6 , 5 , 1 ] ; let m = coins . length ; let V = 11 ; document . write ( " " + minCoins ( coins , m , V ) ) ;
function minCoins ( coins , m , v ) {
let table = new Array ( V + 1 ) ;
for ( let i = 0 ; i < V + 1 ; i ++ ) { table [ i ] = 0 ; }
for ( let i = 1 ; i <= V ; i ++ ) { table [ i ] = Number . MAX_VALUE ; }
for ( let i = 1 ; i <= V ; i ++ ) {
for ( let j = 0 ; j < m ; j ++ ) if ( coins [ j ] <= i ) { let sub_res = table [ i - coins [ j ] ] ; if ( sub_res != Number . MAX_VALUE && sub_res + 1 < table [ i ] ) table [ i ] = sub_res + 1 ; } } if ( table [ V ] == Number . MAX_VALUE ) return - 1 ; return table [ V ] ; }
let coins = [ 9 , 6 , 5 , 1 ] ; let m = coins . length ; let V = 11 ; document . write ( " " + minCoins ( coins , m , V ) )
function superSeq ( X , Y , m , n ) { if ( m == 0 ) return n ; if ( n == 0 ) return m ; if ( X . charAt ( m - 1 ) == Y . charAt ( n - 1 ) ) return 1 + superSeq ( X , Y , m - 1 , n - 1 ) ; return 1 + Math . min ( superSeq ( X , Y , m - 1 , n ) , superSeq ( X , Y , m , n - 1 ) ) ; }
var X = " " ; var Y = " " ; document . write ( " " + " " + superSeq ( X , Y , X . length , Y . length ) ) ;
function superSeq ( X , Y , m , n ) { var dp = Array ( m + 1 ) . fill ( 0 ) . map ( x => Array ( n + 1 ) . fill ( 0 ) ) ;
for ( var i = 0 ; i <= m ; i ++ ) { for ( var j = 0 ; j <= n ; j ++ ) {
if ( i == 0 ) dp [ i ] [ j ] = j ; else if ( j == 0 ) dp [ i ] [ j ] = i ; else if ( X . charAt ( i - 1 ) == Y . charAt ( j - 1 ) ) dp [ i ] [ j ] = 1 + dp [ i - 1 ] [ j - 1 ] ; else dp [ i ] [ j ] = 1 + Math . min ( dp [ i - 1 ] [ j ] , dp [ i ] [ j - 1 ] ) ; } } return dp [ m ] [ n ] ; }
var X = " " ; var Y = " " ; document . write ( " " + superSeq ( X , Y , X . length , Y . length ) ) ;
function sumOfDigitsFrom1ToN ( n ) {
let result = 0 ;
for ( let x = 1 ; x <= n ; x ++ ) result += sumOfDigits ( x ) ; return result ; }
function sumOfDigits ( x ) { let sum = 0 ; while ( x != 0 ) { sum += x % 10 ; x = parseInt ( x / 10 , 10 ) ; } return sum ; }
let n = 328 ; document . write ( " " + " " + n + " " + sumOfDigitsFrom1ToN ( n ) ) ;
function sumOfDigitsFrom1ToN ( n ) {
if ( n < 10 ) return ( n * ( n + 1 ) / 2 ) ;
let d = parseInt ( Math . log ( n ) / Math . log ( 10 ) , 10 ) ;
let a = new Array ( d + 1 ) ; a [ 0 ] = 0 ; a [ 1 ] = 45 ; for ( let i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * parseInt ( Math . ceil ( Math . pow ( 10 , i - 1 ) ) , 10 ) ;
let p = parseInt ( Math . ceil ( Math . pow ( 10 , d ) ) , 10 ) ;
let msd = parseInt ( n / p , 10 ) ;
return ( msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToN ( n % p ) ) ; }
let n = 328 ; document . write ( " " + n + " " + sumOfDigitsFrom1ToN ( n ) ) ;
function countWays ( N ) {
if ( N == 1 )
return 4 ;
let countB = 1 , countS = 1 , prev_countB , prev_countS ;
for ( let i = 2 ; i <= N ; i ++ ) { prev_countB = countB ; prev_countS = countS ; countS = prev_countB + prev_countS ; countB = prev_countS ; }
let result = countS + countB ;
return ( result * result ) ; }
N = 3 ; document . write ( " " + N + " " + countWays ( N ) ) ;
function area ( x1 , y1 , x2 , y2 , x3 , y3 ) { return Math . abs ( ( x1 * ( y2 - y3 ) + x2 * ( y3 - y1 ) + x3 * ( y1 - y2 ) ) / 2.0 ) ; }
function isInside ( x1 , y1 , x2 , y2 , x3 , y3 , x , y ) {
let A = area ( x1 , y1 , x2 , y2 , x3 , y3 ) ;
let A1 = area ( x , y , x2 , y2 , x3 , y3 ) ;
let A2 = area ( x1 , y1 , x , y , x3 , y3 ) ;
let A3 = area ( x1 , y1 , x2 , y2 , x , y ) ;
return ( A == A1 + A2 + A3 ) ; }
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) document . write ( " " ) ; else document . write ( " " ) ;
function getAvg ( prev_avg , x , n ) { return ( prev_avg * n + x ) / ( n + 1 ) ; }
function streamAvg ( arr , n ) { let avg = 0 ; for ( let i = 0 ; i < n ; i ++ ) { avg = getAvg ( avg , arr [ i ] , i ) ; document . write ( " " + ( i + 1 ) + " " + avg . toFixed ( 6 ) + " " ) ; } return ; }
let arr = [ 10 , 20 , 30 , 40 , 50 , 60 ] ; let n = arr . length ; streamAvg ( arr , n ) ;
function sieveOfEratosthenes ( n ) {
prime = Array . from ( { length : n + 1 } , ( _ , i ) => true ) ; for ( p = 2 ; p * p <= n ; p ++ ) {
if ( prime [ p ] == true ) {
for ( i = p * p ; i <= n ; i += p ) prime [ i ] = false ; } }
for ( i = 2 ; i <= n ; i ++ ) { if ( prime [ i ] == true ) document . write ( i + " " ) ; } }
var n = 30 ; document . write ( " " ) ; document . write ( " " + n + " " ) ; sieveOfEratosthenes ( n ) ;
function maximumNumberDistinctPrimeRange ( m , n ) {
let factorCount = new Array ( n + 1 ) ;
let prime = new Array ( n + 1 ) ;
for ( let i = 0 ; i <= n ; i ++ ) { factorCount [ i ] = 0 ;
prime [ i ] = true ; } for ( let i = 2 ; i <= n ; i ++ ) {
if ( prime [ i ] == true ) {
factorCount [ i ] = 1 ;
for ( let j = i * 2 ; j <= n ; j += i ) {
factorCount [ j ] ++ ;
prime [ j ] = false ; } } }
let max = factorCount [ m ] ; let num = m ;
for ( let i = m ; i <= n ; i ++ ) {
if ( factorCount [ i ] > max ) { max = factorCount [ i ] ; num = i ; } } return num ; }
let m = 4 , n = 6 ;
document . write ( maximumNumberDistinctPrimeRange ( m , n ) ) ;
function binomialCoeff ( n , k ) { let res = 1 ; if ( k > n - k ) k = n - k ; for ( let i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
function printPascal ( n ) {
for ( let line = 0 ; line < n ; line ++ ) {
for ( let i = 0 ; i <= line ; i ++ ) document . write ( binomialCoeff ( line , i ) + " " ) ; document . write ( " " ) ; } }
let n = 7 ; printPascal ( n ) ;
function isPerfectSquare ( x ) { let s = parseInt ( Math . sqrt ( x ) ) ; return ( s * s == x ) ; }
function isFibonacci ( n ) {
return isPerfectSquare ( 5 * n * n + 4 ) || isPerfectSquare ( 5 * n * n - 4 ) ; }
for ( let i = 1 ; i <= 10 ; i ++ ) isFibonacci ( i ) ? document . write ( i + " " ) : document . write ( i + " " ) ;
function findTrailingZeros ( n ) {
let count = 0 ;
for ( let i = 5 ; Math . floor ( n / i ) >= 1 ; i *= 5 ) count += Math . floor ( n / i ) ; return count ; }
let n = 100 ; document . write ( " " + 100 + " " + findTrailingZeros ( n ) ) ;
function catalan ( n ) {
if ( n <= 1 ) return 1 ;
let res = 0 ; for ( let i = 0 ; i < n ; i ++ ) res += catalan ( i ) * catalan ( n - i - 1 ) ; return res ; }
for ( let i = 0 ; i < 10 ; i ++ ) document . write ( catalan ( i ) + " " ) ;
function catalanDP ( n ) {
let catalan = [ ] ;
catalan [ 0 ] = catalan [ 1 ] = 1 ;
for ( let i = 2 ; i <= n ; i ++ ) { catalan [ i ] = 0 ; for ( let j = 0 ; j < i ; j ++ ) catalan [ i ] += catalan [ j ] * catalan [ i - j - 1 ] ; }
return catalan [ n ] ; }
for ( let i = 0 ; i < 10 ; i ++ ) document . write ( catalanDP ( i ) + " " ) ;
function binomialCoeff ( n , k ) { let res = 1 ;
if ( k > n - k ) k = n - k ;
for ( let i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res = Math . floor ( res / ( i + 1 ) ) ; } return res ; }
function catalan ( n ) {
c = binomialCoeff ( 2 * ( n ) , n ) ;
return Math . floor ( c / ( n + 1 ) ) ; }
for ( let i = 0 ; i < 10 ; i ++ ) document . write ( catalan ( i ) + " " ) ;
function getInvCount ( arr ) { let inv_count = 0 ; for ( let i = 0 ; i < 2 ; i ++ ) { for ( let j = i + 1 ; j < 3 ; j ++ ) {
if ( arr [ j ] [ i ] > 0 && arr [ j ] [ i ] > arr [ i ] [ j ] ) inv_count += 1 ; } } return inv_count ; }
function isSolvable ( puzzle ) {
let invCount = getInvCount ( puzzle ) ;
return ( invCount % 2 == 0 ) ; }
puzzle = [ [ 1 , 8 , 2 ] , [ 0 , 4 , 3 ] , [ 7 , 6 , 5 ] ] ; if ( isSolvable ( puzzle ) ) document . write ( " " ) ; else document . write ( " " ) ;
function find ( p ) { return Math . ceil ( Math . sqrt ( 2 * 365 * Math . log ( 1 / ( 1 - p ) ) ) ) ; }
document . write ( find ( 0.70 ) ) ;
function countSolutions ( n ) { let res = 0 ; for ( let x = 0 ; x * x < n ; x ++ ) { for ( let y = 0 ; x * x + y * y < n ; y ++ ) { res ++ ; } } return res ; }
document . write ( " " + countSolutions ( 6 ) ) ;
function countSolutions ( n ) { let x = 0 , yCount , res = 0 ;
for ( yCount = 0 ; yCount * yCount < n ; yCount ++ ) ;
while ( yCount != 0 ) {
res += yCount ;
x ++ ;
while ( yCount != 0 && ( x * x + ( yCount - 1 ) * ( yCount - 1 ) >= n ) ) yCount -- ; } return res ; }
document . write ( " " + " " + countSolutions ( 6 ) ) ;
let EPSILON = 0.001 ;
function func ( x ) { return x * x * x - x * x + 2 ; }
function derivFunc ( x ) { return 3 * x * x - 2 * x ; }
function newtonRaphson ( x ) { let h = func ( x ) / derivFunc ( x ) ; while ( Math . abs ( h ) >= EPSILON ) { h = func ( x ) / derivFunc ( x ) ;
x = x - h ; } document . write ( " " + " " + Math . round ( x * 100.0 ) / 100.0 ) ; }
let x0 = - 20 ; newtonRaphson ( x0 ) ;
function oppositeSigns ( x , y ) { return ( ( x ^ y ) < 0 ) ; }
let x = 100 , y = - 100 ; if ( oppositeSigns ( x , y ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
function countSetBits ( n ) {
let bitCount = 0 ; for ( let i = 1 ; i <= n ; i ++ ) { bitCount += countSetBitsUtil ( i ) ; } return bitCount ; }
function countSetBitsUtil ( x ) { if ( x <= 0 ) { return 0 ; } return ( x % 2 == 0 ? 0 : 1 ) + countSetBitsUtil ( Math . floor ( x / 2 ) ) ; }
let n = 4 ; document . write ( " " ) ; document . write ( countSetBits ( n ) ) ;
function countSetBits ( n ) { let i = 0 ;
let ans = 0 ;
while ( ( 1 << i ) <= n ) {
let k = 0 ;
let change = 1 << i ;
for ( let j = 0 ; j <= n ; j ++ ) { ans += k ; if ( change == 1 ) {
k = ! k ;
change = 1 << i ; } else { change -- ; } }
i ++ ; } return ans ; }
let n = 17 ; document . write ( countSetBits ( n ) ) ;
function snoob ( x ) { let rightOne , nextHigherOneBit , rightOnesPattern , next = 0 ; if ( x > 0 ) {
rightOne = x & - x ;
nextHigherOneBit = x + rightOne ;
rightOnesPattern = x ^ nextHigherOneBit ;
rightOnesPattern = ( rightOnesPattern ) / rightOne ;
rightOnesPattern >>= 2 ;
next = nextHigherOneBit | rightOnesPattern ; } return next ; }
let x = 156 ; document . write ( " " + " " + snoob ( x ) ) ;
function multiplyWith3Point5 ( x ) { return ( x << 1 ) + x + ( x >> 1 ) ; }
var x = 4 ; document . write ( multiplyWith3Point5 ( x ) ) ;
function getModulo ( n , d ) { return ( n & ( d - 1 ) ) ; }
n = 6 ;
d = 4 ; document . write ( n + " " + d + " " + getModulo ( n , d ) ) ;
function getOddOccurrence ( arr , arr_size ) { for ( let i = 0 ; i < arr_size ; i ++ ) { let count = 0 ; for ( let j = 0 ; j < arr_size ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; } if ( count % 2 != 0 ) return arr [ i ] ; } return - 1 ; }
let arr = [ 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 ] ; let n = arr . length ;
document . write ( getOddOccurrence ( arr , n ) ) ;
function fastPow ( N , K ) { if ( K == 0 ) return 1 ; let temp = fastPow ( N , Math . floor ( K / 2 ) ) ; if ( K % 2 == 0 ) return temp * temp ; else return N * temp * temp ; } function countWays ( N , K ) { return K * fastPow ( K - 1 , N - 1 ) ; }
let N = 3 , K = 3 ; document . write ( countWays ( N , K ) ) ;
function countSetBits ( n ) {
if ( n == 0 ) return 0 ; else return 1 + countSetBits ( n & ( n - 1 ) ) ; }
var n = 9 ;
document . write ( countSetBits ( n ) ) ;
document . write ( ( 4 ) . toString ( 2 ) . split ( ' ' ) . filter ( x => x == ' ' ) . length + " " ) ; document . write ( ( 15 ) . toString ( 2 ) . split ( ' ' ) . filter ( x => x == ' ' ) . length ) ;
function countSetBits ( n ) { var count = 0 ; while ( n != 0 ) { count ++ ; n &= ( n - 1 ) ; } return count ; }
function FlippedCount ( a , b ) {
return countSetBits ( a ^ b ) ; }
var a = 10 ; var b = 20 ; document . write ( FlippedCount ( a , b ) ) ;
function PositionRightmostSetbit ( n ) {
let position = 1 ; let m = 1 ; while ( ( n & m ) == 0 ) {
m = m << 1 ; position ++ ; } return position ; }
let n = 16 ;
document . write ( PositionRightmostSetbit ( n ) ) ;
let INT_SIZE = 32 ; function Right_most_setbit ( num ) { let pos = 1 ;
for ( let i = 0 ; i < INT_SIZE ; i ++ ) { if ( ( num & ( 1 << i ) ) == 0 ) pos ++ ; else break ; } return pos ; }
let num = 18 ; let pos = Right_most_setbit ( num ) ; document . write ( pos ) ;
function bin ( n ) { if ( n > 1 ) bin ( n >> 1 ) ; document . write ( n & 1 ) ; }
bin ( 131 ) ; document . write ( " " ) ; bin ( 3 ) ;
function maxOnesIndex ( arr , n ) {
let max_count = 0 ;
let max_index = 0 ;
let prev_zero = - 1 ;
let prev_prev_zero = - 1 ;
for ( let curr = 0 ; curr < n ; ++ curr ) {
if ( arr [ curr ] == 0 ) {
if ( curr - prev_prev_zero > max_count ) { max_count = curr - prev_prev_zero ; max_index = prev_zero ; }
prev_prev_zero = prev_zero ; prev_zero = curr ; } }
if ( n - prev_prev_zero > max_count ) max_index = prev_zero ; return max_index ; }
let arr = [ 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 ] ; let n = arr . length ; document . write ( " " + maxOnesIndex ( arr , n ) ) ;
function min ( x , y ) { return ( x < y ) ? x : y ; } function max ( x , y ) { return ( x > y ) ? x : y ; }
function findLength ( arr , n ) {
let max_len = 1 ; for ( let i = 0 ; i < n - 1 ; i ++ ) {
let mn = arr [ i ] , mx = arr [ i ] ;
for ( let j = i + 1 ; j < n ; j ++ ) {
mn = min ( mn , arr [ j ] ) ; mx = max ( mx , arr [ j ] ) ;
if ( ( mx - mn ) == j - i ) max_len = Math . max ( max_len , mx - mn + 1 ) ; } }
return max_len ; }
let arr = [ 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 ] ; let n = arr . length ; document . write ( " " + findLength ( arr , n ) ) ;
function printArr ( arr , k ) { for ( let i = 0 ; i < k ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; }
function printSeqUtil ( n , k , len , arr ) {
if ( len == k ) { printArr ( arr , k ) ; return ; }
let i = ( len == 0 ) ? 1 : arr [ len - 1 ] + 1 ;
len ++ ;
while ( i <= n ) { arr [ len - 1 ] = i ; printSeqUtil ( n , k , len , arr ) ; i ++ ; }
len -- ; }
function printSeq ( n , k ) {
let arr = new Array ( k ) ;
let len = 0 ; printSeqUtil ( n , k , len , arr ) ; }
let k = 3 , n = 7 ; printSeq ( n , k ) ;
function isSubSequence ( str1 , str2 , m , n ) {
if ( m == 0 ) return true ; if ( n == 0 ) return false ;
if ( str1 [ m - 1 ] == str2 [ n - 1 ] ) return isSubSequence ( str1 , str2 , m - 1 , n - 1 ) ;
return isSubSequence ( str1 , str2 , m , n - 1 ) ; }
let str1 = " " ; let str2 = " " ; let m = str1 . length ; let n = str2 . length ; let res = isSubSequence ( str1 , str2 , m , n ) ; if ( res ) document . write ( " " ) ; else document . write ( " " ) ;
function segregate0and1 ( arr , n ) {
let count = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 0 ) count ++ ; }
for ( let i = 0 ; i < count ; i ++ ) arr [ i ] = 0 ;
for ( let i = count ; i < n ; i ++ ) arr [ i ] = 1 ; }
function print ( arr , n ) { document . write ( " " ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 0 , 1 , 0 , 1 , 1 , 1 ] ; let n = arr . length ; segregate0and1 ( arr , n ) ; print ( arr , n ) ;
function segregate0and1 ( arr , size ) { let type0 = 0 ; let type1 = size - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type1 ] = arr [ type1 ] + arr [ type0 ] ; arr [ type0 ] = arr [ type1 ] - arr [ type0 ] ; arr [ type1 ] = arr [ type1 ] - arr [ type0 ] ; type1 -- ; } else type0 ++ ; } }
let arr = [ 0 , 1 , 0 , 1 , 1 , 1 ] ; let i , arr_size = arr . length ; segregate0and1 ( arr , arr_size ) ; document . write ( " " ) ; for ( i = 0 ; i < arr_size ; i ++ ) document . write ( arr [ i ] + " " ) ;
function GetCeilIndex ( arr , T , l , r , key ) { while ( r - l > 1 ) { let m = l + parseInt ( ( r - l ) / 2 , 10 ) ; if ( arr [ T [ m ] ] >= key ) r = m ; else l = m ; } return r ; } function LongestIncreasingSubsequence ( arr , n ) {
let tailIndices = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) tailIndices [ i ] = 0 ; let prevIndices = new Array ( n ) ;
for ( let i = 0 ; i < n ; i ++ ) prevIndices [ i ] = - 1 ;
let len = 1 ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ tailIndices [ 0 ] ] )
tailIndices [ 0 ] = i ; else if ( arr [ i ] > arr [ tailIndices [ len - 1 ] ] ) {
prevIndices [ i ] = tailIndices [ len - 1 ] ; tailIndices [ len ++ ] = i ; } else {
let pos = GetCeilIndex ( arr , tailIndices , - 1 , len - 1 , arr [ i ] ) ; prevIndices [ i ] = tailIndices [ pos - 1 ] ; tailIndices [ pos ] = i ; } } document . write ( " " + " " ) ; for ( let i = tailIndices [ len - 1 ] ; i >= 0 ; i = prevIndices [ i ] ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; return len ; }
let arr = [ 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 ] ; let n = arr . length ; document . write ( " " + LongestIncreasingSubsequence ( arr , n ) ) ;
function generateUtil ( A , B , C , i , j , m , n , len , flag ) {
if ( flag ) {
if ( len != 0 ) printArr ( C , len + 1 ) ;
for ( var k = i ; k < m ; k ++ ) { if ( len == 0 ) {
C [ len ] = A [ k ] ;
generateUtil ( A , B , C , k + 1 , j , m , n , len , ! flag ) ; }
else if ( A [ k ] > C [ len ] ) { C [ len + 1 ] = A [ k ] ; generateUtil ( A , B , C , k + 1 , j , m , n , len + 1 , ! flag ) ; } } }
else { for ( var l = j ; l < n ; l ++ ) { if ( B [ l ] > C [ len ] ) { C [ len + 1 ] = B [ l ] ; generateUtil ( A , B , C , i , l + 1 , m , n , len + 1 , ! flag ) ; } } } }
function generate ( A , B , m , n ) { var C = Array ( m + n ) . fill ( 0 ) ;
generateUtil ( A , B , C , 0 , 0 , m , n , 0 , true ) ; }
function printArr ( arr , n ) { for ( i = 0 ; i < n ; i ++ ) document . write ( arr [ i ] + " " ) ; document . write ( " " ) ; }
var A = [ 10 , 15 , 25 ] ; var B = [ 5 , 20 , 30 ] ; var n = A . length ; var m = B . length ; generate ( A , B , n , m ) ;
function replace_elements ( arr , n ) {
let pos = 0 ; for ( let i = 0 ; i < n ; i ++ ) { arr [ pos ++ ] = arr [ i ] ; while ( pos > 1 && arr [ pos - 2 ] == arr [ pos - 1 ] ) { pos -- ; arr [ pos - 1 ] ++ ; } }
for ( let i = 0 ; i < pos ; i ++ ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 6 , 4 , 3 , 4 , 3 , 3 , 5 ] ; let n = arr . length replace_elements ( arr , n ) ;
function arrangeString ( str , x , y ) { let count_0 = 0 ; let count_1 = 0 ; let len = str . length ;
for ( let i = 0 ; i < len ; i ++ ) { if ( str [ i ] == ' ' ) count_0 ++ ; else count_1 ++ ; }
while ( count_0 > 0 count_1 > 0 ) { for ( let j = 0 ; j < x && count_0 > 0 ; j ++ ) { if ( count_0 > 0 ) { document . write ( " " ) ; count_0 -- ; } } for ( let j = 0 ; j < y && count_1 > 0 ; j ++ ) { if ( count_1 > 0 ) { document . write ( " " ) ; count_1 -- ; } } } }
let str = " " ; let x = 1 ; let y = 2 ; arrangeString ( str , x , y ) ;
function rearrange ( arr , n ) {
if ( arr == null n % 2 == 1 ) return ;
let currIdx = Math . floor ( ( n - 1 ) / 2 ) ;
while ( currIdx > 0 ) { let count = currIdx , swapIdx = currIdx ; while ( count -- > 0 ) { let temp = arr [ swapIdx + 1 ] ; arr [ swapIdx + 1 ] = arr [ swapIdx ] ; arr [ swapIdx ] = temp ; swapIdx ++ ; } currIdx -- ; } }
let arr = [ 1 , 3 , 5 , 2 , 4 , 6 ] ; let n = arr . length ; rearrange ( arr , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( " " + arr [ i ] ) ;
function maxDiff ( arr , n ) {
let maxDiff = - 1 ;
let maxRight = arr [ n - 1 ] ; for ( let i = n - 2 ; i >= 0 ; i -- ) { if ( arr [ i ] > maxRight ) maxRight = arr [ i ] ; else { let diff = maxRight - arr [ i ] ; if ( diff > maxDiff ) { maxDiff = diff ; } } } return maxDiff ; }
let arr = [ 1 , 2 , 90 , 10 , 110 ] ; let n = arr . length ;
document . write ( " " + maxDiff ( arr , n ) ) ;
function maxDiff ( arr , n ) {
let diff = arr [ 1 ] - arr [ 0 ] ; let curr_sum = diff ; let max_sum = curr_sum ; for ( let i = 1 ; i < n - 1 ; i ++ ) {
diff = arr [ i + 1 ] - arr [ i ] ;
if ( curr_sum > 0 ) curr_sum += diff ; else curr_sum = diff ;
if ( curr_sum > max_sum ) max_sum = curr_sum ; } return max_sum ; }
let arr = [ 80 , 2 , 6 , 3 , 100 ] ; let n = arr . length ;
document . write ( " " + maxDiff ( arr , n ) ) ;
function maxRepeating ( arr , n , k ) {
for ( let i = 0 ; i < n ; i ++ ) arr [ arr [ i ] % k ] += k ;
let max = arr [ 0 ] , result = 0 ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; result = i ; } }
return result ; }
let arr = [ 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 ] ; let n = arr . length ; let k = 8 ; document . write ( " " + maxRepeating ( arr , n , k ) + " " ) ;
function maxPathSum ( ar1 , ar2 , m , n ) {
let i = 0 , j = 0 ;
let result = 0 , sum1 = 0 , sum2 = 0 ;
while ( i < m && j < n ) {
if ( ar1 [ i ] < ar2 [ j ] ) sum1 += ar1 [ i ++ ] ;
else if ( ar1 [ i ] > ar2 [ j ] ) sum2 += ar2 [ j ++ ] ;
else {
result += Math . max ( sum1 , sum2 ) + ar1 [ i ] ;
sum1 = 0 ; sum2 = 0 ;
i ++ ; j ++ ; } }
while ( i < m ) sum1 += ar1 [ i ++ ] ;
while ( j < n ) sum2 += ar2 [ j ++ ] ;
result += Math . max ( sum1 , sum2 ) ; return result ; }
let ar1 = [ 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 ] ; let ar2 = [ 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 ] ; let m = ar1 . length ; let n = ar2 . length ;
document . write ( " " + maxPathSum ( ar1 , ar2 , m , n ) ) ;
function smallestGreater ( arr , n ) { for ( let i = 0 ; i < n ; i ++ ) {
let diff = Number . MAX_VALUE ; let closest = - 1 ; for ( let j = 0 ; j < n ; j ++ ) { if ( arr [ i ] < arr [ j ] && arr [ j ] - arr [ i ] < diff ) { diff = arr [ j ] - arr [ i ] ; closest = j ; } }
if ( closest == - 1 ) document . write ( " " ) ; else document . write ( arr [ closest ] + " " ) ; } }
let ar = [ 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 ] ; let n = ar . length ; smallestGreater ( ar , n ) ;
function findZeroes ( arr , n , m ) {
let wL = 0 ; let wR = 0 ;
let bestL = 0 ; let bestWindow = 0 ;
let zeroCount = 0 ;
while ( wR < n ) {
if ( zeroCount <= m ) { if ( arr [ wR ] == 0 ) zeroCount ++ ; wR ++ ; }
if ( zeroCount > m ) { if ( arr [ wL ] == 0 ) zeroCount -- ; wL ++ ; }
if ( ( wR - wL > bestWindow ) && ( zeroCount <= m ) ) { bestWindow = wR - wL ; bestL = wL ; } }
for ( let i = 0 ; i < bestWindow ; i ++ ) { if ( arr [ bestL + i ] == 0 ) document . write ( bestL + i + " " ) ; } }
let arr = new Array ( 1 , 0 , 0 , 1 , 1 , 0 , 1 , 0 , 1 , 1 ) ; let m = 2 ; let n = arr . length ; document . write ( " " ) ; findZeroes ( arr , n , m ) ;
function countIncreasing ( arr , n ) {
let cnt = 0 ;
for ( let i = 0 ; i < n ; i ++ ) {
for ( let j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] > arr [ j - 1 ] ) cnt ++ ;
else break ; } } return cnt ; }
let arr = [ 1 , 2 , 2 , 4 ] ; let n = arr . length ; document . write ( " " + " " + countIncreasing ( arr , n ) ) ;
let arr = [ 1 , 2 , 2 , 4 ] ; function countIncreasing ( n ) {
let cnt = 0 ;
let len = 1 ;
for ( let i = 0 ; i < n - 1 ; ++ i ) {
if ( arr [ i + 1 ] > arr [ i ] ) len ++ ;
else { cnt += ( ( ( len - 1 ) * len ) / 2 ) ; len = 1 ; } }
if ( len > 1 ) cnt += ( ( ( len - 1 ) * len ) / 2 ) ; return cnt ; }
document . write ( " " + " " + countIncreasing ( arr . length ) ) ;
function arraySum ( arr , n ) { var sum = 0 ; for ( var i = 0 ; i < n ; i ++ ) sum = sum + arr [ i ] ; return sum ; }
function maxDiff ( arr , n , k ) {
arr . sort ( ( a , b ) => a - b ) ;
var arraysum = arraySum ( arr , n ) ;
var diff1 = Math . abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
arr . reverse ( ) ;
var diff2 = Math . abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
return ( Math . max ( diff1 , diff2 ) ) ; }
var arr = [ 1 , 7 , 4 , 8 , - 1 , 5 , 2 , 1 ] ; var n = arr . length ; var k = 3 ; document . write ( " " + maxDiff ( arr , n , k ) ) ;
function minNumber ( a , n , x ) {
a . sort ( ) ; let k ; for ( k = 0 ; a [ parseInt ( ( n - 1 ) / 2 , 10 ) ] != x ; k ++ ) { a [ n ++ ] = x ; a . sort ( ) ; } return k ; }
let x = 10 ; let a = [ 10 , 20 , 30 ] ; let n = 3 ; document . write ( minNumber ( a , n , x ) ) ;
function minNumber ( a , n , x ) { let l = 0 , h = 0 , e = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == x ) e ++ ;
else if ( a [ i ] > x ) h ++ ;
else if ( a [ i ] < x ) l ++ ; } let ans = 0 ; if ( l > h ) ans = l - h ; else if ( l < h ) ans = h - l - 1 ;
return ans + 1 - e ; }
let x = 10 ; let a = [ 10 , 20 , 30 ] ; let n = a . length ; document . write ( minNumber ( a , n , x ) ) ;
function fun ( x ) { let y = parseInt ( x / 4 ) * 4 ;
let ans = 0 ; for ( let i = y ; i <= x ; i ++ ) ans ^= i ; return ans ; }
function query ( x ) {
if ( x == 0 ) return 0 ; let k = parseInt ( ( x + 1 ) / 2 ) ;
return ( x %= 2 ) ? 2 * fun ( k ) : ( ( fun ( k - 1 ) * 2 ) ^ ( k & 1 ) ) ; } function allQueries ( q , l , r ) { for ( let i = 0 ; i < q ; i ++ ) document . write ( ( query ( r [ i ] ) ^ query ( l [ i ] - 1 ) ) + " " ) ; }
let q = 3 ; let l = [ 2 , 2 , 5 ] ; let r = [ 4 , 8 , 9 ] ; allQueries ( q , l , r ) ;
function checkEVENodd ( arr , n , l , r ) {
if ( arr [ r ] == 1 ) document . write ( " " ) ;
else document . write ( " " ) ; }
let arr = [ 1 , 1 , 0 , 1 ] ; let n = arr . length ; checkEVENodd ( arr , n , 1 , 3 ) ;
function findMean ( arr , l , r ) {
let sum = 0 , count = 0 ;
for ( let i = l ; i <= r ; i ++ ) { sum += arr [ i ] ; count ++ ; }
let mean = Math . floor ( sum / count ) ;
return mean ; }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ; document . write ( findMean ( arr , 0 , 2 ) + " " ) ; document . write ( findMean ( arr , 1 , 3 ) + " " ) ; document . write ( findMean ( arr , 0 , 4 ) + " " ) ;
function calculateProduct ( A , L , R , P ) {
L = L - 1 ; R = R - 1 ; let ans = 1 ; for ( let i = L ; i <= R ; i ++ ) { ans = ans * A [ i ] ; ans = ans % P ; } return ans ; }
let A = [ 1 , 2 , 3 , 4 , 5 , 6 ] ; let P = 229 ; let L = 2 , R = 5 ; document . write ( calculateProduct ( A , L , R , P ) + " " ) ; L = 1 ; R = 3 ; document . write ( calculateProduct ( A , L , R , P ) + " " ) ;
let MAX = 10000 ;
let prefix = [ ] ; function buildPrefix ( ) {
let prime = [ ] ; for ( let p = 1 ; p <= MAX + 1 ; p ++ ) { prime [ p ] = true ; } for ( let p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == true ) {
for ( let i = p * 2 ; i <= MAX ; i += p ) prime [ i ] = false ; } }
prefix [ 0 ] = prefix [ 1 ] = 0 ; for ( let p = 2 ; p <= MAX ; p ++ ) { prefix [ p ] = prefix [ p - 1 ] ; if ( prime [ p ] ) prefix [ p ] ++ ; } }
function query ( L , R ) { return prefix [ R ] - prefix [ L - 1 ] ; }
buildPrefix ( ) ; let L = 5 , R = 10 ; document . write ( query ( L , R ) + " " ) ; L = 1 ; R = 10 ; document . write ( query ( L , R ) ) ;
function command ( arr , a , b ) { arr [ a ] ^= 1 ; arr [ b + 1 ] ^= 1 ; }
function process ( arr , n ) { for ( var k = 1 ; k <= n ; k ++ ) arr [ k ] ^= arr [ k - 1 ] ; }
function result ( arr , n ) { for ( var k = 1 ; k <= n ; k ++ ) document . write ( arr [ k ] + " " ) ; }
var n = 5 , m = 3 ; var arr = Array ( n + 2 ) . fill ( 0 ) ;
command ( arr , 1 , 5 ) ; command ( arr , 2 , 5 ) ; command ( arr , 3 , 5 ) ;
process ( arr , n ) ;
result ( arr , n ) ;
function probability ( a , b , size1 , size2 ) {
let max1 = Number . MIN_VALUE , count1 = 0 ; for ( let i = 0 ; i < size1 ; i ++ ) { if ( a [ i ] > max1 ) { max1 = a [ i ] ; count1 = 1 ; } else if ( a [ i ] == max1 ) { count1 ++ ; } }
let max2 = Number . MIN_VALUE , count2 = 0 ; for ( let i = 0 ; i < size2 ; i ++ ) { if ( b [ i ] > max2 ) { max2 = b [ i ] ; count2 = 1 ; } else if ( b [ i ] == max2 ) { count2 ++ ; } }
return ( count1 * count2 ) / ( size1 * size2 ) ; }
let a = [ 1 , 2 , 3 ] ; let b = [ 1 , 3 , 3 ] ; let size1 = a . length ; let size2 = b . length ; document . write ( probability ( a , b , size1 , size2 ) ) ;
function countDe ( arr , n ) { let v = [ ] ;
for ( let i = 0 ; i < n ; i ++ ) v [ i ] = arr [ i ] ;
arr . sort ( ) ;
let count1 = 0 ; for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count1 ++ ;
arr . reverse ( ) ;
let count2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count2 ++ ;
return ( Math . min ( count1 , count2 ) ) ; }
let arr = [ 5 , 9 , 21 , 17 , 13 ] ; let n = 5 ; document . write ( " " + countDe ( arr , n ) ) ;
function maxOfSegmentMins ( a , n , k ) {
if ( k == 1 ) { a . sort ( ) ; return a [ 0 ] ; } if ( k == 2 ) return Math . max ( a [ 0 ] , a [ n - 1 ] ) ;
return a [ n - 1 ] ; }
var a = [ - 10 , - 9 , - 8 , 2 , 7 , - 6 , - 5 ] ; var n = a . length ; var k = 2 ; document . write ( maxOfSegmentMins ( a , n , k ) ) ;
function printMinimumProduct ( arr , n ) {
let first_min = Math . min ( arr [ 0 ] , arr [ 1 ] ) ; let second_min = Math . max ( arr [ 0 ] , arr [ 1 ] ) ;
for ( let i = 2 ; i < n ; i ++ ) { if ( arr [ i ] < first_min ) { second_min = first_min ; first_min = arr [ i ] ; } else if ( arr [ i ] < second_min ) second_min = arr [ i ] ; } return first_min * second_min ; }
let a = [ 11 , 8 , 5 , 7 , 5 , 100 ] ; let n = a . length ; document . write ( printMinimumProduct ( a , n ) ) ;
function noOfTriples ( arr , n ) {
arr . sort ( ) ;
let count = 0 ; for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] == arr [ 2 ] ) count ++ ;
if ( arr [ 0 ] == arr [ 2 ] ) return ( count - 2 ) * ( count - 1 ) * ( count ) / 6 ;
else if ( arr [ 1 ] == arr [ 2 ] ) return ( count - 1 ) * ( count ) / 2 ;
return count ; }
let arr = [ 1 , 3 , 3 , 4 ] ; let n = arr . length ; document . write ( noOfTriples ( arr , n ) ) ;
function checkReverse ( arr , n ) {
let temp = [ ] ; for ( let i = 0 ; i < n ; i ++ ) { temp [ i ] = arr [ i ] ; }
temp . sort ( ) ;
let front ; for ( front = 0 ; front < n ; front ++ ) { if ( temp [ front ] != arr [ front ] ) { break ; } }
let back ; for ( back = n - 1 ; back >= 0 ; back -- ) { if ( temp [ back ] != arr [ back ] ) { break ; } }
if ( front >= back ) { return true ; }
do { front ++ ; if ( arr [ front - 1 ] < arr [ front ] ) { return false ; } } while ( front != back ) ; return true ; }
let arr = [ 1 , 2 , 5 , 4 , 3 ] ; let n = arr . length ; if ( checkReverse ( arr , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function checkReverse ( arr , n ) { if ( n == 1 ) return true ;
let i ; for ( i = 1 ; i < n && arr [ i - 1 ] < arr [ i ] ; i ++ ) ; if ( i == n ) return true ;
let j = i ; while ( j < n && arr [ j ] < arr [ j - 1 ] ) { if ( i > 1 && arr [ j ] < arr [ i - 2 ] ) return false ; j ++ ; } if ( j == n ) return true ;
let k = j ;
if ( arr [ k ] < arr [ i - 1 ] ) return false ; while ( k > 1 && k < n ) { if ( arr [ k ] < arr [ k - 1 ] ) return false ; k ++ ; } return true ; }
let arr = [ 1 , 3 , 4 , 10 , 9 , 8 ] ; let n = arr . length ; if ( checkReverse ( arr , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function MinOperation ( a , b , n ) {
a . sort ( function ( a , b ) { return a - b } ) ; b . sort ( function ( a , b ) { return a - b } ) ;
let result = 0 ;
for ( let i = 0 ; i < n ; ++ i ) { if ( a [ i ] > b [ i ] ) result = result + Math . abs ( a [ i ] - b [ i ] ) ; else if ( a [ i ] < b [ i ] ) result = result + Math . abs ( a [ i ] - b [ i ] ) ; } return result ; }
let a = [ 3 , 1 , 1 ] ; let b = [ 1 , 2 , 2 ] ; let n = a . length ; document . write ( MinOperation ( a , b , n ) ) ;
function sortExceptUandL ( a , l , u , n ) {
let b = [ ] ; for ( let i = 0 ; i < l ; i ++ ) b [ i ] = a [ i ] ; for ( let i = u + 1 ; i < n ; i ++ ) b [ l + ( i - ( u + 1 ) ) ] = a [ i ] ;
b . sort ( ) ;
for ( let i = 0 ; i < l ; i ++ ) a [ i ] = b [ i ] ; for ( let i = u + 1 ; i < n ; i ++ ) a [ i ] = b [ l + ( i - ( u + 1 ) ) ] ; }
let a = [ 5 , 4 , 3 , 12 , 14 , 9 ] ; let n = a . length ; let l = 2 , u = 4 ; sortExceptUandL ( a , l , u , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( a [ i ] + " " ) ;
function sortExceptK ( arr , k , n ) {
let temp = arr [ k ] ; arr [ k ] = arr [ n - 1 ] ; arr [ n - 1 ] = temp ;
arr . sort ( function ( a , b ) { return a - b } ) ;
let last = arr [ n - 1 ] ;
for ( let i = n - 1 ; i > k ; i -- ) arr [ i ] = arr [ i - 1 ] ;
arr [ k ] = last ;
temp = arr [ k ] ; arr [ k ] = arr [ n - 1 ] ; arr [ n - 1 ] = temp ; return 0 ; } let a = [ 10 , 4 , 11 , 7 , 6 , 20 ] ; let k = 2 ; let n = a . length ; sortExceptK ( a , k , n ) ; for ( let i = 0 ; i < n ; i ++ ) document . write ( a [ i ] + " " ) ;
function findMinSwaps ( arr , n ) {
let noOfZeroes = [ ] ; let i , count = 0 ;
noOfZeroes [ n - 1 ] = 1 - arr [ n - 1 ] ; for ( i = n - 2 ; i >= 0 ; i -- ) { noOfZeroes [ i ] = noOfZeroes [ i + 1 ] ; if ( arr [ i ] == 0 ) noOfZeroes [ i ] ++ ; }
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 1 ) count += noOfZeroes [ i ] ; } return count ; }
let ar = [ 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 ] ; document . write ( findMinSwaps ( ar , ar . length ) ) ;
function maxPartitions ( arr , n ) { let ans = 0 , max_so_far = 0 ; for ( let i = 0 ; i < n ; ++ i ) {
max_so_far = Math . max ( max_so_far , arr [ i ] ) ;
if ( max_so_far == i ) ans ++ ; } return ans ; }
let arr = [ 1 , 0 , 2 , 3 , 4 ] ; let n = arr . length ; document . write ( maxPartitions ( arr , n ) ) ;
function cuttringRopes ( Ropes , n ) {
Ropes . sort ( ) ; let singleOperation = 0 ;
let cuttingLenght = Ropes [ 0 ] ;
for ( let i = 1 ; i < n ; i ++ ) {
if ( Ropes [ i ] - cuttingLenght > 0 ) { document . write ( n - i + " " ) ;
cuttingLenght = Ropes [ i ] ; singleOperation ++ ; } }
if ( singleOperation == 0 ) document . write ( " " ) ; }
let Ropes = [ 5 , 1 , 1 , 2 , 3 , 5 ] ; let n = Ropes . length ; cuttringRopes ( Ropes , n ) ;
function rankify ( A , n ) {
var R = [ ... Array ( n ) ] ;
for ( var i = 0 ; i < n ; i ++ ) { var r = 1 , s = 1 ; for ( var j = 0 ; j < n ; j ++ ) { if ( j != i && A [ j ] < A [ i ] ) r += 1 ; if ( j != i && A [ j ] == A [ i ] ) s += 1 ; }
R [ i ] = parseFloat ( r + parseFloat ( s - 1 ) / parseFloat ( 2 ) ) ; } for ( var i = 0 ; i < n ; i ++ ) document . write ( parseFloat ( R [ i ] ) . toFixed ( 1 ) + " " ) ; }
var A = [ 1 , 2 , 5 , 2 , 1 , 25 , 2 ] ; var n = A . length ; for ( var i = 0 ; i < n ; i ++ ) document . write ( A [ i ] + " " ) ; document . write ( " " ) ; rankify ( A , n ) ;
function min_noOf_operation ( arr , n , k ) { let noOfSubtraction ; let res = 0 ; for ( let i = 1 ; i < n ; i ++ ) { noOfSubtraction = 0 ; if ( arr [ i ] > arr [ i - 1 ] ) {
noOfSubtraction = ( arr [ i ] - arr [ i - 1 ] ) / k ;
if ( ( arr [ i ] - arr [ i - 1 ] ) % k != 0 ) noOfSubtraction ++ ;
arr [ i ] = arr [ i ] - k * noOfSubtraction ; }
res = res + noOfSubtraction ; } return res ; }
let arr = [ 1 , 1 , 2 , 3 ] ; let N = 4 ; let k = 5 ; document . write ( Math . floor ( min_noOf_operation ( arr , N , k ) ) ) ;
function maxSum ( arr , n ) {
arr . sort ( ) ;
let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) sum += ( arr [ i ] * i ) ; return sum ; }
let arr = [ 3 , 5 , 6 , 1 ] ; let n = arr . length ; document . write ( maxSum ( arr , n ) ) ;
function countPairs ( a , n , k ) { var res = 0 ; for ( var i = 0 ; i < n ; i ++ ) for ( var j = i + 1 ; j < n ; j ++ ) if ( Math . abs ( a [ j ] - a [ i ] ) < k ) res ++ ; return res ; }
var a = [ 1 , 10 , 4 , 2 ] ; var k = 3 ; var n = a . length ; document . write ( countPairs ( a , n , k ) ) ;
function countPairs ( a , n , k ) {
a . sort ( ( a , b ) => a - b ) ; let res = 0 ; for ( let i = 0 ; i < n ; i ++ ) {
let j = i + 1 ; while ( j < n && a [ j ] - a [ i ] < k ) { res ++ ; j ++ ; } } return res ; }
let a = [ 1 , 10 , 4 , 2 ] ; let k = 3 ; let n = a . length ; document . write ( countPairs ( a , n , k ) + " " ) ;
function sumOfMinAbsDifferences ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ;
let sum = 0 ;
sum += Math . abs ( arr [ 0 ] - arr [ 1 ] ) ;
sum += Math . abs ( arr [ n - 1 ] - arr [ n - 2 ] ) ;
for ( let i = 1 ; i < n - 1 ; i ++ ) sum += Math . min ( Math . abs ( arr [ i ] - arr [ i - 1 ] ) , Math . abs ( arr [ i ] - arr [ i + 1 ] ) ) ;
return sum ; }
let arr = [ 5 , 10 , 1 , 4 , 8 , 7 ] ; let n = arr . length ; document . write ( " " + sumOfMinAbsDifferences ( arr , n ) ) ;
function findSmallestDifference ( A , B , m , n ) {
A . sort ( ( a , b ) => a - b ) ; B . sort ( ( a , b ) => a - b ) ; let a = 0 , b = 0 ;
let result = Number . MAX_SAFE_INTEGER ;
while ( a < m && b < n ) { if ( Math . abs ( A [ a ] - B [ b ] ) < result ) result = Math . abs ( A [ a ] - B [ b ] ) ;
if ( A [ a ] < B [ b ] ) a ++ ; else b ++ ; }
return result ; }
let A = [ 1 , 2 , 11 , 5 ] ;
let B = [ 4 , 12 , 19 , 23 , 127 , 235 ] ;
let m = A . length ; let n = B . length ;
document . write ( findSmallestDifference ( A , B , m , n ) ) ;
function findLarger ( arr , n ) {
arr . sort ( ) ;
for ( let i = n - 1 ; i >= n / 2 ; i -- ) document . write ( arr [ i ] + " " ) ; }
let arr = [ 1 , 3 , 6 , 1 , 0 , 9 ] ; let n = arr . length ; findLarger ( arr , n ) ;
function findSingle ( ar , ar_size ) {
let res = ar [ 0 ] ; for ( let i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
let ar = [ 2 , 3 , 5 , 4 , 5 , 3 , 4 ] ; let n = ar . length ; document . write ( " " + findSingle ( ar , n ) ) ;
function countOccurrences ( arr , n , x ) { let res = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( x == arr [ i ] ) res ++ ; } return res ; }
arr = [ 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 ] let n = arr . length ; let x = 2 ; document . write ( countOccurrences ( arr , n , x ) ) ;
function binarySearch ( arr , l , r , x ) { if ( r < l ) return - 1 ; var mid = l + parseInt ( ( r - l ) / 2 ) ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
function countOccurrences ( arr , n , x ) { var ind = binarySearch ( arr , 0 , n - 1 , x ) ;
if ( ind == - 1 ) return 0 ;
var count = 1 ; var left = ind - 1 ; while ( left >= 0 && arr [ left ] == x ) count ++ , left -- ;
var right = ind + 1 ; while ( right < n && arr [ right ] == x ) count ++ , right ++ ; return count ; }
var arr = [ 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 ] ; var n = arr . length ; var x = 2 ; document . write ( countOccurrences ( arr , n , x ) ) ;
function printClosest ( arr , n , x ) {
let res_l = 0 , res_r = 0 ;
let l = 0 , r = n - 1 , diff = Number . MAX_VALUE ;
while ( r > l ) {
if ( Math . abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } document . write ( " " + arr [ res_l ] + " " + arr [ res_r ] ) ; }
let arr = [ 10 , 22 , 28 , 29 , 30 , 40 ] , x = 54 ; let n = arr . length ; printClosest ( arr , n , x ) ;
function countOnes ( arr , low , high ) { if ( high >= low ) {
let mid = Math . trunc ( low + ( high - low ) / 2 ) ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
let arr = [ 1 , 1 , 1 , 1 , 0 , 0 , 0 ] ; let n = arr . length ; document . write ( " " + countOnes ( arr , 0 , n - 1 ) ) ;
function findMissingUtil ( arr1 , arr2 , N ) {
if ( N == 1 ) return arr1 [ 0 ] ;
if ( arr1 [ 0 ] != arr2 [ 0 ] ) return arr1 [ 0 ] ;
let lo = 0 , hi = N - 1 ;
while ( lo < hi ) { let mid = parseInt ( ( lo + hi ) / 2 , 10 ) ;
if ( arr1 [ mid ] == arr2 [ mid ] ) lo = mid ; else hi = mid ;
if ( lo == hi - 1 ) break ; }
return arr1 [ hi ] ; }
function findMissing ( arr1 , arr2 , M , N ) { if ( N == M - 1 ) document . write ( " " + findMissingUtil ( arr1 , arr2 , M ) + " " ) ; else if ( M == N - 1 ) document . write ( " " + findMissingUtil ( arr2 , arr1 , N ) + " " ) ; else document . write ( " " + " " ) ; }
let arr1 = [ 1 , 4 , 5 , 7 , 9 ] ; let arr2 = [ 4 , 5 , 7 , 9 ] ; let M = arr1 . length ; let N = arr2 . length ; findMissing ( arr1 , arr2 , M , N ) ;
function findMissing ( arr1 , arr2 , M , N ) { if ( M != N - 1 && N != M - 1 ) { document . write ( " " ) ; return ; }
let res = 0 ; for ( let i = 0 ; i < M ; i ++ ) res = res ^ arr1 [ i ] ; for ( let i = 0 ; i < N ; i ++ ) res = res ^ arr2 [ i ] ; document . write ( " " + res ) ; }
let arr1 = [ 4 , 1 , 5 , 9 , 7 ] ; let arr2 = [ 7 , 5 , 9 , 4 ] ; let M = arr1 . length ; let N = arr2 . length ; findMissing ( arr1 , arr2 , M , N ) ;
function search ( arr , n , x ) {
let i = 0 ; while ( i < n ) {
if ( arr [ i ] == x ) return i ;
i = i + Math . abs ( arr [ i ] - x ) ; } document . write ( " " ) ; return - 1 ; }
let arr = [ 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 ] ; let n = arr . length ; let x = 3 ; document . write ( " " + x + " " + search ( arr , n , 3 ) ) ;
function thirdLargest ( arr , arr_size ) {
if ( arr_size < 3 ) { document . write ( " " ) ; return ; }
let first = arr [ 0 ] ; for ( let i = 1 ; i < arr_size ; i ++ ) if ( arr [ i ] > first ) first = arr [ i ] ;
let second = Number . MIN_VALUE ; for ( let i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > second && arr [ i ] < first ) second = arr [ i ] ;
let third = Number . MIN_VALUE ; for ( let i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > third && arr [ i ] < second ) third = arr [ i ] ; document . write ( " " + " " , third ) ; }
let arr = [ 12 , 13 , 1 , 10 , 34 , 16 ] ; let n = arr . length ; thirdLargest ( arr , n ) ;
function thirdLargest ( arr , arr_size ) {
if ( arr_size < 3 ) { document . write ( " " ) ; return ; }
var first = arr [ 0 ] , second = - 1000000000 , third = - 1000000000 ;
for ( var i = 1 ; i < arr_size ; i ++ ) {
if ( arr [ i ] > first ) { third = second ; second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) { third = second ; second = arr [ i ] ; }
else if ( arr [ i ] > third ) third = arr [ i ] ; } document . write ( " " + third ) ; }
var arr = [ 12 , 13 , 1 , 10 , 34 , 16 ] ; var n = arr . length ; thirdLargest ( arr , n ) ;
function checkPair ( arr , n ) {
let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) { sum += arr [ i ] ; }
if ( sum % 2 != 0 ) { return false ; } sum = Math . floor ( sum / 2 ) ;
let s = new Set ( ) ; for ( let i = 0 ; i < n ; i ++ ) { let val = sum - arr [ i ] ;
if ( ! s . has ( arr [ i ] ) ) { s . add ( arr [ i ] ) } if ( s . has ( val ) ) { document . write ( " " + arr [ i ] + " " + val + " " ) ; return true ; } s . add ( arr [ i ] ) ; } return false ; }
let arr = [ 2 , 11 , 5 , 1 , 4 , 7 ] ; let n = arr . length ; if ( checkPair ( arr , n ) == false ) { document . write ( " " ) ; }
function search ( arr , n , x ) {
if ( arr [ n - 1 ] == x ) return " " ; let backup = arr [ n - 1 ] ; arr [ n - 1 ] = x ;
for ( let i = 0 ; ; i ++ ) {
if ( arr [ i ] == x ) {
arr [ n - 1 ] = backup ;
if ( i < n - 1 ) return " " ;
return " " ; } } }
let arr = [ 4 , 6 , 1 , 5 , 8 ] ; let n = arr . length ; let x = 1 ; document . write ( search ( arr , n , x ) ) ;
function findMajority ( arr , n ) { return arr [ Math . floor ( n / 2 ) ] ; }
let arr = [ 1 , 2 , 2 , 3 ] ; let n = arr . length ; document . write ( findMajority ( arr , n ) ) ;
function minAdjDifference ( arr , n ) { if ( n < 2 ) return ;
let res = Math . abs ( arr [ 1 ] - arr [ 0 ] ) ; for ( let i = 2 ; i < n ; i ++ ) res = Math . min ( res , Math . abs ( arr [ i ] - arr [ i - 1 ] ) ) ;
res = Math . min ( res , Math . abs ( arr [ n - 1 ] - arr [ 0 ] ) ) ; document . write ( " " + res ) ; }
let a = [ 10 , 12 , 13 , 15 , 10 ] ; let n = a . length ; minAdjDifference ( a , n ) ;
let MAX = 100000 function Print3Smallest ( array , n ) { let firstmin = MAX , secmin = MAX , thirdmin = MAX ; for ( let i = 0 ; i < n ; i ++ ) {
if ( array [ i ] < firstmin ) { thirdmin = secmin ; secmin = firstmin ; firstmin = array [ i ] ; }
else if ( array [ i ] < secmin ) { thirdmin = secmin ; secmin = array [ i ] ; }
else if ( array [ i ] < thirdmin ) thirdmin = array [ i ] ; } document . write ( " " + firstmin + " " ) ; document . write ( " " + secmin + " " ) ; document . write ( " " + thirdmin + " " ) ; }
let array = [ 4 , 9 , 1 , 32 , 12 ] ; let n = array . length ; Print3Smallest ( array , n ) ;
function getMin ( arr , n ) { return Math . min . apply ( Math , arr ) ; } function getMax ( arr , n ) { return Math . max . apply ( Math , arr ) ; }
var arr = [ 12 , 1234 , 45 , 67 , 1 ] ; var n = arr . length ; document . write ( " " + getMin ( arr , n ) + " " ) ; document . write ( " " + getMax ( arr , n ) ) ;
function printfrequency ( arr , n ) {
for ( let j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] - 1 ;
for ( let i = 0 ; i < n ; i ++ ) arr [ arr [ i ] % n ] = arr [ arr [ i ] % n ] + n ;
for ( let i = 0 ; i < n ; i ++ ) document . write ( ( i + 1 ) + " " + parseInt ( arr [ i ] / n , 10 ) + " " ) ; }
let arr = [ 2 , 3 , 3 , 2 , 5 ] ; let n = arr . length ; printfrequency ( arr , n ) ;
function getInvCount ( arr , n ) {
let invcount = 0 ; for ( let i = 0 ; i < n - 1 ; i ++ ) {
let small = 0 ; for ( let j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) small ++ ;
let great = 0 ; for ( let j = i - 1 ; j >= 0 ; j -- ) if ( arr [ i ] < arr [ j ] ) great ++ ;
invcount += great * small ; } return invcount ; }
let arr = [ 8 , 4 , 2 , 1 ] ; let n = arr . length ; document . write ( " " + getInvCount ( arr , n ) ) ;
function findWater ( n ) {
let water = 0 ;
left [ 0 ] = arr [ 0 ] ; for ( let i = 1 ; i < n ; i ++ ) left [ i ] = Math . max ( left [ i - 1 ] , arr [ i ] ) ;
right [ n - 1 ] = arr [ n - 1 ] ; for ( let i = n - 2 ; i >= 0 ; i -- ) right [ i ] = Math . max ( right [ i + 1 ] , arr [ i ] ) ;
for ( let i = 0 ; i < n ; i ++ ) water += Math . min ( left [ i ] , right [ i ] ) - arr [ i ] ; return water ; }
document . write ( " " + findWater ( arr . length ) ) ;
function findWater ( arr , n ) {
let result = 0 ;
let left_max = 0 , right_max = 0 ;
let lo = 0 , hi = n - 1 ; while ( lo <= hi ) { if ( arr [ lo ] < arr [ hi ] ) { if ( arr [ lo ] > left_max )
left_max = arr [ lo ] ; else
result += left_max - arr [ lo ] ; lo ++ ; } else { if ( arr [ hi ] > right_max )
right_max = arr [ hi ] ; else result += right_max - arr [ hi ] ; hi -- ; } } return result ; }
let arr = [ 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 ] ; let n = arr . length ; document . write ( " " + " " + findWater ( arr , n ) ) ;
function missingK ( a , k , n ) { let difference = 0 , ans = 0 , count = k ; let flag = false ;
for ( let i = 0 ; i < n - 1 ; i ++ ) { difference = 0 ;
if ( ( a [ i ] + 1 ) != a [ i + 1 ] ) {
difference += ( a [ i + 1 ] - a [ i ] ) - 1 ;
if ( difference >= count ) { ans = a [ i ] + count ; flag = true ; break ; } else count -= difference ; } }
if ( flag ) return ans ; else return - 1 ; }
let a = [ 1 , 5 , 11 , 19 ] ;
let k = 11 ; let n = a . length ;
let missing = missingK ( a , k , n ) ; document . write ( missing ) ;
let a = [ 900 ] ; let b = [ 10 , 13 , 14 ] ;
function maximum ( a , b ) { return a > b ? a : b ; }
function minimum ( a , b ) { return a < b ? a : b ; }
function findMedianSortedArrays ( n , m ) { let min_index = 0 , max_index = n , i = 0 , j = 0 , median = 0 ; while ( min_index <= max_index ) { i = Math . floor ( ( min_index + max_index ) / 2 ) ; j = Math . floor ( ( n + m + 1 ) / 2 ) - i ;
if ( i < n && j > 0 && b [ j - 1 ] > a [ i ] ) min_index = i + 1 ;
else if ( i > 0 && j < m && b [ j ] < a [ i - 1 ] ) max_index = i - 1 ;
else {
if ( i == 0 ) median = b [ j - 1 ] ;
else if ( j == 0 ) median = a [ i - 1 ] ; else median = maximum ( a [ i - 1 ] , b [ j - 1 ] ) ; break ; } }
if ( ( n + m ) % 2 == 1 ) return median ;
if ( i == n ) return ( median + b [ j ] ) / 2.0 ;
if ( j == m ) return ( median + a [ i ] ) / 2.0 ; return ( median + minimum ( a [ i ] , b [ j ] ) ) / 2.0 ; }
let n = a . length ; let m = b . length ;
if ( n < m ) document . write ( " " + findMedianSortedArrays ( n , m ) ) ; else document . write ( " " + findMedianSortedArrays ( m , n ) ) ;
function prletUncommon ( arr1 , arr2 , n1 , n2 ) { let i = 0 , j = 0 , k = 0 ; while ( i < n1 && j < n2 ) {
if ( arr1 [ i ] < arr2 [ j ] ) { document . write ( arr1 [ i ] + " " ) ; i ++ ; k ++ ; } else if ( arr2 [ j ] < arr1 [ i ] ) { document . write ( arr2 [ j ] + " " ) ; k ++ ; j ++ ; }
else { i ++ ; j ++ ; } }
while ( i < n1 ) { document . write ( arr1 [ i ] + " " ) ; i ++ ; k ++ ; } while ( j < n2 ) { document . write ( arr2 [ j ] + " " ) ; j ++ ; k ++ ; } }
let arr1 = [ 10 , 20 , 30 ] ; let arr2 = [ 20 , 25 , 30 , 40 , 50 ] ; let n1 = arr1 . length ; let n2 = arr2 . length ; prletUncommon ( arr1 , arr2 , n1 , n2 ) ;
function leastFrequent ( arr , n ) {
arr . sort ( ) ;
let min_count = n + 1 , res = - 1 ; let curr_count = 1 ; for ( let i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
let arr = [ 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 ] ; let n = arr . length ; document . write ( leastFrequent ( arr , n ) ) ;
let M = 4 ;
function maximumSum ( a , n ) {
let prev = Math . max ( a [ n - 1 ] [ 0 ] , a [ n - 1 ] [ M - 1 ] + 1 ) ;
let sum = prev ; for ( let i = n - 2 ; i >= 0 ; i -- ) { let max_smaller = Number . MIN_VALUE ; for ( let j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i ] [ j ] < prev && a [ i ] [ j ] > max_smaller ) max_smaller = a [ i ] [ j ] ; }
if ( max_smaller == Number . MIN_VALUE ) return 0 ; prev = max_smaller ; sum += max_smaller ; } return sum ; }
let arr = [ [ 1 , 7 , 3 , 4 ] , [ 4 , 2 , 5 , 1 ] , [ 9 , 5 , 1 , 8 ] ] ; let n = arr . length ; document . write ( maximumSum ( arr , n ) ) ;
function countPairs ( A , n , k ) { var ans = 0 ;
A . sort ( ( a , b ) => a - b )
for ( var i = 0 ; i < n ; i ++ ) { for ( var j = i + 1 ; j < n ; j ++ ) {
var x = 0 ;
while ( ( A [ i ] * Math . pow ( k , x ) ) <= A [ j ] ) { if ( ( A [ i ] * Math . pow ( k , x ) ) == A [ j ] ) { ans ++ ; break ; } x ++ ; } } } return ans ; }
var A = [ 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 ] ; var n = A . length ; var k = 3 ; document . write ( countPairs ( A , n , k ) ) ;
function minDistance ( arr , n ) { let maximum_element = arr [ 0 ] ; let min_dis = n ; let index = 0 ; for ( let i = 1 ; i < n ; i ++ ) {
if ( maximum_element == arr [ i ] ) { min_dis = Math . min ( min_dis , ( i - index ) ) ; index = i ; }
else if ( maximum_element < arr [ i ] ) { maximum_element = arr [ i ] ; min_dis = n ; index = i ; }
else continue ; } return min_dis ; }
let arr = [ 6 , 3 , 1 , 3 , 6 , 4 , 6 ] ; let n = arr . length ; document . write ( " " + minDistance ( arr , n ) ) ;
function findValue ( arr , n , k ) {
for ( let i = 0 ; i < n ; i ++ ) if ( arr [ i ] == k ) k *= 2 ; return k ; }
let arr = [ 2 , 3 , 4 , 10 , 8 , 1 ] , k = 2 ; let n = arr . length ; document . write ( findValue ( arr , n , k ) ) ;
function dupLastIndex ( arr , n ) {
if ( arr == null n <= 0 ) return ;
for ( let i = n - 1 ; i > 0 ; i -- ) { if ( arr [ i ] == arr [ i - 1 ] ) { document . write ( " " + i + " " ) ; document . write ( " " + arr [ i ] + " " ) ; return ; } }
document . write ( " " ) ; }
let arr = [ 1 , 5 , 5 , 6 , 6 , 7 , 9 ] ; let n = arr . length ; dupLastIndex ( arr , n ) ;
function findSmallest ( a , n ) {
for ( let i = 0 ; i < n ; i ++ ) { let j ; for ( j = 0 ; j < n ; j ++ ) if ( a [ j ] % a [ i ] >= 1 ) break ;
if ( j == n ) return a [ i ] ; } return - 1 ; }
let a = [ 25 , 20 , 5 , 10 , 100 ] ; let n = a . length ; document . write ( findSmallest ( a , n ) ) ;
function findSmallest ( a , n ) {
let smallest = min_element ( a ) ;
for ( let i = 1 ; i < n ; i ++ ) if ( a [ i ] % smallest >= 1 ) return - 1 ; return smallest ; }
let a = [ 25 , 20 , 5 , 10 , 100 ] ; let n = a . length ; document . write ( findSmallest ( a , n ) ) ;
function findIndex ( arr , len ) {
let maxIndex = 0 ; for ( let i = 0 ; i < len ; ++ i ) if ( arr [ i ] > arr [ maxIndex ] ) maxIndex = i ;
for ( let i = 0 ; i < len ; ++ i ) if ( maxIndex != i && arr [ maxIndex ] < 2 * arr [ i ] ) return - 1 ; return maxIndex ; }
let arr = [ 3 , 6 , 1 , 0 ] ; let len = arr . length ; document . write ( findIndex ( arr , len ) ) ;
function find_consecutive_steps ( arr , len ) { let count = 0 ; let maximum = 0 ; for ( let index = 1 ; index < len ; index ++ ) {
if ( arr [ index ] > arr [ index - 1 ] ) count ++ ; else { maximum = Math . max ( maximum , count ) ; count = 0 ; } } return Math . max ( maximum , count ) ; }
let arr = [ 1 , 2 , 3 , 4 ] ; let len = arr . length ; document . write ( find_consecutive_steps ( arr , len ) ) ;
function CalculateMax ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b } ) ; let min_sum = arr [ 0 ] + arr [ 1 ] ; let max_sum = arr [ n - 1 ] + arr [ n - 2 ] ; return ( Math . abs ( max_sum - min_sum ) ) ; }
let arr = [ 6 , 7 , 1 , 11 ] ; let n = arr . length ; document . write ( CalculateMax ( arr , n ) ) ;
function calculate ( a , n ) {
a . sort ( ) ; let i , j ;
let s = [ ] ; for ( i = 0 , j = n - 1 ; i < j ; i ++ , j -- ) s . push ( ( a [ i ] + a [ j ] ) ) ; let mini = Math . min ( ... s ) ; let maxi = Math . max ( ... s ) ; return Math . abs ( maxi - mini ) ; }
let a = [ 2 , 6 , 4 , 3 ] ; let n = a . length ; document . write ( calculate ( a , n ) ) ;
function printMinDiffPairs ( arr , n ) { if ( n <= 1 ) return ;
arr . sort ( ) ;
let minDiff = arr [ 1 ] - arr [ 0 ] ; for ( let i = 2 ; i < n ; i ++ ) minDiff = Math . min ( minDiff , arr [ i ] - arr [ i - 1 ] ) ;
for ( let i = 1 ; i < n ; i ++ ) { if ( ( arr [ i ] - arr [ i - 1 ] ) == minDiff ) { document . write ( " " + arr [ i - 1 ] + " " + arr [ i ] + " " ) ; } } }
let arr = [ 5 , 3 , 2 , 4 , 1 ] ; let n = arr . length ; printMinDiffPairs ( arr , n ) ;
let MAX = 256 ; function calculateDiff ( i , j , array ) {
return Math . abs ( array [ i ] - array [ j ] ) + Math . abs ( i - j ) ; }
function maxDistance ( array ) {
let result = 0 ;
for ( let i = 0 ; i < array . length ; i ++ ) { for ( let j = i ; j < array . length ; j ++ ) {
result = Math . max ( result , calculateDiff ( i , j , array ) ) ; } } return result ; }
let array = [ - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 ] ; document . write ( maxDistance ( array ) ) ;
function maxDistance ( array ) {
let max1 = Number . MIN_VALUE ; let min1 = Number . MAX_VALUE ; let max2 = Number . MIN_VALUE ; let min2 = Number . MAX_VALUE ; for ( let i = 0 ; i < array . length ; i ++ ) {
max1 = Math . max ( max1 , array [ i ] + i ) ; min1 = Math . min ( min1 , array [ i ] + i ) ; max2 = Math . max ( max2 , array [ i ] - i ) ; min2 = Math . min ( min2 , array [ i ] - i ) ; }
return Math . max ( max1 - min1 , max2 - min2 ) ; }
let array = [ - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 ] ; document . write ( maxDistance ( array ) ) ;
function extrema ( a , n ) { let count = 0 ;
for ( let i = 1 ; i < n - 1 ; i ++ ) {
if ( a [ i ] > a [ i - 1 ] && a [ i ] > a [ i + 1 ] ) count += 1 ;
if ( a [ i ] < a [ i - 1 ] && a [ i ] < a [ i + 1 ] ) count += 1 ; } return count ; }
let a = [ 1 , 0 , 2 , 1 ] ; let n = a . length ; document . write ( extrema ( a , n ) ) ;
function findClosest ( arr , target ) { let n = arr . length ;
if ( target <= arr [ 0 ] ) return arr [ 0 ] ; if ( target >= arr [ n - 1 ] ) return arr [ n - 1 ] ;
let i = 0 , j = n , mid = 0 ; while ( i < j ) { mid = ( i + j ) / 2 ; if ( arr [ mid ] == target ) return arr [ mid ] ;
if ( target < arr [ mid ] ) {
if ( mid > 0 && target > arr [ mid - 1 ] ) return getClosest ( arr [ mid - 1 ] , arr [ mid ] , target ) ;
j = mid ; }
else { if ( mid < n - 1 && target < arr [ mid + 1 ] ) return getClosest ( arr [ mid ] , arr [ mid + 1 ] , target ) ;
i = mid + 1 ; } }
return arr [ mid ] ; }
function getClosest ( val1 , val2 , target ) { if ( target - val1 >= val2 - target ) return val2 ; else return val1 ; }
let arr = [ 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 ] ; let target = 11 ; document . write ( findClosest ( arr , target ) ) ;
function sum ( a , n ) {
let maxSum = Number . MIN_VALUE ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) maxSum = Math . max ( maxSum , a [ i ] + a [ j ] ) ;
let c = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) if ( a [ i ] + a [ j ] == maxSum ) c ++ ; return c ; }
let array = [ 1 , 1 , 1 , 2 , 2 , 2 ] ; let n = array . length ; document . write ( sum ( array , n ) ) ;
function sum ( a , n ) {
let maxVal = a [ 0 ] , maxCount = 1 ; let secondMax = Number . MIN_VALUE ; let secondMaxCount = 0 ; for ( let i = 1 ; i < n ; i ++ ) { if ( a [ i ] == maxVal ) maxCount ++ ; else if ( a [ i ] > maxVal ) { secondMax = maxVal ; secondMaxCount = maxCount ; maxVal = a [ i ] ; maxCount = 1 ; } else if ( a [ i ] == secondMax ) { secondMax = a [ i ] ; secondMaxCount ++ ; } else if ( a [ i ] > secondMax ) { secondMax = a [ i ] ; secondMaxCount = 1 ; } }
if ( maxCount > 1 ) return maxCount * parseInt ( ( maxCount - 1 ) / 2 , 10 ) ;
return secondMaxCount ; }
let array = [ 1 , 1 , 1 , 2 , 2 , 2 , 3 ] ; let n = array . length ; document . write ( sum ( array , n ) ) ;
function printKMissing ( arr , n , k ) { arr . sort ( ( a , b ) => a - b ) ;
let i = 0 ; while ( i < n && arr [ i ] <= 0 ) i ++ ;
let count = 0 , curr = 1 ; while ( count < k && i < n ) { if ( arr [ i ] != curr ) { document . write ( curr + " " ) ; count ++ ; } else i ++ ; curr ++ ; }
while ( count < k ) { document . write ( curr , " " ) ; curr ++ ; count ++ ; } }
let arr = new Array ( 2 , 3 , 4 ) ; let n = arr . length ; let k = 3 ; printKMissing ( arr , n , k ) ;
function nobleInteger ( arr ) { let size = arr . length ; for ( let i = 0 ; i < size ; i ++ ) { let count = 0 ; for ( let j = 0 ; j < size ; j ++ ) if ( arr [ i ] < arr [ j ] ) count ++ ;
if ( count == arr [ i ] ) return arr [ i ] ; } return - 1 ; }
let arr = [ 10 , 3 , 20 , 40 , 2 ] ; let res = nobleInteger ( arr ) ; if ( res != - 1 ) document . write ( " " + " " + res ) ; else document . write ( " " + " " ) ;
function nobleInteger ( arr ) { arr . sort ( function ( a , b ) { return a - b ; } ) ;
let n = arr . length ; for ( let i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] == arr [ i + 1 ] ) continue ;
if ( arr [ i ] == n - i - 1 ) return arr [ i ] ; } if ( arr [ n - 1 ] == 0 ) return arr [ n - 1 ] ; return - 1 ; }
let arr = [ 10 , 3 , 20 , 40 , 2 ] ; let res = nobleInteger ( arr ) ; if ( res != - 1 ) document . write ( " " + res ) ; else document . write ( " " ) ;
function findMinSum ( a , b , n ) {
a . sort ( ) ; b . sort ( ) ;
let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) sum = sum + Math . abs ( a [ i ] - b [ i ] ) ; return sum ; }
let a = [ 4 , 1 , 8 , 7 ] ; let b = [ 2 , 3 , 6 , 5 ] ; let n = a . length ; document . write ( findMinSum ( a , b , n ) ) ;
function checkIsAP ( arr , n ) { if ( n == 1 ) return true ;
arr . sort ( ( a , b ) => a - b ) ;
let d = arr [ 1 ] - arr [ 0 ] ; for ( let i = 2 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] != d ) return false ; return true ; }
let arr = [ 20 , 15 , 5 , 0 , 10 ] ; let n = arr . length ; ( checkIsAP ( arr , n ) ) ? ( document . write ( " " + " " ) ) : ( document . write ( " " + " " ) ) ;
function minProductSubset ( a , n ) { if ( n == 1 ) return a [ 0 ] ;
let negmax = Number . MIN_VALUE ; let posmin = Number . MIN_VALUE ; let count_neg = 0 , count_zero = 0 ; let product = 1 ; for ( let i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == 0 ) { count_zero ++ ; continue ; }
if ( a [ i ] < 0 ) { count_neg ++ ; negmax = Math . max ( negmax , a [ i ] ) ; }
if ( a [ i ] > 0 && a [ i ] < posmin ) { posmin = a [ i ] ; } product *= a [ i ] ; }
if ( count_zero == n || ( count_neg == 0 && count_zero > 0 ) ) return 0 ;
if ( count_neg == 0 ) return posmin ;
if ( count_neg % 2 == 0 && count_neg != 0 ) {
product = parseInt ( product / negmax , 10 ) ; } return product ; }
let a = [ - 1 , - 1 , - 2 , 4 , 3 ] ; let n = 5 ; document . write ( minProductSubset ( a , n ) ) ;
function countPairs ( a , n ) {
let mn = Number . MAX_VALUE ; let mx = Number . MIN_VALUE ; for ( let i = 0 ; i < n ; i ++ ) { mn = Math . min ( mn , a [ i ] ) ; mx = Math . max ( mx , a [ i ] ) ; }
let c1 = 0 ;
let c2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { if ( a [ i ] == mn ) c1 ++ ; if ( a [ i ] == mx ) c2 ++ ; }
if ( mn == mx ) return n * ( n - 1 ) / 2 ; else return c1 * c2 ; }
let a = [ 3 , 2 , 1 , 1 , 3 ] ; let n = a . length ; document . write ( countPairs ( a , n ) ) ;
function binary_search ( a , x , lo = 0 , hi = null ) { if ( hi == null ) hi = a . length ; while ( lo < hi ) { mid = Math . floor ( ( lo + hi ) / 2 ) ; midval = a [ mid ] ; if ( midval < x ) lo = mid + 1 ; else if ( midval > x ) hi = mid ; else return mid ; } return - 1 ; } function findElement ( a , n , b ) {
a . sort ( ( a , b ) => a - b ) ;
let max = a [ n - 1 ] ; while ( b < max ) {
if ( binary_search ( a , a + n , b ) ) b *= 2 ; else return b ; } return b ; }
let a = [ 1 , 2 , 3 ] ; let n = a . length ; let b = 1 ; document . write ( findElement ( a , n , b ) ) ;
let Mod = 1000000007 ;
function findSum ( arr , n ) { let sum = 0 ;
arr . sort ( ) ;
let i = 0 ; while ( i < n && arr [ i ] < 0 ) { if ( i != n - 1 && arr [ i + 1 ] <= 0 ) { sum = ( sum + ( arr [ i ] * arr [ i + 1 ] ) % Mod ) % Mod ; i += 2 ; } else break ; }
let j = n - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { if ( j != 0 && arr [ j - 1 ] > 0 ) { sum = ( sum + ( arr [ j ] * arr [ j - 1 ] ) % Mod ) % Mod ; j -= 2 ; } else break ; }
if ( j > i ) sum = ( sum + ( arr [ i ] * arr [ j ] ) % Mod ) % Mod ;
else if ( i == j ) sum = ( sum + arr [ i ] ) % Mod ; return sum ; }
let arr = [ - 1 , 9 , 4 , 5 , - 4 , 7 ] ; let n = arr . length ; document . write ( findSum ( arr , n ) ) ;
function countOddRotations ( n ) { var odd_count = 0 , even_count = 0 ; do { var digit = n % 10 ; if ( digit % 2 == 1 ) odd_count ++ ; else even_count ++ ; n = parseInt ( n / 10 ) ; } while ( n != 0 ) ; document . write ( " " + odd_count + " " ) ; document . write ( " " + even_count + " " ) ; }
var n = 1234 ; countOddRotations ( n ) ;
function numberOfDigits ( n ) { let cnt = 0 ; while ( n > 0 ) { cnt ++ ; n = parseInt ( n / 10 , 10 ) ; } return cnt ; }
function cal ( num ) { let digits = numberOfDigits ( num ) ; let powTen = Math . pow ( 10 , digits - 1 ) ; for ( let i = 0 ; i < digits - 1 ; i ++ ) { let firstDigit = parseInt ( num / powTen , 10 ) ;
let left = ( ( num * 10 ) + firstDigit ) - ( firstDigit * powTen * 10 ) ; document . write ( left + " " ) ;
num = left ; } }
let num = 1445 ; cal ( num ) ;
function CheckKCycles ( n , s ) { var ff = true ; var x = 0 ; for ( i = 1 ; i < n ; i ++ ) {
x = ( s . substring ( i ) + s . substring ( 0 , i ) ) . length ;
if ( x >= s . length ) { continue ; } ff = false ; break ; } if ( ff ) { document . write ( " " ) ; } else { document . write ( " " ) ; } }
var n = 3 ; var s = " " ; CheckKCycles ( n , s ) ;
function rightRotationDivisor ( N ) { let lastDigit = N % 10 ; let rightRotation = ( lastDigit * Math . pow ( 10 , Math . floor ( ( Math . log10 ( N ) ) ) ) + Math . floor ( N / 10 ) ) ; return ( rightRotation % N == 0 ) ; }
function generateNumbers ( m ) { for ( let i = Math . floor ( Math . pow ( 10 , ( m - 1 ) ) ) ; i < Math . floor ( Math . pow ( 10 , m ) ) ; i ++ ) if ( rightRotationDivisor ( i ) ) document . write ( i + " " ) ; }
let m = 3 ; generateNumbers ( m ) ;
let minIndex = - 1 ;
for ( let i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < minEle ) { minEle = arr [ i ] ; minIndex = i ; } } let flag1 = true ;
for ( let i = 1 ; i < minIndex ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag1 = false ; break ; } } let flag2 = true ;
for ( let i = minIndex + 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag2 = false ; break ; } }
if ( flag1 && flag2 && ( arr [ n - 1 ] < arr [ 0 ] ) ) document . write ( " " ) ; else document . write ( " " ) ; }
let arr = [ 3 , 4 , 5 , 1 , 2 ] ; let n = arr . length ;
checkIfSortRotated ( arr , n ) ;
function occurredOnce ( arr , n ) {
arr . sort ( function ( a , b ) { return a - b ; } ) ;
if ( arr [ 0 ] != arr [ 1 ] ) document . write ( arr [ 0 ] + " " ) ;
for ( let i = 1 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i - 1 ] ) document . write ( arr [ i ] + " " ) ;
if ( arr [ n - 2 ] != arr [ n - 1 ] ) document . write ( arr [ n - 1 ] + " " ) ; }
let arr = [ 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ] ; let n = arr . length ; occurredOnce ( arr , n ) ;
function occurredOnce ( arr , n ) { var i = 1 , len = n ;
if ( arr [ 0 ] == arr [ len - 1 ] ) { i = 2 ; len -- ; }
for ( ; i < n ; i ++ )
if ( arr [ i ] == arr [ i - 1 ] ) i ++ ;
else document . write ( arr [ i - 1 ] + " " ) ;
if ( arr [ n - 1 ] != arr [ 0 ] && arr [ n - 1 ] != arr [ n - 2 ] ) document . write ( arr [ n - 1 ] ) ; }
var arr = [ 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 ] ; var n = arr . length ; occurredOnce ( arr , n ) ;
function rvereseArray ( arr , start , end ) { while ( start < end ) { let temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
function printArray ( arr , size ) { for ( let i = 0 ; i < size ; i ++ ) document . write ( arr [ i ] + " " ) ; }
function splitArr ( arr , k , n ) { rvereseArray ( arr , 0 , n - 1 ) ; rvereseArray ( arr , 0 , n - k - 1 ) ; rvereseArray ( arr , n - k , n - 1 ) ; }
let arr = new Array ( 12 , 10 , 5 , 6 , 52 , 36 ) ; let n = arr . length ; let k = 2 ;
splitArr ( arr , k , n ) ; printArray ( arr , n ) ;
function countRotationsDivBy8 ( n ) { let len = n . length ; let count = 0 ;
if ( len == 1 ) { let oneDigit = n [ 0 ] - ' ' ; if ( oneDigit % 8 == 0 ) return 1 ; return 0 ; }
if ( len == 2 ) {
let first = ( n [ 0 ] - ' ' ) * 10 + ( n [ 1 ] - ' ' ) ;
let second = ( n [ 1 ] - ' ' ) * 10 + ( n [ 0 ] - ' ' ) ; if ( first % 8 == 0 ) count ++ ; if ( second % 8 == 0 ) count ++ ; return count ; }
let threeDigit ; for ( let i = 0 ; i < ( len - 2 ) ; i ++ ) { threeDigit = ( n [ i ] - ' ' ) * 100 + ( n [ i + 1 ] - ' ' ) * 10 + ( n [ i + 2 ] - ' ' ) ; if ( threeDigit % 8 == 0 ) count ++ ; }
threeDigit = ( n [ len - 1 ] - ' ' ) * 100 + ( n [ 0 ] - ' ' ) * 10 + ( n [ 1 ] - ' ' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
threeDigit = ( n [ len - 2 ] - ' ' ) * 100 + ( n [ len - 1 ] - ' ' ) * 10 + ( n [ 0 ] - ' ' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
return count ; }
let n = " " ; document . write ( " " + countRotationsDivBy8 ( n ) ) ;
function isRotation ( x , y ) {
var x64 = x | ( x << 32 ) ; while ( x64 >= y ) {
if ( x64 == y ) { return true ; }
x64 >>= 1 ; } return false ; }
var x = 122 ; var y = 2147483678 ; if ( isRotation ( x , y ) == false ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function countRotations ( n ) { let len = n . length ;
if ( len == 1 ) { let oneDigit = n [ 0 ] - ' ' ; if ( oneDigit % 4 == 0 ) return 1 ; return 0 ; }
let twoDigit ; let count = 0 ; for ( let i = 0 ; i < ( len - 1 ) ; i ++ ) { twoDigit = ( n [ i ] - ' ' ) * 10 + ( n [ i + 1 ] - ' ' ) ; if ( twoDigit % 4 == 0 ) count ++ ; }
twoDigit = ( n [ len - 1 ] - ' ' ) * 10 + ( n [ 0 ] - ' ' ) ; if ( twoDigit % 4 == 0 ) count ++ ; return count ; }
let n = " " ; document . write ( " " + countRotations ( n ) ) ;
let INF = Number . MAX_VALUE , N = 4 ;
function minCost ( cost ) {
let dist = new Array ( N ) ; dist . fill ( 0 ) ; for ( let i = 0 ; i < N ; i ++ ) dist [ i ] = INF ; dist [ 0 ] = 0 ;
for ( let i = 0 ; i < N ; i ++ ) for ( let j = i + 1 ; j < N ; j ++ ) if ( dist [ j ] > dist [ i ] + cost [ i ] [ j ] ) dist [ j ] = dist [ i ] + cost [ i ] [ j ] ; return dist [ N - 1 ] ; }
let cost = [ [ 0 , 15 , 80 , 90 ] , [ INF , 0 , 40 , 50 ] , [ INF , INF , 0 , 70 ] , [ INF , INF , INF , 0 ] ] ; document . write ( " " + " " + N + " " + minCost ( cost ) ) ;
function numOfways ( n , k ) { let p = 1 ; if ( k % 2 != 0 ) p = - 1 ; return ( Math . pow ( n - 1 , k ) + p * ( n - 1 ) ) / n ; }
let n = 4 , k = 2 ; document . write ( numOfways ( n , k ) ) ;
function power ( n ) { if ( n == 1 ) return 2 ; return 2 * power ( n - 1 ) ; }
var n = 4 ; document . write ( power ( n ) ) ;
var size = 4 ;
function checkStar ( mat ) {
var vertexD1 = 0 , vertexDn_1 = 0 ;
if ( size == 1 ) return ( mat [ 0 ] [ 0 ] == 0 ) ;
if ( size == 2 ) return ( mat [ 0 ] [ 0 ] == 0 && mat [ 0 ] [ 1 ] == 1 && mat [ 1 ] [ 0 ] == 1 && mat [ 1 ] [ 1 ] == 0 ) ;
for ( var i = 0 ; i < size ; i ++ ) { var degreeI = 0 ; for ( var j = 0 ; j < size ; j ++ ) if ( mat [ i ] [ j ] ) degreeI ++ ; if ( degreeI == 1 ) vertexD1 ++ ; else if ( degreeI == size - 1 ) vertexDn_1 ++ ; } return ( vertexD1 == ( size - 1 ) && vertexDn_1 == 1 ) ; }
var mat = [ [ 0 , 1 , 1 , 1 ] , [ 1 , 0 , 0 , 0 ] , [ 1 , 0 , 0 , 0 ] , [ 1 , 0 , 0 , 0 ] ] ; checkStar ( mat ) ? document . write ( " " ) : document . write ( " " ) ;
function fib ( n ) { if ( n <= 1 ) return n ; return fib ( n - 1 ) + fib ( n - 2 ) ; }
function findVertices ( n ) {
return fib ( n + 2 ) ; }
var n = 3 ; document . write ( findVertices ( n ) ) ;
function isInorder ( arr , n ) {
if ( n == 0 n == 1 ) { return true ; }
for ( i = 1 ; i < n ; i ++ ) { if ( arr [ i - 1 ] > arr [ i ] ) { return false ; } }
return true ; }
var arr = [ 19 , 23 , 25 , 30 , 45 ] ; var n = arr . length ; if ( isInorder ( arr , n ) ) { document . write ( " " ) ; } else { document . write ( " " ) ; }
function isLeaf ( pre , n , min , max ) { if ( i >= n ) { return false ; } if ( pre [ i ] > min && pre [ i ] < max ) { i ++ ; let left = isLeaf ( pre , n , min , pre [ i - 1 ] ) ; let right = isLeaf ( pre , n , pre [ i - 1 ] , max ) ; if ( ! left && ! right ) { document . write ( pre [ i - 1 ] + " " ) ; } return true ; } return false ; } function printLeaves ( preorder , n ) { isLeaf ( preorder , n , Number . MIN_VALUE , Number . MAX_VALUE ) ; }
let preorder = [ 890 , 325 , 290 , 530 , 965 ] ; let n = preorder . length ; printLeaves ( preorder , n ) ;
function pairs ( arr , n , k ) {
var smallest = 1000000000 ; var count = 0 ;
for ( var i = 0 ; i < n ; i ++ ) for ( var j = i + 1 ; j < n ; j ++ ) {
if ( Math . abs ( arr [ i ] + arr [ j ] - k ) < smallest ) { smallest = Math . abs ( arr [ i ] + arr [ j ] - k ) ; count = 1 ; }
else if ( Math . abs ( arr [ i ] + arr [ j ] - k ) == smallest ) count ++ ; }
document . write ( " " + smallest + " " ) ; document . write ( " " + count + " " ) ; }
var arr = [ 3 , 5 , 7 , 5 , 1 , 9 , 9 ] ; var k = 12 ; var n = arr . length ; pairs ( arr , n , k ) ;
var a = [ 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 ] ; var key = 20 ; var arraySize = a . length ; var count = 0 ; for ( i = 0 ; i < arraySize ; i ++ ) { if ( a [ i ] <= key ) { count += 1 ; } } document . write ( " " + key + " " + ( count - 1 ) ) ;
let MAX_SIZE = 10 ;
function sortByRow ( mat , n , ascending ) { for ( let i = 0 ; i < n ; i ++ ) { if ( ascending ) mat [ i ] . sort ( function ( a , b ) { return a - b ; } ) ; else mat [ i ] . sort ( function ( a , b ) { return b - a ; } ) ; } }
function transpose ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) {
let temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ j ] [ i ] ; mat [ j ] [ i ] = temp ; } }
function sortMatRowAndColWise ( mat , n ) {
sortByRow ( mat , n , true ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n , false ) ;
transpose ( mat , n ) ; }
function printMat ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) document . write ( mat [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let n = 3 ; let mat = [ [ 3 , 2 , 1 ] , [ 9 , 8 , 7 ] , [ 6 , 5 , 4 ] ] ; document . write ( " " ) ; printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; document . write ( " " ) ; printMat ( mat , n ) ;
var MAX = 100 ; function middlesum ( mat , n ) { var row_sum = 0 , col_sum = 0 ;
for ( i = 0 ; i < n ; i ++ ) row_sum += mat [ parseInt ( n / 2 ) ] [ i ] ; document . write ( " " + row_sum + " " ) ;
for ( i = 0 ; i < n ; i ++ ) col_sum += mat [ i ] [ parseInt ( n / 2 ) ] ; document . write ( " " + col_sum ) ; }
var mat = [ [ 2 , 5 , 7 ] , [ 3 , 7 , 2 ] , [ 5 , 6 , 9 ] ] ; middlesum ( mat , 3 ) ;
var M = 3 ; var N = 3 ;
function rotateMatrix ( matrix , k ) {
var temp = Array ( M ) . fill ( 0 ) ;
k = k % M ; for ( i = 0 ; i < N ; i ++ ) {
for ( t = 0 ; t < M - k ; t ++ ) temp [ t ] = matrix [ i ] [ t ] ;
for ( j = M - k ; j < M ; j ++ ) matrix [ i ] [ j - M + k ] = matrix [ i ] [ j ] ;
for ( j = k ; j < M ; j ++ ) matrix [ i ] [ j ] = temp [ j - k ] ; } }
function displayMatrix ( matrix ) { for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < M ; j ++ ) document . write ( matrix [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
var matrix = [ [ 12 , 23 , 34 ] , [ 45 , 56 , 67 ] , [ 78 , 89 , 91 ] ] ; var k = 2 ;
rotateMatrix ( matrix , k ) ;
displayMatrix ( matrix ) ;
function interchangeFirstLast ( m ) { let rows = m . length ;
for ( let i = 0 ; i < m [ 0 ] . length ; i ++ ) { let t = m [ 0 ] [ i ] ; m [ 0 ] [ i ] = m [ rows - 1 ] [ i ] ; m [ rows - 1 ] [ i ] = t ; } }
let m = [ [ 8 , 9 , 7 , 6 ] , [ 4 , 7 , 6 , 5 ] , [ 3 , 2 , 1 , 8 ] , [ 9 , 9 , 7 , 7 ] ] interchangeFirstLast ( m ) ;
for ( let i = 0 ; i < m . length ; i ++ ) { for ( let j = 0 ; j < m [ 0 ] . length ; j ++ ) document . write ( m [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
let n = 3 function checkMarkov ( m ) {
for ( let i = 0 ; i < n ; i ++ ) {
let sum = 0 ; for ( let j = 0 ; j < n ; j ++ ) sum = sum + m [ i ] [ j ] ; if ( sum != 1 ) return false ; } return true ; }
let m = [ [ 0 , 0 , 1 ] , [ 0.5 , 0 , 0.5 ] , [ 1 , 0 , 0 ] ] ;
if ( checkMarkov ( m ) ) document . write ( " " ) ; else document . write ( " " ) ;
let N = 4 ;
function isDiagonalMatrix ( mat ) { for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < N ; j ++ )
if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ; return true ; }
let mat = [ [ 4 , 0 , 0 , 0 ] , [ 0 , 7 , 0 , 0 ] , [ 0 , 0 , 5 , 0 ] , [ 0 , 0 , 0 , 1 ] ] ; if ( isDiagonalMatrix ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
let N = 4 ;
function isScalarMatrix ( mat ) {
for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ;
for ( let i = 0 ; i < N - 1 ; i ++ ) if ( mat [ i ] [ i ] != mat [ i + 1 ] [ i + 1 ] ) return false ; return true ; }
let mat = [ [ 2 , 0 , 0 , 0 ] , [ 0 , 2 , 0 , 0 ] , [ 0 , 0 , 2 , 0 ] , [ 0 , 0 , 0 , 2 ] ] ;
if ( isScalarMatrix ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
let MAX_SIZE = 10 ;
function sortByRow ( mat , n ) { for ( let i = 0 ; i < n ; i ++ )
mat [ i ] . sort ( function ( a , b ) { return a - b ; } ) ; }
function transpose ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) for ( let j = i + 1 ; j < n ; j ++ ) {
let temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ j ] [ i ] ; mat [ j ] [ i ] = temp ; } }
function sortMatRowAndColWise ( mat , n ) {
sortByRow ( mat , n ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n ) ;
transpose ( mat , n ) ; }
function printMat ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) document . write ( mat [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let mat = [ [ 4 , 1 , 3 ] , [ 9 , 6 , 8 ] , [ 5 , 2 , 7 ] ] ; let n = 3 ; document . write ( " " ) ; printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; document . write ( " " ) ; printMat ( mat , n ) ;
function doublyEven ( n ) { var arr = Array ( n ) . fill ( 0 ) . map ( x => Array ( n ) . fill ( 0 ) ) ; var i , j ;
for ( i = 0 ; i < n ; i ++ ) for ( j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * i ) + j + 1 ;
for ( i = 0 ; i < parseInt ( n / 4 ) ; i ++ ) for ( j = 0 ; j < parseInt ( n / 4 ) ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < parseInt ( n / 4 ) ; i ++ ) for ( j = 3 * ( parseInt ( n / 4 ) ) ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * parseInt ( n / 4 ) ; i < n ; i ++ ) for ( j = 0 ; j < parseInt ( n / 4 ) ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * parseInt ( n / 4 ) ; i < n ; i ++ ) for ( j = 3 * parseInt ( n / 4 ) ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = parseInt ( n / 4 ) ; i < 3 * parseInt ( n / 4 ) ; i ++ ) for ( j = parseInt ( n / 4 ) ; j < 3 * parseInt ( n / 4 ) ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) document . write ( arr [ i ] [ j ] + " " ) ; document . write ( ' ' ) ; } }
var n = 8 ;
doublyEven ( n ) ;
function isMagicSquare ( mat ) {
var sum = 0 , sum2 = 0 ; for ( var i = 0 ; i < N ; i ++ ) sum = sum + mat [ i ] [ i ] ;
for ( var i = 0 ; i < N ; i ++ ) sum2 = sum2 + mat [ i ] [ N - 1 - i ] ; if ( sum != sum2 ) return false ;
for ( var i = 0 ; i < N ; i ++ ) { var rowSum = 0 ; for ( var j = 0 ; j < N ; j ++ ) rowSum += mat [ i ] [ j ] ;
if ( rowSum != sum ) return false ; }
for ( var i = 0 ; i < N ; i ++ ) { var colSum = 0 ; for ( var j = 0 ; j < N ; j ++ ) colSum += mat [ j ] [ i ] ;
if ( sum != colSum ) return false ; } return true ; }
var mat = [ [ 2 , 7 , 6 ] , [ 9 , 5 , 1 ] , [ 4 , 3 , 8 ] ] ; if ( isMagicSquare ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
function subCount ( arr , n , k ) {
var mod = Array ( k ) . fill ( 0 ) ;
var cumSum = 0 ; for ( var i = 0 ; i < n ; i ++ ) { cumSum += arr [ i ] ;
mod [ ( ( cumSum % k ) + k ) % k ] ++ ; }
var result = 0 ;
for ( var i = 0 ; i < k ; i ++ )
if ( mod [ i ] > 1 ) result += ( mod [ i ] * ( mod [ i ] - 1 ) ) / 2 ;
result += mod [ 0 ] ; return result ; }
function countSubmatrix ( mat , n , k ) {
var tot_count = 0 ; var left , right , i ; var temp = Array ( n ) ;
for ( left = 0 ; left < n ; left ++ ) {
temp = Array ( n ) . fill ( 0 ) ;
for ( right = left ; right < n ; right ++ ) {
for ( i = 0 ; i < n ; ++ i ) temp [ i ] += mat [ i ] [ right ] ;
tot_count += subCount ( temp , n , k ) ; } }
return tot_count ; }
var mat = [ [ 5 , - 1 , 6 ] , [ - 2 , 3 , 8 ] , [ 7 , 4 , - 9 ] ] ; var n = 3 , k = 4 ; document . write ( " " + countSubmatrix ( mat , n , k ) ) ;
function find ( n , k ) { if ( n + 1 >= k ) return ( k - 1 ) ; else return ( 2 * n + 1 - k ) ; }
var n = 4 , k = 7 ; var freq = find ( n , k ) ; if ( freq < 0 ) document . write ( " " ) ; else document . write ( " " + k + " " + freq + " " ) ;
function ZigZag ( rows , columns , numbers ) { let k = 0 ;
let arr = new Array ( rows ) ; for ( let i = 0 ; i < rows ; i ++ ) { arr [ i ] = new Array ( rows ) ; for ( let j = 0 ; j < columns ; j ++ ) { arr [ i ] [ j ] = 0 ; } } for ( let i = 0 ; i < rows ; i ++ ) {
if ( i % 2 == 0 ) {
for ( let j = 0 ; j < columns && numbers [ k ] > 0 ; j ++ ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } }
else {
for ( let j = columns - 1 ; j >= 0 && numbers [ k ] > 0 ; j -- ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } } }
for ( let i = 0 ; i < rows ; i ++ ) { for ( let j = 0 ; j < columns ; j ++ ) document . write ( arr [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let rows = 4 ; let columns = 5 ; let Numbers = [ 3 , 4 , 2 , 2 , 3 , 1 , 5 ] ; ZigZag ( rows , columns , Numbers ) ;
function numberofPosition ( n , k , x , y , obstPosx , obstPosy ) {
let d11 , d12 , d21 , d22 , r1 , r2 , c1 , c2 ;
d11 = Math . min ( x - 1 , y - 1 ) ; d12 = Math . min ( n - x , n - y ) ; d21 = Math . min ( n - x , y - 1 ) ; d22 = Math . min ( x - 1 , n - y ) ; r1 = y - 1 ; r2 = n - y ; c1 = x - 1 ; c2 = n - x ;
for ( let i = 0 ; i < k ; i ++ ) { if ( x > obstPosx [ i ] && y > obstPosy [ i ] && x - obstPosx [ i ] == y - obstPosy [ i ] ) d11 = Math . min ( d11 , x - obstPosx [ i ] - 1 ) ; if ( obstPosx [ i ] > x && obstPosy [ i ] > y && obstPosx [ i ] - x == obstPosy [ i ] - y ) d12 = Math . min ( d12 , obstPosx [ i ] - x - 1 ) ; if ( obstPosx [ i ] > x && y > obstPosy [ i ] && obstPosx [ i ] - x == y - obstPosy [ i ] ) d21 = Math . min ( d21 , obstPosx [ i ] - x - 1 ) ; if ( x > obstPosx [ i ] && obstPosy [ i ] > y && x - obstPosx [ i ] == obstPosy [ i ] - y ) d22 = Math . min ( d22 , x - obstPosx [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] < y ) r1 = min ( r1 , y - obstPosy [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] > y ) r2 = Math . min ( r2 , obstPosy [ i ] - y - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] < x ) c1 = Math . min ( c1 , x - obstPosx [ i ] - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] > x ) c2 = Math . min ( c2 , obstPosx [ i ] - x - 1 ) ; } return d11 + d12 + d21 + d22 + r1 + r2 + c1 + c2 ; }
let n = 8 ;
let k = 1 ;
let Qposx = 4 ;
let Qposy = 4 ;
let obstPosx = [ 3 ] ;
let obstPosy = [ 5 ] ; document . write ( numberofPosition ( n , k , Qposx , Qposy , obstPosx , obstPosy ) ) ;
let n = 5 ;
function FindMaxProduct ( arr , n ) { let max = 0 , result ;
for ( let i = 0 ; i < n ; i ++ ) {
for ( let j = 0 ; j < n ; j ++ ) {
if ( ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i ] [ j - 1 ] * arr [ i ] [ j - 2 ] * arr [ i ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j ] * arr [ i - 2 ] [ j ] * arr [ i - 3 ] [ j ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j - 1 ] * arr [ i - 2 ] [ j - 2 ] * arr [ i - 3 ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 1 ) <= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j + 1 ] * arr [ i - 2 ] [ j + 2 ] * arr [ i - 3 ] [ j + 3 ] ; if ( max < result ) max = result ; } } } return max ; }
let arr = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 6 , 7 , 8 , 9 , 1 ] , [ 2 , 3 , 4 , 5 , 6 ] , [ 7 , 8 , 9 , 1 , 0 ] , [ 9 , 6 , 4 , 2 , 3 ] ] ; document . write ( FindMaxProduct ( arr , n ) ) ;
/ *JavaScript Program to find minimum flip required to make Binary Matrix symmetric along main diagonal
function minimumflip ( mat , n ) { let transpose = new Array ( n ) ; for ( var i = 0 ; i < transpose . length ; i ++ ) { transpose [ i ] = new Array ( 2 ) ; }
for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n ; j ++ ) transpose [ i ] [ j ] = mat [ j ] [ i ] ;
let flip = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n ; j ++ ) if ( transpose [ i ] [ j ] != mat [ i ] [ j ] ) flip ++ ; return flip / 2 ; }
let n = 3 ; let mat = [ [ 0 , 0 , 1 ] , [ 1 , 1 , 1 ] , [ 1 , 0 , 0 ] ] ; document . write ( minimumflip ( mat , n ) ) ;
function minimumflip ( mat , n ) {
let flip = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) flip ++ ; return flip ; }
let n = 3 ; let mat = [ [ 0 , 0 , 1 ] , [ 1 , 1 , 1 ] , [ 1 , 0 , 0 ] ] ; document . write ( minimumflip ( mat , n ) ) ;
let N = 4 ;
function isLowerTriangularMatrix ( mat ) { for ( let i = 0 ; i < N ; i ++ ) for ( let j = i + 1 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
let mat = [ [ 1 , 0 , 0 , 0 ] , [ 1 , 4 , 0 , 0 ] , [ 4 , 6 , 2 , 0 ] , [ 0 , 4 , 7 , 6 ] ] ;
if ( isLowerTriangularMatrix ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
let N = 4 ;
function isUpperTriangularMatrix ( mat ) { for ( let i = 1 ; i < N ; i ++ ) for ( let j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
let mat = [ [ 1 , 3 , 5 , 3 ] , [ 0 , 4 , 6 , 2 ] , [ 0 , 0 , 2 , 5 ] , [ 0 , 0 , 0 , 6 ] ] ; if ( isUpperTriangularMatrix ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
let MAX = 100 ;
function freq ( ar , m , n ) { let even = 0 , odd = 0 ; for ( let i = 0 ; i < m ; ++ i ) { for ( let j = 0 ; j < n ; ++ j ) {
if ( ( ar [ i ] [ j ] % 2 ) == 0 ) ++ even ; else ++ odd ; } }
document . write ( " " + odd + " " ) ; document . write ( " " + even + " " ) ; }
let m = 3 , n = 3 ; let array = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] ; freq ( array , m , n ) ;
const MAX = 100 ;
function HalfDiagonalSums ( mat , n ) {
let diag1_left = 0 , diag1_right = 0 ; let diag2_left = 0 , diag2_right = 0 ; for ( let i = 0 , j = n - 1 ; i < n ; i ++ , j -- ) { if ( i < parseInt ( n / 2 ) ) { diag1_left += mat [ i ] [ i ] ; diag2_left += mat [ j ] [ i ] ; } else if ( i > parseInt ( n / 2 ) ) { diag1_right += mat [ i ] [ i ] ; diag2_right += mat [ j ] [ i ] ; } } return ( diag1_left == diag2_right && diag2_right == diag2_left && diag1_right == diag2_left && diag2_right == mat [ parseInt ( n / 2 ) ] [ parseInt ( n / 2 ) ] ) ; }
let a = [ [ 2 , 9 , 1 , 4 , - 2 ] , [ 6 , 7 , 2 , 11 , 4 ] , [ 4 , 2 , 9 , 2 , 4 ] , [ 1 , 9 , 2 , 4 , 4 ] , [ 0 , 2 , 4 , 2 , 5 ] ] ; document . write ( HalfDiagonalSums ( a , 5 ) ? " " : " " ) ;
let MAX = 100 ; function isIdentity ( mat , N ) { for ( let row = 0 ; row < N ; row ++ ) { for ( let col = 0 ; col < N ; col ++ ) { if ( row == col && mat [ row ] [ col ] != 1 ) return false ; else if ( row != col && mat [ row ] [ col ] != 0 ) return false ; } } return true ; }
let N = 4 ; let mat = [ [ 1 , 0 , 0 , 0 ] , [ 0 , 1 , 0 , 0 ] , [ 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 1 ] ] ; if ( isIdentity ( mat , N ) ) document . write ( " " ) ; else document . write ( " " ) ;
let mod = 100000007 ;
function modPower ( a , t , mod ) { let now = a , ret = 1 ;
while ( t > 0 ) { if ( t % 2 == 1 ) ret = now * ( ret % mod ) ; now = now * ( now % mod ) ; t >>= 1 ; } return ret ; }
function countWays ( n , m , k ) {
if ( n == 1 m == 1 ) return 1 ;
else if ( ( n + m ) % 2 == 1 && k == - 1 ) return 0 ;
return ( modPower ( modPower ( 2 , n - 1 , mod ) , m - 1 , mod ) % mod ) ; }
let n = 2 , m = 7 , k = 1 ; document . write ( countWays ( n , m , k ) ) ;
let MAX = 100 ; function imageSwap ( mat , n ) {
for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j <= i ; j ++ ) mat [ i ] [ j ] = mat [ i ] [ j ] + mat [ j ] [ i ] - ( mat [ j ] [ i ] = mat [ i ] [ j ] ) ; }
function printMatrix ( mat , n ) { for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) document . write ( mat [ i ] [ j ] + " " ) ; document . write ( " " ) ; } }
let mat = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 9 , 10 , 11 , 12 ] , [ 13 , 14 , 15 , 16 ] ] ; let n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ;
var m = 3 ;
var n = 2 ;
function countSets ( a ) {
var res = 0 ;
for ( i = 0 ; i < n ; i ++ ) { var u = 0 , v = 0 ; for ( j = 0 ; j < m ; j ++ ) { if ( a [ i ] [ j ] == 1 ) u ++ ; else v ++ ; } res += Math . pow ( 2 , u ) - 1 + Math . pow ( 2 , v ) - 1 ; }
for ( i = 0 ; i < m ; i ++ ) { var u = 0 , v = 0 ; for ( j = 0 ; j < n ; j ++ ) { if ( a [ j ] [ i ] == 1 ) u ++ ; else v ++ ; } res += Math . pow ( 2 , u ) - 1 + Math . pow ( 2 , v ) - 1 ; }
return res - ( n * m ) ; }
var a = [ [ 1 , 0 , 1 ] , [ 0 , 1 , 0 ] ] ; document . write ( countSets ( a ) ) ;
function fill0X ( m , n ) {
let i , k = 0 , l = 0 ;
let r = m , c = n ;
let x = ' ' ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) { a [ k ] [ i ] = x ; } k ++ ;
for ( i = k ; i < m ; ++ i ) { a [ i ] [ n - 1 ] = x ; } n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = x ; m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) { a [ i ] [ l ] = x ; } l ++ ; }
x = ( x == ' ' ) ? ' ' : ' ' ; }
for ( i = 0 ; i < r ; i ++ ) { for ( let j = 0 ; j < c ; j ++ ) { document . write ( a [ i ] [ j ] + " " ) ; } document . write ( " " ) ; } }
document . write ( " " ) ; fill0X ( 5 , 6 ) ; document . write ( " " ) ; fill0X ( 4 , 4 ) ; document . write ( " " ) ; fill0X ( 3 , 4 ) ;
function calculateEnergy ( mat , n ) { let i_des , j_des , q ; let tot_energy = 0 ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
q = Math . floor ( mat [ i ] [ j ] / n ) ;
i_des = q ; j_des = mat [ i ] [ j ] - ( n * q ) ;
tot_energy += Math . abs ( i_des - i ) + Math . abs ( j_des - j ) ; } }
return tot_energy ; }
let mat = [ [ 4 , 7 , 0 , 3 ] , [ 8 , 5 , 6 , 1 ] , [ 9 , 11 , 10 , 2 ] , [ 15 , 13 , 14 , 12 ] ] ; let n = 4 ; document . write ( " " + calculateEnergy ( mat , n ) + " " ) ;
let MAX = 100 ;
function isUnique ( mat , i , j , n , m ) {
let sumrow = 0 ; for ( let k = 0 ; k < m ; k ++ ) { sumrow += mat [ i ] [ k ] ; if ( sumrow > 1 ) return false ; }
let sumcol = 0 ; for ( let k = 0 ; k < n ; k ++ ) { sumcol += mat [ k ] [ j ] ; if ( sumcol > 1 ) return false ; } return true ; } function countUnique ( mat , n , m ) { let uniquecount = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] != 0 && isUnique ( mat , i , j , n , m ) ) uniquecount ++ ; return uniquecount ; }
let mat = [ [ 0 , 1 , 0 , 0 ] , [ 0 , 0 , 1 , 0 ] , [ 1 , 0 , 0 , 1 ] ] ; document . write ( countUnique ( mat , 3 , 4 ) ) ;
for ( let i = 0 ; i < m ; ++ i ) for ( let j = 0 ; j < n ; ++ j ) if ( array [ i ] [ j ] == 0 ) ++ counter ; return ( counter > parseInt ( ( m * n ) / 2 ) , 10 ) ; }
let array = [ [ 1 , 0 , 3 ] , [ 0 , 0 , 4 ] , [ 6 , 0 , 0 ] ] ; let m = 3 , n = 3 ; if ( isSparse ( array , m , n ) ) document . write ( " " ) ; else document . write ( " " ) ;
let MAX = 100 ;
function countCommon ( mat , n ) { let res = 0 ; for ( let i = 0 ; i < n ; i ++ ) if ( mat [ i ] [ i ] == mat [ i ] [ n - i - 1 ] ) res ++ ; return res ; }
let mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] ; document . write ( countCommon ( mat , 3 ) ) ;
function areSumSame ( a , n , m ) { let sum1 = 0 , sum2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { sum1 = 0 ; sum2 = 0 ; for ( let j = 0 ; j < m ; j ++ ) { sum1 += a [ i ] [ j ] ; sum2 += a [ j ] [ i ] ; } if ( sum1 == sum2 ) return true ; } return false ; }
let n = 4 ;
let m = 4 ; let M = [ [ 1 , 2 , 3 , 4 ] , [ 9 , 5 , 3 , 1 ] , [ 0 , 3 , 5 , 6 ] , [ 0 , 4 , 5 , 6 ] ] ; if ( areSumSame ( M , n , m ) == true ) document . write ( " " ) ; else document . write ( " " ) ;
var N = 4
function findMax ( arr ) { var row = 0 , i , j ; for ( i = 0 , j = N - 1 ; i < N ; i ++ ) {
while ( arr [ i ] [ j ] == 1 && j >= 0 ) { row = i ; j -- ; } } document . write ( " " + ( row + 1 ) ) ; document . write ( " " + ( N - 1 - j ) ) ; }
var arr = [ [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 0 ] , [ 0 , 1 , 1 , 1 ] ] ; findMax ( arr ) ;
function transpose ( mat , tr , N ) { for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) tr [ i ] [ j ] = mat [ j ] [ i ] ; }
function isSymmetric ( mat , N ) { let tr = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { tr [ i ] = new Array ( MAX ) ; } transpose ( mat , tr , N ) ; for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != tr [ i ] [ j ] ) return false ; return true ; }
let mat = [ [ 1 , 3 , 5 ] , [ 3 , 2 , 4 ] , [ 5 , 4 , 1 ] ] ; if ( isSymmetric ( mat , 3 ) ) document . write ( " " ) ; else document . write ( " " ) ;
let MAX = 100 ;
function isSymmetric ( mat , N ) { for ( let i = 0 ; i < N ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) return false ; return true ; }
let mat = [ [ 1 , 3 , 5 ] , [ 3 , 2 , 4 ] , [ 5 , 4 , 1 ] ] ; if ( isSymmetric ( mat , 3 ) ) document . write ( " " ) ; else document . write ( " " ) ;
let n = 4 ; let m = 4 ;
function findPossibleMoves ( mat , p , q ) {
let X = [ 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 ] ; let Y = [ 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 ] ; let count = 0 ;
for ( let i = 0 ; i < 8 ; i ++ ) {
let x = p + X [ i ] ; let y = q + Y [ i ] ;
if ( x >= 0 && y >= 0 && x < n && y < m && mat [ x ] [ y ] == 0 ) count ++ ; }
return count ; }
let mat = [ [ 1 , 0 , 1 , 0 ] , [ 0 , 1 , 1 , 1 ] , [ 1 , 1 , 0 , 1 ] , [ 0 , 1 , 1 , 1 ] ] ; let p = 2 , q = 2 ; document . write ( findPossibleMoves ( mat , p , q ) ) ;
const MAX = 100 ; void printDiagonalSums ( mat , n ) { let principal = 0 , secondary = 0 ; for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( i == j ) principal += mat [ i ] [ j ] ;
if ( ( i + j ) == ( n - 1 ) ) secondary += mat [ i ] [ j ] ; } } document . write ( " " + principal + " " ) ; document . write ( " " + secondary + " " ) ; }
let a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] ; printDiagonalSums ( a , 4 ) ;
function printDiagonalSums ( mat , n ) { let principal = 0 , secondary = 0 ; for ( let i = 0 ; i < n ; i ++ ) { principal += mat [ i ] [ i ] ; secondary += mat [ i ] [ n - i - 1 ] ; } document . write ( " " + principal + " " ) ; document . write ( " " + secondary ) ; }
let a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] ; printDiagonalSums ( a , 4 ) ;
function getBoundarySum ( a , m , n ) { let sum = 0 ; for ( let i = 0 ; i < m ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) { if ( i == 0 ) sum += a [ i ] [ j ] ; else if ( i == m - 1 ) sum += a [ i ] [ j ] ; else if ( j == 0 ) sum += a [ i ] [ j ] ; else if ( j == n - 1 ) sum += a [ i ] [ j ] ; } } return sum ; }
let a = [ [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] , [ 1 , 2 , 3 , 4 ] , [ 5 , 6 , 7 , 8 ] ] ; let sum = getBoundarySum ( a , 4 , 4 ) ; document . write ( " " + " " + sum ) ;
const MAX = 100 ; function printSpiral ( mat , r , c ) { let i , a = 0 , b = 2 ; let low_row = ( 0 > a ) ? 0 : a ; let low_column = ( 0 > b ) ? 0 : b - 1 ; let high_row = ( ( a + 1 ) >= r ) ? r - 1 : a + 1 ; let high_column = ( ( b + 1 ) >= c ) ? c - 1 : b + 1 ; while ( ( low_row > 0 - r && low_column > 0 - c ) ) { for ( i = low_column + 1 ; i <= high_column && i < c && low_row >= 0 ; ++ i ) document . write ( mat [ low_row ] [ i ] + " " ) ; low_row -= 1 ; for ( i = low_row + 2 ; i <= high_row && i < r && high_column < c ; ++ i ) document . write ( mat [ i ] [ high_column ] + " " ) ; high_column += 1 ; for ( i = high_column - 2 ; i >= low_column && i >= 0 && high_row < r ; -- i ) document . write ( mat [ high_row ] [ i ] + " " ) ; high_row += 1 ; for ( i = high_row - 2 ; i > low_row && i >= 0 && low_column >= 0 ; -- i ) document . write ( mat [ i ] [ low_column ] + " " ) ; low_column -= 1 ; } document . write ( " " ) ; }
let mat = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] ; let r = 3 , c = 3 ;
printSpiral ( mat , r , c ) ;
function difference ( arr , n ) {
let d1 = 0 , d2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( i == j ) d1 += arr [ i ] [ j ] ;
if ( i == n - j - 1 ) d2 += arr [ i ] [ j ] ; } }
return Math . abs ( d1 - d2 ) ; }
let n = 3 ; let arr = [ [ 11 , 2 , 4 ] , [ 4 , 5 , 6 ] , [ 10 , 8 , - 12 ] ] ; document . write ( difference ( arr , n ) ) ;
function difference ( arr , n ) {
let d1 = 0 , d2 = 0 ; for ( let i = 0 ; i < n ; i ++ ) { d1 += arr [ i ] [ i ] ; d2 += arr [ i ] [ n - i - 1 ] ; }
return Math . abs ( d1 - d2 ) ; }
let n = 3 ; let arr = [ [ 11 , 2 , 4 ] , [ 4 , 5 , 6 ] , [ 10 , 8 , - 12 ] ] ; document . write ( difference ( arr , n ) ) ;
function spiralFill ( m , n , a ) {
let val = 1 ;
let k = 0 , l = 0 ; while ( k < m && l < n ) {
for ( let i = l ; i < n ; ++ i ) a [ k ] [ i ] = val ++ ; k ++ ;
for ( let i = k ; i < m ; ++ i ) a [ i ] [ n - 1 ] = val ++ ; n -- ;
if ( k < m ) { for ( let i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = val ++ ; m -- ; }
if ( l < n ) { for ( let i = m - 1 ; i >= k ; -- i ) a [ i ] [ l ] = val ++ ; l ++ ; } } }
let m = 4 , n = 4 ; let a = Array . from ( Array ( MAX ) , ( ) => new Array ( MAX ) ) ; spiralFill ( m , n , a ) ; for ( let i = 0 ; i < m ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) document . write ( a [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
let MAX = 100 ;
function maxMin ( arr , n ) { let min = + 2147483647 ; let max = - 2147483648 ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j <= n / 2 ; j ++ ) {
if ( arr [ i ] [ j ] > arr [ i ] [ n - j - 1 ] ) { if ( min > arr [ i ] [ n - j - 1 ] ) min = arr [ i ] [ n - j - 1 ] ; if ( max < arr [ i ] [ j ] ) max = arr [ i ] [ j ] ; } else { if ( min > arr [ i ] [ j ] ) min = arr [ i ] [ j ] ; if ( max < arr [ i ] [ n - j - 1 ] ) max = arr [ i ] [ n - j - 1 ] ; } } } document . write ( " " + max + " " + min ) ; }
let arr = [ [ 5 , 9 , 11 ] , [ 25 , 0 , 14 ] , [ 21 , 6 , 4 ] ] ; maxMin ( arr , 3 ) ;
var MAX = 100 ;
function findNormal ( mat , n ) { var sum = 0 ; for ( var i = 0 ; i < n ; i ++ ) for ( var j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] * mat [ i ] [ j ] ; return parseInt ( Math . sqrt ( sum ) ) ; }
function findTrace ( mat , n ) { var sum = 0 ; for ( var i = 0 ; i < n ; i ++ ) sum += mat [ i ] [ i ] ; return sum ; }
var mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] ; document . write ( " " + findTrace ( mat , 5 ) + " " ) ; document . write ( " " + findNormal ( mat , 5 ) ) ;
let N = 5 ; let M = 5 ;
function minOperation ( arr ) { let ans = 0 ; for ( let i = N - 1 ; i >= 0 ; i -- ) { for ( let j = M - 1 ; j >= 0 ; j -- ) {
if ( arr [ i ] [ j ] == false ) {
ans ++ ;
for ( let k = 0 ; k <= i ; k ++ ) { for ( let h = 0 ; h <= j ; h ++ ) {
if ( arr [ k ] [ h ] == true ) { arr [ k ] [ h ] = false ; } else { arr [ k ] [ h ] = true ; } } } } } } return ans ; }
let mat = [ [ 0 , 0 , 1 , 1 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] ] document . write ( minOperation ( mat ) )
function findSum ( n ) { let ans = 0 , temp = 0 , num ;
for ( let i = 1 ; i <= n && temp < n ; i ++ ) {
temp = i - 1 ;
num = 1 ; while ( temp < n ) { if ( temp + i <= n ) ans += ( i * num ) ; else ans += ( ( n - temp ) * num ) ; temp += i ; num ++ ; } } return ans ; }
let N = 2 ; document . write ( findSum ( N ) ) ;
function printCoils ( n ) {
let m = 8 * n * n ;
let coil1 = new Array ( m ) ; coil1 . fill ( 0 ) ;
coil1 [ 0 ] = 8 * n * n + 2 * n ; let curr = coil1 [ 0 ] ; let nflg = 1 , step = 2 ;
let index = 1 ; while ( index < m ) {
for ( let i = 0 ; i < step ; i ++ ) {
curr = coil1 [ index ++ ] = ( curr - 4 * n * nflg ) ; if ( index >= m ) break ; } if ( index >= m ) break ;
for ( let i = 0 ; i < step ; i ++ ) { curr = coil1 [ index ++ ] = curr + nflg ; if ( index >= m ) break ; } nflg = nflg * ( - 1 ) ; step += 2 ; }
let coil2 = new Array ( m ) ; coil2 . fill ( 0 ) ; for ( let i = 0 ; i < 8 * n * n ; i ++ ) coil2 [ i ] = 16 * n * n + 1 - coil1 [ i ] ;
document . write ( " " ) ; for ( let i = 0 ; i < 8 * n * n ; i ++ ) document . write ( coil1 [ i ] + " " ) ; document . write ( " " + " " ) ; for ( let i = 0 ; i < 8 * n * n ; i ++ ) document . write ( coil2 [ i ] + " " ) ; }
let n = 1 ; printCoils ( n ) ;
function findSum ( n ) {
let arr = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) { arr [ i ] = new Array ( n ) ; for ( let j = 0 ; j < n ; j ++ ) { arr [ i ] [ j ] = 0 ; } } for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = Math . abs ( i - j ) ;
let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) for ( let j = 0 ; j < n ; j ++ ) sum += arr [ i ] [ j ] ; return sum ; }
let n = 3 ; document . write ( findSum ( n ) ) ;
function findSum ( n ) { let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) sum += i * ( n - i ) ; return 2 * sum ; }
let n = 3 ; document . write ( findSum ( n ) ) ;
function findSum ( n ) { n -- ; let sum = 0 ; sum += ( n * ( n + 1 ) ) / 2 ; sum += ( n * ( n + 1 ) * ( 2 * n + 1 ) ) / 6 ; return sum ; }
let n = 3 ; document . write ( findSum ( n ) ) ;
function checkHV ( arr , N , M ) {
let horizontal = true ; let vertical = true ;
for ( let i = 0 , k = N - 1 ; i < parseInt ( N / 2 , 10 ) ; i ++ , k -- ) {
for ( let j = 0 ; j < M ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { horizontal = false ; break ; } } }
for ( let i = 0 , k = M - 1 ; i < parseInt ( M / 2 , 10 ) ; i ++ , k -- ) {
for ( let j = 0 ; j < N ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { horizontal = false ; break ; } } } if ( ! horizontal && ! vertical ) document . write ( " " ) ; else if ( horizontal && ! vertical ) document . write ( " " ) ; else if ( vertical && ! horizontal ) document . write ( " " ) ; else document . write ( " " ) ; }
let mat = [ [ 1 , 0 , 1 ] , [ 0 , 0 , 0 ] , [ 1 , 0 , 1 ] ] ; checkHV ( mat , 3 , 3 ) ;
function maxDet ( n ) { return ( 2 * n * n * n ) ; }
function resMatrix ( n ) { for ( let i = 0 ; i < 3 ; i ++ ) { for ( let j = 0 ; j < 3 ; j ++ ) {
if ( i == 0 && j == 2 ) document . write ( " " ) ; else if ( i == 1 && j == 0 ) document . write ( " " ) ; else if ( i == 2 && j == 1 ) document . write ( " " ) ;
else document . write ( n + " " ) ; } document . write ( " " ) ; } }
let n = 15 ; document . write ( " " + maxDet ( n ) + " " ) ; document . write ( " " ) ; resMatrix ( n ) ;
function spiralDiaSum ( n ) { if ( n == 1 ) return 1 ;
return ( 4 * n * n - 6 * n + 6 + spiralDiaSum ( n - 2 ) ) ; }
let n = 7 ; document . write ( spiralDiaSum ( n ) ) ;
let R = 3 ; let C = 5 ;
function numofneighbour ( mat , i , j ) { let count = 0 ;
if ( i > 0 && mat [ i - 1 ] [ j ] == 1 ) count ++ ;
if ( j > 0 && mat [ i ] [ j - 1 ] == 1 ) count ++ ;
if ( i < R - 1 && mat [ i + 1 ] [ j ] == 1 ) count ++ ;
if ( j < C - 1 && mat [ i ] [ j + 1 ] == 1 ) count ++ ; return count ; }
function findperimeter ( mat ) { let perimeter = 0 ;
for ( let i = 0 ; i < R ; i ++ ) for ( let j = 0 ; j < C ; j ++ ) if ( mat [ i ] [ j ] == 1 ) perimeter += ( 4 - numofneighbour ( mat , i , j ) ) ; return perimeter ; }
let mat = [ [ 0 , 1 , 0 , 0 , 0 ] , [ 1 , 1 , 1 , 0 , 0 ] , [ 1 , 0 , 0 , 0 , 0 ] ] ; document . write ( findperimeter ( mat ) ) ;
function printMatrixDiagonal ( arr , len ) {
let i = 0 , j = 0 ;
let isUp = true ;
for ( let k = 0 ; k < len * len ; ) {
if ( isUp ) { for ( ; i >= 0 && j < len ; i -- , j ++ ) { document . write ( arr [ i ] [ j ] + ' ' ) ; k ++ ; }
if ( i < 0 && j < len ) i = 0 ; if ( j === len ) i = i + 2 , j -- ; }
else { for ( ; j >= 0 && i < len ; i ++ , j -- ) { document . write ( arr [ i ] [ j ] + ' ' ) ; k ++ ; }
if ( j < 0 && i < len ) j = 0 ; if ( i === len ) j = j + 2 , i -- ; }
isUp = ! isUp } }
let arr = [ [ 1 , 2 , 3 ] , [ 4 , 5 , 6 ] , [ 7 , 8 , 9 ] ] ; let arrLength = arr . length ; printMatrixDiagonal ( arr , arrLength ) ;
function maxRowDiff ( mat , m , n ) {
let rowSum = new Array ( m ) ;
for ( let i = 0 ; i < m ; i ++ ) { let sum = 0 ; for ( let j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] ; rowSum [ i ] = sum ; }
let max_diff = rowSum [ 1 ] - rowSum [ 0 ] ; let min_element = rowSum [ 0 ] ; for ( let i = 1 ; i < m ; i ++ ) {
if ( rowSum [ i ] - min_element > max_diff ) max_diff = rowSum [ i ] - min_element ;
if ( rowSum [ i ] < min_element ) min_element = rowSum [ i ] ; } return max_diff ; }
let m = 5 , n = 4 ; let mat = [ [ - 1 , 2 , 3 , 4 ] , [ 5 , 3 , - 2 , 1 ] , [ 6 , 7 , 2 , - 3 ] , [ 2 , 9 , 1 , 4 ] , [ 2 , 1 , - 2 , 0 ] ] ; document . write ( maxRowDiff ( mat , m , n ) ) ;
let MAX = 100 ;
function sortedCount ( mat , r , c ) {
let result = 0 ;
for ( let i = 0 ; i < r ; i ++ ) {
let j ; for ( j = 0 ; j < c - 1 ; j ++ ) if ( mat [ i ] [ j + 1 ] <= mat [ i ] [ j ] ) break ;
if ( j == c - 1 ) result ++ ; }
for ( let i = 0 ; i < r ; i ++ ) {
let j ; for ( j = c - 1 ; j > 0 ; j -- ) if ( mat [ i ] [ j - 1 ] <= mat [ i ] [ j ] ) break ;
if ( c > 1 && j == 0 ) result ++ ; } return result ; }
let m = 4 , n = 5 ; let mat = [ [ 1 , 2 , 3 , 4 , 5 ] , [ 4 , 3 , 1 , 2 , 6 ] , [ 8 , 7 , 6 , 5 , 4 ] , [ 5 , 7 , 8 , 9 , 10 ] ] document . write ( sortedCount ( mat , m , n ) )
const MAX = 1000 ;
function maxXOR ( mat , N ) {
let r_xor , c_xor ; let max_xor = 0 ;
for ( let i = 0 ; i < N ; i ++ ) { r_xor = 0 , c_xor = 0 ; for ( let j = 0 ; j < N ; j ++ ) {
r_xor = r_xor ^ mat [ i ] [ j ] ;
c_xor = c_xor ^ mat [ j ] [ i ] ; }
if ( max_xor < Math . max ( r_xor , c_xor ) ) max_xor = Math . max ( r_xor , c_xor ) ; }
return max_xor ; }
let N = 3 ; let mat = [ [ 1 , 5 , 4 ] , [ 3 , 7 , 2 ] , [ 5 , 9 , 10 ] ] ; document . write ( " " + maxXOR ( mat , N ) ) ;
function direction ( R , C ) { if ( R != C && R % 2 == 0 && C % 2 != 0 && R < C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R > C ) { document . write ( " " ) ; return ; } if ( R == C && R % 2 != 0 && C % 2 != 0 ) { document . write ( " " ) ; return ; } if ( R == C && R % 2 == 0 && C % 2 == 0 ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R < C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R > C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R < C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R > C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 != 0 && R > C ) { document . write ( " " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R < C ) { document . write ( " " ) ; return ; } }
let R = 3 , C = 1 ; direction ( R , C ) ;
function checkDiagonal ( mat , i , j ) { let res = mat [ i ] [ j ] ; while ( ++ i < N && ++ j < M ) {
if ( mat [ i ] [ j ] != res ) return false ; }
return true ; }
function isToepliz ( mat ) {
for ( let i = 0 ; i < M ; i ++ ) {
if ( ! checkDiagonal ( mat , 0 , i ) ) return false ; }
for ( let i = 1 ; i < N ; i ++ ) {
if ( ! checkDiagonal ( mat , i , 0 ) ) return false ; }
return true ; }
let mat = [ [ 6 , 7 , 8 , 9 ] , [ 4 , 6 , 7 , 8 ] , [ 1 , 4 , 6 , 7 ] , [ 0 , 1 , 4 , 6 ] , [ 2 , 0 , 1 , 4 ] ] ;
if ( isToepliz ( mat ) ) document . write ( " " ) ; else document . write ( " " ) ;
let N = 5 ;
function countZeroes ( mat ) {
let row = N - 1 , col = 0 ;
let count = 0 ; while ( col < N ) {
while ( mat [ row ] [ col ] > 0 )
if ( -- row < 0 ) return count ;
count += ( row + 1 ) ;
col ++ ; } return count ; }
let mat = [ [ 0 , 0 , 0 , 0 , 1 ] , [ 0 , 0 , 0 , 1 , 1 ] , [ 0 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 ] ] ; document . write ( countZeroes ( mat ) ) ;
function countNegative ( M , n , m ) { let count = 0 ;
for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < m ; j ++ ) { if ( M [ i ] [ j ] < 0 ) count += 1 ;
else break ; } } return count ; }
let M = [ [ - 3 , - 2 , - 1 , 1 ] , [ - 2 , 2 , 3 , 4 ] , [ 4 , 5 , 7 , 8 ] ] ; document . write ( countNegative ( M , 3 , 4 ) ) ;
function countNegative ( M , n , m ) {
let count = 0 ;
let i = 0 ; let j = m - 1 ;
while ( j >= 0 && i < n ) { if ( M [ i ] [ j ] < 0 ) {
count += j + 1 ;
i += 1 ; }
else j -= 1 ; } return count ; } `
let M = [ [ - 3 , - 2 , - 1 , 1 ] , [ - 2 , 2 , 3 , 4 ] , [ 4 , 5 , 7 , 8 ] ] ; document . write ( countNegative ( M , 3 , 4 ) ) ;
let N = 10 ;
function findLargestPlus ( mat ) {
let left = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { left [ i ] = new Array ( N ) ; } let right = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { right [ i ] = new Array ( N ) ; } let top = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { top [ i ] = new Array ( N ) ; } let bottom = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { bottom [ i ] = new Array ( N ) ; } for ( let i = 0 ; i < N ; i ++ ) { for ( let j = 0 ; j < N ; j ++ ) { left [ i ] [ j ] = 0 ; right [ i ] [ j ] = 0 ; top [ i ] [ j ] = 0 ; bottom [ i ] [ j ] = 0 ; } }
for ( let i = 0 ; i < N ; i ++ ) {
top [ 0 ] [ i ] = mat [ 0 ] [ i ] ;
bottom [ N - 1 ] [ i ] = mat [ N - 1 ] [ i ] ;
left [ i ] [ 0 ] = mat [ i ] [ 0 ] ;
right [ i ] [ N - 1 ] = mat [ i ] [ N - 1 ] ; }
for ( let i = 0 ; i < N ; i ++ ) { for ( let j = 1 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] == 1 ) left [ i ] [ j ] = left [ i ] [ j - 1 ] + 1 ; else left [ i ] [ j ] = 0 ;
if ( mat [ j ] [ i ] == 1 ) top [ j ] [ i ] = top [ j - 1 ] [ i ] + 1 ; else top [ j ] [ i ] = 0 ;
j = N - 1 - j ;
if ( mat [ j ] [ i ] == 1 ) bottom [ j ] [ i ] = bottom [ j + 1 ] [ i ] + 1 ; else bottom [ j ] [ i ] = 0 ;
if ( mat [ i ] [ j ] == 1 ) right [ i ] [ j ] = right [ i ] [ j + 1 ] + 1 ; else right [ i ] [ j ] = 0 ;
j = N - 1 - j ; } }
let n = 0 ;
for ( let i = 0 ; i < N ; i ++ ) { for ( let j = 0 ; j < N ; j ++ ) {
let len = Math . min ( Math . min ( top [ i ] [ j ] , bottom [ i ] [ j ] ) , Math . min ( left [ i ] [ j ] , right [ i ] [ j ] ) ) ;
if ( len > n ) n = len ; } }
if ( n > 0 ) return 4 * ( n - 1 ) + 1 ;
return 0 ; }
let mat = [ [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 ] , [ 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 ] , [ 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 ] , [ 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 ] , [ 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 ] , [ 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 ] , [ 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 ] , [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 ] , [ 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 ] , [ 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 ] ] document . write ( findLargestPlus ( mat ) ) ;
function findLeft ( str ) { let n = str . length ;
while ( n > 0 ) { n -- ;
if ( str [ n ] == ' ' ) { str = str . replaceAt ( n , ' ' ) ; break ; } if ( str [ n ] == ' ' ) { str = str . replaceAt ( n , ' ' ) ; break ; }
if ( str [ n ] == ' ' ) str = str . replaceAt ( n , ' ' ) ; else if ( str [ n ] == ' ' ) str = str . replaceAt ( n , ' ' ) ; } return str ; }
let str = " " ; document . write ( " " + str + " " + findLeft ( str ) ) ;
function printSpiral ( n ) { for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
let x ;
x = Math . min ( Math . min ( i , j ) , Math . min ( n - 1 - i , n - 1 - j ) ) ;
if ( i <= j ) document . write ( ` ${ ( n - 2 * x ) * ( n - 2 * x ) - ( i - x ) - ( j - x ) } ` ) ;
else document . write ( ` ${ ( n - 2 * x - 2 ) * ( n - 2 * x - 2 ) + ( i - x ) + ( j - x ) } ` ) ; } document . write ( " " ) ; } }
let n = 5 ;
printSpiral ( n ) ;
function findMaxValue ( N , mat ) {
let maxValue = Number . MIN_VALUE ;
for ( let a = 0 ; a < N - 1 ; a ++ ) for ( let b = 0 ; b < N - 1 ; b ++ ) for ( let d = a + 1 ; d < N ; d ++ ) for ( let e = b + 1 ; e < N ; e ++ ) if ( maxValue < ( mat [ d ] [ e ] - mat [ a ] [ b ] ) ) maxValue = mat [ d ] [ e ] - mat [ a ] [ b ] ; return maxValue ; }
let N = 5 ; let mat = [ [ 1 , 2 , - 1 , - 4 , - 20 ] , [ - 8 , - 3 , 4 , 2 , 1 ] , [ 3 , 8 , 6 , 1 , 3 ] , [ - 4 , - 1 , 1 , 7 , - 6 ] , [ 0 , - 4 , 10 , - 5 , 1 ] ] ; document . write ( " " + findMaxValue ( N , mat ) ) ;
function findMaxValue ( N , mat ) {
let maxValue = Number . MIN_VALUE ;
let maxArr = new Array ( N ) ; for ( let i = 0 ; i < N ; i ++ ) { maxArr [ i ] = new Array ( N ) ; }
maxArr [ N - 1 ] [ N - 1 ] = mat [ N - 1 ] [ N - 1 ] ;
let maxv = mat [ N - 1 ] [ N - 1 ] ; for ( let j = N - 2 ; j >= 0 ; j -- ) { if ( mat [ N - 1 ] [ j ] > maxv ) maxv = mat [ N - 1 ] [ j ] ; maxArr [ N - 1 ] [ j ] = maxv ; }
maxv = mat [ N - 1 ] [ N - 1 ] ; for ( let i = N - 2 ; i >= 0 ; i -- ) { if ( mat [ i ] [ N - 1 ] > maxv ) maxv = mat [ i ] [ N - 1 ] ; maxArr [ i ] [ N - 1 ] = maxv ; }
for ( let i = N - 2 ; i >= 0 ; i -- ) { for ( let j = N - 2 ; j >= 0 ; j -- ) {
if ( maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] > maxValue ) maxValue = maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] ;
maxArr [ i ] [ j ] = Math . max ( mat [ i ] [ j ] , Math . max ( maxArr [ i ] [ j + 1 ] , maxArr [ i + 1 ] [ j ] ) ) ; } } return maxValue ; }
let N = 5 ; let mat = [ [ 1 , 2 , - 1 , - 4 , - 20 ] , [ - 8 , - 3 , 4 , 2 , 1 ] , [ 3 , 8 , 6 , 1 , 3 ] , [ - 4 , - 1 , 1 , 7 , - 6 ] , [ 0 , - 4 , 10 , - 5 , 1 ] ] ; document . write ( " " + findMaxValue ( N , mat ) ) ;
function modifyMatrix ( mat , R , C ) { let row = new Array ( R ) ; let col = new Array ( C ) ;
for ( i = 0 ; i < R ; i ++ ) { row [ i ] = 0 ; }
for ( i = 0 ; i < C ; i ++ ) { col [ i ] = 0 ; }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( mat [ i ] [ j ] == 1 ) { row [ i ] = 1 ; col [ j ] = 1 ; } } }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( row [ i ] == 1 col [ j ] == 1 ) { mat [ i ] [ j ] = 1 ; } } } }
function printMatrix ( mat , R , C ) { let i , j ; for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { document . write ( mat [ i ] [ j ] + " " ) ; } document . write ( " " ) ; } }
let mat = [ [ 1 , 0 , 0 , 1 ] , [ 0 , 0 , 1 , 0 ] , [ 0 , 0 , 0 , 0 ] ] ; document . write ( " " ) printMatrix ( mat , 3 , 4 ) ; modifyMatrix ( mat , 3 , 4 ) ; document . write ( " " ) ; printMatrix ( mat , 3 , 4 ) ;
var R = 3 ; var C = 3 ;
function swap ( mat , row1 , row2 , col ) { for ( i = 0 ; i < col ; i ++ ) { var temp = mat [ row1 ] [ i ] ; mat [ row1 ] [ i ] = mat [ row2 ] [ i ] ; mat [ row2 ] [ i ] = temp ; } }
function rankOfMatrix ( mat ) { var rank = C ; for ( row = 0 ; row < rank ; row ++ ) {
if ( mat [ row ] [ row ] != 0 ) { for ( col = 0 ; col < R ; col ++ ) { if ( col != row ) {
var mult = mat [ col ] [ row ] / mat [ row ] [ row ] ; for ( i = 0 ; i < rank ; i ++ ) mat [ col ] [ i ] -= mult * mat [ row ] [ i ] ; } } }
else { reduce = true ;
for ( var i = row + 1 ; i < R ; i ++ ) {
if ( mat [ i ] [ row ] != 0 ) { swap ( mat , row , i , rank ) ; reduce = false ; break ; } }
if ( reduce ) {
rank -- ;
for ( i = 0 ; i < R ; i ++ ) mat [ i ] [ row ] = mat [ i ] [ rank ] ; }
row -- ; }
} return rank ; }
function display ( mat , row , col ) { for ( i = 0 ; i < row ; i ++ ) { for ( j = 0 ; j < col ; j ++ ) document . write ( " " + mat [ i ] [ j ] ) ; document . write ( ' ' ) ; } }
var mat = [ [ 10 , 20 , 10 ] , [ - 20 , - 30 , 10 ] , [ 30 , 50 , 0 ] ] ; document . write ( " " + rankOfMatrix ( mat ) ) ;
function countIslands ( mat , m , n ) {
let count = 0 ;
for ( let i = 0 ; i < m ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) {
if ( mat [ i ] [ j ] == ' ' ) { if ( ( i == 0 mat [ i - 1 ] [ j ] == ' ' ) && ( j == 0 mat [ i ] [ j - 1 ] == ' ' ) ) count ++ ; } } } return count ; }
let m = 6 ; let n = 3 ; let mat = [ [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] ] ; document . write ( " " + countIslands ( mat , m , n ) ) ;
let M = 6 ; let N = 6 ;
function floodFillUtil ( mat , x , y , prevV , newV ) {
if ( x < 0 x >= M y < 0 y >= N ) return ; if ( mat [ x ] [ y ] != prevV ) return ;
mat [ x ] [ y ] = newV ;
floodFillUtil ( mat , x + 1 , y , prevV , newV ) ; floodFillUtil ( mat , x - 1 , y , prevV , newV ) ; floodFillUtil ( mat , x , y + 1 , prevV , newV ) ; floodFillUtil ( mat , x , y - 1 , prevV , newV ) ; }
function replaceSurrounded ( mat ) {
for ( let i = 0 ; i < M ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' ' ) mat [ i ] [ j ] = ' ' ;
for ( let i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ 0 ] == ' ' ) floodFillUtil ( mat , i , 0 , ' ' , ' ' ) ;
for ( let i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ N - 1 ] == ' ' ) floodFillUtil ( mat , i , N - 1 , ' ' , ' ' ) ;
for ( let i = 0 ; i < N ; i ++ ) if ( mat [ 0 ] [ i ] == ' ' ) floodFillUtil ( mat , 0 , i , ' ' , ' ' ) ;
for ( let i = 0 ; i < N ; i ++ ) if ( mat [ M - 1 ] [ i ] == ' ' ) floodFillUtil ( mat , M - 1 , i , ' ' , ' ' ) ;
for ( let i = 0 ; i < M ; i ++ ) for ( let j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' ' ) mat [ i ] [ j ] = ' ' ; }
let mat = [ [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] ] ; replaceSurrounded ( mat ) ; for ( let i = 0 ; i < M ; i ++ ) { for ( let j = 0 ; j < N ; j ++ ) document . write ( mat [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
let n = 5 ;
function printSumSimple ( mat , k ) {
if ( k > n ) return ;
for ( let i = 0 ; i < n - k + 1 ; i ++ ) {
for ( let j = 0 ; j < n - k + 1 ; j ++ ) {
let sum = 0 ; for ( let p = i ; p < k + i ; p ++ ) for ( let q = j ; q < k + j ; q ++ ) sum += mat [ p ] [ q ] ; document . write ( sum + " " ) ; }
document . write ( " " ) ; } }
let mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] let k = 3 ; printSumSimple ( mat , k ) ;
let n = 5 ;
function printSumTricky ( mat , k ) {
if ( k > n ) return ;
let stripSum = new Array ( n ) ; for ( let i = 0 ; i < n ; i ++ ) { stripSum [ i ] = new Array ( n ) ; } for ( let i = 0 ; i < n ; i ++ ) { for ( let j = 0 ; j < n ; j ++ ) { stripSum [ i ] [ j ] = 0 ; } }
for ( let j = 0 ; j < n ; j ++ ) {
let sum = 0 ; for ( let i = 0 ; i < k ; i ++ ) sum += mat [ i ] [ j ] ; stripSum [ 0 ] [ j ] = sum ;
for ( let i = 1 ; i < n - k + 1 ; i ++ ) { sum += ( mat [ i + k - 1 ] [ j ] - mat [ i - 1 ] [ j ] ) ; stripSum [ i ] [ j ] = sum ; } }
for ( let i = 0 ; i < n - k + 1 ; i ++ ) {
let sum = 0 ; for ( let j = 0 ; j < k ; j ++ ) sum += stripSum [ i ] [ j ] ; document . write ( sum + " " ) ;
for ( let j = 1 ; j < n - k + 1 ; j ++ ) { sum += ( stripSum [ i ] [ j + k - 1 ] - stripSum [ i ] [ j - 1 ] ) ; document . write ( sum + " " ) ; } document . write ( " " ) ; } }
let mat = [ [ 1 , 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 , 4 ] , [ 5 , 5 , 5 , 5 , 5 ] ] ; let k = 3 ; printSumTricky ( mat , k ) ;
var M = 3 ; var N = 4 ;
function transpose ( A , B ) { var i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < M ; j ++ ) B [ i ] [ j ] = A [ j ] [ i ] ; }
var A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] ] ; var B = Array ( N ) ; for ( i = 0 ; i < N ; i ++ ) B [ i ] = Array ( M ) . fill ( 0 ) ; transpose ( A , B ) ; document . write ( " " ) ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < M ; j ++ ) document . write ( B [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
var N = 4 ;
function transpose ( A ) { for ( i = 0 ; i < N ; i ++ ) for ( j = i + 1 ; j < N ; j ++ ) { var temp = A [ i ] [ j ] ; A [ i ] [ j ] = A [ j ] [ i ] ; A [ j ] [ i ] = temp ; } }
var A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] ; transpose ( A ) ; document . write ( " " ) ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < N ; j ++ ) document . write ( A [ i ] [ j ] + " " ) ; document . write ( " \< " ) ; }
let R = 3 ; let C = 3 ;
function pathCountRec ( mat , m , n , k ) {
if ( m < 0 n < 0 ) return 0 ; if ( m == 0 && n == 0 ) return ( k == mat [ m ] [ n ] ) ;
return pathCountRec ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountRec ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; }
function pathCount ( mat , k ) { return pathCountRec ( mat , R - 1 , C - 1 , k ) ; }
let k = 12 ; let mat = [ [ 1 , 2 , 3 ] , [ 4 , 6 , 5 ] , [ 3 , 2 , 1 ] ] ; document . write ( pathCount ( mat , k ) ) ;
let x = [ 0 , 1 , 1 , - 1 , 1 , 0 , - 1 , - 1 ] ; let y = [ 1 , 0 , 1 , 1 , - 1 , - 1 , 0 , - 1 ] ; let R = 3 ; let C = 3 ;
let dp = new Array ( R ) ; for ( let i = 0 ; i < R ; i ++ ) { dp [ i ] = new Array ( C ) ; for ( let j = 0 ; j < C ; j ++ ) { dp [ i ] [ j ] = 0 ; } }
function isvalid ( i , j ) { if ( i < 0 j < 0 i >= R j >= C ) return false ; return true ; }
function isadjacent ( prev , curr ) { return ( ( curr . charCodeAt ( ) - prev . charCodeAt ( ) ) == 1 ) ; }
function getLenUtil ( mat , i , j , prev ) {
if ( ! isvalid ( i , j ) || ! isadjacent ( prev , mat [ i ] [ j ] ) ) return 0 ;
if ( dp [ i ] [ j ] != - 1 ) return dp [ i ] [ j ] ;
let ans = 0 ;
for ( let k = 0 ; k < 8 ; k ++ ) ans = Math . max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , mat [ i ] [ j ] ) ) ;
return dp [ i ] [ j ] = ans ; }
function getLen ( mat , s ) { for ( let i = 0 ; i < R ; ++ i ) for ( let j = 0 ; j < C ; ++ j ) dp [ i ] [ j ] = - 1 ; let ans = 0 ; for ( let i = 0 ; i < R ; i ++ ) { for ( let j = 0 ; j < C ; j ++ ) {
if ( mat [ i ] [ j ] == s ) {
for ( let k = 0 ; k < 8 ; k ++ ) ans = Math . max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , s ) ) ; } } } return ans ; }
let mat = [ [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] , [ ' ' , ' ' , ' ' ] ] ; document . write ( getLen ( mat , ' ' ) + " " ) ; document . write ( getLen ( mat , ' ' ) + " " ) ; document . write ( getLen ( mat , ' ' ) + " " ) ; document . write ( getLen ( mat , ' ' ) ) ;
