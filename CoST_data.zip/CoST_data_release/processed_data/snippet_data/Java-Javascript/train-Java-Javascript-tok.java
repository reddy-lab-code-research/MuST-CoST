class Node { int key ; Node left , right ; public Node ( int item ) { key = item ; left = right = null ; } }
import java . util . * ; class GFG { static Vector < Integer > no_NGN ( int arr [ ] , int n ) { Vector < Integer > nxt = new Vector < > ( ) ;
Stack < Integer > s = new Stack < > ( ) ; nxt . add ( 0 ) ;
s . add ( n - 1 ) ;
for ( int i = n - 2 ; i >= 0 ; i -- ) { while ( ! s . isEmpty ( ) && arr [ i ] >= arr [ s . peek ( ) ] ) s . pop ( ) ;
if ( s . isEmpty ( ) ) nxt . add ( 0 ) ; else
nxt . add ( nxt . get ( n - s . peek ( ) - 1 ) + 1 ) ; s . add ( i ) ; }
Collections . reverse ( nxt ) ;
return nxt ; }
public static void main ( String [ ] args ) { int n = 8 ; int arr [ ] = { 3 , 4 , 2 , 7 , 5 , 8 , 10 , 6 } ; Vector < Integer > nxt = no_NGN ( arr , n ) ;
System . out . print ( nxt . get ( 3 ) + "NEW_LINE");
System . out . print ( nxt . get ( 6 ) + "NEW_LINE");
System . out . print ( nxt . get ( 1 ) + "NEW_LINE"); } }
static Stack < Integer > sortStack ( Stack < Integer > input ) { Stack < Integer > tmpStack = new Stack < Integer > ( ) ; while ( ! input . empty ( ) ) {
int tmp = input . peek ( ) ; input . pop ( ) ;
while ( ! tmpStack . empty ( ) && tmpStack . peek ( ) < tmp ) {
input . push ( tmpStack . peek ( ) ) ; tmpStack . pop ( ) ; }
tmpStack . push ( tmp ) ; } return tmpStack ; } static void sortArrayUsingStacks ( int [ ] arr , int n ) {
Stack < Integer > input = new Stack < Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) input . push ( arr [ i ] ) ;
Stack < Integer > tmpStack = sortStack ( input ) ;
for ( int i = 0 ; i < n ; i ++ ) { arr [ i ] = tmpStack . peek ( ) ; tmpStack . pop ( ) ; } }
public static void main ( String args [ ] ) { int [ ] arr = { 10 , 5 , 15 , 45 } ; int n = arr . length ; sortArrayUsingStacks ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
import java . util . * ; import java . io . * ; import java . math . * ; class GFG { static void towerOfHanoi ( int n , char from_rod , char to_rod , char aux_rod ) { if ( n == 1 ) { System . out . println ( " Move ▁ disk ▁ 1 ▁ from ▁ rod ▁ " + from_rod + " ▁ to ▁ rod ▁ " + to_rod ) ; return ; } towerOfHanoi ( n - 1 , from_rod , aux_rod , to_rod ) ; System . out . println ( " Move ▁ disk ▁ " + n + " ▁ from ▁ rod ▁ " + from_rod + " ▁ to ▁ rod ▁ " + to_rod ) ; towerOfHanoi ( n - 1 , aux_rod , to_rod , from_rod ) ; }
int n = 4 ;
towerOfHanoi ( n , ' A ' , ' C ' , ' B ' ) ; } }
class Test { static int arr [ ] = { 10 , 20 , 30 , 50 , 10 , 70 , 30 } ; static void printMaxOfMin ( int n ) {
for ( int k = 1 ; k <= n ; k ++ ) {
int maxOfMin = Integer . MIN_VALUE ;
for ( int i = 0 ; i <= n - k ; i ++ ) {
int min = arr [ i ] ; for ( int j = 1 ; j < k ; j ++ ) { if ( arr [ i + j ] < min ) min = arr [ i + j ] ; }
if ( min > maxOfMin ) maxOfMin = min ; }
System . out . print ( maxOfMin + " ▁ " ) ; } }
public static void main ( String [ ] args ) { printMaxOfMin ( arr . length ) ; } }
import java . util . Stack ; class Test { static int arr [ ] = { 10 , 20 , 30 , 50 , 10 , 70 , 30 } ; static void printMaxOfMin ( int n ) {
Stack < Integer > s = new Stack < > ( ) ;
int left [ ] = new int [ n + 1 ] ; int right [ ] = new int [ n + 1 ] ;
for ( int i = 0 ; i < n ; i ++ ) { left [ i ] = - 1 ; right [ i ] = n ; }
for ( int i = 0 ; i < n ; i ++ ) { while ( ! s . empty ( ) && arr [ s . peek ( ) ] >= arr [ i ] ) s . pop ( ) ; if ( ! s . empty ( ) ) left [ i ] = s . peek ( ) ; s . push ( i ) ; }
while ( ! s . empty ( ) ) s . pop ( ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) { while ( ! s . empty ( ) && arr [ s . peek ( ) ] >= arr [ i ] ) s . pop ( ) ; if ( ! s . empty ( ) ) right [ i ] = s . peek ( ) ; s . push ( i ) ; }
int ans [ ] = new int [ n + 1 ] ; for ( int i = 0 ; i <= n ; i ++ ) ans [ i ] = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int len = right [ i ] - left [ i ] - 1 ;
ans [ len ] = Math . max ( ans [ len ] , arr [ i ] ) ; }
for ( int i = n - 1 ; i >= 1 ; i -- ) ans [ i ] = Math . max ( ans [ i ] , ans [ i + 1 ] ) ;
for ( int i = 1 ; i <= n ; i ++ ) System . out . print ( ans [ i ] + " ▁ " ) ; }
public static int solve ( String s , int n ) {
int left = 0 , right = 0 ; int maxlength = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( s . charAt ( i ) == ' ( ' ) left ++ ; else right ++ ;
if ( left == right ) maxlength = Math . max ( maxlength , 2 * right ) ;
else if ( right > left ) left = right = 0 ; } left = right = 0 ;
for ( int i = n - 1 ; i >= 0 ; i -- ) {
if ( s . charAt ( i ) == ' ( ' ) left ++ ; else right ++ ;
if ( left == right ) maxlength = Math . max ( maxlength , 2 * left ) ;
else if ( left > right ) left = right = 0 ; } return maxlength ; }
System . out . print ( solve ( " ( ( ( ) ( ) ( ) ( ) ( ( ( ( ) ) " , 16 ) ) ; } }
import java . io . * ; import java . util . * ; public class GFG { static void printLeast ( String arr ) {
int min_avail = 1 , pos_of_I = 0 ;
ArrayList < Integer > al = new ArrayList < > ( ) ;
if ( arr . charAt ( 0 ) == ' I ' ) { al . add ( 1 ) ; al . add ( 2 ) ; min_avail = 3 ; pos_of_I = 1 ; } else { al . add ( 2 ) ; al . add ( 1 ) ; min_avail = 3 ; pos_of_I = 0 ; }
for ( int i = 1 ; i < arr . length ( ) ; i ++ ) { if ( arr . charAt ( i ) == ' I ' ) { al . add ( min_avail ) ; min_avail ++ ; pos_of_I = i + 1 ; } else { al . add ( al . get ( i ) ) ; for ( int j = pos_of_I ; j <= i ; j ++ ) al . set ( j , al . get ( j ) + 1 ) ; min_avail ++ ; } }
for ( int i = 0 ; i < al . size ( ) ; i ++ ) System . out . print ( al . get ( i ) + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String args [ ] ) { printLeast ( " IDID " ) ; printLeast ( " I " ) ; printLeast ( " DD " ) ; printLeast ( " II " ) ; printLeast ( " DIDI " ) ; printLeast ( " IIDDD " ) ; printLeast ( " DDIDDIID " ) ; } }
static void PrintMinNumberForPattern ( String seq ) {
String result = " " ;
Stack < Integer > stk = new Stack < Integer > ( ) ;
for ( int i = 0 ; i <= seq . length ( ) ; i ++ ) {
stk . push ( i + 1 ) ;
if ( i == seq . length ( ) || seq . charAt ( i ) == ' I ' ) {
while ( ! stk . empty ( ) ) {
result += String . valueOf ( stk . peek ( ) ) ; result += " ▁ " ; stk . pop ( ) ; } } } System . out . println ( result ) ; }
public static void main ( String [ ] args ) { PrintMinNumberForPattern ( " IDID " ) ; PrintMinNumberForPattern ( " I " ) ; PrintMinNumberForPattern ( " DD " ) ; PrintMinNumberForPattern ( " II " ) ; PrintMinNumberForPattern ( " DIDI " ) ; PrintMinNumberForPattern ( " IIDDD " ) ; PrintMinNumberForPattern ( " DDIDDIID " ) ; } }
static String getMinNumberForPattern ( String seq ) { int n = seq . length ( ) ; if ( n >= 9 ) return " - 1" ; char result [ ] = new char [ n + 1 ] ; int count = 1 ;
for ( int i = 0 ; i <= n ; i ++ ) { if ( i == n || seq . charAt ( i ) == ' I ' ) { for ( int j = i - 1 ; j >= - 1 ; j -- ) { result [ j + 1 ] = ( char ) ( ( int ) '0' + count ++ ) ; if ( j >= 0 && seq . charAt ( j ) == ' I ' ) break ; } } } return new String ( result ) ; }
public static void main ( String [ ] args ) throws IOException { String inputs [ ] = { " IDID " , " I " , " DD " , " II " , " DIDI " , " IIDDD " , " DDIDDIID " } ; for ( String input : inputs ) { System . out . println ( getMinNumberForPattern ( input ) ) ; } } }
public static void nextGreater ( int arr [ ] , int next [ ] , char order ) {
Stack < Integer > stack = new Stack < > ( ) ;
for ( int i = arr . length - 1 ; i >= 0 ; i -- ) {
while ( ! stack . isEmpty ( ) && ( ( order == ' G ' ) ? arr [ stack . peek ( ) ] <= arr [ i ] : arr [ stack . peek ( ) ] >= arr [ i ] ) ) stack . pop ( ) ;
if ( ! stack . isEmpty ( ) ) next [ i ] = stack . peek ( ) ;
else next [ i ] = - 1 ;
stack . push ( i ) ; } }
public static void nextSmallerOfNextGreater ( int arr [ ] ) {
int NG [ ] = new int [ arr . length ] ;
int RS [ ] = new int [ arr . length ] ;
nextGreater ( arr , NG , ' G ' ) ;
nextGreater ( arr , RS , ' S ' ) ;
for ( int i = 0 ; i < arr . length ; i ++ ) { if ( NG [ i ] != - 1 && RS [ NG [ i ] ] != - 1 ) System . out . print ( arr [ RS [ NG [ i ] ] ] + " ▁ " ) ; else System . out . print ( " - 1 ▁ " ) ; } }
public static void main ( String args [ ] ) { int arr [ ] = { 5 , 1 , 9 , 2 , 5 , 1 , 7 } ; nextSmallerOfNextGreater ( arr ) ; } }
class Node { int data ; Node left , right ; Node ( int data ) { this . data = data ; } } ;
public static Node flipBinaryTree ( Node root ) { if ( root == null ) return root ; if ( root . left == null && root . right == null ) return root ;
Node flippedRoot = flipBinaryTree ( root . left ) ;
root . left . left = root . right ; root . left . right = root ; root . left = root . right = null ; return flippedRoot ; }
public static void printLevelOrder ( Node root ) {
if ( root == null ) return ;
Queue < Node > q = new LinkedList < > ( ) ;
q . add ( root ) ; while ( true ) {
int nodeCount = q . size ( ) ; if ( nodeCount == 0 ) break ;
while ( nodeCount > 0 ) { Node node = q . remove ( ) ; System . out . print ( node . data + " ▁ " ) ; if ( node . left != null ) q . add ( node . left ) ; if ( node . right != null ) q . add ( node . right ) ; nodeCount -- ; } System . out . println ( ) ; } }
public static void main ( String args [ ] ) { Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 1 ) ; root . right . left = new Node ( 4 ) ; root . right . right = new Node ( 5 ) ; System . out . println ( " Level ▁ order ▁ traversal ▁ of ▁ given ▁ tree " ) ; printLevelOrder ( root ) ; root = flipBinaryTree ( root ) ; System . out . println ( " Level ▁ order ▁ traversal ▁ of ▁ flipped ▁ tree " ) ; printLevelOrder ( root ) ; } }
void heapify ( int arr [ ] , int n , int i ) {
int largest = i ;
int l = 2 * i + 1 ;
int r = 2 * i + 2 ;
if ( l < n && arr [ l ] > arr [ largest ] ) largest = l ;
if ( r < n && arr [ r ] > arr [ largest ] ) largest = r ;
if ( largest != i ) { int swap = arr [ i ] ; arr [ i ] = arr [ largest ] ; arr [ largest ] = swap ;
heapify ( arr , n , largest ) ; } }
public void sort ( int arr [ ] ) { int n = arr . length ;
for ( int i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( int i = n - 1 ; i > 0 ; i -- ) {
int temp = arr [ 0 ] ; arr [ 0 ] = arr [ i ] ; arr [ i ] = temp ;
heapify ( arr , i , 0 ) ; } }
static void printArray ( int arr [ ] ) { int n = arr . length ; for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 12 , 11 , 13 , 5 , 6 , 7 } ; int n = arr . length ; HeapSort ob = new HeapSort ( ) ; ob . sort ( arr ) ; System . out . println ( " Sorted ▁ array ▁ is " ) ; printArray ( arr ) ; } }
static boolean isHeap ( int arr [ ] , int n ) {
for ( int i = 0 ; i <= ( n - 2 ) / 2 ; i ++ ) {
if ( arr [ 2 * i + 1 ] > arr [ i ] ) { return false ; }
if ( 2 * i + 2 < n && arr [ 2 * i + 2 ] > arr [ i ] ) { return false ; } } return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 90 , 15 , 10 , 7 , 12 , 2 , 7 , 3 } ; int n = arr . length ; if ( isHeap ( arr , n ) ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " No " ) ; } } }
public static void mergeKArrays ( int [ ] [ ] arr , int a , int [ ] output ) { int c = 0 ;
for ( int i = 0 ; i < a ; i ++ ) { for ( int j = 0 ; j < 4 ; j ++ ) output [ c ++ ] = arr [ i ] [ j ] ; }
Arrays . sort ( output ) ; }
public static void printArray ( int [ ] arr , int size ) { for ( int i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int [ ] [ ] arr = { { 2 , 6 , 12 , 34 } , { 1 , 9 , 20 , 1000 } , { 23 , 34 , 90 , 2000 } } ; int k = 4 ; int n = 3 ; int [ ] output = new int [ n * k ] ; mergeKArrays ( arr , n , output ) ; System . out . println ( " Merged ▁ array ▁ is ▁ " ) ; printArray ( output , n * k ) ; } }
import java . util . * ; class GFG { static final int n = 4 ;
static void mergeArrays ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 , int arr3 [ ] ) { int i = 0 , j = 0 , k = 0 ;
while ( i < n1 && j < n2 ) {
if ( arr1 [ i ] < arr2 [ j ] ) arr3 [ k ++ ] = arr1 [ i ++ ] ; else arr3 [ k ++ ] = arr2 [ j ++ ] ; }
while ( i < n1 ) arr3 [ k ++ ] = arr1 [ i ++ ] ;
while ( j < n2 ) arr3 [ k ++ ] = arr2 [ j ++ ] ; }
static void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
static void mergeKArrays ( int arr [ ] [ ] , int i , int j , int output [ ] ) {
if ( i == j ) { for ( int p = 0 ; p < n ; p ++ ) output [ p ] = arr [ i ] [ p ] ; return ; }
if ( j - i == 1 ) { mergeArrays ( arr [ i ] , arr [ j ] , n , n , output ) ; return ; }
int [ ] out1 = new int [ n * ( ( ( i + j ) / 2 ) - i + 1 ) ] ; int [ ] out2 = new int [ n * ( j - ( ( i + j ) / 2 ) ) ] ;
mergeKArrays ( arr , i , ( i + j ) / 2 , out1 ) ; mergeKArrays ( arr , ( i + j ) / 2 + 1 , j , out2 ) ;
mergeArrays ( out1 , out2 , n * ( ( ( i + j ) / 2 ) - i + 1 ) , n * ( j - ( ( i + j ) / 2 ) ) , output ) ; }
public static void main ( String [ ] args ) {
class GFG { static void generate_derangement ( int N ) {
int S [ ] = new int [ N + 1 ] ; for ( int i = 1 ; i <= N ; i ++ ) S [ i ] = i ;
int D [ ] = new int [ N + 1 ] ; for ( int i = 1 ; i <= N ; i += 2 ) { if ( i == N ) {
D [ N ] = S [ N - 1 ] ; D [ N - 1 ] = S [ N ] ; } else { D [ i ] = i + 1 ; D [ i + 1 ] = i ; } }
for ( int i = 1 ; i <= N ; i ++ ) System . out . print ( D [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String [ ] args ) { generate_derangement ( 10 ) ; } }
static void heapify ( int arr [ ] , int n , int i ) {
int smallest = i ;
int l = 2 * i + 1 ;
int r = 2 * i + 2 ;
if ( l < n && arr [ l ] < arr [ smallest ] ) smallest = l ;
if ( r < n && arr [ r ] < arr [ smallest ] ) smallest = r ;
if ( smallest != i ) { int temp = arr [ i ] ; arr [ i ] = arr [ smallest ] ; arr [ smallest ] = temp ;
heapify ( arr , n , smallest ) ; } }
static void heapSort ( int arr [ ] , int n ) {
for ( int i = n / 2 - 1 ; i >= 0 ; i -- ) heapify ( arr , n , i ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int temp = arr [ 0 ] ; arr [ 0 ] = arr [ i ] ; arr [ i ] = temp ;
heapify ( arr , i , 0 ) ; } }
static void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 4 , 6 , 3 , 2 , 9 } ; int n = arr . length ; heapSort ( arr , n ) ; System . out . println ( " Sorted ▁ array ▁ is ▁ " ) ; printArray ( arr , n ) ; } }
static int sumBetweenTwoKth ( int arr [ ] , int k1 , int k2 ) {
Arrays . sort ( arr ) ;
int result = 0 ; for ( int i = k1 ; i < k2 - 1 ; i ++ ) result += arr [ i ] ; return result ; }
public static void main ( String [ ] args ) { int arr [ ] = { 20 , 8 , 22 , 4 , 12 , 10 , 14 } ; int k1 = 3 , k2 = 6 ; int n = arr . length ; System . out . print ( sumBetweenTwoKth ( arr , k1 , k2 ) ) ; } }
static int minSum ( int a [ ] , int n ) {
Arrays . sort ( a ) ; int num1 = 0 ; int num2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) num1 = num1 * 10 + a [ i ] ; else num2 = num2 * 10 + a [ i ] ; } return num2 + num1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 5 , 3 , 0 , 7 , 4 } ; int n = arr . length ; System . out . println ( " The ▁ required ▁ sum ▁ is ▁ " + minSum ( arr , n ) ) ; } }
class Node { int key ; Node left , right ; public Node ( int key ) { this . key = key ; left = right = null ; } } class BinaryTree { Node root ;
int count ( Node node ) { if ( node == null ) return 0 ; return count ( node . left ) + count ( node . right ) + 1 ; }
boolean checkRec ( Node node , int n ) {
if ( node == null ) return false ;
if ( count ( node ) == n - count ( node ) ) return true ;
return checkRec ( node . left , n ) || checkRec ( node . right , n ) ; }
boolean check ( Node node ) {
int n = count ( node ) ;
return checkRec ( node , n ) ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 5 ) ; tree . root . left = new Node ( 1 ) ; tree . root . right = new Node ( 6 ) ; tree . root . left . left = new Node ( 3 ) ; tree . root . right . left = new Node ( 7 ) ; tree . root . right . right = new Node ( 4 ) ; if ( tree . check ( tree . root ) == true ) System . out . println ( " YES " ) ; else System . out . println ( " NO " ) ; } }
static void stack_push ( Stack < Integer > stack ) { for ( int i = 0 ; i < 5 ; i ++ ) { stack . push ( i ) ; } }
static void stack_pop ( Stack < Integer > stack ) { System . out . println ( " Pop ▁ : " ) ; for ( int i = 0 ; i < 5 ; i ++ ) { Integer y = ( Integer ) stack . pop ( ) ; System . out . println ( y ) ; } }
static void stack_peek ( Stack < Integer > stack ) { Integer element = ( Integer ) stack . peek ( ) ; System . out . println ( " Element ▁ on ▁ stack ▁ top ▁ : ▁ " + element ) ; }
static void stack_search ( Stack < Integer > stack , int element ) { Integer pos = ( Integer ) stack . search ( element ) ; if ( pos == - 1 ) System . out . println ( " Element ▁ not ▁ found " ) ; else System . out . println ( " Element ▁ is ▁ found ▁ at ▁ position ▁ " + pos ) ; }
public static void main ( String [ ] args ) { Stack < Integer > stack = new Stack < Integer > ( ) ; stack_push ( stack ) ; stack_pop ( stack ) ; stack_push ( stack ) ; stack_peek ( stack ) ; stack_search ( stack , 2 ) ; stack_search ( stack , 6 ) ; } }
class Node { int key ; Node left , right ; public Node ( int key ) { this . key = key ; left = right = null ; } } class Res { boolean res = false ; } class BinaryTree { Node root ;
int count ( Node node ) { if ( node == null ) return 0 ; return count ( node . left ) + count ( node . right ) + 1 ; }
int checkRec ( Node root , int n , Res res ) {
if ( root == null ) return 0 ;
int c = checkRec ( root . left , n , res ) + 1 + checkRec ( root . right , n , res ) ;
if ( c == n - c ) res . res = true ;
return c ; }
boolean check ( Node root ) {
int n = count ( root ) ;
Res res = new Res ( ) ; checkRec ( root , n , res ) ; return res . res ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 5 ) ; tree . root . left = new Node ( 1 ) ; tree . root . right = new Node ( 6 ) ; tree . root . left . left = new Node ( 3 ) ; tree . root . right . left = new Node ( 7 ) ; tree . root . right . right = new Node ( 4 ) ; if ( tree . check ( tree . root ) == true ) System . out . println ( " YES " ) ; else System . out . println ( " NO " ) ; } }
import java . util . * ; class GfG { static int preIndex = 0 ;
static class Node { int data ; Node left , right ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . left = null ; temp . right = null ; return temp ; }
static int search ( int arr [ ] , int strt , int end , int value ) { for ( int i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) return i ; } return - 1 ; }
static Node buildTree ( int in [ ] , int pre [ ] , int inStrt , int inEnd ) { if ( inStrt > inEnd ) return null ;
Node tNode = newNode ( pre [ preIndex ++ ] ) ;
if ( inStrt == inEnd ) return tNode ;
int inIndex = search ( in , inStrt , inEnd , tNode . data ) ;
tNode . left = buildTree ( in , pre , inStrt , inIndex - 1 ) ; tNode . right = buildTree ( in , pre , inIndex + 1 , inEnd ) ; return tNode ; }
static int checkPostorder ( Node node , int postOrder [ ] , int index ) { if ( node == null ) return index ;
index = checkPostorder ( node . left , postOrder , index ) ;
index = checkPostorder ( node . right , postOrder , index ) ;
if ( node . data == postOrder [ index ] ) index ++ ; else return - 1 ; return index ; }
public static void main ( String [ ] args ) { int inOrder [ ] = { 4 , 2 , 5 , 1 , 3 } ; int preOrder [ ] = { 1 , 2 , 4 , 5 , 3 } ; int postOrder [ ] = { 4 , 5 , 2 , 3 , 1 } ; int len = inOrder . length ;
Node root = buildTree ( inOrder , preOrder , 0 , len - 1 ) ;
int index = checkPostorder ( root , postOrder , 0 ) ;
if ( index == len ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . io . * ; class GFG { static int N = 3 ; static int M = 4 ;
static void printDistance ( int mat [ ] [ ] ) { int ans [ ] [ ] = new int [ N ] [ M ] ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) ans [ i ] [ j ] = Integer . MAX_VALUE ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < M ; j ++ ) {
for ( int k = 0 ; k < N ; k ++ ) for ( int l = 0 ; l < M ; l ++ ) {
if ( mat [ k ] [ l ] == 1 ) ans [ i ] [ j ] = Math . min ( ans [ i ] [ j ] , Math . abs ( i - k ) + Math . abs ( j - l ) ) ; } }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) System . out . print ( ans [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 0 , 0 , 0 , 1 } , { 0 , 0 , 1 , 1 } , { 0 , 1 , 1 , 0 } } ; printDistance ( mat ) ; } }
static int isChangeable ( int notes [ ] , int n ) {
int fiveCount = 0 ; int tenCount = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( notes [ i ] == 5 ) fiveCount ++ ; else if ( notes [ i ] == 10 ) {
if ( fiveCount > 0 ) { fiveCount -- ; tenCount ++ ; } else return 0 ; } else {
if ( fiveCount > 0 && tenCount > 0 ) { fiveCount -- ; tenCount -- ; }
else if ( fiveCount >= 3 ) { fiveCount -= 3 ; } else return 0 ; } } return 1 ; }
int a [ ] = { 5 , 5 , 5 , 10 , 20 } ; int n = a . length ;
if ( isChangeable ( a , n ) > 0 ) System . out . print ( " YES " ) ; else System . out . print ( " NO " ) ; } }
static int maxDistance ( int [ ] arr , int n ) {
HashMap < Integer , Integer > map = new HashMap < > ( ) ;
int max_dist = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( ! map . containsKey ( arr [ i ] ) ) map . put ( arr [ i ] , i ) ;
else max_dist = Math . max ( max_dist , i - map . get ( arr [ i ] ) ) ; } return max_dist ; }
public static void main ( String args [ ] ) { int [ ] arr = { 3 , 2 , 1 , 2 , 1 , 4 , 5 , 8 , 6 , 7 , 4 , 2 } ; int n = arr . length ; System . out . println ( maxDistance ( arr , n ) ) ; } }
import java . util . * ; class Main { static boolean checkDuplicatesWithinK ( int arr [ ] , int k ) {
HashSet < Integer > set = new HashSet < > ( ) ;
for ( int i = 0 ; i < arr . length ; i ++ ) {
if ( set . contains ( arr [ i ] ) ) return true ;
set . add ( arr [ i ] ) ;
if ( i >= k ) set . remove ( arr [ i - k ] ) ; } return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 10 , 5 , 3 , 4 , 3 , 5 , 6 } ; if ( checkDuplicatesWithinK ( arr , 3 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . util . * ; class GFG { static int mostFrequent ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
int max_count = 1 , res = arr [ 0 ] ; int curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count > max_count ) { max_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 5 , 2 , 1 , 3 , 2 , 1 } ; int n = arr . length ; System . out . println ( mostFrequent ( arr , n ) ) ; } }
import java . util . HashMap ; import java . util . Map ; import java . util . Map . Entry ; class GFG { static int mostFrequent ( int arr [ ] , int n ) {
Map < Integer , Integer > hp = new HashMap < Integer , Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { int key = arr [ i ] ; if ( hp . containsKey ( key ) ) { int freq = hp . get ( key ) ; freq ++ ; hp . put ( key , freq ) ; } else { hp . put ( key , 1 ) ; } }
int max_count = 0 , res = - 1 ; for ( Entry < Integer , Integer > val : hp . entrySet ( ) ) { if ( max_count < val . getValue ( ) ) { res = val . getKey ( ) ; max_count = val . getValue ( ) ; } } return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 5 , 2 , 1 , 3 , 2 , 1 } ; int n = arr . length ; System . out . println ( mostFrequent ( arr , n ) ) ; } }
import java . io . * ; import java . util . * ; class GfG { static void smallestSubsegment ( int a [ ] , int n ) {
HashMap < Integer , Integer > left = new HashMap < Integer , Integer > ( ) ;
HashMap < Integer , Integer > count = new HashMap < Integer , Integer > ( ) ;
int mx = 0 ;
int mn = - 1 , strindex = - 1 ; for ( int i = 0 ; i < n ; i ++ ) { int x = a [ i ] ;
if ( count . get ( x ) == null ) { left . put ( x , i ) ; count . put ( x , 1 ) ; }
else count . put ( x , count . get ( x ) + 1 ) ;
if ( count . get ( x ) > mx ) { mx = count . get ( x ) ;
mn = i - left . get ( x ) + 1 ; strindex = left . get ( x ) ; }
else if ( ( count . get ( x ) == mx ) && ( i - left . get ( x ) + 1 < mn ) ) { mn = i - left . get ( x ) + 1 ; strindex = left . get ( x ) ; } }
for ( int i = strindex ; i < strindex + mn ; i ++ ) System . out . print ( a [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int A [ ] = { 1 , 2 , 2 , 2 , 1 } ; int n = A . length ; smallestSubsegment ( A , n ) ; } }
static void findSymPairs ( int arr [ ] [ ] ) {
HashMap < Integer , Integer > hM = new HashMap < Integer , Integer > ( ) ;
for ( int i = 0 ; i < arr . length ; i ++ ) {
int first = arr [ i ] [ 0 ] ; int sec = arr [ i ] [ 1 ] ;
Integer val = hM . get ( sec ) ;
if ( val != null && val == first ) System . out . println ( " ( " + sec + " , ▁ " + first + " ) " ) ;
else hM . put ( first , sec ) ; } }
public static void main ( String arg [ ] ) { int arr [ ] [ ] = new int [ 5 ] [ 2 ] ; arr [ 0 ] [ 0 ] = 11 ; arr [ 0 ] [ 1 ] = 20 ; arr [ 1 ] [ 0 ] = 30 ; arr [ 1 ] [ 1 ] = 40 ; arr [ 2 ] [ 0 ] = 5 ; arr [ 2 ] [ 1 ] = 10 ; arr [ 3 ] [ 0 ] = 40 ; arr [ 3 ] [ 1 ] = 30 ; arr [ 4 ] [ 0 ] = 10 ; arr [ 4 ] [ 1 ] = 5 ; findSymPairs ( arr ) ; } }
static void groupElements ( int arr [ ] , int n ) {
boolean visited [ ] = new boolean [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { visited [ i ] = false ; }
for ( int i = 0 ; i < n ; i ++ ) {
if ( ! visited [ i ] ) {
System . out . print ( arr [ i ] + " ▁ " ) ; for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) { System . out . print ( arr [ i ] + " ▁ " ) ; visited [ j ] = true ; } } } } }
public static void main ( String [ ] args ) { int arr [ ] = { 4 , 6 , 9 , 2 , 3 , 4 , 9 , 6 , 10 , 4 } ; int n = arr . length ; groupElements ( arr , n ) ; } }
boolean aredisjoint ( int set1 [ ] , int set2 [ ] ) {
for ( int i = 0 ; i < set1 . length ; i ++ ) { for ( int j = 0 ; j < set2 . length ; j ++ ) { if ( set1 [ i ] == set2 [ j ] ) return false ; } }
return true ; }
public static void main ( String [ ] args ) { disjoint1 dis = new disjoint1 ( ) ; int set1 [ ] = { 12 , 34 , 11 , 9 , 3 } ; int set2 [ ] = { 7 , 2 , 1 , 5 } ; boolean result = dis . aredisjoint ( set1 , set2 ) ; if ( result ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
boolean aredisjoint ( int set1 [ ] , int set2 [ ] ) { int i = 0 , j = 0 ;
Arrays . sort ( set1 ) ; Arrays . sort ( set2 ) ;
while ( i < set1 . length && j < set2 . length ) { if ( set1 [ i ] < set2 [ j ] ) i ++ ; else if ( set1 [ i ] > set2 [ j ] ) j ++ ;
else return false ; } return true ; }
public static void main ( String [ ] args ) { disjoint1 dis = new disjoint1 ( ) ; int set1 [ ] = { 12 , 34 , 11 , 9 , 3 } ; int set2 [ ] = { 7 , 2 , 1 , 5 } ; boolean result = dis . aredisjoint ( set1 , set2 ) ; if ( result ) System . out . println ( " YES " ) ; else System . out . println ( " NO " ) ; } }
static void findMissing ( int a [ ] , int b [ ] , int n , int m ) { for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < m ; j ++ ) if ( a [ i ] == b [ j ] ) break ; if ( j == m ) System . out . print ( a [ i ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 6 , 3 , 4 , 5 } ; int b [ ] = { 2 , 4 , 3 , 1 , 0 } ; int n = a . length ; int m = b . length ; findMissing ( a , b , n , m ) ; } }
static void findMissing ( int a [ ] , int b [ ] , int n , int m ) {
HashSet < Integer > s = new HashSet < > ( ) ; for ( int i = 0 ; i < m ; i ++ ) s . add ( b [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( ! s . contains ( a [ i ] ) ) System . out . print ( a [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 6 , 3 , 4 , 5 } ; int b [ ] = { 2 , 4 , 3 , 1 , 0 } ; int n = a . length ; int m = b . length ; findMissing ( a , b , n , m ) ; } }
public static boolean areEqual ( int arr1 [ ] , int arr2 [ ] ) { int n = arr1 . length ; int m = arr2 . length ;
if ( n != m ) return false ;
Arrays . sort ( arr1 ) ; Arrays . sort ( arr2 ) ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr1 [ i ] != arr2 [ i ] ) return false ;
return true ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 3 , 5 , 2 , 5 , 2 } ; int arr2 [ ] = { 2 , 3 , 5 , 5 , 2 } ; if ( areEqual ( arr1 , arr2 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . util . * ; class GFG { static void makePermutation ( int [ ] a , int n ) {
HashMap < Integer , Integer > count = new HashMap < Integer , Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( count . containsKey ( a [ i ] ) ) { count . put ( a [ i ] , count . get ( a [ i ] ) + 1 ) ; } else { count . put ( a [ i ] , 1 ) ; } } }
static int find_maximum ( int a [ ] , int n , int k ) {
HashMap < Integer , Integer > b = new HashMap < Integer , Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { int x = a [ i ] ;
int d = Math . min ( 1 + i , n - i ) ; if ( ! b . containsKey ( x ) ) b . put ( x , d ) ; else {
b . put ( x , Math . min ( d , b . get ( x ) ) ) ; } } int ans = Integer . MAX_VALUE ; for ( int i = 0 ; i < n ; i ++ ) { int x = a [ i ] ;
if ( x != k - x && b . containsKey ( k - x ) ) ans = Math . min ( Math . max ( b . get ( x ) , b . get ( k - x ) ) , ans ) ; } return ans ; }
public static void main ( String [ ] args ) { int a [ ] = { 3 , 5 , 8 , 6 , 7 } ; int K = 11 ; int n = a . length ; System . out . println ( find_maximum ( a , n , K ) ) ; } }
boolean isProduct ( int arr [ ] , int n , int x ) {
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] * arr [ j ] == x ) return true ; return false ; }
public static void main ( String [ ] args ) { GFG g = new GFG ( ) ; int arr [ ] = { 10 , 20 , 9 , 40 } ; int x = 400 ; int n = arr . length ; if ( g . isProduct ( arr , n , x ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; x = 190 ; if ( g . isProduct ( arr , n , x ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static boolean isProduct ( int arr [ ] , int n , int x ) {
HashSet < Integer > hset = new HashSet < > ( ) ; if ( n < 2 ) return false ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] == 0 ) { if ( x == 0 ) return true ; else continue ; }
if ( x % arr [ i ] == 0 ) { if ( hset . contains ( x / arr [ i ] ) ) return true ;
hset . add ( arr [ i ] ) ; } } return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 10 , 20 , 9 , 40 } ; int x = 400 ; int n = arr . length ; if ( isProduct ( arr , arr . length , x ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; x = 190 ; if ( isProduct ( arr , arr . length , x ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static void printMissing ( int arr [ ] , int low , int high ) {
boolean [ ] points_of_range = new boolean [ high - low + 1 ] ; for ( int i = 0 ; i < arr . length ; i ++ ) {
if ( low <= arr [ i ] && arr [ i ] <= high ) points_of_range [ arr [ i ] - low ] = true ; }
for ( int x = 0 ; x <= high - low ; x ++ ) { if ( points_of_range [ x ] == false ) System . out . print ( ( low + x ) + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 5 , 4 } ; int low = 1 , high = 10 ; printMissing ( arr , low , high ) ; } }
static int find ( int a [ ] , int b [ ] , int k , int n1 , int n2 ) {
LinkedHashSet < Integer > s = new LinkedHashSet < > ( ) ; for ( int i = 0 ; i < n2 ; i ++ ) s . add ( b [ i ] ) ;
int missing = 0 ; for ( int i = 0 ; i < n1 ; i ++ ) { if ( ! s . contains ( a [ i ] ) ) missing ++ ; if ( missing == k ) return a [ i ] ; } return - 1 ; }
public static void main ( String [ ] args ) { int a [ ] = { 0 , 2 , 4 , 6 , 8 , 10 , 12 , 14 , 15 } ; int b [ ] = { 4 , 10 , 6 , 8 , 12 } ; int n1 = a . length ; int n2 = b . length ; int k = 3 ; System . out . println ( find ( a , b , k , n1 , n2 ) ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
boolean isFullTree ( Node node ) {
if ( node == null ) return true ;
if ( node . left == null && node . right == null ) return true ;
if ( ( node . left != null ) && ( node . right != null ) ) return ( isFullTree ( node . left ) && isFullTree ( node . right ) ) ;
return false ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 20 ) ; tree . root . right = new Node ( 30 ) ; tree . root . left . right = new Node ( 40 ) ; tree . root . left . left = new Node ( 50 ) ; tree . root . right . left = new Node ( 60 ) ; tree . root . left . left . left = new Node ( 80 ) ; tree . root . right . right = new Node ( 70 ) ; tree . root . left . left . right = new Node ( 90 ) ; tree . root . left . right . left = new Node ( 80 ) ; tree . root . left . right . right = new Node ( 90 ) ; tree . root . right . left . left = new Node ( 80 ) ; tree . root . right . left . right = new Node ( 90 ) ; tree . root . right . right . left = new Node ( 80 ) ; tree . root . right . right . right = new Node ( 90 ) ; if ( tree . isFullTree ( tree . root ) ) System . out . print ( " The ▁ binary ▁ tree ▁ is ▁ full " ) ; else System . out . print ( " The ▁ binary ▁ tree ▁ is ▁ not ▁ full " ) ; } }
static int findGreatest ( int [ ] arr , int n ) { int result = - 1 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ j ] * arr [ k ] == arr [ i ] ) result = Math . max ( result , arr [ i ] ) ; return result ; }
static public void main ( String [ ] args ) { int [ ] arr = { 30 , 10 , 9 , 3 , 35 } ; int n = arr . length ; System . out . println ( findGreatest ( arr , n ) ) ; } }
static int findGreatest ( int arr [ ] , int n ) {
Map < Integer , Integer > m = new HashMap < > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( m . containsKey ( arr [ i ] ) ) { m . put ( arr [ i ] , m . get ( arr [ i ] ) + 1 ) ; } else { m . put ( arr [ i ] , m . get ( arr [ i ] ) ) ; } }
Arrays . sort ( arr ) ; for ( int i = n - 1 ; i > 1 ; i -- ) {
for ( int j = 0 ; j < i && arr [ j ] <= Math . sqrt ( arr [ i ] ) ; j ++ ) { if ( arr [ i ] % arr [ j ] == 0 ) { int result = arr [ i ] / arr [ j ] ;
if ( result != arr [ j ] && m . get ( result ) == null || m . get ( result ) > 0 ) { return arr [ i ] ; }
else if ( result == arr [ j ] && m . get ( result ) > 1 ) { return arr [ i ] ; } } } } return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 17 , 2 , 1 , 15 , 30 } ; int n = arr . length ; System . out . println ( findGreatest ( arr , n ) ) ; } }
public static int subset ( int ar [ ] , int n ) {
int res = 0 ;
Arrays . sort ( ar ) ;
for ( int i = 0 ; i < n ; i ++ ) { int count = 1 ;
for ( ; i < n - 1 ; i ++ ) { if ( ar [ i ] == ar [ i + 1 ] ) count ++ ; else break ; }
res = Math . max ( res , count ) ; } return res ; }
public static void main ( String argc [ ] ) { int arr [ ] = { 5 , 6 , 9 , 3 , 4 , 3 , 4 } ; int n = 7 ; System . out . println ( subset ( arr , n ) ) ; } }
public static int minRemove ( int a [ ] , int b [ ] , int n , int m ) {
HashMap < Integer , Integer > countA = new HashMap < Integer , Integer > ( ) ; HashMap < Integer , Integer > countB = new HashMap < Integer , Integer > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( countA . containsKey ( a [ i ] ) ) countA . put ( a [ i ] , countA . get ( a [ i ] ) + 1 ) ; else countA . put ( a [ i ] , 1 ) ; }
for ( int i = 0 ; i < m ; i ++ ) { if ( countB . containsKey ( b [ i ] ) ) countB . put ( b [ i ] , countB . get ( b [ i ] ) + 1 ) ; else countB . put ( b [ i ] , 1 ) ; }
int res = 0 ; Set < Integer > s = countA . keySet ( ) ; for ( int x : s ) if ( countB . containsKey ( x ) ) res += Math . min ( countB . get ( x ) , countA . get ( x ) ) ;
return res ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 3 , 4 } ; int b [ ] = { 2 , 3 , 4 , 5 , 8 } ; int n = a . length ; int m = b . length ; System . out . println ( minRemove ( a , b , n , m ) ) ; } }
static int countItems ( item list1 [ ] , int m , item list2 [ ] , int n ) { int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( ( list1 [ i ] . name . compareTo ( list2 [ j ] . name ) == 0 ) && ( list1 [ i ] . price != list2 [ j ] . price ) ) count ++ ;
return count ; }
public static void main ( String [ ] args ) { item list1 [ ] = { new item ( " apple " , 60 ) , new item ( " bread " , 20 ) , new item ( " wheat " , 50 ) , new item ( " oil " , 30 ) } ; item list2 [ ] = { new item ( " milk " , 20 ) , new item ( " bread " , 15 ) , new item ( " wheat " , 40 ) , new item ( " apple " , 60 ) } ; int m = list1 . length ; int n = list2 . length ; System . out . print ( " Count ▁ = ▁ " + countItems ( list1 , m , list2 , n ) ) ; } }
import java . util . * ; class GFG { static void makePermutation ( int [ ] a , int n ) {
HashMap < Integer , Integer > count = new HashMap < Integer , Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( count . containsKey ( a [ i ] ) ) { count . put ( a [ i ] , count . get ( a [ i ] ) + 1 ) ; } else { count . put ( a [ i ] , 1 ) ; } } int next_missing = 1 ; for ( int i = 0 ; i < n ; i ++ ) { if ( count . containsKey ( a [ i ] ) && count . get ( a [ i ] ) != 1 a [ i ] > n a [ i ] < 1 ) { count . put ( a [ i ] , count . get ( a [ i ] ) - 1 ) ;
while ( count . containsKey ( next_missing ) ) next_missing ++ ;
a [ i ] = next_missing ; count . put ( next_missing , 1 ) ; } } }
public static void main ( String [ ] args ) { int A [ ] = { 2 , 2 , 3 , 3 } ; int n = A . length ; makePermutation ( A , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( A [ i ] + " ▁ " ) ; } }
public static void getPairsCount ( int [ ] arr , int sum ) {
int count = 0 ;
for ( int i = 0 ; i < arr . length ; i ++ ) for ( int j = i + 1 ; j < arr . length ; j ++ ) if ( ( arr [ i ] + arr [ j ] ) == sum ) count ++ ; System . out . printf ( " Count ▁ of ▁ pairs ▁ is ▁ % d " , count ) ; }
public static void main ( String args [ ] ) { int [ ] arr = { 1 , 5 , 7 , - 1 , 5 } ; int sum = 6 ; getPairsCount ( arr , sum ) ; } }
static int countPairs ( int [ ] arr1 , int [ ] arr2 , int m , int n , int x ) { int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ )
if ( ( arr1 [ i ] + arr2 [ j ] ) == x ) count ++ ;
return count ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = arr1 . length ; int n = arr2 . length ; int x = 10 ; System . out . println ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static boolean isPresent ( int arr [ ] , int low , int high , int value ) { while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] == value ) return true ; else if ( arr [ mid ] > value ) high = mid - 1 ; else low = mid + 1 ; }
return false ; }
static int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ; for ( int i = 0 ; i < m ; i ++ ) {
int value = x - arr1 [ i ] ;
if ( isPresent ( arr2 , 0 , n - 1 , value ) ) count ++ ; }
return count ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = arr1 . length ; int n = arr2 . length ; int x = 10 ; System . out . println ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ; HashSet < Integer > us = new HashSet < Integer > ( ) ;
for ( int i = 0 ; i < m ; i ++ ) us . add ( arr1 [ i ] ) ;
for ( int j = 0 ; j < n ; j ++ )
if ( us . contains ( x - arr2 [ j ] ) ) count ++ ;
return count ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = arr1 . length ; int n = arr2 . length ; int x = 10 ; System . out . print ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
static int countPairs ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) { int count = 0 ; int l = 0 , r = n - 1 ;
while ( l < m && r >= 0 ) {
if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) { l ++ ; r -- ; count ++ ; }
else if ( ( arr1 [ l ] + arr2 [ r ] ) < x ) l ++ ;
else r -- ; }
return count ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 3 , 5 , 7 } ; int arr2 [ ] = { 2 , 3 , 5 , 8 } ; int m = arr1 . length ; int n = arr2 . length ; int x = 10 ; System . out . println ( " Count ▁ = ▁ " + countPairs ( arr1 , arr2 , m , n , x ) ) ; } }
import java . util . * ; class Solution { public static void main ( String [ ] args ) { int arr [ ] = { 10 , 2 , - 2 , - 20 , 10 } ; int k = - 10 ; int n = arr . length ; int res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { int sum = 0 ; for ( int j = i ; j < n ; j ++ ) {
sum += arr [ j ] ;
if ( sum == k ) res ++ ; } } System . out . println ( res ) ; } }
static int findSubarraySum ( int arr [ ] , int n , int sum ) {
HashMap < Integer , Integer > prevSum = new HashMap < > ( ) ; int res = 0 ;
int currsum = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
currsum += arr [ i ] ;
if ( currsum == sum ) res ++ ;
if ( prevSum . containsKey ( currsum - sum ) ) res += prevSum . get ( currsum - sum ) ;
Integer count = prevSum . get ( currsum ) ; if ( count == null ) prevSum . put ( currsum , 1 ) ; else prevSum . put ( currsum , count + 1 ) ; } return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { 10 , 2 , - 2 , - 20 , 10 } ; int sum = - 10 ; int n = arr . length ; System . out . println ( findSubarraySum ( arr , n , sum ) ) ; } }
static int countPairs ( int arr [ ] , int n ) { int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int product = arr [ i ] * arr [ j ] ;
for ( int k = 0 ; k < n ; k ++ ) {
if ( arr [ k ] == product ) { result ++ ; break ; } } } }
return result ; }
public static void main ( String [ ] args ) { int arr [ ] = { 6 , 2 , 4 , 12 , 5 , 3 } ; int n = arr . length ; System . out . println ( countPairs ( arr , n ) ) ; } }
static int countPairs ( int arr [ ] , int n ) { int result = 0 ;
HashSet < Integer > Hash = new HashSet < > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { Hash . add ( arr [ i ] ) ; }
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int product = arr [ i ] * arr [ j ] ;
if ( Hash . contains ( product ) ) { result ++ ; } } }
return result ; }
public static void main ( String [ ] args ) { int arr [ ] = { 6 , 2 , 4 , 12 , 5 , 3 } ; int n = arr . length ; System . out . println ( countPairs ( arr , n ) ) ; } }
static void findPairs ( int arr1 [ ] , int arr2 [ ] , int n , int m , int x ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( arr1 [ i ] + arr2 [ j ] == x ) System . out . println ( arr1 [ i ] + " ▁ " + arr2 [ j ] ) ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 2 , 3 , 7 , 5 , 4 } ; int arr2 [ ] = { 0 , 7 , 4 , 3 , 2 , 1 } ; int x = 8 ; findPairs ( arr1 , arr2 , arr1 . length , arr2 . length , x ) ; } }
public static void findPairs ( int arr1 [ ] , int arr2 [ ] , int n , int m , int x ) {
HashMap < Integer , Integer > s = new HashMap < Integer , Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) s . put ( arr1 [ i ] , 0 ) ;
for ( int j = 0 ; j < m ; j ++ ) if ( s . containsKey ( x - arr2 [ j ] ) ) System . out . println ( x - arr2 [ j ] + " ▁ " + arr2 [ j ] ) ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 0 , - 4 , 7 , 6 , 4 } ; int arr2 [ ] = { 0 , 2 , 4 , - 3 , 2 , 1 } ; int x = 8 ; findPairs ( arr1 , arr2 , arr1 . length , arr2 . length , x ) ; } }
static void countFreq ( int a [ ] , int n ) {
int hm [ ] = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) hm [ a [ i ] ] ++ ; int cumul = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
cumul += hm [ a [ i ] ] ;
if ( hm [ a [ i ] ] != 0 ) { System . out . println ( a [ i ] + " - > " + cumul ) ; }
hm [ a [ i ] ] = 0 ; } }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 3 , 2 , 4 , 2 , 1 } ; int n = a . length ; countFreq ( a , n ) ; } }
static void findPair ( int [ ] arr , int n ) { boolean found = false ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { for ( int k = 0 ; k < n ; k ++ ) { if ( arr [ i ] + arr [ j ] == arr [ k ] ) { System . out . println ( arr [ i ] + " ▁ " + arr [ j ] ) ; found = true ; } } } } if ( found == false ) System . out . println ( " Not ▁ exist " ) ; }
static public void main ( String [ ] args ) { int [ ] arr = { 10 , 4 , 8 , 13 , 5 } ; int n = arr . length ; findPair ( arr , n ) ; } }
static boolean printPairs ( int arr [ ] , int n , int k ) { boolean isPairFound = true ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i != j && arr [ i ] % arr [ j ] == k ) { System . out . print ( " ( " + arr [ i ] + " , ▁ " + arr [ j ] + " ) " + " ▁ " ) ; isPairFound = true ; } } } return isPairFound ; }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , 3 , 5 , 4 , 7 } ; int k = 3 ; if ( printPairs ( arr , arr . length , k ) == false ) System . out . println ( " No ▁ such ▁ pair ▁ exists " ) ; } }
static Vector < Integer > findDivisors ( int n ) { Vector < Integer > v = new Vector < > ( ) ;
for ( int i = 1 ; i <= Math . sqrt ( n ) ; i ++ ) { if ( n % i == 0 ) {
if ( n / i == i ) v . add ( i ) ; else { v . add ( i ) ; v . add ( n / i ) ; } } } return v ; }
static boolean printPairs ( int arr [ ] , int n , int k ) {
HashMap < Integer , Boolean > occ = new HashMap < > ( ) ; for ( int i = 0 ; i < n ; i ++ ) occ . put ( arr [ i ] , true ) ; boolean isPairFound = false ; for ( int i = 0 ; i < n ; i ++ ) {
if ( occ . get ( k ) && k < arr [ i ] ) { System . out . print ( " ( " + k + " , ▁ " + arr [ i ] + " ) ▁ " ) ; isPairFound = true ; }
if ( arr [ i ] >= k ) {
Vector < Integer > v = findDivisors ( arr [ i ] - k ) ;
for ( int j = 0 ; j < v . size ( ) ; j ++ ) { if ( arr [ i ] % v . get ( j ) == k && arr [ i ] != v . get ( j ) && occ . get ( v . get ( j ) ) ) { System . out . print ( " ( " + arr [ i ] + " , ▁ " + v . get ( j ) + " ) ▁ " ) ; isPairFound = true ; } }
v . clear ( ) ; } } return isPairFound ; }
public static void main ( String args [ ] ) { int arr [ ] = { 3 , 1 , 2 , 5 , 4 } ; int k = 2 ; if ( printPairs ( arr , arr . length , k ) == false ) System . out . println ( " No ▁ such ▁ pair ▁ exists " ) ; } }
import java . util . * ; class GFG { public static void convert ( int arr [ ] , int n ) {
int temp [ ] = arr . clone ( ) ;
Arrays . sort ( temp ) ;
HashMap < Integer , Integer > umap = new HashMap < > ( ) ;
int val = 0 ; for ( int i = 0 ; i < n ; i ++ ) umap . put ( temp [ i ] , val ++ ) ;
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = umap . get ( arr [ i ] ) ; } public static void printArr ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 10 , 20 , 15 , 12 , 11 , 50 } ; int n = arr . length ; System . out . println ( " Given ▁ Array ▁ is ▁ " ) ; printArr ( arr , n ) ; convert ( arr , n ) ; System . out . println ( " Converted Array is "); printArr ( arr , n ) ; } }
public class GFG { static final int ASCII_SIZE = 256 ; static char getMaxOccuringChar ( String str ) {
int count [ ] = new int [ ASCII_SIZE ] ;
int len = str . length ( ) ; for ( int i = 0 ; i < len ; i ++ ) count [ str . charAt ( i ) ] ++ ;
int max = - 1 ;
char result = ' ▁ ' ;
for ( int i = 0 ; i < len ; i ++ ) { if ( max < count [ str . charAt ( i ) ] ) { max = count [ str . charAt ( i ) ] ; result = str . charAt ( i ) ; } } return result ; }
public static void main ( String [ ] args ) { String str = " sample ▁ string " ; System . out . println ( " Max ▁ occurring ▁ character ▁ is ▁ " + getMaxOccuringChar ( str ) ) ; } }
import java . util . HashSet ; public class Main { static char MARKER = ' $ ' ;
class Node { int data ; Node left , right ; Node ( int data ) { this . data = data ; } } ;
public static String dupSubUtil ( Node root , HashSet < String > subtrees ) { String s = " " ;
if ( root == null ) return s + MARKER ;
String lStr = dupSubUtil ( root . left , subtrees ) ; if ( lStr . equals ( s ) ) return s ;
String rStr = dupSubUtil ( root . right , subtrees ) ; if ( rStr . equals ( s ) ) return s ;
s = s + root . data + lStr + rStr ;
if ( s . length ( ) > 3 && subtrees . contains ( s ) ) return " " ; subtrees . add ( s ) ; return s ; }
public static String dupSub ( Node root ) { HashSet < String > subtrees = new HashSet < > ( ) ; return dupSubUtil ( root , subtrees ) ; }
public static void main ( String args [ ] ) { Node root = new Node ( ' A ' ) ; root . left = new Node ( ' B ' ) ; root . right = new Node ( ' C ' ) ; root . left . left = new Node ( ' D ' ) ; root . left . right = new Node ( ' E ' ) ; root . right . right = new Node ( ' B ' ) ; root . right . right . right = new Node ( ' E ' ) ; root . right . right . left = new Node ( ' D ' ) ; String str = dupSub ( root ) ; if ( str . equals ( " " ) ) System . out . print ( " ▁ Yes ▁ " ) ; else System . out . print ( " ▁ No ▁ " ) ; } }
static void printFirstRepeating ( int arr [ ] ) {
int min = - 1 ;
HashSet < Integer > set = new HashSet < > ( ) ;
for ( int i = arr . length - 1 ; i >= 0 ; i -- ) {
if ( set . contains ( arr [ i ] ) ) min = i ;
else set . add ( arr [ i ] ) ; }
if ( min != - 1 ) System . out . println ( " The ▁ first ▁ repeating ▁ element ▁ is ▁ " + arr [ min ] ) ; else System . out . println ( " There ▁ are ▁ no ▁ repeating ▁ elements " ) ; }
public static void main ( String [ ] args ) throws java . lang . Exception { int arr [ ] = { 10 , 5 , 3 , 4 , 3 , 5 , 6 } ; printFirstRepeating ( arr ) ; } }
static void printFirstRepeating ( int [ ] arr , int n ) {
int k = 0 ;
int max = n ; for ( int i = 0 ; i < n ; i ++ ) if ( max < arr [ i ] ) max = arr [ i ] ;
int [ ] a = new int [ max + 1 ] ;
int [ ] b = new int [ max + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ arr [ i ] ] != 0 ) { b [ arr [ i ] ] = 1 ; k = 1 ; continue ; } else
a [ arr [ i ] ] = i ; } if ( k == 0 ) System . out . println ( " No ▁ repeating ▁ element ▁ found " ) ; else { int min = max + 1 ;
for ( int i = 0 ; i < max + 1 ; i ++ ) if ( a [ i ] != 0 && min > a [ i ] && b [ i ] != 0 ) min = a [ i ] ; System . out . print ( arr [ min ] ) ; } System . out . println ( ) ; }
public static void main ( String [ ] args ) { int [ ] arr = { 10 , 5 , 3 , 4 , 3 , 5 , 6 } ; int n = arr . length ; printFirstRepeating ( arr , n ) ; } }
static int findSum ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ; int sum = arr [ 0 ] ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) { sum = sum + arr [ i + 1 ] ; } } return sum ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 1 , 1 , 4 , 5 , 6 } ; int n = arr . length ; System . out . println ( findSum ( arr , n ) ) ; } }
static int findSum ( int arr [ ] , int n ) { int sum = 0 ;
HashSet < Integer > s = new HashSet < Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( ! s . contains ( arr [ i ] ) ) { sum += arr [ i ] ; s . add ( arr [ i ] ) ; } } return sum ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 1 , 1 , 4 , 5 , 6 } ; int n = arr . length ; System . out . println ( findSum ( arr , n ) ) ; } }
static int printKDistinct ( int arr [ ] , int n , int k ) { int dist_count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j ; for ( j = 0 ; j < n ; j ++ ) if ( i != j && arr [ j ] == arr [ i ] ) break ;
if ( j == n ) dist_count ++ ; if ( dist_count == k ) return arr [ i ] ; } return - 1 ; }
public static void main ( String [ ] args ) { int ar [ ] = { 1 , 2 , 1 , 3 , 4 , 2 } ; int n = ar . length ; int k = 2 ; System . out . print ( printKDistinct ( ar , n , k ) ) ; } }
class Node { int data ; Node left , right ; public Node ( int data ) { this . data = data ; left = right = null ; } } class BinaryTree { Node a , b ;
boolean areMirror ( Node a , Node b ) {
if ( a == null && b == null ) return true ;
if ( a == null b == null ) return false ;
return a . data == b . data && areMirror ( a . left , b . right ) && areMirror ( a . right , b . left ) ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; Node a = new Node ( 1 ) ; Node b = new Node ( 1 ) ; a . left = new Node ( 2 ) ; a . right = new Node ( 3 ) ; a . left . left = new Node ( 4 ) ; a . left . right = new Node ( 5 ) ; b . left = new Node ( 3 ) ; b . right = new Node ( 2 ) ; b . right . left = new Node ( 5 ) ; b . right . right = new Node ( 4 ) ; if ( tree . areMirror ( a , b ) == true ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
public static void printPairs ( int arr [ ] , int n ) { Vector < Integer > v = new Vector < Integer > ( ) ;
for ( int i = 0 ; i < n ; i ++ )
for ( int j = i + 1 ; j < n ; j ++ )
if ( Math . abs ( arr [ i ] ) == Math . abs ( arr [ j ] ) ) v . add ( Math . abs ( arr [ i ] ) ) ;
if ( v . size ( ) == 0 ) return ;
Collections . sort ( v ) ;
for ( int i = 0 ; i < v . size ( ) ; i ++ ) System . out . print ( - v . get ( i ) + " ▁ " + v . get ( i ) ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 4 , 8 , 9 , - 4 , 1 , - 1 , - 8 , - 9 } ; int n = arr . length ; printPairs ( arr , n ) ; } }
static boolean canPairs ( int ar [ ] , int k ) {
if ( ar . length % 2 == 1 ) return false ;
HashMap < Integer , Integer > hm = new HashMap < > ( ) ;
for ( int i = 0 ; i < ar . length ; i ++ ) { int rem = ( ( ar [ i ] % k ) + k ) % k ; if ( ! hm . containsKey ( rem ) ) { hm . put ( rem , 0 ) ; } hm . put ( rem , hm . get ( rem ) + 1 ) ; }
for ( int i = 0 ; i < ar . length ; i ++ ) {
int rem = ( ( ar [ i ] % k ) + k ) % k ;
if ( 2 * rem == k ) {
if ( hm . get ( rem ) % 2 == 1 ) return false ; }
else if ( rem == 0 ) {
if ( hm . get ( rem ) % 2 == 1 ) return false ; }
else { if ( hm . get ( k - rem ) != hm . get ( rem ) ) return false ; } } return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 92 , 75 , 65 , 48 , 45 , 35 } ; int k = 10 ;
boolean ans = canPairs ( arr , k ) ; if ( ans ) System . out . println ( " True " ) ; else System . out . println ( " False " ) ; } }
static boolean findTriplet ( int a1 [ ] , int a2 [ ] , int a3 [ ] , int n1 , int n2 , int n3 , int sum ) { for ( int i = 0 ; i < n1 ; i ++ ) for ( int j = 0 ; j < n2 ; j ++ ) for ( int k = 0 ; k < n3 ; k ++ ) if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) return true ; return false ; }
public static void main ( String [ ] args ) { int a1 [ ] = { 1 , 2 , 3 , 4 , 5 } ; int a2 [ ] = { 2 , 3 , 6 , 1 , 2 } ; int a3 [ ] = { 3 , 2 , 4 , 5 , 6 } ; int sum = 9 ; int n1 = a1 . length ; int n2 = a2 . length ; int n3 = a3 . length ; if ( findTriplet ( a1 , a2 , a3 , n1 , n2 , n3 , sum ) ) System . out . print ( " Yes " ) ; else System . out . print ( " No " ) ; } }
static int maxLen ( int arr [ ] ) {
HashMap < Integer , Integer > hM = new HashMap < Integer , Integer > ( ) ;
int sum = 0 ;
int max_len = 0 ;
for ( int i = 0 ; i < arr . length ; i ++ ) {
sum += arr [ i ] ; if ( arr [ i ] == 0 && max_len == 0 ) max_len = 1 ; if ( sum == 0 ) max_len = i + 1 ;
Integer prev_i = hM . get ( sum ) ; if ( prev_i != null ) max_len = Math . max ( max_len , i - prev_i ) ;
else hM . put ( sum , i ) ; } return max_len ; }
public static void main ( String arg [ ] ) { int arr [ ] = { 15 , - 2 , 2 , - 8 , 1 , 7 , 10 , 23 } ; System . out . println ( " Length ▁ of ▁ the ▁ longest ▁ 0 ▁ sum ▁ subarray ▁ is ▁ " + maxLen ( arr ) ) ; } }
static int LongIncrConseqSubseq ( int arr [ ] , int n ) {
HashMap < Integer , Integer > map = new HashMap < > ( ) ;
map . put ( arr [ 0 ] , 1 ) ;
for ( int i = 1 ; i < n ; i ++ ) {
if ( map . containsKey ( arr [ i ] - 1 ) ) {
map . put ( arr [ i ] , map . get ( arr [ i ] - 1 ) + 1 ) ; map . remove ( arr [ i ] - 1 ) ; } else { map . put ( arr [ i ] , 1 ) ; } } return Collections . max ( map . values ( ) ) ; }
public static void main ( String args [ ] ) { Scanner sc = new Scanner ( System . in ) ; int n = sc . nextInt ( ) ; int arr [ ] = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = sc . nextInt ( ) ; System . out . println ( LongIncrConseqSubseq ( arr , n ) ) ; } }
static int longLenSub ( int [ ] arr , int n ) {
HashMap < Integer , Integer > um = new HashMap < Integer , Integer > ( ) ;
int longLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int len = 0 ;
if ( um . containsKey ( arr [ i ] - 1 ) && len < um . get ( arr [ i ] - 1 ) ) len = um . get ( arr [ i ] - 1 ) ;
if ( um . containsKey ( arr [ i ] + 1 ) && len < um . get ( arr [ i ] + 1 ) ) len = um . get ( arr [ i ] + 1 ) ;
um . put ( arr [ i ] , len + 1 ) ;
if ( longLen < um . get ( arr [ i ] ) ) longLen = um . get ( arr [ i ] ) ; }
return longLen ; }
public static void main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 , 3 , 2 } ; int n = arr . length ; System . out . println ( " Longest ▁ length ▁ subsequence ▁ = ▁ " + longLenSub ( arr , n ) ) ; } }
static int countWindowDistinct ( int win [ ] , int k ) { int dist_count = 0 ;
for ( int i = 0 ; i < k ; i ++ ) {
int j ; for ( j = 0 ; j < i ; j ++ ) if ( win [ i ] == win [ j ] ) break ; if ( j == i ) dist_count ++ ; } return dist_count ; }
static void countDistinct ( int arr [ ] , int n , int k ) {
for ( int i = 0 ; i <= n - k ; i ++ ) System . out . println ( countWindowDistinct ( Arrays . copyOfRange ( arr , i , arr . length ) , k ) ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 1 , 3 , 4 , 2 , 3 } , k = 4 ; countDistinct ( arr , arr . length , k ) ; } }
static boolean areElementsContiguous ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] > 1 ) return false ; return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = arr . length ; if ( areElementsContiguous ( arr , n ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static boolean areElementsContiguous ( int arr [ ] , int n ) {
int max = Integer . MIN_VALUE ; int min = Integer . MAX_VALUE ; for ( int i = 0 ; i < n ; i ++ ) { max = Math . max ( max , arr [ i ] ) ; min = Math . min ( min , arr [ i ] ) ; } int m = max - min + 1 ;
if ( m > n ) return false ;
boolean visited [ ] = new boolean [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) visited [ arr [ i ] - min ] = true ;
for ( int i = 0 ; i < m ; i ++ ) if ( visited [ i ] == false ) return false ; return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = arr . length ; if ( areElementsContiguous ( arr , n ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static Boolean areElementsContiguous ( int arr [ ] , int n ) {
HashSet < Integer > us = new HashSet < Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) us . add ( arr [ i ] ) ;
int count = 1 ;
int curr_ele = arr [ 0 ] - 1 ;
while ( us . contains ( curr_ele ) == true ) {
count ++ ;
curr_ele -- ; }
curr_ele = arr [ 0 ] + 1 ;
while ( us . contains ( curr_ele ) == true ) {
count ++ ;
curr_ele ++ ; }
return ( count == ( us . size ( ) ) ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 5 , 2 , 3 , 6 , 4 , 4 , 6 , 6 } ; int n = arr . length ; if ( areElementsContiguous ( arr , n ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
public static void subArraySum ( int [ ] arr , int n , int sum ) {
int cur_sum = 0 ; int start = 0 ; int end = - 1 ; HashMap < Integer , Integer > hashMap = new HashMap < > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { cur_sum = cur_sum + arr [ i ] ;
if ( cur_sum - sum == 0 ) { start = 0 ; end = i ; break ; }
if ( hashMap . containsKey ( cur_sum - sum ) ) { start = hashMap . get ( cur_sum - sum ) + 1 ; end = i ; break ; }
hashMap . put ( cur_sum , i ) ; }
if ( end == - 1 ) { System . out . println ( " No ▁ subarray ▁ with ▁ given ▁ sum ▁ exists " ) ; } else { System . out . println ( " Sum ▁ found ▁ between ▁ indexes ▁ " + start + " ▁ to ▁ " + end ) ; } }
public static void main ( String [ ] args ) { int [ ] arr = { 10 , 2 , - 2 , - 20 , 10 } ; int n = arr . length ; int sum = - 10 ; subArraySum ( arr , n , sum ) ; } }
static int minInsertion ( String str ) {
int n = str . length ( ) ;
int res = 0 ;
int [ ] count = new int [ 26 ] ;
for ( int i = 0 ; i < n ; i ++ ) count [ str . charAt ( i ) - ' a ' ] ++ ;
for ( int i = 0 ; i < 26 ; i ++ ) { if ( count [ i ] % 2 == 1 ) res ++ ; }
return ( res == 0 ) ? 0 : res - 1 ; }
public static void main ( String [ ] args ) { String str = " geeksforgeeks " ; System . out . println ( minInsertion ( str ) ) ; } }
static int maxdiff ( int arr [ ] , int n ) { Map < Integer , Integer > freq = new HashMap < > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) freq . put ( arr [ i ] , freq . get ( arr [ i ] ) == null ? 1 : freq . get ( arr [ i ] ) + 1 ) ; int ans = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( freq . get ( arr [ i ] ) > freq . get ( arr [ j ] ) && arr [ i ] > arr [ j ] ) ans = Math . max ( ans , freq . get ( arr [ i ] ) - freq . get ( arr [ j ] ) ) ; else if ( freq . get ( arr [ i ] ) < freq . get ( arr [ j ] ) && arr [ i ] < arr [ j ] ) ans = Math . max ( ans , freq . get ( arr [ j ] ) - freq . get ( arr [ i ] ) ) ; } } return ans ; }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 1 , 3 , 2 , 3 , 2 } ; int n = arr . length ; System . out . println ( maxdiff ( arr , n ) ) ; } }
import java . util . * ; class GFG { static int findDiff ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ; int count = 0 , max_count = 0 , min_count = n ; for ( int i = 0 ; i < ( n - 1 ) ; i ++ ) {
if ( arr [ i ] == arr [ i + 1 ] ) { count += 1 ; continue ; } else { max_count = Math . max ( max_count , count ) ; min_count = Math . min ( min_count , count ) ; count = 0 ; } } return ( max_count - min_count ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 7 , 8 , 4 , 5 , 4 , 1 , 1 , 7 , 7 , 2 , 5 } ; int n = arr . length ; System . out . println ( findDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) { int SubsetSum_1 = 0 , SubsetSum_2 = 0 ; for ( int i = 0 ; i <= n - 1 ; i ++ ) { boolean isSingleOccurance = true ; for ( int j = i + 1 ; j <= n - 1 ; j ++ ) {
if ( arr [ i ] == arr [ j ] ) { isSingleOccurance = false ; arr [ i ] = arr [ j ] = 0 ; break ; } } if ( isSingleOccurance ) { if ( arr [ i ] > 0 ) SubsetSum_1 += arr [ i ] ; else SubsetSum_2 += arr [ i ] ; } } return Math . abs ( SubsetSum_1 - SubsetSum_2 ) ; }
static public void main ( String [ ] args ) { int [ ] arr = { 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 } ; int n = arr . length ; System . out . println ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxDiff ( int [ ] arr , int n ) { int result = 0 ;
Arrays . sort ( arr ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] != arr [ i + 1 ] ) result += Math . abs ( arr [ i ] ) ; else i ++ ; }
if ( arr [ n - 2 ] != arr [ n - 1 ] ) result += Math . abs ( arr [ n - 1 ] ) ;
return result ; }
static public void main ( String [ ] args ) { int [ ] arr = { 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 } ; int n = arr . length ; System . out . println ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n ) ) ; } }
public static int maxDiff ( int arr [ ] , int n ) { HashMap < Integer , Integer > hashPositive = new HashMap < > ( ) ; HashMap < Integer , Integer > hashNegative = new HashMap < > ( ) ; int SubsetSum_1 = 0 , SubsetSum_2 = 0 ;
for ( int i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] > 0 ) { if ( hashPositive . containsKey ( arr [ i ] ) ) { hashPositive . replace ( arr [ i ] , hashPositive . get ( arr [ i ] ) + 1 ) ; } else { hashPositive . put ( arr [ i ] , 1 ) ; } } }
for ( int i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] > 0 && hashPositive . containsKey ( arr [ i ] ) ) { if ( hashPositive . get ( arr [ i ] ) == 1 ) { SubsetSum_1 += arr [ i ] ; } } }
for ( int i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] < 0 ) { if ( hashNegative . containsKey ( Math . abs ( arr [ i ] ) ) ) { hashNegative . replace ( Math . abs ( arr [ i ] ) , hashNegative . get ( Math . abs ( arr [ i ] ) ) + 1 ) ; } else { hashNegative . put ( Math . abs ( arr [ i ] ) , 1 ) ; } } }
for ( int i = 0 ; i <= n - 1 ; i ++ ) { if ( arr [ i ] < 0 && hashNegative . containsKey ( Math . abs ( arr [ i ] ) ) ) { if ( hashNegative . get ( Math . abs ( arr [ i ] ) ) == 1 ) { SubsetSum_2 += arr [ i ] ; } } } return Math . abs ( SubsetSum_1 - SubsetSum_2 ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 4 , 2 , - 3 , 3 , - 2 , - 2 , 8 } ; int n = arr . length ; System . out . print ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n ) ) ; } }
static void minRange ( int arr [ ] , int n , int k ) { int l = 0 , r = n ;
for ( int i = 0 ; i < n ; i ++ ) {
Set < Integer > s = new HashSet < Integer > ( ) ; int j ; for ( j = i ; j < n ; j ++ ) { s . add ( arr [ j ] ) ; if ( s . size ( ) == k ) { if ( ( j - i ) < ( r - l ) ) { r = j ; l = i ; } break ; } }
if ( j == n ) break ; }
if ( l == 0 && r == n ) System . out . println ( " Invalid ▁ k " ) ; else System . out . println ( l + " ▁ " + r ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = arr . length ; int k = 3 ; minRange ( arr , n , k ) ; } }
static void minRange ( int arr [ ] , int n , int k ) {
int l = 0 , r = n ;
int j = - 1 ; HashMap < Integer , Integer > hm = new HashMap < > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { while ( j < n ) {
j ++ ;
if ( j < n && hm . size ( ) < k ) hm . put ( arr [ j ] , hm . getOrDefault ( arr [ j ] , 0 ) + 1 ) ;
if ( hm . size ( ) == k && ( ( r - l ) >= ( j - i ) ) ) { l = i ; r = j ; break ; } }
if ( hm . size ( ) < k ) break ;
while ( hm . size ( ) == k ) { if ( hm . getOrDefault ( arr [ i ] , 0 ) == 1 ) hm . remove ( arr [ i ] ) ; else hm . put ( arr [ i ] , hm . getOrDefault ( arr [ i ] , 0 ) - 1 ) ;
i ++ ;
if ( hm . size ( ) == k && ( r - l ) >= ( j - i ) ) { l = i ; r = j ; } } if ( hm . getOrDefault ( arr [ i ] , 0 ) == 1 ) hm . remove ( arr [ i ] ) ; else hm . put ( arr [ i ] , hm . getOrDefault ( arr [ i ] , 0 ) - 1 ) ; } if ( l == 0 && r == n ) System . out . println ( " Invalid ▁ k " ) ; else System . out . println ( l + " ▁ " + r ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 2 , 2 , 3 , 3 , 4 , 5 } ; int n = arr . length ; int k = 3 ; minRange ( arr , n , k ) ; } }
static void longest ( int a [ ] , int n , int k ) { int [ ] freq = new int [ 7 ] ; int start = 0 , end = 0 , now = 0 , l = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
freq [ a [ i ] ] ++ ;
if ( freq [ a [ i ] ] == 1 ) now ++ ;
while ( now > k ) {
freq [ a [ l ] ] -- ;
if ( freq [ a [ l ] ] == 0 ) now -- ;
l ++ ; }
if ( i - l + 1 >= end - start + 1 ) { end = i ; start = l ; } }
for ( int i = start ; i <= end ; i ++ ) System . out . print ( a [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int a [ ] = { 6 , 5 , 1 , 2 , 3 , 2 , 1 , 4 , 5 } ; int n = a . length ; int k = 3 ; longest ( a , n , k ) ; } }
public static int sum ( int a [ ] , int n ) {
Map < Integer , Integer > cnt = new HashMap < Integer , Integer > ( ) ;
int ans = 0 , pre_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { ans += ( i * a [ i ] ) - pre_sum ; pre_sum += a [ i ] ;
if ( cnt . containsKey ( a [ i ] - 1 ) ) ans -= cnt . get ( a [ i ] - 1 ) ;
if ( cnt . containsKey ( a [ i ] + 1 ) ) ans += cnt . get ( a [ i ] + 1 ) ;
if ( cnt . containsKey ( a [ i ] ) ) { cnt . put ( a [ i ] , cnt . get ( a [ i ] ) + 1 ) ; } else { cnt . put ( a [ i ] , 1 ) ; } } return ans ; }
public static void main ( String args [ ] ) { int a [ ] = { 1 , 2 , 3 , 1 , 3 } ; int n = a . length ; System . out . println ( sum ( a , n ) ) ; } }
static int calculate ( int a [ ] , int n ) {
Arrays . sort ( a ) ; int count = 1 ; int answer = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == a [ i - 1 ] ) {
count += 1 ; } else {
answer = answer + ( count * ( count - 1 ) ) / 2 ; count = 1 ; } } answer = answer + ( count * ( count - 1 ) ) / 2 ; return answer ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 1 , 2 , 4 } ; int n = a . length ;
System . out . println ( calculate ( a , n ) ) ; } }
static int calculate ( int a [ ] , int n ) {
int maximum = Arrays . stream ( a ) . max ( ) . getAsInt ( ) ;
int frequency [ ] = new int [ maximum + 1 ] ;
for ( int i = 0 ; i < n ; i ++ ) {
frequency [ a [ i ] ] += 1 ; } int answer = 0 ;
for ( int i = 0 ; i < ( maximum ) + 1 ; i ++ ) {
answer = answer + frequency [ i ] * ( frequency [ i ] - 1 ) ; } return answer / 2 ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 1 , 2 , 4 } ; int n = a . length ;
System . out . println ( calculate ( a , n ) ) ; } }
static int countSubarrWithEqualZeroAndOne ( int arr [ ] , int n ) {
Map < Integer , Integer > um = new HashMap < > ( ) ; int curr_sum = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { curr_sum += ( arr [ i ] == 0 ) ? - 1 : arr [ i ] ; um . put ( curr_sum , um . get ( curr_sum ) == null ? 1 : um . get ( curr_sum ) + 1 ) ; } int count = 0 ;
for ( Map . Entry < Integer , Integer > itr : um . entrySet ( ) ) {
if ( itr . getValue ( ) > 1 ) count += ( ( itr . getValue ( ) * ( itr . getValue ( ) - 1 ) ) / 2 ) ; }
if ( um . containsKey ( 0 ) ) count += um . get ( 0 ) ;
return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 0 , 0 , 1 , 0 , 1 , 1 } ; int n = arr . length ; System . out . println ( " Count ▁ = ▁ " + countSubarrWithEqualZeroAndOne ( arr , n ) ) ; } }
static int lenOfLongSubarr ( int arr [ ] , int n ) {
HashMap < Integer , Integer > um = new HashMap < Integer , Integer > ( ) ; int sum = 0 , maxLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
sum += arr [ i ] == 0 ? - 1 : 1 ;
if ( sum == 1 ) maxLen = i + 1 ;
else if ( ! um . containsKey ( sum ) ) um . put ( sum , i ) ;
if ( um . containsKey ( sum - 1 ) ) {
if ( maxLen < ( i - um . get ( sum - 1 ) ) ) maxLen = i - um . get ( sum - 1 ) ; } }
return maxLen ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 1 , 1 , 0 , 0 , 1 } ; int n = arr . length ; System . out . println ( " Length ▁ = ▁ " + lenOfLongSubarr ( arr , n ) ) ; } }
static void printAllAPTriplets ( int [ ] arr , int n ) { ArrayList < Integer > s = new ArrayList < Integer > ( ) ; for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int diff = arr [ j ] - arr [ i ] ; boolean exists = s . contains ( arr [ i ] - diff ) ; if ( exists ) System . out . println ( arr [ i ] - diff + " ▁ " + arr [ i ] + " ▁ " + arr [ j ] ) ; } s . add ( arr [ i ] ) ; } }
public static void main ( String args [ ] ) { int [ ] arr = { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = arr . length ; printAllAPTriplets ( arr , n ) ; } }
static void findAllTriplets ( int arr [ ] , int n ) { for ( int i = 1 ; i < n - 1 ; i ++ ) {
for ( int j = i - 1 , k = i + 1 ; j >= 0 && k < n ; ) {
if ( arr [ j ] + arr [ k ] == 2 * arr [ i ] ) { System . out . println ( arr [ j ] + " ▁ " + arr [ i ] + " ▁ " + arr [ k ] ) ;
k ++ ; j -- ; }
else if ( arr [ j ] + arr [ k ] < 2 * arr [ i ] ) k ++ ; else j -- ; } } }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 6 , 9 , 12 , 17 , 22 , 31 , 32 , 35 , 42 } ; int n = arr . length ; findAllTriplets ( arr , n ) ; } }
public static void findTriplets ( int a [ ] , int n , int sum ) { int i ;
Arrays . sort ( a ) ;
boolean flag = false ;
for ( i = 0 ; i < n - 2 ; i ++ ) { if ( i == 0 a [ i ] > a [ i - 1 ] ) {
int start = i + 1 ;
int end = n - 1 ;
int target = sum - a [ i ] ; while ( start < end ) {
if ( start > i + 1 && a [ start ] == a [ start - 1 ] ) { start ++ ; continue ; }
if ( end < n - 1 && a [ end ] == a [ end + 1 ] ) { end -- ; continue ; }
if ( target == a [ start ] + a [ end ] ) { System . out . print ( " [ " + a [ i ] + " , " + a [ start ] + " , " + a [ end ] + " ] ▁ " ) ; flag = true ; start ++ ; end -- ; }
else if ( target > ( a [ start ] + a [ end ] ) ) { start ++ ; }
else { end -- ; } } } }
if ( flag == false ) { System . out . print ( " No ▁ Such ▁ Triplets ▁ Exist " ) ; } }
public static void main ( String [ ] args ) { int a [ ] = { 12 , 3 , 6 , 1 , 6 , 9 } ; int n = a . length ; int sum = 24 ;
findTriplets ( a , n , sum ) ; } }
static int countTriplets ( int arr [ ] , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) for ( int j = i + 1 ; j < n - 1 ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] * arr [ j ] * arr [ k ] == m ) count ++ ; return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 4 , 6 , 2 , 3 , 8 } ; int m = 24 ; System . out . println ( countTriplets ( arr , arr . length , m ) ) ; } }
static int countPairs ( int arr [ ] , int n ) { int ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ )
if ( arr [ i ] == arr [ j ] ) ans ++ ; return ans ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 2 } ; int n = arr . length ; System . out . println ( countPairs ( arr , n ) ) ; } }
public static int countPairs ( int arr [ ] , int n ) { HashMap < Integer , Integer > hm = new HashMap < > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( hm . containsKey ( arr [ i ] ) ) hm . put ( arr [ i ] , hm . get ( arr [ i ] ) + 1 ) ; else hm . put ( arr [ i ] , 1 ) ; } int ans = 0 ;
for ( Map . Entry < Integer , Integer > it : hm . entrySet ( ) ) { int count = it . getValue ( ) ; ans += ( count * ( count - 1 ) ) / 2 ; } return ans ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 1 , 2 , 3 , 1 } ; System . out . println ( countPairs ( arr , arr . length ) ) ; } }
class GFG { static final int N = 5 ;
static int ptr [ ] = new int [ 501 ] ;
static void findSmallestRange ( int arr [ ] [ ] , int n , int k ) { int i , minval , maxval , minrange , minel = 0 , maxel = 0 , flag , minind ;
for ( i = 0 ; i <= k ; i ++ ) { ptr [ i ] = 0 ; } minrange = Integer . MAX_VALUE ; while ( true ) {
minind = - 1 ; minval = Integer . MAX_VALUE ; maxval = Integer . MIN_VALUE ; flag = 0 ;
for ( i = 0 ; i < k ; i ++ ) {
if ( ptr [ i ] == n ) { flag = 1 ; break ; }
if ( ptr [ i ] < n && arr [ i ] [ ptr [ i ] ] < minval ) {
minind = i ; minval = arr [ i ] [ ptr [ i ] ] ; }
if ( ptr [ i ] < n && arr [ i ] [ ptr [ i ] ] > maxval ) { maxval = arr [ i ] [ ptr [ i ] ] ; } }
if ( flag == 1 ) { break ; } ptr [ minind ] ++ ;
if ( ( maxval - minval ) < minrange ) { minel = minval ; maxel = maxval ; minrange = maxel - minel ; } } System . out . printf ( "The smallest range is [%d, %d]NEW_LINE", minel, maxel); }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 4 , 7 , 9 , 12 , 15 } , { 0 , 8 , 10 , 14 , 20 } , { 6 , 12 , 16 , 30 , 50 } } ; int k = arr . length ; findSmallestRange ( arr , N , k ) ; } }
static int countNum ( int [ ] arr , int n ) { int count = 0 ;
Arrays . sort ( arr ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) count += arr [ i + 1 ] - arr [ i ] - 1 ; return count ; }
static public void main ( String [ ] args ) { int [ ] arr = { 3 , 5 , 8 , 6 } ; int n = arr . length ; System . out . println ( countNum ( arr , n ) ) ; } }
static int countNum ( int arr [ ] , int n ) { HashSet < Integer > s = new HashSet < > ( ) ; int count = 0 , maxm = Integer . MIN_VALUE , minm = Integer . MAX_VALUE ;
for ( int i = 0 ; i < n ; i ++ ) { s . add ( arr [ i ] ) ; if ( arr [ i ] < minm ) minm = arr [ i ] ; if ( arr [ i ] > maxm ) maxm = arr [ i ] ; }
for ( int i = minm ; i <= maxm ; i ++ ) if ( ! s . contains ( i ) ) count ++ ; return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 5 , 8 , 6 } ; int n = arr . length ; System . out . println ( countNum ( arr , n ) ) ; } }
static int MAXN = 11 ;
static int ver = 2 ;
static int [ ] [ ] hashtable = new int [ ver ] [ MAXN ] ;
static int [ ] pos = new int [ ver ] ;
static void initTable ( ) { for ( int j = 0 ; j < MAXN ; j ++ ) for ( int i = 0 ; i < ver ; i ++ ) hashtable [ i ] [ j ] = Integer . MIN_VALUE ; }
static int hash ( int function , int key ) { switch ( function ) { case 1 : return key % MAXN ; case 2 : return ( key / MAXN ) % MAXN ; } return Integer . MIN_VALUE ; }
static void place ( int key , int tableID , int cnt , int n ) {
if ( cnt == n ) { System . out . printf ( "%d unpositionedNEW_LINE", key); System . out . printf ( "Cycle present. REHASH.NEW_LINE"); return ; }
for ( int i = 0 ; i < ver ; i ++ ) { pos [ i ] = hash ( i + 1 , key ) ; if ( hashtable [ i ] [ pos [ i ] ] == key ) return ; }
if ( hashtable [ tableID ] [ pos [ tableID ] ] != Integer . MIN_VALUE ) { int dis = hashtable [ tableID ] [ pos [ tableID ] ] ; hashtable [ tableID ] [ pos [ tableID ] ] = key ; place ( dis , ( tableID + 1 ) % ver , cnt + 1 , n ) ; }
else hashtable [ tableID ] [ pos [ tableID ] ] = key ; }
static void printTable ( ) { System . out . printf ( "Final hash tables:NEW_LINE"); for ( int i = 0 ; i < ver ; i ++ , System . out . printf ( "NEW_LINE")) for ( int j = 0 ; j < MAXN ; j ++ ) if ( hashtable [ i ] [ j ] == Integer . MIN_VALUE ) System . out . printf ( " - ▁ " ) ; else System . out . printf ( " % d ▁ " , hashtable [ i ] [ j ] ) ; System . out . printf ( "NEW_LINE"); }
static void cuckoo ( int keys [ ] , int n ) {
initTable ( ) ;
for ( int i = 0 , cnt = 0 ; i < n ; i ++ , cnt = 0 ) place ( keys [ i ] , 0 , cnt , n ) ;
printTable ( ) ; }
int keys_1 [ ] = { 20 , 50 , 53 , 75 , 100 , 67 , 105 , 3 , 36 , 39 } ; int n = keys_1 . length ; cuckoo ( keys_1 , n ) ;
int keys_2 [ ] = { 20 , 50 , 53 , 75 , 100 , 67 , 105 , 3 , 36 , 39 , 6 } ; int m = keys_2 . length ; cuckoo ( keys_2 , m ) ; } }
public static int sumoflength ( int [ ] arr , int n ) {
Set < Integer > s = new HashSet < > ( ) ;
int j = 0 , ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { while ( j < n && ! s . contains ( arr [ j ] ) ) { s . add ( arr [ i ] ) ; j ++ ; }
ans += ( ( j - i ) * ( j - i + 1 ) ) / 2 ;
s . remove ( arr [ i ] ) ; } return ans ; }
public static void main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 3 , 4 } ; int n = arr . length ; System . out . println ( sumoflength ( arr , n ) ) ; } }
static int countDistictSubarray ( int arr [ ] , int n ) {
HashMap < Integer , Integer > vis = new HashMap < Integer , Integer > ( ) { @ Override public Integer get ( Object key ) { if ( ! containsKey ( key ) ) return 0 ; return super . get ( key ) ; } } ; for ( int i = 0 ; i < n ; ++ i ) vis . put ( arr [ i ] , 1 ) ; int k = vis . size ( ) ;
vis . clear ( ) ;
int ans = 0 , right = 0 , window = 0 ; for ( int left = 0 ; left < n ; ++ left ) { while ( right < n && window < k ) { vis . put ( arr [ right ] , vis . get ( arr [ right ] ) + 1 ) ; if ( vis . get ( arr [ right ] ) == 1 ) ++ window ; ++ right ; }
if ( window == k ) ans += ( n - right + 1 ) ;
vis . put ( arr [ left ] , vis . get ( arr [ left ] ) - 1 ) ;
if ( vis . get ( arr [ left ] ) == 0 ) -- window ; } return ans ; }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , 1 , 3 , 2 , 3 } ; System . out . println ( countDistictSubarray ( arr , arr . length ) ) ; } }
static int countSubarrays ( int [ ] arr , int n ) {
int difference = 0 ; int ans = 0 ;
int [ ] hash_positive = new int [ n + 1 ] ; int [ ] hash_negative = new int [ n + 1 ] ;
hash_positive [ 0 ] = 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ( arr [ i ] & 1 ) == 1 ) { difference ++ ; } else { difference -- ; }
if ( difference < 0 ) { ans += hash_negative [ - difference ] ; hash_negative [ - difference ] ++ ;
} else { ans += hash_positive [ difference ] ; hash_positive [ difference ] ++ ; } }
return ans ; }
public static void main ( String [ ] args ) { int [ ] arr = new int [ ] { 3 , 4 , 6 , 8 , 1 , 10 , 5 , 7 } ; int n = arr . length ;
System . out . println ( " Total ▁ Number ▁ of ▁ Even - Odd " + " ▁ subarrays ▁ are ▁ " + countSubarrays ( arr , n ) ) ; } }
class Node { int data ; Node left , right ; Node ( int val ) { data = val ; left = right = null ; } } class GFG { static int ans , lh , rh , f ; static Node k ; public static Node Root ;
static int height ( Node root ) { if ( root == null ) return 0 ; int left_height = height ( root . left ) ; int right_height = height ( root . right ) ;
if ( ans < 1 + left_height + right_height ) { ans = 1 + left_height + right_height ;
k = root ;
lh = left_height ; rh = right_height ; } return 1 + Math . max ( left_height , right_height ) ; }
static void printArray ( int [ ] ints , int len ) { int i ;
if ( f == 0 ) { for ( i = len - 1 ; i >= 0 ; i -- ) { System . out . print ( ints [ i ] + " ▁ " ) ; } } else if ( f == 1 ) { for ( i = 0 ; i < len ; i ++ ) { System . out . print ( ints [ i ] + " ▁ " ) ; } } }
static void printPathsRecur ( Node node , int [ ] path , int pathLen , int max ) { if ( node == null ) return ;
path [ pathLen ] = node . data ; pathLen ++ ;
if ( node . left == null && node . right == null ) {
if ( pathLen == max && ( f == 0 f == 1 ) ) { printArray ( path , pathLen ) ; f = 2 ; } } else {
printPathsRecur ( node . left , path , pathLen , max ) ; printPathsRecur ( node . right , path , pathLen , max ) ; } }
static void diameter ( Node root ) { if ( root == null ) return ;
ans = Integer . MIN_VALUE ; lh = 0 ; rh = 0 ;
f = 0 ; int height_of_tree = height ( root ) ; int [ ] lPath = new int [ 100 ] ; int pathlen = 0 ;
printPathsRecur ( k . left , lPath , pathlen , lh ) ; System . out . print ( k . data + " ▁ " ) ; int [ ] rPath = new int [ 100 ] ; f = 1 ;
printPathsRecur ( k . right , rPath , pathlen , rh ) ; }
GFG . Root = new Node ( 1 ) ; GFG . Root . left = new Node ( 2 ) ; GFG . Root . right = new Node ( 3 ) ; GFG . Root . left . left = new Node ( 4 ) ; GFG . Root . left . right = new Node ( 5 ) ; GFG . Root . left . right . left = new Node ( 6 ) ; GFG . Root . left . right . right = new Node ( 7 ) ; GFG . Root . left . left . right = new Node ( 8 ) ; GFG . Root . left . left . right . left = new Node ( 9 ) ; diameter ( Root ) ; } }
static int findLargestd ( int [ ] S , int n ) { boolean found = false ;
Arrays . sort ( S ) ;
for ( int i = n - 1 ; i >= 0 ; i -- ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) continue ; for ( int k = j + 1 ; k < n ; k ++ ) { if ( i == k ) continue ; for ( int l = k + 1 ; l < n ; l ++ ) { if ( i == l ) continue ;
if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) { found = true ; return S [ i ] ; } } } } } if ( found == false ) return Integer . MAX_VALUE ; return - 1 ; }
public static void main ( String [ ] args ) { int [ ] S = new int [ ] { 2 , 3 , 5 , 7 , 12 } ; int n = S . length ; int ans = findLargestd ( S , n ) ; if ( ans == Integer . MAX_VALUE ) System . out . println ( " No ▁ Solution " ) ; else System . out . println ( " Largest ▁ d ▁ such ▁ that ▁ " + " a ▁ + ▁ " + " b ▁ + ▁ c ▁ = ▁ d ▁ is ▁ " + ans ) ; } }
class Indexes { int i , j ; Indexes ( int i , int j ) { this . i = i ; this . j = j ; } int getI ( ) { return i ; } int getJ ( ) { return j ; } } class GFG {
static int findFourElements ( int [ ] arr , int n ) { HashMap < Integer , Indexes > map = new HashMap < > ( ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { map . put ( arr [ i ] + arr [ j ] , new Indexes ( i , j ) ) ; } } int d = Integer . MIN_VALUE ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int abs_diff = Math . abs ( arr [ i ] - arr [ j ] ) ;
if ( map . containsKey ( abs_diff ) ) { Indexes indexes = map . get ( abs_diff ) ;
if ( indexes . getI ( ) != i && indexes . getI ( ) != j && indexes . getJ ( ) != i && indexes . getJ ( ) != j ) { d = Math . max ( d , Math . max ( arr [ i ] , arr [ j ] ) ) ; } } } } return d ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 3 , 5 , 7 , 12 } ; int n = arr . length ; int res = findFourElements ( arr , n ) ; if ( res == Integer . MIN_VALUE ) System . out . println ( " No ▁ Solution " ) ; else System . out . println ( res ) ; } }
static void recaman ( int n ) {
int arr [ ] = new int [ n ] ;
arr [ 0 ] = 0 ; System . out . print ( arr [ 0 ] + " ▁ , " ) ;
for ( int i = 1 ; i < n ; i ++ ) { int curr = arr [ i - 1 ] - i ; int j ; for ( j = 0 ; j < i ; j ++ ) {
if ( ( arr [ j ] == curr ) curr < 0 ) { curr = arr [ i - 1 ] + i ; break ; } } arr [ i ] = curr ; System . out . print ( arr [ i ] + " , ▁ " ) ; } }
public static void main ( String [ ] args ) { int n = 17 ; recaman ( n ) ; } }
static void recaman ( int n ) { if ( n <= 0 ) return ;
System . out . printf ( " % d , ▁ " , 0 ) ; HashSet < Integer > s = new HashSet < Integer > ( ) ; s . add ( 0 ) ;
int prev = 0 ; for ( int i = 1 ; i < n ; i ++ ) { int curr = prev - i ;
if ( curr < 0 || s . contains ( curr ) ) curr = prev + i ; s . add ( curr ) ; System . out . printf ( " % d , ▁ " , curr ) ; prev = curr ; } }
public static void main ( String [ ] args ) { int n = 17 ; recaman ( n ) ; } }
static int sumOfDiv ( int x ) {
int sum = 1 ; for ( int i = 2 ; i <= Math . sqrt ( x ) ; i ++ ) { if ( x % i == 0 ) { sum += i ;
if ( x / i != i ) sum += x / i ; } } return sum ; }
static boolean isAmicable ( int a , int b ) { return ( sumOfDiv ( a ) == b && sumOfDiv ( b ) == a ) ; }
static int countPairs ( int arr [ ] , int n ) {
HashSet < Integer > s = new HashSet < Integer > ( ) ; int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) s . add ( arr [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( s . contains ( sumOfDiv ( arr [ i ] ) ) ) {
int sum = sumOfDiv ( arr [ i ] ) ; if ( isAmicable ( arr [ i ] , sum ) ) count ++ ; } }
return count / 2 ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 220 , 284 , 1184 , 1210 , 2 , 5 } ; int n1 = arr1 . length ; System . out . println ( countPairs ( arr1 , n1 ) ) ; int arr2 [ ] = { 2620 , 2924 , 5020 , 5564 , 6232 , 6368 } ; int n2 = arr2 . length ; System . out . println ( countPairs ( arr2 , n2 ) ) ; } }
static int findArea ( Integer arr [ ] , int n ) {
Arrays . sort ( arr , Collections . reverseOrder ( ) ) ;
int [ ] dimension = { 0 , 0 } ;
for ( int i = 0 , j = 0 ; i < n - 1 && j < 2 ; i ++ )
if ( arr [ i ] == arr [ i + 1 ] ) dimension [ j ++ ] = arr [ i ++ ] ;
return ( dimension [ 0 ] * dimension [ 1 ] ) ; }
public static void main ( String args [ ] ) { Integer arr [ ] = { 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 } ; int n = arr . length ; System . out . println ( findArea ( arr , n ) ) ; } }
static int findArea ( int arr [ ] , int n ) { Set < Integer > s = new HashSet < > ( ) ;
int first = 0 , second = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( ! s . contains ( arr [ i ] ) ) { s . add ( arr [ i ] ) ; continue ; }
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; } else if ( arr [ i ] > second ) second = arr [ i ] ; }
return ( first * second ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 4 , 2 , 1 , 4 , 6 , 6 , 2 , 5 } ; int n = arr . length ; System . out . println ( findArea ( arr , n ) ) ; } }
import java . util . ArrayList ; class Graph { static final int MAX_PATH_SIZE = 1000 ;
static class Node { char data ; Node left , right ; } ;
static Node newNode ( char data ) { Node temp = new Node ( ) ; temp . data = data ; temp . left = temp . right = null ; return temp ; }
static class PATH { int Hd ; char key ; public PATH ( int Hd , char key ) { this . Hd = Hd ; this . key = key ; } public PATH ( ) { } } ;
static void printPath ( ArrayList < PATH > path , int size ) {
int minimum_Hd = Integer . MAX_VALUE ; PATH p ;
for ( int it = 0 ; it < size ; it ++ ) { p = path . get ( it ) ; minimum_Hd = Math . min ( minimum_Hd , p . Hd ) ; }
for ( int it = 0 ; it < size ; it ++ ) {
p = path . get ( it ) ; int noOfUnderScores = Math . abs ( p . Hd - minimum_Hd ) ;
for ( int i = 0 ; i < noOfUnderScores ; i ++ ) System . out . print ( " _ " ) ;
System . out . println ( p . key ) ; } System . out . println ( " = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = " ) ; }
static void printAllPathsUtil ( Node root , ArrayList < PATH > AllPath , int HD , int order ) {
if ( root == null ) return ;
if ( root . left == null && root . right == null ) {
AllPath . set ( order , new PATH ( HD , root . data ) ) ; printPath ( AllPath , order + 1 ) ; return ; }
AllPath . set ( order , new PATH ( HD , root . data ) ) ;
printAllPathsUtil ( root . left , AllPath , HD - 1 , order + 1 ) ;
printAllPathsUtil ( root . right , AllPath , HD + 1 , order + 1 ) ; } static void printAllPaths ( Node root ) {
if ( root == null ) return ; ArrayList < PATH > Allpaths = new ArrayList < > ( ) ; for ( int i = 0 ; i < MAX_PATH_SIZE ; i ++ ) { Allpaths . add ( new PATH ( ) ) ; } printAllPathsUtil ( root , Allpaths , 0 , 0 ) ; }
public static void main ( String [ ] args ) { Node root = newNode ( ' A ' ) ; root . left = newNode ( ' B ' ) ; root . right = newNode ( ' C ' ) ; root . left . left = newNode ( ' D ' ) ; root . left . right = newNode ( ' E ' ) ; root . right . left = newNode ( ' F ' ) ; root . right . right = newNode ( ' G ' ) ; printAllPaths ( root ) ; } }
static int longLenStrictBitonicSub ( int arr [ ] , int n ) {
HashMap < Integer , Integer > inc = new HashMap < Integer , Integer > ( ) ; HashMap < Integer , Integer > dcr = new HashMap < Integer , Integer > ( ) ;
int len_inc [ ] = new int [ n ] ; int len_dcr [ ] = new int [ n ] ;
int longLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int len = 0 ;
if ( inc . containsKey ( arr [ i ] - 1 ) ) len = inc . get ( arr [ i ] - 1 ) ;
len_inc [ i ] = len + 1 ; inc . put ( arr [ i ] , len_inc [ i ] ) ; }
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int len = 0 ;
if ( dcr . containsKey ( arr [ i ] - 1 ) ) len = dcr . get ( arr [ i ] - 1 ) ;
len_dcr [ i ] = len + 1 ; dcr . put ( arr [ i ] , len_dcr [ i ] ) ; }
for ( int i = 0 ; i < n ; i ++ ) if ( longLen < ( len_inc [ i ] + len_dcr [ i ] - 1 ) ) longLen = len_inc [ i ] + len_dcr [ i ] - 1 ;
return longLen ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 5 , 2 , 3 , 4 , 5 , 3 , 2 } ; int n = arr . length ; System . out . println ( " Longest ▁ length ▁ strict ▁ " + " bitonic ▁ subsequence ▁ = ▁ " + longLenStrictBitonicSub ( arr , n ) ) ; } }
public static void leftRotate ( int arr [ ] , int d , int n ) { leftRotateRec ( arr , 0 , d , n ) ; } public static void leftRotateRec ( int arr [ ] , int i , int d , int n ) {
if ( d == 0 d == n ) return ;
if ( n - d == d ) { swap ( arr , i , n - d + i , d ) ; return ; }
if ( d < n - d ) { swap ( arr , i , n - d + i , d ) ; leftRotateRec ( arr , i , d , n - d ) ; }
else { swap ( arr , i , d , n - d ) ; leftRotateRec ( arr , n - d + i , 2 * d - n , d ) ; } }
public static void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void swap ( int arr [ ] , int fi , int si , int d ) { int i , temp ; for ( i = 0 ; i < d ; i ++ ) { temp = arr [ fi + i ] ; arr [ fi + i ] = arr [ si + i ] ; arr [ si + i ] = temp ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; leftRotate ( arr , 2 , 7 ) ; printArray ( arr , 7 ) ; } }
static void leftRotate ( int arr [ ] , int d , int n ) { int i , j ; if ( d == 0 d == n ) return ; i = d ; j = n - d ; while ( i != j ) {
if ( i < j ) { swap ( arr , d - i , d + j - i , i ) ; j -= i ; }
else { swap ( arr , d - i , d , j ) ; i -= j ; } }
swap ( arr , d - i , d , i ) ; }
static int search ( int arr [ ] , int l , int h , int key ) { if ( l > h ) return - 1 ; int mid = ( l + h ) / 2 ; if ( arr [ mid ] == key ) return mid ;
if ( arr [ l ] <= arr [ mid ] ) {
if ( key >= arr [ l ] && key <= arr [ mid ] ) return search ( arr , l , mid - 1 , key ) ;
return search ( arr , mid + 1 , h , key ) ; }
if ( key >= arr [ mid ] && key <= arr [ h ] ) return search ( arr , mid + 1 , h , key ) ; return search ( arr , l , mid - 1 , key ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 4 , 5 , 6 , 7 , 8 , 9 , 1 , 2 , 3 } ; int n = arr . length ; int key = 6 ; int i = search ( arr , 0 , n - 1 , key ) ; if ( i != - 1 ) System . out . println ( " Index : ▁ " + i ) ; else System . out . println ( " Key ▁ not ▁ found " ) ; } }
static boolean pairInSortedRotated ( int arr [ ] , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) return true ;
if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 11 , 15 , 6 , 8 , 9 , 10 } ; int sum = 16 ; int n = arr . length ; if ( pairInSortedRotated ( arr , n , sum ) ) System . out . print ( " Array ▁ has ▁ two ▁ elements " + " ▁ with ▁ sum ▁ 16" ) ; else System . out . print ( " Array ▁ doesn ' t ▁ have ▁ two " + " ▁ elements ▁ with ▁ sum ▁ 16 ▁ " ) ; } }
static int pairsInSortedRotated ( int arr [ ] , int n , int x ) {
int i ; for ( i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
int l = ( i + 1 ) % n ;
int r = i ;
int cnt = 0 ;
while ( l != r ) {
if ( arr [ l ] + arr [ r ] == x ) { cnt ++ ;
if ( l == ( r - 1 + n ) % n ) { return cnt ; } l = ( l + 1 ) % n ; r = ( r - 1 + n ) % n ; }
else if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
else r = ( n + r - 1 ) % n ; } return cnt ; }
public static void main ( String [ ] args ) { int arr [ ] = { 11 , 15 , 6 , 7 , 9 , 10 } ; int sum = 16 ; int n = arr . length ; System . out . println ( pairsInSortedRotated ( arr , n , sum ) ) ; } }
static int maxSum ( ) {
int arrSum = 0 ;
int currVal = 0 ; for ( int i = 0 ; i < arr . length ; i ++ ) { arrSum = arrSum + arr [ i ] ; currVal = currVal + ( i * arr [ i ] ) ; }
int maxVal = currVal ;
for ( int j = 1 ; j < arr . length ; j ++ ) { currVal = currVal + arrSum - arr . length * arr [ arr . length - j ] ; if ( currVal > maxVal ) maxVal = currVal ; }
return maxVal ; }
public static void main ( String [ ] args ) { System . out . println ( " Max ▁ sum ▁ is ▁ " + maxSum ( ) ) ; } }
static int maxSum ( int arr [ ] , int n ) {
int res = Integer . MIN_VALUE ;
for ( int i = 0 ; i < n ; i ++ ) {
int curr_sum = 0 ;
for ( int j = 0 ; j < n ; j ++ ) { int index = ( i + j ) % n ; curr_sum += j * arr [ index ] ; }
res = Math . max ( res , curr_sum ) ; } return res ; }
public static void main ( String args [ ] ) { int arr [ ] = { 8 , 3 , 1 , 2 } ; int n = arr . length ; System . out . println ( maxSum ( arr , n ) ) ; } }
import java . io . * ; class GFG { static int maxSum ( int arr [ ] , int n ) {
int cum_sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) cum_sum += arr [ i ] ;
int curr_val = 0 ; for ( int i = 0 ; i < n ; i ++ ) curr_val += i * arr [ i ] ;
int res = curr_val ;
for ( int i = 1 ; i < n ; i ++ ) {
int next_val = curr_val - ( cum_sum - arr [ i - 1 ] ) + arr [ i - 1 ] * ( n - 1 ) ;
curr_val = next_val ;
res = Math . max ( res , next_val ) ; } return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { 8 , 3 , 1 , 2 } ; int n = arr . length ; System . out . println ( maxSum ( arr , n ) ) ; } }
static int countRotations ( int arr [ ] , int n ) {
int min = arr [ 0 ] , min_index = - 1 ; for ( int i = 0 ; i < n ; i ++ ) { if ( min > arr [ i ] ) { min = arr [ i ] ; min_index = i ; } } return min_index ; }
public static void main ( String [ ] args ) { int arr [ ] = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = arr . length ; System . out . println ( countRotations ( arr , n ) ) ; } }
static int countRotations ( int arr [ ] , int low , int high ) {
if ( high < low ) return 0 ;
if ( high == low ) return low ;
int mid = low + ( high - low ) / 2 ;
if ( mid < high && arr [ mid + 1 ] < arr [ mid ] ) return ( mid + 1 ) ;
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) return mid ;
if ( arr [ high ] > arr [ mid ] ) return countRotations ( arr , low , mid - 1 ) ; return countRotations ( arr , mid + 1 , high ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 15 , 18 , 2 , 3 , 6 , 12 } ; int n = arr . length ; System . out . println ( countRotations ( arr , 0 , n - 1 ) ) ; } }
static void preprocess ( int arr [ ] , int n , int temp [ ] ) {
for ( int i = 0 ; i < n ; i ++ ) temp [ i ] = temp [ i + n ] = arr [ i ] ; }
static void leftRotate ( int arr [ ] , int n , int k , int temp [ ] ) {
int start = k % n ;
for ( int i = start ; i < start + n ; i ++ ) System . out . print ( temp [ i ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . length ; int temp [ ] = new int [ 2 * n ] ; preprocess ( arr , n , temp ) ; int k = 2 ; leftRotate ( arr , n , k , temp ) ; k = 3 ; leftRotate ( arr , n , k , temp ) ; k = 4 ; leftRotate ( arr , n , k , temp ) ; } }
static void leftRotate ( int arr [ ] , int n , int k ) {
for ( int i = k ; i < k + n ; i ++ ) System . out . print ( arr [ i % n ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . length ; int k = 2 ; leftRotate ( arr , n , k ) ; System . out . println ( ) ; k = 3 ; leftRotate ( arr , n , k ) ; System . out . println ( ) ; k = 4 ; leftRotate ( arr , n , k ) ; System . out . println ( ) ; } }
public static int findMin ( int arr [ ] , int low , int high ) { while ( low < high ) { int mid = low + ( high - low ) / 2 ; if ( arr [ mid ] == arr [ high ] ) high -- ; else if ( arr [ mid ] > arr [ high ] ) low = mid + 1 ; else high = mid ; } return arr [ high ] ; }
public static void main ( String args [ ] ) { int arr1 [ ] = { 5 , 6 , 1 , 2 , 3 , 4 } ; int n1 = arr1 . length ; System . out . println ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr1 , 0 , n1 - 1 ) ) ; int arr2 [ ] = { 1 , 2 , 3 , 4 } ; int n2 = arr2 . length ; System . out . println ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr2 , 0 , n2 - 1 ) ) ; int arr3 [ ] = { 1 } ; int n3 = arr3 . length ; System . out . println ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr3 , 0 , n3 - 1 ) ) ; int arr4 [ ] = { 1 , 2 } ; int n4 = arr4 . length ; System . out . println ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr4 , 0 , n4 - 1 ) ) ; int arr5 [ ] = { 2 , 1 } ; int n5 = arr5 . length ; System . out . println ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr5 , 0 , n5 - 1 ) ) ; int arr6 [ ] = { 5 , 6 , 7 , 1 , 2 , 3 , 4 } ; int n6 = arr6 . length ; System . out . println ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr6 , 0 , n6 - 1 ) ) ; int arr7 [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int n7 = arr7 . length ; System . out . println ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr7 , 0 , n7 - 1 ) ) ; int arr8 [ ] = { 2 , 3 , 4 , 5 , 6 , 7 , 8 , 1 } ; int n8 = arr8 . length ; System . out . println ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr8 , 0 , n8 - 1 ) ) ; int arr9 [ ] = { 3 , 4 , 5 , 1 , 2 } ; int n9 = arr9 . length ; System . out . println ( " The ▁ minimum ▁ element ▁ is ▁ " + findMin ( arr9 , 0 , n9 - 1 ) ) ; } }
static void reverseArray ( int arr [ ] , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
static void rightRotate ( int arr [ ] , int d , int n ) { reverseArray ( arr , 0 , n - 1 ) ; reverseArray ( arr , 0 , d - 1 ) ; reverseArray ( arr , d , n - 1 ) ; }
static void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 } ; int n = arr . length ; int k = 3 ; rightRotate ( arr , k , n ) ; printArray ( arr , n ) ; } }
static int maxHamming ( int arr [ ] , int n ) {
int brr [ ] = new int [ 2 * n + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ i ] = arr [ i ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ n + i ] = arr [ i ] ;
int maxHam = 0 ;
for ( int i = 1 ; i < n ; i ++ ) { int currHam = 0 ; for ( int j = i , k = 0 ; j < ( i + n ) ; j ++ , k ++ ) if ( brr [ j ] != arr [ k ] ) currHam ++ ;
if ( currHam == n ) return n ; maxHam = Math . max ( maxHam , currHam ) ; } return maxHam ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 4 , 6 , 8 } ; int n = arr . length ; System . out . print ( maxHamming ( arr , n ) ) ; } }
static void leftRotate ( int arr [ ] , int n , int k ) {
int mod = k % n ;
for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ ( i + mod ) % n ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 5 , 7 , 9 } ; int n = arr . length ; int k = 2 ;
leftRotate ( arr , n , k ) ; k = 3 ;
leftRotate ( arr , n , k ) ; k = 4 ;
leftRotate ( arr , n , k ) ; } }
static int findElement ( int [ ] arr , int [ ] [ ] ranges , int rotations , int index ) { for ( int i = rotations - 1 ; i >= 0 ; i -- ) {
int left = ranges [ i ] [ 0 ] ; int right = ranges [ i ] [ 1 ] ;
if ( left <= index && right >= index ) { if ( index == left ) index = right ; else index -- ; } }
return arr [ index ] ; }
public static void main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ;
int rotations = 2 ;
int [ ] [ ] ranges = { { 0 , 2 } , { 0 , 3 } } ; int index = 1 ; System . out . println ( findElement ( arr , ranges , rotations , index ) ) ; } }
import java . util . * ; import java . lang . * ; class GFG { public static void splitArr ( int arr [ ] , int n , int k ) { for ( int i = 0 ; i < k ; i ++ ) {
int x = arr [ 0 ] ; for ( int j = 0 ; j < n - 1 ; ++ j ) arr [ j ] = arr [ j + 1 ] ; arr [ n - 1 ] = x ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = arr . length ; int position = 2 ; splitArr ( arr , 6 , position ) ; for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void SplitAndAdd ( int [ ] A , int length , int rotation ) {
int [ ] tmp = new int [ length * 2 ] ;
System . arraycopy ( A , 0 , tmp , 0 , length ) ; System . arraycopy ( A , 0 , tmp , length , length ) ; for ( int i = rotation ; i < rotation + length ; i ++ ) A [ i - rotation ] = tmp [ i ] ; }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = arr . length ; int position = 2 ; SplitAndAdd ( arr , n , position ) ; for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void fixArray ( int ar [ ] , int n ) { int i , j , temp ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) {
if ( ar [ j ] == i ) { temp = ar [ j ] ; ar [ j ] = ar [ i ] ; ar [ i ] = temp ; break ; } } }
for ( i = 0 ; i < n ; i ++ ) {
if ( ar [ i ] != i ) { ar [ i ] = - 1 ; } }
System . out . println ( " Array ▁ after ▁ Rearranging " ) ; for ( i = 0 ; i < n ; i ++ ) { System . out . print ( ar [ i ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int n , ar [ ] = { - 1 , - 1 , 6 , 1 , 9 , 3 , 2 , - 1 , 4 , - 1 } ; n = ar . length ;
fixArray ( ar , n ) ; } }
public static void rearrangeArr ( int arr [ ] , int n ) {
int evenPos = n / 2 ;
int oddPos = n - evenPos ; int [ ] tempArr = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) tempArr [ i ] = arr [ i ] ;
Arrays . sort ( tempArr ) ; int j = oddPos - 1 ;
for ( int i = 0 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j -- ; } j = oddPos ;
for ( int i = 1 ; i < n ; i += 2 ) { arr [ i ] = tempArr [ j ] ; j ++ ; }
for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String argc [ ] ) { int [ ] arr = new int [ ] { 1 , 2 , 3 , 4 , 5 , 6 , 7 } ; int size = 7 ; rearrangeArr ( arr , size ) ; } }
static void pushZerosToEnd ( int arr [ ] , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 } ; int n = arr . length ; pushZerosToEnd ( arr , n ) ; System . out . println ( " Array ▁ after ▁ pushing ▁ zeros ▁ to ▁ the ▁ back : ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static void moveZerosToEnd ( int arr [ ] , int n ) {
int count = 0 ; int temp ;
for ( int i = 0 ; i < n ; i ++ ) { if ( ( arr [ i ] != 0 ) ) { temp = arr [ count ] ; arr [ count ] = arr [ i ] ; arr [ i ] = temp ; count = count + 1 ; } } }
static void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 0 , 1 , 9 , 8 , 4 , 0 , 0 , 2 , 7 , 0 , 6 , 0 , 9 } ; int n = arr . length ; System . out . print ( " Original ▁ array : ▁ " ) ; printArray ( arr , n ) ; moveZerosToEnd ( arr , n ) ; System . out . print ( " Modified array : "); printArray ( arr , n ) ; } }
import java . io . * ; class GFG { static void printArray ( int [ ] array , int length ) { System . out . print ( " [ " ) ; for ( int i = 0 ; i < length ; i ++ ) { System . out . print ( array [ i ] ) ; if ( i < ( length - 1 ) ) System . out . print ( " , " ) ; else System . out . print ( "]NEW_LINE"); } } static void reverse ( int [ ] array , int start , int end ) { while ( start < end ) { int temp = array [ start ] ; array [ start ] = array [ end ] ; array [ end ] = temp ; start ++ ; end -- ; } }
static void rearrange ( int [ ] array , int start , int end ) {
if ( start == end ) return ;
rearrange ( array , ( start + 1 ) , end ) ;
if ( array [ start ] >= 0 ) { reverse ( array , ( start + 1 ) , end ) ; reverse ( array , start , end ) ; } }
public static void main ( String [ ] args ) { int [ ] array = { - 12 , - 11 , - 13 , - 5 , - 6 , 7 , 5 , 3 , 6 } ; int length = array . length ; int countNegative = 0 ; for ( int i = 0 ; i < length ; i ++ ) { if ( array [ i ] < 0 ) countNegative ++ ; } System . out . print ( " array : ▁ " ) ; printArray ( array , length ) ; rearrange ( array , 0 , ( length - 1 ) ) ; reverse ( array , countNegative , ( length - 1 ) ) ; System . out . print ( " rearranged ▁ array : ▁ " ) ; printArray ( array , length ) ; } }
static void pushZerosToEnd ( int arr [ ] , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != 0 )
arr [ count ++ ] = arr [ i ] ;
while ( count < n ) arr [ count ++ ] = 0 ; }
static void modifyAndRearrangeArr ( int arr [ ] , int n ) {
if ( n == 1 ) return ;
for ( int i = 0 ; i < n - 1 ; i ++ ) {
if ( ( arr [ i ] != 0 ) && ( arr [ i ] == arr [ i + 1 ] ) ) {
arr [ i ] = 2 * arr [ i ] ;
arr [ i + 1 ] = 0 ;
i ++ ; } }
pushZerosToEnd ( arr , n ) ; }
static void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 2 , 2 , 2 , 0 , 6 , 6 , 0 , 0 , 8 } ; int n = arr . length ; System . out . print ( " Original ▁ array : ▁ " ) ; printArray ( arr , n ) ; modifyAndRearrangeArr ( arr , n ) ; System . out . print ( " Modified ▁ array : ▁ " ) ; printArray ( arr , n ) ; } }
public static void swap ( int [ ] A , int i , int j ) { int temp = A [ i ] ; A [ i ] = A [ j ] ; A [ j ] = temp ; }
static void shiftAllZeroToLeft ( int array [ ] , int n ) {
int lastSeenNonZero = 0 ; for ( int index = 0 ; index < n ; index ++ ) {
if ( array [ index ] != 0 ) {
swap ( array , array [ index ] , array [ lastSeenNonZero ] ) ;
lastSeenNonZero ++ ; } } } }
static void reorder ( ) { int temp [ ] = new int [ arr . length ] ;
for ( int i = 0 ; i < arr . length ; i ++ ) temp [ index [ i ] ] = arr [ i ] ;
for ( int i = 0 ; i < arr . length ; i ++ ) { arr [ i ] = temp [ i ] ; index [ i ] = i ; } }
public static void main ( String [ ] args ) { reorder ( ) ; System . out . println ( " Reordered ▁ array ▁ is : ▁ " ) ; System . out . println ( Arrays . toString ( arr ) ) ; System . out . println ( " Modified ▁ Index ▁ array ▁ is : " ) ; System . out . println ( Arrays . toString ( index ) ) ; } }
static void reorder ( ) {
for ( int i = 0 ; i < arr . length ; i ++ ) {
while ( index [ i ] != i ) {
int oldTargetI = index [ index [ i ] ] ; char oldTargetE = ( char ) arr [ index [ i ] ] ;
arr [ index [ i ] ] = arr [ i ] ; index [ index [ i ] ] = index [ i ] ;
index [ i ] = oldTargetI ; arr [ i ] = oldTargetE ; } } }
public static void main ( String [ ] args ) { reorder ( ) ; System . out . println ( " Reordered ▁ array ▁ is : ▁ " ) ; System . out . println ( Arrays . toString ( arr ) ) ; System . out . println ( " Modified ▁ Index ▁ array ▁ is : " ) ; System . out . println ( Arrays . toString ( index ) ) ; } }
static void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
static void RearrangePosNeg ( int arr [ ] , int n ) { int key , j ; for ( int i = 1 ; i < n ; i ++ ) { key = arr [ i ] ;
if ( key > 0 ) continue ;
j = i - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { arr [ j + 1 ] = arr [ j ] ; j = j - 1 ; }
arr [ j + 1 ] = key ; } }
public static void main ( String [ ] args ) { int arr [ ] = { - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 } ; int n = arr . length ; RearrangePosNeg ( arr , n ) ; printArray ( arr , n ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
boolean isLeaf ( Node node ) { if ( node == null ) return false ; if ( node . left == null && node . right == null ) return true ; return false ; }
int leftLeavesSum ( Node node ) {
int res = 0 ;
if ( node != null ) {
if ( isLeaf ( node . left ) ) res += node . left . data ;
else res += leftLeavesSum ( node . left ) ;
res += leftLeavesSum ( node . right ) ; }
return res ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 20 ) ; tree . root . left = new Node ( 9 ) ; tree . root . right = new Node ( 49 ) ; tree . root . left . right = new Node ( 12 ) ; tree . root . left . left = new Node ( 5 ) ; tree . root . right . left = new Node ( 23 ) ; tree . root . right . right = new Node ( 52 ) ; tree . root . left . right . right = new Node ( 12 ) ; tree . root . right . right . left = new Node ( 50 ) ; System . out . println ( " The ▁ sum ▁ of ▁ leaves ▁ is ▁ " + tree . leftLeavesSum ( tree . root ) ) ; } }
static void printArray ( int A [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) System . out . print ( A [ i ] + " ▁ " ) ; System . out . println ( " " ) ; ; }
static void reverse ( int arr [ ] , int l , int r ) { if ( l < r ) { arr = swap ( arr , l , r ) ; reverse ( arr , ++ l , -- r ) ; } }
static void merge ( int arr [ ] , int l , int m , int r ) {
int i = l ;
int j = m + 1 ; while ( i <= m && arr [ i ] < 0 ) i ++ ;
while ( j <= r && arr [ j ] < 0 ) j ++ ;
reverse ( arr , i , m ) ;
reverse ( arr , m + 1 , j - 1 ) ;
reverse ( arr , i , j - 1 ) ; }
static void RearrangePosNeg ( int arr [ ] , int l , int r ) { if ( l < r ) {
int m = l + ( r - l ) / 2 ;
RearrangePosNeg ( arr , l , m ) ; RearrangePosNeg ( arr , m + 1 , r ) ; merge ( arr , l , m , r ) ; } } static int [ ] swap ( int [ ] arr , int i , int j ) { int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; return arr ; }
public static void main ( String [ ] args ) { int arr [ ] = { - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 } ; int arr_size = arr . length ; RearrangePosNeg ( arr , 0 , arr_size - 1 ) ; printArray ( arr , arr_size ) ; } }
import java . io . * ; class GFG { public static void RearrangePosNeg ( int arr [ ] ) { int i = 0 ; int j = arr . length - 1 ; while ( true ) {
while ( arr [ i ] < 0 && i < arr . length ) i ++ ;
while ( arr [ j ] > 0 && j >= 0 ) j -- ;
if ( i < j ) { int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } else break ; } }
public static void main ( String [ ] args ) { int arr [ ] = { - 12 , 11 , - 13 , - 5 , 6 , - 7 , 5 , - 3 , - 6 } ; RearrangePosNeg ( arr ) ; for ( int i = 0 ; i < arr . length ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
void rearrangeNaive ( int arr [ ] , int n ) {
int temp [ ] = new int [ n ] ; int i ;
for ( i = 0 ; i < n ; i ++ ) temp [ arr [ i ] ] = i ;
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
void printArray ( int arr [ ] , int n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } System . out . println ( " " ) ; }
public static void main ( String [ ] args ) { RearrangeArray arrange = new RearrangeArray ( ) ; int arr [ ] = { 1 , 3 , 0 , 2 } ; int n = arr . length ; System . out . println ( " Given ▁ array ▁ is ▁ " ) ; arrange . printArray ( arr , n ) ; arrange . rearrangeNaive ( arr , n ) ; System . out . println ( " Modified ▁ array ▁ is ▁ " ) ; arrange . printArray ( arr , n ) ; } }
static void rearrange ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) {
arr [ arr [ i ] % n ] += i * n ; } for ( int i = 0 ; i < n ; i ++ ) {
arr [ i ] /= n ; } }
static void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } System . out . println ( ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 0 , 1 , 4 , 5 , 3 } ; int n = arr . length ; System . out . println ( " Given ▁ array ▁ is ▁ : ▁ " ) ; printArray ( arr , n ) ; rearrange ( arr , n ) ; System . out . println ( " Modified ▁ array ▁ is ▁ : " ) ; printArray ( arr , n ) ; } }
static void rearrange ( int [ ] arr , int n ) {
int temp [ ] = arr . clone ( ) ;
int small = 0 , large = n - 1 ;
boolean flag = true ;
for ( int i = 0 ; i < n ; i ++ ) { if ( flag ) arr [ i ] = temp [ large -- ] ; else arr [ i ] = temp [ small ++ ] ; flag = ! flag ; } }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 1 , 2 , 3 , 4 , 5 , 6 } ; System . out . println ( " Original ▁ Array ▁ " ) ; System . out . println ( Arrays . toString ( arr ) ) ; rearrange ( arr , arr . length ) ; System . out . println ( " Modified ▁ Array ▁ " ) ; System . out . println ( Arrays . toString ( arr ) ) ; } }
public static void rearrange ( int arr [ ] , int n ) {
int max_idx = n - 1 , min_idx = 0 ;
int max_elem = arr [ n - 1 ] + 1 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] += ( arr [ max_idx ] % max_elem ) * max_elem ; max_idx -- ; }
else { arr [ i ] += ( arr [ min_idx ] % max_elem ) * max_elem ; min_idx ++ ; } }
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = arr [ i ] / max_elem ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = arr . length ; System . out . println ( " Original ▁ Array " ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; rearrange ( arr , n ) ; System . out . print ( " Modified Array "); for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void rearrange ( int arr [ ] , int n ) {
int max_ele = arr [ n - 1 ] ; int min_ele = arr [ 0 ] ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( i % 2 == 0 ) { arr [ i ] = max_ele ; max_ele -= 1 ; }
else { arr [ i ] = min_ele ; min_ele += 1 ; } } }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 } ; int n = arr . length ; System . out . println ( " Original ▁ Array " ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; rearrange ( arr , n ) ; System . out . print ( " Modified Array "); for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } }
class Sum { int sum = 0 ; } class BinaryTree {
Node root ; void leftLeavesSumRec ( Node node , boolean isleft , Sum summ ) { if ( node == null ) return ;
if ( node . left == null && node . right == null && isleft ) summ . sum = summ . sum + node . data ;
leftLeavesSumRec ( node . left , true , summ ) ; leftLeavesSumRec ( node . right , false , summ ) ; }
int leftLeavesSum ( Node node ) { Sum suum = new Sum ( ) ;
leftLeavesSumRec ( node , false , suum ) ; return suum . sum ; }
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 20 ) ; tree . root . left = new Node ( 9 ) ; tree . root . right = new Node ( 49 ) ; tree . root . left . right = new Node ( 12 ) ; tree . root . left . left = new Node ( 5 ) ; tree . root . right . left = new Node ( 23 ) ; tree . root . right . right = new Node ( 52 ) ; tree . root . left . right . right = new Node ( 12 ) ; tree . root . right . right . left = new Node ( 50 ) ; System . out . println ( " The ▁ sum ▁ of ▁ leaves ▁ is ▁ " + tree . leftLeavesSum ( tree . root ) ) ; } }
import java . io . * ; class GFG { static void rearrange ( int arr [ ] , int n ) { int j = 0 , temp ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < 0 ) { if ( i != j ) { temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } j ++ ; } } }
static void printArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { - 1 , 2 , - 3 , 4 , 5 , 6 , - 7 , 8 , 9 } ; int n = arr . length ; rearrange ( arr , n ) ; printArray ( arr , n ) ; } }
static void segregateElements ( int arr [ ] , int n ) {
int temp [ ] = new int [ n ] ;
int j = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] >= 0 ) temp [ j ++ ] = arr [ i ] ;
if ( j == n j == 0 ) return ;
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < 0 ) temp [ j ++ ] = arr [ i ] ;
for ( int i = 0 ; i < n ; i ++ ) arr [ i ] = temp [ i ] ; }
public static void main ( String arg [ ] ) { int arr [ ] = { 1 , - 1 , - 3 , - 2 , 7 , 5 , 11 , 6 } ; int n = arr . length ; segregateElements ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static void rearrange ( int arr [ ] , int n ) { int temp ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( i % 2 == 0 && arr [ i ] > arr [ i + 1 ] ) { temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } if ( i % 2 != 0 && arr [ i ] < arr [ i + 1 ] ) { temp = arr [ i ] ; arr [ i ] = arr [ i + 1 ] ; arr [ i + 1 ] = temp ; } } }
static void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 6 , 4 , 2 , 1 , 8 , 3 } ; int n = arr . length ; System . out . print ( "Before rearranging: NEW_LINE"); printArray ( arr , n ) ; rearrange ( arr , n ) ; System . out . print ( "After rearranging: NEW_LINE"); printArray ( arr , n ) ; } }
import java . io . * ; class GFG { static void rearrange ( int a [ ] , int size ) { int positive = 0 , negative = 1 , temp ; while ( true ) {
while ( positive < size && a [ positive ] >= 0 ) positive += 2 ;
while ( negative < size && a [ negative ] <= 0 ) negative += 2 ;
if ( positive < size && negative < size ) { temp = a [ positive ] ; a [ positive ] = a [ negative ] ; a [ negative ] = temp ; }
else break ; } }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 } ; int n = arr . length ; rearrange ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static void swap ( int [ ] a , int i , int j ) { int temp = a [ i ] ; a [ i ] = a [ j ] ; a [ j ] = temp ; }
static void printArray ( int [ ] a , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( a [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String args [ ] ) { int [ ] arr = { 1 , - 3 , 5 , 6 , - 3 , 6 , 7 , - 4 , 9 , 10 } ; int n = arr . length ;
printArray ( arr , n ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] >= 0 && i % 2 == 1 ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < 0 && j % 2 == 0 ) {
swap ( arr , i , j ) ; break ; } } } else if ( arr [ i ] < 0 && i % 2 == 0 ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] >= 0 && j % 2 == 1 ) {
swap ( arr , i , j ) ; break ; } } } }
printArray ( arr , n ) ; } }
import java . io . * ; class GFG { public static void arrayEvenAndOdd ( int arr [ ] , int n ) { int [ ] a ; a = new int [ n ] ; int ind = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] % 2 == 0 ) { a [ ind ] = arr [ i ] ; ind ++ ; } } for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] % 2 != 0 ) { a [ ind ] = arr [ i ] ; ind ++ ; } } for ( int i = 0 ; i < n ; i ++ ) { System . out . print ( a [ i ] + " ▁ " ) ; } System . out . println ( " " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 } ; int n = arr . length ;
arrayEvenAndOdd ( arr , n ) ; } }
static void arrayEvenAndOdd ( int arr [ ] , int n ) { int i = - 1 , j = 0 ; while ( j != n ) { if ( arr [ j ] % 2 == 0 ) { i ++ ;
int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; } j ++ ; }
for ( int k = 0 ; k < n ; k ++ ) System . out . print ( arr [ k ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 3 , 2 , 4 , 7 , 6 , 9 , 10 } ; int n = arr . length ; arrayEvenAndOdd ( arr , n ) ; } }
class Node { int key ; Node left , right ; public Node ( int item ) { key = item ; left = right = null ; } } class BinaryTree {
Node root ; BinaryTree ( ) { root = null ; }
void printPostorder ( Node node ) { if ( node == null ) return ;
printPostorder ( node . left ) ;
printPostorder ( node . right ) ;
System . out . print ( node . key + " ▁ " ) ; }
void printInorder ( Node node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
System . out . print ( node . key + " ▁ " ) ;
printInorder ( node . right ) ; }
void printPreorder ( Node node ) { if ( node == null ) return ;
System . out . print ( node . key + " ▁ " ) ;
printPreorder ( node . left ) ;
printPreorder ( node . right ) ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; System . out . println ( " Preorder ▁ traversal ▁ of ▁ binary ▁ tree ▁ is ▁ " ) ; tree . printPreorder ( ) ; System . out . println ( " Inorder traversal of binary tree is "); tree . printInorder ( ) ; System . out . println ( " Postorder traversal of binary tree is "); tree . printPostorder ( ) ; } }
static int largest ( ) { int i ;
int max = arr [ 0 ] ;
for ( i = 1 ; i < arr . length ; i ++ ) if ( arr [ i ] > max ) max = arr [ i ] ; return max ; }
public static void main ( String [ ] args ) { System . out . println ( " Largest ▁ in ▁ given ▁ array ▁ is ▁ " + largest ( ) ) ; } }
static int largest ( int [ ] arr , int n ) { Arrays . sort ( arr ) ; return arr [ n - 1 ] ; }
static public void main ( String [ ] args ) { int [ ] arr = { 10 , 324 , 45 , 90 , 9808 } ; int n = arr . length ; System . out . println ( largest ( arr , n ) ) ; } }
import java . io . * ; import java . util . Arrays ; class GFG { void find3largest ( int [ ] arr ) {
Arrays . sort ( arr ) ;
int n = arr . length ; int check = 0 , count = 1 ; for ( int i = 1 ; i <= n ; i ++ ) { if ( count < 4 ) { if ( check != arr [ n - i ] ) {
System . out . print ( arr [ n - i ] + " ▁ " ) ; check = arr [ n - i ] ; count ++ ; } } else break ; } }
public static void main ( String [ ] args ) { GFG obj = new GFG ( ) ; int [ ] arr = { 12 , 45 , 1 , - 1 , 45 , 54 , 23 , 5 , 0 , - 10 } ; obj . find3largest ( arr ) ; } }
import java . util . * ; import java . io . * ; class GFG { static void findElements ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) if ( arr [ j ] > arr [ i ] ) count ++ ; if ( count >= 2 ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . length ; findElements ( arr , n ) ; } }
import java . util . * ; import java . io . * ; class GFG { static void findElements ( int arr [ ] , int n ) { Arrays . sort ( arr ) ; for ( int i = 0 ; i < n - 2 ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . length ; findElements ( arr , n ) ; } }
import java . util . * ; import java . io . * ; class GFG { static void findElements ( int arr [ ] , int n ) { int first = Integer . MIN_VALUE ; int second = Integer . MAX_VALUE ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > first ) { second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) second = arr [ i ] ; } for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] < second ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , - 6 , 3 , 5 , 1 } ; int n = arr . length ; findElements ( arr , n ) ; } }
public static double findMean ( int a [ ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += a [ i ] ; return ( double ) sum / ( double ) n ; }
public static double findMedian ( int a [ ] , int n ) {
Arrays . sort ( a ) ;
if ( n % 2 != 0 ) return ( double ) a [ n / 2 ] ; return ( double ) ( a [ ( n - 1 ) / 2 ] + a [ n / 2 ] ) / 2.0 ; }
public static void main ( String args [ ] ) { int a [ ] = { 1 , 3 , 4 , 2 , 7 , 5 , 8 , 6 } ; int n = a . length ;
System . out . println ( " Mean ▁ = ▁ " + findMean ( a , n ) ) ; System . out . println ( " Median ▁ = ▁ " + findMedian ( a , n ) ) ; } }
public static void printSmall ( int arr [ ] , int n , int k ) {
for ( int i = k ; i < n ; ++ i ) {
int max_var = arr [ k - 1 ] ; int pos = k - 1 ; for ( int j = k - 2 ; j >= 0 ; j -- ) { if ( arr [ j ] > max_var ) { max_var = arr [ j ] ; pos = j ; } }
if ( max_var > arr [ i ] ) { int j = pos ; while ( j < k - 1 ) { arr [ j ] = arr [ j + 1 ] ; j ++ ; }
arr [ k - 1 ] = arr [ i ] ; } }
for ( int i = 0 ; i < k ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String argc [ ] ) { int [ ] arr = { 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 } ; int n = 10 ; int k = 5 ; printSmall ( arr , n , k ) ; } }
static void kSmallestPair ( int arr1 [ ] , int n1 , int arr2 [ ] , int n2 , int k ) { if ( k > n1 * n2 ) { System . out . print ( " k ▁ pairs ▁ don ' t ▁ exist " ) ; return ; }
int index2 [ ] = new int [ n1 ] ; while ( k > 0 ) {
int min_sum = Integer . MAX_VALUE ; int min_index = 0 ;
for ( int i1 = 0 ; i1 < n1 ; i1 ++ ) {
if ( index2 [ i1 ] < n2 && arr1 [ i1 ] + arr2 [ index2 [ i1 ] ] < min_sum ) {
min_index = i1 ;
min_sum = arr1 [ i1 ] + arr2 [ index2 [ i1 ] ] ; } } System . out . print ( " ( " + arr1 [ min_index ] + " , ▁ " + arr2 [ index2 [ min_index ] ] + " ) ▁ " ) ; index2 [ min_index ] ++ ; k -- ; } }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 3 , 11 } ; int n1 = arr1 . length ; int arr2 [ ] = { 2 , 4 , 8 } ; int n2 = arr2 . length ; int k = 4 ; kSmallestPair ( arr1 , n1 , arr2 , n2 , k ) ; } }
static void print2largest ( int arr [ ] , int arr_size ) { int i , first , second ;
if ( arr_size < 2 ) { System . out . printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
Arrays . sort ( arr ) ;
for ( i = arr_size - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] != arr [ arr_size - 1 ] ) { System . out . printf ( " The ▁ second ▁ largest ▁ " + "element is %dNEW_LINE", arr[i]); return ; } } System . out . printf ( " There ▁ is ▁ no ▁ second ▁ " + "largest elementNEW_LINE"); }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 35 , 1 , 10 , 34 , 1 } ; int n = arr . length ; print2largest ( arr , n ) ; } }
static int sumNodes ( int l ) {
int leafNodeCount = ( int ) Math . pow ( 2 , l - 1 ) ;
Vector < Vector < Integer > > vec = new Vector < Vector < Integer > > ( ) ;
for ( int i = 1 ; i <= l ; i ++ ) vec . add ( new Vector < Integer > ( ) ) ;
for ( int i = 1 ; i <= leafNodeCount ; i ++ ) vec . get ( l - 1 ) . add ( i ) ;
for ( int i = l - 2 ; i >= 0 ; i -- ) { int k = 0 ;
while ( k < vec . get ( i + 1 ) . size ( ) - 1 ) {
vec . get ( i ) . add ( vec . get ( i + 1 ) . get ( k ) + vec . get ( i + 1 ) . get ( k + 1 ) ) ; k += 2 ; } } int sum = 0 ;
for ( int i = 0 ; i < l ; i ++ ) { for ( int j = 0 ; j < vec . get ( i ) . size ( ) ; j ++ ) sum += vec . get ( i ) . get ( j ) ; } return sum ; }
public static void main ( String args [ ] ) { int l = 3 ; System . out . println ( sumNodes ( l ) ) ; } }
static void print2largest ( int arr [ ] , int arr_size ) { int i , first , second ;
if ( arr_size < 2 ) { System . out . printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; } int largest = second = Integer . MIN_VALUE ;
for ( i = 0 ; i < arr_size ; i ++ ) { largest = Math . max ( largest , arr [ i ] ) ; }
for ( i = 0 ; i < arr_size ; i ++ ) { if ( arr [ i ] != largest ) second = Math . max ( second , arr [ i ] ) ; } if ( second == Integer . MIN_VALUE ) System . out . printf ( " There ▁ is ▁ no ▁ second ▁ " + "largest elementNEW_LINE"); else System . out . printf ( " The ▁ second ▁ largest ▁ " + "element is %dNEW_LINE", second); }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 35 , 1 , 10 , 34 , 1 } ; int n = arr . length ; print2largest ( arr , n ) ; } }
int findFirstMissing ( int [ ] arr , int start , int end , int first ) { if ( start < end ) { int mid = ( start + end ) / 2 ;
if ( arr [ mid ] != mid + first ) return findFirstMissing ( arr , start , mid , first ) ; else return findFirstMissing ( arr , mid + 1 , end , first ) ; } return start + first ; }
int findSmallestMissinginSortedArray ( int [ ] arr ) {
if ( arr [ 0 ] != 0 ) return 0 ;
if ( arr [ arr . length - 1 ] == arr . length - 1 ) return arr . length ; int first = arr [ 0 ] ; return findFirstMissing ( arr , 0 , arr . length - 1 , first ) ; }
public static void main ( String [ ] args ) { GFG small = new GFG ( ) ; int arr [ ] = { 0 , 1 , 2 , 3 , 4 , 5 , 7 } ; int n = arr . length ;
System . out . println ( " First ▁ Missing ▁ element ▁ is ▁ : ▁ " + small . findSmallestMissinginSortedArray ( arr ) ) ; } }
static double sumNodes ( int l ) {
double leafNodeCount = Math . pow ( 2 , l - 1 ) ; double sumLastLevel = 0 ;
sumLastLevel = ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ;
double sum = sumLastLevel * l ; return sum ; }
public static void main ( String [ ] args ) { int l = 3 ; System . out . println ( sumNodes ( l ) ) ; } }
import java . io . * ; class GFG { static int MAX = 500 ;
static int [ ] [ ] lookup = new int [ MAX ] [ MAX ] ;
static void buildSparseTable ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) lookup [ i ] [ 0 ] = arr [ i ] ;
for ( int j = 1 ; ( 1 << j ) <= n ; j ++ ) {
for ( int i = 0 ; ( i + ( 1 << j ) - 1 ) < n ; i ++ ) {
if ( lookup [ i ] [ j - 1 ] < lookup [ i + ( 1 << ( j - 1 ) ) ] [ j - 1 ] ) lookup [ i ] [ j ] = lookup [ i ] [ j - 1 ] ; else lookup [ i ] [ j ] = lookup [ i + ( 1 << ( j - 1 ) ) ] [ j - 1 ] ; } } }
static int query ( int L , int R ) {
int j = ( int ) Math . log ( R - L + 1 ) ;
if ( lookup [ L ] [ j ] <= lookup [ R - ( 1 << j ) + 1 ] [ j ] ) return lookup [ L ] [ j ] ; else return lookup [ R - ( 1 << j ) + 1 ] [ j ] ; }
public static void main ( String [ ] args ) { int a [ ] = { 7 , 2 , 3 , 0 , 5 , 10 , 3 , 12 , 18 } ; int n = a . length ; buildSparseTable ( a , n ) ; System . out . println ( query ( 0 , 4 ) ) ; System . out . println ( query ( 4 , 7 ) ) ; System . out . println ( query ( 7 , 8 ) ) ; } }
static void add ( int arr [ ] , int N , int lo , int hi , int val ) { arr [ lo ] += val ; if ( hi != N - 1 ) arr [ hi + 1 ] -= val ; }
static void updateArray ( int arr [ ] , int N ) {
for ( int i = 1 ; i < N ; i ++ ) arr [ i ] += arr [ i - 1 ] ; }
static void printArr ( int arr [ ] , int N ) { updateArray ( arr , N ) ; for ( int i = 0 ; i < N ; i ++ ) System . out . print ( " " + arr [ i ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); }
public static void main ( String [ ] args ) { int N = 6 ; int arr [ ] = new int [ N ] ;
add ( arr , N , 0 , 2 , 100 ) ; add ( arr , N , 1 , 5 , 100 ) ; add ( arr , N , 2 , 3 , 100 ) ; printArr ( arr , N ) ; } }
class GFG { static final int MAX = 1000 ;
static int tree [ ] = new int [ 4 * MAX ] ;
static int arr [ ] = new int [ MAX ] ;
static int gcd ( int a , int b ) { if ( a == 0 ) { return b ; } return gcd ( b % a , a ) ; }
static int lcm ( int a , int b ) { return a * b / gcd ( a , b ) ; }
static void build ( int node , int start , int end ) {
if ( start == end ) { tree [ node ] = arr [ start ] ; return ; } int mid = ( start + end ) / 2 ;
build ( 2 * node , start , mid ) ; build ( 2 * node + 1 , mid + 1 , end ) ;
int left_lcm = tree [ 2 * node ] ; int right_lcm = tree [ 2 * node + 1 ] ; tree [ node ] = lcm ( left_lcm , right_lcm ) ; }
static int query ( int node , int start , int end , int l , int r ) {
if ( end < l start > r ) { return 1 ; }
if ( l <= start && r >= end ) { return tree [ node ] ; }
int mid = ( start + end ) / 2 ; int left_lcm = query ( 2 * node , start , mid , l , r ) ; int right_lcm = query ( 2 * node + 1 , mid + 1 , end , l , r ) ; return lcm ( left_lcm , right_lcm ) ; }
arr [ 0 ] = 5 ; arr [ 1 ] = 7 ; arr [ 2 ] = 5 ; arr [ 3 ] = 2 ; arr [ 4 ] = 10 ; arr [ 5 ] = 12 ; arr [ 6 ] = 11 ; arr [ 7 ] = 17 ; arr [ 8 ] = 14 ; arr [ 9 ] = 1 ; arr [ 10 ] = 44 ;
build ( 1 , 0 , 10 ) ;
System . out . println ( query ( 1 , 0 , 10 , 2 , 5 ) ) ;
System . out . println ( query ( 1 , 0 , 10 , 5 , 10 ) ) ;
System . out . println ( query ( 1 , 0 , 10 , 0 , 10 ) ) ; } }
static int GCD ( int a , int b ) { if ( b == 0 ) return a ; return GCD ( b , a % b ) ; }
static void FillPrefixSuffix ( int prefix [ ] , int arr [ ] , int suffix [ ] , int n ) {
prefix [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) prefix [ i ] = GCD ( prefix [ i - 1 ] , arr [ i ] ) ;
suffix [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) suffix [ i ] = GCD ( suffix [ i + 1 ] , arr [ i ] ) ; }
static int GCDoutsideRange ( int l , int r , int prefix [ ] , int suffix [ ] , int n ) {
if ( l == 0 ) return suffix [ r + 1 ] ;
if ( r == n - 1 ) return prefix [ l - 1 ] ; return GCD ( prefix [ l - 1 ] , suffix [ r + 1 ] ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 6 , 9 } ; int n = arr . length ; int prefix [ ] = new int [ n ] ; int suffix [ ] = new int [ n ] ; FillPrefixSuffix ( prefix , arr , suffix , n ) ; int l = 0 , r = 0 ; System . out . println ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; l = 1 ; r = 1 ; System . out . println ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; l = 1 ; r = 2 ; System . out . println ( GCDoutsideRange ( l , r , prefix , suffix , n ) ) ; } }
static int countInRange ( int arr [ ] , int n , int x , int y ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] >= x && arr [ i ] <= y ) count ++ ; } return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 4 , 9 , 10 , 3 } ; int n = arr . length ;
int i = 1 , j = 4 ; System . out . println ( countInRange ( arr , n , i , j ) ) ; i = 9 ; j = 12 ; System . out . println ( countInRange ( arr , n , i , j ) ) ; } }
static int lowerIndex ( int arr [ ] , int n , int x ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] >= x ) h = mid - 1 ; else l = mid + 1 ; } return l ; }
static int upperIndex ( int arr [ ] , int n , int y ) { int l = 0 , h = n - 1 ; while ( l <= h ) { int mid = ( l + h ) / 2 ; if ( arr [ mid ] <= y ) l = mid + 1 ; else h = mid - 1 ; } return h ; }
static int countInRange ( int arr [ ] , int n , int x , int y ) {
int count = 0 ; count = upperIndex ( arr , n , y ) - lowerIndex ( arr , n , x ) + 1 ; return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 4 , 4 , 9 , 10 , 3 } ; int n = arr . length ;
Arrays . sort ( arr ) ;
int i = 1 , j = 4 ; System . out . println ( countInRange ( arr , n , i , j ) ) ; ; i = 9 ; j = 12 ; System . out . println ( countInRange ( arr , n , i , j ) ) ; } }
static void precompute ( int arr [ ] , int n , int pre [ ] ) { Arrays . fill ( pre , 0 ) ; pre [ n - 1 ] = arr [ n - 1 ] * ( int ) ( Math . pow ( 2 , 0 ) ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) pre [ i ] = pre [ i + 1 ] + arr [ i ] * ( 1 << ( n - 1 - i ) ) ; }
static int decimalOfSubarr ( int arr [ ] , int l , int r , int n , int pre [ ] ) {
if ( r != n - 1 ) return ( pre [ l ] - pre [ r + 1 ] ) / ( 1 << ( n - 1 - r ) ) ; return pre [ l ] / ( 1 << ( n - 1 - r ) ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 0 , 1 , 0 , 1 , 1 } ; int n = arr . length ; int pre [ ] = new int [ n ] ; precompute ( arr , n , pre ) ; System . out . println ( decimalOfSubarr ( arr , 2 , 4 , n , pre ) ) ; System . out . println ( decimalOfSubarr ( arr , 4 , 5 , n , pre ) ) ; } }
static int answerQuery ( int a [ ] , int n , int l , int r ) {
int count = 0 ;
l = l - 1 ;
for ( int i = l ; i < r ; i ++ ) { int element = a [ i ] ; int divisors = 0 ;
for ( int j = l ; j < r ; j ++ ) {
if ( a [ j ] % a [ i ] == 0 ) divisors ++ ; else break ; }
if ( divisors == ( r - l ) ) count ++ ; }
return count ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 3 , 5 } ; int n = a . length ; int l = 1 , r = 4 ; System . out . println ( answerQuery ( a , n , l , r ) ) ; l = 2 ; r = 4 ; System . out . println ( answerQuery ( a , n , l , r ) ) ; } }
static class Node { int data ; Node left , right ; } ;
static HashMap < Integer , Integer > grid = new HashMap < > ( ) ;
static void addConsideringGrid ( Node root , int level , int index ) {
if ( root == null ) return ;
if ( grid . containsKey ( level - index ) ) grid . put ( level - index , grid . get ( level - index ) + ( root . data ) ) ; else grid . put ( level - index , root . data ) ;
addConsideringGrid ( root . left , level + 1 , index - 1 ) ;
addConsideringGrid ( root . right , level + 1 , index + 1 ) ; } static Vector < Integer > diagonalSum ( Node root ) { grid . clear ( ) ;
addConsideringGrid ( root , 0 , 0 ) ; Vector < Integer > ans = new Vector < > ( ) ;
for ( Map . Entry < Integer , Integer > x : grid . entrySet ( ) ) { ans . add ( x . getValue ( ) ) ; } return ans ; }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 9 ) ; root . left . right = newNode ( 6 ) ; root . right . left = newNode ( 4 ) ; root . right . right = newNode ( 5 ) ; root . right . left . right = newNode ( 7 ) ; root . right . left . left = newNode ( 12 ) ; root . left . right . left = newNode ( 11 ) ; root . left . left . right = newNode ( 10 ) ;
Vector < Integer > v = diagonalSum ( root ) ;
for ( int i = 0 ; i < v . size ( ) ; i ++ ) System . out . print ( v . get ( i ) + " ▁ " ) ; } }
import java . lang . Math ; class GFG { private static final int MAX = 2147483647 ; static int [ ] [ ] one = new int [ 100001 ] [ 32 ] ;
static void make_prefix ( int A [ ] , int n ) { for ( int j = 0 ; j < 32 ; j ++ ) one [ 0 ] [ j ] = 0 ;
for ( int i = 1 ; i <= n ; i ++ ) { int a = A [ i - 1 ] ; for ( int j = 0 ; j < 32 ; j ++ ) { int x = ( int ) Math . pow ( 2 , j ) ;
if ( ( a & x ) != 0 ) one [ i ] [ j ] = 1 + one [ i - 1 ] [ j ] ; else one [ i ] [ j ] = one [ i - 1 ] [ j ] ; } } }
static int Solve ( int L , int R ) { int l = L , r = R ; int tot_bits = r - l + 1 ;
int X = MAX ;
for ( int i = 0 ; i < 31 ; i ++ ) {
int x = one [ r ] [ i ] - one [ l - 1 ] [ i ] ;
if ( x >= tot_bits - x ) { int ith_bit = ( int ) Math . pow ( 2 , i ) ;
X = X ^ ith_bit ; } } return X ; }
public static void main ( String [ ] args ) { int n = 5 , q = 3 ; int A [ ] = { 210 , 11 , 48 , 22 , 133 } ; int L [ ] = { 1 , 4 , 2 } , R [ ] = { 3 , 14 , 4 } ; make_prefix ( A , n ) ; for ( int j = 0 ; j < q ; j ++ ) System . out . println ( Solve ( L [ j ] , R [ j ] ) ) ; } }
static void type1 ( int [ ] arr , int start , int limit ) {
for ( int i = start ; i <= limit ; i ++ ) arr [ i ] ++ ; }
static void type2 ( int [ ] arr , int [ ] [ ] query , int start , int limit ) { for ( int i = start ; i <= limit ; i ++ ) {
if ( query [ i ] [ 0 ] == 1 ) type1 ( arr , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ;
else if ( query [ i ] [ 0 ] == 2 ) type2 ( arr , query , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ; } }
int n = 5 , m = 5 ; int [ ] arr = new int [ n + 1 ] ;
int [ ] temp = { 1 , 1 , 2 , 1 , 4 , 5 , 2 , 1 , 2 , 2 , 1 , 3 , 2 , 3 , 4 } ; int [ ] [ ] query = new int [ 6 ] [ 4 ] ; int j = 0 ; for ( int i = 1 ; i <= m ; i ++ ) { query [ i ] [ 0 ] = temp [ j ++ ] ; query [ i ] [ 1 ] = temp [ j ++ ] ; query [ i ] [ 2 ] = temp [ j ++ ] ; }
for ( int i = 1 ; i <= m ; i ++ ) if ( query [ i ] [ 0 ] == 1 ) type1 ( arr , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ; else if ( query [ i ] [ 0 ] == 2 ) type2 ( arr , query , query [ i ] [ 1 ] , query [ i ] [ 2 ] ) ;
for ( int i = 1 ; i <= n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; } }
static void record_sum ( int record [ ] , int l , int r , int n , int adder ) { for ( int i = l ; i <= r ; i ++ ) { record [ i ] += adder ; } }
public static void main ( String [ ] args ) { int n = 5 , m = 5 ; int arr [ ] = new int [ n ] ;
Arrays . fill ( arr , 0 ) ; int query [ ] [ ] = { { 1 , 1 , 2 } , { 1 , 4 , 5 } , { 2 , 1 , 2 } , { 2 , 1 , 3 } , { 2 , 3 , 4 } } ; int record [ ] = new int [ m ] ; Arrays . fill ( record , 0 ) ; for ( int i = m - 1 ; i >= 0 ; i -- ) {
if ( query [ i ] [ 0 ] == 2 ) { record_sum ( record , query [ i ] [ 1 ] - 1 , query [ i ] [ 2 ] - 1 , m , record [ i ] + 1 ) ; }
else { record_sum ( record , i , i , m , 1 ) ; } }
for ( int i = 0 ; i < m ; i ++ ) { if ( query [ i ] [ 0 ] == 1 ) { record_sum ( arr , query [ i ] [ 1 ] - 1 , query [ i ] [ 2 ] - 1 , n , record [ i ] ) ; } }
for ( int i = 0 ; i < n ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } } }
static int solveQuery ( int start , int end , int arr [ ] ) {
Map < Integer , Integer > mp = new HashMap < > ( ) ;
for ( int i = start ; i <= end ; i ++ ) mp . put ( arr [ i ] , mp . get ( arr [ i ] ) == null ? 1 : mp . get ( arr [ i ] ) + 1 ) ;
int count = 0 ; for ( Map . Entry < Integer , Integer > entry : mp . entrySet ( ) ) if ( entry . getKey ( ) == entry . getValue ( ) ) count ++ ; return count ; }
public static void main ( String [ ] args ) { int A [ ] = { 1 , 2 , 2 , 3 , 3 , 3 } ; int n = A . length ;
int [ ] [ ] queries = { { 0 , 1 } , { 1 , 1 } , { 0 , 2 } , { 1 , 3 } , { 3 , 5 } , { 0 , 5 } } ;
int q = queries . length ; for ( int i = 0 ; i < q ; i ++ ) { int start = queries [ i ] [ 0 ] ; int end = queries [ i ] [ 1 ] ; System . out . println ( " Answer ▁ for ▁ Query ▁ " + ( i + 1 ) + " ▁ = ▁ " + solveQuery ( start , end , A ) ) ; } } }
static int answer_query ( int a [ ] , int n , int l , int r ) {
int count = 0 ; for ( int i = l ; i < r ; i ++ ) if ( a [ i ] == a [ i + 1 ] ) count += 1 ; return count ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = a . length ;
int L , R ; L = 1 ; R = 8 ; System . out . println ( answer_query ( a , n , L , R ) ) ;
L = 0 ; R = 4 ; System . out . println ( answer_query ( a , n , L , R ) ) ; } }
class GFG { public static int N = 1000 ;
static int prefixans [ ] = new int [ 1000 ] ;
public static void countIndex ( int a [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { if ( i + 1 < n && a [ i ] == a [ i + 1 ] ) prefixans [ i ] = 1 ; if ( i != 0 ) prefixans [ i ] += prefixans [ i - 1 ] ; } }
public static int answer_query ( int l , int r ) { if ( l == 0 ) return prefixans [ r - 1 ] ; else return prefixans [ r - 1 ] - prefixans [ l - 1 ] ; }
public static void main ( String args [ ] ) { int a [ ] = { 1 , 2 , 2 , 2 , 3 , 3 , 4 , 4 , 4 } ; int n = 9 ;
countIndex ( a , n ) ; int L , R ;
L = 1 ; R = 8 ; System . out . println ( answer_query ( L , R ) ) ;
L = 0 ; R = 4 ; System . out . println ( answer_query ( L , R ) ) ; } }
static void initializeDiffArray ( int A [ ] , int D [ ] ) { int n = A . length ;
D [ 0 ] = A [ 0 ] ; D [ n ] = 0 ; for ( int i = 1 ; i < n ; i ++ ) D [ i ] = A [ i ] - A [ i - 1 ] ; }
static void update ( int D [ ] , int l , int r , int x ) { D [ l ] += x ; D [ r + 1 ] -= x ; }
static int printArray ( int A [ ] , int D [ ] ) { for ( int i = 0 ; i < A . length ; i ++ ) { if ( i == 0 ) A [ i ] = D [ i ] ;
else A [ i ] = D [ i ] + A [ i - 1 ] ; System . out . print ( A [ i ] + " ▁ " ) ; } System . out . println ( ) ; return 0 ; }
int A [ ] = { 10 , 5 , 20 , 40 } ; int n = A . length ;
int D [ ] = new int [ n + 1 ] ; initializeDiffArray ( A , D ) ;
update ( D , 0 , 1 , 10 ) ; printArray ( A , D ) ;
update ( D , 1 , 3 , 20 ) ; update ( D , 2 , 2 , 30 ) ; printArray ( A , D ) ; } }
import java . io . * ; import java . util . * ; class Kadane { static int maxSubArraySum ( int a [ ] ) { int size = a . length ; int max_so_far = Integer . MIN_VALUE , max_ending_here = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here = max_ending_here + a [ i ] ; if ( max_so_far < max_ending_here ) max_so_far = max_ending_here ; if ( max_ending_here < 0 ) max_ending_here = 0 ; } return max_so_far ; }
public static void main ( String [ ] args ) { int [ ] a = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; System . out . println ( " Maximum ▁ contiguous ▁ sum ▁ is ▁ " + maxSubArraySum ( a ) ) ; } }
import java . io . * ; class GFG { static int maxSubArraySum ( int a [ ] , int size ) { int max_so_far = a [ 0 ] ; int curr_max = a [ 0 ] ; for ( int i = 1 ; i < size ; i ++ ) { curr_max = Math . max ( a [ i ] , curr_max + a [ i ] ) ; max_so_far = Math . max ( max_so_far , curr_max ) ; } return max_so_far ; }
public static void main ( String [ ] args ) { int a [ ] = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; int n = a . length ; int max_sum = maxSubArraySum ( a , n ) ; System . out . println ( " Maximum ▁ contiguous ▁ sum ▁ is ▁ " + max_sum ) ; } }
import java . io . * ; import java . util . * ; class GFG { public static void main ( String [ ] args ) { Scanner sc = new Scanner ( System . in ) ; int price [ ] = { 2 , 30 , 15 , 10 , 8 , 25 , 80 } ;
int profit = 0 ;
for ( int i = 1 ; i < price . length ; i ++ ) {
int sub = price [ i ] - price [ i - 1 ] ; if ( sub > 0 ) profit += sub ; } System . out . print ( " Maximum ▁ Profit = " + profit ) ; } }
static void findMinAvgSubarray ( int n , int k ) {
if ( n < k ) return ;
int res_index = 0 ;
int curr_sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) curr_sum += arr [ i ] ;
int min_sum = curr_sum ;
for ( int i = k ; i < n ; i ++ ) {
curr_sum += arr [ i ] - arr [ i - k ] ;
if ( curr_sum < min_sum ) { min_sum = curr_sum ; res_index = ( i - k + 1 ) ; } } System . out . println ( " Subarray ▁ between ▁ [ " + res_index + " , ▁ " + ( res_index + k - 1 ) + " ] ▁ has ▁ minimum ▁ average " ) ; }
public static void main ( String [ ] args ) {
int k = 3 ; findMinAvgSubarray ( arr . length , k ) ; } }
static int minJumps ( int arr [ ] , int n ) {
int [ ] jumps = new int [ n ] ; int min ;
jumps [ n - 1 ] = 0 ;
for ( int i = n - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] == 0 ) jumps [ i ] = Integer . MAX_VALUE ;
else if ( arr [ i ] >= n - i - 1 ) jumps [ i ] = 1 ;
else {
min = Integer . MAX_VALUE ;
for ( int j = i + 1 ; j < n && j <= arr [ i ] + i ; j ++ ) { if ( min > jumps [ j ] ) min = jumps [ j ] ; }
if ( min != Integer . MAX_VALUE ) jumps [ i ] = min + 1 ; else
jumps [ i ] = min ; } } return jumps [ 0 ] ; }
public static void main ( String [ ] args ) { int [ ] arr = { 1 , 3 , 6 , 1 , 0 , 9 } ; int size = arr . length ; System . out . println ( " Minimum ▁ number ▁ of " + " ▁ jumps ▁ to ▁ reach ▁ end ▁ is ▁ " + minJumps ( arr , size ) ) ; } }
static int smallestSubWithSum ( int arr [ ] , int n , int x ) {
int min_len = n + 1 ;
for ( int start = 0 ; start < n ; start ++ ) {
int curr_sum = arr [ start ] ;
if ( curr_sum > x ) return 1 ;
for ( int end = start + 1 ; end < n ; end ++ ) {
curr_sum += arr [ end ] ;
if ( curr_sum > x && ( end - start + 1 ) < min_len ) min_len = ( end - start + 1 ) ; } } return min_len ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = arr1 . length ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; if ( res1 == n1 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res1 ) ; int arr2 [ ] = { 1 , 10 , 5 , 2 , 7 } ; int n2 = arr2 . length ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; if ( res2 == n2 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res2 ) ; int arr3 [ ] = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = arr3 . length ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; if ( res3 == n3 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res3 ) ; } }
static int smallestSubWithSum ( int arr [ ] , int n , int x ) {
int curr_sum = 0 , min_len = n + 1 ;
int start = 0 , end = 0 ; while ( end < n ) {
while ( curr_sum <= x && end < n ) curr_sum += arr [ end ++ ] ;
while ( curr_sum > x && start < n ) {
if ( end - start < min_len ) min_len = end - start ;
curr_sum -= arr [ start ++ ] ; } } return min_len ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 1 , 4 , 45 , 6 , 10 , 19 } ; int x = 51 ; int n1 = arr1 . length ; int res1 = smallestSubWithSum ( arr1 , n1 , x ) ; if ( res1 == n1 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res1 ) ; int arr2 [ ] = { 1 , 10 , 5 , 2 , 7 } ; int n2 = arr2 . length ; x = 9 ; int res2 = smallestSubWithSum ( arr2 , n2 , x ) ; if ( res2 == n2 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res2 ) ; int arr3 [ ] = { 1 , 11 , 100 , 1 , 0 , 200 , 3 , 2 , 1 , 250 } ; int n3 = arr3 . length ; x = 280 ; int res3 = smallestSubWithSum ( arr3 , n3 , x ) ; if ( res3 == n3 + 1 ) System . out . println ( " Not ▁ Possible " ) ; else System . out . println ( res3 ) ; } }
static int findMaxAverage ( int [ ] arr , int n , int k ) {
if ( k > n ) return - 1 ;
int [ ] csum = new int [ n ] ; csum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) csum [ i ] = csum [ i - 1 ] + arr [ i ] ;
int max_sum = csum [ k - 1 ] , max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { int curr_sum = csum [ i ] - csum [ i - k ] ; if ( curr_sum > max_sum ) { max_sum = curr_sum ; max_end = i ; } }
return max_end - k + 1 ; }
static public void main ( String [ ] args ) { int [ ] arr = { 1 , 12 , - 5 , - 6 , 50 , 3 } ; int k = 4 ; int n = arr . length ; System . out . println ( " The ▁ maximum ▁ " + " average ▁ subarray ▁ of ▁ length ▁ " + k + " ▁ begins ▁ at ▁ index ▁ " + findMaxAverage ( arr , n , k ) ) ; } }
static int findMaxAverage ( int arr [ ] , int n , int k ) {
if ( k > n ) return - 1 ;
int sum = arr [ 0 ] ; for ( int i = 1 ; i < k ; i ++ ) sum += arr [ i ] ; int max_sum = sum , max_end = k - 1 ;
for ( int i = k ; i < n ; i ++ ) { sum = sum + arr [ i ] - arr [ i - k ] ; if ( sum > max_sum ) { max_sum = sum ; max_end = i ; } }
return max_end - k + 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 12 , - 5 , - 6 , 50 , 3 } ; int k = 4 ; int n = arr . length ; System . out . println ( " The ▁ maximum ▁ average " + " ▁ subarray ▁ of ▁ length ▁ " + k + " ▁ begins ▁ at ▁ index ▁ " + findMaxAverage ( arr , n , k ) ) ; } }
class Test { static int arr [ ] = new int [ ] { 16 , 16 , 16 } ;
static int countMinOperations ( int n ) {
int result = 0 ;
while ( true ) {
int zero_count = 0 ;
int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] % 2 == 1 ) break ;
else if ( arr [ i ] == 0 ) zero_count ++ ; }
if ( zero_count == n ) return result ;
if ( i == n ) {
for ( int j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] / 2 ; result ++ ; }
for ( int j = i ; j < n ; j ++ ) { if ( arr [ j ] % 2 == 1 ) { arr [ j ] -- ; result ++ ; } } } }
public static void main ( String [ ] args ) { System . out . println ( "Minimum number of steps required to NEW_LINE" + " get ▁ the ▁ given ▁ target ▁ array ▁ is ▁ " + countMinOperations ( arr . length ) ) ; } }
static int findMinOps ( int [ ] arr , int n ) {
int ans = 0 ;
for ( int i = 0 , j = n - 1 ; i <= j ; ) {
if ( arr [ i ] == arr [ j ] ) { i ++ ; j -- ; }
else if ( arr [ i ] > arr [ j ] ) {
j -- ; arr [ j ] += arr [ j + 1 ] ; ans ++ ; }
else { i ++ ; arr [ i ] += arr [ i - 1 ] ; ans ++ ; } } return ans ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 1 , 4 , 5 , 9 , 1 } ; System . out . println ( " Count ▁ of ▁ minimum ▁ operations ▁ is ▁ " + findMinOps ( arr , arr . length ) ) ; } }
int findSmallest ( int arr [ ] , int n ) {
int res = 1 ;
for ( int i = 0 ; i < n && arr [ i ] <= res ; i ++ ) res = res + arr [ i ] ; return res ; }
public static void main ( String [ ] args ) { FindSmallestInteger small = new FindSmallestInteger ( ) ; int arr1 [ ] = { 1 , 3 , 4 , 5 } ; int n1 = arr1 . length ; System . out . println ( small . findSmallest ( arr1 , n1 ) ) ; int arr2 [ ] = { 1 , 2 , 6 , 10 , 11 , 15 } ; int n2 = arr2 . length ; System . out . println ( small . findSmallest ( arr2 , n2 ) ) ; int arr3 [ ] = { 1 , 1 , 1 , 1 } ; int n3 = arr3 . length ; System . out . println ( small . findSmallest ( arr3 , n3 ) ) ; int arr4 [ ] = { 1 , 1 , 3 , 4 } ; int n4 = arr4 . length ; System . out . println ( small . findSmallest ( arr4 , n4 ) ) ; } }
static int maxSubArraySum ( int a [ ] , int size ) { int max_so_far = Integer . MIN_VALUE , max_ending_here = 0 , start = 0 , end = 0 , s = 0 ; for ( int i = 0 ; i < size ; i ++ ) { max_ending_here += a [ i ] ; if ( max_so_far < max_ending_here ) { max_so_far = max_ending_here ; start = s ; end = i ; } if ( max_ending_here < 0 ) { max_ending_here = 0 ; s = i + 1 ; } } return ( end - start + 1 ) ; }
public static void main ( String [ ] args ) { int a [ ] = { - 2 , - 3 , 4 , - 1 , - 2 , 1 , 5 , - 3 } ; int n = a . length ; System . out . println ( maxSubArraySum ( a , n ) ) ; } }
static int findMinDiff ( int [ ] arr , int n ) {
int diff = Integer . MAX_VALUE ;
for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( Math . abs ( ( arr [ i ] - arr [ j ] ) ) < diff ) diff = Math . abs ( ( arr [ i ] - arr [ j ] ) ) ;
return diff ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 1 , 5 , 3 , 19 , 18 , 25 } ; System . out . println ( " Minimum ▁ difference ▁ is ▁ " + findMinDiff ( arr , arr . length ) ) ; } }
static int findMinDiff ( int [ ] arr , int n ) {
Arrays . sort ( arr ) ;
int diff = Integer . MAX_VALUE ;
for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i + 1 ] - arr [ i ] < diff ) diff = arr [ i + 1 ] - arr [ i ] ;
return diff ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 1 , 5 , 3 , 19 , 18 , 25 } ; System . out . println ( " Minimum ▁ difference ▁ is ▁ " + findMinDiff ( arr , arr . length ) ) ; } }
public static void main ( String [ ] args ) { int a = 2 , b = 10 ; int size = Math . abs ( b - a ) + 1 ; int array [ ] = new int [ size ] ;
for ( int i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) array [ i - a ] = 1 ; System . out . println ( " MULTIPLES ▁ of ▁ 2" + " ▁ and ▁ 5 : " ) ; for ( int i = a ; i <= b ; i ++ ) if ( array [ i - a ] == 1 ) System . out . printf ( i + " ▁ " ) ; } }
static boolean checkbit ( int array [ ] , int index ) { int val = array [ index >> 5 ] & ( 1 << ( index & 31 ) ) ; if ( val == 0 ) return false ; return true ; }
static void setbit ( int array [ ] , int index ) { array [ index >> 5 ] |= ( 1 << ( index & 31 ) ) ; }
public static void main ( String args [ ] ) { int a = 2 , b = 10 ; int size = Math . abs ( b - a ) ;
size = ( int ) Math . ceil ( ( double ) size / 32 ) ;
int [ ] array = new int [ size ] ;
for ( int i = a ; i <= b ; i ++ ) if ( i % 2 == 0 i % 5 == 0 ) setbit ( array , i - a ) ; System . out . println ( " MULTIPLES ▁ of ▁ 2 ▁ and ▁ 5 : " ) ; for ( int i = a ; i <= b ; i ++ ) if ( checkbit ( array , i - a ) ) System . out . print ( i + " ▁ " ) ; } }
class Test { static int arr1 [ ] = new int [ ] { 0 , 1 , 0 , 1 , 1 , 1 , 1 } ; static int arr2 [ ] = new int [ ] { 1 , 1 , 1 , 1 , 1 , 0 , 1 } ;
static int longestCommonSum ( int n ) {
int maxLen = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
int sum1 = 0 , sum2 = 0 ;
for ( int j = i ; j < n ; j ++ ) {
sum1 += arr1 [ j ] ; sum2 += arr2 [ j ] ;
if ( sum1 == sum2 ) { int len = j - i + 1 ; if ( len > maxLen ) maxLen = len ; } } } return maxLen ; }
public static void main ( String [ ] args ) { System . out . print ( " Length ▁ of ▁ the ▁ longest ▁ common ▁ span ▁ with ▁ same ▁ sum ▁ is ▁ " ) ; System . out . println ( longestCommonSum ( arr1 . length ) ) ; } }
void swap ( int arr [ ] , int a , int b ) { int temp = arr [ a ] ; arr [ a ] = arr [ b ] ; arr [ b ] = temp ; }
void sortInWave ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
for ( int i = 0 ; i < n - 1 ; i += 2 ) swap ( arr , i , i + 1 ) ; }
public static void main ( String args [ ] ) { SortWave ob = new SortWave ( ) ; int arr [ ] = { 10 , 90 , 49 , 2 , 1 , 5 , 23 } ; int n = arr . length ; ob . sortInWave ( arr , n ) ; for ( int i : arr ) System . out . print ( i + " ▁ " ) ; } }
void swap ( int arr [ ] , int a , int b ) { int temp = arr [ a ] ; arr [ a ] = arr [ b ] ; arr [ b ] = temp ; }
void sortInWave ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i += 2 ) {
if ( i > 0 && arr [ i - 1 ] > arr [ i ] ) swap ( arr , i - 1 , i ) ;
if ( i < n - 1 && arr [ i ] < arr [ i + 1 ] ) swap ( arr , i , i + 1 ) ; } }
public static void main ( String args [ ] ) { SortWave ob = new SortWave ( ) ; int arr [ ] = { 10 , 90 , 49 , 2 , 1 , 5 , 23 } ; int n = arr . length ; ob . sortInWave ( arr , n ) ; for ( int i : arr ) System . out . print ( i + " ▁ " ) ; } }
static boolean sortedAfterSwap ( int A [ ] , boolean B [ ] , int n ) { int i , j ;
for ( i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] ) { j = i ; while ( B [ j ] ) { j ++ ; }
Arrays . sort ( A , i , 1 + j ) ; i = j ; } }
for ( i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) { return false ; } } return true ; }
public static void main ( String [ ] args ) { int A [ ] = { 1 , 2 , 5 , 3 , 4 , 6 } ; boolean B [ ] = { false , true , true , true , false } ; int n = A . length ; if ( sortedAfterSwap ( A , B , n ) ) { System . out . println ( " A ▁ can ▁ be ▁ sorted " ) ; } else { System . out . println ( " A ▁ can ▁ not ▁ be ▁ sorted " ) ; } } }
static int sortedAfterSwap ( int [ ] A , int [ ] B , int n ) { int t = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( B [ i ] != 0 ) { if ( A [ i ] != i + 1 ) t = A [ i ] ; A [ i ] = A [ i + 1 ] ; A [ i + 1 ] = t ; } }
for ( int i = 0 ; i < n ; i ++ ) { if ( A [ i ] != i + 1 ) return 0 ; } return 1 ; }
public static void main ( String [ ] args ) { int [ ] A = { 1 , 2 , 5 , 3 , 4 , 6 } ; int [ ] B = { 0 , 1 , 1 , 1 , 0 } ; int n = A . length ; if ( sortedAfterSwap ( A , B , n ) == 0 ) System . out . println ( " A ▁ can ▁ be ▁ sorted " ) ; else System . out . println ( " A ▁ can ▁ not ▁ be ▁ sorted " ) ; } }
class segregation {
static void segregate0and1 ( int arr [ ] , int n ) { int type0 = 0 ; int type1 = n - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type0 ] = arr [ type0 ] + arr [ type1 ] ; arr [ type1 ] = arr [ type0 ] - arr [ type1 ] ; arr [ type0 ] = arr [ type0 ] - arr [ type1 ] ; type1 -- ; } else { type0 ++ ; } } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 , 1 , 1 , 0 , 0 } ; segregate0and1 ( arr , arr . length ) ; for ( int a : arr ) System . out . print ( a + " ▁ " ) ; } }
static void findMinSum ( int [ ] arr , int n ) { for ( int i = 1 ; i < n ; i ++ ) { if ( ! ( Math . abs ( arr [ i - 1 ] ) < Math . abs ( arr [ i ] ) ) ) { int temp = arr [ i - 1 ] ; arr [ i - 1 ] = arr [ i ] ; arr [ i ] = temp ; } } int min = Integer . MAX_VALUE ; int x = 0 , y = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( Math . abs ( arr [ i - 1 ] + arr [ i ] ) <= min ) {
min = Math . abs ( arr [ i - 1 ] + arr [ i ] ) ; x = i - 1 ; y = i ; } } System . out . println ( " The ▁ two ▁ elements ▁ whose ▁ " + " sum ▁ is ▁ minimum ▁ are ▁ " + arr [ x ] + " ▁ and ▁ " + arr [ y ] ) ; }
public static void main ( String [ ] args ) { int [ ] arr = { 1 , 60 , - 10 , 70 , - 80 , 85 } ; int n = arr . length ; findMinSum ( arr , n ) ; } }
public static boolean increasing ( int a [ ] , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( a [ i ] >= a [ i + 1 ] ) return false ; return true ; }
public static boolean decreasing ( int arr [ ] , int n ) { for ( int i = 0 ; i < n - 1 ; i ++ ) if ( arr [ i ] < arr [ i + 1 ] ) return false ; return true ; } public static int shortestUnsorted ( int a [ ] , int n ) {
if ( increasing ( a , n ) == true || decreasing ( a , n ) == true ) return 0 ; else return 3 ; }
public static void main ( String [ ] args ) { int ar [ ] = new int [ ] { 7 , 9 , 10 , 8 , 11 } ; int n = ar . length ; System . out . println ( shortestUnsorted ( ar , n ) ) ; } }
public void swap ( int [ ] arr , int i , int j ) { int temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; }
public int indexOf ( int [ ] arr , int ele ) { for ( int i = 0 ; i < arr . length ; i ++ ) { if ( arr [ i ] == ele ) { return i ; } } return - 1 ; }
public int minSwaps ( int [ ] arr , int N ) { int ans = 0 ; int [ ] temp = Arrays . copyOfRange ( arr , 0 , N ) ; Arrays . sort ( temp ) ; for ( int i = 0 ; i < N ; i ++ ) {
if ( arr [ i ] != temp [ i ] ) { ans ++ ;
swap ( arr , i , indexOf ( arr , temp [ i ] ) ) ; } } return ans ; } }
public static void main ( String [ ] args ) throws Exception { int [ ] a = { 101 , 758 , 315 , 730 , 472 , 619 , 460 , 479 } ; int n = a . length ;
System . out . println ( new GfG ( ) . minSwaps ( a , n ) ) ; } }
void printUnion ( int arr1 [ ] , int arr2 [ ] , int m , int n ) {
if ( m > n ) { int tempp [ ] = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
Arrays . sort ( arr1 ) ; for ( int i = 0 ; i < m ; i ++ ) System . out . print ( arr1 [ i ] + " ▁ " ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) == - 1 ) System . out . print ( arr2 [ i ] + " ▁ " ) ; } }
void printIntersection ( int arr1 [ ] , int arr2 [ ] , int m , int n ) {
if ( m > n ) { int tempp [ ] = arr1 ; arr1 = arr2 ; arr2 = tempp ; int temp = m ; m = n ; n = temp ; }
Arrays . sort ( arr1 ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( binarySearch ( arr1 , 0 , m - 1 , arr2 [ i ] ) != - 1 ) System . out . print ( arr2 [ i ] + " ▁ " ) ; } }
int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
public static void main ( String [ ] args ) { UnionAndIntersection u_i = new UnionAndIntersection ( ) ; int arr1 [ ] = { 7 , 1 , 5 , 2 , 3 , 6 } ; int arr2 [ ] = { 3 , 8 , 6 , 20 , 7 } ; int m = arr1 . length ; int n = arr2 . length ;
System . out . println ( " Union ▁ of ▁ two ▁ arrays ▁ is ▁ " ) ; u_i . printUnion ( arr1 , arr2 , m , n ) ; System . out . println ( " " ) ; System . out . println ( " Intersection ▁ of ▁ two ▁ arrays ▁ is ▁ " ) ; u_i . printIntersection ( arr1 , arr2 , m , n ) ; } }
static void intersection ( int a [ ] , int b [ ] , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) { if ( a [ i ] > b [ j ] ) { j ++ ; } else if ( b [ j ] > a [ i ] ) { i ++ ; } else {
System . out . print ( a [ i ] + " ▁ " ) ; i ++ ; j ++ ; } } }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 3 , 2 , 3 , 4 , 5 , 5 , 6 } ; int b [ ] = { 3 , 3 , 5 } ; int n = a . length ; int m = b . length ;
Arrays . sort ( a ) ; Arrays . sort ( b ) ;
intersection ( a , b , n , m ) ; } }
static void printArr ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
static void sortArr ( int arr [ ] , int n ) { int i , cnt0 = 0 , cnt1 = 0 , cnt2 = 0 ;
for ( i = 0 ; i < n ; i ++ ) { switch ( arr [ i ] ) { case 0 : cnt0 ++ ; break ; case 1 : cnt1 ++ ; break ; case 2 : cnt2 ++ ; break ; } }
i = 0 ;
while ( cnt0 > 0 ) { arr [ i ++ ] = 0 ; cnt0 -- ; }
while ( cnt1 > 0 ) { arr [ i ++ ] = 1 ; cnt1 -- ; }
while ( cnt2 > 0 ) { arr [ i ++ ] = 2 ; cnt2 -- ; }
printArr ( arr , n ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 1 , 1 , 0 , 1 , 2 , 1 , 2 , 0 , 0 , 0 , 1 } ; int n = arr . length ; sortArr ( arr , n ) ; } }
static int findNumberOfTriangles ( int arr [ ] , int n ) {
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
for ( int k = j + 1 ; k < n ; k ++ )
if ( arr [ i ] + arr [ j ] > arr [ k ] && arr [ i ] + arr [ k ] > arr [ j ] && arr [ k ] + arr [ j ] > arr [ i ] ) count ++ ; } } return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 10 , 21 , 22 , 100 , 101 , 200 , 300 } ; int size = arr . length ; System . out . println ( " Total ▁ number ▁ of ▁ triangles ▁ possible ▁ is ▁ " + findNumberOfTriangles ( arr , size ) ) ; } }
static void CountTriangles ( int [ ] A ) { int n = A . length ; Arrays . sort ( A ) ; int count = 0 ; for ( int i = n - 1 ; i >= 1 ; i -- ) { int l = 0 , r = i - 1 ; while ( l < r ) { if ( A [ l ] + A [ r ] > A [ i ] ) {
count += r - l ;
r -- ; }
else { l ++ ; } } } System . out . print ( " No ▁ of ▁ possible ▁ solutions : ▁ " + count ) ; }
public static void main ( String [ ] args ) { int [ ] A = { 4 , 3 , 5 , 7 , 6 } ; CountTriangles ( A ) ; } }
public static long countPairsBruteForce ( long X [ ] , long Y [ ] , int m , int n ) { long ans = 0 ; for ( int i = 0 ; i < m ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( Math . pow ( X [ i ] , Y [ j ] ) > Math . pow ( Y [ j ] , X [ i ] ) ) ans ++ ; return ans ; }
import java . util . * ; import java . io . * ; class GFG { static int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] - arr [ j ] == k arr [ j ] - arr [ i ] == k ) count ++ ; } return count ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . length ; int k = 3 ; System . out . println ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static int binarySearch ( int arr [ ] , int low , int high , int x ) { if ( high >= low ) { int mid = low + ( high - low ) / 2 ; if ( x == arr [ mid ] ) return mid ; if ( x > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
static int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 , i ;
Arrays . sort ( arr ) ;
for ( i = 0 ; i < n - 1 ; i ++ ) if ( binarySearch ( arr , i + 1 , n - 1 , arr [ i ] + k ) != - 1 ) count ++ ; return count ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . length ; int k = 3 ; System . out . println ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static int countPairsWithDiffK ( int arr [ ] , int n , int k ) { int count = 0 ;
Arrays . sort ( arr ) ; int l = 0 ; int r = 0 ; while ( r < n ) { if ( arr [ r ] - arr [ l ] == k ) { count ++ ; l ++ ; r ++ ; } else if ( arr [ r ] - arr [ l ] > k ) l ++ ;
else r ++ ; } return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 5 , 3 , 4 , 2 } ; int n = arr . length ; int k = 3 ; System . out . println ( " Count ▁ of ▁ pairs ▁ with ▁ given ▁ diff ▁ is ▁ " + countPairsWithDiffK ( arr , n , k ) ) ; } }
static class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } }
public static int getSumAlternate ( Node root ) { if ( root == null ) return 0 ; int sum = root . data ; if ( root . left != null ) { sum += getSum ( root . left . left ) ; sum += getSum ( root . left . right ) ; } if ( root . right != null ) { sum += getSum ( root . right . left ) ; sum += getSum ( root . right . right ) ; } return sum ; }
public static int getSum ( Node root ) { if ( root == null ) return 0 ;
return Math . max ( getSumAlternate ( root ) , ( getSumAlternate ( root . left ) + getSumAlternate ( root . right ) ) ) ; }
public static void main ( String [ ] args ) { Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . right . left = new Node ( 4 ) ; root . right . left . right = new Node ( 5 ) ; root . right . left . right . left = new Node ( 6 ) ; System . out . println ( getSum ( root ) ) ; } }
static void constructArr ( int arr [ ] , int pair [ ] , int n ) { arr [ 0 ] = ( pair [ 0 ] + pair [ 1 ] - pair [ n - 1 ] ) / 2 ; for ( int i = 1 ; i < n ; i ++ ) arr [ i ] = pair [ i - 1 ] - arr [ 0 ] ; }
public static void main ( String [ ] args ) { int pair [ ] = { 15 , 13 , 11 , 10 , 12 , 10 , 9 , 8 , 7 , 5 } ; int n = 5 ; int [ ] arr = new int [ n ] ; constructArr ( arr , pair , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static int arr1 [ ] = new int [ ] { 1 , 5 , 9 , 10 , 15 , 20 } ; static int arr2 [ ] = new int [ ] { 2 , 3 , 8 , 13 } ; static void merge ( int m , int n ) {
for ( int i = n - 1 ; i >= 0 ; i -- ) {
int j , last = arr1 [ m - 1 ] ; for ( j = m - 2 ; j >= 0 && arr1 [ j ] > arr2 [ i ] ; j -- ) arr1 [ j + 1 ] = arr1 [ j ] ;
if ( j != m - 2 last > arr2 [ i ] ) { arr1 [ j + 1 ] = arr2 [ i ] ; arr2 [ i ] = last ; } } }
public static void main ( String [ ] args ) { merge ( arr1 . length , arr2 . length ) ; System . out . print ( " After ▁ Merging ▁ nFirst ▁ Array : ▁ " ) ; System . out . println ( Arrays . toString ( arr1 ) ) ; System . out . print ( " Second ▁ Array : ▁ " ) ; System . out . println ( Arrays . toString ( arr2 ) ) ; } }
public static int minMaxProduct ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) {
Arrays . sort ( arr1 ) ; Arrays . sort ( arr2 ) ;
return arr1 [ n1 - 1 ] * arr2 [ 0 ] ; }
public static void main ( String argc [ ] ) { int [ ] arr1 = new int [ ] { 10 , 2 , 3 , 6 , 4 , 1 } ; int [ ] arr2 = new int [ ] { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = 6 ; int n2 = 6 ; System . out . println ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ; } }
public static int minMaxProduct ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) {
int max = arr1 [ 0 ] ;
int min = arr2 [ 0 ] ; int i ; for ( i = 1 ; i < n1 && i < n2 ; ++ i ) {
if ( arr1 [ i ] > max ) max = arr1 [ i ] ;
if ( arr2 [ i ] < min ) min = arr2 [ i ] ; }
while ( i < n1 ) { if ( arr1 [ i ] > max ) max = arr1 [ i ] ; i ++ ; } while ( i < n2 ) { if ( arr2 [ i ] < min ) min = arr2 [ i ] ; i ++ ; } return max * min ; }
public static void main ( String argc [ ] ) { int [ ] arr1 = new int [ ] { 10 , 2 , 3 , 6 , 4 , 1 } ; int [ ] arr2 = new int [ ] { 5 , 1 , 4 , 2 , 6 , 9 } ; int n1 = 6 ; int n2 = 6 ; System . out . println ( minMaxProduct ( arr1 , arr2 , n1 , n2 ) ) ; } }
static int insertSorted ( int arr [ ] , int n , int key , int capacity ) {
if ( n >= capacity ) return n ; arr [ n ] = key ; return ( n + 1 ) ; }
public static void main ( String [ ] args ) { int [ ] arr = new int [ 20 ] ; arr [ 0 ] = 12 ; arr [ 1 ] = 16 ; arr [ 2 ] = 20 ; arr [ 3 ] = 40 ; arr [ 4 ] = 50 ; arr [ 5 ] = 70 ; int capacity = 20 ; int n = 6 ; int i , key = 26 ; System . out . print ( " Before ▁ Insertion : ▁ " ) ; for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ;
n = insertSorted ( arr , n , key , capacity ) ; System . out . print ( " After Insertion : "); for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static int findElement ( int arr [ ] , int n , int key ) { int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == key ) return i ; return - 1 ; }
static int deleteElement ( int arr [ ] , int n , int key ) {
int pos = findElement ( arr , n , key ) ; if ( pos == - 1 ) { System . out . println ( " Element ▁ not ▁ found " ) ; return n ; }
int i ; for ( i = pos ; i < n - 1 ; i ++ ) arr [ i ] = arr [ i + 1 ] ; return n - 1 ; }
public static void main ( String args [ ] ) { int i ; int arr [ ] = { 10 , 50 , 30 , 40 , 20 } ; int n = arr . length ; int key = 30 ; System . out . println ( " Array ▁ before ▁ deletion " ) ; for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; n = deleteElement ( arr , n , key ) ; System . out . println ( " Array after deletion "); for ( i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
void findCommon ( int ar1 [ ] , int ar2 [ ] , int ar3 [ ] ) {
int i = 0 , j = 0 , k = 0 ;
while ( i < ar1 . length && j < ar2 . length && k < ar3 . length ) {
if ( ar1 [ i ] == ar2 [ j ] && ar2 [ j ] == ar3 [ k ] ) { System . out . print ( ar1 [ i ] + " ▁ " ) ; i ++ ; j ++ ; k ++ ; }
else if ( ar1 [ i ] < ar2 [ j ] ) i ++ ;
else if ( ar2 [ j ] < ar3 [ k ] ) j ++ ;
else k ++ ; } }
public static void main ( String args [ ] ) { FindCommon ob = new FindCommon ( ) ; int ar1 [ ] = { 1 , 5 , 10 , 20 , 40 , 80 } ; int ar2 [ ] = { 6 , 7 , 20 , 80 , 100 } ; int ar3 [ ] = { 3 , 4 , 15 , 20 , 30 , 70 , 80 , 120 } ; System . out . print ( " Common ▁ elements ▁ are ▁ " ) ; ob . findCommon ( ar1 , ar2 , ar3 ) ; } }
static int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r >= l ) { int mid = l + ( r - l ) / 2 ; if ( arr [ mid ] == x ) return mid ; if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ; return binarySearch ( arr , mid + 1 , r , x ) ; } return - 1 ; }
static int findPos ( int arr [ ] , int key ) { int l = 0 , h = 1 ; int val = arr [ 0 ] ;
while ( val < key ) {
l = h ;
if ( 2 * h < arr . length - 1 ) h = 2 * h ; else h = arr . length - 1 ;
val = arr [ h ] ; }
return binarySearch ( arr , l , h , key ) ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 3 , 5 , 7 , 9 , 10 , 90 , 100 , 130 , 140 , 160 , 170 } ; int ans = findPos ( arr , 10 ) ; if ( ans == - 1 ) System . out . println ( " Element ▁ not ▁ found " ) ; else System . out . println ( " Element ▁ found ▁ at ▁ index ▁ " + ans ) ; } }
static int findSingle ( int ar [ ] , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
public static void main ( String [ ] args ) { int ar [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = ar . length ; System . out . println ( " Element ▁ occurring ▁ once ▁ is ▁ " + findSingle ( ar , n ) + " ▁ " ) ; } }
static int singleNumber ( int [ ] nums , int n ) { HashMap < Integer , Integer > m = new HashMap < > ( ) ; long sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( ! m . containsKey ( nums [ i ] ) ) { sum1 += nums [ i ] ; m . put ( nums [ i ] , 1 ) ; } sum2 += nums [ i ] ; }
return ( int ) ( 2 * ( sum1 ) - sum2 ) ; }
public static void main ( String args [ ] ) { int [ ] a = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = 7 ; System . out . println ( singleNumber ( a , n ) ) ; int [ ] b = { 15 , 18 , 16 , 18 , 16 , 15 , 89 } ; System . out . println ( singleNumber ( b , n ) ) ; } }
static boolean isPresent ( int B [ ] , int m , int x ) { for ( int i = 0 ; i < m ; i ++ ) if ( B [ i ] == x ) return true ; return false ; }
static int findMaxSubarraySumUtil ( int A [ ] , int B [ ] , int n , int m ) {
int max_so_far = - 2147483648 , curr_max = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( isPresent ( B , m , A [ i ] ) ) { curr_max = 0 ; continue ; }
curr_max = Math . max ( A [ i ] , curr_max + A [ i ] ) ; max_so_far = Math . max ( max_so_far , curr_max ) ; } return max_so_far ; }
static void findMaxSubarraySum ( int A [ ] , int B [ ] , int n , int m ) { int maxSubarraySum = findMaxSubarraySumUtil ( A , B , n , m ) ;
if ( maxSubarraySum == - 2147483648 ) { System . out . println ( " Maximum ▁ Subarray ▁ Sum " + " ▁ " + " can ' t ▁ be ▁ found " ) ; } else { System . out . println ( " The ▁ Maximum ▁ Subarray ▁ Sum ▁ = ▁ " + maxSubarraySum ) ; } }
public static void main ( String [ ] args ) { int A [ ] = { 3 , 4 , 5 , - 4 , 6 } ; int B [ ] = { 1 , 8 , 5 } ; int n = A . length ; int m = B . length ;
findMaxSubarraySum ( A , B , n , m ) ; } }
static int findMaxSum ( int [ ] arr , int n ) { int res = Integer . MIN_VALUE ; for ( int i = 0 ; i < n ; i ++ ) { int prefix_sum = arr [ i ] ; for ( int j = 0 ; j < i ; j ++ ) prefix_sum += arr [ j ] ; int suffix_sum = arr [ i ] ; for ( int j = n - 1 ; j > i ; j -- ) suffix_sum += arr [ j ] ; if ( prefix_sum == suffix_sum ) res = Math . max ( res , prefix_sum ) ; } return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 } ; int n = arr . length ; System . out . println ( findMaxSum ( arr , n ) ) ; } }
static class Node { int data ; Node left ; Node right ; }
static int getHeight ( Node Node ) { if ( Node == null ) return 0 ; else {
int lHeight = getHeight ( Node . left ) ; int rHeight = getHeight ( Node . right ) ;
if ( lHeight > rHeight ) return ( lHeight + 1 ) ; else return ( rHeight + 1 ) ; } }
static int getTotalHeight ( Node root ) { if ( root == null ) return 0 ; return getTotalHeight ( root . left ) + getHeight ( root ) + getTotalHeight ( root . right ) ; }
public static void main ( String [ ] args ) { Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; System . out . println ( " Sum ▁ of ▁ heights ▁ of ▁ all ▁ Nodes ▁ = ▁ " + getTotalHeight ( root ) ) ; } }
static int findMaxSum ( int [ ] arr , int n ) {
int [ ] preSum = new int [ n ] ;
int [ ] suffSum = new int [ n ] ;
int ans = Integer . MIN_VALUE ;
preSum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) preSum [ i ] = preSum [ i - 1 ] + arr [ i ] ;
suffSum [ n - 1 ] = arr [ n - 1 ] ; if ( preSum [ n - 1 ] == suffSum [ n - 1 ] ) ans = Math . max ( ans , preSum [ n - 1 ] ) ; for ( int i = n - 2 ; i >= 0 ; i -- ) { suffSum [ i ] = suffSum [ i + 1 ] + arr [ i ] ; if ( suffSum [ i ] == preSum [ i ] ) ans = Math . max ( ans , preSum [ i ] ) ; } return ans ; }
static public void main ( String [ ] args ) { int [ ] arr = { - 2 , 5 , 3 , 1 , 2 , 6 , - 4 , 2 } ; int n = arr . length ; System . out . println ( findMaxSum ( arr , n ) ) ; } }
class GFG { static int equilibrium ( int a [ ] , int n ) { if ( n == 1 ) return ( 0 ) ; int [ ] front = new int [ n ] ; int [ ] back = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) { if ( i != 0 ) { front [ i ] = front [ i - 1 ] + a [ i ] ; } else { front [ i ] = a [ i ] ; } }
for ( int i = n - 1 ; i > 0 ; i -- ) { if ( i <= n - 2 ) { back [ i ] = back [ i + 1 ] + a [ i ] ; } else { back [ i ] = a [ i ] ; } }
for ( int i = 0 ; i < n ; i ++ ) { if ( front [ i ] == back [ i ] ) { return i ; } }
return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { - 7 , 1 , 5 , 2 , - 4 , 3 , 0 } ; int arr_size = arr . length ; System . out . println ( " First ▁ Point ▁ of ▁ equilibrium ▁ " + " is ▁ at ▁ index ▁ " + equilibrium ( arr , arr_size ) ) ; } }
class LeadersInArray { void printLeaders ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) { int j ; for ( j = i + 1 ; j < size ; j ++ ) { if ( arr [ i ] <= arr [ j ] ) break ; }
if ( j == size ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { LeadersInArray lead = new LeadersInArray ( ) ; int arr [ ] = new int [ ] { 16 , 17 , 4 , 3 , 5 , 2 } ; int n = arr . length ; lead . printLeaders ( arr , n ) ; } }
static void findMajority ( int arr [ ] , int n ) { int maxCount = 0 ;
int index = - 1 ; for ( int i = 0 ; i < n ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; }
if ( count > maxCount ) { maxCount = count ; index = i ; } }
if ( maxCount > n / 2 ) System . out . println ( arr [ index ] ) ; else System . out . println ( " No ▁ Majority ▁ Element " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 2 , 1 , 3 , 5 , 1 } ; int n = arr . length ;
findMajority ( arr , n ) ; } }
static class Node { int data ; Node left ; Node right ; } ; static int sum ;
static int getTotalHeightUtil ( Node root ) { if ( root == null ) { return 0 ; } int lh = getTotalHeightUtil ( root . left ) ; int rh = getTotalHeightUtil ( root . right ) ; int h = Math . max ( lh , rh ) + 1 ; sum = sum + h ; return h ; } static int getTotalHeight ( Node root ) { sum = 0 ; getTotalHeightUtil ( root ) ; return sum ; }
public static void main ( String [ ] args ) { Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; System . out . printf ( " Sum ▁ of ▁ heights ▁ of ▁ all ▁ Nodes ▁ = ▁ % d " , getTotalHeight ( root ) ) ; } }
public static int majorityElement ( int [ ] arr , int n ) {
Arrays . sort ( arr ) ; int count = 1 , max_ele = - 1 , temp = arr [ 0 ] , ele = 0 , f = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( temp == arr [ i ] ) { count ++ ; } else { count = 1 ; temp = arr [ i ] ; }
if ( max_ele < count ) { max_ele = count ; ele = arr [ i ] ; if ( max_ele > ( n / 2 ) ) { f = 1 ; break ; } } }
return ( f == 1 ? ele : - 1 ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 2 , 1 , 3 , 5 , 1 } ; int n = 7 ;
System . out . println ( majorityElement ( arr , n ) ) ; } }
static int _binarySearch ( int arr [ ] , int low , int high , int x ) { if ( high >= low ) { int mid = ( low + high ) / 2 ;
if ( ( mid == 0 x > arr [ mid - 1 ] ) && ( arr [ mid ] == x ) ) return mid ; else if ( x > arr [ mid ] ) return _binarySearch ( arr , ( mid + 1 ) , high , x ) ; else return _binarySearch ( arr , low , ( mid - 1 ) , x ) ; } return - 1 ; }
static boolean isMajority ( int arr [ ] , int n , int x ) {
int i = _binarySearch ( arr , 0 , n - 1 , x ) ;
if ( i == - 1 ) return false ;
if ( ( ( i + n / 2 ) <= ( n - 1 ) ) && arr [ i + n / 2 ] == x ) return true ; else return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = arr . length ; int x = 3 ; if ( isMajority ( arr , n , x ) == true ) System . out . println ( x + " ▁ appears ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; else System . out . println ( x + " ▁ does ▁ not ▁ appear ▁ more ▁ than ▁ " + n / 2 + " ▁ times ▁ in ▁ arr [ ] " ) ; } }
import java . util . * ; class GFG { static boolean isMajorityElement ( int arr [ ] , int n , int key ) { if ( arr [ n / 2 ] == key ) return true ; else return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 3 , 3 , 3 , 10 } ; int n = arr . length ; int x = 3 ; if ( isMajorityElement ( arr , n , x ) ) System . out . printf ( " % d ▁ appears ▁ more ▁ than ▁ % d ▁ " + " times ▁ in ▁ arr [ ] " , x , n / 2 ) ; else System . out . printf ( " % d ▁ does ▁ not ▁ appear ▁ more ▁ " + " than ▁ % d ▁ times ▁ in ▁ " + " arr [ ] " , x , n / 2 ) ; } }
public static int isPairSum ( int A [ ] , int N , int X ) {
int i = 0 ;
int j = N - 1 ; while ( i < j ) {
if ( A [ i ] + A [ j ] == X ) return 1 ;
else if ( A [ i ] + A [ j ] < X ) i ++ ;
else j -- ; } return 0 ; }
int arr [ ] = { 3 , 5 , 9 , 2 , 8 , 10 , 11 } ;
int val = 17 ;
int arrSize = arr . length ;
System . out . println ( isPairSum ( arr , arrSize , val ) ) ; } }
static int findPeak ( int arr [ ] , int n ) {
if ( n == 1 ) return 0 ; if ( arr [ 0 ] >= arr [ 1 ] ) return 0 ; if ( arr [ n - 1 ] >= arr [ n - 2 ] ) return n - 1 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
if ( arr [ i ] >= arr [ i - 1 ] && arr [ i ] >= arr [ i + 1 ] ) return i ; } return 0 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 20 , 4 , 1 , 0 } ; int n = arr . length ; System . out . print ( " Index ▁ of ▁ a ▁ peak ▁ point ▁ is ▁ " + findPeak ( arr , n ) ) ; } }
import java . io . * ; class GFG { static int maxTripletSum ( int arr [ ] , int n ) {
int sum = - 1000000 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) for ( int k = j + 1 ; k < n ; k ++ ) if ( sum < arr [ i ] + arr [ j ] + arr [ k ] ) sum = arr [ i ] + arr [ j ] + arr [ k ] ; return sum ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . length ; System . out . println ( maxTripletSum ( arr , n ) ) ; } }
static int maxTripletSum ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
return arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . length ; System . out . println ( maxTripletSum ( arr , n ) ) ; } }
static int maxTripletSum ( int arr [ ] , int n ) {
int maxA = - 100000000 , maxB = - 100000000 ; int maxC = - 100000000 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( arr [ i ] > maxA ) { maxC = maxB ; maxB = maxA ; maxA = arr [ i ] ; }
else if ( arr [ i ] > maxB ) { maxC = maxB ; maxB = arr [ i ] ; }
else if ( arr [ i ] > maxC ) maxC = arr [ i ] ; } return ( maxA + maxB + maxC ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 0 , 8 , 6 , 4 , 2 } ; int n = arr . length ; System . out . println ( maxTripletSum ( arr , n ) ) ; } }
static int maximum ( int a , int b , int c ) { return Math . max ( Math . max ( a , b ) , c ) ; }
static int minimum ( int a , int b , int c ) { return Math . min ( Math . min ( a , b ) , c ) ; }
static void smallestDifferenceTriplet ( int arr1 [ ] , int arr2 [ ] , int arr3 [ ] , int n ) {
Arrays . sort ( arr1 ) ; Arrays . sort ( arr2 ) ; Arrays . sort ( arr3 ) ;
int res_min = 0 , res_max = 0 , res_mid = 0 ;
int i = 0 , j = 0 , k = 0 ;
int diff = 2147483647 ; while ( i < n && j < n && k < n ) { int sum = arr1 [ i ] + arr2 [ j ] + arr3 [ k ] ;
int max = maximum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ;
int min = minimum ( arr1 [ i ] , arr2 [ j ] , arr3 [ k ] ) ; if ( min == arr1 [ i ] ) i ++ ; else if ( min == arr2 [ j ] ) j ++ ; else k ++ ;
if ( diff > ( max - min ) ) { diff = max - min ; res_max = max ; res_mid = sum - ( max + min ) ; res_min = min ; } }
System . out . print ( res_max + " , ▁ " + res_mid + " , ▁ " + res_min ) ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 5 , 2 , 8 } ; int arr2 [ ] = { 10 , 7 , 12 } ; int arr3 [ ] = { 9 , 14 , 6 } ; int n = arr1 . length ; smallestDifferenceTriplet ( arr1 , arr2 , arr3 , n ) ; } }
boolean find3Numbers ( int A [ ] , int arr_size , int sum ) { int l , r ;
quickSort ( A , 0 , arr_size - 1 ) ;
for ( int i = 0 ; i < arr_size - 2 ; i ++ ) {
l = i + 1 ;
r = arr_size - 1 ; while ( l < r ) { if ( A [ i ] + A [ l ] + A [ r ] == sum ) { System . out . print ( " Triplet ▁ is ▁ " + A [ i ] + " , ▁ " + A [ l ] + " , ▁ " + A [ r ] ) ; return true ; } else if ( A [ i ] + A [ l ] + A [ r ] < sum ) l ++ ;
else r -- ; } }
return false ; }
public static void main ( String [ ] args ) { FindTriplet triplet = new FindTriplet ( ) ; int A [ ] = { 1 , 4 , 45 , 6 , 10 , 8 } ; int sum = 22 ; int arr_size = A . length ; triplet . find3Numbers ( A , arr_size , sum ) ; } }
import java . io . * ; import java . util . * ; class GFG { static int SIZE = 10 ;
static void sortMat ( int mat [ ] [ ] , int n ) {
int temp [ ] = new int [ n * n ] ; int k = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) temp [ k ++ ] = mat [ i ] [ j ] ;
Arrays . sort ( temp ) ;
k = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) mat [ i ] [ j ] = temp [ k ++ ] ; }
static void printMat ( int mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String args [ ] ) { int mat [ ] [ ] = { { 5 , 4 , 7 } , { 1 , 3 , 8 } , { 2 , 9 , 6 } } ; int n = 3 ; System . out . println ( " Original ▁ Matrix : " ) ; printMat ( mat , n ) ; sortMat ( mat , n ) ; System . out . println ( " Matrix ▁ After ▁ Sorting : " ) ; printMat ( mat , n ) ; } }
class Test { static int arr [ ] = new int [ ] { 1 , 2 , 3 , 4 } ;
static void subArray ( int n ) {
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i ; j < n ; j ++ ) {
for ( int k = i ; k <= j ; k ++ ) System . out . print ( arr [ k ] + " ▁ " ) ; } } }
public static void main ( String [ ] args ) { System . out . println ( " All ▁ Non - empty ▁ Subarrays " ) ; subArray ( arr . length ) ; } }
import java . math . BigInteger ; class Test { static int arr [ ] = new int [ ] { 1 , 2 , 3 , 4 } ; static void printSubsequences ( int n ) {
int opsize = ( int ) Math . pow ( 2 , n ) ;
for ( int counter = 1 ; counter < opsize ; counter ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( BigInteger . valueOf ( counter ) . testBit ( j ) ) System . out . print ( arr [ j ] + " ▁ " ) ; } System . out . println ( ) ; } }
public static void main ( String [ ] args ) { System . out . println ( " All ▁ Non - empty ▁ Subsequences " ) ; printSubsequences ( arr . length ) ; } }
void productArray ( int arr [ ] , int n ) {
if ( n == 1 ) { System . out . print ( "0" ) ; return ; } int i , temp = 1 ;
int prod [ ] = new int [ n ] ;
for ( int j = 0 ; j < n ; j ++ ) prod [ j ] = 1 ;
for ( i = 0 ; i < n ; i ++ ) { prod [ i ] = temp ; temp *= arr [ i ] ; }
temp = 1 ;
for ( i = n - 1 ; i >= 0 ; i -- ) { prod [ i ] *= temp ; temp *= arr [ i ] ; }
for ( i = 0 ; i < n ; i ++ ) System . out . print ( prod [ i ] + " ▁ " ) ; return ; }
public static void main ( String [ ] args ) { ProductArray pa = new ProductArray ( ) ; int arr [ ] = { 10 , 3 , 5 , 6 , 2 } ; int n = arr . length ; System . out . println ( " The ▁ product ▁ array ▁ is ▁ : ▁ " ) ; pa . productArray ( arr , n ) ; } }
import java . io . * ; import java . util . * ; class Solution { public static long [ ] productExceptSelf ( int a [ ] , int n ) { long prod = 1 ; long flag = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == 0 ) flag ++ ; else prod *= a [ i ] ; }
long arr [ ] = new long [ n ] ; for ( int i = 0 ; i < n ; i ++ ) {
if ( flag > 1 ) { arr [ i ] = 0 ; }
else if ( flag == 0 ) arr [ i ] = ( prod / a [ i ] ) ;
else if ( flag == 1 && a [ i ] != 0 ) { arr [ i ] = 0 ; }
else arr [ i ] = prod ; } return arr ; }
public static void main ( String args [ ] ) throws IOException { int n = 5 ; int [ ] array = { 10 , 3 , 5 , 6 , 2 } ; Solution ob = new Solution ( ) ; long [ ] ans = new long [ n ] ; ans = ob . productExceptSelf ( array , n ) ; for ( int i = 0 ; i < n ; i ++ ) { System . out . print ( ans [ i ] + " ▁ " ) ; } } }
boolean areConsecutive ( int arr [ ] , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) {
boolean visited [ ] = new boolean [ n ] ; int i ; for ( i = 0 ; i < n ; i ++ ) {
if ( visited [ arr [ i ] - min ] != false ) return false ;
visited [ arr [ i ] - min ] = true ; }
return true ; }
return false ; }
int getMin ( int arr [ ] , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void main ( String [ ] args ) { AreConsecutive consecutive = new AreConsecutive ( ) ; int arr [ ] = { 5 , 4 , 2 , 3 , 1 , 6 } ; int n = arr . length ; if ( consecutive . areConsecutive ( arr , n ) == true ) System . out . println ( " Array ▁ elements ▁ are ▁ consecutive " ) ; else System . out . println ( " Array ▁ elements ▁ are ▁ not ▁ consecutive " ) ; } }
boolean areConsecutive ( int arr [ ] , int n ) { if ( n < 1 ) return false ;
int min = getMin ( arr , n ) ;
int max = getMax ( arr , n ) ;
if ( max - min + 1 == n ) { int i ; for ( i = 0 ; i < n ; i ++ ) { int j ; if ( arr [ i ] < 0 ) j = - arr [ i ] - min ; else j = arr [ i ] - min ;
if ( arr [ j ] > 0 ) arr [ j ] = - arr [ j ] ; else return false ; }
return true ; }
return false ; }
int getMin ( int arr [ ] , int n ) { int min = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < min ) min = arr [ i ] ; } return min ; } int getMax ( int arr [ ] , int n ) { int max = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) max = arr [ i ] ; } return max ; }
public static void main ( String [ ] args ) { AreConsecutive consecutive = new AreConsecutive ( ) ; int arr [ ] = { 5 , 4 , 2 , 3 , 1 , 6 } ; int n = arr . length ; if ( consecutive . areConsecutive ( arr , n ) == true ) System . out . println ( " Array ▁ elements ▁ are ▁ consecutive " ) ; else System . out . println ( " Array ▁ elements ▁ are ▁ not ▁ consecutive " ) ; } }
class GFG { static void relativeComplement ( int arr1 [ ] , int arr2 [ ] , int n , int m ) { int i = 0 , j = 0 ; while ( i < n && j < m ) {
if ( arr1 [ i ] < arr2 [ j ] ) { System . out . print ( arr1 [ i ] + " ▁ " ) ; i ++ ;
} else if ( arr1 [ i ] > arr2 [ j ] ) { j ++ ;
} else if ( arr1 [ i ] == arr2 [ j ] ) { i ++ ; j ++ ; } }
while ( i < n ) System . out . print ( arr1 [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr1 [ ] = { 3 , 6 , 10 , 12 , 15 } ; int arr2 [ ] = { 1 , 3 , 5 , 10 , 16 } ; int n = arr1 . length ; int m = arr2 . length ; relativeComplement ( arr1 , arr2 , n , m ) ; } }
static int minOps ( int arr [ ] , int n , int k ) {
Arrays . sort ( arr ) ; int max = arr [ arr . length - 1 ] ; int res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( ( max - arr [ i ] ) % k != 0 ) return - 1 ;
else res += ( max - arr [ i ] ) / k ; }
return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { 21 , 33 , 9 , 45 , 63 } ; int n = arr . length ; int k = 6 ; System . out . println ( minOps ( arr , n , k ) ) ; } }
import java . util . * ; class GFG { static int solve ( int [ ] A , int [ ] B , int [ ] C ) { int i , j , k ;
i = A . length - 1 ; j = B . length - 1 ; k = C . length - 1 ; int min_diff , current_diff , max_term ;
min_diff = Math . abs ( Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) - Math . min ( A [ i ] , Math . min ( B [ j ] , C [ k ] ) ) ) ; while ( i != - 1 && j != - 1 && k != - 1 ) { current_diff = Math . abs ( Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) - Math . min ( A [ i ] , Math . min ( B [ j ] , C [ k ] ) ) ) ;
if ( current_diff < min_diff ) min_diff = current_diff ;
max_term = Math . max ( A [ i ] , Math . max ( B [ j ] , C [ k ] ) ) ;
if ( A [ i ] == max_term ) i -= 1 ; else if ( B [ j ] == max_term ) j -= 1 ; else k -= 1 ; } return min_diff ; }
public static void main ( String [ ] args ) { int [ ] D = { 5 , 8 , 10 , 15 } ; int [ ] E = { 6 , 9 , 15 , 78 , 89 } ; int [ ] F = { 2 , 3 , 6 , 6 , 8 , 8 , 10 } ; System . out . println ( solve ( D , E , F ) ) ; } }
import java . io . * ; class GFG { public static void search ( int arr [ ] , int search_Element ) { int left = 0 ; int length = arr . length ; int right = length - 1 ; int position = - 1 ;
for ( left = 0 ; left <= right ; ) {
if ( arr [ left ] == search_Element ) { position = left ; System . out . println ( " Element ▁ found ▁ in ▁ Array ▁ at ▁ " + ( position + 1 ) + " ▁ Position ▁ with ▁ " + ( left + 1 ) + " ▁ Attempt " ) ; break ; }
if ( arr [ right ] == search_Element ) { position = right ; System . out . println ( " Element ▁ found ▁ in ▁ Array ▁ at ▁ " + ( position + 1 ) + " ▁ Position ▁ with ▁ " + ( length - right ) + " ▁ Attempt " ) ; break ; } left ++ ; right -- ; }
if ( position == - 1 ) System . out . println ( " Not ▁ found ▁ in ▁ Array ▁ with ▁ " + left + " ▁ Attempt " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int search_element = 5 ;
search ( arr , search_element ) ; } }
public class JumpSearch { public static int jumpSearch ( int [ ] arr , int x ) { int n = arr . length ;
int step = ( int ) Math . floor ( Math . sqrt ( n ) ) ;
int prev = 0 ; while ( arr [ Math . min ( step , n ) - 1 ] < x ) { prev = step ; step += ( int ) Math . floor ( Math . sqrt ( n ) ) ; if ( prev >= n ) return - 1 ; }
while ( arr [ prev ] < x ) { prev ++ ;
if ( prev == Math . min ( step , n ) ) return - 1 ; }
if ( arr [ prev ] == x ) return prev ; return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 1 , 1 , 2 , 3 , 5 , 8 , 13 , 21 , 34 , 55 , 89 , 144 , 233 , 377 , 610 } ; int x = 55 ;
int index = jumpSearch ( arr , x ) ;
System . out . println ( " Number " ▁ + ▁ x ▁ + ▁ " is at index " + index); } }
public static int interpolationSearch ( int arr [ ] , int lo , int hi , int x ) { int pos ;
if ( lo <= hi && x >= arr [ lo ] && x <= arr [ hi ] ) {
pos = lo + ( ( ( hi - lo ) / ( arr [ hi ] - arr [ lo ] ) ) * ( x - arr [ lo ] ) ) ;
if ( arr [ pos ] == x ) return pos ;
if ( arr [ pos ] < x ) return interpolationSearch ( arr , pos + 1 , hi , x ) ;
if ( arr [ pos ] > x ) return interpolationSearch ( arr , lo , pos - 1 , x ) ; } return - 1 ; }
int arr [ ] = { 10 , 12 , 13 , 16 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 33 , 35 , 42 , 47 } ; int n = arr . length ;
int x = 18 ; int index = interpolationSearch ( arr , 0 , n - 1 , x ) ;
if ( index != - 1 ) System . out . println ( " Element ▁ found ▁ at ▁ index ▁ " + index ) ; else System . out . println ( " Element ▁ not ▁ found . " ) ; } }
static int exponentialSearch ( int arr [ ] , int n , int x ) {
if ( arr [ 0 ] == x ) return 0 ;
int i = 1 ; while ( i < n && arr [ i ] <= x ) i = i * 2 ;
return Arrays . binarySearch ( arr , i / 2 , Math . min ( i , n - 1 ) , x ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 2 , 3 , 4 , 10 , 40 } ; int x = 10 ; int result = exponentialSearch ( arr , arr . length , x ) ; System . out . println ( ( result < 0 ) ? " Element ▁ is ▁ not ▁ present ▁ in ▁ array " : " Element ▁ is ▁ present ▁ at ▁ index ▁ " + result ) ; } }
void merge ( int arr [ ] , int l , int m , int r ) {
int n1 = m - l + 1 ; int n2 = r - m ;
int L [ ] = new int [ n1 ] ; int R [ ] = new int [ n2 ] ;
for ( int i = 0 ; i < n1 ; ++ i ) L [ i ] = arr [ l + i ] ; for ( int j = 0 ; j < n2 ; ++ j ) R [ j ] = arr [ m + 1 + j ] ;
int i = 0 , j = 0 ;
int k = l ; while ( i < n1 && j < n2 ) { if ( L [ i ] <= R [ j ] ) { arr [ k ] = L [ i ] ; i ++ ; } else { arr [ k ] = R [ j ] ; j ++ ; } k ++ ; }
while ( i < n1 ) { arr [ k ] = L [ i ] ; i ++ ; k ++ ; }
while ( j < n2 ) { arr [ k ] = R [ j ] ; j ++ ; k ++ ; } }
void sort ( int arr [ ] , int l , int r ) { if ( l < r ) {
int m = l + ( r - l ) / 2 ;
sort ( arr , l , m ) ; sort ( arr , m + 1 , r ) ;
merge ( arr , l , m , r ) ; } }
static void printArray ( int arr [ ] ) { int n = arr . length ; for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 12 , 11 , 13 , 5 , 6 , 7 } ; System . out . println ( " Given ▁ Array " ) ; printArray ( arr ) ; MergeSort ob = new MergeSort ( ) ; ob . sort ( arr , 0 , arr . length - 1 ) ; System . out . println ( " Sorted array "); printArray ( arr ) ; } }
static void countSort ( int [ ] arr ) { int max = Arrays . stream ( arr ) . max ( ) . getAsInt ( ) ; int min = Arrays . stream ( arr ) . min ( ) . getAsInt ( ) ; int range = max - min + 1 ; int count [ ] = new int [ range ] ; int output [ ] = new int [ arr . length ] ; for ( int i = 0 ; i < arr . length ; i ++ ) { count [ arr [ i ] - min ] ++ ; } for ( int i = 1 ; i < count . length ; i ++ ) { count [ i ] += count [ i - 1 ] ; } for ( int i = arr . length - 1 ; i >= 0 ; i -- ) { output [ count [ arr [ i ] - min ] - 1 ] = arr [ i ] ; count [ arr [ i ] - min ] -- ; } for ( int i = 0 ; i < arr . length ; i ++ ) { arr [ i ] = output [ i ] ; } }
static void printArray ( int [ ] arr ) { for ( int i = 0 ; i < arr . length ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } System . out . println ( " " ) ; }
public static void main ( String [ ] args ) { int [ ] arr = { - 5 , - 10 , 0 , - 3 , 8 , 5 , - 1 , 10 } ; countSort ( arr ) ; printArray ( arr ) ; } }
int getNextGap ( int gap ) {
gap = ( gap * 10 ) / 13 ; if ( gap < 1 ) return 1 ; return gap ; }
void sort ( int arr [ ] ) { int n = arr . length ;
int gap = n ;
boolean swapped = true ;
while ( gap != 1 swapped == true ) {
gap = getNextGap ( gap ) ;
swapped = false ;
for ( int i = 0 ; i < n - gap ; i ++ ) { if ( arr [ i ] > arr [ i + gap ] ) {
int temp = arr [ i ] ; arr [ i ] = arr [ i + gap ] ; arr [ i + gap ] = temp ;
swapped = true ; } } } }
public static void main ( String args [ ] ) { CombSort ob = new CombSort ( ) ; int arr [ ] = { 8 , 4 , 1 , 56 , 3 , - 44 , 23 , - 6 , 28 , 0 } ; ob . sort ( arr ) ; System . out . println ( " sorted ▁ array " ) ; for ( int i = 0 ; i < arr . length ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void cycleSort ( int arr [ ] , int n ) {
int writes = 0 ;
for ( int cycle_start = 0 ; cycle_start <= n - 2 ; cycle_start ++ ) {
int item = arr [ cycle_start ] ;
int pos = cycle_start ; for ( int i = cycle_start + 1 ; i < n ; i ++ ) if ( arr [ i ] < item ) pos ++ ;
if ( pos == cycle_start ) continue ;
while ( item == arr [ pos ] ) pos += 1 ;
if ( pos != cycle_start ) { int temp = item ; item = arr [ pos ] ; arr [ pos ] = temp ; writes ++ ; }
while ( pos != cycle_start ) { pos = cycle_start ;
for ( int i = cycle_start + 1 ; i < n ; i ++ ) if ( arr [ i ] < item ) pos += 1 ;
while ( item == arr [ pos ] ) pos += 1 ;
if ( item != arr [ pos ] ) { int temp = item ; item = arr [ pos ] ; arr [ pos ] = temp ; writes ++ ; } } } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 8 , 3 , 9 , 10 , 10 , 2 , 4 } ; int n = arr . length ; cycleSort ( arr , n ) ; System . out . println ( " After ▁ sort ▁ : ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
class Node { int data ; Node next ; Node ( int key ) { this . data = key ; next = null ; } } class GFG {
static Node mergeSort ( Node head ) { if ( head . next == null ) return head ; Node mid = findMid ( head ) ; Node head2 = mid . next ; mid . next = null ; Node newHead1 = mergeSort ( head ) ; Node newHead2 = mergeSort ( head2 ) ; Node finalHead = merge ( newHead1 , newHead2 ) ; return finalHead ; }
static Node merge ( Node head1 , Node head2 ) { Node merged = new Node ( - 1 ) ; Node temp = merged ;
while ( head1 != null && head2 != null ) { if ( head1 . data < head2 . data ) { temp . next = head1 ; head1 = head1 . next ; } else { temp . next = head2 ; head2 = head2 . next ; } temp = temp . next ; }
while ( head1 != null ) { temp . next = head1 ; head1 = head1 . next ; temp = temp . next ; }
while ( head2 != null ) { temp . next = head2 ; head2 = head2 . next ; temp = temp . next ; } return merged . next ; }
static Node findMid ( Node head ) { Node slow = head , fast = head . next ; while ( fast != null && fast . next != null ) { slow = slow . next ; fast = fast . next . next ; } return slow ; }
static void printList ( Node head ) { while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; head = head . next ; } }
public static void main ( String [ ] args ) { Node head = new Node ( 7 ) ; Node temp = head ; temp . next = new Node ( 10 ) ; temp = temp . next ; temp . next = new Node ( 5 ) ; temp = temp . next ; temp . next = new Node ( 20 ) ; temp = temp . next ; temp . next = new Node ( 3 ) ; temp = temp . next ; temp . next = new Node ( 2 ) ; temp = temp . next ;
head = mergeSort ( head ) ; System . out . print ( " Sorted Linked List is : "); printList ( head ) ; } }
int findCrossOver ( int arr [ ] , int low , int high , int x ) {
if ( arr [ high ] <= x ) return high ;
if ( arr [ low ] > x ) return low ;
int mid = ( low + high ) / 2 ;
if ( arr [ mid ] <= x && arr [ mid + 1 ] > x ) return mid ;
if ( arr [ mid ] < x ) return findCrossOver ( arr , mid + 1 , high , x ) ; return findCrossOver ( arr , low , mid - 1 , x ) ; }
void printKclosest ( int arr [ ] , int x , int k , int n ) {
int l = findCrossOver ( arr , 0 , n - 1 , x ) ;
int r = l + 1 ;
int count = 0 ;
if ( arr [ l ] == x ) l -- ;
while ( l >= 0 && r < n && count < k ) { if ( x - arr [ l ] < arr [ r ] - x ) System . out . print ( arr [ l -- ] + " ▁ " ) ; else System . out . print ( arr [ r ++ ] + " ▁ " ) ; count ++ ; }
while ( count < k && l >= 0 ) { System . out . print ( arr [ l -- ] + " ▁ " ) ; count ++ ; }
while ( count < k && r < n ) { System . out . print ( arr [ r ++ ] + " ▁ " ) ; count ++ ; } }
public static void main ( String args [ ] ) { KClosest ob = new KClosest ( ) ; int arr [ ] = { 12 , 16 , 22 , 30 , 35 , 39 , 42 , 45 , 48 , 50 , 53 , 55 , 56 } ; int n = arr . length ; int x = 35 , k = 4 ; ob . printKclosest ( arr , x , 4 , n ) ; } }
void countSort ( int arr [ ] , int n , int exp ) {
int output [ ] = new int [ n ] ; int i , count [ ] = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) count [ i ] = 0 ;
for ( i = 0 ; i < n ; i ++ ) count [ ( arr [ i ] / exp ) % n ] ++ ;
for ( i = 1 ; i < n ; i ++ ) count [ i ] += count [ i - 1 ] ;
for ( i = n - 1 ; i >= 0 ; i -- ) { output [ count [ ( arr [ i ] / exp ) % n ] - 1 ] = arr [ i ] ; count [ ( arr [ i ] / exp ) % n ] -- ; }
for ( i = 0 ; i < n ; i ++ ) arr [ i ] = output [ i ] ; }
void sort ( int arr [ ] , int n ) {
countSort ( arr , n , 1 ) ;
countSort ( arr , n , n ) ; }
void printArr ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
int arr [ ] = { 40 , 12 , 45 , 32 , 33 , 1 , 22 } ; int n = arr . length ; System . out . println ( " Given ▁ array " ) ; ob . printArr ( arr , n ) ; ob . sort ( arr , n ) ; System . out . println ( " Sorted ▁ array " ) ; ob . printArr ( arr , n ) ; } }
void printClosest ( int ar1 [ ] , int ar2 [ ] , int m , int n , int x ) {
int diff = Integer . MAX_VALUE ;
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 ; while ( l < m && r >= 0 ) {
if ( Math . abs ( ar1 [ l ] + ar2 [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( ar1 [ l ] + ar2 [ r ] - x ) ; }
if ( ar1 [ l ] + ar2 [ r ] > x ) r -- ;
else l ++ ; }
System . out . print ( " The ▁ closest ▁ pair ▁ is ▁ [ " + ar1 [ res_l ] + " , ▁ " + ar2 [ res_r ] + " ] " ) ; }
public static void main ( String args [ ] ) { ClosestPair ob = new ClosestPair ( ) ; int ar1 [ ] = { 1 , 4 , 5 , 7 } ; int ar2 [ ] = { 10 , 20 , 30 , 40 } ; int m = ar1 . length ; int n = ar2 . length ; int x = 38 ; ob . printClosest ( ar1 , ar2 , m , n , x ) ; } }
static void printClosest ( int arr [ ] , int n , int x ) {
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 , diff = Integer . MAX_VALUE ;
while ( r > l ) {
if ( Math . abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } System . out . println ( " ▁ The ▁ closest ▁ pair ▁ is ▁ " + arr [ res_l ] + " ▁ and ▁ " + arr [ res_r ] ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 10 , 22 , 28 , 29 , 30 , 40 } , x = 54 ; int n = arr . length ; printClosest ( arr , n , x ) ; } }
int countOnes ( int arr [ ] , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
public static void main ( String args [ ] ) { CountOnes ob = new CountOnes ( ) ; int arr [ ] = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = arr . length ; System . out . println ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " + ob . countOnes ( arr , 0 , n - 1 ) ) ; } }
public class LinkedlistIS { node head ; node sorted ; class node { int val ; node next ; public node ( int val ) { this . val = val ; } }
void push ( int val ) {
node newnode = new node ( val ) ;
newnode . next = head ;
head = newnode ; }
void insertionSort ( node headref ) {
sorted = null ; node current = headref ;
while ( current != null ) {
node next = current . next ;
sortedInsert ( current ) ;
current = next ; }
head = sorted ; }
void sortedInsert ( node newnode ) {
if ( sorted == null sorted . val >= newnode . val ) { newnode . next = sorted ; sorted = newnode ; } else { node current = sorted ;
while ( current . next != null && current . next . val < newnode . val ) { current = current . next ; } newnode . next = current . next ; current . next = newnode ; } }
void printlist ( node head ) { while ( head != null ) { System . out . print ( head . val + " ▁ " ) ; head = head . next ; } }
public static void main ( String [ ] args ) { LinkedlistIS list = new LinkedlistIS ( ) ; list . push ( 5 ) ; list . push ( 20 ) ; list . push ( 4 ) ; list . push ( 3 ) ; list . push ( 30 ) ; System . out . println ( " Linked ▁ List ▁ before ▁ Sorting . . " ) ; list . printlist ( list . head ) ; list . insertionSort ( list . head ) ; System . out . println ( " LinkedList After sorting "); list . printlist ( list . head ) ; } }
public static void minimumSwaps ( int a [ ] , int n ) { int maxx = - 1 , minn = a [ 0 ] , l = 0 , r = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] > maxx ) { maxx = a [ i ] ; l = i ; }
if ( a [ i ] <= minn ) { minn = a [ i ] ; r = i ; } } if ( r < l ) System . out . println ( l + ( n - r - 2 ) ) ; else System . out . println ( l + ( n - r - 1 ) ) ; }
public static void main ( String args [ ] ) throws IOException { int a [ ] = { 5 , 6 , 1 , 3 } ; int n = a . length ; minimumSwaps ( a , n ) ; } }
static int max_ref ;
static int _lis ( int arr [ ] , int n ) {
if ( n == 1 ) return 1 ;
int res , max_ending_here = 1 ;
for ( int i = 1 ; i < n ; i ++ ) { res = _lis ( arr , i ) ; if ( arr [ i - 1 ] < arr [ n - 1 ] && res + 1 > max_ending_here ) max_ending_here = res + 1 ; }
if ( max_ref < max_ending_here ) max_ref = max_ending_here ;
return max_ending_here ; }
static int lis ( int arr [ ] , int n ) {
max_ref = 1 ;
_lis ( arr , n ) ;
return max_ref ; }
public static void main ( String args [ ] ) { int arr [ ] = { 10 , 22 , 9 , 33 , 21 , 50 , 41 , 60 } ; int n = arr . length ; System . out . println ( " Length ▁ of ▁ lis ▁ is ▁ " + lis ( arr , n ) + "NEW_LINE"); } }
static int lis ( int arr [ ] , int n ) { int lis [ ] = new int [ n ] ; int i , j , max = 0 ;
for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
for ( i = 0 ; i < n ; i ++ ) if ( max < lis [ i ] ) max = lis [ i ] ; return max ; }
public static void main ( String args [ ] ) { int arr [ ] = { 10 , 22 , 9 , 33 , 21 , 50 , 41 , 60 } ; int n = arr . length ; System . out . println ( " Length ▁ of ▁ lis ▁ is ▁ " + lis ( arr , n ) + "NEW_LINE"); } }
import java . util . * ; class GFG { static int row = 3 ; static int col = 3 ; static int minCost ( int cost [ ] [ ] ) {
for ( int i = 1 ; i < row ; i ++ ) { cost [ i ] [ 0 ] += cost [ i - 1 ] [ 0 ] ; }
for ( int j = 1 ; j < col ; j ++ ) { cost [ 0 ] [ j ] += cost [ 0 ] [ j - 1 ] ; }
for ( int i = 1 ; i < row ; i ++ ) { for ( int j = 1 ; j < col ; j ++ ) { cost [ i ] [ j ] += Math . min ( cost [ i - 1 ] [ j - 1 ] , Math . min ( cost [ i - 1 ] [ j ] , cost [ i ] [ j - 1 ] ) ) ; } }
return cost [ row - 1 ] [ col - 1 ] ; }
public static void main ( String [ ] args ) { int cost [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 8 , 2 } , { 1 , 5 , 3 } } ; System . out . print ( minCost ( cost ) + "NEW_LINE"); } }
public static int count ( int S [ ] , int m , int n ) {
int table [ ] = new int [ n + 1 ] ;
table [ 0 ] = 1 ;
for ( int i = 0 ; i < m ; i ++ ) for ( int j = S [ i ] ; j <= n ; j ++ ) table [ j ] += table [ j - S [ i ] ] ; return table [ n ] ; }
import java . io . * ; import java . util . * ; class GFG { static int [ ] [ ] dp = new int [ 100 ] [ 100 ] ;
static int matrixChainMemoised ( int [ ] p , int i , int j ) { if ( i == j ) { return 0 ; } if ( dp [ i ] [ j ] != - 1 ) { return dp [ i ] [ j ] ; } dp [ i ] [ j ] = Integer . MAX_VALUE ; for ( int k = i ; k < j ; k ++ ) { dp [ i ] [ j ] = Math . min ( dp [ i ] [ j ] , matrixChainMemoised ( p , i , k ) + matrixChainMemoised ( p , k + 1 , j ) + p [ i - 1 ] * p [ k ] * p [ j ] ) ; } return dp [ i ] [ j ] ; } static int MatrixChainOrder ( int [ ] p , int n ) { int i = 1 , j = n - 1 ; return matrixChainMemoised ( p , i , j ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int n = arr . length ; for ( int [ ] row : dp ) Arrays . fill ( row , - 1 ) ; System . out . println ( " Minimum ▁ number ▁ of ▁ multiplications ▁ is ▁ " + MatrixChainOrder ( arr , n ) ) ; } }
import java . util . * ; class GFG { static int binomialCoeff ( int n , int k ) { int C [ ] = new int [ k + 1 ] ;
C [ 0 ] = 1 ; for ( int i = 1 ; i <= n ; i ++ ) {
for ( int j = Math . min ( i , k ) ; j > 0 ; j -- ) C [ j ] = C [ j ] + C [ j - 1 ] ; } return C [ k ] ; }
public static void main ( String [ ] args ) { int n = 5 , k = 2 ; System . out . printf ( " Value ▁ of ▁ C ( % d , ▁ % d ) ▁ is ▁ % d ▁ " , n , k , binomialCoeff ( n , k ) ) ; } }
static int eggDrop ( int n , int k ) {
if ( k == 1 k == 0 ) return k ;
if ( n == 1 ) return k ; int min = Integer . MAX_VALUE ; int x , res ;
for ( x = 1 ; x <= k ; x ++ ) { res = Math . max ( eggDrop ( n - 1 , x - 1 ) , eggDrop ( n , k - x ) ) ; if ( res < min ) min = res ; } return min + 1 ; }
public static void main ( String args [ ] ) { int n = 2 , k = 10 ; System . out . print ( " Minimum ▁ number ▁ of ▁ " + " trials ▁ in ▁ worst ▁ case ▁ with ▁ " + n + " ▁ eggs ▁ and ▁ " + k + " ▁ floors ▁ is ▁ " + eggDrop ( n , k ) ) ; } }
static int cutRod ( int price [ ] , int n ) { if ( n <= 0 ) return 0 ; int max_val = Integer . MIN_VALUE ;
for ( int i = 0 ; i < n ; i ++ ) max_val = Math . max ( max_val , price [ i ] + cutRod ( price , n - i - 1 ) ) ; return max_val ; }
public static void main ( String args [ ] ) { int arr [ ] = new int [ ] { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = arr . length ; System . out . println ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " + cutRod ( arr , size ) ) ; } }
class GFG { static class pair { int first , second ; public pair ( int first , int second ) { this . first = first ; this . second = second ; } } static int findRoot ( pair arr [ ] , int n ) {
int root = 0 ; for ( int i = 0 ; i < n ; i ++ ) { root += ( arr [ i ] . first - arr [ i ] . second ) ; } return root ; }
public static void main ( String [ ] args ) { pair arr [ ] = { new pair ( 1 , 5 ) , new pair ( 2 , 0 ) , new pair ( 3 , 0 ) , new pair ( 4 , 0 ) , new pair ( 5 , 5 ) , new pair ( 6 , 5 ) } ; int n = arr . length ; System . out . printf ( "%dNEW_LINE", findRoot(arr, n)); } }
static int cutRod ( int price [ ] , int n ) { int val [ ] = new int [ n + 1 ] ; val [ 0 ] = 0 ;
for ( int i = 1 ; i <= n ; i ++ ) { int max_val = Integer . MIN_VALUE ; for ( int j = 0 ; j < i ; j ++ ) max_val = Math . max ( max_val , price [ j ] + val [ i - j - 1 ] ) ; val [ i ] = max_val ; } return val [ n ] ; }
public static void main ( String args [ ] ) { int arr [ ] = new int [ ] { 1 , 5 , 8 , 9 , 10 , 17 , 17 , 20 } ; int size = arr . length ; System . out . println ( " Maximum ▁ Obtainable ▁ Value ▁ is ▁ " + cutRod ( arr , size ) ) ; } }
static int lbs ( int arr [ ] , int n ) { int i , j ;
int [ ] lis = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lis [ i ] = 1 ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
int [ ] lds = new int [ n ] ; for ( i = 0 ; i < n ; i ++ ) lds [ i ] = 1 ;
for ( i = n - 2 ; i >= 0 ; i -- ) for ( j = n - 1 ; j > i ; j -- ) if ( arr [ i ] > arr [ j ] && lds [ i ] < lds [ j ] + 1 ) lds [ i ] = lds [ j ] + 1 ;
int max = lis [ 0 ] + lds [ 0 ] - 1 ; for ( i = 1 ; i < n ; i ++ ) if ( lis [ i ] + lds [ i ] - 1 > max ) max = lis [ i ] + lds [ i ] - 1 ; return max ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 8 , 4 , 12 , 2 , 10 , 6 , 14 , 1 , 9 , 5 , 13 , 3 , 11 , 7 , 15 } ; int n = arr . length ; System . out . println ( " Length ▁ of ▁ LBS ▁ is ▁ " + lbs ( arr , n ) ) ; } }
public class GFG { static boolean isPalindrome ( String string , int i , int j ) { while ( i < j ) { if ( string . charAt ( i ) != string . charAt ( j ) ) return false ; i ++ ; j -- ; } return true ; } static int minPalPartion ( String string , int i , int j ) { if ( i >= j || isPalindrome ( string , i , j ) ) return 0 ; int ans = Integer . MAX_VALUE , count ; for ( int k = i ; k < j ; k ++ ) { count = minPalPartion ( string , i , k ) + minPalPartion ( string , k + 1 , j ) + 1 ; ans = Math . min ( ans , count ) ; } return ans ; }
public static void main ( String args [ ] ) { String str = " ababbbabbababa " ; System . out . println ( " Min ▁ cuts ▁ needed ▁ for ▁ " + " Palindrome ▁ Partitioning ▁ is ▁ " + minPalPartion ( str , 0 , str . length ( ) - 1 ) ) ; } }
public static boolean findPartiion ( int arr [ ] , int n ) { int sum = 0 ; int i , j ;
for ( i = 0 ; i < n ; i ++ ) sum += arr [ i ] ; if ( sum % 2 != 0 ) return false ; boolean [ ] part = new boolean [ sum / 2 + 1 ] ;
for ( i = 0 ; i <= sum / 2 ; i ++ ) { part [ i ] = false ; }
for ( i = 0 ; i < n ; i ++ ) {
for ( j = sum / 2 ; j >= arr [ i ] ; j -- ) {
if ( part [ j - arr [ i ] ] == true j == arr [ i ] ) part [ j ] = true ; } } return part [ sum / 2 ] ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 3 , 2 , 3 , 2 } ; int n = 6 ;
if ( findPartiion ( arr , n ) == true ) System . out . println ( " Can ▁ be ▁ divided ▁ into ▁ two ▁ " + " subsets ▁ of ▁ equal ▁ sum " ) ; else System . out . println ( " Can ▁ not ▁ be ▁ divided ▁ into ▁ " + " two ▁ subsets ▁ of ▁ equal ▁ sum " ) ; } }
public class WordWrap { final int MAX = Integer . MAX_VALUE ;
int printSolution ( int p [ ] , int n ) { int k ; if ( p [ n ] == 1 ) k = 1 ; else k = printSolution ( p , p [ n ] - 1 ) + 1 ; System . out . println ( " Line ▁ number " + " ▁ " + k + " : ▁ " + " From ▁ word ▁ no . " + " ▁ " + p [ n ] + " ▁ " + " to " + " ▁ " + n ) ; return k ; }
void solveWordWrap ( int l [ ] , int n , int M ) {
int extras [ ] [ ] = new int [ n + 1 ] [ n + 1 ] ;
int lc [ ] [ ] = new int [ n + 1 ] [ n + 1 ] ;
int c [ ] = new int [ n + 1 ] ;
int p [ ] = new int [ n + 1 ] ;
for ( int i = 1 ; i <= n ; i ++ ) { extras [ i ] [ i ] = M - l [ i - 1 ] ; for ( int j = i + 1 ; j <= n ; j ++ ) extras [ i ] [ j ] = extras [ i ] [ j - 1 ] - l [ j - 1 ] - 1 ; }
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = i ; j <= n ; j ++ ) { if ( extras [ i ] [ j ] < 0 ) lc [ i ] [ j ] = MAX ; else if ( j == n && extras [ i ] [ j ] >= 0 ) lc [ i ] [ j ] = 0 ; else lc [ i ] [ j ] = extras [ i ] [ j ] * extras [ i ] [ j ] ; } }
c [ 0 ] = 0 ; for ( int j = 1 ; j <= n ; j ++ ) { c [ j ] = MAX ; for ( int i = 1 ; i <= j ; i ++ ) { if ( c [ i - 1 ] != MAX && lc [ i ] [ j ] != MAX && ( c [ i - 1 ] + lc [ i ] [ j ] < c [ j ] ) ) { c [ j ] = c [ i - 1 ] + lc [ i ] [ j ] ; p [ j ] = i ; } } } printSolution ( p , n ) ; }
public static void main ( String args [ ] ) { WordWrap w = new WordWrap ( ) ; int l [ ] = { 3 , 2 , 2 , 5 } ; int n = l . length ; int M = 6 ; w . solveWordWrap ( l , n , M ) ; } }
static int maxDivide ( int a , int b ) { while ( a % b == 0 ) a = a / b ; return a ; }
static int isUgly ( int no ) { no = maxDivide ( no , 2 ) ; no = maxDivide ( no , 3 ) ; no = maxDivide ( no , 5 ) ; return ( no == 1 ) ? 1 : 0 ; }
static int getNthUglyNo ( int n ) { int i = 1 ;
int count = 1 ;
while ( n > count ) { i ++ ; if ( isUgly ( i ) == 1 ) count ++ ; } return i ; }
public static void main ( String args [ ] ) { int no = getNthUglyNo ( 150 ) ; System . out . println ( "150th ▁ ugly ▁ " + " no . ▁ is ▁ " + no ) ; } }
static int sum ( int freq [ ] , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) s += freq [ k ] ; return s ; }
static int optCost ( int freq [ ] , int i , int j ) {
if ( j < i ) return 0 ;
if ( j == i ) return freq [ i ] ;
int fsum = sum ( freq , i , j ) ;
int min = Integer . MAX_VALUE ;
for ( int r = i ; r <= j ; ++ r ) { int cost = optCost ( freq , i , r - 1 ) + optCost ( freq , r + 1 , j ) ; if ( cost < min ) min = cost ; }
return min + fsum ; }
static int optimalSearchTree ( int keys [ ] , int freq [ ] , int n ) {
return optCost ( freq , 0 , n - 1 ) ; }
public static void main ( String [ ] args ) { int keys [ ] = { 10 , 12 , 20 } ; int freq [ ] = { 34 , 8 , 50 } ; int n = keys . length ; System . out . println ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ " + optimalSearchTree ( keys , freq , n ) ) ; } }
static int sum ( int freq [ ] , int i , int j ) { int s = 0 ; for ( int k = i ; k <= j ; k ++ ) { if ( k >= freq . length ) continue ; s += freq [ k ] ; } return s ; }
static int optimalSearchTree ( int keys [ ] , int freq [ ] , int n ) {
int cost [ ] [ ] = new int [ n + 1 ] [ n + 1 ] ;
for ( int i = 0 ; i < n ; i ++ ) cost [ i ] [ i ] = freq [ i ] ;
for ( int L = 2 ; L <= n ; L ++ ) {
for ( int i = 0 ; i <= n - L + 1 ; i ++ ) {
int j = i + L - 1 ; cost [ i ] [ j ] = Integer . MAX_VALUE ;
for ( int r = i ; r <= j ; r ++ ) {
int c = ( ( r > i ) ? cost [ i ] [ r - 1 ] : 0 ) + ( ( r < j ) ? cost [ r + 1 ] [ j ] : 0 ) + sum ( freq , i , j ) ; if ( c < cost [ i ] [ j ] ) cost [ i ] [ j ] = c ; } } } return cost [ 0 ] [ n - 1 ] ; }
public static void main ( String [ ] args ) { int keys [ ] = { 10 , 12 , 20 } ; int freq [ ] = { 34 , 8 , 50 } ; int n = keys . length ; System . out . println ( " Cost ▁ of ▁ Optimal ▁ BST ▁ is ▁ " + optimalSearchTree ( keys , freq , n ) ) ; } }
static boolean isSubsetSum ( int set [ ] , int n , int sum ) {
if ( sum == 0 ) return true ; if ( n == 0 ) return false ;
if ( set [ n - 1 ] > sum ) return isSubsetSum ( set , n - 1 , sum ) ;
return isSubsetSum ( set , n - 1 , sum ) || isSubsetSum ( set , n - 1 , sum - set [ n - 1 ] ) ; }
public static void main ( String args [ ] ) { int set [ ] = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = set . length ; if ( isSubsetSum ( set , n , sum ) == true ) System . out . println ( " Found ▁ a ▁ subset " + " ▁ with ▁ given ▁ sum " ) ; else System . out . println ( " No ▁ subset ▁ with " + " ▁ given ▁ sum " ) ; } }
static boolean isSubsetSum ( int set [ ] , int n , int sum ) {
boolean subset [ ] [ ] = new boolean [ sum + 1 ] [ n + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) subset [ 0 ] [ i ] = true ;
for ( int i = 1 ; i <= sum ; i ++ ) subset [ i ] [ 0 ] = false ;
for ( int i = 1 ; i <= sum ; i ++ ) { for ( int j = 1 ; j <= n ; j ++ ) { subset [ i ] [ j ] = subset [ i ] [ j - 1 ] ; if ( i >= set [ j - 1 ] ) subset [ i ] [ j ] = subset [ i ] [ j ] || subset [ i - set [ j - 1 ] ] [ j - 1 ] ; } }
for ( int i = 0 ; i <= sum ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) System . out . println ( subset [ i ] [ j ] ) ; } return subset [ sum ] [ n ] ; }
public static void main ( String args [ ] ) { int set [ ] = { 3 , 34 , 4 , 12 , 5 , 2 } ; int sum = 9 ; int n = set . length ; if ( isSubsetSum ( set , n , sum ) == true ) System . out . println ( " Found ▁ a ▁ subset " + " ▁ with ▁ given ▁ sum " ) ; else System . out . println ( " No ▁ subset ▁ with " + " ▁ given ▁ sum " ) ; } }
static int countParenth ( char symb [ ] , char oper [ ] , int n ) { int F [ ] [ ] = new int [ n ] [ n ] ; int T [ ] [ ] = new int [ n ] [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) { F [ i ] [ i ] = ( symb [ i ] == ' F ' ) ? 1 : 0 ; T [ i ] [ i ] = ( symb [ i ] == ' T ' ) ? 1 : 0 ; }
for ( int gap = 1 ; gap < n ; ++ gap ) { for ( int i = 0 , j = gap ; j < n ; ++ i , ++ j ) { T [ i ] [ j ] = F [ i ] [ j ] = 0 ; for ( int g = 0 ; g < gap ; g ++ ) {
int k = i + g ;
int tik = T [ i ] [ k ] + F [ i ] [ k ] ; int tkj = T [ k + 1 ] [ j ] + F [ k + 1 ] [ j ] ;
if ( oper [ k ] == ' & ' ) { T [ i ] [ j ] += T [ i ] [ k ] * T [ k + 1 ] [ j ] ; F [ i ] [ j ] += ( tik * tkj - T [ i ] [ k ] * T [ k + 1 ] [ j ] ) ; } if ( oper [ k ] == ' ▁ ' ) { F [ i ] [ j ] += F [ i ] [ k ] * F [ k + 1 ] [ j ] ; T [ i ] [ j ] += ( tik * tkj - F [ i ] [ k ] * F [ k + 1 ] [ j ] ) ; } if ( oper [ k ] == ' ^ ' ) { T [ i ] [ j ] += F [ i ] [ k ] * T [ k + 1 ] [ j ] + T [ i ] [ k ] * F [ k + 1 ] [ j ] ; F [ i ] [ j ] += T [ i ] [ k ] * T [ k + 1 ] [ j ] + F [ i ] [ k ] * F [ k + 1 ] [ j ] ; } } } } return T [ 0 ] [ n - 1 ] ; }
public static void main ( String [ ] args ) { char symbols [ ] = " TTFT " . toCharArray ( ) ; char operators [ ] = " | & ^ " . toCharArray ( ) ; int n = symbols . length ;
System . out . println ( countParenth ( symbols , operators , n ) ) ; } }
static int getCount ( char keypad [ ] [ ] , int n ) { if ( keypad == null n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
int row [ ] = { 0 , 0 , - 1 , 0 , 1 } ; int col [ ] = { 0 , - 1 , 0 , 1 , 0 } ;
int [ ] [ ] count = new int [ 10 ] [ n + 1 ] ; int i = 0 , j = 0 , k = 0 , move = 0 , ro = 0 , co = 0 , num = 0 ; int nextNum = 0 , totalCount = 0 ;
for ( i = 0 ; i <= 9 ; i ++ ) { count [ i ] [ 0 ] = 0 ; count [ i ] [ 1 ] = 1 ; }
for ( k = 2 ; k <= n ; k ++ ) {
for ( i = 0 ; i < 4 ; i ++ ) {
for ( j = 0 ; j < 3 ; j ++ ) {
if ( keypad [ i ] [ j ] != ' * ' && keypad [ i ] [ j ] != ' # ' ) {
num = keypad [ i ] [ j ] - '0' ; count [ num ] [ k ] = 0 ;
for ( move = 0 ; move < 5 ; move ++ ) { ro = i + row [ move ] ; co = j + col [ move ] ; if ( ro >= 0 && ro <= 3 && co >= 0 && co <= 2 && keypad [ ro ] [ co ] != ' * ' && keypad [ ro ] [ co ] != ' # ' ) { nextNum = keypad [ ro ] [ co ] - '0' ; count [ num ] [ k ] += count [ nextNum ] [ k - 1 ] ; } } } } } }
totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ ) totalCount += count [ i ] [ n ] ; return totalCount ; }
public static void main ( String [ ] args ) { char keypad [ ] [ ] = { { '1' , '2' , '3' } , { '4' , '5' , '6' } , { '7' , '8' , '9' } , { ' * ' , '0' , ' # ' } } ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 1, getCount ( keypad , 1 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 2, getCount ( keypad , 2 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 3, getCount ( keypad , 3 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 4, getCount ( keypad , 4 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 5, getCount ( keypad , 5 ) ) ; } }
static int getCount ( char keypad [ ] [ ] , int n ) { if ( keypad == null n <= 0 ) return 0 ; if ( n == 1 ) return 10 ;
int [ ] odd = new int [ 10 ] ; int [ ] even = new int [ 10 ] ; int i = 0 , j = 0 , useOdd = 0 , totalCount = 0 ; for ( i = 0 ; i <= 9 ; i ++ )
odd [ i ] = 1 ;
for ( j = 2 ; j <= n ; j ++ ) { useOdd = 1 - useOdd ;
if ( useOdd == 1 ) { even [ 0 ] = odd [ 0 ] + odd [ 8 ] ; even [ 1 ] = odd [ 1 ] + odd [ 2 ] + odd [ 4 ] ; even [ 2 ] = odd [ 2 ] + odd [ 1 ] + odd [ 3 ] + odd [ 5 ] ; even [ 3 ] = odd [ 3 ] + odd [ 2 ] + odd [ 6 ] ; even [ 4 ] = odd [ 4 ] + odd [ 1 ] + odd [ 5 ] + odd [ 7 ] ; even [ 5 ] = odd [ 5 ] + odd [ 2 ] + odd [ 4 ] + odd [ 8 ] + odd [ 6 ] ; even [ 6 ] = odd [ 6 ] + odd [ 3 ] + odd [ 5 ] + odd [ 9 ] ; even [ 7 ] = odd [ 7 ] + odd [ 4 ] + odd [ 8 ] ; even [ 8 ] = odd [ 8 ] + odd [ 0 ] + odd [ 5 ] + odd [ 7 ] + odd [ 9 ] ; even [ 9 ] = odd [ 9 ] + odd [ 6 ] + odd [ 8 ] ; } else { odd [ 0 ] = even [ 0 ] + even [ 8 ] ; odd [ 1 ] = even [ 1 ] + even [ 2 ] + even [ 4 ] ; odd [ 2 ] = even [ 2 ] + even [ 1 ] + even [ 3 ] + even [ 5 ] ; odd [ 3 ] = even [ 3 ] + even [ 2 ] + even [ 6 ] ; odd [ 4 ] = even [ 4 ] + even [ 1 ] + even [ 5 ] + even [ 7 ] ; odd [ 5 ] = even [ 5 ] + even [ 2 ] + even [ 4 ] + even [ 8 ] + even [ 6 ] ; odd [ 6 ] = even [ 6 ] + even [ 3 ] + even [ 5 ] + even [ 9 ] ; odd [ 7 ] = even [ 7 ] + even [ 4 ] + even [ 8 ] ; odd [ 8 ] = even [ 8 ] + even [ 0 ] + even [ 5 ] + even [ 7 ] + even [ 9 ] ; odd [ 9 ] = even [ 9 ] + even [ 6 ] + even [ 8 ] ; } }
totalCount = 0 ; if ( useOdd == 1 ) { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += even [ i ] ; } else { for ( i = 0 ; i <= 9 ; i ++ ) totalCount += odd [ i ] ; } return totalCount ; }
public static void main ( String [ ] args ) { char keypad [ ] [ ] = { { '1' , '2' , '3' } , { '4' , '5' , '6' } , { '7' , '8' , '9' } , { ' * ' , '0' , ' # ' } } ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 1, getCount ( keypad , 1 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 2, getCount ( keypad , 2 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 3, getCount ( keypad , 3 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 4, getCount ( keypad , 4 ) ) ; System . out . printf ( "Count for numbers of length %d: %dNEW_LINE", 5, getCount ( keypad , 5 ) ) ; } }
static int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ? 1 : 0 ; if ( sum == 0 ) return 1 ;
int ans = 0 ;
for ( int i = 0 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
static int finalCount ( int n , int sum ) {
int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
public static void main ( String args [ ] ) { int n = 2 , sum = 5 ; System . out . println ( finalCount ( n , sum ) ) ; } }
static int lookup [ ] [ ] = new int [ 101 ] [ 501 ] ;
static int countRec ( int n , int sum ) {
if ( n == 0 ) return sum == 0 ? 1 : 0 ;
if ( lookup [ n ] [ sum ] != - 1 ) return lookup [ n ] [ sum ] ;
int ans = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return lookup [ n ] [ sum ] = ans ; }
static int finalCount ( int n , int sum ) {
for ( int i = 0 ; i <= 100 ; ++ i ) { for ( int j = 0 ; j <= 500 ; ++ j ) { lookup [ i ] [ j ] = - 1 ; } }
int ans = 0 ;
for ( int i = 1 ; i <= 9 ; i ++ ) if ( sum - i >= 0 ) ans += countRec ( n - 1 , sum - i ) ; return ans ; }
public static void main ( String args [ ] ) { int n = 3 , sum = 5 ; System . out . println ( finalCount ( n , sum ) ) ; } }
public class GFG { private static void findCount ( int n , int sum ) {
int start = ( int ) Math . pow ( 10 , n - 1 ) ; int end = ( int ) Math . pow ( 10 , n ) - 1 ; int count = 0 ; int i = start ; while ( i < end ) { int cur = 0 ; int temp = i ; while ( temp != 0 ) { cur += temp % 10 ; temp = temp / 10 ; } if ( cur == sum ) { count ++ ; i += 9 ; } else i ++ ; } System . out . println ( count ) ; }
public static void main ( String [ ] args ) { int n = 3 ; int sum = 5 ; findCount ( n , sum ) ; } }
class NDN { static int countNonDecreasing ( int n ) {
int dp [ ] [ ] = new int [ 10 ] [ n + 1 ] ;
for ( int i = 0 ; i < 10 ; i ++ ) dp [ i ] [ 1 ] = 1 ;
for ( int digit = 0 ; digit <= 9 ; digit ++ ) {
for ( int len = 2 ; len <= n ; len ++ ) {
for ( int x = 0 ; x <= digit ; x ++ ) dp [ digit ] [ len ] += dp [ x ] [ len - 1 ] ; } } int count = 0 ;
for ( int i = 0 ; i < 10 ; i ++ ) count += dp [ i ] [ n ] ; return count ; }
public static void main ( String args [ ] ) { int n = 3 ; System . out . println ( countNonDecreasing ( n ) ) ; } }
public class GFG { static long countNonDecreasing ( int n ) { int N = 10 ;
long count = 1 ; for ( int i = 1 ; i <= n ; i ++ ) { count *= ( N + i - 1 ) ; count /= i ; } return count ; }
public static void main ( String args [ ] ) { int n = 3 ; System . out . print ( countNonDecreasing ( n ) ) ; } }
static int getMinSquares ( int n ) {
if ( n <= 3 ) return n ;
int res = n ;
for ( int x = 1 ; x <= n ; x ++ ) { int temp = x * x ; if ( temp > n ) break ; else res = Math . min ( res , 1 + getMinSquares ( n - temp ) ) ; } return res ; }
public static void main ( String args [ ] ) { System . out . println ( getMinSquares ( 6 ) ) ; } }
static int getMinSquares ( int n ) {
if ( n <= 3 ) return n ;
int dp [ ] = new int [ n + 1 ] ;
dp [ 0 ] = 0 ; dp [ 1 ] = 1 ; dp [ 2 ] = 2 ; dp [ 3 ] = 3 ;
for ( int i = 4 ; i <= n ; i ++ ) {
dp [ i ] = i ;
for ( int x = 1 ; x <= Math . ceil ( Math . sqrt ( i ) ) ; x ++ ) { int temp = x * x ; if ( temp > i ) break ; else dp [ i ] = Math . min ( dp [ i ] , 1 + dp [ i - temp ] ) ; } }
int res = dp [ n ] ; return res ; }
public static void main ( String args [ ] ) { System . out . println ( getMinSquares ( 6 ) ) ; } }
static int minCoins ( int coins [ ] , int m , int V ) {
if ( V == 0 ) return 0 ;
int res = Integer . MAX_VALUE ;
for ( int i = 0 ; i < m ; i ++ ) { if ( coins [ i ] <= V ) { int sub_res = minCoins ( coins , m , V - coins [ i ] ) ;
if ( sub_res != Integer . MAX_VALUE && sub_res + 1 < res ) res = sub_res + 1 ; } } return res ; }
public static void main ( String args [ ] ) { int coins [ ] = { 9 , 6 , 5 , 1 } ; int m = coins . length ; int V = 11 ; System . out . println ( " Minimum ▁ coins ▁ required ▁ is ▁ " + minCoins ( coins , m , V ) ) ; } }
static int minCoins ( int coins [ ] , int m , int V ) {
int table [ ] = new int [ V + 1 ] ;
table [ 0 ] = 0 ;
for ( int i = 1 ; i <= V ; i ++ ) table [ i ] = Integer . MAX_VALUE ;
for ( int i = 1 ; i <= V ; i ++ ) {
for ( int j = 0 ; j < m ; j ++ ) if ( coins [ j ] <= i ) { int sub_res = table [ i - coins [ j ] ] ; if ( sub_res != Integer . MAX_VALUE && sub_res + 1 < table [ i ] ) table [ i ] = sub_res + 1 ; } } if ( table [ V ] == Integer . MAX_VALUE ) return - 1 ; return table [ V ] ; }
public static void main ( String [ ] args ) { int coins [ ] = { 9 , 6 , 5 , 1 } ; int m = coins . length ; int V = 11 ; System . out . println ( " Minimum ▁ coins ▁ required ▁ is ▁ " + minCoins ( coins , m , V ) ) ; } }
class GFG { static int superSeq ( String X , String Y , int m , int n ) { if ( m == 0 ) return n ; if ( n == 0 ) return m ; if ( X . charAt ( m - 1 ) == Y . charAt ( n - 1 ) ) return 1 + superSeq ( X , Y , m - 1 , n - 1 ) ; return 1 + Math . min ( superSeq ( X , Y , m - 1 , n ) , superSeq ( X , Y , m , n - 1 ) ) ; }
public static void main ( String args [ ] ) { String X = " AGGTAB " ; String Y = " GXTXAYB " ; System . out . println ( " Length ▁ of ▁ the ▁ shortest " + " supersequence ▁ is : ▁ " + superSeq ( X , Y , X . length ( ) , Y . length ( ) ) ) ; } }
static int superSeq ( String X , String Y , int m , int n ) { int [ ] [ ] dp = new int [ m + 1 ] [ n + 1 ] ;
for ( int i = 0 ; i <= m ; i ++ ) { for ( int j = 0 ; j <= n ; j ++ ) {
if ( i == 0 ) dp [ i ] [ j ] = j ; else if ( j == 0 ) dp [ i ] [ j ] = i ; else if ( X . charAt ( i - 1 ) == Y . charAt ( j - 1 ) ) dp [ i ] [ j ] = 1 + dp [ i - 1 ] [ j - 1 ] ; else dp [ i ] [ j ] = 1 + Math . min ( dp [ i - 1 ] [ j ] , dp [ i ] [ j - 1 ] ) ; } } return dp [ m ] [ n ] ; }
public static void main ( String args [ ] ) { String X = " AGGTAB " ; String Y = " GXTXAYB " ; System . out . println ( " Length ▁ of ▁ the ▁ shortest ▁ supersequence ▁ is ▁ " + superSeq ( X , Y , X . length ( ) , Y . length ( ) ) ) ; } }
static int sumOfDigitsFrom1ToN ( int n ) {
int result = 0 ;
for ( int x = 1 ; x <= n ; x ++ ) result += sumOfDigits ( x ) ; return result ; }
static int sumOfDigits ( int x ) { int sum = 0 ; while ( x != 0 ) { sum += x % 10 ; x = x / 10 ; } return sum ; }
public static void main ( String args [ ] ) { int n = 328 ; System . out . println ( " Sum ▁ of ▁ digits ▁ in ▁ numbers " + " ▁ from ▁ 1 ▁ to ▁ " + n + " ▁ is ▁ " + sumOfDigitsFrom1ToN ( n ) ) ; } }
static int sumOfDigitsFrom1ToN ( int n ) {
if ( n < 10 ) return ( n * ( n + 1 ) / 2 ) ;
int d = ( int ) ( Math . log10 ( n ) ) ;
int a [ ] = new int [ d + 1 ] ; a [ 0 ] = 0 ; a [ 1 ] = 45 ; for ( int i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * ( int ) ( Math . ceil ( Math . pow ( 10 , i - 1 ) ) ) ;
int p = ( int ) ( Math . ceil ( Math . pow ( 10 , d ) ) ) ;
int msd = n / p ;
return ( msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToN ( n % p ) ) ; }
public static void main ( String args [ ] ) { int n = 328 ; System . out . println ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ " + " from ▁ 1 ▁ to ▁ " + n + " ▁ is ▁ " + sumOfDigitsFrom1ToN ( n ) ) ; } }
static int sumOfDigitsFrom1ToNUtil ( int n , int a [ ] ) { if ( n < 10 ) return ( n * ( n + 1 ) / 2 ) ; int d = ( int ) ( Math . log10 ( n ) ) ; int p = ( int ) ( Math . ceil ( Math . pow ( 10 , d ) ) ) ; int msd = n / p ; return ( msd * a [ d ] + ( msd * ( msd - 1 ) / 2 ) * p + msd * ( 1 + n % p ) + sumOfDigitsFrom1ToNUtil ( n % p , a ) ) ; } static int sumOfDigitsFrom1ToN ( int n ) { int d = ( int ) ( Math . log10 ( n ) ) ; int a [ ] = new int [ d + 1 ] ; a [ 0 ] = 0 ; a [ 1 ] = 45 ; for ( int i = 2 ; i <= d ; i ++ ) a [ i ] = a [ i - 1 ] * 10 + 45 * ( int ) ( Math . ceil ( Math . pow ( 10 , i - 1 ) ) ) ; return sumOfDigitsFrom1ToNUtil ( n , a ) ; }
public static void main ( String args [ ] ) { int n = 328 ; System . out . println ( " Sum ▁ of ▁ digits ▁ in ▁ numbers ▁ " + " from ▁ 1 ▁ to ▁ " + n + " ▁ is ▁ " + sumOfDigitsFrom1ToN ( n ) ) ; } }
static int countWays ( int N ) {
if ( N == 1 )
return 4 ;
int countB = 1 , countS = 1 , prev_countB , prev_countS ;
for ( int i = 2 ; i <= N ; i ++ ) { prev_countB = countB ; prev_countS = countS ; countS = prev_countB + prev_countS ; countB = prev_countS ; }
int result = countS + countB ;
return ( result * result ) ; }
public static void main ( String args [ ] ) { int N = 3 ; System . out . println ( " Count ▁ of ▁ ways ▁ for ▁ " + N + " ▁ sections ▁ is ▁ " + countWays ( N ) ) ; } }
static int findoptimal ( int N ) {
if ( N <= 6 ) return N ;
int screen [ ] = new int [ N ] ;
int b ;
int n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = 0 ;
for ( b = n - 3 ; b >= 1 ; b -- ) {
int curr = ( n - b - 1 ) * screen [ b - 1 ] ; if ( curr > screen [ n - 1 ] ) screen [ n - 1 ] = curr ; } } return screen [ N - 1 ] ; }
public static void main ( String [ ] args ) { int N ;
for ( N = 1 ; N <= 20 ; N ++ ) System . out . println ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with ▁ keystrokes ▁ is ▁ " + N + findoptimal ( N ) ) ; } }
static int findoptimal ( int N ) {
if ( N <= 6 ) return N ;
int [ ] screen = new int [ N ] ;
int b ;
int n ; for ( n = 1 ; n <= 6 ; n ++ ) screen [ n - 1 ] = n ;
for ( n = 7 ; n <= N ; n ++ ) {
screen [ n - 1 ] = Math . max ( 2 * screen [ n - 4 ] , Math . max ( 3 * screen [ n - 5 ] , 4 * screen [ n - 6 ] ) ) ; } return screen [ N - 1 ] ; }
public static void main ( String [ ] args ) { int N ;
for ( N = 1 ; N <= 20 ; N ++ ) System . out . printf ( " Maximum ▁ Number ▁ of ▁ A ' s ▁ with " + " %d keystrokes is %dNEW_LINE", N , findoptimal ( N ) ) ; } }
static int power ( int x , int y ) { int temp ; if ( y == 0 ) return 1 ; temp = power ( x , y / 2 ) ; if ( y % 2 == 0 ) return temp * temp ; else return x * temp * temp ; }
import java . io . * ; class GFG { public static int power ( int x , int y ) {
if ( y == 0 ) return 1 ;
if ( x == 0 ) return 0 ;
return x * power ( x , y - 1 ) ; }
public static void main ( String [ ] args ) { int x = 2 ; int y = 3 ; System . out . println ( power ( x , y ) ) ; } }
import java . io . * ; class GFG { public static int power ( int x , int y ) {
return ( int ) Math . pow ( x , y ) ; }
public static void main ( String [ ] args ) { int x = 2 ; int y = 3 ; System . out . println ( power ( x , y ) ) ; } }
static double area ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 ) { return Math . abs ( ( x1 * ( y2 - y3 ) + x2 * ( y3 - y1 ) + x3 * ( y1 - y2 ) ) / 2.0 ) ; }
static boolean isInside ( int x1 , int y1 , int x2 , int y2 , int x3 , int y3 , int x , int y ) {
double A = area ( x1 , y1 , x2 , y2 , x3 , y3 ) ;
double A1 = area ( x , y , x2 , y2 , x3 , y3 ) ;
double A2 = area ( x1 , y1 , x , y , x3 , y3 ) ;
double A3 = area ( x1 , y1 , x2 , y2 , x , y ) ;
return ( A == A1 + A2 + A3 ) ; }
if ( isInside ( 0 , 0 , 20 , 0 , 10 , 30 , 10 , 15 ) ) System . out . println ( " Inside " ) ; else System . out . println ( " Not ▁ Inside " ) ; } }
import java . util . * ; public class PrintPost { static int preIndex = 0 ; void printPost ( int [ ] in , int [ ] pre , int inStrt , int inEnd , HashMap < Integer , Integer > hm ) { if ( inStrt > inEnd ) return ;
int inIndex = hm . get ( pre [ preIndex ++ ] ) ;
printPost ( in , pre , inStrt , inIndex - 1 , hm ) ;
printPost ( in , pre , inIndex + 1 , inEnd , hm ) ;
System . out . print ( in [ inIndex ] + " ▁ " ) ; } void printPostMain ( int [ ] in , int [ ] pre ) { int n = pre . length ; HashMap < Integer , Integer > hm = new HashMap < Integer , Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) hm . put ( in [ i ] , i ) ; printPost ( in , pre , 0 , n - 1 , hm ) ; }
public static void main ( String ars [ ] ) { int in [ ] = { 4 , 2 , 5 , 1 , 3 , 6 } ; int pre [ ] = { 1 , 2 , 4 , 5 , 3 , 6 } ; PrintPost tree = new PrintPost ( ) ; tree . printPostMain ( in , pre ) ; } }
class Node { int key ; Node left , right ; public Node ( int key ) { this . key = key ; left = right = null ; } }
class Res { int r = Integer . MIN_VALUE ; } public class BinaryTree { Node root ;
int maxDiffUtil ( Node t , Res res ) {
if ( t == null ) return Integer . MAX_VALUE ;
if ( t . left == null && t . right == null ) return t . key ;
int val = Math . min ( maxDiffUtil ( t . left , res ) , maxDiffUtil ( t . right , res ) ) ;
res . r = Math . max ( res . r , t . key - val ) ;
return Math . min ( val , t . key ) ; }
int maxDiff ( Node root ) {
Res res = new Res ( ) ; maxDiffUtil ( root , res ) ; return res . r ; }
void inorder ( Node root ) { if ( root != null ) { inorder ( root . left ) ; System . out . print ( root . key + " " ) ; inorder ( root . right ) ; } }
tree . root = new Node ( 8 ) ; tree . root . left = new Node ( 3 ) ; tree . root . left . left = new Node ( 1 ) ; tree . root . left . right = new Node ( 6 ) ; tree . root . left . right . left = new Node ( 4 ) ; tree . root . left . right . right = new Node ( 7 ) ; tree . root . right = new Node ( 10 ) ; tree . root . right . right = new Node ( 14 ) ; tree . root . right . right . left = new Node ( 13 ) ; System . out . println ( " Maximum ▁ difference ▁ between ▁ a ▁ node ▁ and " + " ▁ its ▁ ancestor ▁ is ▁ : ▁ " + tree . maxDiff ( tree . root ) ) ; } }
static float getAvg ( float prev_avg , float x , int n ) { return ( prev_avg * n + x ) / ( n + 1 ) ; }
static void streamAvg ( float arr [ ] , int n ) { float avg = 0 ; for ( int i = 0 ; i < n ; i ++ ) { avg = getAvg ( avg , arr [ i ] , i ) ; System . out . printf ( "Average of %d numbers is %f NEW_LINE", i + 1, avg); } return ; }
public static void main ( String [ ] args ) { float arr [ ] = { 10 , 20 , 30 , 40 , 50 , 60 } ; int n = arr . length ; streamAvg ( arr , n ) ; } }
class SieveOfEratosthenes { void sieveOfEratosthenes ( int n ) {
boolean prime [ ] = new boolean [ n + 1 ] ; for ( int i = 0 ; i <= n ; i ++ ) prime [ i ] = true ; for ( int p = 2 ; p * p <= n ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * p ; i <= n ; i += p ) prime [ i ] = false ; } }
for ( int i = 2 ; i <= n ; i ++ ) { if ( prime [ i ] == true ) System . out . print ( i + " ▁ " ) ; } }
public static void main ( String args [ ] ) { int n = 30 ; System . out . print ( " Following ▁ are ▁ the ▁ prime ▁ numbers ▁ " ) ; System . out . println ( " smaller ▁ than ▁ or ▁ equal ▁ to ▁ " + n ) ; SieveOfEratosthenes g = new SieveOfEratosthenes ( ) ; g . sieveOfEratosthenes ( n ) ; } }
static int maximumNumberDistinctPrimeRange ( int m , int n ) {
long factorCount [ ] = new long [ n + 1 ] ;
boolean prime [ ] = new boolean [ n + 1 ] ;
for ( int i = 0 ; i <= n ; i ++ ) { factorCount [ i ] = 0 ;
prime [ i ] = true ; } for ( int i = 2 ; i <= n ; i ++ ) {
if ( prime [ i ] == true ) {
factorCount [ i ] = 1 ;
for ( int j = i * 2 ; j <= n ; j += i ) {
factorCount [ j ] ++ ;
prime [ j ] = false ; } } }
int max = ( int ) factorCount [ m ] ; int num = m ;
for ( int i = m ; i <= n ; i ++ ) {
if ( factorCount [ i ] > max ) { max = ( int ) factorCount [ i ] ; num = i ; } } return num ; }
public static void main ( String [ ] args ) { int m = 4 , n = 6 ;
System . out . println ( maximumNumberDistinctPrimeRange ( m , n ) ) ; } }
static int binomialCoeff ( int n , int k ) { int res = 1 ; if ( k > n - k ) k = n - k ; for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
static void printPascal ( int n ) {
for ( int line = 0 ; line < n ; line ++ ) {
for ( int i = 0 ; i <= line ; i ++ ) System . out . print ( binomialCoeff ( line , i ) + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String args [ ] ) { int n = 7 ; printPascal ( n ) ; } }
static int findCeil ( int arr [ ] , int r , int l , int h ) { int mid ; while ( l < h ) {
mid = l + ( ( h - l ) >> 1 ) ; if ( r > arr [ mid ] ) l = mid + 1 ; else h = mid ; } return ( arr [ l ] >= r ) ? l : - 1 ; }
static int myRand ( int arr [ ] , int freq [ ] , int n ) {
int prefix [ ] = new int [ n ] , i ; prefix [ 0 ] = freq [ 0 ] ; for ( i = 1 ; i < n ; ++ i ) prefix [ i ] = prefix [ i - 1 ] + freq [ i ] ;
int r = ( ( int ) ( Math . random ( ) * ( 323567 ) ) % prefix [ n - 1 ] ) + 1 ;
int indexc = findCeil ( prefix , r , 0 , n - 1 ) ; return arr [ indexc ] ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int freq [ ] = { 10 , 5 , 20 , 100 } ; int i , n = arr . length ;
for ( i = 0 ; i < 5 ; i ++ ) System . out . println ( myRand ( arr , freq , n ) ) ; } }
static boolean isPerfectSquare ( int x ) { int s = ( int ) Math . sqrt ( x ) ; return ( s * s == x ) ; }
static boolean isFibonacci ( int n ) {
return isPerfectSquare ( 5 * n * n + 4 ) || isPerfectSquare ( 5 * n * n - 4 ) ; }
public static void main ( String [ ] args ) { for ( int i = 1 ; i <= 10 ; i ++ ) System . out . println ( isFibonacci ( i ) ? i + " ▁ is ▁ a ▁ Fibonacci ▁ Number " : i + " ▁ is ▁ a ▁ not ▁ Fibonacci ▁ Number " ) ; } }
static int findTrailingZeros ( int n ) {
int count = 0 ;
for ( int i = 5 ; n / i >= 1 ; i *= 5 ) count += n / i ; return count ; }
public static void main ( String [ ] args ) { int n = 100 ; System . out . println ( " Count ▁ of ▁ trailing ▁ 0s ▁ in ▁ " + n + " ! ▁ is ▁ " + findTrailingZeros ( n ) ) ; } }
int catalan ( int n ) {
if ( n <= 1 ) { return 1 ; }
int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) { res += catalan ( i ) * catalan ( n - i - 1 ) ; } return res ; }
public static void main ( String [ ] args ) { CatalnNumber cn = new CatalnNumber ( ) ; for ( int i = 0 ; i < 10 ; i ++ ) { System . out . print ( cn . catalan ( i ) + " ▁ " ) ; } } }
class GFG { static int catalanDP ( int n ) {
int catalan [ ] = new int [ n + 2 ] ;
catalan [ 0 ] = 1 ; catalan [ 1 ] = 1 ;
for ( int i = 2 ; i <= n ; i ++ ) { catalan [ i ] = 0 ; for ( int j = 0 ; j < i ; j ++ ) { catalan [ i ] += catalan [ j ] * catalan [ i - j - 1 ] ; } }
return catalan [ n ] ; }
public static void main ( String [ ] args ) { for ( int i = 0 ; i < 10 ; i ++ ) { System . out . print ( catalanDP ( i ) + " ▁ " ) ; } } }
static long binomialCoeff ( int n , int k ) { long res = 1 ;
if ( k > n - k ) { k = n - k ; }
for ( int i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
static long catalan ( int n ) {
long c = binomialCoeff ( 2 * n , n ) ;
return c / ( n + 1 ) ; }
public static void main ( String [ ] args ) { for ( int i = 0 ; i < 10 ; i ++ ) { System . out . print ( catalan ( i ) + " ▁ " ) ; } } }
static void catalan ( int n ) { int cat_ = 1 ;
System . out . print ( cat_ + " ▁ " ) ;
for ( int i = 1 ; i < n ; i ++ ) {
cat_ *= ( 4 * i - 2 ) ; cat_ /= ( i + 1 ) ; System . out . print ( cat_ + " ▁ " ) ; } }
public static void main ( String args [ ] ) { int n = 5 ;
catalan ( n ) ; } }
import java . util . * ; class GFG { static void printString ( int n ) { int [ ] arr = new int [ 10000 ] ; int i = 0 ;
while ( n > 0 ) { arr [ i ] = n % 26 ; n = n / 26 ; i ++ ; }
for ( int j = 0 ; j < i - 1 ; j ++ ) { if ( arr [ j ] <= 0 ) { arr [ j ] += 26 ; arr [ j + 1 ] = arr [ j + 1 ] - 1 ; } } for ( int j = i ; j >= 0 ; j -- ) { if ( arr [ j ] > 0 ) System . out . print ( ( char ) ( ' A ' + arr [ j ] - 1 ) ) ; } System . out . println ( ) ; }
public static void main ( String [ ] args ) { printString ( 26 ) ; printString ( 51 ) ; printString ( 52 ) ; printString ( 80 ) ; printString ( 676 ) ; printString ( 702 ) ; printString ( 705 ) ; } }
static int getInvCount ( int [ ] [ ] arr ) { int inv_count = 0 ; for ( int i = 0 ; i < 3 - 1 ; i ++ ) for ( int j = i + 1 ; j < 3 ; j ++ )
if ( arr [ j ] [ i ] > 0 && arr [ j ] [ i ] > arr [ i ] [ j ] ) inv_count ++ ; return inv_count ; }
static boolean isSolvable ( int [ ] [ ] puzzle ) {
int invCount = getInvCount ( puzzle ) ;
return ( invCount % 2 == 0 ) ; }
public static void main ( String [ ] args ) { int [ ] [ ] puzzle = { { 1 , 8 , 2 } , { 0 , 4 , 3 } , { 7 , 6 , 5 } } ; if ( isSolvable ( puzzle ) ) System . out . println ( " Solvable " ) ; else System . out . println ( " Not ▁ Solvable " ) ; } }
static double find ( double p ) { return Math . ceil ( Math . sqrt ( 2 * 365 * Math . log ( 1 / ( 1 - p ) ) ) ) ; }
public static void main ( String [ ] args ) { System . out . println ( find ( 0.70 ) ) ; } }
static int countSolutions ( int n ) { int res = 0 ; for ( int x = 0 ; x * x < n ; x ++ ) for ( int y = 0 ; x * x + y * y < n ; y ++ ) res ++ ; return res ; }
public static void main ( String args [ ] ) { System . out . println ( " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " + countSolutions ( 6 ) ) ; } }
static int countSolutions ( int n ) { int x = 0 , yCount , res = 0 ;
for ( yCount = 0 ; yCount * yCount < n ; yCount ++ ) ;
while ( yCount != 0 ) {
res += yCount ;
x ++ ;
while ( yCount != 0 && ( x * x + ( yCount - 1 ) * ( yCount - 1 ) >= n ) ) yCount -- ; } return res ; }
public static void main ( String args [ ] ) { System . out . println ( " Total ▁ Number ▁ of ▁ distinct ▁ Non - Negative ▁ pairs ▁ is ▁ " + countSolutions ( 6 ) ) ; } }
import java . io . * ; class GFG { static int MAX_ITER = 1000000 ;
static double func ( double x ) { return ( x * x * x - x * x + 2 ) ; }
static void regulaFalsi ( double a , double b ) { if ( func ( a ) * func ( b ) >= 0 ) { System . out . println ( " You ▁ have ▁ not ▁ assumed ▁ right ▁ a ▁ and ▁ b " ) ; }
double c = a ; for ( int i = 0 ; i < MAX_ITER ; i ++ ) {
c = ( a * func ( b ) - b * func ( a ) ) / ( func ( b ) - func ( a ) ) ;
if ( func ( c ) == 0 ) break ;
else if ( func ( c ) * func ( a ) < 0 ) b = c ; else a = c ; } System . out . println ( " The ▁ value ▁ of ▁ root ▁ is ▁ : ▁ " + ( int ) c ) ; }
double a = - 200 , b = 300 ; regulaFalsi ( a , b ) ; } }
class GFG { static final double EPSILON = 0.001 ;
static double func ( double x ) { return x * x * x - x * x + 2 ; }
static double derivFunc ( double x ) { return 3 * x * x - 2 * x ; }
static void newtonRaphson ( double x ) { double h = func ( x ) / derivFunc ( x ) ; while ( Math . abs ( h ) >= EPSILON ) { h = func ( x ) / derivFunc ( x ) ;
x = x - h ; } System . out . print ( " The ▁ value ▁ of ▁ the " + " ▁ root ▁ is ▁ : ▁ " + Math . round ( x * 100.0 ) / 100.0 ) ; }
double x0 = - 20 ; newtonRaphson ( x0 ) ; } }
static boolean oppositeSigns ( int x , int y ) { return ( ( x ^ y ) < 0 ) ; }
public static void main ( String [ ] args ) { int x = 100 , y = - 100 ; if ( oppositeSigns ( x , y ) == true ) System . out . println ( " Signs ▁ are ▁ opposite " ) ; else System . out . println ( " Signs ▁ are ▁ not ▁ opposite " ) ; } }
static int countSetBits ( int n ) {
int bitCount = 0 ; for ( int i = 1 ; i <= n ; i ++ ) bitCount += countSetBitsUtil ( i ) ; return bitCount ; }
static int countSetBitsUtil ( int x ) { if ( x <= 0 ) return 0 ; return ( x % 2 == 0 ? 0 : 1 ) + countSetBitsUtil ( x / 2 ) ; }
public static void main ( String [ ] args ) { int n = 4 ; System . out . print ( " Total ▁ set ▁ bit ▁ count ▁ is ▁ " ) ; System . out . print ( countSetBits ( n ) ) ; } }
public class GFG { static int countSetBits ( int n ) { int i = 0 ;
int ans = 0 ;
while ( ( 1 << i ) <= n ) {
boolean k = false ;
int change = 1 << i ;
for ( int j = 0 ; j <= n ; j ++ ) { if ( k == true ) ans += 1 ; else ans += 0 ; if ( change == 1 ) {
k = ! k ;
change = 1 << i ; } else { change -- ; } }
i ++ ; } return ans ; }
public static void main ( String [ ] args ) { int n = 17 ; System . out . println ( countSetBits ( n ) ) ; } }
static int getSetBitsFromOneToN ( int N ) { int two = 2 , ans = 0 ; int n = N ; while ( n != 0 ) { ans += ( N / two ) * ( two >> 1 ) ; if ( ( N & ( two - 1 ) ) > ( two >> 1 ) - 1 ) ans += ( N & ( two - 1 ) ) - ( two >> 1 ) + 1 ; two <<= 1 ; n >>= 1 ; } return ans ; }
class GFG { static int swapBits ( int num , int p1 , int p2 , int n ) { int shift1 , shift2 , value1 , value2 ; while ( n -- > 0 ) {
shift1 = 1 << p1 ;
shift2 = 1 << p2 ;
value1 = ( ( num & shift1 ) ) ; value2 = ( ( num & shift2 ) ) ;
if ( ( value1 == 0 && value2 != 0 ) || ( value2 == 0 && value1 != 0 ) ) {
if ( value1 != 0 ) {
num = num & ( ~ shift1 ) ;
num = num | shift2 ; }
else {
num = num & ( ~ shift2 ) ;
num = num | shift1 ; } } p1 ++ ; p2 ++ ; }
return num ; }
public static void main ( String [ ] args ) { int res = swapBits ( 28 , 0 , 3 , 2 ) ; System . out . println ( " Result ▁ = ▁ " + res ) ; } }
static int Add ( int x , int y ) { if ( y == 0 ) return x ; else return Add ( x ^ y , ( x & y ) << 1 ) ; }
class GFG { static int CHAR_BIT = 8 ;
static int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( ( Integer . SIZE / 8 ) * CHAR_BIT - 1 ) ) ) ; }
static int smallest ( int x , int y , int z ) { return Math . min ( x , Math . min ( y , z ) ) ; }
public static void main ( String [ ] args ) { int x = 12 , y = 15 , z = 5 ; System . out . println ( " Minimum ▁ of ▁ 3 ▁ numbers ▁ is ▁ " + smallest ( x , y , z ) ) ; } }
static int smallest ( int x , int y , int z ) {
if ( ( y / x ) != 1 ) return ( ( y / z ) != 1 ) ? y : z ; return ( ( x / z ) != 1 ) ? x : z ; }
public static void main ( String [ ] args ) { int x = 78 , y = 88 , z = 68 ; System . out . printf ( " Minimum ▁ of ▁ 3 ▁ numbers " + " ▁ is ▁ % d " , smallest ( x , y , z ) ) ; } }
import java . io . * ; class GFG { public static void changeToZero ( int a [ ] ) { a [ a [ 1 ] ] = a [ 1 - a [ 1 ] ] ; }
public static void main ( String args [ ] ) { int [ ] arr ; arr = new int [ 2 ] ; arr [ 0 ] = 1 ; arr [ 1 ] = 0 ; changeToZero ( arr ) ; System . out . println ( " arr [ 0 ] = ▁ " + arr [ 0 ] ) ; System . out . println ( " arr [ 1 ] = ▁ " + arr [ 1 ] ) ; } }
static int snoob ( int x ) { int rightOne , nextHigherOneBit , rightOnesPattern , next = 0 ; if ( x > 0 ) {
rightOne = x & - x ;
nextHigherOneBit = x + rightOne ;
rightOnesPattern = x ^ nextHigherOneBit ;
rightOnesPattern = ( rightOnesPattern ) / rightOne ;
rightOnesPattern >>= 2 ;
next = nextHigherOneBit | rightOnesPattern ; } return next ; }
public static void main ( String [ ] args ) { int x = 156 ; System . out . println ( " Next ▁ higher ▁ number ▁ with ▁ same " + " number ▁ of ▁ set ▁ bits ▁ is ▁ " + snoob ( x ) ) ; } }
class GFG { static int multiplyWith3Point5 ( int x ) { return ( x << 1 ) + x + ( x >> 1 ) ; }
public static void main ( String [ ] args ) { int x = 2 ; System . out . println ( multiplyWith3Point5 ( x ) ) ; } }
static int multiplyWith3Point5 ( int x ) { int r = 0 ;
int x1Shift = x << 1 ; int x2Shifts = x << 2 ; r = ( x ^ x1Shift ) ^ x2Shifts ; int c = ( x & x1Shift ) | ( x & x2Shifts ) | ( x1Shift & x2Shifts ) ; while ( c > 0 ) { c <<= 1 ; int t = r ; r ^= c ; c &= t ; }
r = r >> 1 ; return r ; }
public static void main ( String [ ] args ) { System . out . println ( multiplyWith3Point5 ( 5 ) ) ; } }
import java . io . * ; class GFG { static boolean isPowerOfFour ( int n ) { return n != 0 && ( ( n & ( n - 1 ) ) == 0 ) && ( n & 0xAAAAAAAA ) == 0 ; }
public static void main ( String [ ] args ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) ) System . out . println ( test_no + " ▁ is ▁ a ▁ power ▁ of ▁ 4" ) ; else System . out . println ( test_no + " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ) ; } }
import java . util . * ; class GFG { static double logn ( int n , int r ) { return Math . log ( n ) / Math . log ( r ) ; } static boolean isPowerOfFour ( int n ) {
if ( n == 0 ) return false ; return Math . floor ( logn ( n , 4 ) ) == Math . ceil ( logn ( n , 4 ) ) ; }
public static void main ( String [ ] args ) { int test_no = 64 ; if ( isPowerOfFour ( test_no ) ) System . out . print ( test_no + " ▁ is ▁ a ▁ power ▁ of ▁ 4" ) ; else System . out . print ( test_no + " ▁ is ▁ not ▁ a ▁ power ▁ of ▁ 4" ) ; } }
import java . util . * ; class Solution { static class INT { int data ; INT ( int d ) { data = d ; } }
static void findPostOrderUtil ( int pre [ ] , int n , int minval , int maxval , INT preIndex ) {
if ( preIndex . data == n ) return ;
if ( pre [ preIndex . data ] < minval pre [ preIndex . data ] > maxval ) { return ; }
int val = pre [ preIndex . data ] ; preIndex . data ++ ;
findPostOrderUtil ( pre , n , minval , val , preIndex ) ;
findPostOrderUtil ( pre , n , val , maxval , preIndex ) ; System . out . print ( val + " ▁ " ) ; }
static void findPostOrder ( int pre [ ] , int n ) {
INT preIndex = new INT ( 0 ) ; findPostOrderUtil ( pre , n , Integer . MIN_VALUE , Integer . MAX_VALUE , preIndex ) ; }
public static void main ( String args [ ] ) { int pre [ ] = { 40 , 30 , 35 , 80 , 100 } ; int n = pre . length ;
findPostOrder ( pre , n ) ; } }
static int getModulo ( int n , int d ) { return ( n & ( d - 1 ) ) ; }
public static void main ( String [ ] args ) { int n = 6 ;
int d = 4 ; System . out . println ( n + " ▁ moduo ▁ " + d + " ▁ is ▁ " + getModulo ( n , d ) ) ; } }
class GFG { static int CHAR_BIT = 4 ; static int INT_BIT = 8 ;
static int min ( int x , int y ) { return y + ( ( x - y ) & ( ( x - y ) >> ( INT_BIT * CHAR_BIT - 1 ) ) ) ; }
static int max ( int x , int y ) { return x - ( ( x - y ) & ( ( x - y ) >> ( INT_BIT * CHAR_BIT - 1 ) ) ) ; }
public static void main ( String [ ] args ) { int x = 15 ; int y = 6 ; System . out . println ( " Minimum ▁ of ▁ " + x + " ▁ and ▁ " + y + " ▁ is ▁ " + min ( x , y ) ) ; System . out . println ( " Maximum ▁ of ▁ " + x + " ▁ and ▁ " + y + " ▁ is ▁ " + max ( x , y ) ) ; } }
public static int absbit32 ( int x , int y ) { int sub = x - y ; int mask = ( sub >> 31 ) ; return ( sub ^ mask ) - mask ; }
public static int max ( int x , int y ) { int abs = absbit32 ( x , y ) ; return ( x + y + abs ) / 2 ; }
public static int min ( int x , int y ) { int abs = absbit32 ( x , y ) ; return ( x + y - abs ) / 2 ; }
public static void main ( String [ ] args ) { System . out . println ( max ( 2 , 3 ) ) ; System . out . println ( max ( 2 , - 3 ) ) ; System . out . println ( max ( - 2 , - 3 ) ) ; System . out . println ( min ( 2 , 3 ) ) ; System . out . println ( min ( 2 , - 3 ) ) ; System . out . println ( min ( - 2 , - 3 ) ) ; } }
public static void UniqueNumbers2 ( int [ ] arr , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
sum = ( sum ^ arr [ i ] ) ; }
sum = ( sum & - sum ) ;
int sum1 = 0 ; int sum2 = 0 ;
for ( int i = 0 ; i < arr . length ; i ++ ) {
if ( ( arr [ i ] & sum ) > 0 ) {
sum1 = ( sum1 ^ arr [ i ] ) ; } else {
sum2 = ( sum2 ^ arr [ i ] ) ; } }
System . out . println ( " The ▁ non - repeating ▁ elements ▁ are ▁ " + sum1 + " ▁ and ▁ " + sum2 ) ; }
public static void main ( String [ ] args ) { int [ ] arr = new int [ ] { 2 , 3 , 7 , 9 , 11 , 2 , 3 , 11 } ; int n = arr . length ; UniqueNumbers2 ( arr , n ) ; } }
static int getOddOccurrence ( int arr [ ] , int arr_size ) { int i ; for ( i = 0 ; i < arr_size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < arr_size ; j ++ ) { if ( arr [ i ] == arr [ j ] ) count ++ ; } if ( count % 2 != 0 ) return arr [ i ] ; } return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 } ; int n = arr . length ;
System . out . println ( getOddOccurrence ( arr , n ) ) ; } }
static int getOddOccurrence ( int arr [ ] , int n ) { HashMap < Integer , Integer > hmap = new HashMap < > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( hmap . containsKey ( arr [ i ] ) ) { int val = hmap . get ( arr [ i ] ) ;
hmap . put ( arr [ i ] , val + 1 ) ; } else
hmap . put ( arr [ i ] , 1 ) ; }
for ( Integer a : hmap . keySet ( ) ) { if ( hmap . get ( a ) % 2 != 0 ) return a ; } return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 2 , 3 , 5 , 4 , 5 , 2 , 4 , 3 , 5 , 2 , 4 , 4 , 2 } ; int n = arr . length ; System . out . println ( getOddOccurrence ( arr , n ) ) ; } }
static int fastPow ( int N , int K ) { if ( K == 0 ) return 1 ; int temp = fastPow ( N , K / 2 ) ; if ( K % 2 == 0 ) return temp * temp ; else return N * temp * temp ; } static int countWays ( int N , int K ) { return K * fastPow ( K - 1 , N - 1 ) ; }
public static void main ( String [ ] args ) { int N = 3 , K = 3 ; System . out . println ( countWays ( N , K ) ) ; } }
public static int countSetBits ( int n ) {
if ( n == 0 ) return 0 ; else return 1 + countSetBits ( n & ( n - 1 ) ) ; }
int n = 9 ;
System . out . println ( countSetBits ( n ) ) ; } }
static int [ ] BitsSetTable256 = new int [ 256 ] ;
public static void initialize ( ) {
BitsSetTable256 [ 0 ] = 0 ; for ( int i = 0 ; i < 256 ; i ++ ) { BitsSetTable256 [ i ] = ( i & 1 ) + BitsSetTable256 [ i / 2 ] ; } }
public static int countSetBits ( int n ) { return ( BitsSetTable256 [ n & 0xff ] + BitsSetTable256 [ ( n >> 8 ) & 0xff ] + BitsSetTable256 [ ( n >> 16 ) & 0xff ] + BitsSetTable256 [ n >> 24 ] ) ; }
initialize ( ) ; int n = 9 ; System . out . print ( countSetBits ( n ) ) ; } }
public static void main ( String [ ] args ) { System . out . println ( Integer . bitCount ( 4 ) ) ; System . out . println ( Integer . bitCount ( 15 ) ) ; } }
static int countSetBits ( int N ) { int count = 0 ;
for ( int i = 0 ; i < 4 * 8 ; i ++ ) { if ( ( N & ( 1 << i ) ) != 0 ) count ++ ; } return count ; }
public static void main ( String [ ] args ) { int N = 15 ; System . out . println ( countSetBits ( N ) ) ; } }
public static int countSetBits ( int n ) { int count = 0 ; while ( n != 0 ) { count ++ ; n &= ( n - 1 ) ; } return count ; }
public static int FlippedCount ( int a , int b ) {
return countSetBits ( a ^ b ) ; }
public static void main ( String [ ] args ) { int a = 10 ; int b = 20 ; System . out . print ( FlippedCount ( a , b ) ) ; } }
static boolean powerOf2 ( int n ) {
if ( n == 1 ) return true ;
else if ( n % 2 != 0 n == 0 ) return false ;
return powerOf2 ( n / 2 ) ; }
int n = 64 ;
int m = 12 ; if ( powerOf2 ( n ) == true ) System . out . print ( " True " + "NEW_LINE"); else System . out . print ( " False " + "NEW_LINE"); if ( powerOf2 ( m ) == true ) System . out . print ( " True " + "NEW_LINE"); else System . out . print ( " False " + "NEW_LINE"); } }
static int PositionRightmostSetbit ( int n ) {
int position = 1 ; int m = 1 ; while ( ( n & m ) == 0 ) {
m = m << 1 ; position ++ ; } return position ; }
public static void main ( String [ ] args ) { int n = 16 ;
System . out . println ( PositionRightmostSetbit ( n ) ) ; } }
public class GFG { static int INT_SIZE = 32 ; static int Right_most_setbit ( int num ) { int pos = 1 ;
for ( int i = 0 ; i < INT_SIZE ; i ++ ) { if ( ( num & ( 1 << i ) ) == 0 ) pos ++ ; else break ; } return pos ; }
public static void main ( String [ ] args ) { int num = 18 ; int pos = Right_most_setbit ( num ) ; System . out . println ( pos ) ; } }
public static int Last_set_bit ( int n ) { int p = 1 ;
while ( n > 0 ) {
if ( ( n & 1 ) > 0 ) { return p ; }
p ++ ; n = n >> 1 ; }
return - 1 ; }
public static void main ( String [ ] args ) { int n = 18 ;
int pos = Last_set_bit ( n ) ; if ( pos != - 1 ) System . out . println ( pos ) ; else System . out . println ( "0" ) ; } }
static void bin ( long n ) { long i ; System . out . print ( "0" ) ; for ( i = 1 << 30 ; i > 0 ; i = i / 2 ) { if ( ( n & i ) != 0 ) { System . out . print ( "1" ) ; } else { System . out . print ( "0" ) ; } } }
public static void main ( String [ ] args ) { bin ( 7 ) ; System . out . println ( ) ; bin ( 4 ) ; } }
static void bin ( Integer n ) { if ( n > 1 ) bin ( n >> 1 ) ; System . out . printf ( " % d " , n & 1 ) ; }
public static void main ( String [ ] args ) { bin ( 131 ) ; System . out . printf ( "NEW_LINE"); bin ( 3 ) ; } }
public static void swap ( int a , int b ) {
a = ( a & b ) + ( a b ) ;
b = a + ( ~ b ) + 1 ;
a = a + ( ~ b ) + 1 ; System . out . print ( " After ▁ swapping : ▁ a ▁ = ▁ " + a + " , ▁ b ▁ = ▁ " + b ) ; }
public static void main ( String [ ] args ) { int a = 5 , b = 10 ;
swap ( a , b ) ; } }
static boolean checkSentence ( char [ ] str ) {
int len = str . length ;
if ( str [ 0 ] < ' A ' str [ 0 ] > ' Z ' ) return false ;
if ( str [ len - 1 ] != ' . ' ) return false ;
int prev_state = 0 , curr_state = 0 ;
int index = 1 ;
while ( index <= str . length ) {
if ( str [ index ] >= ' A ' && str [ index ] <= ' Z ' ) curr_state = 0 ;
else if ( str [ index ] == ' ▁ ' ) curr_state = 1 ;
else if ( str [ index ] >= ' a ' && str [ index ] <= ' z ' ) curr_state = 2 ;
else if ( str [ index ] == ' . ' ) curr_state = 3 ;
if ( prev_state == curr_state && curr_state != 2 ) return false ; if ( prev_state == 2 && curr_state == 0 ) return false ;
if ( curr_state == 3 && prev_state != 1 ) return ( index + 1 == str . length ) ; index ++ ;
prev_state = curr_state ; } return false ; }
public static void main ( String [ ] args ) { String [ ] str = { " I ▁ love ▁ cinema . " , " The ▁ vertex ▁ is ▁ S . " , " I ▁ am ▁ single . " , " My ▁ name ▁ is ▁ KG . " , " I ▁ lovE ▁ cinema . " , " GeeksQuiz . ▁ is ▁ a ▁ quiz ▁ site . " , " I ▁ love ▁ Geeksquiz ▁ and ▁ Geeksforgeeks . " , " ▁ You ▁ are ▁ my ▁ friend . " , " I ▁ love ▁ cinema " } ; int str_size = str . length ; int i = 0 ; for ( i = 0 ; i < str_size ; i ++ ) { if ( checkSentence ( str [ i ] . toCharArray ( ) ) ) System . out . println ( " \" " + str [ i ] + " \" " + " ▁ is ▁ correct " ) ; else System . out . println ( " \" " + str [ i ] + " \" " + " ▁ is ▁ incorrect " ) ; } } }
static int maxOnesIndex ( int arr [ ] , int n ) {
int max_count = 0 ;
int max_index = 0 ;
int prev_zero = - 1 ;
int prev_prev_zero = - 1 ;
for ( int curr = 0 ; curr < n ; ++ curr ) {
if ( arr [ curr ] == 0 ) {
if ( curr - prev_prev_zero > max_count ) { max_count = curr - prev_prev_zero ; max_index = prev_zero ; }
prev_prev_zero = prev_zero ; prev_zero = curr ; } }
if ( n - prev_prev_zero > max_count ) max_index = prev_zero ; return max_index ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } ; int n = arr . length ; System . out . println ( " Index ▁ of ▁ 0 ▁ to ▁ be ▁ replaced ▁ is ▁ " + maxOnesIndex ( arr , n ) ) ; } }
int min ( int x , int y ) { return ( x < y ) ? x : y ; } int max ( int x , int y ) { return ( x > y ) ? x : y ; }
int findLength ( int arr [ ] , int n ) {
int max_len = 1 ; for ( int i = 0 ; i < n - 1 ; i ++ ) {
int mn = arr [ i ] , mx = arr [ i ] ;
for ( int j = i + 1 ; j < n ; j ++ ) {
mn = min ( mn , arr [ j ] ) ; mx = max ( mx , arr [ j ] ) ;
if ( ( mx - mn ) == j - i ) max_len = max ( max_len , mx - mn + 1 ) ; } }
return max_len ; }
public static void main ( String [ ] args ) { LargestSubArray2 large = new LargestSubArray2 ( ) ; int arr [ ] = { 1 , 56 , 58 , 57 , 90 , 92 , 94 , 93 , 91 , 45 } ; int n = arr . length ; System . out . println ( " Length ▁ of ▁ the ▁ longest ▁ contiguous ▁ subarray ▁ is ▁ " + large . findLength ( arr , n ) ) ; } }
static void printArr ( int [ ] arr , int k ) { for ( int i = 0 ; i < k ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); }
static void printSeqUtil ( int n , int k , int len , int [ ] arr ) {
if ( len == k ) { printArr ( arr , k ) ; return ; }
int i = ( len == 0 ) ? 1 : arr [ len - 1 ] + 1 ;
len ++ ;
while ( i <= n ) { arr [ len - 1 ] = i ; printSeqUtil ( n , k , len , arr ) ; i ++ ; }
len -- ; }
static void printSeq ( int n , int k ) {
int [ ] arr = new int [ k ] ;
int len = 0 ; printSeqUtil ( n , k , len , arr ) ; }
static public void main ( String [ ] args ) { int k = 3 , n = 7 ; printSeq ( n , k ) ; } }
static boolean isSubSequence ( String str1 , String str2 , int m , int n ) {
if ( m == 0 ) return true ; if ( n == 0 ) return false ;
if ( str1 . charAt ( m - 1 ) == str2 . charAt ( n - 1 ) ) return isSubSequence ( str1 , str2 , m - 1 , n - 1 ) ;
return isSubSequence ( str1 , str2 , m , n - 1 ) ; }
public static void main ( String [ ] args ) { String str1 = " gksrek " ; String str2 = " geeksforgeeks " ; int m = str1 . length ( ) ; int n = str2 . length ( ) ; boolean res = isSubSequence ( str1 , str2 , m , n ) ; if ( res ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static void segregate0and1 ( int arr [ ] , int n ) {
int count = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 0 ) count ++ ; }
for ( int i = 0 ; i < count ; i ++ ) arr [ i ] = 0 ;
for ( int i = count ; i < n ; i ++ ) arr [ i ] = 1 ; }
static void print ( int arr [ ] , int n ) { System . out . print ( " Array ▁ after ▁ segregation ▁ is ▁ " ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = new int [ ] { 0 , 1 , 0 , 1 , 1 , 1 } ; int n = arr . length ; segregate0and1 ( arr , n ) ; print ( arr , n ) ; } }
static void segregate0and1 ( int arr [ ] ) { int type0 = 0 ; int type1 = arr . length - 1 ; while ( type0 < type1 ) { if ( arr [ type0 ] == 1 ) { arr [ type1 ] = arr [ type1 ] + arr [ type0 ] ; arr [ type0 ] = arr [ type1 ] - arr [ type0 ] ; arr [ type1 ] = arr [ type1 ] - arr [ type0 ] ; type1 -- ; } else { type0 ++ ; } } }
public static void main ( String [ ] args ) { int [ ] array = { 0 , 1 , 0 , 1 , 1 , 1 } ; segregate0and1 ( array ) ; for ( int a : array ) { System . out . print ( a + " ▁ " ) ; } } }
public static void find3Numbers ( int [ ] nums ) {
if ( nums . length < 3 ) { System . out . print ( " No ▁ such ▁ triplet ▁ found " ) ; return ; }
int seq = 1 ;
int min_num = nums [ 0 ] ;
int max_seq = Integer . MIN_VALUE ;
int store_min = min_num ;
for ( int i = 1 ; i < nums . length ; i ++ ) { if ( nums [ i ] == min_num ) continue ; else if ( nums [ i ] < min_num ) { min_num = nums [ i ] ; continue ; }
else if ( nums [ i ] < max_seq ) {
max_seq = nums [ i ] ;
store_min = min_num ; }
else if ( nums [ i ] > max_seq ) { seq ++ ;
if ( seq == 3 ) { System . out . println ( " Triplet : ▁ " + store_min + " , ▁ " + max_seq + " , ▁ " + nums [ i ] ) ; return ; } max_seq = nums [ i ] ; } }
System . out . print ( " No ▁ such ▁ triplet ▁ found " ) ; }
public static void main ( String [ ] args ) { int [ ] nums = { 1 , 2 , - 1 , 7 , 5 } ;
find3Numbers ( nums ) ; } }
static int maxSubarrayProduct ( int arr [ ] ) {
int result = arr [ 0 ] ; int n = arr . length ; for ( int i = 0 ; i < n ; i ++ ) { int mul = arr [ i ] ;
for ( int j = i + 1 ; j < n ; j ++ ) {
result = Math . max ( result , mul ) ; mul *= arr [ j ] ; }
result = Math . max ( result , mul ) ; } return result ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , - 2 , - 3 , 0 , 7 , - 8 , - 2 } ; System . out . println ( " Maximum ▁ Sub ▁ array ▁ product ▁ is ▁ " + maxSubarrayProduct ( arr ) ) ; } }
public static int maxCircularSum ( int a [ ] , int n ) {
if ( n == 1 ) return a [ 0 ] ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum += a [ i ] ; }
int curr_max = a [ 0 ] , max_so_far = a [ 0 ] , curr_min = a [ 0 ] , min_so_far = a [ 0 ] ;
for ( int i = 1 ; i < n ; i ++ ) {
curr_max = Math . max ( curr_max + a [ i ] , a [ i ] ) ; max_so_far = Math . max ( max_so_far , curr_max ) ;
curr_min = Math . min ( curr_min + a [ i ] , a [ i ] ) ; min_so_far = Math . min ( min_so_far , curr_min ) ; } if ( min_so_far == sum ) { return max_so_far ; }
return Math . max ( max_so_far , sum - min_so_far ) ; }
public static void main ( String [ ] args ) { int a [ ] = { 11 , 10 , - 20 , 5 , - 3 , - 5 , 8 , - 13 , 10 } ; int n = 9 ; System . out . println ( " Maximum ▁ circular ▁ sum ▁ is ▁ " + maxCircularSum ( a , n ) ) ; } }
static int GetCeilIndex ( int arr [ ] , int T [ ] , int l , int r , int key ) { while ( r - l > 1 ) { int m = l + ( r - l ) / 2 ; if ( arr [ T [ m ] ] >= key ) r = m ; else l = m ; } return r ; } static int LongestIncreasingSubsequence ( int arr [ ] , int n ) {
int tailIndices [ ] = new int [ n ] ; Arrays . fill ( tailIndices , 0 ) ; int prevIndices [ ] = new int [ n ] ;
Arrays . fill ( prevIndices , - 1 ) ;
int len = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ tailIndices [ 0 ] ] )
tailIndices [ 0 ] = i ; else if ( arr [ i ] > arr [ tailIndices [ len - 1 ] ] ) {
prevIndices [ i ] = tailIndices [ len - 1 ] ; tailIndices [ len ++ ] = i ; } else {
int pos = GetCeilIndex ( arr , tailIndices , - 1 , len - 1 , arr [ i ] ) ; prevIndices [ i ] = tailIndices [ pos - 1 ] ; tailIndices [ pos ] = i ; } } System . out . println ( " LIS ▁ of ▁ given ▁ input " ) ; for ( int i = tailIndices [ len - 1 ] ; i >= 0 ; i = prevIndices [ i ] ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( ) ; return len ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 5 , 3 , 7 , 11 , 8 , 10 , 13 , 6 } ; int n = arr . length ; System . out . print ( "LIS sizeNEW_LINE" + LongestIncreasingSubsequence(arr, n)); } }
static int maxSum ( int arr [ ] , int n ) { int sum = 0 ;
Arrays . sort ( arr ) ;
for ( int i = 0 ; i < n / 2 ; i ++ ) { sum -= ( 2 * arr [ i ] ) ; sum += ( 2 * arr [ n - i - 1 ] ) ; } return sum ; }
public static void main ( String [ ] args ) { int arr [ ] = { 4 , 2 , 1 , 8 } ; int n = arr . length ; System . out . println ( maxSum ( arr , n ) ) ; } }
public static void threeWayPartition ( int [ ] arr , int lowVal , int highVal ) { int n = arr . length ;
int start = 0 , end = n - 1 ;
for ( int i = 0 ; i <= end ; ) {
if ( arr [ i ] < lowVal ) { int temp = arr [ start ] ; arr [ start ] = arr [ i ] ; arr [ i ] = temp ; start ++ ; i ++ ; }
else if ( arr [ i ] > highVal ) { int temp = arr [ end ] ; arr [ end ] = arr [ i ] ; arr [ i ] = temp ; end -- ; } else i ++ ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 14 , 5 , 20 , 4 , 2 , 54 , 20 , 87 , 98 , 3 , 1 , 32 } ; threeWayPartition ( arr , 10 , 20 ) ; System . out . println ( " Modified ▁ array ▁ " ) ; for ( int i = 0 ; i < arr . length ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } } }
void generateUtil ( int A [ ] , int B [ ] , int C [ ] , int i , int j , int m , int n , int len , boolean flag ) {
if ( flag ) {
if ( len != 0 ) printArr ( C , len + 1 ) ;
for ( int k = i ; k < m ; k ++ ) { if ( len == 0 ) {
C [ len ] = A [ k ] ;
generateUtil ( A , B , C , k + 1 , j , m , n , len , ! flag ) ; }
else if ( A [ k ] > C [ len ] ) { C [ len + 1 ] = A [ k ] ; generateUtil ( A , B , C , k + 1 , j , m , n , len + 1 , ! flag ) ; } } }
else { for ( int l = j ; l < n ; l ++ ) { if ( B [ l ] > C [ len ] ) { C [ len + 1 ] = B [ l ] ; generateUtil ( A , B , C , i , l + 1 , m , n , len + 1 , ! flag ) ; } } } }
void generate ( int A [ ] , int B [ ] , int m , int n ) { int C [ ] = new int [ m + n ] ;
generateUtil ( A , B , C , 0 , 0 , m , n , 0 , true ) ; }
void printArr ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( " " ) ; }
public static void main ( String [ ] args ) { GenerateArrays generate = new GenerateArrays ( ) ; int A [ ] = { 10 , 15 , 25 } ; int B [ ] = { 5 , 20 , 30 } ; int n = A . length ; int m = B . length ; generate . generate ( A , B , n , m ) ; } }
static void updateindex ( int index [ ] , int a , int ai , int b , int bi ) { index [ a ] = ai ; index [ b ] = bi ; }
static int minSwapsUtil ( int arr [ ] , int pairs [ ] , int index [ ] , int i , int n ) {
if ( i > n ) return 0 ;
if ( pairs [ arr [ i ] ] == arr [ i + 1 ] ) return minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
int one = arr [ i + 1 ] ; int indextwo = i + 1 ; int indexone = index [ pairs [ arr [ i ] ] ] ; int two = arr [ index [ pairs [ arr [ i ] ] ] ] ; arr [ i + 1 ] = arr [ i + 1 ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i + 1 ] ) ; updateindex ( index , one , indexone , two , indextwo ) ; int a = minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
arr [ i + 1 ] = arr [ i + 1 ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i + 1 ] ) ; updateindex ( index , one , indextwo , two , indexone ) ; one = arr [ i ] ; indexone = index [ pairs [ arr [ i + 1 ] ] ] ;
two = arr [ index [ pairs [ arr [ i + 1 ] ] ] ] ; indextwo = i ; arr [ i ] = arr [ i ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i ] ) ; updateindex ( index , one , indexone , two , indextwo ) ; int b = minSwapsUtil ( arr , pairs , index , i + 2 , n ) ;
arr [ i ] = arr [ i ] ^ arr [ indexone ] ^ ( arr [ indexone ] = arr [ i ] ) ; updateindex ( index , one , indextwo , two , indexone ) ;
return 1 + Math . min ( a , b ) ; }
static int minSwaps ( int n , int pairs [ ] , int arr [ ] ) {
int index [ ] = new int [ 2 * n + 1 ] ;
for ( int i = 1 ; i <= 2 * n ; i ++ ) index [ arr [ i ] ] = i ;
return minSwapsUtil ( arr , pairs , index , 1 , 2 * n ) ; }
int arr [ ] = { 0 , 3 , 5 , 6 , 4 , 1 , 2 } ;
int pairs [ ] = { 0 , 3 , 6 , 1 , 5 , 4 , 2 } ; int m = pairs . length ;
int n = m / 2 ;
System . out . print ( " Min ▁ swaps ▁ required ▁ is ▁ " + minSwaps ( n , pairs , arr ) ) ; } }
static void replace_elements ( int arr [ ] , int n ) {
int pos = 0 ; for ( int i = 0 ; i < n ; i ++ ) { arr [ pos ++ ] = arr [ i ] ; while ( pos > 1 && arr [ pos - 2 ] == arr [ pos - 1 ] ) { pos -- ; arr [ pos - 1 ] ++ ; } }
for ( int i = 0 ; i < pos ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 6 , 4 , 3 , 4 , 3 , 3 , 5 } ; int n = arr . length ; replace_elements ( arr , n ) ; } }
static void arrangeString ( String str , int x , int y ) { int count_0 = 0 ; int count_1 = 0 ; int len = str . length ( ) ;
for ( int i = 0 ; i < len ; i ++ ) { if ( str . charAt ( i ) == '0' ) count_0 ++ ; else count_1 ++ ; }
while ( count_0 > 0 count_1 > 0 ) { for ( int j = 0 ; j < x && count_0 > 0 ; j ++ ) { if ( count_0 > 0 ) { System . out . print ( "0" ) ; count_0 -- ; } } for ( int j = 0 ; j < y && count_1 > 0 ; j ++ ) { if ( count_1 > 0 ) { System . out . print ( "1" ) ; count_1 -- ; } } } }
public static void main ( String [ ] args ) { String str = "01101101101101101000000" ; int x = 1 ; int y = 2 ; arrangeString ( str , x , y ) ; } }
import java . io . * ; import java . util . HashMap ; import java . util . Map ; class GFG { static void distinctAdjacentElement ( int a [ ] , int n ) {
HashMap < Integer , Integer > m = new HashMap < Integer , Integer > ( ) ;
for ( int i = 0 ; i < n ; ++ i ) { if ( m . containsKey ( a [ i ] ) ) { int x = m . get ( a [ i ] ) + 1 ; m . put ( a [ i ] , x ) ; } else { m . put ( a [ i ] , 1 ) ; } }
int mx = 0 ;
for ( int i = 0 ; i < n ; ++ i ) if ( mx < m . get ( a [ i ] ) ) mx = m . get ( a [ i ] ) ;
if ( mx > ( n + 1 ) / 2 ) System . out . println ( " NO " ) ; else System . out . println ( " YES " ) ; }
public static void main ( String [ ] args ) { int a [ ] = { 7 , 7 , 7 , 7 } ; int n = 4 ; distinctAdjacentElement ( a , n ) ; } }
public static void rearrange ( int [ ] arr ) {
if ( arr == null arr . length % 2 == 1 ) return ;
int currIdx = ( arr . length - 1 ) / 2 ;
while ( currIdx > 0 ) { int count = currIdx , swapIdx = currIdx ; while ( count -- > 0 ) { int temp = arr [ swapIdx + 1 ] ; arr [ swapIdx + 1 ] = arr [ swapIdx ] ; arr [ swapIdx ] = temp ; swapIdx ++ ; } currIdx -- ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 5 , 2 , 4 , 6 } ; rearrange ( arr ) ; for ( int i = 0 ; i < arr . length ; i ++ ) System . out . print ( " ▁ " + arr [ i ] ) ; } }
static int maxDiff ( int arr [ ] , int n ) {
int maxDiff = - 1 ;
int maxRight = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) { if ( arr [ i ] > maxRight ) maxRight = arr [ i ] ; else { int diff = maxRight - arr [ i ] ; if ( diff > maxDiff ) { maxDiff = diff ; } } } return maxDiff ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 90 , 10 , 110 } ; int n = arr . length ;
System . out . println ( " Maximum ▁ difference ▁ is ▁ " + maxDiff ( arr , n ) ) ; } }
static int maxDiff ( int arr [ ] , int n ) {
int diff = arr [ 1 ] - arr [ 0 ] ; int curr_sum = diff ; int max_sum = curr_sum ; for ( int i = 1 ; i < n - 1 ; i ++ ) {
diff = arr [ i + 1 ] - arr [ i ] ;
if ( curr_sum > 0 ) curr_sum += diff ; else curr_sum = diff ;
if ( curr_sum > max_sum ) max_sum = curr_sum ; } return max_sum ; }
public static void main ( String [ ] args ) { int arr [ ] = { 80 , 2 , 6 , 3 , 100 } ; int n = arr . length ;
System . out . print ( " Maximum ▁ difference ▁ is ▁ " + maxDiff ( arr , n ) ) ; } }
import java . util . * ; class GFG { public static void main ( String [ ] args ) { int [ ] v = { 34 , 8 , 10 , 3 , 2 , 80 , 30 , 33 , 1 } ; int n = v . length ; int [ ] maxFromEnd = new int [ n + 1 ] ; Arrays . fill ( maxFromEnd , Integer . MIN_VALUE ) ;
for ( int i = v . length - 1 ; i >= 0 ; i -- ) { maxFromEnd [ i ] = Math . max ( maxFromEnd [ i + 1 ] , v [ i ] ) ; } int result = 0 ; for ( int i = 0 ; i < v . length ; i ++ ) { int low = i + 1 , high = v . length - 1 , ans = i ; while ( low <= high ) { int mid = ( low + high ) / 2 ; if ( v [ i ] <= maxFromEnd [ mid ] ) {
ans = Math . max ( ans , mid ) ; low = mid + 1 ; } else { high = mid - 1 ; } }
result = Math . max ( result , ans - i ) ; } System . out . print ( result + "NEW_LINE"); } }
import java . io . * ; class GFG { public void getPostOrderBST ( int pre [ ] ) { int pivotPoint = 0 ;
for ( int i = 1 ; i < pre . length ; i ++ ) { if ( pre [ 0 ] <= pre [ i ] ) { pivotPoint = i ; break ; } }
for ( int i = pivotPoint - 1 ; i > 0 ; i -- ) { System . out . print ( pre [ i ] + " ▁ " ) ; }
for ( int i = pre . length - 1 ; i >= pivotPoint ; i -- ) { System . out . print ( pre [ i ] + " ▁ " ) ; } System . out . print ( pre [ 0 ] ) ; }
class CountSmaller { void constructLowerArray ( int arr [ ] , int countSmaller [ ] , int n ) { int i , j ;
for ( i = 0 ; i < n ; i ++ ) countSmaller [ i ] = 0 ; for ( i = 0 ; i < n ; i ++ ) { for ( j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] < arr [ i ] ) countSmaller [ i ] ++ ; } } }
void printArray ( int arr [ ] , int size ) { int i ; for ( i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; System . out . println ( " " ) ; }
public static void main ( String [ ] args ) { CountSmaller small = new CountSmaller ( ) ; int arr [ ] = { 12 , 10 , 5 , 4 , 2 , 20 , 6 , 1 , 0 , 2 } ; int n = arr . length ; int low [ ] = new int [ n ] ; small . constructLowerArray ( arr , low , n ) ; small . printArray ( low , n ) ; } }
static int segregate ( int arr [ ] , int size ) { int j = 0 , i ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] <= 0 ) { int temp ; temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ;
j ++ ; } } return j ; }
static int findMissingPositive ( int arr [ ] , int size ) { int i ;
for ( i = 0 ; i < size ; i ++ ) { int x = Math . abs ( arr [ i ] ) ; if ( x - 1 < size && arr [ x - 1 ] > 0 ) arr [ x - 1 ] = - arr [ x - 1 ] ; }
for ( i = 0 ; i < size ; i ++ ) if ( arr [ i ] > 0 )
return i + 1 ; return size + 1 ; }
static int findMissing ( int arr [ ] , int size ) {
int shift = segregate ( arr , size ) ; int arr2 [ ] = new int [ size - shift ] ; int j = 0 ; for ( int i = shift ; i < size ; i ++ ) { arr2 [ j ] = arr [ i ] ; j ++ ; }
return findMissingPositive ( arr2 , j ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 10 , 2 , - 10 , - 20 } ; int arr_size = arr . length ; int missing = findMissing ( arr , arr_size ) ; System . out . println ( " The ▁ smallest ▁ positive ▁ missing ▁ number ▁ is ▁ " + missing ) ; } }
static int firstMissingPositive ( int arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) {
while ( arr [ i ] >= 1 && arr [ i ] <= n && arr [ i ] != arr [ arr [ i ] - 1 ] ) { int temp = arr [ arr [ i ] - 1 ] ; arr [ arr [ i ] - 1 ] = arr [ i ] ; arr [ i ] = temp ; } }
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != i + 1 ) return ( i + 1 ) ;
return ( n + 1 ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 3 , - 7 , 6 , 8 , 1 , - 10 , 15 } ; int n = arr . length ; int ans = firstMissingPositive ( arr , n ) ; System . out . println ( ans ) ; } }
void fillDepth ( int parent [ ] , int i , int depth [ ] ) {
if ( depth [ i ] != 0 ) { return ; }
if ( parent [ i ] == - 1 ) { depth [ i ] = 1 ; return ; }
if ( depth [ parent [ i ] ] == 0 ) { fillDepth ( parent , parent [ i ] , depth ) ; }
depth [ i ] = depth [ parent [ i ] ] + 1 ; }
int findHeight ( int parent [ ] , int n ) {
int depth [ ] = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { depth [ i ] = 0 ; }
for ( int i = 0 ; i < n ; i ++ ) { fillDepth ( parent , i , depth ) ; }
int ht = depth [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { if ( ht < depth [ i ] ) { ht = depth [ i ] ; } } return ht ; }
int parent [ ] = new int [ ] { - 1 , 0 , 0 , 1 , 1 , 3 , 5 } ; int n = parent . length ; System . out . println ( " Height ▁ is ▁ " + tree . findHeight ( parent , n ) ) ; } }
static int maxRepeating ( int arr [ ] , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) arr [ ( arr [ i ] % k ) ] += k ;
int max = arr [ 0 ] , result = 0 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] > max ) { max = arr [ i ] ; result = i ; } }
return result ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 3 , 3 , 5 , 3 , 4 , 1 , 7 } ; int n = arr . length ; int k = 8 ; System . out . println ( " Maximum ▁ repeating ▁ element ▁ is : ▁ " + maxRepeating ( arr , n , k ) ) ; } }
int max ( int x , int y ) { return ( x > y ) ? x : y ; }
int maxPathSum ( int ar1 [ ] , int ar2 [ ] , int m , int n ) {
int i = 0 , j = 0 ;
int result = 0 , sum1 = 0 , sum2 = 0 ;
while ( i < m && j < n ) {
if ( ar1 [ i ] < ar2 [ j ] ) sum1 += ar1 [ i ++ ] ;
else if ( ar1 [ i ] > ar2 [ j ] ) sum2 += ar2 [ j ++ ] ;
else {
result += max ( sum1 , sum2 ) + ar1 [ i ] ;
sum1 = 0 ; sum2 = 0 ;
i ++ ; j ++ ; } }
while ( i < m ) sum1 += ar1 [ i ++ ] ;
while ( j < n ) sum2 += ar2 [ j ++ ] ;
result += max ( sum1 , sum2 ) ; return result ; }
public static void main ( String [ ] args ) { MaximumSumPath sumpath = new MaximumSumPath ( ) ; int ar1 [ ] = { 2 , 3 , 7 , 10 , 12 , 15 , 30 , 34 } ; int ar2 [ ] = { 1 , 5 , 7 , 8 , 10 , 15 , 16 , 19 } ; int m = ar1 . length ; int n = ar2 . length ;
System . out . println ( " Maximum ▁ sum ▁ path ▁ is ▁ : " + sumpath . maxPathSum ( ar1 , ar2 , m , n ) ) ; } }
import java . io . * ; class GFG { static void smallestGreater ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) {
int diff = Integer . MAX_VALUE ; int closest = - 1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( arr [ i ] < arr [ j ] && arr [ j ] - arr [ i ] < diff ) { diff = arr [ j ] - arr [ i ] ; closest = j ; } }
if ( closest == - 1 ) System . out . print ( " _ ▁ " ) ; else System . out . print ( arr [ closest ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int ar [ ] = { 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 } ; int n = ar . length ; smallestGreater ( ar , n ) ; } }
import java . util . * ; class GFG { static void smallestGreater ( int arr [ ] , int n ) { HashSet < Integer > s = new HashSet < > ( ) ; for ( int i = 0 ; i < n ; i ++ ) s . add ( arr [ i ] ) ; Vector < Integer > newAr = new Vector < > ( ) ; for ( int p : s ) { newAr . add ( p ) ; } for ( int i = 0 ; i < n ; i ++ ) { int temp = lowerBound ( newAr , 0 , newAr . size ( ) , arr [ i ] ) ; if ( temp < n ) System . out . print ( newAr . get ( temp ) + " ▁ " ) ; else System . out . print ( " _ ▁ " ) ; } }
static int lowerBound ( Vector < Integer > vec , int low , int high , int element ) { int [ ] array = new int [ vec . size ( ) ] ; int k = 0 ; for ( Integer val : vec ) { array [ k ] = val ; k ++ ; } while ( low < high ) { int middle = low + ( high - low ) / 2 ; if ( element > array [ middle ] ) { low = middle + 1 ; } else { high = middle ; } } return low + 1 ; }
public static void main ( String [ ] args ) { int ar [ ] = { 6 , 3 , 9 , 8 , 10 , 2 , 1 , 15 , 7 } ; int n = ar . length ; smallestGreater ( ar , n ) ; } }
static void findZeroes ( int m ) {
int wL = 0 , wR = 0 ;
int bestL = 0 , bestWindow = 0 ;
int zeroCount = 0 ;
while ( wR < arr . length ) {
if ( zeroCount <= m ) { if ( arr [ wR ] == 0 ) zeroCount ++ ; wR ++ ; }
if ( zeroCount > m ) { if ( arr [ wL ] == 0 ) zeroCount -- ; wL ++ ; }
if ( ( wR - wL > bestWindow ) && ( zeroCount <= m ) ) { bestWindow = wR - wL ; bestL = wL ; } }
for ( int i = 0 ; i < bestWindow ; i ++ ) { if ( arr [ bestL + i ] == 0 ) System . out . print ( bestL + i + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int m = 2 ; System . out . println ( " Indexes ▁ of ▁ zeroes ▁ to ▁ be ▁ flipped ▁ are ▁ " ) ; findZeroes ( m ) ; } }
class Test { static int arr [ ] = new int [ ] { 1 , 2 , 2 , 4 } ; static int countIncreasing ( int n ) {
int cnt = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = i + 1 ; j < n ; j ++ ) { if ( arr [ j ] > arr [ j - 1 ] ) cnt ++ ;
else break ; } } return cnt ; }
public static void main ( String [ ] args ) { System . out . println ( " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is ▁ " + countIncreasing ( arr . length ) ) ; } }
class Test { static int arr [ ] = new int [ ] { 1 , 2 , 2 , 4 } ; static int countIncreasing ( int n ) {
int cnt = 0 ;
int len = 1 ;
for ( int i = 0 ; i < n - 1 ; ++ i ) {
if ( arr [ i + 1 ] > arr [ i ] ) len ++ ;
else { cnt += ( ( ( len - 1 ) * len ) / 2 ) ; len = 1 ; } }
if ( len > 1 ) cnt += ( ( ( len - 1 ) * len ) / 2 ) ; return cnt ; }
public static void main ( String [ ] args ) { System . out . println ( " Count ▁ of ▁ strictly ▁ increasing ▁ subarrays ▁ is ▁ " + countIncreasing ( arr . length ) ) ; } }
static long arraySum ( int arr [ ] , int n ) { long sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + arr [ i ] ; return sum ; }
static long maxDiff ( int arr [ ] , int n , int k ) {
Arrays . sort ( arr ) ;
long arraysum = arraySum ( arr , n ) ;
long diff1 = Math . abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
int end = arr . length - 1 ; int start = 0 ; while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; }
long diff2 = Math . abs ( arraysum - 2 * arraySum ( arr , k ) ) ;
return ( Math . max ( diff1 , diff2 ) ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 7 , 4 , 8 , - 1 , 5 , 2 , 1 } ; int n = arr . length ; int k = 3 ; System . out . println ( " Maximum ▁ Difference ▁ = ▁ " + maxDiff ( arr , n , k ) ) ; } }
static int minNumber ( int a [ ] , int n , int x ) {
Arrays . sort ( a ) ; int k ; for ( k = 0 ; a [ ( n ) / 2 ] != x ; k ++ ) { a [ n ++ ] = x ; Arrays . sort ( a ) ; } return k ; }
public static void main ( String [ ] args ) { int x = 10 ; int a [ ] = { 10 , 20 , 30 } ; int n = 3 ; System . out . println ( minNumber ( a , n - 1 , x ) ) ; } }
import java . util . * ; import java . lang . * ; class GFG { public static int minNumber ( int a [ ] , int n , int x ) { int l = 0 , h = 0 , e = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == x ) e ++ ;
else if ( a [ i ] > x ) h ++ ;
else if ( a [ i ] < x ) l ++ ; } int ans = 0 ; if ( l > h ) ans = l - h ; else if ( l < h ) ans = h - l - 1 ;
return ans + 1 - e ; }
public static void main ( String [ ] args ) { int x = 10 ; int a [ ] = { 10 , 20 , 30 } ; int n = a . length ; System . out . println ( minNumber ( a , n , x ) ) ; } }
static int fun ( int x ) { int y = ( x / 4 ) * 4 ;
int ans = 0 ; for ( int i = y ; i <= x ; i ++ ) ans ^= i ; return ans ; }
static int query ( int x ) {
if ( x == 0 ) return 0 ; int k = ( x + 1 ) / 2 ;
return ( ( x %= 2 ) != 0 ) ? 2 * fun ( k ) : ( ( fun ( k - 1 ) * 2 ) ^ ( k & 1 ) ) ; } static void allQueries ( int q , int l [ ] , int r [ ] ) { for ( int i = 0 ; i < q ; i ++ ) System . out . println ( ( query ( r [ i ] ) ^ query ( l [ i ] - 1 ) ) ) ; }
public static void main ( String [ ] args ) { int q = 3 ; int [ ] l = { 2 , 2 , 5 } ; int [ ] r = { 4 , 8 , 9 } ; allQueries ( q , l , r ) ; } }
static void preprocess ( int arr [ ] , int N , int left [ ] , int right [ ] ) {
left [ 0 ] = 0 ; int lastIncr = 0 ; for ( int i = 1 ; i < N ; i ++ ) {
if ( arr [ i ] > arr [ i - 1 ] ) lastIncr = i ; left [ i ] = lastIncr ; }
right [ N - 1 ] = N - 1 ; int firstDecr = N - 1 ; for ( int i = N - 2 ; i >= 0 ; i -- ) {
if ( arr [ i ] > arr [ i + 1 ] ) firstDecr = i ; right [ i ] = firstDecr ; } }
static boolean isSubarrayMountainForm ( int arr [ ] , int left [ ] , int right [ ] , int L , int R ) {
return ( right [ L ] >= left [ R ] ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 3 , 2 , 4 , 4 , 6 , 3 , 2 } ; int N = arr . length ; int left [ ] = new int [ N ] ; int right [ ] = new int [ N ] ; preprocess ( arr , N , left , right ) ; int L = 0 ; int R = 2 ; if ( isSubarrayMountainForm ( arr , left , right , L , R ) ) System . out . println ( " Subarray ▁ is ▁ in ▁ mountain ▁ form " ) ; else System . out . println ( " Subarray ▁ is ▁ not ▁ in ▁ mountain ▁ form " ) ; L = 1 ; R = 3 ; if ( isSubarrayMountainForm ( arr , left , right , L , R ) ) System . out . println ( " Subarray ▁ is ▁ in ▁ mountain ▁ form " ) ; else System . out . println ( " Subarray ▁ is ▁ not ▁ in ▁ mountain ▁ form " ) ; } }
import java . util . * ; import java . lang . * ; class GFG { public static void preCompute ( int arr [ ] , int n , int pre [ ] ) { pre [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) pre [ i ] = arr [ i ] + pre [ i - 1 ] ; }
public static int rangeSum ( int i , int j , int pre [ ] ) { if ( i == 0 ) return pre [ j ] ; return pre [ j ] - pre [ i - 1 ] ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = arr . length ; int pre [ ] = new int [ n ] ;
preCompute ( arr , n , pre ) ; System . out . println ( rangeSum ( 1 , 3 , pre ) ) ; System . out . println ( rangeSum ( 2 , 4 , pre ) ) ; } }
import java . io . * ; import java . util . * ; class GFG { static int MAX = 1000 ; static void sieveOfEratosthenes ( boolean isPrime [ ] ) { isPrime [ 1 ] = false ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( isPrime [ p ] == true ) {
for ( int i = p * 2 ; i <= MAX ; i += p ) isPrime [ i ] = false ; } } }
static int getMid ( int s , int e ) { return s + ( e - s ) / 2 ; }
static int queryPrimesUtil ( int [ ] st , int ss , int se , int qs , int qe , int index ) {
if ( qs <= ss && qe >= se ) return st [ index ] ;
if ( se < qs ss > qe ) return 0 ;
int mid = getMid ( ss , se ) ; return queryPrimesUtil ( st , ss , mid , qs , qe , 2 * index + 1 ) + queryPrimesUtil ( st , mid + 1 , se , qs , qe , 2 * index + 2 ) ; }
static void updateValueUtil ( int [ ] st , int ss , int se , int i , int diff , int si ) {
if ( i < ss i > se ) return ;
st [ si ] = st [ si ] + diff ; if ( se != ss ) { int mid = getMid ( ss , se ) ; updateValueUtil ( st , ss , mid , i , diff , 2 * si + 1 ) ; updateValueUtil ( st , mid + 1 , se , i , diff , 2 * si + 2 ) ; } }
static void updateValue ( int arr [ ] , int [ ] st , int n , int i , int new_val , boolean isPrime [ ] ) {
if ( i < 0 i > n - 1 ) { System . out . println ( " Invalid ▁ Input " ) ; return ; } int diff = 0 ; int oldValue ; oldValue = arr [ i ] ;
arr [ i ] = new_val ;
if ( isPrime [ oldValue ] && isPrime [ new_val ] ) return ;
if ( ( ! isPrime [ oldValue ] ) && ( ! isPrime [ new_val ] ) ) return ;
if ( isPrime [ oldValue ] && ! isPrime [ new_val ] ) { diff = - 1 ; }
if ( ! isPrime [ oldValue ] && isPrime [ new_val ] ) { diff = 1 ; }
updateValueUtil ( st , 0 , n - 1 , i , diff , 0 ) ; }
static void queryPrimes ( int [ ] st , int n , int qs , int qe ) { int primesInRange = queryPrimesUtil ( st , 0 , n - 1 , qs , qe , 0 ) ; System . out . println ( " Number ▁ of ▁ Primes ▁ in ▁ subarray ▁ from ▁ " + qs + " ▁ to ▁ " + qe + " ▁ = ▁ " + primesInRange ) ; }
static int constructSTUtil ( int arr [ ] , int ss , int se , int [ ] st , int si , boolean isPrime [ ] ) {
if ( ss == se ) {
if ( isPrime [ arr [ ss ] ] ) st [ si ] = 1 ; else st [ si ] = 0 ; return st [ si ] ; }
int mid = getMid ( ss , se ) ; st [ si ] = constructSTUtil ( arr , ss , mid , st , si * 2 + 1 , isPrime ) + constructSTUtil ( arr , mid + 1 , se , st , si * 2 + 2 , isPrime ) ; return st [ si ] ; }
static int [ ] constructST ( int arr [ ] , int n , boolean isPrime [ ] ) {
int x = ( int ) ( Math . ceil ( Math . log ( n ) / Math . log ( 2 ) ) ) ;
int max_size = 2 * ( int ) Math . pow ( 2 , x ) - 1 ; int [ ] st = new int [ max_size ] ;
constructSTUtil ( arr , 0 , n - 1 , st , 0 , isPrime ) ;
return st ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 5 , 7 , 9 } ; int n = arr . length ;
boolean [ ] isPrime = new boolean [ MAX + 1 ] ; Arrays . fill ( isPrime , Boolean . TRUE ) ; sieveOfEratosthenes ( isPrime ) ;
int [ ] st = constructST ( arr , n , isPrime ) ;
int start = 0 ; int end = 4 ; queryPrimes ( st , n , start , end ) ;
int i = 3 ; int x = 6 ; updateValue ( arr , st , n , i , x , isPrime ) ;
start = 0 ; end = 4 ; queryPrimes ( st , n , start , end ) ; } }
static void checkEVENodd ( int arr [ ] , int n , int l , int r ) {
if ( arr [ r ] == 1 ) System . out . println ( " odd " ) ;
else System . out . println ( " even " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 0 , 1 } ; int n = arr . length ; checkEVENodd ( arr , n , 1 , 3 ) ; } }
static int findMean ( int arr [ ] , int l , int r ) {
int sum = 0 , count = 0 ;
for ( int i = l ; i <= r ; i ++ ) { sum += arr [ i ] ; count ++ ; }
int mean = ( int ) Math . floor ( sum / count ) ;
return mean ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; System . out . println ( findMean ( arr , 0 , 2 ) ) ; System . out . println ( findMean ( arr , 1 , 3 ) ) ; System . out . println ( findMean ( arr , 0 , 4 ) ) ; } }
public class Main { public static final int MAX = 1000005 ; static int prefixSum [ ] = new int [ MAX ] ;
static void calculatePrefixSum ( int arr [ ] , int n ) {
prefixSum [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) prefixSum [ i ] = prefixSum [ i - 1 ] + arr [ i ] ; }
static int findMean ( int l , int r ) { if ( l == 0 ) return ( int ) Math . floor ( prefixSum [ r ] / ( r + 1 ) ) ;
return ( int ) Math . floor ( ( prefixSum [ r ] - prefixSum [ l - 1 ] ) / ( r - l + 1 ) ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = arr . length ; calculatePrefixSum ( arr , n ) ; System . out . println ( findMean ( 1 , 2 ) ) ; System . out . println ( findMean ( 1 , 3 ) ) ; System . out . println ( findMean ( 1 , 4 ) ) ; } }
static void updateQuery ( int arr [ ] , int n , int q , int l , int r , int k ) {
if ( q == 0 ) { arr [ l - 1 ] += k ; arr [ r ] += - k ; }
else { arr [ l - 1 ] += - k ; arr [ r ] += k ; } return ; }
static void generateArray ( int arr [ ] , int n ) {
for ( int i = 1 ; i < n ; ++ i ) arr [ i ] += arr [ i - 1 ] ; }
public static void main ( String arg [ ] ) { int n = 5 ; int arr [ ] = new int [ n + 1 ] ; Arrays . fill ( arr , 0 ) ; int q = 0 , l = 1 , r = 3 , k = 2 ; updateQuery ( arr , n , q , l , r , k ) ; q = 1 ; l = 3 ; r = 5 ; k = 3 ; updateQuery ( arr , n , q , l , r , k ) ; q = 0 ; l = 2 ; r = 5 ; k = 1 ; updateQuery ( arr , n , q , l , r , k ) ;
generateArray ( arr , n ) ;
for ( int i = 0 ; i < n ; ++ i ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static int calculateProduct ( int [ ] A , int L , int R , int P ) {
L = L - 1 ; R = R - 1 ; int ans = 1 ; for ( int i = L ; i <= R ; i ++ ) { ans = ans * A [ i ] ; ans = ans % P ; } return ans ; }
static public void main ( String [ ] args ) { int [ ] A = { 1 , 2 , 3 , 4 , 5 , 6 } ; int P = 229 ; int L = 2 , R = 5 ; System . out . println ( calculateProduct ( A , L , R , P ) ) ; L = 1 ; R = 3 ; System . out . println ( calculateProduct ( A , L , R , P ) ) ; } }
class GFG { static int MAX = 100 ; int pre_product [ ] = new int [ MAX ] ; int inverse_product [ ] = new int [ MAX ] ;
int modInverse ( int a , int m ) { int m0 = m , t , q ; int x0 = 0 , x1 = 1 ; if ( m == 1 ) return 0 ; while ( a > 1 ) {
q = a / m ; t = m ;
m = a % m ; a = t ; t = x0 ; x0 = x1 - q * x0 ; x1 = t ; }
if ( x1 < 0 ) x1 += m0 ; return x1 ; }
void calculate_Pre_Product ( int A [ ] , int N , int P ) { pre_product [ 0 ] = A [ 0 ] ; for ( int i = 1 ; i < N ; i ++ ) { pre_product [ i ] = pre_product [ i - 1 ] * A [ i ] ; pre_product [ i ] = pre_product [ i ] % P ; } }
void calculate_inverse_product ( int A [ ] , int N , int P ) { inverse_product [ 0 ] = modInverse ( pre_product [ 0 ] , P ) ; for ( int i = 1 ; i < N ; i ++ ) inverse_product [ i ] = modInverse ( pre_product [ i ] , P ) ; }
int calculateProduct ( int A [ ] , int L , int R , int P ) {
L = L - 1 ; R = R - 1 ; int ans ; if ( L == 0 ) ans = pre_product [ R ] ; else ans = pre_product [ R ] * inverse_product [ L - 1 ] ; return ans ; }
int A [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ;
int P = 113 ;
d . calculate_Pre_Product ( A , A . length , P ) ; d . calculate_inverse_product ( A , A . length , P ) ;
int L = 2 , R = 5 ; System . out . println ( d . calculateProduct ( A , L , R , P ) ) ; L = 1 ; R = 3 ; System . out . println ( d . calculateProduct ( A , L , R , P ) ) ; } }
import java . util . * ; class GFG { static final int MAX = 10000 ;
static int prefix [ ] = new int [ MAX + 1 ] ; static void buildPrefix ( ) {
boolean prime [ ] = new boolean [ MAX + 1 ] ; Arrays . fill ( prime , true ) ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * 2 ; i <= MAX ; i += p ) prime [ i ] = false ; } }
prefix [ 0 ] = prefix [ 1 ] = 0 ; for ( int p = 2 ; p <= MAX ; p ++ ) { prefix [ p ] = prefix [ p - 1 ] ; if ( prime [ p ] ) prefix [ p ] ++ ; } }
static int query ( int L , int R ) { return prefix [ R ] - prefix [ L - 1 ] ; }
public static void main ( String [ ] args ) { buildPrefix ( ) ; int L = 5 , R = 10 ; System . out . println ( query ( L , R ) ) ; L = 1 ; R = 10 ; System . out . println ( query ( L , R ) ) ; } }
static void command ( boolean arr [ ] , int a , int b ) { arr [ a ] ^= true ; arr [ b + 1 ] ^= true ; }
static void process ( boolean arr [ ] , int n ) { for ( int k = 1 ; k <= n ; k ++ ) { arr [ k ] ^= arr [ k - 1 ] ; } }
static void result ( boolean arr [ ] , int n ) { for ( int k = 1 ; k <= n ; k ++ ) { if ( arr [ k ] == true ) System . out . print ( "1" + " ▁ " ) ; else System . out . print ( "0" + " ▁ " ) ; } }
public static void main ( String args [ ] ) { int n = 5 , m = 3 ; boolean arr [ ] = new boolean [ n + 2 ] ;
command ( arr , 1 , 5 ) ; command ( arr , 2 , 5 ) ; command ( arr , 3 , 5 ) ;
process ( arr , n ) ;
result ( arr , n ) ; } }
static class Interval { int start ; int end ; public Interval ( int start , int end ) { super ( ) ; this . start = start ; this . end = end ; } } ;
static boolean isIntersect ( Interval arr [ ] , int n ) {
Arrays . sort ( arr , ( i1 , i2 ) -> { return i1 . start - i2 . start ; } ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( arr [ i - 1 ] . end > arr [ i ] . start ) return true ;
return false ; }
public static void main ( String [ ] args ) { Interval arr1 [ ] = { new Interval ( 1 , 3 ) , new Interval ( 7 , 9 ) , new Interval ( 4 , 6 ) , new Interval ( 10 , 13 ) } ; int n1 = arr1 . length ; if ( isIntersect ( arr1 , n1 ) ) System . out . print ( "YesNEW_LINE"); else System . out . print ( "NoNEW_LINE"); Interval arr2 [ ] = { new Interval ( 6 , 8 ) , new Interval ( 1 , 3 ) , new Interval ( 2 , 4 ) , new Interval ( 4 , 7 ) } ; int n2 = arr2 . length ; if ( isIntersect ( arr2 , n2 ) ) System . out . print ( "YesNEW_LINE"); else System . out . print ( "NoNEW_LINE"); } }
static class Interval { int start ; int end ; public Interval ( int start , int end ) { super ( ) ; this . start = start ; this . end = end ; } } ;
static boolean isIntersect ( Interval arr [ ] , int n ) { int max_ele = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { if ( max_ele < arr [ i ] . end ) max_ele = arr [ i ] . end ; }
int [ ] aux = new int [ max_ele + 1 ] ; for ( int i = 0 ; i < n ; i ++ ) {
int x = arr [ i ] . start ;
int y = arr [ i ] . end ; aux [ x ] ++ ; aux [ y ] -- ; } for ( int i = 1 ; i <= max_ele ; i ++ ) {
aux [ i ] += aux [ i - 1 ] ;
if ( aux [ i ] > 1 ) return true ; }
return false ; }
public static void main ( String [ ] args ) { Interval arr1 [ ] = { new Interval ( 1 , 3 ) , new Interval ( 7 , 9 ) , new Interval ( 4 , 6 ) , new Interval ( 10 , 13 ) } ; int n1 = arr1 . length ; if ( isIntersect ( arr1 , n1 ) ) System . out . print ( "YesNEW_LINE"); else System . out . print ( "NoNEW_LINE"); Interval arr2 [ ] = { new Interval ( 6 , 8 ) , new Interval ( 1 , 3 ) , new Interval ( 2 , 4 ) , new Interval ( 4 , 7 ) } ; int n2 = arr2 . length ; if ( isIntersect ( arr2 , n2 ) ) System . out . print ( "YesNEW_LINE"); else System . out . print ( "NoNEW_LINE"); } }
static class query { int start , end ; query ( int start , int end ) { this . start = start ; this . end = end ; } }
public static void incrementByD ( int [ ] arr , query [ ] q_arr , int n , int m , int d ) { int [ ] sum = new int [ n ] ;
for ( int i = 0 ; i < m ; i ++ ) {
sum [ q_arr [ i ] . start ] += d ;
if ( ( q_arr [ i ] . end + 1 ) < n ) sum [ q_arr [ i ] . end + 1 ] -= d ; }
arr [ 0 ] += sum [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) { sum [ i ] += sum [ i - 1 ] ; arr [ i ] += sum [ i ] ; } }
public static void printArray ( int [ ] arr , int n ) { for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int [ ] arr = { 3 , 5 , 4 , 8 , 6 , 1 } ; query [ ] q_arr = new query [ 5 ] ; q_arr [ 0 ] = new query ( 0 , 3 ) ; q_arr [ 1 ] = new query ( 4 , 5 ) ; q_arr [ 2 ] = new query ( 1 , 4 ) ; q_arr [ 3 ] = new query ( 0 , 1 ) ; q_arr [ 4 ] = new query ( 2 , 5 ) ; int n = arr . length ; int m = q_arr . length ; int d = 2 ; System . out . println ( " Original ▁ Array : " ) ; printArray ( arr , n ) ;
incrementByD ( arr , q_arr , n , m , d ) ; System . out . println ( " Modified Array : "); printArray ( arr , n ) ; } }
static void prefixXOR ( int arr [ ] , int preXOR [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { while ( arr [ i ] % 2 != 1 ) arr [ i ] /= 2 ; preXOR [ i ] = arr [ i ] ; }
for ( int i = 1 ; i < n ; i ++ ) preXOR [ i ] = preXOR [ i - 1 ] ^ preXOR [ i ] ; }
static int query ( int preXOR [ ] , int l , int r ) { if ( l == 0 ) return preXOR [ r ] ; else return preXOR [ r ] ^ preXOR [ l - 1 ] ; }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 4 , 5 } ; int n = arr . length ; int preXOR [ ] = new int [ n ] ; prefixXOR ( arr , preXOR , n ) ; System . out . println ( query ( preXOR , 0 , 2 ) ) ; System . out . println ( query ( preXOR , 1 , 2 ) ) ; } }
class GFG { static final int MAX = 100000 ;
static int tree [ ] = new int [ MAX ] ;
static boolean lazy [ ] = new boolean [ MAX ] ;
static void toggle ( int node , int st , int en , int us , int ue ) {
if ( lazy [ node ] ) {
lazy [ node ] = false ; tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ 1 + ( node << 1 ) ] = ! lazy [ 1 + ( node << 1 ) ] ; } }
if ( st > en us > en ue < st ) { return ; }
if ( us <= st && en <= ue ) {
tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ 1 + ( node << 1 ) ] = ! lazy [ 1 + ( node << 1 ) ] ; } return ; }
int mid = ( st + en ) / 2 ; toggle ( ( node << 1 ) , st , mid , us , ue ) ; toggle ( ( node << 1 ) + 1 , mid + 1 , en , us , ue ) ;
if ( st < en ) { tree [ node ] = tree [ node << 1 ] + tree [ ( node << 1 ) + 1 ] ; } }
static int countQuery ( int node , int st , int en , int qs , int qe ) {
if ( st > en qs > en qe < st ) { return 0 ; }
if ( lazy [ node ] ) {
lazy [ node ] = false ; tree [ node ] = en - st + 1 - tree [ node ] ;
if ( st < en ) {
lazy [ node << 1 ] = ! lazy [ node << 1 ] ; lazy [ ( node << 1 ) + 1 ] = ! lazy [ ( node << 1 ) + 1 ] ; } }
if ( qs <= st && en <= qe ) { return tree [ node ] ; }
int mid = ( st + en ) / 2 ; return countQuery ( ( node << 1 ) , st , mid , qs , qe ) + countQuery ( ( node << 1 ) + 1 , mid + 1 , en , qs , qe ) ; }
public static void main ( String args [ ] ) { int n = 5 ;
toggle ( 1 , 0 , n - 1 , 1 , 2 ) ;
toggle ( 1 , 0 , n - 1 , 2 , 4 ) ;
System . out . println ( countQuery ( 1 , 0 , n - 1 , 2 , 3 ) ) ;
toggle ( 1 , 0 , n - 1 , 2 , 4 ) ;
System . out . println ( countQuery ( 1 , 0 , n - 1 , 1 , 4 ) ) ; } }
static double probability ( int a [ ] , int b [ ] , int size1 , int size2 ) {
int max1 = Integer . MIN_VALUE , count1 = 0 ; for ( int i = 0 ; i < size1 ; i ++ ) { if ( a [ i ] > max1 ) { max1 = a [ i ] ; count1 = 1 ; } else if ( a [ i ] == max1 ) { count1 ++ ; } }
int max2 = Integer . MIN_VALUE , count2 = 0 ; for ( int i = 0 ; i < size2 ; i ++ ) { if ( b [ i ] > max2 ) { max2 = b [ i ] ; count2 = 1 ; } else if ( b [ i ] == max2 ) { count2 ++ ; } }
return ( double ) ( count1 * count2 ) / ( size1 * size2 ) ; }
public static void main ( String args [ ] ) { int a [ ] = { 1 , 2 , 3 } ; int b [ ] = { 1 , 3 , 3 } ; int size1 = a . length ; int size2 = b . length ; System . out . println ( probability ( a , b , size1 , size2 ) ) ; } }
public static int countDe ( int arr [ ] , int n ) { int v [ ] = new int [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) v [ i ] = arr [ i ] ;
Arrays . sort ( arr ) ;
int count1 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count1 ++ ;
Collections . reverse ( Arrays . asList ( arr ) ) ;
int count2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] != v [ i ] ) count2 ++ ;
return ( Math . min ( count1 , count2 ) ) ; }
public static void main ( String argc [ ] ) { int arr [ ] = { 5 , 9 , 21 , 17 , 13 } ; int n = 5 ; System . out . println ( " Minimum ▁ Dearrangement ▁ = ▁ " + countDe ( arr , n ) ) ; } }
static int maxOfSegmentMins ( int [ ] a , int n , int k ) {
if ( k == 1 ) { Arrays . sort ( a ) ; return a [ 0 ] ; } if ( k == 2 ) return Math . max ( a [ 0 ] , a [ n - 1 ] ) ;
return a [ n - 1 ] ; }
static public void main ( String [ ] args ) { int [ ] a = { - 10 , - 9 , - 8 , 2 , 7 , - 6 , - 5 } ; int n = a . length ; int k = 2 ; System . out . println ( maxOfSegmentMins ( a , n , k ) ) ; } }
static int printMinimumProduct ( int arr [ ] , int n ) {
int first_min = Math . min ( arr [ 0 ] , arr [ 1 ] ) ; int second_min = Math . max ( arr [ 0 ] , arr [ 1 ] ) ;
for ( int i = 2 ; i < n ; i ++ ) { if ( arr [ i ] < first_min ) { second_min = first_min ; first_min = arr [ i ] ; } else if ( arr [ i ] < second_min ) second_min = arr [ i ] ; } return first_min * second_min ; }
public static void main ( String [ ] args ) { int a [ ] = { 11 , 8 , 5 , 7 , 5 , 100 } ; int n = a . length ; System . out . print ( printMinimumProduct ( a , n ) ) ; } }
static long noOfTriples ( long arr [ ] , int n ) {
Arrays . sort ( arr ) ;
long count = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] == arr [ 2 ] ) count ++ ;
if ( arr [ 0 ] == arr [ 2 ] ) return ( count - 2 ) * ( count - 1 ) * ( count ) / 6 ;
else if ( arr [ 1 ] == arr [ 2 ] ) return ( count - 1 ) * ( count ) / 2 ;
return count ; }
public static void main ( String arg [ ] ) { long arr [ ] = { 1 , 3 , 3 , 4 } ; int n = arr . length ; System . out . print ( noOfTriples ( arr , n ) ) ; } }
static boolean checkReverse ( int arr [ ] , int n ) {
int temp [ ] = new int [ n ] ; for ( int i = 0 ; i < n ; i ++ ) { temp [ i ] = arr [ i ] ; }
Arrays . sort ( temp ) ;
int front ; for ( front = 0 ; front < n ; front ++ ) { if ( temp [ front ] != arr [ front ] ) { break ; } }
int back ; for ( back = n - 1 ; back >= 0 ; back -- ) { if ( temp [ back ] != arr [ back ] ) { break ; } }
if ( front >= back ) { return true ; }
do { front ++ ; if ( arr [ front - 1 ] < arr [ front ] ) { return false ; } } while ( front != back ) ; return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 5 , 4 , 3 } ; int n = arr . length ; if ( checkReverse ( arr , n ) ) { System . out . print ( " Yes " ) ; } else { System . out . print ( " No " ) ; } } }
static boolean checkReverse ( int arr [ ] , int n ) { if ( n == 1 ) { return true ; }
int i ; for ( i = 1 ; arr [ i - 1 ] < arr [ i ] && i < n ; i ++ ) ; if ( i == n ) { return true ; }
int j = i ; while ( j < n && arr [ j ] < arr [ j - 1 ] ) { if ( i > 1 && arr [ j ] < arr [ i - 2 ] ) { return false ; } j ++ ; } if ( j == n ) { return true ; }
int k = j ;
if ( arr [ k ] < arr [ i - 1 ] ) { return false ; } while ( k > 1 && k < n ) { if ( arr [ k ] < arr [ k - 1 ] ) { return false ; } k ++ ; } return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 4 , 10 , 9 , 8 } ; int n = arr . length ; if ( checkReverse ( arr , n ) ) { System . out . print ( " Yes " ) ; } else { System . out . print ( " No " ) ; } } }
import java . util . Arrays ; import java . io . * ; class GFG { static int MinOperation ( int a [ ] , int b [ ] , int n ) {
Arrays . sort ( a ) ; Arrays . sort ( b ) ;
int result = 0 ;
for ( int i = 0 ; i < n ; ++ i ) { if ( a [ i ] > b [ i ] ) result = result + Math . abs ( a [ i ] - b [ i ] ) ; else if ( a [ i ] < b [ i ] ) result = result + Math . abs ( a [ i ] - b [ i ] ) ; } return result ; }
public static void main ( String [ ] args ) { int a [ ] = { 3 , 1 , 1 } ; int b [ ] = { 1 , 2 , 2 } ; int n = a . length ; System . out . println ( MinOperation ( a , b , n ) ) ; } }
public static void sortExceptUandL ( int a [ ] , int l , int u , int n ) {
int b [ ] = new int [ n - ( u - l + 1 ) ] ; for ( int i = 0 ; i < l ; i ++ ) b [ i ] = a [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) b [ l + ( i - ( u + 1 ) ) ] = a [ i ] ;
Arrays . sort ( b ) ;
for ( int i = 0 ; i < l ; i ++ ) a [ i ] = b [ i ] ; for ( int i = u + 1 ; i < n ; i ++ ) a [ i ] = b [ l + ( i - ( u + 1 ) ) ] ; }
public static void main ( String args [ ] ) { int a [ ] = { 5 , 4 , 3 , 12 , 14 , 9 } ; int n = a . length ; int l = 2 , u = 4 ; sortExceptUandL ( a , l , u , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( a [ i ] + " ▁ " ) ; } }
import java . util . Arrays ; class GFG { static int sortExceptK ( int arr [ ] , int k , int n ) {
int temp = arr [ k ] ; arr [ k ] = arr [ n - 1 ] ; arr [ n - 1 ] = temp ;
Arrays . sort ( arr , 0 , n - 1 ) ;
int last = arr [ n - 1 ] ;
for ( int i = n - 1 ; i > k ; i -- ) arr [ i ] = arr [ i - 1 ] ;
arr [ k ] = last ; return 0 ; }
public static void main ( String [ ] args ) { int a [ ] = { 10 , 4 , 11 , 7 , 6 , 20 } ; int k = 2 ; int n = a . length ; sortExceptK ( a , k , n ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( a [ i ] + " ▁ " ) ; } }
static int findMinSwaps ( int arr [ ] , int n ) {
int noOfZeroes [ ] = new int [ n ] ; int i , count = 0 ;
noOfZeroes [ n - 1 ] = 1 - arr [ n - 1 ] ; for ( i = n - 2 ; i >= 0 ; i -- ) { noOfZeroes [ i ] = noOfZeroes [ i + 1 ] ; if ( arr [ i ] == 0 ) noOfZeroes [ i ] ++ ; }
for ( i = 0 ; i < n ; i ++ ) { if ( arr [ i ] == 1 ) count += noOfZeroes [ i ] ; } return count ; }
public static void main ( String args [ ] ) { int ar [ ] = { 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 } ; System . out . println ( findMinSwaps ( ar , ar . length ) ) ; } }
import java . io . * ; class GFG { public static int minswaps ( int arr [ ] , int n ) { int count = 0 ; int num_unplaced_zeros = 0 ; for ( int index = n - 1 ; index >= 0 ; index -- ) { if ( arr [ index ] == 0 ) num_unplaced_zeros += 1 ; else count += num_unplaced_zeros ; } return count ; }
public static void main ( String [ ] args ) { int [ ] arr = { 0 , 0 , 1 , 0 , 1 , 0 , 1 , 1 } ; System . out . println ( minswaps ( arr , 9 ) ) ; } }
static class Node { int data ; Node next ; } ;
static Node push ( Node head_ref , int new_data ) { Node new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
static void printList ( Node head ) { while ( head != null ) { System . out . print ( head . data + " - > " ) ; head = head . next ; } }
static void sortlist ( int arr [ ] , int N , Node head ) {
HashMap < Integer , Integer > hash = new HashMap < Integer , Integer > ( ) ; Node temp = head ; while ( temp != null ) { if ( hash . containsKey ( temp . data ) ) hash . put ( temp . data , hash . get ( temp . data ) + 1 ) ; else hash . put ( temp . data , 1 ) ; temp = temp . next ; } temp = head ;
for ( int i = 0 ; i < N ; i ++ ) {
int frequency = hash . get ( arr [ i ] ) ; while ( frequency -- > 0 ) {
temp . data = arr [ i ] ; temp = temp . next ; } } }
public static void main ( String [ ] args ) { Node head = null ; int arr [ ] = { 5 , 1 , 3 , 2 , 8 } ; int N = arr . length ;
head = push ( head , 3 ) ; head = push ( head , 2 ) ; head = push ( head , 5 ) ; head = push ( head , 8 ) ; head = push ( head , 5 ) ; head = push ( head , 2 ) ; head = push ( head , 1 ) ;
sortlist ( arr , N , head ) ;
System . out . print ( " Sorted ▁ List : " + "NEW_LINE"); printList ( head ) ; } }
import java . io . * ; import java . util . * ; public class GFG { static void printRepeating ( Integer [ ] arr , int size ) {
SortedSet < Integer > s = new TreeSet < > ( ) ; Collections . addAll ( s , arr ) ;
System . out . print ( s ) ; }
public static void main ( String args [ ] ) { Integer [ ] arr = { 1 , 3 , 2 , 2 , 1 } ; int n = arr . length ; printRepeating ( arr , n ) ; } }
static int maxPartitions ( int arr [ ] , int n ) { int ans = 0 , max_so_far = 0 ; for ( int i = 0 ; i < n ; ++ i ) {
max_so_far = Math . max ( max_so_far , arr [ i ] ) ;
if ( max_so_far == i ) ans ++ ; } return ans ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 0 , 2 , 3 , 4 } ; int n = arr . length ; System . out . println ( maxPartitions ( arr , n ) ) ; } }
public static void cuttringRopes ( int Ropes [ ] , int n ) {
Arrays . sort ( Ropes ) ; int singleOperation = 0 ;
int cuttingLenght = Ropes [ 0 ] ;
for ( int i = 1 ; i < n ; i ++ ) {
if ( Ropes [ i ] - cuttingLenght > 0 ) { System . out . print ( n - i + " ▁ " ) ;
cuttingLenght = Ropes [ i ] ; singleOperation ++ ; } }
if ( singleOperation == 0 ) System . out . print ( "0" ) ; }
public static void main ( String [ ] arg ) { int [ ] Ropes = { 5 , 1 , 1 , 2 , 3 , 5 } ; int n = Ropes . length ; cuttringRopes ( Ropes , n ) ; } }
public static void rankify ( int A [ ] , int n ) {
float R [ ] = new float [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) { int r = 1 , s = 1 ; for ( int j = 0 ; j < n ; j ++ ) { if ( j != i && A [ j ] < A [ i ] ) r += 1 ; if ( j != i && A [ j ] == A [ i ] ) s += 1 ; }
R [ i ] = r + ( float ) ( s - 1 ) / ( float ) 2 ; } for ( int i = 0 ; i < n ; i ++ ) System . out . print ( R [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int A [ ] = { 1 , 2 , 5 , 2 , 1 , 25 , 2 } ; int n = A . length ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( A [ i ] + " ▁ " ) ; System . out . println ( ) ; rankify ( A , n ) ; } }
public static int min_noOf_operation ( int arr [ ] , int n , int k ) { int noOfSubtraction ; int res = 0 ; for ( int i = 1 ; i < n ; i ++ ) { noOfSubtraction = 0 ; if ( arr [ i ] > arr [ i - 1 ] ) {
noOfSubtraction = ( arr [ i ] - arr [ i - 1 ] ) / k ;
if ( ( arr [ i ] - arr [ i - 1 ] ) % k != 0 ) noOfSubtraction ++ ;
arr [ i ] = arr [ i ] - k * noOfSubtraction ; }
res = res + noOfSubtraction ; } return res ; }
public static void main ( String argc [ ] ) { int arr = { 1 , 1 , 2 , 3 } ; int N = 4 ; int k = 5 ; System . out . println ( min_noOf_operation ( arr , N , k ) ) ; } }
import java . util . * ; class GFG { static int maxSum ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += ( arr [ i ] * i ) ; return sum ; }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 5 , 6 , 1 } ; int n = arr . length ; System . out . println ( maxSum ( arr , n ) ) ; } }
static int countPairs ( int a [ ] , int n , int k ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( Math . abs ( a [ j ] - a [ i ] ) < k ) res ++ ; return res ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = a . length ; System . out . println ( countPairs ( a , n , k ) ) ; } }
import java . io . * ; import java . util . Arrays ; class GFG { static int countPairs ( int a [ ] , int n , int k ) {
Arrays . sort ( a ) ; int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
int j = i + 1 ; while ( j < n && a [ j ] - a [ i ] < k ) { res ++ ; j ++ ; } } return res ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 10 , 4 , 2 } ; int k = 3 ; int n = a . length ; System . out . println ( countPairs ( a , n , k ) ) ; } }
public static void sortedMerge ( int a [ ] , int b [ ] , int res [ ] , int n , int m ) {
Arrays . sort ( a ) ; Arrays . sort ( b ) ;
int i = 0 , j = 0 , k = 0 ; while ( i < n && j < m ) { if ( a [ i ] <= b [ j ] ) { res [ k ] = a [ i ] ; i += 1 ; k += 1 ; } else { res [ k ] = b [ j ] ; j += 1 ; k += 1 ; } }
while ( i < n ) { res [ k ] = a [ i ] ; i += 1 ; k += 1 ; }
while ( j < m ) { res [ k ] = b [ j ] ; j += 1 ; k += 1 ; } }
public static void main ( String [ ] args ) { int a [ ] = { 10 , 5 , 15 } ; int b [ ] = { 20 , 3 , 2 , 12 } ; int n = a . length ; int m = b . length ;
int res [ ] = new int [ n + m ] ; sortedMerge ( a , b , res , n , m ) ; System . out . print ( " Sorted ▁ merged ▁ list ▁ : " ) ; for ( int i = 0 ; i < n + m ; i ++ ) System . out . print ( " ▁ " + res [ i ] ) ; } }
static int findMaxPairs ( int a [ ] , int b [ ] , int n , int k ) {
Arrays . sort ( a ) ;
Arrays . sort ( b ) ;
boolean [ ] flag = new boolean [ n ] ; Arrays . fill ( flag , false ) ;
int result = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( Math . abs ( a [ i ] - b [ j ] ) <= k && flag [ j ] == false ) {
result ++ ;
flag [ j ] = true ;
break ; } } } return result ; }
public static void main ( String args [ ] ) { int [ ] a = { 10 , 15 , 20 } ; int [ ] b = { 17 , 12 , 24 } ; int n = a . length ; int k = 3 ; System . out . println ( findMaxPairs ( a , b , n , k ) ) ; } }
static int findMaxPairs ( int a [ ] , int b [ ] , int n , int k ) {
Arrays . sort ( a ) ;
Arrays . sort ( b ) ; int result = 0 ; for ( int i = 0 , j = 0 ; i < n && j < n ; ) { if ( Math . abs ( a [ i ] - b [ j ] ) <= k ) { result ++ ;
i ++ ; j ++ ; }
else if ( a [ i ] > b [ j ] ) j ++ ;
else i ++ ; } return result ; }
public static void main ( String args [ ] ) { int a [ ] = { 10 , 15 , 20 } ; int b [ ] = { 17 , 12 , 24 } ; int n = a . length ; int k = 3 ; System . out . println ( findMaxPairs ( a , b , n , k ) ) ; } }
static int sumOfMinAbsDifferences ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
int sum = 0 ;
sum += Math . abs ( arr [ 0 ] - arr [ 1 ] ) ;
sum += Math . abs ( arr [ n - 1 ] - arr [ n - 2 ] ) ;
for ( int i = 1 ; i < n - 1 ; i ++ ) sum += Math . min ( Math . abs ( arr [ i ] - arr [ i - 1 ] ) , Math . abs ( arr [ i ] - arr [ i + 1 ] ) ) ;
return sum ; }
public static void main ( String args [ ] ) { int arr [ ] = { 5 , 10 , 1 , 4 , 8 , 7 } ; int n = arr . length ; System . out . println ( " Sum ▁ = ▁ " + sumOfMinAbsDifferences ( arr , n ) ) ; } }
static int findSmallestDifference ( int A [ ] , int B [ ] , int m , int n ) {
Arrays . sort ( A ) ; Arrays . sort ( B ) ; int a = 0 , b = 0 ;
int result = Integer . MAX_VALUE ;
while ( a < m && b < n ) { if ( Math . abs ( A [ a ] - B [ b ] ) < result ) result = Math . abs ( A [ a ] - B [ b ] ) ;
if ( A [ a ] < B [ b ] ) a ++ ; else b ++ ; }
return result ; }
int A [ ] = { 1 , 2 , 11 , 5 } ;
int B [ ] = { 4 , 12 , 19 , 23 , 127 , 235 } ;
int m = A . length ; int n = B . length ;
System . out . println ( findSmallestDifference ( A , B , m , n ) ) ; } }
static int arraySortedOrNot ( int arr [ ] , int n ) {
if ( n == 1 n == 0 ) return 1 ;
if ( arr [ n - 1 ] < arr [ n - 2 ] ) return 0 ;
return arraySortedOrNot ( arr , n - 1 ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 20 , 23 , 23 , 45 , 78 , 88 } ; int n = arr . length ; if ( arraySortedOrNot ( arr , n ) != 0 ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static boolean arraySortedOrNot ( int a [ ] , int n ) {
if ( n == 1 n == 0 ) return true ;
return a [ n - 1 ] >= a [ n - 2 ] && arraySortedOrNot ( a , n - 1 ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 20 , 23 , 23 , 45 , 78 , 88 } ; int n = arr . length ;
if ( arraySortedOrNot ( arr , n ) ) System . out . print ( " Yes " ) ; else System . out . print ( " No " ) ; } }
static boolean arraySortedOrNot ( int arr [ ] , int n ) {
if ( n == 0 n == 1 ) return true ; for ( int i = 1 ; i < n ; i ++ )
if ( arr [ i - 1 ] > arr [ i ] ) return false ;
return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 20 , 23 , 23 , 45 , 78 , 88 } ; int n = arr . length ; if ( arraySortedOrNot ( arr , n ) ) System . out . print ( "YesNEW_LINE"); else System . out . print ( "NoNEW_LINE"); } }
static void findLarger ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
for ( int i = n - 1 ; i >= n / 2 ; i -- ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 6 , 1 , 0 , 9 } ; int n = arr . length ; findLarger ( arr , n ) ; } }
class GFG { static int minSwapsToSort ( int arr [ ] , int n ) {
ArrayList < ArrayList < Integer > > arrPos = new ArrayList < ArrayList < Integer > > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { arrPos . add ( new ArrayList < Integer > ( Arrays . asList ( arr [ i ] , i ) ) ) ; }
Collections . sort ( arrPos , new Comparator < ArrayList < Integer > > ( ) { @ Override public int compare ( ArrayList < Integer > o1 , ArrayList < Integer > o2 ) { return o1 . get ( 0 ) . compareTo ( o2 . get ( 0 ) ) ; } } ) ;
boolean [ ] vis = new boolean [ n ] ;
int ans = 0 ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( vis [ i ] || arrPos . get ( i ) . get ( 1 ) == i ) continue ;
int cycle_size = 0 ; int j = i ; while ( ! vis [ j ] ) { vis [ j ] = true ;
j = arrPos . get ( j ) . get ( 1 ) ; cycle_size ++ ; }
ans += ( cycle_size - 1 ) ; }
return ans ; }
static int minSwapToMakeArraySame ( int a [ ] , int b [ ] , int n ) {
Map < Integer , Integer > mp = new HashMap < Integer , Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { mp . put ( b [ i ] , i ) ; }
for ( int i = 0 ; i < n ; i ++ ) b [ i ] = mp . get ( a [ i ] ) ;
return minSwapsToSort ( b , n ) ; }
public static void main ( String [ ] args ) { int a [ ] = { 3 , 6 , 4 , 8 } ; int b [ ] = { 4 , 6 , 8 , 3 } ; int n = a . length ; System . out . println ( minSwapToMakeArraySame ( a , b , n ) ) ; } }
static int findSingle ( int ar [ ] , int ar_size ) {
int res = ar [ 0 ] ; for ( int i = 1 ; i < ar_size ; i ++ ) res = res ^ ar [ i ] ; return res ; }
public static void main ( String [ ] args ) { int ar [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = ar . length ; System . out . println ( " Element ▁ occurring ▁ once ▁ is ▁ " + findSingle ( ar , n ) + " ▁ " ) ; } }
static int singleNumber ( int [ ] nums , int n ) { HashMap < Integer , Integer > m = new HashMap < > ( ) ; long sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( ! m . containsKey ( nums [ i ] ) ) { sum1 += nums [ i ] ; m . put ( nums [ i ] , 1 ) ; } sum2 += nums [ i ] ; }
return ( int ) ( 2 * ( sum1 ) - sum2 ) ; }
public static void main ( String args [ ] ) { int [ ] a = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int n = 7 ; System . out . println ( singleNumber ( a , n ) ) ; int [ ] b = { 15 , 18 , 16 , 18 , 16 , 15 , 89 } ; System . out . println ( singleNumber ( b , n ) ) ; } }
static int singleelement ( int arr [ ] , int n ) { int low = 0 , high = n - 2 ; int mid ; while ( low <= high ) { mid = ( low + high ) / 2 ; if ( arr [ mid ] == arr [ mid ^ 1 ] ) { low = mid + 1 ; } else { high = mid - 1 ; } } return arr [ low ] ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 3 , 5 , 4 , 5 , 3 , 4 } ; int size = 7 ; Arrays . sort ( arr ) ; System . out . println ( singleelement ( arr , size ) ) ; } }
class Test { static int arr [ ] = new int [ ] { 5 , 1 , 3 , 4 , 7 } ; static int countTriplets ( int n , int sum ) {
int ans = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) {
for ( int j = i + 1 ; j < n - 1 ; j ++ ) {
for ( int k = j + 1 ; k < n ; k ++ ) if ( arr [ i ] + arr [ j ] + arr [ k ] < sum ) ans ++ ; } } return ans ; }
public static void main ( String [ ] args ) { int sum = 12 ; System . out . println ( countTriplets ( arr . length , sum ) ) ; } }
import java . util . Arrays ; class Test { static int arr [ ] = new int [ ] { 5 , 1 , 3 , 4 , 7 } ; static int countTriplets ( int n , int sum ) {
Arrays . sort ( arr ) ;
int ans = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) {
int j = i + 1 , k = n - 1 ;
while ( j < k ) {
if ( arr [ i ] + arr [ j ] + arr [ k ] >= sum ) k -- ;
else {
ans += ( k - j ) ; j ++ ; } } } return ans ; }
public static void main ( String [ ] args ) { int sum = 12 ; System . out . println ( countTriplets ( arr . length , sum ) ) ; } }
static int countTriplets ( int [ ] a , int n ) {
ArrayList < Integer > s = new ArrayList < Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) s . add ( a [ i ] ) ;
int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int xr = a [ i ] ^ a [ j ] ;
if ( s . contains ( xr ) && xr != a [ i ] && xr != a [ j ] ) count ++ ; } }
return count / 3 ; }
public static void main ( String srgs [ ] ) { int [ ] a = { 1 , 3 , 5 , 10 , 14 , 15 } ; int n = a . length ; System . out . print ( countTriplets ( a , n ) ) ; } }
static int getMissingNo ( int a [ ] , int n ) { int total = 1 ; for ( int i = 2 ; i <= ( n + 1 ) ; i ++ ) { total += i ; total -= a [ i - 2 ] ; } return total ; }
public static void main ( String [ ] args ) { int [ ] arr = { 1 , 2 , 3 , 5 } ; System . out . println ( getMissingNo ( arr , arr . length ) ) ; } }
static int getMissingNo ( int a [ ] , int n ) { int n_elements_sum = n * ( n + 1 ) / 2 ; int sum = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) sum += a [ i ] ; return n_elements_sum - sum ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 4 , 5 , 6 } ; int n = a . length + 1 ; int miss = getMissingNo ( a , n ) ; System . out . print ( miss ) ; } }
static int countOccurrences ( int arr [ ] , int n , int x ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( x == arr [ i ] ) res ++ ; return res ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = arr . length ; int x = 2 ; System . out . println ( countOccurrences ( arr , n , x ) ) ; } }
static int binarySearch ( int arr [ ] , int l , int r , int x ) { if ( r < l ) return - 1 ; int mid = l + ( r - l ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
static int countOccurrences ( int arr [ ] , int n , int x ) { int ind = binarySearch ( arr , 0 , n - 1 , x ) ;
if ( ind == - 1 ) return 0 ;
int count = 1 ; int left = ind - 1 ; while ( left >= 0 && arr [ left ] == x ) { count ++ ; left -- ; }
int right = ind + 1 ; while ( right < n && arr [ right ] == x ) { count ++ ; right ++ ; } return count ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 2 , 2 , 2 , 3 , 4 , 7 , 8 , 8 } ; int n = arr . length ; int x = 2 ; System . out . print ( countOccurrences ( arr , n , x ) ) ; } }
static void printClosest ( int arr [ ] , int n , int x ) {
int res_l = 0 , res_r = 0 ;
int l = 0 , r = n - 1 , diff = Integer . MAX_VALUE ;
while ( r > l ) {
if ( Math . abs ( arr [ l ] + arr [ r ] - x ) < diff ) { res_l = l ; res_r = r ; diff = Math . abs ( arr [ l ] + arr [ r ] - x ) ; }
if ( arr [ l ] + arr [ r ] > x ) r -- ;
else l ++ ; } System . out . println ( " ▁ The ▁ closest ▁ pair ▁ is ▁ " + arr [ res_l ] + " ▁ and ▁ " + arr [ res_r ] ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 10 , 22 , 28 , 29 , 30 , 40 } , x = 54 ; int n = arr . length ; printClosest ( arr , n , x ) ; } }
static void constructTree ( int n , int d , int h ) { if ( d == 1 ) {
if ( n == 2 && h == 1 ) { System . out . println ( "1 ▁ 2" ) ; return ; }
System . out . println ( " - 1" ) ; return ; } if ( d > 2 * h ) { System . out . println ( " - 1" ) ; return ; }
for ( int i = 1 ; i <= h ; i ++ ) System . out . println ( i + " ▁ " + ( i + 1 ) ) ; if ( d > h ) {
System . out . println ( "1" + " ▁ " + ( h + 2 ) ) ; for ( int i = h + 2 ; i <= d ; i ++ ) { System . out . println ( i + " ▁ " + ( i + 1 ) ) ; } }
for ( int i = d + 1 ; i < n ; i ++ ) { int k = 1 ; if ( d == h ) k = 2 ; System . out . println ( k + " ▁ " + ( i + 1 ) ) ; } }
public static void main ( String [ ] args ) { int n = 5 , d = 3 , h = 2 ; constructTree ( n , d , h ) ; } }
int countOnes ( int arr [ ] , int low , int high ) { if ( high >= low ) {
int mid = low + ( high - low ) / 2 ;
if ( ( mid == high arr [ mid + 1 ] == 0 ) && ( arr [ mid ] == 1 ) ) return mid + 1 ;
if ( arr [ mid ] == 1 ) return countOnes ( arr , ( mid + 1 ) , high ) ;
return countOnes ( arr , low , ( mid - 1 ) ) ; } return 0 ; }
public static void main ( String args [ ] ) { CountOnes ob = new CountOnes ( ) ; int arr [ ] = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = arr . length ; System . out . println ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " + ob . countOnes ( arr , 0 , n - 1 ) ) ; } }
static int countOnes ( int arr [ ] , int n ) { int ans ; int low = 0 , high = n - 1 ;
while ( low <= high ) { int mid = ( low + high ) / 2 ;
if ( arr [ mid ] < 1 ) high = mid - 1 ;
else if ( arr [ mid ] > 1 ) low = mid + 1 ; else
{ if ( mid == n - 1 arr [ mid + 1 ] != 1 ) return mid + 1 ; else low = mid + 1 ; } } return 0 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 1 , 1 , 1 , 0 , 0 , 0 } ; int n = arr . length ; System . out . println ( " Count ▁ of ▁ 1 ' s ▁ in ▁ given ▁ array ▁ is ▁ " + countOnes ( arr , n ) ) ; } }
int findMissingUtil ( int arr1 [ ] , int arr2 [ ] , int N ) {
if ( N == 1 ) return arr1 [ 0 ] ;
if ( arr1 [ 0 ] != arr2 [ 0 ] ) return arr1 [ 0 ] ;
int lo = 0 , hi = N - 1 ;
while ( lo < hi ) { int mid = ( lo + hi ) / 2 ;
if ( arr1 [ mid ] == arr2 [ mid ] ) lo = mid ; else hi = mid ;
if ( lo == hi - 1 ) break ; }
return arr1 [ hi ] ; }
void findMissing ( int arr1 [ ] , int arr2 [ ] , int M , int N ) { if ( N == M - 1 ) System . out . println ( " Missing ▁ Element ▁ is ▁ " + findMissingUtil ( arr1 , arr2 , M ) + "NEW_LINE"); else if ( M == N - 1 ) System . out . println ( " Missing ▁ Element ▁ is ▁ " + findMissingUtil ( arr2 , arr1 , N ) + "NEW_LINE"); else System . out . println ( " Invalid ▁ Input " ) ; }
public static void main ( String args [ ] ) { MissingNumber obj = new MissingNumber ( ) ; int arr1 [ ] = { 1 , 4 , 5 , 7 , 9 } ; int arr2 [ ] = { 4 , 5 , 7 , 9 } ; int M = arr1 . length ; int N = arr2 . length ; obj . findMissing ( arr1 , arr2 , M , N ) ; } }
void findMissing ( int arr1 [ ] , int arr2 [ ] , int M , int N ) { if ( M != N - 1 && N != M - 1 ) { System . out . println ( " Invalid ▁ Input " ) ; return ; }
int res = 0 ; for ( int i = 0 ; i < M ; i ++ ) res = res ^ arr1 [ i ] ; for ( int i = 0 ; i < N ; i ++ ) res = res ^ arr2 [ i ] ; System . out . println ( " Missing ▁ element ▁ is ▁ " + res ) ; }
public static void main ( String args [ ] ) { Missing obj = new Missing ( ) ; int arr1 [ ] = { 4 , 1 , 5 , 9 , 7 } ; int arr2 [ ] = { 7 , 5 , 9 , 4 } ; int M = arr1 . length ; int N = arr2 . length ; obj . findMissing ( arr1 , arr2 , M , N ) ; } }
static void findFourElements ( int arr [ ] , int n , int X ) {
HashMap < Integer , pair > mp = new HashMap < Integer , pair > ( ) ; for ( int i = 0 ; i < n - 1 ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) mp . put ( arr [ i ] + arr [ j ] , new pair ( i , j ) ) ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) { int sum = arr [ i ] + arr [ j ] ;
if ( mp . containsKey ( X - sum ) ) {
pair p = mp . get ( X - sum ) ; if ( p . first != i && p . first != j && p . second != i && p . second != j ) { System . out . print ( arr [ i ] + " , ▁ " + arr [ j ] + " , ▁ " + arr [ p . first ] + " , ▁ " + arr [ p . second ] ) ; return ; } } } } }
public static void main ( String [ ] args ) { int arr [ ] = { 10 , 20 , 30 , 40 , 1 , 2 } ; int n = arr . length ; int X = 91 ;
findFourElements ( arr , n , X ) ; } }
import java . util . * ; class fourElementWithSum {
public static void fourSum ( int X , int [ ] arr , Map < Integer , pair > map ) { int [ ] temp = new int [ arr . length ] ;
for ( int i = 0 ; i < temp . length ; i ++ ) temp [ i ] = 0 ;
for ( int i = 0 ; i < arr . length - 1 ; i ++ ) {
for ( int j = i + 1 ; j < arr . length ; j ++ ) {
int curr_sum = arr [ i ] + arr [ j ] ;
if ( map . containsKey ( X - curr_sum ) ) {
pair p = map . get ( X - curr_sum ) ; if ( p . first != i && p . sec != i && p . first != j && p . sec != j && temp [ p . first ] == 0 && temp [ p . sec ] == 0 && temp [ i ] == 0 && temp [ j ] == 0 ) {
System . out . printf ( " % d , % d , % d , % d " , arr [ i ] , arr [ j ] , arr [ p . first ] , arr [ p . sec ] ) ; temp [ p . sec ] = 1 ; temp [ i ] = 1 ; temp [ j ] = 1 ; break ; } } } } }
public static Map < Integer , pair > twoSum ( int [ ] nums ) { Map < Integer , pair > map = new HashMap < > ( ) ; for ( int i = 0 ; i < nums . length - 1 ; i ++ ) { for ( int j = i + 1 ; j < nums . length ; j ++ ) { map . put ( nums [ i ] + nums [ j ] , new pair ( i , j ) ) ; } } return map ; }
public static void main ( String args [ ] ) { int [ ] arr = { 10 , 20 , 30 , 40 , 1 , 2 } ; int n = arr . length ; int X = 91 ; Map < Integer , pair > map = twoSum ( arr ) ;
fourSum ( X , arr , map ) ; } }
static int search ( int arr [ ] , int n , int x ) {
int i = 0 ; while ( i < n ) {
if ( arr [ i ] == x ) return i ;
i = i + Math . abs ( arr [ i ] - x ) ; } System . out . println ( " number ▁ is ▁ not " + " ▁ present ! " ) ; return - 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 8 , 7 , 6 , 7 , 6 , 5 , 4 , 3 , 2 , 3 , 4 , 3 } ; int n = arr . length ; int x = 3 ; System . out . println ( " Element ▁ " + x + " ▁ is ▁ present ▁ at ▁ index ▁ " + search ( arr , n , 3 ) ) ; } }
class GFG { static void thirdLargest ( int arr [ ] , int arr_size ) {
if ( arr_size < 3 ) { System . out . printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] ; for ( int i = 1 ; i < arr_size ; i ++ ) if ( arr [ i ] > first ) first = arr [ i ] ;
int second = Integer . MIN_VALUE ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > second && arr [ i ] < first ) second = arr [ i ] ;
int third = Integer . MIN_VALUE ; for ( int i = 0 ; i < arr_size ; i ++ ) if ( arr [ i ] > third && arr [ i ] < second ) third = arr [ i ] ; System . out . printf ( " The ▁ third ▁ Largest ▁ " + "element is %dNEW_LINE", third); }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = arr . length ; thirdLargest ( arr , n ) ; } }
class GFG { static void thirdLargest ( int arr [ ] , int arr_size ) {
if ( arr_size < 3 ) { System . out . printf ( " ▁ Invalid ▁ Input ▁ " ) ; return ; }
int first = arr [ 0 ] , second = Integer . MIN_VALUE , third = Integer . MIN_VALUE ;
for ( int i = 1 ; i < arr_size ; i ++ ) {
if ( arr [ i ] > first ) { third = second ; second = first ; first = arr [ i ] ; }
else if ( arr [ i ] > second ) { third = second ; second = arr [ i ] ; }
else if ( arr [ i ] > third ) { third = arr [ i ] ; } } System . out . printf ( "The third Largest element is %dNEW_LINE", third); }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 13 , 1 , 10 , 34 , 16 } ; int n = arr . length ; thirdLargest ( arr , n ) ; } }
static boolean checkPair ( int arr [ ] , int n ) {
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum += arr [ i ] ; }
if ( sum % 2 != 0 ) { return false ; } sum = sum / 2 ;
HashSet < Integer > s = new HashSet < Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { int val = sum - arr [ i ] ;
if ( s . contains ( val ) && val == ( int ) s . toArray ( ) [ s . size ( ) - 1 ] ) { System . out . printf ( "Pair elements are %d and %dNEW_LINE", arr[i], val); return true ; } s . add ( arr [ i ] ) ; } return false ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 11 , 5 , 1 , 4 , 7 } ; int n = arr . length ; if ( checkPair ( arr , n ) == false ) { System . out . printf ( " No ▁ pair ▁ found " ) ; } } }
static String search ( int arr [ ] , int n , int x ) {
if ( arr [ n - 1 ] == x ) return " Found " ; int backup = arr [ n - 1 ] ; arr [ n - 1 ] = x ;
for ( int i = 0 ; ; i ++ ) {
if ( arr [ i ] == x ) {
arr [ n - 1 ] = backup ;
if ( i < n - 1 ) return " Found " ;
return " Not ▁ Found " ; } } }
public static void main ( String [ ] args ) { int arr [ ] = { 4 , 6 , 1 , 5 , 8 } ; int n = arr . length ; int x = 1 ; System . out . println ( search ( arr , n , x ) ) ; } }
static Point sequence ( Vector < Integer > a ) { if ( a . size ( ) == 0 ) return new Point ( 0 , 0 ) ; int s = 0 ; int e = a . size ( ) - 1 ; while ( s < e ) { int m = ( s + e ) / 2 ;
if ( a . get ( m ) >= m + a . get ( 0 ) ) s = m + 1 ;
else e = m ; } return new Point ( a . get ( s ) , a . size ( ) - ( a . get ( a . size ( ) - 1 ) - a . get ( 0 ) ) ) ; }
public static void main ( String args [ ] ) { Integer array [ ] = new Integer [ ] { 1 , 2 , 3 , 4 , 4 , 4 , 5 , 6 } ; Point p = sequence ( new Vector < > ( Arrays . asList ( array ) ) ) ; System . out . println ( " Repeated ▁ element ▁ is ▁ " + p . x + " , ▁ it ▁ appears ▁ " + p . y + " ▁ times " ) ; } }
public class Test { public static int findMajority ( int arr [ ] , int n ) { return arr [ n / 2 ] ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 2 , 2 , 3 } ; int n = arr . length ; System . out . println ( findMajority ( arr , n ) ) ; } }
class GFG { static void minAdjDifference ( int arr [ ] , int n ) { if ( n < 2 ) return ;
int res = Math . abs ( arr [ 1 ] - arr [ 0 ] ) ; for ( int i = 2 ; i < n ; i ++ ) res = Math . min ( res , Math . abs ( arr [ i ] - arr [ i - 1 ] ) ) ;
res = Math . min ( res , Math . abs ( arr [ n - 1 ] - arr [ 0 ] ) ) ; System . out . print ( " Min ▁ Difference ▁ = ▁ " + res ) ; }
public static void main ( String arg [ ] ) { int a [ ] = { 10 , 12 , 13 , 15 , 10 } ; int n = a . length ; minAdjDifference ( a , n ) ; } }
import java . util . * ; public class GFG { static void Print3Smallest ( int array [ ] , int n ) { int firstmin = Integer . MAX_VALUE ; int secmin = Integer . MAX_VALUE ; int thirdmin = Integer . MAX_VALUE ; for ( int i = 0 ; i < n ; i ++ ) {
if ( array [ i ] < firstmin ) { thirdmin = secmin ; secmin = firstmin ; firstmin = array [ i ] ; }
else if ( array [ i ] < secmin ) { thirdmin = secmin ; secmin = array [ i ] ; }
else if ( array [ i ] < thirdmin ) thirdmin = array [ i ] ; } System . out . println ( " First ▁ min ▁ = ▁ " + firstmin ) ; System . out . println ( " Second ▁ min ▁ = ▁ " + secmin ) ; System . out . println ( " Third ▁ min ▁ = ▁ " + thirdmin ) ; }
public static void main ( String [ ] args ) { int array [ ] = { 4 , 9 , 1 , 32 , 12 } ; int n = array . length ; Print3Smallest ( array , n ) ; } }
class GFG { static int getMin ( int arr [ ] , int i , int n ) {
return ( n == 1 ) ? arr [ i ] : Math . min ( arr [ i ] , getMin ( arr , i + 1 , n - 1 ) ) ; } static int getMax ( int arr [ ] , int i , int n ) {
return ( n == 1 ) ? arr [ i ] : Math . max ( arr [ i ] , getMax ( arr , i + 1 , n - 1 ) ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 1234 , 45 , 67 , 1 } ; int n = arr . length ; System . out . print ( " Minimum ▁ element ▁ of ▁ array : ▁ " + getMin ( arr , 0 , n ) + "NEW_LINE"); System . out . println ( " Maximum ▁ element ▁ of ▁ array : ▁ " + getMax ( arr , 0 , n ) ) ; } }
import java . util . Arrays ; class GFG { static int getMin ( int arr [ ] , int n ) { return Arrays . stream ( arr ) . min ( ) . getAsInt ( ) ; } static int getMax ( int arr [ ] , int n ) { return Arrays . stream ( arr ) . max ( ) . getAsInt ( ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 12 , 1234 , 45 , 67 , 1 } ; int n = arr . length ; System . out . println ( " Minimum ▁ element ▁ of ▁ array : ▁ " + getMin ( arr , n ) ) ; System . out . println ( " Maximum ▁ element ▁ of ▁ array : ▁ " + getMax ( arr , n ) ) ; } }
public static void findCounts ( int arr [ ] , int n ) {
int hash [ ] = new int [ n ] ; Arrays . fill ( hash , 0 ) ;
int i = 0 ; while ( i < n ) {
hash [ arr [ i ] - 1 ] ++ ;
i ++ ; } System . out . println ( " Below are counts " ▁ + ▁ " of all elements "); for ( i = 0 ; i < n ; i ++ ) { System . out . println ( ( i + 1 ) + " ▁ - > ▁ " + hash [ i ] ) ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 3 , 3 , 2 , 5 } ; findCounts ( arr , arr . length ) ; int arr1 [ ] = { 1 } ; findCounts ( arr1 , arr1 . length ) ; int arr3 [ ] = { 4 , 4 , 4 , 4 } ; findCounts ( arr3 , arr3 . length ) ; int arr2 [ ] = { 1 , 3 , 5 , 7 , 9 , 1 , 3 , 5 , 7 , 9 , 1 } ; findCounts ( arr2 , arr2 . length ) ; int arr4 [ ] = { 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 } ; findCounts ( arr4 , arr4 . length ) ; int arr5 [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 } ; findCounts ( arr5 , arr5 . length ) ; int arr6 [ ] = { 11 , 10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 } ; findCounts ( arr6 , arr6 . length ) ; } }
void findCounts ( int arr [ ] , int n ) {
int i = 0 ; while ( i < n ) {
if ( arr [ i ] <= 0 ) { i ++ ; continue ; }
int elementIndex = arr [ i ] - 1 ;
if ( arr [ elementIndex ] > 0 ) { arr [ i ] = arr [ elementIndex ] ;
arr [ elementIndex ] = - 1 ; } else {
arr [ elementIndex ] -- ;
arr [ i ] = 0 ; i ++ ; } } System . out . println ( " Below ▁ are ▁ counts ▁ of ▁ all ▁ elements " ) ; for ( int j = 0 ; j < n ; j ++ ) System . out . println ( j + 1 + " - > " + Math . abs ( arr [ j ] ) ) ; }
public static void main ( String [ ] args ) { CountFrequencies count = new CountFrequencies ( ) ; int arr [ ] = { 2 , 3 , 3 , 2 , 5 } ; count . findCounts ( arr , arr . length ) ; int arr1 [ ] = { 1 } ; count . findCounts ( arr1 , arr1 . length ) ; int arr3 [ ] = { 4 , 4 , 4 , 4 } ; count . findCounts ( arr3 , arr3 . length ) ; int arr2 [ ] = { 1 , 3 , 5 , 7 , 9 , 1 , 3 , 5 , 7 , 9 , 1 } ; count . findCounts ( arr2 , arr2 . length ) ; int arr4 [ ] = { 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 } ; count . findCounts ( arr4 , arr4 . length ) ; int arr5 [ ] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 } ; count . findCounts ( arr5 , arr5 . length ) ; int arr6 [ ] = { 11 , 10 , 9 , 8 , 7 , 6 , 5 , 4 , 3 , 2 , 1 } ; count . findCounts ( arr6 , arr6 . length ) ; } }
void printfrequency ( int arr [ ] , int n ) {
for ( int j = 0 ; j < n ; j ++ ) arr [ j ] = arr [ j ] - 1 ;
for ( int i = 0 ; i < n ; i ++ ) arr [ arr [ i ] % n ] = arr [ arr [ i ] % n ] + n ;
for ( int i = 0 ; i < n ; i ++ ) System . out . println ( i + 1 + " - > " + arr [ i ] / n ) ; }
public static void main ( String [ ] args ) { CountFrequency count = new CountFrequency ( ) ; int arr [ ] = { 2 , 3 , 3 , 2 , 5 } ; int n = arr . length ; count . printfrequency ( arr , n ) ; } }
static int deleteElement ( int arr [ ] , int n , int x ) {
int i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == x ) break ;
if ( i < n ) {
n = n - 1 ; for ( int j = i ; j < n ; j ++ ) arr [ j ] = arr [ j + 1 ] ; } return n ; }
public static void main ( String [ ] args ) { int arr [ ] = { 11 , 15 , 6 , 8 , 9 , 10 } ; int n = arr . length ; int x = 6 ;
n = deleteElement ( arr , n , x ) ; System . out . println ( " Modified ▁ array ▁ is " ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
static int deleteElement ( int arr [ ] , int n , int x ) {
if ( arr [ n - 1 ] == x ) return ( n - 1 ) ;
int prev = arr [ n - 1 ] , i ; for ( i = n - 2 ; i >= 0 && arr [ i ] != x ; i -- ) { int curr = arr [ i ] ; arr [ i ] = prev ; prev = curr ; }
if ( i < 0 ) return 0 ;
arr [ i ] = prev ; return ( n - 1 ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 11 , 15 , 6 , 8 , 9 , 10 } ; int n = arr . length ; int x = 6 ;
n = deleteElement ( arr , n , x ) ; System . out . println ( " Modified ▁ array ▁ is " ) ; for ( int i = 0 ; i < n ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
int getInvCount ( int arr [ ] , int n ) {
int invcount = 0 ; for ( int i = 0 ; i < n - 1 ; i ++ ) {
int small = 0 ; for ( int j = i + 1 ; j < n ; j ++ ) if ( arr [ i ] > arr [ j ] ) small ++ ;
int great = 0 ; for ( int j = i - 1 ; j >= 0 ; j -- ) if ( arr [ i ] < arr [ j ] ) great ++ ;
invcount += great * small ; } return invcount ; }
public static void main ( String args [ ] ) { Inversion inversion = new Inversion ( ) ; int arr [ ] = new int [ ] { 8 , 4 , 2 , 1 } ; int n = arr . length ; System . out . print ( " Inversion ▁ count ▁ : ▁ " + inversion . getInvCount ( arr , n ) ) ; } }
public static int maxWater ( int [ ] arr , int n ) {
int res = 0 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
int left = arr [ i ] ; for ( int j = 0 ; j < i ; j ++ ) { left = Math . max ( left , arr [ j ] ) ; }
int right = arr [ i ] ; for ( int j = i + 1 ; j < n ; j ++ ) { right = Math . max ( right , arr [ j ] ) ; }
res += Math . min ( left , right ) - arr [ i ] ; } return res ; }
public static void main ( String [ ] args ) { int [ ] arr = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = arr . length ; System . out . print ( maxWater ( arr , n ) ) ; } }
class Test { static int arr [ ] = new int [ ] { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ;
static int findWater ( int n ) {
int left [ ] = new int [ n ] ;
int right [ ] = new int [ n ] ;
int water = 0 ;
left [ 0 ] = arr [ 0 ] ; for ( int i = 1 ; i < n ; i ++ ) left [ i ] = Math . max ( left [ i - 1 ] , arr [ i ] ) ;
right [ n - 1 ] = arr [ n - 1 ] ; for ( int i = n - 2 ; i >= 0 ; i -- ) right [ i ] = Math . max ( right [ i + 1 ] , arr [ i ] ) ;
for ( int i = 0 ; i < n ; i ++ ) water += Math . min ( left [ i ] , right [ i ] ) - arr [ i ] ; return water ; }
public static void main ( String [ ] args ) { System . out . println ( " Maximum ▁ water ▁ that ▁ can ▁ be ▁ accumulated ▁ is ▁ " + findWater ( arr . length ) ) ; } }
import java . util . * ; class GFG { static int findWater ( int arr [ ] , int n ) {
int result = 0 ;
int left_max = 0 , right_max = 0 ;
int lo = 0 , hi = n - 1 ; while ( lo <= hi ) { if ( arr [ lo ] < arr [ hi ] ) { if ( arr [ lo ] > left_max )
left_max = arr [ lo ] ; else
result += left_max - arr [ lo ] ; lo ++ ; } else { if ( arr [ hi ] > right_max )
right_max = arr [ hi ] ; else result += right_max - arr [ hi ] ; hi -- ; } } return result ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = arr . length ; System . out . println ( " Maximum ▁ water ▁ that ▁ " + " can ▁ be ▁ accumulated ▁ is ▁ " + findWater ( arr , n ) ) ; } }
public static int maxWater ( int arr [ ] , int n ) { int size = n - 1 ;
int prev = arr [ 0 ] ;
int prev_index = 0 ; int water = 0 ;
int temp = 0 ; for ( int i = 1 ; i <= size ; i ++ ) {
if ( arr [ i ] >= prev ) { prev = arr [ i ] ; prev_index = i ;
temp = 0 ; } else {
water += prev - arr [ i ] ;
temp += prev - arr [ i ] ; } }
if ( prev_index < size ) {
water -= temp ;
prev = arr [ size ] ;
for ( int i = size ; i >= prev_index ; i -- ) {
if ( arr [ i ] >= prev ) { prev = arr [ i ] ; } else { water += prev - arr [ i ] ; } } }
return water ; }
public static void main ( String [ ] args ) { int arr [ ] = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = arr . length ; System . out . print ( maxWater ( arr , n ) ) ; } }
import java . util . * ; class GFG { static int maxWater ( int [ ] arr , int n ) {
int left = 0 ; int right = n - 1 ;
int l_max = 0 ; int r_max = 0 ;
int result = 0 ; while ( left <= right ) {
if ( r_max <= l_max ) {
result += Math . max ( 0 , r_max - arr [ right ] ) ;
r_max = Math . max ( r_max , arr [ right ] ) ;
right -= 1 ; } else {
result += Math . max ( 0 , l_max - arr [ left ] ) ;
l_max = Math . max ( l_max , arr [ left ] ) ;
left += 1 ; } } return result ; }
public static void main ( String [ ] args ) { int [ ] arr = { 0 , 1 , 0 , 2 , 1 , 0 , 1 , 3 , 2 , 1 , 2 , 1 } ; int n = arr . length ; System . out . print ( maxWater ( arr , n ) ) ; } }
static int missingK ( int [ ] a , int k , int n ) { int difference = 0 , ans = 0 , count = k ; boolean flag = false ;
for ( int i = 0 ; i < n - 1 ; i ++ ) { difference = 0 ;
if ( ( a [ i ] + 1 ) != a [ i + 1 ] ) {
difference += ( a [ i + 1 ] - a [ i ] ) - 1 ;
if ( difference >= count ) { ans = a [ i ] + count ; flag = true ; break ; } else count -= difference ; } }
if ( flag ) return ans ; else return - 1 ; }
int [ ] a = { 1 , 5 , 11 , 19 } ;
int k = 11 ; int n = a . length ;
int missing = missingK ( a , k , n ) ; System . out . print ( missing ) ; } }
import java . io . * ; class GFG { static int [ ] a = new int [ ] { 900 } ; static int [ ] b = new int [ ] { 10 , 13 , 14 } ;
static int maximum ( int a , int b ) { return a > b ? a : b ; }
static int minimum ( int a , int b ) { return a < b ? a : b ; }
static double findMedianSortedArrays ( int n , int m ) { int min_index = 0 , max_index = n , i = 0 , j = 0 , median = 0 ; while ( min_index <= max_index ) { i = ( min_index + max_index ) / 2 ; j = ( ( n + m + 1 ) / 2 ) - i ;
if ( i < n && j > 0 && b [ j - 1 ] > a [ i ] ) min_index = i + 1 ;
else if ( i > 0 && j < m && b [ j ] < a [ i - 1 ] ) max_index = i - 1 ;
else {
if ( i == 0 ) median = b [ j - 1 ] ;
else if ( j == 0 ) median = a [ i - 1 ] ; else median = maximum ( a [ i - 1 ] , b [ j - 1 ] ) ; break ; } }
if ( ( n + m ) % 2 == 1 ) return ( double ) median ;
if ( i == n ) return ( median + b [ j ] ) / 2.0 ;
if ( j == m ) return ( median + a [ i ] ) / 2.0 ; return ( median + minimum ( a [ i ] , b [ j ] ) ) / 2.0 ; }
public static void main ( String args [ ] ) { int n = a . length ; int m = b . length ;
if ( n < m ) System . out . print ( " The ▁ median ▁ is ▁ : ▁ " + findMedianSortedArrays ( n , m ) ) ; else System . out . print ( " The ▁ median ▁ is ▁ : ▁ " + findMedianSortedArrays ( m , n ) ) ; } }
import java . io . * ; class GFG { static void printUncommon ( int arr1 [ ] , int arr2 [ ] , int n1 , int n2 ) { int i = 0 , j = 0 , k = 0 ; while ( i < n1 && j < n2 ) {
if ( arr1 [ i ] < arr2 [ j ] ) { System . out . print ( arr1 [ i ] + " ▁ " ) ; i ++ ; k ++ ; } else if ( arr2 [ j ] < arr1 [ i ] ) { System . out . print ( arr2 [ j ] + " ▁ " ) ; k ++ ; j ++ ; }
else { i ++ ; j ++ ; } }
while ( i < n1 ) { System . out . print ( arr1 [ i ] + " ▁ " ) ; i ++ ; k ++ ; } while ( j < n2 ) { System . out . print ( arr2 [ j ] + " ▁ " ) ; j ++ ; k ++ ; } }
public static void main ( String [ ] args ) { int arr1 [ ] = { 10 , 20 , 30 } ; int arr2 [ ] = { 20 , 25 , 30 , 40 , 50 } ; int n1 = arr1 . length ; int n2 = arr2 . length ; printUncommon ( arr1 , arr2 , n1 , n2 ) ; } }
import java . io . * ; import java . util . * ; class GFG { static int leastFrequent ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
int min_count = n + 1 , res = - 1 ; int curr_count = 1 ; for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ; else { if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ i - 1 ] ; } curr_count = 1 ; } }
if ( curr_count < min_count ) { min_count = curr_count ; res = arr [ n - 1 ] ; } return res ; }
public static void main ( String args [ ] ) { int arr [ ] = { 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 } ; int n = arr . length ; System . out . print ( leastFrequent ( arr , n ) ) ; } }
import java . util . HashMap ; import java . util . Map ; import java . util . Map . Entry ; class GFG { static int leastFrequent ( int arr [ ] , int n ) {
Map < Integer , Integer > count = new HashMap < Integer , Integer > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { int key = arr [ i ] ; if ( count . containsKey ( key ) ) { int freq = count . get ( key ) ; freq ++ ; count . put ( key , freq ) ; } else count . put ( key , 1 ) ; }
int min_count = n + 1 , res = - 1 ; for ( Entry < Integer , Integer > val : count . entrySet ( ) ) { if ( min_count >= val . getValue ( ) ) { res = val . getKey ( ) ; min_count = val . getValue ( ) ; } } return res ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 3 , 2 , 1 , 2 , 2 , 3 , 1 } ; int n = arr . length ; System . out . println ( leastFrequent ( arr , n ) ) ; } }
import java . io . * ; class GFG { static int M = 4 ; static int arr [ ] [ ] = { { 1 , 7 , 3 , 4 } , { 4 , 2 , 5 , 1 } , { 9 , 5 , 1 , 8 } } ; static void sort ( int a [ ] [ ] , int row , int n ) { for ( int i = 0 ; i < M - 1 ; i ++ ) { if ( a [ row ] [ i ] > a [ row ] [ i + 1 ] ) { int temp = a [ row ] [ i ] ; a [ row ] [ i ] = a [ row ] [ i + 1 ] ; a [ row ] [ i + 1 ] = temp ; } } }
static int maximumSum ( int a [ ] [ ] , int n ) {
int sum = a [ n - 1 ] [ M - 1 ] ; int prev = a [ n - 1 ] [ M - 1 ] ; int i , j ;
for ( i = n - 2 ; i >= 0 ; i -- ) { for ( j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i ] [ j ] < prev ) { prev = a [ i ] [ j ] ; sum += prev ; break ; } }
if ( j == - 1 ) return 0 ; } return sum ; }
public static void main ( String args [ ] ) { int n = arr . length ; System . out . print ( maximumSum ( arr , n ) ) ; } }
import java . util . * ; class GFG { static int M = 4 ;
static int maximumSum ( int a [ ] [ ] , int n ) {
int prev = Math . max ( a [ n - 1 ] [ 0 ] , a [ n - 1 ] [ M - 1 ] + 1 ) ;
int sum = prev ; for ( int i = n - 2 ; i >= 0 ; i -- ) { int max_smaller = Integer . MIN_VALUE ; for ( int j = M - 1 ; j >= 0 ; j -- ) { if ( a [ i ] [ j ] < prev && a [ i ] [ j ] > max_smaller ) max_smaller = a [ i ] [ j ] ; }
if ( max_smaller == Integer . MIN_VALUE ) return 0 ; prev = max_smaller ; sum += max_smaller ; } return sum ; }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 1 , 7 , 3 , 4 } , { 4 , 2 , 5 , 1 } , { 9 , 5 , 1 , 8 } } ; int n = arr . length ; System . out . print ( maximumSum ( arr , n ) ) ; } }
static int countPairs ( int A [ ] , int n , int k ) { int ans = 0 ;
Arrays . sort ( A ) ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = i + 1 ; j < n ; j ++ ) {
int x = 0 ;
while ( ( A [ i ] * Math . pow ( k , x ) ) <= A [ j ] ) { if ( ( A [ i ] * Math . pow ( k , x ) ) == A [ j ] ) { ans ++ ; break ; } x ++ ; } } } return ans ; }
public static void main ( String [ ] args ) { int A [ ] = { 3 , 8 , 9 , 12 , 18 , 4 , 24 , 2 , 6 } ; int n = A . length ; int k = 3 ; System . out . println ( countPairs ( A , n , k ) ) ; } }
static int minDistance ( int arr [ ] , int n ) { int maximum_element = arr [ 0 ] ; int min_dis = n ; int index = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
if ( maximum_element == arr [ i ] ) { min_dis = Math . min ( min_dis , ( i - index ) ) ; index = i ; }
else if ( maximum_element < arr [ i ] ) { maximum_element = arr [ i ] ; min_dis = n ; index = i ; }
else continue ; } return min_dis ; }
public static void main ( String [ ] args ) { int arr [ ] = { 6 , 3 , 1 , 3 , 6 , 4 , 6 } ; int n = arr . length ; System . out . print ( " Minimum ▁ distance ▁ = ▁ " + minDistance ( arr , n ) ) ; } }
static int findValue ( int arr [ ] , int n , int k ) {
for ( int i = 0 ; i < n ; i ++ ) if ( arr [ i ] == k ) k *= 2 ; return k ; }
public static void main ( String [ ] args ) { int arr [ ] = { 2 , 3 , 4 , 10 , 8 , 1 } , k = 2 ; int n = arr . length ; System . out . print ( findValue ( arr , n , k ) ) ; } }
import java . io . * ; class GFG { static void dupLastIndex ( int arr [ ] , int n ) {
if ( arr == null n <= 0 ) return ;
for ( int i = n - 1 ; i > 0 ; i -- ) { if ( arr [ i ] == arr [ i - 1 ] ) { System . out . println ( " Last ▁ index : " + i ) ; System . out . println ( " Last ▁ duplicate ▁ item : ▁ " + arr [ i ] ) ; return ; } }
System . out . print ( " no ▁ duplicate ▁ found " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 5 , 5 , 6 , 6 , 7 , 9 } ; int n = arr . length ; dupLastIndex ( arr , n ) ; } }
static int findSmallest ( int a [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int j ; for ( j = 0 ; j < n ; j ++ ) if ( a [ j ] % a [ i ] >= 1 ) break ;
if ( j == n ) return a [ i ] ; } return - 1 ; }
public static void main ( String args [ ] ) { int a [ ] = { 25 , 20 , 5 , 10 , 100 } ; int n = a . length ; System . out . println ( findSmallest ( a , n ) ) ; } }
static int min_element ( int a [ ] ) { int min = Integer . MAX_VALUE , i ; for ( i = 0 ; i < a . length ; i ++ ) { if ( a [ i ] < min ) min = a [ i ] ; } return min ; }
static int findSmallest ( int a [ ] , int n ) {
int smallest = min_element ( a ) ;
for ( int i = 1 ; i < n ; i ++ ) if ( a [ i ] % smallest >= 1 ) return - 1 ; return smallest ; }
public static void main ( String args [ ] ) { int a [ ] = { 25 , 20 , 5 , 10 , 100 } ; int n = a . length ; System . out . println ( findSmallest ( a , n ) ) ; } }
public static void printMax ( int arr [ ] , int k , int n ) {
Integer [ ] brr = new Integer [ n ] ; for ( int i = 0 ; i < n ; i ++ ) brr [ i ] = arr [ i ] ;
Arrays . sort ( brr , Collections . reverseOrder ( ) ) ;
for ( int i = 0 ; i < n ; ++ i ) if ( Arrays . binarySearch ( brr , arr [ i ] , Collections . reverseOrder ( ) ) >= 0 && Arrays . binarySearch ( brr , arr [ i ] , Collections . reverseOrder ( ) ) < k ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 50 , 8 , 45 , 12 , 25 , 40 , 84 } ; int n = arr . length ; int k = 3 ; printMax ( arr , k , n ) ; } }
public static int findIndex ( int [ ] arr ) {
int maxIndex = 0 ; for ( int i = 0 ; i < arr . length ; ++ i ) if ( arr [ i ] > arr [ maxIndex ] ) maxIndex = i ;
for ( int i = 0 ; i < arr . length ; ++ i ) if ( maxIndex != i && arr [ maxIndex ] < 2 * arr [ i ] ) return - 1 ; return maxIndex ; }
public static void main ( String argc [ ] ) { int [ ] arr = new int [ ] { 3 , 6 , 1 , 0 } ; System . out . println ( findIndex ( arr ) ) ; } }
static int find_consecutive_steps ( int arr [ ] , int len ) { int count = 0 ; int maximum = 0 ; for ( int index = 1 ; index < len ; index ++ ) {
if ( arr [ index ] > arr [ index - 1 ] ) count ++ ; else { maximum = Math . max ( maximum , count ) ; count = 0 ; } } return Math . max ( maximum , count ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 } ; int len = arr . length ; System . out . println ( find_consecutive_steps ( arr , len ) ) ; } }
import java . util . Arrays ; import java . io . * ; class GFG { static int CalculateMax ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ; int min_sum = arr [ 0 ] + arr [ 1 ] ; int max_sum = arr [ n - 1 ] + arr [ n - 2 ] ; return ( Math . abs ( max_sum - min_sum ) ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 6 , 7 , 1 , 11 } ; int n = arr . length ; System . out . println ( CalculateMax ( arr , n ) ) ; } }
import java . util . Arrays ; import java . util . Collections ; import java . util . Vector ; class GFG { static long calculate ( long a [ ] , int n ) {
Arrays . sort ( a ) ; int i , j ;
Vector < Long > s = new Vector < > ( ) ; for ( i = 0 , j = n - 1 ; i < j ; i ++ , j -- ) s . add ( ( a [ i ] + a [ j ] ) ) ; long mini = Collections . min ( s ) ; long maxi = Collections . max ( s ) ; return Math . abs ( maxi - mini ) ; }
public static void main ( String [ ] args ) { long a [ ] = { 2 , 6 , 4 , 3 } ; int n = a . length ; System . out . println ( calculate ( a , n ) ) ; } }
static void printMinDiffPairs ( int arr [ ] , int n ) { if ( n <= 1 ) return ;
Arrays . sort ( arr ) ;
int minDiff = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) minDiff = Math . min ( minDiff , arr [ i ] - arr [ i - 1 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) { if ( ( arr [ i ] - arr [ i - 1 ] ) == minDiff ) { System . out . print ( " ( " + arr [ i - 1 ] + " , ▁ " + arr [ i ] + " ) , " ) ; } } }
public static void main ( String [ ] args ) { int arr [ ] = { 5 , 3 , 2 , 4 , 1 } ; int n = arr . length ; printMinDiffPairs ( arr , n ) ; } }
public class MaximumAbsoluteDifference { private static int calculateDiff ( int i , int j , int [ ] array ) {
return Math . abs ( array [ i ] - array [ j ] ) + Math . abs ( i - j ) ; }
private static int maxDistance ( int [ ] array ) {
int result = 0 ;
for ( int i = 0 ; i < array . length ; i ++ ) { for ( int j = i ; j < array . length ; j ++ ) {
result = Math . max ( result , calculateDiff ( i , j , array ) ) ; } } return result ; }
public static void main ( String [ ] args ) { int [ ] array = { - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 } ; System . out . println ( maxDistance ( array ) ) ; } }
private static int maxDistance ( int [ ] array ) {
int max1 = Integer . MIN_VALUE ; int min1 = Integer . MAX_VALUE ; int max2 = Integer . MIN_VALUE ; int min2 = Integer . MAX_VALUE ; for ( int i = 0 ; i < array . length ; i ++ ) {
max1 = Math . max ( max1 , array [ i ] + i ) ; min1 = Math . min ( min1 , array [ i ] + i ) ; max2 = Math . max ( max2 , array [ i ] - i ) ; min2 = Math . min ( min2 , array [ i ] - i ) ; }
return Math . max ( max1 - min1 , max2 - min2 ) ; }
public static void main ( String [ ] args ) { int [ ] array = { - 70 , - 64 , - 6 , - 56 , 64 , 61 , - 57 , 16 , 48 , - 98 } ; System . out . println ( maxDistance ( array ) ) ; } }
static int extrema ( int a [ ] , int n ) { int count = 0 ;
for ( int i = 1 ; i < n - 1 ; i ++ ) {
if ( a [ i ] > a [ i - 1 ] && a [ i ] > a [ i + 1 ] ) count += 1 ;
if ( a [ i ] < a [ i - 1 ] && a [ i ] < a [ i + 1 ] ) count += 1 ; } return count ; }
public static void main ( String args [ ] ) throws IOException { int a [ ] = { 1 , 0 , 2 , 1 } ; int n = a . length ; System . out . println ( extrema ( a , n ) ) ; } }
public static int findClosest ( int arr [ ] , int target ) { int n = arr . length ;
if ( target <= arr [ 0 ] ) return arr [ 0 ] ; if ( target >= arr [ n - 1 ] ) return arr [ n - 1 ] ;
int i = 0 , j = n , mid = 0 ; while ( i < j ) { mid = ( i + j ) / 2 ; if ( arr [ mid ] == target ) return arr [ mid ] ;
if ( target < arr [ mid ] ) {
if ( mid > 0 && target > arr [ mid - 1 ] ) return getClosest ( arr [ mid - 1 ] , arr [ mid ] , target ) ;
j = mid ; }
else { if ( mid < n - 1 && target < arr [ mid + 1 ] ) return getClosest ( arr [ mid ] , arr [ mid + 1 ] , target ) ;
i = mid + 1 ; } }
return arr [ mid ] ; }
public static int getClosest ( int val1 , int val2 , int target ) { if ( target - val1 >= val2 - target ) return val2 ; else return val1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 4 , 5 , 6 , 6 , 8 , 9 } ; int target = 11 ; System . out . println ( findClosest ( arr , target ) ) ; } }
static int sum ( int a [ ] , int n ) {
int maxSum = Integer . MIN_VALUE ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) maxSum = Math . max ( maxSum , a [ i ] + a [ j ] ) ;
int c = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) if ( a [ i ] + a [ j ] == maxSum ) c ++ ; return c ; }
public static void main ( String [ ] args ) { int array [ ] = { 1 , 1 , 1 , 2 , 2 , 2 } ; int n = array . length ; System . out . println ( sum ( array , n ) ) ; } }
static int sum ( int a [ ] , int n ) {
int maxVal = a [ 0 ] , maxCount = 1 ; int secondMax = Integer . MIN_VALUE , secondMaxCount = 0 ; for ( int i = 1 ; i < n ; i ++ ) { if ( a [ i ] == maxVal ) maxCount ++ ; else if ( a [ i ] > maxVal ) { secondMax = maxVal ; secondMaxCount = maxCount ; maxVal = a [ i ] ; maxCount = 1 ; } else if ( a [ i ] == secondMax ) { secondMax = a [ i ] ; secondMaxCount ++ ; } else if ( a [ i ] > secondMax ) { secondMax = a [ i ] ; secondMaxCount = 1 ; } }
if ( maxCount > 1 ) return maxCount * ( maxCount - 1 ) / 2 ;
return secondMaxCount ; }
public static void main ( String [ ] args ) { int array [ ] = { 1 , 1 , 1 , 2 , 2 , 2 , 3 } ; int n = array . length ; System . out . println ( sum ( array , n ) ) ; } }
static void printSmall ( int arr [ ] , int asize , int n ) {
int [ ] copy_arr = Arrays . copyOf ( arr , asize ) ;
Arrays . sort ( copy_arr ) ;
for ( int i = 0 ; i < asize ; ++ i ) { if ( Arrays . binarySearch ( copy_arr , 0 , n , arr [ i ] ) > - 1 ) System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 5 , 8 , 9 , 6 , 7 , 3 , 4 , 2 , 0 } ; int asize = arr . length ; int n = 5 ; printSmall ( arr , asize , n ) ; } }
static void printKMissing ( int [ ] arr , int n , int k ) { Arrays . sort ( arr ) ;
int i = 0 ; while ( i < n && arr [ i ] <= 0 ) i ++ ;
int count = 0 , curr = 1 ; while ( count < k && i < n ) { if ( arr [ i ] != curr ) { System . out . print ( curr + " ▁ " ) ; count ++ ; } else i ++ ; curr ++ ; }
while ( count < k ) { System . out . print ( curr + " ▁ " ) ; curr ++ ; count ++ ; } }
public static void main ( String [ ] args ) { int [ ] arr = { 2 , 3 , 4 } ; int n = arr . length ; int k = 3 ; printKMissing ( arr , n , k ) ; } }
static void printmissingk ( int arr [ ] , int n , int k ) {
HashMap < Integer , Integer > d = new HashMap < > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) d . put ( arr [ i ] , arr [ i ] ) ; int cnt = 1 ; int fl = 0 ;
for ( int i = 0 ; i < ( n + k ) ; i ++ ) { if ( ! d . containsKey ( cnt ) ) { fl += 1 ; System . out . print ( cnt + " ▁ " ) ; if ( fl == k ) break ; } cnt += 1 ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 4 , 3 } ; int n = arr . length ; int k = 3 ; printmissingk ( arr , n , k ) ; } }
public static int nobleInteger ( int arr [ ] ) { int size = arr . length ; for ( int i = 0 ; i < size ; i ++ ) { int count = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( arr [ i ] < arr [ j ] ) count ++ ;
if ( count == arr [ i ] ) return arr [ i ] ; } return - 1 ; }
public static void main ( String args [ ] ) { int [ ] arr = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr ) ; if ( res != - 1 ) System . out . println ( " The ▁ noble ▁ " + " integer ▁ is ▁ " + res ) ; else System . out . println ( " No ▁ Noble ▁ " + " Integer ▁ Found " ) ; } }
public static int nobleInteger ( int arr [ ] ) { Arrays . sort ( arr ) ;
int n = arr . length ; for ( int i = 0 ; i < n - 1 ; i ++ ) { if ( arr [ i ] == arr [ i + 1 ] ) continue ;
if ( arr [ i ] == n - i - 1 ) return arr [ i ] ; } if ( arr [ n - 1 ] == 0 ) return arr [ n - 1 ] ; return - 1 ; }
public static void main ( String args [ ] ) { int [ ] arr = { 10 , 3 , 20 , 40 , 2 } ; int res = nobleInteger ( arr ) ; if ( res != - 1 ) System . out . println ( " The ▁ noble ▁ integer ▁ is ▁ " + res ) ; else System . out . println ( " No ▁ Noble ▁ Integer ▁ Found " ) ; } }
static long findMinSum ( long a [ ] , long b [ ] , long n ) {
Arrays . sort ( a ) ; Arrays . sort ( b ) ;
long sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum = sum + Math . abs ( a [ i ] - b [ i ] ) ; return sum ; }
long a [ ] = { 4 , 1 , 8 , 7 } ; long b [ ] = { 2 , 3 , 6 , 5 } ; int n = a . length ; System . out . println ( findMinSum ( a , b , n ) ) ; } }
static boolean checkIsAP ( int arr [ ] , int n ) { if ( n == 1 ) return true ;
Arrays . sort ( arr ) ;
int d = arr [ 1 ] - arr [ 0 ] ; for ( int i = 2 ; i < n ; i ++ ) if ( arr [ i ] - arr [ i - 1 ] != d ) return false ; return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 20 , 15 , 5 , 0 , 10 } ; int n = arr . length ; if ( checkIsAP ( arr , n ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
class GFG { static int minProductSubset ( int a [ ] , int n ) { if ( n == 1 ) return a [ 0 ] ;
int negmax = Integer . MIN_VALUE ; int posmin = Integer . MAX_VALUE ; int count_neg = 0 , count_zero = 0 ; int product = 1 ; for ( int i = 0 ; i < n ; i ++ ) {
if ( a [ i ] == 0 ) { count_zero ++ ; continue ; }
if ( a [ i ] < 0 ) { count_neg ++ ; negmax = Math . max ( negmax , a [ i ] ) ; }
if ( a [ i ] > 0 && a [ i ] < posmin ) posmin = a [ i ] ; product *= a [ i ] ; }
if ( count_zero == n || ( count_neg == 0 && count_zero > 0 ) ) return 0 ;
if ( count_neg == 0 ) return posmin ;
if ( count_neg % 2 == 0 && count_neg != 0 ) {
product = product / negmax ; } return product ; }
public static void main ( String [ ] args ) { int a [ ] = { - 1 , - 1 , - 2 , 4 , 3 } ; int n = 5 ; System . out . println ( minProductSubset ( a , n ) ) ; } }
import java . util . * ; class GFG { static int countPairs ( int a [ ] , int n ) {
int mn = Integer . MAX_VALUE ; int mx = Integer . MIN_VALUE ; for ( int i = 0 ; i < n ; i ++ ) { mn = Math . min ( mn , a [ i ] ) ; mx = Math . max ( mx , a [ i ] ) ; }
int c1 = 0 ;
int c2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] == mn ) c1 ++ ; if ( a [ i ] == mx ) c2 ++ ; }
if ( mn == mx ) return n * ( n - 1 ) / 2 ; else return c1 * c2 ; }
public static void main ( String [ ] args ) { int a [ ] = { 3 , 2 , 1 , 1 , 3 } ; int n = a . length ; System . out . print ( countPairs ( a , n ) ) ; } }
import java . util . Arrays ; public class Test4 { static int findElement ( int a [ ] , int n , int b ) {
Arrays . sort ( a ) ;
int max = a [ n - 1 ] ; while ( b < max ) {
if ( Arrays . binarySearch ( a , b ) > - 1 ) b *= 2 ; else return b ; } return b ; }
public static void main ( String args [ ] ) { int a [ ] = { 1 , 2 , 3 } ; int n = a . length ; int b = 1 ; System . out . println ( findElement ( a , n , b ) ) ; } }
import java . io . * ; import java . util . * ; class GFG { static int Mod = 1000000007 ;
static long findSum ( int arr [ ] , int n ) { long sum = 0 ;
Arrays . sort ( arr ) ;
int i = 0 ; while ( i < n && arr [ i ] < 0 ) { if ( i != n - 1 && arr [ i + 1 ] <= 0 ) { sum = ( sum + ( arr [ i ] * arr [ i + 1 ] ) % Mod ) % Mod ; i += 2 ; } else break ; }
int j = n - 1 ; while ( j >= 0 && arr [ j ] > 0 ) { if ( j != 0 && arr [ j - 1 ] > 0 ) { sum = ( sum + ( arr [ j ] * arr [ j - 1 ] ) % Mod ) % Mod ; j -= 2 ; } else break ; }
if ( j > i ) sum = ( sum + ( arr [ i ] * arr [ j ] ) % Mod ) % Mod ;
else if ( i == j ) sum = ( sum + arr [ i ] ) % Mod ; return sum ; }
public static void main ( String args [ ] ) { int arr [ ] = { - 1 , 9 , 4 , 5 , - 4 , 7 } ; int n = arr . length ; System . out . println ( findSum ( arr , n ) ) ; } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public void insertAfter ( Node prev_node , int new_data ) {
if ( prev_node == null ) { System . out . println ( " The ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ null " ) ; return ; }
Node new_node = new Node ( new_data ) ;
new_node . next = prev_node . next ;
prev_node . next = new_node ; }
class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } }
Node head ;
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public boolean search ( Node head , int x ) {
if ( head == null ) return false ;
if ( head . data == x ) return true ;
return search ( head . next , x ) ; }
llist . push ( 10 ) ; llist . push ( 30 ) ; llist . push ( 11 ) ; llist . push ( 21 ) ; llist . push ( 14 ) ; if ( llist . search ( llist . head , 21 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static class Node { int data ; Node next ; } ; static Node head_ref = null ;
static void reverse ( ) { Node prev = null ; Node current = head_ref ;
while ( current != null ) {
Node next = current . next ; current . next = prev ; prev = current ; current = next ; } head_ref = prev ; }
static void push ( int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ;
( head_ref ) = new_node ; }
static void printList ( ) { Node temp = head_ref ; while ( temp != null ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } }
public static void main ( String [ ] args ) { push ( 20 ) ; push ( 4 ) ; push ( 15 ) ; push ( 85 ) ; System . out . print ( "Given linked listNEW_LINE"); printList ( ) ; reverse ( ) ; System . out . print ( " Reversed Linked list "); printList ( ) ; } }
static class Node { int data ; Node next ; }
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } System . out . println ( ) ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static Node insertBeg ( Node head , int val ) { Node temp = newNode ( val ) ; temp . next = head ; head = temp ; return head ; }
static void rearrangeOddEven ( Node head ) { Stack < Node > odd = new Stack < Node > ( ) ; Stack < Node > even = new Stack < Node > ( ) ; int i = 1 ; while ( head != null ) { if ( head . data % 2 != 0 && i % 2 == 0 ) {
odd . push ( head ) ; } else if ( head . data % 2 == 0 && i % 2 != 0 ) {
even . push ( head ) ; } head = head . next ; i ++ ; } while ( odd . size ( ) > 0 && even . size ( ) > 0 ) {
int k = odd . peek ( ) . data ; odd . peek ( ) . data = even . peek ( ) . data ; even . peek ( ) . data = k ; odd . pop ( ) ; even . pop ( ) ; } }
public static void main ( String args [ ] ) { Node head = newNode ( 8 ) ; head = insertBeg ( head , 7 ) ; head = insertBeg ( head , 6 ) ; head = insertBeg ( head , 5 ) ; head = insertBeg ( head , 3 ) ; head = insertBeg ( head , 2 ) ; head = insertBeg ( head , 1 ) ; System . out . println ( " Linked ▁ List : " ) ; printList ( head ) ; rearrangeOddEven ( head ) ; System . out . println ( " Linked ▁ List ▁ after ▁ " + " Rearranging : " ) ; printList ( head ) ; } }
static class Node { int data ; Node next ; } ;
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } System . out . println ( ) ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static Node insertBeg ( Node head , int val ) { Node temp = newNode ( val ) ; temp . next = head ; head = temp ; return head ; }
static Node rearrange ( Node head ) {
Node even ; Node temp , prev_temp ; Node i , j , k , l , ptr = null ;
temp = ( head ) . next ; prev_temp = head ; while ( temp != null ) {
Node x = temp . next ;
if ( temp . data % 2 != 0 ) { prev_temp . next = x ; temp . next = ( head ) ; ( head ) = temp ; } else { prev_temp = temp ; }
temp = x ; }
temp = ( head ) . next ; prev_temp = ( head ) ; while ( temp != null && temp . data % 2 != 0 ) { prev_temp = temp ; temp = temp . next ; } even = temp ;
prev_temp . next = null ;
i = head ; j = even ; while ( j != null && i != null ) {
k = i . next ; l = j . next ; i . next = j ; j . next = k ;
ptr = j ;
i = k ; j = l ; } if ( i == null ) {
ptr . next = j ; }
return head ; }
public static void main ( String args [ ] ) { Node head = newNode ( 8 ) ; head = insertBeg ( head , 7 ) ; head = insertBeg ( head , 6 ) ; head = insertBeg ( head , 3 ) ; head = insertBeg ( head , 5 ) ; head = insertBeg ( head , 1 ) ; head = insertBeg ( head , 2 ) ; head = insertBeg ( head , 10 ) ; System . out . println ( " Linked ▁ List : " ) ; printList ( head ) ; System . out . println ( " Rearranged ▁ List " ) ; head = rearrange ( head ) ; printList ( head ) ; } }
class Node { int data ; Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } public class BinaryTree {
Node root ; int minimumDepth ( ) { return minimumDepth ( root ) ; }
int minimumDepth ( Node root ) {
if ( root == null ) return 0 ;
if ( root . left == null && root . right == null ) return 1 ;
if ( root . left == null ) return minimumDepth ( root . right ) + 1 ;
if ( root . right == null ) return minimumDepth ( root . left ) + 1 ; return Math . min ( minimumDepth ( root . left ) , minimumDepth ( root . right ) ) + 1 ; }
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; System . out . println ( " The ▁ minimum ▁ depth ▁ of ▁ " + " binary ▁ tree ▁ is ▁ : ▁ " + tree . minimumDepth ( ) ) ; } }
static Node deleteAlt ( Node head ) { if ( head == null ) return ; Node node = head . next ; if ( node == null ) return ;
head . next = node . next ;
head . next = deleteAlt ( head . next ) ; }
static void AlternatingSplit ( Node source , Node aRef , Node bRef ) { Node aDummy = new Node ( ) ; Node aTail = aDummy ;
Node bDummy = new Node ( ) ; Node bTail = bDummy ;
Node current = source ; aDummy . next = null ; bDummy . next = null ; while ( current != null ) { MoveNode ( ( aTail . next ) , current ) ;
aTail = aTail . next ;
if ( current != null ) { MoveNode ( ( bTail . next ) , current ) ; bTail = bTail . next ; } } aRef = aDummy . next ; bRef = bDummy . next ; }
boolean areIdenticalRecur ( Node a , Node b ) {
if ( a == null && b == null ) return true ;
if ( a != null && b != null ) return ( a . data == b . data ) && areIdenticalRecur ( a . next , b . next ) ;
return false ; }
boolean areIdentical ( LinkedList listb ) { return areIdenticalRecur ( this . head , listb . head ) ; }
static class Node { int data ; Node next ; } ; static Node head = null ;
static void rotate ( int k ) { if ( k == 0 ) return ;
Node current = head ;
while ( current . next != null ) current = current . next ; current . next = head ; current = head ;
for ( int i = 0 ; i < k - 1 ; i ++ ) current = current . next ;
head = current . next ; current . next = null ; }
static void push ( int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head ;
head = new_node ; }
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } }
for ( int i = 60 ; i > 0 ; i -= 10 ) push ( i ) ; System . out . print ( "Given linked list NEW_LINE"); printList ( head ) ; rotate ( 4 ) ; System . out . print ( " Rotated Linked list "); printList ( head ) ; } }
Node head ;
class Node { int data ; Node right , down ; Node ( int data ) { this . data = data ; right = null ; down = null ; } }
Node merge ( Node a , Node b ) {
if ( a == null ) return b ;
if ( b == null ) return a ;
Node result ; if ( a . data < b . data ) { result = a ; result . down = merge ( a . down , b ) ; } else { result = b ; result . down = merge ( a , b . down ) ; } result . right = null ; return result ; } Node flatten ( Node root ) {
if ( root == null root . right == null ) return root ;
root . right = flatten ( root . right ) ;
root = merge ( root , root . right ) ;
return root ; }
Node push ( Node head_ref , int data ) {
Node new_node = new Node ( data ) ;
new_node . down = head_ref ;
head_ref = new_node ;
return head_ref ; } void printList ( ) { Node temp = head ; while ( temp != null ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . down ; } System . out . println ( ) ; }
L . head = L . push ( L . head , 30 ) ; L . head = L . push ( L . head , 8 ) ; L . head = L . push ( L . head , 7 ) ; L . head = L . push ( L . head , 5 ) ; L . head . right = L . push ( L . head . right , 20 ) ; L . head . right = L . push ( L . head . right , 10 ) ; L . head . right . right = L . push ( L . head . right . right , 50 ) ; L . head . right . right = L . push ( L . head . right . right , 22 ) ; L . head . right . right = L . push ( L . head . right . right , 19 ) ; L . head . right . right . right = L . push ( L . head . right . right . right , 45 ) ; L . head . right . right . right = L . push ( L . head . right . right . right , 40 ) ; L . head . right . right . right = L . push ( L . head . right . right . right , 35 ) ; L . head . right . right . right = L . push ( L . head . right . right . right , 20 ) ;
L . head = L . flatten ( L . head ) ; L . printList ( ) ; } }
Node head ;
class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } } void sortList ( ) {
int count [ ] = { 0 , 0 , 0 } ; Node ptr = head ;
while ( ptr != null ) { count [ ptr . data ] ++ ; ptr = ptr . next ; } int i = 0 ; ptr = head ;
while ( ptr != null ) { if ( count [ i ] == 0 ) i ++ ; else { ptr . data = i ; -- count [ i ] ; ptr = ptr . next ; } } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
void printList ( ) { Node temp = head ; while ( temp != null ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } System . out . println ( ) ; }
llist . push ( 0 ) ; llist . push ( 1 ) ; llist . push ( 0 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; llist . push ( 1 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; llist . push ( 2 ) ; System . out . println ( " Linked ▁ List ▁ before ▁ sorting " ) ; llist . printList ( ) ; llist . sortList ( ) ; System . out . println ( " Linked ▁ List ▁ after ▁ sorting " ) ; llist . printList ( ) ; } }
static class List { public int data ; public List next ; public List child ; } ;
class Geeks { static class Node { int data ; Node next ; }
static Node rearrange ( Node head ) {
if ( head == null ) return null ;
Node prev = head , curr = head . next ; while ( curr != null ) {
if ( prev . data > curr . data ) { int t = prev . data ; prev . data = curr . data ; curr . data = t ; }
if ( curr . next != null && curr . next . data > curr . data ) { int t = curr . next . data ; curr . next . data = curr . data ; curr . data = t ; } prev = curr . next ; if ( curr . next == null ) break ; curr = curr . next . next ; } return head ; }
static Node push ( Node head , int k ) { Node tem = new Node ( ) ; tem . data = k ; tem . next = head ; head = tem ; return head ; }
static void display ( Node head ) { Node curr = head ; while ( curr != null ) { System . out . printf ( " % d ▁ " , curr . data ) ; curr = curr . next ; } }
head = push ( head , 7 ) ; head = push ( head , 3 ) ; head = push ( head , 8 ) ; head = push ( head , 6 ) ; head = push ( head , 9 ) ; head = rearrange ( head ) ; display ( head ) ; } }
class Node { int data ; Node next ; Node ( int key ) { data = key ; next = null ; } }
class GFG { Node left = null ;
void printlist ( Node head ) { while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; if ( head . next != null ) { System . out . print ( " - > " ) ; } head = head . next ; } System . out . println ( ) ; }
void rearrange ( Node head ) { if ( head != null ) { left = head ; reorderListUtil ( left ) ; } } void reorderListUtil ( Node right ) { if ( right == null ) { return ; } reorderListUtil ( right . next ) ;
if ( left == null ) { return ; }
if ( left != right && left . next != right ) { Node temp = left . next ; left . next = right ; right . next = temp ; left = temp ; }
else { if ( left . next == right ) {
left . next . next = null ; left = null ; } else {
left . next = null ; left = null ; } } }
public static void main ( String [ ] args ) { Node head = new Node ( 1 ) ; head . next = new Node ( 2 ) ; head . next . next = new Node ( 3 ) ; head . next . next . next = new Node ( 4 ) ; head . next . next . next . next = new Node ( 5 ) ; GFG gfg = new GFG ( ) ;
gfg . printlist ( head ) ;
gfg . rearrange ( head ) ;
gfg . printlist ( head ) ; } }
static class Node { int data ; Node next ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static Node rearrangeEvenOdd ( Node head ) {
if ( head == null ) return null ;
Node odd = head ; Node even = head . next ;
Node evenFirst = even ; while ( 1 == 1 ) {
if ( odd == null || even == null || ( even . next ) == null ) { odd . next = evenFirst ; break ; }
odd . next = even . next ; odd = even . next ;
if ( odd . next == null ) { even . next = null ; odd . next = evenFirst ; break ; }
even . next = odd . next ; even = odd . next ; } return head ; }
static void printlist ( Node node ) { while ( node != null ) { System . out . print ( node . data + " - > " ) ; node = node . next ; } System . out . println ( " NULL " ) ; }
public static void main ( String [ ] args ) { Node head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; System . out . println ( " Given ▁ Linked ▁ List " ) ; printlist ( head ) ; head = rearrangeEvenOdd ( head ) ; System . out . println ( " Modified ▁ Linked ▁ List " ) ; printlist ( head ) ; } }
class Node { int data ; Node next ; Node ( int data ) { this . data = data ; } } public class GFG { private Node head ;
public void printLL ( ) { Node t = head ; while ( t != null ) { System . out . print ( t . data + " ▁ - > " ) ; t = t . next ; } System . out . println ( ) ; }
public void swap ( Node a , Node b ) { if ( a == null b == null ) return ; int temp = a . data ; a . data = b . data ; b . data = temp ; }
public Node zigZag ( Node node , int flag ) { if ( node == null node . next == null ) { return node ; } if ( flag == 0 ) { if ( node . data > node . next . data ) { swap ( node , node . next ) ; } return zigZag ( node . next , 1 ) ; } else { if ( node . data < node . next . data ) { swap ( node , node . next ) ; } return zigZag ( node . next , 0 ) ; } }
public static void main ( String [ ] args ) { GFG lobj = new GFG ( ) ; lobj . head = new Node ( 11 ) ; lobj . head . next = new Node ( 15 ) ; lobj . head . next . next = new Node ( 20 ) ; lobj . head . next . next . next = new Node ( 5 ) ; lobj . head . next . next . next . next = new Node ( 10 ) ; lobj . printLL ( ) ;
int flag = 0 ; lobj . zigZag ( lobj . head , flag ) ; System . out . println ( " LL ▁ in ▁ zig ▁ zag ▁ fashion ▁ : ▁ " ) ; lobj . printLL ( ) ; } }
static class Node { int data ; Node next ; }
static Node newNode ( int data ) { Node new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
static int addWithCarry ( Node head ) {
if ( head == null ) return 1 ;
int res = head . data + addWithCarry ( head . next ) ;
head . data = ( res ) % 10 ; return ( res ) / 10 ; }
static Node addOne ( Node head ) {
int carry = addWithCarry ( head ) ;
if ( carry > 0 ) { Node newNode = newNode ( carry ) ; newNode . next = head ;
return newNode ; } return head ; }
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data ) ; node = node . next ; } System . out . println ( ) ; }
public static void main ( String [ ] args ) { Node head = newNode ( 1 ) ; head . next = newNode ( 9 ) ; head . next . next = newNode ( 9 ) ; head . next . next . next = newNode ( 9 ) ; System . out . print ( " List ▁ is ▁ " ) ; printList ( head ) ; head = addOne ( head ) ; System . out . println ( ) ; System . out . print ( " Resultant ▁ list ▁ is ▁ " ) ; printList ( head ) ; } }
static class Node { int data ; Node next , arbit ; }
static Node reverse ( Node head ) { Node prev = null , current = head , next = null ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } return prev ; }
static Node populateArbit ( Node head ) {
head = reverse ( head ) ;
Node max = head ;
Node temp = head . next ; while ( temp != null ) {
temp . arbit = max ;
if ( max . data < temp . data ) max = temp ;
temp = temp . next ; }
return reverse ( head ) ; }
static void printNextArbitPointers ( Node node ) { System . out . println ( " Node TABSYMBOL Next ▁ Pointer TABSYMBOL Arbit ▁ Pointer " ) ; while ( node != null ) { System . out . print ( node . data + " TABSYMBOL TABSYMBOL " ) ; if ( node . next != null ) System . out . print ( node . next . data + " TABSYMBOL TABSYMBOL " ) ; else System . out . print ( " NULL " + " TABSYMBOL TABSYMBOL " ) ; if ( node . arbit != null ) System . out . print ( node . arbit . data ) ; else System . out . print ( " NULL " ) ; System . out . println ( ) ; node = node . next ; } }
static Node newNode ( int data ) { Node new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
public static void main ( String [ ] args ) { Node head = newNode ( 5 ) ; head . next = newNode ( 10 ) ; head . next . next = newNode ( 2 ) ; head . next . next . next = newNode ( 3 ) ; head = populateArbit ( head ) ; System . out . println ( " Resultant ▁ Linked ▁ List ▁ is : ▁ " ) ; printNextArbitPointers ( head ) ; } }
static class Node { int data ; Node next , arbit ; } static Node maxNode ;
static void populateArbit ( Node head ) {
if ( head == null ) return ;
if ( head . next == null ) { maxNode = head ; return ; }
populateArbit ( head . next ) ;
head . arbit = maxNode ;
if ( head . data > maxNode . data ) maxNode = head ; return ; }
static void printNextArbitPointers ( Node node ) { System . out . println ( " Node TABSYMBOL Next ▁ Pointer TABSYMBOL Arbit ▁ Pointer " ) ; while ( node != null ) { System . out . print ( node . data + " TABSYMBOL TABSYMBOL TABSYMBOL " ) ; if ( node . next != null ) System . out . print ( node . next . data + " TABSYMBOL TABSYMBOL TABSYMBOL TABSYMBOL " ) ; else System . out . print ( " NULL " + " TABSYMBOL TABSYMBOL TABSYMBOL " ) ; if ( node . arbit != null ) System . out . print ( node . arbit . data ) ; else System . out . print ( " NULL " ) ; System . out . println ( ) ; node = node . next ; } }
static Node newNode ( int data ) { Node new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
public static void main ( String [ ] args ) { Node head = newNode ( 5 ) ; head . next = newNode ( 10 ) ; head . next . next = newNode ( 2 ) ; head . next . next . next = newNode ( 3 ) ; populateArbit ( head ) ; System . out . println ( " Resultant ▁ Linked ▁ List ▁ is : ▁ " ) ; printNextArbitPointers ( head ) ; } }
static class Node { int data ; Node next ; } ;
static void deleteLast ( Node head , int x ) { Node temp = head , ptr = null ; while ( temp != null ) {
if ( temp . data == x ) ptr = temp ; temp = temp . next ; }
if ( ptr != null && ptr . next == null ) { temp = head ; while ( temp . next != ptr ) temp = temp . next ; temp . next = null ; }
if ( ptr != null && ptr . next != null ) { ptr . data = ptr . next . data ; temp = ptr . next ; ptr . next = ptr . next . next ; System . gc ( ) ; } }
static Node newNode ( int x ) { Node node = new Node ( ) ; node . data = x ; node . next = null ; return node ; }
static void display ( Node head ) { Node temp = head ; if ( head == null ) { System . out . print ( "nullNEW_LINE"); return ; } while ( temp != null ) { System . out . printf ( " % d ▁ - - > ▁ " , temp . data ) ; temp = temp . next ; } System . out . print ( "nullNEW_LINE"); }
public static void main ( String [ ] args ) { Node head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; head . next . next . next . next . next = newNode ( 4 ) ; head . next . next . next . next . next . next = newNode ( 4 ) ; System . out . print ( " Created ▁ Linked ▁ list : ▁ " ) ; display ( head ) ; deleteLast ( head , 4 ) ; System . out . print ( " List ▁ after ▁ deletion ▁ of ▁ 4 : ▁ " ) ; display ( head ) ; } }
Node flattenList2 ( Node head ) { Node headcop = head ; Stack < Node > save = new Stack < > ( ) ; save . push ( head ) ; Node prev = null ; while ( ! save . isEmpty ( ) ) { Node temp = save . peek ( ) ; save . pop ( ) ; if ( temp . next ) save . push ( temp . next ) ; if ( temp . down ) save . push ( temp . down ) ; if ( prev != null ) prev . next = temp ; prev = temp ; } return headcop ; }
static Node head ; boolean borrow ;
static class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } }
int getLength ( Node node ) { int size = 0 ; while ( node != null ) { node = node . next ; size ++ ; } return size ; }
Node paddZeros ( Node sNode , int diff ) { if ( sNode == null ) return null ; Node zHead = new Node ( 0 ) ; diff -- ; Node temp = zHead ; while ( ( diff -- ) != 0 ) { temp . next = new Node ( 0 ) ; temp = temp . next ; } temp . next = sNode ; return zHead ; }
Node subtractLinkedListHelper ( Node l1 , Node l2 ) { if ( l1 == null && l2 == null && borrow == false ) return null ; Node previous = subtractLinkedListHelper ( ( l1 != null ) ? l1 . next : null , ( l2 != null ) ? l2 . next : null ) ; int d1 = l1 . data ; int d2 = l2 . data ; int sub = 0 ;
if ( borrow ) { d1 -- ; borrow = false ; }
if ( d1 < d2 ) { borrow = true ; d1 = d1 + 10 ; }
sub = d1 - d2 ;
Node current = new Node ( sub ) ;
current . next = previous ; return current ; }
Node subtractLinkedList ( Node l1 , Node l2 ) {
if ( l1 == null && l2 == null ) return null ;
int len1 = getLength ( l1 ) ; int len2 = getLength ( l2 ) ; Node lNode = null , sNode = null ; Node temp1 = l1 ; Node temp2 = l2 ;
if ( len1 != len2 ) { lNode = len1 > len2 ? l1 : l2 ; sNode = len1 > len2 ? l2 : l1 ; sNode = paddZeros ( sNode , Math . abs ( len1 - len2 ) ) ; } else {
while ( l1 != null && l2 != null ) { if ( l1 . data != l2 . data ) { lNode = l1 . data > l2 . data ? temp1 : temp2 ; sNode = l1 . data > l2 . data ? temp2 : temp1 ; break ; } l1 = l1 . next ; l2 = l2 . next ; } }
borrow = false ; return subtractLinkedListHelper ( lNode , sNode ) ; }
static void printList ( Node head ) { Node temp = head ; while ( temp != null ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } }
public static void main ( String [ ] args ) { Node head = new Node ( 1 ) ; head . next = new Node ( 0 ) ; head . next . next = new Node ( 0 ) ; Node head2 = new Node ( 1 ) ; LinkedList ob = new LinkedList ( ) ; Node result = ob . subtractLinkedList ( head , head2 ) ; printList ( result ) ; } }
static class Node { int data ; Node next ; }
static Node newNode ( int data ) { Node new_node = new Node ( ) ; new_node . data = data ; new_node . next = null ; return new_node ; }
static Node partition ( Node head , int x ) {
Node smallerHead = null , smallerLast = null ; Node greaterLast = null , greaterHead = null ; Node equalHead = null , equalLast = null ;
while ( head != null ) {
if ( head . data == x ) { if ( equalHead == null ) equalHead = equalLast = head ; else { equalLast . next = head ; equalLast = equalLast . next ; } }
else if ( head . data < x ) { if ( smallerHead == null ) smallerLast = smallerHead = head ; else { smallerLast . next = head ; smallerLast = head ; } }
else { if ( greaterHead == null ) greaterLast = greaterHead = head ; else { greaterLast . next = head ; greaterLast = head ; } } head = head . next ; }
if ( greaterLast != null ) greaterLast . next = null ;
if ( smallerHead == null ) { if ( equalHead == null ) return greaterHead ; equalLast . next = greaterHead ; return equalHead ; }
if ( equalHead == null ) { smallerLast . next = greaterHead ; return smallerHead ; }
smallerLast . next = equalHead ; equalLast . next = greaterHead ; return smallerHead ; }
static void printList ( Node head ) { Node temp = head ; while ( temp != null ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } }
Node head = newNode ( 10 ) ; head . next = newNode ( 4 ) ; head . next . next = newNode ( 5 ) ; head . next . next . next = newNode ( 30 ) ; head . next . next . next . next = newNode ( 2 ) ; head . next . next . next . next . next = newNode ( 50 ) ; int x = 3 ; head = partition ( head , x ) ; printList ( head ) ; } }
static class Node { int data ; Node next ; }
static Node getLoopstart ( Node loop_node , Node head ) { Node ptr1 = loop_node ; Node ptr2 = loop_node ;
int k = 1 , i ; while ( ptr1 . next != ptr2 ) { ptr1 = ptr1 . next ; k ++ ; }
ptr1 = head ;
ptr2 = head ; for ( i = 0 ; i < k ; i ++ ) ptr2 = ptr2 . next ;
while ( ptr2 != ptr1 ) { ptr1 = ptr1 . next ; ptr2 = ptr2 . next ; } return ptr1 ; }
static Node detectAndgetLoopstarting ( Node head ) { Node slow_p = head , fast_p = head , loop_start = null ;
while ( slow_p != null && fast_p != null && fast_p . next != null ) { slow_p = slow_p . next ; fast_p = fast_p . next . next ;
if ( slow_p == fast_p ) { loop_start = getLoopstart ( slow_p , head ) ; break ; } }
return loop_start ; }
static boolean isPalindromeUtil ( Node head , Node loop_start ) { Node ptr = head ; Stack < Integer > s = new Stack < Integer > ( ) ;
int count = 0 ; while ( ptr != loop_start count != 1 ) { s . push ( ptr . data ) ; if ( ptr == loop_start ) count = 1 ; ptr = ptr . next ; } ptr = head ; count = 0 ;
while ( ptr != loop_start count != 1 ) {
if ( ptr . data == s . peek ( ) ) s . pop ( ) ;
else return false ; if ( ptr == loop_start ) count = 1 ; ptr = ptr . next ; }
return true ; }
static boolean isPalindrome ( Node head ) {
Node loop_start = detectAndgetLoopstarting ( head ) ;
return isPalindromeUtil ( head , loop_start ) ; } static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
public static void main ( String [ ] args ) { Node head = newNode ( 50 ) ; head . next = newNode ( 20 ) ; head . next . next = newNode ( 15 ) ; head . next . next . next = newNode ( 20 ) ; head . next . next . next . next = newNode ( 50 ) ;
head . next . next . next . next . next = head . next . next ; if ( isPalindrome ( head ) == true ) System . out . println ( " Palindrome " ) ; else System . out . println ( " Not ▁ Palindrome " ) ; } }
static class Node { int data ; Node next ; }
static int countCommon ( Node a , Node b ) { int count = 0 ;
for ( ; a != null && b != null ; a = a . next , b = b . next )
if ( a . data == b . data ) ++ count ; else break ; return count ; }
static int maxPalindrome ( Node head ) { int result = 0 ; Node prev = null , curr = head ;
while ( curr != null ) {
Node next = curr . next ; curr . next = prev ;
result = Math . max ( result , 2 * countCommon ( prev , next ) + 1 ) ;
result = Math . max ( result , 2 * countCommon ( curr , next ) ) ;
prev = curr ; curr = next ; } return result ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
Node head = newNode ( 2 ) ; head . next = newNode ( 4 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 2 ) ; head . next . next . next . next . next = newNode ( 15 ) ; System . out . println ( maxPalindrome ( head ) ) ; } }
ArrayList < Integer > list = new ArrayList < > ( ) ;
list . add ( 1 ) ; list . add ( 2 ) ; list . add ( 3 ) ;
Iterator < Integer > it = list . iterator ( ) ; while ( it . hasNext ( ) ) { System . out . print ( it . next ( ) + " ▁ " ) ; } } }
static class Node { int data ; Node next ; }
static Node newNode ( int x ) { Node temp = new Node ( ) ; temp . data = x ; temp . next = null ; return temp ; }
static void printList ( Node head ) { Node temp = head ; while ( temp != null ) { System . out . printf ( " % d ▁ " , temp . data ) ; temp = temp . next ; } System . out . printf ( "NEW_LINE"); }
static void moveToEnd ( Node head , int key ) {
Node pKey = head ;
Node pCrawl = head ; while ( pCrawl != null ) {
if ( pCrawl != pKey && pCrawl . data != key ) { pKey . data = pCrawl . data ; pCrawl . data = key ; pKey = pKey . next ; }
if ( pKey . data != key ) pKey = pKey . next ;
pCrawl = pCrawl . next ; } }
public static void main ( String args [ ] ) { Node head = newNode ( 10 ) ; head . next = newNode ( 20 ) ; head . next . next = newNode ( 10 ) ; head . next . next . next = newNode ( 30 ) ; head . next . next . next . next = newNode ( 40 ) ; head . next . next . next . next . next = newNode ( 10 ) ; head . next . next . next . next . next . next = newNode ( 60 ) ; System . out . printf ( "Before moveToEnd(), the Linked list isNEW_LINE"); printList ( head ) ; int key = 10 ; moveToEnd ( head , key ) ; System . out . printf ( " After moveToEnd ( ) , the Linked list is "); printList ( head ) ; } }
class Node { int data ; Node next ; public Node ( int data ) { this . data = data ; this . next = null ; } } class gfg { static Node root ;
public static Node keyToEnd ( Node head , int key ) {
Node tail = head ; if ( head == null ) { return null ; } while ( tail . next != null ) { tail = tail . next ; }
Node last = tail ; Node current = head ; Node prev = null ;
Node prev2 = null ;
while ( current != tail ) { if ( current . data == key && prev2 == null ) { prev = current ; current = current . next ; head = current ; last . next = prev ; last = last . next ; last . next = null ; prev = null ; } else { if ( current . data == key && prev2 != null ) { prev = current ; current = current . next ; prev2 . next = current ; last . next = prev ; last = last . next ; last . next = null ; } else if ( current != tail ) { prev2 = current ; current = current . next ; } } } return head ; }
public static void display ( Node root ) { while ( root != null ) { System . out . print ( root . data + " ▁ " ) ; root = root . next ; } }
public static void main ( String args [ ] ) { root = new Node ( 5 ) ; root . next = new Node ( 2 ) ; root . next . next = new Node ( 2 ) ; root . next . next . next = new Node ( 7 ) ; root . next . next . next . next = new Node ( 2 ) ; root . next . next . next . next . next = new Node ( 2 ) ; root . next . next . next . next . next . next = new Node ( 2 ) ; int key = 2 ; System . out . println ( " Linked ▁ List ▁ before ▁ operations ▁ : " ) ; display ( root ) ; System . out . println ( " Linked List after operations : "); root = keyToEnd ( root , key ) ; display ( root ) ; } }
class LinkedList { Node head = null ; class Node { int val ; Node next ; Node ( int v ) { val = v ; next = null ; } }
public void insert ( int data ) { Node new_node = new Node ( data ) ; new_node . next = head ; head = new_node ; }
public void removeAllDuplicates ( ) {
Node dummy = new Node ( 0 ) ;
dummy . next = head ; Node prev = dummy ; Node current = head ; while ( current != null ) {
while ( current . next != null && prev . next . val == current . next . val ) current = current . next ;
if ( prev . next == current ) prev = prev . next ;
else prev . next = current . next ; current = current . next ; }
head = dummy . next ; }
public void printList ( ) { Node trav = head ; if ( head == null ) System . out . print ( " ▁ List ▁ is ▁ empty " ) ; while ( trav != null ) { System . out . print ( trav . val + " ▁ " ) ; trav = trav . next ; } }
public static void main ( String [ ] args ) { LinkedList ll = new LinkedList ( ) ; ll . insert ( 53 ) ; ll . insert ( 53 ) ; ll . insert ( 49 ) ; ll . insert ( 49 ) ; ll . insert ( 35 ) ; ll . insert ( 28 ) ; ll . insert ( 28 ) ; ll . insert ( 23 ) ; System . out . println ( " Before ▁ removal ▁ of ▁ duplicates " ) ; ll . printList ( ) ; ll . removeAllDuplicates ( ) ; System . out . println ( " After removal of duplicates "); ll . printList ( ) ; } }
static class Node { int data ; Node next ; }
static Node freeList ( Node node ) { while ( node != null ) { Node next = node . next ; node = next ; } return node ; }
static Node deleteKthNode ( Node head , int k ) {
if ( head == null ) return null ; if ( k == 1 ) { head = freeList ( head ) ; return null ; }
Node ptr = head , prev = null ;
int count = 0 ; while ( ptr != null ) {
count ++ ;
if ( k == count ) {
prev . next = ptr . next ;
count = 0 ; }
if ( count != 0 ) prev = ptr ; ptr = prev . next ; } return head ; }
static void displayList ( Node head ) { Node temp = head ; while ( temp != null ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } }
static Node newNode ( int x ) { Node temp = new Node ( ) ; temp . data = x ; temp . next = null ; return temp ; }
Node head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; head . next . next . next . next = newNode ( 5 ) ; head . next . next . next . next . next = newNode ( 6 ) ; head . next . next . next . next . next . next = newNode ( 7 ) ; head . next . next . next . next . next . next . next = newNode ( 8 ) ; int k = 3 ; head = deleteKthNode ( head , k ) ; displayList ( head ) ; } }
static class Node { int data ; Node next ; }
static int LinkedListLength ( Node head ) { while ( head != null && head . next != null ) { head = head . next . next ; } if ( head == null ) return 0 ; return 1 ; }
static void push ( Node head , int info ) {
Node node = new Node ( ) ;
node . data = info ;
node . next = ( head ) ;
( head ) = node ; }
public static void main ( String [ ] args ) { Node head = null ;
push ( head , 4 ) ; push ( head , 5 ) ; push ( head , 7 ) ; push ( head , 2 ) ; push ( head , 9 ) ; push ( head , 6 ) ; push ( head , 1 ) ; push ( head , 2 ) ; push ( head , 0 ) ; push ( head , 5 ) ; push ( head , 5 ) ; int check = LinkedListLength ( head ) ;
if ( check == 0 ) { System . out . println ( " Odd " ) ; } else { System . out . println ( " Even " ) ; } } }
static class Node { int data ; Node next ; } ; static Node head ; static int n , sum ;
static void push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; head = head_ref ; }
static void sumOfLastN_Nodes ( Node head ) {
if ( head == null ) return ;
sumOfLastN_Nodes ( head . next ) ;
if ( n > 0 ) {
sum = sum + head . data ;
-- n ; } }
static int sumOfLastN_NodesUtil ( Node head , int n ) {
if ( n <= 0 ) return 0 ; sum = 0 ;
sumOfLastN_Nodes ( head ) ;
return sum ; }
public static void main ( String [ ] args ) { head = null ;
push ( head , 12 ) ; push ( head , 4 ) ; push ( head , 8 ) ; push ( head , 6 ) ; push ( head , 10 ) ; n = 2 ; System . out . print ( " Sum ▁ of ▁ last ▁ " + n + " ▁ nodes ▁ = ▁ " + sumOfLastN_NodesUtil ( head , n ) ) ; } }
static class Node { int data ; Node next ; } ;
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; return head_ref ; }
static int sumOfLastN_NodesUtil ( Node head , int n ) {
if ( n <= 0 ) return 0 ; Stack < Integer > st = new Stack < Integer > ( ) ; int sum = 0 ;
while ( head != null ) {
st . push ( head . data ) ;
head = head . next ; }
while ( n -- > 0 ) { sum += st . peek ( ) ; st . pop ( ) ; }
return sum ; }
public static void main ( String [ ] args ) { Node head = null ;
head = push ( head , 12 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 6 ) ; head = push ( head , 10 ) ; int n = 2 ; System . out . print ( " Sum ▁ of ▁ last ▁ " + n + " ▁ nodes ▁ = ▁ " + sumOfLastN_NodesUtil ( head , n ) ) ; } }
static class Node { int data ; Node next ; } ; static Node head ;
static void push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; head = head_ref ; } static void reverseList ( Node head_ref ) { Node current , prev , next ; current = head_ref ; prev = null ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } head_ref = prev ; head = head_ref ; }
static int sumOfLastN_NodesUtil ( int n ) {
if ( n <= 0 ) return 0 ;
reverseList ( head ) ; int sum = 0 ; Node current = head ;
while ( current != null && n -- > 0 ) {
sum += current . data ;
current = current . next ; }
reverseList ( head ) ;
return sum ; }
push ( head , 12 ) ; push ( head , 4 ) ; push ( head , 8 ) ; push ( head , 6 ) ; push ( head , 10 ) ; int n = 2 ; System . out . println ( " Sum ▁ of ▁ last ▁ " + n + " ▁ nodes ▁ = ▁ " + sumOfLastN_NodesUtil ( n ) ) ; } }
static class Node { int data ; Node next ; } ; static Node head ;
static void push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head_ref ;
head_ref = new_node ; head = head_ref ; }
static int sumOfLastN_NodesUtil ( Node head , int n ) {
if ( n <= 0 ) return 0 ; int sum = 0 , len = 0 ; Node temp = head ;
while ( temp != null ) { len ++ ; temp = temp . next ; }
int c = len - n ; temp = head ;
while ( temp != null && c -- > 0 ) {
temp = temp . next ; }
while ( temp != null ) {
sum += temp . data ;
temp = temp . next ; }
return sum ; }
push ( head , 12 ) ; push ( head , 4 ) ; push ( head , 8 ) ; push ( head , 6 ) ; push ( head , 10 ) ; int n = 2 ; System . out . println ( " Sum ▁ of ▁ last ▁ " + n + " ▁ nodes ▁ = ▁ " + sumOfLastN_NodesUtil ( head , n ) ) ; } }
Node SortedMerge ( Node a , Node b ) { Node result = null ;
Node lastPtrRef = result ; while ( 1 ) { if ( a == null ) { lastPtrRef = b ; break ; } else if ( b == null ) { lastPtrRef = a ; break ; } if ( a . data <= b . data ) { MoveNode ( lastPtrRef , a ) ; } else { MoveNode ( lastPtrRef , b ) ; }
lastPtrRef = ( ( lastPtrRef ) . next ) ; } return ( result ) ; }
class Node { int data ; Node next ;
Node ( int key ) { data = key ; next = null ; } } class GFG { static Node head ; static Node temp ;
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } System . out . println ( ) ; }
static Node mergeKLists ( Node arr [ ] , int last ) {
for ( int i = 1 ; i <= last ; i ++ ) { while ( true ) {
Node head_0 = arr [ 0 ] ; Node head_i = arr [ i ] ;
if ( head_i == null ) break ;
if ( head_0 . data >= head_i . data ) { arr [ i ] = head_i . next ; head_i . next = head_0 ; arr [ 0 ] = head_i ; } else {
while ( head_0 . next != null ) {
if ( head_0 . next . data >= head_i . data ) { arr [ i ] = head_i . next ; head_i . next = head_0 . next ; head_0 . next = head_i ; break ; }
head_0 = head_0 . next ;
if ( head_0 . next == null ) { arr [ i ] = head_i . next ; head_i . next = null ; head_0 . next = head_i ; head_0 . next . next = null ; break ; } } } } } return arr [ 0 ] ; }
int k = 3 ;
int n = 4 ;
Node [ ] arr = new Node [ k ] ; arr [ 0 ] = new Node ( 1 ) ; arr [ 0 ] . next = new Node ( 3 ) ; arr [ 0 ] . next . next = new Node ( 5 ) ; arr [ 0 ] . next . next . next = new Node ( 7 ) ; arr [ 1 ] = new Node ( 2 ) ; arr [ 1 ] . next = new Node ( 4 ) ; arr [ 1 ] . next . next = new Node ( 6 ) ; arr [ 1 ] . next . next . next = new Node ( 8 ) ; arr [ 2 ] = new Node ( 0 ) ; arr [ 2 ] . next = new Node ( 9 ) ; arr [ 2 ] . next . next = new Node ( 10 ) ; arr [ 2 ] . next . next . next = new Node ( 11 ) ;
head = mergeKLists ( arr , k - 1 ) ; printList ( head ) ; } }
class GFG { static class Node { int data ; Node next ; } ;
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static void printList ( Node node ) { while ( node != null ) { System . out . printf ( " % d ▁ " , node . data ) ; node = node . next ; } }
static Node merge ( Node h1 , Node h2 ) { if ( h1 == null ) return h2 ; if ( h2 == null ) return h1 ;
if ( h1 . data < h2 . data ) { h1 . next = merge ( h1 . next , h2 ) ; return h1 ; } else { h2 . next = merge ( h1 , h2 . next ) ; return h2 ; } }
public static void main ( String args [ ] ) { Node head1 = newNode ( 1 ) ; head1 . next = newNode ( 3 ) ; head1 . next . next = newNode ( 5 ) ;
Node head2 = newNode ( 0 ) ; head2 . next = newNode ( 2 ) ; head2 . next . next = newNode ( 4 ) ;
Node mergedhead = merge ( head1 , head2 ) ; printList ( mergedhead ) ; } }
static class Node { int data ; Node next ; }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } }
static Node mergeUtil ( Node h1 , Node h2 ) {
if ( h1 . next == null ) { h1 . next = h2 ; return h1 ; }
Node curr1 = h1 , next1 = h1 . next ; Node curr2 = h2 , next2 = h2 . next ; while ( next1 != null && curr2 != null ) {
if ( ( curr2 . data ) >= ( curr1 . data ) && ( curr2 . data ) <= ( next1 . data ) ) { next2 = curr2 . next ; curr1 . next = curr2 ; curr2 . next = next1 ;
curr1 = curr2 ; curr2 = next2 ; } else {
if ( next1 . next != null ) { next1 = next1 . next ; curr1 = curr1 . next ; }
else { next1 . next = curr2 ; return h1 ; } } } return h1 ; }
static Node merge ( Node h1 , Node h2 ) { if ( h1 == null ) return h2 ; if ( h2 == null ) return h1 ;
if ( h1 . data < h2 . data ) return mergeUtil ( h1 , h2 ) ; else return mergeUtil ( h2 , h1 ) ; }
public static void main ( String [ ] args ) { Node head1 = newNode ( 1 ) ; head1 . next = newNode ( 3 ) ; head1 . next . next = newNode ( 5 ) ;
Node head2 = newNode ( 0 ) ; head2 . next = newNode ( 2 ) ; head2 . next . next = newNode ( 4 ) ;
Node mergedhead = merge ( head1 , head2 ) ; printList ( mergedhead ) ; } }
static class Node { int data ; Node next ; } ;
static Node swapNodes ( Node head_ref , Node currX , Node currY , Node prevY ) {
head_ref = currY ;
prevY . next = currX ;
Node temp = currY . next ; currY . next = currX . next ; currX . next = temp ; return head_ref ; }
static Node recurSelectionSort ( Node head ) {
if ( head . next == null ) return head ;
Node min = head ;
Node beforeMin = null ; Node ptr ;
for ( ptr = head ; ptr . next != null ; ptr = ptr . next ) {
if ( ptr . next . data < min . data ) { min = ptr . next ; beforeMin = ptr ; } }
if ( min != head ) head = swapNodes ( head , head , min , beforeMin ) ;
head . next = recurSelectionSort ( head . next ) ; return head ; }
static Node sort ( Node head_ref ) {
if ( ( head_ref ) == null ) return null ;
head_ref = recurSelectionSort ( head_ref ) ; return head_ref ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ;
( head_ref ) = new_node ; return head_ref ; }
static void printList ( Node head ) { while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; head = head . next ; } }
public static void main ( String args [ ] ) { Node head = null ;
head = push ( head , 6 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 12 ) ; head = push ( head , 10 ) ; System . out . println ( " Linked ▁ list ▁ before ▁ sorting : " ) ; printList ( head ) ;
head = sort ( head ) ; System . out . print ( " Linked list after sorting : "); printList ( head ) ; } }
static Node head ;
static class Node { int data ; Node next ;
Node ( int d ) { data = d ; next = null ; } }
static void insertAtMid ( int x ) {
if ( head == null ) head = new Node ( x ) ; else {
Node newNode = new Node ( x ) ; Node ptr = head ; int len = 0 ;
while ( ptr != null ) { len ++ ; ptr = ptr . next ; }
int count = ( ( len % 2 ) == 0 ) ? ( len / 2 ) : ( len + 1 ) / 2 ; ptr = head ;
while ( count -- > 1 ) ptr = ptr . next ;
newNode . next = ptr . next ; ptr . next = newNode ; } }
static void display ( ) { Node temp = head ; while ( temp != null ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } }
head = null ; head = new Node ( 1 ) ; head . next = new Node ( 2 ) ; head . next . next = new Node ( 4 ) ; head . next . next . next = new Node ( 5 ) ; System . out . println ( " Linked ▁ list ▁ before ▁ " + " insertion : ▁ " ) ; display ( ) ; int x = 3 ; insertAtMid ( x ) ; System . out . println ( " Linked list after " + ▁ " insertion : "); display ( ) ; } }
static Node head ;
static class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } }
static void insertAtMid ( int x ) {
if ( head == null ) head = new Node ( x ) ; else {
Node newNode = new Node ( x ) ;
Node slow = head ; Node fast = head . next ; while ( fast != null && fast . next != null ) {
slow = slow . next ;
fast = fast . next . next ; }
newNode . next = slow . next ; slow . next = newNode ; } }
static void display ( ) { Node temp = head ; while ( temp != null ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } }
head = null ; head = new Node ( 1 ) ; head . next = new Node ( 2 ) ; head . next . next = new Node ( 4 ) ; head . next . next . next = new Node ( 5 ) ; System . out . println ( " Linked ▁ list ▁ before " + " ▁ insertion : ▁ " ) ; display ( ) ; int x = 3 ; insertAtMid ( x ) ; System . out . println ( " Linked list after " + ▁ " insertion : "); display ( ) ; } }
static class Node { int data ; Node next ; }
static Node getNode ( int data ) {
Node newNode = new Node ( ) ;
newNode . data = data ; newNode . next = null ; return newNode ; }
static void insertAfterNthNode ( Node head , int n , int x ) {
if ( head == null ) return ;
Node newNode = getNode ( x ) ; Node ptr = head ; int len = 0 , i ;
while ( ptr != null ) { len ++ ; ptr = ptr . next ; }
ptr = head ; for ( i = 1 ; i <= ( len - n ) ; i ++ ) ptr = ptr . next ;
newNode . next = ptr . next ; ptr . next = newNode ; }
static void printList ( Node head ) { while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; head = head . next ; } }
Node head = getNode ( 1 ) ; head . next = getNode ( 3 ) ; head . next . next = getNode ( 4 ) ; head . next . next . next = getNode ( 5 ) ; int n = 4 , x = 2 ; System . out . print ( " Original ▁ Linked ▁ List : ▁ " ) ; printList ( head ) ; insertAfterNthNode ( head , n , x ) ; System . out . println ( ) ; System . out . print ( " Linked ▁ List ▁ After ▁ Insertion : ▁ " ) ; printList ( head ) ; } }
static class Node { int data ; Node next ; }
static Node getNode ( int data ) {
Node newNode = new Node ( ) ;
newNode . data = data ; newNode . next = null ; return newNode ; }
static void insertAfterNthNode ( Node head , int n , int x ) {
if ( head == null ) return ;
Node newNode = getNode ( x ) ;
Node slow_ptr = head ; Node fast_ptr = head ;
for ( int i = 1 ; i <= n - 1 ; i ++ ) fast_ptr = fast_ptr . next ;
while ( fast_ptr . next != null ) {
slow_ptr = slow_ptr . next ; fast_ptr = fast_ptr . next ; }
newNode . next = slow_ptr . next ; slow_ptr . next = newNode ; }
static void printList ( Node head ) { while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; head = head . next ; } }
Node head = getNode ( 1 ) ; head . next = getNode ( 3 ) ; head . next . next = getNode ( 4 ) ; head . next . next . next = getNode ( 5 ) ; int n = 4 , x = 2 ; System . out . println ( " Original ▁ Linked ▁ List : ▁ " ) ; printList ( head ) ; insertAfterNthNode ( head , n , x ) ; System . out . println ( ) ; System . out . println ( " Linked ▁ List ▁ After ▁ Insertion : ▁ " ) ; printList ( head ) ; } }
static class Node { int data ; Node next ; } ; static Node tail ;
static Node rotateHelper ( Node blockHead , Node blockTail , int d , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { Node temp = blockHead ; for ( int i = 1 ; temp . next . next != null && i < k - 1 ; i ++ ) temp = temp . next ; blockTail . next = blockHead ; tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , k ) ; }
if ( d < 0 ) { blockTail . next = blockHead ; tail = blockHead ; return rotateHelper ( blockHead . next , blockHead , d + 1 , k ) ; } return blockHead ; }
static Node rotateByBlocks ( Node head , int k , int d ) {
if ( head == null head . next == null ) return head ;
if ( d == 0 ) return head ; Node temp = head ; tail = null ;
int i ; for ( i = 1 ; temp . next != null && i < k ; i ++ ) temp = temp . next ;
Node nextBlock = temp . next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , i ) ; else head = rotateHelper ( head , temp , d % k , k ) ;
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
static Node push ( Node head_ref , int new_data ) { Node new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } }
Node head = null ;
for ( int i = 9 ; i > 0 ; i -= 1 ) head = push ( head , i ) ; System . out . print ( "Given linked list NEW_LINE"); printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; System . out . print ( " Rotated by blocks Linked list "); printList ( head ) ; } }
static class Node { int data ; Node next ; } ;
static int countRotation ( Node head ) {
int count = 0 ;
int min = head . data ;
while ( head != null ) {
if ( min > head . data ) break ; count ++ ;
head = head . next ; } return count ; }
static Node push ( Node head , int data ) {
Node newNode = new Node ( ) ;
newNode . data = data ;
newNode . next = ( head ) ;
( head ) = newNode ; return head ; }
static void printList ( Node node ) { while ( node != null ) { System . out . printf ( " % d ▁ " , node . data ) ; node = node . next ; } }
Node head = null ;
head = push ( head , 12 ) ; head = push ( head , 11 ) ; head = push ( head , 8 ) ; head = push ( head , 5 ) ; head = push ( head , 18 ) ; head = push ( head , 15 ) ; printList ( head ) ; System . out . println ( ) ; System . out . print ( " Linked ▁ list ▁ rotated ▁ elements : ▁ " ) ;
System . out . print ( countRotation ( head ) + "NEW_LINE"); } }
static class Node { int data ; Node next ; Node ( int data ) { this . data = data ; next = null ; } } static Node head ;
static void setMiddleHead ( ) { if ( head == null ) return ;
Node one_node = head ;
Node two_node = head ;
Node prev = null ; while ( two_node != null && two_node . next != null ) {
prev = one_node ;
two_node = two_node . next . next ;
one_node = one_node . next ; }
prev . next = prev . next . next ; one_node . next = head ; head = one_node ; }
static void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
static void printList ( Node ptr ) { while ( ptr != null ) { System . out . print ( ptr . data + " ▁ " ) ; ptr = ptr . next ; } System . out . println ( ) ; }
head = null ; int i ; for ( i = 5 ; i > 0 ; i -- ) push ( i ) ; System . out . print ( " ▁ list ▁ before : ▁ " ) ; printList ( head ) ; setMiddleHead ( ) ; System . out . print ( " ▁ list ▁ After : ▁ " ) ; printList ( head ) ; } }
public void InsertAfter ( Node prev_Node , int new_data ) {
if ( prev_Node == null ) { System . out . println ( " The ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ NULL ▁ " ) ; return ; }
Node new_node = new Node ( new_data ) ;
new_node . next = prev_Node . next ;
prev_Node . next = new_node ;
new_node . prev = prev_Node ;
if ( new_node . next != null ) new_node . next . prev = new_node ; }
class GFG { static class Node { int data ; Node next , prev ; } ;
static Node insert ( Node head_ref , int data ) {
Node new_node = new Node ( ) ;
new_node . data = data ;
if ( head_ref == null ) { new_node . next = new_node ; new_node . prev = new_node ; } else {
Node last = ( head_ref ) . prev ;
new_node . next = head_ref ; new_node . prev = last ;
last . next = ( head_ref ) . prev = new_node ; }
head_ref = new_node ; return head_ref ; }
static Node merge ( Node first , Node second ) {
if ( first == null ) return second ;
if ( second == null ) return first ;
if ( first . data < second . data ) { first . next = merge ( first . next , second ) ; first . next . prev = first ; first . prev = null ; return first ; } else { second . next = merge ( first , second . next ) ; second . next . prev = second ; second . prev = null ; return second ; } }
static Node mergeUtil ( Node head1 , Node head2 ) {
if ( head1 == null ) return head2 ;
if ( head2 == null ) return head1 ;
Node last_node ; if ( head1 . prev . data < head2 . prev . data ) last_node = head2 . prev ; else last_node = head1 . prev ;
head1 . prev . next = head2 . prev . next = null ;
Node finalHead = merge ( head1 , head2 ) ;
finalHead . prev = last_node ; last_node . next = finalHead ; return finalHead ; }
static void printList ( Node head ) { Node temp = head ; while ( temp . next != head ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } System . out . print ( temp . data + " ▁ " ) ; }
public static void main ( String args [ ] ) { Node head1 = null , head2 = null ;
head1 = insert ( head1 , 8 ) ; head1 = insert ( head1 , 5 ) ; head1 = insert ( head1 , 3 ) ; head1 = insert ( head1 , 1 ) ;
head2 = insert ( head2 , 11 ) ; head2 = insert ( head2 , 9 ) ; head2 = insert ( head2 , 7 ) ; head2 = insert ( head2 , 2 ) ; Node newHead = mergeUtil ( head1 , head2 ) ; System . out . print ( " Final ▁ Sorted ▁ List : ▁ " ) ; printList ( newHead ) ; } }
class GFG { static class Node { int data ; Node prev , next ; } ; static Node newNode ( int val ) { Node temp = new Node ( ) ; temp . data = val ; temp . prev = temp . next = null ; return temp ; } static void printList ( Node head ) { while ( head . next != null ) { System . out . print ( head . data + " ▁ < - > ▁ " ) ; head = head . next ; } System . out . println ( head . data ) ; }
static Node insert ( Node head , int val ) { Node temp = newNode ( val ) ; temp . next = head ; ( head ) . prev = temp ; ( head ) = temp ; return head ; }
static Node reverseList ( Node head ) { Node left = head , right = head ;
while ( right . next != null ) right = right . next ;
while ( left != right && left . prev != right ) {
int t = left . data ; left . data = right . data ; right . data = t ;
left = left . next ;
right = right . prev ; } return head ; }
public static void main ( String args [ ] ) { Node head = newNode ( 5 ) ; head = insert ( head , 4 ) ; head = insert ( head , 3 ) ; head = insert ( head , 2 ) ; head = insert ( head , 1 ) ; printList ( head ) ; System . out . println ( " List ▁ After ▁ Reversing " ) ; head = reverseList ( head ) ; printList ( head ) ; } }
static class Node { int data ; Node prev , next ; } ;
static Node getNode ( int data ) {
Node newNode = new Node ( ) ;
newNode . data = data ; newNode . prev = newNode . next = null ; return newNode ; }
static Node sortedInsert ( Node head_ref , Node newNode ) { Node current ;
if ( head_ref == null ) head_ref = newNode ;
else if ( ( head_ref ) . data >= newNode . data ) { newNode . next = head_ref ; newNode . next . prev = newNode ; head_ref = newNode ; } else { current = head_ref ;
while ( current . next != null && current . next . data < newNode . data ) current = current . next ;
newNode . next = current . next ;
if ( current . next != null ) newNode . next . prev = newNode ; current . next = newNode ; newNode . prev = current ; } return head_ref ; }
static Node insertionSort ( Node head_ref ) {
Node sorted = null ;
Node current = head_ref ; while ( current != null ) {
Node next = current . next ;
current . prev = current . next = null ;
sorted = sortedInsert ( sorted , current ) ;
current = next ; }
head_ref = sorted ; return head_ref ; }
static void printList ( Node head ) { while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; head = head . next ; } }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ; new_node . prev = null ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
Node head = null ;
head = push ( head , 9 ) ; head = push ( head , 3 ) ; head = push ( head , 5 ) ; head = push ( head , 10 ) ; head = push ( head , 12 ) ; head = push ( head , 8 ) ; System . out . println ( "Doubly Linked List Before SortingNEW_LINE"); printList ( head ) ; head = insertionSort ( head ) ; System . out . println ( " Doubly Linked List After Sorting "); printList ( head ) ; } }
static class Node { char data ; Node next ; Node prev ; } ;
static Node push ( Node head_ref , char new_data ) { Node new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; new_node . prev = null ; if ( head_ref != null ) head_ref . prev = new_node ; head_ref = new_node ; return head_ref ; }
static boolean isPalindrome ( Node left ) { if ( left == null ) return true ;
Node right = left ; while ( right . next != null ) right = right . next ; while ( left != right ) { if ( left . data != right . data ) return false ; left = left . next ; right = right . prev ; } return true ; }
public static void main ( String [ ] args ) { Node head = null ; head = push ( head , ' l ' ) ; head = push ( head , ' e ' ) ; head = push ( head , ' v ' ) ; head = push ( head , ' e ' ) ; head = push ( head , ' l ' ) ; if ( isPalindrome ( head ) ) System . out . printf ( " It ▁ is ▁ Palindrome " ) ; else System . out . printf ( " Not ▁ Palindrome " ) ; } }
class Node { int data ; Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
void printLevels ( Node node , int low , int high ) { Queue < Node > Q = new LinkedList < > ( ) ;
Node marker = new Node ( 4 ) ;
int level = 1 ;
Q . add ( node ) ; Q . add ( marker ) ;
while ( Q . isEmpty ( ) == false ) {
Node n = Q . peek ( ) ; Q . remove ( ) ;
if ( n == marker ) {
System . out . println ( " " ) ; level ++ ;
if ( Q . isEmpty ( ) == true level > high ) break ;
Q . add ( marker ) ;
continue ; }
if ( level >= low ) System . out . print ( n . data + " ▁ " ) ;
if ( n . left != null ) Q . add ( n . left ) ; if ( n . right != null ) Q . add ( n . right ) ; } }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 20 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 22 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 12 ) ; tree . root . left . right . left = new Node ( 10 ) ; tree . root . left . right . right = new Node ( 14 ) ; System . out . print ( " Level ▁ Order ▁ traversal ▁ between ▁ given ▁ two ▁ levels ▁ is ▁ " ) ; tree . printLevels ( tree . root , 2 , 3 ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ; void printKDistant ( Node node , int k ) { if ( node == null k < 0 ) return ; if ( k == 0 ) { System . out . print ( node . data + " ▁ " ) ; return ; } printKDistant ( node . left , k - 1 ) ; printKDistant ( node . right , k - 1 ) ; }
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 8 ) ; tree . printKDistant ( tree . root , 2 ) ; } }
static class Node { int data ; Node left , right ; }
static Node newNode ( int data ) { Node newnode = new Node ( ) ; newnode . data = data ; newnode . left = newnode . right = null ; return newnode ; }
static boolean printKDistant ( Node root , int klevel ) { Queue < Node > q = new LinkedList < > ( ) ; int level = 1 ; boolean flag = false ; q . add ( root ) ;
q . add ( null ) ; while ( q . size ( ) > 0 ) { Node temp = q . peek ( ) ;
if ( level == klevel && temp != null ) { flag = true ; System . out . print ( temp . data + " ▁ " ) ; } q . remove ( ) ; if ( temp == null ) { if ( q . peek ( ) != null ) q . add ( null ) ; level += 1 ;
if ( level > klevel ) break ; } else { if ( temp . left != null ) q . add ( temp . left ) ; if ( temp . right != null ) q . add ( temp . right ) ; } } System . out . println ( ) ; return flag ; }
Node root = newNode ( 20 ) ; root . left = newNode ( 10 ) ; root . right = newNode ( 30 ) ; root . left . left = newNode ( 5 ) ; root . left . right = newNode ( 15 ) ; root . left . right . left = newNode ( 12 ) ; root . right . left = newNode ( 25 ) ; root . right . right = newNode ( 40 ) ; System . out . print ( " data ▁ at ▁ level ▁ 1 ▁ : ▁ " ) ; boolean ret = printKDistant ( root , 1 ) ; if ( ret == false ) System . out . print ( " Number ▁ exceeds ▁ total ▁ " + "number of levelsNEW_LINE"); System . out . print ( " data ▁ at ▁ level ▁ 2 ▁ : ▁ " ) ; ret = printKDistant ( root , 2 ) ; if ( ret == false ) System . out . print ( " Number ▁ exceeds ▁ total ▁ " + "number of levelsNEW_LINE"); System . out . print ( " data ▁ at ▁ level ▁ 3 ▁ : ▁ " ) ; ret = printKDistant ( root , 3 ) ; if ( ret == false ) System . out . print ( " Number ▁ exceeds ▁ total ▁ " + "number of levelsNEW_LINE"); System . out . print ( " data ▁ at ▁ level ▁ 6 ▁ : ▁ " ) ; ret = printKDistant ( root , 6 ) ; if ( ret == false ) System . out . print ( " Number ▁ exceeds ▁ total " + "number of levelsNEW_LINE"); } }
static class Node { public int data ; public Node left , right ; } ;
static void printLeafNodes ( Node root ) {
if ( root == null ) return ;
if ( root . left == null && root . right == null ) { System . out . print ( root . data + " ▁ " ) ; return ; }
if ( root . left != null ) printLeafNodes ( root . left ) ;
if ( root . right != null ) printLeafNodes ( root . right ) ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . left = null ; temp . right = null ; return temp ; }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . right . left = newNode ( 5 ) ; root . right . right = newNode ( 8 ) ; root . right . left . left = newNode ( 6 ) ; root . right . left . right = newNode ( 7 ) ; root . right . right . left = newNode ( 9 ) ; root . right . right . right = newNode ( 10 ) ;
printLeafNodes ( root ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
void printkdistanceNodeDown ( Node node , int k ) {
if ( node == null k < 0 ) return ;
if ( k == 0 ) { System . out . print ( node . data ) ; System . out . println ( " " ) ; return ; }
printkdistanceNodeDown ( node . left , k - 1 ) ; printkdistanceNodeDown ( node . right , k - 1 ) ; }
int printkdistanceNode ( Node node , Node target , int k ) {
if ( node == null ) return - 1 ;
if ( node == target ) { printkdistanceNodeDown ( node , k ) ; return 0 ; }
int dl = printkdistanceNode ( node . left , target , k ) ;
if ( dl != - 1 ) {
if ( dl + 1 == k ) { System . out . print ( node . data ) ; System . out . println ( " " ) ; }
else printkdistanceNodeDown ( node . right , k - dl - 2 ) ;
return 1 + dl ; }
int dr = printkdistanceNode ( node . right , target , k ) ; if ( dr != - 1 ) { if ( dr + 1 == k ) { System . out . print ( node . data ) ; System . out . println ( " " ) ; } else printkdistanceNodeDown ( node . left , k - dr - 2 ) ; return 1 + dr ; }
return - 1 ; }
tree . root = new Node ( 20 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 22 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 12 ) ; tree . root . left . right . left = new Node ( 10 ) ; tree . root . left . right . right = new Node ( 14 ) ; Node target = tree . root . left . right ; tree . printkdistanceNode ( tree . root , target , 2 ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
void printSingles ( Node node ) {
if ( node == null ) return ;
if ( node . left != null && node . right != null ) { printSingles ( node . left ) ; printSingles ( node . right ) ; }
else if ( node . right != null ) { System . out . print ( node . right . data + " ▁ " ) ; printSingles ( node . right ) ; }
else if ( node . left != null ) { System . out . print ( node . left . data + " ▁ " ) ; printSingles ( node . left ) ; } }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . right = new Node ( 4 ) ; tree . root . right . left = new Node ( 5 ) ; tree . root . right . left . right = new Node ( 6 ) ; tree . printSingles ( tree . root ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
void kDistantFromLeafUtil ( Node node , int path [ ] , boolean visited [ ] , int pathLen , int k ) {
if ( node == null ) return ;
path [ pathLen ] = node . data ; visited [ pathLen ] = false ; pathLen ++ ;
if ( node . left == null && node . right == null && pathLen - k - 1 >= 0 && visited [ pathLen - k - 1 ] == false ) { System . out . print ( path [ pathLen - k - 1 ] + " ▁ " ) ; visited [ pathLen - k - 1 ] = true ; return ; }
kDistantFromLeafUtil ( node . left , path , visited , pathLen , k ) ; kDistantFromLeafUtil ( node . right , path , visited , pathLen , k ) ; }
void printKDistantfromLeaf ( Node node , int k ) { int path [ ] = new int [ 1000 ] ; boolean visited [ ] = new boolean [ 1000 ] ; kDistantFromLeafUtil ( node , path , visited , 0 , k ) ; }
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 6 ) ; tree . root . right . right = new Node ( 7 ) ; tree . root . right . left . right = new Node ( 8 ) ; System . out . println ( " ▁ Nodes ▁ at ▁ distance ▁ 2 ▁ are ▁ : " ) ; tree . printKDistantfromLeaf ( tree . root , 2 ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
int printKDistantfromLeaf ( Node node , int k ) { if ( node == null ) return - 1 ; int lk = printKDistantfromLeaf ( node . left , k ) ; int rk = printKDistantfromLeaf ( node . right , k ) ; boolean isLeaf = lk == - 1 && lk == rk ; if ( lk == 0 || rk == 0 || ( isLeaf && k == 0 ) ) System . out . print ( " ▁ " + node . data ) ; if ( isLeaf && k > 0 )
return k - 1 ; if ( lk > 0 && lk < k )
return lk - 1 ; if ( rk > 0 && rk < k )
return rk - 1 ; return - 2 ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ;
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . left = new Node ( 6 ) ; tree . root . right . right = new Node ( 7 ) ; tree . root . right . left . right = new Node ( 8 ) ; System . out . println ( " ▁ Nodes ▁ at ▁ distance ▁ 2 ▁ are ▁ : " ) ; tree . printKDistantfromLeaf ( tree . root , 2 ) ; } }
class GFG { static final int COUNT = 10 ;
static class Node { int data ; Node left , right ;
Node ( int data ) { this . data = data ; this . left = null ; this . right = null ; } } ;
static void print2DUtil ( Node root , int space ) {
if ( root == null ) return ;
space += COUNT ;
print2DUtil ( root . right , space ) ;
System . out . print ( "NEW_LINE"); for ( int i = COUNT ; i < space ; i ++ ) System . out . print ( " ▁ " ) ; System . out . print ( root . data + "NEW_LINE");
print2DUtil ( root . left , space ) ; }
static void print2D ( Node root ) {
print2DUtil ( root , 0 ) ; }
public static void main ( String args [ ] ) { Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; root . left . left . left = new Node ( 8 ) ; root . left . left . right = new Node ( 9 ) ; root . left . right . left = new Node ( 10 ) ; root . left . right . right = new Node ( 11 ) ; root . right . left . left = new Node ( 12 ) ; root . right . left . right = new Node ( 13 ) ; root . right . right . left = new Node ( 14 ) ; root . right . right . right = new Node ( 15 ) ; print2D ( root ) ; } }
class Node { int data ; Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } }
class BinaryTree { Node root ; static int max_level = 0 ;
void leftViewUtil ( Node node , int level ) {
if ( node == null ) return ;
if ( max_level < level ) { System . out . print ( " ▁ " + node . data ) ; max_level = level ; }
leftViewUtil ( node . left , level + 1 ) ; leftViewUtil ( node . right , level + 1 ) ; }
void leftView ( ) { leftViewUtil ( root , 1 ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 12 ) ; tree . root . left = new Node ( 10 ) ; tree . root . right = new Node ( 30 ) ; tree . root . right . left = new Node ( 25 ) ; tree . root . right . right = new Node ( 40 ) ; tree . leftView ( ) ; } }
static int rotate ( int arr [ ] , int N , int X ) {
long nextPower = 1 ;
while ( nextPower <= N ) nextPower *= 2 ;
if ( X == 1 ) return ( int ) nextPower - N ;
long prevPower = nextPower / 2 ;
return 2 * ( N - ( int ) prevPower ) + 1 ; }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int X = 1 ; int N = arr . length ; System . out . println ( rotate ( arr , N , X ) ) ; } }
static void print ( int mat [ ] [ ] ) {
for ( int i = 0 ; i < mat . length ; i ++ ) {
for ( int j = 0 ; j < mat [ 0 ] . length ; j ++ )
System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
static void performSwap ( int mat [ ] [ ] , int i , int j ) { int N = mat . length ;
int ei = N - 1 - i ;
int ej = N - 1 - j ;
int temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ ej ] [ i ] ; mat [ ej ] [ i ] = mat [ ei ] [ ej ] ; mat [ ei ] [ ej ] = mat [ j ] [ ei ] ; mat [ j ] [ ei ] = temp ; }
static void rotate ( int mat [ ] [ ] , int N , int K ) {
K = K % 4 ;
while ( K -- > 0 ) {
for ( int i = 0 ; i < N / 2 ; i ++ ) {
for ( int j = i ; j < N - i - 1 ; j ++ ) {
if ( i != j && ( i + j ) != N - 1 ) {
performSwap ( mat , i , j ) ; } } } }
print ( mat ) ; }
public static void main ( String [ ] args ) { int K = 5 ; int mat [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 6 , 7 , 8 , 9 } , { 11 , 12 , 13 , 14 } , { 16 , 17 , 18 , 19 } , } ; int N = mat . length ; rotate ( mat , N , K ) ; } }
static void findMaximumZeros ( String str , int n ) {
int c0 = 0 ;
for ( int i = 0 ; i < n ; ++ i ) { if ( str . charAt ( i ) == '0' ) c0 ++ ; }
if ( c0 == n ) {
System . out . print ( n ) ; return ; }
String s = str + str ;
int mx = 0 ;
for ( int i = 0 ; i < n ; ++ i ) {
int cs = 0 ; int ce = 0 ;
for ( int j = i ; j < i + n ; ++ j ) { if ( s . charAt ( j ) == '0' ) cs ++ ; else break ; }
for ( int j = i + n - 1 ; j >= i ; -- j ) { if ( s . charAt ( j ) == '0' ) ce ++ ; else break ; }
int val = cs + ce ;
mx = Math . max ( val , mx ) ; }
System . out . print ( mx ) ; }
String s = "1001" ;
int n = s . length ( ) ; findMaximumZeros ( s , n ) ; } }
static void findMaximumZeros ( String str , int n ) {
int c0 = 0 ; for ( int i = 0 ; i < n ; ++ i ) { if ( str . charAt ( i ) == '0' ) c0 ++ ; }
if ( c0 == n ) {
System . out . print ( n ) ; return ; }
int mx = 0 ;
int cnt = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( str . charAt ( i ) == '0' ) cnt ++ ; else { mx = Math . max ( mx , cnt ) ; cnt = 0 ; } }
mx = Math . max ( mx , cnt ) ;
int start = 0 , end = n - 1 ; cnt = 0 ;
while ( str . charAt ( start ) != '1' && start < n ) { cnt ++ ; start ++ ; }
while ( str . charAt ( end ) != '1' && end >= 0 ) { cnt ++ ; end -- ; }
mx = Math . max ( mx , cnt ) ;
System . out . println ( mx ) ; }
String s = "1001" ;
int n = s . length ( ) ; findMaximumZeros ( s , n ) ; } }
static void reverse ( int arr [ ] , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
static void rotateMatrix ( int mat [ ] [ ] ) { int i = 0 ;
for ( int rows [ ] : mat ) {
reverse ( rows , 0 , rows . length - 1 ) ;
reverse ( rows , 0 , i - 1 ) ;
reverse ( rows , i , rows . length - 1 ) ;
i ++ ; }
for ( int rows [ ] : mat ) { for ( int cols : rows ) { System . out . print ( cols + " ▁ " ) ; } System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; rotateMatrix ( mat ) ; } }
static class Node { int data ; Node left , right ; }
static int getLeafCount ( Node node ) {
if ( node == null ) { return 0 ; }
Queue < Node > q = new LinkedList < > ( ) ;
int count = 0 ; q . add ( node ) ; while ( ! q . isEmpty ( ) ) { Node temp = q . peek ( ) ; q . poll ( ) ; if ( temp . left != null ) { q . add ( temp . left ) ; } if ( temp . right != null ) { q . add ( temp . right ) ; } if ( temp . left == null && temp . right == null ) { count ++ ; } } return count ; }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ;
System . out . println ( getLeafCount ( root ) ) ; } } }
static void stringShift ( String s , int [ ] [ ] shift ) { int val = 0 ; for ( int i = 0 ; i < shift . length ; ++ i )
if ( shift [ i ] [ 0 ] == 0 ) val -= shift [ i ] [ 1 ] ; else val += shift [ i ] [ 1 ] ;
int len = s . length ( ) ;
val = val % len ;
String result = " " ;
if ( val > 0 ) result = s . substring ( len - val , ( len - val ) + val ) + s . substring ( 0 , len - val ) ;
else result = s . substring ( - val , len + val ) + s . substring ( 0 , - val ) ; System . out . println ( result ) ; }
public static void main ( String [ ] args ) { String s = " abc " ; int [ ] [ ] shift = new int [ ] [ ] { { 0 , 1 } , { 1 , 2 } } ; stringShift ( s , shift ) ; } }
static void rotateArray ( int [ ] arr , int N ) {
int [ ] v = arr ;
Arrays . sort ( v ) ;
for ( int i = 1 ; i <= N ; ++ i ) {
int x = arr [ N - 1 ] ; i = N - 1 ; while ( i > 0 ) { arr [ i ] = arr [ i - 1 ] ; arr [ 0 ] = x ; i -= 1 ; }
if ( arr == v ) { System . out . print ( " YES " ) ; return ; } }
System . out . print ( " NO " ) ; }
int [ ] arr = { 3 , 4 , 5 , 1 , 2 } ;
int N = arr . length ;
rotateArray ( arr , N ) ; } }
static void findLargestRotation ( int num ) {
int ans = num ;
int len = ( int ) Math . floor ( ( ( int ) Math . log10 ( num ) ) + 1 ) ; int x = ( int ) Math . pow ( 10 , len - 1 ) ;
for ( int i = 1 ; i < len ; i ++ ) {
int lastDigit = num % 10 ;
num = num / 10 ;
num += ( lastDigit * x ) ;
if ( num > ans ) { ans = num ; } }
System . out . print ( ans ) ; }
public static void main ( String [ ] args ) { int N = 657 ; findLargestRotation ( N ) ; } }
static int numberOfDigit ( int N ) {
int digit = 0 ;
while ( N > 0 ) {
digit ++ ;
N /= 10 ; } return digit ; }
static void rotateNumberByK ( int N , int K ) {
int X = numberOfDigit ( N ) ;
K = ( ( K % X ) + X ) % X ;
int left_no = N / ( int ) ( Math . pow ( 10 , X - K ) ) ;
N = N % ( int ) ( Math . pow ( 10 , X - K ) ) ;
int left_digit = numberOfDigit ( left_no ) ;
N = ( N * ( int ) ( Math . pow ( 10 , left_digit ) ) ) + left_no ; System . out . println ( N ) ; }
public static void main ( String args [ ] ) { int N = 12345 , K = 7 ;
rotateNumberByK ( N , K ) ; } }
static void minMovesToSort ( int arr [ ] , int N ) {
int count = 0 ;
int index = 0 ;
for ( int i = 0 ; i < N - 1 ; i ++ ) {
if ( arr [ i ] < arr [ i + 1 ] ) {
count ++ ;
index = i ; } }
if ( count == 0 ) { System . out . print ( "0" ) ; } else if ( count == N - 1 ) { System . out . print ( N - 1 ) ; } else if ( count == 1 && arr [ 0 ] <= arr [ N - 1 ] ) { System . out . print ( index + 1 ) ; }
else { System . out . print ( " - 1" ) ; } }
int [ ] arr = { 2 , 1 , 5 , 4 , 2 } ; int N = arr . length ;
minMovesToSort ( arr , N ) ; } }
import java . util . * ; class GFG { static int N = 3 ;
static int findMaximumDiagonalSumOMatrixf ( int A [ ] [ ] ) {
int maxDiagonalSum = Integer . MIN_VALUE ;
for ( int i = 0 ; i < N ; i ++ ) {
int curr = 0 ;
for ( int j = 0 ; j < N ; j ++ ) {
curr += A [ j ] [ ( i + j ) % N ] ; }
maxDiagonalSum = Math . max ( maxDiagonalSum , curr ) ; }
for ( int i = 0 ; i < N ; i ++ ) {
int curr = 0 ;
for ( int j = 0 ; j < N ; j ++ ) {
curr += A [ ( i + j ) % N ] [ j ] ; }
maxDiagonalSum = Math . max ( maxDiagonalSum , curr ) ; } return maxDiagonalSum ; }
public static void main ( String [ ] args ) { int [ ] [ ] mat = { { 1 , 1 , 2 } , { 2 , 1 , 2 } , { 1 , 2 , 2 } } ; System . out . println ( findMaximumDiagonalSumOMatrixf ( mat ) ) ; } }
static void diagonalSumPerfectSquare ( int [ ] arr , int N ) {
for ( int i = 0 ; i < N ; i ++ ) {
for ( int j = 0 ; j < N ; j ++ ) { System . out . print ( arr [ ( j + i ) % 7 ] + " ▁ " ) ; } System . out . println ( ) ; } }
int N = 7 ; int [ ] arr = new int [ N ] ;
for ( int i = 0 ; i < N ; i ++ ) { arr [ i ] = i + 1 ; }
diagonalSumPerfectSquare ( arr , N ) ; } }
static class Node { int data ; Node left , right ; }
static int countLeaves ( Node node ) {
if ( node == null ) return 0 ;
if ( node . left == null && node . right == null ) return 1 ;
return countLeaves ( node . left ) + countLeaves ( node . right ) ; }
public static void main ( String [ ] args ) { Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ;
System . out . println ( countLeaves ( root ) ) ; } }
static int MaxSum ( int [ ] arr , int n , int k ) { int i , max_sum = 0 , sum = 0 ;
for ( i = 0 ; i < k ; i ++ ) { sum += arr [ i ] ; } max_sum = sum ;
while ( i < n ) {
sum = sum - arr [ i - k ] + arr [ i ] ; if ( max_sum < sum ) { max_sum = sum ; } i ++ ; }
return max_sum ; }
static int gcd ( int n1 , int n2 ) {
if ( n2 == 0 ) { return n1 ; }
else { return gcd ( n2 , n1 % n2 ) ; } }
static int [ ] RotateArr ( int [ ] arr , int n , int d ) {
int i = 0 , j = 0 ; d = d % n ;
int no_of_sets = gcd ( d , n ) ; for ( i = 0 ; i < no_of_sets ; i ++ ) { int temp = arr [ i ] ; j = i ;
while ( true ) { int k = j + d ; if ( k >= n ) k = k - n ; if ( k == i ) break ; arr [ j ] = arr [ k ] ; j = k ; }
arr [ j ] = temp ; }
return arr ; }
static void performQuery ( int [ ] arr , int Q [ ] [ ] , int q ) { int N = arr . length ;
for ( int i = 0 ; i < q ; i ++ ) {
if ( Q [ i ] [ 0 ] == 1 ) { arr = RotateArr ( arr , N , Q [ i ] [ 1 ] ) ;
for ( int t : arr ) { System . out . print ( t + " ▁ " ) ; } System . out . print ( "NEW_LINE"); }
else { System . out . print ( MaxSum ( arr , N , Q [ i ] [ 1 ] ) + "NEW_LINE"); } } }
int [ ] arr = { 1 , 2 , 3 , 4 , 5 } ; int q = 5 ;
int Q [ ] [ ] = { { 1 , 2 } , { 2 , 3 } , { 1 , 3 } , { 1 , 1 } , { 2 , 4 } } ;
performQuery ( arr , Q , q ) ; } }
public static int getMinimumRemoval ( String str ) { int n = str . length ( ) ;
int ans = n ;
if ( n % 2 == 0 ) {
int [ ] freqEven = new int [ 128 ] ; int [ ] freqOdd = new int [ 128 ] ;
for ( int i = 0 ; i < n ; i ++ ) { if ( i % 2 == 0 ) { freqEven [ str . charAt ( i ) ] ++ ; } else { freqOdd [ str . charAt ( i ) ] ++ ; } }
int evenMax = 0 , oddMax = 0 ; for ( char chr = ' a ' ; chr <= ' z ' ; chr ++ ) { evenMax = Math . max ( evenMax , freqEven [ chr ] ) ; oddMax = Math . max ( oddMax , freqOdd [ chr ] ) ; }
ans = ans - evenMax - oddMax ; }
else {
int [ ] freq = new int [ 128 ] ; for ( int i = 0 ; i < n ; i ++ ) { freq [ str . charAt ( i ) ] ++ ; }
int strMax = 0 ; for ( char chr = ' a ' ; chr <= ' z ' ; chr ++ ) { strMax = Math . max ( strMax , freq [ chr ] ) ; }
ans = ans - strMax ; } return ans ; }
public static void main ( String [ ] args ) { String str = " geeksgeeks " ; System . out . print ( getMinimumRemoval ( str ) ) ; } }
static int findAltSubSeq ( String s ) {
int n = s . length ( ) , ans = Integer . MIN_VALUE ;
for ( int i = 0 ; i < 10 ; i ++ ) { for ( int j = 0 ; j < 10 ; j ++ ) { int cur = 0 , f = 0 ;
for ( int k = 0 ; k < n ; k ++ ) { if ( f == 0 && s . charAt ( k ) - '0' == i ) { f = 1 ;
cur ++ ; } else if ( f == 1 && s . charAt ( k ) - '0' == j ) { f = 0 ;
cur ++ ; } }
if ( i != j && cur % 2 == 1 )
cur -- ;
ans = Math . max ( cur , ans ) ; } }
return ans ; }
public static void main ( String [ ] args ) { String s = "100210601" ; System . out . print ( findAltSubSeq ( s ) ) ; } }
static int getFirstElement ( int a [ ] , int N , int K , int M ) {
K %= N ; int index ;
if ( K >= M )
index = ( N - K ) + ( M - 1 ) ;
else
index = ( M - K - 1 ) ; int result = a [ index ] ;
return result ; }
public static void main ( String [ ] args ) { int a [ ] = { 1 , 2 , 3 , 4 , 5 } ; int N = 5 ; int K = 3 , M = 2 ; System . out . println ( getFirstElement ( a , N , K , M ) ) ; } }
public static int getFirstElement ( int [ ] a , int N , int K , int M ) {
K %= N ;
int index = ( K + M - 1 ) % N ; int result = a [ index ] ;
return result ; }
int a [ ] = { 3 , 4 , 5 , 23 } ;
int N = a . length ;
int K = 2 , M = 1 ;
System . out . println ( getFirstElement ( a , N , K , M ) ) ; } }
static void left_rotate ( int [ ] arr ) { int last = arr [ 1 ] ; for ( int i = 3 ; i < arr . length ; i = i + 2 ) { arr [ i - 2 ] = arr [ i ] ; } arr [ arr . length - 1 ] = last ; }
static void right_rotate ( int [ ] arr ) { int start = arr [ arr . length - 2 ] ; for ( int i = arr . length - 4 ; i >= 0 ; i = i - 2 ) { arr [ i + 2 ] = arr [ i ] ; } arr [ 0 ] = start ; }
public static void rotate ( int arr [ ] ) { left_rotate ( arr ) ; right_rotate ( arr ) ; for ( int i = 0 ; i < arr . length ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ; rotate ( arr ) ; } }
static int maximumMatchingPairs ( int perm1 [ ] , int perm2 [ ] , int n ) {
int [ ] left = new int [ n ] ; int [ ] right = new int [ n ] ;
HashMap < Integer , Integer > mp1 = new HashMap < > ( ) ; HashMap < Integer , Integer > mp2 = new HashMap < > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { mp1 . put ( perm1 [ i ] , i ) ; } for ( int j = 0 ; j < n ; j ++ ) { mp2 . put ( perm2 [ j ] , j ) ; } for ( int i = 0 ; i < n ; i ++ ) {
int idx2 = mp2 . get ( perm1 [ i ] ) ; int idx1 = i ; if ( idx1 == idx2 ) {
left [ i ] = 0 ; right [ i ] = 0 ; } else if ( idx1 < idx2 ) {
left [ i ] = ( n - ( idx2 - idx1 ) ) ; right [ i ] = ( idx2 - idx1 ) ; } else {
left [ i ] = ( idx1 - idx2 ) ; right [ i ] = ( n - ( idx1 - idx2 ) ) ; } }
HashMap < Integer , Integer > freq1 = new HashMap < > ( ) ; HashMap < Integer , Integer > freq2 = new HashMap < > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { if ( freq1 . containsKey ( left [ i ] ) ) freq1 . put ( left [ i ] , freq1 . get ( left [ i ] ) + 1 ) ; else freq1 . put ( left [ i ] , 1 ) ; if ( freq2 . containsKey ( right [ i ] ) ) freq2 . put ( right [ i ] , freq2 . get ( right [ i ] ) + 1 ) ; else freq2 . put ( right [ i ] , 1 ) ; } int ans = 0 ; for ( int i = 0 ; i < n ; i ++ ) {
ans = Math . max ( ans , Math . max ( freq1 . get ( left [ i ] ) , freq2 . get ( right [ i ] ) ) ) ; }
return ans ; }
int P1 [ ] = { 5 , 4 , 3 , 2 , 1 } ; int P2 [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = P1 . length ;
System . out . print ( maximumMatchingPairs ( P1 , P2 , n ) ) ; } }
static int arr [ ] = new int [ 10000 ] ;
public static void reverse ( int arr [ ] , int s , int e ) { while ( s < e ) { int tem = arr [ s ] ; arr [ s ] = arr [ e ] ; arr [ e ] = tem ; s = s + 1 ; e = e - 1 ; } }
public static void fun ( int arr [ ] , int k ) { int n = 4 - 1 ; int v = n - k ; if ( v >= 0 ) { reverse ( arr , 0 , v ) ; reverse ( arr , v + 1 , n ) ; reverse ( arr , 0 , n ) ; } }
public static void main ( String args [ ] ) { arr [ 0 ] = 1 ; arr [ 1 ] = 2 ; arr [ 2 ] = 3 ; arr [ 3 ] = 4 ; for ( int i = 0 ; i < 4 ; i ++ ) { fun ( arr , i ) ; System . out . print ( " [ " ) ; for ( int j = 0 ; j < 4 ; j ++ ) { System . out . print ( arr [ j ] + " , ▁ " ) ; } System . out . print ( " ] " ) ; } } }
public static int countRotation ( int [ ] arr , int n ) { for ( int i = 1 ; i < n ; i ++ ) {
if ( arr [ i ] < arr [ i - 1 ] ) {
return i ; } }
return 0 ; }
public static void main ( String [ ] args ) { int [ ] arr1 = { 4 , 5 , 1 , 2 , 3 } ; System . out . println ( countRotation ( arr1 , arr1 . length ) ) ; } }
public static int countRotation ( int [ ] arr , int low , int high ) {
if ( low > high ) { return 0 ; } int mid = low + ( high - low ) / 2 ;
if ( mid < high && arr [ mid ] > arr [ mid + 1 ] ) {
return mid + 1 ; }
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) {
return mid ; }
if ( arr [ mid ] > arr [ low ] ) {
return countRotation ( arr , mid + 1 , high ) ; } if ( arr [ mid ] < arr [ high ] ) {
return countRotation ( arr , low , mid - 1 ) ; } else {
int rightIndex = countRotation ( arr , mid + 1 , high ) ; int leftIndex = countRotation ( arr , low , mid - 1 ) ; if ( rightIndex == 0 ) { return leftIndex ; } return rightIndex ; } }
public static void main ( String [ ] args ) { int [ ] arr1 = { 4 , 5 , 1 , 2 , 3 } ; System . out . println ( countRotation ( arr1 , 0 , arr1 . length - 1 ) ) ; } }
import java . util . * ; class GFG { static int MAX = 100005 ;
static int [ ] seg = new int [ 4 * MAX ] ;
static void build ( int node , int l , int r , int a [ ] ) { if ( l == r ) seg [ node ] = a [ l ] ; else { int mid = ( l + r ) / 2 ; build ( 2 * node , l , mid , a ) ; build ( 2 * node + 1 , mid + 1 , r , a ) ; seg [ node ] = ( seg [ 2 * node ] seg [ 2 * node + 1 ] ) ; } }
static int query ( int node , int l , int r , int start , int end , int a [ ] ) {
if ( l > end r < start ) return 0 ; if ( start <= l && r <= end ) return seg [ node ] ;
int mid = ( l + r ) / 2 ;
return ( ( query ( 2 * node , l , mid , start , end , a ) ) | ( query ( 2 * node + 1 , mid + 1 , r , start , end , a ) ) ) ; }
static void orsum ( int a [ ] , int n , int q , int k [ ] ) {
build ( 1 , 0 , n - 1 , a ) ;
for ( int j = 0 ; j < q ; j ++ ) {
int i = k [ j ] % ( n / 2 ) ;
int sec = query ( 1 , 0 , n - 1 , n / 2 - i , n - i - 1 , a ) ;
int first = ( query ( 1 , 0 , n - 1 , 0 , n / 2 - 1 - i , a ) | query ( 1 , 0 , n - 1 , n - i , n - 1 , a ) ) ; int temp = sec + first ;
System . out . print ( temp + "NEW_LINE"); } }
public static void main ( String [ ] args ) { int a [ ] = { 7 , 44 , 19 , 86 , 65 , 39 , 75 , 101 } ; int n = a . length ; int q = 2 ; int k [ ] = { 4 , 2 } ; orsum ( a , n , q , k ) ; } }
static void maximumEqual ( int a [ ] , int b [ ] , int n ) {
int store [ ] = new int [ ( int ) 1e5 ] ;
for ( int i = 0 ; i < n ; i ++ ) { store [ b [ i ] ] = i + 1 ; }
int ans [ ] = new int [ ( int ) 1e5 ] ;
for ( int i = 0 ; i < n ; i ++ ) {
int d = Math . abs ( store [ a [ i ] ] - ( i + 1 ) ) ;
if ( store [ a [ i ] ] < i + 1 ) { d = n - d ; }
ans [ d ] ++ ; } int finalans = 0 ;
for ( int i = 0 ; i < 1e5 ; i ++ ) finalans = Math . max ( finalans , ans [ i ] ) ;
System . out . print ( finalans + "NEW_LINE"); }
int A [ ] = { 6 , 7 , 3 , 9 , 5 } ; int B [ ] = { 7 , 3 , 9 , 5 , 6 } ; int size = A . length ;
maximumEqual ( A , B , size ) ; } }
static void rotatedSumQuery ( int arr [ ] , int n , int [ ] [ ] query , int Q ) {
int [ ] prefix = new int [ 2 * n ] ;
for ( int i = 0 ; i < n ; i ++ ) { prefix [ i ] = arr [ i ] ; prefix [ i + n ] = arr [ i ] ; }
for ( int i = 1 ; i < 2 * n ; i ++ ) prefix [ i ] += prefix [ i - 1 ] ;
int start = 0 ; for ( int q = 0 ; q < Q ; q ++ ) {
if ( query [ q ] [ 0 ] == 1 ) { int k = query [ q ] [ 1 ] ; start = ( start + k ) % n ; }
else if ( query [ q ] [ 0 ] == 2 ) { int L , R ; L = query [ q ] [ 1 ] ; R = query [ q ] [ 2 ] ;
if ( start + L == 0 )
System . out . print ( prefix [ start + R ] + "NEW_LINE"); else
System . out . print ( prefix [ start + R ] - prefix [ start + L - 1 ] + "NEW_LINE"); } } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ;
int Q = 5 ;
int [ ] [ ] query = { { 2 , 1 , 3 } , { 1 , 3 } , { 2 , 0 , 3 } , { 1 , 4 } , { 2 , 3 , 5 } } ; int n = arr . length ; rotatedSumQuery ( arr , n , query , Q ) ; } }
static void isConversionPossible ( String s1 , String s2 , int x ) { int diff = 0 , n ; n = s1 . length ( ) ;
for ( int i = 0 ; i < n ; i ++ ) {
if ( s1 . charAt ( i ) == s2 . charAt ( i ) ) continue ;
diff = ( ( int ) ( s2 . charAt ( i ) - s1 . charAt ( i ) ) + 26 ) % 26 ;
if ( diff > x ) { System . out . println ( " NO " ) ; return ; } } System . out . println ( " YES " ) ; }
public static void main ( String [ ] args ) { String s1 = " you " ; String s2 = " ara " ; int x = 6 ;
isConversionPossible ( s1 , s2 , x ) ; } }
static void RightRotate ( int a [ ] , int n , int k ) {
k = k % n ; for ( int i = 0 ; i < n ; i ++ ) { if ( i < k ) {
System . out . print ( a [ n + i - k ] + " ▁ " ) ; } else {
System . out . print ( a [ i - k ] + " ▁ " ) ; } } System . out . println ( ) ; }
public static void main ( String args [ ] ) { int Array [ ] = { 1 , 2 , 3 , 4 , 5 } ; int N = Array . length ; int K = 2 ; RightRotate ( Array , N , K ) ; } }
static int countRotation ( int n ) { int count = 0 ;
do { int digit = n % 10 ;
if ( digit == 0 ) count ++ ; n = n / 10 ; } while ( n != 0 ) ; return count ; }
public static void main ( String [ ] args ) { int n = 10203 ; System . out . println ( countRotation ( n ) ) ; } }
static class Node { int data ; Node next ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = ( head_ref ) ;
( head_ref ) = new_node ; return head_ref ; }
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ - > ▁ " ) ; node = node . next ; } System . out . print ( " null " ) ; }
static Node rightRotate ( Node head , int k ) {
if ( head == null ) return head ;
Node tmp = head ; int len = 1 ; while ( tmp . next != null ) { tmp = tmp . next ; len ++ ; }
if ( k > len ) k = k % len ;
k = len - k ;
if ( k == 0 k == len ) return head ;
Node current = head ; int cnt = 1 ; while ( cnt < k && current != null ) { current = current . next ; cnt ++ ; }
if ( current == null ) return head ;
Node kthnode = current ;
tmp . next = head ;
head = kthnode . next ;
kthnode . next = null ;
return head ; }
Node head = null ; head = push ( head , 5 ) ; head = push ( head , 4 ) ; head = push ( head , 3 ) ; head = push ( head , 2 ) ; head = push ( head , 1 ) ; int k = 2 ;
Node updated_head = rightRotate ( head , k ) ;
printList ( updated_head ) ; } }
static boolean isPossible ( int a [ ] , int n ) {
if ( n <= 2 ) return true ; int flag = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) { if ( ! ( a [ i ] > a [ i + 1 ] && a [ i + 1 ] > a [ i + 2 ] ) ) { flag = 1 ; break ; } }
if ( flag == 0 ) return true ; flag = 0 ;
for ( int i = 0 ; i < n - 2 ; i ++ ) { if ( ! ( a [ i ] < a [ i + 1 ] && a [ i + 1 ] < a [ i + 2 ] ) ) { flag = 1 ; break ; } }
if ( flag == 0 ) return true ;
int val1 = Integer . MAX_VALUE , mini = - 1 , val2 = Integer . MIN_VALUE , maxi = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( a [ i ] < val1 ) { mini = i ; val1 = a [ i ] ; } if ( a [ i ] > val2 ) { maxi = i ; val2 = a [ i ] ; } } flag = 1 ;
for ( int i = 0 ; i < maxi ; i ++ ) { if ( a [ i ] > a [ i + 1 ] ) { flag = 0 ; break ; } }
if ( flag == 1 && maxi + 1 == mini ) { flag = 1 ;
for ( int i = mini ; i < n - 1 ; i ++ ) { if ( a [ i ] > a [ i + 1 ] ) { flag = 0 ; break ; } } if ( flag == 1 ) return true ; } flag = 1 ;
for ( int i = 0 ; i < mini ; i ++ ) { if ( a [ i ] < a [ i + 1 ] ) { flag = 0 ; break ; } }
if ( flag == 1 && maxi - 1 == mini ) { flag = 1 ;
for ( int i = maxi ; i < n - 1 ; i ++ ) { if ( a [ i ] < a [ i + 1 ] ) { flag = 0 ; break ; } } if ( flag == 1 ) return true ; }
return false ; }
public static void main ( String args [ ] ) { int a [ ] = { 4 , 5 , 6 , 2 , 3 } ; int n = a . length ; if ( isPossible ( a , n ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
static int cntRotations ( String s , int n ) {
String str = s + s ;
int pre [ ] = new int [ 2 * n ] ;
for ( int i = 0 ; i < 2 * n ; i ++ ) { if ( i != 0 ) pre [ i ] += pre [ i - 1 ] ; if ( str . charAt ( i ) == ' a ' || str . charAt ( i ) == ' e ' || str . charAt ( i ) == ' i ' || str . charAt ( i ) == ' o ' || str . charAt ( i ) == ' u ' ) { pre [ i ] ++ ; } }
int ans = 0 ;
for ( int i = n - 1 ; i < 2 * n - 1 ; i ++ ) {
int r = i , l = i - n ;
int x1 = pre [ r ] ; if ( l >= 0 ) x1 -= pre [ l ] ; r = i - n / 2 ;
int left = pre [ r ] ; if ( l >= 0 ) left -= pre [ l ] ;
int right = x1 - left ;
if ( left > right ) { ans ++ ; } }
return ans ; }
public static void main ( String args [ ] ) { String s = " abecidft " ; int n = s . length ( ) ; System . out . println ( cntRotations ( s , n ) ) ; } }
public static int cntRotations ( char s [ ] , int n ) { int lh = 0 , rh = 0 , i , ans = 0 ;
for ( i = 0 ; i < n / 2 ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { lh ++ ; }
for ( i = n / 2 ; i < n ; ++ i ) if ( s [ i ] == ' a ' s [ i ] == ' e ' s [ i ] == ' i ' s [ i ] == ' o ' s [ i ] == ' u ' ) { rh ++ ; }
if ( lh > rh ) ans ++ ;
for ( i = 1 ; i < n ; ++ i ) { if ( s [ i - 1 ] == ' a ' s [ i - 1 ] == ' e ' s [ i - 1 ] == ' i ' s [ i - 1 ] == ' o ' s [ i - 1 ] == ' u ' ) { rh ++ ; lh -- ; } if ( s [ ( i - 1 + n / 2 ) % n ] == ' a ' || s [ ( i - 1 + n / 2 ) % n ] == ' e ' || s [ ( i - 1 + n / 2 ) % n ] == ' i ' || s [ ( i - 1 + n / 2 ) % n ] == ' o ' || s [ ( i - 1 + n / 2 ) % n ] == ' u ' ) { rh -- ; lh ++ ; } if ( lh > rh ) ans ++ ; }
return ans ; }
public static void main ( String [ ] args ) { char s [ ] = { ' a ' , ' b ' , ' e ' , ' c ' , ' i ' , ' d ' , ' f ' , ' t ' } ; int n = s . length ;
System . out . println ( cntRotations ( s , n ) ) ; } }
import java . util . * ; class GFG { static int size = 2 ;
static void performQueries ( String str , int n , int queries [ ] [ ] , int q ) {
int ptr = 0 ;
for ( int i = 0 ; i < q ; i ++ ) {
if ( queries [ i ] [ 0 ] == 1 ) {
ptr = ( ptr + queries [ i ] [ 1 ] ) % n ; } else { int k = queries [ i ] [ 1 ] ;
int index = ( ptr + k - 1 ) % n ;
System . out . println ( str . charAt ( index ) ) ; } } }
public static void main ( String [ ] args ) { String str = " abcdefgh " ; int n = str . length ( ) ; int queries [ ] [ ] = { { 1 , 2 } , { 2 , 2 } , { 1 , 4 } , { 2 , 7 } } ; int q = queries . length ; performQueries ( str , n , queries , q ) ; } }
static void countOddRotations ( int n ) { int odd_count = 0 , even_count = 0 ; do { int digit = n % 10 ; if ( digit % 2 == 1 ) odd_count ++ ; else even_count ++ ; n = n / 10 ; } while ( n != 0 ) ; System . out . println ( " Odd ▁ = ▁ " + odd_count ) ; System . out . println ( " Even ▁ = ▁ " + even_count ) ; }
public static void main ( String [ ] args ) { int n = 1234 ; countOddRotations ( n ) ; } }
static int numberOfDigits ( int n ) { int cnt = 0 ; while ( n > 0 ) { cnt ++ ; n /= 10 ; } return cnt ; }
static void cal ( int num ) { int digits = numberOfDigits ( num ) ; int powTen = ( int ) Math . pow ( 10 , digits - 1 ) ; for ( int i = 0 ; i < digits - 1 ; i ++ ) { int firstDigit = num / powTen ;
int left = ( ( num * 10 ) + firstDigit ) - ( firstDigit * powTen * 10 ) ; System . out . print ( left + " ▁ " ) ;
num = left ; } }
public static void main ( String [ ] args ) { int num = 1445 ; cal ( num ) ; } }
class GFG { static void CheckKCycles ( int n , String s ) { boolean ff = true ; int x = 0 ; for ( int i = 1 ; i < n ; i ++ ) {
x = ( s . substring ( i ) + s . substring ( 0 , i ) ) . length ( ) ;
if ( x >= s . length ( ) ) { continue ; } ff = false ; break ; } if ( ff ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " No " ) ; } }
public static void main ( String [ ] args ) { int n = 3 ; String s = "123" ; CheckKCycles ( n , s ) ; } }
static class ListNode { int data ; ListNode next ; }
static void rotateSubList ( ListNode A , int m , int n , int k ) { int size = n - m + 1 ;
if ( k > size ) { k = k % size ; }
if ( k == 0 k == size ) { ListNode head = A ; while ( head != null ) { System . out . print ( head . data ) ; head = head . next ; } return ; }
ListNode link = null ; if ( m == 1 ) { link = A ; }
ListNode c = A ;
int count = 0 ; ListNode end = null ;
ListNode pre = null ; while ( c != null ) { count ++ ;
if ( count == m - 1 ) { pre = c ; link = c . next ; } if ( count == n - k ) { if ( m == 1 ) { end = c ; A = c . next ; } else { end = c ;
pre . next = c . next ; } }
if ( count == n ) { ListNode d = c . next ; c . next = link ; end . next = d ; ListNode head = A ; while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; head = head . next ; } return ; } c = c . next ; } }
static ListNode push ( ListNode head , int val ) { ListNode new_node = new ListNode ( ) ; new_node . data = val ; new_node . next = ( head ) ; ( head ) = new_node ; return head ; }
public static void main ( String args [ ] ) { ListNode head = null ; head = push ( head , 70 ) ; head = push ( head , 60 ) ; head = push ( head , 50 ) ; head = push ( head , 40 ) ; head = push ( head , 30 ) ; head = push ( head , 20 ) ; head = push ( head , 10 ) ; ListNode tmp = head ; System . out . print ( " Given ▁ List : ▁ " ) ; while ( tmp != null ) { System . out . print ( tmp . data + " ▁ " ) ; tmp = tmp . next ; } System . out . println ( ) ; int m = 3 , n = 6 , k = 2 ; System . out . print ( " After ▁ rotation ▁ of ▁ sublist : ▁ " ) ; rotateSubList ( head , m , n , k ) ; } }
static boolean rightRotationDivisor ( int N ) { int lastDigit = N % 10 ; int rightRotation = ( int ) ( lastDigit * Math . pow ( 10 , ( int ) ( Math . log10 ( N ) ) ) + Math . floor ( N / 10 ) ) ; return ( rightRotation % N == 0 ) ; }
static void generateNumbers ( int m ) { for ( int i = ( int ) Math . pow ( 10 , ( m - 1 ) ) ; i < Math . pow ( 10 , m ) ; i ++ ) if ( rightRotationDivisor ( i ) ) System . out . println ( i ) ; }
public static void main ( String args [ ] ) { int m = 3 ; generateNumbers ( m ) ; } }
class Node { int data ; Node left , right , next ; Node ( int item ) { data = item ; left = right = next = null ; } } class BinaryTree { Node root ; static Node next = null ;
void populateNext ( Node node ) {
if ( node != null ) {
populateNext ( node . right ) ;
node . next = next ;
next = node ;
populateNext ( node . left ) ; } }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 8 ) ; tree . root . right = new Node ( 12 ) ; tree . root . left . left = new Node ( 3 ) ;
tree . populateNext ( tree . root ) ;
Node ptr = tree . root . left . left ; while ( ptr != null ) {
int print = ptr . next != null ? ptr . next . data : - 1 ; System . out . println ( " Next ▁ of ▁ " + ptr . data + " ▁ is : ▁ " + print ) ; ptr = ptr . next ; } } }
static void generateNumbers ( int m ) { ArrayList < Integer > numbers = new ArrayList < > ( ) ; int k_max , x ; for ( int y = 0 ; y < 10 ; y ++ ) { k_max = ( int ) ( Math . pow ( 10 , m - 2 ) * ( 10 * y + 1 ) ) / ( int ) ( Math . pow ( 10 , m - 1 ) + y ) ; for ( int k = 1 ; k <= k_max ; k ++ ) { x = ( int ) ( y * ( Math . pow ( 10 , m - 1 ) - k ) ) / ( 10 * k - 1 ) ; if ( ( int ) ( y * ( Math . pow ( 10 , m - 1 ) - k ) ) % ( 10 * k - 1 ) == 0 ) numbers . add ( 10 * x + y ) ; } } Collections . sort ( numbers ) ; for ( int i = 0 ; i < numbers . size ( ) ; i ++ ) System . out . println ( numbers . get ( i ) ) ; }
public static void main ( String args [ ] ) { int m = 3 ; generateNumbers ( m ) ; } }
static void checkIfSortRotated ( int arr [ ] , int n ) { int minEle = Integer . MAX_VALUE ; int maxEle = Integer . MIN_VALUE ; int minIndex = - 1 ;
for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] < minEle ) { minEle = arr [ i ] ; minIndex = i ; } } boolean flag1 = true ;
for ( int i = 1 ; i < minIndex ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag1 = false ; break ; } } boolean flag2 = true ;
for ( int i = minIndex + 1 ; i < n ; i ++ ) { if ( arr [ i ] < arr [ i - 1 ] ) { flag2 = false ; break ; } }
if ( flag1 && flag2 && ( arr [ n - 1 ] < arr [ 0 ] ) ) System . out . println ( " YES " ) ; else System . out . print ( " NO " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 4 , 5 , 1 , 2 } ; int n = arr . length ;
checkIfSortRotated ( arr , n ) ; } }
import java . io . * ; class GFG { static int N = 4 ;
static void rotate90Clockwise ( int arr [ ] [ ] ) {
for ( int j = 0 ; j < N ; j ++ ) { for ( int i = N - 1 ; i >= 0 ; i -- ) System . out . print ( arr [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; rotate90Clockwise ( arr ) ; } }
import java . io . * ; class GFG {
static void rotate ( int [ ] [ ] arr ) { int n = arr . length ;
for ( int i = 0 ; i < n ; ++ i ) { for ( int j = 0 ; j < i ; ++ j ) { int temp = arr [ i ] [ j ] ; arr [ i ] [ j ] = arr [ j ] [ i ] ; arr [ j ] [ i ] = temp ; } }
for ( int i = 0 ; i < n ; ++ i ) { for ( int j = 0 ; j < n / 2 ; ++ j ) { int temp = arr [ i ] [ j ] ; arr [ i ] [ j ] = arr [ i ] [ n - j - 1 ] ; arr [ i ] [ n - j - 1 ] = temp ; } } }
static void printMatrix ( int arr [ ] [ ] ) { int n = arr . length ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) System . out . print ( arr [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; rotate ( arr ) ; printMatrix ( arr ) ; } }
static void occurredOnce ( int arr [ ] , int n ) {
Arrays . sort ( arr ) ;
if ( arr [ 0 ] != arr [ 1 ] ) System . out . println ( arr [ 0 ] + " ▁ " ) ;
for ( int i = 1 ; i < n - 1 ; i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i - 1 ] ) System . out . print ( arr [ i ] + " ▁ " ) ;
if ( arr [ n - 2 ] != arr [ n - 1 ] ) System . out . print ( arr [ n - 1 ] + " ▁ " ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = arr . length ; occurredOnce ( arr , n ) ; } }
static void occurredOnce ( int [ ] arr , int n ) { HashMap < Integer , Integer > mp = new HashMap < > ( ) ;
for ( int i = 0 ; i < n ; i ++ ) { if ( mp . containsKey ( arr [ i ] ) ) mp . put ( arr [ i ] , 1 + mp . get ( arr [ i ] ) ) ; else mp . put ( arr [ i ] , 1 ) ; }
for ( Map . Entry entry : mp . entrySet ( ) ) { if ( Integer . parseInt ( String . valueOf ( entry . getValue ( ) ) ) == 1 ) System . out . print ( entry . getKey ( ) + " ▁ " ) ; } }
public static void main ( String args [ ] ) { int [ ] arr = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = arr . length ; occurredOnce ( arr , n ) ; } }
static void occurredOnce ( int arr [ ] , int n ) { int i = 1 , len = n ;
if ( arr [ 0 ] == arr [ len - 1 ] ) { i = 2 ; len -- ; }
for ( ; i < n ; i ++ )
if ( arr [ i ] == arr [ i - 1 ] ) i ++ ;
else System . out . print ( arr [ i - 1 ] + " ▁ " ) ;
if ( arr [ n - 1 ] != arr [ 0 ] && arr [ n - 1 ] != arr [ n - 2 ] ) System . out . print ( arr [ n - 1 ] ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 7 , 7 , 8 , 8 , 9 , 1 , 1 , 4 , 2 , 2 } ; int n = arr . length ; occurredOnce ( arr , n ) ; } }
static void rvereseArray ( int arr [ ] , int start , int end ) { while ( start < end ) { int temp = arr [ start ] ; arr [ start ] = arr [ end ] ; arr [ end ] = temp ; start ++ ; end -- ; } }
static void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
static void splitArr ( int arr [ ] , int k , int n ) { rvereseArray ( arr , 0 , n - 1 ) ; rvereseArray ( arr , 0 , n - k - 1 ) ; rvereseArray ( arr , n - k , n - 1 ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 12 , 10 , 5 , 6 , 52 , 36 } ; int n = arr . length ; int k = 2 ;
splitArr ( arr , k , n ) ; printArray ( arr , n ) ; } }
import java . util . * ; import java . lang . * ; import java . io . * ; class stringMatching { public static boolean isRotation ( String a , String b ) { int n = a . length ( ) ; int m = b . length ( ) ; if ( n != m ) return false ;
int lps [ ] = new int [ n ] ;
int len = 0 ; int i = 1 ;
lps [ 0 ] = 0 ;
while ( i < n ) { if ( a . charAt ( i ) == b . charAt ( len ) ) { lps [ i ] = ++ len ; ++ i ; } else { if ( len == 0 ) { lps [ i ] = 0 ; ++ i ; } else { len = lps [ len - 1 ] ; } } } i = 0 ;
for ( int k = lps [ n - 1 ] ; k < m ; ++ k ) { if ( b . charAt ( k ) != a . charAt ( i ++ ) ) return false ; } return true ; }
public static void main ( String [ ] args ) { String s1 = " ABACD " ; String s2 = " CDABA " ; System . out . println ( isRotation ( s1 , s2 ) ? "1" : "0" ) ; } }
static int countRotationsDivBy8 ( String n ) { int len = n . length ( ) ; int count = 0 ;
if ( len == 1 ) { int oneDigit = n . charAt ( 0 ) - '0' ; if ( oneDigit % 8 == 0 ) return 1 ; return 0 ; }
if ( len == 2 ) {
int first = ( n . charAt ( 0 ) - '0' ) * 10 + ( n . charAt ( 1 ) - '0' ) ;
int second = ( n . charAt ( 1 ) - '0' ) * 10 + ( n . charAt ( 0 ) - '0' ) ; if ( first % 8 == 0 ) count ++ ; if ( second % 8 == 0 ) count ++ ; return count ; }
int threeDigit ; for ( int i = 0 ; i < ( len - 2 ) ; i ++ ) { threeDigit = ( n . charAt ( i ) - '0' ) * 100 + ( n . charAt ( i + 1 ) - '0' ) * 10 + ( n . charAt ( i + 2 ) - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ; }
threeDigit = ( n . charAt ( len - 1 ) - '0' ) * 100 + ( n . charAt ( 0 ) - '0' ) * 10 + ( n . charAt ( 1 ) - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
threeDigit = ( n . charAt ( len - 2 ) - '0' ) * 100 + ( n . charAt ( len - 1 ) - '0' ) * 10 + ( n . charAt ( 0 ) - '0' ) ; if ( threeDigit % 8 == 0 ) count ++ ;
return count ; }
public static void main ( String [ ] args ) { String n = "43262488612" ; System . out . println ( " Rotations : ▁ " + countRotationsDivBy8 ( n ) ) ; } }
static int minimunMoves ( String arr [ ] , int n ) { int ans = Integer . MAX_VALUE ; for ( int i = 0 ; i < n ; i ++ ) { int curr_count = 0 ;
String tmp = " " ; for ( int j = 0 ; j < n ; j ++ ) { tmp = arr [ j ] + arr [ j ] ;
int index = tmp . indexOf ( arr [ i ] ) ;
if ( index == arr [ i ] . length ( ) ) return - 1 ; curr_count += index ; } ans = Math . min ( curr_count , ans ) ; } return ans ; }
public static void main ( String args [ ] ) { String arr [ ] = { " xzzwo " , " zwoxz " , " zzwox " , " xzzwo " } ; int n = arr . length ; System . out . println ( minimunMoves ( arr , n ) ) ; } }
static void restoreSortedArray ( int arr [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { if ( arr [ i ] > arr [ i + 1 ] ) {
reverse ( arr , 0 , i ) ; reverse ( arr , i + 1 , n ) ; reverse ( arr , 0 , n ) ; } } } static void reverse ( int [ ] arr , int i , int j ) { int temp ; while ( i < j ) { temp = arr [ i ] ; arr [ i ] = arr [ j ] ; arr [ j ] = temp ; i ++ ; j -- ; } }
static void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) System . out . print ( arr [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 4 , 5 , 1 , 2 } ; int n = arr . length ; restoreSortedArray ( arr , n - 1 ) ; printArray ( arr , n ) ; } }
static int findStartIndexOfArray ( int arr [ ] , int low , int high ) { if ( low > high ) { return - 1 ; } if ( low == high ) { return low ; } int mid = low + ( high - low ) / 2 ; if ( arr [ mid ] > arr [ mid + 1 ] ) { return mid + 1 ; } if ( arr [ mid - 1 ] > arr [ mid ] ) { return mid ; } if ( arr [ low ] > arr [ mid ] ) { return findStartIndexOfArray ( arr , low , mid - 1 ) ; } else { return findStartIndexOfArray ( arr , mid + 1 , high ) ; } }
static void restoreSortedArray ( int arr [ ] , int n ) {
if ( arr [ 0 ] < arr [ n - 1 ] ) { return ; } int start = findStartIndexOfArray ( arr , 0 , n - 1 ) ;
Arrays . sort ( arr , 0 , start ) ; Arrays . sort ( arr , start , n ) ; Arrays . sort ( arr ) ; }
static void printArray ( int arr [ ] , int size ) { for ( int i = 0 ; i < size ; i ++ ) { System . out . print ( arr [ i ] + " ▁ " ) ; } }
public static void main ( String [ ] args ) { int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = arr . length ; restoreSortedArray ( arr , n ) ; printArray ( arr , n ) ; } }
static class Node { int data ; Node next ; } ;
static int countRotation ( Node head ) {
int count = 0 ;
int min = head . data ;
while ( head != null ) {
if ( min > head . data ) break ; count ++ ;
head = head . next ; } return count ; }
static Node push ( Node head , int data ) {
Node newNode = new Node ( ) ;
newNode . data = data ;
newNode . next = ( head ) ;
( head ) = newNode ; return head ; }
static void printList ( Node node ) { while ( node != null ) { System . out . printf ( " % d ▁ " , node . data ) ; node = node . next ; } }
Node head = null ;
head = push ( head , 12 ) ; head = push ( head , 11 ) ; head = push ( head , 8 ) ; head = push ( head , 5 ) ; head = push ( head , 18 ) ; head = push ( head , 15 ) ; printList ( head ) ; System . out . println ( ) ; System . out . print ( " Linked ▁ list ▁ rotated ▁ elements : ▁ " ) ;
System . out . print ( countRotation ( head ) + "NEW_LINE"); } }
static class Node { int data ; Node next ; } ; static Node tail ;
static Node rotateHelper ( Node blockHead , Node blockTail , int d , int k ) { if ( d == 0 ) return blockHead ;
if ( d > 0 ) { Node temp = blockHead ; for ( int i = 1 ; temp . next . next != null && i < k - 1 ; i ++ ) temp = temp . next ; blockTail . next = blockHead ; tail = temp ; return rotateHelper ( blockTail , temp , d - 1 , k ) ; }
if ( d < 0 ) { blockTail . next = blockHead ; tail = blockHead ; return rotateHelper ( blockHead . next , blockHead , d + 1 , k ) ; } return blockHead ; }
static Node rotateByBlocks ( Node head , int k , int d ) {
if ( head == null head . next == null ) return head ;
if ( d == 0 ) return head ; Node temp = head ; tail = null ;
int i ; for ( i = 1 ; temp . next != null && i < k ; i ++ ) temp = temp . next ;
Node nextBlock = temp . next ;
if ( i < k ) head = rotateHelper ( head , temp , d % k , i ) ; else head = rotateHelper ( head , temp , d % k , k ) ;
tail . next = rotateByBlocks ( nextBlock , k , d % k ) ;
return head ; }
static Node push ( Node head_ref , int new_data ) { Node new_node = new Node ( ) ; new_node . data = new_data ; new_node . next = head_ref ; head_ref = new_node ; return head_ref ; }
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } }
Node head = null ;
for ( int i = 9 ; i > 0 ; i -= 1 ) head = push ( head , i ) ; System . out . print ( "Given linked list NEW_LINE"); printList ( head ) ;
int k = 3 , d = 2 ; head = rotateByBlocks ( head , k , d ) ; System . out . print ( " Rotated by blocks Linked list "); printList ( head ) ; } }
static boolean isRotation ( long x , long y ) {
long x64 = x | ( x << 32 ) ; while ( x64 >= y ) {
if ( x64 == y ) { return true ; }
x64 >>= 1 ; } return false ; }
public static void main ( String [ ] args ) { long x = 122 ; long y = 2147483678L ; if ( isRotation ( x , y ) == false ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " No " ) ; } } }
static String leftrotate ( String str , int d ) { String ans = str . substring ( d ) + str . substring ( 0 , d ) ; return ans ; }
static String rightrotate ( String str , int d ) { return leftrotate ( str , str . length ( ) - d ) ; }
public static void main ( String args [ ] ) { String str1 = " GeeksforGeeks " ; System . out . println ( leftrotate ( str1 , 2 ) ) ; String str2 = " GeeksforGeeks " ; System . out . println ( rightrotate ( str2 , 2 ) ) ; } }
static int countRotations ( String n ) { int len = n . length ( ) ;
if ( len == 1 ) { int oneDigit = n . charAt ( 0 ) - '0' ; if ( oneDigit % 4 == 0 ) return 1 ; return 0 ; }
int twoDigit , count = 0 ; for ( int i = 0 ; i < ( len - 1 ) ; i ++ ) { twoDigit = ( n . charAt ( i ) - '0' ) * 10 + ( n . charAt ( i + 1 ) - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; }
twoDigit = ( n . charAt ( len - 1 ) - '0' ) * 10 + ( n . charAt ( 0 ) - '0' ) ; if ( twoDigit % 4 == 0 ) count ++ ; return count ; }
public static void main ( String args [ ] ) { String n = "4834" ; System . out . println ( " Rotations : ▁ " + countRotations ( n ) ) ; } }
static boolean isRotated ( String str1 , String str2 ) { if ( str1 . length ( ) != str2 . length ( ) ) return false ; if ( str1 . length ( ) < 2 ) { return str1 . equals ( str2 ) ; } String clock_rot = " " ; String anticlock_rot = " " ; int len = str2 . length ( ) ;
anticlock_rot = anticlock_rot + str2 . substring ( len - 2 , len ) + str2 . substring ( 0 , len - 2 ) ;
clock_rot = clock_rot + str2 . substring ( 2 ) + str2 . substring ( 0 , 2 ) ;
return ( str1 . equals ( clock_rot ) || str1 . equals ( anticlock_rot ) ) ; }
public static void main ( String [ ] args ) { String str1 = " geeks " ; String str2 = " eksge " ; System . out . println ( isRotated ( str1 , str2 ) ? " Yes " : " No " ) ; } }
static String minLexRotation ( String str ) {
int n = str . length ( ) ;
String arr [ ] = new String [ n ] ;
String concat = str + str ;
for ( int i = 0 ; i < n ; i ++ ) { arr [ i ] = concat . substring ( i , i + n ) ; }
Arrays . sort ( arr ) ;
return arr [ 0 ] ; }
public static void main ( String [ ] args ) { System . out . println ( minLexRotation ( " GEEKSFORGEEKS " ) ) ; System . out . println ( minLexRotation ( " GEEKSQUIZ " ) ) ; System . out . println ( minLexRotation ( " BCABDADAB " ) ) ; } }
static class Node { int data ; Node next ; } ; static Node head = null ;
static void rotate ( int k ) { if ( k == 0 ) return ;
Node current = head ;
while ( current . next != null ) current = current . next ; current . next = head ; current = head ;
for ( int i = 0 ; i < k - 1 ; i ++ ) current = current . next ;
head = current . next ; current . next = null ; }
static void push ( int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . next = head ;
head = new_node ; }
static void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } }
for ( int i = 60 ; i > 0 ; i -= 10 ) push ( i ) ; System . out . print ( "Given linked list NEW_LINE"); printList ( head ) ; rotate ( 4 ) ; System . out . print ( " Rotated Linked list "); printList ( head ) ; } }
import java . io . * ; import java . util . * ; class GFG { static Node head ;
static class Node { int data ; Node next ;
public Node ( int data ) { this . data = data ; this . next = null ; } }
static void print ( Node head ) { Node temp = head ;
while ( temp != null ) {
System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } }
static void NextGreaterElement ( Node head ) {
Node H = head ;
Node res = null ;
Node tempList = null ;
do {
Node curr = head ;
int Val = - 1 ;
do {
if ( head . data < curr . data ) {
Val = curr . data ; break ; }
curr = curr . next ; } while ( curr != head ) ;
if ( res == null ) {
res = new Node ( Val ) ;
tempList = res ; } else {
tempList . next = new Node ( Val ) ;
tempList = tempList . next ; }
head = head . next ; } while ( head != H ) ;
print ( res ) ; }
public static void main ( String [ ] args ) { head = new Node ( 1 ) ; head . next = new Node ( 5 ) ; head . next . next = new Node ( 12 ) ; head . next . next . next = new Node ( 10 ) ; head . next . next . next . next = new Node ( 0 ) ; head . next . next . next . next . next = head ; NextGreaterElement ( head ) ; } }
static class Node { int data ; Node next ; } ;
static class Node { int data ; Node next ; } ;
static void printList ( Node n ) {
while ( n != null ) {
System . out . print ( n . data + " ▁ " ) ; n = n . next ; } }
public static void main ( String [ ] args ) { Node head = null ; Node second = null ; Node third = null ;
head = new Node ( ) ; second = new Node ( ) ; third = new Node ( ) ;
head . data = 1 ;
head . next = second ;
second . data = 2 ; second . next = third ;
third . data = 3 ; third . next = null ; printList ( head ) ; } }
static class Node { int data ; Node next ; } ;
static Node push ( Node head_ref , int data ) {
Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) {
while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static void deleteNode ( Node head_ref , Node del ) {
if ( head_ref == del ) head_ref = del . next ; Node temp = head_ref ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ;
System . gc ( ) ; return ; }
static boolean isEvenParity ( int x ) {
int parity = 0 ; while ( x != 0 ) { if ( ( x & 1 ) != 0 ) parity ++ ; x = x >> 1 ; } if ( parity % 2 == 0 ) return true ; else return false ; }
static void deleteEvenParityNodes ( Node head ) { if ( head == null ) return ; if ( head == head . next ) { if ( isEvenParity ( head . data ) ) head = null ; return ; } Node ptr = head ; Node next ;
do { next = ptr . next ;
if ( isEvenParity ( ptr . data ) ) deleteNode ( head , ptr ) ;
ptr = next ; } while ( ptr != head ) ; if ( head == head . next ) { if ( isEvenParity ( head . data ) ) head = null ; return ; } }
static void printList ( Node head ) { if ( head == null ) { System . out . print ( "Empty ListNEW_LINE"); return ; } Node temp = head ; if ( head != null ) { do { System . out . printf ( " % d ▁ " , temp . data ) ; temp = temp . next ; } while ( temp != head ) ; } }
Node head = null ;
head = push ( head , 21 ) ; head = push ( head , 13 ) ; head = push ( head , 6 ) ; head = push ( head , 34 ) ; head = push ( head , 9 ) ; head = push ( head , 11 ) ; deleteEvenParityNodes ( head ) ; printList ( head ) ; } }
static class Node { int data ; Node next ; } ;
static Node push ( Node head_ref , int data ) {
Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) {
while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static void deleteNode ( Node head_ref , Node del ) { Node temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ;
del = null ; return ; }
static int digitSum ( int num ) { int sum = 0 ; while ( num > 0 ) { sum += ( num % 10 ) ; num /= 10 ; } return sum ; }
static void deleteEvenDigitSumNodes ( Node head ) { Node ptr = head ; Node next ;
do {
if ( ! ( digitSum ( ptr . data ) % 2 == 1 ) ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; }
static void printList ( Node head ) { Node temp = head ; if ( head != null ) { do { System . out . printf ( " % d ▁ " , temp . data ) ; temp = temp . next ; } while ( temp != head ) ; } }
Node head = null ;
head = push ( head , 21 ) ; head = push ( head , 13 ) ; head = push ( head , 6 ) ; head = push ( head , 34 ) ; head = push ( head , 11 ) ; head = push ( head , 9 ) ; deleteEvenDigitSumNodes ( head ) ; printList ( head ) ; } }
static class Node { int data ; Node next ; } ;
static Node push ( Node head_ref , int data ) {
Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) {
while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static void deleteNode ( Node head_ref , Node del ) { Node temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ;
del = null ; return ; }
static int largestElement ( Node head_ref ) {
Node current ;
current = head_ref ;
int maxEle = Integer . MIN_VALUE ;
do {
if ( current . data > maxEle ) { maxEle = current . data ; } current = current . next ; } while ( current != head_ref ) ; return maxEle ; }
static void createHash ( HashSet < Integer > hash , int maxElement ) { int prev = 0 , curr = 1 ;
hash . add ( prev ) ; hash . add ( curr ) ;
while ( curr <= maxElement ) { int temp = curr + prev ; hash . add ( temp ) ; prev = curr ; curr = temp ; } }
static void deleteFibonacciNodes ( Node head ) {
int maxEle = largestElement ( head ) ;
HashSet < Integer > hash = new HashSet < Integer > ( ) ; createHash ( hash , maxEle ) ; Node ptr = head ; Node next ;
do {
if ( hash . contains ( ptr . data ) ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; }
static void printList ( Node head ) { Node temp = head ; if ( head != null ) { do { System . out . printf ( " % d ▁ " , temp . data ) ; temp = temp . next ; } while ( temp != head ) ; } }
Node head = null ;
head = push ( head , 20 ) ; head = push ( head , 13 ) ; head = push ( head , 6 ) ; head = push ( head , 34 ) ; head = push ( head , 11 ) ; head = push ( head , 9 ) ; deleteFibonacciNodes ( head ) ; printList ( head ) ; } }
static class Node { int data ; Node next ; } ;
static Node push ( Node head_ref , int data ) { Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) { while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; return head_ref ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static Node deleteNode ( Node head_ref , Node del ) { Node temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ; return head_ref ; }
static Node deleteoddNodes ( Node head ) { Node ptr = head ; Node next ;
do {
if ( ptr . data % 2 == 1 ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; return head ; }
static void printList ( Node head ) { Node temp = head ; if ( head != null ) { do { System . out . printf ( " % d ▁ " , temp . data ) ; temp = temp . next ; } while ( temp != head ) ; } }
Node head = null ;
head = push ( head , 2 ) ; head = push ( head , 12 ) ; head = push ( head , 11 ) ; head = push ( head , 57 ) ; head = push ( head , 61 ) ; head = push ( head , 56 ) ; System . out . println ( " List after deletion : "); head = deleteoddNodes ( head ) ; printList ( head ) ; } }
static class Node { Node next ; int data ; } ;
static Node create ( ) { Node new_node = new Node ( ) ; new_node . next = null ; return new_node ; }
static Node find_head ( Node random ) {
if ( random == null ) return null ; Node head , var = random ;
while ( ! ( var . data > var . next . data var . next == random ) ) { var = var . next ; }
return var . next ; }
static Node sortedInsert ( Node head_ref , Node new_node ) { Node current = head_ref ;
if ( current == null ) { new_node . next = new_node ; head_ref = new_node ; }
else if ( current . data >= new_node . data ) {
while ( current . next != head_ref ) current = current . next ; current . next = new_node ; new_node . next = head_ref ; head_ref = new_node ; } else {
while ( current . next != head_ref && current . next . data < new_node . data ) { current = current . next ; } new_node . next = current . next ; current . next = new_node ; }
return head_ref ; }
static void printList ( Node start ) { Node temp ; if ( start != null ) { temp = start ; do { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } while ( temp != start ) ; } }
public static void main ( String args [ ] ) { int arr [ ] = { 12 , 56 , 2 , 11 , 1 , 90 } ; int list_size , i ;
Node start = null ; Node temp ;
for ( i = 0 ; i < 6 ; i ++ ) {
if ( start != null ) for ( int j = 0 ; j < ( Math . random ( ) * 10 ) ; j ++ ) start = start . next ; temp = create ( ) ; temp . data = arr [ i ] ; start = sortedInsert ( find_head ( start ) , temp ) ; }
printList ( find_head ( start ) ) ; } }
public class CircularLinkedList { Node last ; static class Node { int data ; Node next ; } ;
public Node addToEmpty ( int data ) {
if ( this . last != null ) return this . last ;
Node temp = new Node ( ) ;
temp . data = data ; this . last = temp ;
this . last . next = this . last ; return last ; }
public Node addBegin ( int data ) {
if ( last == null ) return addToEmpty ( data ) ;
Node temp = new Node ( ) ;
temp . data = data ; temp . next = this . last . next ; this . last . next = temp ; return this . last ; }
public void traverse ( ) { Node p ;
if ( this . last == null ) { System . out . println ( " List ▁ is ▁ empty . " ) ; return ; }
p = this . last . next ;
do { System . out . print ( p . data + " ▁ " ) ; p = p . next ; } while ( p != this . last . next ) ; System . out . println ( " " ) ; }
public int length ( ) {
int x = 0 ;
if ( this . last == null ) return x ;
Node itr = this . last . next ; while ( itr . next != this . last . next ) { x ++ ; itr = itr . next ; }
return ( x + 1 ) ; }
public Node split ( int k ) {
Node pass = new Node ( ) ;
if ( this . last == null ) return this . last ;
Node newLast , itr = this . last ; for ( int i = 0 ; i < k ; i ++ ) { itr = itr . next ; }
newLast = itr ; pass . next = itr . next ; newLast . next = this . last . next ; this . last . next = pass . next ;
return newLast ; }
public static void main ( String [ ] args ) { CircularLinkedList clist = new CircularLinkedList ( ) ; clist . last = null ; clist . addToEmpty ( 12 ) ; clist . addBegin ( 10 ) ; clist . addBegin ( 8 ) ; clist . addBegin ( 6 ) ; clist . addBegin ( 4 ) ; clist . addBegin ( 2 ) ; System . out . println ( " Original ▁ list : " ) ; clist . traverse ( ) ; int k = 4 ;
clist2 . last = clist . split ( k ) ;
System . out . println ( " The ▁ new ▁ lists ▁ are : " ) ; clist2 . traverse ( ) ; clist . traverse ( ) ; } }
static class Node { int data ; Node left ; Node right ; Node ( int x ) { data = x ; left = right = null ; } } ;
static void inorder ( Node root , Vector < Integer > v ) { if ( root == null ) return ;
inorder ( root . left , v ) ;
v . add ( root . data ) ;
inorder ( root . right , v ) ; }
static Node bTreeToCList ( Node root ) {
if ( root == null ) return null ;
Vector < Integer > v = new Vector < > ( ) ;
inorder ( root , v ) ;
Node head_ref = new Node ( v . get ( 0 ) ) ;
Node curr = head_ref ;
for ( int i = 1 ; i < v . size ( ) ; i ++ ) {
Node temp = curr ;
curr . right = new Node ( v . get ( i ) ) ;
curr = curr . right ;
curr . left = temp ; }
curr . right = head_ref ;
head_ref . left = curr ;
return head_ref ; }
static void displayCList ( Node head ) { System . out . println ( " Circular ▁ Doubly ▁ Linked ▁ List ▁ is ▁ : " ) ; Node itr = head ; do { System . out . print ( itr . data + " ▁ " ) ; itr = itr . right ; } while ( head != itr ) ; System . out . println ( ) ; }
public static void main ( String [ ] args ) { Node root = new Node ( 10 ) ; root . left = new Node ( 12 ) ; root . right = new Node ( 15 ) ; root . left . left = new Node ( 25 ) ; root . left . right = new Node ( 30 ) ; root . right . left = new Node ( 36 ) ; Node head = bTreeToCList ( root ) ; displayCList ( head ) ; } }
static void DeleteAllOddNode ( Node head ) { int len = Length ( head ) ; int count = 0 ; Node previous = head , next = head ;
if ( head == null ) { System . out . printf ( " Delete Last List is empty "); return ; }
if ( len == 1 ) { DeleteFirst ( head ) ; return ; }
while ( len > 0 ) {
if ( count == 0 ) {
DeleteFirst ( head ) ; }
if ( count % 2 == 0 && count != 0 ) { deleteNode ( head , previous ) ; } previous = previous . next ; next = previous . next ; len -- ; count ++ ; } return ; }
static Node DeleteAllEvenNode ( Node head ) {
int len = Length ( head ) ; int count = 1 ; Node previous = head , next = head ;
if ( head == null ) { System . out . printf ( " List is empty "); return null ; }
if ( len < 2 ) { return null ; }
previous = head ;
next = previous . next ; while ( len > 0 ) {
if ( count % 2 == 0 ) { previous . next = next . next ; previous = next . next ; next = previous . next ; } len -- ; count ++ ; } return head ; }
static class Node { int data ; Node next ; } ;
static int Length ( Node head ) { Node current = head ; int count = 0 ;
if ( head == null ) { return 0 ; }
else { do { current = current . next ; count ++ ; } while ( current != head ) ; } return count ; }
static void Display ( Node head ) { Node current = head ;
if ( head == null ) { System . out . printf ( " Display List is empty "); return ; }
else { do { System . out . printf ( " % d ▁ " , current . data ) ; current = current . next ; } while ( current != head ) ; } }
static Node Insert ( Node head , int data ) { Node current = head ;
Node newNode = new Node ( ) ;
if ( newNode == null ) { System . out . printf ( " Memory Error "); return null ; }
newNode . data = data ;
if ( head == null ) { newNode . next = newNode ; head = newNode ; return head ; }
else {
while ( current . next != head ) { current = current . next ; }
newNode . next = head ;
current . next = newNode ; } return head ; }
static Node deleteNode ( Node head_ref , Node del ) { Node temp = head_ref ;
if ( head_ref == del ) { head_ref = del . next ; }
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ; return head_ref ; }
static Node DeleteFirst ( Node head ) { Node previous = head , next = head ;
if ( head == null ) { System . out . printf ( " List is empty "); return head ; }
if ( previous . next == previous ) { head = null ; return head ; }
while ( previous . next != head ) { previous = previous . next ; next = previous . next ; }
previous . next = next . next ;
head = previous . next ; return head ; }
static Node DeleteAllOddNode ( Node head ) { int len = Length ( head ) ; int count = 0 ; Node previous = head , next = head ;
if ( head == null ) { System . out . printf ( " Delete Last List is empty "); return null ; }
if ( len == 1 ) { head = DeleteFirst ( head ) ; return head ; }
while ( len > 0 ) {
if ( count == 0 ) {
head = DeleteFirst ( head ) ; }
if ( count % 2 == 0 && count != 0 ) { head = deleteNode ( head , previous ) ; } previous = previous . next ; next = previous . next ; len -- ; count ++ ; } return head ; }
static Node DeleteAllEvenNode ( Node head ) {
int len = Length ( head ) ; int count = 1 ; Node previous = head , next = head ;
if ( head == null ) { System . out . printf ( " List is empty "); return null ; }
if ( len < 2 ) { return null ; }
previous = head ;
next = previous . next ; while ( len > 0 ) {
if ( count % 2 == 0 ) { previous . next = next . next ; previous = next . next ; next = previous . next ; } len -- ; count ++ ; } return head ; }
public static void main ( String args [ ] ) { Node head = null ; head = Insert ( head , 99 ) ; head = Insert ( head , 11 ) ; head = Insert ( head , 22 ) ; head = Insert ( head , 33 ) ; head = Insert ( head , 44 ) ; head = Insert ( head , 55 ) ; head = Insert ( head , 66 ) ;
System . out . printf ( " Initial ▁ List : ▁ " ) ; Display ( head ) ; System . out . printf ( " After deleting Odd position nodes : "); head = DeleteAllOddNode ( head ) ; Display ( head ) ;
System . out . printf ( " Initial List : "); Display ( head ) ; System . out . printf ( " After deleting even position nodes : "); head = DeleteAllEvenNode ( head ) ; Display ( head ) ; } }
static void DeleteFirst ( Node head ) { Node previous = head , firstNode = head ;
if ( head == null ) { System . out . printf ( " List is empty "); return ; }
if ( previous . next == previous ) { head = null ; return ; }
while ( previous . next != head ) { previous = previous . next ; }
previous . next = firstNode . next ;
head = previous . next ; System . gc ( ) ; return ; }
static Node DeleteLast ( Node head ) { Node current = head , temp = head , previous = null ;
if ( head == null ) { System . out . printf ( " List is empty "); return null ; }
if ( current . next == current ) { head = null ; return null ; }
while ( current . next != head ) { previous = current ; current = current . next ; } previous . next = current . next ; head = previous . next ; return head ; }
static class Node { int data ; Node next ; } ;
static void printMinMax ( Node head ) {
if ( head == null ) { return ; }
Node current ;
current = head ;
int min = Integer . MAX_VALUE , max = Integer . MIN_VALUE ;
while ( current . next != head ) {
if ( current . data < min ) { min = current . data ; }
if ( current . data > max ) { max = current . data ; } current = current . next ; } System . out . println ( " Minimum = " ▁ + ▁ min ▁ + ▁ " , Maximum = " + max); }
static Node insertNode ( Node head , int data ) { Node current = head ;
Node newNode = new Node ( ) ;
if ( newNode == null ) { System . out . printf ( " Memory Error "); return null ; }
newNode . data = data ;
if ( head == null ) { newNode . next = newNode ; head = newNode ; return head ; }
else {
while ( current . next != head ) { current = current . next ; }
newNode . next = head ;
current . next = newNode ; } return head ; }
static void displayList ( Node head ) { Node current = head ;
if ( head == null ) { System . out . printf ( " Display List is empty "); return ; }
else { do { System . out . printf ( " % d ▁ " , current . data ) ; current = current . next ; } while ( current != head ) ; } }
public static void main ( String args [ ] ) { Node Head = null ; Head = insertNode ( Head , 99 ) ; Head = insertNode ( Head , 11 ) ; Head = insertNode ( Head , 22 ) ; Head = insertNode ( Head , 33 ) ; Head = insertNode ( Head , 44 ) ; Head = insertNode ( Head , 55 ) ; Head = insertNode ( Head , 66 ) ; System . out . println ( " Initial ▁ List : ▁ " ) ; displayList ( Head ) ; printMinMax ( Head ) ; } }
static class Node { int data ; Node next ; } ;
static Node push ( Node head_ref , int data ) { Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) { while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; return head_ref ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static Node deleteNode ( Node head_ref , Node del ) { Node temp = head_ref ;
if ( head_ref == del ) head_ref = del . next ;
while ( temp . next != del ) { temp = temp . next ; }
temp . next = del . next ; return head_ref ; }
static Node deleteEvenNodes ( Node head ) { Node ptr = head ; Node next ;
do {
if ( ptr . data % 2 == 0 ) deleteNode ( head , ptr ) ;
next = ptr . next ; ptr = next ; } while ( ptr != head ) ; return head ; }
static void printList ( Node head ) { Node temp = head ; if ( head != null ) { do { System . out . printf ( " % d ▁ " , temp . data ) ; temp = temp . next ; } while ( temp != head ) ; } }
Node head = null ;
head = push ( head , 61 ) ; head = push ( head , 12 ) ; head = push ( head , 56 ) ; head = push ( head , 2 ) ; head = push ( head , 11 ) ; head = push ( head , 57 ) ; System . out . println ( " List after deletion : "); head = deleteEvenNodes ( head ) ; printList ( head ) ; } }
static class Node { int data ; Node next ; } ;
static Node push ( Node head_ref , int data ) { Node ptr1 = new Node ( ) ; Node temp = head_ref ; ptr1 . data = data ; ptr1 . next = head_ref ;
if ( head_ref != null ) { while ( temp . next != head_ref ) temp = temp . next ; temp . next = ptr1 ; } else
ptr1 . next = ptr1 ; head_ref = ptr1 ; return head_ref ; }
static int sumOfList ( Node head ) { Node temp = head ; int sum = 0 ; if ( head != null ) { do { temp = temp . next ; sum += temp . data ; } while ( temp != head ) ; } return sum ; }
Node head = null ;
head = push ( head , 12 ) ; head = push ( head , 56 ) ; head = push ( head , 2 ) ; head = push ( head , 11 ) ; System . out . println ( " Sum ▁ of ▁ Circular ▁ linked " + " ▁ list ▁ is ▁ = ▁ " + sumOfList ( head ) ) ; } }
static class Node { int data ; Node next ; Node ( int x ) { data = x ; next = null ; } } ;
static void printList ( Node head ) { if ( head == null ) return ; Node temp = head ; do { System . out . print ( temp . data + " - > " ) ; temp = temp . next ; } while ( temp != head ) ; System . out . println ( head . data ) ; }
static Node deleteK ( Node head_ref , int k ) { Node head = head_ref ;
if ( head == null ) return null ;
Node curr = head , prev = null ; while ( true ) {
if ( curr . next == head && curr == head ) break ;
printList ( head ) ;
for ( int i = 0 ; i < k ; i ++ ) { prev = curr ; curr = curr . next ; }
if ( curr == head ) { prev = head ; while ( prev . next != head ) prev = prev . next ; head = curr . next ; prev . next = head ; head_ref = head ; }
else if ( curr . next == head ) { prev . next = head ; } else { prev . next = curr . next ; } } return head ; }
static Node insertNode ( Node head_ref , int x ) {
Node head = head_ref ; Node temp = new Node ( x ) ;
if ( head == null ) { temp . next = temp ; head_ref = temp ; return head_ref ; }
else { Node temp1 = head ; while ( temp1 . next != head ) temp1 = temp1 . next ; temp1 . next = temp ; temp . next = head ; } return head ; }
Node head = null ; head = insertNode ( head , 1 ) ; head = insertNode ( head , 2 ) ; head = insertNode ( head , 3 ) ; head = insertNode ( head , 4 ) ; head = insertNode ( head , 5 ) ; head = insertNode ( head , 6 ) ; head = insertNode ( head , 7 ) ; head = insertNode ( head , 8 ) ; head = insertNode ( head , 9 ) ; int k = 4 ;
head = deleteK ( head , k ) ; } }
static class Node { int data ; Node next ; Node prev ; } ;
static Node insertNode ( Node start , int value ) {
if ( start == null ) { Node new_node = new Node ( ) ; new_node . data = value ; new_node . next = new_node . prev = new_node ; start = new_node ; return new_node ; }
Node last = ( start ) . prev ;
Node new_node = new Node ( ) ; new_node . data = value ;
new_node . next = start ;
( start ) . prev = new_node ;
new_node . prev = last ;
last . next = new_node ; return start ; }
static void displayList ( Node start ) { Node temp = start ; while ( temp . next != start ) { System . out . printf ( " % d ▁ " , temp . data ) ; temp = temp . next ; } System . out . printf ( " % d ▁ " , temp . data ) ; }
static int searchList ( Node start , int search ) {
Node temp = start ;
int count = 0 , flag = 0 , value ;
if ( temp == null ) return - 1 ; else {
while ( temp . next != start ) {
count ++ ;
if ( temp . data == search ) { flag = 1 ; count -- ; break ; }
temp = temp . next ; }
if ( temp . data == search ) { count ++ ; flag = 1 ; }
if ( flag == 1 ) System . out . println ( " " + search ▁ + " found at location "+ count); else System . out . println ( " " + search ▁ + " not found "); } return - 1 ; }
Node start = null ;
start = insertNode ( start , 4 ) ;
start = insertNode ( start , 5 ) ;
start = insertNode ( start , 7 ) ;
start = insertNode ( start , 8 ) ;
start = insertNode ( start , 6 ) ; System . out . printf ( " Created ▁ circular ▁ doubly ▁ linked ▁ list ▁ is : ▁ " ) ; displayList ( start ) ; searchList ( start , 5 ) ; } }
static class node { int data ; node next ; node prev ; } ;
static node getNode ( ) { return new node ( ) ; }
static int displayList ( node temp ) { node t = temp ; if ( temp == null ) return 0 ; else { System . out . println ( " The ▁ list ▁ is : ▁ " ) ; while ( temp . next != t ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } System . out . println ( temp . data ) ; return 1 ; } }
static int countList ( node start ) {
node temp = start ;
int count = 0 ;
while ( temp . next != start ) { temp = temp . next ; count ++ ; }
count ++ ; return count ; }
static node insertAtLocation ( node start , int data , int loc ) {
node temp , newNode ; int i , count ;
newNode = getNode ( ) ;
temp = start ;
count = countList ( start ) ;
if ( temp == null count < loc ) return start ; else {
newNode . data = data ;
for ( i = 1 ; i < loc - 1 ; i ++ ) { temp = temp . next ; }
newNode . next = temp . next ;
( temp . next ) . prev = newNode ;
temp . next = newNode ;
newNode . prev = temp ; return start ; } }
static node createList ( int arr [ ] , int n , node start ) {
node newNode , temp ; int i ;
for ( i = 0 ; i < n ; i ++ ) {
newNode = getNode ( ) ;
newNode . data = arr [ i ] ;
if ( i == 0 ) { start = newNode ; newNode . prev = start ; newNode . next = start ; } else {
temp = ( start ) . prev ;
temp . next = newNode ; newNode . next = start ; newNode . prev = temp ; temp = start ; temp . prev = newNode ; } } return start ; }
int arr [ ] = { 1 , 2 , 3 , 4 , 5 , 6 } ; int n = arr . length ;
node start = null ;
start = createList ( arr , n , start ) ;
displayList ( start ) ;
start = insertAtLocation ( start , 8 , 3 ) ;
displayList ( start ) ; } }
static class Node { int data ; Node next , prev ; } ;
static Node getNode ( int data ) { Node newNode = new Node ( ) ; newNode . data = data ; return newNode ; }
static Node insertEnd ( Node head , Node new_node ) {
if ( head == null ) { new_node . next = new_node . prev = new_node ; head = new_node ; return head ; }
Node last = ( head ) . prev ;
new_node . next = head ;
( head ) . prev = new_node ;
new_node . prev = last ;
last . next = new_node ; return head ; }
static Node reverse ( Node head ) { if ( head == null ) return null ;
Node new_head = null ;
Node last = head . prev ;
Node curr = last , prev ;
while ( curr . prev != last ) { prev = curr . prev ;
new_head = insertEnd ( new_head , curr ) ; curr = prev ; } new_head = insertEnd ( new_head , curr ) ;
return new_head ; }
static void display ( Node head ) { if ( head == null ) return ; Node temp = head ; System . out . print ( " Forward ▁ direction : ▁ " ) ; while ( temp . next != head ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } System . out . print ( temp . data + " ▁ " ) ; Node last = head . prev ; temp = last ; System . out . print ( " Backward direction : "); while ( temp . prev != last ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . prev ; } System . out . print ( temp . data + " ▁ " ) ; }
public static void main ( String args [ ] ) { Node head = null ; head = insertEnd ( head , getNode ( 1 ) ) ; head = insertEnd ( head , getNode ( 2 ) ) ; head = insertEnd ( head , getNode ( 3 ) ) ; head = insertEnd ( head , getNode ( 4 ) ) ; head = insertEnd ( head , getNode ( 5 ) ) ; System . out . print ( "Current list:NEW_LINE"); display ( head ) ; head = reverse ( head ) ; System . out . print ( " Reversed list : "); display ( head ) ; } }
static class node { int data ; node next ; node prev ; } ;
static node getNode ( ) { return new node ( ) ; }
static int displayList ( node temp ) { node t = temp ; if ( temp == null ) return 0 ; else { System . out . print ( " The ▁ list ▁ is : ▁ " ) ; while ( temp . next != t ) { System . out . print ( temp . data + " ▁ " ) ; temp = temp . next ; } System . out . print ( temp . data ) ; return 1 ; } }
static node createList ( int arr [ ] , int n , node start ) {
node newNode , temp ; int i ;
for ( i = 0 ; i < n ; i ++ ) {
newNode = getNode ( ) ;
newNode . data = arr [ i ] ;
if ( i == 0 ) { start = newNode ; newNode . prev = start ; newNode . next = start ; } else {
temp = ( start ) . prev ;
temp . next = newNode ; newNode . next = start ; newNode . prev = temp ; temp = start ; temp . prev = newNode ; } } return start ; }
int arr [ ] = { 1 , 2 , 3 , 4 , 5 } ; int n = arr . length ;
node start = null ;
start = createList ( arr , n , start ) ;
displayList ( start ) ; } }
static class Node { int data ; Node next ; } ; static Node newNode ( int data ) { Node node = new Node ( ) ; node . data = data ; node . next = null ; return node ; }
static int alivesol ( int Num ) { if ( Num == 1 ) return 1 ;
Node last = newNode ( 1 ) ; last . next = last ; for ( int i = 2 ; i <= Num ; i ++ ) { Node temp = newNode ( i ) ; temp . next = last . next ; last . next = temp ; last = temp ; }
Node curr = last . next ;
Node temp = new Node ( ) ; while ( curr . next != curr ) { temp = curr ; curr = curr . next ; temp . next = curr . next ;
temp = temp . next ; curr = temp ; }
int res = temp . data ; return res ; }
public static void main ( String args [ ] ) { int N = 100 ; System . out . println ( alivesol ( N ) ) ; } }
class Node { Node left = null ; Node right = null ; int data ; Node ( int data ) { this . data = data ; } } class GFG {
public static int findDepth ( Node root ) {
if ( root == null ) return 0 ;
int left = findDepth ( root . left ) ;
int right = findDepth ( root . right ) ;
return 1 + Math . max ( left , right ) ; }
public static Node DFS ( Node root , int curr , int depth ) {
if ( root == null ) return null ;
if ( curr == depth ) return root ;
Node left = DFS ( root . left , curr + 1 , depth ) ;
Node right = DFS ( root . right , curr + 1 , depth ) ;
if ( left != null && right != null ) return root ;
return ( left != null ) ? left : right ; }
public static Node lcaOfDeepestLeaves ( Node root ) {
if ( root == null ) return null ;
int depth = findDepth ( root ) - 1 ;
return DFS ( root , 0 , depth ) ; }
Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . left = new Node ( 6 ) ; root . right . right = new Node ( 7 ) ; root . right . left . left = new Node ( 8 ) ; root . right . left . right = new Node ( 9 ) ; System . out . println ( lcaOfDeepestLeaves ( root ) . data ) ; } }
static int filter ( int x , int y , int z ) { if ( x != - 1 && y != - 1 ) { return z ; } return x == - 1 ? y : x ; }
static int samePathUtil ( int mtrx [ ] [ ] , int vrtx , int v1 , int v2 , int i ) { int ans = - 1 ;
if ( i == v1 i == v2 ) return i ; for ( int j = 0 ; j < vrtx ; j ++ ) {
if ( mtrx [ i ] [ j ] == 1 ) {
ans = filter ( ans , samePathUtil ( mtrx , vrtx , v1 , v2 , j ) , i ) ; } }
return ans ; }
static boolean isVertexAtSamePath ( int mtrx [ ] [ ] , int vrtx , int v1 , int v2 , int i ) { int lca = samePathUtil ( mtrx , vrtx , v1 - 1 , v2 - 1 , i ) ; if ( lca == v1 - 1 lca == v2 - 1 ) return true ; return false ; }
public static void main ( String [ ] args ) { int vrtx = 7 ; int mtrx [ ] [ ] = { { 0 , 1 , 1 , 1 , 0 , 0 , 0 } , { 0 , 0 , 0 , 0 , 1 , 0 , 0 } , { 0 , 0 , 0 , 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 } , { 0 , 0 , 0 , 0 , 0 , 0 , 0 } } ; int v1 = 1 , v2 = 5 ; if ( isVertexAtSamePath ( mtrx , vrtx , v1 , v2 , 0 ) ) System . out . print ( " Yes " ) ; else System . out . print ( " No " ) ; } }
import java . io . * ; import java . util . * ; class GFG { static final int MAX = 1000 ;
static final int log = 10 ;
static int [ ] level = new int [ MAX ] ; static int [ ] [ ] lca = new int [ MAX ] [ log ] ; static int [ ] [ ] dist = new int [ MAX ] [ log ] ;
@ SuppressWarnings ( " unchecked " ) static List < List < int [ ] > > graph = new ArrayList ( ) ; static void addEdge ( int u , int v , int cost ) { graph . get ( u ) . add ( new int [ ] { v , cost } ) ; graph . get ( v ) . add ( new int [ ] { u , cost } ) ; }
static void dfs ( int node , int parent , int h , int cost ) {
lca [ node ] [ 0 ] = parent ;
level [ node ] = h ; if ( parent != - 1 ) { dist [ node ] [ 0 ] = cost ; } for ( int i = 1 ; i < log ; i ++ ) { if ( lca [ node ] [ i - 1 ] != - 1 ) {
lca [ node ] [ i ] = lca [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ; dist [ node ] [ i ] = dist [ node ] [ i - 1 ] + dist [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ; } } for ( int [ ] i : graph . get ( node ) ) { if ( i [ 0 ] == parent ) continue ; dfs ( i [ 0 ] , node , h + 1 , i [ 1 ] ) ; } }
static void findDistance ( int u , int v ) { int ans = 0 ;
if ( level [ u ] > level [ v ] ) { int temp = u ; u = v ; v = temp ; }
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v ] [ i ] != - 1 && level [ lca [ v ] [ i ] ] >= level [ u ] ) {
ans += dist [ v ] [ i ] ; v = lca [ v ] [ i ] ; } }
if ( v == u ) { System . out . println ( ans ) ; } else {
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v ] [ i ] != lca [ u ] [ i ] ) {
ans += dist [ u ] [ i ] + dist [ v ] [ i ] ; v = lca [ v ] [ i ] ; u = lca [ u ] [ i ] ; } }
ans += dist [ u ] [ 0 ] + dist [ v ] [ 0 ] ; System . out . println ( ans ) ; } }
int n = 5 ; for ( int i = 0 ; i < MAX ; i ++ ) { graph . add ( new ArrayList < int [ ] > ( ) ) ; }
addEdge ( 1 , 2 , 2 ) ; addEdge ( 1 , 3 , 3 ) ; addEdge ( 2 , 4 , 5 ) ; addEdge ( 2 , 5 , 7 ) ;
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = 0 ; j < log ; j ++ ) { lca [ i ] [ j ] = - 1 ; dist [ i ] [ j ] = 0 ; } }
dfs ( 1 , - 1 , 0 , 0 ) ;
findDistance ( 1 , 3 ) ;
findDistance ( 2 , 3 ) ;
findDistance ( 3 , 5 ) ; } }
import java . util . * ; class GFG { static final int MAX = 1000 ; static int [ ] weight = new int [ MAX ] ; static int [ ] level = new int [ MAX ] ; static int [ ] par = new int [ MAX ] ; static boolean [ ] prime = new boolean [ MAX + 1 ] ; static Vector < Integer > [ ] graph = new Vector [ MAX ] ;
static void SieveOfEratosthenes ( ) {
for ( int i = 0 ; i < prime . length ; i ++ ) prime [ i ] = true ; for ( int p = 2 ; p * p <= MAX ; p ++ ) {
if ( prime [ p ] == true ) {
for ( int i = p * p ; i <= MAX ; i += p ) prime [ i ] = false ; } } }
static void dfs ( int node , int parent , int h ) {
par [ node ] = parent ;
level [ node ] = h ; for ( int child : graph [ node ] ) { if ( child == parent ) continue ; dfs ( child , node , h + 1 ) ; } }
static int findPrimeOnPath ( int u , int v ) { int count = 0 ;
if ( level [ u ] > level [ v ] ) { int temp = v ; v = u ; u = temp ; } int d = level [ v ] - level [ u ] ;
while ( d -- > 0 ) {
if ( prime [ weight [ v ] ] ) count ++ ; v = par [ v ] ; }
if ( v == u ) { if ( prime [ weight [ v ] ] ) count ++ ; return count ; }
while ( v != u ) { if ( prime [ weight [ v ] ] ) count ++ ; if ( prime [ weight [ u ] ] ) count ++ ; u = par [ u ] ; v = par [ v ] ; }
if ( prime [ weight [ v ] ] ) count ++ ; return count ; }
SieveOfEratosthenes ( ) ;
weight [ 1 ] = 5 ; weight [ 2 ] = 10 ; weight [ 3 ] = 11 ; weight [ 4 ] = 8 ; weight [ 5 ] = 6 ;
graph [ 1 ] . add ( 2 ) ; graph [ 2 ] . add ( 3 ) ; graph [ 2 ] . add ( 4 ) ; graph [ 1 ] . add ( 5 ) ; dfs ( 1 , - 1 , 0 ) ; int u = 3 , v = 5 ; System . out . print ( findPrimeOnPath ( u , v ) ) ; } }
import java . util . * ; class GFG { static final int MAX = 1000 ;
static final int log = 10 ;
static int [ ] level = new int [ MAX ] ; static int [ ] [ ] lca = new int [ MAX ] [ log ] ; static int [ ] [ ] minWeight = new int [ MAX ] [ log ] ; static int [ ] [ ] maxWeight = new int [ MAX ] [ log ] ;
static Vector < Integer > [ ] graph = new Vector [ MAX ] ;
static int [ ] weight = new int [ MAX ] ; private static void swap ( int x , int y ) { int temp = x ; x = y ; y = temp ; } static void addEdge ( int u , int v ) { graph [ u ] . add ( v ) ; graph [ v ] . add ( u ) ; }
static void dfs ( int node , int parent , int h ) {
lca [ node ] [ 0 ] = parent ;
level [ node ] = h ; if ( parent != - 1 ) { minWeight [ node ] [ 0 ] = Math . min ( weight [ node ] , weight [ parent ] ) ; maxWeight [ node ] [ 0 ] = Math . max ( weight [ node ] , weight [ parent ] ) ; } for ( int i = 1 ; i < log ; i ++ ) { if ( lca [ node ] [ i - 1 ] != - 1 ) {
lca [ node ] [ i ] = lca [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ; minWeight [ node ] [ i ] = Math . min ( minWeight [ node ] [ i - 1 ] , minWeight [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ) ; maxWeight [ node ] [ i ] = Math . max ( maxWeight [ node ] [ i - 1 ] , maxWeight [ lca [ node ] [ i - 1 ] ] [ i - 1 ] ) ; } } for ( int i : graph [ node ] ) { if ( i == parent ) continue ; dfs ( i , node , h + 1 ) ; } }
static void findMinMaxWeight ( int u , int v ) { int minWei = Integer . MAX_VALUE ; int maxWei = Integer . MIN_VALUE ;
if ( level [ u ] > level [ v ] ) swap ( u , v ) ;
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( lca [ v ] [ i ] != - 1 && level [ lca [ v ] [ i ] ] >= level [ u ] ) {
minWei = Math . min ( minWei , minWeight [ v ] [ i ] ) ; maxWei = Math . max ( maxWei , maxWeight [ v ] [ i ] ) ; v = lca [ v ] [ i ] ; } }
if ( v == u ) { System . out . print ( minWei + " ▁ " + maxWei + "NEW_LINE"); } else {
for ( int i = log - 1 ; i >= 0 ; i -- ) { if ( v == - 1 ) v ++ ; if ( lca [ v ] [ i ] != lca [ u ] [ i ] ) {
minWei = Math . min ( minWei , Math . min ( minWeight [ v ] [ i ] , minWeight [ u ] [ i ] ) ) ;
maxWei = Math . max ( maxWei , Math . max ( maxWeight [ v ] [ i ] , maxWeight [ u ] [ i ] ) ) ; v = lca [ v ] [ i ] ; u = lca [ u ] [ i ] ; } }
if ( u == - 1 ) u ++ ; minWei = Math . min ( minWei , Math . min ( minWeight [ v ] [ 0 ] , minWeight [ u ] [ 0 ] ) ) ;
maxWei = Math . max ( maxWei , Math . max ( maxWeight [ v ] [ 0 ] , maxWeight [ u ] [ 0 ] ) ) ; System . out . print ( minWei + " ▁ " + maxWei + "NEW_LINE"); } }
int n = 5 ; for ( int i = 0 ; i < graph . length ; i ++ ) graph [ i ] = new Vector < Integer > ( ) ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 5 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 3 ) ; weight [ 1 ] = - 1 ; weight [ 2 ] = 5 ; weight [ 3 ] = - 1 ; weight [ 4 ] = 3 ; weight [ 5 ] = - 2 ;
for ( int i = 1 ; i <= n ; i ++ ) { for ( int j = 0 ; j < log ; j ++ ) { lca [ i ] [ j ] = - 1 ; minWeight [ i ] [ j ] = Integer . MAX_VALUE ; maxWeight [ i ] [ j ] = Integer . MIN_VALUE ; } }
dfs ( 1 , - 1 , 0 ) ;
findMinMaxWeight ( 1 , 3 ) ;
findMinMaxWeight ( 2 , 4 ) ;
findMinMaxWeight ( 3 , 5 ) ; } }
static int T = 1 ; static void dfs ( int node , int parent , Vector < Integer > g [ ] , int level [ ] , int t_in [ ] , int t_out [ ] ) {
if ( parent == - 1 ) { level [ node ] = 1 ; } else { level [ node ] = level [ parent ] + 1 ; }
t_in [ node ] = T ; for ( int i : g [ node ] ) { if ( i != parent ) { T ++ ; dfs ( i , node , g , level , t_in , t_out ) ; } } T ++ ;
t_out [ node ] = T ; } static int findLCA ( int n , Vector < Integer > g [ ] , Vector < Integer > v ) {
int [ ] level = new int [ n + 1 ] ;
int [ ] t_in = new int [ n + 1 ] ;
int [ ] t_out = new int [ n + 1 ] ;
dfs ( 1 , - 1 , g , level , t_in , t_out ) ; int mint = Integer . MAX_VALUE , maxt = Integer . MIN_VALUE ; int minv = - 1 , maxv = - 1 ; for ( int i = 0 ; i < v . size ( ) ; i ++ ) {
if ( t_in [ v . get ( i ) ] < mint ) { mint = t_in [ v . get ( i ) ] ; minv = v . get ( i ) ; }
if ( t_out [ v . get ( i ) ] > maxt ) { maxt = t_out [ v . get ( i ) ] ; maxv = v . get ( i ) ; } }
if ( minv == maxv ) { return minv ; }
int lev = Math . min ( level [ minv ] , level [ maxv ] ) ; int node = 0 , l = Integer . MIN_VALUE ; for ( int i = 1 ; i <= n ; i ++ ) {
if ( level [ i ] > lev ) continue ;
if ( t_in [ i ] <= mint && t_out [ i ] >= maxt && level [ i ] > l ) { node = i ; l = level [ i ] ; } } return node ; }
public static void main ( String [ ] args ) { int n = 10 ; Vector < Integer > [ ] g = new Vector [ n + 1 ] ; for ( int i = 0 ; i < g . length ; i ++ ) g [ i ] = new Vector < Integer > ( ) ; g [ 1 ] . add ( 2 ) ; g [ 2 ] . add ( 1 ) ; g [ 1 ] . add ( 3 ) ; g [ 3 ] . add ( 1 ) ; g [ 1 ] . add ( 4 ) ; g [ 4 ] . add ( 1 ) ; g [ 2 ] . add ( 5 ) ; g [ 5 ] . add ( 2 ) ; g [ 2 ] . add ( 6 ) ; g [ 6 ] . add ( 2 ) ; g [ 3 ] . add ( 7 ) ; g [ 7 ] . add ( 3 ) ; g [ 4 ] . add ( 10 ) ; g [ 10 ] . add ( 4 ) ; g [ 8 ] . add ( 7 ) ; g [ 7 ] . add ( 8 ) ; g [ 9 ] . add ( 7 ) ; g [ 7 ] . add ( 9 ) ; Vector < Integer > v = new Vector < > ( ) ; v . add ( 7 ) ; v . add ( 3 ) ; v . add ( 8 ) ; System . out . print ( findLCA ( n , g , v ) + "NEW_LINE"); } }
import java . util . * ; @ SuppressWarnings ( " unchecked " ) class GFG { static int MAX_SIZE = 100005 , MAX_CHAR = 26 ; static int [ ] [ ] nodeCharactersCount = new int [ MAX_SIZE ] [ MAX_CHAR ] ; static Vector < Integer > [ ] tree = new Vector [ MAX_SIZE ] ;
static boolean canFormPalindrome ( int [ ] charArray ) {
int oddCount = 0 ; for ( int i = 0 ; i < MAX_CHAR ; i ++ ) { if ( charArray [ i ] % 2 == 1 ) oddCount ++ ; }
if ( oddCount >= 2 ) return false ; else return true ; }
static int LCA ( int currentNode , int x , int y ) {
if ( currentNode == x ) return x ;
if ( currentNode == y ) return y ; int xLca , yLca ;
xLca = yLca = - 1 ;
int gotLca = - 1 ;
for ( int l = 0 ; l < tree [ currentNode ] . size ( ) ; l ++ ) {
int nextNode = tree [ currentNode ] . elementAt ( l ) ;
int out_ = LCA ( nextNode , x , y ) ; if ( out_ == x ) xLca = out_ ; if ( out_ == y ) yLca = out_ ;
if ( xLca != - 1 && yLca != - 1 ) return currentNode ;
if ( out_ != - 1 ) gotLca = out_ ; } return gotLca ; }
static void buildTree ( int i ) { for ( int l = 0 ; l < tree [ i ] . size ( ) ; l ++ ) { int nextNode = tree [ i ] . elementAt ( l ) ; for ( int j = 0 ; j < MAX_CHAR ; j ++ ) {
nodeCharactersCount [ nextNode ] [ j ] += nodeCharactersCount [ i ] [ j ] ; }
buildTree ( nextNode ) ; } }
static boolean canFormPalindromicPath ( int x , int y ) { int lcaNode ;
if ( x == y ) lcaNode = x ;
else lcaNode = LCA ( 1 , x , y ) ; int [ ] charactersCountFromXtoY = new int [ MAX_CHAR ] ; Arrays . fill ( charactersCountFromXtoY , 0 ) ;
for ( int i = 0 ; i < MAX_CHAR ; i ++ ) { charactersCountFromXtoY [ i ] = nodeCharactersCount [ x ] [ i ] + nodeCharactersCount [ y ] [ i ] - 2 * nodeCharactersCount [ lcaNode ] [ i ] ; }
if ( canFormPalindrome ( charactersCountFromXtoY ) ) return true ; return false ; }
static void updateNodeCharactersCount ( String str , int v ) {
for ( int i = 0 ; i < str . length ( ) ; i ++ ) nodeCharactersCount [ v ] [ str . charAt ( i ) - ' a ' ] ++ ; }
static void performQueries ( int [ ] [ ] queries , int q ) { int i = 0 ; while ( i < q ) { int x = queries [ i ] [ 0 ] ; int y = queries [ i ] [ 1 ] ;
if ( canFormPalindromicPath ( x , y ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; i ++ ; } }
for ( int i = 0 ; i < MAX_SIZE ; i ++ ) { for ( int j = 0 ; j < MAX_CHAR ; j ++ ) { nodeCharactersCount [ i ] [ j ] = 0 ; } } for ( int i = 0 ; i < MAX_SIZE ; i ++ ) { tree [ i ] = new Vector < > ( ) ; }
tree [ 1 ] . add ( 2 ) ; updateNodeCharactersCount ( " bbc " , 2 ) ;
tree [ 1 ] . add ( 3 ) ; updateNodeCharactersCount ( " ac " , 3 ) ;
buildTree ( 1 ) ; int [ ] [ ] queries = { { 1 , 2 } , { 2 , 3 } , { 3 , 1 } , { 3 , 3 } } ; int q = queries . length ;
performQueries ( queries , q ) ; } }
static class Node { Node left ; Node right ; int data ; } ;
static Node newNode ( int key ) { Node node = new Node ( ) ; node . left = node . right = null ; node . data = key ; return node ; } static Vector < Integer > path ;
static boolean FindPath ( Node root , int key ) { if ( root == null ) return false ; path . add ( root . data ) ; if ( root . data == key ) return true ; if ( FindPath ( root . left , key ) || FindPath ( root . right , key ) ) return true ; path . remove ( path . size ( ) - 1 ) ; return false ; }
static int minMaxNodeInPath ( Node root , int a , int b ) {
path = new Vector < Integer > ( ) ; boolean flag = true ;
Vector < Integer > Path2 = new Vector < Integer > ( ) , Path1 = new Vector < Integer > ( ) ;
int min1 = Integer . MAX_VALUE ; int max1 = Integer . MIN_VALUE ;
int min2 = Integer . MAX_VALUE ; int max2 = Integer . MIN_VALUE ; int i = 0 ; int j = 0 ; flag = FindPath ( root , a ) ; Path1 = path ; path = new Vector < Integer > ( ) ; flag &= FindPath ( root , b ) ; Path2 = path ;
if ( flag ) {
for ( i = 0 ; i < Path1 . size ( ) && i < Path2 . size ( ) ; i ++ ) if ( Path1 . get ( i ) != Path2 . get ( i ) ) break ; i -- ; j = i ;
for ( ; i < Path1 . size ( ) ; i ++ ) { if ( min1 > Path1 . get ( i ) ) min1 = Path1 . get ( i ) ; if ( max1 < Path1 . get ( i ) ) max1 = Path1 . get ( i ) ; }
for ( ; j < Path2 . size ( ) ; j ++ ) { if ( min2 > Path2 . get ( j ) ) min2 = Path2 . get ( j ) ; if ( max2 < Path2 . get ( j ) ) max2 = Path2 . get ( j ) ; }
System . out . println ( " Min ▁ = ▁ " + Math . min ( min1 , min2 ) ) ;
System . out . println ( " Max ▁ = ▁ " + Math . max ( max1 , max2 ) ) ; }
else System . out . println ( "Min = -1 Max = - 1 "); return 0 ; }
public static void main ( String args [ ] ) { Node root = newNode ( 20 ) ; root . left = newNode ( 8 ) ; root . right = newNode ( 22 ) ; root . left . left = newNode ( 5 ) ; root . left . right = newNode ( 3 ) ; root . right . left = newNode ( 4 ) ; root . right . right = newNode ( 25 ) ; root . left . right . left = newNode ( 10 ) ; root . left . right . right = newNode ( 14 ) ; int a = 5 ; int b = 14 ; minMaxNodeInPath ( root , a , b ) ; } }
static class Node { int data ; Node left ; Node right ; }
static Node newNode ( int data ) { Node node = new Node ( ) ; node . data = data ; node . left = null ; node . right = null ; return node ; }
static boolean getPath ( Node root , Vector < Integer > arr , int x ) {
if ( root == null ) return false ;
arr . add ( root . data ) ;
if ( root . data == x ) return true ;
if ( getPath ( root . left , arr , x ) || getPath ( root . right , arr , x ) ) return true ;
arr . remove ( arr . size ( ) - 1 ) ; return false ; }
static int sumOddNodes ( Node root , int n1 , int n2 ) {
Vector < Integer > path1 = new Vector < Integer > ( ) ;
Vector < Integer > path2 = new Vector < Integer > ( ) ; getPath ( root , path1 , n1 ) ; getPath ( root , path2 , n2 ) ; int intersection = - 1 ;
int i = 0 , j = 0 ; while ( i != path1 . size ( ) || j != path2 . size ( ) ) {
if ( i == j && path1 . get ( i ) == path2 . get ( j ) ) { i ++ ; j ++ ; } else { intersection = j - 1 ; break ; } } int sum = 0 ;
for ( i = path1 . size ( ) - 1 ; i > intersection ; i -- ) if ( path1 . get ( i ) % 2 != 0 ) sum += path1 . get ( i ) ; for ( i = intersection ; i < path2 . size ( ) ; i ++ ) if ( path2 . get ( i ) % 2 != 0 ) sum += path2 . get ( i ) ; return sum ; }
public static void main ( String args [ ] ) { Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . right = newNode ( 6 ) ; int node1 = 5 ; int node2 = 6 ; System . out . print ( sumOddNodes ( root , node1 , node2 ) ) ; } }
static int MAX = 1000 ;
static int findLCA ( int n1 , int n2 , int parent [ ] ) {
boolean [ ] visited = new boolean [ MAX ] ; visited [ n1 ] = true ;
while ( parent [ n1 ] != - 1 ) { visited [ n1 ] = true ;
n1 = parent [ n1 ] ; } visited [ n1 ] = true ;
while ( ! visited [ n2 ] ) n2 = parent [ n2 ] ; return n2 ; }
static void insertAdj ( int parent [ ] , int i , int j ) { parent [ i ] = j ; }
int [ ] parent = new int [ MAX ] ;
parent [ 20 ] = - 1 ; insertAdj ( parent , 8 , 20 ) ; insertAdj ( parent , 22 , 20 ) ; insertAdj ( parent , 4 , 8 ) ; insertAdj ( parent , 12 , 8 ) ; insertAdj ( parent , 10 , 12 ) ; insertAdj ( parent , 14 , 12 ) ; System . out . println ( findLCA ( 10 , 14 , parent ) ) ; } }
class GfG { static class Node { Node left , right ; int key ; } static Node newNode ( int key ) { Node ptr = new Node ( ) ; ptr . key = key ; ptr . left = null ; ptr . right = null ; return ptr ; }
static Node insert ( Node root , int key ) { if ( root == null ) root = newNode ( key ) ; else if ( root . key > key ) root . left = insert ( root . left , key ) ; else if ( root . key < key ) root . right = insert ( root . right , key ) ; return root ; }
static int distanceFromRoot ( Node root , int x ) { if ( root . key == x ) return 0 ; else if ( root . key > x ) return 1 + distanceFromRoot ( root . left , x ) ; return 1 + distanceFromRoot ( root . right , x ) ; }
static int distanceBetween2 ( Node root , int a , int b ) { if ( root == null ) return 0 ;
if ( root . key > a && root . key > b ) return distanceBetween2 ( root . left , a , b ) ;
if ( root . key < a && root . key < b ) return distanceBetween2 ( root . right , a , b ) ;
if ( root . key >= a && root . key <= b ) return distanceFromRoot ( root , a ) + distanceFromRoot ( root , b ) ; return 0 ; }
static int findDistWrapper ( Node root , int a , int b ) { int temp = 0 ; if ( a > b ) { temp = a ; a = b ; b = temp ; } return distanceBetween2 ( root , a , b ) ; }
public static void main ( String [ ] args ) { Node root = null ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; System . out . println ( findDistWrapper ( root , 5 , 35 ) ) ; } }
import java . io . * ; import java . util . * ; class GFG { static int MAXN = 1001 ;
static int [ ] depth = new int [ MAXN ] ;
static int [ ] parent = new int [ MAXN ] ; @ SuppressWarnings ( " unchecked " ) static Vector < Integer > [ ] adj = new Vector [ MAXN ] ; static { for ( int i = 0 ; i < MAXN ; i ++ ) adj [ i ] = new Vector < > ( ) ; } static void addEdge ( int u , int v ) { adj [ u ] . add ( v ) ; adj [ v ] . add ( u ) ; } static void dfs ( int cur , int prev ) {
parent [ cur ] = prev ;
depth [ cur ] = depth [ prev ] + 1 ;
for ( int i = 0 ; i < adj [ cur ] . size ( ) ; i ++ ) if ( adj [ cur ] . elementAt ( i ) != prev ) dfs ( adj [ cur ] . elementAt ( i ) , cur ) ; } static void preprocess ( ) {
depth [ 0 ] = - 1 ;
dfs ( 1 , 0 ) ; }
static int LCANaive ( int u , int v ) { if ( u == v ) return u ; if ( depth [ u ] > depth [ v ] ) { int temp = u ; u = v ; v = temp ; } v = parent [ v ] ; return LCANaive ( u , v ) ; }
public static void main ( String [ ] args ) {
addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 1 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 4 , 8 ) ; addEdge ( 4 , 9 ) ; addEdge ( 9 , 10 ) ; addEdge ( 9 , 11 ) ; addEdge ( 7 , 12 ) ; addEdge ( 7 , 13 ) ; preprocess ( ) ; System . out . println ( " LCA ( 11,8 ) ▁ : ▁ " + LCANaive ( 11 , 8 ) ) ; System . out . println ( " LCA ( 3,13 ) ▁ : ▁ " + LCANaive ( 3 , 13 ) ) ; } }
import java . util . * ; class GFG { static final int MAXN = 1001 ;
static int block_sz ;
static int [ ] depth = new int [ MAXN ] ;
static int [ ] parent = new int [ MAXN ] ;
static int [ ] jump_parent = new int [ MAXN ] ; static Vector < Integer > [ ] adj = new Vector [ MAXN ] ; static void addEdge ( int u , int v ) { adj [ u ] . add ( v ) ; adj [ v ] . add ( u ) ; } static int LCANaive ( int u , int v ) { if ( u == v ) return u ; if ( depth [ u ] > depth [ v ] ) { int t = u ; u = v ; v = t ; } v = parent [ v ] ; return LCANaive ( u , v ) ; }
static void dfs ( int cur , int prev ) {
depth [ cur ] = depth [ prev ] + 1 ;
parent [ cur ] = prev ;
if ( depth [ cur ] % block_sz == 0 )
jump_parent [ cur ] = parent [ cur ] ; else
jump_parent [ cur ] = jump_parent [ prev ] ;
for ( int i = 0 ; i < adj [ cur ] . size ( ) ; ++ i ) if ( adj [ cur ] . get ( i ) != prev ) dfs ( adj [ cur ] . get ( i ) , cur ) ; }
static int LCASQRT ( int u , int v ) { while ( jump_parent [ u ] != jump_parent [ v ] ) { if ( depth [ u ] > depth [ v ] ) {
int t = u ; u = v ; v = t ; }
v = jump_parent [ v ] ; }
return LCANaive ( u , v ) ; } static void preprocess ( int height ) { block_sz = ( int ) Math . sqrt ( height ) ; depth [ 0 ] = - 1 ;
dfs ( 1 , 0 ) ; }
public static void main ( String [ ] args ) { for ( int i = 0 ; i < adj . length ; i ++ ) adj [ i ] = new Vector < Integer > ( ) ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 1 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 4 , 8 ) ; addEdge ( 4 , 9 ) ; addEdge ( 9 , 10 ) ; addEdge ( 9 , 11 ) ; addEdge ( 7 , 12 ) ; addEdge ( 7 , 13 ) ;
int height = 4 ; preprocess ( height ) ; System . out . print ( " LCA ( 11,8 ) ▁ : ▁ " + LCASQRT ( 11 , 8 ) + "NEW_LINE"); System . out . print ( " LCA ( 3,13 ) ▁ : ▁ " + LCASQRT ( 3 , 13 ) + "NEW_LINE"); } }
static final int MAXN = 100001 ; static Vector < Integer > [ ] tree = new Vector [ MAXN ] ;
static void dfs ( int cur , int prev , int pathNumber , int ptr , int node ) { for ( int i = 0 ; i < tree [ cur ] . size ( ) ; i ++ ) { if ( tree [ cur ] . get ( i ) != prev && ! flag ) {
path [ pathNumber ] [ ptr ] = tree [ cur ] . get ( i ) ; if ( tree [ cur ] . get ( i ) == node ) {
flag = true ;
path [ pathNumber ] [ ptr + 1 ] = - 1 ; return ; } dfs ( tree [ cur ] . get ( i ) , cur , pathNumber , ptr + 1 , node ) ; } } }
static int LCA ( int a , int b ) {
if ( a == b ) return a ;
path [ 1 ] [ 0 ] = path [ 2 ] [ 0 ] = 1 ;
flag = false ; dfs ( 1 , 0 , 1 , 1 , a ) ;
flag = false ; dfs ( 1 , 0 , 2 , 1 , b ) ;
int i = 0 ; while ( i < MAXN && path [ 1 ] [ i ] == path [ 2 ] [ i ] ) i ++ ;
return path [ 1 ] [ i - 1 ] ; } static void addEdge ( int a , int b ) { tree [ a ] . add ( b ) ; tree [ b ] . add ( a ) ; }
public static void main ( String [ ] args ) { for ( int i = 0 ; i < MAXN ; i ++ ) tree [ i ] = new Vector < Integer > ( ) ;
addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 3 , 8 ) ; System . out . print ( " LCA ( 4 , ▁ 7 ) ▁ = ▁ " + LCA ( 4 , 7 ) + "NEW_LINE"); System . out . print ( " LCA ( 4 , ▁ 6 ) ▁ = ▁ " + LCA ( 4 , 6 ) + "NEW_LINE"); } }
import java . util . * ; class GFG { static final int MAXN = 100000 ; static final int level = 18 ; @ SuppressWarnings ( " unchecked " ) static Vector < Integer > [ ] tree = new Vector [ MAXN ] ; static int [ ] depth = new int [ MAXN ] ; static int [ ] [ ] parent = new int [ MAXN ] [ level ] ;
static void dfs ( int cur , int prev ) { depth [ cur ] = depth [ prev ] + 1 ; parent [ cur ] [ 0 ] = prev ; for ( int i = 0 ; i < tree [ cur ] . size ( ) ; i ++ ) { if ( tree [ cur ] . get ( i ) != prev ) dfs ( tree [ cur ] . get ( i ) , cur ) ; } }
static void precomputeSparseMatrix ( int n ) { for ( int i = 1 ; i < level ; i ++ ) { for ( int node = 1 ; node <= n ; node ++ ) { if ( parent [ node ] [ i - 1 ] != - 1 ) parent [ node ] [ i ] = parent [ parent [ node ] [ i - 1 ] ] [ i - 1 ] ; } } }
static int lca ( int u , int v ) { if ( depth [ v ] < depth [ u ] ) { u = u + v ; v = u - v ; u = u - v ; } int diff = depth [ v ] - depth [ u ] ;
for ( int i = 0 ; i < level ; i ++ ) if ( ( ( diff >> i ) & 1 ) == 1 ) v = parent [ v ] [ i ] ;
if ( u == v ) return u ;
for ( int i = level - 1 ; i >= 0 ; i -- ) if ( parent [ u ] [ i ] != parent [ v ] [ i ] ) { u = parent [ u ] [ i ] ; v = parent [ v ] [ i ] ; } return parent [ u ] [ 0 ] ; } static void addEdge ( int u , int v ) { tree [ u ] . add ( v ) ; tree [ v ] . add ( u ) ; } static void memset ( int value ) { for ( int i = 0 ; i < MAXN ; i ++ ) { for ( int j = 0 ; j < level ; j ++ ) { parent [ i ] [ j ] = - 1 ; } } }
public static void main ( String [ ] args ) { memset ( - 1 ) ; for ( int i = 0 ; i < MAXN ; i ++ ) tree [ i ] = new Vector < Integer > ( ) ; int n = 8 ; addEdge ( 1 , 2 ) ; addEdge ( 1 , 3 ) ; addEdge ( 2 , 4 ) ; addEdge ( 2 , 5 ) ; addEdge ( 2 , 6 ) ; addEdge ( 3 , 7 ) ; addEdge ( 3 , 8 ) ; depth [ 0 ] = 0 ;
dfs ( 1 , 0 ) ;
precomputeSparseMatrix ( n ) ;
System . out . print ( " LCA ( 4 , ▁ 7 ) ▁ = ▁ " + lca ( 4 , 7 ) + "NEW_LINE"); System . out . print ( " LCA ( 4 , ▁ 6 ) ▁ = ▁ " + lca ( 4 , 6 ) + "NEW_LINE"); } }
static class Query { int L , R ; Query ( int L , int R ) { this . L = L ; this . R = R ; } } ;
static int LCE ( String str , int n , int L , int R ) { int length = 0 ; while ( R + length < n && str . charAt ( L + length ) == str . charAt ( R + length ) ) length ++ ; return ( length ) ; }
static void LCEQueries ( String str , int n , Query q [ ] , int m ) { for ( int i = 0 ; i < m ; i ++ ) { int L = q [ i ] . L ; int R = q [ i ] . R ; System . out . printf ( "LCE (%d, %d) = %dNEW_LINE", L, R, LCE ( str , n , L , R ) ) ; } return ; }
public static void main ( String [ ] args ) { String str = " abbababba " ; int n = str . length ( ) ;
Query q [ ] = new Query [ 3 ] ; q [ 0 ] = new Query ( 1 , 2 ) ; q [ 1 ] = new Query ( 1 , 6 ) ; q [ 2 ] = new Query ( 0 , 5 ) ; int m = q . length ; LCEQueries ( str , n , q , m ) ; } }
static final int V = 5 ;
static final int WHITE = 1 ;
static final int BLACK = 2 ;
static class Node { int data ; Node left , right ; } ;
static class subset { int parent ; int rank ; int ancestor ; int child ; int sibling ; int color ; } ;
static class Query { int L , R ; Query ( int L , int R ) { this . L = L ; this . R = R ; } } ;
static Node newNode ( int data ) { Node node = new Node ( ) ; node . data = data ; node . left = node . right = null ; return ( node ) ; }
static void makeSet ( subset subsets [ ] , int i ) { if ( i < 1 i > V ) return ; subsets [ i ] . color = WHITE ; subsets [ i ] . parent = i ; subsets [ i ] . rank = 0 ; return ; }
static int findSet ( subset subsets [ ] , int i ) {
if ( subsets [ i ] . parent != i ) subsets [ i ] . parent = findSet ( subsets , subsets [ i ] . parent ) ; return subsets [ i ] . parent ; }
static void unionSet ( subset subsets [ ] , int x , int y ) { int xroot = findSet ( subsets , x ) ; int yroot = findSet ( subsets , y ) ;
if ( subsets [ xroot ] . rank < subsets [ yroot ] . rank ) subsets [ xroot ] . parent = yroot ; else if ( subsets [ xroot ] . rank > subsets [ yroot ] . rank ) subsets [ yroot ] . parent = xroot ;
else { subsets [ yroot ] . parent = xroot ; ( subsets [ xroot ] . rank ) ++ ; } }
static void lcaWalk ( int u , Query q [ ] , int m , subset subsets [ ] ) {
makeSet ( subsets , u ) ;
subsets [ findSet ( subsets , u ) ] . ancestor = u ; int child = subsets [ u ] . child ;
while ( child != 0 ) { lcaWalk ( child , q , m , subsets ) ; unionSet ( subsets , u , child ) ; subsets [ findSet ( subsets , u ) ] . ancestor = u ; child = subsets [ child ] . sibling ; } subsets [ u ] . color = BLACK ; for ( int i = 0 ; i < m ; i ++ ) { if ( q [ i ] . L == u ) { if ( subsets [ q [ i ] . R ] . color == BLACK ) { System . out . printf ( "LCA(%d %d)->%dNEW_LINE", q [ i ] . L , q [ i ] . R , subsets [ findSet ( subsets , q [ i ] . R ) ] . ancestor ) ; } } else if ( q [ i ] . R == u ) { if ( subsets [ q [ i ] . L ] . color == BLACK ) { System . out . printf ( "LCA(%d %d)->%dNEW_LINE", q [ i ] . L , q [ i ] . R , subsets [ findSet ( subsets , q [ i ] . L ) ] . ancestor ) ; } } } return ; }
static void preprocess ( Node node , subset subsets [ ] ) { if ( node == null ) return ;
preprocess ( node . left , subsets ) ; if ( node . left != null && node . right != null ) {
subsets [ node . data ] . child = node . left . data ; subsets [ node . left . data ] . sibling = node . right . data ; } else if ( ( node . left != null && node . right == null ) || ( node . left == null && node . right != null ) ) { if ( node . left != null && node . right == null ) subsets [ node . data ] . child = node . left . data ; else subsets [ node . data ] . child = node . right . data ; }
preprocess ( node . right , subsets ) ; }
static void initialise ( subset subsets [ ] ) {
for ( int i = 1 ; i < subsets . length ; i ++ ) { subsets [ i ] = new subset ( ) ; subsets [ i ] . color = WHITE ; } return ; }
static void printLCAs ( Node root , Query q [ ] , int m ) {
subset [ ] subsets = new subset [ V + 1 ] ;
initialise ( subsets ) ;
preprocess ( root , subsets ) ;
lcaWalk ( root . data , q , m , subsets ) ; }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ;
Query q [ ] = new Query [ 3 ] ; q [ 0 ] = new Query ( 5 , 4 ) ; q [ 1 ] = new Query ( 1 , 3 ) ; q [ 2 ] = new Query ( 2 , 3 ) ; int m = q . length ; printLCAs ( root , q , m ) ; } }
class Node { int data ; Node left , right ; public Node ( int item ) { data = item ; left = right = null ; } } class Count { int count = 0 ; } class BinaryTree { Node root ; Count ct = new Count ( ) ;
boolean countSingleRec ( Node node , Count c ) {
if ( node == null ) return true ;
boolean left = countSingleRec ( node . left , c ) ; boolean right = countSingleRec ( node . right , c ) ;
if ( left == false right == false ) return false ;
if ( node . left != null && node . data != node . left . data ) return false ;
if ( node . right != null && node . data != node . right . data ) return false ;
c . count ++ ; return true ; }
int countSingle ( ) { return countSingle ( root ) ; } int countSingle ( Node node ) {
countSingleRec ( node , ct ) ; return ct . count ; }
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 5 ) ; tree . root . left = new Node ( 4 ) ; tree . root . right = new Node ( 5 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 4 ) ; tree . root . right . right = new Node ( 5 ) ; System . out . println ( " The ▁ count ▁ of ▁ single ▁ valued ▁ sub ▁ trees ▁ is ▁ : ▁ " + tree . countSingle ( ) ) ; } }
class Node { int key ; Node left , right ; public Node ( int key ) { this . key = key ; left = right = null ; } }
class Distance { int minDis = Integer . MAX_VALUE ; } class BinaryTree { Node root ;
void findLeafDown ( Node root , int lev , Distance minDist ) {
if ( root == null ) return ;
if ( root . left == null && root . right == null ) { if ( lev < ( minDist . minDis ) ) minDist . minDis = lev ; return ; }
findLeafDown ( root . left , lev + 1 , minDist ) ; findLeafDown ( root . right , lev + 1 , minDist ) ; }
int findThroughParent ( Node root , Node x , Distance minDist ) {
if ( root == null ) return - 1 ; if ( root == x ) return 0 ;
int l = findThroughParent ( root . left , x , minDist ) ;
if ( l != - 1 ) {
findLeafDown ( root . right , l + 2 , minDist ) ; return l + 1 ; }
int r = findThroughParent ( root . right , x , minDist ) ;
if ( r != - 1 ) {
findLeafDown ( root . left , r + 2 , minDist ) ; return r + 1 ; } return - 1 ; }
int minimumDistance ( Node root , Node x ) {
Distance d = new Distance ( ) ;
findLeafDown ( x , 0 , d ) ;
findThroughParent ( root , x , d ) ; return d . minDis ; }
tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 12 ) ; tree . root . right = new Node ( 13 ) ; tree . root . right . left = new Node ( 14 ) ; tree . root . right . right = new Node ( 15 ) ; tree . root . right . left . left = new Node ( 21 ) ; tree . root . right . left . right = new Node ( 22 ) ; tree . root . right . right . left = new Node ( 23 ) ; tree . root . right . right . right = new Node ( 24 ) ; tree . root . right . left . left . left = new Node ( 1 ) ; tree . root . right . left . left . right = new Node ( 2 ) ; tree . root . right . left . right . left = new Node ( 3 ) ; tree . root . right . left . right . right = new Node ( 4 ) ; tree . root . right . right . left . left = new Node ( 5 ) ; tree . root . right . right . left . right = new Node ( 6 ) ; tree . root . right . right . right . left = new Node ( 7 ) ; tree . root . right . right . right . right = new Node ( 8 ) ; Node x = tree . root . right ; System . out . println ( " The ▁ closest ▁ leaf ▁ to ▁ node ▁ with ▁ value ▁ " + x . key + " ▁ is ▁ at ▁ a ▁ distance ▁ of ▁ " + tree . minimumDistance ( tree . root , x ) ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } }
class BinaryTree { Node root ; void printInorder ( Node node ) { if ( node != null ) { printInorder ( node . left ) ; System . out . print ( node . data + " ▁ " ) ; printInorder ( node . right ) ; } }
Node RemoveHalfNodes ( Node node ) { if ( node == null ) return null ; node . left = RemoveHalfNodes ( node . left ) ; node . right = RemoveHalfNodes ( node . right ) ; if ( node . left == null && node . right == null ) return node ;
if ( node . left == null ) { Node new_root = node . right ; return new_root ; }
if ( node . right == null ) { Node new_root = node . left ; return new_root ; } return node ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; Node NewRoot = null ; tree . root = new Node ( 2 ) ; tree . root . left = new Node ( 7 ) ; tree . root . right = new Node ( 5 ) ; tree . root . left . right = new Node ( 6 ) ; tree . root . left . right . left = new Node ( 1 ) ; tree . root . left . right . right = new Node ( 11 ) ; tree . root . right . right = new Node ( 9 ) ; tree . root . right . right . left = new Node ( 4 ) ; System . out . println ( " the ▁ inorder ▁ traversal ▁ of ▁ tree ▁ is ▁ " ) ; tree . printInorder ( tree . root ) ; NewRoot = tree . RemoveHalfNodes ( tree . root ) ; System . out . print ( " Inorder traversal of the modified tree "); tree . printInorder ( NewRoot ) ; } }
static Node newNode ( int data ) { Node node = new Node ( ) ; node . data = data ; node . left = node . right = node . abtr = null ; return node ; } static Vector < Node > even_ptrs = new Vector < > ( ) ; static Vector < Node > odd_ptrs = new Vector < > ( ) ;
static void preorderTraversal ( Node root ) { if ( root == null ) return ;
if ( root . data % 2 == 0 ) ( even_ptrs ) . add ( root ) ;
else ( odd_ptrs ) . add ( root ) ; preorderTraversal ( root . left ) ; preorderTraversal ( root . right ) ; }
static void createLoops ( Node root ) { preorderTraversal ( root ) ; int i ;
for ( i = 1 ; i < even_ptrs . size ( ) ; i ++ ) even_ptrs . get ( i - 1 ) . abtr = even_ptrs . get ( i ) ;
even_ptrs . get ( i - 1 ) . abtr = even_ptrs . get ( 0 ) ;
for ( i = 1 ; i < odd_ptrs . size ( ) ; i ++ ) odd_ptrs . get ( i - 1 ) . abtr = odd_ptrs . get ( i ) ; odd_ptrs . get ( i - 1 ) . abtr = odd_ptrs . get ( 0 ) ; }
static void traverseLoop ( Node start ) { Node curr = start ; do { System . out . print ( curr . data + " ▁ " ) ; curr = curr . abtr ; } while ( curr != start ) ; }
Node root = null ; root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 7 ) ; createLoops ( root ) ;
System . out . print ( " Odd ▁ nodes : ▁ " ) ; traverseLoop ( root . right ) ; System . out . print ( " Even nodes : ");
traverseLoop ( root . left ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; right = left = null ; } }
public class BinaryTree { Node root ; Node head ; Node prev ;
public Node extractLeafList ( Node root ) { if ( root == null ) return null ; if ( root . left == null && root . right == null ) { if ( head == null ) { head = root ; prev = root ; } else { prev . right = root ; root . left = prev ; prev = root ; } return null ; } root . left = extractLeafList ( root . left ) ; root . right = extractLeafList ( root . right ) ; return root ; }
void inorder ( Node node ) { if ( node == null ) return ; inorder ( node . left ) ; System . out . print ( node . data + " ▁ " ) ; inorder ( node . right ) ; }
public void printDLL ( Node head ) { Node last = null ; while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; last = head ; head = head . right ; } }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 1 ) ; tree . root . left = new Node ( 2 ) ; tree . root . right = new Node ( 3 ) ; tree . root . left . left = new Node ( 4 ) ; tree . root . left . right = new Node ( 5 ) ; tree . root . right . right = new Node ( 6 ) ; tree . root . left . left . left = new Node ( 7 ) ; tree . root . left . left . right = new Node ( 8 ) ; tree . root . right . right . left = new Node ( 9 ) ; tree . root . right . right . right = new Node ( 10 ) ; System . out . println ( " Inorder ▁ traversal ▁ of ▁ given ▁ tree ▁ is ▁ : ▁ " ) ; tree . inorder ( tree . root ) ; tree . extractLeafList ( tree . root ) ; System . out . println ( " " ) ; System . out . println ( " Extracted ▁ double ▁ link ▁ list ▁ is ▁ : ▁ " ) ; tree . printDLL ( tree . head ) ; System . out . println ( " " ) ; System . out . println ( " Inorder ▁ traversal ▁ of ▁ modified ▁ tree ▁ is ▁ : ▁ " ) ; tree . inorder ( tree . root ) ; } }
public static boolean isStepNum ( int n ) {
int prevDigit = - 1 ;
while ( n > 0 ) {
int curDigit = n % 10 ;
if ( prevDigit != - 1 ) {
if ( Math . abs ( curDigit - prevDigit ) != 1 ) return false ; } n /= 10 ; prevDigit = curDigit ; } return true ; }
public static void displaySteppingNumbers ( int n , int m ) {
for ( int i = n ; i <= m ; i ++ ) if ( isStepNum ( i ) ) System . out . print ( i + " ▁ " ) ; }
public static void main ( String args [ ] ) { int n = 0 , m = 21 ;
displaySteppingNumbers ( n , m ) ; } }
public static void bfs ( int n , int m , int num ) {
Queue < Integer > q = new LinkedList < Integer > ( ) ; q . add ( num ) ; while ( ! q . isEmpty ( ) ) {
int stepNum = q . poll ( ) ;
if ( stepNum <= m && stepNum >= n ) { System . out . print ( stepNum + " ▁ " ) ; }
if ( stepNum == 0 stepNum > m ) continue ;
int lastDigit = stepNum % 10 ;
int stepNumA = stepNum * 10 + ( lastDigit - 1 ) ; int stepNumB = stepNum * 10 + ( lastDigit + 1 ) ;
if ( lastDigit == 0 ) q . add ( stepNumB ) ;
else if ( lastDigit == 9 ) q . add ( stepNumA ) ; else { q . add ( stepNumA ) ; q . add ( stepNumB ) ; } } }
public static void displaySteppingNumbers ( int n , int m ) {
for ( int i = 0 ; i <= 9 ; i ++ ) bfs ( n , m , i ) ; }
public static void main ( String args [ ] ) { int n = 0 , m = 21 ;
displaySteppingNumbers ( n , m ) ; } }
static class Node { int data ; Node left ; Node right ; Node ( int data ) { this . data = data ; left = null ; right = null ; } }
static void levelOrder ( Node root ) { if ( root == null ) return ;
Queue < Node > q = new LinkedList < > ( ) ;
q . add ( root ) ;
q . add ( null ) ;
while ( ! q . isEmpty ( ) ) { Node curr = q . poll ( ) ;
if ( curr == null ) { if ( ! q . isEmpty ( ) ) { q . add ( null ) ; System . out . println ( ) ; } } else {
if ( curr . left != null ) q . add ( curr . left ) ;
if ( curr . right != null ) q . add ( curr . right ) ; System . out . print ( curr . data + " ▁ " ) ; } } }
Node root = new Node ( 1 ) ; root . left = new Node ( 2 ) ; root . right = new Node ( 3 ) ; root . left . left = new Node ( 4 ) ; root . left . right = new Node ( 5 ) ; root . right . right = new Node ( 6 ) ; levelOrder ( root ) ; } }
static class Node { Node left ; int data ; Node right ; } ;
static void modifiedLevelOrder ( Node node ) {
if ( node == null ) return ; if ( node . left == null && node . right == null ) { System . out . print ( node . data ) ; return ; }
Queue < Node > myQueue = new LinkedList < > ( ) ;
Stack < Node > myStack = new Stack < > ( ) ; Node temp = null ;
int sz ;
int ct = 0 ;
boolean rightToLeft = false ;
myQueue . add ( node ) ;
while ( ! myQueue . isEmpty ( ) ) { ct ++ ; sz = myQueue . size ( ) ;
for ( int i = 0 ; i < sz ; i ++ ) { temp = myQueue . peek ( ) ; myQueue . remove ( ) ;
if ( rightToLeft == false ) System . out . print ( temp . data + " ▁ " ) ;
else myStack . push ( temp ) ; if ( temp . left != null ) myQueue . add ( temp . left ) ; if ( temp . right != null ) myQueue . add ( temp . right ) ; } if ( rightToLeft == true ) {
while ( ! myStack . isEmpty ( ) ) { temp = myStack . peek ( ) ; myStack . pop ( ) ; System . out . print ( temp . data + " ▁ " ) ; } }
if ( ct == 2 ) { rightToLeft = ! rightToLeft ; ct = 0 ; } System . out . print ( "NEW_LINE"); } }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 7 ) ; root . left . left . left = newNode ( 8 ) ; root . left . left . right = newNode ( 9 ) ; root . left . right . left = newNode ( 3 ) ; root . left . right . right = newNode ( 1 ) ; root . right . left . left = newNode ( 4 ) ; root . right . left . right = newNode ( 2 ) ; root . right . right . left = newNode ( 7 ) ; root . right . right . right = newNode ( 2 ) ; root . left . right . left . left = newNode ( 16 ) ; root . left . right . left . right = newNode ( 17 ) ; root . right . left . right . left = newNode ( 18 ) ; root . right . right . left . right = newNode ( 19 ) ; modifiedLevelOrder ( root ) ; } }
static int find ( int parent [ ] , int i ) { if ( parent [ i ] == - 1 ) return i ; return find ( parent , parent [ i ] ) ; }
static void Union ( int parent [ ] , int x , int y ) { int xset = find ( parent , x ) ; int yset = find ( parent , y ) ; parent [ xset ] = yset ; }
import java . util . * ; class GFG { static final int LEFT = 0 ; static final int RIGHT = 1 ; static int ChangeDirection ( int Dir ) { Dir = 1 - Dir ; return Dir ; }
static class node { int data ; node left , right ; } ;
static node newNode ( int data ) { node temp = new node ( ) ; temp . data = data ; temp . left = temp . right = null ; return temp ; }
static void modifiedLevelOrder ( node root ) { if ( root == null ) return ; int dir = LEFT ; node temp ; Queue < node > Q = new LinkedList < > ( ) ; Stack < node > S = new Stack < > ( ) ; S . add ( root ) ;
while ( ! Q . isEmpty ( ) || ! S . isEmpty ( ) ) { while ( ! S . isEmpty ( ) ) { temp = S . peek ( ) ; S . pop ( ) ; System . out . print ( temp . data + " ▁ " ) ; if ( dir == LEFT ) { if ( temp . left != null ) Q . add ( temp . left ) ; if ( temp . right != null ) Q . add ( temp . right ) ; }
else { if ( temp . right != null ) Q . add ( temp . right ) ; if ( temp . left != null ) Q . add ( temp . left ) ; } } System . out . println ( ) ;
while ( ! Q . isEmpty ( ) ) { temp = Q . peek ( ) ; Q . remove ( ) ; System . out . print ( temp . data + " ▁ " ) ; if ( dir == LEFT ) { if ( temp . left != null ) S . add ( temp . left ) ; if ( temp . right != null ) S . add ( temp . right ) ; } else { if ( temp . right != null ) S . add ( temp . right ) ; if ( temp . left != null ) S . add ( temp . left ) ; } } System . out . println ( ) ;
dir = ChangeDirection ( dir ) ; } }
node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 7 ) ; root . left . left . left = newNode ( 8 ) ; root . left . left . right = newNode ( 9 ) ; root . left . right . left = newNode ( 3 ) ; root . left . right . right = newNode ( 1 ) ; root . right . left . left = newNode ( 4 ) ; root . right . left . right = newNode ( 2 ) ; root . right . right . left = newNode ( 7 ) ; root . right . right . right = newNode ( 2 ) ; root . left . right . left . left = newNode ( 16 ) ; root . left . right . left . right = newNode ( 17 ) ; root . right . left . right . left = newNode ( 18 ) ; root . right . right . left . right = newNode ( 19 ) ; modifiedLevelOrder ( root ) ; } }
static int minnode ( int n , int keyval [ ] , boolean mstset [ ] ) { int mini = Integer . MAX_VALUE ; int mini_index = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { if ( mstset [ i ] == false && keyval [ i ] < mini ) { mini = keyval [ i ] ; mini_index = i ; } } return mini_index ; }
static void findcost ( int n , int city [ ] [ ] ) {
int parent [ ] = new int [ n ] ;
int keyval [ ] = new int [ n ] ;
boolean mstset [ ] = new boolean [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) { keyval [ i ] = Integer . MAX_VALUE ; mstset [ i ] = false ; }
parent [ 0 ] = - 1 ; keyval [ 0 ] = 0 ;
for ( int i = 0 ; i < n - 1 ; i ++ ) {
int u = minnode ( n , keyval , mstset ) ;
mstset [ u ] = true ;
for ( int v = 0 ; v < n ; v ++ ) { if ( city [ u ] [ v ] > 0 && mstset [ v ] == false && city [ u ] [ v ] < keyval [ v ] ) { keyval [ v ] = city [ u ] [ v ] ; parent [ v ] = u ; } } }
int cost = 0 ; for ( int i = 1 ; i < n ; i ++ ) cost += city [ parent [ i ] ] [ i ] ; System . out . println ( cost ) ; }
int n1 = 5 ; int city1 [ ] [ ] = { { 0 , 1 , 2 , 3 , 4 } , { 1 , 0 , 5 , 0 , 7 } , { 2 , 5 , 0 , 6 , 0 } , { 3 , 0 , 6 , 0 , 0 } , { 4 , 7 , 0 , 0 , 0 } } ; findcost ( n1 , city1 ) ;
int n2 = 6 ; int city2 [ ] [ ] = { { 0 , 1 , 1 , 100 , 0 , 0 } , { 1 , 0 , 1 , 0 , 0 , 0 } , { 1 , 1 , 0 , 0 , 0 , 0 } , { 100 , 0 , 0 , 0 , 2 , 2 } , { 0 , 0 , 0 , 2 , 0 , 2 } , { 0 , 0 , 0 , 2 , 2 , 0 } } ; findcost ( n2 , city2 ) ; } }
class KnightTour { static int N = 8 ;
static boolean isSafe ( int x , int y , int sol [ ] [ ] ) { return ( x >= 0 && x < N && y >= 0 && y < N && sol [ x ] [ y ] == - 1 ) ; }
static void printSolution ( int sol [ ] [ ] ) { for ( int x = 0 ; x < N ; x ++ ) { for ( int y = 0 ; y < N ; y ++ ) System . out . print ( sol [ x ] [ y ] + " ▁ " ) ; System . out . println ( ) ; } }
static boolean solveKT ( ) { int sol [ ] [ ] = new int [ 8 ] [ 8 ] ;
for ( int x = 0 ; x < N ; x ++ ) for ( int y = 0 ; y < N ; y ++ ) sol [ x ] [ y ] = - 1 ;
int xMove [ ] = { 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 } ; int yMove [ ] = { 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 } ;
sol [ 0 ] [ 0 ] = 0 ;
if ( ! solveKTUtil ( 0 , 0 , 1 , sol , xMove , yMove ) ) { System . out . println ( " Solution ▁ does ▁ not ▁ exist " ) ; return false ; } else printSolution ( sol ) ; return true ; }
static boolean solveKTUtil ( int x , int y , int movei , int sol [ ] [ ] , int xMove [ ] , int yMove [ ] ) { int k , next_x , next_y ; if ( movei == N * N ) return true ;
for ( k = 0 ; k < 8 ; k ++ ) { next_x = x + xMove [ k ] ; next_y = y + yMove [ k ] ; if ( isSafe ( next_x , next_y , sol ) ) { sol [ next_x ] [ next_y ] = movei ; if ( solveKTUtil ( next_x , next_y , movei + 1 , sol , xMove , yMove ) ) return true ; else
sol [ next_x ] [ next_y ] = - 1 ; } } return false ; }
solveKT ( ) ; } }
static int V = 4 ;
static void printSolution ( int [ ] color ) { System . out . println ( " Solution ▁ Exists : " + " ▁ Following ▁ are ▁ the ▁ assigned ▁ colors ▁ " ) ; for ( int i = 0 ; i < V ; i ++ ) System . out . print ( " ▁ " + color [ i ] ) ; System . out . println ( ) ; }
static boolean isSafe ( boolean [ ] [ ] graph , int [ ] color ) {
for ( int i = 0 ; i < V ; i ++ ) for ( int j = i + 1 ; j < V ; j ++ ) if ( graph [ i ] [ j ] && color [ j ] == color [ i ] ) return false ; return true ; }
static boolean graphColoring ( boolean [ ] [ ] graph , int m , int i , int [ ] color ) {
if ( i == V ) {
if ( isSafe ( graph , color ) ) {
printSolution ( color ) ; return true ; } return false ; }
for ( int j = 1 ; j <= m ; j ++ ) { color [ i ] = j ;
if ( graphColoring ( graph , m , i + 1 , color ) ) return true ; color [ i ] = 0 ; } return false ; }
boolean [ ] [ ] graph = { { false , true , true , true } , { true , false , true , false } , { true , true , false , true } , { true , false , true , false } , } ;
int m = 3 ;
int [ ] color = new int [ V ] ; for ( int i = 0 ; i < V ; i ++ ) color [ i ] = 0 ; if ( ! graphColoring ( graph , m , 0 , color ) ) System . out . println ( " Solution ▁ does ▁ not ▁ exist " ) ; } }
static int shortestChainLen ( String start , String target , Set < String > D ) { if ( start == target ) return 0 ;
if ( ! D . contains ( target ) ) return 0 ;
int level = 0 , wordlength = start . length ( ) ;
Queue < String > Q = new LinkedList < > ( ) ; Q . add ( start ) ;
while ( ! Q . isEmpty ( ) ) {
++ level ;
int sizeofQ = Q . size ( ) ;
for ( int i = 0 ; i < sizeofQ ; ++ i ) {
char [ ] word = Q . peek ( ) . toCharArray ( ) ; Q . remove ( ) ;
for ( int pos = 0 ; pos < wordlength ; ++ pos ) {
char orig_char = word [ pos ] ;
for ( char c = ' a ' ; c <= ' z ' ; ++ c ) { word [ pos ] = c ;
if ( String . valueOf ( word ) . equals ( target ) ) return level + 1 ;
if ( ! D . contains ( String . valueOf ( word ) ) ) continue ; D . remove ( String . valueOf ( word ) ) ;
Q . add ( String . valueOf ( word ) ) ; }
word [ pos ] = orig_char ; } } } return 0 ; }
Set < String > D = new HashSet < String > ( ) ; D . add ( " poon " ) ; D . add ( " plee " ) ; D . add ( " same " ) ; D . add ( " poie " ) ; D . add ( " plie " ) ; D . add ( " poin " ) ; D . add ( " plea " ) ; String start = " toon " ; String target = " plea " ; System . out . print ( " Length ▁ of ▁ shortest ▁ chain ▁ is : ▁ " + shortestChainLen ( start , target , D ) ) ; } }
class shortest_path { static int INF = Integer . MAX_VALUE , N = 4 ;
static int minCost ( int cost [ ] [ ] ) {
int dist [ ] = new int [ N ] ; for ( int i = 0 ; i < N ; i ++ ) dist [ i ] = INF ; dist [ 0 ] = 0 ;
for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( dist [ j ] > dist [ i ] + cost [ i ] [ j ] ) dist [ j ] = dist [ i ] + cost [ i ] [ j ] ; return dist [ N - 1 ] ; }
public static void main ( String args [ ] ) { int cost [ ] [ ] = { { 0 , 15 , 80 , 90 } , { INF , 0 , 40 , 50 } , { INF , INF , 0 , 70 } , { INF , INF , INF , 0 } } ; System . out . println ( " The ▁ Minimum ▁ cost ▁ to ▁ reach ▁ station ▁ " + N + " ▁ is ▁ " + minCost ( cost ) ) ; } }
static int numOfways ( int n , int k ) { int p = 1 ; if ( k % 2 != 0 ) p = - 1 ; return ( int ) ( Math . pow ( n - 1 , k ) + p * ( n - 1 ) ) / n ; }
public static void main ( String args [ ] ) { int n = 4 , k = 2 ; System . out . println ( numOfways ( n , k ) ) ; } }
if ( inMST [ v ] == false && key [ v ] > weight ) {
key [ v ] = weight ; pq . add ( new Pair < Integer , Integer > ( key [ v ] , v ) ) ; parent [ v ] = u ; }
import java . util . * ; class GFG { static int maxindex ( int [ ] dist , int n ) { int mi = 0 ; for ( int i = 0 ; i < n ; i ++ ) { if ( dist [ i ] > dist [ mi ] ) mi = i ; } return mi ; } static void selectKcities ( int n , int weights [ ] [ ] , int k ) { int [ ] dist = new int [ n ] ; ArrayList < Integer > centers = new ArrayList < > ( ) ; for ( int i = 0 ; i < n ; i ++ ) { dist [ i ] = Integer . MAX_VALUE ; }
int max = 0 ; for ( int i = 0 ; i < k ; i ++ ) { centers . add ( max ) ; for ( int j = 0 ; j < n ; j ++ ) {
dist [ j ] = Math . min ( dist [ j ] , weights [ max ] [ j ] ) ; }
max = maxindex ( dist , n ) ; }
System . out . println ( dist [ max ] ) ;
for ( int i = 0 ; i < centers . size ( ) ; i ++ ) { System . out . print ( centers . get ( i ) + " ▁ " ) ; } System . out . print ( "NEW_LINE"); }
public static void main ( String [ ] args ) { int n = 4 ; int [ ] [ ] weights = new int [ ] [ ] { { 0 , 4 , 8 , 5 } , { 4 , 0 , 10 , 7 } , { 8 , 10 , 0 , 9 } , { 5 , 7 , 9 , 0 } } ; int k = 2 ;
selectKcities ( n , weights , k ) ; } }
int V = 4 ;
void multiply ( int A [ ] [ ] , int B [ ] [ ] , int C [ ] [ ] ) { for ( int i = 0 ; i < V ; i ++ ) { for ( int j = 0 ; j < V ; j ++ ) { C [ i ] [ j ] = 0 ; for ( int k = 0 ; k < V ; k ++ ) { C [ i ] [ j ] += A [ i ] [ k ] * B [ k ] [ j ] ; } } } }
int getTrace ( int graph [ ] [ ] ) { int trace = 0 ; for ( int i = 0 ; i < V ; i ++ ) { trace += graph [ i ] [ i ] ; } return trace ; }
int triangleInGraph ( int graph [ ] [ ] ) {
int [ ] [ ] aux2 = new int [ V ] [ V ] ;
int [ ] [ ] aux3 = new int [ V ] [ V ] ;
for ( int i = 0 ; i < V ; ++ i ) { for ( int j = 0 ; j < V ; ++ j ) { aux2 [ i ] [ j ] = aux3 [ i ] [ j ] = 0 ; } }
multiply ( graph , graph , aux2 ) ;
multiply ( graph , aux2 , aux3 ) ; int trace = getTrace ( aux3 ) ; return trace / 6 ; }
public static void main ( String args [ ] ) { Directed obj = new Directed ( ) ; int graph [ ] [ ] = { { 0 , 1 , 1 , 0 } , { 1 , 0 , 1 , 1 } , { 1 , 1 , 0 , 1 } , { 0 , 1 , 1 , 0 } } ; System . out . println ( " Total ▁ number ▁ of ▁ Triangle ▁ in ▁ Graph ▁ : ▁ " + obj . triangleInGraph ( graph ) ) ; } }
static int power ( int n ) { if ( n == 1 ) return 2 ; return 2 * power ( n - 1 ) ; }
public static void main ( String [ ] args ) { int n = 4 ; System . out . println ( power ( n ) ) ; } }
static int size = 4 ;
static boolean checkStar ( int mat [ ] [ ] ) {
int vertexD1 = 0 , vertexDn_1 = 0 ;
if ( size == 1 ) return ( mat [ 0 ] [ 0 ] == 0 ) ;
if ( size == 2 ) return ( mat [ 0 ] [ 0 ] == 0 && mat [ 0 ] [ 1 ] == 1 && mat [ 1 ] [ 0 ] == 1 && mat [ 1 ] [ 1 ] == 0 ) ;
for ( int i = 0 ; i < size ; i ++ ) { int degreeI = 0 ; for ( int j = 0 ; j < size ; j ++ ) if ( mat [ i ] [ j ] == 1 ) degreeI ++ ; if ( degreeI == 1 ) vertexD1 ++ ; else if ( degreeI == size - 1 ) vertexDn_1 ++ ; } return ( vertexD1 == ( size - 1 ) && vertexDn_1 == 1 ) ; }
public static void main ( String args [ ] ) { int mat [ ] [ ] = { { 0 , 1 , 1 , 1 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } , { 1 , 0 , 0 , 0 } } ; if ( checkStar ( mat ) ) System . out . print ( " Star ▁ Graph " ) ; else System . out . print ( " Not ▁ a ▁ Star ▁ Graph " ) ; } }
static int fib ( int n ) { if ( n <= 1 ) return n ; return fib ( n - 1 ) + fib ( n - 2 ) ; }
static int findVertices ( int n ) {
return fib ( n + 2 ) ; } public static void main ( String args [ ] ) {
int n = 3 ; System . out . println ( findVertices ( n ) ) ; } }
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public void insertAfter ( Node prev_node , int new_data ) {
if ( prev_node == null ) { System . out . println ( " The ▁ given ▁ previous ▁ node ▁ cannot ▁ be ▁ null " ) ; return ; }
Node new_node = new Node ( new_data ) ;
new_node . next = prev_node . next ;
prev_node . next = new_node ; }
class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } }
Node head ;
public void push ( int new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
public int getCountRec ( Node node ) {
if ( node == null ) return 0 ;
return 1 + getCountRec ( node . next ) ; }
public int getCount ( ) { return getCountRec ( head ) ; }
LinkedList llist = new LinkedList ( ) ; llist . push ( 1 ) ; llist . push ( 3 ) ; llist . push ( 1 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; System . out . println ( " Count ▁ of ▁ nodes ▁ is ▁ " + llist . getCount ( ) ) ; } }
int count ( Node head , int key ) { if ( head == null ) return 0 ; if ( head . data == key ) return 1 + count ( head . next , key ) ; return count ( head . next , key ) ; }
class Node { char data ; Node next ; Node ( char d ) { data = d ; next = null ; } }
Node head ; Node slow_ptr , fast_ptr , second_half ;
boolean isPalindrome ( Node head ) { slow_ptr = head ; fast_ptr = head ; Node prev_of_slow_ptr = head ;
Node midnode = null ;
boolean res = true ; if ( head != null && head . next != null ) {
while ( fast_ptr != null && fast_ptr . next != null ) { fast_ptr = fast_ptr . next . next ;
prev_of_slow_ptr = slow_ptr ; slow_ptr = slow_ptr . next ; }
if ( fast_ptr != null ) { midnode = slow_ptr ; slow_ptr = slow_ptr . next ; }
second_half = slow_ptr ;
prev_of_slow_ptr . next = null ;
reverse ( ) ;
res = compareLists ( head , second_half ) ;
reverse ( ) ; if ( midnode != null ) {
prev_of_slow_ptr . next = midnode ; midnode . next = second_half ; } else prev_of_slow_ptr . next = second_half ; } return res ; }
void reverse ( ) { Node prev = null ; Node current = second_half ; Node next ; while ( current != null ) { next = current . next ; current . next = prev ; prev = current ; current = next ; } second_half = prev ; }
boolean compareLists ( Node head1 , Node head2 ) { Node temp1 = head1 ; Node temp2 = head2 ; while ( temp1 != null && temp2 != null ) { if ( temp1 . data == temp2 . data ) { temp1 = temp1 . next ; temp2 = temp2 . next ; } else return false ; }
if ( temp1 == null && temp2 == null ) return true ;
return false ; }
public void push ( char new_data ) {
Node new_node = new Node ( new_data ) ;
new_node . next = head ;
head = new_node ; }
void printList ( Node ptr ) { while ( ptr != null ) { System . out . print ( ptr . data + " - > " ) ; ptr = ptr . next ; } System . out . println ( " NULL " ) ; }
LinkedList llist = new LinkedList ( ) ; char str [ ] = { ' a ' , ' b ' , ' a ' , ' c ' , ' a ' , ' b ' , ' a ' } ; String string = new String ( str ) ; for ( int i = 0 ; i < 7 ; i ++ ) { llist . push ( str [ i ] ) ; llist . printList ( llist . head ) ; if ( llist . isPalindrome ( llist . head ) != false ) { System . out . println ( " Is ▁ Palindrome " ) ; System . out . println ( " " ) ; } else { System . out . println ( " Not ▁ Palindrome " ) ; System . out . println ( " " ) ; } } } }
class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } } class LinkedList {
Node head ;
public void swapNodes ( int x , int y ) {
if ( x == y ) return ;
Node prevX = null , currX = head ; while ( currX != null && currX . data != x ) { prevX = currX ; currX = currX . next ; }
Node prevY = null , currY = head ; while ( currY != null && currY . data != y ) { prevY = currY ; currY = currY . next ; }
if ( currX == null currY == null ) return ;
if ( prevX != null ) prevX . next = currY ;
else head = currY ;
if ( prevY != null ) prevY . next = currX ;
else head = currX ;
Node temp = currX . next ; currX . next = currY . next ; currY . next = temp ; }
public void push ( int new_data ) {
Node new_Node = new Node ( new_data ) ;
new_Node . next = head ;
head = new_Node ; }
public void printList ( ) { Node tNode = head ; while ( tNode != null ) { System . out . print ( tNode . data + " ▁ " ) ; tNode = tNode . next ; } }
llist . push ( 7 ) ; llist . push ( 6 ) ; llist . push ( 5 ) ; llist . push ( 4 ) ; llist . push ( 3 ) ; llist . push ( 2 ) ; llist . push ( 1 ) ; System . out . print ( " Linked list before calling swapNodes ( ) "); llist . printList ( ) ; llist . swapNodes ( 4 , 3 ) ; System . out . print ( " Linked list after calling swapNodes ( ) "); llist . printList ( ) ; } }
static class Node { int data ; Node next ; }
static boolean isCircular ( Node head ) {
if ( head == null ) return true ;
Node node = head . next ;
while ( node != null && node != head ) node = node . next ;
return ( node == head ) ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . next = null ; return temp ; }
Node head = newNode ( 1 ) ; head . next = newNode ( 2 ) ; head . next . next = newNode ( 3 ) ; head . next . next . next = newNode ( 4 ) ; System . out . print ( isCircular ( head ) ? "Yes " ▁ : ▁ " No " );
head . next . next . next . next = head ; System . out . print ( isCircular ( head ) ? "Yes " ▁ : ▁ " No " ); } }
static Node addToEmpty ( Node last , int data ) {
if ( last != null ) return last ;
Node temp = ( Node * ) malloc ( sizeof ( Node ) ) ;
temp . data = data ; last = temp ;
temp . next = last ; return last ; }
static Node addBegin ( Node last , int data ) { if ( last == null ) return addToEmpty ( last , data ) ;
Node temp = new Node ( ) ;
temp . data = data ;
temp . next = last . next ; last . next = temp ; return last ; }
static class Node { public int data ; public Node next ; public Node ( int data ) { this . data = data ; } }
static void getJosephusPosition ( int m , int n ) {
Node head = new Node ( 1 ) ; Node prev = head ; for ( int i = 2 ; i <= n ; i ++ ) { prev . next = new Node ( i ) ; prev = prev . next ; }
prev . next = head ;
Node ptr1 = head , ptr2 = head ; while ( ptr1 . next != ptr1 ) {
int count = 1 ; while ( count != m ) { ptr2 = ptr1 ; ptr1 = ptr1 . next ; count ++ ; }
ptr2 . next = ptr1 . next ; ptr1 = ptr2 . next ; } System . out . println ( " Last ▁ person ▁ left ▁ standing ▁ " + " ( Josephus ▁ Position ) ▁ is ▁ " + ptr1 . data ) ; }
public static void main ( String args [ ] ) { int n = 14 , m = 2 ; getJosephusPosition ( m , n ) ; } }
class Node { int data ; Node next ; Node ( int d ) { data = d ; next = null ; } } class LinkedList { Node head ;
void push ( int new_data ) { Node new_node = new Node ( new_data ) ; new_node . next = head ; head = new_node ; }
void printList ( ) { Node node = head ; while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . next ; } System . out . println ( " " ) ; }
int countNodes ( ) { int count = 0 ; Node s = head ; while ( s != null ) { count ++ ; s = s . next ; } return count ; }
void swapKth ( int k ) {
int n = countNodes ( ) ;
if ( n < k ) return ;
if ( 2 * k - 1 == n ) return ;
Node x = head ; Node x_prev = null ; for ( int i = 1 ; i < k ; i ++ ) { x_prev = x ; x = x . next ; }
Node y = head ; Node y_prev = null ; for ( int i = 1 ; i < n - k + 1 ; i ++ ) { y_prev = y ; y = y . next ; }
if ( x_prev != null ) x_prev . next = y ;
if ( y_prev != null ) y_prev . next = x ;
Node temp = x . next ; x . next = y . next ; y . next = temp ;
if ( k == 1 ) head = y ; if ( k == n ) head = x ; }
public static void main ( String [ ] args ) { LinkedList llist = new LinkedList ( ) ; for ( int i = 8 ; i >= 1 ; i -- ) llist . push ( i ) ; System . out . print ( " Original ▁ linked ▁ list : ▁ " ) ; llist . printList ( ) ; System . out . println ( " " ) ; for ( int i = 1 ; i < 9 ; i ++ ) { llist . swapKth ( i ) ; System . out . println ( " Modified ▁ List ▁ for ▁ k ▁ = ▁ " + i ) ; llist . printList ( ) ; System . out . println ( " " ) ; } } }
static class Node { int data ; Node next , prev ; } ;
static int countPairs ( Node first , Node second , int value ) { int count = 0 ;
while ( first != null && second != null && first != second && second . next != first ) {
if ( ( first . data + second . data ) == value ) {
count ++ ;
first = first . next ;
second = second . prev ; }
else if ( ( first . data + second . data ) > value ) second = second . prev ;
else first = first . next ; }
return count ; }
static int countTriplets ( Node head , int x ) {
if ( head == null ) return 0 ; Node current , first , last ; int count = 0 ;
last = head ; while ( last . next != null ) last = last . next ;
for ( current = head ; current != null ; current = current . next ) {
first = current . next ;
count += countPairs ( first , last , x - current . data ) ; }
return count ; }
static Node insert ( Node head , int data ) {
Node temp = new Node ( ) ;
temp . data = data ; temp . next = temp . prev = null ; if ( ( head ) == null ) ( head ) = temp ; else { temp . next = head ; ( head ) . prev = temp ; ( head ) = temp ; } return head ; }
Node head = null ;
head = insert ( head , 9 ) ; head = insert ( head , 8 ) ; head = insert ( head , 6 ) ; head = insert ( head , 5 ) ; head = insert ( head , 4 ) ; head = insert ( head , 2 ) ; head = insert ( head , 1 ) ; int x = 17 ; System . out . print ( " Count ▁ = ▁ " + countTriplets ( head , x ) ) ; } }
class GFG {
static Node deleteNode ( Node head_ref , Node del ) {
if ( head_ref == null del == null ) return head_ref ;
if ( head_ref == del ) head_ref = del . next ;
if ( del . next != null ) del . next . prev = del . prev ;
if ( del . prev != null ) del . prev . next = del . next ; return head_ref ; }
static Node removeDuplicates ( Node head_ref ) {
if ( ( head_ref ) == null || ( head_ref ) . next == null ) return head_ref ; ; Node ptr1 , ptr2 ;
for ( ptr1 = head_ref ; ptr1 != null ; ptr1 = ptr1 . next ) { ptr2 = ptr1 . next ;
while ( ptr2 != null ) {
if ( ptr1 . data == ptr2 . data ) {
Node next = ptr2 . next ;
head_ref = deleteNode ( head_ref , ptr2 ) ;
ptr2 = next ; }
else ptr2 = ptr2 . next ; } } return head_ref ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . prev = null ;
new_node . next = ( head_ref ) ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
static void printList ( Node head ) {
if ( head == null ) System . out . print ( " Doubly ▁ Linked ▁ list ▁ empty " ) ; while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; head = head . next ; } }
public static void main ( String args [ ] ) { Node head = null ;
head = push ( head , 12 ) ; head = push ( head , 12 ) ; head = push ( head , 10 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 4 ) ; head = push ( head , 6 ) ; head = push ( head , 4 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; System . out . print ( "Original Doubly linked list:NEW_LINE"); printList ( head ) ;
head = removeDuplicates ( head ) ; System . out . print ( " Doubly linked list after " ▁ + ▁ " removing duplicates : "); printList ( head ) ; } }
import java . util . * ; class GFG {
static class Node { int data ; Node next ; Node prev ; } ;
static Node deleteNode ( Node head_ref , Node del ) {
if ( head_ref == null del == null ) return null ;
if ( head_ref == del ) head_ref = del . next ;
if ( del . next != null ) del . next . prev = del . prev ;
if ( del . prev != null ) del . prev . next = del . next ; return head_ref ; }
static Node removeDuplicates ( Node head_ref ) {
if ( ( head_ref ) == null ) return null ;
HashSet < Integer > us = new HashSet < > ( ) ; Node current = head_ref , next ;
while ( current != null ) {
if ( us . contains ( current . data ) ) {
next = current . next ;
head_ref = deleteNode ( head_ref , current ) ;
current = next ; } else {
us . add ( current . data ) ;
current = current . next ; } } return head_ref ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . prev = null ;
new_node . next = ( head_ref ) ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
static void printList ( Node head ) {
if ( head == null ) System . out . print ( " Doubly ▁ Linked ▁ list ▁ empty " ) ; while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; head = head . next ; } }
public static void main ( String [ ] args ) { Node head = null ;
head = push ( head , 12 ) ; head = push ( head , 12 ) ; head = push ( head , 10 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; head = push ( head , 4 ) ; head = push ( head , 6 ) ; head = push ( head , 4 ) ; head = push ( head , 4 ) ; head = push ( head , 8 ) ; System . out . println ( " Original ▁ Doubly ▁ linked ▁ list : " ) ; printList ( head ) ;
head = removeDuplicates ( head ) ; System . out . println ( " Doubly linked list after " ▁ + ▁ " removing duplicates : "); printList ( head ) ; } }
static class Node { int data ; Node next ; Node prev ; }
static Node reverse ( Node head_ref ) { Node temp = null ; Node current = head_ref ;
while ( current != null ) { temp = current . prev ; current . prev = current . next ; current . next = temp ; current = current . prev ; }
if ( temp != null ) head_ref = temp . prev ; return head_ref ; }
static Node merge ( Node first , Node second ) {
if ( first == null ) return second ;
if ( second == null ) return first ;
if ( first . data < second . data ) { first . next = merge ( first . next , second ) ; first . next . prev = first ; first . prev = null ; return first ; } else { second . next = merge ( first , second . next ) ; second . next . prev = second ; second . prev = null ; return second ; } }
static Node sort ( Node head ) {
if ( head == null head . next == null ) return head ; Node current = head . next ; while ( current != null ) {
if ( current . data < current . prev . data ) break ;
current = current . next ; }
if ( current == null ) return head ;
current . prev . next = null ; current . prev = null ;
current = reverse ( current ) ;
return merge ( head , current ) ; }
static Node push ( Node head_ref , int new_data ) {
Node new_node = new Node ( ) ;
new_node . data = new_data ;
new_node . prev = null ;
new_node . next = ( head_ref ) ;
if ( ( head_ref ) != null ) ( head_ref ) . prev = new_node ;
( head_ref ) = new_node ; return head_ref ; }
static void printList ( Node head ) {
if ( head == null ) System . out . println ( " Doubly ▁ Linked ▁ list ▁ empty " ) ; while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; head = head . next ; } }
public static void main ( String args [ ] ) { Node head = null ;
head = push ( head , 1 ) ; head = push ( head , 4 ) ; head = push ( head , 6 ) ; head = push ( head , 10 ) ; head = push ( head , 12 ) ; head = push ( head , 7 ) ; head = push ( head , 5 ) ; head = push ( head , 2 ) ; System . out . println ( " Original ▁ Doubly ▁ linked ▁ list : n " ) ; printList ( head ) ;
head = sort ( head ) ; System . out . println ( " Doubly linked list after sorting : n "); printList ( head ) ; } }
class Node { int info ; Node prev , next ; } class GFG { static Node head , tail ;
static void nodeInsetail ( int key ) { Node p = new Node ( ) ; p . info = key ; p . next = null ;
if ( head == null ) { head = p ; tail = p ; head . prev = null ; return ; }
if ( p . info < head . info ) { p . prev = null ; head . prev = p ; p . next = head ; head = p ; return ; }
if ( p . info > tail . info ) { p . prev = tail ; tail . next = p ; tail = p ; return ; }
Node temp = head . next ; while ( temp . info < p . info ) temp = temp . next ;
( temp . prev ) . next = p ; p . prev = temp . prev ; temp . prev = p ; p . next = temp ; }
static void printList ( Node temp ) { while ( temp != null ) { System . out . print ( temp . info + " ▁ " ) ; temp = temp . next ; } }
public static void main ( String args [ ] ) { head = tail = null ; nodeInsetail ( 30 ) ; nodeInsetail ( 50 ) ; nodeInsetail ( 90 ) ; nodeInsetail ( 10 ) ; nodeInsetail ( 40 ) ; nodeInsetail ( 110 ) ; nodeInsetail ( 60 ) ; nodeInsetail ( 95 ) ; nodeInsetail ( 23 ) ; System . out . println ( " Doubly ▁ linked ▁ list ▁ on ▁ printing ▁ from ▁ left ▁ to ▁ right " ) ; printList ( head ) ; } }
static void insertEnd ( int value ) {
if ( start == null ) { Node new_node = new Node ( ) ; new_node . data = value ; new_node . next = new_node . prev = new_node ; start = new_node ; return ; }
Node last = ( start ) . prev ;
Node new_node = new Node ( ) ; new_node . data = value ;
new_node . next = start ;
( start ) . prev = new_node ;
new_node . prev = last ;
last . next = new_node ; }
static class Node { int data ; Node next ; } ;
static int findDepthRec ( String tree , int n , int index ) { if ( index >= n || tree . charAt ( index ) == ' l ' ) return 0 ;
index ++ ; int left = findDepthRec ( tree , n , index ) ;
index ++ ; int right = findDepthRec ( tree , n , index ) ; return Math . max ( left , right ) + 1 ; }
static int findDepth ( String tree , int n ) { int index = 0 ; return ( findDepthRec ( tree , n , index ) ) ; }
static public void main ( String [ ] args ) { String tree = " nlnnlll " ; int n = tree . length ( ) ; System . out . println ( findDepth ( tree , n ) ) ; } }
static class Node { char data ; Node next ; }
static Node newNode ( char key ) { Node temp = new Node ( ) ; temp . data = key ; temp . next = null ; return temp ; }
static void printlist ( Node head ) { if ( head == null ) { System . out . println ( " Empty ▁ List " ) ; return ; } while ( head != null ) { System . out . print ( head . data + " ▁ " ) ; if ( head . next != null ) System . out . print ( " - > ▁ " ) ; head = head . next ; } System . out . println ( ) ; }
static boolean isVowel ( char x ) { return ( x == ' a ' x == ' e ' x == ' i ' x == ' o ' x == ' u ' ) ; }
static Node arrange ( Node head ) { Node newHead = head ;
Node latestVowel ; Node curr = head ;
if ( head == null ) return null ;
if ( isVowel ( head . data ) == true )
latestVowel = head ; else {
while ( curr . next != null && ! isVowel ( curr . next . data ) ) curr = curr . next ;
if ( curr . next == null ) return head ;
latestVowel = newHead = curr . next ; curr . next = curr . next . next ; latestVowel . next = head ; }
while ( curr != null && curr . next != null ) { if ( isVowel ( curr . next . data ) == true ) {
if ( curr == latestVowel ) {
latestVowel = curr = curr . next ; } else {
Node temp = latestVowel . next ;
latestVowel . next = curr . next ;
latestVowel = latestVowel . next ;
curr . next = curr . next . next ;
latestVowel . next = temp ; } } else {
curr = curr . next ; } } return newHead ; }
public static void main ( String [ ] args ) { Node head = newNode ( ' a ' ) ; head . next = newNode ( ' b ' ) ; head . next . next = newNode ( ' c ' ) ; head . next . next . next = newNode ( ' e ' ) ; head . next . next . next . next = newNode ( ' d ' ) ; head . next . next . next . next . next = newNode ( ' o ' ) ; head . next . next . next . next . next . next = newNode ( ' x ' ) ; head . next . next . next . next . next . next . next = newNode ( ' i ' ) ; System . out . println ( " Linked ▁ list ▁ before ▁ : ▁ " ) ; printlist ( head ) ; head = arrange ( head ) ; System . out . println ( " Linked ▁ list ▁ after ▁ : " ) ; printlist ( head ) ; } }
class Node { int data ; Node left , right ; Node ( int x ) { data = x ; left = right = null ; } } class GFG { static int count = 0 ;
public static Node insert ( Node root , int x ) { if ( root == null ) return new Node ( x ) ; if ( x < root . data ) root . left = insert ( root . left , x ) ; else if ( x > root . data ) root . right = insert ( root . right , x ) ; return root ; }
public static Node kthSmallest ( Node root , int k ) {
if ( root == null ) return null ;
Node left = kthSmallest ( root . left , k ) ;
if ( left != null ) return left ;
count ++ ; if ( count == k ) return root ;
return kthSmallest ( root . right , k ) ; }
public static void printKthSmallest ( Node root , int k ) {
count = 0 ; Node res = kthSmallest ( root , k ) ; if ( res == null ) System . out . println ( " There ▁ are ▁ less ▁ " + " than ▁ k ▁ nodes ▁ in ▁ the ▁ BST " ) ; else System . out . println ( " K - th ▁ Smallest " + " ▁ Element ▁ is ▁ " + res . data ) ; }
public static void main ( String [ ] args ) { Node root = null ; int keys [ ] = { 20 , 8 , 22 , 4 , 12 , 10 , 14 } ; for ( int x : keys ) root = insert ( root , x ) ; int k = 3 ; printKthSmallest ( root , k ) ; } }
import java . util . * ; public class TreeNode { int val ; TreeNode left ; TreeNode right ; TreeNode ( int x ) { val = x ; } } class BinaryTree { static Set < TreeNode > set = new HashSet < > ( ) ; static Stack < TreeNode > stack = new Stack < > ( ) ;
public TreeNode buildTree ( int [ ] preorder , int [ ] inorder ) { TreeNode root = null ; for ( int pre = 0 , in = 0 ; pre < preorder . length ; ) { TreeNode node = null ; do { node = new TreeNode ( preorder [ pre ] ) ; if ( root == null ) { root = node ; } if ( ! stack . isEmpty ( ) ) { if ( set . contains ( stack . peek ( ) ) ) { set . remove ( stack . peek ( ) ) ; stack . pop ( ) . right = node ; } else { stack . peek ( ) . left = node ; } } stack . push ( node ) ; } while ( preorder [ pre ++ ] != inorder [ in ] && pre < preorder . length ) ; node = null ; while ( ! stack . isEmpty ( ) && in < inorder . length && stack . peek ( ) . val == inorder [ in ] ) { node = stack . pop ( ) ; in ++ ; } if ( node != null ) { set . add ( node ) ; stack . push ( node ) ; } } return root ; }
void printInorder ( TreeNode node ) { if ( node == null ) return ;
printInorder ( node . left ) ;
System . out . print ( node . val + " ▁ " ) ;
printInorder ( node . right ) ; }
public static void main ( String args [ ] ) { BinaryTree tree = new BinaryTree ( ) ; int in [ ] = new int [ ] { 9 , 8 , 4 , 2 , 10 , 5 , 10 , 1 , 6 , 3 , 13 , 12 , 7 } ; int pre [ ] = new int [ ] { 1 , 2 , 4 , 8 , 9 , 5 , 10 , 10 , 3 , 6 , 7 , 12 , 13 } ; int len = in . length ; TreeNode root = tree . buildTree ( pre , in ) ; tree . printInorder ( root ) ; } }
static class Node { int data ; Node left , right ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . right = null ; temp . left = null ; return temp ; } static Node KthLargestUsingMorrisTraversal ( Node root , int k ) { Node curr = root ; Node Klargest = null ;
int count = 0 ; while ( curr != null ) {
if ( curr . right == null ) {
if ( ++ count == k ) Klargest = curr ;
curr = curr . left ; } else {
Node succ = curr . right ; while ( succ . left != null && succ . left != curr ) succ = succ . left ; if ( succ . left == null ) {
succ . left = curr ;
curr = curr . right ; }
else { succ . left = null ; if ( ++ count == k ) Klargest = curr ;
curr = curr . left ; } } } return Klargest ; }
Node root = newNode ( 4 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 7 ) ; root . left . left = newNode ( 1 ) ; root . left . right = newNode ( 3 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 10 ) ; System . out . println ( " Finding ▁ K - th ▁ largest ▁ Node ▁ in ▁ BST ▁ : ▁ " + KthLargestUsingMorrisTraversal ( root , 2 ) . data ) ; } }
static class Node { int key ; Node left , right ; }
static int KSmallestUsingMorris ( Node root , int k ) {
int count = 0 ;
int ksmall = Integer . MIN_VALUE ;
Node curr = root ; while ( curr != null ) {
if ( curr . left == null ) { count ++ ;
if ( count == k ) ksmall = curr . key ;
curr = curr . right ; } else {
Node pre = curr . left ; while ( pre . right != null && pre . right != curr ) pre = pre . right ;
if ( pre . right == null ) {
pre . right = curr ; curr = curr . left ; }
else {
pre . right = null ; count ++ ;
if ( count == k ) ksmall = curr . key ; curr = curr . right ; } } }
return ksmall ; }
static Node newNode ( int item ) { Node temp = new Node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; return temp ; }
static Node insert ( Node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else if ( key > node . key ) node . right = insert ( node . right , key ) ;
return node ; }
Node root = null ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ; for ( int k = 1 ; k <= 7 ; k ++ ) System . out . print ( KSmallestUsingMorris ( root , k ) + " ▁ " ) ; } }
static boolean isInorder ( int [ ] arr , int n ) {
if ( n == 0 n == 1 ) { return true ; }
for ( int i = 1 ; i < n ; i ++ ) { if ( arr [ i - 1 ] > arr [ i ] ) { return false ; } }
return true ; }
public static void main ( String [ ] args ) { int arr [ ] = { 19 , 23 , 25 , 30 , 45 } ; int n = arr . length ; if ( isInorder ( arr , n ) ) { System . out . println ( " Yes " ) ; } else { System . out . println ( " Non " ) ; } } }
static class Node { int data ; Node left ; Node right ; } ;
static Node newNode ( int val ) { Node temp = new Node ( ) ; temp . data = val ; temp . left = temp . right = null ; return temp ; }
static void storeInorder ( Node root , Vector < Integer > v ) { if ( root == null ) return ; storeInorder ( root . left , v ) ; v . add ( root . data ) ; storeInorder ( root . right , v ) ; }
static boolean checkBSTs ( Node root1 , Node root2 ) {
if ( root1 != null && root2 != null ) return true ; if ( ( root1 == null && root2 != null ) || ( root1 != null && root2 == null ) ) return false ;
Vector < Integer > v1 = new Vector < Integer > ( ) ; Vector < Integer > v2 = new Vector < Integer > ( ) ; storeInorder ( root1 , v1 ) ; storeInorder ( root2 , v2 ) ;
return ( v1 == v2 ) ; }
Node root1 = newNode ( 15 ) ; root1 . left = newNode ( 10 ) ; root1 . right = newNode ( 20 ) ; root1 . left . left = newNode ( 5 ) ; root1 . left . right = newNode ( 12 ) ; root1 . right . right = newNode ( 25 ) ;
Node root2 = newNode ( 15 ) ; root2 . left = newNode ( 12 ) ; root2 . right = newNode ( 20 ) ; root2 . left . left = newNode ( 5 ) ; root2 . left . left . right = newNode ( 10 ) ; root2 . right . right = newNode ( 25 ) ;
if ( checkBSTs ( root1 , root2 ) ) System . out . print ( " YES " ) ; else System . out . print ( " NO " ) ; } }
static class Node { int key ; Node left , right ; }
static Node newNode ( int item ) { Node temp = new Node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; return temp ; }
static Node insert ( Node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else if ( key > node . key ) node . right = insert ( node . right , key ) ;
return node ; }
static int findMaxforN ( Node root , int N ) {
if ( root == null ) return - 1 ; if ( root . key == N ) return N ;
else if ( root . key < N ) { int k = findMaxforN ( root . right , N ) ; if ( k == - 1 ) return root . key ; else return k ; }
else if ( root . key > N ) return findMaxforN ( root . left , N ) ; return - 1 ; }
public static void main ( String [ ] args ) { int N = 4 ;
Node root = null ; root = insert ( root , 25 ) ; insert ( root , 2 ) ; insert ( root , 1 ) ; insert ( root , 3 ) ; insert ( root , 12 ) ; insert ( root , 9 ) ; insert ( root , 21 ) ; insert ( root , 19 ) ; insert ( root , 25 ) ; System . out . println ( findMaxforN ( root , N ) ) ; } }
class GfG { static class Node { Node left , right ; int key ; } static Node newNode ( int key ) { Node ptr = new Node ( ) ; ptr . key = key ; ptr . left = null ; ptr . right = null ; return ptr ; }
static Node insert ( Node root , int key ) { if ( root == null ) root = newNode ( key ) ; else if ( root . key > key ) root . left = insert ( root . left , key ) ; else if ( root . key < key ) root . right = insert ( root . right , key ) ; return root ; }
static int distanceFromRoot ( Node root , int x ) { if ( root . key == x ) return 0 ; else if ( root . key > x ) return 1 + distanceFromRoot ( root . left , x ) ; return 1 + distanceFromRoot ( root . right , x ) ; }
static int distanceBetween2 ( Node root , int a , int b ) { if ( root == null ) return 0 ;
if ( root . key > a && root . key > b ) return distanceBetween2 ( root . left , a , b ) ;
if ( root . key < a && root . key < b ) return distanceBetween2 ( root . right , a , b ) ;
if ( root . key >= a && root . key <= b ) return distanceFromRoot ( root , a ) + distanceFromRoot ( root , b ) ; return 0 ; }
static int findDistWrapper ( Node root , int a , int b ) { int temp = 0 ; if ( a > b ) { temp = a ; a = b ; b = temp ; } return distanceBetween2 ( root , a , b ) ; }
public static void main ( String [ ] args ) { Node root = null ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; System . out . println ( findDistWrapper ( root , 5 , 35 ) ) ; } }
class GfG { static class node { int data ; node left , right ; }
static void RangeTraversal ( node root , int n1 , int n2 ) { if ( root == null ) return ; node curr = root ; while ( curr != null ) { if ( curr . left == null ) {
if ( curr . data <= n2 && curr . data >= n1 ) { System . out . print ( curr . data + " ▁ " ) ; } curr = curr . right ; } else { node pre = curr . left ;
while ( pre . right != null && pre . right != curr ) pre = pre . right ; if ( pre . right == null ) { pre . right = curr ; curr = curr . left ; } else { pre . right = null ;
if ( curr . data <= n2 && curr . data >= n1 ) { System . out . print ( curr . data + " ▁ " ) ; } curr = curr . right ; } } } }
static node newNode ( int data ) { node temp = new node ( ) ; temp . data = data ; temp . right = null ; temp . left = null ; return temp ; }
node root = newNode ( 4 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 7 ) ; root . left . left = newNode ( 1 ) ; root . left . right = newNode ( 3 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 10 ) ; RangeTraversal ( root , 4 , 12 ) ; } }
static class node { int data ; node left , right ; } ;
static class INT { int a ; }
static boolean inRange ( node root , int low , int high ) { return root . data >= low && root . data <= high ; }
static boolean getCountUtil ( node root , int low , int high , INT count ) {
if ( root == null ) return true ;
boolean l = getCountUtil ( root . left , low , high , count ) ; boolean r = getCountUtil ( root . right , low , high , count ) ;
if ( l && r && inRange ( root , low , high ) ) { ++ count . a ; return true ; } return false ; }
static INT getCount ( node root , int low , int high ) { INT count = new INT ( ) ; count . a = 0 ; getCountUtil ( root , low , high , count ) ; return count ; }
static node newNode ( int data ) { node temp = new node ( ) ; temp . data = data ; temp . left = temp . right = null ; return ( temp ) ; }
node root = newNode ( 10 ) ; root . left = newNode ( 5 ) ; root . right = newNode ( 50 ) ; root . left . left = newNode ( 1 ) ; root . right . left = newNode ( 40 ) ; root . right . right = newNode ( 100 ) ;
int l = 5 ; int h = 45 ; System . out . println ( " Count ▁ of ▁ subtrees ▁ in ▁ [ " + l + " , ▁ " + h + " ] ▁ is ▁ " + getCount ( root , l , h ) . a ) ; } }
class GfG { static class Node { int data ; Node left ; Node right ; }
static Node newNode ( int data ) { Node temp = new Node ( ) ; temp . data = data ; temp . left = null ; temp . right = null ; return temp ; }
static Node insert ( Node root , int data ) { if ( root == null ) return newNode ( data ) ; if ( data < root . data ) root . left = insert ( root . left , data ) ; else if ( data > root . data ) root . right = insert ( root . right , data ) ; return root ; }
static void inorder ( Node root ) { if ( root != null ) { inorder ( root . left ) ; System . out . print ( root . data + " ▁ " ) ; inorder ( root . right ) ; } }
static Node leafDelete ( Node root ) { if ( root == null ) { return null ; } if ( root . left == null && root . right == null ) { return null ; }
root . left = leafDelete ( root . left ) ; root . right = leafDelete ( root . right ) ; return root ; }
public static void main ( String [ ] args ) { Node root = null ; root = insert ( root , 20 ) ; insert ( root , 10 ) ; insert ( root , 5 ) ; insert ( root , 15 ) ; insert ( root , 30 ) ; insert ( root , 25 ) ; insert ( root , 35 ) ; System . out . println ( " Inorder ▁ before ▁ Deleting ▁ the ▁ leaf ▁ Node . ▁ " ) ; inorder ( root ) ; System . out . println ( ) ; leafDelete ( root ) ; System . out . println ( " INorder ▁ after ▁ Deleting ▁ the ▁ leaf ▁ Node . ▁ " ) ; inorder ( root ) ; } }
static class Node { int data ; Node left , right ; } ;
static Node createNode ( int data ) { Node new_Node = new Node ( ) ; new_Node . left = null ; new_Node . right = null ; new_Node . data = data ; return new_Node ; }
static Node insert ( Node root , int key ) {
if ( root == null ) return createNode ( key ) ;
if ( root . data > key ) root . left = insert ( root . left , key ) ; else if ( root . data < key ) root . right = insert ( root . right , key ) ;
return root ; } static int count = 0 ;
static int ksmallestElementSumRec ( Node root , int k ) {
if ( root == null ) return 0 ; if ( count > k ) return 0 ;
int res = ksmallestElementSumRec ( root . left , k ) ; if ( count >= k ) return res ;
res += root . data ;
count ++ ; if ( count >= k ) return res ;
return res + ksmallestElementSumRec ( root . right , k ) ; }
static int ksmallestElementSum ( Node root , int k ) { int res = ksmallestElementSumRec ( root , k ) ; return res ; }
Node root = null ; root = insert ( root , 20 ) ; root = insert ( root , 8 ) ; root = insert ( root , 4 ) ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 14 ) ; root = insert ( root , 22 ) ; int k = 3 ; int count = ksmallestElementSum ( root , k ) ; System . out . println ( count ) ; } }
class Node { int data ; Node left , right , parent ; Node ( int d ) { data = d ; left = right = parent = null ; } } class BinaryTree { static Node head ;
Node insert ( Node node , int data ) {
if ( node == null ) { return ( new Node ( data ) ) ; } else { Node temp = null ;
if ( data <= node . data ) { temp = insert ( node . left , data ) ; node . left = temp ; temp . parent = node ; } else { temp = insert ( node . right , data ) ; node . right = temp ; temp . parent = node ; }
return node ; } } Node inOrderSuccessor ( Node root , Node n ) {
if ( n . right != null ) { return minValue ( n . right ) ; }
Node p = n . parent ; while ( p != null && n == p . right ) { n = p ; p = p . parent ; } return p ; }
Node minValue ( Node node ) { Node current = node ;
while ( current . left != null ) { current = current . left ; } return current ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; Node root = null , temp = null , suc = null , min = null ; root = tree . insert ( root , 20 ) ; root = tree . insert ( root , 8 ) ; root = tree . insert ( root , 22 ) ; root = tree . insert ( root , 4 ) ; root = tree . insert ( root , 12 ) ; root = tree . insert ( root , 10 ) ; root = tree . insert ( root , 14 ) ; temp = root . left . right . right ; suc = tree . inOrderSuccessor ( root , temp ) ; if ( suc != null ) { System . out . println ( " Inorder ▁ successor ▁ of ▁ " + temp . data + " ▁ is ▁ " + suc . data ) ; } else { System . out . println ( " Inorder ▁ successor ▁ does ▁ not ▁ exist " ) ; } } }
static class Node { int key ; Node left , right ; } ; static Node pre ; static Node suc ;
static void findPreSuc ( Node root , int key ) { if ( root == null ) return ;
while ( root != null ) {
if ( root . key == key ) {
if ( root . right != null ) { suc = root . right ; while ( suc . left != null ) suc = suc . left ; }
if ( root . left != null ) { pre = root . left ; while ( pre . right != null ) pre = pre . right ; } return ; }
else if ( root . key < key ) { pre = root ; root = root . right ; }
else { suc = root ; root = root . left ; } } }
static Node newNode ( int item ) { Node temp = new Node ( ) ; temp . key = item ; temp . left = temp . right = null ; return temp ; }
static Node insert ( Node node , int key ) { if ( node == null ) return newNode ( key ) ; if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ; return node ; }
int key = 65 ;
Node root = null ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ; findPreSuc ( root , key ) ; if ( pre != null ) System . out . println ( " Predecessor ▁ is ▁ " + pre . key ) ; else System . out . print ( " - 1" ) ; if ( suc != null ) System . out . print ( " Successor ▁ is ▁ " + suc . key ) ; else System . out . print ( " - 1" ) ; } }
static class node { int key ; node left ; node right ; } ; static node head ; static node tail ;
static void convertBSTtoDLL ( node root ) {
if ( root == null ) return ;
if ( root . left != null ) convertBSTtoDLL ( root . left ) ;
root . left = tail ;
if ( tail != null ) ( tail ) . right = root ; else head = root ;
tail = root ;
if ( root . right != null ) convertBSTtoDLL ( root . right ) ; }
static boolean isPresentInDLL ( node head , node tail , int sum ) { while ( head != tail ) { int curr = head . key + tail . key ; if ( curr == sum ) return true ; else if ( curr > sum ) tail = tail . left ; else head = head . right ; } return false ; }
static boolean isTripletPresent ( node root ) {
if ( root == null ) return false ;
head = null ; tail = null ; convertBSTtoDLL ( root ) ;
while ( ( head . right != tail ) && ( head . key < 0 ) ) {
if ( isPresentInDLL ( head . right , tail , - 1 * head . key ) ) return true ; else head = head . right ; }
return false ; }
static node newNode ( int num ) { node temp = new node ( ) ; temp . key = num ; temp . left = temp . right = null ; return temp ; }
static node insert ( node root , int key ) { if ( root == null ) return newNode ( key ) ; if ( root . key > key ) root . left = insert ( root . left , key ) ; else root . right = insert ( root . right , key ) ; return root ; }
public static void main ( String [ ] args ) { node root = null ; root = insert ( root , 6 ) ; root = insert ( root , - 13 ) ; root = insert ( root , 14 ) ; root = insert ( root , - 8 ) ; root = insert ( root , 15 ) ; root = insert ( root , 13 ) ; root = insert ( root , 7 ) ; if ( isTripletPresent ( root ) ) System . out . print ( " Present " ) ; else System . out . print ( " Not ▁ Present " ) ; } }
class Solution { static class Node { Node left , right ; int data ; }
static Node createNode ( int x ) { Node p = new Node ( ) ; p . data = x ; p . left = p . right = null ; return p ; }
static void insertNode ( Node root , int x ) { Node p = root , q = null ; while ( p != null ) { q = p ; if ( p . data < x ) p = p . right ; else p = p . left ; } if ( q == null ) p = createNode ( x ) ; else { if ( q . data < x ) q . right = createNode ( x ) ; else q . left = createNode ( x ) ; } }
static int maxelpath ( Node q , int x ) { Node p = q ; int mx = - 1 ;
while ( p . data != x ) { if ( p . data > x ) { mx = Math . max ( mx , p . data ) ; p = p . left ; } else { mx = Math . max ( mx , p . data ) ; p = p . right ; } } return Math . max ( mx , x ) ; }
static int maximumElement ( Node root , int x , int y ) { Node p = root ;
while ( ( x < p . data && y < p . data ) || ( x > p . data && y > p . data ) ) {
if ( x < p . data && y < p . data ) p = p . left ;
else if ( x > p . data && y > p . data ) p = p . right ; }
return Math . max ( maxelpath ( p , x ) , maxelpath ( p , y ) ) ; }
public static void main ( String args [ ] ) { int arr [ ] = { 18 , 36 , 9 , 6 , 12 , 10 , 1 , 8 } ; int a = 1 , b = 10 ; int n = arr . length ;
Node root = createNode ( arr [ 0 ] ) ;
for ( int i = 1 ; i < n ; i ++ ) insertNode ( root , arr [ i ] ) ; System . out . println ( maximumElement ( root , a , b ) ) ; } }
static class Node { int data ; Node left , right ; boolean rightThread ; }
import java . util . * ; class solution { static class Node { Node left , right ; int info ;
boolean lthread ;
boolean rthread ; } ;
static Node insert ( Node root , int ikey ) {
Node ptr = root ;
Node par = null ; while ( ptr != null ) {
if ( ikey == ( ptr . info ) ) { System . out . printf ( "Duplicate Key !NEW_LINE"); return root ; }
par = ptr ;
if ( ikey < ptr . info ) { if ( ptr . lthread == false ) ptr = ptr . left ; else break ; }
else { if ( ptr . rthread == false ) ptr = ptr . right ; else break ; } }
Node tmp = new Node ( ) ; tmp . info = ikey ; tmp . lthread = true ; tmp . rthread = true ; if ( par == null ) { root = tmp ; tmp . left = null ; tmp . right = null ; } else if ( ikey < ( par . info ) ) { tmp . left = par . left ; tmp . right = par ; par . lthread = false ; par . left = tmp ; } else { tmp . left = par ; tmp . right = par . right ; par . rthread = false ; par . right = tmp ; } return root ; }
static Node inorderSuccessor ( Node ptr ) {
if ( ptr . rthread == true ) return ptr . right ;
ptr = ptr . right ; while ( ptr . lthread == false ) ptr = ptr . left ; return ptr ; }
static void inorder ( Node root ) { if ( root == null ) System . out . printf ( " Tree ▁ is ▁ empty " ) ;
Node ptr = root ; while ( ptr . lthread == false ) ptr = ptr . left ;
while ( ptr != null ) { System . out . printf ( " % d ▁ " , ptr . info ) ; ptr = inorderSuccessor ( ptr ) ; } }
public static void main ( String [ ] args ) { Node root = null ; root = insert ( root , 20 ) ; root = insert ( root , 10 ) ; root = insert ( root , 30 ) ; root = insert ( root , 5 ) ; root = insert ( root , 16 ) ; root = insert ( root , 14 ) ; root = insert ( root , 17 ) ; root = insert ( root , 13 ) ; inorder ( root ) ; } }
static class Node { Node left , right ; int info ;
boolean lthread ;
boolean rthread ; } ;
static class Node { int key ; Node left , right ;
boolean isThreaded ; } ;
static Node createThreaded ( Node root ) {
if ( root == null ) return null ; if ( root . left == null && root . right == null ) return root ;
if ( root . left != null ) {
Node l = createThreaded ( root . left ) ;
l . right = root ; l . isThreaded = true ; }
if ( root . right == null ) return root ;
return createThreaded ( root . right ) ; }
static Node leftMost ( Node root ) { while ( root != null && root . left != null ) root = root . left ; return root ; }
static void inOrder ( Node root ) { if ( root == null ) return ;
Node cur = leftMost ( root ) ; while ( cur != null ) { System . out . print ( cur . key + " ▁ " ) ;
if ( cur . isThreaded ) cur = cur . right ;
else cur = leftMost ( cur . right ) ; } }
static Node newNode ( int key ) { Node temp = new Node ( ) ; temp . left = temp . right = null ; temp . key = key ; return temp ; }
Node root = newNode ( 1 ) ; root . left = newNode ( 2 ) ; root . right = newNode ( 3 ) ; root . left . left = newNode ( 4 ) ; root . left . right = newNode ( 5 ) ; root . right . left = newNode ( 6 ) ; root . right . right = newNode ( 7 ) ; createThreaded ( root ) ; System . out . println ( " Inorder ▁ traversal ▁ of ▁ created ▁ " + "threaded tree isNEW_LINE"); inOrder ( root ) ; } }
class Node { int key ; Node left , right , parent ; public Node ( int key ) { this . key = key ; left = right = parent = null ; } } class BinaryTree { Node root ;
Node insert ( Node node , int key ) {
if ( node == null ) return new Node ( key ) ;
if ( key < node . key ) { node . left = insert ( node . left , key ) ; node . left . parent = node ; } else if ( key > node . key ) { node . right = insert ( node . right , key ) ; node . right . parent = node ; }
return node ; }
void inorder ( Node root ) { boolean leftdone = false ;
while ( root != null ) {
if ( ! leftdone ) { while ( root . left != null ) { root = root . left ; } }
System . out . print ( root . key + " ▁ " ) ;
leftdone = true ;
if ( root . right != null ) { leftdone = false ; root = root . right ; }
else if ( root . parent != null ) {
while ( root . parent != null && root == root . parent . right ) root = root . parent ; if ( root . parent == null ) break ; root = root . parent ; } else break ; } }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = tree . insert ( tree . root , 24 ) ; tree . root = tree . insert ( tree . root , 27 ) ; tree . root = tree . insert ( tree . root , 29 ) ; tree . root = tree . insert ( tree . root , 34 ) ; tree . root = tree . insert ( tree . root , 14 ) ; tree . root = tree . insert ( tree . root , 4 ) ; tree . root = tree . insert ( tree . root , 10 ) ; tree . root = tree . insert ( tree . root , 22 ) ; tree . root = tree . insert ( tree . root , 13 ) ; tree . root = tree . insert ( tree . root , 3 ) ; tree . root = tree . insert ( tree . root , 2 ) ; tree . root = tree . insert ( tree . root , 6 ) ; System . out . println ( " Inorder ▁ traversal ▁ is ▁ " ) ; tree . inorder ( tree . root ) ; } }
class Node { int data ; Node left , right ; Node ( int d ) { data = d ; left = right = null ; } } class BinaryTree { Node root ;
int Ceil ( Node node , int input ) {
if ( node == null ) { return - 1 ; }
if ( node . data == input ) { return node . data ; }
if ( node . data < input ) { return Ceil ( node . right , input ) ; }
int ceil = Ceil ( node . left , input ) ; return ( ceil >= input ) ? ceil : node . data ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 8 ) ; tree . root . left = new Node ( 4 ) ; tree . root . right = new Node ( 12 ) ; tree . root . left . left = new Node ( 2 ) ; tree . root . left . right = new Node ( 6 ) ; tree . root . right . left = new Node ( 10 ) ; tree . root . right . right = new Node ( 14 ) ; for ( int i = 0 ; i < 16 ; i ++ ) { System . out . println ( i + " ▁ " + tree . Ceil ( tree . root , i ) ) ; } } }
class GFG { static class node { int key ; int count ; node left , right ; } ;
static node newNode ( int item ) { node temp = new node ( ) ; temp . key = item ; temp . left = temp . right = null ; temp . count = 1 ; return temp ; }
static void inorder ( node root ) { if ( root != null ) { inorder ( root . left ) ; System . out . print ( root . key + " ( " + root . count + " ) ▁ " ) ; inorder ( root . right ) ; } }
static node insert ( node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key == node . key ) { ( node . count ) ++ ; return node ; }
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
return node ; }
static node minValueNode ( node node ) { node current = node ;
while ( current . left != null ) current = current . left ; return current ; }
static node deleteNode ( node root , int key ) {
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . count > 1 ) { ( root . count ) -- ; return root ; }
if ( root . left == null ) { node temp = root . right ; root = null ; return temp ; } else if ( root . right == null ) { node temp = root . left ; root = null ; return temp ; }
node temp = minValueNode ( root . right ) ;
root . key = temp . key ;
root . right = deleteNode ( root . right , temp . key ) ; } return root ; }
node root = null ; root = insert ( root , 12 ) ; root = insert ( root , 10 ) ; root = insert ( root , 20 ) ; root = insert ( root , 9 ) ; root = insert ( root , 11 ) ; root = insert ( root , 10 ) ; root = insert ( root , 12 ) ; root = insert ( root , 12 ) ; System . out . print ( " Inorder ▁ traversal ▁ of ▁ " + " the ▁ given ▁ tree ▁ " + "NEW_LINE"); inorder ( root ) ; System . out . print ( " Delete 20 "); root = deleteNode ( root , 20 ) ; System . out . print ( " Inorder ▁ traversal ▁ of ▁ " + "the modified tree NEW_LINE"); inorder ( root ) ; System . out . print ( " Delete 12 "); root = deleteNode ( root , 12 ) ; System . out . print ( " Inorder ▁ traversal ▁ of ▁ " + "the modified tree NEW_LINE"); inorder ( root ) ; System . out . print ( " Delete 9 "); root = deleteNode ( root , 9 ) ; System . out . print ( " Inorder ▁ traversal ▁ of ▁ " + "the modified tree NEW_LINE"); inorder ( root ) ; } }
class GfG { static class node { int key ; node left , right ; } static node root = null ;
static node newNode ( int item ) { node temp = new node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; return temp ; }
static void inorder ( node root ) { if ( root != null ) { inorder ( root . left ) ; System . out . print ( root . key + " ▁ " ) ; inorder ( root . right ) ; } }
static node insert ( node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) node . left = insert ( node . left , key ) ; else node . right = insert ( node . right , key ) ;
return node ; }
static node minValueNode ( node Node ) { node current = Node ;
while ( current . left != null ) current = current . left ; return current ; }
static node deleteNode ( node root , int key ) {
if ( root == null ) return root ;
if ( key < root . key ) root . left = deleteNode ( root . left , key ) ;
else if ( key > root . key ) root . right = deleteNode ( root . right , key ) ;
else {
if ( root . left == null ) { node temp = root . right ; return temp ; } else if ( root . right == null ) { node temp = root . left ; return temp ; }
node temp = minValueNode ( root . right ) ;
root . key = temp . key ;
root . right = deleteNode ( root . right , temp . key ) ; } return root ; }
static node changeKey ( node root , int oldVal , int newVal ) {
root = deleteNode ( root , oldVal ) ;
root = insert ( root , newVal ) ;
return root ; }
root = insert ( root , 50 ) ; root = insert ( root , 30 ) ; root = insert ( root , 20 ) ; root = insert ( root , 40 ) ; root = insert ( root , 70 ) ; root = insert ( root , 60 ) ; root = insert ( root , 80 ) ; System . out . println ( " Inorder ▁ traversal ▁ of ▁ the ▁ given ▁ tree " ) ; inorder ( root ) ; root = changeKey ( root , 40 , 10 ) ;
System . out . println ( " Inorder traversal of the modified tree "); inorder ( root ) ; } }
class GFG { static int i = 0 ;
static boolean isLeaf ( int pre [ ] , int n , int min , int max ) { if ( i >= n ) { return false ; } if ( pre [ i ] > min && pre [ i ] < max ) { i ++ ; boolean left = isLeaf ( pre , n , min , pre [ i - 1 ] ) ; boolean right = isLeaf ( pre , n , pre [ i - 1 ] , max ) ; if ( ! left && ! right ) { System . out . print ( pre [ i - 1 ] + " ▁ " ) ; } return true ; } return false ; } static void printLeaves ( int preorder [ ] , int n ) { isLeaf ( preorder , n , Integer . MIN_VALUE , Integer . MAX_VALUE ) ; }
public static void main ( String [ ] args ) { int preorder [ ] = { 890 , 325 , 290 , 530 , 965 } ; int n = preorder . length ; printLeaves ( preorder , n ) ; } }
static class Node { int key ; Node left , right , parent ; }
static Node newNode ( int item ) { Node temp = new Node ( ) ; temp . key = item ; temp . left = null ; temp . right = null ; temp . parent = null ; return temp ; }
static void inorder ( Node root ) { if ( root != null ) { inorder ( root . left ) ; System . out . print ( " Node ▁ : ▁ " + root . key + " ▁ , ▁ " ) ; if ( root . parent == null ) System . out . println ( " Parent ▁ : ▁ NULL " ) ; else System . out . println ( " Parent ▁ : ▁ " + root . parent . key ) ; inorder ( root . right ) ; } }
static Node insert ( Node node , int key ) {
if ( node == null ) return newNode ( key ) ;
if ( key < node . key ) { Node lchild = insert ( node . left , key ) ; node . left = lchild ;
lchild . parent = node ; } else if ( key > node . key ) { Node rchild = insert ( node . right , key ) ; node . right = rchild ;
rchild . parent = node ; }
return node ; }
Node root = null ; root = insert ( root , 50 ) ; insert ( root , 30 ) ; insert ( root , 20 ) ; insert ( root , 40 ) ; insert ( root , 70 ) ; insert ( root , 60 ) ; insert ( root , 80 ) ;
inorder ( root ) ; } }
static void pairs ( int arr [ ] , int n , int k ) {
int smallest = Integer . MAX_VALUE ; int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
if ( Math . abs ( arr [ i ] + arr [ j ] - k ) < smallest ) { smallest = Math . abs ( arr [ i ] + arr [ j ] - k ) ; count = 1 ; }
else if ( Math . abs ( arr [ i ] + arr [ j ] - k ) == smallest ) count ++ ; }
System . out . println ( " Minimal ▁ Value ▁ = ▁ " + smallest ) ; System . out . println ( " Total ▁ Pairs ▁ = ▁ " + count ) ; }
public static void main ( String [ ] args ) { int arr [ ] = { 3 , 5 , 7 , 5 , 1 , 9 , 9 } ; int k = 12 ; int n = arr . length ; pairs ( arr , n , k ) ; } }
public static void main ( String [ ] args ) { int a [ ] = { 5 , 1 , 14 , 4 , 15 , 9 , 7 , 20 , 11 } ; int key = 20 ; int arraySize = a . length ; int count = 0 ; for ( int i = 0 ; i < arraySize ; i ++ ) { if ( a [ i ] <= key ) { count += 1 ; } } System . out . println ( " Rank ▁ of ▁ " + key + " ▁ in ▁ stream ▁ is : ▁ " + ( count - 1 ) ) ; } }
class Node { int info ; Node left , right ; Node ( int d ) { info = d ; left = right = null ; } } class BinaryTree { static Node head ; static int count ;
Node insert ( Node node , int info ) {
if ( node == null ) { return ( new Node ( info ) ) ; } else {
if ( info <= node . info ) { node . left = insert ( node . left , info ) ; } else { node . right = insert ( node . right , info ) ; }
return node ; } }
static int check ( int num ) { int sum = 0 , i = num , sum_of_digits , prod_of_digits ;
if ( num < 10 num > 99 ) return 0 ; else { sum_of_digits = ( i % 10 ) + ( i / 10 ) ; prod_of_digits = ( i % 10 ) * ( i / 10 ) ; sum = sum_of_digits + prod_of_digits ; } if ( sum == num ) return 1 ; else return 0 ; }
static void countSpecialDigit ( Node rt ) { int x ; if ( rt == null ) return ; else { x = check ( rt . info ) ; if ( x == 1 ) count = count + 1 ; countSpecialDigit ( rt . left ) ; countSpecialDigit ( rt . right ) ; } }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; Node root = null ; root = tree . insert ( root , 50 ) ; tree . insert ( root , 29 ) ; tree . insert ( root , 59 ) ; tree . insert ( root , 19 ) ; tree . insert ( root , 53 ) ; tree . insert ( root , 556 ) ; tree . insert ( root , 56 ) ; tree . insert ( root , 94 ) ; tree . insert ( root , 13 ) ;
countSpecialDigit ( root ) ; System . out . println ( count ) ; } }
import java . util . Arrays ; import java . util . Collections ; class GFG { static int MAX_SIZE = 10 ;
static void sortByRow ( Integer mat [ ] [ ] , int n , boolean ascending ) { for ( int i = 0 ; i < n ; i ++ ) { if ( ascending ) Arrays . sort ( mat [ i ] ) ; else Arrays . sort ( mat [ i ] , Collections . reverseOrder ( ) ) ; } }
static void transpose ( Integer mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
int temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ j ] [ i ] ; mat [ j ] [ i ] = temp ; } }
static void sortMatRowAndColWise ( Integer mat [ ] [ ] , int n ) {
sortByRow ( mat , n , true ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n , false ) ;
transpose ( mat , n ) ; }
static void printMat ( Integer mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int n = 3 ; Integer mat [ ] [ ] = { { 3 , 2 , 1 } , { 9 , 8 , 7 } , { 6 , 5 , 4 } } ; System . out . print ( "Original Matrix:NEW_LINE"); printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; System . out . print ( " Matrix After Sorting : "); printMat ( mat , n ) ; } }
import java . io . * ; class GFG { static int MAX = 100 ; static void middlesum ( int mat [ ] [ ] , int n ) { int row_sum = 0 , col_sum = 0 ;
for ( int i = 0 ; i < n ; i ++ ) row_sum += mat [ n / 2 ] [ i ] ; System . out . println ( " Sum ▁ of ▁ middle ▁ row ▁ = ▁ " + row_sum ) ;
for ( int i = 0 ; i < n ; i ++ ) col_sum += mat [ i ] [ n / 2 ] ; System . out . println ( " Sum ▁ of ▁ middle ▁ column ▁ = ▁ " + col_sum ) ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 2 , 5 , 7 } , { 3 , 7 , 2 } , { 5 , 6 , 9 } } ; middlesum ( mat , 3 ) ; } }
static final int M = 3 ; static final int N = 3 ;
static void rotateMatrix ( int matrix [ ] [ ] , int k ) {
int temp [ ] = new int [ M ] ;
k = k % M ; for ( int i = 0 ; i < N ; i ++ ) {
for ( int t = 0 ; t < M - k ; t ++ ) temp [ t ] = matrix [ i ] [ t ] ;
for ( int j = M - k ; j < M ; j ++ ) matrix [ i ] [ j - M + k ] = matrix [ i ] [ j ] ;
for ( int j = k ; j < M ; j ++ ) matrix [ i ] [ j ] = temp [ j - k ] ; } }
static void displayMatrix ( int matrix [ ] [ ] ) { for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < M ; j ++ ) System . out . print ( matrix [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int matrix [ ] [ ] = { { 12 , 23 , 34 } , { 45 , 56 , 67 } , { 78 , 89 , 91 } } ; int k = 2 ;
rotateMatrix ( matrix , k ) ;
displayMatrix ( matrix ) ; } }
import java . io . * ; public class Interchange { static void interchangeFirstLast ( int m [ ] [ ] ) { int rows = m . length ;
for ( int i = 0 ; i < m [ 0 ] . length ; i ++ ) { int t = m [ 0 ] [ i ] ; m [ 0 ] [ i ] = m [ rows - 1 ] [ i ] ; m [ rows - 1 ] [ i ] = t ; } }
int m [ ] [ ] = { { 8 , 9 , 7 , 6 } , { 4 , 7 , 6 , 5 } , { 3 , 2 , 1 , 8 } , { 9 , 9 , 7 , 7 } } ; interchangeFirstLast ( m ) ;
for ( int i = 0 ; i < m . length ; i ++ ) { for ( int j = 0 ; j < m [ 0 ] . length ; j ++ ) System . out . print ( m [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } } }
class Node { int data ; Node left , right ; public Node ( int data ) { this . data = data ; left = right = null ; } } class BinaryTree {
Node buildUtil ( int in [ ] , int post [ ] , int inStrt , int inEnd , int postStrt , int postEnd ) {
if ( inStrt > inEnd ) return null ;
Node node = new Node ( post [ postEnd ] ) ;
if ( inStrt == inEnd ) return node ;
int iIndex = search ( in , inStrt , inEnd , node . data ) ;
node . left = buildUtil ( in , post , inStrt , iIndex - 1 , postStrt , postStrt - inStrt + iIndex - 1 ) ; node . right = buildUtil ( in , post , iIndex + 1 , inEnd , postEnd - inEnd + iIndex , postEnd - 1 ) ; return node ; }
int search ( int arr [ ] , int strt , int end , int value ) { int i ; for ( i = strt ; i <= end ; i ++ ) { if ( arr [ i ] == value ) break ; } return i ; }
void preOrder ( Node node ) { if ( node == null ) return ; System . out . print ( node . data + " ▁ " ) ; preOrder ( node . left ) ; preOrder ( node . right ) ; }
public static void main ( String [ ] args ) { BinaryTree tree = new BinaryTree ( ) ; int in [ ] = new int [ ] { 4 , 8 , 2 , 5 , 1 , 6 , 3 , 7 } ; int post [ ] = new int [ ] { 8 , 4 , 5 , 2 , 6 , 7 , 3 , 1 } ; int n = in . length ; Node root = tree . buildUtil ( in , post , 0 , n - 1 , 0 , n - 1 ) ; System . out . println ( " Preorder ▁ of ▁ the ▁ constructed ▁ tree ▁ : ▁ " ) ; tree . preOrder ( root ) ; } }
import java . io . * ; public class Sort2DMatrix { static int sortRowWise ( int m [ ] [ ] ) {
for ( int i = 0 ; i < m . length ; i ++ ) {
for ( int j = 0 ; j < m [ i ] . length ; j ++ ) {
for ( int k = 0 ; k < m [ i ] . length - j - 1 ; k ++ ) { if ( m [ i ] [ k ] > m [ i ] [ k + 1 ] ) {
int t = m [ i ] [ k ] ; m [ i ] [ k ] = m [ i ] [ k + 1 ] ; m [ i ] [ k + 1 ] = t ; } } } }
for ( int i = 0 ; i < m . length ; i ++ ) { for ( int j = 0 ; j < m [ i ] . length ; j ++ ) System . out . print ( m [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } return 0 ; }
public static void main ( String args [ ] ) { int m [ ] [ ] = { { 9 , 8 , 7 , 1 } , { 7 , 3 , 0 , 2 } , { 9 , 5 , 3 , 2 } , { 6 , 3 , 1 , 2 } } ; sortRowWise ( m ) ; } }
import java . io . * ; public class markov { static boolean checkMarkov ( double m [ ] [ ] ) {
for ( int i = 0 ; i < m . length ; i ++ ) {
double sum = 0 ; for ( int j = 0 ; j < m [ i ] . length ; j ++ ) sum = sum + m [ i ] [ j ] ; if ( sum != 1 ) return false ; } return true ; }
double m [ ] [ ] = { { 0 , 0 , 1 } , { 0.5 , 0 , 0.5 } , { 1 , 0 , 0 } } ;
if ( checkMarkov ( m ) ) System . out . println ( " ▁ yes ▁ " ) ; else System . out . println ( " ▁ no ▁ " ) ; } }
import java . io . * ; class GFG { static int N = 4 ;
static boolean isDiagonalMatrix ( int mat [ ] [ ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ )
if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ; return true ; }
public static void main ( String args [ ] ) { int mat [ ] [ ] = { { 4 , 0 , 0 , 0 } , { 0 , 7 , 0 , 0 } , { 0 , 0 , 5 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isDiagonalMatrix ( mat ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . io . * ; class GFG { static int N = 4 ;
static boolean isScalarMatrix ( int mat [ ] [ ] ) {
for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( ( i != j ) && ( mat [ i ] [ j ] != 0 ) ) return false ;
for ( int i = 0 ; i < N - 1 ; i ++ ) if ( mat [ i ] [ i ] != mat [ i + 1 ] [ i + 1 ] ) return false ; return true ; }
public static void main ( String args [ ] ) { int mat [ ] [ ] = { { 2 , 0 , 0 , 0 } , { 0 , 2 , 0 , 0 } , { 0 , 0 , 2 , 0 } , { 0 , 0 , 0 , 2 } } ;
if ( isScalarMatrix ( mat ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . util . Arrays ; class GFG { static final int MAX_SIZE = 10 ;
static void sortByRow ( int mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ )
Arrays . sort ( mat [ i ] ) ; }
static void transpose ( int mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) for ( int j = i + 1 ; j < n ; j ++ ) {
int temp = mat [ i ] [ j ] ; mat [ i ] [ j ] = mat [ j ] [ i ] ; mat [ j ] [ i ] = temp ; } }
static void sortMatRowAndColWise ( int mat [ ] [ ] , int n ) {
sortByRow ( mat , n ) ;
transpose ( mat , n ) ;
sortByRow ( mat , n ) ;
transpose ( mat , n ) ; }
static void printMat ( int mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 4 , 1 , 3 } , { 9 , 6 , 8 } , { 5 , 2 , 7 } } ; int n = 3 ; System . out . print ( "Original Matrix:NEW_LINE"); printMat ( mat , n ) ; sortMatRowAndColWise ( mat , n ) ; System . out . print ( " Matrix After Sorting : "); printMat ( mat , n ) ; } }
static void doublyEven ( int n ) { int [ ] [ ] arr = new int [ n ] [ n ] ; int i , j ;
for ( i = 0 ; i < n ; i ++ ) for ( j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * i ) + j + 1 ;
for ( i = 0 ; i < n / 4 ; i ++ ) for ( j = 0 ; j < n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < n / 4 ; i ++ ) for ( j = 3 * ( n / 4 ) ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * n / 4 ; i < n ; i ++ ) for ( j = 0 ; j < n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 3 * n / 4 ; i < n ; i ++ ) for ( j = 3 * n / 4 ; j < n ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = n / 4 ; i < 3 * n / 4 ; i ++ ) for ( j = n / 4 ; j < 3 * n / 4 ; j ++ ) arr [ i ] [ j ] = ( n * n + 1 ) - arr [ i ] [ j ] ;
for ( i = 0 ; i < n ; i ++ ) { for ( j = 0 ; j < n ; j ++ ) System . out . print ( arr [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int n = 8 ;
doublyEven ( n ) ; } }
import java . io . * ; class GFG { static int N = 3 ;
static boolean isMagicSquare ( int mat [ ] [ ] ) {
int sum = 0 , sum2 = 0 ; for ( int i = 0 ; i < N ; i ++ ) sum = sum + mat [ i ] [ i ] ;
for ( int i = 0 ; i < N ; i ++ ) sum2 = sum2 + mat [ i ] [ N - 1 - i ] ; if ( sum != sum2 ) return false ;
for ( int i = 0 ; i < N ; i ++ ) { int rowSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) rowSum += mat [ i ] [ j ] ;
if ( rowSum != sum ) return false ; }
for ( int i = 0 ; i < N ; i ++ ) { int colSum = 0 ; for ( int j = 0 ; j < N ; j ++ ) colSum += mat [ j ] [ i ] ;
if ( sum != colSum ) return false ; } return true ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 2 , 7 , 6 } , { 9 , 5 , 1 } , { 4 , 3 , 8 } } ; if ( isMagicSquare ( mat ) ) System . out . println ( " Magic ▁ Square " ) ; else System . out . println ( " Not ▁ a ▁ magic " + " ▁ Square " ) ; } }
import java . util . * ; class GFG { static final int SIZE = 10 ;
static int subCount ( int arr [ ] , int n , int k ) {
int mod [ ] = new int [ k ] ; Arrays . fill ( mod , 0 ) ;
int cumSum = 0 ; for ( int i = 0 ; i < n ; i ++ ) { cumSum += arr [ i ] ;
mod [ ( ( cumSum % k ) + k ) % k ] ++ ; }
int result = 0 ;
for ( int i = 0 ; i < k ; i ++ )
if ( mod [ i ] > 1 ) result += ( mod [ i ] * ( mod [ i ] - 1 ) ) / 2 ;
result += mod [ 0 ] ; return result ; }
static int countSubmatrix ( int mat [ ] [ ] , int n , int k ) {
int tot_count = 0 ; int left , right , i ; int temp [ ] = new int [ n ] ;
for ( left = 0 ; left < n ; left ++ ) {
Arrays . fill ( temp , 0 ) ;
for ( right = left ; right < n ; right ++ ) {
for ( i = 0 ; i < n ; ++ i ) temp [ i ] += mat [ i ] [ right ] ;
tot_count += subCount ( temp , n , k ) ; } }
return tot_count ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 5 , - 1 , 6 } , { - 2 , 3 , 8 } , { 7 , 4 , - 9 } } ; int n = 3 , k = 4 ; System . out . print ( " Count ▁ = ▁ " + countSubmatrix ( mat , n , k ) ) ; } }
static int findMinOpeartion ( int matrix [ ] [ ] , int n ) {
int [ ] sumRow = new int [ n ] ; int [ ] sumCol = new int [ n ] ;
for ( int i = 0 ; i < n ; ++ i ) for ( int j = 0 ; j < n ; ++ j ) { sumRow [ i ] += matrix [ i ] [ j ] ; sumCol [ j ] += matrix [ i ] [ j ] ; }
int maxSum = 0 ; for ( int i = 0 ; i < n ; ++ i ) { maxSum = Math . max ( maxSum , sumRow [ i ] ) ; maxSum = Math . max ( maxSum , sumCol [ i ] ) ; } int count = 0 ; for ( int i = 0 , j = 0 ; i < n && j < n ; ) {
int diff = Math . min ( maxSum - sumRow [ i ] , maxSum - sumCol [ j ] ) ;
matrix [ i ] [ j ] += diff ; sumRow [ i ] += diff ; sumCol [ j ] += diff ;
count += diff ;
if ( sumRow [ i ] == maxSum ) ++ i ;
if ( sumCol [ j ] == maxSum ) ++ j ; } return count ; }
static void printMatrix ( int matrix [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; ++ i ) { for ( int j = 0 ; j < n ; ++ j ) System . out . print ( matrix [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int matrix [ ] [ ] = { { 1 , 2 } , { 3 , 4 } } ; System . out . println ( findMinOpeartion ( matrix , 2 ) ) ; printMatrix ( matrix , 2 ) ; } }
import java . util . * ; import java . lang . * ; public class GfG { public static int find ( int n , int k ) { if ( n + 1 >= k ) return ( k - 1 ) ; else return ( 2 * n + 1 - k ) ; }
public static void main ( String argc [ ] ) { int n = 4 , k = 7 ; int freq = find ( n , k ) ; if ( freq < 0 ) System . out . print ( " ▁ element " + " not exist NEW_LINE "); else System . out . print ( " ▁ Frequency " + " ▁ of ▁ " + k + " ▁ is ▁ " + freq + "NEW_LINE"); } }
public static void ZigZag ( int rows , int columns , int numbers [ ] ) { int k = 0 ;
int [ ] [ ] arr = new int [ rows ] [ columns ] ; for ( int i = 0 ; i < rows ; i ++ ) {
if ( i % 2 == 0 ) {
for ( int j = 0 ; j < columns && numbers [ k ] > 0 ; j ++ ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } }
else {
for ( int j = columns - 1 ; j >= 0 && numbers [ k ] > 0 ; j -- ) {
arr [ i ] [ j ] = k + 1 ;
numbers [ k ] -- ;
if ( numbers [ k ] == 0 ) k ++ ; } } }
for ( int i = 0 ; i < rows ; i ++ ) { for ( int j = 0 ; j < columns ; j ++ ) System . out . print ( arr [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String argc [ ] ) { int rows = 4 ; int columns = 5 ; int [ ] Numbers = new int [ ] { 3 , 4 , 2 , 2 , 3 , 1 , 5 } ; ZigZag ( rows , columns , Numbers ) ; } }
static int numberofPosition ( int n , int k , int x , int y , int obstPosx [ ] , int obstPosy [ ] ) {
int d11 , d12 , d21 , d22 , r1 , r2 , c1 , c2 ;
d11 = Math . min ( x - 1 , y - 1 ) ; d12 = Math . min ( n - x , n - y ) ; d21 = Math . min ( n - x , y - 1 ) ; d22 = Math . min ( x - 1 , n - y ) ; r1 = y - 1 ; r2 = n - y ; c1 = x - 1 ; c2 = n - x ;
for ( int i = 0 ; i < k ; i ++ ) { if ( x > obstPosx [ i ] && y > obstPosy [ i ] && x - obstPosx [ i ] == y - obstPosy [ i ] ) d11 = Math . min ( d11 , x - obstPosx [ i ] - 1 ) ; if ( obstPosx [ i ] > x && obstPosy [ i ] > y && obstPosx [ i ] - x == obstPosy [ i ] - y ) d12 = Math . min ( d12 , obstPosx [ i ] - x - 1 ) ; if ( obstPosx [ i ] > x && y > obstPosy [ i ] && obstPosx [ i ] - x == y - obstPosy [ i ] ) d21 = Math . min ( d21 , obstPosx [ i ] - x - 1 ) ; if ( x > obstPosx [ i ] && obstPosy [ i ] > y && x - obstPosx [ i ] == obstPosy [ i ] - y ) d22 = Math . min ( d22 , x - obstPosx [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] < y ) r1 = Math . min ( r1 , y - obstPosy [ i ] - 1 ) ; if ( x == obstPosx [ i ] && obstPosy [ i ] > y ) r2 = Math . min ( r2 , obstPosy [ i ] - y - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] < x ) c1 = Math . min ( c1 , x - obstPosx [ i ] - 1 ) ; if ( y == obstPosy [ i ] && obstPosx [ i ] > x ) c2 = Math . min ( c2 , obstPosx [ i ] - x - 1 ) ; } return d11 + d12 + d21 + d22 + r1 + r2 + c1 + c2 ; }
int n = 8 ;
int k = 1 ;
int Qposx = 4 ;
int Qposy = 4 ;
int obstPosx [ ] = { 3 } ;
int obstPosy [ ] = { 5 } ; System . out . println ( numberofPosition ( n , k , Qposx , Qposy , obstPosx , obstPosy ) ) ; } }
class GFG { static final int n = 5 ;
static int FindMaxProduct ( int arr [ ] [ ] , int n ) { int max = 0 , result ;
for ( int i = 0 ; i < n ; i ++ ) {
for ( int j = 0 ; j < n ; j ++ ) {
if ( ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i ] [ j - 1 ] * arr [ i ] [ j - 2 ] * arr [ i ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j ] * arr [ i - 2 ] [ j ] * arr [ i - 3 ] [ j ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 3 ) >= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j - 1 ] * arr [ i - 2 ] [ j - 2 ] * arr [ i - 3 ] [ j - 3 ] ; if ( max < result ) max = result ; }
if ( ( i - 3 ) >= 0 && ( j - 1 ) <= 0 ) { result = arr [ i ] [ j ] * arr [ i - 1 ] [ j + 1 ] * arr [ i - 2 ] [ j + 2 ] * arr [ i - 3 ] [ j + 3 ] ; if ( max < result ) max = result ; } } } return max ; }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 1 } , { 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 1 , 0 } , { 9 , 6 , 4 , 2 , 3 } } ; System . out . print ( FindMaxProduct ( arr , n ) ) ; } }
import java . io . * ; class GFG { public static int maxPro ( int [ ] [ ] a , int n , int m , int k ) { int maxi = 1 , mp = 1 ; for ( int i = 0 ; i < n ; ++ i ) {
int wp = 1 ; for ( int l = 0 ; l < k ; ++ l ) { wp *= a [ i ] [ l ] ; }
mp = wp ; for ( int j = k ; j < m ; ++ j ) { wp = wp * a [ i ] [ j ] / a [ i ] [ j - k ] ;
maxi = Math . max ( maxi , Math . max ( mp , wp ) ) ; } } return maxi ; }
public static void main ( String [ ] args ) { int n = 6 , m = 5 , k = 4 ; int [ ] [ ] a = new int [ ] [ ] { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 1 } , { 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 1 , 0 } , { 9 , 6 , 4 , 2 , 3 } , { 1 , 1 , 2 , 1 , 1 } } ;
int maxpro = maxPro ( a , n , m , k ) ; System . out . println ( maxpro ) ; } }
import java . util . * ; class GFG {
static int minimumflip ( int mat [ ] [ ] , int n ) { int transpose [ ] [ ] = new int [ n ] [ n ] ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) transpose [ i ] [ j ] = mat [ j ] [ i ] ;
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) if ( transpose [ i ] [ j ] != mat [ i ] [ j ] ) flip ++ ; return flip / 2 ; }
public static void main ( String [ ] args ) { int n = 3 ; int mat [ ] [ ] = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; System . out . println ( minimumflip ( mat , n ) ) ; } }
static int minimumflip ( int mat [ ] [ ] , int n ) {
int flip = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) flip ++ ; return flip ; }
public static void main ( String [ ] args ) { int n = 3 ; int mat [ ] [ ] = { { 0 , 0 , 1 } , { 1 , 1 , 1 } , { 1 , 0 , 0 } } ; System . out . println ( minimumflip ( mat , n ) ) ; } }
import java . io . * ; class Lower_triangular { int N = 4 ;
boolean isLowerTriangularMatrix ( int mat [ ] [ ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
public static void main ( String args [ ] ) { Lower_triangular ob = new Lower_triangular ( ) ; int mat [ ] [ ] = { { 1 , 0 , 0 , 0 } , { 1 , 4 , 0 , 0 } , { 4 , 6 , 2 , 0 } , { 0 , 4 , 7 , 6 } } ;
if ( ob . isLowerTriangularMatrix ( mat ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . util . * ; import java . lang . * ; public class GfG { private static final int N = 4 ;
public static Boolean isUpperTriangularMatrix ( int mat [ ] [ ] ) { for ( int i = 1 ; i < N ; i ++ ) for ( int j = 0 ; j < i ; j ++ ) if ( mat [ i ] [ j ] != 0 ) return false ; return true ; }
public static void main ( String argc [ ] ) { int [ ] [ ] mat = { { 1 , 3 , 5 , 3 } , { 0 , 4 , 6 , 2 } , { 0 , 0 , 2 , 5 } , { 0 , 0 , 0 , 6 } } ; if ( isUpperTriangularMatrix ( mat ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
class GFG { static final int MAX = 100 ;
static void freq ( int ar [ ] [ ] , int m , int n ) { int even = 0 , odd = 0 ; for ( int i = 0 ; i < m ; ++ i ) { for ( int j = 0 ; j < n ; ++ j ) {
if ( ( ar [ i ] [ j ] % 2 ) == 0 ) ++ even ; else ++ odd ; } }
System . out . print ( " ▁ Frequency ▁ of ▁ odd ▁ number ▁ = " + odd + " NEW_LINE"); System . out . print ( " ▁ Frequency ▁ of ▁ even ▁ number ▁ = ▁ " + even + " NEW_LINE"); }
public static void main ( String [ ] args ) { int m = 3 , n = 3 ; int array [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; freq ( array , m , n ) ; } }
import java . util . Arrays ; public class GFG { static int MAX = 100 ;
static boolean HalfDiagonalSums ( int mat [ ] [ ] , int n ) {
int diag1_left = 0 , diag1_right = 0 ; int diag2_left = 0 , diag2_right = 0 ; for ( int i = 0 , j = n - 1 ; i < n ; i ++ , j -- ) { if ( i < n / 2 ) { diag1_left += mat [ i ] [ i ] ; diag2_left += mat [ j ] [ i ] ; } else if ( i > n / 2 ) { diag1_right += mat [ i ] [ i ] ; diag2_right += mat [ j ] [ i ] ; } } return ( diag1_left == diag2_right && diag2_right == diag2_left && diag1_right == diag2_left && diag2_right == mat [ n / 2 ] [ n / 2 ] ) ; }
public static void main ( String args [ ] ) { int a [ ] [ ] = { { 2 , 9 , 1 , 4 , - 2 } , { 6 , 7 , 2 , 11 , 4 } , { 4 , 2 , 9 , 2 , 4 } , { 1 , 9 , 2 , 4 , 4 } , { 0 , 2 , 4 , 2 , 5 } } ; System . out . print ( HalfDiagonalSums ( a , 5 ) ? " Yes " : " No " ) ; } }
class GFG { int MAX = 100 ; static boolean isIdentity ( int mat [ ] [ ] , int N ) { for ( int row = 0 ; row < N ; row ++ ) { for ( int col = 0 ; col < N ; col ++ ) { if ( row == col && mat [ row ] [ col ] != 1 ) return false ; else if ( row != col && mat [ row ] [ col ] != 0 ) return false ; } } return true ; }
public static void main ( String args [ ] ) { int N = 4 ; int mat [ ] [ ] = { { 1 , 0 , 0 , 0 } , { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 1 } } ; if ( isIdentity ( mat , N ) ) System . out . println ( " Yes ▁ " ) ; else System . out . println ( " No ▁ " ) ; } }
import java . io . * ; class Example { final static long mod = 100000007 ;
static long modPower ( long a , long t , long mod ) { long now = a , ret = 1 ;
while ( t > 0 ) { if ( t % 2 == 1 ) ret = now * ( ret % mod ) ; now = now * ( now % mod ) ; t >>= 1 ; } return ret ; }
static long countWays ( int n , int m , int k ) {
if ( n == 1 m == 1 ) return 1 ;
else if ( ( n + m ) % 2 == 1 && k == - 1 ) return 0 ;
return ( modPower ( modPower ( ( long ) 2 , n - 1 , mod ) , m - 1 , mod ) % mod ) ; }
public static void main ( String args [ ] ) throws IOException { int n = 2 , m = 7 , k = 1 ; System . out . println ( countWays ( n , m , k ) ) ; } }
import java . util . * ; class GFG { static int MAX = 100 ; static void imageSwap ( int mat [ ] [ ] , int n ) {
int row = 0 ;
for ( int j = 0 ; j < n ; j ++ ) {
Stack < Integer > s = new Stack < > ( ) ; int i = row , k = j ; while ( i < n && k >= 0 ) { s . push ( mat [ i ++ ] [ k -- ] ) ; }
i = row ; k = j ; while ( i < n && k >= 0 ) { mat [ i ++ ] [ k -- ] = s . peek ( ) ; s . pop ( ) ; } }
int column = n - 1 ; for ( int j = 1 ; j < n ; j ++ ) {
Stack < Integer > s = new Stack < > ( ) ; int i = j , k = column ; while ( i < n && k >= 0 ) { s . push ( mat [ i ++ ] [ k -- ] ) ; }
i = j ; k = column ; while ( i < n && k >= 0 ) { mat [ i ++ ] [ k -- ] = s . peek ( ) ; s . pop ( ) ; } } }
static void printMatrix ( int mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; } System . out . println ( " " ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; int n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ; } }
import java . io . * ; class GFG { static int MAX = 100 ; static void imageSwap ( int mat [ ] [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j <= i ; j ++ ) mat [ i ] [ j ] = mat [ i ] [ j ] + mat [ j ] [ i ] - ( mat [ j ] [ i ] = mat [ i ] [ j ] ) ; }
static void printMatrix ( int mat [ ] [ ] , int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ; int n = 4 ; imageSwap ( mat , n ) ; printMatrix ( mat , n ) ; } }
static final int m = 3 ;
static final int n = 2 ;
static long countSets ( int a [ ] [ ] ) {
long res = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < m ; j ++ ) { if ( a [ i ] [ j ] == 1 ) u ++ ; else v ++ ; } res += Math . pow ( 2 , u ) - 1 + Math . pow ( 2 , v ) - 1 ; }
for ( int i = 0 ; i < m ; i ++ ) { int u = 0 , v = 0 ; for ( int j = 0 ; j < n ; j ++ ) { if ( a [ j ] [ i ] == 1 ) u ++ ; else v ++ ; } res += Math . pow ( 2 , u ) - 1 + Math . pow ( 2 , v ) - 1 ; }
return res - ( n * m ) ; }
public static void main ( String [ ] args ) { int a [ ] [ ] = { { 1 , 0 , 1 } , { 0 , 1 , 0 } } ; System . out . print ( countSets ( a ) ) ; } }
static int search ( int [ ] [ ] mat , int n , int x ) { if ( n == 0 ) return - 1 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ )
if ( mat [ i ] [ j ] == x ) { System . out . print ( " Element ▁ found ▁ at ▁ ( " + i + " , ▁ " + j + ")NEW_LINE"); return 1 ; } } System . out . print ( " ▁ Element ▁ not ▁ found " ) ; return 0 ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 10 , 20 , 30 , 40 } , { 15 , 25 , 35 , 45 } , { 27 , 29 , 37 , 48 } , { 32 , 33 , 39 , 50 } } ; search ( mat , 4 , 29 ) ; } }
static void fill0X ( int m , int n ) {
int i , k = 0 , l = 0 ;
int r = m , c = n ;
char a [ ] [ ] = new char [ m ] [ n ] ;
char x = ' X ' ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) a [ k ] [ i ] = x ; k ++ ;
for ( i = k ; i < m ; ++ i ) a [ i ] [ n - 1 ] = x ; n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) a [ m - 1 ] [ i ] = x ; m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) a [ i ] [ l ] = x ; l ++ ; }
x = ( x == '0' ) ? ' X ' : '0' ; }
for ( i = 0 ; i < r ; i ++ ) { for ( int j = 0 ; j < c ; j ++ ) System . out . print ( a [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { System . out . println ( " Output ▁ for ▁ m ▁ = ▁ 5 , ▁ n ▁ = ▁ 6" ) ; fill0X ( 5 , 6 ) ; System . out . println ( " Output ▁ for ▁ m ▁ = ▁ 4 , ▁ n ▁ = ▁ 4" ) ; fill0X ( 4 , 4 ) ; System . out . println ( " Output ▁ for ▁ m ▁ = ▁ 3 , ▁ n ▁ = ▁ 4" ) ; fill0X ( 3 , 4 ) ; } }
static class NodeTemp { int data ; NodeTemp next , child ; public NodeTemp ( int data ) { this . data = data ; next = child = null ; } }
static public NodeTemp addSibling ( NodeTemp node , int data ) { if ( node == null ) return null ; while ( node . next != null ) node = node . next ; return ( node . next = new NodeTemp ( data ) ) ; }
static public NodeTemp addChild ( NodeTemp node , int data ) { if ( node == null ) return null ;
if ( node . child != null ) return ( addSibling ( node . child , data ) ) ; else return ( node . child = new NodeTemp ( data ) ) ; }
static public void traverseTree ( NodeTemp root ) { if ( root == null ) return ; while ( root != null ) { System . out . print ( root . data + " ▁ " ) ; if ( root . child != null ) traverseTree ( root . child ) ; root = root . next ; } }
public static void main ( String args [ ] ) { NodeTemp root = new NodeTemp ( 10 ) ; NodeTemp n1 = addChild ( root , 2 ) ; NodeTemp n2 = addChild ( root , 3 ) ; NodeTemp n3 = addChild ( root , 4 ) ; NodeTemp n4 = addChild ( n3 , 6 ) ; NodeTemp n5 = addChild ( root , 5 ) ; NodeTemp n6 = addChild ( n5 , 7 ) ; NodeTemp n7 = addChild ( n5 , 8 ) ; NodeTemp n8 = addChild ( n5 , 9 ) ; traverseTree ( root ) ; } }
import java . util . * ; import java . lang . * ; public class GfG { private final static int SIZE = 100 ;
public static int calculateEnergy ( int mat [ ] [ ] , int n ) { int i_des , j_des , q ; int tot_energy = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
q = mat [ i ] [ j ] / n ;
i_des = q ; j_des = mat [ i ] [ j ] - ( n * q ) ;
tot_energy += Math . abs ( i_des - i ) + Math . abs ( j_des - j ) ; } }
return tot_energy ; }
public static void main ( String argc [ ] ) { int [ ] [ ] mat = new int [ ] [ ] { { 4 , 7 , 0 , 3 } , { 8 , 5 , 6 , 1 } , { 9 , 11 , 10 , 2 } , { 15 , 13 , 14 , 12 } } ; int n = 4 ; System . out . println ( " Total ▁ energy ▁ required ▁ = ▁ " + calculateEnergy ( mat , n ) + " ▁ units " ) ; } }
class GFG { static final int MAX = 100 ;
static boolean isUnique ( int mat [ ] [ ] , int i , int j , int n , int m ) {
int sumrow = 0 ; for ( int k = 0 ; k < m ; k ++ ) { sumrow += mat [ i ] [ k ] ; if ( sumrow > 1 ) return false ; }
int sumcol = 0 ; for ( int k = 0 ; k < n ; k ++ ) { sumcol += mat [ k ] [ j ] ; if ( sumcol > 1 ) return false ; } return true ; } static int countUnique ( int mat [ ] [ ] , int n , int m ) { int uniquecount = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] != 0 && isUnique ( mat , i , j , n , m ) ) uniquecount ++ ; return uniquecount ; }
static public void main ( String [ ] args ) { int mat [ ] [ ] = { { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 1 , 0 , 0 , 1 } } ; System . out . print ( countUnique ( mat , 3 , 4 ) ) ; } }
class GFG { static int MAX = 100 ; static int countUnique ( int mat [ ] [ ] , int n , int m ) { int [ ] rowsum = new int [ n ] ; int [ ] colsum = new int [ m ] ;
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] != 0 ) { rowsum [ i ] ++ ; colsum [ j ] ++ ; }
int uniquecount = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) if ( mat [ i ] [ j ] != 0 && rowsum [ i ] == 1 && colsum [ j ] == 1 ) uniquecount ++ ; return uniquecount ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 0 , 1 , 0 , 0 } , { 0 , 0 , 1 , 0 } , { 1 , 0 , 0 , 1 } } ; System . out . print ( countUnique ( mat , 3 , 4 ) ) ; } }
for ( int i = 0 ; i < m ; ++ i ) for ( int j = 0 ; j < n ; ++ j ) if ( array [ i ] [ j ] == 0 ) ++ counter ; return ( counter > ( ( m * n ) / 2 ) ) ; }
public static void main ( String args [ ] ) { int array [ ] [ ] = { { 1 , 0 , 3 } , { 0 , 0 , 4 } , { 6 , 0 , 0 } } ; int m = 3 , n = 3 ; if ( isSparse ( array , m , n ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . io . * ; class GFG { int MAX = 100 ;
static int countCommon ( int mat [ ] [ ] , int n ) { int res = 0 ; for ( int i = 0 ; i < n ; i ++ ) if ( mat [ i ] [ i ] == mat [ i ] [ n - i - 1 ] ) res ++ ; return res ; }
public static void main ( String args [ ] ) throws IOException { int mat [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; System . out . println ( countCommon ( mat , 3 ) ) ; } }
static boolean areSumSame ( int a [ ] [ ] , int n , int m ) { int sum1 = 0 , sum2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { sum1 = 0 ; sum2 = 0 ; for ( int j = 0 ; j < m ; j ++ ) { sum1 += a [ i ] [ j ] ; sum2 += a [ j ] [ i ] ; } if ( sum1 == sum2 ) return true ; } return false ; }
int n = 4 ;
int m = 4 ; int M [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 9 , 5 , 3 , 1 } , { 0 , 3 , 5 , 6 } , { 0 , 4 , 5 , 6 } } ; if ( areSumSame ( M , n , m ) == true ) System . out . print ( "1NEW_LINE"); else System . out . print ( "0NEW_LINE"); } }
import java . util . * ; class GFG { static class Node { int data ; Node next ; Node child ; } ;
static Node newNode ( int data ) { Node newNode = new Node ( ) ; newNode . next = newNode . child = null ; newNode . data = data ; return newNode ; }
static Node addSibling ( Node n , int data ) { if ( n == null ) return null ; while ( n . next != null ) n = n . next ; return ( n . next = newNode ( data ) ) ; }
static Node addChild ( Node n , int data ) { if ( n == null ) return null ;
if ( n . child != null ) return addSibling ( n . child , data ) ; else return ( n . child = newNode ( data ) ) ; }
static void traverseTree ( Node root ) {
if ( root == null ) return ; System . out . print ( root . data + " ▁ " ) ; if ( root . child == null ) return ;
Queue < Node > q = new LinkedList < > ( ) ; Node curr = root . child ; q . add ( curr ) ; while ( ! q . isEmpty ( ) ) {
curr = q . peek ( ) ; q . remove ( ) ;
while ( curr != null ) { System . out . print ( curr . data + " ▁ " ) ; if ( curr . child != null ) { q . add ( curr . child ) ; } curr = curr . next ; } } }
public static void main ( String [ ] args ) { Node root = newNode ( 10 ) ; Node n1 = addChild ( root , 2 ) ; Node n2 = addChild ( root , 3 ) ; Node n3 = addChild ( root , 4 ) ; Node n4 = addChild ( n3 , 6 ) ; Node n5 = addChild ( root , 5 ) ; Node n6 = addChild ( n5 , 7 ) ; Node n7 = addChild ( n5 , 8 ) ; Node n8 = addChild ( n5 , 9 ) ; traverseTree ( root ) ; } }
class GFG { static final int N = 4 ;
static void findMax ( int arr [ ] [ ] ) { int row = 0 , i , j ; for ( i = 0 , j = N - 1 ; i < N ; i ++ ) {
while ( j >= 0 && arr [ i ] [ j ] == 1 ) { row = i ; j -- ; } } System . out . print ( " Row ▁ number ▁ = ▁ " + ( row + 1 ) ) ; System . out . print ( " , ▁ MaxCount ▁ = ▁ " + ( N - 1 - j ) ) ; }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 0 } , { 0 , 1 , 1 , 1 } } ; findMax ( arr ) ; } }
import java . io . * ; class GFG { static int MAX = 100 ;
static void transpose ( int mat [ ] [ ] , int tr [ ] [ ] , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) tr [ i ] [ j ] = mat [ j ] [ i ] ; }
static boolean isSymmetric ( int mat [ ] [ ] , int N ) { int tr [ ] [ ] = new int [ N ] [ MAX ] ; transpose ( mat , tr , N ) ; for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != tr [ i ] [ j ] ) return false ; return true ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " No " ) ; } }
import java . io . * ; class GFG { static int MAX = 100 ;
static boolean isSymmetric ( int mat [ ] [ ] , int N ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) return false ; return true ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 3 , 5 } , { 3 , 2 , 4 } , { 5 , 4 , 1 } } ; if ( isSymmetric ( mat , 3 ) ) System . out . println ( " Yes " ) ; else System . out . println ( " NO " ) ; } }
import java . io . * ; class Cell { int x ; int y ;
Cell ( int x , int y ) { this . x = x ; this . y = y ; } } public class MoveCellPerCellValue {
public boolean isAllCellTraversed ( Cell grid [ ] [ ] ) { boolean [ ] [ ] visited = new boolean [ grid . length ] [ grid [ 0 ] . length ] ; int total = grid . length * grid [ 0 ] . length ;
int startx = grid [ 0 ] [ 0 ] . x ; int starty = grid [ 0 ] [ 0 ] . y ; for ( int i = 0 ; i < total - 2 ; i ++ ) {
if ( grid [ startx ] [ starty ] == null ) return false ;
if ( visited [ startx ] [ starty ] == true ) return false ; visited [ startx ] [ starty ] = true ; int x = grid [ startx ] [ starty ] . x ; int y = grid [ startx ] [ starty ] . y ;
startx = x ; starty = y ; }
if ( grid [ startx ] [ starty ] == null ) return true ; return false ; }
public static void main ( String args [ ] ) { Cell cell [ ] [ ] = new Cell [ 3 ] [ 2 ] ; cell [ 0 ] [ 0 ] = new Cell ( 0 , 1 ) ; cell [ 0 ] [ 1 ] = new Cell ( 2 , 0 ) ; cell [ 1 ] [ 0 ] = null ; cell [ 1 ] [ 1 ] = new Cell ( 1 , 0 ) ; cell [ 2 ] [ 0 ] = new Cell ( 2 , 1 ) ; cell [ 2 ] [ 1 ] = new Cell ( 1 , 1 ) ; MoveCellPerCellValue mcp = new MoveCellPerCellValue ( ) ; System . out . println ( mcp . isAllCellTraversed ( cell ) ) ; } }
public class PalinPath { public static boolean isPalin ( String str ) { int len = str . length ( ) / 2 ; for ( int i = 0 ; i < len ; i ++ ) { if ( str . charAt ( i ) != str . charAt ( str . length ( ) - i - 1 ) ) return false ; } return true ; }
public static void palindromicPath ( String str , char a [ ] [ ] , int i , int j , int m , int n ) {
if ( j < m - 1 i < n - 1 ) { if ( i < n - 1 ) palindromicPath ( str + a [ i ] [ j ] , a , i + 1 , j , m , n ) ; if ( j < m - 1 ) palindromicPath ( str + a [ i ] [ j ] , a , i , j + 1 , m , n ) ; }
else { str = str + a [ n - 1 ] [ m - 1 ] ; if ( isPalin ( str ) ) System . out . println ( str ) ; } }
public static void main ( String args [ ] ) { char arr [ ] [ ] = { { ' a ' , ' a ' , ' a ' , ' b ' } , { ' b ' , ' a ' , ' a ' , ' a ' } , { ' a ' , ' b ' , ' b ' , ' a ' } } ; String str = " " ; palindromicPath ( str , arr , 0 , 0 , 4 , 3 ) ; } }
public class Main { public static final int n = 4 ; public static final int m = 4 ;
static int findPossibleMoves ( int mat [ ] [ ] , int p , int q ) {
int X [ ] = { 2 , 1 , - 1 , - 2 , - 2 , - 1 , 1 , 2 } ; int Y [ ] = { 1 , 2 , 2 , 1 , - 1 , - 2 , - 2 , - 1 } ; int count = 0 ;
for ( int i = 0 ; i < 8 ; i ++ ) {
int x = p + X [ i ] ; int y = q + Y [ i ] ;
if ( x >= 0 && y >= 0 && x < n && y < m && mat [ x ] [ y ] == 0 ) count ++ ; }
return count ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 0 , 1 , 0 } , { 0 , 1 , 1 , 1 } , { 1 , 1 , 0 , 1 } , { 0 , 1 , 1 , 1 } } ; int p = 2 , q = 2 ; System . out . println ( findPossibleMoves ( mat , p , q ) ) ; } }
import java . io . * ; public class GFG { static void printDiagonalSums ( int [ ] [ ] mat , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) principal += mat [ i ] [ j ] ;
if ( ( i + j ) == ( n - 1 ) ) secondary += mat [ i ] [ j ] ; } } System . out . println ( " Principal ▁ Diagonal : " + principal ) ; System . out . println ( " Secondary ▁ Diagonal : " + secondary ) ; }
static public void main ( String [ ] args ) { int [ ] [ ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; } }
import java . io . * ; public class GFG { static void printDiagonalSums ( int [ ] [ ] mat , int n ) { int principal = 0 , secondary = 0 ; for ( int i = 0 ; i < n ; i ++ ) { principal += mat [ i ] [ i ] ; secondary += mat [ i ] [ n - i - 1 ] ; } System . out . println ( " Principal ▁ Diagonal : " + principal ) ; System . out . println ( " Secondary ▁ Diagonal : " + secondary ) ; }
static public void main ( String [ ] args ) { int [ ] [ ] a = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; printDiagonalSums ( a , 4 ) ; } }
class GFG { public static long getBoundarySum ( int a [ ] [ ] , int m , int n ) { long sum = 0 ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { if ( i == 0 ) sum += a [ i ] [ j ] ; else if ( i == m - 1 ) sum += a [ i ] [ j ] ; else if ( j == 0 ) sum += a [ i ] [ j ] ; else if ( j == n - 1 ) sum += a [ i ] [ j ] ; } } return sum ; }
public static void main ( String [ ] args ) { int a [ ] [ ] = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } } ; long sum = getBoundarySum ( a , 4 , 4 ) ; System . out . println ( " Sum ▁ of ▁ boundary ▁ elements " + " ▁ is ▁ " + sum ) ; } }
import java . io . * ; class GFG { static void printSpiral ( int [ ] [ ] mat , int r , int c ) { int i , a = 0 , b = 2 ; int low_row = ( 0 > a ) ? 0 : a ; int low_column = ( 0 > b ) ? 0 : b - 1 ; int high_row = ( ( a + 1 ) >= r ) ? r - 1 : a + 1 ; int high_column = ( ( b + 1 ) >= c ) ? c - 1 : b + 1 ; while ( ( low_row > 0 - r && low_column > 0 - c ) ) { for ( i = low_column + 1 ; i <= high_column && i < c && low_row >= 0 ; ++ i ) System . out . print ( mat [ low_row ] [ i ] + " ▁ " ) ; low_row -= 1 ; for ( i = low_row + 2 ; i <= high_row && i < r && high_column < c ; ++ i ) System . out . print ( mat [ i ] [ high_column ] + " ▁ " ) ; high_column += 1 ; for ( i = high_column - 2 ; i >= low_column && i >= 0 && high_row < r ; -- i ) System . out . print ( mat [ high_row ] [ i ] + " ▁ " ) ; high_row += 1 ; for ( i = high_row - 2 ; i > low_row && i >= 0 && low_column >= 0 ; -- i ) System . out . print ( mat [ i ] [ low_column ] + " ▁ " ) ; low_column -= 1 ; } System . out . println ( ) ; }
static public void main ( String [ ] args ) { int [ ] [ ] mat = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int r = 3 , c = 3 ;
printSpiral ( mat , r , c ) ; } }
import java . io . * ; class GFG { public static int N = 3 ;
static void interchangeDiagonals ( int array [ ] [ ] ) {
for ( int i = 0 ; i < N ; ++ i ) if ( i != N / 2 ) { int temp = array [ i ] [ i ] ; array [ i ] [ i ] = array [ i ] [ N - i - 1 ] ; array [ i ] [ N - i - 1 ] = temp ; } for ( int i = 0 ; i < N ; ++ i ) { for ( int j = 0 ; j < N ; ++ j ) System . out . print ( array [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int array [ ] [ ] = { { 4 , 5 , 6 } , { 1 , 2 , 3 } , { 7 , 8 , 9 } } ; interchangeDiagonals ( array ) ; } }
class GFG { public static int difference ( int arr [ ] [ ] , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( i == j ) d1 += arr [ i ] [ j ] ;
if ( i == n - j - 1 ) d2 += arr [ i ] [ j ] ; } }
return Math . abs ( d1 - d2 ) ; }
public static void main ( String [ ] args ) { int n = 3 ; int arr [ ] [ ] = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , - 12 } } ; System . out . print ( difference ( arr , n ) ) ; } }
class GFG { public static int difference ( int arr [ ] [ ] , int n ) {
int d1 = 0 , d2 = 0 ; for ( int i = 0 ; i < n ; i ++ ) { d1 += arr [ i ] [ i ] ; d2 += arr [ i ] [ n - i - 1 ] ; }
return Math . abs ( d1 - d2 ) ; }
public static void main ( String [ ] args ) { int n = 3 ; int arr [ ] [ ] = { { 11 , 2 , 4 } , { 4 , 5 , 6 } , { 10 , 8 , - 12 } } ; System . out . print ( difference ( arr , n ) ) ; } }
class GFG { static int MAX = 100 ;
static void spiralFill ( int m , int n , int a [ ] [ ] ) {
int val = 1 ;
int k = 0 , l = 0 ; while ( k < m && l < n ) {
for ( int i = l ; i < n ; ++ i ) { a [ k ] [ i ] = val ++ ; } k ++ ;
for ( int i = k ; i < m ; ++ i ) { a [ i ] [ n - 1 ] = val ++ ; } n -- ;
if ( k < m ) { for ( int i = n - 1 ; i >= l ; -- i ) { a [ m - 1 ] [ i ] = val ++ ; } m -- ; }
if ( l < n ) { for ( int i = m - 1 ; i >= k ; -- i ) { a [ i ] [ l ] = val ++ ; } l ++ ; } } }
public static void main ( String [ ] args ) { int m = 4 , n = 4 ; int a [ ] [ ] = new int [ MAX ] [ MAX ] ; spiralFill ( m , n , a ) ; for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) { System . out . print ( a [ i ] [ j ] + " ▁ " ) ; } System . out . println ( " " ) ; } } }
class GFG { static final int MAX = 100 ;
static void maxMin ( int arr [ ] [ ] , int n ) { int min = + 2147483647 ; int max = - 2147483648 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j <= n / 2 ; j ++ ) {
if ( arr [ i ] [ j ] > arr [ i ] [ n - j - 1 ] ) { if ( min > arr [ i ] [ n - j - 1 ] ) min = arr [ i ] [ n - j - 1 ] ; if ( max < arr [ i ] [ j ] ) max = arr [ i ] [ j ] ; } else { if ( min > arr [ i ] [ j ] ) min = arr [ i ] [ j ] ; if ( max < arr [ i ] [ n - j - 1 ] ) max = arr [ i ] [ n - j - 1 ] ; } } } System . out . print ( " Maximum ▁ = ▁ " + max + " , ▁ Minimum ▁ = ▁ " + min ) ; }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 5 , 9 , 11 } , { 25 , 0 , 14 } , { 21 , 6 , 4 } } ; maxMin ( arr , 3 ) ; } }
import java . util . * ; class GFG { public static void antiSpiralTraversal ( int m , int n , int a [ ] [ ] ) { int i , k = 0 , l = 0 ;
Stack < Integer > stk = new Stack < Integer > ( ) ; while ( k <= m && l <= n ) {
for ( i = l ; i <= n ; ++ i ) stk . push ( a [ k ] [ i ] ) ; k ++ ;
for ( i = k ; i <= m ; ++ i ) stk . push ( a [ i ] [ n ] ) ; n -- ;
if ( k <= m ) { for ( i = n ; i >= l ; -- i ) stk . push ( a [ m ] [ i ] ) ; m -- ; }
if ( l <= n ) { for ( i = m ; i >= k ; -- i ) stk . push ( a [ i ] [ l ] ) ; l ++ ; } } while ( ! stk . empty ( ) ) { System . out . print ( stk . peek ( ) + " ▁ " ) ; stk . pop ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 , 4 , 5 } , { 6 , 7 , 8 , 9 , 10 } , { 11 , 12 , 13 , 14 , 15 } , { 16 , 17 , 18 , 19 , 20 } } ; antiSpiralTraversal ( mat . length - 1 , mat [ 0 ] . length - 1 , mat ) ; } }
static int MAX = 100 ;
static int findNormal ( int mat [ ] [ ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] * mat [ i ] [ j ] ; return ( int ) Math . sqrt ( sum ) ; }
static int findTrace ( int mat [ ] [ ] , int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += mat [ i ] [ i ] ; return sum ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; System . out . println ( " Trace ▁ of ▁ Matrix ▁ = ▁ " + findTrace ( mat , 5 ) ) ; System . out . println ( " Normal ▁ of ▁ Matrix ▁ = ▁ " + findNormal ( mat , 5 ) ) ; } }
class GFG { static final int N = 5 ; static final int M = 5 ;
static int minOperation ( boolean arr [ ] [ ] ) { int ans = 0 ; for ( int i = N - 1 ; i >= 0 ; i -- ) { for ( int j = M - 1 ; j >= 0 ; j -- ) {
if ( arr [ i ] [ j ] == false ) {
ans ++ ;
for ( int k = 0 ; k <= i ; k ++ ) { for ( int h = 0 ; h <= j ; h ++ ) {
if ( arr [ k ] [ h ] == true ) { arr [ k ] [ h ] = false ; } else { arr [ k ] [ h ] = true ; } } } } } } return ans ; }
public static void main ( String [ ] args ) { boolean mat [ ] [ ] = { { false , false , true , true , true } , { false , false , false , true , true } , { false , false , false , true , true } , { true , true , true , true , true } , { true , true , true , true , true } } ; System . out . println ( minOperation ( mat ) ) ; } }
static int findSum ( int n ) { int ans = 0 , temp = 0 , num ;
for ( int i = 1 ; i <= n && temp < n ; i ++ ) {
temp = i - 1 ;
num = 1 ; while ( temp < n ) { if ( temp + i <= n ) ans += ( i * num ) ; else ans += ( ( n - temp ) * num ) ; temp += i ; num ++ ; } } return ans ; }
public static void main ( String [ ] args ) { int N = 2 ; System . out . println ( findSum ( N ) ) ; } }
static void printCoils ( int n ) {
int m = 8 * n * n ;
int coil1 [ ] = new int [ m ] ;
coil1 [ 0 ] = 8 * n * n + 2 * n ; int curr = coil1 [ 0 ] ; int nflg = 1 , step = 2 ;
int index = 1 ; while ( index < m ) {
for ( int i = 0 ; i < step ; i ++ ) {
curr = coil1 [ index ++ ] = ( curr - 4 * n * nflg ) ; if ( index >= m ) break ; } if ( index >= m ) break ;
for ( int i = 0 ; i < step ; i ++ ) { curr = coil1 [ index ++ ] = curr + nflg ; if ( index >= m ) break ; } nflg = nflg * ( - 1 ) ; step += 2 ; }
int coil2 [ ] = new int [ m ] ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) coil2 [ i ] = 16 * n * n + 1 - coil1 [ i ] ;
System . out . print ( " Coil ▁ 1 ▁ : ▁ " ) ; for ( int i = 0 ; i < 8 * n * n ; i ++ ) System . out . print ( coil1 [ i ] + " ▁ " ) ; System . out . print ( " Coil 2 : "); for ( int i = 0 ; i < 8 * n * n ; i ++ ) System . out . print ( coil2 [ i ] + " ▁ " ) ; }
public static void main ( String [ ] args ) { int n = 1 ; printCoils ( n ) ; } }
static int findSum ( int n ) {
int [ ] [ ] arr = new int [ n ] [ n ] ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) arr [ i ] [ j ] = Math . abs ( i - j ) ;
int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < n ; j ++ ) sum += arr [ i ] [ j ] ; return sum ; }
static public void main ( String [ ] args ) { int n = 3 ; System . out . println ( findSum ( n ) ) ; } }
static int findSum ( int n ) { int sum = 0 ; for ( int i = 0 ; i < n ; i ++ ) sum += i * ( n - i ) ; return 2 * sum ; }
static public void main ( String [ ] args ) { int n = 3 ; System . out . println ( findSum ( n ) ) ; } }
static int findSum ( int n ) { n -- ; int sum = 0 ; sum += ( n * ( n + 1 ) ) / 2 ; sum += ( n * ( n + 1 ) * ( 2 * n + 1 ) ) / 6 ; return sum ; }
static public void main ( String [ ] args ) { int n = 3 ; System . out . println ( findSum ( n ) ) ; } }
import java . io . * ; public class GFG { static void checkHV ( int [ ] [ ] arr , int N , int M ) {
boolean horizontal = true ; boolean vertical = true ;
for ( int i = 0 , k = N - 1 ; i < N / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < M ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { horizontal = false ; break ; } } }
for ( int i = 0 , k = M - 1 ; i < M / 2 ; i ++ , k -- ) {
for ( int j = 0 ; j < N ; j ++ ) {
if ( arr [ i ] [ j ] != arr [ k ] [ j ] ) { horizontal = false ; break ; } } } if ( ! horizontal && ! vertical ) System . out . println ( " NO " ) ; else if ( horizontal && ! vertical ) System . out . println ( " HORIZONTAL " ) ; else if ( vertical && ! horizontal ) System . out . println ( " VERTICAL " ) ; else System . out . println ( " BOTH " ) ; }
static public void main ( String [ ] args ) { int [ ] [ ] mat = { { 1 , 0 , 1 } , { 0 , 0 , 0 } , { 1 , 0 , 1 } } ; checkHV ( mat , 3 , 3 ) ; } }
static int maxDet ( int n ) { return ( 2 * n * n * n ) ; }
void resMatrix ( int n ) { for ( int i = 0 ; i < 3 ; i ++ ) { for ( int j = 0 ; j < 3 ; j ++ ) {
if ( i == 0 && j == 2 ) System . out . print ( "0 ▁ " ) ; else if ( i == 1 && j == 0 ) System . out . print ( "0 ▁ " ) ; else if ( i == 2 && j == 1 ) System . out . print ( "0 ▁ " ) ;
else System . out . print ( n + " ▁ " ) ; } System . out . println ( " " ) ; } }
static public void main ( String [ ] args ) { int n = 15 ; GFG geeks = new GFG ( ) ; System . out . println ( " Maximum ▁ Determinant ▁ = ▁ " + maxDet ( n ) ) ; System . out . println ( " Resultant ▁ Matrix ▁ : " ) ; geeks . resMatrix ( n ) ; } }
static int spiralDiaSum ( int n ) { if ( n == 1 ) return 1 ;
return ( 4 * n * n - 6 * n + 6 + spiralDiaSum ( n - 2 ) ) ; }
public static void main ( String [ ] args ) { int n = 7 ; System . out . print ( spiralDiaSum ( n ) ) ; } }
class GFG { static final int R = 3 ; static final int C = 5 ;
static int numofneighbour ( int mat [ ] [ ] , int i , int j ) { int count = 0 ;
if ( i > 0 && mat [ i - 1 ] [ j ] == 1 ) count ++ ;
if ( j > 0 && mat [ i ] [ j - 1 ] == 1 ) count ++ ;
if ( i < R - 1 && mat [ i + 1 ] [ j ] == 1 ) count ++ ;
if ( j < C - 1 && mat [ i ] [ j + 1 ] == 1 ) count ++ ; return count ; }
static int findperimeter ( int mat [ ] [ ] ) { int perimeter = 0 ;
for ( int i = 0 ; i < R ; i ++ ) for ( int j = 0 ; j < C ; j ++ ) if ( mat [ i ] [ j ] == 1 ) perimeter += ( 4 - numofneighbour ( mat , i , j ) ) ; return perimeter ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 0 , 1 , 0 , 0 , 0 } , { 1 , 1 , 1 , 0 , 0 } , { 1 , 0 , 0 , 0 , 0 } } ; System . out . println ( findperimeter ( mat ) ) ; } }
class GFG { static final int MAX = 100 ; static void printMatrixDiagonal ( int mat [ ] [ ] , int n ) {
int i = 0 , j = 0 ;
boolean isUp = true ;
for ( int k = 0 ; k < n * n ; ) {
if ( isUp ) { for ( ; i >= 0 && j < n ; j ++ , i -- ) { System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; k ++ ; }
if ( i < 0 && j <= n - 1 ) i = 0 ; if ( j == n ) { i = i + 2 ; j -- ; } }
else { for ( ; j >= 0 && i < n ; i ++ , j -- ) { System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; k ++ ; }
if ( j < 0 && i <= n - 1 ) j = 0 ; if ( i == n ) { j = j + 2 ; i -- ; } }
isUp = ! isUp ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 5 , 6 } , { 7 , 8 , 9 } } ; int n = 3 ; printMatrixDiagonal ( mat , n ) ; } }
public class MatrixDiag {
int [ ] [ ] mat = { { 1 , 2 , 3 , 4 } , { 5 , 6 , 7 , 8 } , { 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 } } ;
int n = 4 , mode = 0 , it = 0 , lower = 0 ;
for ( int t = 0 ; t < ( 2 * n - 1 ) ; t ++ ) { int t1 = t ; if ( t1 >= n ) { mode ++ ; t1 = n - 1 ; it -- ; lower ++ ; } else { lower = 0 ; it ++ ; } for ( int i = t1 ; i >= lower ; i -- ) { if ( ( t1 + mode ) % 2 == 0 ) { System . out . println ( mat [ i ] [ t1 + lower - i ] ) ; } else { System . out . println ( mat [ t1 + lower - i ] [ i ] ) ; } } } } }
static int maxRowDiff ( int mat [ ] [ ] , int m , int n ) {
int rowSum [ ] = new int [ m ] ;
for ( int i = 0 ; i < m ; i ++ ) { int sum = 0 ; for ( int j = 0 ; j < n ; j ++ ) sum += mat [ i ] [ j ] ; rowSum [ i ] = sum ; }
int max_diff = rowSum [ 1 ] - rowSum [ 0 ] ; int min_element = rowSum [ 0 ] ; for ( int i = 1 ; i < m ; i ++ ) {
if ( rowSum [ i ] - min_element > max_diff ) max_diff = rowSum [ i ] - min_element ;
if ( rowSum [ i ] < min_element ) min_element = rowSum [ i ] ; } return max_diff ; }
public static void main ( String [ ] args ) { int m = 5 , n = 4 ; int mat [ ] [ ] = { { - 1 , 2 , 3 , 4 } , { 5 , 3 , - 2 , 1 } , { 6 , 7 , 2 , - 3 } , { 2 , 9 , 1 , 4 } , { 2 , 1 , - 2 , 0 } } ; System . out . print ( maxRowDiff ( mat , m , n ) ) ; } }
import java . io . * ; class GFG { static int R = 4 ; static int C = 4 ;
static int getTotalCoverageOfMatrix ( int [ ] [ ] mat ) { int res = 0 ;
for ( int i = 0 ; i < R ; i ++ ) {
boolean isOne = false ;
for ( int j = 0 ; j < C ; j ++ ) {
if ( mat [ i ] [ j ] == 1 ) isOne = true ;
else if ( isOne ) res ++ ; }
isOne = false ; for ( int j = C - 1 ; j >= 0 ; j -- ) { if ( mat [ i ] [ j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } }
for ( int j = 0 ; j < C ; j ++ ) {
boolean isOne = false ; for ( int i = 0 ; i < R ; i ++ ) { if ( mat [ i ] [ j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } isOne = false ; for ( int i = R - 1 ; i >= 0 ; i -- ) { if ( mat [ i ] [ j ] == 1 ) isOne = true ; else if ( isOne ) res ++ ; } } return res ; }
static public void main ( String [ ] args ) { int [ ] [ ] mat = { { 0 , 0 , 0 , 0 } , { 1 , 0 , 0 , 1 } , { 0 , 1 , 1 , 0 } , { 0 , 1 , 0 , 0 } } ; System . out . println ( getTotalCoverageOfMatrix ( mat ) ) ; } }
import java . io . * ; class GFG { static int R = 3 ; static int C = 4 ;
static int gcd ( int a , int b ) { if ( b == 0 ) return a ; return gcd ( b , a % b ) ; }
static void replacematrix ( int [ ] [ ] mat , int n , int m ) { int [ ] rgcd = new int [ R ] ; int [ ] cgcd = new int [ C ] ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < m ; j ++ ) { rgcd [ i ] = gcd ( rgcd [ i ] , mat [ i ] [ j ] ) ; cgcd [ j ] = gcd ( cgcd [ j ] , mat [ i ] [ j ] ) ; } }
for ( int i = 0 ; i < n ; i ++ ) for ( int j = 0 ; j < m ; j ++ ) mat [ i ] [ j ] = Math . max ( rgcd [ i ] , cgcd [ j ] ) ; }
static public void main ( String [ ] args ) { int [ ] [ ] m = { { 1 , 2 , 3 , 3 } , { 4 , 5 , 6 , 6 } , { 7 , 8 , 9 , 9 } , } ; replacematrix ( m , R , C ) ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) System . out . print ( m [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } } }
class GFG { static int MAX = 100 ;
static int sortedCount ( int mat [ ] [ ] , int r , int c ) {
int result = 0 ;
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = 0 ; j < c - 1 ; j ++ ) if ( mat [ i ] [ j + 1 ] <= mat [ i ] [ j ] ) break ;
if ( j == c - 1 ) result ++ ; }
for ( int i = 0 ; i < r ; i ++ ) {
int j ; for ( j = c - 1 ; j > 0 ; j -- ) if ( mat [ i ] [ j - 1 ] <= mat [ i ] [ j ] ) break ;
if ( c > 1 && j == 0 ) result ++ ; } return result ; }
public static void main ( String arg [ ] ) { int m = 4 , n = 5 ; int mat [ ] [ ] = { { 1 , 2 , 3 , 4 , 5 } , { 4 , 3 , 1 , 2 , 6 } , { 8 , 7 , 6 , 5 , 4 } , { 5 , 7 , 8 , 9 , 10 } } ; System . out . print ( sortedCount ( mat , m , n ) ) ; } }
class GFG { static final int MAX = 1000 ;
static int maxXOR ( int mat [ ] [ ] , int N ) {
int r_xor , c_xor ; int max_xor = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { r_xor = 0 ; c_xor = 0 ; for ( int j = 0 ; j < N ; j ++ ) {
r_xor = r_xor ^ mat [ i ] [ j ] ;
c_xor = c_xor ^ mat [ j ] [ i ] ; }
if ( max_xor < Math . max ( r_xor , c_xor ) ) max_xor = Math . max ( r_xor , c_xor ) ; }
return max_xor ; }
public static void main ( String [ ] args ) { int N = 3 ; int mat [ ] [ ] = { { 1 , 5 , 4 } , { 3 , 7 , 2 } , { 5 , 9 , 10 } } ; System . out . print ( " maximum ▁ XOR ▁ value ▁ : ▁ " + maxXOR ( mat , N ) ) ; } }
static void direction ( int R , int C ) { if ( R != C && R % 2 == 0 && C % 2 != 0 && R < C ) { System . out . println ( " Left " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R > C ) { System . out . println ( " Up " ) ; return ; } if ( R == C && R % 2 != 0 && C % 2 != 0 ) { System . out . println ( " Right " ) ; return ; } if ( R == C && R % 2 == 0 && C % 2 == 0 ) { System . out . println ( " Left " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R < C ) { System . out . println ( " Right " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 != 0 && R > C ) { System . out . println ( " Down " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R < C ) { System . out . println ( " Left " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 == 0 && R > C ) { System . out . println ( " Up " ) ; return ; } if ( R != C && R % 2 == 0 && C % 2 != 0 && R > C ) { System . out . println ( " Down " ) ; return ; } if ( R != C && R % 2 != 0 && C % 2 == 0 && R < C ) { System . out . println ( " Right " ) ; return ; } }
public static void main ( String [ ] args ) { int R = 3 , C = 1 ; direction ( R , C ) ; } }
import java . io . * ; class GFG { static int R = 3 ; static int C = 6 ; static void spiralPrint ( int m , int n , int [ ] [ ] a , int c ) { int i , k = 0 , l = 0 ; int count = 0 ;
while ( k < m && l < n ) {
for ( i = l ; i < n ; ++ i ) { count ++ ; if ( count == c ) System . out . println ( a [ k ] [ i ] + " ▁ " ) ; } k ++ ;
for ( i = k ; i < m ; ++ i ) { count ++ ; if ( count == c ) System . out . println ( a [ i ] [ n - 1 ] + " ▁ " ) ; } n -- ;
if ( k < m ) { for ( i = n - 1 ; i >= l ; -- i ) { count ++ ; if ( count == c ) System . out . println ( a [ m - 1 ] [ i ] + " ▁ " ) ; } m -- ; }
if ( l < n ) { for ( i = m - 1 ; i >= k ; -- i ) { count ++ ; if ( count == c ) System . out . println ( a [ i ] [ l ] + " ▁ " ) ; } l ++ ; } } }
public static void main ( String [ ] args ) { int a [ ] [ ] = { { 1 , 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 , 17 , 18 } } ; int k = 17 ; spiralPrint ( R , C , a , k ) ; } }
class GFG { static int MAX = 100 ;
static int findK ( int A [ ] [ ] , int i , int j , int n , int m , int k ) { if ( n < 1 m < 1 ) return - 1 ;
if ( k <= m ) return A [ i + 0 ] [ j + k - 1 ] ;
if ( k <= ( m + n - 1 ) ) return A [ i + ( k - m ) ] [ j + m - 1 ] ;
if ( k <= ( m + n - 1 + m - 1 ) ) return A [ i + n - 1 ] [ j + m - 1 - ( k - ( m + n - 1 ) ) ] ;
if ( k <= ( m + n - 1 + m - 1 + n - 2 ) ) return A [ i + n - 1 - ( k - ( m + n - 1 + m - 1 ) ) ] [ j + 0 ] ;
return findK ( A , i + 1 , j + 1 , n - 2 , m - 2 , k - ( 2 * n + 2 * m - 4 ) ) ; }
public static void main ( String args [ ] ) { int a [ ] [ ] = { { 1 , 2 , 3 , 4 , 5 , 6 } , { 7 , 8 , 9 , 10 , 11 , 12 } , { 13 , 14 , 15 , 16 , 17 , 18 } } ; int k = 17 ; System . out . println ( findK ( a , 0 , 0 , 3 , 6 , k ) ) ; } }
import java . io . * ; class GFG { public static int N = 5 ; public static int M = 4 ;
static boolean checkDiagonal ( int mat [ ] [ ] , int i , int j ) { int res = mat [ i ] [ j ] ; while ( ++ i < N && ++ j < M ) {
if ( mat [ i ] [ j ] != res ) return false ; }
return true ; }
static boolean isToepliz ( int mat [ ] [ ] ) {
for ( int i = 0 ; i < M ; i ++ ) {
if ( ! checkDiagonal ( mat , 0 , i ) ) return false ; }
for ( int i = 1 ; i < N ; i ++ ) {
if ( ! checkDiagonal ( mat , i , 0 ) ) return false ; }
return true ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 6 , 7 , 8 , 9 } , { 4 , 6 , 7 , 8 } , { 1 , 4 , 6 , 7 } , { 0 , 1 , 4 , 6 } , { 2 , 0 , 1 , 4 } } ;
if ( isToepliz ( mat ) ) System . out . println ( " Matrix ▁ is ▁ a ▁ Toepliz ▁ " ) ; else System . out . println ( " Matrix ▁ is ▁ not ▁ a ▁ Toepliz ▁ " ) ; } }
import java . io . * ; class GFG { public static int N = 5 ;
static int countZeroes ( int mat [ ] [ ] ) {
int row = N - 1 , col = 0 ;
int count = 0 ; while ( col < N ) {
while ( mat [ row ] [ col ] > 0 )
if ( -- row < 0 ) return count ;
count += ( row + 1 ) ;
col ++ ; } return count ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , 0 , 1 , 1 } , { 0 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 } } ; System . out . println ( countZeroes ( mat ) ) ; } }
import java . util . * ; import java . lang . * ; import java . io . * ; class GFG { static int countNegative ( int M [ ] [ ] , int n , int m ) { int count = 0 ;
for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < m ; j ++ ) { if ( M [ i ] [ j ] < 0 ) count += 1 ;
else break ; } } return count ; }
public static void main ( String [ ] args ) { int M [ ] [ ] = { { - 3 , - 2 , - 1 , 1 } , { - 2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; System . out . println ( countNegative ( M , 3 , 4 ) ) ; } }
static int countNegative ( int M [ ] [ ] , int n , int m ) {
int count = 0 ;
int i = 0 ; int j = m - 1 ;
while ( j >= 0 && i < n ) { if ( M [ i ] [ j ] < 0 ) {
count += j + 1 ;
i += 1 ; }
else j -= 1 ; } return count ; }
public static void main ( String [ ] args ) { int M [ ] [ ] = { { - 3 , - 2 , - 1 , 1 } , { - 2 , 2 , 3 , 4 } , { 4 , 5 , 7 , 8 } } ; System . out . println ( countNegative ( M , 3 , 4 ) ) ; } }
class Node { int data ; Node left , right ; Node ( int item ) { data = item ; left = right = null ; } } class BinaryTree { Node root ;
Node bintree2listUtil ( Node node ) {
if ( node == null ) return node ;
if ( node . left != null ) {
Node left = bintree2listUtil ( node . left ) ;
for ( ; left . right != null ; left = left . right ) ;
left . right = node ;
node . left = left ; }
if ( node . right != null ) {
Node right = bintree2listUtil ( node . right ) ;
for ( ; right . left != null ; right = right . left ) ;
right . left = node ;
node . right = right ; } return node ; }
Node bintree2list ( Node node ) {
if ( node == null ) return node ;
node = bintree2listUtil ( node ) ;
while ( node . left != null ) node = node . left ; return node ; }
void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . right ; } }
tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 12 ) ; tree . root . right = new Node ( 15 ) ; tree . root . left . left = new Node ( 25 ) ; tree . root . left . right = new Node ( 30 ) ; tree . root . right . left = new Node ( 36 ) ;
Node head = tree . bintree2list ( tree . root ) ;
tree . printList ( head ) ; } }
static int N = 10 ;
static int findLargestPlus ( int mat [ ] [ ] ) {
int left [ ] [ ] = new int [ N ] [ N ] ; int right [ ] [ ] = new int [ N ] [ N ] ; int top [ ] [ ] = new int [ N ] [ N ] ; int bottom [ ] [ ] = new int [ N ] [ N ] ;
for ( int i = 0 ; i < N ; i ++ ) {
top [ 0 ] [ i ] = mat [ 0 ] [ i ] ;
bottom [ N - 1 ] [ i ] = mat [ N - 1 ] [ i ] ;
left [ i ] [ 0 ] = mat [ i ] [ 0 ] ;
right [ i ] [ N - 1 ] = mat [ i ] [ N - 1 ] ; }
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 1 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] == 1 ) left [ i ] [ j ] = left [ i ] [ j - 1 ] + 1 ; else left [ i ] [ j ] = 0 ;
if ( mat [ j ] [ i ] == 1 ) top [ j ] [ i ] = top [ j - 1 ] [ i ] + 1 ; else top [ j ] [ i ] = 0 ;
j = N - 1 - j ;
if ( mat [ j ] [ i ] == 1 ) bottom [ j ] [ i ] = bottom [ j + 1 ] [ i ] + 1 ; else bottom [ j ] [ i ] = 0 ;
if ( mat [ i ] [ j ] == 1 ) right [ i ] [ j ] = right [ i ] [ j + 1 ] + 1 ; else right [ i ] [ j ] = 0 ;
j = N - 1 - j ; } }
int n = 0 ;
for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) {
int len = Math . min ( Math . min ( top [ i ] [ j ] , bottom [ i ] [ j ] ) , Math . min ( left [ i ] [ j ] , right [ i ] [ j ] ) ) ;
if ( len > n ) n = len ; } }
if ( n > 0 ) return 4 * ( n - 1 ) + 1 ;
return 0 ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 1 , 1 } , { 1 , 0 , 1 , 0 , 1 , 1 , 1 , 0 , 1 , 1 } , { 1 , 1 , 1 , 0 , 1 , 1 , 0 , 1 , 0 , 1 } , { 0 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 } , { 1 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 } , { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 0 } , { 1 , 0 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 0 , 1 , 1 } , { 1 , 1 , 0 , 0 , 1 , 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 } } ; System . out . println ( findLargestPlus ( mat ) ) ; } }
import java . io . * ; class GFG {
static StringBuilder findLeft ( StringBuilder str ) { int n = str . length ( ) ;
while ( n > 0 ) { n -- ;
if ( str . charAt ( n ) == ' d ' ) { str . setCharAt ( n , ' c ' ) ; break ; } if ( str . charAt ( n ) == ' b ' ) { str . setCharAt ( n , ' a ' ) ; break ; }
if ( str . charAt ( n ) == ' a ' ) str . setCharAt ( n , ' b ' ) ; else if ( str . charAt ( n ) == ' c ' ) str . setCharAt ( n , ' d ' ) ; } return str ; }
public static void main ( String [ ] args ) { StringBuilder str = new StringBuilder ( " aacbddc " ) ; System . out . print ( " Left ▁ of ▁ " + str + " ▁ is ▁ " + findLeft ( str ) ) ; } }
static void printSpiral ( int n ) { for ( int i = 0 ; i < n ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
int x ;
x = Math . min ( Math . min ( i , j ) , Math . min ( n - 1 - i , n - 1 - j ) ) ;
if ( i <= j ) System . out . print ( ( n - 2 * x ) * ( n - 2 * x ) - ( i - x ) - ( j - x ) + " TABSYMBOL " ) ;
else System . out . print ( ( n - 2 * x - 2 ) * ( n - 2 * x - 2 ) + ( i - x ) + ( j - x ) + " TABSYMBOL " ) ; } System . out . println ( ) ; } }
public static void main ( String args [ ] ) { int n = 5 ;
printSpiral ( n ) ; } }
static int findMaxValue ( int N , int mat [ ] [ ] ) {
int maxValue = Integer . MIN_VALUE ;
for ( int a = 0 ; a < N - 1 ; a ++ ) for ( int b = 0 ; b < N - 1 ; b ++ ) for ( int d = a + 1 ; d < N ; d ++ ) for ( int e = b + 1 ; e < N ; e ++ ) if ( maxValue < ( mat [ d ] [ e ] - mat [ a ] [ b ] ) ) maxValue = mat [ d ] [ e ] - mat [ a ] [ b ] ; return maxValue ; }
public static void main ( String [ ] args ) { int N = 5 ; int mat [ ] [ ] = { { 1 , 2 , - 1 , - 4 , - 20 } , { - 8 , - 3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { - 4 , - 1 , 1 , 7 , - 6 } , { 0 , - 4 , 10 , - 5 , 1 } } ; System . out . print ( " Maximum ▁ Value ▁ is ▁ " + findMaxValue ( N , mat ) ) ; } }
static int findMaxValue ( int N , int mat [ ] [ ] ) {
int maxValue = Integer . MIN_VALUE ;
int maxArr [ ] [ ] = new int [ N ] [ N ] ;
maxArr [ N - 1 ] [ N - 1 ] = mat [ N - 1 ] [ N - 1 ] ;
int maxv = mat [ N - 1 ] [ N - 1 ] ; for ( int j = N - 2 ; j >= 0 ; j -- ) { if ( mat [ N - 1 ] [ j ] > maxv ) maxv = mat [ N - 1 ] [ j ] ; maxArr [ N - 1 ] [ j ] = maxv ; }
maxv = mat [ N - 1 ] [ N - 1 ] ; for ( int i = N - 2 ; i >= 0 ; i -- ) { if ( mat [ i ] [ N - 1 ] > maxv ) maxv = mat [ i ] [ N - 1 ] ; maxArr [ i ] [ N - 1 ] = maxv ; }
for ( int i = N - 2 ; i >= 0 ; i -- ) { for ( int j = N - 2 ; j >= 0 ; j -- ) {
if ( maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] > maxValue ) maxValue = maxArr [ i + 1 ] [ j + 1 ] - mat [ i ] [ j ] ;
maxArr [ i ] [ j ] = Math . max ( mat [ i ] [ j ] , Math . max ( maxArr [ i ] [ j + 1 ] , maxArr [ i + 1 ] [ j ] ) ) ; } } return maxValue ; }
public static void main ( String [ ] args ) { int N = 5 ; int mat [ ] [ ] = { { 1 , 2 , - 1 , - 4 , - 20 } , { - 8 , - 3 , 4 , 2 , 1 } , { 3 , 8 , 6 , 1 , 3 } , { - 4 , - 1 , 1 , 7 , - 6 } , { 0 , - 4 , 10 , - 5 , 1 } } ; System . out . print ( " Maximum ▁ Value ▁ is ▁ " + findMaxValue ( N , mat ) ) ; } }
class GFG { public static void modifyMatrix ( int mat [ ] [ ] , int R , int C ) { int row [ ] = new int [ R ] ; int col [ ] = new int [ C ] ; int i , j ;
for ( i = 0 ; i < R ; i ++ ) { row [ i ] = 0 ; }
for ( i = 0 ; i < C ; i ++ ) { col [ i ] = 0 ; }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( mat [ i ] [ j ] == 1 ) { row [ i ] = 1 ; col [ j ] = 1 ; } } }
for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { if ( row [ i ] == 1 col [ j ] == 1 ) { mat [ i ] [ j ] = 1 ; } } } }
public static void printMatrix ( int mat [ ] [ ] , int R , int C ) { int i , j ; for ( i = 0 ; i < R ; i ++ ) { for ( j = 0 ; j < C ; j ++ ) { System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; } System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 0 , 0 , 1 } , { 0 , 0 , 1 , 0 } , { 0 , 0 , 0 , 0 } , } ; System . out . println ( " Matrix ▁ Intially " ) ; printMatrix ( mat , 3 , 4 ) ; modifyMatrix ( mat , 3 , 4 ) ; System . out . println ( " Matrix ▁ after ▁ modification ▁ n " ) ; printMatrix ( mat , 3 , 4 ) ; } }
class GFG { static int ROW = 4 ; static int COL = 5 ;
static void findUniqueRows ( int M [ ] [ ] ) {
for ( int i = 0 ; i < ROW ; i ++ ) { int flag = 0 ;
for ( int j = 0 ; j < i ; j ++ ) { flag = 1 ; for ( int k = 0 ; k < COL ; k ++ ) if ( M [ i ] [ k ] != M [ j ] [ k ] ) flag = 0 ; if ( flag == 1 ) break ; }
if ( flag == 0 ) {
for ( int j = 0 ; j < COL ; j ++ ) System . out . print ( M [ i ] [ j ] + " ▁ " ) ; System . out . println ( ) ; } } }
public static void main ( String [ ] args ) { int M [ ] [ ] = { { 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 1 , 0 } , { 0 , 1 , 0 , 0 , 1 } , { 1 , 0 , 1 , 0 , 0 } } ; findUniqueRows ( M ) ; } }
static class node { int data ; node left , right ; public node ( int data ) { this . data = data ; } } static node prev ;
static void inorder ( node root ) { if ( root == null ) return ; inorder ( root . left ) ; System . out . print ( root . data + " ▁ " ) ; inorder ( root . right ) ; }
static void fixPrevptr ( node root ) { if ( root == null ) return ; fixPrevptr ( root . left ) ; root . left = prev ; prev = root ; fixPrevptr ( root . right ) ; }
static node fixNextptr ( node root ) {
while ( root . right != null ) root = root . right ;
while ( root != null && root . left != null ) { node left = root . left ; left . right = root ; root = root . left ; }
return root ; }
static node BTTtoDLL ( node root ) { prev = null ;
fixPrevptr ( root ) ;
return fixNextptr ( root ) ; }
static void printlist ( node root ) { while ( root != null ) { System . out . print ( root . data + " ▁ " ) ; root = root . right ; } }
node root = new node ( 10 ) ; root . left = new node ( 12 ) ; root . right = new node ( 15 ) ; root . left . left = new node ( 25 ) ; root . left . right = new node ( 30 ) ; root . right . left = new node ( 36 ) ; System . out . println ( " Inorder ▁ Tree ▁ Traversal " ) ; inorder ( root ) ; node head = BTTtoDLL ( root ) ; System . out . println ( " DLL Traversal "); printlist ( head ) ; } }
class GFG { static final int R = 3 ; static final int C = 3 ;
static void swap ( int mat [ ] [ ] , int row1 , int row2 , int col ) { for ( int i = 0 ; i < col ; i ++ ) { int temp = mat [ row1 ] [ i ] ; mat [ row1 ] [ i ] = mat [ row2 ] [ i ] ; mat [ row2 ] [ i ] = temp ; } }
static int rankOfMatrix ( int mat [ ] [ ] ) { int rank = C ; for ( int row = 0 ; row < rank ; row ++ ) {
if ( mat [ row ] [ row ] != 0 ) { for ( int col = 0 ; col < R ; col ++ ) { if ( col != row ) {
double mult = ( double ) mat [ col ] [ row ] / mat [ row ] [ row ] ; for ( int i = 0 ; i < rank ; i ++ ) mat [ col ] [ i ] -= mult * mat [ row ] [ i ] ; } } }
else { boolean reduce = true ;
for ( int i = row + 1 ; i < R ; i ++ ) {
if ( mat [ i ] [ row ] != 0 ) { swap ( mat , row , i , rank ) ; reduce = false ; break ; } }
if ( reduce ) {
rank -- ;
for ( int i = 0 ; i < R ; i ++ ) mat [ i ] [ row ] = mat [ i ] [ rank ] ; }
row -- ; }
} return rank ; }
static void display ( int mat [ ] [ ] , int row , int col ) { for ( int i = 0 ; i < row ; i ++ ) { for ( int j = 0 ; j < col ; j ++ ) System . out . print ( " ▁ " + mat [ i ] [ j ] ) ; System . out . print ( "NEW_LINE"); } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 10 , 20 , 10 } , { - 20 , - 30 , 10 } , { 30 , 50 , 0 } } ; System . out . print ( " Rank ▁ of ▁ the ▁ matrix ▁ is ▁ : ▁ " + rankOfMatrix ( mat ) ) ; } }
class GFG { static int R = 3 ; static int C = 3 ;
static class Cell {
public Cell ( int r , int c ) { this . r = r ; this . c = c ; } } ;
static void printSums ( int mat [ ] [ ] , Cell arr [ ] , int n ) {
for ( int i = 0 ; i < n ; i ++ ) { int sum = 0 , r = arr [ i ] . r , c = arr [ i ] . c ;
for ( int j = 0 ; j < R ; j ++ ) { for ( int k = 0 ; k < C ; k ++ ) { if ( j != r && k != c ) { sum += mat [ j ] [ k ] ; } } } System . out . println ( sum ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 1 , 2 } , { 3 , 4 , 6 } , { 5 , 3 , 2 } } ; Cell arr [ ] = { new Cell ( 0 , 0 ) , new Cell ( 1 , 1 ) , new Cell ( 0 , 1 ) } ; int n = arr . length ; printSums ( mat , arr , n ) ; } }
static int countIslands ( int mat [ ] [ ] , int m , int n ) {
int count = 0 ;
for ( int i = 0 ; i < m ; i ++ ) { for ( int j = 0 ; j < n ; j ++ ) {
if ( mat [ i ] [ j ] == ' X ' ) { if ( ( i == 0 mat [ i - 1 ] [ j ] == ' O ' ) && ( j == 0 mat [ i ] [ j - 1 ] == ' O ' ) ) count ++ ; } } } return count ; }
public static void main ( String [ ] args ) { int m = 6 ; int n = 3 ; int mat [ ] [ ] = { { ' O ' , ' O ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' X ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' } , { ' O ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' O ' } } ; System . out . println ( " Number ▁ of ▁ rectangular ▁ islands ▁ is : ▁ " + countIslands ( mat , m , n ) ) ; } }
static final int M = 4 ; static final int N = 5 ;
static int findCommon ( int mat [ ] [ ] ) {
int column [ ] = new int [ M ] ;
int min_row ;
int i ; for ( i = 0 ; i < M ; i ++ ) column [ i ] = N - 1 ;
min_row = 0 ;
while ( column [ min_row ] >= 0 ) {
for ( i = 0 ; i < M ; i ++ ) { if ( mat [ i ] [ column [ i ] ] < mat [ min_row ] [ column [ min_row ] ] ) min_row = i ; }
int eq_count = 0 ;
for ( i = 0 ; i < M ; i ++ ) {
if ( mat [ i ] [ column [ i ] ] > mat [ min_row ] [ column [ min_row ] ] ) { if ( column [ i ] == 0 ) return - 1 ;
column [ i ] -= 1 ; } else eq_count ++ ; }
if ( eq_count == M ) return mat [ min_row ] [ column [ min_row ] ] ; } return - 1 ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 , 4 , 5 } , { 2 , 4 , 5 , 8 , 10 } , { 3 , 5 , 7 , 9 , 11 } , { 1 , 3 , 5 , 7 , 9 } } ; int result = findCommon ( mat ) ; if ( result == - 1 ) System . out . print ( " No ▁ common ▁ element " ) ; else System . out . print ( " Common ▁ element ▁ is ▁ " + result ) ; } }
static int M = 4 ; static int N = 5 ;
static int findCommon ( int mat [ ] [ ] ) {
HashMap < Integer , Integer > cnt = new HashMap < Integer , Integer > ( ) ; int i , j ; for ( i = 0 ; i < M ; i ++ ) {
if ( cnt . containsKey ( mat [ i ] [ 0 ] ) ) { cnt . put ( mat [ i ] [ 0 ] , cnt . get ( mat [ i ] [ 0 ] ) + 1 ) ; } else { cnt . put ( mat [ i ] [ 0 ] , 1 ) ; }
for ( j = 1 ; j < N ; j ++ ) {
if ( mat [ i ] [ j ] != mat [ i ] [ j - 1 ] ) if ( cnt . containsKey ( mat [ i ] [ j ] ) ) { cnt . put ( mat [ i ] [ j ] , cnt . get ( mat [ i ] [ j ] ) + 1 ) ; } else { cnt . put ( mat [ i ] [ j ] , 1 ) ; } } }
for ( Map . Entry < Integer , Integer > ele : cnt . entrySet ( ) ) { if ( ele . getValue ( ) == M ) return ele . getKey ( ) ; }
return - 1 ; }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 2 , 3 , 4 , 5 } , { 2 , 4 , 5 , 8 , 10 } , { 3 , 5 , 7 , 9 , 11 } , { 1 , 3 , 5 , 7 , 9 } } ; int result = findCommon ( mat ) ; if ( result == - 1 ) System . out . println ( " No ▁ common ▁ element " ) ; else System . out . println ( " Common ▁ element ▁ is ▁ " + result ) ; } }
static int M = 6 ; static int N = 6 ;
static void floodFillUtil ( char mat [ ] [ ] , int x , int y , char prevV , char newV ) {
if ( x < 0 x >= M y < 0 y >= N ) return ; if ( mat [ x ] [ y ] != prevV ) return ;
mat [ x ] [ y ] = newV ;
floodFillUtil ( mat , x + 1 , y , prevV , newV ) ; floodFillUtil ( mat , x - 1 , y , prevV , newV ) ; floodFillUtil ( mat , x , y + 1 , prevV , newV ) ; floodFillUtil ( mat , x , y - 1 , prevV , newV ) ; }
static void replaceSurrounded ( char mat [ ] [ ] ) {
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' O ' ) mat [ i ] [ j ] = ' - ' ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ 0 ] == ' - ' ) floodFillUtil ( mat , i , 0 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) if ( mat [ i ] [ N - 1 ] == ' - ' ) floodFillUtil ( mat , i , N - 1 , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ 0 ] [ i ] == ' - ' ) floodFillUtil ( mat , 0 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < N ; i ++ ) if ( mat [ M - 1 ] [ i ] == ' - ' ) floodFillUtil ( mat , M - 1 , i , ' - ' , ' O ' ) ;
for ( int i = 0 ; i < M ; i ++ ) for ( int j = 0 ; j < N ; j ++ ) if ( mat [ i ] [ j ] == ' - ' ) mat [ i ] [ j ] = ' X ' ; }
public static void main ( String [ ] args ) { char [ ] [ ] mat = { { ' X ' , ' O ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' X ' , ' O ' , ' X ' , ' X ' , ' O ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' X ' } , { ' O ' , ' X ' , ' X ' , ' X ' , ' X ' , ' X ' } , { ' X ' , ' X ' , ' X ' , ' O ' , ' X ' , ' O ' } , { ' O ' , ' O ' , ' X ' , ' O ' , ' O ' , ' O ' } } ; replaceSurrounded ( mat ) ; for ( int i = 0 ; i < M ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) System . out . print ( mat [ i ] [ j ] + " ▁ " ) ; System . out . println ( " " ) ; } } }
class Node { int data ; Node left , right ; public Node ( int data ) { this . data = data ; left = right = null ; } } class BinaryTree { Node root ;
Node head ;
void BinaryTree2DoubleLinkedList ( Node root ) {
if ( root == null ) return ;
static Node prev = null ;
BinaryTree2DoubleLinkedList ( root . left ) ;
if ( prev == null ) head = root ; else { root . left = prev ; prev . right = root ; } prev = root ;
BinaryTree2DoubleLinkedList ( root . right ) ; }
void printList ( Node node ) { while ( node != null ) { System . out . print ( node . data + " ▁ " ) ; node = node . right ; } }
BinaryTree tree = new BinaryTree ( ) ; tree . root = new Node ( 10 ) ; tree . root . left = new Node ( 12 ) ; tree . root . right = new Node ( 15 ) ; tree . root . left . left = new Node ( 25 ) ; tree . root . left . right = new Node ( 30 ) ; tree . root . right . left = new Node ( 36 ) ;
tree . BinaryTree2DoubleLinkedList ( tree . root ) ;
tree . printList ( tree . head ) ; } }
class GFG { static final int INF = Integer . MAX_VALUE ; static final int N = 4 ;
static void youngify ( int mat [ ] [ ] , int i , int j ) {
int downVal = ( i + 1 < N ) ? mat [ i + 1 ] [ j ] : INF ; int rightVal = ( j + 1 < N ) ? mat [ i ] [ j + 1 ] : INF ;
if ( downVal == INF && rightVal == INF ) { return ; }
if ( downVal < rightVal ) { mat [ i ] [ j ] = downVal ; mat [ i + 1 ] [ j ] = INF ; youngify ( mat , i + 1 , j ) ; } else { mat [ i ] [ j ] = rightVal ; mat [ i ] [ j + 1 ] = INF ; youngify ( mat , i , j + 1 ) ; } }
static int extractMin ( int mat [ ] [ ] ) { int ret = mat [ 0 ] [ 0 ] ; mat [ 0 ] [ 0 ] = INF ; youngify ( mat , 0 , 0 ) ; return ret ; }
static void printSorted ( int mat [ ] [ ] ) { System . out . println ( " Elements ▁ of ▁ matrix ▁ in ▁ sorted ▁ order ▁ n " ) ; for ( int i = 0 ; i < N * N ; i ++ ) { System . out . print ( extractMin ( mat ) + " ▁ " ) ; } }
static final int n = 5 ;
static void printSumSimple ( int mat [ ] [ ] , int k ) {
if ( k > n ) return ;
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
for ( int j = 0 ; j < n - k + 1 ; j ++ ) {
int sum = 0 ; for ( int p = i ; p < k + i ; p ++ ) for ( int q = j ; q < k + j ; q ++ ) sum += mat [ p ] [ q ] ; System . out . print ( sum + " ▁ " ) ; }
System . out . println ( ) ; } }
public static void main ( String arg [ ] ) { int mat [ ] [ ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } } ; int k = 3 ; printSumSimple ( mat , k ) ; } }
static int n = 5 ;
static void printSumTricky ( int mat [ ] [ ] , int k ) {
if ( k > n ) return ;
int stripSum [ ] [ ] = new int [ n ] [ n ] ;
for ( int j = 0 ; j < n ; j ++ ) {
int sum = 0 ; for ( int i = 0 ; i < k ; i ++ ) sum += mat [ i ] [ j ] ; stripSum [ 0 ] [ j ] = sum ;
for ( int i = 1 ; i < n - k + 1 ; i ++ ) { sum += ( mat [ i + k - 1 ] [ j ] - mat [ i - 1 ] [ j ] ) ; stripSum [ i ] [ j ] = sum ; } }
for ( int i = 0 ; i < n - k + 1 ; i ++ ) {
int sum = 0 ; for ( int j = 0 ; j < k ; j ++ ) sum += stripSum [ i ] [ j ] ; System . out . print ( sum + " ▁ " ) ;
for ( int j = 1 ; j < n - k + 1 ; j ++ ) { sum += ( stripSum [ i ] [ j + k - 1 ] - stripSum [ i ] [ j - 1 ] ) ; System . out . print ( sum + " ▁ " ) ; } System . out . println ( ) ; } }
public static void main ( String [ ] args ) { int mat [ ] [ ] = { { 1 , 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 , 4 } , { 5 , 5 , 5 , 5 , 5 } , } ; int k = 3 ; printSumTricky ( mat , k ) ; } }
class GFG { static final int M = 3 ; static final int N = 4 ;
static void transpose ( int A [ ] [ ] , int B [ ] [ ] ) { int i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < M ; j ++ ) B [ i ] [ j ] = A [ j ] [ i ] ; }
public static void main ( String [ ] args ) { int A [ ] [ ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } } ; int B [ ] [ ] = new int [ N ] [ M ] , i , j ; transpose ( A , B ) ; System . out . print ( "Result matrix is NEW_LINE"); for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < M ; j ++ ) System . out . print ( B [ i ] [ j ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); } } }
class GFG { static final int N = 4 ;
static void transpose ( int A [ ] [ ] ) { for ( int i = 0 ; i < N ; i ++ ) for ( int j = i + 1 ; j < N ; j ++ ) { int temp = A [ i ] [ j ] ; A [ i ] [ j ] = A [ j ] [ i ] ; A [ j ] [ i ] = temp ; } }
public static void main ( String [ ] args ) { int A [ ] [ ] = { { 1 , 1 , 1 , 1 } , { 2 , 2 , 2 , 2 } , { 3 , 3 , 3 , 3 } , { 4 , 4 , 4 , 4 } } ; transpose ( A ) ; System . out . print ( "Modified matrix is NEW_LINE"); for ( int i = 0 ; i < N ; i ++ ) { for ( int j = 0 ; j < N ; j ++ ) System . out . print ( A [ i ] [ j ] + " ▁ " ) ; System . out . print ( "NEW_LINE"); } } }
class GFG { static final int R = 5 ; static final int C = 4 ;
static boolean isValid ( int x , int y1 , int y2 ) { return ( x >= 0 && x < R && y1 >= 0 && y1 < C && y2 >= 0 && y2 < C ) ; }
static int getMaxUtil ( int arr [ ] [ ] , int mem [ ] [ ] [ ] , int x , int y1 , int y2 ) {
if ( ! isValid ( x , y1 , y2 ) ) return Integer . MIN_VALUE ;
if ( x == R - 1 && y1 == 0 && y2 == C - 1 ) return ( y1 == y2 ) ? arr [ x ] [ y1 ] : arr [ x ] [ y1 ] + arr [ x ] [ y2 ] ;
if ( x == R - 1 ) return Integer . MIN_VALUE ;
if ( mem [ x ] [ y1 ] [ y2 ] != - 1 ) return mem [ x ] [ y1 ] [ y2 ] ;
int ans = Integer . MIN_VALUE ;
int temp = ( y1 == y2 ) ? arr [ x ] [ y1 ] : arr [ x ] [ y1 ] + arr [ x ] [ y2 ] ;
ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 - 1 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 + 1 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 , y2 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 - 1 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 - 1 , y2 + 1 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 - 1 ) ) ; ans = Math . max ( ans , temp + getMaxUtil ( arr , mem , x + 1 , y1 + 1 , y2 + 1 ) ) ; return ( mem [ x ] [ y1 ] [ y2 ] = ans ) ; }
static int geMaxCollection ( int arr [ ] [ ] ) {
int [ ] [ ] [ ] mem = new int [ R ] [ C ] [ C ] ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) { for ( int l = 0 ; l < C ; l ++ ) mem [ i ] [ j ] [ l ] = - 1 ; } }
return getMaxUtil ( arr , mem , 0 , 0 , C - 1 ) ; }
public static void main ( String [ ] args ) { int arr [ ] [ ] = { { 3 , 6 , 8 , 2 } , { 5 , 2 , 4 , 3 } , { 1 , 1 , 20 , 10 } , { 1 , 1 , 20 , 10 } , { 1 , 1 , 20 , 10 } , } ; System . out . print ( " Maximum ▁ collection ▁ is ▁ " + geMaxCollection ( arr ) ) ; } }
class GFG { static final int R = 3 ; static final int C = 3 ;
static int pathCountRec ( int mat [ ] [ ] , int m , int n , int k ) {
if ( m < 0 n < 0 ) { return 0 ; } if ( m == 0 && n == 0 && ( k == mat [ m ] [ n ] ) ) { return 1 ; }
return pathCountRec ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountRec ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; }
static int pathCount ( int mat [ ] [ ] , int k ) { return pathCountRec ( mat , R - 1 , C - 1 , k ) ; }
public static void main ( String [ ] args ) { int k = 12 ; int mat [ ] [ ] = { { 1 , 2 , 3 } , { 4 , 6 , 5 } , { 3 , 2 , 1 } } ; System . out . println ( pathCount ( mat , k ) ) ; } }
class GFG { static final int R = 3 ; static final int C = 3 ; static final int MAX_K = 100 ; static int [ ] [ ] [ ] dp = new int [ R ] [ C ] [ MAX_K ] ; static int pathCountDPRecDP ( int [ ] [ ] mat , int m , int n , int k ) {
if ( m < 0 n < 0 ) return 0 ; if ( m == 0 && n == 0 ) return ( k == mat [ m ] [ n ] ? 1 : 0 ) ;
if ( dp [ m ] [ n ] [ k ] != - 1 ) return dp [ m ] [ n ] [ k ] ;
dp [ m ] [ n ] [ k ] = pathCountDPRecDP ( mat , m - 1 , n , k - mat [ m ] [ n ] ) + pathCountDPRecDP ( mat , m , n - 1 , k - mat [ m ] [ n ] ) ; return dp [ m ] [ n ] [ k ] ; }
static int pathCountDP ( int [ ] [ ] mat , int k ) { for ( int i = 0 ; i < R ; i ++ ) for ( int j = 0 ; j < C ; j ++ ) for ( int l = 0 ; l < MAX_K ; l ++ ) dp [ i ] [ j ] [ l ] = - 1 ; return pathCountDPRecDP ( mat , R - 1 , C - 1 , k ) ; }
public static void main ( String [ ] args ) { int k = 12 ; int [ ] [ ] mat = new int [ ] [ ] { new int [ ] { 1 , 2 , 3 } , new int [ ] { 4 , 6 , 5 } , new int [ ] { 3 , 2 , 1 } } ; System . out . println ( pathCountDP ( mat , k ) ) ; } }
static int x [ ] = { 0 , 1 , 1 , - 1 , 1 , 0 , - 1 , - 1 } ; static int y [ ] = { 1 , 0 , 1 , 1 , - 1 , - 1 , 0 , - 1 } ; static int R = 3 ; static int C = 3 ;
static int dp [ ] [ ] = new int [ R ] [ C ] ;
static boolean isvalid ( int i , int j ) { if ( i < 0 j < 0 i >= R j >= C ) return false ; return true ; }
static boolean isadjacent ( char prev , char curr ) { return ( ( curr - prev ) == 1 ) ; }
static int getLenUtil ( char mat [ ] [ ] , int i , int j , char prev ) {
if ( ! isvalid ( i , j ) || ! isadjacent ( prev , mat [ i ] [ j ] ) ) return 0 ;
if ( dp [ i ] [ j ] != - 1 ) return dp [ i ] [ j ] ;
int ans = 0 ;
for ( int k = 0 ; k < 8 ; k ++ ) ans = Math . max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , mat [ i ] [ j ] ) ) ;
return dp [ i ] [ j ] = ans ; }
static int getLen ( char mat [ ] [ ] , char s ) { for ( int i = 0 ; i < R ; ++ i ) for ( int j = 0 ; j < C ; ++ j ) dp [ i ] [ j ] = - 1 ; int ans = 0 ; for ( int i = 0 ; i < R ; i ++ ) { for ( int j = 0 ; j < C ; j ++ ) {
if ( mat [ i ] [ j ] == s ) {
for ( int k = 0 ; k < 8 ; k ++ ) ans = Math . max ( ans , 1 + getLenUtil ( mat , i + x [ k ] , j + y [ k ] , s ) ) ; } } } return ans ; }
public static void main ( String args [ ] ) { char mat [ ] [ ] = { { ' a ' , ' c ' , ' d ' } , { ' h ' , ' b ' , ' a ' } , { ' i ' , ' g ' , ' f ' } } ; System . out . println ( getLen ( mat , ' a ' ) ) ; System . out . println ( getLen ( mat , ' e ' ) ) ; System . out . println ( getLen ( mat , ' b ' ) ) ; System . out . println ( getLen ( mat , ' f ' ) ) ; } }
