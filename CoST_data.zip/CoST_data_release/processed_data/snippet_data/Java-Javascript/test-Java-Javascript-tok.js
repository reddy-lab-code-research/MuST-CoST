function printNGE ( arr , n ) { var next , i , j ; for ( i = 0 ; i < n ; i ++ ) { next = - 1 ; for ( j = i + 1 ; j < n ; j ++ ) { if ( arr [ i ] < arr [ j ] ) { next = arr [ j ] ; break ; } } document . write ( arr [ i ] + " " + next ) ; document . write ( " " ) ; } }
var arr = [ 11 , 13 , 21 , 3 ] ; var n = arr . length ; printNGE ( arr , n ) ;
function findMin ( arr , low , high ) {
if ( high < low ) return arr [ 0 ] ;
if ( high == low ) return arr [ low ] ;
let mid = low + Math . floor ( ( high - low ) / 2 ) ;
if ( mid < high && arr [ mid + 1 ] < arr [ mid ] ) return arr [ mid + 1 ] ;
if ( mid > low && arr [ mid ] < arr [ mid - 1 ] ) return arr [ mid ] ;
if ( arr [ high ] > arr [ mid ] ) return findMin ( arr , low , mid - 1 ) ; return findMin ( arr , mid + 1 , high ) ; }
let arr1 = [ 5 , 6 , 1 , 2 , 3 , 4 ] ; let n1 = arr1 . length ; document . write ( " " + findMin ( arr1 , 0 , n1 - 1 ) + " " ) ; let arr2 = [ 1 , 2 , 3 , 4 ] ; let n2 = arr2 . length ; document . write ( " " + findMin ( arr2 , 0 , n2 - 1 ) + " " ) ; let arr3 = [ 1 ] ; let n3 = arr3 . length ; document . write ( " " + findMin ( arr3 , 0 , n3 - 1 ) + " " ) ; let arr4 = [ 1 , 2 ] ; let n4 = arr4 . length ; document . write ( " " + findMin ( arr4 , 0 , n4 - 1 ) + " " ) ; let arr5 = [ 2 , 1 ] ; let n5 = arr5 . length ; document . write ( " " + findMin ( arr5 , 0 , n5 - 1 ) + " " ) ; let arr6 = [ 5 , 6 , 7 , 1 , 2 , 3 , 4 ] ; let n6 = arr6 . length ; document . write ( " " + findMin ( arr6 , 0 , n6 - 1 ) + " " ) ; let arr7 = [ 1 , 2 , 3 , 4 , 5 , 6 , 7 ] ; let n7 = arr7 . length ; document . write ( " " + findMin ( arr7 , 0 , n7 - 1 ) + " " ) ; let arr8 = [ 2 , 3 , 4 , 5 , 6 , 7 , 8 , 1 ] ; let n8 = arr8 . length ; document . write ( " " + findMin ( arr8 , 0 , n8 - 1 ) + " " ) ; let arr9 = [ 3 , 4 , 5 , 1 , 2 ] ; let n9 = arr9 . length ; document . write ( " " + findMin ( arr9 , 0 , n9 - 1 ) + " " ) ;
function print2largest ( arr , arr_size ) { let i ; let largest = second = - 2454635434 ;
if ( arr_size < 2 ) { document . write ( " " ) ; return ; } for ( i = 0 ; i < arr_size ; i ++ ) {
if ( arr [ i ] > largest ) { second = largest ; largest = arr [ i ] }
else if ( arr [ i ] != largest && arr [ i ] > second ) { second = arr [ i ] ; } } if ( second == - 2454635434 ) { document . write ( " " ) ; } else { document . write ( " " + second ) ; return ; } }
let arr = [ 12 , 35 , 1 , 10 , 34 , 1 ] ; let n = arr . length ; print2largest ( arr , n ) ;
function FindMaxSum ( arr , n ) { let incl = arr [ 0 ] ; let excl = 0 ; let excl_new ; let i ; for ( i = 1 ; i < n ; i ++ ) {
excl_new = ( incl > excl ) ? incl : excl ;
incl = excl + arr [ i ] ; excl = excl_new ; }
return ( ( incl > excl ) ? incl : excl ) ; }
let arr = [ 5 , 5 , 10 , 100 , 10 , 5 ] ; document . write ( FindMaxSum ( arr , arr . length ) ) ;
function minJumps ( arr , n ) {
if ( n == 1 ) return 0 ;
let res = Number . MAX_VALUE ; for ( let i = n - 2 ; i >= 0 ; i -- ) { if ( i + arr [ i ] >= n - 1 ) { let sub_res = minJumps ( arr , i + 1 ) ; if ( sub_res != Number . MAX_VALUE ) res = Math . min ( res , sub_res + 1 ) ; } } return res ; }
let arr = [ 1 , 3 , 6 , 3 , 2 , 3 , 6 , 8 , 9 , 5 ] ; let n = arr . length ; document . write ( " " ) ; document . write ( " " + minJumps ( arr , n ) ) ;
function maxSumIS ( arr , n ) { let i , j , max = 0 ; let msis = new Array ( n ) ;
for ( i = 0 ; i < n ; i ++ ) msis [ i ] = arr [ i ] ;
for ( i = 1 ; i < n ; i ++ ) for ( j = 0 ; j < i ; j ++ ) if ( arr [ i ] > arr [ j ] && msis [ i ] < msis [ j ] + arr [ i ] ) msis [ i ] = msis [ j ] + arr [ i ] ;
for ( i = 0 ; i < n ; i ++ ) if ( max < msis [ i ] ) max = msis [ i ] ; return max ; }
let arr = [ 1 , 101 , 2 , 3 , 100 , 4 , 5 ] ; let n = arr . length ; document . write ( " " + " " + maxSumIS ( arr , n ) ) ;
function moveToEnd ( mPlusN , size ) { let i = 0 ; let j = size - 1 ; for ( i = size - 1 ; i >= 0 ; i -- ) { if ( mPlusN [ i ] != - 1 ) { mPlusN [ j ] = mPlusN [ i ] ; j -- ; } } }
function merge ( mPlusN , N , m , n ) { let i = n ;
let j = 0 ;
let k = 0 ;
while ( k < ( m + n ) ) {
if ( ( i < ( m + n ) && mPlusN [ i ] <= N [ j ] ) || ( j == n ) ) { mPlusN [ k ] = mPlusN [ i ] ; k ++ ; i ++ ; }
else { mPlusN [ k ] = N [ j ] ; k ++ ; j ++ ; } } }
function printArray ( arr , size ) { let i = 0 ; for ( i = 0 ; i < size ; i ++ ) { document . write ( arr [ i ] + " " ) ; } document . write ( " " ) ; }
let mPlusN = [ 2 , 8 , - 1 , - 1 , - 1 , 13 , - 1 , 15 , 20 ] ; let N = [ 5 , 7 , 9 , 25 ] let n = N . length ; let m = mPlusN . length - n ;
moveToEnd ( mPlusN , m + n ) ;
merge ( mPlusN , N , m , n ) ;
printArray ( mPlusN , m + n ) ;
function minAbsSumPair ( arr , arr_size ) { var inv_count = 0 ; var l , r , min_sum , sum , min_l , min_r ;
if ( arr_size < 2 ) { document . write ( " " ) ; return ; }
min_l = 0 ; min_r = 1 ; min_sum = arr [ 0 ] + arr [ 1 ] ; for ( l = 0 ; l < arr_size - 1 ; l ++ ) { for ( r = l + 1 ; r < arr_size ; r ++ ) { sum = arr [ l ] + arr [ r ] ; if ( Math . abs ( min_sum ) > Math . abs ( sum ) ) { min_sum = sum ; min_l = l ; min_r = r ; } } } document . write ( " " + arr [ min_l ] + " " + arr [ min_r ] ) ; }
arr = new Array ( 1 , 60 , - 10 , 70 , - 80 , 85 ) ; minAbsSumPair ( arr , 6 ) ;
function sort012 ( a , arr_size ) { let lo = 0 ; let hi = arr_size - 1 ; let mid = 0 ; let temp = 0 ; while ( mid <= hi ) { if ( a [ mid ] == 0 ) { temp = a [ lo ] ; a [ lo ] = a [ mid ] ; a [ mid ] = temp ; lo ++ ; mid ++ ; } else if ( a [ mid ] == 1 ) { mid ++ ; } else { temp = a [ mid ] ; a [ mid ] = a [ hi ] ; a [ hi ] = temp ; hi -- ; } } }
function printArray ( arr , arr_size ) { let i ; for ( i = 0 ; i < arr_size ; i ++ ) { document . write ( arr [ i ] + " " ) ; } document . write ( " " ) ; }
let arr = [ 0 , 1 , 1 , 0 , 1 , 2 , 1 , 2 , 0 , 0 , 0 , 1 ] ; let arr_size = arr . length ; sort012 ( arr , arr_size ) ; document . write ( " " ) printArray ( arr , arr_size ) ;
function findNumberOfTriangles ( arr ) { let n = arr . length ;
arr . sort ( ( a , b ) => a - b ) ;
let count = 0 ;
for ( let i = 0 ; i < n - 2 ; ++ i ) {
let k = i + 2 ;
for ( let j = i + 1 ; j < n ; ++ j ) {
while ( k < n && arr [ i ] + arr [ j ] > arr [ k ] ) ++ k ;
if ( k > j ) count += k - j - 1 ; } } return count ; }
let arr = [ 10 , 21 , 22 , 100 , 101 , 200 , 300 ] ; let size = arr . length ; document . write ( " " + findNumberOfTriangles ( arr , size ) ) ;
function binarySearch ( arr , low , high , key ) { if ( high < low ) return - 1 ;
let mid = Math . trunc ( ( low + high ) / 2 ) ; if ( key == arr [ mid ] ) return mid ; if ( key > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high , key ) ; return binarySearch ( arr , low , ( mid - 1 ) , key ) ; }
let arr = [ 5 , 6 , 7 , 8 , 9 , 10 ] ; let n , key ; n = arr . length ; key = 10 ; document . write ( " " + binarySearch ( arr , 0 , n - 1 , key ) + " " ) ;
function equilibrium ( arr , n ) { var i , j ; var leftsum , rightsum ;
for ( i = 0 ; i < n ; ++ i ) { leftsum = 0 ; rightsum = 0 ;
for ( let j = 0 ; j < i ; j ++ ) leftsum += arr [ j ] ;
for ( let j = i + 1 ; j < n ; j ++ ) rightsum += arr [ j ] ;
if ( leftsum == rightsum ) return i ; }
return - 1 ; }
var arr = new Array ( - 7 , 1 , 5 , 2 , - 4 , 3 , 0 ) ; n = arr . length ; document . write ( equilibrium ( arr , n ) ) ;
function ceilSearch ( arr , low , high , x ) { let mid ;
if ( x <= arr [ low ] ) return low ;
if ( x > arr [ high ] ) return - 1 ;
mid = ( low + high ) / 2 ;
if ( arr [ mid ] == x ) return mid ;
else if ( arr [ mid ] < x ) { if ( mid + 1 <= high && x <= arr [ mid + 1 ] ) return mid + 1 ; else return ceilSearch ( arr , mid + 1 , high , x ) ; }
else { if ( mid - 1 >= low && x > arr [ mid - 1 ] ) return mid ; else return ceilSearch ( arr , low , mid - 1 , x ) ; } }
let arr = [ 1 , 2 , 8 , 10 , 10 , 12 , 19 ] ; let n = arr . length ; let x = 20 ; let index = ceilSearch ( arr , 0 , n - 1 , x ) ; if ( index == - 1 ) { document . write ( ` ${ x } ` ) ; } else { document . write ( ` ${ x } ${ arr [ index ] } ` ) ; }
function findCandidate ( a , size ) { let maj_index = 0 , count = 1 ; let i ; for ( i = 1 ; i < size ; i ++ ) { if ( a [ maj_index ] == a [ i ] ) count ++ ; else count -- ; if ( count == 0 ) { maj_index = i ; count = 1 ; } } return a [ maj_index ] ; }
function isMajority ( a , size , cand ) { let i , count = 0 ; for ( i = 0 ; i < size ; i ++ ) { if ( a [ i ] == cand ) count ++ ; } if ( count > parseInt ( size / 2 , 10 ) ) return true ; else return false ; }
function printMajority ( a , size ) {
let cand = findCandidate ( a , size ) ;
if ( isMajority ( a , size , cand ) ) document . write ( " " + cand + " " ) ; else document . write ( " " ) ; }
let a = [ 1 , 3 , 3 , 1 , 2 ] ; let size = a . length ;
printMajority ( a , size ) ;
function printRepeating ( arr , size ) { var i , j ; document . write ( " " ) ; for ( i = 0 ; i < size ; i ++ ) { for ( j = i + 1 ; j < size ; j ++ ) { if ( arr [ i ] == arr [ j ] ) document . write ( arr [ i ] + " " ) ; } } }
var arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 1 ] ; var arr_size = arr . length ; printRepeating ( arr , arr_size ) ;
function printRepeating ( arr , size ) {
var S = 0 ;
var P = 1 ;
var x , y ;
var D ; var n = size - 2 , i ;
for ( i = 0 ; i < size ; i ++ ) { S = S + arr [ i ] ; P = P * arr [ i ] ; }
S = S - n * parseInt ( ( n + 1 ) / 2 ) ;
P = parseInt ( P / fact ( n ) ) ;
D = parseInt ( Math . sqrt ( S * S - 4 * P ) ) ; x = parseInt ( ( D + S ) / 2 ) ; y = parseInt ( ( S - D ) / 2 ) ; document . write ( " " ) ; document . write ( x + " " + y ) ; }
function fact ( n ) { var ans = false ; if ( n == 0 ) return 1 ; else return ( n * fact ( n - 1 ) ) ; }
var arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 1 ] ; var arr_size = arr . length ; printRepeating ( arr , arr_size ) ;
function printRepeating ( arr , size ) {
let Xor = arr [ 0 ] ;
let set_bit_no ; let i ; let n = size - 2 ; let x = 0 , y = 0 ;
for ( i = 1 ; i < size ; i ++ ) Xor ^= arr [ i ] ; for ( i = 1 ; i <= n ; i ++ ) Xor ^= i ;
set_bit_no = Xor & ~ ( Xor - 1 ) ;
for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] & set_bit_no ) x = x ^ arr [ i ] ;
else y = y ^ arr [ i ] ;
} for ( i = 1 ; i <= n ; i ++ ) { if ( i & set_bit_no ) x = x ^ i ;
else y = y ^ i ;
} document . write ( " " + y + " " + x ) ; }
let arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 1 ] ; let arr_size = arr . length ; printRepeating ( arr , arr_size ) ;
function printRepeating ( arr , size ) { var i ; document . write ( " " ) ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ Math . abs ( arr [ i ] ) ] > 0 ) arr [ Math . abs ( arr [ i ] ) ] = - arr [ Math . abs ( arr [ i ] ) ] ; else document . write ( Math . abs ( arr [ i ] ) + " " ) ; } }
var arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 1 ] ; var arr_size = arr . length ; printRepeating ( arr , arr_size ) ;
function binarySearch ( arr , low , high ) { if ( high >= low ) { let mid = Math . floor ( ( low + high ) / 2 ) ;
if ( mid == arr [ mid ] ) return mid ; if ( mid > arr [ mid ] ) return binarySearch ( arr , ( mid + 1 ) , high ) ; else return binarySearch ( arr , low , ( mid - 1 ) ) ; }
return - 1 ; }
let arr = [ - 10 , - 1 , 0 , 3 , 10 , 11 , 30 , 50 , 100 ] ; let n = arr . length ; document . write ( " " + binarySearch ( arr , 0 , n - 1 ) ) ;
function find3Numbers ( A , arr_size , sum ) { let l , r ;
for ( let i = 0 ; i < arr_size - 2 ; i ++ ) {
for ( let j = i + 1 ; j < arr_size - 1 ; j ++ ) {
for ( let k = j + 1 ; k < arr_size ; k ++ ) { if ( A [ i ] + A [ j ] + A [ k ] == sum ) { document . write ( " " + A [ i ] + " " + A [ j ] + " " + A [ k ] ) ; return true ; } } } }
return false ; }
let A = [ 1 , 4 , 45 , 6 , 10 , 8 ] ; let sum = 22 ; let arr_size = A . length ; find3Numbers ( A , arr_size , sum ) ;
function search ( arr , n , x ) { let i ; for ( i = 0 ; i < n ; i ++ ) if ( arr [ i ] == x ) return i ; return - 1 ; }
let arr = [ 2 , 3 , 4 , 10 , 40 ] ; let x = 10 ; let n = arr . length ;
let result = search ( arr , n , x ) ; ( result == - 1 ) ? document . write ( " " ) : document . write ( " " + result ) ;
function binarySearch ( arr , l , r , x ) { if ( r >= l ) { let mid = l + Math . floor ( ( r - l ) / 2 ) ;
if ( arr [ mid ] == x ) return mid ;
if ( arr [ mid ] > x ) return binarySearch ( arr , l , mid - 1 , x ) ;
return binarySearch ( arr , mid + 1 , r , x ) ; }
return - 1 ; }
let arr = [ 2 , 3 , 4 , 10 , 40 ] ; let x = 10 ; let n = arr . length let result = binarySearch ( arr , 0 , n - 1 , x ) ; ( result == - 1 ) ? document . write ( " " ) : document . write ( " " + result ) ;
function sort ( arr ) { var n = arr . length ;
var output = Array . from ( { length : n } , ( _ , i ) => 0 ) ;
var count = Array . from ( { length : 256 } , ( _ , i ) => 0 ) ;
for ( var i = 0 ; i < n ; ++ i ) ++ count [ arr [ i ] . charCodeAt ( 0 ) ] ;
for ( var i = 1 ; i <= 255 ; ++ i ) count [ i ] += count [ i - 1 ] ;
for ( var i = n - 1 ; i >= 0 ; i -- ) { output [ count [ arr [ i ] . charCodeAt ( 0 ) ] - 1 ] = arr [ i ] ; -- count [ arr [ i ] . charCodeAt ( 0 ) ] ; }
for ( var i = 0 ; i < n ; ++ i ) arr [ i ] = output [ i ] ; return arr ; }
var arr = [ ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' , ' ' ] ; arr = sort ( arr ) ; document . write ( " " ) ; for ( var i = 0 ; i < arr . length ; ++ i ) document . write ( arr [ i ] ) ; cript
function printMaxActivities ( s , f , n ) { let i , j ; document . write ( " " ) ;
i = 0 ; document . write ( i + " " ) ;
for ( j = 1 ; j < n ; j ++ ) {
if ( s [ j ] >= f [ i ] ) { document . write ( j + " " ) ; i = j ; } } }
let s = [ 1 , 3 , 0 , 5 , 8 , 5 ] let f = [ 2 , 4 , 6 , 7 , 9 , 9 ] let n = s . length ; printMaxActivities ( s , f , n ) ;
function min ( x , y , z ) { if ( x < y ) return ( x < z ) ? x : z ; else return ( y < z ) ? y : z ; }
function minCost ( cost , m , n ) { if ( n < 0 m < 0 ) return Number . MAX_VALUE ; else if ( m == 0 && n == 0 ) return cost [ m ] [ n ] ; else return cost [ m ] [ n ] + min ( minCost ( cost , m - 1 , n - 1 ) , minCost ( cost , m - 1 , n ) , minCost ( cost , m , n - 1 ) ) ; }
var cost = [ [ 1 , 2 , 3 ] , [ 4 , 8 , 2 ] , [ 1 , 5 , 3 ] ] ; document . write ( minCost ( cost , 2 , 2 ) ) ;
function minCost ( cost , m , n ) { let i , j ;
let tc = new Array ( m + 1 ) ; for ( let k = 0 ; k < m + 1 ; k ++ ) { tc [ k ] = new Array ( n + 1 ) ; } tc [ 0 ] [ 0 ] = cost [ 0 ] [ 0 ] ;
for ( i = 1 ; i <= m ; i ++ ) tc [ i ] [ 0 ] = tc [ i - 1 ] [ 0 ] + cost [ i ] [ 0 ] ;
for ( j = 1 ; j <= n ; j ++ ) tc [ 0 ] [ j ] = tc [ 0 ] [ j - 1 ] + cost [ 0 ] [ j ] ;
for ( i = 1 ; i <= m ; i ++ ) for ( j = 1 ; j <= n ; j ++ ) tc [ i ] [ j ] = Math . min ( tc [ i - 1 ] [ j - 1 ] , tc [ i - 1 ] [ j ] , tc [ i ] [ j - 1 ] ) + cost [ i ] [ j ] ; return tc [ m ] [ n ] ; }
function min ( x , y , z ) { if ( x < y ) return ( x < z ) ? x : z ; else return ( y < z ) ? y : z ; }
let cost = [ [ 1 , 2 , 3 ] , [ 4 , 8 , 2 ] , [ 1 , 5 , 3 ] ] ; document . write ( minCost ( cost , 2 , 2 ) ) ;
function binomialCoeff ( n , k ) {
if ( k > n ) return 0 ; if ( k == 0 k == n ) return 1 ;
return binomialCoeff ( n - 1 , k - 1 ) + binomialCoeff ( n - 1 , k ) ; }
var n = 5 , k = 2 ; document . write ( " " + n + " " + k + " " + binomialCoeff ( n , k ) ) ;
function max ( a , b ) { return ( a > b ) ? a : b ; }
function knapSack ( W , wt , val , n ) { let i , w ; let K = new Array ( n + 1 ) ;
for ( i = 0 ; i <= n ; i ++ ) { K [ i ] = new Array ( W + 1 ) ; for ( w = 0 ; w <= W ; w ++ ) { if ( i == 0 w == 0 ) K [ i ] [ w ] = 0 ; else if ( wt [ i - 1 ] <= w ) K [ i ] [ w ] = max ( val [ i - 1 ] + K [ i - 1 ] [ w - wt [ i - 1 ] ] , K [ i - 1 ] [ w ] ) ; else K [ i ] [ w ] = K [ i - 1 ] [ w ] ; } } return K [ n ] [ W ] ; }
let val = [ 60 , 100 , 120 ] ; let wt = [ 10 , 20 , 30 ] ; let W = 50 ; let n = val . length ; document . write ( knapSack ( W , wt , val , n ) ) ;
function max ( x , y ) { return ( x > y ) ? x : y ; }
function lps ( seq , i , j ) {
if ( i == j ) { return 1 ; }
if ( seq [ i ] == seq [ j ] && i + 1 == j ) { return 2 ; }
if ( seq [ i ] == seq [ j ] ) { return lps ( seq , i + 1 , j - 1 ) + 2 ; }
return max ( lps ( seq , i , j - 1 ) , lps ( seq , i + 1 , j ) ) ; }
let seq = " " ; let n = seq . length ; document . write ( " " , lps ( seq . split ( " " ) , 0 , n - 1 ) ) ;
function isSubsetSum ( arr , n , sum ) {
if ( sum == 0 ) return true ; if ( n == 0 && sum != 0 ) return false ;
if ( arr [ n - 1 ] > sum ) return isSubsetSum ( arr , n - 1 , sum ) ;
return isSubsetSum ( arr , n - 1 , sum ) || isSubsetSum ( arr , n - 1 , sum - arr [ n - 1 ] ) ; }
function findPartition ( arr , n ) {
let sum = 0 ; for ( let i = 0 ; i < n ; i ++ ) sum += arr [ i ] ;
if ( sum % 2 != 0 ) return false ;
return isSubsetSum ( arr , n , Math . floor ( sum / 2 ) ) ; }
let arr = [ 3 , 1 , 5 , 9 , 12 ] ; let n = arr . length ;
if ( findPartition ( arr , n ) == true ) document . write ( " " + " " ) ; else document . write ( " " + " " ) ;
function findoptimal ( N ) {
if ( N <= 6 ) return N ;
let max = 0 ;
let b ; for ( b = N - 3 ; b >= 1 ; b -- ) {
let curr = ( N - b - 1 ) * findoptimal ( b ) ; if ( curr > max ) max = curr ; } return max ; }
let N ;
for ( N = 1 ; N <= 20 ; N ++ ) document . write ( " " + N + " " + findoptimal ( N ) + " " ) ;
function search ( pat , txt ) { let M = pat . length ; let N = txt . length ; let i = 0 ; while ( i <= N - M ) { let j ;
for ( j = 0 ; j < M ; j ++ ) if ( txt [ i + j ] != pat [ j ] ) break ;
if ( j == M ) { document . write ( " " + i + " " ) ; i = i + M ; } else if ( j == 0 ) i = i + 1 ; else
i = i + j ; } }
let txt = " " ; let pat = " " ; search ( pat , txt ) ;
function power ( x , y ) { var temp ; if ( y == 0 ) return 1 ; temp = power ( x , parseInt ( y / 2 ) ) ; if ( y % 2 == 0 ) return temp * temp ; else { if ( y > 0 ) return x * temp * temp ; else return ( temp * temp ) / x ; } }
var x = 2 ; var y = - 3 ; document . write ( power ( x , y ) . toFixed ( 6 ) ) ;
function getMedian ( ar1 , ar2 , n ) { var i = 0 ; var j = 0 ; var count ; var m1 = - 1 , m2 = - 1 ;
for ( count = 0 ; count <= n ; count ++ ) {
if ( i == n ) { m1 = m2 ; m2 = ar2 [ 0 ] ; break ; }
else if ( j == n ) { m1 = m2 ; m2 = ar1 [ 0 ] ; break ; }
if ( ar1 [ i ] <= ar2 [ j ] ) { m1 = m2 ;
m2 = ar1 [ i ] ; i ++ ; } else { m1 = m2 ;
m2 = ar2 [ j ] ; j ++ ; } } return ( m1 + m2 ) / 2 ; }
var ar1 = [ 1 , 12 , 15 , 26 , 38 ] ; var ar2 = [ 2 , 13 , 17 , 30 , 45 ] ; var n1 = ar1 . length ; var n2 = ar2 . length ; if ( n1 == n2 ) document . write ( " " + getMedian ( ar1 , ar2 , n1 ) ) ; else document . write ( " " ) ;
function multiply ( x , y ) {
if ( y == 0 ) return 0 ;
if ( y > 0 ) return ( x + multiply ( x , y - 1 ) ) ;
if ( y < 0 ) return - multiply ( x , - y ) ; }
document . write ( multiply ( 5 , - 11 ) ) ;
function pow ( a , b ) { if ( b == 0 ) return 1 ; var answer = a ; var increment = a ; var i , j ; for ( i = 1 ; i < b ; i ++ ) { for ( j = 1 ; j < a ; j ++ ) { answer += increment ; } increment = answer ; } return answer ; }
document . write ( pow ( 5 , 3 ) ) ;
function fact ( n ) { return ( n <= 1 ) ? 1 : n * fact ( n - 1 ) ; }
function findSmallerInRight ( str , low , high ) { let countRight = 0 ; let i ; for ( i = low + 1 ; i <= high ; ++ i ) if ( str [ i ] < str [ low ] ) ++ countRight ; return countRight ; }
function findRank ( str ) { let len = ( str ) . length ; let mul = fact ( len ) ; let rank = 1 ; let countRight ; let i ; for ( i = 0 ; i < len ; ++ i ) { mul /= len - i ;
countRight = findSmallerInRight ( str , i , len - 1 ) ; rank += countRight * mul ; } return rank ; }
let str = " " ; document . write ( findRank ( str ) ) ;
function binomialCoeff ( n , k ) { let res = 1 ;
if ( k > n - k ) k = n - k ;
for ( let i = 0 ; i < k ; ++ i ) { res *= ( n - i ) ; res /= ( i + 1 ) ; } return res ; }
let n = 8 ; let k = 2 ; document . write ( " " + n + " " + k + " " + " " + " " + binomialCoeff ( n , k ) ) ;
function printPascal ( n ) { for ( line = 1 ; line <= n ; line ++ ) {
var C = 1 ; for ( i = 1 ; i <= line ; i ++ ) {
document . write ( C + " " ) ; C = C * ( line - i ) / i ; } document . write ( " " ) ; } }
var n = 5 ; printPascal ( n ) ;
function exponential ( n , x ) {
var sum = 1 ; for ( i = n - 1 ; i > 0 ; -- i ) sum = 1 + x * sum / i ; return sum ; }
var n = 10 ; var x = 1 ; document . write ( " " + exponential ( n , x ) . toFixed ( 6 ) ) ;
function printCombination ( arr , n , r ) {
let data = new Array ( r ) ;
combinationUtil ( arr , n , r , 0 , data , 0 ) ; }
function combinationUtil ( arr , n , r , index , data , i ) {
if ( index == r ) { for ( let j = 0 ; j < r ; j ++ ) { document . write ( data [ j ] + " " ) ; } document . write ( " " ) ; return ; }
if ( i >= n ) { return ; }
data [ index ] = arr [ i ] ; combinationUtil ( arr , n , r , index + 1 , data , i + 1 ) ;
combinationUtil ( arr , n , r , index , data , i + 1 ) ; }
let arr = [ 1 , 2 , 3 , 4 , 5 ] ; let r = 3 ; let n = arr . length ; printCombination ( arr , n , r ) ;
function calcAngle ( h , m ) {
if ( h < 0 m < 0 h > 12 m > 60 ) document . write ( " " ) ; if ( h == 12 ) h = 0 ; if ( m == 60 ) { m = 0 ; h += 1 ; if ( h > 12 ) h = h - 12 ; }
let hour_angle = 0.5 * ( h * 60 + m ) ; let minute_angle = 6 * m ;
let angle = Math . abs ( hour_angle - minute_angle ) ;
angle = min ( 360 - angle , angle ) ; return angle ; }
document . write ( calcAngle ( 9 , 60 ) + " " ) ; document . write ( calcAngle ( 3 , 30 ) + " " ) ;
function getSingle ( arr , n ) { let ones = 0 , twos = 0 ; let common_bit_mask ; for ( let i = 0 ; i < n ; i ++ ) {
twos = twos | ( ones & arr [ i ] ) ;
ones = ones ^ arr [ i ] ;
common_bit_mask = ~ ( ones & twos ) ;
ones &= common_bit_mask ;
twos &= common_bit_mask ; } return ones ; }
let arr = [ 3 , 3 , 2 , 3 ] ; let n = arr . length ; document . write ( " " + getSingle ( arr , n ) ) ;
let INT_SIZE = 32 ; function getSingle ( arr , n ) {
let result = 0 ; let x , sum ;
for ( let i = 0 ; i < INT_SIZE ; i ++ ) {
sum = 0 ; x = ( 1 << i ) ; for ( let j = 0 ; j < n ; j ++ ) { if ( arr [ j ] & x ) sum ++ ; }
if ( ( sum % 3 ) != 0 ) result |= x ; } return result ; }
let arr = [ 12 , 1 , 12 , 3 , 12 , 1 , 1 , 2 , 3 , 2 , 2 , 3 , 7 ] ; let n = arr . length ; document . write ( " " + getSingle ( arr , n ) ) ;
function smallest ( x , y , z ) { let c = 0 ; while ( x && y && z ) { x -- ; y -- ; z -- ; c ++ ; } return c ; }
let x = 12 , y = 15 , z = 5 ; document . write ( " " + smallest ( x , y , z ) ) ;
function addOne ( x ) { return ( - ( ~ x ) ) ; }
document . write ( addOne ( 13 ) ) ;
function isPowerOfFour ( n ) { let count = 0 ;
if ( n && ! ( n & ( n - 1 ) ) ) {
while ( n > 1 ) { n >>= 1 ; count += 1 ; }
return ( count % 2 == 0 ) ? 1 : 0 ; }
return 0 ; }
let test_no = 64 ; if ( isPowerOfFour ( test_no ) ) document . write ( test_no + " " ) ; else document . write ( test_no + " " ) ;
function min ( x , y ) { return y ^ ( ( x ^ y ) & - ( x << y ) ) ; }
function max ( x , y ) { return x ^ ( ( x ^ y ) & - ( x << y ) ) ; }
let x = 15 let y = 6 document . write ( " " + x + " " + y + " " ) ; document . write ( min ( x , y ) + " " ) ; document . write ( " " + x + " " + y + " " ) ; document . write ( max ( x , y ) + " " ) ;
function countSetBits ( n ) { var count = 0 ; while ( n ) { count += n & 1 ; n >>= 1 ; } return count ; }
var i = 9 ; document . write ( countSetBits ( i ) ) ;
var num_to_bits = [ 0 , 1 , 1 , 2 , 1 , 2 , 2 , 3 , 1 , 2 , 2 , 3 , 2 , 3 , 3 , 4 ] ;
function countSetBitsRec ( num ) { var nibble = 0 ; if ( 0 == num ) return num_to_bits [ 0 ] ;
nibble = num & 0xf ;
return num_to_bits [ nibble ] + countSetBitsRec ( num >> 4 ) ; }
var num = 31 ; document . write ( countSetBitsRec ( num ) ) ;
function nextPowerOf2 ( n ) { p = 1 ; if ( n && ! ( n & ( n - 1 ) ) ) return n ; while ( p < n ) p <<= 1 ; return p ; }
n = 5 ; document . write ( nextPowerOf2 ( n ) ) ;
function nextPowerOf2 ( n ) { n -= 1 n |= n >> 1 n |= n >> 2 n |= n >> 4 n |= n >> 8 n |= n >> 16 n += 1 return n }
n = 5 ; document . write ( nextPowerOf2 ( n ) ) ;
function getParity ( n ) { var parity = false ; while ( n != 0 ) { parity = ! parity ; n = n & ( n - 1 ) ; } return parity ; }
var n = 7 ; document . write ( " " + n + " " + ( getParity ( n ) ? " " : " " ) ) ;
function isPowerOfTwo ( n ) { if ( n == 0 ) return false ; return parseInt ( ( Math . ceil ( ( Math . log ( n ) / Math . log ( 2 ) ) ) ) ) == parseInt ( ( Math . floor ( ( ( Math . log ( n ) / Math . log ( 2 ) ) ) ) ) ) ; }
if ( isPowerOfTwo ( 31 ) ) document . write ( " " ) ; else document . write ( " " ) ; if ( isPowerOfTwo ( 64 ) ) document . write ( " " ) ; else document . write ( " " ) ;
function isPowerOfTwo ( x ) {
return x != 0 && ( ( x & ( x - 1 ) ) == 0 ) ; }
document . write ( isPowerOfTwo ( 31 ) ? " " : " " ) ; document . write ( " " + ( isPowerOfTwo ( 64 ) ? " " : " " ) ) ;
function swapBits ( x ) {
even_bits = x & 0xAAAAAAAA ;
odd_bits = x & 0x55555555 ;
even_bits >>= 1 ;
odd_bits <<= 1 ;
return ( even_bits odd_bits ) ; }
let x = 23 ;
document . write ( swapBits ( x ) ) ;
function isPowerOfTwo ( n ) { return ( n > 0 && ( ( n & ( n - 1 ) ) == 0 ) ) ? true : false ; }
function findPosition ( n ) { if ( isPowerOfTwo ( n ) == false ) return - 1 ; var i = 1 ; var pos = 1 ;
while ( ( i & n ) == 0 ) {
i = i << 1 ;
pos += 1 ; } return pos ; }
var n = 16 ; var pos = findPosition ( n ) ; if ( pos == - 1 ) document . write ( " " + n + " " ) ; else document . write ( " " + n + " " + pos ) ; document . write ( " " ) ; n = 12 ; pos = findPosition ( n ) ; if ( pos == - 1 ) document . write ( " " + n + " " ) ; else document . write ( " " + n + " " , pos ) ; document . write ( " " ) ; n = 128 ; pos = findPosition ( n ) ; if ( pos == - 1 ) document . write ( " " + n + " " ) ; else document . write ( " " + n + " " + pos ) ;
function segregate0and1 ( arr , size ) {
let left = 0 , right = size - 1 ; while ( left < right ) {
while ( arr [ left ] == 0 && left < right ) left ++ ;
while ( arr [ right ] == 1 && left < right ) right -- ;
if ( left < right ) { arr [ left ] = 0 ; arr [ right ] = 1 ; left ++ ; right -- ; } } }
let arr = [ 0 , 1 , 0 , 1 , 1 , 1 ] ; let i , arr_size = arr . length ; segregate0and1 ( arr , arr_size ) ; document . write ( " " ) ; for ( i = 0 ; i < 6 ; i ++ ) document . write ( arr [ i ] + " " ) ;
function nextGreatest ( arr , size ) {
max_from_right = arr [ size - 1 ] ;
arr [ size - 1 ] = - 1 ;
for ( let i = size - 2 ; i >= 0 ; i -- ) {
temp = arr [ i ] ;
arr [ i ] = max_from_right ;
if ( max_from_right < temp ) max_from_right = temp ; } }
function printArray ( arr , size ) { var i ; for ( let i = 0 ; i < size ; i ++ ) document . write ( arr [ i ] + " " ) ; }
arr = new Array ( 16 , 17 , 4 , 3 , 5 , 2 ) ; size = arr . length ; nextGreatest ( arr , size ) ; document . write ( " " + " " + " " ) ; printArray ( arr , size ) ;
function maxDiff ( arr , arr_size ) { let max_diff = arr [ 1 ] - arr [ 0 ] ; for ( let i = 0 ; i < arr_size ; i ++ ) { for ( let j = i + 1 ; j < arr_size ; j ++ ) { if ( arr [ j ] - arr [ i ] > max_diff ) max_diff = arr [ j ] - arr [ i ] ; } } return max_diff ; }
let arr = [ 1 , 2 , 90 , 10 , 110 ] ; let n = arr . length ;
document . write ( " " + maxDiff ( arr , n ) ) ;
function findMaximum ( arr , low , high ) {
if ( low == high ) return arr [ low ] ;
if ( ( high == low + 1 ) && arr [ low ] >= arr [ high ] ) return arr [ low ] ;
if ( ( high == low + 1 ) && arr [ low ] < arr [ high ] ) return arr [ high ] ; mid = ( low + high ) / 2 ;
if ( arr [ mid ] > arr [ mid + 1 ] && arr [ mid ] > arr [ mid - 1 ] ) return arr [ mid ] ;
if ( arr [ mid ] > arr [ mid + 1 ] && arr [ mid ] < arr [ mid - 1 ] ) return findMaximum ( arr , low , mid - 1 ) ;
return findMaximum ( arr , mid + 1 , high ) ; }
arr = new Array ( 1 , 3 , 50 , 10 , 9 , 7 , 6 ) ; n = arr . length ; document . write ( " " + " " + findMaximum ( arr , 0 , n - 1 ) ) ;
function getMissingNo ( a , n ) { let total = Math . floor ( ( n + 1 ) * ( n + 2 ) / 2 ) ; for ( let i = 0 ; i < n ; i ++ ) total -= a [ i ] ; return total ; }
let arr = [ 1 , 2 , 4 , 5 , 6 ] ; let n = arr . length ; let miss = getMissingNo ( arr , n ) ; document . write ( miss ) ;
function printTwoElements ( arr , size ) { var i ; document . write ( " " ) ; for ( i = 0 ; i < size ; i ++ ) { var abs_value = Math . abs ( arr [ i ] ) ; if ( arr [ abs_value - 1 ] > 0 ) arr [ abs_value - 1 ] = - arr [ abs_value - 1 ] ; else document . write ( abs_value ) ; } document . write ( " " ) ; for ( i = 0 ; i < size ; i ++ ) { if ( arr [ i ] > 0 ) document . write ( i + 1 ) ; } }
arr = new Array ( 7 , 3 , 4 , 5 , 5 , 6 , 2 ) ; n = arr . length ; printTwoElements ( arr , n ) ;
function printTwoOdd ( arr , size ) {
let xor2 = arr [ 0 ] ;
let set_bit_no ; let i ; int n = size - 2 ; let x = 0 , y = 0 ;
for ( i = 1 ; i < size ; i ++ ) xor2 = xor2 ^ arr [ i ] ;
set_bit_no = xor2 & ~ ( xor2 - 1 ) ;
for ( i = 0 ; i < size ; i ++ ) {
if ( ( arr [ i ] & set_bit_no ) > 0 ) x = x ^ arr [ i ] ;
else y = y ^ arr [ i ] ; } document . write ( " " + x + " " + y + " " ) ; }
let arr = [ 4 , 2 , 4 , 5 , 2 , 3 , 3 , 1 ] ; let arr_size = arr . length ; printTwoOdd ( arr , arr_size ) ;
function findPair ( arr , size , n ) {
let i = 0 ; let j = 1 ;
while ( i < size && j < size ) { if ( i != j && arr [ j ] - arr [ i ] == n ) { document . write ( " " + arr [ i ] + " " + arr [ j ] + " " ) ; return true ; } else if ( arr [ j ] - arr [ i ] < n ) j ++ ; else i ++ ; } document . write ( " " ) ; return false ; }
let arr = [ 1 , 8 , 30 , 40 , 100 ] ; let size = arr . length ; let n = 60 ; findPair ( arr , size , n ) ;
function findFourElements ( A , n , X ) {
for ( let i = 0 ; i < n - 3 ; i ++ ) {
for ( let j = i + 1 ; j < n - 2 ; j ++ ) {
for ( let k = j + 1 ; k < n - 1 ; k ++ ) {
for ( let l = k + 1 ; l < n ; l ++ ) if ( A [ i ] + A [ j ] + A [ k ] + A [ l ] == X ) document . write ( A [ i ] + " " + A [ j ] + " " + A [ k ] + " " + A [ l ] ) ; } } } }
let A = [ 10 , 20 , 30 , 40 , 1 , 2 ] ; let n = A . length ; let X = 91 ; findFourElements ( A , n , X ) ;
let cola = 2 , rowa = 3 , colb = 3 , rowb = 2 ;
function Kroneckerproduct ( A , B ) { let C = new Array ( rowa * rowb ) for ( let i = 0 ; i < ( rowa * rowb ) ; i ++ ) { C [ i ] = new Array ( cola * colb ) ; for ( let j = 0 ; j < ( cola * colb ) ; j ++ ) { C [ i ] [ j ] = 0 ; } }
for ( let i = 0 ; i < rowa ; i ++ ) {
for ( let k = 0 ; k < rowb ; k ++ ) {
for ( let j = 0 ; j < cola ; j ++ ) {
for ( let l = 0 ; l < colb ; l ++ ) {
C [ i + l + 1 ] [ j + k + 1 ] = A [ i ] [ j ] * B [ k ] [ l ] ; document . write ( C [ i + l + 1 ] [ j + k + 1 ] + " " ) ; } } document . write ( " " ) ; } } }
let A = [ [ 1 , 2 ] , [ 3 , 4 ] , [ 1 , 0 ] ] ; let B = [ [ 0 , 5 , 2 ] , [ 6 , 7 , 3 ] ] ; Kroneckerproduct ( A , B ) ;
function Identity ( num ) { var row ; var col ; for ( row = 0 ; row < num ; row ++ ) { for ( col = 0 ; col < num ; col ++ ) {
if ( row == col ) document . write ( 1 + " " ) ; else document . write ( 0 + " " ) ; } document . write ( " " + " " ) ; } return 0 ; }
size = 5 ; Identity ( size ) ;
var N = 4 ;
function subtract ( A , B , C ) { var i , j ; for ( i = 0 ; i < N ; i ++ ) for ( j = 0 ; j < N ; j ++ ) C [ i ] [ j ] = A [ i ] [ j ] - B [ i ] [ j ] ; }
var A = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] ; var B = [ [ 1 , 1 , 1 , 1 ] , [ 2 , 2 , 2 , 2 ] , [ 3 , 3 , 3 , 3 ] , [ 4 , 4 , 4 , 4 ] ] ; var C = Array . from ( Array ( N ) , ( ) => Array ( N ) ) ; var i , j ; subtract ( A , B , C ) ; document . write ( " " + " " ) ; for ( i = 0 ; i < N ; i ++ ) { for ( j = 0 ; j < N ; j ++ ) document . write ( C [ i ] [ j ] + " " ) ; document . write ( " " ) ; }
